function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='2BB18181BDBE29D4E229DEB0CBD9E1D4',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '2BB18181BDBE29D4E229DEB0CBD9E1D4';function n(){}
function s(){}
function Y(){}
function be(){}
function Zd(){}
function eb(){}
function of(){}
function pf(){}
function ph(){}
function dh(){}
function hh(){}
function lh(){}
function Ih(){}
function Wh(){}
function Xg(){}
function $g(){}
function gi(){}
function ii(){}
function ji(){}
function ui(){}
function u(){new Me}
function v(a){Te(a)}
function cb(a){bb()}
function Ti(a){a.p()}
function nf(a,b){a.a=b}
function mf(a){this.a=a}
function qf(a){this.a=a}
function th(a){this.a=a}
function uh(a){this.a=a}
function wh(a){this.a=a}
function xh(a){this.a=a}
function yh(a){this.a=a}
function zh(a){this.a=a}
function Ah(a){this.a=a}
function Bh(a){this.a=a}
function Ch(a){this.a=a}
function Dh(a){this.a=a}
function Gh(a){this.a=a}
function Hh(a){this.a=a}
function hi(a){this.a=a}
function ki(a){this.a=a}
function si(a){this.a=a}
function ti(a){this.a=a}
function vi(a){this.a=a}
function Pe(a){this.c=a}
function ie(){ie=Zd}
function r(){r=Zd;new q}
function F(){F=Zd;D=new n}
function V(){V=Zd;U=new Y}
function L(){L=Zd;!!(bb(),ab)}
function Ff(a,b){Ef(a,b)}
function Uh(a,b){He(a.c,b)}
function bi(a,b){He(a.b,b)}
function oi(a,b){He(a.a,b)}
function Ge(a,b,c){rf(a.a,b,c)}
function Gf(a,b){a.key=b}
function sf(a,b){a.splice(b,1)}
function fb(a,b){return re(a,b)}
function Kg(a,b){return a.a=b}
function De(a,b){return a===b}
function Id(a){return a.b}
function Ri(a){return false}
function Qi(){return wf(this)}
function Be(){w(this);this.r()}
function le(a){ke(a);return a.k}
function ff(a,b){a.D(b);return a}
function Pf(a,b){a.ref=b;return a}
function bf(a,b){Ye(a);a.a.H(b)}
function gf(a,b){nf(a,ff(a.a,b))}
function Ue(a,b){while(a.I(b));}
function we(a,b){this.a=a;this.b=b}
function kf(a,b){this.a=a;this.b=b}
function Nf(a,b){this.a=a;this.b=b}
function wg(a,b){we.call(this,a,b)}
function rf(a,b,c){a.splice(b,0,c)}
function Qf(a,b){a.href=b;return a}
function S(a){$wnd.clearTimeout(a)}
function kb(a){return new Array(a)}
function Gb(a){return a.l|a.m<<22}
function Ub(a){return typeof a===xi}
function Wb(a){return a==null?null:a}
function Sd(){Qd==null&&(Qd=[])}
function T(){I!=0&&(I=0);K=-1}
function Yg(){this.a=Hf((ah(),_g))}
function Zg(){this.a=Hf((fh(),eh))}
function vh(){this.a=Hf((jh(),ih))}
function Fh(){this.a=Hf((nh(),mh))}
function Jh(){this.a=Hf((rh(),qh))}
function zg(a){this.d=Te(a);r();++yg}
function Bg(a){this.d=Te(a);r();++Ag}
function Hg(a){this.d=Te(a);r();++Gg}
function Wg(a){this.d=Te(a);r();++Vg}
function Xe(a){this.b=a;this.a=16464}
function Rh(a,b){we.call(this,a,b)}
function Zf(a,b){a.value=b;return a}
function Uf(a,b){a.onBlur=b;return a}
function Rf(a,b){a.onClick=b;return a}
function Tf(a,b){a.checked=b;return a}
function Vf(a,b){a.onChange=b;return a}
function Th(a,b){a.a=b;Ie(a.c,new Wh)}
function fi(a,b){b.a=a;Ie(b.c,new Wh)}
function ni(a,b){a.b=b;Ie(a.a,new ui)}
function ob(a){return pb(a.l,a.m,a.h)}
function Ne(a){return a.a<a.c.a.length}
function Ce(a,b){return a.charCodeAt(b)}
function Sb(a,b){return a!=null&&Qb(a,b)}
function pb(a,b,c){return {l:a,m:b,h:c}}
function $h(a,b){return Je(a.a,b,0)!=-1}
function wf(a){return a.$H||(a.$H=++vf)}
function Si(){this.a.d.forceUpdate()}
function Fg(a,b){a.a=b;a.d.forceUpdate()}
function Rg(a,b){a.b=b;a.d.forceUpdate()}
function A(a,b){a.b=b;b!=null&&uf(b,Ai,a)}
function ke(a){if(a.k!=null){return}te(a)}
function Wf(a,b){a.onKeyDown=b;return a}
function Sf(a){a.autoFocus=true;return a}
function Af(){Af=Zd;xf=new n;zf=new n}
function ei(){this.a=new Me;this.b=new Me}
function C(a){this.c=a;w(this);this.r()}
function ef(a,b){$e.call(this,a);this.a=b}
function Ef(a,b){for(var c in a){b(c)}}
function uf(b,c,d){try{b[c]=d}catch(a){}}
function M(a,b,c){return a.apply(b,c);var d}
function Vb(a){return typeof a==='string'}
function Tb(a){return typeof a==='boolean'}
function he(){C.call(this,'divide by zero')}
function Me(){this.a=hb(tc,yi,1,0,5,1)}
function _h(a,b){Ke(a.a,b);Ie(a.b,new ii)}
function ci(a,b){Th(b,!b.a);Ie(a.b,new ii)}
function oe(a){var b;b=ne(a);ve(a,b);return b}
function w(a){a.d&&a.b!==zi&&a.r();return a}
function $f(a,b){a.onDoubleClick=b;return a}
function He(a,b){a.a[a.a.length]=b;return true}
function Oe(a){a.b=a.a++;return a.c.a[a.b]}
function Od(a){if(Ub(a)){return a|0}return Gb(a)}
function Og(a){ci((Mh(),Kh),a.d.props['a'])}
function Lg(a){_h((Mh(),Kh),a.d.props['a'])}
function hf(a,b,c){if(a.a.K(c)){a.b=true;b.J(c)}}
function ge(a,b,c,d){a.addEventListener(b,c,d)}
function Mh(){Mh=Zd;Kh=new ei;Lh=new qi(Kh)}
function bb(){bb=Zd;var a;!db();a=new eb;ab=a}
function cf(a){Ze(a);return new ef(a,new lf(a.a))}
function Pd(a){if(Ub(a)){return ''+a}return Hb(a)}
function Te(a){if(a==null){throw Id(new Be)}return a}
function qe(a){var b;b=ne(a);b.j=a;b.e=1;return b}
function Z(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Yf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Cg(a,b){var c;c=b.target;Fg(a,c.value)}
function af(a,b){Ze(a);return new ef(a,new jf(b,a.a))}
function Ye(a){if(!a.b){Ze(a);a.c=true}else{Ye(a.b)}}
function $e(a){if(!a){this.b=null;new Me}else{this.b=a}}
function q(){this.a=new t;new v(this.a);new u}
function jb(a){return Array.isArray(a)&&a.T===be}
function Rb(a){return !Array.isArray(a)&&a.T===be}
function ri(a,b){return (Qh(),Oh)==a||(Nh==a?!b.a:b.a)}
function Se(a,b){return Wb(a)===Wb(b)||!!a&&Wb(a)===Wb(b)}
function Ve(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function lf(a){Ve.call(this,a.G(),a.F()&-6);this.a=a}
function Ug(a){bi((Mh(),Kh),new Gh(a));oi(Lh,new Hh(a))}
function ai(a,b,c){b.d=Te(c);Ie(b.c,new Wh);Ie(a.b,new ii)}
function pe(a,b){var c;c=ne(a);ve(a,c);c.e=b?8:0;return c}
function We(a){if(!a.d){a.d=new Pe(a.b);a.c=a.b.a.length}}
function se(a){if(a.B()){return null}var b=a.j;return Vd[b]}
function _d(a){function b(){}
;b.prototype=a||{};return new b}
function fh(){fh=Zd;var a;eh=(a=$d(dh.prototype.Q,dh,[]),a)}
function jh(){jh=Zd;var a;ih=(a=$d(hh.prototype.Q,hh,[]),a)}
function nh(){nh=Zd;var a;mh=(a=$d(lh.prototype.Q,lh,[]),a)}
function rh(){rh=Zd;var a;qh=(a=$d(ph.prototype.Q,ph,[]),a)}
function ah(){ah=Zd;var a;_g=(a=$d($g.prototype.Q,$g,[]),a)}
function Sh(){Qh();return lb(fb(sd,1),yi,22,0,[Nh,Ph,Oh])}
function R(a){L();$wnd.setTimeout(function(){throw a},0)}
function bh(a){$wnd.React.Component.call(this,a);new zg(this)}
function gh(a){$wnd.React.Component.call(this,a);new Bg(this)}
function Ze(a){if(a.b){Ze(a.b)}else if(a.c){throw Id(new xe)}}
function Q(a){a&&X((V(),U));--I;if(a){if(K!=-1){S(K);K=-1}}}
function Df(){if(yf==256){xf=zf;zf=new n;yf=0}++yf}
function Xd(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function re(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.t(b))}
function P(a,b,c){var d;d=N();try{return M(a,b,c)}finally{Q(d)}}
function Mf(a,b,c){!De(c,'key')&&!De(c,'ref')&&(a[c]=b[c],undefined)}
function jf(a,b){Ve.call(this,b.G(),b.F()&-16449);this.a=a;this.c=b}
function Fe(){C.call(this,'Add not supported on this collection')}
function Xf(a){a.placeholder='What needs to be done?';return a}
function B(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function O(b){L();return function(){return P(b,this,arguments);var a}}
function Xb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Mg(a){ni((Mh(),Lh),a.d.props['a']);Rg(a,a.d.props['a'].d)}
function Re(a,b){while(a.a<a.c.a.length){b.J((a.b=a.a++,a.c.a[a.b]))}}
function pi(a){var b;b=a.b;!!b&&!$h(a.c,b)&&(a.b=null,Ie(a.a,new ui))}
function di(a,b){bf(new ef(null,new Xe(a.a)),new ki(b));Ie(a.b,new ii)}
function Xh(a,b){He(a.a,new Vh(''+Pd(Ld(Date.now())),b));Ie(a.b,new ii)}
function Vh(a,b){this.c=new Me;this.b=Te(a);this.d=Te(b);this.a=false}
function kh(a){$wnd.React.Component.call(this,a);this.a=new Hg(this)}
function oh(a){$wnd.React.Component.call(this,a);this.a=new Tg(this)}
function sh(a){$wnd.React.Component.call(this,a);this.a=new Wg(this)}
function H(){if(Date.now){return Date.now()}return (new Date).getTime()}
function fe(){fe=Zd;de=$wnd.window.document;ee=$wnd.window.window}
function _e(a){var b;Ye(a);b=0;while(a.a.I(new pf)){b=Jd(b,1)}return b}
function df(a,b){var c;Ye(a);c=new of;c.a=b;a.a.H(new qf(c));return c.a}
function Ke(a,b){var c;c=Je(a,b,0);if(c==-1){return false}sf(a.a,c);return true}
function hb(a,b,c,d,e,f){var g;g=ib(e,d);e!=10&&lb(fb(a,f),b,c,e,g);return g}
function Je(a,b,c){for(;c<a.a.length;++c){if(Se(b,a.a[c])){return c}}return -1}
function nb(a){var b,c,d;b=a&Ci;c=a>>22&Ci;d=a<0?Di:0;return pb(b,c,d)}
function Ie(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.J(c)}}
function Ig(a,b){var c;if((Mh(),Lh).b==a.d.props['a']){c=b.target;Rg(a,c.value)}}
function W(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=$(b,c)}while(a.a);a.a=c}}
function X(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=$(b,c)}while(a.b);a.b=c}}
function t(){var a;this.a=hb($b,yi,27,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function Mb(){Mb=Zd;Ib=pb(Ci,Ci,524287);Jb=pb(0,0,Ei);Kb=nb(1);nb(2);Lb=nb(0)}
function Hd(a){var b;if(Sb(a,5)){return a}b=a&&a[Ai];if(!b){b=new G(a);cb(b)}return b}
function ve(a,b){var c;if(!a){return}b.j=a;var d=se(b);if(!d){Vd[a]=[b];return}d.R=b}
function ze(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function $d(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ne(a){var b;b=new me;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Hf(a){var b;b=Jf($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Kf(a){var b;return If($wnd.React.StrictMode,null,null,(b={},b[Ii]=Te(a),b))}
function Yh(a){var b;df(af(new ef(null,new Xe(a.a)),new gi),(b=new Me,b)).C(new hi(a))}
function Qh(){Qh=Zd;Nh=new Rh('ACTIVE',0);Ph=new Rh('COMPLETED',1);Oh=new Rh('ALL',2)}
function ce(){$wnd.ReactDOM.render(Kf([(new Jh).a]),(fe(),de).getElementById('app'),null)}
function tf(a,b){return gb(b)!=10&&lb(o(b),b.S,b.__elementTypeId$,gb(b),a),a}
function gb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function xe(){C.call(this,"Stream already terminated, can't be modified or used")}
function Rd(){Sd();var a=Qd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Ae(a,b){var c,d;for(d=new Pe(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);_h(b.a,c)}}
function Nd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Fi;d=Di}c=Xb(e/Gi);b=Xb(e-c*Gi);return pb(b,c,d)}
function zb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return pb(c&Ci,d&Ci,e&Di)}
function Fb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return pb(c&Ci,d&Ci,e&Di)}
function Kd(a){var b;b=a.h;if(b==0){return a.l+a.m*Gi}if(b==Di){return a.l+a.m*Gi-Fi}return a}
function Ld(a){if(Hi<a&&a<Fi){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Kd(Bb(a))}
function Eh(a,b){Gf(a.a,(ke(nd),nd.k+(''+(b?b.b:null))));Te(b);a.a.props['a']=b;return a.a}
function Jg(a,b){27==b.which?(ni((Mh(),Lh),null),Rg(a,a.d.props['a'].d)):13==b.which&&Ng(a)}
function Tg(a){this.d=Te(a);r();++Sg;this.b=this.d.props['a'].d;Uh(this.d.props['a'],new wh(this))}
function G(a){F();w(this);this.b=a;a!=null&&uf(a,Ai,this);this.c=a==null?'null':ae(a);this.a=a}
function Zh(a){return Od(_e(new ef(null,new Xe(a.a))))-Od(_e(af(new ef(null,new Xe(a.a)),new ji)))}
function qi(a){this.a=new Me;this.c=Te(a);ge((fe(),ee),'hashchange',new si(this),false);bi(a,new ti(this))}
function me(){this.g=je++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function vb(a){var b,c,d;b=~a.l+1&Ci;c=~a.m+(b==0?1:0)&Ci;d=~a.h+(b==0&&c==0?1:0)&Di;a.l=b;a.m=c;a.h=d}
function Cb(a){var b,c,d;b=~a.l+1&Ci;c=~a.m+(b==0?1:0)&Ci;d=~a.h+(b==0&&c==0?1:0)&Di;return pb(b,c,d)}
function wb(a){var b,c;c=ye(a.h);if(c==32){b=ye(a.m);return b==32?ye(a.l)+32:b+20-10}else{return c-12}}
function If(a,b,c,d){var e;e=Jf($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Te(d);return e}
function lb(a,b,c,d,e){e.R=a;e.S=b;e.T=be;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function sb(a,b,c,d,e){var f;f=Eb(a,b);c&&vb(f);if(e){a=ub(a,b);d?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h))}return f}
function rb(a,b){if(a.h==Ei&&a.m==0&&a.l==0){b&&(mb=pb(0,0,0));return ob((Mb(),Kb))}b&&(mb=pb(a.l,a.m,a.h));return pb(0,0,0)}
function Jd(a,b){var c;if(Ub(a)&&Ub(b)){c=a+b;if(Hi<c&&c<Fi){return c}}return Kd(zb(Ub(a)?Nd(a):a,Ub(b)?Nd(b):b))}
function o(a){return Vb(a)?vc:Ub(a)?mc:Tb(a)?kc:Rb(a)?a.R:jb(a)?a.R:a.R||Array.isArray(a)&&fb(dc,1)||dc}
function p(a){return Vb(a)?Cf(a):Ub(a)?Xb(a):Tb(a)?a?1231:1237:Rb(a)?a.o():jb(a)?wf(a):!!a&&!!a.hashCode?a.hashCode():wf(a)}
function ae(a){var b;if(Array.isArray(a)&&a.T===be){return le(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function N(){var a;if(I!=0){a=H();if(a-J>2000){J=a;K=$wnd.setTimeout(T,10)}}if(I++==0){W((V(),U));return true}return false}
function Dg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=Ee(a.a);if(c.length>0){Xh((Mh(),Kh),c);a.a='';a.d.forceUpdate()}}}
function ue(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Le(a,b){var c,d;d=a.a.length;b.length<d&&(b=tf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Qe(a){var b,c,d;d=1;for(c=new Pe(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function Cf(a){Af();var b,c,d;c=':'+a;d=zf[c];if(d!=null){return Xb(d)}d=xf[c];b=d==null?Bf(a):Xb(d);Df();zf[c]=b;return b}
function Ud(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function xg(){vg();return lb(fb(Qc,1),yi,6,0,[_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg,rg,sg,tg,ug])}
function db(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Ng(a){if(null!=a.b&&a.b.length!=0){ai((Mh(),Kh),a.d.props['a'],a.b);ni(Lh,null);Rg(a,a.b)}else{_h((Mh(),Kh),a.d.props['a'])}}
function Of(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Qb(a,b){if(Vb(a)){return !!Pb[b]}else if(a.S){return !!a.S[b]}else if(Ub(a)){return !!Ob[b]}else if(Tb(a)){return !!Nb[b]}return false}
function Pg(a){var b;b=(Mh(),Lh).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();Rg(a,a.d.props['a'].d)}else a.c&&!b&&(a.c=false)}
function Ee(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ub(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return pb(c,d,e)}
function Db(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return pb(c&Ci,d&Ci,e&Di)}
function ib(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function yb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&Ci;a.m=d&Ci;a.h=e&Di;return true}
function Eg(a){return Lf(Ki,Sf(Vf(Wf(Zf(Xf(Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,['new-todo']))),a.a),$d(th.prototype.O,th,[a])),$d(uh.prototype.N,uh,[a]))),null)}
function Ab(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Td(b,c,d,e){Sd();var f=Qd;$moduleName=c;$moduleBase=d;Gd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{wi(g)()}catch(a){b(c,a)}}else{wi(g)()}}
function Jf(a,b){var c;c=new $wnd.Object;c.$$typeof=Te(a);c.type=Te(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function $(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].U()&&(c=Z(c,g)):g[0].U()}catch(a){a=Hd(a);if(Sb(a,5)){d=a;L();R(Sb(d,24)?d.s():d)}else throw Id(a)}}return c}
function Wd(){Vd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function li(a){var b,c,d,e;b=(e=(c=(fe(),ee).location.hash,null==c?'':c.substr(1)),De(Li,e)?(Qh(),Nh):De(Mi,e)?(Qh(),Ph):(Qh(),Oh));return df(af(new ef(null,new Xe(a.c.a)),new vi(b)),(d=new Me,d))}
function Bf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ce(a,c++)}b=b|0;return b}
function ye(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Yd(a,b,c){var d=Vd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Vd[b]),_d(h));_.S=c;!b&&(_.T=be);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.R=f)}
function Eb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&Ei)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?Di:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?Di:0;f=d?Ci:0;e=c>>b-44}return pb(e&Ci,f&Ci,g&Di)}
function mi(a,b){var c,d,e;b.preventDefault();c=(d=(fe(),ee).location.hash,null==d?'':d.substr(1));if(De(Li,c)||De(Mi,c)||De('',c)){Ie(a.a,new ui)}else{e=ee.location.pathname+(''+ee.location.search);ee.history.pushState('',de.title,e)}}
function te(a){if(a.A()){var b=a.c;b.B()?(a.k='['+b.j):!b.A()?(a.k='[L'+b.v()+';'):(a.k='['+b.v());a.b=b.u()+'[]';a.i=b.w()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=ue('.',[c,ue('$',d)]);a.b=ue('.',[c,ue('.',d)]);a.i=d[d.length-1]}
function Lf(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Ff(b,$d(Nf.prototype.L,Nf,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ii]=c[0],undefined):(d[Ii]=c,undefined));return If(a,e,f,d)}
function xb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return ze(c)}if(b==0&&d!=0&&c==0){return ze(d)+22}if(b!=0&&d==0&&c==0){return ze(b)+44}return -1}
function Bb(a){var b,c,d,e,f;if(isNaN(a)){return Mb(),Lb}if(a<-9223372036854775808){return Mb(),Jb}if(a>=9223372036854775807){return Mb(),Ib}e=false;if(a<0){e=true;a=-a}d=0;if(a>=Fi){d=Xb(a/Fi);a-=d*Fi}c=0;if(a>=Gi){c=Xb(a/Gi);a-=c*Gi}b=Xb(a);f=pb(b,c,d);e&&vb(f);return f}
function Hb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==Ei&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Hb(Cb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=nb(1000000000);c=qb(c,e,true);b=''+Gb(mb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function tb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=wb(b)-wb(a);g=Db(b,j);i=pb(0,0,0);while(j>=0){h=yb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&vb(i);if(f){if(d){mb=Cb(a);e&&(mb=Fb(mb,(Mb(),Kb)))}else{mb=pb(a.l,a.m,a.h)}}return i}
function vg(){vg=Zd;_f=new wg(Ji,0);ag=new wg('checkbox',1);bg=new wg('color',2);cg=new wg('date',3);dg=new wg('datetime',4);eg=new wg('email',5);fg=new wg('file',6);gg=new wg('hidden',7);hg=new wg('image',8);ig=new wg('month',9);jg=new wg(xi,10);kg=new wg('password',11);lg=new wg('radio',12);mg=new wg('range',13);ng=new wg('reset',14);og=new wg('search',15);pg=new wg('submit',16);qg=new wg('tel',17);rg=new wg('text',18);sg=new wg('time',19);tg=new wg('url',20);ug=new wg('week',21)}
function qb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Id(new he)}if(a.l==0&&a.m==0&&a.h==0){c&&(mb=pb(0,0,0));return pb(0,0,0)}if(b.h==Ei&&b.m==0&&b.l==0){return rb(a,c)}i=false;if(b.h>>19!=0){b=Cb(b);i=true}g=xb(b);f=false;e=false;d=false;if(a.h==Ei&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ob((Mb(),Ib));d=true;i=!i}else{h=Eb(a,g);i&&vb(h);c&&(mb=pb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Cb(a);d=true;i=!i}if(g!=-1){return sb(a,g,i,f,c)}if(Ab(a,b)<0){c&&(f?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h)));return pb(0,0,0)}return tb(d?a:pb(a.l,a.m,a.h),b,i,f,e,c)}
function Qg(a){var b,c;c=a.d.props['a'];b=c.a;return Lf('li',Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,[b?'checked':null,(Mh(),Lh).b==a.d.props['a']?'editing':null])),[Lf('div',Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,['view'])),[Lf(Ki,Vf(Tf(Yf(Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,['toggle'])),(vg(),ag)),b),$d(zh.prototype.N,zh,[a])),null),Lf('label',$f(new $wnd.Object,$d(Ah.prototype.P,Ah,[a])),[c.d]),Lf(Ji,Rf(Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,['destroy'])),$d(Bh.prototype.P,Bh,[a])),null)]),Lf(Ki,Wf(Vf(Uf(Zf(Of(Pf(new $wnd.Object,$d(Ch.prototype.J,Ch,[a])),lb(fb(vc,1),yi,2,6,['edit'])),a.b),$d(Dh.prototype.M,Dh,[a])),$d(xh.prototype.N,xh,[a])),$d(yh.prototype.O,yh,[a])),null)])}
var xi='number',yi={3:1,4:1},zi='__noinit__',Ai='__java$exception',Bi={3:1,7:1,5:1},Ci=4194303,Di=1048575,Ei=524288,Fi=17592186044416,Gi=4194304,Hi=-17592186044416,Ii='children',Ji='button',Ki='input',Li='active',Mi='completed',Ni='selected',Oi='header',Pi={40:1};var _,Vd,Qd,Gd=-1;Wd();Yd(1,null,{},n);_.n=function(){return this.R};_.o=Qi;_.hashCode=function(){return this.o()};var Nb,Ob,Pb;Yd(33,1,{},me);_.t=function(a){var b;b=new me;b.e=4;a>1?(b.c=re(this,a-1)):(b.c=this);return b};_.u=function(){ke(this);return this.b};_.v=function(){return le(this)};_.w=function(){ke(this);return this.i};_.A=function(){return (this.e&4)!=0};_.B=function(){return (this.e&1)!=0};_.e=0;_.g=0;var je=1;var tc=oe(1);var lc=oe(33);Yd(60,1,{},q);var Zb=oe(60);Yd(27,1,{27:1},s);var $b=oe(27);Yd(71,1,{149:1},t);var _b=oe(71);Yd(73,1,{},u);var ac=oe(73);Yd(72,1,{},v);var bc=oe(72);Yd(5,1,{3:1,5:1});_.q=function(a){return new Error(a)};_.r=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=le(this.R),c==null?a:a+': '+c);A(this,B(this.q(b)));cb(this)};_.b=zi;_.d=true;var wc=oe(5);Yd(25,5,{3:1,5:1});var oc=oe(25);Yd(7,25,Bi);var uc=oe(7);Yd(34,7,Bi);var qc=oe(34);Yd(46,34,Bi);var fc=oe(46);Yd(24,46,{24:1,3:1,7:1,5:1},G);_.s=function(){return Wb(this.a)===Wb(D)?null:this.a};var D;var cc=oe(24);var dc=oe(0);Yd(103,1,{});var ec=oe(103);var I=0,J=0,K=-1;Yd(54,103,{},Y);var U;var gc=oe(54);var ab;Yd(116,1,{});var ic=oe(116);Yd(47,116,{},eb);var hc=oe(47);var mb;var Ib,Jb,Kb,Lb;var de,ee;Yd(52,7,Bi,he);var jc=oe(52);Nb={3:1,23:1};var kc=oe(113);Yd(114,1,{3:1});var sc=oe(114);Ob={3:1,23:1};var mc=oe(115);Yd(20,1,{3:1,23:1,20:1});_.o=Qi;_.b=0;var nc=oe(20);Yd(49,7,Bi,xe);var pc=oe(49);Yd(178,1,{});Yd(51,34,Bi,Be);_.q=function(a){return new TypeError(a)};var rc=oe(51);Pb={3:1,42:1,23:1,2:1};var vc=oe(2);Yd(182,1,{});Yd(50,7,Bi,Fe);var xc=oe(50);Yd(117,1,{100:1});_.C=function(a){Ae(this,a)};_.D=function(a){throw Id(new Fe)};var yc=oe(117);Yd(118,117,{100:1,125:1});_.D=function(a){Ge(this,this.a.length,a);return true};_.o=function(){return Qe(this)};var zc=oe(118);Yd(10,118,{3:1,10:1,100:1,125:1},Me);_.D=function(a){return He(this,a)};_.C=function(a){Ie(this,a)};var Bc=oe(10);Yd(17,1,{},Pe);_.a=0;_.b=-1;var Ac=oe(17);Yd(76,1,{});_.H=function(a){Ue(this,a)};_.F=function(){return this.d};_.G=function(){return this.e};_.d=0;_.e=0;var Dc=oe(76);Yd(36,76,{});var Cc=oe(36);Yd(13,1,{},Xe);_.F=function(){return this.a};_.G=function(){We(this);return this.c};_.H=function(a){We(this);Re(this.d,a)};_.I=function(a){We(this);if(Ne(this.d)){a.J(Oe(this.d));return true}return false};_.a=0;_.c=0;var Ec=oe(13);Yd(75,1,{});_.c=false;var Nc=oe(75);Yd(11,75,{148:1,11:1},ef);var Mc=oe(11);Yd(78,36,{},jf);_.I=function(a){this.b=false;while(!this.b&&this.c.I(new kf(this,a)));return this.b};_.b=false;var Gc=oe(78);Yd(81,1,{},kf);_.J=function(a){hf(this.a,this.b,a)};var Fc=oe(81);Yd(77,36,{},lf);_.I=function(a){return this.a.I(new mf(a))};var Ic=oe(77);Yd(80,1,{},mf);_.J=function(a){this.a.J(Eh(new Fh,a))};var Hc=oe(80);Yd(79,1,{},of);_.J=function(a){nf(this,a)};var Jc=oe(79);Yd(82,1,{},pf);_.J=function(a){};var Kc=oe(82);Yd(83,1,{},qf);_.J=function(a){gf(this.a,a)};var Lc=oe(83);Yd(180,1,{});Yd(123,1,{});var Oc=oe(123);Yd(177,1,{});var vf=0;var xf,yf=0,zf;Yd(781,1,{});Yd(119,1,{});var Pc=oe(119);Yd(147,$wnd.Function,{},Nf);_.L=function(a){Mf(this.a,this.b,a)};Yd(6,20,{3:1,23:1,20:1,6:1},wg);var _f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg,rg,sg,tg,ug;var Qc=pe(6,xg);Yd(122,119,{});var Zc=oe(122);Yd(92,122,{});var bd=oe(92);Yd(93,92,{},zg);_.o=Qi;var yg=0;var Sc=oe(93);Yd(124,119,{});var Yc=oe(124);Yd(98,124,{});var ad=oe(98);Yd(99,98,{},Bg);_.o=Qi;var Ag=0;var Rc=oe(99);Yd(89,119,{});_.a='';var kd=oe(89);Yd(90,89,{});var dd=oe(90);Yd(91,90,{},Hg);_.o=Qi;var Gg=0;var Tc=oe(91);Yd(121,119,{});_.c=false;var nd=oe(121);Yd(95,121,{});var fd=oe(95);Yd(96,95,{},Tg);_.o=Qi;var Sg=0;var Uc=oe(96);Yd(120,119,{});var rd=oe(120);Yd(58,120,{});var hd=oe(58);Yd(59,58,{},Wg);_.o=Qi;var Vg=0;var Vc=oe(59);Yd(154,$wnd.Function,{},Xg);_.P=function(a){Yh((Mh(),Kh))};Yd(66,1,{},Yg);var Wc=oe(66);Yd(94,1,{},Zg);var Xc=oe(94);Yd(153,$wnd.Function,{},$g);_.Q=function(a){return new bh(a)};var _g;Yd(85,$wnd.React.Component,{},bh);Xd(Vd[1],_);_.render=function(){var a,b,c;return a=(c=(Mh(),b=(fe(),ee).location.hash,null==b?'':b.substr(1)),De(Li,c)?(Qh(),Nh):De(Mi,c)?(Qh(),Ph):(Qh(),Oh)),Lf('footer',Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,['footer'])),[(new Zg).a,Lf('ul',Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,['filters'])),[Lf('li',null,[Lf('a',Qf(Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,[(Qh(),Oh)==a?Ni:null])),'#'),['All'])]),Lf('li',null,[Lf('a',Qf(Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,[Nh==a?Ni:null])),'#active'),['Active'])]),Lf('li',null,[Lf('a',Qf(Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,[Ph==a?Ni:null])),'#completed'),['Completed'])])]),Zh(Kh)>0?Lf(Ji,Rf(Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,['clear-completed'])),$d(Xg.prototype.P,Xg,[])),['Clear Completed']):null])};_.shouldComponentUpdate=Ri;var $c=oe(85);Yd(164,$wnd.Function,{},dh);_.Q=function(a){return new gh(a)};var eh;Yd(97,$wnd.React.Component,{},gh);Xd(Vd[1],_);_.render=function(){var a,b;return a=Od(_e(new ef(null,new Xe((Mh(),Kh).a)))),b='item'+(a==1?'':'s'),Lf('span',Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,['todo-count'])),[Lf('strong',null,[a]),' '+b+' left'])};_.shouldComponentUpdate=Ri;var _c=oe(97);Yd(150,$wnd.Function,{},hh);_.Q=function(a){return new kh(a)};var ih;Yd(74,$wnd.React.Component,{},kh);Xd(Vd[1],_);_.render=function(){return Eg(this.a)};_.shouldComponentUpdate=Ri;var cd=oe(74);Yd(163,$wnd.Function,{},lh);_.Q=function(a){return new oh(a)};var mh;Yd(88,$wnd.React.Component,{},oh);Xd(Vd[1],_);_.componentDidUpdate=function(a){Pg(this.a)};_.render=function(){return Qg(this.a)};_.shouldComponentUpdate=Ri;var ed=oe(88);Yd(145,$wnd.Function,{},ph);_.Q=function(a){return new sh(a)};var qh;Yd(55,$wnd.React.Component,{},sh);Xd(Vd[1],_);_.componentDidMount=function(){Ug(this.a)};_.render=function(){var a,b;return Lf('div',null,[Lf('div',null,[Lf(Oi,Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,[Oi])),[Lf('h1',null,['todos']),(new vh).a]),0!=Od(_e(new ef(null,new Xe((Mh(),Kh).a))))?Lf('section',Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,[Oi])),[Lf(Ki,Vf(Yf(Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,['toggle-all'])),(vg(),ag)),$d(Ih.prototype.N,Ih,[])),null),Lf('ul',Of(new $wnd.Object,lb(fb(vc,1),yi,2,6,['todo-list'])),(a=df(Te(cf(new ef(null,new Xe(li(Lh))))),(b=new Me,b)),Le(a,kb(a.a.length))))]):null,0!=Od(_e(new ef(null,new Xe(Kh.a))))?(new Yg).a:null])])};_.shouldComponentUpdate=Ri;var gd=oe(55);Yd(151,$wnd.Function,{},th);_.O=function(a){Dg(this.a,a)};Yd(152,$wnd.Function,{},uh);_.N=function(a){Cg(this.a,a)};Yd(61,1,{},vh);var jd=oe(61);Yd(87,1,Pi,wh);_.p=Si;var ld=oe(87);Yd(161,$wnd.Function,{},xh);_.N=function(a){Ig(this.a,a)};Yd(162,$wnd.Function,{},yh);_.O=function(a){Jg(this.a,a)};Yd(155,$wnd.Function,{},zh);_.N=function(a){Og(this.a)};Yd(157,$wnd.Function,{},Ah);_.P=function(a){Mg(this.a)};Yd(158,$wnd.Function,{},Bh);_.P=function(a){Lg(this.a)};Yd(159,$wnd.Function,{},Ch);_.J=function(a){Kg(this.a,a)};Yd(160,$wnd.Function,{},Dh);_.M=function(a){Ng(this.a)};Yd(86,1,{},Fh);var md=oe(86);Yd(56,1,Pi,Gh);_.p=Si;var od=oe(56);Yd(57,1,Pi,Hh);_.p=Si;var pd=oe(57);Yd(146,$wnd.Function,{},Ih);_.N=function(a){var b;b=a.target;di((Mh(),Kh),b.checked)};Yd(41,1,{},Jh);var qd=oe(41);var Kh,Lh;Yd(22,20,{3:1,23:1,20:1,22:1},Rh);var Nh,Oh,Ph;var sd=pe(22,Sh);Yd(37,1,{37:1},Vh);_.a=false;var Ad=oe(37);Yd(28,1,{},Wh);_.J=Ti;var td=oe(28);Yd(35,1,{35:1},ei);var zd=oe(35);Yd(64,1,{},gi);_.K=function(a){return a.a};var ud=oe(64);Yd(65,1,{},hi);_.J=function(a){_h(this.a,a)};var vd=oe(65);Yd(21,1,{},ii);_.J=Ti;var wd=oe(21);Yd(62,1,{},ji);_.K=function(a){return !a.a};var xd=oe(62);Yd(63,1,{},ki);_.J=function(a){fi(this.a,a)};_.a=false;var yd=oe(63);Yd(67,1,{},qi);var Fd=oe(67);Yd(68,1,{},si);_.handleEvent=function(a){mi(this.a,a)};var Bd=oe(68);Yd(69,1,Pi,ti);_.p=function(){pi(this.a)};var Cd=oe(69);Yd(26,1,{},ui);_.J=Ti;var Dd=oe(26);Yd(70,1,{},vi);_.K=function(a){return ri(this.a,a)};var Ed=oe(70);var Yb=qe('D');var wi=(L(),O);var gwtOnLoad=gwtOnLoad=Td;Rd(ce);Ud('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();