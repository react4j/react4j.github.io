function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='BFDA2488F729F6293978280980E59F9E',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'BFDA2488F729F6293978280980E59F9E';function n(){}
function U(){}
function Od(){}
function Kd(){}
function ab(){}
function ef(){}
function ff(){}
function qg(){}
function rg(){}
function sg(){}
function vg(){}
function wg(){}
function Ag(){}
function Bg(){}
function Ig(){}
function Jg(){}
function Wg(){}
function Xg(){}
function _g(){}
function ah(){}
function th(){}
function Rh(){}
function Th(){}
function Uh(){}
function ei(){}
function Di(a){a()}
function Z(a){Y()}
function Ud(){Ud=Kd}
function df(a,b){a.a=b}
function Qh(a,b){b.a=a}
function fh(a){this.a=a}
function gh(a){this.a=a}
function gf(a){this.a=a}
function cf(a){this.a=a}
function qe(a){this.a=a}
function se(a){this.b=a}
function De(a){this.c=a}
function ih(a){this.a=a}
function jh(a){this.a=a}
function kh(a){this.a=a}
function lh(a){this.a=a}
function mh(a){this.a=a}
function nh(a){this.a=a}
function oh(a){this.a=a}
function Sh(a){this.a=a}
function Vh(a){this.a=a}
function ci(a){this.a=a}
function di(a){this.a=a}
function fi(a){this.a=a}
function td(a){return a.e}
function xf(a,b){return a[b]}
function me(a,b){return a===b}
function Pg(a,b){return a.a=b}
function $h(a,b){ue(a.a,b)}
function Mh(a,b){ue(a.b,b)}
function wf(a,b){vf(a,b)}
function Cf(a,b){a.key=b}
function jf(a,b){a.splice(b,1)}
function te(a,b,c){hf(a.a,b,c)}
function we(a,b){return a.a[b]}
function Bi(){return this.a}
function Ai(){return nf(this)}
function ke(){q(this);this.s()}
function zg(a){yf.call(this,a)}
function Eg(a){yf.call(this,a)}
function Mg(a){yf.call(this,a)}
function $g(a){yf.call(this,a)}
function eh(a){yf.call(this,a)}
function H(){H=Kd;!!(Y(),X)}
function w(){w=Kd;v=new n}
function R(){R=Kd;Q=new U}
function P(){D!=0&&(D=0);G=-1}
function Dd(){Bd==null&&(Bd=[])}
function Xd(a){Wd(a);return a.k}
function Xe(a,b){a.F(b);return a}
function Gf(a,b){a.ref=b;return a}
function bb(a,b){return ae(a,b)}
function Cb(a){return a.l|a.m<<22}
function gb(a){return new Array(a)}
function O(a){$wnd.clearTimeout(a)}
function Hf(a,b){a.href=b;return a}
function Bf(a,b){this.a=a;this.b=b}
function fe(a,b){this.a=a;this.b=b}
function _e(a,b){this.a=a;this.b=b}
function og(a,b){fe.call(this,a,b)}
function Te(a,b){Oe(a);a.a.L(b)}
function Ye(a,b){df(a,Xe(a.a,b))}
function Ie(a,b){while(a.M(b));}
function hf(a,b,c){a.splice(b,0,c)}
function af(a,b){a.N(rh(ph(b.b),b))}
function Ch(a,b){fe.call(this,a,b)}
function ph(a){return qh(new sh,a)}
function Qb(a){return typeof a===ii}
function Tb(a){return a==null?null:a}
function kb(a){return lb(a.l,a.m,a.h)}
function tg(){this.a=Ef((yg(),xg))}
function ug(){this.a=Ef((Dg(),Cg))}
function hh(){this.a=Ef((Lg(),Kg))}
function sh(){this.a=Ef((Zg(),Yg))}
function uh(){this.a=Ef((dh(),bh))}
function Ae(){this.a=db(lc,ti,1,0,5,1)}
function Le(a){this.b=a;this.a=16464}
function Zh(a,b){a.b=b;ve(a.a,new ei)}
function oe(a,b){a.a+=''+b;return a}
function Rf(a,b){a.value=b;return a}
function Mf(a,b){a.onBlur=b;return a}
function If(a,b){a.onClick=b;return a}
function Nf(a,b){a.onChange=b;return a}
function Kf(a,b){a.checked=b;return a}
function Of(a,b){a.onKeyDown=b;return a}
function qh(a,b){Cf(a.a,He(b));return a}
function Jh(a,b){return xe(a.a,b,0)!=-1}
function lb(a,b,c){return {l:a,m:b,h:c}}
function le(a,b){return a.charCodeAt(b)}
function Ob(a,b){return a!=null&&Mb(a,b)}
function Be(a){return a.a<a.c.a.length}
function nf(a){return a.$H||(a.$H=++mf)}
function Sb(a){return typeof a==='string'}
function rf(){rf=Kd;of=new n;qf=new n}
function Y(){Y=Kd;var a;!$();a=new ab;X=a}
function Kh(a,b){ye(a.a,b);ve(a.b,new Th)}
function Hg(a,b){a.a=b;a.d.forceUpdate()}
function Vg(a,b){a.b=b;a.d.forceUpdate()}
function r(a,b){a.e=b;b!=null&&lf(b,ki,a)}
function Wd(a){if(a.k!=null){return}ce(a)}
function Ce(a){a.b=a.a++;return a.c.a[a.b]}
function Jf(a){a.autoFocus=true;return a}
function Lf(a,b){a.defaultValue=b;return a}
function q(a){a.g&&a.e!==ji&&a.s();return a}
function u(a){this.f=a;q(this);this.s()}
function We(a,b){Qe.call(this,a);this.a=b}
function vf(a,b){for(var c in a){b(c)}}
function lf(b,c,d){try{b[c]=d}catch(a){}}
function I(a,b,c){return a.apply(b,c);var d}
function Lh(a,b,c){b.c=He(c);ve(a.b,new Th)}
function Nh(a,b){df(b,!b.a);ve(a.b,new Th)}
function Ph(){this.a=new Ae;this.b=new Ae}
function xh(){xh=Kd;vh=new Ph;wh=new ai(vh)}
function Rd(){Rd=Kd;Qd=$wnd.window.document}
function Td(){u.call(this,'divide by zero')}
function Tg(a){Nh((xh(),vh),a.d.props['a'])}
function Qg(a){Kh((xh(),vh),xf(a.d.props,'a'))}
function Pb(a){return typeof a==='boolean'}
function fb(a){return Array.isArray(a)&&a._===Od}
function Nb(a){return !Array.isArray(a)&&a._===Od}
function $d(a){var b;b=Zd(a);ee(a,b);return b}
function Sf(a,b){a.onDoubleClick=b;return a}
function rh(a,b){a.a.props['a']=b;return a.a}
function ue(a,b){a.a[a.a.length]=b;return true}
function V(a,b){!a&&(a=[]);a[a.length]=b;return a}
function zd(a){if(Qb(a)){return a|0}return Cb(a)}
function Ad(a){if(Qb(a)){return ''+a}return Db(a)}
function Ue(a){Pe(a);return new We(a,new bf(a.a))}
function Se(a,b){Pe(a);return new We(a,new $e(b,a.a))}
function Fg(a,b){var c;c=b.target;Hg(a,c.value)}
function Ze(a,b,c){if(a.a.O(c)){a.b=true;b.N(c)}}
function Oe(a){if(!a.b){Pe(a);a.c=true}else{Oe(a.b)}}
function Qe(a){if(!a){this.b=null;new Ae}else{this.b=a}}
function He(a){if(a==null){throw td(new ke)}return a}
function uf(){if(pf==256){of=qf;qf=new n;pf=0}++pf}
function Qf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function _d(a,b){var c;c=Zd(a);ee(a,c);c.e=b?8:0;return c}
function s(a,b){var c;c=Xd(a.Z);return b==null?c:c+': '+b}
function bi(a,b){return (Bh(),zh)==a||(yh==a?!b.a:b.a)}
function Ge(a,b){return Tb(a)===Tb(b)||!!a&&Tb(a)===Tb(b)}
function Je(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Fh(a,b){this.b=He(a);this.c=He(b);this.a=false}
function bf(a){Je.call(this,a.K(),a.J()&-6);this.a=a}
function N(a){H();$wnd.setTimeout(function(){throw a},0)}
function be(a){if(a.C()){return null}var b=a.j;return Gd[b]}
function Ke(a){if(!a.d){a.d=new De(a.b);a.c=a.b.a.length}}
function M(a){a&&T((R(),Q));--D;if(a){if(G!=-1){O(G);G=-1}}}
function Pe(a){if(a.b){Pe(a.b)}else if(a.c){throw td(new ge)}}
function Md(a){function b(){}
;b.prototype=a||{};return new b}
function Ef(a){var b;b=Df(a);b.props={};b.ref=null;return b}
function Pf(a){a.placeholder='What needs to be done?';return a}
function Dh(){Bh();return hb(bb(ed,1),ti,21,0,[yh,Ah,zh])}
function dh(){dh=Kd;var a;bh=(a=Ld(ah.prototype.S,ah,[]),a)}
function yg(){yg=Kd;var a;xg=(a=Ld(wg.prototype.S,wg,[]),a)}
function Dg(){Dg=Kd;var a;Cg=(a=Ld(Bg.prototype.S,Bg,[]),a)}
function Lg(){Lg=Kd;var a;Kg=(a=Ld(Jg.prototype.S,Jg,[]),a)}
function Zg(){Zg=Kd;var a;Yg=(a=Ld(Xg.prototype.S,Xg,[]),a)}
function ae(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.u(b))}
function L(a,b,c){var d;d=J();try{return I(a,b,c)}finally{M(d)}}
function Sd(a,b,c,d){a.addEventListener(b,c,(Ud(),d?true:false))}
function Id(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Af(a,b,c){!me(c,'key')&&!me(c,'ref')&&(a[c]=b[c],undefined)}
function _h(a){var b;b=a.b;!!b&&!Jh(a.c,b)&&(a.b=null,ve(a.a,new ei))}
function Oh(a,b){Te(new We(null,new Le(a.a)),new Vh(b));ve(a.b,new Th)}
function Me(a,b){!a.a?(a.a=new qe(a.d)):oe(a.a,a.b);oe(a.a,b);return a}
function Ve(a,b){var c;Oe(a);c=new ef;c.a=b;a.a.L(new gf(c));return c.a}
function Re(a){var b;Oe(a);b=0;while(a.a.M(new ff)){b=ud(b,1)}return b}
function t(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function re(){u.call(this,'Add not supported on this collection')}
function $e(a,b){Je.call(this,b.K(),b.J()&-16449);this.a=a;this.c=b}
function Fe(a,b){while(a.a<a.c.a.length){b.N((a.b=a.a++,a.c.a[a.b]))}}
function Gh(a,b){ue(a.a,new Fh(''+Ad(wd(Date.now())),b));ve(a.b,new Th)}
function C(){if(Date.now){return Date.now()}return (new Date).getTime()}
function K(b){H();return function(){return L(b,this,arguments);var a}}
function Ub(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function jb(a){var b,c,d;b=a&mi;c=a>>22&mi;d=a<0?ni:0;return lb(b,c,d)}
function ve(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.N(c)}}
function ye(a,b){var c;c=xe(a,b,0);if(c==-1){return false}jf(a.a,c);return true}
function db(a,b,c,d,e,f){var g;g=eb(e,d);e!=10&&hb(bb(a,f),b,c,e,g);return g}
function xe(a,b,c){for(;c<a.a.length;++c){if(Ge(b,a.a[c])){return c}}return -1}
function kf(a,b){return cb(b)!=10&&hb(o(b),b.$,b.__elementTypeId$,cb(b),a),a}
function cb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Rb(a){return a!=null&&(typeof a===hi||typeof a==='function')&&!(a._===Od)}
function Ng(a,b){var c;if((xh(),wh).b==a.d.props['a']){c=b.target;Vg(a,c.value)}}
function S(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=W(b,c)}while(a.a);a.a=c}}
function T(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=W(b,c)}while(a.b);a.b=c}}
function sd(a){var b;if(Ob(a,5)){return a}b=a&&a[ki];if(!b){b=new B(a);Z(b)}return b}
function ee(a,b){var c;if(!a){return}b.j=a;var d=be(b);if(!d){Gd[a]=[b];return}d.Z=b}
function Ld(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ie(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function Zd(a){var b;b=new Yd;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function vd(a){var b;b=a.h;if(b==0){return a.l+a.m*qi}if(b==ni){return a.l+a.m*qi-pi}return a}
function Hh(a){var b;Ve(Se(new We(null,new Le(a.a)),new Rh),(b=new Ae,b)).D(new Sh(a))}
function Bh(){Bh=Kd;yh=new Ch('ACTIVE',0);Ah=new Ch('COMPLETED',1);zh=new Ch('ALL',2)}
function Ib(){Ib=Kd;Eb=lb(mi,mi,524287);Fb=lb(0,0,oi);Gb=jb(1);jb(2);Hb=jb(0)}
function Ne(){this.b=', ';this.d='[';this.e=']';this.c=this.d+(''+this.e)}
function yf(a){$wnd.React.Component.call(this,a);this.a=this.T();this.a.d=He(this);this.a.Q()}
function Ci(){$wnd.ReactDOM.render((new uh).a,(Rd(),Qd).getElementById(si),null)}
function ge(){u.call(this,"Stream already terminated, can't be modified or used")}
function Cd(){Dd();var a=Bd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function je(a,b){var c,d;for(d=new De(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Kh(b.a,c)}}
function yd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=pi;d=ni}c=Ub(e/qi);b=Ub(e-c*qi);return lb(b,c,d)}
function yb(a){var b,c,d;b=~a.l+1&mi;c=~a.m+(b==0?1:0)&mi;d=~a.h+(b==0&&c==0?1:0)&ni;return lb(b,c,d)}
function rb(a){var b,c,d;b=~a.l+1&mi;c=~a.m+(b==0?1:0)&mi;d=~a.h+(b==0&&c==0?1:0)&ni;a.l=b;a.m=c;a.h=d}
function vb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return lb(c&mi,d&mi,e&ni)}
function Bb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return lb(c&mi,d&mi,e&ni)}
function sb(a){var b,c;c=he(a.h);if(c==32){b=he(a.m);return b==32?he(a.l)+32:b+20-10}else{return c-12}}
function ob(a,b,c,d,e){var f;f=Ab(a,b);c&&rb(f);if(e){a=qb(a,b);d?(ib=yb(a)):(ib=lb(a.l,a.m,a.h))}return f}
function hb(a,b,c,d,e){e.Z=a;e.$=b;e._=Od;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Fd(a,b){typeof window===hi&&typeof window['$gwt']===hi&&(window['$gwt'][a]=b)}
function Rg(a){Zh((xh(),wh),xf(a.d.props,'a'));a.b=xf(a.d.props,'a').c;a.d.forceUpdate()}
function Og(a,b){27==b.which?(Zh((xh(),wh),null),a.b=xf(a.d.props,'a').c,a.d.forceUpdate()):13==b.which&&Sg(a)}
function wd(a){if(ri<a&&a<pi){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return vd(xb(a))}
function Nd(a){var b;if(Array.isArray(a)&&a._===Od){return Xd(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function nb(a,b){if(a.h==oi&&a.m==0&&a.l==0){b&&(ib=lb(0,0,0));return kb((Ib(),Gb))}b&&(ib=lb(a.l,a.m,a.h));return lb(0,0,0)}
function ud(a,b){var c;if(Qb(a)&&Qb(b)){c=a+b;if(ri<c&&c<pi){return c}}return vd(vb(Qb(a)?yd(a):a,Qb(b)?yd(b):b))}
function o(a){return Sb(a)?oc:Qb(a)?ec:Pb(a)?cc:Nb(a)?a.Z:fb(a)?a.Z:a.Z||Array.isArray(a)&&bb(Wb,1)||Wb}
function p(a){return Sb(a)?tf(a):Qb(a)?Ub(a):Pb(a)?a?1231:1237:Nb(a)?a.o():fb(a)?nf(a):!!a&&!!a.hashCode?a.hashCode():nf(a)}
function Ih(a){return zd(Re(new We(null,new Le(a.a))))-zd(Re(Se(new We(null,new Le(a.a)),new Uh)))}
function Yd(){this.g=Vd++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function B(a){w();q(this);this.e=a;a!=null&&lf(a,ki,this);this.f=a==null?'null':Nd(a);this.a='';this.b=a;this.a=''}
function tf(a){rf();var b,c,d;c=':'+a;d=qf[c];if(d!=null){return Ub(d)}d=of[c];b=d==null?sf(a):Ub(d);uf();qf[c]=b;return b}
function Ee(a){var b,c,d;d=1;for(c=new De(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function ze(a,b){var c,d;d=a.a.length;b.length<d&&(b=kf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function de(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Gg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=ne(a.a);if(c.length>0){Gh((xh(),vh),c);a.a='';a.d.forceUpdate()}}}
function J(){var a;if(D!=0){a=C();if(a-F>2000){F=a;G=$wnd.setTimeout(P,10)}}if(D++==0){S((R(),Q));return true}return false}
function $(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function pg(){ng();return hb(bb(Lc,1),ti,6,0,[Tf,Uf,Vf,Wf,Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg])}
function Sg(a){if(null!=a.b&&a.b.length!=0){Lh((xh(),vh),a.d.props['a'],a.b);Zh(wh,null);Vg(a,a.b)}else{Kh((xh(),vh),a.d.props['a'])}}
function ai(a){this.a=new Ae;this.c=He(a);Sd((Rd(),$wnd.window.window),'hashchange',new ci(this),false);Mh(a,Ld(di.prototype.U,di,[this]))}
function Ff(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Mb(a,b){if(Sb(a)){return !!Lb[b]}else if(a.$){return !!a.$[b]}else if(Qb(a)){return !!Kb[b]}else if(Pb(a)){return !!Jb[b]}return false}
function Pd(){Mh((xh(),vh),Ld(qg.prototype.U,qg,[]));$h(wh,Ld(rg.prototype.U,rg,[]));$wnd.ReactDOM.render((new uh).a,(Rd(),Qd).getElementById(si),null)}
function ne(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function qb(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return lb(c,d,e)}
function zb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return lb(c&mi,d&mi,e&ni)}
function eb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function ub(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&mi;a.m=d&mi;a.h=e&ni;return true}
function Ug(a){var b;b=(xh(),wh).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();a.b=a.d.props['a'].c;a.d.forceUpdate()}else a.c&&!b&&(a.c=false)}
function Xh(a,b){var c,d;b.preventDefault();c=(d=(Rd(),$wnd.window.window).location.hash,null==d?'':d.substr(1));me(vi,c)||me(wi,c)||me('',c)?ve(a.a,new ei):Yh()}
function wb(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Ed(b,c,d,e){Dd();var f=Bd;$moduleName=c;$moduleBase=d;rd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{gi(g)()}catch(a){b(c,a)}}else{gi(g)()}}
function W(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].ab()&&(c=V(c,g)):g[0].ab()}catch(a){a=sd(a);if(Ob(a,5)){d=a;H();N(Ob(d,24)?d.t():d)}else throw td(a)}}return c}
function Df(a){var b;b=new $wnd.Object;b.$$typeof=$wnd.React.Element;b.type=He(a);b._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return b}
function Hd(){Gd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function A(a){var b;if(a.c==null){b=Tb(a.b)===Tb(v)?null:a.b;a.d=b==null?'null':Rb(b)?b==null?null:b.name:Sb(b)?'String':Xd(o(b));a.a=a.a+': '+(Rb(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function sf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+le(a,c++)}b=b|0;return b}
function Yh(){var a;if(0==''.length){a=(Rd(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Qd.title,a)}else{(Rd(),$wnd.window.window).location.hash=''}}
function he(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Jd(a,b,c){var d=Gd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Gd[b]),Md(h));_.$=c;!b&&(_._=Od);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.Z=f)}
function Ab(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&oi)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?ni:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?ni:0;f=d?mi:0;e=c>>b-44}return lb(e&mi,f&mi,g&ni)}
function ce(a){if(a.B()){var b=a.c;b.C()?(a.k='['+b.j):!b.B()?(a.k='[L'+b.w()+';'):(a.k='['+b.w());a.b=b.v()+'[]';a.i=b.A()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=de('.',[c,de('$',d)]);a.b=de('.',[c,de('.',d)]);a.i=d[d.length-1]}
function Wh(a){var b,c,d,e;b=(e=(c=(Rd(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),me(vi,e)||me(wi,e)||me('',e)?me(vi,e)?(Bh(),yh):me(wi,e)?(Bh(),Ah):(Bh(),zh):(Bh(),zh));return Ve(Se(new We(null,new Le(a.c.a)),new fi(b)),(d=new Ae,d))}
function tb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return ie(c)}if(b==0&&d!=0&&c==0){return ie(d)+22}if(b!=0&&d==0&&c==0){return ie(b)+44}return -1}
function xb(a){var b,c,d,e,f;if(isNaN(a)){return Ib(),Hb}if(a<-9223372036854775808){return Ib(),Fb}if(a>=9223372036854775807){return Ib(),Eb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=pi){d=Ub(a/pi);a-=d*pi}c=0;if(a>=qi){c=Ub(a/qi);a-=c*qi}b=Ub(a);f=lb(b,c,d);e&&rb(f);return f}
function zf(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?''+b['key']:null;f='ref' in b?b['ref']:null;wf(b,Ld(Bf.prototype.P,Bf,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=Df(a),g.key=e,g.ref=f,g.props=He(d),g}
function Db(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==oi&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Db(yb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=jb(1000000000);c=mb(c,e,true);b=''+Cb(ib);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function pb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=sb(b)-sb(a);g=zb(b,j);i=lb(0,0,0);while(j>=0){h=ub(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&rb(i);if(f){if(d){ib=yb(a);e&&(ib=Bb(ib,(Ib(),Gb)))}else{ib=lb(a.l,a.m,a.h)}}return i}
function ng(){ng=Kd;Tf=new og(ui,0);Uf=new og('checkbox',1);Vf=new og('color',2);Wf=new og('date',3);Xf=new og('datetime',4);Yf=new og('email',5);Zf=new og('file',6);$f=new og('hidden',7);_f=new og('image',8);ag=new og('month',9);bg=new og(ii,10);cg=new og('password',11);dg=new og('radio',12);eg=new og('range',13);fg=new og('reset',14);gg=new og('search',15);hg=new og('submit',16);ig=new og('tel',17);jg=new og('text',18);kg=new og('time',19);lg=new og('url',20);mg=new og('week',21)}
function mb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw td(new Td)}if(a.l==0&&a.m==0&&a.h==0){c&&(ib=lb(0,0,0));return lb(0,0,0)}if(b.h==oi&&b.m==0&&b.l==0){return nb(a,c)}i=false;if(b.h>>19!=0){b=yb(b);i=true}g=tb(b);f=false;e=false;d=false;if(a.h==oi&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=kb((Ib(),Eb));d=true;i=!i}else{h=Ab(a,g);i&&rb(h);c&&(ib=lb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=yb(a);d=true;i=!i}if(g!=-1){return ob(a,g,i,f,c)}if(wb(a,b)<0){c&&(f?(ib=yb(a)):(ib=lb(a.l,a.m,a.h)));return lb(0,0,0)}return pb(d?a:lb(a.l,a.m,a.h),b,i,f,e,c)}
var hi='object',ii='number',ji='__noinit__',ki='__java$exception',li={3:1,7:1,5:1},mi=4194303,ni=1048575,oi=524288,pi=17592186044416,qi=4194304,ri=-17592186044416,si='todoapp',ti={3:1,4:1},ui='button',vi='active',wi='completed',xi='selected',yi='input',zi='header';var _,Gd,Bd,rd=-1;Hd();Jd(1,null,{},n);_.n=function(){return this.Z};_.o=Ai;_.p=function(){var a;return Xd(o(this))+'@'+(a=p(this)>>>0,a.toString(16))};_.hashCode=function(){return this.o()};_.toString=function(){return this.p()};var Jb,Kb,Lb;Jd(29,1,{},Yd);_.u=function(a){var b;b=new Yd;b.e=4;a>1?(b.c=ae(this,a-1)):(b.c=this);return b};_.v=function(){Wd(this);return this.b};_.w=function(){return Xd(this)};_.A=function(){Wd(this);return this.i};_.B=function(){return (this.e&4)!=0};_.C=function(){return (this.e&1)!=0};_.p=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Wd(this),this.k)};_.e=0;_.g=0;var Vd=1;var lc=$d(1);var dc=$d(29);Jd(5,1,{3:1,5:1});_.q=function(a){return new Error(a)};_.r=function(){return this.f};_.s=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Xd(this.Z),c==null?a:a+': '+c);r(this,t(this.q(b)));Z(this)};_.p=function(){return s(this,this.r())};_.e=ji;_.g=true;var pc=$d(5);Jd(26,5,{3:1,5:1});var gc=$d(26);Jd(7,26,li);var mc=$d(7);Jd(30,7,li);var ic=$d(30);Jd(42,30,li);var Yb=$d(42);Jd(24,42,{24:1,3:1,7:1,5:1},B);_.r=function(){A(this);return this.c};_.t=function(){return Tb(this.b)===Tb(v)?null:this.b};var v;var Vb=$d(24);var Wb=$d(0);Jd(85,1,{});var Xb=$d(85);var D=0,F=0,G=-1;Jd(57,85,{},U);var Q;var Zb=$d(57);var X;Jd(98,1,{});var _b=$d(98);Jd(43,98,{},ab);var $b=$d(43);var ib;var Eb,Fb,Gb,Hb;var Qd;Jd(40,1,{38:1});_.p=Bi;var ac=$d(40);Jd(55,7,li,Td);var bc=$d(55);Jb={3:1,23:1};var cc=$d(95);Jd(96,1,{3:1});var kc=$d(96);Kb={3:1,23:1};var ec=$d(97);Jd(20,1,{3:1,23:1,20:1});_.o=Ai;_.p=function(){return this.a!=null?this.a:''+this.b};_.b=0;var fc=$d(20);Jd(45,7,li,ge);var hc=$d(45);Jd(158,1,{});Jd(54,30,li,ke);_.q=function(a){return new TypeError(a)};var jc=$d(54);Lb={3:1,38:1,23:1,2:1};var oc=$d(2);Jd(41,40,{38:1},qe);var nc=$d(41);Jd(162,1,{});Jd(53,7,li,re);var qc=$d(53);Jd(99,1,{82:1});_.D=function(a){je(this,a)};_.F=function(a){throw td(new re)};_.p=function(){var a,b,c;c=new Ne;for(b=this.G();b.H();){a=b.I();Me(c,a===this?'(this Collection)':a==null?'null':Nd(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var rc=$d(99);Jd(100,99,{82:1,106:1});_.F=function(a){te(this,this.a.length,a);return true};_.o=function(){return Ee(this)};_.G=function(){return new se(this)};var tc=$d(100);Jd(56,1,{},se);_.H=function(){return this.a<this.b.a.length};_.I=function(){return we(this.b,this.a++)};_.a=0;var sc=$d(56);Jd(10,100,{3:1,10:1,82:1,106:1},Ae);_.F=function(a){return ue(this,a)};_.D=function(a){ve(this,a)};_.G=function(){return new De(this)};var vc=$d(10);Jd(15,1,{},De);_.H=function(){return Be(this)};_.I=function(){return Ce(this)};_.a=0;_.b=-1;var uc=$d(15);Jd(61,1,{});_.L=function(a){Ie(this,a)};_.J=function(){return this.d};_.K=function(){return this.e};_.d=0;_.e=0;var xc=$d(61);Jd(33,61,{});var wc=$d(33);Jd(11,1,{},Le);_.J=Bi;_.K=function(){Ke(this);return this.c};_.L=function(a){Ke(this);Fe(this.d,a)};_.M=function(a){Ke(this);if(Be(this.d)){a.N(Ce(this.d));return true}return false};_.a=0;_.c=0;var yc=$d(11);Jd(44,1,{},Ne);_.p=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var zc=$d(44);Jd(60,1,{});_.c=false;var Ic=$d(60);Jd(9,60,{},We);var Hc=$d(9);Jd(63,33,{},$e);_.M=function(a){this.b=false;while(!this.b&&this.c.M(new _e(this,a)));return this.b};_.b=false;var Bc=$d(63);Jd(66,1,{},_e);_.N=function(a){Ze(this.a,this.b,a)};var Ac=$d(66);Jd(62,33,{},bf);_.M=function(a){return this.a.M(new cf(a))};var Dc=$d(62);Jd(65,1,{},cf);_.N=function(a){af(this.a,a)};var Cc=$d(65);Jd(64,1,{},ef);_.N=function(a){df(this,a)};var Ec=$d(64);Jd(67,1,{},ff);_.N=function(a){};var Fc=$d(67);Jd(68,1,{},gf);_.N=function(a){Ye(this.a,a)};var Gc=$d(68);Jd(160,1,{});Jd(157,1,{});var mf=0;var of,pf=0,qf;Jd(537,1,{});Jd(599,1,{});Jd(101,1,{});_.Q=function(){};var Jc=$d(101);Jd(19,$wnd.React.Component,{});Id(Gd[1],_);_.render=function(){return this.a.R()};var Kc=$d(19);Jd(129,$wnd.Function,{},Bf);_.P=function(a){Af(this.a,this.b,a)};Jd(6,20,{3:1,23:1,20:1,6:1},og);var Tf,Uf,Vf,Wf,Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg;var Lc=_d(6,pg);Jd(109,$wnd.Function,{37:1},qg);_.U=Ci;Jd(110,$wnd.Function,{37:1},rg);_.U=Ci;Jd(103,101,{});_.R=function(){var a,b,c;a=(xh(),c=(b=(Rd(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),me(vi,c)||me(wi,c)||me('',c)?me(vi,c)?(Bh(),yh):me(wi,c)?(Bh(),Ah):(Bh(),zh):(Bh(),zh));return zf('footer',Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,['footer'])),[(new ug).a,zf('ul',Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,['filters'])),[zf('li',null,[zf('a',Hf(Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,[(Bh(),zh)==a?xi:null])),'#'),['All'])]),zf('li',null,[zf('a',Hf(Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,[yh==a?xi:null])),'#active'),['Active'])]),zf('li',null,[zf('a',Hf(Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,[Ah==a?xi:null])),'#completed'),['Completed'])])]),Ih(vh)>0?zf(ui,If(Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,['clear-completed'])),Ld(sg.prototype.Y,sg,[])),['Clear Completed']):null])};var Pc=$d(103);Jd(134,$wnd.Function,{},sg);_.Y=function(a){Hh((xh(),vh))};Jd(71,1,{},tg);var Mc=$d(71);Jd(105,101,{});_.R=function(){var a,b;b=zd(Re(new We(null,new Le((xh(),vh).a))));a='item'+(b==1?'':'s');return zf('span',Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,['todo-count'])),[zf('strong',null,[b]),' '+a+' left'])};var Oc=$d(105);Jd(79,1,{},ug);var Nc=$d(79);Jd(75,103,{},vg);var Tc=$d(75);Jd(133,$wnd.Function,{},wg);_.S=function(a){return new zg(a)};var xg;Jd(76,19,{},zg);_.T=function(){return new vg};var Qc=$d(76);Jd(80,105,{},Ag);var Sc=$d(80);Jd(144,$wnd.Function,{},Bg);_.S=function(a){return new Eg(a)};var Cg;Jd(81,19,{},Eg);_.T=function(){return new Ag};var Rc=$d(81);Jd(72,101,{});_.R=function(){return zf(yi,Jf(Nf(Of(Rf(Pf(Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,['new-todo']))),this.a),Ld(fh.prototype.X,fh,[this])),Ld(gh.prototype.W,gh,[this]))),null)};_.a='';var _c=$d(72);Jd(73,72,{},Ig);var Vc=$d(73);Jd(130,$wnd.Function,{},Jg);_.S=function(a){return new Mg(a)};var Kg;Jd(74,19,{},Mg);_.T=function(){return new Ig};var Uc=$d(74);Jd(104,101,{});_.Q=function(){this.b=xf(this.d.props,'a').c};_.R=function(){var a,b;b=this.d.props['a'];a=b.a;return zf('li',Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,[a?wi:null,(xh(),wh).b==this.d.props['a']?'editing':null])),[zf('div',Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,['view'])),[zf(yi,Nf(Kf(Qf(Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,['toggle'])),(ng(),Uf)),a),Ld(kh.prototype.W,kh,[this])),null),zf('label',Sf(new $wnd.Object,Ld(lh.prototype.Y,lh,[this])),[b.c]),zf(ui,If(Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,['destroy'])),Ld(mh.prototype.Y,mh,[this])),null)]),zf(yi,Of(Nf(Mf(Lf(Ff(Gf(new $wnd.Object,Ld(nh.prototype.N,nh,[this])),hb(bb(oc,1),ti,2,6,['edit'])),this.b),Ld(oh.prototype.V,oh,[this])),Ld(ih.prototype.W,ih,[this])),Ld(jh.prototype.X,jh,[this])),null)])};_.c=false;var bd=$d(104);Jd(34,104,{34:1},Wg);var Xc=$d(34);Jd(135,$wnd.Function,{},Xg);_.S=function(a){return new $g(a)};var Yg;Jd(78,19,{},$g);_.T=function(){return new Wg};_.componentDidUpdate=function(a){Ug(this.a)};var Wc=$d(78);Jd(102,101,{});_.R=function(){var a,b;return zf('div',null,[zf('div',null,[zf(zi,Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,[zi])),[zf('h1',null,['todos']),(new hh).a]),0!=zd(Re(new We(null,new Le((xh(),vh).a))))?zf('section',Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,[zi])),[zf(yi,Nf(Qf(Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,['toggle-all'])),(ng(),Uf)),Ld(th.prototype.W,th,[])),null),zf('ul',Ff(new $wnd.Object,hb(bb(oc,1),ti,2,6,['todo-list'])),(a=Ve(Ue(new We(null,new Le(Wh(wh)))),(b=new Ae,b)),ze(a,gb(a.a.length))))]):null,0!=zd(Re(new We(null,new Le(vh.a))))?(new tg).a:null])])};var dd=$d(102);Jd(58,102,{},_g);var Zc=$d(58);Jd(127,$wnd.Function,{},ah);_.S=function(a){return new eh(a)};var bh;Jd(59,19,{},eh);_.T=function(){return new _g};var Yc=$d(59);Jd(131,$wnd.Function,{},fh);_.X=function(a){Gg(this.a,a)};Jd(132,$wnd.Function,{},gh);_.W=function(a){Fg(this.a,a)};Jd(70,1,{},hh);var $c=$d(70);Jd(142,$wnd.Function,{},ih);_.W=function(a){Ng(this.a,a)};Jd(143,$wnd.Function,{},jh);_.X=function(a){Og(this.a,a)};Jd(136,$wnd.Function,{},kh);_.W=function(a){Tg(this.a)};Jd(138,$wnd.Function,{},lh);_.Y=function(a){Rg(this.a)};Jd(139,$wnd.Function,{},mh);_.Y=function(a){Qg(this.a)};Jd(140,$wnd.Function,{},nh);_.N=function(a){Pg(this.a,a)};Jd(141,$wnd.Function,{},oh);_.V=function(a){Sg(this.a)};Jd(77,1,{},sh);var ad=$d(77);Jd(128,$wnd.Function,{},th);_.W=function(a){var b;b=a.target;Oh((xh(),vh),b.checked)};Jd(25,1,{},uh);var cd=$d(25);var vh,wh;Jd(21,20,{3:1,23:1,20:1,21:1},Ch);var yh,zh,Ah;var ed=_d(21,Dh);Jd(32,1,{32:1},Fh);_.a=false;var md=$d(32);Jd(31,1,{31:1},Ph);var ld=$d(31);Jd(48,1,{},Rh);_.O=function(a){return a.a};var fd=$d(48);Jd(49,1,{},Sh);_.N=function(a){Kh(this.a,a)};var gd=$d(49);Jd(18,1,{},Th);_.N=Di;var hd=$d(18);Jd(46,1,{},Uh);_.O=function(a){return !a.a};var jd=$d(46);Jd(47,1,{},Vh);_.N=function(a){Qh(this.a,a)};_.a=false;var kd=$d(47);Jd(50,1,{},ai);var qd=$d(50);Jd(51,1,{},ci);_.handleEvent=function(a){Xh(this.a,a)};var nd=$d(51);Jd(115,$wnd.Function,{37:1},di);_.U=function(){_h(this.a)};Jd(27,1,{},ei);_.N=Di;var od=$d(27);Jd(52,1,{},fi);_.O=function(a){return bi(this.a,a)};var pd=$d(52);var gi=(H(),K);var gwtOnLoad=gwtOnLoad=Ed;Cd(Pd);Fd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();