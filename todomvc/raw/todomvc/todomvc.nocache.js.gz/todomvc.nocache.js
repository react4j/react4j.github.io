function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='68DA7EB10551714C7EE16D0F752575EF',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '68DA7EB10551714C7EE16D0F752575EF';function n(){}
function N(){}
function ze(){}
function ve(){}
function _e(){}
function nb(){}
function ub(){}
function Af(){}
function Pf(){}
function Xf(){}
function Yf(){}
function sg(){}
function sh(){}
function hh(){}
function kh(){}
function oh(){}
function wh(){}
function Ah(){}
function Th(){}
function Uh(){}
function gi(){}
function si(){}
function ui(){}
function vi(){}
function Gi(){}
function bi(a,b){}
function sb(a){rb()}
function cj(a){a.p()}
function Wf(a,b){a.a=b}
function Bf(a){this.a=a}
function Zf(a){this.a=a}
function t(a){this.a=a}
function gh(a){this.a=a}
function Eh(a){this.a=a}
function Fh(a){this.a=a}
function Hh(a){this.a=a}
function Ih(a){this.a=a}
function Jh(a){this.a=a}
function Kh(a){this.a=a}
function Lh(a){this.a=a}
function Mh(a){this.a=a}
function Nh(a){this.a=a}
function Oh(a){this.a=a}
function Rh(a){this.a=a}
function Sh(a){this.a=a}
function ti(a){this.a=a}
function wi(a){this.a=a}
function Ei(a){this.a=a}
function Fi(a){this.a=a}
function Hi(a){this.a=a}
function lf(a){this.c=a}
function _i(){M(this.a.a)}
function Zi(a){rf(this,a)}
function ei(a,b){cf(a.c,b)}
function ni(a,b){cf(a.b,b)}
function Ai(a,b){cf(a.a,b)}
function lg(a,b){kg(a,b)}
function ng(a,b){a.key=b}
function Ge(){Ge=ve}
function v(){v=ve;u=new s}
function V(){V=ve;U=new n}
function kb(){kb=ve;jb=new nb}
function ee(a){return a.b}
function aj(a){return false}
function $i(){return this.b}
function Yi(){return cg(this)}
function Xg(a,b){return a.d=b}
function vb(a,b){return Pe(a,b)}
function Q(a,b){a.b=b;P(a,b)}
function _f(a,b){a.splice(b,1)}
function bf(a,b,c){$f(a.a,b,c)}
function wf(a,b,c){b.M(a.a[c])}
function Tf(a,b,c){b.M(a.a.G(c))}
function rf(a,b){while(a.L(b));}
function Of(a,b){Wf(a,Nf(a.a,b))}
function If(a,b){Cf(a);a.a.K(b)}
function Nf(a,b){a.H(b);return a}
function vg(a,b){a.ref=b;return a}
function Je(a){Ie(a);return a.k}
function Fe(a){T.call(this,a)}
function Ug(a){oi((Yh(),Wh),a.c)}
function Wg(a){li((Yh(),Wh),a.c)}
function ib(){Y!=0&&(Y=0);$=-1}
function ab(){ab=ve;!!(rb(),qb)}
function oe(){me==null&&(me=[])}
function Vb(a){return a.l|a.m<<22}
function F(a){this.d=a;this.b=100}
function Sf(a,b){this.a=a;this.b=b}
function Vf(a,b){this.a=a;this.b=b}
function tg(a,b){this.a=a;this.b=b}
function wg(a,b){a.href=b;return a}
function Fg(a,b){a.value=b;return a}
function $f(a,b,c){a.splice(b,0,c)}
function ih(){this.a=pg((mh(),lh))}
function jh(){this.a=pg((qh(),ph))}
function Gh(){this.a=pg((uh(),th))}
function Qh(){this.a=pg((yh(),xh))}
function Vh(){this.a=pg((Ch(),Bh))}
function bj(){this.a.b.forceUpdate()}
function zf(a){this.b=a;this.a=16464}
function Lg(){v();++Kg;this.a=new N}
function gg(){gg=ve;dg=new n;fg=new n}
function zg(a,b){a.checked=b;return a}
function Ag(a,b){a.onBlur=b;return a}
function xg(a,b){a.onClick=b;return a}
function di(a,b){a.a=b;df(a.c,new gi)}
function ri(a,b){b.a=a;df(b.c,new gi)}
function zi(a,b){a.b=b;df(a.a,new Gi)}
function Ze(a,b){return jc(a)===jc(b)}
function Db(a){return Eb(a.l,a.m,a.h)}
function jf(a){return a.a<a.c.a.length}
function jc(a){return a==null?null:a}
function Ye(a,b){return a.charCodeAt(b)}
function cg(a){return a.$H||(a.$H=++bg)}
function Eb(a,b,c){return {l:a,m:b,h:c}}
function ki(a,b){return ef(a.a,b,0)!=-1}
function fc(a,b){return a!=null&&dc(a,b)}
function kg(a,b){for(var c in a){b(c)}}
function Bg(a,b){a.onChange=b;return a}
function Cg(a,b){a.onKeyDown=b;return a}
function mg(a,b){a.props['a']=b;return a}
function Og(a,b){a.c=b;a.b.forceUpdate()}
function _g(a,b){a.e=b;a.b.forceUpdate()}
function hb(a){$wnd.clearTimeout(a)}
function Hg(a){Ai((Yh(),Xh),new gh(a))}
function K(a){++(v(),v(),u).b;this.a=a}
function T(a){this.d=a;O(this);this.t()}
function Mf(a,b){Ef.call(this,a);this.a=b}
function li(a,b){ff(a.a,b);df(a.b,new ui)}
function qi(){this.a=new hf;this.b=new hf}
function hf(){this.a=xb(Lc,Ki,1,0,5,1)}
function B(){this.a=xb(Lc,Ki,1,100,5,1)}
function Ie(a){if(a.k!=null){return}Re(a)}
function O(a){a.f&&a.b!==Li&&a.t();return a}
function Eg(a){a.type='checkbox';return a}
function Gg(a,b){a.onDoubleClick=b;return a}
function yg(a){return a.autoFocus=true,a}
function hc(a){return typeof a==='number'}
function ic(a){return typeof a==='string'}
function gc(a){return typeof a==='boolean'}
function bb(a,b,c){return a.apply(b,c);var d}
function oi(a,b){di(b,!b.a);df(a.b,new ui)}
function Vg(a){zi((Yh(),Xh),a.c);_g(a,a.c.d)}
function kf(a){a.b=a.a++;return a.c.a[a.b]}
function cf(a,b){a.a[a.a.length]=b;return true}
function Me(a){var b;b=Le(a);Te(a,b);return b}
function Mg(a,b){var c;c=b.target;Og(a,c.value)}
function uf(a,b){while(a.c<a.d){wf(a,b,a.c++)}}
function D(a){while(true){if(!C(a)){break}}}
function Ee(){T.call(this,'divide by zero')}
function Yh(){Yh=ve;Wh=new qi;Xh=new Ci(Wh)}
function rb(){rb=ve;var a;!tb();a=new ub;qb=a}
function Jg(a){this.b=a;v();++Ig;this.a=new N}
function Rg(a){this.b=a;v();++Qg;this.a=new N}
function fh(a){this.b=a;v();++eh;this.a=new N}
function Oe(a){var b;b=Le(a);b.j=a;b.e=1;return b}
function ob(a,b){!a&&(a=[]);a[a.length]=b;return a}
function mf(a,b){return sf(b,a.length),new xf(a,b)}
function Ff(a,b){var c;return Kf(a,(c=new hf,c))}
function le(a){if(hc(a)){return ''+a}return Wb(a)}
function ke(a){if(hc(a)){return a|0}return Vb(a)}
function Cf(a){if(!a.b){Df(a);a.c=true}else{Cf(a.b)}}
function Qf(a,b,c){if(a.a.O(c)){a.b=true;b.M(c)}}
function De(a,b,c,d){a.addEventListener(b,c,d)}
function Hf(a,b){Df(a);return new Mf(a,new Rf(b,a.a))}
function Jf(a,b){Df(a);return new Mf(a,new Uf(b,a.a))}
function nf(a){return new Mf(null,mf(a,a.length))}
function zb(a){return Array.isArray(a)&&a.X===ze}
function ec(a){return !Array.isArray(a)&&a.X===ze}
function A(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Di(a,b){return (ai(),$h)==a||(Zh==a?!b.a:b.a)}
function qf(a,b){return jc(a)===jc(b)||!!a&&jc(a)===jc(b)}
function tf(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function xf(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Ef(a){if(!a){this.b=null;new hf}else{this.b=a}}
function yf(a){if(!a.d){a.d=new lf(a.b);a.c=a.b.a.length}}
function dh(a){ni((Yh(),Wh),new Rh(a));Ai(Xh,new Sh(a))}
function mi(a,b,c){b.d=c;df(b.c,new gi);df(a.b,new ui)}
function Ne(a,b){var c;c=Le(a);Te(a,c);c.e=b?8:0;return c}
function R(a,b){var c;c=Je(a.V);return b==null?c:c+': '+b}
function M(a){var b;if(a.a>=0){a.a=-2;q((b=(v(),v(),u),b))}}
function jg(){if(eg==256){dg=fg;fg=new n;eg=0}++eg}
function Ce(){Ce=ve;Be=$wnd.goog.global.document}
function Ch(){Ch=ve;var a;Bh=(a=we(Ah.prototype.U,Ah,[]),a)}
function mh(){mh=ve;var a;lh=(a=we(kh.prototype.U,kh,[]),a)}
function qh(){qh=ve;var a;ph=(a=we(oh.prototype.U,oh,[]),a)}
function uh(){uh=ve;var a;th=(a=we(sh.prototype.U,sh,[]),a)}
function yh(){yh=ve;var a;xh=(a=we(wh.prototype.U,wh,[]),a)}
function s(){this.f=new I;this.a=new F(this.f);new t(this.a)}
function fi(a,b){this.c=new hf;this.b=a;this.d=b;this.a=false}
function Uf(a,b){tf.call(this,b.J(),b.I()&-6);this.a=a;this.b=b}
function rh(a){$wnd.React.Component.call(this,a);this.a=new Lg}
function gb(a){ab();$wnd.setTimeout(function(){throw a},0)}
function Df(a){if(a.b){Df(a.b)}else if(a.c){throw ee(new Ue)}}
function Qe(a){if(a.D()){return null}var b=a.j;return re[b]}
function xe(a){function b(){}
;b.prototype=a||{};return new b}
function S(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Dg(a){a.placeholder='What needs to be done?';return a}
function af(){T.call(this,'Add not supported on this collection')}
function Rf(a,b){tf.call(this,b.J(),b.I()&-16449);this.a=a;this.c=b}
function vf(a,b){if(a.c<a.d){wf(a,b,a.c++);return true}return false}
function Pe(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.v(b))}
function te(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ci(){ai();return Ab(vb(Qd,1),Ki,19,0,[Zh,_h,$h])}
function eb(a,b,c){var d;d=cb();try{return bb(a,b,c)}finally{fb(d)}}
function Sg(a,b){var c;if((Yh(),Xh).b==a.c){c=b.target;_g(a,c.value)}}
function pf(a,b){while(a.a<a.c.a.length){b.M((a.b=a.a++,a.c.a[a.b]))}}
function Bi(a){var b;b=a.b;!!b&&!ki(a.c,b)&&(a.b=null,df(a.a,new Gi))}
function pi(a,b){If(new Mf(null,new zf(a.a)),new wi(b));df(a.b,new ui)}
function Gf(a){var b;Cf(a);b=0;while(a.a.L(new Yf)){b=fe(b,1)}return b}
function Kf(a,b){var c;Cf(a);c=new Xf;c.a=b;a.a.K(new Zf(c));return c.a}
function Cb(a){var b,c,d;b=a&Ni;c=a>>22&Ni;d=a<0?Oi:0;return Eb(b,c,d)}
function fb(a){a&&mb((kb(),jb));--Y;if(a){if($!=-1){hb($);$=-1}}}
function kc(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function nh(a){$wnd.React.Component.call(this,a);this.a=new Jg(this)}
function vh(a){$wnd.React.Component.call(this,a);this.a=new Rg(this)}
function zh(a){$wnd.React.Component.call(this,a);this.a=new bh(this)}
function Dh(a){$wnd.React.Component.call(this,a);this.a=new fh(this)}
function hi(a,b){cf(a.a,new fi(''+le(he(Date.now())),b));df(a.b,new ui)}
function Lf(a,b){var c;c=Ff(a,new Bf(new Af));return gf(c,b.N(c.a.length))}
function db(b){ab();return function(){return eb(b,this,arguments);var a}}
function X(){if(Date.now){return Date.now()}return (new Date).getTime()}
function rg(a,b,c){!Ze(c,'key')&&!Ze(c,'ref')&&(a[c]=b[c],undefined)}
function ef(a,b,c){for(;c<a.a.length;++c){if(qf(b,a.a[c])){return c}}return -1}
function H(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=A(a.a[c])}return b}
function df(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.M(c)}}
function ff(a,b){var c;c=ef(a,b,0);if(c==-1){return false}_f(a.a,c);return true}
function xb(a,b,c,d,e,f){var g;g=yb(e,d);e!=10&&Ab(vb(a,f),b,c,e,g);return g}
function Ph(a,b){ng(a.a,(b?b.b:null)+(''+(Ie(Kd),Kd.k)));mg(a.a,b);return a.a}
function ag(a,b){return wb(b)!=10&&Ab(o(b),b.W,b.__elementTypeId$,wb(b),a),a}
function wb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function lb(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=pb(b,c)}while(a.a);a.a=c}}
function mb(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=pb(b,c)}while(a.b);a.b=c}}
function L(){var a;try{v()}finally{a=J.a;!a&&((v(),v(),u).d=true);J=J.a}}
function I(){var a;this.a=xb(oc,Ki,27,5,0,1);for(a=0;a<5;a++){this.a[a]=new B}}
function _b(){_b=ve;Xb=Eb(Ni,Ni,524287);Yb=Eb(0,0,Pi);Zb=Cb(1);Cb(2);$b=Cb(0)}
function ai(){ai=ve;Zh=new bi('ACTIVE',0);_h=new bi('COMPLETED',1);$h=new bi('ALL',2)}
function ii(a){Ff(Hf(new Mf(null,new zf(a.a)),new si),new Bf(new Af)).F(new ti(a))}
function r(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{D(a.a)}finally{a.c=false}}}}
function W(a){V();O(this);this.b=a;P(this,a);this.d=a==null?'null':ye(a);this.a=a}
function Ue(){T.call(this,"Stream already terminated, can't be modified or used")}
function Ae(){$wnd.ReactDOM.render((new Vh).a,(Ce(),Be).getElementById('app'),null)}
function we(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Te(a,b){var c;if(!a){return}b.j=a;var d=Qe(b);if(!d){re[a]=[b];return}d.V=b}
function We(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function ge(a){var b;b=a.h;if(b==0){return a.l+a.m*Ri}if(b==Oi){return a.l+a.m*Ri-Qi}return a}
function Le(a){var b;b=new Ke;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function pg(a){var b;b=og($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function je(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Qi;d=Oi}c=kc(e/Ri);b=kc(e-c*Ri);return Eb(b,c,d)}
function Ob(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return Eb(c&Ni,d&Ni,e&Oi)}
function Ub(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return Eb(c&Ni,d&Ni,e&Oi)}
function Rb(a){var b,c,d;b=~a.l+1&Ni;c=~a.m+(b==0?1:0)&Ni;d=~a.h+(b==0&&c==0?1:0)&Oi;return Eb(b,c,d)}
function Kb(a){var b,c,d;b=~a.l+1&Ni;c=~a.m+(b==0?1:0)&Ni;d=~a.h+(b==0&&c==0?1:0)&Oi;a.l=b;a.m=c;a.h=d}
function Lb(a){var b,c;c=Ve(a.h);if(c==32){b=Ve(a.m);return b==32?Ve(a.l)+32:b+20-10}else{return c-12}}
function de(a){var b;if(fc(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new W(a);sb(b)}return b}
function he(a){if(Si<a&&a<Qi){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return ge(Qb(a))}
function ne(){oe();var a=me;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Xe(a,b){var c,d;for(d=new lf(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);li(b.a,c)}}
function Tg(a,b){27==b.which?(zi((Yh(),Xh),null),_g(a,a.c.d)):13==b.which&&Yg(a)}
function sf(a,b){if(0>a||a>b){throw ee(new Fe('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function qe(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Ab(a,b,c,d,e){e.V=a;e.W=b;e.X=ze;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Hb(a,b,c,d,e){var f;f=Tb(a,b);c&&Kb(f);if(e){a=Jb(a,b);d?(Bb=Rb(a)):(Bb=Eb(a.l,a.m,a.h))}return f}
function fe(a,b){var c;if(hc(a)&&hc(b)){c=a+b;if(Si<c&&c<Qi){return c}}return ge(Ob(hc(a)?je(a):a,hc(b)?je(b):b))}
function ji(a){return ke(Gf(new Mf(null,new zf(a.a))))-ke(Gf(Hf(new Mf(null,new zf(a.a)),new vi)))}
function o(a){return ic(a)?Nc:hc(a)?Ec:gc(a)?Cc:ec(a)?a.V:zb(a)?a.V:a.V||Array.isArray(a)&&vb(uc,1)||uc}
function p(a){return ic(a)?ig(a):hc(a)?kc(a):gc(a)?a?1231:1237:ec(a)?a.o():zb(a)?cg(a):!!a&&!!a.hashCode?a.hashCode():cg(a)}
function Yg(a){if(null!=a.e&&a.e.length!=0){mi((Yh(),Wh),a.c,a.e);zi(Xh,null);_g(a,a.e)}else{li((Yh(),Wh),a.c)}}
function Zg(a){var b;b=(Yh(),Xh).b==a.c;if(!a.f&&b){a.f=true;a.d.focus();a.d.select();_g(a,a.c.d)}else a.f&&!b&&(a.f=false)}
function bh(a){this.b=a;this.c=a.props['a'];v();++ah;this.a=new N;this.e=this.c.d;ei(this.c,new Hh(this))}
function Ke(){this.g=He++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Ci(a){this.a=new hf;this.c=a;De((Ce(),$wnd.goog.global.window),'hashchange',new Ei(this),false);ni(a,new Fi(this))}
function ye(a){var b;if(Array.isArray(a)&&a.X===ze){return Je(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function Gb(a,b){if(a.h==Pi&&a.m==0&&a.l==0){b&&(Bb=Eb(0,0,0));return Db((_b(),Zb))}b&&(Bb=Eb(a.l,a.m,a.h));return Eb(0,0,0)}
function ig(a){gg();var b,c,d;c=':'+a;d=fg[c];if(d!=null){return kc(d)}d=dg[c];b=d==null?hg(a):kc(d);jg();fg[c]=b;return b}
function of(a){var b,c,d;d=1;for(c=new lf(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function G(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=w(d);return c}}return null}
function cb(){var a;if(Y!=0){a=X();if(a-Z>2000){Z=a;$=$wnd.setTimeout(ib,10)}}if(Y++==0){lb((kb(),jb));return true}return false}
function Ng(a,b){var c;if(13==b.keyCode){b.preventDefault();c=$e(a.c);if(c.length>0){hi((Yh(),Wh),c);a.c='';a.b.forceUpdate()}}}
function Se(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function gf(a,b){var c,d;d=a.a.length;b.length<d&&(b=ag(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function w(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function tb(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function dc(a,b){if(ic(a)){return !!cc[b]}else if(a.W){return !!a.W[b]}else if(hc(a)){return !!bc[b]}else if(gc(a)){return !!ac[b]}return false}
function ug(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function $e(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Jb(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return Eb(c,d,e)}
function yb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Nb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&Ni;a.m=d&Ni;a.h=e&Oi;return true}
function C(a){var b;if(0==a.c){b=H(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;G(a.d);null.Y();return true}
function Pg(a){return qg(Ti,yg(Bg(Cg(Fg(Dg(ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,['new-todo']))),a.c),we(Eh.prototype.S,Eh,[a])),we(Fh.prototype.R,Fh,[a]))),null)}
function Pb(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function pe(b,c,d,e){oe();var f=me;$moduleName=c;$moduleBase=d;ce=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Ii(g)()}catch(a){b(c,a)}}else{Ii(g)()}}
function og(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function q(b){var c,d;try{if(J){d=null}else{J=new K(J);b.d=false;try{d=null}finally{L()}}return d}catch(a){a=de(a);if(fc(a,4)){c=a;throw ee(c)}else throw ee(a)}finally{r(b)}}
function pb(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Y()&&(c=ob(c,g)):g[0].Y()}catch(a){a=de(a);if(fc(a,4)){d=a;ab();gb(fc(d,22)?d.u():d)}else throw ee(a)}}return c}
function se(){re={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return Eb(c&Ni,d&Ni,e&Oi)}
function Tb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&Pi)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?Oi:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?Oi:0;f=d?Ni:0;e=c>>b-44}return Eb(e&Ni,f&Ni,g&Oi)}
function hg(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ye(a,c++)}b=b|0;return b}
function xi(a){var b,c,d;b=(d=(c=(Ce(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1)),Ze(Ui,d)?(ai(),Zh):Ze(Vi,d)?(ai(),_h):(ai(),$h));return Ff(Hf(new Mf(null,new zf(a.c.a)),new Hi(b)),new Bf(new Af))}
function Ve(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function ue(a,b,c){var d=re,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=re[b]),xe(h));_.W=c;!b&&(_.X=ze);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.V=f)}
function Re(a){if(a.C()){var b=a.c;b.D()?(a.k='['+b.j):!b.C()?(a.k='[L'+b.A()+';'):(a.k='['+b.A());a.b=b.w()+'[]';a.i=b.B()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Se('.',[c,Se('$',d)]);a.b=Se('.',[c,Se('.',d)]);a.i=d[d.length-1]}
function Mb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return We(c)}if(b==0&&d!=0&&c==0){return We(d)+22}if(b!=0&&d==0&&c==0){return We(b)+44}return -1}
function Qb(a){var b,c,d,e,f;if(isNaN(a)){return _b(),$b}if(a<-9223372036854775808){return _b(),Yb}if(a>=9223372036854775807){return _b(),Xb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=Qi){d=kc(a/Qi);a-=d*Qi}c=0;if(a>=Ri){c=kc(a/Ri);a-=c*Ri}b=kc(a);f=Eb(b,c,d);e&&Kb(f);return f}
function P(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.s();return a&&a.q()}},suppressed:{get:function(){return c.r()}}})}catch(a){}}}
function qg(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;lg(b,we(tg.prototype.P,tg,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=og($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function yi(a,b){var c,d,e;b.preventDefault();c=(d=(Ce(),$wnd.goog.global.window).location.hash,null==d?'':d.substr(1));if(Ze(Ui,c)||Ze(Vi,c)||Ze('',c)){df(a.a,new Gi)}else{e=$wnd.goog.global.window.location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Be.title,e)}}
function Wb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==Pi&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Wb(Rb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=Cb(1000000000);c=Fb(c,e,true);b=''+Vb(Bb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function Ib(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=Lb(b)-Lb(a);g=Sb(b,j);i=Eb(0,0,0);while(j>=0){h=Nb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&Kb(i);if(f){if(d){Bb=Rb(a);e&&(Bb=Ub(Bb,(_b(),Zb)))}else{Bb=Eb(a.l,a.m,a.h)}}return i}
function Fb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw ee(new Ee)}if(a.l==0&&a.m==0&&a.h==0){c&&(Bb=Eb(0,0,0));return Eb(0,0,0)}if(b.h==Pi&&b.m==0&&b.l==0){return Gb(a,c)}i=false;if(b.h>>19!=0){b=Rb(b);i=!i}g=Mb(b);f=false;e=false;d=false;if(a.h==Pi&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=Db((_b(),Xb));d=true;i=!i}else{h=Tb(a,g);i&&Kb(h);c&&(Bb=Eb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Rb(a);d=true;i=!i}if(g!=-1){return Hb(a,g,i,f,c)}if(Pb(a,b)<0){c&&(f?(Bb=Rb(a)):(Bb=Eb(a.l,a.m,a.h)));return Eb(0,0,0)}return Ib(d?a:Eb(a.l,a.m,a.h),b,i,f,e,c)}
function $g(a){var b,c;c=a.c;b=c.a;return qg('li',ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,[b?'checked':null,(Yh(),Xh).b==a.c?'editing':null])),[qg('div',ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,['view'])),[qg(Ti,Bg(zg(Eg(ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,['toggle']))),b),we(Kh.prototype.R,Kh,[a])),null),qg('label',Gg(new $wnd.Object,we(Lh.prototype.T,Lh,[a])),[c.d]),qg('button',xg(ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,['destroy'])),we(Mh.prototype.T,Mh,[a])),null)]),qg(Ti,Cg(Bg(Ag(Fg(ug(vg(new $wnd.Object,we(Nh.prototype.M,Nh,[a])),Ab(vb(Nc,1),Ki,2,6,['edit'])),a.e),we(Oh.prototype.Q,Oh,[a])),we(Ih.prototype.R,Ih,[a])),we(Jh.prototype.S,Jh,[a])),null)])}
var Ji={23:1},Ki={3:1},Li='__noinit__',Mi={3:1,6:1,4:1},Ni=4194303,Oi=1048575,Pi=524288,Qi=17592186044416,Ri=4194304,Si=-17592186044416,Ti='input',Ui='active',Vi='completed',Wi='selected',Xi='header';var _,re,me,ce=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;se();ue(1,null,{},n);_.n=function(){return this.V};_.o=Yi;_.hashCode=function(){return this.o()};var ac,bc,cc;ue(36,1,{},Ke);_.v=function(a){var b;b=new Ke;b.e=4;a>1?(b.c=Pe(this,a-1)):(b.c=this);return b};_.w=function(){Ie(this);return this.b};_.A=function(){return Je(this)};_.B=function(){Ie(this);return this.i};_.C=function(){return (this.e&4)!=0};_.D=function(){return (this.e&1)!=0};_.e=0;_.g=0;var He=1;var Lc=Me(1);var Dc=Me(36);ue(53,1,{},s);_.b=1;_.c=false;_.d=true;_.e=0;var nc=Me(53);ue(54,1,Ji,t);_.p=function(){D(this.a)};var mc=Me(54);var u;ue(27,1,{27:1},B);_.b=0;_.c=false;_.d=0;var oc=Me(27);ue(66,1,{},F);_.a=0;_.b=0;_.c=0;var pc=Me(66);ue(65,1,{},I);var qc=Me(65);ue(93,1,{},K);var J;var rc=Me(93);ue(17,1,{},N);_.a=0;var sc=Me(17);ue(4,1,{3:1,4:1});_.q=$i;_.r=function(){return Lf(Jf(nf((this.e==null&&(this.e=xb(Pc,Ki,4,0,0,1)),this.e)),new _e),new Pf)};_.s=function(){return this.c};_.t=function(){Q(this,S(new Error(R(this,this.d))));sb(this)};_.b=Li;_.f=true;var Pc=Me(4);ue(35,4,{3:1,4:1});var Gc=Me(35);ue(6,35,Mi);var Mc=Me(6);ue(47,6,Mi);var Jc=Me(47);ue(48,47,Mi);var wc=Me(48);ue(22,48,{22:1,3:1,6:1,4:1},W);_.u=function(){return jc(this.a)===jc(U)?null:this.a};var U;var tc=Me(22);var uc=Me(0);ue(112,1,{});var vc=Me(112);var Y=0,Z=0,$=-1;ue(58,112,{},nb);var jb;var xc=Me(58);var qb;ue(125,1,{});var zc=Me(125);ue(49,125,{},ub);var yc=Me(49);var Bb;var Xb,Yb,Zb,$b;var Be;ue(56,6,Mi,Ee);var Ac=Me(56);ue(52,6,Mi);var Ic=Me(52);ue(79,52,Mi,Fe);var Bc=Me(79);ac={3:1,25:1};var Cc=Me(122);ue(123,1,Ki);var Kc=Me(123);bc={3:1,25:1};var Ec=Me(124);ue(26,1,{3:1,25:1,26:1});_.o=Yi;var Fc=Me(26);ue(51,6,Mi,Ue);var Hc=Me(51);ue(186,1,{});cc={3:1,43:1,25:1,2:1};var Nc=Me(2);ue(190,1,{});ue(41,1,{},_e);_.G=function(a){return a.b};var Oc=Me(41);ue(55,6,Mi,af);var Qc=Me(55);ue(126,1,{109:1});_.F=function(a){Xe(this,a)};_.H=function(a){throw ee(new af)};var Rc=Me(126);ue(127,126,{109:1,133:1});_.H=function(a){bf(this,this.a.length,a);return true};_.o=function(){return of(this)};var Sc=Me(127);ue(10,127,{3:1,10:1,109:1,133:1},hf);_.H=function(a){return cf(this,a)};_.F=function(a){df(this,a)};var Uc=Me(10);ue(15,1,{},lf);_.a=0;_.b=-1;var Tc=Me(15);ue(68,1,{});_.K=Zi;_.I=function(){return this.d};_.J=function(){return this.e};_.d=0;_.e=0;var Yc=Me(68);ue(37,68,{});var Vc=Me(37);ue(59,1,{});_.K=Zi;_.I=$i;_.J=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Xc=Me(59);ue(60,59,{},xf);_.K=function(a){uf(this,a)};_.L=function(a){return vf(this,a)};var Wc=Me(60);ue(11,1,{},zf);_.I=function(){return this.a};_.J=function(){yf(this);return this.c};_.K=function(a){yf(this);pf(this.d,a)};_.L=function(a){yf(this);if(jf(this.d)){a.M(kf(this.d));return true}return false};_.a=0;_.c=0;var Zc=Me(11);ue(24,1,{},Af);_.G=function(a){return a};var $c=Me(24);ue(29,1,{},Bf);var _c=Me(29);ue(67,1,{});_.c=false;var kd=Me(67);ue(8,67,{},Mf);var jd=Me(8);ue(42,1,{},Pf);_.N=function(a){return xb(Lc,Ki,1,a,5,1)};var ad=Me(42);ue(70,37,{},Rf);_.L=function(a){this.b=false;while(!this.b&&this.c.L(new Sf(this,a)));return this.b};_.b=false;var cd=Me(70);ue(73,1,{},Sf);_.M=function(a){Qf(this.a,this.b,a)};var bd=Me(73);ue(69,37,{},Uf);_.L=function(a){return this.b.L(new Vf(this,a))};var ed=Me(69);ue(72,1,{},Vf);_.M=function(a){Tf(this.a,this.b,a)};var dd=Me(72);ue(71,1,{},Xf);_.M=function(a){Wf(this,a)};var fd=Me(71);ue(74,1,{},Yf);_.M=function(a){};var gd=Me(74);ue(75,1,{},Zf);_.M=function(a){Of(this.a,a)};var hd=Me(75);ue(188,1,{});ue(185,1,{});var bg=0;var dg,eg=0,fg;ue(799,1,{});ue(822,1,{});ue(80,1,{},sg);_.N=function(a){return new Array(a)};var ld=Me(80);ue(154,$wnd.Function,{},tg);_.P=function(a){rg(this.a,this.b,a)};ue(130,1,{});var vd=Me(130);ue(102,130,{});var zd=Me(102);ue(103,102,{},Jg);var Ig=0;var nd=Me(103);ue(131,1,{});var ud=Me(131);ue(132,131,{});var yd=Me(132);ue(108,132,{},Lg);var Kg=0;var md=Me(108);ue(99,1,{});_.c='';var Hd=Me(99);ue(100,99,{});var Bd=Me(100);ue(101,100,{},Rg);var Qg=0;var od=Me(101);ue(129,1,{});_.f=false;var Kd=Me(129);ue(105,129,{});var Dd=Me(105);ue(106,105,{},bh);var ah=0;var pd=Me(106);ue(128,1,{});var Pd=Me(128);ue(77,128,{});var Fd=Me(77);ue(78,77,{},fh);var eh=0;var qd=Me(78);ue(96,1,Ji,gh);_.p=bj;var rd=Me(96);ue(159,$wnd.Function,{},hh);_.T=function(a){ii((Yh(),Wh))};ue(87,1,{},ih);var sd=Me(87);ue(104,1,{},jh);var td=Me(104);ue(158,$wnd.Function,{},kh);_.U=function(a){return new nh(a)};var lh;ue(95,$wnd.React.Component,{},nh);te(re[1],_);_.componentDidMount=function(){Hg(this.a)};_.componentWillUnmount=_i;_.render=function(){var a,b,c;return a=(c=(Yh(),b=(Ce(),$wnd.goog.global.window).location.hash,null==b?'':b.substr(1)),Ze(Ui,c)?(ai(),Zh):Ze(Vi,c)?(ai(),_h):(ai(),$h)),qg('footer',ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,['footer'])),[(new jh).a,qg('ul',ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,['filters'])),[qg('li',null,[qg('a',wg(ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,[(ai(),$h)==a?Wi:null])),'#'),['All'])]),qg('li',null,[qg('a',wg(ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,[Zh==a?Wi:null])),'#active'),['Active'])]),qg('li',null,[qg('a',wg(ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,[_h==a?Wi:null])),'#completed'),['Completed'])])]),ji(Wh)>0?qg('button',xg(ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,['clear-completed'])),we(hh.prototype.T,hh,[])),['Clear Completed']):null])};_.shouldComponentUpdate=aj;var wd=Me(95);ue(169,$wnd.Function,{},oh);_.U=function(a){return new rh(a)};var ph;ue(107,$wnd.React.Component,{},rh);te(re[1],_);_.componentWillUnmount=_i;_.render=function(){var a;return a=ke(Gf(new Mf(null,new zf((Yh(),Wh).a)))),qg('span',ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,['todo-count'])),[qg('strong',null,[a]),' item'+(a==1?'':'s')+' left'])};_.shouldComponentUpdate=aj;var xd=Me(107);ue(157,$wnd.Function,{},sh);_.U=function(a){return new vh(a)};var th;ue(94,$wnd.React.Component,{},vh);te(re[1],_);_.componentWillUnmount=_i;_.render=function(){return Pg(this.a)};_.shouldComponentUpdate=aj;var Ad=Me(94);ue(160,$wnd.Function,{},wh);_.U=function(a){return new zh(a)};var xh;ue(97,$wnd.React.Component,{},zh);te(re[1],_);_.componentDidUpdate=function(a){Zg(this.a)};_.componentWillUnmount=_i;_.render=function(){return $g(this.a)};_.shouldComponentUpdate=aj;var Cd=Me(97);ue(152,$wnd.Function,{},Ah);_.U=function(a){return new Dh(a)};var Bh;ue(61,$wnd.React.Component,{},Dh);te(re[1],_);_.componentDidMount=function(){dh(this.a)};_.componentWillUnmount=_i;_.render=function(){return qg('div',null,[qg('div',null,[qg(Xi,ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,[Xi])),[qg('h1',null,['todos']),(new Gh).a]),0!=ke(Gf(new Mf(null,new zf((Yh(),Wh).a))))?qg('section',ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,[Xi])),[qg(Ti,Bg(Eg(ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,['toggle-all']))),we(Th.prototype.R,Th,[])),null),qg('ul',ug(new $wnd.Object,Ab(vb(Nc,1),Ki,2,6,['todo-list'])),Lf(Jf(new Mf(null,new zf(xi(Xh))),new Uh),new sg))]):null,0!=ke(Gf(new Mf(null,new zf(Wh.a))))?(new ih).a:null])])};_.shouldComponentUpdate=aj;var Ed=Me(61);ue(155,$wnd.Function,{},Eh);_.S=function(a){Ng(this.a,a)};ue(156,$wnd.Function,{},Fh);_.R=function(a){Mg(this.a,a)};ue(81,1,{},Gh);var Gd=Me(81);ue(98,1,Ji,Hh);_.p=bj;var Id=Me(98);ue(167,$wnd.Function,{},Ih);_.R=function(a){Sg(this.a,a)};ue(168,$wnd.Function,{},Jh);_.S=function(a){Tg(this.a,a)};ue(161,$wnd.Function,{},Kh);_.R=function(a){Ug(this.a)};ue(163,$wnd.Function,{},Lh);_.T=function(a){Vg(this.a)};ue(164,$wnd.Function,{},Mh);_.T=function(a){Wg(this.a)};ue(165,$wnd.Function,{},Nh);_.M=function(a){Xg(this.a,a)};ue(166,$wnd.Function,{},Oh);_.Q=function(a){Yg(this.a)};ue(92,1,{},Qh);var Jd=Me(92);ue(62,1,Ji,Rh);_.p=bj;var Ld=Me(62);ue(63,1,Ji,Sh);_.p=bj;var Md=Me(63);ue(153,$wnd.Function,{},Th);_.R=function(a){var b;b=a.target;pi((Yh(),Wh),b.checked)};ue(64,1,{},Uh);_.G=function(a){return Ph(new Qh,a)};var Nd=Me(64);ue(40,1,{},Vh);var Od=Me(40);var Wh,Xh;ue(19,26,{3:1,25:1,26:1,19:1},bi);var Zh,$h,_h;var Qd=Ne(19,ci);ue(38,1,{38:1},fi);_.a=false;var Yd=Me(38);ue(30,1,{},gi);_.M=cj;var Rd=Me(30);ue(82,1,{},qi);var Xd=Me(82);ue(85,1,{},si);_.O=function(a){return a.a};var Sd=Me(85);ue(86,1,{},ti);_.M=function(a){li(this.a,a)};var Td=Me(86);ue(18,1,{},ui);_.M=cj;var Ud=Me(18);ue(83,1,{},vi);_.O=function(a){return !a.a};var Vd=Me(83);ue(84,1,{},wi);_.M=function(a){ri(this.a,a)};_.a=false;var Wd=Me(84);ue(88,1,{},Ci);var be=Me(88);ue(89,1,{},Ei);_.handleEvent=function(a){yi(this.a,a)};var Zd=Me(89);ue(90,1,Ji,Fi);_.p=function(){Bi(this.a)};var $d=Me(90);ue(28,1,{},Gi);_.M=cj;var _d=Me(28);ue(91,1,{},Hi);_.O=function(a){return Di(this.a,a)};var ae=Me(91);var lc=Oe('D');var Ii=(ab(),db);var gwtOnLoad=gwtOnLoad=pe;ne(Ae);qe('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();