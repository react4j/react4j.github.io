function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='49F303142DF270EEBE3267880A276502',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '49F303142DF270EEBE3267880A276502';function n(){}
function s(){}
function Y(){}
function ge(){}
function ce(){}
function Je(){}
function eb(){}
function hf(){}
function xf(){}
function Ff(){}
function Gf(){}
function cg(){}
function qh(){}
function th(){}
function xh(){}
function Bh(){}
function Fh(){}
function Jh(){}
function ai(){}
function bi(){}
function pi(){}
function Bi(){}
function Di(){}
function Ei(){}
function Pi(){}
function q(){new t}
function ne(){ne=ce}
function nj(a){a.p()}
function cb(a){bb()}
function Ef(a,b){a.a=b}
function jf(a){this.a=a}
function Hf(a){this.a=a}
function ph(a){this.a=a}
function Nh(a){this.a=a}
function Oh(a){this.a=a}
function Qh(a){this.a=a}
function Rh(a){this.a=a}
function Sh(a){this.a=a}
function Th(a){this.a=a}
function Uh(a){this.a=a}
function Vh(a){this.a=a}
function Wh(a){this.a=a}
function Xh(a){this.a=a}
function $h(a){this.a=a}
function _h(a){this.a=a}
function Ci(a){this.a=a}
function Fi(a){this.a=a}
function Ni(a){this.a=a}
function Oi(a){this.a=a}
function Qi(a){this.a=a}
function Ue(a){this.c=a}
function jj(a){$e(this,a)}
function Nd(a){return a.b}
function kj(){return this.b}
function lj(a){return false}
function r(){r=ce;new q}
function F(){F=ce;D=new n}
function V(){V=ce;U=new Y}
function Ug(){r();++Tg}
function Vf(a,b){Uf(a,b)}
function ni(a,b){Me(a.c,b)}
function wi(a,b){Me(a.b,b)}
function Ji(a,b){Me(a.a,b)}
function Le(a,b,c){If(a.a,b,c)}
function df(a,b,c){b.M(a.a[c])}
function Xf(a,b){a.key=b}
function w(a,b){a.b=b;v(a,b)}
function Jf(a,b){a.splice(b,1)}
function fb(a,b){return we(a,b)}
function fh(a,b){return a.b=b}
function qe(a){pe(a);return a.k}
function vf(a,b){a.H(b);return a}
function qf(a,b){kf(a);a.a.K(b)}
function wf(a,b){Ef(a,vf(a.a,b))}
function $e(a,b){while(a.L(b));}
function Bf(a,b,c){b.M(a.a.G(c))}
function me(a){C.call(this,a)}
function L(){L=ce;!!(bb(),ab)}
function T(){I!=0&&(I=0);K=-1}
function Xd(){Vd==null&&(Vd=[])}
function ij(){return Mf(this)}
function Fb(a){return a.l|a.m<<22}
function Sg(a){this.a=a;r();++Rg}
function $g(a){this.a=a;r();++Zg}
function oh(a){this.a=a;r();++nh}
function Be(a,b){this.a=a;this.b=b}
function Af(a,b){this.a=a;this.b=b}
function Df(a,b){this.a=a;this.b=b}
function dg(a,b){this.a=a;this.b=b}
function Og(a,b){Be.call(this,a,b)}
function ki(a,b){Be.call(this,a,b)}
function If(a,b,c){a.splice(b,0,c)}
function fg(a,b){a.ref=b;return a}
function gg(a,b){a.href=b;return a}
function pg(a,b){a.value=b;return a}
function kg(a,b){a.onBlur=b;return a}
function S(a){$wnd.clearTimeout(a)}
function rh(){this.a=_f((vh(),uh))}
function sh(){this.a=_f((zh(),yh))}
function Ph(){this.a=_f((Dh(),Ch))}
function Zh(){this.a=_f((Hh(),Gh))}
function ci(){this.a=_f((Lh(),Kh))}
function mj(){this.a.a.forceUpdate()}
function gf(a){this.b=a;this.a=16464}
function Tb(a){return typeof a===Si}
function Vb(a){return a==null?null:a}
function nb(a){return ob(a.l,a.m,a.h)}
function Se(a){return a.a<a.c.a.length}
function He(a,b){return Vb(a)===Vb(b)}
function Uf(a,b){for(var c in a){b(c)}}
function hg(a,b){a.onClick=b;return a}
function lg(a,b){a.onChange=b;return a}
function jg(a,b){a.checked=b;return a}
function mi(a,b){a.a=b;Ne(a.c,new pi)}
function Ai(a,b){b.a=a;Ne(b.c,new pi)}
function Ii(a,b){a.b=b;Ne(a.a,new Pi)}
function ti(a,b){return Oe(a.a,b,0)!=-1}
function ob(a,b,c){return {l:a,m:b,h:c}}
function Ge(a,b){return a.charCodeAt(b)}
function Rb(a,b){return a!=null&&Pb(a,b)}
function Mf(a){return a.$H||(a.$H=++Lf)}
function Ub(a){return typeof a==='string'}
function mg(a,b){a.onKeyDown=b;return a}
function Wf(a,b){a.props['a']=b;return a}
function ig(a){a.autoFocus=true;return a}
function pe(a){if(a.k!=null){return}ye(a)}
function Qg(a){Ji((fi(),ei),new ph(a))}
function ui(a,b){Pe(a.a,b);Ne(a.b,new Di)}
function xi(a,b){mi(b,!b.a);Ne(a.b,new Di)}
function Xg(a,b){a.b=b;a.a.forceUpdate()}
function jh(a,b){a.c=b;a.a.forceUpdate()}
function C(a){this.d=a;u(this);this.t()}
function uf(a,b){mf.call(this,a);this.a=b}
function le(){C.call(this,'divide by zero')}
function Re(){this.a=hb(rc,Ti,1,0,5,1)}
function zi(){this.a=new Re;this.b=new Re}
function Qf(){Qf=ce;Nf=new n;Pf=new n}
function fi(){fi=ce;di=new zi;ei=new Li(di)}
function bb(){bb=ce;var a;!db();a=new eb;ab=a}
function Sb(a){return typeof a==='boolean'}
function M(a,b,c){return a.apply(b,c);var d}
function Te(a){a.b=a.a++;return a.c.a[a.b]}
function u(a){a.f&&a.b!==Ui&&a.t();return a}
function qg(a,b){a.onDoubleClick=b;return a}
function Me(a,b){a.a[a.a.length]=b;return true}
function te(a){var b;b=se(a);Ae(a,b);return b}
function Vg(a,b){var c;c=b.target;Xg(a,c.value)}
function nf(a,b){var c;return sf(a,(c=new Re,c))}
function bf(a,b){while(a.c<a.d){df(a,b,a.c++)}}
function yf(a,b,c){if(a.a.O(c)){a.b=true;b.M(c)}}
function ke(a,b,c,d){a.addEventListener(b,c,d)}
function Td(a){if(Tb(a)){return a|0}return Fb(a)}
function Ud(a){if(Tb(a)){return ''+a}return Gb(a)}
function ve(a){var b;b=se(a);b.j=a;b.e=1;return b}
function Z(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ve(a,b){return _e(b,a.length),new ef(a,b)}
function We(a){return new uf(null,Ve(a,a.length))}
function pf(a,b){lf(a);return new uf(a,new zf(b,a.a))}
function rf(a,b){lf(a);return new uf(a,new Cf(b,a.a))}
function kf(a){if(!a.b){lf(a);a.c=true}else{kf(a.b)}}
function bh(a){xi((fi(),di),a.a.props['a'])}
function eh(a){ui((fi(),di),a.a.props['a'])}
function mh(a){wi((fi(),di),new $h(a));Ji(ei,new _h(a))}
function vi(a,b,c){b.d=c;Ne(b.c,new pi);Ne(a.b,new Di)}
function og(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function af(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function ef(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function mf(a){if(!a){this.b=null;new Re}else{this.b=a}}
function Tf(){if(Of==256){Nf=Pf;Pf=new n;Of=0}++Of}
function jb(a){return Array.isArray(a)&&a.X===ge}
function Qb(a){return !Array.isArray(a)&&a.X===ge}
function Mi(a,b){return (ji(),hi)==a||(gi==a?!b.a:b.a)}
function Ze(a,b){return Vb(a)===Vb(b)||!!a&&Vb(a)===Vb(b)}
function li(){ji();return kb(fb(xd,1),Ti,20,0,[gi,ii,hi])}
function je(){je=ce;ie=$wnd.goog.global.document}
function Ah(a){$wnd.React.Component.call(this,a);new Ug}
function R(a){L();$wnd.setTimeout(function(){throw a},0)}
function xe(a){if(a.D()){return null}var b=a.j;return $d[b]}
function ff(a){if(!a.d){a.d=new Ue(a.b);a.c=a.b.a.length}}
function ue(a,b){var c;c=se(a);Ae(a,c);c.e=b?8:0;return c}
function A(a,b){var c;c=qe(a.V);return b==null?c:c+': '+b}
function we(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.v(b))}
function vh(){vh=ce;var a;uh=(a=de(th.prototype.U,th,[]),a)}
function zh(){zh=ce;var a;yh=(a=de(xh.prototype.U,xh,[]),a)}
function Dh(){Dh=ce;var a;Ch=(a=de(Bh.prototype.U,Bh,[]),a)}
function Hh(){Hh=ce;var a;Gh=(a=de(Fh.prototype.U,Fh,[]),a)}
function Lh(){Lh=ce;var a;Kh=(a=de(Jh.prototype.U,Jh,[]),a)}
function ee(a){function b(){}
;b.prototype=a||{};return new b}
function B(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function ng(a){a.placeholder='What needs to be done?';return a}
function cf(a,b){if(a.c<a.d){df(a,b,a.c++);return true}return false}
function lf(a){if(a.b){lf(a.b)}else if(a.c){throw Nd(new Ce)}}
function Q(a){a&&X((V(),U));--I;if(a){if(K!=-1){S(K);K=-1}}}
function oi(a,b){this.c=new Re;this.b=a;this.d=b;this.a=false}
function Cf(a,b){af.call(this,b.J(),b.I()&-6);this.a=a;this.b=b}
function zf(a,b){af.call(this,b.J(),b.I()&-16449);this.a=a;this.c=b}
function Ke(){C.call(this,'Add not supported on this collection')}
function dh(a){Ii((fi(),ei),a.a.props['a']);jh(a,a.a.props['a'].d)}
function Ye(a,b){while(a.a<a.c.a.length){b.M((a.b=a.a++,a.c.a[a.b]))}}
function ae(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function P(a,b,c){var d;d=N();try{return M(a,b,c)}finally{Q(d)}}
function O(b){L();return function(){return P(b,this,arguments);var a}}
function Wb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function wh(a){$wnd.React.Component.call(this,a);this.a=new Sg(this)}
function Eh(a){$wnd.React.Component.call(this,a);this.a=new $g(this)}
function Ih(a){$wnd.React.Component.call(this,a);this.a=new lh(this)}
function Mh(a){$wnd.React.Component.call(this,a);this.a=new oh(this)}
function Ki(a){var b;b=a.b;!!b&&!ti(a.c,b)&&(a.b=null,Ne(a.a,new Pi))}
function yi(a,b){qf(new uf(null,new gf(a.a)),new Fi(b));Ne(a.b,new Di)}
function qi(a,b){Me(a.a,new oi(''+Ud(Qd(Date.now())),b));Ne(a.b,new Di)}
function tf(a,b){var c;c=nf(a,new jf(new hf));return Qe(c,b.N(c.a.length))}
function sf(a,b){var c;kf(a);c=new Ff;c.a=b;a.a.K(new Hf(c));return c.a}
function of(a){var b;kf(a);b=0;while(a.a.L(new Gf)){b=Od(b,1)}return b}
function mb(a){var b,c,d;b=a&Wi;c=a>>22&Wi;d=a<0?Xi:0;return ob(b,c,d)}
function Ne(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.M(c)}}
function Pe(a,b){var c;c=Oe(a,b,0);if(c==-1){return false}Jf(a.a,c);return true}
function Yh(a,b){Xf(a.a,(b?b.b:null)+(''+(pe(rd),rd.k)));Wf(a.a,b);return a.a}
function Oe(a,b,c){for(;c<a.a.length;++c){if(Ze(b,a.a[c])){return c}}return -1}
function bg(a,b,c){!He(c,'key')&&!He(c,'ref')&&(a[c]=b[c],undefined)}
function hb(a,b,c,d,e,f){var g;g=ib(e,d);e!=10&&kb(fb(a,f),b,c,e,g);return g}
function Kf(a,b){return gb(b)!=10&&kb(o(b),b.W,b.__elementTypeId$,gb(b),a),a}
function gb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function H(){if(Date.now){return Date.now()}return (new Date).getTime()}
function ri(a){nf(pf(new uf(null,new gf(a.a)),new Bi),new jf(new hf)).F(new Ci(a))}
function $f(a){var b;return Yf($wnd.React.StrictMode,null,null,(b={},b[aj]=a,b))}
function X(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=$(b,c)}while(a.b);a.b=c}}
function W(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=$(b,c)}while(a.a);a.a=c}}
function t(){var a;this.a=hb(Zb,Ti,26,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function Ee(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function Ae(a,b){var c;if(!a){return}b.j=a;var d=xe(b);if(!d){$d[a]=[b];return}d.V=b}
function de(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function _g(a,b){var c;if((fi(),ei).b==a.a.props['a']){c=b.target;jh(a,c.value)}}
function _f(a){var b;b=Zf($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Yf(a,b,c,d){var e;e=Zf($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function se(a){var b;b=new re;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Pd(a){var b;b=a.h;if(b==0){return a.l+a.m*$i}if(b==Xi){return a.l+a.m*$i-Zi}return a}
function Qd(a){if(_i<a&&a<Zi){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Pd(Ab(a))}
function Wd(){Xd();var a=Vd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Fe(a,b){var c,d;for(d=new Ue(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);ui(b.a,c)}}
function Sd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Zi;d=Xi}c=Wb(e/$i);b=Wb(e-c*$i);return ob(b,c,d)}
function Lb(){Lb=ce;Hb=ob(Wi,Wi,524287);Ib=ob(0,0,Yi);Jb=mb(1);mb(2);Kb=mb(0)}
function ji(){ji=ce;gi=new ki('ACTIVE',0);ii=new ki('COMPLETED',1);hi=new ki('ALL',2)}
function Ce(){C.call(this,"Stream already terminated, can't be modified or used")}
function G(a){F();u(this);this.b=a;v(this,a);this.d=a==null?'null':fe(a);this.a=a}
function lh(a){this.a=a;r();++kh;this.c=this.a.props['a'].d;ni(this.a.props['a'],new Qh(this))}
function ah(a,b){27==b.which?(Ii((fi(),ei),null),jh(a,a.a.props['a'].d)):13==b.which&&gh(a)}
function he(){$wnd.ReactDOM.render($f([(new ci).a]),(je(),ie).getElementById('app'),null)}
function si(a){return Td(of(new uf(null,new gf(a.a))))-Td(of(pf(new uf(null,new gf(a.a)),new Ei)))}
function Md(a){var b;if(Rb(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new G(a);cb(b)}return b}
function vb(a){var b,c;c=De(a.h);if(c==32){b=De(a.m);return b==32?De(a.l)+32:b+20-10}else{return c-12}}
function Bb(a){var b,c,d;b=~a.l+1&Wi;c=~a.m+(b==0?1:0)&Wi;d=~a.h+(b==0&&c==0?1:0)&Xi;return ob(b,c,d)}
function ub(a){var b,c,d;b=~a.l+1&Wi;c=~a.m+(b==0?1:0)&Wi;d=~a.h+(b==0&&c==0?1:0)&Xi;a.l=b;a.m=c;a.h=d}
function yb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ob(c&Wi,d&Wi,e&Xi)}
function Eb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return ob(c&Wi,d&Wi,e&Xi)}
function kb(a,b,c,d,e){e.V=a;e.W=b;e.X=ge;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function rb(a,b,c,d,e){var f;f=Db(a,b);c&&ub(f);if(e){a=tb(a,b);d?(lb=Bb(a)):(lb=ob(a.l,a.m,a.h))}return f}
function Od(a,b){var c;if(Tb(a)&&Tb(b)){c=a+b;if(_i<c&&c<Zi){return c}}return Pd(yb(Tb(a)?Sd(a):a,Tb(b)?Sd(b):b))}
function _e(a,b){if(0>a||a>b){throw Nd(new me('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Zd(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function o(a){return Ub(a)?tc:Tb(a)?kc:Sb(a)?ic:Qb(a)?a.V:jb(a)?a.V:a.V||Array.isArray(a)&&fb(ac,1)||ac}
function p(a){return Ub(a)?Sf(a):Tb(a)?Wb(a):Sb(a)?a?1231:1237:Qb(a)?a.o():jb(a)?Mf(a):!!a&&!!a.hashCode?a.hashCode():Mf(a)}
function fe(a){var b;if(Array.isArray(a)&&a.X===ge){return qe(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function qb(a,b){if(a.h==Yi&&a.m==0&&a.l==0){b&&(lb=ob(0,0,0));return nb((Lb(),Jb))}b&&(lb=ob(a.l,a.m,a.h));return ob(0,0,0)}
function Sf(a){Qf();var b,c,d;c=':'+a;d=Pf[c];if(d!=null){return Wb(d)}d=Nf[c];b=d==null?Rf(a):Wb(d);Tf();Pf[c]=b;return b}
function Xe(a){var b,c,d;d=1;for(c=new Ue(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function Qe(a,b){var c,d;d=a.a.length;b.length<d&&(b=Kf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function ze(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Wg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=Ie(a.b);if(c.length>0){qi((fi(),di),c);a.b='';a.a.forceUpdate()}}}
function N(){var a;if(I!=0){a=H();if(a-J>2000){J=a;K=$wnd.setTimeout(T,10)}}if(I++==0){W((V(),U));return true}return false}
function db(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function re(){this.g=oe++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Li(a){this.a=new Re;this.c=a;ke((je(),$wnd.goog.global.window),'hashchange',new Ni(this),false);wi(a,new Oi(this))}
function Pg(){Ng();return kb(fb(Tc,1),Ti,5,0,[rg,sg,tg,ug,vg,wg,xg,yg,zg,Ag,Bg,Cg,Dg,Eg,Fg,Gg,Hg,Ig,Jg,Kg,Lg,Mg])}
function gh(a){if(null!=a.c&&a.c.length!=0){vi((fi(),di),a.a.props['a'],a.c);Ii(ei,null);jh(a,a.c)}else{ui((fi(),di),a.a.props['a'])}}
function Pb(a,b){if(Ub(a)){return !!Ob[b]}else if(a.W){return !!a.W[b]}else if(Tb(a)){return !!Nb[b]}else if(Sb(a)){return !!Mb[b]}return false}
function hh(a){var b;b=(fi(),ei).b==a.a.props['a'];if(!a.d&&b){a.d=true;a.b.focus();a.b.select();jh(a,a.a.props['a'].d)}else a.d&&!b&&(a.d=false)}
function eg(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Ie(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function tb(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return ob(c,d,e)}
function Cb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return ob(c&Wi,d&Wi,e&Xi)}
function ib(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function xb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&Wi;a.m=d&Wi;a.h=e&Xi;return true}
function Yg(a){return ag(cj,ig(lg(mg(pg(ng(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['new-todo']))),a.b),de(Nh.prototype.S,Nh,[a])),de(Oh.prototype.R,Oh,[a]))),null)}
function zb(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Yd(b,c,d,e){Xd();var f=Vd;$moduleName=c;$moduleBase=d;Ld=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Ri(g)()}catch(a){b(c,a)}}else{Ri(g)()}}
function Zf(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function $(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Y()&&(c=Z(c,g)):g[0].Y()}catch(a){a=Md(a);if(Rb(a,4)){d=a;L();R(Rb(d,24)?d.u():d)}else throw Nd(a)}}return c}
function _d(){$d={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Rf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ge(a,c++)}b=b|0;return b}
function Gi(a){var b,c,d;b=(d=(c=(je(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1)),He(ej,d)?(ji(),gi):He(fj,d)?(ji(),ii):(ji(),hi));return nf(pf(new uf(null,new gf(a.c.a)),new Qi(b)),new jf(new hf))}
function De(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function be(a,b,c){var d=$d,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=$d[b]),ee(h));_.W=c;!b&&(_.X=ge);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.V=f)}
function Db(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&Yi)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?Xi:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?Xi:0;f=d?Wi:0;e=c>>b-44}return ob(e&Wi,f&Wi,g&Xi)}
function ye(a){if(a.C()){var b=a.c;b.D()?(a.k='['+b.j):!b.C()?(a.k='[L'+b.A()+';'):(a.k='['+b.A());a.b=b.w()+'[]';a.i=b.B()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=ze('.',[c,ze('$',d)]);a.b=ze('.',[c,ze('.',d)]);a.i=d[d.length-1]}
function ag(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Vf(b,de(dg.prototype.P,dg,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[aj]=c[0],undefined):(d[aj]=c,undefined));return Yf(a,e,f,d)}
function wb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return Ee(c)}if(b==0&&d!=0&&c==0){return Ee(d)+22}if(b!=0&&d==0&&c==0){return Ee(b)+44}return -1}
function Ab(a){var b,c,d,e,f;if(isNaN(a)){return Lb(),Kb}if(a<-9223372036854775808){return Lb(),Ib}if(a>=9223372036854775807){return Lb(),Hb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=Zi){d=Wb(a/Zi);a-=d*Zi}c=0;if(a>=$i){c=Wb(a/$i);a-=c*$i}b=Wb(a);f=ob(b,c,d);e&&ub(f);return f}
function v(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.s();return a&&a.q()}},suppressed:{get:function(){return c.r()}}})}catch(a){}}}
function Hi(a,b){var c,d,e;b.preventDefault();c=(d=(je(),$wnd.goog.global.window).location.hash,null==d?'':d.substr(1));if(He(ej,c)||He(fj,c)||He('',c)){Ne(a.a,new Pi)}else{e=$wnd.goog.global.window.location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',ie.title,e)}}
function Gb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==Yi&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Gb(Bb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=mb(1000000000);c=pb(c,e,true);b=''+Fb(lb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function sb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=vb(b)-vb(a);g=Cb(b,j);i=ob(0,0,0);while(j>=0){h=xb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&ub(i);if(f){if(d){lb=Bb(a);e&&(lb=Eb(lb,(Lb(),Jb)))}else{lb=ob(a.l,a.m,a.h)}}return i}
function Ng(){Ng=ce;rg=new Og(bj,0);sg=new Og('checkbox',1);tg=new Og('color',2);ug=new Og('date',3);vg=new Og('datetime',4);wg=new Og('email',5);xg=new Og('file',6);yg=new Og('hidden',7);zg=new Og('image',8);Ag=new Og('month',9);Bg=new Og(Si,10);Cg=new Og('password',11);Dg=new Og('radio',12);Eg=new Og('range',13);Fg=new Og('reset',14);Gg=new Og('search',15);Hg=new Og('submit',16);Ig=new Og('tel',17);Jg=new Og('text',18);Kg=new Og('time',19);Lg=new Og('url',20);Mg=new Og('week',21)}
function pb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Nd(new le)}if(a.l==0&&a.m==0&&a.h==0){c&&(lb=ob(0,0,0));return ob(0,0,0)}if(b.h==Yi&&b.m==0&&b.l==0){return qb(a,c)}i=false;if(b.h>>19!=0){b=Bb(b);i=!i}g=wb(b);f=false;e=false;d=false;if(a.h==Yi&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=nb((Lb(),Hb));d=true;i=!i}else{h=Db(a,g);i&&ub(h);c&&(lb=ob(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Bb(a);d=true;i=!i}if(g!=-1){return rb(a,g,i,f,c)}if(zb(a,b)<0){c&&(f?(lb=Bb(a)):(lb=ob(a.l,a.m,a.h)));return ob(0,0,0)}return sb(d?a:ob(a.l,a.m,a.h),b,i,f,e,c)}
function ih(a){var b,c;c=a.a.props['a'];b=c.a;return ag('li',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[b?'checked':null,(fi(),ei).b==a.a.props['a']?'editing':null])),[ag('div',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['view'])),[ag(cj,lg(jg(og(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['toggle'])),(Ng(),sg)),b),de(Th.prototype.R,Th,[a])),null),ag('label',qg(new $wnd.Object,de(Uh.prototype.T,Uh,[a])),[c.d]),ag(bj,hg(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['destroy'])),de(Vh.prototype.T,Vh,[a])),null)]),ag(cj,mg(lg(kg(pg(eg(fg(new $wnd.Object,de(Wh.prototype.M,Wh,[a])),kb(fb(tc,1),Ti,2,6,['edit'])),a.c),de(Xh.prototype.Q,Xh,[a])),de(Rh.prototype.R,Rh,[a])),de(Sh.prototype.S,Sh,[a])),null)])}
var Si='number',Ti={3:1},Ui='__noinit__',Vi={3:1,7:1,4:1},Wi=4194303,Xi=1048575,Yi=524288,Zi=17592186044416,$i=4194304,_i=-17592186044416,aj='children',bj='button',cj='input',dj={33:1},ej='active',fj='completed',gj='selected',hj='header';var _,$d,Vd,Ld=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;_d();be(1,null,{},n);_.n=function(){return this.V};_.o=ij;_.hashCode=function(){return this.o()};var Mb,Nb,Ob;be(36,1,{},re);_.v=function(a){var b;b=new re;b.e=4;a>1?(b.c=we(this,a-1)):(b.c=this);return b};_.w=function(){pe(this);return this.b};_.A=function(){return qe(this)};_.B=function(){pe(this);return this.i};_.C=function(){return (this.e&4)!=0};_.D=function(){return (this.e&1)!=0};_.e=0;_.g=0;var oe=1;var rc=te(1);var jc=te(36);be(55,1,{},q);var Yb=te(55);be(26,1,{26:1},s);var Zb=te(26);be(64,1,{},t);var $b=te(64);be(4,1,{3:1,4:1});_.q=kj;_.r=function(){return tf(rf(We((this.e==null&&(this.e=hb(vc,Ti,4,0,0,1)),this.e)),new Je),new xf)};_.s=function(){return this.c};_.t=function(){w(this,B(new Error(A(this,this.d))));cb(this)};_.b=Ui;_.f=true;var vc=te(4);be(35,4,{3:1,4:1});var mc=te(35);be(7,35,Vi);var sc=te(7);be(47,7,Vi);var pc=te(47);be(48,47,Vi);var cc=te(48);be(24,48,{24:1,3:1,7:1,4:1},G);_.u=function(){return Vb(this.a)===Vb(D)?null:this.a};var D;var _b=te(24);var ac=te(0);be(109,1,{});var bc=te(109);var I=0,J=0,K=-1;be(57,109,{},Y);var U;var dc=te(57);var ab;be(122,1,{});var fc=te(122);be(49,122,{},eb);var ec=te(49);var lb;var Hb,Ib,Jb,Kb;var ie;be(54,7,Vi,le);var gc=te(54);be(52,7,Vi);var oc=te(52);be(77,52,Vi,me);var hc=te(77);Mb={3:1,23:1};var ic=te(119);be(120,1,Ti);var qc=te(120);Nb={3:1,23:1};var kc=te(121);be(18,1,{3:1,23:1,18:1});_.o=ij;_.b=0;var lc=te(18);be(51,7,Vi,Ce);var nc=te(51);be(183,1,{});Ob={3:1,43:1,23:1,2:1};var tc=te(2);be(187,1,{});be(41,1,{},Je);_.G=function(a){return a.b};var uc=te(41);be(53,7,Vi,Ke);var wc=te(53);be(123,1,{106:1});_.F=function(a){Fe(this,a)};_.H=function(a){throw Nd(new Ke)};var xc=te(123);be(124,123,{106:1,130:1});_.H=function(a){Le(this,this.a.length,a);return true};_.o=function(){return Xe(this)};var yc=te(124);be(11,124,{3:1,11:1,106:1,130:1},Re);_.H=function(a){return Me(this,a)};_.F=function(a){Ne(this,a)};var Ac=te(11);be(16,1,{},Ue);_.a=0;_.b=-1;var zc=te(16);be(66,1,{});_.K=jj;_.I=function(){return this.d};_.J=function(){return this.e};_.d=0;_.e=0;var Ec=te(66);be(37,66,{});var Bc=te(37);be(58,1,{});_.K=jj;_.I=kj;_.J=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Dc=te(58);be(59,58,{},ef);_.K=function(a){bf(this,a)};_.L=function(a){return cf(this,a)};var Cc=te(59);be(12,1,{},gf);_.I=function(){return this.a};_.J=function(){ff(this);return this.c};_.K=function(a){ff(this);Ye(this.d,a)};_.L=function(a){ff(this);if(Se(this.d)){a.M(Te(this.d));return true}return false};_.a=0;_.c=0;var Fc=te(12);be(25,1,{},hf);_.G=function(a){return a};var Gc=te(25);be(29,1,{},jf);var Hc=te(29);be(65,1,{});_.c=false;var Rc=te(65);be(9,65,{},uf);var Qc=te(9);be(42,1,{},xf);_.N=function(a){return hb(rc,Ti,1,a,5,1)};var Ic=te(42);be(68,37,{},zf);_.L=function(a){this.b=false;while(!this.b&&this.c.L(new Af(this,a)));return this.b};_.b=false;var Kc=te(68);be(71,1,{},Af);_.M=function(a){yf(this.a,this.b,a)};var Jc=te(71);be(67,37,{},Cf);_.L=function(a){return this.b.L(new Df(this,a))};var Mc=te(67);be(70,1,{},Df);_.M=function(a){Bf(this.a,this.b,a)};var Lc=te(70);be(69,1,{},Ff);_.M=function(a){Ef(this,a)};var Nc=te(69);be(72,1,{},Gf);_.M=function(a){};var Oc=te(72);be(73,1,{},Hf);_.M=function(a){wf(this.a,a)};var Pc=te(73);be(185,1,{});be(182,1,{});var Lf=0;var Nf,Of=0,Pf;be(797,1,{});be(818,1,{});be(78,1,{},cg);_.N=function(a){return new Array(a)};var Sc=te(78);be(151,$wnd.Function,{},dg);_.P=function(a){bg(this.a,this.b,a)};be(5,18,{3:1,23:1,18:1,5:1},Og);var rg,sg,tg,ug,vg,wg,xg,yg,zg,Ag,Bg,Cg,Dg,Eg,Fg,Gg,Hg,Ig,Jg,Kg,Lg,Mg;var Tc=ue(5,Pg);be(127,1,{});var bd=te(127);be(99,127,{});var fd=te(99);be(100,99,{},Sg);var Rg=0;var Vc=te(100);be(128,1,{});var ad=te(128);be(129,128,{});var ed=te(129);be(105,129,{},Ug);var Tg=0;var Uc=te(105);be(96,1,{});_.b='';var od=te(96);be(97,96,{});var hd=te(97);be(98,97,{},$g);var Zg=0;var Wc=te(98);be(126,1,{});_.d=false;var rd=te(126);be(102,126,{});var kd=te(102);be(103,102,{},lh);var kh=0;var Xc=te(103);be(125,1,{});var wd=te(125);be(75,125,{});var md=te(75);be(76,75,{},oh);var nh=0;var Yc=te(76);be(93,1,dj,ph);_.p=mj;var Zc=te(93);be(156,$wnd.Function,{},qh);_.T=function(a){ri((fi(),di))};be(85,1,{},rh);var $c=te(85);be(101,1,{},sh);var _c=te(101);be(155,$wnd.Function,{},th);_.U=function(a){return new wh(a)};var uh;be(92,$wnd.React.Component,{},wh);ae($d[1],_);_.componentDidMount=function(){Qg(this.a)};_.render=function(){var a,b,c;return a=(c=(fi(),b=(je(),$wnd.goog.global.window).location.hash,null==b?'':b.substr(1)),He(ej,c)?(ji(),gi):He(fj,c)?(ji(),ii):(ji(),hi)),ag('footer',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['footer'])),[(new sh).a,ag('ul',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['filters'])),[ag('li',null,[ag('a',gg(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[(ji(),hi)==a?gj:null])),'#'),['All'])]),ag('li',null,[ag('a',gg(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[gi==a?gj:null])),'#active'),['Active'])]),ag('li',null,[ag('a',gg(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[ii==a?gj:null])),'#completed'),['Completed'])])]),si(di)>0?ag(bj,hg(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['clear-completed'])),de(qh.prototype.T,qh,[])),['Clear Completed']):null])};_.shouldComponentUpdate=lj;var cd=te(92);be(166,$wnd.Function,{},xh);_.U=function(a){return new Ah(a)};var yh;be(104,$wnd.React.Component,{},Ah);ae($d[1],_);_.render=function(){var a;return a=Td(of(new uf(null,new gf((fi(),di).a)))),ag('span',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['todo-count'])),[ag('strong',null,[a]),' item'+(a==1?'':'s')+' left'])};_.shouldComponentUpdate=lj;var dd=te(104);be(154,$wnd.Function,{},Bh);_.U=function(a){return new Eh(a)};var Ch;be(91,$wnd.React.Component,{},Eh);ae($d[1],_);_.render=function(){return Yg(this.a)};_.shouldComponentUpdate=lj;var gd=te(91);be(157,$wnd.Function,{},Fh);_.U=function(a){return new Ih(a)};var Gh;be(94,$wnd.React.Component,{},Ih);ae($d[1],_);_.componentDidUpdate=function(a){hh(this.a)};_.render=function(){return ih(this.a)};_.shouldComponentUpdate=lj;var jd=te(94);be(149,$wnd.Function,{},Jh);_.U=function(a){return new Mh(a)};var Kh;be(60,$wnd.React.Component,{},Mh);ae($d[1],_);_.componentDidMount=function(){mh(this.a)};_.render=function(){return ag('div',null,[ag('div',null,[ag(hj,eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[hj])),[ag('h1',null,['todos']),(new Ph).a]),0!=Td(of(new uf(null,new gf((fi(),di).a))))?ag('section',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[hj])),[ag(cj,lg(og(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['toggle-all'])),(Ng(),sg)),de(ai.prototype.R,ai,[])),null),ag('ul',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['todo-list'])),tf(rf(new uf(null,new gf(Gi(ei))),new bi),new cg))]):null,0!=Td(of(new uf(null,new gf(di.a))))?(new rh).a:null])])};_.shouldComponentUpdate=lj;var ld=te(60);be(152,$wnd.Function,{},Nh);_.S=function(a){Wg(this.a,a)};be(153,$wnd.Function,{},Oh);_.R=function(a){Vg(this.a,a)};be(79,1,{},Ph);var nd=te(79);be(95,1,dj,Qh);_.p=mj;var pd=te(95);be(164,$wnd.Function,{},Rh);_.R=function(a){_g(this.a,a)};be(165,$wnd.Function,{},Sh);_.S=function(a){ah(this.a,a)};be(158,$wnd.Function,{},Th);_.R=function(a){bh(this.a)};be(160,$wnd.Function,{},Uh);_.T=function(a){dh(this.a)};be(161,$wnd.Function,{},Vh);_.T=function(a){eh(this.a)};be(162,$wnd.Function,{},Wh);_.M=function(a){fh(this.a,a)};be(163,$wnd.Function,{},Xh);_.Q=function(a){gh(this.a)};be(90,1,{},Zh);var qd=te(90);be(61,1,dj,$h);_.p=mj;var sd=te(61);be(62,1,dj,_h);_.p=mj;var td=te(62);be(150,$wnd.Function,{},ai);_.R=function(a){var b;b=a.target;yi((fi(),di),b.checked)};be(63,1,{},bi);_.G=function(a){return Yh(new Zh,a)};var ud=te(63);be(40,1,{},ci);var vd=te(40);var di,ei;be(20,18,{3:1,23:1,18:1,20:1},ki);var gi,hi,ii;var xd=ue(20,li);be(38,1,{38:1},oi);_.a=false;var Fd=te(38);be(28,1,{},pi);_.M=nj;var yd=te(28);be(80,1,{},zi);var Ed=te(80);be(83,1,{},Bi);_.O=function(a){return a.a};var zd=te(83);be(84,1,{},Ci);_.M=function(a){ui(this.a,a)};var Ad=te(84);be(19,1,{},Di);_.M=nj;var Bd=te(19);be(81,1,{},Ei);_.O=function(a){return !a.a};var Cd=te(81);be(82,1,{},Fi);_.M=function(a){Ai(this.a,a)};_.a=false;var Dd=te(82);be(86,1,{},Li);var Kd=te(86);be(87,1,{},Ni);_.handleEvent=function(a){Hi(this.a,a)};var Gd=te(87);be(88,1,dj,Oi);_.p=function(){Ki(this.a)};var Hd=te(88);be(27,1,{},Pi);_.M=nj;var Id=te(27);be(89,1,{},Qi);_.O=function(a){return Mi(this.a,a)};var Jd=te(89);var Xb=ve('D');var Ri=(L(),O);var gwtOnLoad=gwtOnLoad=Yd;Wd(he);Zd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();