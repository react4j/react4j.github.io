function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='5089F15E79538BB5F108CFC7BFDA0F97',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '5089F15E79538BB5F108CFC7BFDA0F97';function n(){}
function S(){}
function Z(){}
function Hd(){}
function Dd(){}
function Se(){}
function Te(){}
function cg(){}
function dg(){}
function eg(){}
function hg(){}
function ig(){}
function mg(){}
function ng(){}
function ug(){}
function vg(){}
function Ig(){}
function Jg(){}
function Ng(){}
function Og(){}
function fh(){}
function Dh(){}
function Fh(){}
function Gh(){}
function Sh(){}
function X(a){W()}
function mi(a){a()}
function Nd(){Nd=Dd}
function Re(a,b){a.a=b}
function Ch(a,b){b.a=a}
function Qe(a){this.a=a}
function Ue(a){this.a=a}
function re(a){this.c=a}
function Sg(a){this.a=a}
function Tg(a){this.a=a}
function Vg(a){this.a=a}
function Wg(a){this.a=a}
function Xg(a){this.a=a}
function Yg(a){this.a=a}
function Zg(a){this.a=a}
function $g(a){this.a=a}
function _g(a){this.a=a}
function Eh(a){this.a=a}
function Hh(a){this.a=a}
function Qh(a){this.a=a}
function Rh(a){this.a=a}
function Th(a){this.a=a}
function md(a){return a.b}
function jf(a,b){return a[b]}
function fe(a,b){return a===b}
function Bg(a,b){return a.a=b}
function $(a,b){return Vd(a,b)}
function hf(a,b){gf(a,b)}
function yh(a,b){je(a.b,b)}
function Mh(a,b){je(a.a,b)}
function ie(a,b,c){Ve(a.a,b,c)}
function nf(a,b){a.key=b}
function We(a,b){a.splice(b,1)}
function lg(a){bg.call(this,a)}
function qg(a){bg.call(this,a)}
function yg(a){bg.call(this,a)}
function Mg(a){bg.call(this,a)}
function Rg(a){bg.call(this,a)}
function ki(){return $e(this)}
function de(){q(this);this.q()}
function Fe(a,b){Ae(a);a.a.G(b)}
function Ke(a,b){Re(a,Je(a.a,b))}
function we(a,b){while(a.H(b));}
function Je(a,b){a.C(b);return a}
function rf(a,b){a.ref=b;return a}
function Qd(a){Pd(a);return a.k}
function v(){v=Dd;u=new n}
function P(){P=Dd;O=new S}
function F(){F=Dd;!!(W(),V)}
function N(){B!=0&&(B=0);D=-1}
function wd(){ud==null&&(ud=[])}
function _f(a,b){$d.call(this,a,b)}
function mf(a,b){this.a=a;this.b=b}
function $d(a,b){this.a=a;this.b=b}
function Ne(a,b){this.a=a;this.b=b}
function sf(a,b){a.href=b;return a}
function Ve(a,b,c){a.splice(b,0,c)}
function oh(a,b){$d.call(this,a,b)}
function M(a){$wnd.clearTimeout(a)}
function eb(a){return new Array(a)}
function ah(a){return bh(new eh,a)}
function Ab(a){return a.l|a.m<<22}
function Qb(a){return a==null?null:a}
function Ob(a){return typeof a===Vh}
function ib(a){return jb(a.l,a.m,a.h)}
function fg(){this.a=of((kg(),jg))}
function gg(){this.a=of((pg(),og))}
function Ug(){this.a=of((xg(),wg))}
function eh(){this.a=of((Lg(),Kg))}
function gh(){this.a=of((Qg(),Pg))}
function oe(){this.a=bb(hc,di,1,0,5,1)}
function ze(a){this.b=a;this.a=16464}
function Oe(a,b){a.I(dh(ah(b.b),b))}
function Lh(a,b){a.b=b;ke(a.a,new Sh)}
function Cf(a,b){a.value=b;return a}
function xf(a,b){a.onBlur=b;return a}
function tf(a,b){a.onClick=b;return a}
function yf(a,b){a.onChange=b;return a}
function vf(a,b){a.checked=b;return a}
function zf(a,b){a.onKeyDown=b;return a}
function bh(a,b){nf(a.a,ve(b));return a}
function vh(a,b){return le(a.a,b,0)!=-1}
function jb(a,b,c){return {l:a,m:b,h:c}}
function ee(a,b){return a.charCodeAt(b)}
function Mb(a,b){return a!=null&&Kb(a,b)}
function pe(a){return a.a<a.c.a.length}
function $e(a){return a.$H||(a.$H=++Ze)}
function Pb(a){return typeof a==='string'}
function uf(a){a.autoFocus=true;return a}
function Pd(a){if(a.k!=null){return}Xd(a)}
function r(a,b){a.b=b;b!=null&&Ye(b,Xh,a)}
function Hg(a,b){a.b=b;a.d.forceUpdate()}
function tg(a,b){a.a=b;a.d.forceUpdate()}
function wh(a,b){me(a.a,b);ke(a.b,new Fh)}
function Bh(){this.a=new oe;this.b=new oe}
function cf(){cf=Dd;_e=new n;bf=new n}
function W(){W=Dd;var a;!Y();a=new Z;V=a}
function zh(a,b){Re(b,!b.a);ke(a.b,new Fh)}
function Ie(a,b){Ce.call(this,a);this.a=b}
function t(a){this.c=a;q(this);this.q()}
function Md(){t.call(this,'divide by zero')}
function Nb(a){return typeof a==='boolean'}
function G(a,b,c){return a.apply(b,c);var d}
function gf(a,b){for(var c in a){b(c)}}
function Ye(b,c,d){try{b[c]=d}catch(a){}}
function xh(a,b,c){b.c=ve(c);ke(a.b,new Fh)}
function Td(a){var b;b=Sd(a);Zd(a,b);return b}
function q(a){a.d&&a.b!==Wh&&a.q();return a}
function wf(a,b){a.defaultValue=b;return a}
function Df(a,b){a.onDoubleClick=b;return a}
function dh(a,b){a.a.props['a']=b;return a.a}
function je(a,b){a.a[a.a.length]=b;return true}
function qe(a){a.b=a.a++;return a.c.a[a.b]}
function sd(a){if(Ob(a)){return a|0}return Ab(a)}
function td(a){if(Ob(a)){return ''+a}return Bb(a)}
function Ge(a){Be(a);return new Ie(a,new Pe(a.a))}
function jh(){jh=Dd;hh=new Bh;ih=new Oh(hh)}
function Kd(){Kd=Dd;Jd=$wnd.window.document}
function Fg(a){zh((jh(),hh),a.d.props['a'])}
function Cg(a){wh((jh(),hh),jf(a.d.props,'a'))}
function Le(a,b,c){if(a.a.J(c)){a.b=true;b.I(c)}}
function Ae(a){if(!a.b){Be(a);a.c=true}else{Ae(a.b)}}
function Ee(a,b){Be(a);return new Ie(a,new Me(b,a.a))}
function rg(a,b){var c;c=b.target;tg(a,c.value)}
function T(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Bf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ve(a){if(a==null){throw md(new de)}return a}
function ff(){if(af==256){_e=bf;bf=new n;af=0}++af}
function Ce(a){if(!a){this.b=null;new oe}else{this.b=a}}
function Pe(a){xe.call(this,a.F(),a.D()&-6);this.a=a}
function rh(a,b){this.b=ve(a);this.c=ve(b);this.a=false}
function xe(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Ph(a,b){return (nh(),lh)==a||(kh==a?!b.a:b.a)}
function ue(a,b){return Qb(a)===Qb(b)||!!a&&Qb(a)===Qb(b)}
function db(a){return Array.isArray(a)&&a.W===Hd}
function Lb(a){return !Array.isArray(a)&&a.W===Hd}
function ph(){nh();return fb($(Zc,1),di,21,0,[kh,mh,lh])}
function Wd(a){if(a.A()){return null}var b=a.j;return zd[b]}
function ye(a){if(!a.d){a.d=new re(a.b);a.c=a.b.a.length}}
function Ud(a,b){var c;c=Sd(a);Zd(a,c);c.e=b?8:0;return c}
function Fd(a){function b(){}
;b.prototype=a||{};return new b}
function Af(a){a.placeholder='What needs to be done?';return a}
function L(a){F();$wnd.setTimeout(function(){throw a},0)}
function Be(a){if(a.b){Be(a.b)}else if(a.c){throw md(new _d)}}
function K(a){a&&R((P(),O));--B;if(a){if(D!=-1){M(D);D=-1}}}
function kg(){kg=Dd;var a;jg=(a=Ed(ig.prototype.S,ig,[]),a)}
function pg(){pg=Dd;var a;og=(a=Ed(ng.prototype.S,ng,[]),a)}
function xg(){xg=Dd;var a;wg=(a=Ed(vg.prototype.S,vg,[]),a)}
function Lg(){Lg=Dd;var a;Kg=(a=Ed(Jg.prototype.S,Jg,[]),a)}
function Qg(){Qg=Dd;var a;Pg=(a=Ed(Og.prototype.S,Og,[]),a)}
function Vd(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.s(b))}
function Bd(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function J(a,b,c){var d;d=H();try{return G(a,b,c)}finally{K(d)}}
function Ld(a,b,c,d){a.addEventListener(b,c,(Nd(),d?true:false))}
function lf(a,b,c){!fe(c,'key')&&!fe(c,'ref')&&(a[c]=b[c],undefined)}
function Nh(a){var b;b=a.b;!!b&&!vh(a.c,b)&&(a.b=null,ke(a.a,new Sh))}
function Ah(a,b){Fe(new Ie(null,new ze(a.a)),new Hh(b));ke(a.b,new Fh)}
function He(a,b){var c;Ae(a);c=new Se;c.a=b;a.a.G(new Ue(c));return c.a}
function De(a){var b;Ae(a);b=0;while(a.a.H(new Te)){b=nd(b,1)}return b}
function s(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function he(){t.call(this,'Add not supported on this collection')}
function Me(a,b){xe.call(this,b.F(),b.D()&-16449);this.a=a;this.c=b}
function te(a,b){while(a.a<a.c.a.length){b.I((a.b=a.a++,a.c.a[a.b]))}}
function sh(a,b){je(a.a,new rh(''+td(pd(Date.now())),b));ke(a.b,new Fh)}
function A(){if(Date.now){return Date.now()}return (new Date).getTime()}
function I(b){F();return function(){return J(b,this,arguments);var a}}
function Rb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function hb(a){var b,c,d;b=a&Zh;c=a>>22&Zh;d=a<0?$h:0;return jb(b,c,d)}
function ke(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.I(c)}}
function me(a,b){var c;c=le(a,b,0);if(c==-1){return false}We(a.a,c);return true}
function bb(a,b,c,d,e,f){var g;g=cb(e,d);e!=10&&fb($(a,f),b,c,e,g);return g}
function le(a,b,c){for(;c<a.a.length;++c){if(ue(b,a.a[c])){return c}}return -1}
function Zd(a,b){var c;if(!a){return}b.j=a;var d=Wd(b);if(!d){zd[a]=[b];return}d.U=b}
function ld(a){var b;if(Mb(a,5)){return a}b=a&&a[Xh];if(!b){b=new w(a);X(b)}return b}
function Sd(a){var b;b=new Rd;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function zg(a,b){var c;if((jh(),ih).b==a.d.props['a']){c=b.target;Hg(a,c.value)}}
function Q(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=U(b,c)}while(a.a);a.a=c}}
function R(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=U(b,c)}while(a.b);a.b=c}}
function be(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function Ed(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function vd(){wd();var a=ud;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function _d(){t.call(this,"Stream already terminated, can't be modified or used")}
function ab(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Xe(a,b){return ab(b)!=10&&fb(o(b),b.V,b.__elementTypeId$,ab(b),a),a}
function li(){$wnd.ReactDOM.render((new gh).a,(Kd(),Jd).getElementById('app'),null)}
function bg(a){$wnd.React.Component.call(this,a);this.a=this.T();this.a.d=ve(this);this.a.L()}
function w(a){v();q(this);this.b=a;a!=null&&Ye(a,Xh,this);this.c=a==null?'null':Gd(a);this.a=a}
function of(a){var b;b=pf($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function od(a){var b;b=a.h;if(b==0){return a.l+a.m*bi}if(b==$h){return a.l+a.m*bi-ai}return a}
function pd(a){if(ci<a&&a<ai){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return od(vb(a))}
function rd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=ai;d=$h}c=Rb(e/bi);b=Rb(e-c*bi);return jb(b,c,d)}
function tb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return jb(c&Zh,d&Zh,e&$h)}
function zb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return jb(c&Zh,d&Zh,e&$h)}
function wb(a){var b,c,d;b=~a.l+1&Zh;c=~a.m+(b==0?1:0)&Zh;d=~a.h+(b==0&&c==0?1:0)&$h;return jb(b,c,d)}
function pb(a){var b,c,d;b=~a.l+1&Zh;c=~a.m+(b==0?1:0)&Zh;d=~a.h+(b==0&&c==0?1:0)&$h;a.l=b;a.m=c;a.h=d}
function Gb(){Gb=Dd;Cb=jb(Zh,Zh,524287);Db=jb(0,0,_h);Eb=hb(1);hb(2);Fb=hb(0)}
function nh(){nh=Dd;kh=new oh('ACTIVE',0);mh=new oh('COMPLETED',1);lh=new oh('ALL',2)}
function th(a){var b;He(Ee(new Ie(null,new ze(a.a)),new Dh),(b=new oe,b)).B(new Eh(a))}
function uh(a){return sd(De(new Ie(null,new ze(a.a))))-sd(De(Ee(new Ie(null,new ze(a.a)),new Gh)))}
function ce(a,b){var c,d;for(d=new re(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);wh(b.a,c)}}
function Dg(a){Lh((jh(),ih),jf(a.d.props,'a'));a.b=jf(a.d.props,'a').c;a.d.forceUpdate()}
function Ag(a,b){27==b.which?(Lh((jh(),ih),null),a.b=jf(a.d.props,'a').c,a.d.forceUpdate()):13==b.which&&Eg(a)}
function qb(a){var b,c;c=ae(a.h);if(c==32){b=ae(a.m);return b==32?ae(a.l)+32:b+20-10}else{return c-12}}
function mb(a,b,c,d,e){var f;f=yb(a,b);c&&pb(f);if(e){a=ob(a,b);d?(gb=wb(a)):(gb=jb(a.l,a.m,a.h))}return f}
function fb(a,b,c,d,e){e.U=a;e.V=b;e.W=Hd;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function yd(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function nd(a,b){var c;if(Ob(a)&&Ob(b)){c=a+b;if(ci<c&&c<ai){return c}}return od(tb(Ob(a)?rd(a):a,Ob(b)?rd(b):b))}
function o(a){return Pb(a)?jc:Ob(a)?ac:Nb(a)?$b:Lb(a)?a.U:db(a)?a.U:a.U||Array.isArray(a)&&$(Tb,1)||Tb}
function p(a){return Pb(a)?ef(a):Ob(a)?Rb(a):Nb(a)?a?1231:1237:Lb(a)?a.o():db(a)?$e(a):!!a&&!!a.hashCode?a.hashCode():$e(a)}
function Gd(a){var b;if(Array.isArray(a)&&a.W===Hd){return Qd(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function lb(a,b){if(a.h==_h&&a.m==0&&a.l==0){b&&(gb=jb(0,0,0));return ib((Gb(),Eb))}b&&(gb=jb(a.l,a.m,a.h));return jb(0,0,0)}
function ef(a){cf();var b,c,d;c=':'+a;d=bf[c];if(d!=null){return Rb(d)}d=_e[c];b=d==null?df(a):Rb(d);ff();bf[c]=b;return b}
function se(a){var b,c,d;d=1;for(c=new re(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function ne(a,b){var c,d;d=a.a.length;b.length<d&&(b=Xe(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Yd(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function sg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=ge(a.a);if(c.length>0){sh((jh(),hh),c);a.a='';a.d.forceUpdate()}}}
function H(){var a;if(B!=0){a=A();if(a-C>2000){C=a;D=$wnd.setTimeout(N,10)}}if(B++==0){Q((P(),O));return true}return false}
function Y(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Rd(){this.g=Od++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Oh(a){this.a=new oe;this.c=ve(a);Ld((Kd(),$wnd.window.window),'hashchange',new Qh(this),false);yh(a,Ed(Rh.prototype.N,Rh,[this]))}
function ag(){$f();return fb($(Dc,1),di,6,0,[Ef,Ff,Gf,Hf,If,Jf,Kf,Lf,Mf,Nf,Of,Pf,Qf,Rf,Sf,Tf,Uf,Vf,Wf,Xf,Yf,Zf])}
function Eg(a){if(null!=a.b&&a.b.length!=0){xh((jh(),hh),a.d.props['a'],a.b);Lh(ih,null);Hg(a,a.b)}else{wh((jh(),hh),a.d.props['a'])}}
function qf(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Kb(a,b){if(Pb(a)){return !!Jb[b]}else if(a.V){return !!a.V[b]}else if(Ob(a)){return !!Ib[b]}else if(Nb(a)){return !!Hb[b]}return false}
function ge(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ob(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return jb(c,d,e)}
function cb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function sb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&Zh;a.m=d&Zh;a.h=e&$h;return true}
function Id(){yh((jh(),hh),Ed(cg.prototype.N,cg,[]));Mh(ih,Ed(dg.prototype.N,dg,[]));$wnd.ReactDOM.render((new gh).a,(Kd(),Jd).getElementById('app'),null)}
function Gg(a){var b;b=(jh(),ih).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();a.b=a.d.props['a'].c;a.d.forceUpdate()}else a.c&&!b&&(a.c=false)}
function Jh(a,b){var c,d;b.preventDefault();c=(d=(Kd(),$wnd.window.window).location.hash,null==d?'':d.substr(1));fe(fi,c)||fe(gi,c)||fe('',c)?ke(a.a,new Sh):Kh()}
function ub(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function xd(b,c,d,e){wd();var f=ud;$moduleName=c;$moduleBase=d;kd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Uh(g)()}catch(a){b(c,a)}}else{Uh(g)()}}
function pf(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=ve(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function U(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].X()&&(c=T(c,g)):g[0].X()}catch(a){a=ld(a);if(Mb(a,5)){d=a;F();L(Mb(d,24)?d.r():d)}else throw md(a)}}return c}
function Ad(){zd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function xb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return jb(c&Zh,d&Zh,e&$h)}
function yb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&_h)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?$h:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?$h:0;f=d?Zh:0;e=c>>b-44}return jb(e&Zh,f&Zh,g&$h)}
function df(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ee(a,c++)}b=b|0;return b}
function Kh(){var a;if(0==''.length){a=(Kd(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Jd.title,a)}else{(Kd(),$wnd.window.window).location.hash=''}}
function ae(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Cd(a,b,c){var d=zd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=zd[b]),Fd(h));_.V=c;!b&&(_.W=Hd);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.U=f)}
function Xd(a){if(a.w()){var b=a.c;b.A()?(a.k='['+b.j):!b.w()?(a.k='[L'+b.u()+';'):(a.k='['+b.u());a.b=b.t()+'[]';a.i=b.v()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Yd('.',[c,Yd('$',d)]);a.b=Yd('.',[c,Yd('.',d)]);a.i=d[d.length-1]}
function Ih(a){var b,c,d,e;b=(e=(c=(Kd(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),fe(fi,e)||fe(gi,e)||fe('',e)?fe(fi,e)?(nh(),kh):fe(gi,e)?(nh(),mh):(nh(),lh):(nh(),lh));return He(Ee(new Ie(null,new ze(a.c.a)),new Th(b)),(d=new oe,d))}
function rb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return be(c)}if(b==0&&d!=0&&c==0){return be(d)+22}if(b!=0&&d==0&&c==0){return be(b)+44}return -1}
function vb(a){var b,c,d,e,f;if(isNaN(a)){return Gb(),Fb}if(a<-9223372036854775808){return Gb(),Db}if(a>=9223372036854775807){return Gb(),Cb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=ai){d=Rb(a/ai);a-=d*ai}c=0;if(a>=bi){c=Rb(a/bi);a-=c*bi}b=Rb(a);f=jb(b,c,d);e&&pb(f);return f}
function kf(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;hf(b,Ed(mf.prototype.K,mf,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=pf($wnd.React.Element,a),g.key=e,g.ref=f,g.props=ve(d),g}
function Bb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==_h&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Bb(wb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=hb(1000000000);c=kb(c,e,true);b=''+Ab(gb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function nb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=qb(b)-qb(a);g=xb(b,j);i=jb(0,0,0);while(j>=0){h=sb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&pb(i);if(f){if(d){gb=wb(a);e&&(gb=zb(gb,(Gb(),Eb)))}else{gb=jb(a.l,a.m,a.h)}}return i}
function $f(){$f=Dd;Ef=new _f(ei,0);Ff=new _f('checkbox',1);Gf=new _f('color',2);Hf=new _f('date',3);If=new _f('datetime',4);Jf=new _f('email',5);Kf=new _f('file',6);Lf=new _f('hidden',7);Mf=new _f('image',8);Nf=new _f('month',9);Of=new _f(Vh,10);Pf=new _f('password',11);Qf=new _f('radio',12);Rf=new _f('range',13);Sf=new _f('reset',14);Tf=new _f('search',15);Uf=new _f('submit',16);Vf=new _f('tel',17);Wf=new _f('text',18);Xf=new _f('time',19);Yf=new _f('url',20);Zf=new _f('week',21)}
function kb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw md(new Md)}if(a.l==0&&a.m==0&&a.h==0){c&&(gb=jb(0,0,0));return jb(0,0,0)}if(b.h==_h&&b.m==0&&b.l==0){return lb(a,c)}i=false;if(b.h>>19!=0){b=wb(b);i=true}g=rb(b);f=false;e=false;d=false;if(a.h==_h&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ib((Gb(),Cb));d=true;i=!i}else{h=yb(a,g);i&&pb(h);c&&(gb=jb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=wb(a);d=true;i=!i}if(g!=-1){return mb(a,g,i,f,c)}if(ub(a,b)<0){c&&(f?(gb=wb(a)):(gb=jb(a.l,a.m,a.h)));return jb(0,0,0)}return nb(d?a:jb(a.l,a.m,a.h),b,i,f,e,c)}
var Vh='number',Wh='__noinit__',Xh='__java$exception',Yh={3:1,7:1,5:1},Zh=4194303,$h=1048575,_h=524288,ai=17592186044416,bi=4194304,ci=-17592186044416,di={3:1,4:1},ei='button',fi='active',gi='completed',hi='selected',ii='input',ji='header';var _,zd,ud,kd=-1;Ad();Cd(1,null,{},n);_.n=function(){return this.U};_.o=ki;_.hashCode=function(){return this.o()};var Hb,Ib,Jb;Cd(29,1,{},Rd);_.s=function(a){var b;b=new Rd;b.e=4;a>1?(b.c=Vd(this,a-1)):(b.c=this);return b};_.t=function(){Pd(this);return this.b};_.u=function(){return Qd(this)};_.v=function(){Pd(this);return this.i};_.w=function(){return (this.e&4)!=0};_.A=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Od=1;var hc=Td(1);var _b=Td(29);Cd(5,1,{3:1,5:1});_.p=function(a){return new Error(a)};_.q=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=Qd(this.U),c==null?a:a+': '+c);r(this,s(this.p(b)));X(this)};_.b=Wh;_.d=true;var kc=Td(5);Cd(26,5,{3:1,5:1});var cc=Td(26);Cd(7,26,Yh);var ic=Td(7);Cd(30,7,Yh);var ec=Td(30);Cd(42,30,Yh);var Vb=Td(42);Cd(24,42,{24:1,3:1,7:1,5:1},w);_.r=function(){return Qb(this.a)===Qb(u)?null:this.a};var u;var Sb=Td(24);var Tb=Td(0);Cd(85,1,{});var Ub=Td(85);var B=0,C=0,D=-1;Cd(57,85,{},S);var O;var Wb=Td(57);var V;Cd(98,1,{});var Yb=Td(98);Cd(43,98,{},Z);var Xb=Td(43);var gb;var Cb,Db,Eb,Fb;var Jd;Cd(55,7,Yh,Md);var Zb=Td(55);Hb={3:1,23:1};var $b=Td(95);Cd(96,1,{3:1});var gc=Td(96);Ib={3:1,23:1};var ac=Td(97);Cd(20,1,{3:1,23:1,20:1});_.o=ki;_.b=0;var bc=Td(20);Cd(45,7,Yh,_d);var dc=Td(45);Cd(158,1,{});Cd(54,30,Yh,de);_.p=function(a){return new TypeError(a)};var fc=Td(54);Jb={3:1,38:1,23:1,2:1};var jc=Td(2);Cd(162,1,{});Cd(53,7,Yh,he);var lc=Td(53);Cd(99,1,{82:1});_.B=function(a){ce(this,a)};_.C=function(a){throw md(new he)};var mc=Td(99);Cd(100,99,{82:1,106:1});_.C=function(a){ie(this,this.a.length,a);return true};_.o=function(){return se(this)};var nc=Td(100);Cd(10,100,{3:1,10:1,82:1,106:1},oe);_.C=function(a){return je(this,a)};_.B=function(a){ke(this,a)};var pc=Td(10);Cd(15,1,{},re);_.a=0;_.b=-1;var oc=Td(15);Cd(61,1,{});_.G=function(a){we(this,a)};_.D=function(){return this.d};_.F=function(){return this.e};_.d=0;_.e=0;var rc=Td(61);Cd(33,61,{});var qc=Td(33);Cd(11,1,{},ze);_.D=function(){return this.a};_.F=function(){ye(this);return this.c};_.G=function(a){ye(this);te(this.d,a)};_.H=function(a){ye(this);if(pe(this.d)){a.I(qe(this.d));return true}return false};_.a=0;_.c=0;var sc=Td(11);Cd(60,1,{});_.c=false;var Bc=Td(60);Cd(9,60,{},Ie);var Ac=Td(9);Cd(63,33,{},Me);_.H=function(a){this.b=false;while(!this.b&&this.c.H(new Ne(this,a)));return this.b};_.b=false;var uc=Td(63);Cd(66,1,{},Ne);_.I=function(a){Le(this.a,this.b,a)};var tc=Td(66);Cd(62,33,{},Pe);_.H=function(a){return this.a.H(new Qe(a))};var wc=Td(62);Cd(65,1,{},Qe);_.I=function(a){Oe(this.a,a)};var vc=Td(65);Cd(64,1,{},Se);_.I=function(a){Re(this,a)};var xc=Td(64);Cd(67,1,{},Te);_.I=function(a){};var yc=Td(67);Cd(68,1,{},Ue);_.I=function(a){Ke(this.a,a)};var zc=Td(68);Cd(160,1,{});Cd(157,1,{});var Ze=0;var _e,af=0,bf;Cd(537,1,{});Cd(599,1,{});Cd(101,1,{});_.L=function(){};var Cc=Td(101);Cd(129,$wnd.Function,{},mf);_.K=function(a){lf(this.a,this.b,a)};Cd(6,20,{3:1,23:1,20:1,6:1},_f);var Ef,Ff,Gf,Hf,If,Jf,Kf,Lf,Mf,Nf,Of,Pf,Qf,Rf,Sf,Tf,Uf,Vf,Wf,Xf,Yf,Zf;var Dc=Ud(6,ag);Cd(19,$wnd.React.Component,{});Bd(zd[1],_);_.render=function(){return this.a.M()};var Ec=Td(19);Cd(109,$wnd.Function,{37:1},cg);_.N=li;Cd(110,$wnd.Function,{37:1},dg);_.N=li;Cd(103,101,{});_.M=function(){var a,b,c;a=(jh(),c=(b=(Kd(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),fe(fi,c)||fe(gi,c)||fe('',c)?fe(fi,c)?(nh(),kh):fe(gi,c)?(nh(),mh):(nh(),lh):(nh(),lh));return kf('footer',qf(new $wnd.Object,fb($(jc,1),di,2,6,['footer'])),[(new gg).a,kf('ul',qf(new $wnd.Object,fb($(jc,1),di,2,6,['filters'])),[kf('li',null,[kf('a',sf(qf(new $wnd.Object,fb($(jc,1),di,2,6,[(nh(),lh)==a?hi:null])),'#'),['All'])]),kf('li',null,[kf('a',sf(qf(new $wnd.Object,fb($(jc,1),di,2,6,[kh==a?hi:null])),'#active'),['Active'])]),kf('li',null,[kf('a',sf(qf(new $wnd.Object,fb($(jc,1),di,2,6,[mh==a?hi:null])),'#completed'),['Completed'])])]),uh(hh)>0?kf(ei,tf(qf(new $wnd.Object,fb($(jc,1),di,2,6,['clear-completed'])),Ed(eg.prototype.R,eg,[])),['Clear Completed']):null])};var Ic=Td(103);Cd(134,$wnd.Function,{},eg);_.R=function(a){th((jh(),hh))};Cd(71,1,{},fg);var Fc=Td(71);Cd(105,101,{});_.M=function(){var a,b;b=sd(De(new Ie(null,new ze((jh(),hh).a))));a='item'+(b==1?'':'s');return kf('span',qf(new $wnd.Object,fb($(jc,1),di,2,6,['todo-count'])),[kf('strong',null,[b]),' '+a+' left'])};var Hc=Td(105);Cd(79,1,{},gg);var Gc=Td(79);Cd(75,103,{},hg);var Mc=Td(75);Cd(133,$wnd.Function,{},ig);_.S=function(a){return new lg(a)};var jg;Cd(76,19,{},lg);_.T=function(){return new hg};var Jc=Td(76);Cd(80,105,{},mg);var Lc=Td(80);Cd(144,$wnd.Function,{},ng);_.S=function(a){return new qg(a)};var og;Cd(81,19,{},qg);_.T=function(){return new mg};var Kc=Td(81);Cd(72,101,{});_.M=function(){return kf(ii,uf(yf(zf(Cf(Af(qf(new $wnd.Object,fb($(jc,1),di,2,6,['new-todo']))),this.a),Ed(Sg.prototype.Q,Sg,[this])),Ed(Tg.prototype.P,Tg,[this]))),null)};_.a='';var Uc=Td(72);Cd(73,72,{},ug);var Oc=Td(73);Cd(130,$wnd.Function,{},vg);_.S=function(a){return new yg(a)};var wg;Cd(74,19,{},yg);_.T=function(){return new ug};var Nc=Td(74);Cd(104,101,{});_.L=function(){this.b=jf(this.d.props,'a').c};_.M=function(){var a,b;b=this.d.props['a'];a=b.a;return kf('li',qf(new $wnd.Object,fb($(jc,1),di,2,6,[a?gi:null,(jh(),ih).b==this.d.props['a']?'editing':null])),[kf('div',qf(new $wnd.Object,fb($(jc,1),di,2,6,['view'])),[kf(ii,yf(vf(Bf(qf(new $wnd.Object,fb($(jc,1),di,2,6,['toggle'])),($f(),Ff)),a),Ed(Xg.prototype.P,Xg,[this])),null),kf('label',Df(new $wnd.Object,Ed(Yg.prototype.R,Yg,[this])),[b.c]),kf(ei,tf(qf(new $wnd.Object,fb($(jc,1),di,2,6,['destroy'])),Ed(Zg.prototype.R,Zg,[this])),null)]),kf(ii,zf(yf(xf(wf(qf(rf(new $wnd.Object,Ed($g.prototype.I,$g,[this])),fb($(jc,1),di,2,6,['edit'])),this.b),Ed(_g.prototype.O,_g,[this])),Ed(Vg.prototype.P,Vg,[this])),Ed(Wg.prototype.Q,Wg,[this])),null)])};_.c=false;var Wc=Td(104);Cd(34,104,{34:1},Ig);var Qc=Td(34);Cd(135,$wnd.Function,{},Jg);_.S=function(a){return new Mg(a)};var Kg;Cd(78,19,{},Mg);_.T=function(){return new Ig};_.componentDidUpdate=function(a){Gg(this.a)};var Pc=Td(78);Cd(102,101,{});_.M=function(){var a,b;return kf('div',null,[kf('div',null,[kf(ji,qf(new $wnd.Object,fb($(jc,1),di,2,6,[ji])),[kf('h1',null,['todos']),(new Ug).a]),0!=sd(De(new Ie(null,new ze((jh(),hh).a))))?kf('section',qf(new $wnd.Object,fb($(jc,1),di,2,6,[ji])),[kf(ii,yf(Bf(qf(new $wnd.Object,fb($(jc,1),di,2,6,['toggle-all'])),($f(),Ff)),Ed(fh.prototype.P,fh,[])),null),kf('ul',qf(new $wnd.Object,fb($(jc,1),di,2,6,['todo-list'])),(a=He(Ge(new Ie(null,new ze(Ih(ih)))),(b=new oe,b)),ne(a,eb(a.a.length))))]):null,0!=sd(De(new Ie(null,new ze(hh.a))))?(new fg).a:null])])};var Yc=Td(102);Cd(58,102,{},Ng);var Sc=Td(58);Cd(127,$wnd.Function,{},Og);_.S=function(a){return new Rg(a)};var Pg;Cd(59,19,{},Rg);_.T=function(){return new Ng};var Rc=Td(59);Cd(131,$wnd.Function,{},Sg);_.Q=function(a){sg(this.a,a)};Cd(132,$wnd.Function,{},Tg);_.P=function(a){rg(this.a,a)};Cd(70,1,{},Ug);var Tc=Td(70);Cd(142,$wnd.Function,{},Vg);_.P=function(a){zg(this.a,a)};Cd(143,$wnd.Function,{},Wg);_.Q=function(a){Ag(this.a,a)};Cd(136,$wnd.Function,{},Xg);_.P=function(a){Fg(this.a)};Cd(138,$wnd.Function,{},Yg);_.R=function(a){Dg(this.a)};Cd(139,$wnd.Function,{},Zg);_.R=function(a){Cg(this.a)};Cd(140,$wnd.Function,{},$g);_.I=function(a){Bg(this.a,a)};Cd(141,$wnd.Function,{},_g);_.O=function(a){Eg(this.a)};Cd(77,1,{},eh);var Vc=Td(77);Cd(128,$wnd.Function,{},fh);_.P=function(a){var b;b=a.target;Ah((jh(),hh),b.checked)};Cd(25,1,{},gh);var Xc=Td(25);var hh,ih;Cd(21,20,{3:1,23:1,20:1,21:1},oh);var kh,lh,mh;var Zc=Ud(21,ph);Cd(32,1,{32:1},rh);_.a=false;var ed=Td(32);Cd(31,1,{31:1},Bh);var dd=Td(31);Cd(48,1,{},Dh);_.J=function(a){return a.a};var $c=Td(48);Cd(49,1,{},Eh);_.I=function(a){wh(this.a,a)};var _c=Td(49);Cd(18,1,{},Fh);_.I=mi;var ad=Td(18);Cd(46,1,{},Gh);_.J=function(a){return !a.a};var bd=Td(46);Cd(47,1,{},Hh);_.I=function(a){Ch(this.a,a)};_.a=false;var cd=Td(47);Cd(50,1,{},Oh);var jd=Td(50);Cd(51,1,{},Qh);_.handleEvent=function(a){Jh(this.a,a)};var fd=Td(51);Cd(115,$wnd.Function,{37:1},Rh);_.N=function(){Nh(this.a)};Cd(27,1,{},Sh);_.I=mi;var gd=Td(27);Cd(52,1,{},Th);_.J=function(a){return Ph(this.a,a)};var hd=Td(52);var Uh=(F(),I);var gwtOnLoad=gwtOnLoad=xd;vd(Id);yd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();