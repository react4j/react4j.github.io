function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='32C5A0E0B78C3D040F628B894F155DAF',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '32C5A0E0B78C3D040F628B894F155DAF';function n(){}
function S(){}
function Z(){}
function Zf(){}
function Xf(){}
function Yf(){}
function Hd(){}
function Dd(){}
function Se(){}
function Te(){}
function fg(){}
function kg(){}
function sg(){}
function Fg(){}
function Kg(){}
function _g(){}
function zh(){}
function Bh(){}
function Ch(){}
function Oh(){}
function ii(){}
function ki(a){a()}
function X(a){W()}
function eg(){dg()}
function jg(){ig()}
function rg(){qg()}
function Eg(){Dg()}
function Jg(){Ig()}
function Nd(){Nd=Dd}
function Re(a,b){a.a=b}
function yh(a,b){b.a=a}
function Qe(a){this.a=a}
function Ue(a){this.a=a}
function re(a){this.c=a}
function Mg(a){this.a=a}
function Ng(a){this.a=a}
function Qg(a){this.a=a}
function Rg(a){this.a=a}
function Sg(a){this.a=a}
function Tg(a){this.a=a}
function Ug(a){this.a=a}
function Vg(a){this.a=a}
function Wg(a){this.a=a}
function Ah(a){this.a=a}
function Dh(a){this.a=a}
function Mh(a){this.a=a}
function Nh(a){this.a=a}
function Ph(a){this.a=a}
function Pg(){this.a={}}
function bg(){this.a={}}
function $g(){this.a={}}
function _f(){this.a={}}
function bh(){this.a={}}
function Ih(a,b){je(a.a,b)}
function uh(a,b){je(a.b,b)}
function hf(a,b,c){a[b]=c}
function gf(a,b){return a[b]}
function md(a){return a.b}
function wg(a,b){return a.a=b}
function fe(a,b){return a===b}
function $(a,b){return Vd(a,b)}
function hi(){return $e(this)}
function de(){q(this);this.q()}
function gg(a){jf.call(this,a)}
function lg(a){jf.call(this,a)}
function tg(a){jf.call(this,a)}
function Gg(a){jf.call(this,a)}
function Lg(a){jf.call(this,a)}
function F(){F=Dd;!!(W(),V)}
function v(){v=Dd;u=new n}
function P(){P=Dd;O=new S}
function N(){B!=0&&(B=0);D=-1}
function wd(){ud==null&&(ud=[])}
function Qd(a){Pd(a);return a.k}
function Je(a,b){a.C(b);return a}
function lf(a,b){a.ref=b;return a}
function We(a,b){a.splice(b,1)}
function Ve(a,b,c){a.splice(b,0,c)}
function ie(a,b,c){Ve(a.a,b,c)}
function Fe(a,b){Ae(a);a.a.G(b)}
function Ke(a,b){Re(a,Je(a.a,b))}
function we(a,b){while(a.H(b));}
function Ne(a,b){this.a=a;this.b=b}
function $d(a,b){this.a=a;this.b=b}
function Vf(a,b){$d.call(this,a,b)}
function kh(a,b){$d.call(this,a,b)}
function Oe(a,b){a.I(Zg(Xg(b.b),b))}
function mf(a,b){a.href=b;return a}
function wf(a,b){a.value=b;return a}
function rf(a,b){a.onBlur=b;return a}
function nf(a,b){a.onClick=b;return a}
function pf(a,b){a.checked=b;return a}
function Hh(a,b){a.b=b;ke(a.a,new Oh)}
function ib(a){return jb(a.l,a.m,a.h)}
function Ab(a){return a.l|a.m<<22}
function eb(a){return new Array(a)}
function Xg(a){return Yg(new $g,a)}
function Ob(a){return typeof a===Rh}
function Qb(a){return a==null?null:a}
function pe(a){return a.a<a.c.a.length}
function $e(a){return a.$H||(a.$H=++Ze)}
function ee(a,b){return a.charCodeAt(b)}
function Mb(a,b){return a!=null&&Kb(a,b)}
function jb(a,b,c){return {l:a,m:b,h:c}}
function rh(a,b){return le(a.a,b,0)!=-1}
function M(a){$wnd.clearTimeout(a)}
function ze(a){this.b=a;this.a=16464}
function t(a){this.c=a;q(this);this.q()}
function oe(){this.a=bb(hc,ai,1,0,5,1)}
function og(a,b){a.a=b;a.d.forceUpdate()}
function Bg(a,b){a.b=b;a.d.forceUpdate()}
function r(a,b){a.b=b;b!=null&&Ye(b,Th,a)}
function sf(a,b){a.onChange=b;return a}
function tf(a,b){a.onKeyDown=b;return a}
function of(a){a.autoFocus=true;return a}
function Pd(a){if(a.k!=null){return}Xd(a)}
function qe(a){a.b=a.a++;return a.c.a[a.b]}
function qf(a,b){a.defaultValue=b;return a}
function q(a){a.d&&a.b!==Sh&&a.q();return a}
function W(){W=Dd;var a;!Y();a=new Z;V=a}
function cf(){cf=Dd;_e=new n;bf=new n}
function xh(){this.a=new oe;this.b=new oe}
function sh(a,b){me(a.a,b);ke(a.b,new Bh)}
function vh(a,b){Re(b,!b.a);ke(a.b,new Bh)}
function Ie(a,b){Ce.call(this,a);this.a=b}
function Md(){t.call(this,'divide by zero')}
function Nb(a){return typeof a==='boolean'}
function Pb(a){return typeof a==='string'}
function G(a,b,c){return a.apply(b,c);var d}
function th(a,b,c){b.c=ve(c);ke(a.b,new Bh)}
function Td(a){var b;b=Sd(a);Zd(a,b);return b}
function Yg(a,b){ve(b);hf(a.a,'key',b);return a}
function xf(a,b){a.onDoubleClick=b;return a}
function je(a,b){a.a[a.a.length]=b;return true}
function Le(a,b,c){if(a.a.J(c)){a.b=true;b.I(c)}}
function Ye(b,c,d){try{b[c]=d}catch(a){}}
function Kd(){Kd=Dd;Jd=$wnd.window.document}
function fh(){fh=Dd;dh=new xh;eh=new Kh(dh)}
function Ge(a){Be(a);return new Ie(a,new Pe(a.a))}
function sd(a){if(Ob(a)){return a|0}return Ab(a)}
function td(a){if(Ob(a)){return ''+a}return Bb(a)}
function ve(a){if(a==null){throw md(new de)}return a}
function ff(){if(af==256){_e=bf;bf=new n;af=0}++af}
function Ae(a){if(!a.b){Be(a);a.c=true}else{Ae(a.b)}}
function Ag(a){vh((fh(),dh),a.d.props['a'])}
function xg(a){sh((fh(),dh),gf(a.d.props,'a'))}
function mg(a,b){var c;c=b.target;og(a,c.value)}
function T(a,b){!a&&(a=[]);a[a.length]=b;return a}
function vf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function xe(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function nh(a,b){this.b=ve(a);this.c=ve(b);this.a=false}
function Ce(a){if(!a){this.b=null;new oe}else{this.b=a}}
function Pe(a){xe.call(this,a.F(),a.D()&-6);this.a=a}
function db(a){return Array.isArray(a)&&a.W===Hd}
function Lb(a){return !Array.isArray(a)&&a.W===Hd}
function Lh(a,b){return (jh(),hh)==a||(gh==a?!b.a:b.a)}
function ue(a,b){return Qb(a)===Qb(b)||!!a&&Qb(a)===Qb(b)}
function Ee(a,b){Be(a);return new Ie(a,new Me(b,a.a))}
function lh(){jh();return fb($(Zc,1),ai,21,0,[gh,ih,hh])}
function Wd(a){if(a.A()){return null}var b=a.j;return zd[b]}
function ye(a){if(!a.d){a.d=new re(a.b);a.c=a.b.a.length}}
function Ud(a,b){var c;c=Sd(a);Zd(a,c);c.e=b?8:0;return c}
function Fd(a){function b(){}
;b.prototype=a||{};return new b}
function uf(a){a.placeholder='What needs to be done?';return a}
function L(a){F();$wnd.setTimeout(function(){throw a},0)}
function Be(a){if(a.b){Be(a.b)}else if(a.c){throw md(new _d)}}
function K(a){a&&R((P(),O));--B;if(a){if(D!=-1){M(D);D=-1}}}
function dg(){dg=Dd;var a;cg=(a=Ed(fg.prototype.N,fg,[]),a)}
function ig(){ig=Dd;var a;hg=(a=Ed(kg.prototype.N,kg,[]),a)}
function qg(){qg=Dd;var a;pg=(a=Ed(sg.prototype.N,sg,[]),a)}
function Dg(){Dg=Dd;var a;Cg=(a=Ed(Fg.prototype.N,Fg,[]),a)}
function Ig(){Ig=Dd;var a;Hg=(a=Ed(Kg.prototype.N,Kg,[]),a)}
function Vd(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.s(b))}
function Bd(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function J(a,b,c){var d;d=H();try{return G(a,b,c)}finally{K(d)}}
function Ld(a,b,c,d){a.addEventListener(b,c,(Nd(),d?true:false))}
function te(a,b){while(a.a<a.c.a.length){b.I((a.b=a.a++,a.c.a[a.b]))}}
function Me(a,b){xe.call(this,b.F(),b.D()&-16449);this.a=a;this.c=b}
function he(){t.call(this,'Add not supported on this collection')}
function s(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function De(a){var b;Ae(a);b=0;while(a.a.H(new Te)){b=nd(b,1)}return b}
function He(a,b){var c;Ae(a);c=new Se;c.a=b;a.a.G(new Ue(c));return c.a}
function wh(a,b){Fe(new Ie(null,new ze(a.a)),new Dh(b));ke(a.b,new Bh)}
function oh(a,b){je(a.a,new nh(''+td(pd(Date.now())),b));ke(a.b,new Bh)}
function Jh(a){var b;b=a.b;!!b&&!rh(a.c,b)&&(a.b=null,ke(a.a,new Oh))}
function hb(a){var b,c,d;b=a&Vh;c=a>>22&Vh;d=a<0?Wh:0;return jb(b,c,d)}
function ag(a){return $wnd.React.createElement((ig(),hg),a.a,undefined)}
function Og(a){return $wnd.React.createElement((qg(),pg),a.a,undefined)}
function $f(a){return $wnd.React.createElement((dg(),cg),a.a,undefined)}
function ah(a){return $wnd.React.createElement((Ig(),Hg),a.a,undefined)}
function Rb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function I(b){F();return function(){return J(b,this,arguments);var a}}
function A(){if(Date.now){return Date.now()}return (new Date).getTime()}
function me(a,b){var c;c=le(a,b,0);if(c==-1){return false}We(a.a,c);return true}
function bb(a,b,c,d,e,f){var g;g=cb(e,d);e!=10&&fb($(a,f),b,c,e,g);return g}
function le(a,b,c){for(;c<a.a.length;++c){if(ue(b,a.a[c])){return c}}return -1}
function Xe(a,b){return ab(b)!=10&&fb(o(b),b.V,b.__elementTypeId$,ab(b),a),a}
function ab(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ji(){$wnd.ReactDOM.render(ah(new bh),(Kd(),Jd).getElementById(_h),null)}
function _d(){t.call(this,"Stream already terminated, can't be modified or used")}
function vd(){wd();var a=ud;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ke(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.I(c)}}
function ug(a,b){var c;if((fh(),eh).b==a.d.props['a']){c=b.target;Bg(a,c.value)}}
function Q(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=U(b,c)}while(a.a);a.a=c}}
function R(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=U(b,c)}while(a.b);a.b=c}}
function be(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function ld(a){var b;if(Mb(a,5)){return a}b=a&&a[Th];if(!b){b=new w(a);X(b)}return b}
function Zd(a,b){var c;if(!a){return}b.j=a;var d=Wd(b);if(!d){zd[a]=[b];return}d.U=b}
function Ed(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function od(a){var b;b=a.h;if(b==0){return a.l+a.m*Zh}if(b==Wh){return a.l+a.m*Zh-Yh}return a}
function Sd(a){var b;b=new Rd;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function ph(a){var b;He(Ee(new Ie(null,new ze(a.a)),new zh),(b=new oe,b)).B(new Ah(a))}
function jh(){jh=Dd;gh=new kh('ACTIVE',0);ih=new kh('COMPLETED',1);hh=new kh('ALL',2)}
function Gb(){Gb=Dd;Cb=jb(Vh,Vh,524287);Db=jb(0,0,Xh);Eb=hb(1);hb(2);Fb=hb(0)}
function rd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Yh;d=Wh}c=Rb(e/Zh);b=Rb(e-c*Zh);return jb(b,c,d)}
function tb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return jb(c&Vh,d&Vh,e&Wh)}
function zb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return jb(c&Vh,d&Vh,e&Wh)}
function wb(a){var b,c,d;b=~a.l+1&Vh;c=~a.m+(b==0?1:0)&Vh;d=~a.h+(b==0&&c==0?1:0)&Wh;return jb(b,c,d)}
function ce(a,b){var c,d;for(d=new re(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);sh(b.a,c)}}
function yg(a){Hh((fh(),eh),gf(a.d.props,'a'));a.b=gf(a.d.props,'a').c;a.d.forceUpdate()}
function Zg(a,b){hf(a.a,(Dg(),'a'),b);return $wnd.React.createElement(Cg,a.a,undefined)}
function pd(a){if($h<a&&a<Yh){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return od(vb(a))}
function jf(a){$wnd.React.Component.call(this,a);this.a=this.O();this.a.d=ve(this);this.a.L()}
function w(a){v();q(this);this.b=a;a!=null&&Ye(a,Th,this);this.c=a==null?'null':Gd(a);this.a=a}
function Rd(){this.g=Od++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function pb(a){var b,c,d;b=~a.l+1&Vh;c=~a.m+(b==0?1:0)&Vh;d=~a.h+(b==0&&c==0?1:0)&Wh;a.l=b;a.m=c;a.h=d}
function qb(a){var b,c;c=ae(a.h);if(c==32){b=ae(a.m);return b==32?ae(a.l)+32:b+20-10}else{return c-12}}
function mb(a,b,c,d,e){var f;f=yb(a,b);c&&pb(f);if(e){a=ob(a,b);d?(gb=wb(a)):(gb=jb(a.l,a.m,a.h))}return f}
function fb(a,b,c,d,e){e.U=a;e.V=b;e.W=Hd;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function yd(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function qh(a){return sd(De(new Ie(null,new ze(a.a))))-sd(De(Ee(new Ie(null,new ze(a.a)),new Ch)))}
function o(a){return Pb(a)?jc:Ob(a)?ac:Nb(a)?$b:Lb(a)?a.U:db(a)?a.U:a.U||Array.isArray(a)&&$(Tb,1)||Tb}
function p(a){return Pb(a)?ef(a):Ob(a)?Rb(a):Nb(a)?a?1231:1237:Lb(a)?a.o():db(a)?$e(a):!!a&&!!a.hashCode?a.hashCode():$e(a)}
function nd(a,b){var c;if(Ob(a)&&Ob(b)){c=a+b;if($h<c&&c<Yh){return c}}return od(tb(Ob(a)?rd(a):a,Ob(b)?rd(b):b))}
function Gd(a){var b;if(Array.isArray(a)&&a.W===Hd){return Qd(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function lb(a,b){if(a.h==Xh&&a.m==0&&a.l==0){b&&(gb=jb(0,0,0));return ib((Gb(),Eb))}b&&(gb=jb(a.l,a.m,a.h));return jb(0,0,0)}
function ef(a){cf();var b,c,d;c=':'+a;d=bf[c];if(d!=null){return Rb(d)}d=_e[c];b=d==null?df(a):Rb(d);ff();bf[c]=b;return b}
function se(a){var b,c,d;d=1;for(c=new re(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function ne(a,b){var c,d;d=a.a.length;b.length<d&&(b=Xe(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Yd(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function ng(a,b){var c;if(13==b.keyCode){b.preventDefault();c=ge(a.a);if(c.length>0){oh((fh(),dh),c);a.a='';a.d.forceUpdate()}}}
function vg(a,b){27==b.which?(Hh((fh(),eh),null),a.b=gf(a.d.props,'a').c,a.d.forceUpdate()):13==b.which&&zg(a)}
function Wf(){Uf();return fb($(Ec,1),ai,6,0,[yf,zf,Af,Bf,Cf,Df,Ef,Ff,Gf,Hf,If,Jf,Kf,Lf,Mf,Nf,Of,Pf,Qf,Rf,Sf,Tf])}
function H(){var a;if(B!=0){a=A();if(a-C>2000){C=a;D=$wnd.setTimeout(N,10)}}if(B++==0){Q((P(),O));return true}return false}
function Y(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function zg(a){if(null!=a.b&&a.b.length!=0){th((fh(),dh),a.d.props['a'],a.b);Hh(eh,null);Bg(a,a.b)}else{sh((fh(),dh),a.d.props['a'])}}
function Kh(a){this.a=new oe;this.c=ve(a);Ld((Kd(),$wnd.window.window),'hashchange',new Mh(this),false);uh(a,Ed(Nh.prototype.P,Nh,[this]))}
function kf(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Kb(a,b){if(Pb(a)){return !!Jb[b]}else if(a.V){return !!a.V[b]}else if(Ob(a)){return !!Ib[b]}else if(Nb(a)){return !!Hb[b]}return false}
function Id(){uh((fh(),dh),Ed(Xf.prototype.P,Xf,[]));Ih(eh,Ed(Yf.prototype.P,Yf,[]));$wnd.ReactDOM.render(ah(new bh),(Kd(),Jd).getElementById(_h),null)}
function ge(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ob(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return jb(c,d,e)}
function xb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return jb(c&Vh,d&Vh,e&Wh)}
function cb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function sb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&Vh;a.m=d&Vh;a.h=e&Wh;return true}
function Fh(a,b){var c,d;b.preventDefault();c=(d=(Kd(),$wnd.window.window).location.hash,null==d?'':d.substr(1));fe(ci,c)||fe(di,c)||fe('',c)?ke(a.a,new Oh):Gh()}
function ub(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function xd(b,c,d,e){wd();var f=ud;$moduleName=c;$moduleBase=d;kd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Qh(g)()}catch(a){b(c,a)}}else{Qh(g)()}}
function U(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].X()&&(c=T(c,g)):g[0].X()}catch(a){a=ld(a);if(Mb(a,5)){d=a;F();L(Mb(d,24)?d.r():d)}else throw md(a)}}return c}
function Ad(){zd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function df(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ee(a,c++)}b=b|0;return b}
function Gh(){var a;if(0==''.length){a=(Kd(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Jd.title,a)}else{(Kd(),$wnd.window.window).location.hash=''}}
function ae(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Cd(a,b,c){var d=zd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=zd[b]),Fd(h));_.V=c;!b&&(_.W=Hd);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.U=f)}
function yb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&Xh)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?Wh:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?Wh:0;f=d?Vh:0;e=c>>b-44}return jb(e&Vh,f&Vh,g&Wh)}
function Xd(a){if(a.w()){var b=a.c;b.A()?(a.k='['+b.j):!b.w()?(a.k='[L'+b.u()+';'):(a.k='['+b.u());a.b=b.t()+'[]';a.i=b.v()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Yd('.',[c,Yd('$',d)]);a.b=Yd('.',[c,Yd('.',d)]);a.i=d[d.length-1]}
function Eh(a){var b,c,d,e;b=(e=(c=(Kd(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),fe(ci,e)||fe(di,e)||fe('',e)?fe(ci,e)?(jh(),gh):fe(di,e)?(jh(),ih):(jh(),hh):(jh(),hh));return He(Ee(new Ie(null,new ze(a.c.a)),new Ph(b)),(d=new oe,d))}
function rb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return be(c)}if(b==0&&d!=0&&c==0){return be(d)+22}if(b!=0&&d==0&&c==0){return be(b)+44}return -1}
function vb(a){var b,c,d,e,f;if(isNaN(a)){return Gb(),Fb}if(a<-9223372036854775808){return Gb(),Db}if(a>=9223372036854775807){return Gb(),Cb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=Yh){d=Rb(a/Yh);a-=d*Yh}c=0;if(a>=Zh){c=Rb(a/Zh);a-=c*Zh}b=Rb(a);f=jb(b,c,d);e&&pb(f);return f}
function Bb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==Xh&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Bb(wb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=hb(1000000000);c=kb(c,e,true);b=''+Ab(gb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function nb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=qb(b)-qb(a);g=xb(b,j);i=jb(0,0,0);while(j>=0){h=sb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&pb(i);if(f){if(d){gb=wb(a);e&&(gb=zb(gb,(Gb(),Eb)))}else{gb=jb(a.l,a.m,a.h)}}return i}
function Uf(){Uf=Dd;yf=new Vf(bi,0);zf=new Vf('checkbox',1);Af=new Vf('color',2);Bf=new Vf('date',3);Cf=new Vf('datetime',4);Df=new Vf('email',5);Ef=new Vf('file',6);Ff=new Vf('hidden',7);Gf=new Vf('image',8);Hf=new Vf('month',9);If=new Vf(Rh,10);Jf=new Vf('password',11);Kf=new Vf('radio',12);Lf=new Vf('range',13);Mf=new Vf('reset',14);Nf=new Vf('search',15);Of=new Vf('submit',16);Pf=new Vf('tel',17);Qf=new Vf('text',18);Rf=new Vf('time',19);Sf=new Vf('url',20);Tf=new Vf('week',21)}
function kb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw md(new Md)}if(a.l==0&&a.m==0&&a.h==0){c&&(gb=jb(0,0,0));return jb(0,0,0)}if(b.h==Xh&&b.m==0&&b.l==0){return lb(a,c)}i=false;if(b.h>>19!=0){b=wb(b);i=true}g=rb(b);f=false;e=false;d=false;if(a.h==Xh&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ib((Gb(),Cb));d=true;i=!i}else{h=yb(a,g);i&&pb(h);c&&(gb=jb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=wb(a);d=true;i=!i}if(g!=-1){return mb(a,g,i,f,c)}if(ub(a,b)<0){c&&(f?(gb=wb(a)):(gb=jb(a.l,a.m,a.h)));return jb(0,0,0)}return nb(d?a:jb(a.l,a.m,a.h),b,i,f,e,c)}
var Rh='number',Sh='__noinit__',Th='__java$exception',Uh={3:1,7:1,5:1},Vh=4194303,Wh=1048575,Xh=524288,Yh=17592186044416,Zh=4194304,$h=-17592186044416,_h='todoapp',ai={3:1,4:1},bi='button',ci='active',di='completed',ei='selected',fi='input',gi='header';var _,zd,ud,kd=-1;Ad();Cd(1,null,{},n);_.n=function(){return this.U};_.o=hi;_.hashCode=function(){return this.o()};var Hb,Ib,Jb;Cd(29,1,{},Rd);_.s=function(a){var b;b=new Rd;b.e=4;a>1?(b.c=Vd(this,a-1)):(b.c=this);return b};_.t=function(){Pd(this);return this.b};_.u=function(){return Qd(this)};_.v=function(){Pd(this);return this.i};_.w=function(){return (this.e&4)!=0};_.A=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Od=1;var hc=Td(1);var _b=Td(29);Cd(5,1,{3:1,5:1});_.p=function(a){return new Error(a)};_.q=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=Qd(this.U),c==null?a:a+': '+c);r(this,s(this.p(b)));X(this)};_.b=Sh;_.d=true;var kc=Td(5);Cd(26,5,{3:1,5:1});var cc=Td(26);Cd(7,26,Uh);var ic=Td(7);Cd(30,7,Uh);var ec=Td(30);Cd(41,30,Uh);var Vb=Td(41);Cd(24,41,{24:1,3:1,7:1,5:1},w);_.r=function(){return Qb(this.a)===Qb(u)?null:this.a};var u;var Sb=Td(24);var Tb=Td(0);Cd(85,1,{});var Ub=Td(85);var B=0,C=0,D=-1;Cd(56,85,{},S);var O;var Wb=Td(56);var V;Cd(98,1,{});var Yb=Td(98);Cd(42,98,{},Z);var Xb=Td(42);var gb;var Cb,Db,Eb,Fb;var Jd;Cd(54,7,Uh,Md);var Zb=Td(54);Hb={3:1,23:1};var $b=Td(95);Cd(96,1,{3:1});var gc=Td(96);Ib={3:1,23:1};var ac=Td(97);Cd(20,1,{3:1,23:1,20:1});_.o=hi;_.b=0;var bc=Td(20);Cd(44,7,Uh,_d);var dc=Td(44);Cd(156,1,{});Cd(53,30,Uh,de);_.p=function(a){return new TypeError(a)};var fc=Td(53);Jb={3:1,37:1,23:1,2:1};var jc=Td(2);Cd(160,1,{});Cd(52,7,Uh,he);var lc=Td(52);Cd(99,1,{82:1});_.B=function(a){ce(this,a)};_.C=function(a){throw md(new he)};var mc=Td(99);Cd(100,99,{82:1,106:1});_.C=function(a){ie(this,this.a.length,a);return true};_.o=function(){return se(this)};var nc=Td(100);Cd(10,100,{3:1,10:1,82:1,106:1},oe);_.C=function(a){return je(this,a)};_.B=function(a){ke(this,a)};var pc=Td(10);Cd(15,1,{},re);_.a=0;_.b=-1;var oc=Td(15);Cd(60,1,{});_.G=function(a){we(this,a)};_.D=function(){return this.d};_.F=function(){return this.e};_.d=0;_.e=0;var rc=Td(60);Cd(33,60,{});var qc=Td(33);Cd(11,1,{},ze);_.D=function(){return this.a};_.F=function(){ye(this);return this.c};_.G=function(a){ye(this);te(this.d,a)};_.H=function(a){ye(this);if(pe(this.d)){a.I(qe(this.d));return true}return false};_.a=0;_.c=0;var sc=Td(11);Cd(59,1,{});_.c=false;var Bc=Td(59);Cd(9,59,{},Ie);var Ac=Td(9);Cd(62,33,{},Me);_.H=function(a){this.b=false;while(!this.b&&this.c.H(new Ne(this,a)));return this.b};_.b=false;var uc=Td(62);Cd(65,1,{},Ne);_.I=function(a){Le(this.a,this.b,a)};var tc=Td(65);Cd(61,33,{},Pe);_.H=function(a){return this.a.H(new Qe(a))};var wc=Td(61);Cd(64,1,{},Qe);_.I=function(a){Oe(this.a,a)};var vc=Td(64);Cd(63,1,{},Se);_.I=function(a){Re(this,a)};var xc=Td(63);Cd(66,1,{},Te);_.I=function(a){};var yc=Td(66);Cd(67,1,{},Ue);_.I=function(a){Ke(this.a,a)};var zc=Td(67);Cd(158,1,{});Cd(155,1,{});var Ze=0;var _e,af=0,bf;Cd(535,1,{});Cd(598,1,{});Cd(101,1,{});_.K=ii;_.L=ii;var Cc=Td(101);Cd(19,$wnd.React.Component,{});Bd(zd[1],_);_.render=function(){return this.a.M()};var Dc=Td(19);Cd(6,20,{3:1,23:1,20:1,6:1},Vf);var yf,zf,Af,Bf,Cf,Df,Ef,Ff,Gf,Hf,If,Jf,Kf,Lf,Mf,Nf,Of,Pf,Qf,Rf,Sf,Tf;var Ec=Ud(6,Wf);Cd(109,$wnd.Function,{36:1},Xf);_.P=ji;Cd(110,$wnd.Function,{36:1},Yf);_.P=ji;Cd(103,101,{});_.M=function(){var a,b,c;a=(fh(),c=(b=(Kd(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),fe(ci,c)||fe(di,c)||fe('',c)?fe(ci,c)?(jh(),gh):fe(di,c)?(jh(),ih):(jh(),hh):(jh(),hh));return $wnd.React.createElement('footer',kf(new $wnd.Object,fb($(jc,1),ai,2,6,['footer'])),ag(new bg),$wnd.React.createElement('ul',kf(new $wnd.Object,fb($(jc,1),ai,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',mf(kf(new $wnd.Object,fb($(jc,1),ai,2,6,[(jh(),hh)==a?ei:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',mf(kf(new $wnd.Object,fb($(jc,1),ai,2,6,[gh==a?ei:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',mf(kf(new $wnd.Object,fb($(jc,1),ai,2,6,[ih==a?ei:null])),'#completed'),'Completed'))),qh(dh)>0?$wnd.React.createElement(bi,nf(kf(new $wnd.Object,fb($(jc,1),ai,2,6,['clear-completed'])),Ed(Zf.prototype.T,Zf,[])),'Clear Completed'):null)};var Ic=Td(103);Cd(132,$wnd.Function,{},Zf);_.T=function(a){ph((fh(),dh))};Cd(70,1,{},_f);var Fc=Td(70);Cd(105,101,{});_.M=function(){var a,b;b=sd(De(new Ie(null,new ze((fh(),dh).a))));a='item'+(b==1?'':'s');return $wnd.React.createElement('span',kf(new $wnd.Object,fb($(jc,1),ai,2,6,['todo-count'])),$wnd.React.createElement('strong',null,b),' '+a+' left')};var Hc=Td(105);Cd(79,1,{},bg);var Gc=Td(79);Cd(74,103,{},eg);var cg;var Mc=Td(74);Cd(131,$wnd.Function,{},fg);_.N=function(a){return new gg(a)};Cd(75,19,{},gg);_.O=function(){return new eg};var Jc=Td(75);Cd(80,105,{},jg);var hg;var Lc=Td(80);Cd(142,$wnd.Function,{},kg);_.N=function(a){return new lg(a)};Cd(81,19,{},lg);_.O=function(){return new jg};var Kc=Td(81);Cd(71,101,{});_.M=function(){return $wnd.React.createElement(fi,of(sf(tf(wf(uf(kf(new $wnd.Object,fb($(jc,1),ai,2,6,['new-todo']))),this.a),Ed(Mg.prototype.S,Mg,[this])),Ed(Ng.prototype.R,Ng,[this]))))};_.a='';var Uc=Td(71);Cd(72,71,{},rg);var pg;var Oc=Td(72);Cd(128,$wnd.Function,{},sg);_.N=function(a){return new tg(a)};Cd(73,19,{},tg);_.O=function(){return new rg};var Nc=Td(73);Cd(104,101,{});_.K=function(){var a;a=(fh(),eh).b==this.d.props['a'];if(!this.c&&a){this.c=true;this.a.focus();this.a.select();this.b=this.d.props['a'].c;this.d.forceUpdate()}else this.c&&!a&&(this.c=false)};_.L=function(){this.b=gf(this.d.props,'a').c};_.M=function(){var a,b;b=this.d.props['a'];a=b.a;return $wnd.React.createElement('li',kf(new $wnd.Object,fb($(jc,1),ai,2,6,[a?di:null,(fh(),eh).b==this.d.props['a']?'editing':null])),$wnd.React.createElement('div',kf(new $wnd.Object,fb($(jc,1),ai,2,6,['view'])),$wnd.React.createElement(fi,sf(pf(vf(kf(new $wnd.Object,fb($(jc,1),ai,2,6,['toggle'])),(Uf(),zf)),a),Ed(Sg.prototype.R,Sg,[this]))),$wnd.React.createElement('label',xf(new $wnd.Object,Ed(Tg.prototype.T,Tg,[this])),b.c),$wnd.React.createElement(bi,nf(kf(new $wnd.Object,fb($(jc,1),ai,2,6,['destroy'])),Ed(Ug.prototype.T,Ug,[this])))),$wnd.React.createElement(fi,tf(sf(rf(qf(kf(lf(new $wnd.Object,Ed(Vg.prototype.I,Vg,[this])),fb($(jc,1),ai,2,6,['edit'])),this.b),Ed(Wg.prototype.Q,Wg,[this])),Ed(Qg.prototype.R,Qg,[this])),Ed(Rg.prototype.S,Rg,[this]))))};_.c=false;var Wc=Td(104);Cd(77,104,{},Eg);var Cg;var Qc=Td(77);Cd(133,$wnd.Function,{},Fg);_.N=function(a){return new Gg(a)};Cd(78,19,{},Gg);_.O=function(){return new Eg};_.componentDidUpdate=function(a){this.a.K()};var Pc=Td(78);Cd(102,101,{});_.M=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(gi,kf(new $wnd.Object,fb($(jc,1),ai,2,6,[gi])),$wnd.React.createElement('h1',null,'todos'),Og(new Pg)),0!=sd(De(new Ie(null,new ze((fh(),dh).a))))?$wnd.React.createElement('section',kf(new $wnd.Object,fb($(jc,1),ai,2,6,[gi])),$wnd.React.createElement(fi,sf(vf(kf(new $wnd.Object,fb($(jc,1),ai,2,6,['toggle-all'])),(Uf(),zf)),Ed(_g.prototype.R,_g,[]))),$wnd.React.createElement.apply(null,['ul',kf(new $wnd.Object,fb($(jc,1),ai,2,6,['todo-list']))].concat((a=He(Ge(new Ie(null,new ze(Eh(eh)))),(b=new oe,b)),ne(a,eb(a.a.length)))))):null,0!=sd(De(new Ie(null,new ze(dh.a))))?$f(new _f):null))};var Yc=Td(102);Cd(57,102,{},Jg);var Hg;var Sc=Td(57);Cd(126,$wnd.Function,{},Kg);_.N=function(a){return new Lg(a)};Cd(58,19,{},Lg);_.O=function(){return new Jg};var Rc=Td(58);Cd(129,$wnd.Function,{},Mg);_.S=function(a){ng(this.a,a)};Cd(130,$wnd.Function,{},Ng);_.R=function(a){mg(this.a,a)};Cd(69,1,{},Pg);var Tc=Td(69);Cd(140,$wnd.Function,{},Qg);_.R=function(a){ug(this.a,a)};Cd(141,$wnd.Function,{},Rg);_.S=function(a){vg(this.a,a)};Cd(134,$wnd.Function,{},Sg);_.R=function(a){Ag(this.a)};Cd(136,$wnd.Function,{},Tg);_.T=function(a){yg(this.a)};Cd(137,$wnd.Function,{},Ug);_.T=function(a){xg(this.a)};Cd(138,$wnd.Function,{},Vg);_.I=function(a){wg(this.a,a)};Cd(139,$wnd.Function,{},Wg);_.Q=function(a){zg(this.a)};Cd(76,1,{},$g);var Vc=Td(76);Cd(127,$wnd.Function,{},_g);_.R=function(a){var b;b=a.target;wh((fh(),dh),b.checked)};Cd(25,1,{},bh);var Xc=Td(25);var dh,eh;Cd(21,20,{3:1,23:1,20:1,21:1},kh);var gh,hh,ih;var Zc=Ud(21,lh);Cd(32,1,{32:1},nh);_.a=false;var ed=Td(32);Cd(31,1,{31:1},xh);var dd=Td(31);Cd(47,1,{},zh);_.J=function(a){return a.a};var $c=Td(47);Cd(48,1,{},Ah);_.I=function(a){sh(this.a,a)};var _c=Td(48);Cd(18,1,{},Bh);_.I=ki;var ad=Td(18);Cd(45,1,{},Ch);_.J=function(a){return !a.a};var bd=Td(45);Cd(46,1,{},Dh);_.I=function(a){yh(this.a,a)};_.a=false;var cd=Td(46);Cd(49,1,{},Kh);var jd=Td(49);Cd(50,1,{},Mh);_.handleEvent=function(a){Fh(this.a,a)};var fd=Td(50);Cd(115,$wnd.Function,{36:1},Nh);_.P=function(){Jh(this.a)};Cd(27,1,{},Oh);_.I=ki;var gd=Td(27);Cd(51,1,{},Ph);_.J=function(a){return Lh(this.a,a)};var hd=Td(51);var Qh=(F(),I);var gwtOnLoad=gwtOnLoad=xd;vd(Id);yd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();