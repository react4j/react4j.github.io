function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='4DADB948C31E71A2AB677EE8C24E5070',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '4DADB948C31E71A2AB677EE8C24E5070';function n(){}
function s(){}
function Y(){}
function Yd(){}
function Yg(){}
function Vg(){}
function ae(){}
function ah(){}
function fh(){}
function jh(){}
function nh(){}
function nf(){}
function mf(){}
function eb(){}
function ei(){}
function gi(){}
function hi(){}
function si(){}
function Gh(){}
function Uh(){}
function cb(a){bb()}
function v(a){Re(a)}
function Ri(a){a.p()}
function lf(a,b){a.a=b}
function kf(a){this.a=a}
function of(a){this.a=a}
function rh(a){this.a=a}
function sh(a){this.a=a}
function uh(a){this.a=a}
function vh(a){this.a=a}
function wh(a){this.a=a}
function xh(a){this.a=a}
function yh(a){this.a=a}
function zh(a){this.a=a}
function Ah(a){this.a=a}
function Bh(a){this.a=a}
function Eh(a){this.a=a}
function Fh(a){this.a=a}
function fi(a){this.a=a}
function ii(a){this.a=a}
function qi(a){this.a=a}
function ri(a){this.a=a}
function ti(a){this.a=a}
function Ne(a){this.c=a}
function ge(){ge=Yd}
function u(){new Ke}
function r(){r=Yd;new q}
function F(){F=Yd;D=new n}
function V(){V=Yd;U=new Y}
function L(){L=Yd;!!(bb(),ab)}
function Df(a,b){Cf(a,b)}
function Sh(a,b){Fe(a.c,b)}
function _h(a,b){Fe(a.b,b)}
function mi(a,b){Fe(a.a,b)}
function Ee(a,b,c){pf(a.a,b,c)}
function Ef(a,b){a.key=b}
function qf(a,b){a.splice(b,1)}
function fb(a,b){return pe(a,b)}
function Ig(a,b){return a.a=b}
function Be(a,b){return a===b}
function Hd(a){return a.b}
function Pi(a){return false}
function Oi(){return uf(this)}
function ze(){w(this);this.r()}
function _e(a,b){We(a);a.a.H(b)}
function ef(a,b){lf(a,df(a.a,b))}
function Se(a,b){while(a.I(b));}
function ue(a,b){this.a=a;this.b=b}
function hf(a,b){this.a=a;this.b=b}
function Lf(a,b){this.a=a;this.b=b}
function Nf(a,b){a.ref=b;return a}
function Of(a,b){a.href=b;return a}
function df(a,b){a.D(b);return a}
function je(a){ie(a);return a.k}
function Gb(a){return a.l|a.m<<22}
function kb(a){return new Array(a)}
function S(a){$wnd.clearTimeout(a)}
function ug(a,b){ue.call(this,a,b)}
function Ph(a,b){ue.call(this,a,b)}
function pf(a,b,c){a.splice(b,0,c)}
function Xf(a,b){a.value=b;return a}
function Rd(){Pd==null&&(Pd=[])}
function T(){I!=0&&(I=0);K=-1}
function Wg(){this.a=Ff(($g(),Zg))}
function Xg(){this.a=Ff((dh(),bh))}
function th(){this.a=Ff((hh(),gh))}
function Dh(){this.a=Ff((lh(),kh))}
function Hh(){this.a=Ff((ph(),oh))}
function xg(a){this.d=Re(a);r();++wg}
function zg(a){this.d=Re(a);r();++yg}
function Fg(a){this.d=Re(a);r();++Eg}
function Ug(a){this.d=Re(a);r();++Tg}
function Ve(a){this.b=a;this.a=16464}
function Qi(){this.a.d.forceUpdate()}
function di(a,b){b.a=a;Ge(b.c,new Uh)}
function Rh(a,b){a.a=b;Ge(a.c,new Uh)}
function li(a,b){a.b=b;Ge(a.a,new si)}
function Sf(a,b){a.onBlur=b;return a}
function Pf(a,b){a.onClick=b;return a}
function Tf(a,b){a.onChange=b;return a}
function Rf(a,b){a.checked=b;return a}
function Wb(a){return a==null?null:a}
function Ub(a){return typeof a===vi}
function ob(a){return pb(a.l,a.m,a.h)}
function Le(a){return a.a<a.c.a.length}
function uf(a){return a.$H||(a.$H=++tf)}
function Ae(a,b){return a.charCodeAt(b)}
function Sb(a,b){return a!=null&&Qb(a,b)}
function pb(a,b,c){return {l:a,m:b,h:c}}
function Yh(a,b){return He(a.a,b,0)!=-1}
function Cf(a,b){for(var c in a){b(c)}}
function Uf(a,b){a.onKeyDown=b;return a}
function Qf(a){a.autoFocus=true;return a}
function ie(a){if(a.k!=null){return}re(a)}
function A(a,b){a.b=b;b!=null&&sf(b,yi,a)}
function Pg(a,b){a.b=b;a.d.forceUpdate()}
function Dg(a,b){a.a=b;a.d.forceUpdate()}
function Zh(a,b){Ie(a.a,b);Ge(a.b,new gi)}
function ai(a,b){Rh(b,!b.a);Ge(a.b,new gi)}
function ci(){this.a=new Ke;this.b=new Ke}
function yf(){yf=Yd;vf=new n;xf=new n}
function de(){de=Yd;ce=$wnd.window.document}
function Ke(){this.a=hb(tc,wi,1,0,5,1)}
function C(a){this.c=a;w(this);this.r()}
function cf(a,b){Ye.call(this,a);this.a=b}
function fe(){C.call(this,'divide by zero')}
function Mg(a){ai((Kh(),Ih),a.d.props['a'])}
function Jg(a){Zh((Kh(),Ih),a.d.props['a'])}
function Tb(a){return typeof a==='boolean'}
function Vb(a){return typeof a==='string'}
function M(a,b,c){return a.apply(b,c);var d}
function sf(b,c,d){try{b[c]=d}catch(a){}}
function ee(a,b,c,d){a.addEventListener(b,c,d)}
function Fe(a,b){a.a[a.a.length]=b;return true}
function Yf(a,b){a.onDoubleClick=b;return a}
function w(a){a.d&&a.b!==xi&&a.r();return a}
function me(a){var b;b=le(a);te(a,b);return b}
function oe(a){var b;b=le(a);b.j=a;b.e=1;return b}
function Z(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Nd(a){if(Ub(a)){return a|0}return Gb(a)}
function Od(a){if(Ub(a)){return ''+a}return Hb(a)}
function Me(a){a.b=a.a++;return a.c.a[a.b]}
function Ag(a,b){var c;c=b.target;Dg(a,c.value)}
function bb(){bb=Yd;var a;!db();a=new eb;ab=a}
function Kh(){Kh=Yd;Ih=new ci;Jh=new oi(Ih)}
function af(a){Xe(a);return new cf(a,new jf(a.a))}
function $e(a,b){Xe(a);return new cf(a,new gf(b,a.a))}
function Re(a){if(a==null){throw Hd(new ze)}return a}
function Bf(){if(wf==256){vf=xf;xf=new n;wf=0}++wf}
function q(){this.a=new t;new v(this.a);new u}
function Ye(a){if(!a){this.b=null;new Ke}else{this.b=a}}
function We(a){if(!a.b){Xe(a);a.c=true}else{We(a.b)}}
function ff(a,b,c){if(a.a.K(c)){a.b=true;b.J(c)}}
function jf(a){Te.call(this,a.G(),a.F()&-6);this.a=a}
function jb(a){return Array.isArray(a)&&a.T===ae}
function Rb(a){return !Array.isArray(a)&&a.T===ae}
function pi(a,b){return (Oh(),Mh)==a||(Lh==a?!b.a:b.a)}
function Qe(a,b){return Wb(a)===Wb(b)||!!a&&Wb(a)===Wb(b)}
function Te(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Wf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ne(a,b){var c;c=le(a);te(a,c);c.e=b?8:0;return c}
function Ue(a){if(!a.d){a.d=new Ne(a.b);a.c=a.b.a.length}}
function Sg(a){_h((Kh(),Ih),new Eh(a));mi(Jh,new Fh(a))}
function $h(a,b,c){b.d=Re(c);Ge(b.c,new Uh);Ge(a.b,new gi)}
function $d(a){function b(){}
;b.prototype=a||{};return new b}
function qe(a){if(a.B()){return null}var b=a.j;return Ud[b]}
function Xe(a){if(a.b){Xe(a.b)}else if(a.c){throw Hd(new ve)}}
function R(a){L();$wnd.setTimeout(function(){throw a},0)}
function _g(a){$wnd.React.Component.call(this,a);new xg(this)}
function eh(a){$wnd.React.Component.call(this,a);new zg(this)}
function Qh(){Oh();return lb(fb(rd,1),wi,22,0,[Lh,Nh,Mh])}
function dh(){dh=Yd;var a;bh=(a=Zd(ah.prototype.Q,ah,[]),a)}
function hh(){hh=Yd;var a;gh=(a=Zd(fh.prototype.Q,fh,[]),a)}
function lh(){lh=Yd;var a;kh=(a=Zd(jh.prototype.Q,jh,[]),a)}
function ph(){ph=Yd;var a;oh=(a=Zd(nh.prototype.Q,nh,[]),a)}
function $g(){$g=Yd;var a;Zg=(a=Zd(Yg.prototype.Q,Yg,[]),a)}
function pe(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.t(b))}
function P(a,b,c){var d;d=N();try{return M(a,b,c)}finally{Q(d)}}
function Wd(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Kf(a,b,c){!Be(c,'key')&&!Be(c,'ref')&&(a[c]=b[c],undefined)}
function gf(a,b){Te.call(this,b.G(),b.F()&-16449);this.a=a;this.c=b}
function De(){C.call(this,'Add not supported on this collection')}
function Vf(a){a.placeholder='What needs to be done?';return a}
function B(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function O(b){L();return function(){return P(b,this,arguments);var a}}
function Xb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Q(a){a&&X((V(),U));--I;if(a){if(K!=-1){S(K);K=-1}}}
function Kg(a){li((Kh(),Jh),a.d.props['a']);Pg(a,a.d.props['a'].d)}
function Pe(a,b){while(a.a<a.c.a.length){b.J((a.b=a.a++,a.c.a[a.b]))}}
function ni(a){var b;b=a.b;!!b&&!Yh(a.c,b)&&(a.b=null,Ge(a.a,new si))}
function bi(a,b){_e(new cf(null,new Ve(a.a)),new ii(b));Ge(a.b,new gi)}
function Vh(a,b){Fe(a.a,new Th(''+Od(Kd(Date.now())),b));Ge(a.b,new gi)}
function Th(a,b){this.c=new Ke;this.b=Re(a);this.d=Re(b);this.a=false}
function ih(a){$wnd.React.Component.call(this,a);this.a=new Fg(this)}
function mh(a){$wnd.React.Component.call(this,a);this.a=new Rg(this)}
function qh(a){$wnd.React.Component.call(this,a);this.a=new Ug(this)}
function H(){if(Date.now){return Date.now()}return (new Date).getTime()}
function bf(a,b){var c;We(a);c=new mf;c.a=b;a.a.H(new of(c));return c.a}
function Ze(a){var b;We(a);b=0;while(a.a.I(new nf)){b=Id(b,1)}return b}
function Ie(a,b){var c;c=He(a,b,0);if(c==-1){return false}qf(a.a,c);return true}
function hb(a,b,c,d,e,f){var g;g=ib(e,d);e!=10&&lb(fb(a,f),b,c,e,g);return g}
function He(a,b,c){for(;c<a.a.length;++c){if(Qe(b,a.a[c])){return c}}return -1}
function nb(a){var b,c,d;b=a&Ai;c=a>>22&Ai;d=a<0?Bi:0;return pb(b,c,d)}
function Ge(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.J(c)}}
function Gg(a,b){var c;if((Kh(),Jh).b==a.d.props['a']){c=b.target;Pg(a,c.value)}}
function W(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=$(b,c)}while(a.a);a.a=c}}
function X(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=$(b,c)}while(a.b);a.b=c}}
function t(){var a;this.a=hb($b,wi,27,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function Mb(){Mb=Yd;Ib=pb(Ai,Ai,524287);Jb=pb(0,0,Ci);Kb=nb(1);nb(2);Lb=nb(0)}
function Gd(a){var b;if(Sb(a,5)){return a}b=a&&a[yi];if(!b){b=new G(a);cb(b)}return b}
function te(a,b){var c;if(!a){return}b.j=a;var d=qe(b);if(!d){Ud[a]=[b];return}d.R=b}
function xe(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function Zd(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function le(a){var b;b=new ke;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Ff(a){var b;b=Hf($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function If(a){var b;return Gf($wnd.React.StrictMode,null,null,(b={},b[Gi]=Re(a),b))}
function Wh(a){var b;bf($e(new cf(null,new Ve(a.a)),new ei),(b=new Ke,b)).C(new fi(a))}
function Oh(){Oh=Yd;Lh=new Ph('ACTIVE',0);Nh=new Ph('COMPLETED',1);Mh=new Ph('ALL',2)}
function be(){$wnd.ReactDOM.render(If([(new Hh).a]),(de(),ce).getElementById('app'),null)}
function rf(a,b){return gb(b)!=10&&lb(o(b),b.S,b.__elementTypeId$,gb(b),a),a}
function gb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ve(){C.call(this,"Stream already terminated, can't be modified or used")}
function Qd(){Rd();var a=Pd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ye(a,b){var c,d;for(d=new Ne(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Zh(b.a,c)}}
function Md(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Di;d=Bi}c=Xb(e/Ei);b=Xb(e-c*Ei);return pb(b,c,d)}
function zb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return pb(c&Ai,d&Ai,e&Bi)}
function Fb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return pb(c&Ai,d&Ai,e&Bi)}
function Jd(a){var b;b=a.h;if(b==0){return a.l+a.m*Ei}if(b==Bi){return a.l+a.m*Ei-Di}return a}
function Kd(a){if(Fi<a&&a<Di){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Jd(Bb(a))}
function Ch(a,b){Ef(a.a,(ie(md),md.k+(''+(b?b.b:null))));Re(b);a.a.props['a']=b;return a.a}
function Hg(a,b){27==b.which?(li((Kh(),Jh),null),Pg(a,a.d.props['a'].d)):13==b.which&&Lg(a)}
function Rg(a){this.d=Re(a);r();++Qg;this.b=this.d.props['a'].d;Sh(this.d.props['a'],new uh(this))}
function G(a){F();w(this);this.b=a;a!=null&&sf(a,yi,this);this.c=a==null?'null':_d(a);this.a=a}
function ke(){this.g=he++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Xh(a){return Nd(Ze(new cf(null,new Ve(a.a))))-Nd(Ze($e(new cf(null,new Ve(a.a)),new hi)))}
function Gf(a,b,c,d){var e;e=Hf($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Re(d);return e}
function lb(a,b,c,d,e){e.R=a;e.S=b;e.T=ae;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function sb(a,b,c,d,e){var f;f=Eb(a,b);c&&vb(f);if(e){a=ub(a,b);d?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h))}return f}
function wb(a){var b,c;c=we(a.h);if(c==32){b=we(a.m);return b==32?we(a.l)+32:b+20-10}else{return c-12}}
function Cb(a){var b,c,d;b=~a.l+1&Ai;c=~a.m+(b==0?1:0)&Ai;d=~a.h+(b==0&&c==0?1:0)&Bi;return pb(b,c,d)}
function vb(a){var b,c,d;b=~a.l+1&Ai;c=~a.m+(b==0?1:0)&Ai;d=~a.h+(b==0&&c==0?1:0)&Bi;a.l=b;a.m=c;a.h=d}
function o(a){return Vb(a)?vc:Ub(a)?mc:Tb(a)?kc:Rb(a)?a.R:jb(a)?a.R:a.R||Array.isArray(a)&&fb(dc,1)||dc}
function p(a){return Vb(a)?Af(a):Ub(a)?Xb(a):Tb(a)?a?1231:1237:Rb(a)?a.o():jb(a)?uf(a):!!a&&!!a.hashCode?a.hashCode():uf(a)}
function Id(a,b){var c;if(Ub(a)&&Ub(b)){c=a+b;if(Fi<c&&c<Di){return c}}return Jd(zb(Ub(a)?Md(a):a,Ub(b)?Md(b):b))}
function Td(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function vg(){tg();return lb(fb(Pc,1),wi,6,0,[Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg,rg,sg])}
function oi(a){this.a=new Ke;this.c=Re(a);ee((de(),$wnd.window.window),'hashchange',new qi(this),false);_h(a,new ri(this))}
function _d(a){var b;if(Array.isArray(a)&&a.T===ae){return je(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function rb(a,b){if(a.h==Ci&&a.m==0&&a.l==0){b&&(mb=pb(0,0,0));return ob((Mb(),Kb))}b&&(mb=pb(a.l,a.m,a.h));return pb(0,0,0)}
function Af(a){yf();var b,c,d;c=':'+a;d=xf[c];if(d!=null){return Xb(d)}d=vf[c];b=d==null?zf(a):Xb(d);Bf();xf[c]=b;return b}
function Oe(a){var b,c,d;d=1;for(c=new Ne(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function Je(a,b){var c,d;d=a.a.length;b.length<d&&(b=rf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function se(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Bg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=Ce(a.a);if(c.length>0){Vh((Kh(),Ih),c);a.a='';a.d.forceUpdate()}}}
function N(){var a;if(I!=0){a=H();if(a-J>2000){J=a;K=$wnd.setTimeout(T,10)}}if(I++==0){W((V(),U));return true}return false}
function db(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Lg(a){if(null!=a.b&&a.b.length!=0){$h((Kh(),Ih),a.d.props['a'],a.b);li(Jh,null);Pg(a,a.b)}else{Zh((Kh(),Ih),a.d.props['a'])}}
function Mf(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Qb(a,b){if(Vb(a)){return !!Pb[b]}else if(a.S){return !!a.S[b]}else if(Ub(a)){return !!Ob[b]}else if(Tb(a)){return !!Nb[b]}return false}
function Ng(a){var b;b=(Kh(),Jh).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();Pg(a,a.d.props['a'].d)}else a.c&&!b&&(a.c=false)}
function Ce(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ub(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return pb(c,d,e)}
function Db(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return pb(c&Ai,d&Ai,e&Bi)}
function ib(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function yb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&Ai;a.m=d&Ai;a.h=e&Bi;return true}
function Cg(a){return Jf(Ii,Qf(Tf(Uf(Xf(Vf(Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,['new-todo']))),a.a),Zd(rh.prototype.O,rh,[a])),Zd(sh.prototype.N,sh,[a]))),null)}
function Ab(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Sd(b,c,d,e){Rd();var f=Pd;$moduleName=c;$moduleBase=d;Fd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ui(g)()}catch(a){b(c,a)}}else{ui(g)()}}
function Hf(a,b){var c;c=new $wnd.Object;c.$$typeof=Re(a);c.type=Re(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function $(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].U()&&(c=Z(c,g)):g[0].U()}catch(a){a=Gd(a);if(Sb(a,5)){d=a;L();R(Sb(d,24)?d.s():d)}else throw Hd(a)}}return c}
function Vd(){Ud={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function zf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ae(a,c++)}b=b|0;return b}
function ji(a){var b,c,d,e;b=(e=(c=(de(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),Be(Ji,e)?(Oh(),Lh):Be(Ki,e)?(Oh(),Nh):(Oh(),Mh));return bf($e(new cf(null,new Ve(a.c.a)),new ti(b)),(d=new Ke,d))}
function we(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Xd(a,b,c){var d=Ud,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Ud[b]),$d(h));_.S=c;!b&&(_.T=ae);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.R=f)}
function Eb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&Ci)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?Bi:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?Bi:0;f=d?Ai:0;e=c>>b-44}return pb(e&Ai,f&Ai,g&Bi)}
function re(a){if(a.A()){var b=a.c;b.B()?(a.k='['+b.j):!b.A()?(a.k='[L'+b.v()+';'):(a.k='['+b.v());a.b=b.u()+'[]';a.i=b.w()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=se('.',[c,se('$',d)]);a.b=se('.',[c,se('.',d)]);a.i=d[d.length-1]}
function Jf(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Df(b,Zd(Lf.prototype.L,Lf,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Gi]=c[0],undefined):(d[Gi]=c,undefined));return Gf(a,e,f,d)}
function xb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return xe(c)}if(b==0&&d!=0&&c==0){return xe(d)+22}if(b!=0&&d==0&&c==0){return xe(b)+44}return -1}
function Bb(a){var b,c,d,e,f;if(isNaN(a)){return Mb(),Lb}if(a<-9223372036854775808){return Mb(),Jb}if(a>=9223372036854775807){return Mb(),Ib}e=false;if(a<0){e=true;a=-a}d=0;if(a>=Di){d=Xb(a/Di);a-=d*Di}c=0;if(a>=Ei){c=Xb(a/Ei);a-=c*Ei}b=Xb(a);f=pb(b,c,d);e&&vb(f);return f}
function ki(a,b){var c,d,e;b.preventDefault();c=(d=(de(),$wnd.window.window).location.hash,null==d?'':d.substr(1));if(Be(Ji,c)||Be(Ki,c)||Be('',c)){Ge(a.a,new si)}else{e=$wnd.window.window.location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',ce.title,e)}}
function Hb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==Ci&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Hb(Cb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=nb(1000000000);c=qb(c,e,true);b=''+Gb(mb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function tb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=wb(b)-wb(a);g=Db(b,j);i=pb(0,0,0);while(j>=0){h=yb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&vb(i);if(f){if(d){mb=Cb(a);e&&(mb=Fb(mb,(Mb(),Kb)))}else{mb=pb(a.l,a.m,a.h)}}return i}
function tg(){tg=Yd;Zf=new ug(Hi,0);$f=new ug('checkbox',1);_f=new ug('color',2);ag=new ug('date',3);bg=new ug('datetime',4);cg=new ug('email',5);dg=new ug('file',6);eg=new ug('hidden',7);fg=new ug('image',8);gg=new ug('month',9);hg=new ug(vi,10);ig=new ug('password',11);jg=new ug('radio',12);kg=new ug('range',13);lg=new ug('reset',14);mg=new ug('search',15);ng=new ug('submit',16);og=new ug('tel',17);pg=new ug('text',18);qg=new ug('time',19);rg=new ug('url',20);sg=new ug('week',21)}
function qb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Hd(new fe)}if(a.l==0&&a.m==0&&a.h==0){c&&(mb=pb(0,0,0));return pb(0,0,0)}if(b.h==Ci&&b.m==0&&b.l==0){return rb(a,c)}i=false;if(b.h>>19!=0){b=Cb(b);i=true}g=xb(b);f=false;e=false;d=false;if(a.h==Ci&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ob((Mb(),Ib));d=true;i=!i}else{h=Eb(a,g);i&&vb(h);c&&(mb=pb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Cb(a);d=true;i=!i}if(g!=-1){return sb(a,g,i,f,c)}if(Ab(a,b)<0){c&&(f?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h)));return pb(0,0,0)}return tb(d?a:pb(a.l,a.m,a.h),b,i,f,e,c)}
function Og(a){var b,c;c=a.d.props['a'];b=c.a;return Jf('li',Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,[b?'checked':null,(Kh(),Jh).b==a.d.props['a']?'editing':null])),[Jf('div',Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,['view'])),[Jf(Ii,Tf(Rf(Wf(Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,['toggle'])),(tg(),$f)),b),Zd(xh.prototype.N,xh,[a])),null),Jf('label',Yf(new $wnd.Object,Zd(yh.prototype.P,yh,[a])),[c.d]),Jf(Hi,Pf(Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,['destroy'])),Zd(zh.prototype.P,zh,[a])),null)]),Jf(Ii,Uf(Tf(Sf(Xf(Mf(Nf(new $wnd.Object,Zd(Ah.prototype.J,Ah,[a])),lb(fb(vc,1),wi,2,6,['edit'])),a.b),Zd(Bh.prototype.M,Bh,[a])),Zd(vh.prototype.N,vh,[a])),Zd(wh.prototype.O,wh,[a])),null)])}
var vi='number',wi={3:1,4:1},xi='__noinit__',yi='__java$exception',zi={3:1,7:1,5:1},Ai=4194303,Bi=1048575,Ci=524288,Di=17592186044416,Ei=4194304,Fi=-17592186044416,Gi='children',Hi='button',Ii='input',Ji='active',Ki='completed',Li='selected',Mi='header',Ni={40:1};var _,Ud,Pd,Fd=-1;Vd();Xd(1,null,{},n);_.n=function(){return this.R};_.o=Oi;_.hashCode=function(){return this.o()};var Nb,Ob,Pb;Xd(33,1,{},ke);_.t=function(a){var b;b=new ke;b.e=4;a>1?(b.c=pe(this,a-1)):(b.c=this);return b};_.u=function(){ie(this);return this.b};_.v=function(){return je(this)};_.w=function(){ie(this);return this.i};_.A=function(){return (this.e&4)!=0};_.B=function(){return (this.e&1)!=0};_.e=0;_.g=0;var he=1;var tc=me(1);var lc=me(33);Xd(60,1,{},q);var Zb=me(60);Xd(27,1,{27:1},s);var $b=me(27);Xd(71,1,{148:1},t);var _b=me(71);Xd(73,1,{},u);var ac=me(73);Xd(72,1,{},v);var bc=me(72);Xd(5,1,{3:1,5:1});_.q=function(a){return new Error(a)};_.r=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=je(this.R),c==null?a:a+': '+c);A(this,B(this.q(b)));cb(this)};_.b=xi;_.d=true;var wc=me(5);Xd(25,5,{3:1,5:1});var oc=me(25);Xd(7,25,zi);var uc=me(7);Xd(34,7,zi);var qc=me(34);Xd(46,34,zi);var fc=me(46);Xd(24,46,{24:1,3:1,7:1,5:1},G);_.s=function(){return Wb(this.a)===Wb(D)?null:this.a};var D;var cc=me(24);var dc=me(0);Xd(103,1,{});var ec=me(103);var I=0,J=0,K=-1;Xd(54,103,{},Y);var U;var gc=me(54);var ab;Xd(116,1,{});var ic=me(116);Xd(47,116,{},eb);var hc=me(47);var mb;var Ib,Jb,Kb,Lb;var ce;Xd(52,7,zi,fe);var jc=me(52);Nb={3:1,23:1};var kc=me(113);Xd(114,1,{3:1});var sc=me(114);Ob={3:1,23:1};var mc=me(115);Xd(20,1,{3:1,23:1,20:1});_.o=Oi;_.b=0;var nc=me(20);Xd(49,7,zi,ve);var pc=me(49);Xd(177,1,{});Xd(51,34,zi,ze);_.q=function(a){return new TypeError(a)};var rc=me(51);Pb={3:1,42:1,23:1,2:1};var vc=me(2);Xd(181,1,{});Xd(50,7,zi,De);var xc=me(50);Xd(117,1,{100:1});_.C=function(a){ye(this,a)};_.D=function(a){throw Hd(new De)};var yc=me(117);Xd(118,117,{100:1,124:1});_.D=function(a){Ee(this,this.a.length,a);return true};_.o=function(){return Oe(this)};var zc=me(118);Xd(10,118,{3:1,10:1,100:1,124:1},Ke);_.D=function(a){return Fe(this,a)};_.C=function(a){Ge(this,a)};var Bc=me(10);Xd(17,1,{},Ne);_.a=0;_.b=-1;var Ac=me(17);Xd(76,1,{});_.H=function(a){Se(this,a)};_.F=function(){return this.d};_.G=function(){return this.e};_.d=0;_.e=0;var Dc=me(76);Xd(36,76,{});var Cc=me(36);Xd(13,1,{},Ve);_.F=function(){return this.a};_.G=function(){Ue(this);return this.c};_.H=function(a){Ue(this);Pe(this.d,a)};_.I=function(a){Ue(this);if(Le(this.d)){a.J(Me(this.d));return true}return false};_.a=0;_.c=0;var Ec=me(13);Xd(75,1,{});_.c=false;var Nc=me(75);Xd(11,75,{147:1,11:1},cf);var Mc=me(11);Xd(78,36,{},gf);_.I=function(a){this.b=false;while(!this.b&&this.c.I(new hf(this,a)));return this.b};_.b=false;var Gc=me(78);Xd(81,1,{},hf);_.J=function(a){ff(this.a,this.b,a)};var Fc=me(81);Xd(77,36,{},jf);_.I=function(a){return this.a.I(new kf(a))};var Ic=me(77);Xd(80,1,{},kf);_.J=function(a){this.a.J(Ch(new Dh,a))};var Hc=me(80);Xd(79,1,{},mf);_.J=function(a){lf(this,a)};var Jc=me(79);Xd(82,1,{},nf);_.J=function(a){};var Kc=me(82);Xd(83,1,{},of);_.J=function(a){ef(this.a,a)};var Lc=me(83);Xd(179,1,{});Xd(176,1,{});var tf=0;var vf,wf=0,xf;Xd(787,1,{});Xd(808,1,{});Xd(119,1,{});var Oc=me(119);Xd(146,$wnd.Function,{},Lf);_.L=function(a){Kf(this.a,this.b,a)};Xd(6,20,{3:1,23:1,20:1,6:1},ug);var Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg,rg,sg;var Pc=ne(6,vg);Xd(122,119,{});var Yc=me(122);Xd(92,122,{});var ad=me(92);Xd(93,92,{},xg);_.o=Oi;var wg=0;var Rc=me(93);Xd(123,119,{});var Xc=me(123);Xd(98,123,{});var _c=me(98);Xd(99,98,{},zg);_.o=Oi;var yg=0;var Qc=me(99);Xd(89,119,{});_.a='';var jd=me(89);Xd(90,89,{});var cd=me(90);Xd(91,90,{},Fg);_.o=Oi;var Eg=0;var Sc=me(91);Xd(121,119,{});_.c=false;var md=me(121);Xd(95,121,{});var ed=me(95);Xd(96,95,{},Rg);_.o=Oi;var Qg=0;var Tc=me(96);Xd(120,119,{});var qd=me(120);Xd(58,120,{});var gd=me(58);Xd(59,58,{},Ug);_.o=Oi;var Tg=0;var Uc=me(59);Xd(153,$wnd.Function,{},Vg);_.P=function(a){Wh((Kh(),Ih))};Xd(66,1,{},Wg);var Vc=me(66);Xd(94,1,{},Xg);var Wc=me(94);Xd(152,$wnd.Function,{},Yg);_.Q=function(a){return new _g(a)};var Zg;Xd(85,$wnd.React.Component,{},_g);Wd(Ud[1],_);_.render=function(){var a,b,c;return a=(c=(Kh(),b=(de(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),Be(Ji,c)?(Oh(),Lh):Be(Ki,c)?(Oh(),Nh):(Oh(),Mh)),Jf('footer',Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,['footer'])),[(new Xg).a,Jf('ul',Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,['filters'])),[Jf('li',null,[Jf('a',Of(Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,[(Oh(),Mh)==a?Li:null])),'#'),['All'])]),Jf('li',null,[Jf('a',Of(Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,[Lh==a?Li:null])),'#active'),['Active'])]),Jf('li',null,[Jf('a',Of(Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,[Nh==a?Li:null])),'#completed'),['Completed'])])]),Xh(Ih)>0?Jf(Hi,Pf(Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,['clear-completed'])),Zd(Vg.prototype.P,Vg,[])),['Clear Completed']):null])};_.shouldComponentUpdate=Pi;var Zc=me(85);Xd(163,$wnd.Function,{},ah);_.Q=function(a){return new eh(a)};var bh;Xd(97,$wnd.React.Component,{},eh);Wd(Ud[1],_);_.render=function(){var a,b;return a=Nd(Ze(new cf(null,new Ve((Kh(),Ih).a)))),b='item'+(a==1?'':'s'),Jf('span',Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,['todo-count'])),[Jf('strong',null,[a]),' '+b+' left'])};_.shouldComponentUpdate=Pi;var $c=me(97);Xd(149,$wnd.Function,{},fh);_.Q=function(a){return new ih(a)};var gh;Xd(74,$wnd.React.Component,{},ih);Wd(Ud[1],_);_.render=function(){return Cg(this.a)};_.shouldComponentUpdate=Pi;var bd=me(74);Xd(162,$wnd.Function,{},jh);_.Q=function(a){return new mh(a)};var kh;Xd(88,$wnd.React.Component,{},mh);Wd(Ud[1],_);_.componentDidUpdate=function(a){Ng(this.a)};_.render=function(){return Og(this.a)};_.shouldComponentUpdate=Pi;var dd=me(88);Xd(144,$wnd.Function,{},nh);_.Q=function(a){return new qh(a)};var oh;Xd(55,$wnd.React.Component,{},qh);Wd(Ud[1],_);_.componentDidMount=function(){Sg(this.a)};_.render=function(){var a,b;return Jf('div',null,[Jf('div',null,[Jf(Mi,Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,[Mi])),[Jf('h1',null,['todos']),(new th).a]),0!=Nd(Ze(new cf(null,new Ve((Kh(),Ih).a))))?Jf('section',Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,[Mi])),[Jf(Ii,Tf(Wf(Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,['toggle-all'])),(tg(),$f)),Zd(Gh.prototype.N,Gh,[])),null),Jf('ul',Mf(new $wnd.Object,lb(fb(vc,1),wi,2,6,['todo-list'])),(a=bf(Re(af(new cf(null,new Ve(ji(Jh))))),(b=new Ke,b)),Je(a,kb(a.a.length))))]):null,0!=Nd(Ze(new cf(null,new Ve(Ih.a))))?(new Wg).a:null])])};_.shouldComponentUpdate=Pi;var fd=me(55);Xd(150,$wnd.Function,{},rh);_.O=function(a){Bg(this.a,a)};Xd(151,$wnd.Function,{},sh);_.N=function(a){Ag(this.a,a)};Xd(61,1,{},th);var hd=me(61);Xd(87,1,Ni,uh);_.p=Qi;var kd=me(87);Xd(160,$wnd.Function,{},vh);_.N=function(a){Gg(this.a,a)};Xd(161,$wnd.Function,{},wh);_.O=function(a){Hg(this.a,a)};Xd(154,$wnd.Function,{},xh);_.N=function(a){Mg(this.a)};Xd(156,$wnd.Function,{},yh);_.P=function(a){Kg(this.a)};Xd(157,$wnd.Function,{},zh);_.P=function(a){Jg(this.a)};Xd(158,$wnd.Function,{},Ah);_.J=function(a){Ig(this.a,a)};Xd(159,$wnd.Function,{},Bh);_.M=function(a){Lg(this.a)};Xd(86,1,{},Dh);var ld=me(86);Xd(56,1,Ni,Eh);_.p=Qi;var nd=me(56);Xd(57,1,Ni,Fh);_.p=Qi;var od=me(57);Xd(145,$wnd.Function,{},Gh);_.N=function(a){var b;b=a.target;bi((Kh(),Ih),b.checked)};Xd(41,1,{},Hh);var pd=me(41);var Ih,Jh;Xd(22,20,{3:1,23:1,20:1,22:1},Ph);var Lh,Mh,Nh;var rd=ne(22,Qh);Xd(37,1,{37:1},Th);_.a=false;var zd=me(37);Xd(28,1,{},Uh);_.J=Ri;var sd=me(28);Xd(35,1,{35:1},ci);var yd=me(35);Xd(64,1,{},ei);_.K=function(a){return a.a};var td=me(64);Xd(65,1,{},fi);_.J=function(a){Zh(this.a,a)};var ud=me(65);Xd(21,1,{},gi);_.J=Ri;var vd=me(21);Xd(62,1,{},hi);_.K=function(a){return !a.a};var wd=me(62);Xd(63,1,{},ii);_.J=function(a){di(this.a,a)};_.a=false;var xd=me(63);Xd(67,1,{},oi);var Ed=me(67);Xd(68,1,{},qi);_.handleEvent=function(a){ki(this.a,a)};var Ad=me(68);Xd(69,1,Ni,ri);_.p=function(){ni(this.a)};var Bd=me(69);Xd(26,1,{},si);_.J=Ri;var Cd=me(26);Xd(70,1,{},ti);_.K=function(a){return pi(this.a,a)};var Dd=me(70);var Yb=oe('D');var ui=(L(),O);var gwtOnLoad=gwtOnLoad=Sd;Qd(be);Td('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();