function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='0D2194339A165F9964B79EDCC566F5EC',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '0D2194339A165F9964B79EDCC566F5EC';function n(){}
function U(){}
function ee(){}
function ae(){}
function ab(){}
function ah(){}
function bh(){}
function kh(){}
function mh(){}
function qh(){}
function xh(){}
function xf(){}
function sf(){}
function uf(){}
function vf(){}
function wf(){}
function Sf(){}
function Tf(){}
function sg(){}
function Nh(){}
function Zh(){}
function _h(){}
function ii(){}
function Hi(){}
function Ji(){}
function Ki(){}
function Wi(){}
function Z(a){Y()}
function xj(a){a()}
function ph(){oh()}
function le(){le=ae}
function Gi(a,b){b.a=a}
function Rf(a,b){a.a=b}
function Vf(a){this.a=a}
function Je(a){this.a=a}
function Le(a){this.b=a}
function We(a){this.c=a}
function zh(a){this.a=a}
function Ah(a){this.a=a}
function Bh(a){this.a=a}
function Ph(a){this.a=a}
function Qh(a){this.a=a}
function Rh(a){this.a=a}
function Sh(a){this.a=a}
function Th(a){this.a=a}
function Uh(a){this.a=a}
function Vh(a){this.a=a}
function Vi(a){this.a=a}
function ci(a){this.a=a}
function Ii(a){this.a=a}
function Li(a){this.a=a}
function Ui(a){this.a=a}
function Xi(a){this.a=a}
function bi(){this.a={}}
function gi(){this.a={}}
function gh(){this.a={}}
function eh(){this.a={}}
function ki(){this.a={}}
function uj(a){ef(this,a)}
function vj(){return this.a}
function Kd(a){return a.e}
function Fe(a,b){return a===b}
function Ci(a,b){Ne(a.b,b)}
function Qi(a,b){Ne(a.a,b)}
function lg(a,b){mg(a.j,b)}
function ig(a,b,c){a[b]=c}
function Of(a,b,c){b.O(hi(c))}
function Me(a,b,c){Xf(a.a,b,c)}
function lf(a,b,c){b.O(a.a[c])}
function Pe(a,b){return a.a[b]}
function Dh(a,b){return a.g=b}
function tj(){return ag(this)}
function ke(a){u.call(this,a)}
function lh(a){ng.call(this,a)}
function rh(a){ng.call(this,a)}
function yh(a){ng.call(this,a)}
function Oh(a){ng.call(this,a)}
function $h(a){ng.call(this,a)}
function De(){q(this);this.s()}
function w(){w=ae;v=new n}
function R(){R=ae;Q=new U}
function H(){H=ae;!!(Y(),X)}
function P(){D!=0&&(D=0);G=-1}
function Vd(){Td==null&&(Td=[])}
function Yf(a,b){a.splice(b,1)}
function mg(a,b){a.state=df(b)}
function bb(a,b){return te(a,b)}
function gb(a){return new Array(a)}
function Db(a){return a.l|a.m<<22}
function oe(a){ne(a);return a.k}
function pg(a,b){a.ref=b;return a}
function qg(a,b){a.href=b;return a}
function ye(a,b){this.a=a;this.b=b}
function Nf(a,b){this.a=a;this.b=b}
function Qf(a,b){this.a=a;this.b=b}
function Wf(a,b){this.b=a;this.a=b}
function $g(a,b){ye.call(this,a,b)}
function si(a,b){ye.call(this,a,b)}
function Ff(a,b){zf(a);a.a.L(b)}
function ef(a,b){while(a.M(b));}
function Xf(a,b,c){a.splice(b,0,c)}
function Kf(a,b,c){Rf(a,Uf(b,a.a,c))}
function Bg(a,b){a.value=b;return a}
function wg(a,b){a.onBlur=b;return a}
function He(a,b){a.a+=''+b;return a}
function Ye(){this.a=new $wnd.Date}
function of(a){this.b=a;this.a=16464}
function O(a){$wnd.clearTimeout(a)}
function di(a){return ei(new gi,a)}
function hi(a){return fi(di(a.b),a)}
function kb(a){return lb(a.l,a.m,a.h)}
function Sb(a){return typeof a===$i}
function Vb(a){return a==null?null:a}
function Ze(a){return a<10?'0'+a:''+a}
function Ue(a){return a.a<a.c.a.length}
function Uf(a,b,c){return Jf(a.a,b,c)}
function lb(a,b,c){return {l:a,m:b,h:c}}
function Ee(a,b){return a.charCodeAt(b)}
function ag(a){return a.$H||(a.$H=++_f)}
function eg(){eg=ae;bg=new n;dg=new n}
function ug(a,b){a.checked=b;return a}
function rg(a,b){a.onClick=b;return a}
function xg(a,b){a.onChange=b;return a}
function yg(a,b){a.onKeyDown=b;return a}
function Jf(a,b,c){a.a.N(b,c);return b}
function tg(a){a.autoFocus=true;return a}
function kg(a,b){a.j.setState(b,null)}
function Pi(a,b){a.b=b;Oe(a.a,new Wi)}
function zi(a,b){return Qe(a.a,b,0)!=-1}
function Qb(a,b){return a!=null&&Ob(a,b)}
function r(a,b){a.e=b;b!=null&&$f(b,aj,a)}
function ne(a){if(a.k!=null){return}ve(a)}
function Ve(a){a.b=a.a++;return a.c.a[a.b]}
function vg(a,b){a.defaultValue=b;return a}
function If(a,b){Bf.call(this,a);this.a=b}
function u(a){this.f=a;q(this);this.s()}
function Te(){this.a=db(pc,jj,1,0,5,1)}
function Fi(){this.a=new Te;this.b=new Te}
function Ai(a,b){Re(a.a,b);Oe(a.b,new Ji)}
function Di(a,b){Rf(b,!b.a);Oe(a.b,new Ji)}
function jg(a,b){var c;c={};c[a]=b;return c}
function Cg(a,b){a.onDoubleClick=b;return a}
function q(a){a.g&&a.e!==_i&&a.s();return a}
function Ub(a){return typeof a==='string'}
function Rb(a){return typeof a==='boolean'}
function I(a,b,c){return a.apply(b,c);var d}
function Bi(a,b,c){b.c=df(c);Oe(a.b,new Ji)}
function re(a){var b;b=qe(a);xe(a,b);return b}
function ei(a,b){ig(a.a,'key',df(b));return a}
function Ne(a,b){a.a[a.a.length]=b;return true}
function Qd(a){if(Sb(a)){return a|0}return Db(a)}
function V(a,b){!a&&(a=[]);a[a.length]=b;return a}
function jf(a,b){while(a.c<a.d){lf(a,b,a.c++)}}
function tf(a,b,c){this.c=a;this.a=b;this.b=c}
function yf(){this.a=' ';this.b='';this.c=''}
function Y(){Y=ae;var a;!$();a=new ab;X=a}
function ni(){ni=ae;li=new Fi;mi=new Si(li)}
function he(){he=ae;ge=$wnd.window.document}
function je(){u.call(this,'divide by zero')}
function $f(b,c,d){try{b[c]=d}catch(a){}}
function Lf(a,b,c){if(a.a.Q(c)){a.b=true;b.O(c)}}
function gf(a,b){ff(b,a.length);return new mf(a,b)}
function Rd(a){if(Sb(a)){return ''+a}return Eb(a)}
function df(a){if(a==null){throw Kd(new De)}return a}
function hg(){if(cg==256){bg=dg;dg=new n;cg=0}++cg}
function zf(a){if(!a.b){Af(a);a.c=true}else{zf(a.b)}}
function Ef(a,b){Af(a);return new If(a,new Mf(b,a.a))}
function Gf(a,b){Af(a);return new If(a,new Pf(b,a.a))}
function Fb(a,b){return lb(a.l^b.l,a.m^b.m,a.h^b.h)}
function Ti(a,b){return (ri(),pi)==a||(oi==a?!b.a:b.a)}
function fb(a){return Array.isArray(a)&&a.db===ee}
function Pb(a){return !Array.isArray(a)&&a.db===ee}
function cf(a,b){return Vb(a)===Vb(b)||!!a&&Vb(a)===Vb(b)}
function hf(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function mf(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function vi(a,b){this.b=df(a);this.c=df(b);this.a=false}
function Bf(a){if(!a){this.b=null;new Te}else{this.b=a}}
function jh(){ih();this.a=be(mh.prototype.ab,mh,[])}
function Yh(){Xh();this.a=be(_h.prototype.$,_h,[])}
function ih(){ih=ae;var a;hh=(a=be(kh.prototype.W,kh,[]),a)}
function oh(){oh=ae;var a;nh=(a=be(qh.prototype.W,qh,[]),a)}
function uh(){uh=ae;var a;th=(a=be(xh.prototype.W,xh,[]),a)}
function Hh(){Hh=ae;var a;Gh=(a=be(Nh.prototype.W,Nh,[]),a)}
function Xh(){Xh=ae;var a;Wh=(a=be(Zh.prototype.W,Zh,[]),a)}
function ti(){ri();return hb(bb(wd,1),jj,22,0,[oi,qi,pi])}
function Sd(a,b){return Md(Fb(Sb(a)?Pd(a):a,Sb(b)?Pd(b):b))}
function Ag(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function se(a,b){var c;c=qe(a);xe(a,c);c.e=b?8:0;return c}
function s(a,b){var c;c=oe(a.bb);return b==null?c:c+': '+b}
function te(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.u(b))}
function L(a,b,c){var d;d=J();try{return I(a,b,c)}finally{M(d)}}
function ie(a,b,c,d){a.addEventListener(b,c,(le(),d?true:false))}
function N(a){H();$wnd.setTimeout(function(){throw a},0)}
function Af(a){if(a.b){Af(a.b)}else if(a.c){throw Kd(new ze)}}
function nf(a){if(!a.d){a.d=new We(a.b);a.c=a.b.a.length}}
function ue(a){if(a.C()){return null}var b=a.j;return Yd[b]}
function ce(a){function b(){}
;b.prototype=a||{};return new b}
function t(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function zg(a){a.placeholder='What needs to be done?';return a}
function kf(a,b){if(a.c<a.d){lf(a,b,a.c++);return true}return false}
function Pf(a,b){hf.call(this,b.K(),b.J()&-6);this.a=a;this.b=b}
function Mf(a,b){hf.call(this,b.K(),b.J()&-16449);this.a=a;this.c=b}
function Ke(){u.call(this,'Add not supported on this collection')}
function Jh(a){Di((ni(),li),null!=a.j.props[qj]?a.j.props[qj]:null)}
function Lh(a){Ai((ni(),li),null!=a.j.props[qj]?a.j.props[qj]:null)}
function qf(a){return !a.a?a.c:a.e.length==0?a.a.a:a.a.a+(''+a.e)}
function bf(a,b){while(a.a<a.c.a.length){b.O((a.b=a.a++,a.c.a[a.b]))}}
function pf(a,b){!a.a?(a.a=new Je(a.d)):He(a.a,a.b);He(a.a,b);return a}
function Df(a){var b;zf(a);b=0;while(a.a.M(new Tf)){b=Ld(b,1)}return b}
function Ri(a){var b;b=a.b;!!b&&!zi(a.c,b)&&(a.b=null,Oe(a.a,new Wi))}
function Ei(a,b){Ff(new If(null,new of(a.a)),new Li(b));Oe(a.b,new Ji)}
function Cf(a,b){var c;return b.b.P(Hf(a,b.c.R(),(c=new Vf(b),c)))}
function vh(a,b){var c;c=b.target;kg(a,be(zh.prototype.V,zh,[c.value]))}
function $d(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function M(a){a&&T((R(),Q));--D;if(a){if(G!=-1){O(G);G=-1}}}
function Wb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function dh(a){return $wnd.React.createElement((ih(),hh),a.a,undefined)}
function fh(a){return $wnd.React.createElement((oh(),nh),a.a,undefined)}
function ai(a){return $wnd.React.createElement((uh(),th),a.a,undefined)}
function ji(a){return $wnd.React.createElement((Xh(),Wh),a.a,undefined)}
function K(b){H();return function(){return L(b,this,arguments);var a}}
function C(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Re(a,b){var c;c=Qe(a,b,0);if(c==-1){return false}Yf(a.a,c);return true}
function Hf(a,b,c){var d;zf(a);d=new Sf;d.a=b;a.a.L(new Wf(d,c));return d.a}
function db(a,b,c,d,e,f){var g;g=eb(e,d);e!=10&&hb(bb(a,f),b,c,e,g);return g}
function Qe(a,b,c){for(;c<a.a.length;++c){if(cf(b,a.a[c])){return c}}return -1}
function jb(a){var b,c,d;b=a&cj;c=a>>22&cj;d=a<0?dj:0;return lb(b,c,d)}
function Oe(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.O(c)}}
function Fh(a,b){var c;c=a?mj:'';if(b){c.length==0||(c+=' ');c+='editing'}return c}
function rf(a,b,c){this.b=a;this.d=b;this.e=c;this.c=this.d+(''+this.e)}
function Zf(a,b){return cb(b)!=10&&hb(o(b),b.cb,b.__elementTypeId$,cb(b),a),a}
function cb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Tb(a){return a!=null&&(typeof a===Zi||typeof a==='function')&&!(a.db===ee)}
function Kb(){Kb=ae;Gb=lb(cj,cj,524287);Hb=lb(0,0,ej);Ib=jb(1);jb(2);Jb=jb(0)}
function Jd(a){var b;if(Qb(a,5)){return a}b=a&&a[aj];if(!b){b=new B(a);Z(b)}return b}
function xe(a,b){var c;if(!a){return}b.j=a;var d=ue(b);if(!d){Yd[a]=[b];return}d.bb=b}
function be(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function qe(a){var b;b=new pe;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Be(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function T(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=W(b,c)}while(a.b);a.b=c}}
function S(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=W(b,c)}while(a.a);a.a=c}}
function wi(a,b){Ne(a.a,new vi(''+Rd(Nd((new Ye).a.getTime())),b));Oe(a.b,new Ji)}
function fi(a,b){ig(a.a,qj,b);return $wnd.React.createElement((Hh(),Gh),a.a,undefined)}
function Nd(a){if(hj<a&&a<fj){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Md(xb(a))}
function Md(a){var b;b=a.h;if(b==0){return a.l+a.m*gj}if(b==dj){return a.l+a.m*gj-fj}return a}
function Pd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=fj;d=dj}c=Wb(e/gj);b=Wb(e-c*gj);return lb(b,c,d)}
function Ce(a,b){var c,d;for(d=new We(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Ai(b.a,c)}}
function Ud(){Vd();var a=Td;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ze(){u.call(this,"Stream already terminated, can't be modified or used")}
function wj(){$wnd.ReactDOM.render(ji(new ki),(he(),ge).getElementById(ij),null)}
function ng(a){$wnd.React.Component.call(this,a);this.a=this.X();this.a.j=df(this);this.a.T()}
function wh(){uh();this.b=be(Ah.prototype._,Ah,[this]);this.a=be(Bh.prototype.$,Bh,[this])}
function Xd(a,b){typeof window===Zi&&typeof window['$gwt']===Zi&&(window['$gwt'][a]=b)}
function ff(a,b){if(0>a||a>b){throw Kd(new ke('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function xi(a){Cf(Ef(new If(null,new of(a.a)),new Hi),new tf(new wf,new vf,new sf)).D(new Ii(a))}
function yi(a){return Qd(Df(new If(null,new of(a.a))))-Qd(Df(Ef(new If(null,new of(a.a)),new Ki)))}
function ri(){ri=ae;oi=new si('ACTIVE',0);qi=new si('COMPLETED',1);pi=new si('ALL',2)}
function vb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return lb(c&cj,d&cj,e&dj)}
function Cb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return lb(c&cj,d&cj,e&dj)}
function yb(a){var b,c,d;b=~a.l+1&cj;c=~a.m+(b==0?1:0)&cj;d=~a.h+(b==0&&c==0?1:0)&dj;return lb(b,c,d)}
function rb(a){var b,c,d;b=~a.l+1&cj;c=~a.m+(b==0?1:0)&cj;d=~a.h+(b==0&&c==0?1:0)&dj;a.l=b;a.m=c;a.h=d}
function sb(a){var b,c;c=Ae(a.h);if(c==32){b=Ae(a.m);return b==32?Ae(a.l)+32:b+20-10}else{return c-12}}
function ob(a,b,c,d,e){var f;f=Ab(a,b);c&&rb(f);if(e){a=qb(a,b);d?(ib=yb(a)):(ib=lb(a.l,a.m,a.h))}return f}
function hb(a,b,c,d,e){e.bb=a;e.cb=b;e.db=ee;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function og(a,b){a.className=Cf(Ef(new If(null,gf(b,b.length)),new sg),new tf(new yf,new xf,new uf));return a}
function nb(a,b){if(a.h==ej&&a.m==0&&a.l==0){b&&(ib=lb(0,0,0));return kb((Kb(),Ib))}b&&(ib=lb(a.l,a.m,a.h));return lb(0,0,0)}
function de(a){var b;if(Array.isArray(a)&&a.db===ee){return oe(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function Ld(a,b){var c;if(Sb(a)&&Sb(b)){c=a+b;if(hj<c&&c<fj){return c}}return Md(vb(Sb(a)?Pd(a):a,Sb(b)?Pd(b):b))}
function o(a){return Ub(a)?sc:Sb(a)?hc:Rb(a)?fc:Pb(a)?a.bb:fb(a)?a.bb:a.bb||Array.isArray(a)&&bb(Yb,1)||Yb}
function p(a){return Ub(a)?gg(a):Sb(a)?Wb(a):Rb(a)?a?1231:1237:Pb(a)?a.o():fb(a)?ag(a):!!a&&!!a.hashCode?a.hashCode():ag(a)}
function B(a){w();q(this);this.e=a;a!=null&&$f(a,aj,this);this.f=a==null?'null':de(a);this.a='';this.b=a;this.a=''}
function pe(){this.g=me++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function gg(a){eg();var b,c,d;c=':'+a;d=dg[c];if(d!=null){return Wb(d)}d=bg[c];b=d==null?fg(a):Wb(d);hg();dg[c]=b;return b}
function Xe(a){var b,c,d;d=1;for(c=new We(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function Se(a,b){var c,d;d=a.a.length;b.length<d&&(b=Zf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function we(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function _g(){Zg();return hb(bb(_c,1),jj,6,0,[Dg,Eg,Fg,Gg,Hg,Ig,Jg,Kg,Lg,Mg,Ng,Og,Pg,Qg,Rg,Sg,Tg,Ug,Vg,Wg,Xg,Yg])}
function J(){var a;if(D!=0){a=C();if(a-F>2000){F=a;G=$wnd.setTimeout(P,10)}}if(D++==0){S((R(),Q));return true}return false}
function $(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Ch(a,b){var c;if((ni(),mi).b==(null!=a.j.props[qj]?a.j.props[qj]:null)){c=b.target;kg(a,be(Ph.prototype.V,Ph,[c.value]))}}
function Kh(a){Pi((ni(),mi),null!=a.j.props[qj]?a.j.props[qj]:null);kg(a,be(Ph.prototype.V,Ph,[(null!=a.j.props[qj]?a.j.props[qj]:null).c]))}
function Ih(a,b){27==b.which?(kg(a,be(Ph.prototype.V,Ph,[(null!=a.j.props[qj]?a.j.props[qj]:null).c])),Pi((ni(),mi),null)):13==b.which&&Eh(a)}
function Si(a){this.a=new Te;this.c=df(a);ie((he(),$wnd.window.window),'hashchange',new Ui(this),false);Ci(a,be(Vi.prototype.Y,Vi,[this]))}
function sh(a,b){var c;if(13==b.keyCode){b.preventDefault();c=Ge(a.j.state[oj]);if(c.length>0){wi((ni(),li),c);kg(a,be(zh.prototype.V,zh,['']))}}}
function Ob(a,b){if(Ub(a)){return !!Nb[b]}else if(a.cb){return !!a.cb[b]}else if(Sb(a)){return !!Mb[b]}else if(Rb(a)){return !!Lb[b]}return false}
function fe(){Ci((ni(),li),be(ah.prototype.Y,ah,[]));Qi(mi,be(bh.prototype.Y,bh,[]));$wnd.ReactDOM.render(ji(new ki),(he(),ge).getElementById(ij),null)}
function Ge(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function qb(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return lb(c,d,e)}
function zb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return lb(c&cj,d&cj,e&dj)}
function Bb(a,b){var c,d,e,f;b&=63;c=a.h&dj;if(b<22){f=c>>>b;e=a.m>>b|c<<22-b;d=a.l>>b|a.m<<22-b}else if(b<44){f=0;e=c>>>b-22;d=a.m>>b-22|a.h<<44-b}else{f=0;e=0;d=c>>>b-44}return lb(d&cj,e&cj,f&dj)}
function eb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function ub(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&cj;a.m=d&cj;a.h=e&dj;return true}
function Ni(a,b){var c,d;b.preventDefault();c=(d=(he(),$wnd.window.window).location.hash,null==d?'':d.substr(1));Fe(lj,c)||Fe(mj,c)||Fe('',c)?Oe(a.a,new Wi):Oi()}
function wb(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Wd(b,c,d,e){Vd();var f=Td;$moduleName=c;$moduleBase=d;Id=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Yi(g)()}catch(a){b(c,a)}}else{Yi(g)()}}
function af(){af=ae;$e=hb(bb(sc,1),jj,2,6,['Sun','Mon','Tue','Wed','Thu','Fri','Sat']);_e=hb(bb(sc,1),jj,2,6,['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])}
function W(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].eb()&&(c=V(c,g)):g[0].eb()}catch(a){a=Jd(a);if(Qb(a,5)){d=a;H();N(Qb(d,24)?d.t():d)}else throw Kd(a)}}return c}
function Zd(){Yd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function A(a){var b;if(a.c==null){b=Vb(a.b)===Vb(v)?null:a.b;a.d=b==null?'null':Tb(b)?b==null?null:b.name:Ub(b)?'String':oe(o(b));a.a=a.a+': '+(Tb(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function fg(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ee(a,c++)}b=b|0;return b}
function Eh(a){var b;b=a.j.state[rj];if(b.length!=0){Bi((ni(),li),null!=a.j.props[qj]?a.j.props[qj]:null,b);Pi(mi,null);kg(a,be(Ph.prototype.V,Ph,[b]))}else{Ai((ni(),li),null!=a.j.props[qj]?a.j.props[qj]:null)}}
function Oi(){var a;if(0==''.length){a=(he(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',ge.title,a)}else{(he(),$wnd.window.window).location.hash=''}}
function Ae(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Ab(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&ej)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?dj:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?dj:0;f=d?cj:0;e=c>>b-44}return lb(e&cj,f&cj,g&dj)}
function _d(a,b,c){var d=Yd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Yd[b]),ce(h));_.cb=c;!b&&(_.db=ee);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.bb=f)}
function Mh(){Hh();this.b=be(Qh.prototype._,Qh,[this]);this.e=be(Rh.prototype.Z,Rh,[this]);this.f=be(Sh.prototype.$,Sh,[this]);this.d=be(Th.prototype.ab,Th,[this]);this.c=be(Uh.prototype.ab,Uh,[this]);this.a=be(Vh.prototype.$,Vh,[this])}
function ve(a){if(a.B()){var b=a.c;b.C()?(a.k='['+b.j):!b.B()?(a.k='[L'+b.w()+';'):(a.k='['+b.w());a.b=b.v()+'[]';a.i=b.A()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=we('.',[c,we('$',d)]);a.b=we('.',[c,we('.',d)]);a.i=d[d.length-1]}
function Mi(a){var b,c,d;b=(d=(c=(he(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),Fe(lj,d)||Fe(mj,d)||Fe('',d)?Fe(lj,d)?(ri(),oi):Fe(mj,d)?(ri(),qi):(ri(),pi):(ri(),pi));return Cf(Ef(new If(null,new of(a.c.a)),new Xi(b)),new tf(new wf,new vf,new sf))}
function tb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return Be(c)}if(b==0&&d!=0&&c==0){return Be(d)+22}if(b!=0&&d==0&&c==0){return Be(b)+44}return -1}
function xb(a){var b,c,d,e,f;if(isNaN(a)){return Kb(),Jb}if(a<-9223372036854775808){return Kb(),Hb}if(a>=9223372036854775807){return Kb(),Gb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=fj){d=Wb(a/fj);a-=d*fj}c=0;if(a>=gj){c=Wb(a/gj);a-=c*gj}b=Wb(a);f=lb(b,c,d);e&&rb(f);return f}
function Eb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==ej&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Eb(yb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=jb(1000000000);c=mb(c,e,true);b=''+Db(ib);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function pb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=sb(b)-sb(a);g=zb(b,j);i=lb(0,0,0);while(j>=0){h=ub(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&rb(i);if(f){if(d){ib=yb(a);e&&(ib=Cb(ib,(Kb(),Ib)))}else{ib=lb(a.l,a.m,a.h)}}return i}
function Zg(){Zg=ae;Dg=new $g(kj,0);Eg=new $g('checkbox',1);Fg=new $g('color',2);Gg=new $g('date',3);Hg=new $g('datetime',4);Ig=new $g('email',5);Jg=new $g('file',6);Kg=new $g('hidden',7);Lg=new $g('image',8);Mg=new $g('month',9);Ng=new $g($i,10);Og=new $g('password',11);Pg=new $g('radio',12);Qg=new $g('range',13);Rg=new $g('reset',14);Sg=new $g('search',15);Tg=new $g('submit',16);Ug=new $g('tel',17);Vg=new $g('text',18);Wg=new $g('time',19);Xg=new $g('url',20);Yg=new $g('week',21)}
function mb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Kd(new je)}if(a.l==0&&a.m==0&&a.h==0){c&&(ib=lb(0,0,0));return lb(0,0,0)}if(b.h==ej&&b.m==0&&b.l==0){return nb(a,c)}i=false;if(b.h>>19!=0){b=yb(b);i=true}g=tb(b);f=false;e=false;d=false;if(a.h==ej&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=kb((Kb(),Gb));d=true;i=!i}else{h=Ab(a,g);i&&rb(h);c&&(ib=lb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=yb(a);d=true;i=!i}if(g!=-1){return ob(a,g,i,f,c)}if(wb(a,b)<0){c&&(f?(ib=yb(a)):(ib=lb(a.l,a.m,a.h)));return lb(0,0,0)}return pb(d?a:lb(a.l,a.m,a.h),b,i,f,e,c)}
var Zi='object',$i='number',_i='__noinit__',aj='__java$exception',bj={3:1,7:1,5:1},cj=4194303,dj=1048575,ej=524288,fj=17592186044416,gj=4194304,hj=-17592186044416,ij='todoapp',jj={3:1,4:1},kj='button',lj='active',mj='completed',nj='selected',oj='todoText',pj='input',qj='todo',rj='editText',sj='header';var _,Yd,Td,Id=-1;Zd();_d(1,null,{},n);_.n=function(){return this.bb};_.o=tj;_.p=function(){var a;return oe(o(this))+'@'+(a=p(this)>>>0,a.toString(16))};_.hashCode=function(){return this.o()};_.toString=function(){return this.p()};var Lb,Mb,Nb;_d(36,1,{},pe);_.u=function(a){var b;b=new pe;b.e=4;a>1?(b.c=te(this,a-1)):(b.c=this);return b};_.v=function(){ne(this);return this.b};_.w=function(){return oe(this)};_.A=function(){ne(this);return this.i};_.B=function(){return (this.e&4)!=0};_.C=function(){return (this.e&1)!=0};_.p=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(ne(this),this.k)};_.e=0;_.g=0;var me=1;var pc=re(1);var gc=re(36);_d(5,1,{3:1,5:1});_.q=function(a){return new Error(a)};_.r=function(){return this.f};_.s=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=oe(this.bb),c==null?a:a+': '+c);r(this,t(this.q(b)));Z(this)};_.p=function(){return s(this,this.r())};_.e=_i;_.g=true;var tc=re(5);_d(27,5,{3:1,5:1});var jc=re(27);_d(7,27,bj);var qc=re(7);_d(37,7,bj);var mc=re(37);_d(48,37,bj);var $b=re(48);_d(24,48,{24:1,3:1,7:1,5:1},B);_.r=function(){A(this);return this.c};_.t=function(){return Vb(this.b)===Vb(v)?null:this.b};var v;var Xb=re(24);var Yb=re(0);_d(100,1,{});var Zb=re(100);var D=0,F=0,G=-1;_d(64,100,{},U);var Q;var _b=re(64);var X;_d(113,1,{});var bc=re(113);_d(49,113,{},ab);var ac=re(49);var ib;var Gb,Hb,Ib,Jb;var ge;_d(46,1,{44:1});_.p=vj;var cc=re(46);_d(61,7,bj,je);var dc=re(61);_d(51,7,bj);var lc=re(51);_d(84,51,bj,ke);var ec=re(84);Lb={3:1,18:1};var fc=re(110);_d(111,1,{3:1});var oc=re(111);Mb={3:1,18:1};var hc=re(112);_d(20,1,{3:1,18:1,20:1});_.o=tj;_.p=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ic=re(20);_d(50,7,bj,ze);var kc=re(50);_d(175,1,{});_d(60,37,bj,De);_.q=function(a){return new TypeError(a)};var nc=re(60);Nb={3:1,44:1,18:1,2:1};var sc=re(2);_d(47,46,{44:1},Je);var rc=re(47);_d(179,1,{});_d(59,7,bj,Ke);var uc=re(59);_d(114,1,{97:1});_.D=function(a){Ce(this,a)};_.F=function(a){throw Kd(new Ke)};_.p=function(){var a,b,c;c=new rf(', ','[',']');for(b=this.G();b.H();){a=b.I();pf(c,a===this?'(this Collection)':a==null?'null':de(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var vc=re(114);_d(115,114,{97:1,122:1});_.F=function(a){Me(this,this.a.length,a);return true};_.o=function(){return Xe(this)};_.G=function(){return new Le(this)};var xc=re(115);_d(62,1,{},Le);_.H=function(){return this.a<this.b.a.length};_.I=function(){return Pe(this.b,this.a++)};_.a=0;var wc=re(62);_d(11,115,{3:1,11:1,97:1,122:1},Te);_.F=function(a){return Ne(this,a)};_.D=function(a){Oe(this,a)};_.G=function(){return new We(this)};var zc=re(11);_d(15,1,{},We);_.H=function(){return Ue(this)};_.I=function(){return Ve(this)};_.a=0;_.b=-1;var yc=re(15);_d(33,1,{3:1,18:1,33:1},Ye);_.o=function(){var a;a=Nd(this.a.getTime());return Qd(Sd(a,Md(Bb(Sb(a)?Pd(a):a,32))))};_.p=function(){var a,b,c;c=-this.a.getTimezoneOffset();a=(c>=0?'+':'')+(c/60|0);b=Ze($wnd.Math.abs(c)%60);return (af(),$e)[this.a.getDay()]+' '+_e[this.a.getMonth()]+' '+Ze(this.a.getDate())+' '+Ze(this.a.getHours())+':'+Ze(this.a.getMinutes())+':'+Ze(this.a.getSeconds())+' GMT'+a+b+' '+this.a.getFullYear()};var Ac=re(33);var $e,_e;_d(74,1,{});_.L=uj;_.J=function(){return this.d};_.K=function(){return this.e};_.d=0;_.e=0;var Ec=re(74);_d(40,74,{});var Bc=re(40);_d(65,1,{});_.L=uj;_.J=function(){return this.b};_.K=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Dc=re(65);_d(66,65,{},mf);_.L=function(a){jf(this,a)};_.M=function(a){return kf(this,a)};var Cc=re(66);_d(10,1,{},of);_.J=vj;_.K=function(){nf(this);return this.c};_.L=function(a){nf(this);bf(this.d,a)};_.M=function(a){nf(this);if(Ue(this.d)){a.O(Ve(this.d));return true}return false};_.a=0;_.c=0;var Fc=re(10);_d(28,1,{28:1},rf);_.p=function(){return qf(this)};var Gc=re(28);_d(32,1,{},sf);_.P=function(a){return a};var Hc=re(32);_d(25,1,{},tf);var Ic=re(25);_d(69,1,{},uf);_.P=function(a){return qf(a)};var Jc=re(69);_d(30,1,{},vf);_.N=function(a,b){a.F(b)};var Kc=re(30);_d(31,1,{},wf);_.R=function(){return new Te};var Lc=re(31);_d(68,1,{},xf);_.N=function(a,b){pf(a,b)};var Mc=re(68);_d(67,1,{},yf);_.R=function(){return new rf(this.a,this.b,this.c)};var Nc=re(67);_d(73,1,{});_.c=false;var Xc=re(73);_d(9,73,{},If);var Wc=re(9);_d(76,40,{},Mf);_.M=function(a){this.b=false;while(!this.b&&this.c.M(new Nf(this,a)));return this.b};_.b=false;var Pc=re(76);_d(79,1,{},Nf);_.O=function(a){Lf(this.a,this.b,a)};var Oc=re(79);_d(75,40,{},Pf);_.M=function(a){return this.b.M(new Qf(this,a))};var Rc=re(75);_d(78,1,{},Qf);_.O=function(a){Of(this.a,this.b,a)};var Qc=re(78);_d(77,1,{},Sf);_.O=function(a){Rf(this,a)};var Sc=re(77);_d(80,1,{},Tf);_.O=function(a){};var Tc=re(80);_d(81,1,{},Vf);var Uc=re(81);_d(82,1,{},Wf);_.O=function(a){Kf(this.b,this.a,a)};var Vc=re(82);_d(177,1,{});_d(174,1,{});var _f=0;var bg,cg=0,dg;_d(554,1,{});_d(651,1,{});_d(116,1,{});_.S=function(a,b){};_.T=function(){};var Yc=re(116);_d(21,$wnd.React.Component,{});$d(Yd[1],_);_.render=function(){return this.a.U()};var Zc=re(21);_d(63,1,{},sg);_.Q=function(a){return a!=null};var $c=re(63);_d(6,20,{3:1,18:1,20:1,6:1},$g);var Dg,Eg,Fg,Gg,Hg,Ig,Jg,Kg,Lg,Mg,Ng,Og,Pg,Qg,Rg,Sg,Tg,Ug,Vg,Wg,Xg,Yg;var _c=se(6,_g);_d(126,$wnd.Function,{43:1},ah);_.Y=wj;_d(127,$wnd.Function,{43:1},bh);_.Y=wj;_d(119,116,{});_.U=function(){var a,b,c;a=(ni(),c=(b=(he(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),Fe(lj,c)||Fe(mj,c)||Fe('',c)?Fe(lj,c)?(ri(),oi):Fe(mj,c)?(ri(),qi):(ri(),pi):(ri(),pi));return $wnd.React.createElement('footer',og(new $wnd.Object,hb(bb(sc,1),jj,2,6,['footer'])),fh(new gh),$wnd.React.createElement('ul',og(new $wnd.Object,hb(bb(sc,1),jj,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',qg(og(new $wnd.Object,hb(bb(sc,1),jj,2,6,[(ri(),pi)==a?nj:''])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',qg(og(new $wnd.Object,hb(bb(sc,1),jj,2,6,[oi==a?nj:''])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',qg(og(new $wnd.Object,hb(bb(sc,1),jj,2,6,[qi==a?nj:''])),'#completed'),'Completed'))),yi(li)>0?$wnd.React.createElement(kj,rg(og(new $wnd.Object,hb(bb(sc,1),jj,2,6,['clear-completed'])),this.a),'Clear Completed'):null)};var dd=re(119);_d(86,1,{},eh);var ad=re(86);_d(121,116,{});_.U=function(){var a,b;b=Qd(Df(new If(null,new of((ni(),li).a))));a='item'+(b==1?'':'s');return $wnd.React.createElement('span',og(new $wnd.Object,hb(bb(sc,1),jj,2,6,['todo-count'])),$wnd.React.createElement('strong',null,''+b),' '+a+' left')};var cd=re(121);_d(94,1,{},gh);var bd=re(94);_d(89,119,{},jh);var hh;var hd=re(89);_d(148,$wnd.Function,{},kh);_.W=function(a){return new lh(a)};_d(90,21,{},lh);_.X=function(){return new jh};var ed=re(90);_d(149,$wnd.Function,{},mh);_.ab=function(a){xi((ni(),li))};_d(95,121,{},ph);var nh;var gd=re(95);_d(159,$wnd.Function,{},qh);_.W=function(a){return new rh(a)};_d(96,21,{},rh);_.X=function(){return new ph};var fd=re(96);_d(118,116,{});_.T=function(){lg(this,jg(oj,''))};_.U=function(){return $wnd.React.createElement(pj,tg(xg(yg(Bg(zg(og(new $wnd.Object,hb(bb(sc,1),jj,2,6,['new-todo']))),this.j.state[oj]),this.b),this.a)))};var qd=re(118);_d(87,118,{},wh);var th;var kd=re(87);_d(145,$wnd.Function,{},xh);_.W=function(a){return new yh(a)};_d(88,21,{},yh);_.X=function(){return new wh};var jd=re(88);_d(124,$wnd.Function,{},zh);_.V=function(a,b){return uh(),jg(oj,this.a)};_d(146,$wnd.Function,{},Ah);_._=function(a){sh(this.a,a)};_d(147,$wnd.Function,{},Bh);_.$=function(a){vh(this.a,a)};_d(120,116,{});_.S=function(a,b){var c;c=(ni(),mi).b==(null!=this.j.props[qj]?this.j.props[qj]:null);if(!this.i&&c){this.i=true;kg(this,be(Ph.prototype.V,Ph,[(null!=this.j.props[qj]?this.j.props[qj]:null).c]));this.g.focus();this.g.select()}else this.i&&!c&&(this.i=false)};_.T=function(){lg(this,jg(rj,(null!=this.j.props[qj]?this.j.props[qj]:null).c))};_.U=function(){var a,b;b=null!=this.j.props[qj]?this.j.props[qj]:null;a=b.a;return $wnd.React.createElement('li',og(new $wnd.Object,hb(bb(sc,1),jj,2,6,[Fh(a,(ni(),mi).b==(null!=this.j.props[qj]?this.j.props[qj]:null))])),$wnd.React.createElement('div',og(new $wnd.Object,hb(bb(sc,1),jj,2,6,['view'])),$wnd.React.createElement(pj,xg(ug(Ag(og(new $wnd.Object,hb(bb(sc,1),jj,2,6,['toggle'])),(Zg(),Eg)),a),this.f)),$wnd.React.createElement('label',Cg(new $wnd.Object,this.d),b.c),$wnd.React.createElement(kj,rg(og(new $wnd.Object,hb(bb(sc,1),jj,2,6,['destroy'])),this.c))),$wnd.React.createElement(pj,yg(xg(wg(vg(og(pg(new $wnd.Object,be(ci.prototype.O,ci,[this])),hb(bb(sc,1),jj,2,6,['edit'])),this.j.state[rj]),this.e),this.a),this.b)))};_.i=false;var sd=re(120);_d(92,120,{},Mh);var Gh;var md=re(92);_d(150,$wnd.Function,{},Nh);_.W=function(a){return new Oh(a)};_d(93,21,{},Oh);_.X=function(){return new Mh};_.componentDidUpdate=function(a,b){this.a.S(a,b)};var ld=re(93);_d(35,$wnd.Function,{},Ph);_.V=function(a,b){return Hh(),jg(rj,this.a)};_d(151,$wnd.Function,{},Qh);_._=function(a){Ih(this.a,a)};_d(152,$wnd.Function,{},Rh);_.Z=function(a){Eh(this.a)};_d(153,$wnd.Function,{},Sh);_.$=function(a){Jh(this.a)};_d(154,$wnd.Function,{},Th);_.ab=function(a){Kh(this.a)};_d(155,$wnd.Function,{},Uh);_.ab=function(a){Lh(this.a)};_d(156,$wnd.Function,{},Vh);_.$=function(a){Ch(this.a,a)};_d(117,116,{});_.U=function(){var a;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(sj,og(new $wnd.Object,hb(bb(sc,1),jj,2,6,[sj])),$wnd.React.createElement('h1',null,'todos'),ai(new bi)),0!=Qd(Df(new If(null,new of((ni(),li).a))))?$wnd.React.createElement('section',og(new $wnd.Object,hb(bb(sc,1),jj,2,6,[sj])),$wnd.React.createElement(pj,xg(Ag(og(new $wnd.Object,hb(bb(sc,1),jj,2,6,['toggle-all'])),(Zg(),Eg)),this.a)),$wnd.React.createElement.apply(null,['ul',og(new $wnd.Object,hb(bb(sc,1),jj,2,6,['todo-list']))].concat((a=Cf(Gf(new If(null,new of(Mi(mi))),new ii),new tf(new wf,new vf,new sf)),Se(a,gb(a.a.length)))))):null,0!=Qd(Df(new If(null,new of(li.a))))?dh(new eh):null))};var vd=re(117);_d(70,117,{},Yh);var Wh;var od=re(70);_d(143,$wnd.Function,{},Zh);_.W=function(a){return new $h(a)};_d(71,21,{},$h);_.X=function(){return new Yh};var nd=re(71);_d(144,$wnd.Function,{},_h);_.$=function(a){var b;b=a.target;Ei((ni(),li),b.checked)};_d(85,1,{},bi);var pd=re(85);_d(158,$wnd.Function,{},ci);_.O=function(a){Dh(this.a,a)};_d(91,1,{},gi);var rd=re(91);_d(72,1,{},ii);_.P=function(a){return hi(a)};var td=re(72);_d(26,1,{},ki);var ud=re(26);var li,mi;_d(22,20,{3:1,18:1,20:1,22:1},si);var oi,pi,qi;var wd=se(22,ti);_d(39,1,{39:1},vi);_.a=false;var Dd=re(39);_d(38,1,{38:1},Fi);var Cd=re(38);_d(54,1,{},Hi);_.Q=function(a){return a.a};var xd=re(54);_d(55,1,{},Ii);_.O=function(a){Ai(this.a,a)};var yd=re(55);_d(19,1,{},Ji);_.O=xj;var zd=re(19);_d(52,1,{},Ki);_.Q=function(a){return !a.a};var Ad=re(52);_d(53,1,{},Li);_.O=function(a){Gi(this.a,a)};_.a=false;var Bd=re(53);_d(56,1,{},Si);var Hd=re(56);_d(57,1,{},Ui);_.handleEvent=function(a){Ni(this.a,a)};var Ed=re(57);_d(132,$wnd.Function,{43:1},Vi);_.Y=function(){Ri(this.a)};_d(29,1,{},Wi);_.O=xj;var Fd=re(29);_d(58,1,{},Xi);_.Q=function(a){return Ti(this.a,a)};var Gd=re(58);var Yi=(H(),K);var gwtOnLoad=gwtOnLoad=Wd;Ud(fe);Xd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();