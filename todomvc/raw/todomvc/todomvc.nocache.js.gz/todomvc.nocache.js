function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='FA7458BB907455E0944339266DFB2336',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'FA7458BB907455E0944339266DFB2336';function n(){}
function s(){}
function Y(){}
function Zd(){}
function Vd(){}
function eb(){}
function eh(){}
function ih(){}
function mh(){}
function Dh(){}
function Rh(){}
function jf(){}
function kf(){}
function ug(){}
function vg(){}
function Ug(){}
function Xg(){}
function _g(){}
function bi(){}
function di(){}
function ei(){}
function qi(){}
function Pi(a){a()}
function cb(a){bb()}
function v(a){Oe(a)}
function u(){new He}
function de(){de=Vd}
function hf(a,b){a.a=b}
function gf(a){this.a=a}
function lf(a){this.a=a}
function qh(a){this.a=a}
function rh(a){this.a=a}
function th(a){this.a=a}
function uh(a){this.a=a}
function vh(a){this.a=a}
function wh(a){this.a=a}
function xh(a){this.a=a}
function yh(a){this.a=a}
function zh(a){this.a=a}
function Ah(a){this.a=a}
function ci(a){this.a=a}
function fi(a){this.a=a}
function oi(a){this.a=a}
function pi(a){this.a=a}
function ri(a){this.a=a}
function Ke(a){this.c=a}
function Bf(a,b){a.key=b}
function Af(a,b){zf(a,b)}
function Ph(a,b){Ce(a.c,b)}
function Yh(a,b){Ce(a.b,b)}
function ki(a,b){Ce(a.a,b)}
function Ig(a,b){return a.a=b}
function ye(a,b){return a===b}
function Ed(a){return a.b}
function Oi(a){return false}
function Mi(){return rf(this)}
function we(){w(this);this.q()}
function r(){r=Vd;new q}
function F(){F=Vd;D=new n}
function V(){V=Vd;U=new Y}
function L(){L=Vd;!!(bb(),ab)}
function T(){I!=0&&(I=0);K=-1}
function Od(){Md==null&&(Md=[])}
function nf(a,b){a.splice(b,1)}
function fb(a,b){return me(a,b)}
function kb(a){return new Array(a)}
function Gb(a){return a.l|a.m<<22}
function ge(a){fe(a);return a.k}
function af(a,b){a.C(b);return a}
function Kf(a,b){a.ref=b;return a}
function Lf(a,b){a.href=b;return a}
function ef(a,b){this.a=a;this.b=b}
function If(a,b){this.a=a;this.b=b}
function re(a,b){this.a=a;this.b=b}
function sg(a,b){re.call(this,a,b)}
function Ye(a,b){Te(a);a.a.G(b)}
function bf(a,b){hf(a,af(a.a,b))}
function Be(a,b,c){mf(a.a,b,c)}
function Pe(a,b){while(a.H(b));}
function mf(a,b,c){a.splice(b,0,c)}
function Mh(a,b){re.call(this,a,b)}
function Vf(a,b){a.value=b;return a}
function Qf(a,b){a.onBlur=b;return a}
function S(a){$wnd.clearTimeout(a)}
function Se(a){this.b=a;this.a=16464}
function xg(a){this.d=Oe(a);r();++wg}
function zg(a){this.d=Oe(a);r();++yg}
function Fg(a){this.d=Oe(a);r();++Eg}
function Tg(a){this.d=Oe(a);r();++Sg}
function Vg(){this.a=Cf((Zg(),Yg))}
function Wg(){this.a=Cf((bh(),ah))}
function sh(){this.a=Cf((gh(),fh))}
function Ch(){this.a=Cf((kh(),jh))}
function Eh(){this.a=Cf((oh(),nh))}
function He(){this.a=hb(tc,ui,1,0,5,1)}
function ob(a){return pb(a.l,a.m,a.h)}
function Ie(a){return a.a<a.c.a.length}
function Ub(a){return typeof a===ti}
function Wb(a){return a==null?null:a}
function pb(a,b,c){return {l:a,m:b,h:c}}
function xe(a,b){return a.charCodeAt(b)}
function rf(a){return a.$H||(a.$H=++qf)}
function Oh(a,b){a.a=b;De(a.c,new Rh)}
function ai(a,b){b.a=a;De(b.c,new Rh)}
function ji(a,b){a.b=b;De(a.a,new qi)}
function Vh(a,b){return Ee(a.a,b,0)!=-1}
function Sb(a,b){return a!=null&&Qb(a,b)}
function zf(a,b){for(var c in a){b(c)}}
function Mf(a,b){a.onClick=b;return a}
function Rf(a,b){a.onChange=b;return a}
function Of(a,b){a.checked=b;return a}
function Sf(a,b){a.onKeyDown=b;return a}
function Nf(a){a.autoFocus=true;return a}
function fe(a){if(a.k!=null){return}oe(a)}
function A(a,b){a.b=b;b!=null&&pf(b,wi,a)}
function Pg(a,b){a.b=b;a.d.forceUpdate()}
function Dg(a,b){a.a=b;a.d.forceUpdate()}
function Wh(a,b){Fe(a.a,b);De(a.b,new di)}
function Zh(a,b){Oh(b,!b.a);De(a.b,new di)}
function _h(){this.a=new He;this.b=new He}
function vf(){vf=Vd;sf=new n;uf=new n}
function ae(){ae=Vd;_d=$wnd.window.document}
function Je(a){a.b=a.a++;return a.c.a[a.b]}
function Pf(a,b){a.defaultValue=b;return a}
function Wf(a,b){a.onDoubleClick=b;return a}
function w(a){a.d&&a.b!==vi&&a.q();return a}
function C(a){this.c=a;w(this);this.q()}
function _e(a,b){Ve.call(this,a);this.a=b}
function ce(){C.call(this,'divide by zero')}
function Tb(a){return typeof a==='boolean'}
function Vb(a){return typeof a==='string'}
function M(a,b,c){return a.apply(b,c);var d}
function pf(b,c,d){try{b[c]=d}catch(a){}}
function be(a,b,c,d){a.addEventListener(b,c,d)}
function Ce(a,b){a.a[a.a.length]=b;return true}
function je(a){var b;b=ie(a);qe(a,b);return b}
function Ag(a,b){var c;c=b.target;Dg(a,c.value)}
function bb(){bb=Vd;var a;!db();a=new eb;ab=a}
function Hh(){Hh=Vd;Fh=new _h;Gh=new mi(Fh)}
function q(){this.a=new t;new v(this.a);new u}
function Z(a,b){!a&&(a=[]);a[a.length]=b;return a}
function le(a){var b;b=ie(a);b.j=a;b.e=1;return b}
function Kd(a){if(Ub(a)){return a|0}return Gb(a)}
function Ld(a){if(Ub(a)){return ''+a}return Hb(a)}
function Ze(a){Ue(a);return new _e(a,new ff(a.a))}
function Te(a){if(!a.b){Ue(a);a.c=true}else{Te(a.b)}}
function cf(a,b,c){if(a.a.J(c)){a.b=true;b.I(c)}}
function Jg(a){Wh((Hh(),Fh),a.d.props['a'])}
function Mg(a){Zh((Hh(),Fh),a.d.props['a'])}
function ff(a){Qe.call(this,a.F(),a.D()&-6);this.a=a}
function Ve(a){if(!a){this.b=null;new He}else{this.b=a}}
function Oe(a){if(a==null){throw Ed(new we)}return a}
function yf(){if(tf==256){sf=uf;uf=new n;tf=0}++tf}
function jb(a){return Array.isArray(a)&&a.T===Zd}
function Rb(a){return !Array.isArray(a)&&a.T===Zd}
function ni(a,b){return (Lh(),Jh)==a||(Ih==a?!b.a:b.a)}
function Ne(a,b){return Wb(a)===Wb(b)||!!a&&Wb(a)===Wb(b)}
function Qe(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Uf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ke(a,b){var c;c=ie(a);qe(a,c);c.e=b?8:0;return c}
function Re(a){if(!a.d){a.d=new Ke(a.b);a.c=a.b.a.length}}
function Xe(a,b){Ue(a);return new _e(a,new df(b,a.a))}
function Xh(a,b,c){b.d=Oe(c);De(b.c,new Rh);De(a.b,new di)}
function ne(a){if(a.A()){return null}var b=a.j;return Rd[b]}
function Xd(a){function b(){}
;b.prototype=a||{};return new b}
function gh(){gh=Vd;var a;fh=(a=Wd(eh.prototype.Q,eh,[]),a)}
function kh(){kh=Vd;var a;jh=(a=Wd(ih.prototype.Q,ih,[]),a)}
function oh(){oh=Vd;var a;nh=(a=Wd(mh.prototype.Q,mh,[]),a)}
function bh(){bh=Vd;var a;ah=(a=Wd(_g.prototype.Q,_g,[]),a)}
function Zg(){Zg=Vd;var a;Yg=(a=Wd(Xg.prototype.Q,Xg,[]),a)}
function Nh(){Lh();return lb(fb(pd,1),ui,21,0,[Ih,Kh,Jh])}
function R(a){L();$wnd.setTimeout(function(){throw a},0)}
function $g(a){$wnd.React.Component.call(this,a);new xg(this)}
function dh(a){$wnd.React.Component.call(this,a);new zg(this)}
function ph(a){$wnd.React.Component.call(this,a);new Tg(this)}
function Ue(a){if(a.b){Ue(a.b)}else if(a.c){throw Ed(new se)}}
function Q(a){a&&X((V(),U));--I;if(a){if(K!=-1){S(K);K=-1}}}
function Tf(a){a.placeholder='What needs to be done?';return a}
function Bh(a,b){Bf(a.a,b.b);Oe(b);a.a.props['a']=b;return a.a}
function B(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Td(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function me(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.s(b))}
function P(a,b,c){var d;d=N();try{return M(a,b,c)}finally{Q(d)}}
function Hf(a,b,c){!ye(c,'key')&&!ye(c,'ref')&&(a[c]=b[c],undefined)}
function df(a,b){Qe.call(this,b.F(),b.D()&-16449);this.a=a;this.c=b}
function Qh(a,b){this.c=new He;this.b=Oe(a);this.d=Oe(b);this.a=false}
function hh(a){$wnd.React.Component.call(this,a);this.a=new Fg(this)}
function lh(a){$wnd.React.Component.call(this,a);this.a=new Rg(this)}
function li(a){var b;b=a.b;!!b&&!Vh(a.c,b)&&(a.b=null,De(a.a,new qi))}
function $h(a,b){Ye(new _e(null,new Se(a.a)),new fi(b));De(a.b,new di)}
function Sh(a,b){Ce(a.a,new Qh(''+Ld(Hd(Date.now())),b));De(a.b,new di)}
function $e(a,b){var c;Te(a);c=new jf;c.a=b;a.a.G(new lf(c));return c.a}
function We(a){var b;Te(a);b=0;while(a.a.H(new kf)){b=Fd(b,1)}return b}
function nb(a){var b,c,d;b=a&yi;c=a>>22&yi;d=a<0?zi:0;return pb(b,c,d)}
function De(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.I(c)}}
function Me(a,b){while(a.a<a.c.a.length){b.I((a.b=a.a++,a.c.a[a.b]))}}
function Ee(a,b,c){for(;c<a.a.length;++c){if(Ne(b,a.a[c])){return c}}return -1}
function Fe(a,b){var c;c=Ee(a,b,0);if(c==-1){return false}nf(a.a,c);return true}
function hb(a,b,c,d,e,f){var g;g=ib(e,d);e!=10&&lb(fb(a,f),b,c,e,g);return g}
function of(a,b){return gb(b)!=10&&lb(o(b),b.S,b.__elementTypeId$,gb(b),a),a}
function gb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Xb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function O(b){L();return function(){return P(b,this,arguments);var a}}
function H(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ae(){C.call(this,'Add not supported on this collection')}
function se(){C.call(this,"Stream already terminated, can't be modified or used")}
function t(){var a;this.a=hb($b,ui,29,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function W(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=$(b,c)}while(a.a);a.a=c}}
function X(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=$(b,c)}while(a.b);a.b=c}}
function Gg(a,b){var c;if((Hh(),Gh).b==a.d.props['a']){c=b.target;Pg(a,c.value)}}
function Kg(a){ji((Hh(),Gh),a.d.props['a']);a.b=a.d.props['a'].d;a.d.forceUpdate()}
function ie(a){var b;b=new he;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Cf(a){var b;b=Ef($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Ff(a){var b;return Df($wnd.React.StrictMode,null,null,(b={},b[Ei]=Oe(a),b))}
function Th(a){var b;$e(Xe(new _e(null,new Se(a.a)),new bi),(b=new He,b)).B(new ci(a))}
function Dd(a){var b;if(Sb(a,5)){return a}b=a&&a[wi];if(!b){b=new G(a);cb(b)}return b}
function qe(a,b){var c;if(!a){return}b.j=a;var d=ne(b);if(!d){Rd[a]=[b];return}d.R=b}
function ue(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function Gd(a){var b;b=a.h;if(b==0){return a.l+a.m*Ci}if(b==zi){return a.l+a.m*Ci-Bi}return a}
function Wd(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Df(a,b,c,d){var e;e=Ef($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Oe(d);return e}
function lb(a,b,c,d,e){e.R=a;e.S=b;e.T=Zd;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Jd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Bi;d=zi}c=Xb(e/Ci);b=Xb(e-c*Ci);return pb(b,c,d)}
function zb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return pb(c&yi,d&yi,e&zi)}
function Fb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return pb(c&yi,d&yi,e&zi)}
function Cb(a){var b,c,d;b=~a.l+1&yi;c=~a.m+(b==0?1:0)&yi;d=~a.h+(b==0&&c==0?1:0)&zi;return pb(b,c,d)}
function vb(a){var b,c,d;b=~a.l+1&yi;c=~a.m+(b==0?1:0)&yi;d=~a.h+(b==0&&c==0?1:0)&zi;a.l=b;a.m=c;a.h=d}
function Mb(){Mb=Vd;Ib=pb(yi,yi,524287);Jb=pb(0,0,Ai);Kb=nb(1);nb(2);Lb=nb(0)}
function Lh(){Lh=Vd;Ih=new Mh('ACTIVE',0);Kh=new Mh('COMPLETED',1);Jh=new Mh('ALL',2)}
function Ni(){$wnd.ReactDOM.render(Ff([(new Eh).a]),(ae(),_d).getElementById('app'),null)}
function Uh(a){return Kd(We(new _e(null,new Se(a.a))))-Kd(We(Xe(new _e(null,new Se(a.a)),new ei)))}
function ve(a,b){var c,d;for(d=new Ke(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Wh(b.a,c)}}
function Nd(){Od();var a=Md;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Hd(a){if(Di<a&&a<Bi){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Gd(Bb(a))}
function G(a){F();w(this);this.b=a;a!=null&&pf(a,wi,this);this.c=a==null?'null':Yd(a);this.a=a}
function he(){this.g=ee++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Rg(a){this.d=Oe(a);r();++Qg;this.b=this.d.props['a'].d;Ph(this.d.props['a'],Wd(th.prototype.L,th,[this]))}
function Hg(a,b){27==b.which?(ji((Hh(),Gh),null),a.b=a.d.props['a'].d,a.d.forceUpdate()):13==b.which&&Lg(a)}
function Qd(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function wb(a){var b,c;c=te(a.h);if(c==32){b=te(a.m);return b==32?te(a.l)+32:b+20-10}else{return c-12}}
function sb(a,b,c,d,e){var f;f=Eb(a,b);c&&vb(f);if(e){a=ub(a,b);d?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h))}return f}
function rb(a,b){if(a.h==Ai&&a.m==0&&a.l==0){b&&(mb=pb(0,0,0));return ob((Mb(),Kb))}b&&(mb=pb(a.l,a.m,a.h));return pb(0,0,0)}
function Fd(a,b){var c;if(Ub(a)&&Ub(b)){c=a+b;if(Di<c&&c<Bi){return c}}return Gd(zb(Ub(a)?Jd(a):a,Ub(b)?Jd(b):b))}
function o(a){return Vb(a)?vc:Ub(a)?mc:Tb(a)?kc:Rb(a)?a.R:jb(a)?a.R:a.R||Array.isArray(a)&&fb(dc,1)||dc}
function p(a){return Vb(a)?xf(a):Ub(a)?Xb(a):Tb(a)?a?1231:1237:Rb(a)?a.o():jb(a)?rf(a):!!a&&!!a.hashCode?a.hashCode():rf(a)}
function Yd(a){var b;if(Array.isArray(a)&&a.T===Zd){return ge(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function N(){var a;if(I!=0){a=H();if(a-J>2000){J=a;K=$wnd.setTimeout(T,10)}}if(I++==0){W((V(),U));return true}return false}
function xf(a){vf();var b,c,d;c=':'+a;d=uf[c];if(d!=null){return Xb(d)}d=sf[c];b=d==null?wf(a):Xb(d);yf();uf[c]=b;return b}
function Le(a){var b,c,d;d=1;for(c=new Ke(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function Ge(a,b){var c,d;d=a.a.length;b.length<d&&(b=of(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function pe(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Bg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=ze(a.a);if(c.length>0){Sh((Hh(),Fh),c);a.a='';a.d.forceUpdate()}}}
function Lg(a){if(null!=a.b&&a.b.length!=0){Xh((Hh(),Fh),a.d.props['a'],a.b);ji(Gh,null);Pg(a,a.b)}else{Wh((Hh(),Fh),a.d.props['a'])}}
function tg(){rg();return lb(fb(Qc,1),ui,6,0,[Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg])}
function db(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function mi(a){this.a=new He;this.c=Oe(a);be((ae(),$wnd.window.window),'hashchange',new oi(this),false);Yh(a,Wd(pi.prototype.L,pi,[this]))}
function Jf(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Qb(a,b){if(Vb(a)){return !!Pb[b]}else if(a.S){return !!a.S[b]}else if(Ub(a)){return !!Ob[b]}else if(Tb(a)){return !!Nb[b]}return false}
function ze(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ub(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return pb(c,d,e)}
function ib(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function yb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&yi;a.m=d&yi;a.h=e&zi;return true}
function $d(){Yh((Hh(),Fh),Wd(ug.prototype.L,ug,[]));ki(Gh,Wd(vg.prototype.L,vg,[]));$wnd.ReactDOM.render(Ff([(new Eh).a]),(ae(),_d).getElementById('app'),null)}
function Ng(a){var b;b=(Hh(),Gh).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();a.b=a.d.props['a'].d;a.d.forceUpdate()}else a.c&&!b&&(a.c=false)}
function hi(a,b){var c,d;b.preventDefault();c=(d=(ae(),$wnd.window.window).location.hash,null==d?'':d.substr(1));ye(Ji,c)||ye(Ii,c)||ye('',c)?De(a.a,new qi):ii()}
function Cg(a){return Gf(Hi,Nf(Rf(Sf(Vf(Tf(Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,['new-todo']))),a.a),Wd(qh.prototype.O,qh,[a])),Wd(rh.prototype.N,rh,[a]))),null)}
function Ab(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Pd(b,c,d,e){Od();var f=Md;$moduleName=c;$moduleBase=d;Cd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{si(g)()}catch(a){b(c,a)}}else{si(g)()}}
function Ef(a,b){var c;c=new $wnd.Object;c.$$typeof=Oe(a);c.type=Oe(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function $(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].U()&&(c=Z(c,g)):g[0].U()}catch(a){a=Dd(a);if(Sb(a,5)){d=a;L();R(Sb(d,24)?d.r():d)}else throw Ed(a)}}return c}
function Sd(){Rd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Db(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return pb(c&yi,d&yi,e&zi)}
function Eb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&Ai)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?zi:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?zi:0;f=d?yi:0;e=c>>b-44}return pb(e&yi,f&yi,g&zi)}
function wf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+xe(a,c++)}b=b|0;return b}
function ii(){var a;if(0==''.length){a=(ae(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',_d.title,a)}else{(ae(),$wnd.window.window).location.hash=''}}
function te(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Ud(a,b,c){var d=Rd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Rd[b]),Xd(h));_.S=c;!b&&(_.T=Zd);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.R=f)}
function oe(a){if(a.w()){var b=a.c;b.A()?(a.k='['+b.j):!b.w()?(a.k='[L'+b.u()+';'):(a.k='['+b.u());a.b=b.t()+'[]';a.i=b.v()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=pe('.',[c,pe('$',d)]);a.b=pe('.',[c,pe('.',d)]);a.i=d[d.length-1]}
function Gf(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Af(b,Wd(If.prototype.K,If,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ei]=c[0],undefined):(d[Ei]=c,undefined));return Df(a,e,f,d)}
function gi(a){var b,c,d,e;b=(e=(c=(ae(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),ye(Ji,e)||ye(Ii,e)||ye('',e)?ye(Ji,e)?(Lh(),Ih):ye(Ii,e)?(Lh(),Kh):(Lh(),Jh):(Lh(),Jh));return $e(Xe(new _e(null,new Se(a.c.a)),new ri(b)),(d=new He,d))}
function xb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return ue(c)}if(b==0&&d!=0&&c==0){return ue(d)+22}if(b!=0&&d==0&&c==0){return ue(b)+44}return -1}
function Bb(a){var b,c,d,e,f;if(isNaN(a)){return Mb(),Lb}if(a<-9223372036854775808){return Mb(),Jb}if(a>=9223372036854775807){return Mb(),Ib}e=false;if(a<0){e=true;a=-a}d=0;if(a>=Bi){d=Xb(a/Bi);a-=d*Bi}c=0;if(a>=Ci){c=Xb(a/Ci);a-=c*Ci}b=Xb(a);f=pb(b,c,d);e&&vb(f);return f}
function Hb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==Ai&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Hb(Cb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=nb(1000000000);c=qb(c,e,true);b=''+Gb(mb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function tb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=wb(b)-wb(a);g=Db(b,j);i=pb(0,0,0);while(j>=0){h=yb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&vb(i);if(f){if(d){mb=Cb(a);e&&(mb=Fb(mb,(Mb(),Kb)))}else{mb=pb(a.l,a.m,a.h)}}return i}
function rg(){rg=Vd;Xf=new sg(Fi,0);Yf=new sg('checkbox',1);Zf=new sg('color',2);$f=new sg('date',3);_f=new sg('datetime',4);ag=new sg('email',5);bg=new sg('file',6);cg=new sg('hidden',7);dg=new sg('image',8);eg=new sg('month',9);fg=new sg(ti,10);gg=new sg('password',11);hg=new sg('radio',12);ig=new sg('range',13);jg=new sg('reset',14);kg=new sg('search',15);lg=new sg('submit',16);mg=new sg('tel',17);ng=new sg('text',18);og=new sg('time',19);pg=new sg('url',20);qg=new sg('week',21)}
function qb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Ed(new ce)}if(a.l==0&&a.m==0&&a.h==0){c&&(mb=pb(0,0,0));return pb(0,0,0)}if(b.h==Ai&&b.m==0&&b.l==0){return rb(a,c)}i=false;if(b.h>>19!=0){b=Cb(b);i=true}g=xb(b);f=false;e=false;d=false;if(a.h==Ai&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ob((Mb(),Ib));d=true;i=!i}else{h=Eb(a,g);i&&vb(h);c&&(mb=pb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Cb(a);d=true;i=!i}if(g!=-1){return sb(a,g,i,f,c)}if(Ab(a,b)<0){c&&(f?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h)));return pb(0,0,0)}return tb(d?a:pb(a.l,a.m,a.h),b,i,f,e,c)}
function Og(a){var b,c;c=a.d.props['a'];b=c.a;return Gf('li',Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,[b?Ii:null,(Hh(),Gh).b==a.d.props['a']?'editing':null])),[Gf('div',Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,['view'])),[Gf(Hi,Rf(Of(Uf(Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,['toggle'])),(rg(),Yf)),b),Wd(wh.prototype.N,wh,[a])),null),Gf('label',Wf(new $wnd.Object,Wd(xh.prototype.P,xh,[a])),[c.d]),Gf(Fi,Mf(Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,['destroy'])),Wd(yh.prototype.P,yh,[a])),null)]),Gf(Hi,Sf(Rf(Qf(Pf(Jf(Kf(new $wnd.Object,Wd(zh.prototype.I,zh,[a])),lb(fb(vc,1),ui,2,6,['edit'])),a.b),Wd(Ah.prototype.M,Ah,[a])),Wd(uh.prototype.N,uh,[a])),Wd(vh.prototype.O,vh,[a])),null)])}
var ti='number',ui={3:1,4:1},vi='__noinit__',wi='__java$exception',xi={3:1,7:1,5:1},yi=4194303,zi=1048575,Ai=524288,Bi=17592186044416,Ci=4194304,Di=-17592186044416,Ei='children',Fi='button',Gi={34:1},Hi='input',Ii='completed',Ji='active',Ki='selected',Li='header';var _,Rd,Md,Cd=-1;Sd();Ud(1,null,{},n);_.n=function(){return this.R};_.o=Mi;_.hashCode=function(){return this.o()};var Nb,Ob,Pb;Ud(35,1,{},he);_.s=function(a){var b;b=new he;b.e=4;a>1?(b.c=me(this,a-1)):(b.c=this);return b};_.t=function(){fe(this);return this.b};_.u=function(){return ge(this)};_.v=function(){fe(this);return this.i};_.w=function(){return (this.e&4)!=0};_.A=function(){return (this.e&1)!=0};_.e=0;_.g=0;var ee=1;var tc=je(1);var lc=je(35);Ud(65,1,{},q);var Zb=je(65);Ud(825,1,{});Ud(29,1,{29:1},s);var $b=je(29);Ud(68,1,{147:1},t);var _b=je(68);Ud(70,1,{},u);var ac=je(70);Ud(69,1,{},v);var bc=je(69);Ud(5,1,{3:1,5:1});_.p=function(a){return new Error(a)};_.q=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=ge(this.R),c==null?a:a+': '+c);A(this,B(this.p(b)));cb(this)};_.b=vi;_.d=true;var wc=je(5);Ud(26,5,{3:1,5:1});var oc=je(26);Ud(7,26,xi);var uc=je(7);Ud(36,7,xi);var qc=je(36);Ud(46,36,xi);var fc=je(46);Ud(24,46,{24:1,3:1,7:1,5:1},G);_.r=function(){return Wb(this.a)===Wb(D)?null:this.a};var D;var cc=je(24);var dc=je(0);Ud(99,1,{});var ec=je(99);var I=0,J=0,K=-1;Ud(61,99,{},Y);var U;var gc=je(61);var ab;Ud(112,1,{});var ic=je(112);Ud(47,112,{},eb);var hc=je(47);var mb;var Ib,Jb,Kb,Lb;var _d;Ud(59,7,xi,ce);var jc=je(59);Nb={3:1,23:1};var kc=je(109);Ud(110,1,{3:1});var sc=je(110);Ob={3:1,23:1};var mc=je(111);Ud(20,1,{3:1,23:1,20:1});_.o=Mi;_.b=0;var nc=je(20);Ud(49,7,xi,se);var pc=je(49);Ud(177,1,{});Ud(58,36,xi,we);_.p=function(a){return new TypeError(a)};var rc=je(58);Pb={3:1,42:1,23:1,2:1};var vc=je(2);Ud(181,1,{});Ud(57,7,xi,Ae);var xc=je(57);Ud(113,1,{96:1});_.B=function(a){ve(this,a)};_.C=function(a){throw Ed(new Ae)};var yc=je(113);Ud(114,113,{96:1,121:1});_.C=function(a){Be(this,this.a.length,a);return true};_.o=function(){return Le(this)};var zc=je(114);Ud(10,114,{3:1,10:1,96:1,121:1},He);_.C=function(a){return Ce(this,a)};_.B=function(a){De(this,a)};var Bc=je(10);Ud(16,1,{},Ke);_.a=0;_.b=-1;var Ac=je(16);Ud(73,1,{});_.G=function(a){Pe(this,a)};_.D=function(){return this.d};_.F=function(){return this.e};_.d=0;_.e=0;var Dc=je(73);Ud(39,73,{});var Cc=je(39);Ud(13,1,{},Se);_.D=function(){return this.a};_.F=function(){Re(this);return this.c};_.G=function(a){Re(this);Me(this.d,a)};_.H=function(a){Re(this);if(Ie(this.d)){a.I(Je(this.d));return true}return false};_.a=0;_.c=0;var Ec=je(13);Ud(72,1,{});_.c=false;var Nc=je(72);Ud(11,72,{146:1,11:1},_e);var Mc=je(11);Ud(75,39,{},df);_.H=function(a){this.b=false;while(!this.b&&this.c.H(new ef(this,a)));return this.b};_.b=false;var Gc=je(75);Ud(78,1,{},ef);_.I=function(a){cf(this.a,this.b,a)};var Fc=je(78);Ud(74,39,{},ff);_.H=function(a){return this.a.H(new gf(a))};var Ic=je(74);Ud(77,1,{},gf);_.I=function(a){this.a.I(Bh(new Ch,a))};var Hc=je(77);Ud(76,1,{},jf);_.I=function(a){hf(this,a)};var Jc=je(76);Ud(79,1,{},kf);_.I=function(a){};var Kc=je(79);Ud(80,1,{},lf);_.I=function(a){bf(this.a,a)};var Lc=je(80);Ud(179,1,{});Ud(118,1,{});var Oc=je(118);Ud(176,1,{});var qf=0;var sf,tf=0,uf;Ud(624,1,{});Ud(780,1,{});Ud(115,1,{});var Pc=je(115);Ud(145,$wnd.Function,{},If);_.K=function(a){Hf(this.a,this.b,a)};Ud(6,20,{3:1,23:1,20:1,6:1},sg);var Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg;var Qc=ke(6,tg);Ud(124,$wnd.Function,Gi,ug);_.L=Ni;Ud(125,$wnd.Function,Gi,vg);_.L=Ni;Ud(117,115,{});var Zc=je(117);Ud(88,117,{});var bd=je(88);Ud(89,88,{},xg);_.o=Mi;var wg=0;var Sc=je(89);Ud(120,115,{});var Yc=je(120);Ud(94,120,{});var ad=je(94);Ud(95,94,{},zg);_.o=Mi;var yg=0;var Rc=je(95);Ud(85,115,{});_.a='';var kd=je(85);Ud(86,85,{});var dd=je(86);Ud(87,86,{},Fg);_.o=Mi;var Eg=0;var Tc=je(87);Ud(119,115,{});_.c=false;var md=je(119);Ud(91,119,{});var fd=je(91);Ud(92,91,{},Rg);_.o=Mi;var Qg=0;var Uc=je(92);Ud(116,115,{});var od=je(116);Ud(63,116,{});var hd=je(63);Ud(64,63,{},Tg);_.o=Mi;var Sg=0;var Vc=je(64);Ud(152,$wnd.Function,{},Ug);_.P=function(a){Th((Hh(),Fh))};Ud(67,1,{},Vg);var Wc=je(67);Ud(90,1,{},Wg);var Xc=je(90);Ud(151,$wnd.Function,{},Xg);_.Q=function(a){return new $g(a)};var Yg;Ud(82,$wnd.React.Component,{},$g);Td(Rd[1],_);_.render=function(){var a,b,c;return a=(Hh(),c=(b=(ae(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),ye(Ji,c)||ye(Ii,c)||ye('',c)?ye(Ji,c)?(Lh(),Ih):ye(Ii,c)?(Lh(),Kh):(Lh(),Jh):(Lh(),Jh)),Gf('footer',Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,['footer'])),[(new Wg).a,Gf('ul',Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,['filters'])),[Gf('li',null,[Gf('a',Lf(Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,[(Lh(),Jh)==a?Ki:null])),'#'),['All'])]),Gf('li',null,[Gf('a',Lf(Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,[Ih==a?Ki:null])),'#active'),['Active'])]),Gf('li',null,[Gf('a',Lf(Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,[Kh==a?Ki:null])),'#completed'),['Completed'])])]),Uh(Fh)>0?Gf(Fi,Mf(Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,['clear-completed'])),Wd(Ug.prototype.P,Ug,[])),['Clear Completed']):null])};_.shouldComponentUpdate=Oi;var $c=je(82);Ud(163,$wnd.Function,{},_g);_.Q=function(a){return new dh(a)};var ah;Ud(93,$wnd.React.Component,{},dh);Td(Rd[1],_);_.render=function(){var a,b;return a=Kd(We(new _e(null,new Se((Hh(),Fh).a)))),b='item'+(a==1?'':'s'),Gf('span',Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,['todo-count'])),[Gf('strong',null,[a]),' '+b+' left'])};_.shouldComponentUpdate=Oi;var _c=je(93);Ud(148,$wnd.Function,{},eh);_.Q=function(a){return new hh(a)};var fh;Ud(71,$wnd.React.Component,{},hh);Td(Rd[1],_);_.render=function(){return Cg(this.a)};_.shouldComponentUpdate=Oi;var cd=je(71);Ud(153,$wnd.Function,{},ih);_.Q=function(a){return new lh(a)};var jh;Ud(84,$wnd.React.Component,{},lh);Td(Rd[1],_);_.componentDidUpdate=function(a){Ng(this.a)};_.render=function(){return Og(this.a)};_.shouldComponentUpdate=Oi;var ed=je(84);Ud(143,$wnd.Function,{},mh);_.Q=function(a){return new ph(a)};var nh;Ud(62,$wnd.React.Component,{},ph);Td(Rd[1],_);_.render=function(){var a,b;return Gf('div',null,[Gf('div',null,[Gf(Li,Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,[Li])),[Gf('h1',null,['todos']),(new sh).a]),0!=Kd(We(new _e(null,new Se((Hh(),Fh).a))))?Gf('section',Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,[Li])),[Gf(Hi,Rf(Uf(Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,['toggle-all'])),(rg(),Yf)),Wd(Dh.prototype.N,Dh,[])),null),Gf('ul',Jf(new $wnd.Object,lb(fb(vc,1),ui,2,6,['todo-list'])),(a=$e(Oe(Ze(new _e(null,new Se(gi(Gh))))),(b=new He,b)),Ge(a,kb(a.a.length))))]):null,0!=Kd(We(new _e(null,new Se(Fh.a))))?(new Vg).a:null])])};_.shouldComponentUpdate=Oi;var gd=je(62);Ud(149,$wnd.Function,{},qh);_.O=function(a){Bg(this.a,a)};Ud(150,$wnd.Function,{},rh);_.N=function(a){Ag(this.a,a)};Ud(66,1,{},sh);var jd=je(66);Ud(162,$wnd.Function,Gi,th);_.L=function(){this.a.d.forceUpdate()};Ud(160,$wnd.Function,{},uh);_.N=function(a){Gg(this.a,a)};Ud(161,$wnd.Function,{},vh);_.O=function(a){Hg(this.a,a)};Ud(154,$wnd.Function,{},wh);_.N=function(a){Mg(this.a)};Ud(156,$wnd.Function,{},xh);_.P=function(a){Kg(this.a)};Ud(157,$wnd.Function,{},yh);_.P=function(a){Jg(this.a)};Ud(158,$wnd.Function,{},zh);_.I=function(a){Ig(this.a,a)};Ud(159,$wnd.Function,{},Ah);_.M=function(a){Lg(this.a)};Ud(83,1,{},Ch);var ld=je(83);Ud(144,$wnd.Function,{},Dh);_.N=function(a){var b;b=a.target;$h((Hh(),Fh),b.checked)};Ud(25,1,{},Eh);var nd=je(25);var Fh,Gh;Ud(21,20,{3:1,23:1,20:1,21:1},Mh);var Ih,Jh,Kh;var pd=ke(21,Nh);Ud(38,1,{38:1},Qh);_.a=false;var xd=je(38);Ud(28,1,{},Rh);_.I=Pi;var qd=je(28);Ud(37,1,{37:1},_h);var wd=je(37);Ud(52,1,{},bi);_.J=function(a){return a.a};var rd=je(52);Ud(53,1,{},ci);_.I=function(a){Wh(this.a,a)};var sd=je(53);Ud(19,1,{},di);_.I=Pi;var td=je(19);Ud(50,1,{},ei);_.J=function(a){return !a.a};var ud=je(50);Ud(51,1,{},fi);_.I=function(a){ai(this.a,a)};_.a=false;var vd=je(51);Ud(54,1,{},mi);var Bd=je(54);Ud(55,1,{},oi);_.handleEvent=function(a){hi(this.a,a)};var yd=je(55);Ud(130,$wnd.Function,Gi,pi);_.L=function(){li(this.a)};Ud(27,1,{},qi);_.I=Pi;var zd=je(27);Ud(56,1,{},ri);_.J=function(a){return ni(this.a,a)};var Ad=je(56);var Yb=le('D');var si=(L(),O);var gwtOnLoad=gwtOnLoad=Pd;Nd($d);Qd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();