function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='1BE562C90D867A9D5399E686C1CAE78C',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '1BE562C90D867A9D5399E686C1CAE78C';function n(){}
function s(){}
function Z(){}
function ke(){}
function ge(){}
function Oe(){}
function fb(){}
function of(){}
function Df(){}
function Lf(){}
function Mf(){}
function hg(){}
function vh(){}
function yh(){}
function Ch(){}
function Gh(){}
function Kh(){}
function Oh(){}
function fi(){}
function gi(){}
function ui(){}
function Gi(){}
function Ii(){}
function Ji(){}
function Ui(){}
function db(a){cb()}
function t(a){df(a)}
function sj(a){a.p()}
function Kf(a,b){a.a=b}
function pf(a){this.a=a}
function Nf(a){this.a=a}
function uh(a){this.a=a}
function Sh(a){this.a=a}
function Th(a){this.a=a}
function Vh(a){this.a=a}
function Wh(a){this.a=a}
function Xh(a){this.a=a}
function Yh(a){this.a=a}
function Zh(a){this.a=a}
function $h(a){this.a=a}
function _h(a){this.a=a}
function ai(a){this.a=a}
function di(a){this.a=a}
function ei(a){this.a=a}
function Hi(a){this.a=a}
function Ki(a){this.a=a}
function Si(a){this.a=a}
function Ti(a){this.a=a}
function Vi(a){this.a=a}
function Ze(a){this.c=a}
function oj(a){ef(this,a)}
function _f(a,b){$f(a,b)}
function si(a,b){Re(a.c,b)}
function Bi(a,b){Re(a.b,b)}
function Oi(a,b){Re(a.a,b)}
function ag(a,b){a.key=b}
function re(){re=ge}
function r(){r=ge;new q}
function G(){G=ge;F=new n}
function W(){W=ge;V=new Z}
function Rd(a){return a.b}
function qj(a){return false}
function pj(){return this.b}
function nj(){return Sf(this)}
function kh(a,b){return a.a=b}
function ue(a){te(a);return a.k}
function qe(a){D.call(this,a)}
function Ke(){v(this);this.u()}
function M(){M=ge;!!(cb(),bb)}
function A(a,b){a.b=b;w(a,b)}
function Pf(a,b){a.splice(b,1)}
function gb(a,b){return Ae(a,b)}
function Cf(a,b){Kf(a,Bf(a.a,b))}
function wf(a,b){qf(a);a.a.L(b)}
function Qe(a,b,c){Of(a.a,b,c)}
function kf(a,b,c){b.N(a.a[c])}
function Hf(a,b,c){b.N(a.a.H(c))}
function ef(a,b){while(a.M(b));}
function Gf(a,b){this.a=a;this.b=b}
function Jf(a,b){this.a=a;this.b=b}
function Fe(a,b){this.a=a;this.b=b}
function ig(a,b){this.a=a;this.b=b}
function Tg(a,b){Fe.call(this,a,b)}
function Of(a,b,c){a.splice(b,0,c)}
function Bf(a,b){a.I(b);return a}
function kg(a,b){a.ref=b;return a}
function lg(a,b){a.href=b;return a}
function pi(a,b){Fe.call(this,a,b)}
function ci(){this.a=bg((Mh(),Lh))}
function hi(){this.a=bg((Qh(),Ph))}
function wh(){this.a=bg((Ah(),zh))}
function xh(){this.a=bg((Eh(),Dh))}
function Uh(){this.a=bg((Ih(),Hh))}
function Xg(a){this.d=df(a);r();++Wg}
function Zg(a){this.d=df(a);r();++Yg}
function eh(a){this.d=df(a);r();++dh}
function th(a){this.d=df(a);r();++sh}
function nf(a){this.b=a;this.a=16464}
function rj(){this.a.d.forceUpdate()}
function T(a){$wnd.clearTimeout(a)}
function _d(){Zd==null&&(Zd=[])}
function U(){J!=0&&(J=0);L=-1}
function Gb(a){return a.l|a.m<<22}
function ob(a){return pb(a.l,a.m,a.h)}
function Ub(a){return typeof a===Xi}
function Wb(a){return a==null?null:a}
function Me(a,b){return Wb(a)===Wb(b)}
function Xe(a){return a.a<a.c.a.length}
function ri(a,b){a.a=b;Se(a.c,new ui)}
function Fi(a,b){b.a=a;Se(b.c,new ui)}
function Ni(a,b){a.b=b;Se(a.a,new Ui)}
function ug(a,b){a.value=b;return a}
function pg(a,b){a.onBlur=b;return a}
function mg(a,b){a.onClick=b;return a}
function qg(a,b){a.onChange=b;return a}
function og(a,b){a.checked=b;return a}
function rg(a,b){a.onKeyDown=b;return a}
function $f(a,b){for(var c in a){b(c)}}
function pb(a,b,c){return {l:a,m:b,h:c}}
function yi(a,b){return Te(a.a,b,0)!=-1}
function Le(a,b){return a.charCodeAt(b)}
function Sb(a,b){return a!=null&&Qb(a,b)}
function Sf(a){return a.$H||(a.$H=++Rf)}
function Vb(a){return typeof a==='string'}
function ng(a){a.autoFocus=true;return a}
function te(a){if(a.k!=null){return}Ce(a)}
function Vg(a){Oi((ki(),ji),new uh(a))}
function We(){this.a=ib(uc,Yi,1,0,5,1)}
function q(){this.a=new u;new t(this.a)}
function D(a){this.d=a;v(this);this.u()}
function Af(a,b){sf.call(this,a);this.a=b}
function bh(a,b){a.a=b;a.d.forceUpdate()}
function oh(a,b){a.b=b;a.d.forceUpdate()}
function zi(a,b){Ue(a.a,b);Se(a.b,new Ii)}
function Ci(a,b){ri(b,!b.a);Se(a.b,new Ii)}
function Ei(){this.a=new We;this.b=new We}
function Wf(){Wf=ge;Tf=new n;Vf=new n}
function ki(){ki=ge;ii=new Ei;ji=new Qi(ii)}
function cb(){cb=ge;var a;!eb();a=new fb;bb=a}
function Tb(a){return typeof a==='boolean'}
function N(a,b,c){return a.apply(b,c);var d}
function Ye(a){a.b=a.a++;return a.c.a[a.b]}
function v(a){a.f&&a.b!==Zi&&a.u();return a}
function vg(a,b){a.onDoubleClick=b;return a}
function Re(a,b){a.a[a.a.length]=b;return true}
function xe(a){var b;b=we(a);Ee(a,b);return b}
function $g(a,b){var c;c=b.target;bh(a,c.value)}
function tf(a,b){var c;return yf(a,(c=new We,c))}
function hf(a,b){while(a.c<a.d){kf(a,b,a.c++)}}
function Ef(a,b,c){if(a.a.P(c)){a.b=true;b.N(c)}}
function oe(a,b,c,d){a.addEventListener(b,c,d)}
function pe(){D.call(this,'divide by zero')}
function hh(a){Ci((ki(),ii),a.d.props['a'])}
function jh(a){zi((ki(),ii),a.d.props['a'])}
function Xd(a){if(Ub(a)){return a|0}return Gb(a)}
function Yd(a){if(Ub(a)){return ''+a}return Hb(a)}
function df(a){if(a==null){throw Rd(new Ke)}return a}
function Zf(){if(Uf==256){Tf=Vf;Vf=new n;Uf=0}++Uf}
function qf(a){if(!a.b){rf(a);a.c=true}else{qf(a.b)}}
function ze(a){var b;b=we(a);b.j=a;b.e=1;return b}
function $(a,b){!a&&(a=[]);a[a.length]=b;return a}
function tg(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function gf(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function $e(a,b){return ff(b,a.length),new lf(a,b)}
function Ri(a,b){return (oi(),mi)==a||(li==a?!b.a:b.a)}
function Rb(a){return !Array.isArray(a)&&a.Y===ke}
function kb(a){return Array.isArray(a)&&a.Y===ke}
function _e(a){return new Af(null,$e(a,a.length))}
function vf(a,b){rf(a);return new Af(a,new Ff(b,a.a))}
function xf(a,b){rf(a);return new Af(a,new If(b,a.a))}
function rh(a){Bi((ki(),ii),new di(a));Oi(ji,new ei(a))}
function mf(a){if(!a.d){a.d=new Ze(a.b);a.c=a.b.a.length}}
function sf(a){if(!a){this.b=null;new We}else{this.b=a}}
function lf(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function ye(a,b){var c;c=we(a);Ee(a,c);c.e=b?8:0;return c}
function B(a,b){var c;c=ue(a.W);return b==null?c:c+': '+b}
function Ai(a,b,c){b.d=df(c);Se(b.c,new ui);Se(a.b,new Ii)}
function cf(a,b){return Wb(a)===Wb(b)||!!a&&Wb(a)===Wb(b)}
function qi(){oi();return lb(gb(Bd,1),Yi,20,0,[li,ni,mi])}
function ne(){ne=ge;me=$wnd.goog.global.document}
function S(a){M();$wnd.setTimeout(function(){throw a},0)}
function rf(a){if(a.b){rf(a.b)}else if(a.c){throw Rd(new Ge)}}
function Be(a){if(a.F()){return null}var b=a.j;return ce[b]}
function ie(a){function b(){}
;b.prototype=a||{};return new b}
function sg(a){a.placeholder='What needs to be done?';return a}
function Fh(a){$wnd.React.Component.call(this,a);new Zg(this)}
function Ah(){Ah=ge;var a;zh=(a=he(yh.prototype.V,yh,[]),a)}
function Eh(){Eh=ge;var a;Dh=(a=he(Ch.prototype.V,Ch,[]),a)}
function Ih(){Ih=ge;var a;Hh=(a=he(Gh.prototype.V,Gh,[]),a)}
function Mh(){Mh=ge;var a;Lh=(a=he(Kh.prototype.V,Kh,[]),a)}
function Qh(){Qh=ge;var a;Ph=(a=he(Oh.prototype.V,Oh,[]),a)}
function Ae(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.w(b))}
function ee(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Q(a,b,c){var d;d=O();try{return N(a,b,c)}finally{R(d)}}
function gg(a,b,c){!Me(c,'key')&&!Me(c,'ref')&&(a[c]=b[c],undefined)}
function If(a,b){gf.call(this,b.K(),b.J()&-6);this.a=a;this.b=b}
function Ff(a,b){gf.call(this,b.K(),b.J()&-16449);this.a=a;this.c=b}
function Pe(){D.call(this,'Add not supported on this collection')}
function C(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function jf(a,b){if(a.c<a.d){kf(a,b,a.c++);return true}return false}
function ti(a,b){this.c=new We;this.b=df(a);this.d=df(b);this.a=false}
function Bh(a){$wnd.React.Component.call(this,a);this.a=new Xg(this)}
function Jh(a){$wnd.React.Component.call(this,a);this.a=new eh(this)}
function Nh(a){$wnd.React.Component.call(this,a);this.a=new qh(this)}
function Rh(a){$wnd.React.Component.call(this,a);this.a=new th(this)}
function Pi(a){var b;b=a.b;!!b&&!yi(a.c,b)&&(a.b=null,Se(a.a,new Ui))}
function Di(a,b){wf(new Af(null,new nf(a.a)),new Ki(b));Se(a.b,new Ii)}
function vi(a,b){Re(a.a,new ti(''+Yd(Ud(Date.now())),b));Se(a.b,new Ii)}
function zf(a,b){var c;c=tf(a,new pf(new of));return Ve(c,b.O(c.a.length))}
function yf(a,b){var c;qf(a);c=new Lf;c.a=b;a.a.L(new Nf(c));return c.a}
function uf(a){var b;qf(a);b=0;while(a.a.M(new Mf)){b=Sd(b,1)}return b}
function R(a){a&&Y((W(),V));--J;if(a){if(L!=-1){T(L);L=-1}}}
function ih(a){Ni((ki(),ji),a.d.props['a']);oh(a,a.d.props['a'].d)}
function bf(a,b){while(a.a<a.c.a.length){b.N((a.b=a.a++,a.c.a[a.b]))}}
function Te(a,b,c){for(;c<a.a.length;++c){if(cf(b,a.a[c])){return c}}return -1}
function Ue(a,b){var c;c=Te(a,b,0);if(c==-1){return false}Pf(a.a,c);return true}
function ib(a,b,c,d,e,f){var g;g=jb(e,d);e!=10&&lb(gb(a,f),b,c,e,g);return g}
function Se(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.N(c)}}
function nb(a){var b,c,d;b=a&_i;c=a>>22&_i;d=a<0?aj:0;return pb(b,c,d)}
function Xb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function P(b){M();return function(){return Q(b,this,arguments);var a}}
function I(){if(Date.now){return Date.now()}return (new Date).getTime()}
function wi(a){tf(vf(new Af(null,new nf(a.a)),new Gi),new pf(new of)).G(new Hi(a))}
function Qf(a,b){return hb(b)!=10&&lb(o(b),b.X,b.__elementTypeId$,hb(b),a),a}
function hb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function eg(a){var b;return cg($wnd.React.StrictMode,null,null,(b={},b[fj]=df(a),b))}
function X(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=ab(b,c)}while(a.a);a.a=c}}
function Y(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=ab(b,c)}while(a.b);a.b=c}}
function fh(a,b){var c;if((ki(),ji).b==a.d.props['a']){c=b.target;oh(a,c.value)}}
function Ee(a,b){var c;if(!a){return}b.j=a;var d=Be(b);if(!d){ce[a]=[b];return}d.W=b}
function Ie(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function he(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function we(a){var b;b=new ve;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function bg(a){var b;b=dg($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function u(){var a;this.a=ib($b,Yi,27,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function Mb(){Mb=ge;Ib=pb(_i,_i,524287);Jb=pb(0,0,bj);Kb=nb(1);nb(2);Lb=nb(0)}
function oi(){oi=ge;li=new pi('ACTIVE',0);ni=new pi('COMPLETED',1);mi=new pi('ALL',2)}
function Ge(){D.call(this,"Stream already terminated, can't be modified or used")}
function H(a){G();v(this);this.b=a;w(this,a);this.d=a==null?'null':je(a);this.a=a}
function $d(){_d();var a=Zd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Je(a,b){var c,d;for(d=new Ze(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);zi(b.a,c)}}
function Wd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=cj;d=aj}c=Xb(e/dj);b=Xb(e-c*dj);return pb(b,c,d)}
function zb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return pb(c&_i,d&_i,e&aj)}
function Fb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return pb(c&_i,d&_i,e&aj)}
function Td(a){var b;b=a.h;if(b==0){return a.l+a.m*dj}if(b==aj){return a.l+a.m*dj-cj}return a}
function Qd(a){var b;if(Sb(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new H(a);db(b)}return b}
function Ud(a){if(ej<a&&a<cj){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Td(Bb(a))}
function ff(a,b){if(0>a||a>b){throw Rd(new qe('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function bi(a,b){ag(a.a,(te(vd),vd.k+(''+(b?b.b:null))));df(b);a.a.props['a']=b;return a.a}
function gh(a,b){27==b.which?(Ni((ki(),ji),null),oh(a,a.d.props['a'].d)):13==b.which&&lh(a)}
function qh(a){this.d=df(a);r();++ph;this.b=this.d.props['a'].d;si(this.d.props['a'],new Vh(this))}
function xi(a){return Xd(uf(new Af(null,new nf(a.a))))-Xd(uf(vf(new Af(null,new nf(a.a)),new Ji)))}
function le(){$wnd.ReactDOM.render(eg([(new hi).a]),(ne(),me).getElementById('app'),null)}
function cg(a,b,c,d){var e;e=dg($wnd.React.Element,a);e.key=b;e.ref=c;e.props=df(d);return e}
function lb(a,b,c,d,e){e.W=a;e.X=b;e.Y=ke;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function sb(a,b,c,d,e){var f;f=Eb(a,b);c&&vb(f);if(e){a=ub(a,b);d?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h))}return f}
function wb(a){var b,c;c=He(a.h);if(c==32){b=He(a.m);return b==32?He(a.l)+32:b+20-10}else{return c-12}}
function Cb(a){var b,c,d;b=~a.l+1&_i;c=~a.m+(b==0?1:0)&_i;d=~a.h+(b==0&&c==0?1:0)&aj;return pb(b,c,d)}
function vb(a){var b,c,d;b=~a.l+1&_i;c=~a.m+(b==0?1:0)&_i;d=~a.h+(b==0&&c==0?1:0)&aj;a.l=b;a.m=c;a.h=d}
function o(a){return Vb(a)?wc:Ub(a)?mc:Tb(a)?kc:Rb(a)?a.W:kb(a)?a.W:a.W||Array.isArray(a)&&gb(cc,1)||cc}
function p(a){return Vb(a)?Yf(a):Ub(a)?Xb(a):Tb(a)?a?1231:1237:Rb(a)?a.o():kb(a)?Sf(a):!!a&&!!a.hashCode?a.hashCode():Sf(a)}
function Sd(a,b){var c;if(Ub(a)&&Ub(b)){c=a+b;if(ej<c&&c<cj){return c}}return Td(zb(Ub(a)?Wd(a):a,Ub(b)?Wd(b):b))}
function be(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function ve(){this.g=se++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Qi(a){this.a=new We;this.c=df(a);oe((ne(),$wnd.goog.global.window),'hashchange',new Si(this),false);Bi(a,new Ti(this))}
function je(a){var b;if(Array.isArray(a)&&a.Y===ke){return ue(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function rb(a,b){if(a.h==bj&&a.m==0&&a.l==0){b&&(mb=pb(0,0,0));return ob((Mb(),Kb))}b&&(mb=pb(a.l,a.m,a.h));return pb(0,0,0)}
function Yf(a){Wf();var b,c,d;c=':'+a;d=Vf[c];if(d!=null){return Xb(d)}d=Tf[c];b=d==null?Xf(a):Xb(d);Zf();Vf[c]=b;return b}
function af(a){var b,c,d;d=1;for(c=new Ze(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function Ve(a,b){var c,d;d=a.a.length;b.length<d&&(b=Qf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function De(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function _g(a,b){var c;if(13==b.keyCode){b.preventDefault();c=Ne(a.a);if(c.length>0){vi((ki(),ii),c);a.a='';a.d.forceUpdate()}}}
function O(){var a;if(J!=0){a=I();if(a-K>2000){K=a;L=$wnd.setTimeout(U,10)}}if(J++==0){X((W(),V));return true}return false}
function eb(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Ug(){Sg();return lb(gb(Xc,1),Yi,5,0,[wg,xg,yg,zg,Ag,Bg,Cg,Dg,Eg,Fg,Gg,Hg,Ig,Jg,Kg,Lg,Mg,Ng,Og,Pg,Qg,Rg])}
function lh(a){if(null!=a.b&&a.b.length!=0){Ai((ki(),ii),a.d.props['a'],a.b);Ni(ji,null);oh(a,a.b)}else{zi((ki(),ii),a.d.props['a'])}}
function Qb(a,b){if(Vb(a)){return !!Pb[b]}else if(a.X){return !!a.X[b]}else if(Ub(a)){return !!Ob[b]}else if(Tb(a)){return !!Nb[b]}return false}
function mh(a){var b;b=(ki(),ji).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();oh(a,a.d.props['a'].d)}else a.c&&!b&&(a.c=false)}
function jg(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Ne(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ub(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return pb(c,d,e)}
function Db(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return pb(c&_i,d&_i,e&aj)}
function jb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function yb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&_i;a.m=d&_i;a.h=e&aj;return true}
function ah(a){return fg(hj,ng(qg(rg(ug(sg(jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,['new-todo']))),a.a),he(Sh.prototype.T,Sh,[a])),he(Th.prototype.S,Th,[a]))),null)}
function Ab(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function ae(b,c,d,e){_d();var f=Zd;$moduleName=c;$moduleBase=d;Pd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Wi(g)()}catch(a){b(c,a)}}else{Wi(g)()}}
function dg(a,b){var c;c=new $wnd.Object;c.$$typeof=df(a);c.type=df(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function ab(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Z()&&(c=$(c,g)):g[0].Z()}catch(a){a=Qd(a);if(Sb(a,4)){d=a;M();S(Sb(d,24)?d.v():d)}else throw Rd(a)}}return c}
function de(){ce={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Xf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Le(a,c++)}b=b|0;return b}
function Li(a){var b,c,d;b=(d=(c=(ne(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1)),Me(jj,d)?(oi(),li):Me(kj,d)?(oi(),ni):(oi(),mi));return tf(vf(new Af(null,new nf(a.c.a)),new Vi(b)),new pf(new of))}
function He(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function fe(a,b,c){var d=ce,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=ce[b]),ie(h));_.X=c;!b&&(_.Y=ke);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.W=f)}
function Eb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&bj)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?aj:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?aj:0;f=d?_i:0;e=c>>b-44}return pb(e&_i,f&_i,g&aj)}
function Ce(a){if(a.D()){var b=a.c;b.F()?(a.k='['+b.j):!b.D()?(a.k='[L'+b.B()+';'):(a.k='['+b.B());a.b=b.A()+'[]';a.i=b.C()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=De('.',[c,De('$',d)]);a.b=De('.',[c,De('.',d)]);a.i=d[d.length-1]}
function fg(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;_f(b,he(ig.prototype.Q,ig,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[fj]=c[0],undefined):(d[fj]=c,undefined));return cg(a,e,f,d)}
function xb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return Ie(c)}if(b==0&&d!=0&&c==0){return Ie(d)+22}if(b!=0&&d==0&&c==0){return Ie(b)+44}return -1}
function Bb(a){var b,c,d,e,f;if(isNaN(a)){return Mb(),Lb}if(a<-9223372036854775808){return Mb(),Jb}if(a>=9223372036854775807){return Mb(),Ib}e=false;if(a<0){e=true;a=-a}d=0;if(a>=cj){d=Xb(a/cj);a-=d*cj}c=0;if(a>=dj){c=Xb(a/dj);a-=c*dj}b=Xb(a);f=pb(b,c,d);e&&vb(f);return f}
function w(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.t();return a&&a.r()}},suppressed:{get:function(){return c.s()}}})}catch(a){}}}
function Mi(a,b){var c,d,e;b.preventDefault();c=(d=(ne(),$wnd.goog.global.window).location.hash,null==d?'':d.substr(1));if(Me(jj,c)||Me(kj,c)||Me('',c)){Se(a.a,new Ui)}else{e=$wnd.goog.global.window.location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',me.title,e)}}
function Hb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==bj&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Hb(Cb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=nb(1000000000);c=qb(c,e,true);b=''+Gb(mb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function tb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=wb(b)-wb(a);g=Db(b,j);i=pb(0,0,0);while(j>=0){h=yb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&vb(i);if(f){if(d){mb=Cb(a);e&&(mb=Fb(mb,(Mb(),Kb)))}else{mb=pb(a.l,a.m,a.h)}}return i}
function Sg(){Sg=ge;wg=new Tg(gj,0);xg=new Tg('checkbox',1);yg=new Tg('color',2);zg=new Tg('date',3);Ag=new Tg('datetime',4);Bg=new Tg('email',5);Cg=new Tg('file',6);Dg=new Tg('hidden',7);Eg=new Tg('image',8);Fg=new Tg('month',9);Gg=new Tg(Xi,10);Hg=new Tg('password',11);Ig=new Tg('radio',12);Jg=new Tg('range',13);Kg=new Tg('reset',14);Lg=new Tg('search',15);Mg=new Tg('submit',16);Ng=new Tg('tel',17);Og=new Tg('text',18);Pg=new Tg('time',19);Qg=new Tg('url',20);Rg=new Tg('week',21)}
function qb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Rd(new pe)}if(a.l==0&&a.m==0&&a.h==0){c&&(mb=pb(0,0,0));return pb(0,0,0)}if(b.h==bj&&b.m==0&&b.l==0){return rb(a,c)}i=false;if(b.h>>19!=0){b=Cb(b);i=!i}g=xb(b);f=false;e=false;d=false;if(a.h==bj&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ob((Mb(),Ib));d=true;i=!i}else{h=Eb(a,g);i&&vb(h);c&&(mb=pb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Cb(a);d=true;i=!i}if(g!=-1){return sb(a,g,i,f,c)}if(Ab(a,b)<0){c&&(f?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h)));return pb(0,0,0)}return tb(d?a:pb(a.l,a.m,a.h),b,i,f,e,c)}
function nh(a){var b,c;c=a.d.props['a'];b=c.a;return fg('li',jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,[b?'checked':null,(ki(),ji).b==a.d.props['a']?'editing':null])),[fg('div',jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,['view'])),[fg(hj,qg(og(tg(jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,['toggle'])),(Sg(),xg)),b),he(Yh.prototype.S,Yh,[a])),null),fg('label',vg(new $wnd.Object,he(Zh.prototype.U,Zh,[a])),[c.d]),fg(gj,mg(jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,['destroy'])),he($h.prototype.U,$h,[a])),null)]),fg(hj,rg(qg(pg(ug(jg(kg(new $wnd.Object,he(_h.prototype.N,_h,[a])),lb(gb(wc,1),Yi,2,6,['edit'])),a.b),he(ai.prototype.R,ai,[a])),he(Wh.prototype.S,Wh,[a])),he(Xh.prototype.T,Xh,[a])),null)])}
var Xi='number',Yi={3:1},Zi='__noinit__',$i={3:1,6:1,4:1},_i=4194303,aj=1048575,bj=524288,cj=17592186044416,dj=4194304,ej=-17592186044416,fj='children',gj='button',hj='input',ij={34:1},jj='active',kj='completed',lj='selected',mj='header';var _,ce,Zd,Pd=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;de();fe(1,null,{},n);_.n=function(){return this.W};_.o=nj;_.hashCode=function(){return this.o()};var Nb,Ob,Pb;fe(36,1,{},ve);_.w=function(a){var b;b=new ve;b.e=4;a>1?(b.c=Ae(this,a-1)):(b.c=this);return b};_.A=function(){te(this);return this.b};_.B=function(){return ue(this)};_.C=function(){te(this);return this.i};_.D=function(){return (this.e&4)!=0};_.F=function(){return (this.e&1)!=0};_.e=0;_.g=0;var se=1;var uc=xe(1);var lc=xe(36);fe(58,1,{},q);var Zb=xe(58);fe(27,1,{27:1},s);var $b=xe(27);fe(67,1,{},t);var _b=xe(67);fe(38,1,{38:1},u);var ac=xe(38);fe(4,1,{3:1,4:1});_.q=function(a){return new Error(a)};_.r=pj;_.s=function(){return zf(xf(_e((this.e==null&&(this.e=ib(yc,Yi,4,0,0,1)),this.e)),new Oe),new Df)};_.t=function(){return this.c};_.u=function(){A(this,C(this.q(B(this,this.d))));db(this)};_.b=Zi;_.f=true;var yc=xe(4);fe(25,4,{3:1,4:1});var oc=xe(25);fe(6,25,$i);var vc=xe(6);fe(37,6,$i);var rc=xe(37);fe(50,37,$i);var ec=xe(50);fe(24,50,{24:1,3:1,6:1,4:1},H);_.v=function(){return Wb(this.a)===Wb(F)?null:this.a};var F;var bc=xe(24);var cc=xe(0);fe(112,1,{});var dc=xe(112);var J=0,K=0,L=-1;fe(60,112,{},Z);var V;var fc=xe(60);var bb;fe(125,1,{});var hc=xe(125);fe(51,125,{},fb);var gc=xe(51);var mb;var Ib,Jb,Kb,Lb;var me;fe(57,6,$i,pe);var ic=xe(57);fe(54,6,$i);var qc=xe(54);fe(80,54,$i,qe);var jc=xe(80);Nb={3:1,23:1};var kc=xe(122);fe(123,1,Yi);var tc=xe(123);Ob={3:1,23:1};var mc=xe(124);fe(18,1,{3:1,23:1,18:1});_.o=nj;_.b=0;var nc=xe(18);fe(53,6,$i,Ge);var pc=xe(53);fe(188,1,{});fe(56,37,$i,Ke);_.q=function(a){return new TypeError(a)};var sc=xe(56);Pb={3:1,46:1,23:1,2:1};var wc=xe(2);fe(192,1,{});fe(44,1,{},Oe);_.H=function(a){return a.b};var xc=xe(44);fe(55,6,$i,Pe);var zc=xe(55);fe(126,1,{109:1});_.G=function(a){Je(this,a)};_.I=function(a){throw Rd(new Pe)};var Ac=xe(126);fe(127,126,{109:1,133:1});_.I=function(a){Qe(this,this.a.length,a);return true};_.o=function(){return af(this)};var Bc=xe(127);fe(11,127,{3:1,11:1,109:1,133:1},We);_.I=function(a){return Re(this,a)};_.G=function(a){Se(this,a)};var Dc=xe(11);fe(16,1,{},Ze);_.a=0;_.b=-1;var Cc=xe(16);fe(69,1,{});_.L=oj;_.J=function(){return this.d};_.K=function(){return this.e};_.d=0;_.e=0;var Hc=xe(69);fe(39,69,{});var Ec=xe(39);fe(61,1,{});_.L=oj;_.J=pj;_.K=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Gc=xe(61);fe(62,61,{},lf);_.L=function(a){hf(this,a)};_.M=function(a){return jf(this,a)};var Fc=xe(62);fe(12,1,{},nf);_.J=function(){return this.a};_.K=function(){mf(this);return this.c};_.L=function(a){mf(this);bf(this.d,a)};_.M=function(a){mf(this);if(Xe(this.d)){a.N(Ye(this.d));return true}return false};_.a=0;_.c=0;var Ic=xe(12);fe(26,1,{},of);_.H=function(a){return a};var Jc=xe(26);fe(30,1,{},pf);var Kc=xe(30);fe(68,1,{});_.c=false;var Uc=xe(68);fe(9,68,{155:1},Af);var Tc=xe(9);fe(45,1,{},Df);_.O=function(a){return ib(uc,Yi,1,a,5,1)};var Lc=xe(45);fe(71,39,{},Ff);_.M=function(a){this.b=false;while(!this.b&&this.c.M(new Gf(this,a)));return this.b};_.b=false;var Nc=xe(71);fe(74,1,{},Gf);_.N=function(a){Ef(this.a,this.b,a)};var Mc=xe(74);fe(70,39,{},If);_.M=function(a){return this.b.M(new Jf(this,a))};var Pc=xe(70);fe(73,1,{},Jf);_.N=function(a){Hf(this.a,this.b,a)};var Oc=xe(73);fe(72,1,{},Lf);_.N=function(a){Kf(this,a)};var Qc=xe(72);fe(75,1,{},Mf);_.N=function(a){};var Rc=xe(75);fe(76,1,{},Nf);_.N=function(a){Cf(this.a,a)};var Sc=xe(76);fe(190,1,{});fe(187,1,{});var Rf=0;var Tf,Uf=0,Vf;fe(801,1,{});fe(822,1,{});fe(128,1,{});var Vc=xe(128);fe(81,1,{},hg);_.O=function(a){return new Array(a)};var Wc=xe(81);fe(156,$wnd.Function,{},ig);_.Q=function(a){gg(this.a,this.b,a)};fe(5,18,{3:1,23:1,18:1,5:1},Tg);var wg,xg,yg,zg,Ag,Bg,Cg,Dg,Eg,Fg,Gg,Hg,Ig,Jg,Kg,Lg,Mg,Ng,Og,Pg,Qg,Rg;var Xc=ye(5,Ug);fe(131,128,{});var fd=xe(131);fe(101,131,{});var kd=xe(101);fe(102,101,{},Xg);_.o=nj;var Wg=0;var Zc=xe(102);fe(132,128,{});var ed=xe(132);fe(107,132,{});var jd=xe(107);fe(108,107,{},Zg);_.o=nj;var Yg=0;var Yc=xe(108);fe(98,128,{});_.a='';var sd=xe(98);fe(99,98,{});var md=xe(99);fe(100,99,{},eh);_.o=nj;var dh=0;var $c=xe(100);fe(130,128,{});_.c=false;var vd=xe(130);fe(104,130,{});var od=xe(104);fe(105,104,{},qh);_.o=nj;var ph=0;var _c=xe(105);fe(129,128,{});var Ad=xe(129);fe(78,129,{});var qd=xe(78);fe(79,78,{},th);_.o=nj;var sh=0;var ad=xe(79);fe(95,1,ij,uh);_.p=rj;var bd=xe(95);fe(161,$wnd.Function,{},vh);_.U=function(a){wi((ki(),ii))};fe(87,1,{},wh);var cd=xe(87);fe(103,1,{},xh);var dd=xe(103);fe(160,$wnd.Function,{},yh);_.V=function(a){return new Bh(a)};var zh;fe(94,$wnd.React.Component,{},Bh);ee(ce[1],_);_.componentDidMount=function(){Vg(this.a)};_.render=function(){var a,b,c;return a=(c=(ki(),b=(ne(),$wnd.goog.global.window).location.hash,null==b?'':b.substr(1)),Me(jj,c)?(oi(),li):Me(kj,c)?(oi(),ni):(oi(),mi)),fg('footer',jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,['footer'])),[(new xh).a,fg('ul',jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,['filters'])),[fg('li',null,[fg('a',lg(jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,[(oi(),mi)==a?lj:null])),'#'),['All'])]),fg('li',null,[fg('a',lg(jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,[li==a?lj:null])),'#active'),['Active'])]),fg('li',null,[fg('a',lg(jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,[ni==a?lj:null])),'#completed'),['Completed'])])]),xi(ii)>0?fg(gj,mg(jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,['clear-completed'])),he(vh.prototype.U,vh,[])),['Clear Completed']):null])};_.shouldComponentUpdate=qj;var gd=xe(94);fe(171,$wnd.Function,{},Ch);_.V=function(a){return new Fh(a)};var Dh;fe(106,$wnd.React.Component,{},Fh);ee(ce[1],_);_.render=function(){var a,b;return a=Xd(uf(new Af(null,new nf((ki(),ii).a)))),b='item'+(a==1?'':'s'),fg('span',jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,['todo-count'])),[fg('strong',null,[a]),' '+b+' left'])};_.shouldComponentUpdate=qj;var hd=xe(106);fe(157,$wnd.Function,{},Gh);_.V=function(a){return new Jh(a)};var Hh;fe(93,$wnd.React.Component,{},Jh);ee(ce[1],_);_.render=function(){return ah(this.a)};_.shouldComponentUpdate=qj;var ld=xe(93);fe(162,$wnd.Function,{},Kh);_.V=function(a){return new Nh(a)};var Lh;fe(96,$wnd.React.Component,{},Nh);ee(ce[1],_);_.componentDidUpdate=function(a){mh(this.a)};_.render=function(){return nh(this.a)};_.shouldComponentUpdate=qj;var nd=xe(96);fe(153,$wnd.Function,{},Oh);_.V=function(a){return new Rh(a)};var Ph;fe(63,$wnd.React.Component,{},Rh);ee(ce[1],_);_.componentDidMount=function(){rh(this.a)};_.render=function(){return fg('div',null,[fg('div',null,[fg(mj,jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,[mj])),[fg('h1',null,['todos']),(new Uh).a]),0!=Xd(uf(new Af(null,new nf((ki(),ii).a))))?fg('section',jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,[mj])),[fg(hj,qg(tg(jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,['toggle-all'])),(Sg(),xg)),he(fi.prototype.S,fi,[])),null),fg('ul',jg(new $wnd.Object,lb(gb(wc,1),Yi,2,6,['todo-list'])),zf(df(xf(new Af(null,new nf(Li(ji))),new gi)),new hg))]):null,0!=Xd(uf(new Af(null,new nf(ii.a))))?(new wh).a:null])])};_.shouldComponentUpdate=qj;var pd=xe(63);fe(158,$wnd.Function,{},Sh);_.T=function(a){_g(this.a,a)};fe(159,$wnd.Function,{},Th);_.S=function(a){$g(this.a,a)};fe(82,1,{},Uh);var rd=xe(82);fe(97,1,ij,Vh);_.p=rj;var td=xe(97);fe(169,$wnd.Function,{},Wh);_.S=function(a){fh(this.a,a)};fe(170,$wnd.Function,{},Xh);_.T=function(a){gh(this.a,a)};fe(163,$wnd.Function,{},Yh);_.S=function(a){hh(this.a)};fe(165,$wnd.Function,{},Zh);_.U=function(a){ih(this.a)};fe(166,$wnd.Function,{},$h);_.U=function(a){jh(this.a)};fe(167,$wnd.Function,{},_h);_.N=function(a){kh(this.a,a)};fe(168,$wnd.Function,{},ai);_.R=function(a){lh(this.a)};fe(92,1,{},ci);var ud=xe(92);fe(64,1,ij,di);_.p=rj;var wd=xe(64);fe(65,1,ij,ei);_.p=rj;var xd=xe(65);fe(154,$wnd.Function,{},fi);_.S=function(a){var b;b=a.target;Di((ki(),ii),b.checked)};fe(66,1,{},gi);_.H=function(a){return bi(new ci,a)};var yd=xe(66);fe(43,1,{},hi);var zd=xe(43);var ii,ji;fe(20,18,{3:1,23:1,18:1,20:1},pi);var li,mi,ni;var Bd=ye(20,qi);fe(41,1,{41:1},ti);_.a=false;var Jd=xe(41);fe(29,1,{},ui);_.N=sj;var Cd=xe(29);fe(40,1,{40:1},Ei);var Id=xe(40);fe(85,1,{},Gi);_.P=function(a){return a.a};var Dd=xe(85);fe(86,1,{},Hi);_.N=function(a){zi(this.a,a)};var Ed=xe(86);fe(19,1,{},Ii);_.N=sj;var Fd=xe(19);fe(83,1,{},Ji);_.P=function(a){return !a.a};var Gd=xe(83);fe(84,1,{},Ki);_.N=function(a){Fi(this.a,a)};_.a=false;var Hd=xe(84);fe(88,1,{},Qi);var Od=xe(88);fe(89,1,{},Si);_.handleEvent=function(a){Mi(this.a,a)};var Kd=xe(89);fe(90,1,ij,Ti);_.p=function(){Pi(this.a)};var Ld=xe(90);fe(28,1,{},Ui);_.N=sj;var Md=xe(28);fe(91,1,{},Vi);_.P=function(a){return Ri(this.a,a)};var Nd=xe(91);var Yb=ze('D');var Wi=(M(),P);var gwtOnLoad=gwtOnLoad=ae;$d(le);be('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();