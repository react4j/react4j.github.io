function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='96A1BB99724972508E63A6F3764AB374',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '96A1BB99724972508E63A6F3764AB374';function n(){}
function s(){}
function X(){}
function $d(){}
function Wd(){}
function Wg(){}
function Tg(){}
function $g(){}
function db(){}
function dh(){}
function hh(){}
function lh(){}
function lf(){}
function kf(){}
function Eh(){}
function Sh(){}
function ci(){}
function ei(){}
function fi(){}
function qi(){}
function bb(a){ab()}
function Pi(a){a.p()}
function u(a){Pe(a)}
function ee(){ee=Wd}
function jf(a,b){a.a=b}
function hf(a){this.a=a}
function mf(a){this.a=a}
function ph(a){this.a=a}
function qh(a){this.a=a}
function sh(a){this.a=a}
function th(a){this.a=a}
function uh(a){this.a=a}
function vh(a){this.a=a}
function wh(a){this.a=a}
function xh(a){this.a=a}
function yh(a){this.a=a}
function zh(a){this.a=a}
function Ch(a){this.a=a}
function Dh(a){this.a=a}
function di(a){this.a=a}
function gi(a){this.a=a}
function oi(a){this.a=a}
function pi(a){this.a=a}
function ri(a){this.a=a}
function Le(a){this.c=a}
function Cf(a,b){a.key=b}
function Bf(a,b){Af(a,b)}
function Qh(a,b){De(a.c,b)}
function Zh(a,b){De(a.b,b)}
function ki(a,b){De(a.a,b)}
function Gg(a,b){return a.a=b}
function ze(a,b){return a===b}
function Fd(a){return a.b}
function Ni(a){return false}
function Mi(){return sf(this)}
function xe(){v(this);this.r()}
function r(){r=Wd;new q}
function D(){D=Wd;C=new n}
function U(){U=Wd;T=new X}
function K(){K=Wd;!!(ab(),$)}
function S(){H!=0&&(H=0);J=-1}
function Pd(){Nd==null&&(Nd=[])}
function of(a,b){a.splice(b,1)}
function eb(a,b){return ne(a,b)}
function jb(a){return new Array(a)}
function Fb(a){return a.l|a.m<<22}
function he(a){ge(a);return a.k}
function bf(a,b){a.D(b);return a}
function Lf(a,b){a.ref=b;return a}
function Mf(a,b){a.href=b;return a}
function ff(a,b){this.a=a;this.b=b}
function Jf(a,b){this.a=a;this.b=b}
function se(a,b){this.a=a;this.b=b}
function sg(a,b){se.call(this,a,b)}
function Ze(a,b){Ue(a);a.a.H(b)}
function cf(a,b){jf(a,bf(a.a,b))}
function Ce(a,b,c){nf(a.a,b,c)}
function Qe(a,b){while(a.I(b));}
function nf(a,b,c){a.splice(b,0,c)}
function Nh(a,b){se.call(this,a,b)}
function rh(){this.a=Df((fh(),eh))}
function Bh(){this.a=Df((jh(),ih))}
function Fh(){this.a=Df((nh(),mh))}
function Vg(){this.a=Df((ah(),_g))}
function Ug(){this.a=Df((Yg(),Xg))}
function vg(a){this.d=Pe(a);r();++ug}
function xg(a){this.d=Pe(a);r();++wg}
function Dg(a){this.d=Pe(a);r();++Cg}
function Sg(a){this.d=Pe(a);r();++Rg}
function Te(a){this.b=a;this.a=16464}
function Tb(a){return typeof a===ti}
function Vb(a){return a==null?null:a}
function nb(a){return ob(a.l,a.m,a.h)}
function Ph(a,b){a.a=b;Ee(a.c,new Sh)}
function bi(a,b){b.a=a;Ee(b.c,new Sh)}
function ji(a,b){a.b=b;Ee(a.a,new qi)}
function Vf(a,b){a.value=b;return a}
function Qf(a,b){a.onBlur=b;return a}
function Nf(a,b){a.onClick=b;return a}
function Rf(a,b){a.onChange=b;return a}
function Pf(a,b){a.checked=b;return a}
function R(a){$wnd.clearTimeout(a)}
function ye(a,b){return a.charCodeAt(b)}
function Je(a){return a.a<a.c.a.length}
function sf(a){return a.$H||(a.$H=++rf)}
function Rb(a,b){return a!=null&&Pb(a,b)}
function ob(a,b,c){return {l:a,m:b,h:c}}
function Wh(a,b){return Fe(a.a,b,0)!=-1}
function Af(a,b){for(var c in a){b(c)}}
function Sf(a,b){a.onKeyDown=b;return a}
function Of(a){a.autoFocus=true;return a}
function ge(a){if(a.k!=null){return}pe(a)}
function q(){this.a=new t;new u(this.a)}
function B(a){this.c=a;v(this);this.r()}
function af(a,b){We.call(this,a);this.a=b}
function Xh(a,b){Ge(a.a,b);Ee(a.b,new ei)}
function Bg(a,b){a.a=b;a.d.forceUpdate()}
function Ng(a,b){a.b=b;a.d.forceUpdate()}
function Oi(){this.a.d.forceUpdate()}
function Ie(){this.a=gb(rc,ui,1,0,5,1)}
function ai(){this.a=new Ie;this.b=new Ie}
function wf(){wf=Wd;tf=new n;vf=new n}
function be(){be=Wd;ae=$wnd.window.document}
function Ke(a){a.b=a.a++;return a.c.a[a.b]}
function v(a){a.d&&a.b!==vi&&a.r();return a}
function Wf(a,b){a.onDoubleClick=b;return a}
function w(a,b){a.b=b;b!=null&&qf(b,wi,a)}
function $h(a,b){Ph(b,!b.a);Ee(a.b,new ei)}
function ke(a){var b;b=je(a);re(a,b);return b}
function Ub(a){return typeof a==='string'}
function Sb(a){return typeof a==='boolean'}
function L(a,b,c){return a.apply(b,c);var d}
function qf(b,c,d){try{b[c]=d}catch(a){}}
function ce(a,b,c,d){a.addEventListener(b,c,d)}
function De(a,b){a.a[a.a.length]=b;return true}
function Ld(a){if(Tb(a)){return a|0}return Fb(a)}
function me(a){var b;b=je(a);b.j=a;b.e=1;return b}
function Y(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Md(a){if(Tb(a)){return ''+a}return Gb(a)}
function $e(a){Ve(a);return new af(a,new gf(a.a))}
function Ih(){Ih=Wd;Gh=new ai;Hh=new mi(Gh)}
function ab(){ab=Wd;var a;!cb();a=new db;$=a}
function de(){B.call(this,'divide by zero')}
function Hg(a){Xh((Ih(),Gh),a.d.props['a'])}
function Kg(a){$h((Ih(),Gh),a.d.props['a'])}
function df(a,b,c){if(a.a.K(c)){a.b=true;b.J(c)}}
function Ue(a){if(!a.b){Ve(a);a.c=true}else{Ue(a.b)}}
function Ye(a,b){Ve(a);return new af(a,new ef(b,a.a))}
function yg(a,b){var c;c=b.target;Bg(a,c.value)}
function Uf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Pe(a){if(a==null){throw Fd(new xe)}return a}
function zf(){if(uf==256){tf=vf;vf=new n;uf=0}++uf}
function ib(a){return Array.isArray(a)&&a.T===$d}
function Qb(a){return !Array.isArray(a)&&a.T===$d}
function ni(a,b){return (Mh(),Kh)==a||(Jh==a?!b.a:b.a)}
function Oe(a,b){return Vb(a)===Vb(b)||!!a&&Vb(a)===Vb(b)}
function Re(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function gf(a){Re.call(this,a.G(),a.F()&-6);this.a=a}
function We(a){if(!a){this.b=null;new Ie}else{this.b=a}}
function Se(a){if(!a.d){a.d=new Le(a.b);a.c=a.b.a.length}}
function Qg(a){Zh((Ih(),Gh),new Ch(a));ki(Hh,new Dh(a))}
function Yh(a,b,c){b.d=Pe(c);Ee(b.c,new Sh);Ee(a.b,new ei)}
function le(a,b){var c;c=je(a);re(a,c);c.e=b?8:0;return c}
function oe(a){if(a.B()){return null}var b=a.j;return Sd[b]}
function Yd(a){function b(){}
;b.prototype=a||{};return new b}
function Yg(){Yg=Wd;var a;Xg=(a=Xd(Wg.prototype.Q,Wg,[]),a)}
function ah(){ah=Wd;var a;_g=(a=Xd($g.prototype.Q,$g,[]),a)}
function fh(){fh=Wd;var a;eh=(a=Xd(dh.prototype.Q,dh,[]),a)}
function jh(){jh=Wd;var a;ih=(a=Xd(hh.prototype.Q,hh,[]),a)}
function nh(){nh=Wd;var a;mh=(a=Xd(lh.prototype.Q,lh,[]),a)}
function Oh(){Mh();return kb(eb(pd,1),ui,22,0,[Jh,Lh,Kh])}
function Q(a){K();$wnd.setTimeout(function(){throw a},0)}
function Zg(a){$wnd.React.Component.call(this,a);new vg(this)}
function bh(a){$wnd.React.Component.call(this,a);new xg(this)}
function Ve(a){if(a.b){Ve(a.b)}else if(a.c){throw Fd(new te)}}
function P(a){a&&W((U(),T));--H;if(a){if(J!=-1){R(J);J=-1}}}
function Ig(a){ji((Ih(),Hh),a.d.props['a']);Ng(a,a.d.props['a'].d)}
function Be(){B.call(this,'Add not supported on this collection')}
function ef(a,b){Re.call(this,b.G(),b.F()&-16449);this.a=a;this.c=b}
function gh(a){$wnd.React.Component.call(this,a);this.a=new Dg(this)}
function kh(a){$wnd.React.Component.call(this,a);this.a=new Pg(this)}
function oh(a){$wnd.React.Component.call(this,a);this.a=new Sg(this)}
function Rh(a,b){this.c=new Ie;this.b=Pe(a);this.d=Pe(b);this.a=false}
function Ud(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ne(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.t(b))}
function O(a,b,c){var d;d=M();try{return L(a,b,c)}finally{P(d)}}
function N(b){K();return function(){return O(b,this,arguments);var a}}
function G(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Tf(a){a.placeholder='What needs to be done?';return a}
function Xe(a){var b;Ue(a);b=0;while(a.a.I(new lf)){b=Gd(b,1)}return b}
function _e(a,b){var c;Ue(a);c=new kf;c.a=b;a.a.H(new mf(c));return c.a}
function _h(a,b){Ze(new af(null,new Te(a.a)),new gi(b));Ee(a.b,new ei)}
function Th(a,b){De(a.a,new Rh(''+Md(Id(Date.now())),b));Ee(a.b,new ei)}
function li(a){var b;b=a.b;!!b&&!Wh(a.c,b)&&(a.b=null,Ee(a.a,new qi))}
function If(a,b,c){!ze(c,'key')&&!ze(c,'ref')&&(a[c]=b[c],undefined)}
function gb(a,b,c,d,e,f){var g;g=hb(e,d);e!=10&&kb(eb(a,f),b,c,e,g);return g}
function Ge(a,b){var c;c=Fe(a,b,0);if(c==-1){return false}of(a.a,c);return true}
function A(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Fe(a,b,c){for(;c<a.a.length;++c){if(Oe(b,a.a[c])){return c}}return -1}
function Ne(a,b){while(a.a<a.c.a.length){b.J((a.b=a.a++,a.c.a[a.b]))}}
function Ee(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.J(c)}}
function mb(a){var b,c,d;b=a&yi;c=a>>22&yi;d=a<0?zi:0;return ob(b,c,d)}
function Lb(){Lb=Wd;Hb=ob(yi,yi,524287);Ib=ob(0,0,Ai);Jb=mb(1);mb(2);Kb=mb(0)}
function t(){var a;this.a=gb(Zb,ui,27,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function V(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Z(b,c)}while(a.a);a.a=c}}
function W(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Z(b,c)}while(a.b);a.b=c}}
function Eg(a,b){var c;if((Ih(),Hh).b==a.d.props['a']){c=b.target;Ng(a,c.value)}}
function re(a,b){var c;if(!a){return}b.j=a;var d=oe(b);if(!d){Sd[a]=[b];return}d.R=b}
function Ed(a){var b;if(Rb(a,5)){return a}b=a&&a[wi];if(!b){b=new F(a);bb(b)}return b}
function Xd(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ve(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function je(a){var b;b=new ie;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Df(a){var b;b=Ff($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Gf(a){var b;return Ef($wnd.React.StrictMode,null,null,(b={},b[Ei]=Pe(a),b))}
function Uh(a){var b;_e(Ye(new af(null,new Te(a.a)),new ci),(b=new Ie,b)).C(new di(a))}
function Mh(){Mh=Wd;Jh=new Nh('ACTIVE',0);Lh=new Nh('COMPLETED',1);Kh=new Nh('ALL',2)}
function _d(){$wnd.ReactDOM.render(Gf([(new Fh).a]),(be(),ae).getElementById('app'),null)}
function pf(a,b){return fb(b)!=10&&kb(o(b),b.S,b.__elementTypeId$,fb(b),a),a}
function fb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Wb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function te(){B.call(this,"Stream already terminated, can't be modified or used")}
function Od(){Pd();var a=Nd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function we(a,b){var c,d;for(d=new Le(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Xh(b.a,c)}}
function Kd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Bi;d=zi}c=Wb(e/Ci);b=Wb(e-c*Ci);return ob(b,c,d)}
function yb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ob(c&yi,d&yi,e&zi)}
function Eb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return ob(c&yi,d&yi,e&zi)}
function Hd(a){var b;b=a.h;if(b==0){return a.l+a.m*Ci}if(b==zi){return a.l+a.m*Ci-Bi}return a}
function Id(a){if(Di<a&&a<Bi){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Hd(Ab(a))}
function Ah(a,b){Cf(a.a,(ge(kd),kd.k+(''+(b?b.b:null))));Pe(b);a.a.props['a']=b;return a.a}
function Fg(a,b){27==b.which?(ji((Ih(),Hh),null),Ng(a,a.d.props['a'].d)):13==b.which&&Jg(a)}
function Pg(a){this.d=Pe(a);r();++Og;this.b=this.d.props['a'].d;Qh(this.d.props['a'],new sh(this))}
function F(a){D();v(this);this.b=a;a!=null&&qf(a,wi,this);this.c=a==null?'null':Zd(a);this.a=a}
function ie(){this.g=fe++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Vh(a){return Ld(Xe(new af(null,new Te(a.a))))-Ld(Xe(Ye(new af(null,new Te(a.a)),new fi)))}
function o(a){return Ub(a)?tc:Tb(a)?kc:Sb(a)?ic:Qb(a)?a.R:ib(a)?a.R:a.R||Array.isArray(a)&&eb(bc,1)||bc}
function Bb(a){var b,c,d;b=~a.l+1&yi;c=~a.m+(b==0?1:0)&yi;d=~a.h+(b==0&&c==0?1:0)&zi;return ob(b,c,d)}
function ub(a){var b,c,d;b=~a.l+1&yi;c=~a.m+(b==0?1:0)&yi;d=~a.h+(b==0&&c==0?1:0)&zi;a.l=b;a.m=c;a.h=d}
function vb(a){var b,c;c=ue(a.h);if(c==32){b=ue(a.m);return b==32?ue(a.l)+32:b+20-10}else{return c-12}}
function Ef(a,b,c,d){var e;e=Ff($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Pe(d);return e}
function kb(a,b,c,d,e){e.R=a;e.S=b;e.T=$d;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function rb(a,b,c,d,e){var f;f=Db(a,b);c&&ub(f);if(e){a=tb(a,b);d?(lb=Bb(a)):(lb=ob(a.l,a.m,a.h))}return f}
function qb(a,b){if(a.h==Ai&&a.m==0&&a.l==0){b&&(lb=ob(0,0,0));return nb((Lb(),Jb))}b&&(lb=ob(a.l,a.m,a.h));return ob(0,0,0)}
function Zd(a){var b;if(Array.isArray(a)&&a.T===$d){return he(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function Gd(a,b){var c;if(Tb(a)&&Tb(b)){c=a+b;if(Di<c&&c<Bi){return c}}return Hd(yb(Tb(a)?Kd(a):a,Tb(b)?Kd(b):b))}
function Rd(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function mi(a){this.a=new Ie;this.c=Pe(a);ce((be(),$wnd.window.window),'hashchange',new oi(this),false);Zh(a,new pi(this))}
function tg(){rg();return kb(eb(Nc,1),ui,6,0,[Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg])}
function M(){var a;if(H!=0){a=G();if(a-I>2000){I=a;J=$wnd.setTimeout(S,10)}}if(H++==0){V((U(),T));return true}return false}
function yf(a){wf();var b,c,d;c=':'+a;d=vf[c];if(d!=null){return Wb(d)}d=tf[c];b=d==null?xf(a):Wb(d);zf();vf[c]=b;return b}
function Me(a){var b,c,d;d=1;for(c=new Le(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function He(a,b){var c,d;d=a.a.length;b.length<d&&(b=pf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function qe(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function zg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=Ae(a.a);if(c.length>0){Th((Ih(),Gh),c);a.a='';a.d.forceUpdate()}}}
function Jg(a){if(null!=a.b&&a.b.length!=0){Yh((Ih(),Gh),a.d.props['a'],a.b);ji(Hh,null);Ng(a,a.b)}else{Xh((Ih(),Gh),a.d.props['a'])}}
function p(a){return Ub(a)?yf(a):Tb(a)?Wb(a):Sb(a)?a?1231:1237:Qb(a)?a.o():ib(a)?sf(a):!!a&&!!a.hashCode?a.hashCode():sf(a)}
function cb(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Kf(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Pb(a,b){if(Ub(a)){return !!Ob[b]}else if(a.S){return !!a.S[b]}else if(Tb(a)){return !!Nb[b]}else if(Sb(a)){return !!Mb[b]}return false}
function Lg(a){var b;b=(Ih(),Hh).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();Ng(a,a.d.props['a'].d)}else a.c&&!b&&(a.c=false)}
function Ae(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function tb(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return ob(c,d,e)}
function Cb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return ob(c&yi,d&yi,e&zi)}
function hb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function xb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&yi;a.m=d&yi;a.h=e&zi;return true}
function Ag(a){return Hf(Gi,Of(Rf(Sf(Vf(Tf(Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,['new-todo']))),a.a),Xd(ph.prototype.O,ph,[a])),Xd(qh.prototype.N,qh,[a]))),null)}
function zb(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Qd(b,c,d,e){Pd();var f=Nd;$moduleName=c;$moduleBase=d;Dd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{si(g)()}catch(a){b(c,a)}}else{si(g)()}}
function Ff(a,b){var c;c=new $wnd.Object;c.$$typeof=Pe(a);c.type=Pe(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Z(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].U()&&(c=Y(c,g)):g[0].U()}catch(a){a=Ed(a);if(Rb(a,5)){d=a;K();Q(Rb(d,24)?d.s():d)}else throw Fd(a)}}return c}
function Td(){Sd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function xf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ye(a,c++)}b=b|0;return b}
function hi(a){var b,c,d,e;b=(e=(c=(be(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),ze(Hi,e)?(Mh(),Jh):ze(Ii,e)?(Mh(),Lh):(Mh(),Kh));return _e(Ye(new af(null,new Te(a.c.a)),new ri(b)),(d=new Ie,d))}
function ue(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Vd(a,b,c){var d=Sd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Sd[b]),Yd(h));_.S=c;!b&&(_.T=$d);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.R=f)}
function Db(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&Ai)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?zi:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?zi:0;f=d?yi:0;e=c>>b-44}return ob(e&yi,f&yi,g&zi)}
function pe(a){if(a.A()){var b=a.c;b.B()?(a.k='['+b.j):!b.A()?(a.k='[L'+b.v()+';'):(a.k='['+b.v());a.b=b.u()+'[]';a.i=b.w()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=qe('.',[c,qe('$',d)]);a.b=qe('.',[c,qe('.',d)]);a.i=d[d.length-1]}
function Hf(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Bf(b,Xd(Jf.prototype.L,Jf,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ei]=c[0],undefined):(d[Ei]=c,undefined));return Ef(a,e,f,d)}
function wb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return ve(c)}if(b==0&&d!=0&&c==0){return ve(d)+22}if(b!=0&&d==0&&c==0){return ve(b)+44}return -1}
function Ab(a){var b,c,d,e,f;if(isNaN(a)){return Lb(),Kb}if(a<-9223372036854775808){return Lb(),Ib}if(a>=9223372036854775807){return Lb(),Hb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=Bi){d=Wb(a/Bi);a-=d*Bi}c=0;if(a>=Ci){c=Wb(a/Ci);a-=c*Ci}b=Wb(a);f=ob(b,c,d);e&&ub(f);return f}
function ii(a,b){var c,d,e;b.preventDefault();c=(d=(be(),$wnd.window.window).location.hash,null==d?'':d.substr(1));if(ze(Hi,c)||ze(Ii,c)||ze('',c)){Ee(a.a,new qi)}else{e=$wnd.window.window.location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',ae.title,e)}}
function Gb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==Ai&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Gb(Bb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=mb(1000000000);c=pb(c,e,true);b=''+Fb(lb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function sb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=vb(b)-vb(a);g=Cb(b,j);i=ob(0,0,0);while(j>=0){h=xb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&ub(i);if(f){if(d){lb=Bb(a);e&&(lb=Eb(lb,(Lb(),Jb)))}else{lb=ob(a.l,a.m,a.h)}}return i}
function rg(){rg=Wd;Xf=new sg(Fi,0);Yf=new sg('checkbox',1);Zf=new sg('color',2);$f=new sg('date',3);_f=new sg('datetime',4);ag=new sg('email',5);bg=new sg('file',6);cg=new sg('hidden',7);dg=new sg('image',8);eg=new sg('month',9);fg=new sg(ti,10);gg=new sg('password',11);hg=new sg('radio',12);ig=new sg('range',13);jg=new sg('reset',14);kg=new sg('search',15);lg=new sg('submit',16);mg=new sg('tel',17);ng=new sg('text',18);og=new sg('time',19);pg=new sg('url',20);qg=new sg('week',21)}
function pb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Fd(new de)}if(a.l==0&&a.m==0&&a.h==0){c&&(lb=ob(0,0,0));return ob(0,0,0)}if(b.h==Ai&&b.m==0&&b.l==0){return qb(a,c)}i=false;if(b.h>>19!=0){b=Bb(b);i=true}g=wb(b);f=false;e=false;d=false;if(a.h==Ai&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=nb((Lb(),Hb));d=true;i=!i}else{h=Db(a,g);i&&ub(h);c&&(lb=ob(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Bb(a);d=true;i=!i}if(g!=-1){return rb(a,g,i,f,c)}if(zb(a,b)<0){c&&(f?(lb=Bb(a)):(lb=ob(a.l,a.m,a.h)));return ob(0,0,0)}return sb(d?a:ob(a.l,a.m,a.h),b,i,f,e,c)}
function Mg(a){var b,c;c=a.d.props['a'];b=c.a;return Hf('li',Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,[b?'checked':null,(Ih(),Hh).b==a.d.props['a']?'editing':null])),[Hf('div',Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,['view'])),[Hf(Gi,Rf(Pf(Uf(Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,['toggle'])),(rg(),Yf)),b),Xd(vh.prototype.N,vh,[a])),null),Hf('label',Wf(new $wnd.Object,Xd(wh.prototype.P,wh,[a])),[c.d]),Hf(Fi,Nf(Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,['destroy'])),Xd(xh.prototype.P,xh,[a])),null)]),Hf(Gi,Sf(Rf(Qf(Vf(Kf(Lf(new $wnd.Object,Xd(yh.prototype.J,yh,[a])),kb(eb(tc,1),ui,2,6,['edit'])),a.b),Xd(zh.prototype.M,zh,[a])),Xd(th.prototype.N,th,[a])),Xd(uh.prototype.O,uh,[a])),null)])}
var ti='number',ui={3:1,4:1},vi='__noinit__',wi='__java$exception',xi={3:1,7:1,5:1},yi=4194303,zi=1048575,Ai=524288,Bi=17592186044416,Ci=4194304,Di=-17592186044416,Ei='children',Fi='button',Gi='input',Hi='active',Ii='completed',Ji='selected',Ki='header',Li={40:1};var _,Sd,Nd,Dd=-1;Td();Vd(1,null,{},n);_.n=function(){return this.R};_.o=Mi;_.hashCode=function(){return this.o()};var Mb,Nb,Ob;Vd(33,1,{},ie);_.t=function(a){var b;b=new ie;b.e=4;a>1?(b.c=ne(this,a-1)):(b.c=this);return b};_.u=function(){ge(this);return this.b};_.v=function(){return he(this)};_.w=function(){ge(this);return this.i};_.A=function(){return (this.e&4)!=0};_.B=function(){return (this.e&1)!=0};_.e=0;_.g=0;var fe=1;var rc=ke(1);var jc=ke(33);Vd(60,1,{},q);var Yb=ke(60);Vd(27,1,{27:1},s);var Zb=ke(27);Vd(71,1,{147:1},t);var $b=ke(71);Vd(72,1,{},u);var _b=ke(72);Vd(5,1,{3:1,5:1});_.q=function(a){return new Error(a)};_.r=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=he(this.R),c==null?a:a+': '+c);w(this,A(this.q(b)));bb(this)};_.b=vi;_.d=true;var uc=ke(5);Vd(25,5,{3:1,5:1});var mc=ke(25);Vd(7,25,xi);var sc=ke(7);Vd(34,7,xi);var oc=ke(34);Vd(46,34,xi);var dc=ke(46);Vd(24,46,{24:1,3:1,7:1,5:1},F);_.s=function(){return Vb(this.a)===Vb(C)?null:this.a};var C;var ac=ke(24);var bc=ke(0);Vd(102,1,{});var cc=ke(102);var H=0,I=0,J=-1;Vd(54,102,{},X);var T;var ec=ke(54);var $;Vd(115,1,{});var gc=ke(115);Vd(47,115,{},db);var fc=ke(47);var lb;var Hb,Ib,Jb,Kb;var ae;Vd(52,7,xi,de);var hc=ke(52);Mb={3:1,23:1};var ic=ke(112);Vd(113,1,{3:1});var qc=ke(113);Nb={3:1,23:1};var kc=ke(114);Vd(20,1,{3:1,23:1,20:1});_.o=Mi;_.b=0;var lc=ke(20);Vd(49,7,xi,te);var nc=ke(49);Vd(176,1,{});Vd(51,34,xi,xe);_.q=function(a){return new TypeError(a)};var pc=ke(51);Ob={3:1,42:1,23:1,2:1};var tc=ke(2);Vd(180,1,{});Vd(50,7,xi,Be);var vc=ke(50);Vd(116,1,{99:1});_.C=function(a){we(this,a)};_.D=function(a){throw Fd(new Be)};var wc=ke(116);Vd(117,116,{99:1,123:1});_.D=function(a){Ce(this,this.a.length,a);return true};_.o=function(){return Me(this)};var xc=ke(117);Vd(12,117,{3:1,12:1,99:1,123:1},Ie);_.D=function(a){return De(this,a)};_.C=function(a){Ee(this,a)};var zc=ke(12);Vd(17,1,{},Le);_.a=0;_.b=-1;var yc=ke(17);Vd(75,1,{});_.H=function(a){Qe(this,a)};_.F=function(){return this.d};_.G=function(){return this.e};_.d=0;_.e=0;var Bc=ke(75);Vd(36,75,{});var Ac=ke(36);Vd(13,1,{},Te);_.F=function(){return this.a};_.G=function(){Se(this);return this.c};_.H=function(a){Se(this);Ne(this.d,a)};_.I=function(a){Se(this);if(Je(this.d)){a.J(Ke(this.d));return true}return false};_.a=0;_.c=0;var Cc=ke(13);Vd(74,1,{});_.c=false;var Lc=ke(74);Vd(10,74,{146:1,10:1},af);var Kc=ke(10);Vd(77,36,{},ef);_.I=function(a){this.b=false;while(!this.b&&this.c.I(new ff(this,a)));return this.b};_.b=false;var Ec=ke(77);Vd(80,1,{},ff);_.J=function(a){df(this.a,this.b,a)};var Dc=ke(80);Vd(76,36,{},gf);_.I=function(a){return this.a.I(new hf(a))};var Gc=ke(76);Vd(79,1,{},hf);_.J=function(a){this.a.J(Ah(new Bh,a))};var Fc=ke(79);Vd(78,1,{},kf);_.J=function(a){jf(this,a)};var Hc=ke(78);Vd(81,1,{},lf);_.J=function(a){};var Ic=ke(81);Vd(82,1,{},mf);_.J=function(a){cf(this.a,a)};var Jc=ke(82);Vd(178,1,{});Vd(175,1,{});var rf=0;var tf,uf=0,vf;Vd(786,1,{});Vd(807,1,{});Vd(118,1,{});var Mc=ke(118);Vd(145,$wnd.Function,{},Jf);_.L=function(a){If(this.a,this.b,a)};Vd(6,20,{3:1,23:1,20:1,6:1},sg);var Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg;var Nc=le(6,tg);Vd(121,118,{});var Wc=ke(121);Vd(91,121,{});var $c=ke(91);Vd(92,91,{},vg);_.o=Mi;var ug=0;var Pc=ke(92);Vd(122,118,{});var Vc=ke(122);Vd(97,122,{});var Zc=ke(97);Vd(98,97,{},xg);_.o=Mi;var wg=0;var Oc=ke(98);Vd(88,118,{});_.a='';var gd=ke(88);Vd(89,88,{});var ad=ke(89);Vd(90,89,{},Dg);_.o=Mi;var Cg=0;var Qc=ke(90);Vd(120,118,{});_.c=false;var kd=ke(120);Vd(94,120,{});var cd=ke(94);Vd(95,94,{},Pg);_.o=Mi;var Og=0;var Rc=ke(95);Vd(119,118,{});var od=ke(119);Vd(58,119,{});var ed=ke(58);Vd(59,58,{},Sg);_.o=Mi;var Rg=0;var Sc=ke(59);Vd(152,$wnd.Function,{},Tg);_.P=function(a){Uh((Ih(),Gh))};Vd(66,1,{},Ug);var Tc=ke(66);Vd(93,1,{},Vg);var Uc=ke(93);Vd(151,$wnd.Function,{},Wg);_.Q=function(a){return new Zg(a)};var Xg;Vd(84,$wnd.React.Component,{},Zg);Ud(Sd[1],_);_.render=function(){var a,b,c;return a=(c=(Ih(),b=(be(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),ze(Hi,c)?(Mh(),Jh):ze(Ii,c)?(Mh(),Lh):(Mh(),Kh)),Hf('footer',Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,['footer'])),[(new Vg).a,Hf('ul',Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,['filters'])),[Hf('li',null,[Hf('a',Mf(Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,[(Mh(),Kh)==a?Ji:null])),'#'),['All'])]),Hf('li',null,[Hf('a',Mf(Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,[Jh==a?Ji:null])),'#active'),['Active'])]),Hf('li',null,[Hf('a',Mf(Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,[Lh==a?Ji:null])),'#completed'),['Completed'])])]),Vh(Gh)>0?Hf(Fi,Nf(Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,['clear-completed'])),Xd(Tg.prototype.P,Tg,[])),['Clear Completed']):null])};_.shouldComponentUpdate=Ni;var Xc=ke(84);Vd(162,$wnd.Function,{},$g);_.Q=function(a){return new bh(a)};var _g;Vd(96,$wnd.React.Component,{},bh);Ud(Sd[1],_);_.render=function(){var a,b;return a=Ld(Xe(new af(null,new Te((Ih(),Gh).a)))),b='item'+(a==1?'':'s'),Hf('span',Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,['todo-count'])),[Hf('strong',null,[a]),' '+b+' left'])};_.shouldComponentUpdate=Ni;var Yc=ke(96);Vd(148,$wnd.Function,{},dh);_.Q=function(a){return new gh(a)};var eh;Vd(73,$wnd.React.Component,{},gh);Ud(Sd[1],_);_.render=function(){return Ag(this.a)};_.shouldComponentUpdate=Ni;var _c=ke(73);Vd(161,$wnd.Function,{},hh);_.Q=function(a){return new kh(a)};var ih;Vd(87,$wnd.React.Component,{},kh);Ud(Sd[1],_);_.componentDidUpdate=function(a){Lg(this.a)};_.render=function(){return Mg(this.a)};_.shouldComponentUpdate=Ni;var bd=ke(87);Vd(143,$wnd.Function,{},lh);_.Q=function(a){return new oh(a)};var mh;Vd(55,$wnd.React.Component,{},oh);Ud(Sd[1],_);_.componentDidMount=function(){Qg(this.a)};_.render=function(){var a,b;return Hf('div',null,[Hf('div',null,[Hf(Ki,Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,[Ki])),[Hf('h1',null,['todos']),(new rh).a]),0!=Ld(Xe(new af(null,new Te((Ih(),Gh).a))))?Hf('section',Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,[Ki])),[Hf(Gi,Rf(Uf(Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,['toggle-all'])),(rg(),Yf)),Xd(Eh.prototype.N,Eh,[])),null),Hf('ul',Kf(new $wnd.Object,kb(eb(tc,1),ui,2,6,['todo-list'])),(a=_e(Pe($e(new af(null,new Te(hi(Hh))))),(b=new Ie,b)),He(a,jb(a.a.length))))]):null,0!=Ld(Xe(new af(null,new Te(Gh.a))))?(new Ug).a:null])])};_.shouldComponentUpdate=Ni;var dd=ke(55);Vd(149,$wnd.Function,{},ph);_.O=function(a){zg(this.a,a)};Vd(150,$wnd.Function,{},qh);_.N=function(a){yg(this.a,a)};Vd(61,1,{},rh);var fd=ke(61);Vd(86,1,Li,sh);_.p=Oi;var hd=ke(86);Vd(159,$wnd.Function,{},th);_.N=function(a){Eg(this.a,a)};Vd(160,$wnd.Function,{},uh);_.O=function(a){Fg(this.a,a)};Vd(153,$wnd.Function,{},vh);_.N=function(a){Kg(this.a)};Vd(155,$wnd.Function,{},wh);_.P=function(a){Ig(this.a)};Vd(156,$wnd.Function,{},xh);_.P=function(a){Hg(this.a)};Vd(157,$wnd.Function,{},yh);_.J=function(a){Gg(this.a,a)};Vd(158,$wnd.Function,{},zh);_.M=function(a){Jg(this.a)};Vd(85,1,{},Bh);var jd=ke(85);Vd(56,1,Li,Ch);_.p=Oi;var ld=ke(56);Vd(57,1,Li,Dh);_.p=Oi;var md=ke(57);Vd(144,$wnd.Function,{},Eh);_.N=function(a){var b;b=a.target;_h((Ih(),Gh),b.checked)};Vd(41,1,{},Fh);var nd=ke(41);var Gh,Hh;Vd(22,20,{3:1,23:1,20:1,22:1},Nh);var Jh,Kh,Lh;var pd=le(22,Oh);Vd(37,1,{37:1},Rh);_.a=false;var xd=ke(37);Vd(28,1,{},Sh);_.J=Pi;var qd=ke(28);Vd(35,1,{35:1},ai);var wd=ke(35);Vd(64,1,{},ci);_.K=function(a){return a.a};var rd=ke(64);Vd(65,1,{},di);_.J=function(a){Xh(this.a,a)};var sd=ke(65);Vd(21,1,{},ei);_.J=Pi;var td=ke(21);Vd(62,1,{},fi);_.K=function(a){return !a.a};var ud=ke(62);Vd(63,1,{},gi);_.J=function(a){bi(this.a,a)};_.a=false;var vd=ke(63);Vd(67,1,{},mi);var Cd=ke(67);Vd(68,1,{},oi);_.handleEvent=function(a){ii(this.a,a)};var yd=ke(68);Vd(69,1,Li,pi);_.p=function(){li(this.a)};var zd=ke(69);Vd(26,1,{},qi);_.J=Pi;var Ad=ke(26);Vd(70,1,{},ri);_.K=function(a){return ni(this.a,a)};var Bd=ke(70);var Xb=me('D');var si=(K(),N);var gwtOnLoad=gwtOnLoad=Qd;Od(_d);Rd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();