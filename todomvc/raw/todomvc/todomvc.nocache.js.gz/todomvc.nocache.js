function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='9780F6D9A592954F6C108A6D3EA7C709',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|interactive|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '9780F6D9A592954F6C108A6D3EA7C709';function n(){}
function s(){}
function Y(){}
function Yg(){}
function qg(){}
function rg(){}
function Rg(){}
function Ug(){}
function Xd(){}
function Td(){}
function eb(){}
function ef(){}
function ff(){}
function fh(){}
function ah(){}
function jh(){}
function zh(){}
function Xh(){}
function Zh(){}
function $h(){}
function ki(){}
function Hi(a){a()}
function cb(a){bb()}
function v(a){Ke(a)}
function u(){new De}
function be(){be=Td}
function Wh(a,b){b.a=a}
function df(a,b){a.a=b}
function cf(a){this.a=a}
function gf(a){this.a=a}
function nh(a){this.a=a}
function oh(a){this.a=a}
function qh(a){this.a=a}
function rh(a){this.a=a}
function sh(a){this.a=a}
function th(a){this.a=a}
function uh(a){this.a=a}
function vh(a){this.a=a}
function wh(a){this.a=a}
function Yh(a){this.a=a}
function _h(a){this.a=a}
function ii(a){this.a=a}
function ji(a){this.a=a}
function li(a){this.a=a}
function Ge(a){this.c=a}
function xf(a,b){a.key=b}
function wf(a,b){vf(a,b)}
function Sh(a,b){ye(a.b,b)}
function ei(a,b){ye(a.a,b)}
function Eg(a,b){return a.a=b}
function ve(a,b){return a===b}
function Cd(a){return a.b}
function r(){r=Td;new q}
function F(){F=Td;D=new n}
function V(){V=Td;U=new Y}
function L(){L=Td;!!(bb(),ab)}
function xe(a){C.call(this,a)}
function te(){w(this);this.q()}
function Fi(){return nf(this)}
function fb(a,b){return je(a,b)}
function jf(a,b){a.splice(b,1)}
function Le(a,b){while(a.J(b));}
function Ze(a,b){df(a,Ye(a.a,b))}
function Ue(a,b){Pe(a);a.a.I(b)}
function Ye(a,b){a.C(b);return a}
function Gf(a,b){a.ref=b;return a}
function ee(a){de(a);return a.k}
function Hf(a,b){a.href=b;return a}
function af(a,b){this.a=a;this.b=b}
function Ef(a,b){this.a=a;this.b=b}
function oe(a,b){this.a=a;this.b=b}
function og(a,b){oe.call(this,a,b)}
function hf(a,b,c){a.splice(b,0,c)}
function Sg(){this.a=yf((Wg(),Vg))}
function Tg(){this.a=yf(($g(),Zg))}
function ph(){this.a=yf((dh(),bh))}
function yh(){this.a=yf((hh(),gh))}
function Ah(){this.a=yf((lh(),kh))}
function Oe(a){this.b=a;this.a=16464}
function Ih(a,b){oe.call(this,a,b)}
function Rf(a,b){a.value=b;return a}
function Mf(a,b){a.onBlur=b;return a}
function S(a){$wnd.clearTimeout(a)}
function kb(a){return new Array(a)}
function Gb(a){return a.l|a.m<<22}
function ob(a){return pb(a.l,a.m,a.h)}
function Ub(a){return typeof a===ni}
function Wb(a){return a==null?null:a}
function Md(){Kd==null&&(Kd=[])}
function T(){I!=0&&(I=0);K=-1}
function tg(a){this.d=Ke(a);r();++sg}
function vg(a){this.d=Ke(a);r();++ug}
function Bg(a){this.d=Ke(a);r();++Ag}
function Qg(a){this.d=Ke(a);r();++Pg}
function C(a){this.c=a;w(this);this.q()}
function De(){this.a=hb(sc,oi,1,0,5,1)}
function di(a,b){a.b=b;ze(a.a,new ki)}
function Kf(a,b){a.checked=b;return a}
function If(a,b){a.onClick=b;return a}
function Nf(a,b){a.onChange=b;return a}
function Of(a,b){a.onKeyDown=b;return a}
function Jf(a){a.autoFocus=true;return a}
function rf(){rf=Td;of=new n;qf=new n}
function nf(a){return a.$H||(a.$H=++mf)}
function Ee(a){return a.a<a.c.a.length}
function ue(a,b){return a.charCodeAt(b)}
function Sb(a,b){return a!=null&&Qb(a,b)}
function A(a,b){a.b=b;b!=null&&lf(b,qi,a)}
function Lg(a,b){a.b=b;a.d.forceUpdate()}
function zg(a,b){a.a=b;a.d.forceUpdate()}
function Qh(a,b){Be(a.a,b);ze(a.b,new Zh)}
function Ph(a,b){return Ae(a.a,b,0)!=-1}
function pb(a,b,c){return {l:a,m:b,h:c}}
function vf(a,b){for(var c in a){b(c)}}
function lf(b,c,d){try{b[c]=d}catch(a){}}
function M(a,b,c){return a.apply(b,c);var d}
function Vb(a){return typeof a==='string'}
function Tb(a){return typeof a==='boolean'}
function de(a){if(a.k!=null){return}le(a)}
function Fe(a){a.b=a.a++;return a.c.a[a.b]}
function Lf(a,b){a.defaultValue=b;return a}
function Sf(a,b){a.onDoubleClick=b;return a}
function w(a){a.d&&a.b!==pi&&a.q();return a}
function he(a){var b;b=ge(a);ne(a,b);return b}
function Rh(a,b,c){b.c=Ke(c);ze(a.b,new Zh)}
function Th(a,b){df(b,!b.a);ze(a.b,new Zh)}
function Vh(){this.a=new De;this.b=new De}
function q(){this.a=new t;new v(this.a);new u}
function Dh(){Dh=Td;Bh=new Vh;Ch=new gi(Bh)}
function bb(){bb=Td;var a;!db();a=new eb;ab=a}
function $d(){$d=Td;Zd=$wnd.window.document}
function ae(){C.call(this,'divide by zero')}
function Xe(a,b){Re.call(this,a);this.a=b}
function ye(a,b){a.a[a.a.length]=b;return true}
function Z(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Id(a){if(Ub(a)){return a|0}return Gb(a)}
function Jd(a){if(Ub(a)){return ''+a}return Hb(a)}
function Ve(a){Qe(a);return new Xe(a,new bf(a.a))}
function Pe(a){if(!a.b){Qe(a);a.c=true}else{Pe(a.b)}}
function $e(a,b,c){if(a.a.L(c)){a.b=true;b.K(c)}}
function Fg(a){Qh((Dh(),Bh),a.d.props['a'])}
function Ig(a){Th((Dh(),Bh),a.d.props['a'])}
function wg(a,b){var c;c=b.target;zg(a,c.value)}
function Te(a,b){Qe(a);return new Xe(a,new _e(b,a.a))}
function Ke(a){if(a==null){throw Cd(new te)}return a}
function uf(){if(pf==256){of=qf;qf=new n;pf=0}++pf}
function Re(a){if(!a){this.b=null;new De}else{this.b=a}}
function bf(a){Me.call(this,a.H(),a.G()&-6);this.a=a}
function Lh(a,b){this.b=Ke(a);this.c=Ke(b);this.a=false}
function Me(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Qf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ie(a,b){var c;c=ge(a);ne(a,c);c.e=b?8:0;return c}
function Ne(a){if(!a.d){a.d=new Ge(a.b);a.c=a.b.a.length}}
function ke(a){if(a.A()){return null}var b=a.j;return Pd[b]}
function jb(a){return Array.isArray(a)&&a.V===Xd}
function Rb(a){return !Array.isArray(a)&&a.V===Xd}
function hi(a,b){return (Hh(),Fh)==a||(Eh==a?!b.a:b.a)}
function Je(a,b){return Wb(a)===Wb(b)||!!a&&Wb(a)===Wb(b)}
function Jh(){Hh();return lb(fb(od,1),oi,20,0,[Eh,Gh,Fh])}
function dh(){dh=Td;var a;bh=(a=Ud(ah.prototype.S,ah,[]),a)}
function hh(){hh=Td;var a;gh=(a=Ud(fh.prototype.S,fh,[]),a)}
function lh(){lh=Td;var a;kh=(a=Ud(jh.prototype.S,jh,[]),a)}
function Wg(){Wg=Td;var a;Vg=(a=Ud(Ug.prototype.S,Ug,[]),a)}
function $g(){$g=Td;var a;Zg=(a=Ud(Yg.prototype.S,Yg,[]),a)}
function Vd(a){function b(){}
;b.prototype=a||{};return new b}
function xh(a,b){xf(a.a,b.b);Ke(b);a.a.props['a']=b;return a.a}
function Qe(a){if(a.b){Qe(a.b)}else if(a.c){throw Cd(new pe)}}
function R(a){L();$wnd.setTimeout(function(){throw a},0)}
function Xg(a){$wnd.React.Component.call(this,a);new tg(this)}
function _g(a){$wnd.React.Component.call(this,a);new vg(this)}
function mh(a){$wnd.React.Component.call(this,a);new Qg(this)}
function Og(a){this.d=Ke(a);r();++Ng;this.b=this.d.props['a'].c}
function Q(a){a&&X((V(),U));--I;if(a){if(K!=-1){S(K);K=-1}}}
function Pf(a){a.placeholder='What needs to be done?';return a}
function B(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Rd(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function je(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.s(b))}
function P(a,b,c){var d;d=N();try{return M(a,b,c)}finally{Q(d)}}
function _d(a,b,c,d){a.addEventListener(b,c,(be(),d?true:false))}
function Df(a,b,c){!ve(c,'key')&&!ve(c,'ref')&&(a[c]=b[c],undefined)}
function fi(a){var b;b=a.b;!!b&&!Ph(a.c,b)&&(a.b=null,ze(a.a,new ki))}
function Uh(a,b){Ue(new Xe(null,new Oe(a.a)),new _h(b));ze(a.b,new Zh)}
function We(a,b){var c;Pe(a);c=new ef;c.a=b;a.a.I(new gf(c));return c.a}
function Se(a){var b;Pe(a);b=0;while(a.a.J(new ff)){b=Dd(b,1)}return b}
function nb(a){var b,c,d;b=a&si;c=a>>22&si;d=a<0?ti:0;return pb(b,c,d)}
function eh(a){$wnd.React.Component.call(this,a);this.a=new Bg(this)}
function ih(a){$wnd.React.Component.call(this,a);this.a=new Og(this)}
function _e(a,b){Me.call(this,b.H(),b.G()&-16449);this.a=a;this.c=b}
function Ie(a,b){while(a.a<a.c.a.length){b.K((a.b=a.a++,a.c.a[a.b]))}}
function Ae(a,b,c){for(;c<a.a.length;++c){if(Je(b,a.a[c])){return c}}return -1}
function Mh(a,b){ye(a.a,new Lh(''+Jd(Fd(Date.now())),b));ze(a.b,new Zh)}
function H(){if(Date.now){return Date.now()}return (new Date).getTime()}
function O(b){L();return function(){return P(b,this,arguments);var a}}
function Xb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function kf(a,b){return gb(b)!=10&&lb(o(b),b.U,b.__elementTypeId$,gb(b),a),a}
function gb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ze(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.K(c)}}
function Be(a,b){var c;c=Ae(a,b,0);if(c==-1){return false}jf(a.a,c);return true}
function Mg(a,b){var c;c=a.d.props;if(!(c['a']===b['a'])){return true}return false}
function Cg(a,b){var c;if((Dh(),Ch).b==a.d.props['a']){c=b.target;Lg(a,c.value)}}
function Gg(a){di((Dh(),Ch),a.d.props['a']);a.b=a.d.props['a'].c;a.d.forceUpdate()}
function X(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=$(b,c)}while(a.b);a.b=c}}
function W(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=$(b,c)}while(a.a);a.a=c}}
function t(){var a;this.a=hb(Zb,oi,27,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function Mb(){Mb=Td;Ib=pb(si,si,524287);Jb=pb(0,0,ui);Kb=nb(1);nb(2);Lb=nb(0)}
function Bd(a){var b;if(Sb(a,5)){return a}b=a&&a[qi];if(!b){b=new G(a);cb(b)}return b}
function ne(a,b){var c;if(!a){return}b.j=a;var d=ke(b);if(!d){Pd[a]=[b];return}d.T=b}
function re(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function Ud(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function hb(a,b,c,d,e,f){var g;g=ib(e,d);e!=10&&lb(fb(a,f),b,c,e,g);return g}
function zf(a,b,c,d){var e;e=Af($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Ke(d);return e}
function yf(a){var b;b=Af($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function ge(a){var b;b=new fe;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Ed(a){var b;b=a.h;if(b==0){return a.l+a.m*wi}if(b==ti){return a.l+a.m*wi-vi}return a}
function Fd(a){if(xi<a&&a<vi){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Ed(Bb(a))}
function Bf(a){var b;return zf($wnd.React.StrictMode,null,null,(b={},b[yi]=Ke(a),b))}
function Nh(a){var b;We(Te(new Xe(null,new Oe(a.a)),new Xh),(b=new De,b)).B(new Yh(a))}
function Hh(){Hh=Td;Eh=new Ih('ACTIVE',0);Gh=new Ih('COMPLETED',1);Fh=new Ih('ALL',2)}
function Gi(){$wnd.ReactDOM.render(Bf([(new Ah).a]),($d(),Zd).getElementById('app'),null)}
function pe(){C.call(this,"Stream already terminated, can't be modified or used")}
function Ld(){Md();var a=Kd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function se(a,b){var c,d;for(d=new Ge(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Qh(b.a,c)}}
function Hd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=vi;d=ti}c=Xb(e/wi);b=Xb(e-c*wi);return pb(b,c,d)}
function Cb(a){var b,c,d;b=~a.l+1&si;c=~a.m+(b==0?1:0)&si;d=~a.h+(b==0&&c==0?1:0)&ti;return pb(b,c,d)}
function vb(a){var b,c,d;b=~a.l+1&si;c=~a.m+(b==0?1:0)&si;d=~a.h+(b==0&&c==0?1:0)&ti;a.l=b;a.m=c;a.h=d}
function zb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return pb(c&si,d&si,e&ti)}
function Fb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return pb(c&si,d&si,e&ti)}
function wb(a){var b,c;c=qe(a.h);if(c==32){b=qe(a.m);return b==32?qe(a.l)+32:b+20-10}else{return c-12}}
function sb(a,b,c,d,e){var f;f=Eb(a,b);c&&vb(f);if(e){a=ub(a,b);d?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h))}return f}
function lb(a,b,c,d,e){e.T=a;e.U=b;e.V=Xd;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Od(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function G(a){F();w(this);this.b=a;a!=null&&lf(a,qi,this);this.c=a==null?'null':Wd(a);this.a=a}
function fe(){this.g=ce++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Oh(a){return Id(Se(new Xe(null,new Oe(a.a))))-Id(Se(Te(new Xe(null,new Oe(a.a)),new $h)))}
function o(a){return Vb(a)?uc:Ub(a)?lc:Tb(a)?jc:Rb(a)?a.T:jb(a)?a.T:a.T||Array.isArray(a)&&fb(cc,1)||cc}
function p(a){return Vb(a)?tf(a):Ub(a)?Xb(a):Tb(a)?a?1231:1237:Rb(a)?a.o():jb(a)?nf(a):!!a&&!!a.hashCode?a.hashCode():nf(a)}
function Dd(a,b){var c;if(Ub(a)&&Ub(b)){c=a+b;if(xi<c&&c<vi){return c}}return Ed(zb(Ub(a)?Hd(a):a,Ub(b)?Hd(b):b))}
function Dg(a,b){27==b.which?(di((Dh(),Ch),null),a.b=a.d.props['a'].c,a.d.forceUpdate()):13==b.which&&Hg(a)}
function pg(){ng();return lb(fb(Pc,1),oi,6,0,[Tf,Uf,Vf,Wf,Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg])}
function Wd(a){var b;if(Array.isArray(a)&&a.V===Xd){return ee(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function rb(a,b){if(a.h==ui&&a.m==0&&a.l==0){b&&(mb=pb(0,0,0));return ob((Mb(),Kb))}b&&(mb=pb(a.l,a.m,a.h));return pb(0,0,0)}
function tf(a){rf();var b,c,d;c=':'+a;d=qf[c];if(d!=null){return Xb(d)}d=of[c];b=d==null?sf(a):Xb(d);uf();qf[c]=b;return b}
function He(a){var b,c,d;d=1;for(c=new Ge(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function Ce(a,b){var c,d;d=a.a.length;b.length<d&&(b=kf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function me(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function xg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=we(a.a);if(c.length>0){Mh((Dh(),Bh),c);a.a='';a.d.forceUpdate()}}}
function N(){var a;if(I!=0){a=H();if(a-J>2000){J=a;K=$wnd.setTimeout(T,10)}}if(I++==0){W((V(),U));return true}return false}
function db(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Hg(a){if(null!=a.b&&a.b.length!=0){Rh((Dh(),Bh),a.d.props['a'],a.b);di(Ch,null);Lg(a,a.b)}else{Qh((Dh(),Bh),a.d.props['a'])}}
function gi(a){this.a=new De;this.c=Ke(a);_d(($d(),$wnd.window.window),'hashchange',new ii(this),false);Sh(a,Ud(ji.prototype.N,ji,[this]))}
function Ff(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Qb(a,b){if(Vb(a)){return !!Pb[b]}else if(a.U){return !!a.U[b]}else if(Ub(a)){return !!Ob[b]}else if(Tb(a)){return !!Nb[b]}return false}
function we(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ub(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return pb(c,d,e)}
function ib(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function yb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&si;a.m=d&si;a.h=e&ti;return true}
function Yd(){Sh((Dh(),Bh),Ud(qg.prototype.N,qg,[]));ei(Ch,Ud(rg.prototype.N,rg,[]));$wnd.ReactDOM.render(Bf([(new Ah).a]),($d(),Zd).getElementById('app'),null)}
function Jg(a){var b;b=(Dh(),Ch).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();a.b=a.d.props['a'].c;a.d.forceUpdate()}else a.c&&!b&&(a.c=false)}
function bi(a,b){var c,d;b.preventDefault();c=(d=($d(),$wnd.window.window).location.hash,null==d?'':d.substr(1));ve(Ci,c)||ve(Bi,c)||ve('',c)?ze(a.a,new ki):ci()}
function yg(a){return Cf(Ai,Jf(Nf(Of(Rf(Pf(Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,['new-todo']))),a.a),Ud(nh.prototype.Q,nh,[a])),Ud(oh.prototype.P,oh,[a]))),null)}
function Ab(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Nd(b,c,d,e){Md();var f=Kd;$moduleName=c;$moduleBase=d;Ad=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{mi(g)()}catch(a){b(c,a)}}else{mi(g)()}}
function Af(a,b){var c;c=new $wnd.Object;c.$$typeof=Ke(a);c.type=Ke(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function $(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].W()&&(c=Z(c,g)):g[0].W()}catch(a){a=Bd(a);if(Sb(a,5)){d=a;L();R(Sb(d,23)?d.r():d)}else throw Cd(a)}}return c}
function Qd(){Pd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Db(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return pb(c&si,d&si,e&ti)}
function Eb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&ui)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?ti:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?ti:0;f=d?si:0;e=c>>b-44}return pb(e&si,f&si,g&ti)}
function sf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ue(a,c++)}b=b|0;return b}
function ci(){var a;if(0==''.length){a=($d(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Zd.title,a)}else{($d(),$wnd.window.window).location.hash=''}}
function qe(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Sd(a,b,c){var d=Pd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Pd[b]),Vd(h));_.U=c;!b&&(_.V=Xd);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.T=f)}
function le(a){if(a.w()){var b=a.c;b.A()?(a.k='['+b.j):!b.w()?(a.k='[L'+b.u()+';'):(a.k='['+b.u());a.b=b.t()+'[]';a.i=b.v()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=me('.',[c,me('$',d)]);a.b=me('.',[c,me('.',d)]);a.i=d[d.length-1]}
function Cf(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;wf(b,Ud(Ef.prototype.M,Ef,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[yi]=c[0],undefined):(d[yi]=c,undefined));return zf(a,e,f,d)}
function ai(a){var b,c,d,e;b=(e=(c=($d(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),ve(Ci,e)||ve(Bi,e)||ve('',e)?ve(Ci,e)?(Hh(),Eh):ve(Bi,e)?(Hh(),Gh):(Hh(),Fh):(Hh(),Fh));return We(Te(new Xe(null,new Oe(a.c.a)),new li(b)),(d=new De,d))}
function xb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return re(c)}if(b==0&&d!=0&&c==0){return re(d)+22}if(b!=0&&d==0&&c==0){return re(b)+44}return -1}
function Bb(a){var b,c,d,e,f;if(isNaN(a)){return Mb(),Lb}if(a<-9223372036854775808){return Mb(),Jb}if(a>=9223372036854775807){return Mb(),Ib}e=false;if(a<0){e=true;a=-a}d=0;if(a>=vi){d=Xb(a/vi);a-=d*vi}c=0;if(a>=wi){c=Xb(a/wi);a-=c*wi}b=Xb(a);f=pb(b,c,d);e&&vb(f);return f}
function Hb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==ui&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Hb(Cb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=nb(1000000000);c=qb(c,e,true);b=''+Gb(mb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function tb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=wb(b)-wb(a);g=Db(b,j);i=pb(0,0,0);while(j>=0){h=yb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&vb(i);if(f){if(d){mb=Cb(a);e&&(mb=Fb(mb,(Mb(),Kb)))}else{mb=pb(a.l,a.m,a.h)}}return i}
function ng(){ng=Td;Tf=new og(zi,0);Uf=new og('checkbox',1);Vf=new og('color',2);Wf=new og('date',3);Xf=new og('datetime',4);Yf=new og('email',5);Zf=new og('file',6);$f=new og('hidden',7);_f=new og('image',8);ag=new og('month',9);bg=new og(ni,10);cg=new og('password',11);dg=new og('radio',12);eg=new og('range',13);fg=new og('reset',14);gg=new og('search',15);hg=new og('submit',16);ig=new og('tel',17);jg=new og('text',18);kg=new og('time',19);lg=new og('url',20);mg=new og('week',21)}
function qb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Cd(new ae)}if(a.l==0&&a.m==0&&a.h==0){c&&(mb=pb(0,0,0));return pb(0,0,0)}if(b.h==ui&&b.m==0&&b.l==0){return rb(a,c)}i=false;if(b.h>>19!=0){b=Cb(b);i=true}g=xb(b);f=false;e=false;d=false;if(a.h==ui&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ob((Mb(),Ib));d=true;i=!i}else{h=Eb(a,g);i&&vb(h);c&&(mb=pb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Cb(a);d=true;i=!i}if(g!=-1){return sb(a,g,i,f,c)}if(Ab(a,b)<0){c&&(f?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h)));return pb(0,0,0)}return tb(d?a:pb(a.l,a.m,a.h),b,i,f,e,c)}
function Kg(a){var b,c;c=a.d.props['a'];b=c.a;return Cf('li',Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,[b?Bi:null,(Dh(),Ch).b==a.d.props['a']?'editing':null])),[Cf('div',Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,['view'])),[Cf(Ai,Nf(Kf(Qf(Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,['toggle'])),(ng(),Uf)),b),Ud(sh.prototype.P,sh,[a])),null),Cf('label',Sf(new $wnd.Object,Ud(th.prototype.R,th,[a])),[c.c]),Cf(zi,If(Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,['destroy'])),Ud(uh.prototype.R,uh,[a])),null)]),Cf(Ai,Of(Nf(Mf(Lf(Ff(Gf(new $wnd.Object,Ud(vh.prototype.K,vh,[a])),lb(fb(uc,1),oi,2,6,['edit'])),a.b),Ud(wh.prototype.O,wh,[a])),Ud(qh.prototype.P,qh,[a])),Ud(rh.prototype.Q,rh,[a])),null)])}
var ni='number',oi={3:1,4:1},pi='__noinit__',qi='__java$exception',ri={3:1,7:1,5:1},si=4194303,ti=1048575,ui=524288,vi=17592186044416,wi=4194304,xi=-17592186044416,yi='children',zi='button',Ai='input',Bi='completed',Ci='active',Di='selected',Ei='header';var _,Pd,Kd,Ad=-1;Qd();Sd(1,null,{},n);_.n=function(){return this.T};_.o=Fi;_.hashCode=function(){return this.o()};var Nb,Ob,Pb;Sd(30,1,{},fe);_.s=function(a){var b;b=new fe;b.e=4;a>1?(b.c=je(this,a-1)):(b.c=this);return b};_.t=function(){de(this);return this.b};_.u=function(){return ee(this)};_.v=function(){de(this);return this.i};_.w=function(){return (this.e&4)!=0};_.A=function(){return (this.e&1)!=0};_.e=0;_.g=0;var ce=1;var sc=he(1);var kc=he(30);Sd(61,1,{},q);var Yb=he(61);Sd(27,1,{27:1},s);var Zb=he(27);Sd(64,1,{141:1},t);var $b=he(64);Sd(66,1,{},u);var _b=he(66);Sd(65,1,{},v);var ac=he(65);Sd(5,1,{3:1,5:1});_.p=function(a){return new Error(a)};_.q=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=ee(this.T),c==null?a:a+': '+c);A(this,B(this.p(b)));cb(this)};_.b=pi;_.d=true;var vc=he(5);Sd(25,5,{3:1,5:1});var nc=he(25);Sd(7,25,ri);var tc=he(7);Sd(31,7,ri);var pc=he(31);Sd(43,31,ri);var ec=he(43);Sd(23,43,{23:1,3:1,7:1,5:1},G);_.r=function(){return Wb(this.a)===Wb(D)?null:this.a};var D;var bc=he(23);var cc=he(0);Sd(95,1,{});var dc=he(95);var I=0,J=0,K=-1;Sd(57,95,{},Y);var U;var fc=he(57);var ab;Sd(108,1,{});var hc=he(108);Sd(44,108,{},eb);var gc=he(44);var mb;var Ib,Jb,Kb,Lb;var Zd;Sd(55,7,ri,ae);var ic=he(55);Nb={3:1,22:1};var jc=he(105);Sd(106,1,{3:1});var rc=he(106);Ob={3:1,22:1};var lc=he(107);Sd(19,1,{3:1,22:1,19:1});_.o=Fi;_.b=0;var mc=he(19);Sd(46,7,ri,pe);var oc=he(46);Sd(170,1,{});Sd(54,31,ri,te);_.p=function(a){return new TypeError(a)};var qc=he(54);Pb={3:1,39:1,22:1,2:1};var uc=he(2);Sd(174,1,{});Sd(33,7,ri,xe);var wc=he(33);Sd(109,1,{92:1});_.B=function(a){se(this,a)};_.C=function(a){throw Cd(new xe('Add not supported on this collection'))};var xc=he(109);Sd(110,109,{92:1,117:1});_.F=function(a,b){throw Cd(new xe('Add not supported on this list'))};_.C=function(a){this.F(this.D(),a);return true};_.o=function(){return He(this)};var yc=he(110);Sd(10,110,{3:1,10:1,92:1,117:1},De);_.F=function(a,b){hf(this.a,a,b)};_.C=function(a){return ye(this,a)};_.B=function(a){ze(this,a)};_.D=function(){return this.a.length};var Ac=he(10);Sd(15,1,{},Ge);_.a=0;_.b=-1;var zc=he(15);Sd(69,1,{});_.I=function(a){Le(this,a)};_.G=function(){return this.d};_.H=function(){return this.e};_.d=0;_.e=0;var Cc=he(69);Sd(35,69,{});var Bc=he(35);Sd(11,1,{},Oe);_.G=function(){return this.a};_.H=function(){Ne(this);return this.c};_.I=function(a){Ne(this);Ie(this.d,a)};_.J=function(a){Ne(this);if(Ee(this.d)){a.K(Fe(this.d));return true}return false};_.a=0;_.c=0;var Dc=he(11);Sd(68,1,{});_.c=false;var Mc=he(68);Sd(9,68,{140:1,9:1},Xe);var Lc=he(9);Sd(71,35,{},_e);_.J=function(a){this.b=false;while(!this.b&&this.c.J(new af(this,a)));return this.b};_.b=false;var Fc=he(71);Sd(74,1,{},af);_.K=function(a){$e(this.a,this.b,a)};var Ec=he(74);Sd(70,35,{},bf);_.J=function(a){return this.a.J(new cf(a))};var Hc=he(70);Sd(73,1,{},cf);_.K=function(a){this.a.K(xh(new yh,a))};var Gc=he(73);Sd(72,1,{},ef);_.K=function(a){df(this,a)};var Ic=he(72);Sd(75,1,{},ff);_.K=function(a){};var Jc=he(75);Sd(76,1,{},gf);_.K=function(a){Ze(this.a,a)};var Kc=he(76);Sd(172,1,{});Sd(114,1,{});var Nc=he(114);Sd(169,1,{});var mf=0;var of,pf=0,qf;Sd(549,1,{});Sd(606,1,{});Sd(111,1,{});var Oc=he(111);Sd(139,$wnd.Function,{},Ef);_.M=function(a){Df(this.a,this.b,a)};Sd(6,19,{3:1,22:1,19:1,6:1},og);var Tf,Uf,Vf,Wf,Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg;var Pc=ie(6,pg);Sd(120,$wnd.Function,{38:1},qg);_.N=Gi;Sd(121,$wnd.Function,{38:1},rg);_.N=Gi;Sd(113,111,{});var Yc=he(113);Sd(84,113,{});var ad=he(84);Sd(85,84,{},tg);_.o=Fi;var sg=0;var Rc=he(85);Sd(116,111,{});var Xc=he(116);Sd(90,116,{});var _c=he(90);Sd(91,90,{},vg);_.o=Fi;var ug=0;var Qc=he(91);Sd(81,111,{});_.a='';var jd=he(81);Sd(82,81,{});var cd=he(82);Sd(83,82,{},Bg);_.o=Fi;var Ag=0;var Sc=he(83);Sd(115,111,{});_.c=false;var ld=he(115);Sd(87,115,{});var ed=he(87);Sd(88,87,{},Og);_.o=Fi;var Ng=0;var Tc=he(88);Sd(112,111,{});var nd=he(112);Sd(59,112,{});var gd=he(59);Sd(60,59,{},Qg);_.o=Fi;var Pg=0;var Uc=he(60);Sd(146,$wnd.Function,{},Rg);_.R=function(a){Nh((Dh(),Bh))};Sd(63,1,{},Sg);var Vc=he(63);Sd(86,1,{},Tg);var Wc=he(86);Sd(145,$wnd.Function,{},Ug);_.S=function(a){return new Xg(a)};var Vg;Sd(78,$wnd.React.Component,{},Xg);Rd(Pd[1],_);_.render=function(){var a,b,c;return a=(Dh(),c=(b=($d(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),ve(Ci,c)||ve(Bi,c)||ve('',c)?ve(Ci,c)?(Hh(),Eh):ve(Bi,c)?(Hh(),Gh):(Hh(),Fh):(Hh(),Fh)),Cf('footer',Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,['footer'])),[(new Tg).a,Cf('ul',Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,['filters'])),[Cf('li',null,[Cf('a',Hf(Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,[(Hh(),Fh)==a?Di:null])),'#'),['All'])]),Cf('li',null,[Cf('a',Hf(Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,[Eh==a?Di:null])),'#active'),['Active'])]),Cf('li',null,[Cf('a',Hf(Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,[Gh==a?Di:null])),'#completed'),['Completed'])])]),Oh(Bh)>0?Cf(zi,If(Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,['clear-completed'])),Ud(Rg.prototype.R,Rg,[])),['Clear Completed']):null])};var Zc=he(78);Sd(156,$wnd.Function,{},Yg);_.S=function(a){return new _g(a)};var Zg;Sd(89,$wnd.React.Component,{},_g);Rd(Pd[1],_);_.render=function(){var a,b;return a=Id(Se(new Xe(null,new Oe((Dh(),Bh).a)))),b='item'+(a==1?'':'s'),Cf('span',Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,['todo-count'])),[Cf('strong',null,[a]),' '+b+' left'])};var $c=he(89);Sd(142,$wnd.Function,{},ah);_.S=function(a){return new eh(a)};var bh;Sd(67,$wnd.React.Component,{},eh);Rd(Pd[1],_);_.render=function(){return yg(this.a)};var bd=he(67);Sd(147,$wnd.Function,{},fh);_.S=function(a){return new ih(a)};var gh;Sd(80,$wnd.React.Component,{},ih);Rd(Pd[1],_);_.componentDidUpdate=function(a){Jg(this.a)};_.render=function(){return Kg(this.a)};_.shouldComponentUpdate=function(a){return Mg(this.a,a)};var dd=he(80);Sd(137,$wnd.Function,{},jh);_.S=function(a){return new mh(a)};var kh;Sd(58,$wnd.React.Component,{},mh);Rd(Pd[1],_);_.render=function(){var a,b;return Cf('div',null,[Cf('div',null,[Cf(Ei,Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,[Ei])),[Cf('h1',null,['todos']),(new ph).a]),0!=Id(Se(new Xe(null,new Oe((Dh(),Bh).a))))?Cf('section',Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,[Ei])),[Cf(Ai,Nf(Qf(Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,['toggle-all'])),(ng(),Uf)),Ud(zh.prototype.P,zh,[])),null),Cf('ul',Ff(new $wnd.Object,lb(fb(uc,1),oi,2,6,['todo-list'])),(a=We(Ke(Ve(new Xe(null,new Oe(ai(Ch))))),(b=new De,b)),Ce(a,kb(a.a.length))))]):null,0!=Id(Se(new Xe(null,new Oe(Bh.a))))?(new Sg).a:null])])};var fd=he(58);Sd(143,$wnd.Function,{},nh);_.Q=function(a){xg(this.a,a)};Sd(144,$wnd.Function,{},oh);_.P=function(a){wg(this.a,a)};Sd(62,1,{},ph);var hd=he(62);Sd(154,$wnd.Function,{},qh);_.P=function(a){Cg(this.a,a)};Sd(155,$wnd.Function,{},rh);_.Q=function(a){Dg(this.a,a)};Sd(148,$wnd.Function,{},sh);_.P=function(a){Ig(this.a)};Sd(150,$wnd.Function,{},th);_.R=function(a){Gg(this.a)};Sd(151,$wnd.Function,{},uh);_.R=function(a){Fg(this.a)};Sd(152,$wnd.Function,{},vh);_.K=function(a){Eg(this.a,a)};Sd(153,$wnd.Function,{},wh);_.O=function(a){Hg(this.a)};Sd(79,1,{},yh);var kd=he(79);Sd(138,$wnd.Function,{},zh);_.P=function(a){var b;b=a.target;Uh((Dh(),Bh),b.checked)};Sd(24,1,{},Ah);var md=he(24);var Bh,Ch;Sd(20,19,{3:1,22:1,19:1,20:1},Ih);var Eh,Fh,Gh;var od=ie(20,Jh);Sd(34,1,{34:1},Lh);_.a=false;var vd=he(34);Sd(32,1,{32:1},Vh);var ud=he(32);Sd(49,1,{},Xh);_.L=function(a){return a.a};var pd=he(49);Sd(50,1,{},Yh);_.K=function(a){Qh(this.a,a)};var qd=he(50);Sd(18,1,{},Zh);_.K=Hi;var rd=he(18);Sd(47,1,{},$h);_.L=function(a){return !a.a};var sd=he(47);Sd(48,1,{},_h);_.K=function(a){Wh(this.a,a)};_.a=false;var td=he(48);Sd(51,1,{},gi);var zd=he(51);Sd(52,1,{},ii);_.handleEvent=function(a){bi(this.a,a)};var wd=he(52);Sd(126,$wnd.Function,{38:1},ji);_.N=function(){fi(this.a)};Sd(26,1,{},ki);_.K=Hi;var xd=he(26);Sd(53,1,{},li);_.L=function(a){return hi(this.a,a)};var yd=he(53);var mi=(L(),O);var gwtOnLoad=gwtOnLoad=Nd;Ld(Yd);Od('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();