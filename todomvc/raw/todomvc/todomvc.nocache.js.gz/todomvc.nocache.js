function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='903AE604194AEB884103575BE1377D3A',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '903AE604194AEB884103575BE1377D3A';function n(){}
function M(){}
function ye(){}
function ue(){}
function _e(){}
function mb(){}
function tb(){}
function Af(){}
function Pf(){}
function Xf(){}
function Yf(){}
function sg(){}
function Gh(){}
function Jh(){}
function Nh(){}
function Rh(){}
function Vh(){}
function Zh(){}
function qi(){}
function ri(){}
function Fi(){}
function Ri(){}
function Ti(){}
function Ui(){}
function dj(){}
function rb(a){qb()}
function Dj(a){a.p()}
function Wf(a,b){a.a=b}
function Bf(a){this.a=a}
function Zf(a){this.a=a}
function lf(a){this.c=a}
function Fh(a){this.a=a}
function bi(a){this.a=a}
function ci(a){this.a=a}
function ei(a){this.a=a}
function fi(a){this.a=a}
function gi(a){this.a=a}
function hi(a){this.a=a}
function ii(a){this.a=a}
function ji(a){this.a=a}
function ki(a){this.a=a}
function li(a){this.a=a}
function oi(a){this.a=a}
function pi(a){this.a=a}
function Si(a){this.a=a}
function Vi(a){this.a=a}
function bj(a){this.a=a}
function cj(a){this.a=a}
function ej(a){this.a=a}
function Aj(){L(this.a.a)}
function yj(a){rf(this,a)}
function de(a){return a.b}
function Bj(a){return false}
function zj(){return this.b}
function Fe(){Fe=ue}
function ng(a,b){a.key=b}
function lg(a,b){kg(a,b)}
function Di(a,b){cf(a.c,b)}
function Mi(a,b){cf(a.b,b)}
function Zi(a,b){cf(a.a,b)}
function bf(a,b,c){$f(a.a,b,c)}
function wf(a,b,c){b.M(a.a[c])}
function P(a,b){a.b=b;O(a,b)}
function _f(a,b){a.splice(b,1)}
function Ee(a){S.call(this,a)}
function xj(){return cg(this)}
function ub(a,b){return Oe(a,b)}
function vh(a,b){return a.c=b}
function Ie(a){He(a);return a.k}
function Nf(a,b){a.H(b);return a}
function If(a,b){Cf(a);a.a.K(b)}
function Of(a,b){Wf(a,Nf(a.a,b))}
function rf(a,b){while(a.L(b));}
function Tf(a,b,c){b.M(a.a.G(c))}
function Te(a,b){this.a=a;this.b=b}
function Sf(a,b){this.a=a;this.b=b}
function Vf(a,b){this.a=a;this.b=b}
function D(a){this.d=a;this.b=100}
function tg(a,b){this.a=a;this.b=b}
function vg(a,b){a.ref=b;return a}
function wg(a,b){a.href=b;return a}
function u(){u=ue;t=new s}
function U(){U=ue;T=new n}
function jb(){jb=ue;ib=new mb}
function $(){$=ue;!!(qb(),pb)}
function hb(){X!=0&&(X=0);Z=-1}
function ne(){le==null&&(le=[])}
function ni(){this.a=pg((Xh(),Wh))}
function di(){this.a=pg((Th(),Sh))}
function si(){this.a=pg((_h(),$h))}
function Hh(){this.a=pg((Lh(),Kh))}
function Ih(){this.a=pg((Ph(),Oh))}
function zf(a){this.b=a;this.a=16464}
function jh(){u();++ih;this.a=new M}
function dh(a,b){Te.call(this,a,b)}
function Ai(a,b){Te.call(this,a,b)}
function $f(a,b,c){a.splice(b,0,c)}
function Fg(a,b){a.value=b;return a}
function Ag(a,b){a.onBlur=b;return a}
function xg(a,b){a.onClick=b;return a}
function zg(a,b){a.checked=b;return a}
function gb(a){$wnd.clearTimeout(a)}
function Ub(a){return a.l|a.m<<22}
function Cb(a){return Db(a.l,a.m,a.h)}
function gc(a){return typeof a===gj}
function ic(a){return a==null?null:a}
function jf(a){return a.a<a.c.a.length}
function Ze(a,b){return ic(a)===ic(b)}
function kg(a,b){for(var c in a){b(c)}}
function Bg(a,b){a.onChange=b;return a}
function Ci(a,b){a.a=b;df(a.c,new Fi)}
function Qi(a,b){b.a=a;df(b.c,new Fi)}
function Yi(a,b){a.b=b;df(a.a,new dj)}
function Ye(a,b){return a.charCodeAt(b)}
function cg(a){return a.$H||(a.$H=++bg)}
function Ji(a,b){return ef(a.a,b,0)!=-1}
function Db(a,b,c){return {l:a,m:b,h:c}}
function ec(a,b){return a!=null&&cc(a,b)}
function Cg(a,b){a.onKeyDown=b;return a}
function mg(a,b){a.props['a']=b;return a}
function yg(a){a.autoFocus=true;return a}
function J(a){++(u(),u(),t).b;this.a=a}
function fh(a){Zi((vi(),ui),new Fh(a))}
function He(a){if(a.k!=null){return}Qe(a)}
function Cj(){this.a.b.forceUpdate()}
function mh(a,b){a.c=b;a.b.forceUpdate()}
function zh(a,b){a.d=b;a.b.forceUpdate()}
function S(a){this.d=a;N(this);this.t()}
function Mf(a,b){Ef.call(this,a);this.a=b}
function Ki(a,b){ff(a.a,b);df(a.b,new Ti)}
function Ni(a,b){Ci(b,!b.a);df(a.b,new Ti)}
function Pi(){this.a=new hf;this.b=new hf}
function gg(){gg=ue;dg=new n;fg=new n}
function hc(a){return typeof a==='string'}
function fc(a){return typeof a==='boolean'}
function C(a){while(true){if(!B(a)){break}}}
function N(a){a.f&&a.b!==ij&&a.t();return a}
function Gg(a,b){a.onDoubleClick=b;return a}
function Le(a){var b;b=Ke(a);Se(a,b);return b}
function kf(a){a.b=a.a++;return a.c.a[a.b]}
function hh(a){this.b=a;u();++gh;this.a=new M}
function ph(a){this.b=a;u();++oh;this.a=new M}
function Eh(a){this.b=a;u();++Dh;this.a=new M}
function s(){this.f=new H;this.a=new D(this.f)}
function vi(){vi=ue;ti=new Pi;ui=new _i(ti)}
function qb(){qb=ue;var a;!sb();a=new tb;pb=a}
function hf(){this.a=wb(Jc,hj,1,0,5,1)}
function A(){this.a=wb(Jc,hj,1,100,5,1)}
function sh(a){Ni((vi(),ti),a.b.props['a'])}
function uh(a){Ki((vi(),ti),a.b.props['a'])}
function De(){S.call(this,'divide by zero')}
function ab(a,b,c){return a.apply(b,c);var d}
function yb(a){return Array.isArray(a)&&a.X===ye}
function dc(a){return !Array.isArray(a)&&a.X===ye}
function uf(a,b){while(a.c<a.d){wf(a,b,a.c++)}}
function Qf(a,b,c){if(a.a.O(c)){a.b=true;b.M(c)}}
function Ce(a,b,c,d){a.addEventListener(b,c,d)}
function cf(a,b){a.a[a.a.length]=b;return true}
function nb(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ne(a){var b;b=Ke(a);b.j=a;b.e=1;return b}
function je(a){if(gc(a)){return a|0}return Ub(a)}
function ke(a){if(gc(a)){return ''+a}return Vb(a)}
function Ff(a,b){var c;return Kf(a,(c=new hf,c))}
function Hf(a,b){Df(a);return new Mf(a,new Rf(b,a.a))}
function Jf(a,b){Df(a);return new Mf(a,new Uf(b,a.a))}
function nf(a){return new Mf(null,mf(a,a.length))}
function mf(a,b){return sf(b,a.length),new xf(a,b)}
function w(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function kh(a,b){var c;c=b.target;mh(a,c.value)}
function Li(a,b,c){b.d=c;df(b.c,new Fi);df(a.b,new Ti)}
function Ch(a){Mi((vi(),ti),new oi(a));Zi(ui,new pi(a))}
function Cf(a){if(!a.b){Df(a);a.c=true}else{Cf(a.b)}}
function Ef(a){if(!a){this.b=null;new hf}else{this.b=a}}
function xf(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function tf(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Eg(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Me(a,b){var c;c=Ke(a);Se(a,c);c.e=b?8:0;return c}
function Q(a,b){var c;c=Ie(a.V);return b==null?c:c+': '+b}
function aj(a,b){return (zi(),xi)==a||(wi==a?!b.a:b.a)}
function qf(a,b){return ic(a)===ic(b)||!!a&&ic(a)===ic(b)}
function Bi(){zi();return zb(ub(Pd,1),hj,21,0,[wi,yi,xi])}
function Pe(a){if(a.D()){return null}var b=a.j;return qe[b]}
function yf(a){if(!a.d){a.d=new lf(a.b);a.c=a.b.a.length}}
function jg(){if(eg==256){dg=fg;fg=new n;eg=0}++eg}
function Be(){Be=ue;Ae=$wnd.goog.global.document}
function _h(){_h=ue;var a;$h=(a=ve(Zh.prototype.U,Zh,[]),a)}
function Lh(){Lh=ue;var a;Kh=(a=ve(Jh.prototype.U,Jh,[]),a)}
function Ph(){Ph=ue;var a;Oh=(a=ve(Nh.prototype.U,Nh,[]),a)}
function Th(){Th=ue;var a;Sh=(a=ve(Rh.prototype.U,Rh,[]),a)}
function Xh(){Xh=ue;var a;Wh=(a=ve(Vh.prototype.U,Vh,[]),a)}
function L(a){var b;if(a.a>=0){a.a=-2;q((b=(u(),u(),t),b))}}
function Oe(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.v(b))}
function se(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function fb(a){$();$wnd.setTimeout(function(){throw a},0)}
function Qh(a){$wnd.React.Component.call(this,a);this.a=new jh}
function Ei(a,b){this.c=new hf;this.b=a;this.d=b;this.a=false}
function Uf(a,b){tf.call(this,b.J(),b.I()&-6);this.a=a;this.b=b}
function Rf(a,b){tf.call(this,b.J(),b.I()&-16449);this.a=a;this.c=b}
function af(){S.call(this,'Add not supported on this collection')}
function Dg(a){a.placeholder='What needs to be done?';return a}
function we(a){function b(){}
;b.prototype=a||{};return new b}
function R(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Df(a){if(a.b){Df(a.b)}else if(a.c){throw de(new Ue)}}
function vf(a,b){if(a.c<a.d){wf(a,b,a.c++);return true}return false}
function pf(a,b){while(a.a<a.c.a.length){b.M((a.b=a.a++,a.c.a[a.b]))}}
function db(a,b,c){var d;d=bb();try{return ab(a,b,c)}finally{eb(d)}}
function rg(a,b,c){!Ze(c,'key')&&!Ze(c,'ref')&&(a[c]=b[c],undefined)}
function $i(a){var b;b=a.b;!!b&&!Ji(a.c,b)&&(a.b=null,df(a.a,new dj))}
function Oi(a,b){If(new Mf(null,new zf(a.a)),new Vi(b));df(a.b,new Ti)}
function Gf(a){var b;Cf(a);b=0;while(a.a.L(new Yf)){b=ee(b,1)}return b}
function eb(a){a&&lb((jb(),ib));--X;if(a){if(Z!=-1){gb(Z);Z=-1}}}
function th(a){Yi((vi(),ui),a.b.props['a']);zh(a,a.b.props['a'].d)}
function Uh(a){$wnd.React.Component.call(this,a);this.a=new ph(this)}
function Mh(a){$wnd.React.Component.call(this,a);this.a=new hh(this)}
function Yh(a){$wnd.React.Component.call(this,a);this.a=new Bh(this)}
function ai(a){$wnd.React.Component.call(this,a);this.a=new Eh(this)}
function Gi(a,b){cf(a.a,new Ei(''+ke(ge(Date.now())),b));df(a.b,new Ti)}
function Lf(a,b){var c;c=Ff(a,new Bf(new Af));return gf(c,b.N(c.a.length))}
function Kf(a,b){var c;Cf(a);c=new Xf;c.a=b;a.a.K(new Zf(c));return c.a}
function Bb(a){var b,c,d;b=a&kj;c=a>>22&kj;d=a<0?lj:0;return Db(b,c,d)}
function G(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=w(a.a[c])}return b}
function df(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.M(c)}}
function H(){var a;this.a=wb(mc,hj,27,5,0,1);for(a=0;a<5;a++){this.a[a]=new A}}
function K(){var a;try{u()}finally{a=I.a;!a&&((u(),u(),t).d=true);I=I.a}}
function cb(b){$();return function(){return db(b,this,arguments);var a}}
function W(){if(Date.now){return Date.now()}return (new Date).getTime()}
function jc(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function ag(a,b){return vb(b)!=10&&zb(o(b),b.W,b.__elementTypeId$,vb(b),a),a}
function vb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ff(a,b){var c;c=ef(a,b,0);if(c==-1){return false}_f(a.a,c);return true}
function wb(a,b,c,d,e,f){var g;g=xb(e,d);e!=10&&zb(ub(a,f),b,c,e,g);return g}
function mi(a,b){ng(a.a,(b?b.b:null)+(''+(He(Jd),Jd.k)));mg(a.a,b);return a.a}
function ef(a,b,c){for(;c<a.a.length;++c){if(qf(b,a.a[c])){return c}}return -1}
function qh(a,b){var c;if((vi(),ui).b==a.b.props['a']){c=b.target;zh(a,c.value)}}
function lb(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=ob(b,c)}while(a.b);a.b=c}}
function kb(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=ob(b,c)}while(a.a);a.a=c}}
function r(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{C(a.a)}finally{a.c=false}}}}
function V(a){U();N(this);this.b=a;O(this,a);this.d=a==null?'null':xe(a);this.a=a}
function Ue(){S.call(this,"Stream already terminated, can't be modified or used")}
function ze(){$wnd.ReactDOM.render((new si).a,(Be(),Ae).getElementById('app'),null)}
function Hi(a){Ff(Hf(new Mf(null,new zf(a.a)),new Ri),new Bf(new Af)).F(new Si(a))}
function zi(){zi=ue;wi=new Ai('ACTIVE',0);yi=new Ai('COMPLETED',1);xi=new Ai('ALL',2)}
function $b(){$b=ue;Wb=Db(kj,kj,524287);Xb=Db(0,0,mj);Yb=Bb(1);Bb(2);Zb=Bb(0)}
function Ke(a){var b;b=new Je;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function pg(a){var b;b=og($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function We(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function fe(a){var b;b=a.h;if(b==0){return a.l+a.m*oj}if(b==lj){return a.l+a.m*oj-nj}return a}
function ve(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Se(a,b){var c;if(!a){return}b.j=a;var d=Pe(b);if(!d){qe[a]=[b];return}d.V=b}
function me(){ne();var a=le;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Xe(a,b){var c,d;for(d=new lf(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Ki(b.a,c)}}
function ie(a){var b,c,d,e;e=a;d=0;if(e<0){e+=nj;d=lj}c=jc(e/oj);b=jc(e-c*oj);return Db(b,c,d)}
function Qb(a){var b,c,d;b=~a.l+1&kj;c=~a.m+(b==0?1:0)&kj;d=~a.h+(b==0&&c==0?1:0)&lj;return Db(b,c,d)}
function Jb(a){var b,c,d;b=~a.l+1&kj;c=~a.m+(b==0?1:0)&kj;d=~a.h+(b==0&&c==0?1:0)&lj;a.l=b;a.m=c;a.h=d}
function Nb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return Db(c&kj,d&kj,e&lj)}
function Tb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return Db(c&kj,d&kj,e&lj)}
function rh(a,b){27==b.which?(Yi((vi(),ui),null),zh(a,a.b.props['a'].d)):13==b.which&&wh(a)}
function Bh(a){this.b=a;u();++Ah;this.a=new M;this.d=this.b.props['a'].d;Di(this.b.props['a'],new ei(this))}
function Je(){this.g=Ge++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function ge(a){if(pj<a&&a<nj){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return fe(Pb(a))}
function ce(a){var b;if(ec(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new V(a);rb(b)}return b}
function Kb(a){var b,c;c=Ve(a.h);if(c==32){b=Ve(a.m);return b==32?Ve(a.l)+32:b+20-10}else{return c-12}}
function Gb(a,b,c,d,e){var f;f=Sb(a,b);c&&Jb(f);if(e){a=Ib(a,b);d?(Ab=Qb(a)):(Ab=Db(a.l,a.m,a.h))}return f}
function zb(a,b,c,d,e){e.V=a;e.W=b;e.X=ye;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function sf(a,b){if(0>a||a>b){throw de(new Ee('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function pe(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Ii(a){return je(Gf(new Mf(null,new zf(a.a))))-je(Gf(Hf(new Mf(null,new zf(a.a)),new Ui)))}
function o(a){return hc(a)?Lc:gc(a)?Cc:fc(a)?Ac:dc(a)?a.V:yb(a)?a.V:a.V||Array.isArray(a)&&ub(sc,1)||sc}
function p(a){return hc(a)?ig(a):gc(a)?jc(a):fc(a)?a?1231:1237:dc(a)?a.o():yb(a)?cg(a):!!a&&!!a.hashCode?a.hashCode():cg(a)}
function ee(a,b){var c;if(gc(a)&&gc(b)){c=a+b;if(pj<c&&c<nj){return c}}return fe(Nb(gc(a)?ie(a):a,gc(b)?ie(b):b))}
function xe(a){var b;if(Array.isArray(a)&&a.X===ye){return Ie(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function Fb(a,b){if(a.h==mj&&a.m==0&&a.l==0){b&&(Ab=Db(0,0,0));return Cb(($b(),Yb))}b&&(Ab=Db(a.l,a.m,a.h));return Db(0,0,0)}
function ig(a){gg();var b,c,d;c=':'+a;d=fg[c];if(d!=null){return jc(d)}d=dg[c];b=d==null?hg(a):jc(d);jg();fg[c]=b;return b}
function of(a){var b,c,d;d=1;for(c=new lf(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function F(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=v(d);return c}}return null}
function bb(){var a;if(X!=0){a=W();if(a-Y>2000){Y=a;Z=$wnd.setTimeout(hb,10)}}if(X++==0){kb((jb(),ib));return true}return false}
function sb(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function eh(){bh();return zb(ub(kd,1),hj,5,0,[Hg,Ig,Jg,Kg,Lg,Mg,Ng,Og,Pg,Qg,Rg,Sg,Tg,Ug,Vg,Wg,Xg,Yg,Zg,$g,_g,ah])}
function _i(a){this.a=new hf;this.c=a;Ce((Be(),$wnd.goog.global.window),'hashchange',new bj(this),false);Mi(a,new cj(this))}
function lh(a,b){var c;if(13==b.keyCode){b.preventDefault();c=$e(a.c);if(c.length>0){Gi((vi(),ti),c);a.c='';a.b.forceUpdate()}}}
function Re(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function gf(a,b){var c,d;d=a.a.length;b.length<d&&(b=ag(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function v(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function wh(a){if(null!=a.d&&a.d.length!=0){Li((vi(),ti),a.b.props['a'],a.d);Yi(ui,null);zh(a,a.d)}else{Ki((vi(),ti),a.b.props['a'])}}
function cc(a,b){if(hc(a)){return !!bc[b]}else if(a.W){return !!a.W[b]}else if(gc(a)){return !!ac[b]}else if(fc(a)){return !!_b[b]}return false}
function xh(a){var b;b=(vi(),ui).b==a.b.props['a'];if(!a.e&&b){a.e=true;a.c.focus();a.c.select();zh(a,a.b.props['a'].d)}else a.e&&!b&&(a.e=false)}
function ug(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function $e(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Ib(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return Db(c,d,e)}
function xb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Mb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&kj;a.m=d&kj;a.h=e&lj;return true}
function B(a){var b;if(0==a.c){b=G(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;F(a.d);null.Y();return true}
function nh(a){return qg(rj,yg(Bg(Cg(Fg(Dg(ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,['new-todo']))),a.c),ve(bi.prototype.S,bi,[a])),ve(ci.prototype.R,ci,[a]))),null)}
function Ob(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function oe(b,c,d,e){ne();var f=le;$moduleName=c;$moduleBase=d;be=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{fj(g)()}catch(a){b(c,a)}}else{fj(g)()}}
function og(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function q(b){var c,d;try{if(I){d=null}else{I=new J(I);b.d=false;try{d=null}finally{K()}}return d}catch(a){a=ce(a);if(ec(a,4)){c=a;throw de(c)}else throw de(a)}finally{r(b)}}
function ob(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Y()&&(c=nb(c,g)):g[0].Y()}catch(a){a=ce(a);if(ec(a,4)){d=a;$();fb(ec(d,25)?d.u():d)}else throw de(a)}}return c}
function re(){qe={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Rb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return Db(c&kj,d&kj,e&lj)}
function Sb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&mj)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?lj:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?lj:0;f=d?kj:0;e=c>>b-44}return Db(e&kj,f&kj,g&lj)}
function hg(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ye(a,c++)}b=b|0;return b}
function Wi(a){var b,c,d;b=(d=(c=(Be(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1)),Ze(tj,d)?(zi(),wi):Ze(uj,d)?(zi(),yi):(zi(),xi));return Ff(Hf(new Mf(null,new zf(a.c.a)),new ej(b)),new Bf(new Af))}
function Ve(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function te(a,b,c){var d=qe,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=qe[b]),we(h));_.W=c;!b&&(_.X=ye);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.V=f)}
function Qe(a){if(a.C()){var b=a.c;b.D()?(a.k='['+b.j):!b.C()?(a.k='[L'+b.A()+';'):(a.k='['+b.A());a.b=b.w()+'[]';a.i=b.B()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Re('.',[c,Re('$',d)]);a.b=Re('.',[c,Re('.',d)]);a.i=d[d.length-1]}
function Lb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return We(c)}if(b==0&&d!=0&&c==0){return We(d)+22}if(b!=0&&d==0&&c==0){return We(b)+44}return -1}
function Pb(a){var b,c,d,e,f;if(isNaN(a)){return $b(),Zb}if(a<-9223372036854775808){return $b(),Xb}if(a>=9223372036854775807){return $b(),Wb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=nj){d=jc(a/nj);a-=d*nj}c=0;if(a>=oj){c=jc(a/oj);a-=c*oj}b=jc(a);f=Db(b,c,d);e&&Jb(f);return f}
function O(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.s();return a&&a.q()}},suppressed:{get:function(){return c.r()}}})}catch(a){}}}
function qg(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;lg(b,ve(tg.prototype.P,tg,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=og($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function Xi(a,b){var c,d,e;b.preventDefault();c=(d=(Be(),$wnd.goog.global.window).location.hash,null==d?'':d.substr(1));if(Ze(tj,c)||Ze(uj,c)||Ze('',c)){df(a.a,new dj)}else{e=$wnd.goog.global.window.location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Ae.title,e)}}
function Vb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==mj&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Vb(Qb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=Bb(1000000000);c=Eb(c,e,true);b=''+Ub(Ab);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function Hb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=Kb(b)-Kb(a);g=Rb(b,j);i=Db(0,0,0);while(j>=0){h=Mb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&Jb(i);if(f){if(d){Ab=Qb(a);e&&(Ab=Tb(Ab,($b(),Yb)))}else{Ab=Db(a.l,a.m,a.h)}}return i}
function bh(){bh=ue;Hg=new dh(qj,0);Ig=new dh('checkbox',1);Jg=new dh('color',2);Kg=new dh('date',3);Lg=new dh('datetime',4);Mg=new dh('email',5);Ng=new dh('file',6);Og=new dh('hidden',7);Pg=new dh('image',8);Qg=new dh('month',9);Rg=new dh(gj,10);Sg=new dh('password',11);Tg=new dh('radio',12);Ug=new dh('range',13);Vg=new dh('reset',14);Wg=new dh('search',15);Xg=new dh('submit',16);Yg=new dh('tel',17);Zg=new dh('text',18);$g=new dh('time',19);_g=new dh('url',20);ah=new dh('week',21)}
function Eb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw de(new De)}if(a.l==0&&a.m==0&&a.h==0){c&&(Ab=Db(0,0,0));return Db(0,0,0)}if(b.h==mj&&b.m==0&&b.l==0){return Fb(a,c)}i=false;if(b.h>>19!=0){b=Qb(b);i=!i}g=Lb(b);f=false;e=false;d=false;if(a.h==mj&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=Cb(($b(),Wb));d=true;i=!i}else{h=Sb(a,g);i&&Jb(h);c&&(Ab=Db(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Qb(a);d=true;i=!i}if(g!=-1){return Gb(a,g,i,f,c)}if(Ob(a,b)<0){c&&(f?(Ab=Qb(a)):(Ab=Db(a.l,a.m,a.h)));return Db(0,0,0)}return Hb(d?a:Db(a.l,a.m,a.h),b,i,f,e,c)}
function yh(a){var b,c;c=a.b.props['a'];b=c.a;return qg('li',ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,[b?'checked':null,(vi(),ui).b==a.b.props['a']?'editing':null])),[qg('div',ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,['view'])),[qg(rj,Bg(zg(Eg(ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,['toggle'])),(bh(),Ig)),b),ve(hi.prototype.R,hi,[a])),null),qg('label',Gg(new $wnd.Object,ve(ii.prototype.T,ii,[a])),[c.d]),qg(qj,xg(ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,['destroy'])),ve(ji.prototype.T,ji,[a])),null)]),qg(rj,Cg(Bg(Ag(Fg(ug(vg(new $wnd.Object,ve(ki.prototype.M,ki,[a])),zb(ub(Lc,1),hj,2,6,['edit'])),a.d),ve(li.prototype.Q,li,[a])),ve(fi.prototype.R,fi,[a])),ve(gi.prototype.S,gi,[a])),null)])}
var gj='number',hj={3:1},ij='__noinit__',jj={3:1,7:1,4:1},kj=4194303,lj=1048575,mj=524288,nj=17592186044416,oj=4194304,pj=-17592186044416,qj='button',rj='input',sj={34:1},tj='active',uj='completed',vj='selected',wj='header';var _,qe,le,be=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;re();te(1,null,{},n);_.n=function(){return this.V};_.o=xj;_.hashCode=function(){return this.o()};var _b,ac,bc;te(37,1,{},Je);_.v=function(a){var b;b=new Je;b.e=4;a>1?(b.c=Oe(this,a-1)):(b.c=this);return b};_.w=function(){He(this);return this.b};_.A=function(){return Ie(this)};_.B=function(){He(this);return this.i};_.C=function(){return (this.e&4)!=0};_.D=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Ge=1;var Jc=Le(1);var Bc=Le(37);te(56,1,{},s);_.b=1;_.c=false;_.d=true;_.e=0;var lc=Le(56);var t;te(27,1,{27:1},A);_.b=0;_.c=false;_.d=0;var mc=Le(27);te(66,1,{},D);_.a=0;_.b=0;_.c=0;var nc=Le(66);te(65,1,{},H);var oc=Le(65);te(96,1,{},J);var I;var pc=Le(96);te(19,1,{},M);_.a=0;var qc=Le(19);te(4,1,{3:1,4:1});_.q=zj;_.r=function(){return Lf(Jf(nf((this.e==null&&(this.e=wb(Nc,hj,4,0,0,1)),this.e)),new _e),new Pf)};_.s=function(){return this.c};_.t=function(){P(this,R(new Error(Q(this,this.d))));rb(this)};_.b=ij;_.f=true;var Nc=Le(4);te(36,4,{3:1,4:1});var Ec=Le(36);te(7,36,jj);var Kc=Le(7);te(48,7,jj);var Hc=Le(48);te(49,48,jj);var uc=Le(49);te(25,49,{25:1,3:1,7:1,4:1},V);_.u=function(){return ic(this.a)===ic(T)?null:this.a};var T;var rc=Le(25);var sc=Le(0);te(112,1,{});var tc=Le(112);var X=0,Y=0,Z=-1;te(58,112,{},mb);var ib;var vc=Le(58);var pb;te(125,1,{});var xc=Le(125);te(50,125,{},tb);var wc=Le(50);var Ab;var Wb,Xb,Yb,Zb;var Ae;te(55,7,jj,De);var yc=Le(55);te(53,7,jj);var Gc=Le(53);te(79,53,jj,Ee);var zc=Le(79);_b={3:1,24:1};var Ac=Le(122);te(123,1,hj);var Ic=Le(123);ac={3:1,24:1};var Cc=Le(124);te(18,1,{3:1,24:1,18:1});_.o=xj;_.b=0;var Dc=Le(18);te(52,7,jj,Ue);var Fc=Le(52);te(186,1,{});bc={3:1,44:1,24:1,2:1};var Lc=Le(2);te(190,1,{});te(42,1,{},_e);_.G=function(a){return a.b};var Mc=Le(42);te(54,7,jj,af);var Oc=Le(54);te(126,1,{109:1});_.F=function(a){Xe(this,a)};_.H=function(a){throw de(new af)};var Pc=Le(126);te(127,126,{109:1,133:1});_.H=function(a){bf(this,this.a.length,a);return true};_.o=function(){return of(this)};var Qc=Le(127);te(11,127,{3:1,11:1,109:1,133:1},hf);_.H=function(a){return cf(this,a)};_.F=function(a){df(this,a)};var Sc=Le(11);te(16,1,{},lf);_.a=0;_.b=-1;var Rc=Le(16);te(68,1,{});_.K=yj;_.I=function(){return this.d};_.J=function(){return this.e};_.d=0;_.e=0;var Wc=Le(68);te(38,68,{});var Tc=Le(38);te(59,1,{});_.K=yj;_.I=zj;_.J=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Vc=Le(59);te(60,59,{},xf);_.K=function(a){uf(this,a)};_.L=function(a){return vf(this,a)};var Uc=Le(60);te(12,1,{},zf);_.I=function(){return this.a};_.J=function(){yf(this);return this.c};_.K=function(a){yf(this);pf(this.d,a)};_.L=function(a){yf(this);if(jf(this.d)){a.M(kf(this.d));return true}return false};_.a=0;_.c=0;var Xc=Le(12);te(26,1,{},Af);_.G=function(a){return a};var Yc=Le(26);te(30,1,{},Bf);var Zc=Le(30);te(67,1,{});_.c=false;var hd=Le(67);te(9,67,{},Mf);var gd=Le(9);te(43,1,{},Pf);_.N=function(a){return wb(Jc,hj,1,a,5,1)};var $c=Le(43);te(70,38,{},Rf);_.L=function(a){this.b=false;while(!this.b&&this.c.L(new Sf(this,a)));return this.b};_.b=false;var ad=Le(70);te(73,1,{},Sf);_.M=function(a){Qf(this.a,this.b,a)};var _c=Le(73);te(69,38,{},Uf);_.L=function(a){return this.b.L(new Vf(this,a))};var cd=Le(69);te(72,1,{},Vf);_.M=function(a){Tf(this.a,this.b,a)};var bd=Le(72);te(71,1,{},Xf);_.M=function(a){Wf(this,a)};var dd=Le(71);te(74,1,{},Yf);_.M=function(a){};var ed=Le(74);te(75,1,{},Zf);_.M=function(a){Of(this.a,a)};var fd=Le(75);te(188,1,{});te(185,1,{});var bg=0;var dg,eg=0,fg;te(799,1,{});te(822,1,{});te(80,1,{},sg);_.N=function(a){return new Array(a)};var jd=Le(80);te(154,$wnd.Function,{},tg);_.P=function(a){rg(this.a,this.b,a)};te(5,18,{3:1,24:1,18:1,5:1},dh);var Hg,Ig,Jg,Kg,Lg,Mg,Ng,Og,Pg,Qg,Rg,Sg,Tg,Ug,Vg,Wg,Xg,Yg,Zg,$g,_g,ah;var kd=Me(5,eh);te(130,1,{});var ud=Le(130);te(102,130,{});var yd=Le(102);te(103,102,{},hh);var gh=0;var md=Le(103);te(131,1,{});var td=Le(131);te(132,131,{});var xd=Le(132);te(108,132,{},jh);var ih=0;var ld=Le(108);te(99,1,{});_.c='';var Gd=Le(99);te(100,99,{});var Ad=Le(100);te(101,100,{},ph);var oh=0;var nd=Le(101);te(129,1,{});_.e=false;var Jd=Le(129);te(105,129,{});var Cd=Le(105);te(106,105,{},Bh);var Ah=0;var od=Le(106);te(128,1,{});var Od=Le(128);te(77,128,{});var Ed=Le(77);te(78,77,{},Eh);var Dh=0;var pd=Le(78);te(95,1,sj,Fh);_.p=Cj;var qd=Le(95);te(159,$wnd.Function,{},Gh);_.T=function(a){Hi((vi(),ti))};te(87,1,{},Hh);var rd=Le(87);te(104,1,{},Ih);var sd=Le(104);te(158,$wnd.Function,{},Jh);_.U=function(a){return new Mh(a)};var Kh;te(94,$wnd.React.Component,{},Mh);se(qe[1],_);_.componentDidMount=function(){fh(this.a)};_.componentWillUnmount=Aj;_.render=function(){var a,b,c;return a=(c=(vi(),b=(Be(),$wnd.goog.global.window).location.hash,null==b?'':b.substr(1)),Ze(tj,c)?(zi(),wi):Ze(uj,c)?(zi(),yi):(zi(),xi)),qg('footer',ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,['footer'])),[(new Ih).a,qg('ul',ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,['filters'])),[qg('li',null,[qg('a',wg(ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,[(zi(),xi)==a?vj:null])),'#'),['All'])]),qg('li',null,[qg('a',wg(ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,[wi==a?vj:null])),'#active'),['Active'])]),qg('li',null,[qg('a',wg(ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,[yi==a?vj:null])),'#completed'),['Completed'])])]),Ii(ti)>0?qg(qj,xg(ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,['clear-completed'])),ve(Gh.prototype.T,Gh,[])),['Clear Completed']):null])};_.shouldComponentUpdate=Bj;var vd=Le(94);te(169,$wnd.Function,{},Nh);_.U=function(a){return new Qh(a)};var Oh;te(107,$wnd.React.Component,{},Qh);se(qe[1],_);_.componentWillUnmount=Aj;_.render=function(){var a;return a=je(Gf(new Mf(null,new zf((vi(),ti).a)))),qg('span',ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,['todo-count'])),[qg('strong',null,[a]),' item'+(a==1?'':'s')+' left'])};_.shouldComponentUpdate=Bj;var wd=Le(107);te(157,$wnd.Function,{},Rh);_.U=function(a){return new Uh(a)};var Sh;te(93,$wnd.React.Component,{},Uh);se(qe[1],_);_.componentWillUnmount=Aj;_.render=function(){return nh(this.a)};_.shouldComponentUpdate=Bj;var zd=Le(93);te(160,$wnd.Function,{},Vh);_.U=function(a){return new Yh(a)};var Wh;te(97,$wnd.React.Component,{},Yh);se(qe[1],_);_.componentDidUpdate=function(a){xh(this.a)};_.componentWillUnmount=Aj;_.render=function(){return yh(this.a)};_.shouldComponentUpdate=Bj;var Bd=Le(97);te(152,$wnd.Function,{},Zh);_.U=function(a){return new ai(a)};var $h;te(61,$wnd.React.Component,{},ai);se(qe[1],_);_.componentDidMount=function(){Ch(this.a)};_.componentWillUnmount=Aj;_.render=function(){return qg('div',null,[qg('div',null,[qg(wj,ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,[wj])),[qg('h1',null,['todos']),(new di).a]),0!=je(Gf(new Mf(null,new zf((vi(),ti).a))))?qg('section',ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,[wj])),[qg(rj,Bg(Eg(ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,['toggle-all'])),(bh(),Ig)),ve(qi.prototype.R,qi,[])),null),qg('ul',ug(new $wnd.Object,zb(ub(Lc,1),hj,2,6,['todo-list'])),Lf(Jf(new Mf(null,new zf(Wi(ui))),new ri),new sg))]):null,0!=je(Gf(new Mf(null,new zf(ti.a))))?(new Hh).a:null])])};_.shouldComponentUpdate=Bj;var Dd=Le(61);te(155,$wnd.Function,{},bi);_.S=function(a){lh(this.a,a)};te(156,$wnd.Function,{},ci);_.R=function(a){kh(this.a,a)};te(81,1,{},di);var Fd=Le(81);te(98,1,sj,ei);_.p=Cj;var Hd=Le(98);te(167,$wnd.Function,{},fi);_.R=function(a){qh(this.a,a)};te(168,$wnd.Function,{},gi);_.S=function(a){rh(this.a,a)};te(161,$wnd.Function,{},hi);_.R=function(a){sh(this.a)};te(163,$wnd.Function,{},ii);_.T=function(a){th(this.a)};te(164,$wnd.Function,{},ji);_.T=function(a){uh(this.a)};te(165,$wnd.Function,{},ki);_.M=function(a){vh(this.a,a)};te(166,$wnd.Function,{},li);_.Q=function(a){wh(this.a)};te(92,1,{},ni);var Id=Le(92);te(62,1,sj,oi);_.p=Cj;var Kd=Le(62);te(63,1,sj,pi);_.p=Cj;var Ld=Le(63);te(153,$wnd.Function,{},qi);_.R=function(a){var b;b=a.target;Oi((vi(),ti),b.checked)};te(64,1,{},ri);_.G=function(a){return mi(new ni,a)};var Md=Le(64);te(41,1,{},si);var Nd=Le(41);var ti,ui;te(21,18,{3:1,24:1,18:1,21:1},Ai);var wi,xi,yi;var Pd=Me(21,Bi);te(39,1,{39:1},Ei);_.a=false;var Xd=Le(39);te(29,1,{},Fi);_.M=Dj;var Qd=Le(29);te(82,1,{},Pi);var Wd=Le(82);te(85,1,{},Ri);_.O=function(a){return a.a};var Rd=Le(85);te(86,1,{},Si);_.M=function(a){Ki(this.a,a)};var Sd=Le(86);te(20,1,{},Ti);_.M=Dj;var Td=Le(20);te(83,1,{},Ui);_.O=function(a){return !a.a};var Ud=Le(83);te(84,1,{},Vi);_.M=function(a){Qi(this.a,a)};_.a=false;var Vd=Le(84);te(88,1,{},_i);var ae=Le(88);te(89,1,{},bj);_.handleEvent=function(a){Xi(this.a,a)};var Yd=Le(89);te(90,1,sj,cj);_.p=function(){$i(this.a)};var Zd=Le(90);te(28,1,{},dj);_.M=Dj;var $d=Le(28);te(91,1,{},ej);_.O=function(a){return aj(this.a,a)};var _d=Le(91);var kc=Ne('D');var fj=($(),cb);var gwtOnLoad=gwtOnLoad=oe;me(ze);pe('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();