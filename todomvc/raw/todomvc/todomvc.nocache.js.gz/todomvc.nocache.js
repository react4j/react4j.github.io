function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='0A1B0005F480A99C441B19F169F5920D',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '0A1B0005F480A99C441B19F169F5920D';function n(){}
function S(){}
function Z(){}
function Ld(){}
function Hd(){}
function Xe(){}
function Ye(){}
function eg(){}
function fg(){}
function ng(){}
function pg(){}
function tg(){}
function Ag(){}
function Qg(){}
function ah(){}
function dh(){}
function Jh(){}
function Lh(){}
function Mh(){}
function Yh(){}
function X(a){W()}
function wi(a){a()}
function sg(){rg()}
function Rd(){Rd=Hd}
function We(a,b){a.a=b}
function Ih(a,b){b.a=a}
function Ve(a){this.a=a}
function Ze(a){this.a=a}
function ve(a){this.c=a}
function Cg(a){this.a=a}
function Dg(a){this.a=a}
function Eg(a){this.a=a}
function Sg(a){this.a=a}
function Tg(a){this.a=a}
function Ug(a){this.a=a}
function Vg(a){this.a=a}
function Wg(a){this.a=a}
function Xg(a){this.a=a}
function Yg(a){this.a=a}
function gh(a){this.a=a}
function Kh(a){this.a=a}
function Nh(a){this.a=a}
function Wh(a){this.a=a}
function Xh(a){this.a=a}
function Zh(a){this.a=a}
function fh(){this.a={}}
function kh(){this.a={}}
function mh(){this.a={}}
function hg(){this.a={}}
function jg(){this.a={}}
function pd(a){return a.b}
function mf(a,b){return a[b]}
function je(a,b){return a===b}
function Gg(a,b){return a.g=b}
function $(a,b){return Zd(a,b)}
function Sh(a,b){ne(a.a,b)}
function Eh(a,b){ne(a.b,b)}
function qf(a,b){rf(a.j,b)}
function me(a,b,c){$e(a.a,b,c)}
function nf(a,b,c){a[b]=c}
function rf(a,b){a.state=Ae(b)}
function _e(a,b){a.splice(b,1)}
function og(a){sf.call(this,a)}
function ug(a){sf.call(this,a)}
function Bg(a){sf.call(this,a)}
function Rg(a){sf.call(this,a)}
function bh(a){sf.call(this,a)}
function ui(){return df(this)}
function he(){q(this);this.q()}
function Ke(a,b){Fe(a);a.a.G(b)}
function Pe(a,b){We(a,Oe(a.a,b))}
function Be(a,b){while(a.H(b));}
function Oe(a,b){a.C(b);return a}
function uf(a,b){a.ref=b;return a}
function Ud(a){Td(a);return a.k}
function v(){v=Hd;u=new n}
function P(){P=Hd;O=new S}
function F(){F=Hd;!!(W(),V)}
function N(){B!=0&&(B=0);D=-1}
function Ad(){yd==null&&(yd=[])}
function Bb(a){return a.l|a.m<<22}
function eb(a){return new Array(a)}
function hh(a){return ih(new kh,a)}
function Qb(a){return typeof a===_h}
function M(a){$wnd.clearTimeout(a)}
function vf(a,b){a.href=b;return a}
function Ff(a,b){a.value=b;return a}
function Af(a,b){a.onBlur=b;return a}
function ce(a,b){this.a=a;this.b=b}
function Se(a,b){this.a=a;this.b=b}
function Ee(a){this.b=a;this.a=16464}
function xe(){this.a=new $wnd.Date}
function hf(){hf=Hd;ef=new n;gf=new n}
function yf(a,b){a.checked=b;return a}
function wf(a,b){a.onClick=b;return a}
function $e(a,b,c){a.splice(b,0,c)}
function Te(a,b){a.I(jh(hh(b.b),b))}
function cg(a,b){ce.call(this,a,b)}
function uh(a,b){ce.call(this,a,b)}
function pf(a,b){a.j.setState(b,null)}
function Rh(a,b){a.b=b;oe(a.a,new Yh)}
function ib(a){return jb(a.l,a.m,a.h)}
function te(a){return a.a<a.c.a.length}
function Sb(a){return a==null?null:a}
function Ob(a,b){return a!=null&&Mb(a,b)}
function ie(a,b){return a.charCodeAt(b)}
function Bh(a,b){return pe(a.a,b,0)!=-1}
function jb(a,b,c){return {l:a,m:b,h:c}}
function df(a){return a.$H||(a.$H=++cf)}
function Rb(a){return typeof a==='string'}
function Cf(a,b){a.onKeyDown=b;return a}
function Bf(a,b){a.onChange=b;return a}
function xf(a){a.autoFocus=true;return a}
function Td(a){if(a.k!=null){return}_d(a)}
function r(a,b){a.b=b;b!=null&&bf(b,bi,a)}
function zf(a,b){a.defaultValue=b;return a}
function Ne(a,b){He.call(this,a);this.a=b}
function t(a){this.c=a;q(this);this.q()}
function se(){this.a=bb(jc,ki,1,0,5,1)}
function Hh(){this.a=new se;this.b=new se}
function Ch(a,b){qe(a.a,b);oe(a.b,new Lh)}
function Fh(a,b){We(b,!b.a);oe(a.b,new Lh)}
function W(){W=Hd;var a;!Y();a=new Z;V=a}
function q(a){a.d&&a.b!==ai&&a.q();return a}
function Gf(a,b){a.onDoubleClick=b;return a}
function of(a,b){var c;c={};c[a]=b;return c}
function Xd(a){var b;b=Wd(a);be(a,b);return b}
function Dh(a,b,c){b.c=Ae(c);oe(a.b,new Lh)}
function G(a,b,c){return a.apply(b,c);var d}
function bf(b,c,d){try{b[c]=d}catch(a){}}
function ue(a){a.b=a.a++;return a.c.a[a.b]}
function ne(a,b){a.a[a.a.length]=b;return true}
function ih(a,b){nf(a.a,'key',Ae(b));return a}
function vd(a){if(Qb(a)){return a|0}return Bb(a)}
function Pb(a){return typeof a==='boolean'}
function db(a){return Array.isArray(a)&&a.X===Ld}
function Nb(a){return !Array.isArray(a)&&a.X===Ld}
function Le(a){Ge(a);return new Ne(a,new Ue(a.a))}
function wd(a){if(Qb(a)){return ''+a}return Cb(a)}
function T(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Qe(a,b,c){if(a.a.J(c)){a.b=true;b.I(c)}}
function Mg(a){Fh((ph(),nh),a.j.props[ri])}
function Og(a){Ch((ph(),nh),mf(a.j.props,ri))}
function Qd(){t.call(this,'divide by zero')}
function Od(){Od=Hd;Nd=$wnd.window.document}
function ph(){ph=Hd;nh=new Hh;oh=new Uh(nh)}
function lf(){if(ff==256){ef=gf;gf=new n;ff=0}++ff}
function Ae(a){if(a==null){throw pd(new he)}return a}
function He(a){if(!a){this.b=null;new se}else{this.b=a}}
function Fe(a){if(!a.b){Ge(a);a.c=true}else{Fe(a.b)}}
function Je(a,b){Ge(a);return new Ne(a,new Re(b,a.a))}
function Db(a,b){return jb(a.l^b.l,a.m^b.m,a.h^b.h)}
function Vh(a,b){return (th(),rh)==a||(qh==a?!b.a:b.a)}
function ze(a,b){return Sb(a)===Sb(b)||!!a&&Sb(a)===Sb(b)}
function Ce(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function xh(a,b){this.b=Ae(a);this.c=Ae(b);this.a=false}
function Ue(a){Ce.call(this,a.F(),a.D()&-6);this.a=a}
function mg(){lg();this.a=Id(pg.prototype.U,pg,[])}
function _g(){$g();this.a=Id(dh.prototype.S,dh,[])}
function lg(){lg=Hd;var a;kg=(a=Id(ng.prototype.O,ng,[]),a)}
function rg(){rg=Hd;var a;qg=(a=Id(tg.prototype.O,tg,[]),a)}
function xg(){xg=Hd;var a;wg=(a=Id(Ag.prototype.O,Ag,[]),a)}
function Kg(){Kg=Hd;var a;Jg=(a=Id(Qg.prototype.O,Qg,[]),a)}
function $g(){$g=Hd;var a;Zg=(a=Id(ah.prototype.O,ah,[]),a)}
function vh(){th();return fb($(ad,1),ki,22,0,[qh,sh,rh])}
function xd(a,b){return rd(Db(Qb(a)?ud(a):a,Qb(b)?ud(b):b))}
function Yd(a,b){var c;c=Wd(a);be(a,c);c.e=b?8:0;return c}
function Ef(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function $d(a){if(a.A()){return null}var b=a.j;return Dd[b]}
function De(a){if(!a.d){a.d=new ve(a.b);a.c=a.b.a.length}}
function Ge(a){if(a.b){Ge(a.b)}else if(a.c){throw pd(new de)}}
function L(a){F();$wnd.setTimeout(function(){throw a},0)}
function Pd(a,b,c,d){a.addEventListener(b,c,(Rd(),d?true:false))}
function J(a,b,c){var d;d=H();try{return G(a,b,c)}finally{K(d)}}
function Zd(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.s(b))}
function Fd(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Jd(a){function b(){}
;b.prototype=a||{};return new b}
function s(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Df(a){a.placeholder='What needs to be done?';return a}
function Ie(a){var b;Fe(a);b=0;while(a.a.H(new Ye)){b=qd(b,1)}return b}
function Gh(a,b){Ke(new Ne(null,new Ee(a.a)),new Nh(b));oe(a.b,new Lh)}
function Me(a,b){var c;Fe(a);c=new Xe;c.a=b;a.a.G(new Ze(c));return c.a}
function hb(a){var b,c,d;b=a&di;c=a>>22&di;d=a<0?ei:0;return jb(b,c,d)}
function Th(a){var b;b=a.b;!!b&&!Bh(a.c,b)&&(a.b=null,oe(a.a,new Yh))}
function yg(a,b){var c;c=b.target;pf(a,Id(Cg.prototype.N,Cg,[c.value]))}
function ye(a,b){while(a.a<a.c.a.length){b.I((a.b=a.a++,a.c.a[a.b]))}}
function Re(a,b){Ce.call(this,b.F(),b.D()&-16449);this.a=a;this.c=b}
function le(){t.call(this,'Add not supported on this collection')}
function I(b){F();return function(){return J(b,this,arguments);var a}}
function A(){if(Date.now){return Date.now()}return (new Date).getTime()}
function ig(a){return $wnd.React.createElement((rg(),qg),a.a,undefined)}
function gg(a){return $wnd.React.createElement((lg(),kg),a.a,undefined)}
function eh(a){return $wnd.React.createElement((xg(),wg),a.a,undefined)}
function lh(a){return $wnd.React.createElement(($g(),Zg),a.a,undefined)}
function Tb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function K(a){a&&R((P(),O));--B;if(a){if(D!=-1){M(D);D=-1}}}
function Ib(){Ib=Hd;Eb=jb(di,di,524287);Fb=jb(0,0,fi);Gb=hb(1);hb(2);Hb=hb(0)}
function bb(a,b,c,d,e,f){var g;g=cb(e,d);e!=10&&fb($(a,f),b,c,e,g);return g}
function qe(a,b){var c;c=pe(a,b,0);if(c==-1){return false}_e(a.a,c);return true}
function Ig(a,b){var c;c=a?ni:'';if(b){c.length==0||(c+=' ');c+='editing'}return c}
function pe(a,b,c){for(;c<a.a.length;++c){if(ze(b,a.a[c])){return c}}return -1}
function be(a,b){var c;if(!a){return}b.j=a;var d=$d(b);if(!d){Dd[a]=[b];return}d.V=b}
function od(a){var b;if(Ob(a,5)){return a}b=a&&a[bi];if(!b){b=new w(a);X(b)}return b}
function Wd(a){var b;b=new Vd;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Q(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=U(b,c)}while(a.a);a.a=c}}
function R(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=U(b,c)}while(a.b);a.b=c}}
function oe(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.I(c)}}
function zd(){Ad();var a=yd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Id(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function fe(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function rd(a){var b;b=a.h;if(b==0){return a.l+a.m*hi}if(b==ei){return a.l+a.m*hi-gi}return a}
function jh(a,b){nf(a.a,ri,b);return $wnd.React.createElement((Kg(),Jg),a.a,undefined)}
function yh(a,b){ne(a.a,new xh(''+wd(sd((new xe).a.getTime())),b));oe(a.b,new Lh)}
function zh(a){var b;Me(Je(new Ne(null,new Ee(a.a)),new Jh),(b=new se,b)).B(new Kh(a))}
function th(){th=Hd;qh=new uh('ACTIVE',0);sh=new uh('COMPLETED',1);rh=new uh('ALL',2)}
function vi(){$wnd.ReactDOM.render(lh(new mh),(Od(),Nd).getElementById(ji),null)}
function af(a,b){return ab(b)!=10&&fb(o(b),b.W,b.__elementTypeId$,ab(b),a),a}
function ab(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function fb(a,b,c,d,e){e.V=a;e.W=b;e.X=Ld;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function ud(a){var b,c,d,e;e=a;d=0;if(e<0){e+=gi;d=ei}c=Tb(e/hi);b=Tb(e-c*hi);return jb(b,c,d)}
function tb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return jb(c&di,d&di,e&ei)}
function Ab(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return jb(c&di,d&di,e&ei)}
function wb(a){var b,c,d;b=~a.l+1&di;c=~a.m+(b==0?1:0)&di;d=~a.h+(b==0&&c==0?1:0)&ei;return jb(b,c,d)}
function ge(a,b){var c,d;for(d=new ve(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Ch(b.a,c)}}
function sd(a){if(ii<a&&a<gi){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return rd(vb(a))}
function de(){t.call(this,"Stream already terminated, can't be modified or used")}
function zg(){xg();this.b=Id(Dg.prototype.T,Dg,[this]);this.a=Id(Eg.prototype.S,Eg,[this])}
function w(a){v();q(this);this.b=a;a!=null&&bf(a,bi,this);this.c=a==null?'null':Kd(a);this.a=a}
function sf(a){$wnd.React.Component.call(this,a);this.a=this.P();this.a.j=Ae(this);this.a.L()}
function Vd(){this.g=Sd++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Ng(a){Rh((ph(),oh),mf(a.j.props,ri));pf(a,Id(Sg.prototype.N,Sg,[mf(a.j.props,ri).c]))}
function Fg(a,b){var c;if((ph(),oh).b==a.j.props[ri]){c=b.target;pf(a,Id(Sg.prototype.N,Sg,[c.value]))}}
function qd(a,b){var c;if(Qb(a)&&Qb(b)){c=a+b;if(ii<c&&c<gi){return c}}return rd(tb(Qb(a)?ud(a):a,Qb(b)?ud(b):b))}
function qb(a){var b,c;c=ee(a.h);if(c==32){b=ee(a.m);return b==32?ee(a.l)+32:b+20-10}else{return c-12}}
function pb(a){var b,c,d;b=~a.l+1&di;c=~a.m+(b==0?1:0)&di;d=~a.h+(b==0&&c==0?1:0)&ei;a.l=b;a.m=c;a.h=d}
function Ah(a){return vd(Ie(new Ne(null,new Ee(a.a))))-vd(Ie(Je(new Ne(null,new Ee(a.a)),new Mh)))}
function o(a){return Rb(a)?lc:Qb(a)?cc:Pb(a)?ac:Nb(a)?a.V:db(a)?a.V:a.V||Array.isArray(a)&&$(Vb,1)||Vb}
function p(a){return Rb(a)?kf(a):Qb(a)?Tb(a):Pb(a)?a?1231:1237:Nb(a)?a.o():db(a)?df(a):!!a&&!!a.hashCode?a.hashCode():df(a)}
function mb(a,b,c,d,e){var f;f=yb(a,b);c&&pb(f);if(e){a=ob(a,b);d?(gb=wb(a)):(gb=jb(a.l,a.m,a.h))}return f}
function lb(a,b){if(a.h==fi&&a.m==0&&a.l==0){b&&(gb=jb(0,0,0));return ib((Ib(),Gb))}b&&(gb=jb(a.l,a.m,a.h));return jb(0,0,0)}
function Kd(a){var b;if(Array.isArray(a)&&a.X===Ld){return Ud(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function H(){var a;if(B!=0){a=A();if(a-C>2000){C=a;D=$wnd.setTimeout(N,10)}}if(B++==0){Q((P(),O));return true}return false}
function Y(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Cd(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Lg(a,b){27==b.which?(pf(a,Id(Sg.prototype.N,Sg,[mf(a.j.props,ri).c])),Rh((ph(),oh),null)):13==b.which&&Hg(a)}
function dg(){bg();return fb($(Hc,1),ki,6,0,[Hf,If,Jf,Kf,Lf,Mf,Nf,Of,Pf,Qf,Rf,Sf,Tf,Uf,Vf,Wf,Xf,Yf,Zf,$f,_f,ag])}
function kf(a){hf();var b,c,d;c=':'+a;d=gf[c];if(d!=null){return Tb(d)}d=ef[c];b=d==null?jf(a):Tb(d);lf();gf[c]=b;return b}
function we(a){var b,c,d;d=1;for(c=new ve(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function re(a,b){var c,d;d=a.a.length;b.length<d&&(b=af(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function ae(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Uh(a){this.a=new se;this.c=Ae(a);Pd((Od(),$wnd.window.window),'hashchange',new Wh(this),false);Eh(a,Id(Xh.prototype.Q,Xh,[this]))}
function vg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=ke(a.j.state[pi]);if(c.length>0){yh((ph(),nh),c);pf(a,Id(Cg.prototype.N,Cg,['']))}}}
function tf(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Mb(a,b){if(Rb(a)){return !!Lb[b]}else if(a.W){return !!a.W[b]}else if(Qb(a)){return !!Kb[b]}else if(Pb(a)){return !!Jb[b]}return false}
function Md(){Eh((ph(),nh),Id(eg.prototype.Q,eg,[]));Sh(oh,Id(fg.prototype.Q,fg,[]));$wnd.ReactDOM.render(lh(new mh),(Od(),Nd).getElementById(ji),null)}
function ke(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ob(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return jb(c,d,e)}
function xb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return jb(c&di,d&di,e&ei)}
function zb(a,b){var c,d,e,f;b&=63;c=a.h&ei;if(b<22){f=c>>>b;e=a.m>>b|c<<22-b;d=a.l>>b|a.m<<22-b}else if(b<44){f=0;e=c>>>b-22;d=a.m>>b-22|a.h<<44-b}else{f=0;e=0;d=c>>>b-44}return jb(d&di,e&di,f&ei)}
function cb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function sb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&di;a.m=d&di;a.h=e&ei;return true}
function Hg(a){var b;b=a.j.state[si];if(b.length!=0){Dh((ph(),nh),a.j.props[ri],b);Rh(oh,null);pf(a,Id(Sg.prototype.N,Sg,[b]))}else{Ch((ph(),nh),a.j.props[ri])}}
function Ph(a,b){var c,d;b.preventDefault();c=(d=(Od(),$wnd.window.window).location.hash,null==d?'':d.substr(1));je(mi,c)||je(ni,c)||je('',c)?oe(a.a,new Yh):Qh()}
function ub(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Bd(b,c,d,e){Ad();var f=yd;$moduleName=c;$moduleBase=d;nd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{$h(g)()}catch(a){b(c,a)}}else{$h(g)()}}
function U(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Y()&&(c=T(c,g)):g[0].Y()}catch(a){a=od(a);if(Ob(a,5)){d=a;F();L(Ob(d,24)?d.r():d)}else throw pd(a)}}return c}
function Ed(){Dd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function jf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ie(a,c++)}b=b|0;return b}
function Qh(){var a;if(0==''.length){a=(Od(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Nd.title,a)}else{(Od(),$wnd.window.window).location.hash=''}}
function ee(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Gd(a,b,c){var d=Dd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Dd[b]),Jd(h));_.W=c;!b&&(_.X=Ld);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.V=f)}
function Pg(){Kg();this.b=Id(Tg.prototype.T,Tg,[this]);this.e=Id(Ug.prototype.R,Ug,[this]);this.f=Id(Vg.prototype.S,Vg,[this]);this.d=Id(Wg.prototype.U,Wg,[this]);this.c=Id(Xg.prototype.U,Xg,[this]);this.a=Id(Yg.prototype.S,Yg,[this])}
function yb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&fi)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?ei:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?ei:0;f=d?di:0;e=c>>b-44}return jb(e&di,f&di,g&ei)}
function _d(a){if(a.w()){var b=a.c;b.A()?(a.k='['+b.j):!b.w()?(a.k='[L'+b.u()+';'):(a.k='['+b.u());a.b=b.t()+'[]';a.i=b.v()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=ae('.',[c,ae('$',d)]);a.b=ae('.',[c,ae('.',d)]);a.i=d[d.length-1]}
function Oh(a){var b,c,d,e;b=(e=(c=(Od(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),je(mi,e)||je(ni,e)||je('',e)?je(mi,e)?(th(),qh):je(ni,e)?(th(),sh):(th(),rh):(th(),rh));return Me(Je(new Ne(null,new Ee(a.c.a)),new Zh(b)),(d=new se,d))}
function rb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return fe(c)}if(b==0&&d!=0&&c==0){return fe(d)+22}if(b!=0&&d==0&&c==0){return fe(b)+44}return -1}
function vb(a){var b,c,d,e,f;if(isNaN(a)){return Ib(),Hb}if(a<-9223372036854775808){return Ib(),Fb}if(a>=9223372036854775807){return Ib(),Eb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=gi){d=Tb(a/gi);a-=d*gi}c=0;if(a>=hi){c=Tb(a/hi);a-=c*hi}b=Tb(a);f=jb(b,c,d);e&&pb(f);return f}
function Cb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==fi&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Cb(wb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=hb(1000000000);c=kb(c,e,true);b=''+Bb(gb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function nb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=qb(b)-qb(a);g=xb(b,j);i=jb(0,0,0);while(j>=0){h=sb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&pb(i);if(f){if(d){gb=wb(a);e&&(gb=Ab(gb,(Ib(),Gb)))}else{gb=jb(a.l,a.m,a.h)}}return i}
function bg(){bg=Hd;Hf=new cg(li,0);If=new cg('checkbox',1);Jf=new cg('color',2);Kf=new cg('date',3);Lf=new cg('datetime',4);Mf=new cg('email',5);Nf=new cg('file',6);Of=new cg('hidden',7);Pf=new cg('image',8);Qf=new cg('month',9);Rf=new cg(_h,10);Sf=new cg('password',11);Tf=new cg('radio',12);Uf=new cg('range',13);Vf=new cg('reset',14);Wf=new cg('search',15);Xf=new cg('submit',16);Yf=new cg('tel',17);Zf=new cg('text',18);$f=new cg('time',19);_f=new cg('url',20);ag=new cg('week',21)}
function kb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw pd(new Qd)}if(a.l==0&&a.m==0&&a.h==0){c&&(gb=jb(0,0,0));return jb(0,0,0)}if(b.h==fi&&b.m==0&&b.l==0){return lb(a,c)}i=false;if(b.h>>19!=0){b=wb(b);i=true}g=rb(b);f=false;e=false;d=false;if(a.h==fi&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ib((Ib(),Eb));d=true;i=!i}else{h=yb(a,g);i&&pb(h);c&&(gb=jb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=wb(a);d=true;i=!i}if(g!=-1){return mb(a,g,i,f,c)}if(ub(a,b)<0){c&&(f?(gb=wb(a)):(gb=jb(a.l,a.m,a.h)));return jb(0,0,0)}return nb(d?a:jb(a.l,a.m,a.h),b,i,f,e,c)}
var _h='number',ai='__noinit__',bi='__java$exception',ci={3:1,7:1,5:1},di=4194303,ei=1048575,fi=524288,gi=17592186044416,hi=4194304,ii=-17592186044416,ji='todoapp',ki={3:1,4:1},li='button',mi='active',ni='completed',oi='selected',pi='todoText',qi='input',ri='todo',si='editText',ti='header';var _,Dd,yd,nd=-1;Ed();Gd(1,null,{},n);_.n=function(){return this.V};_.o=ui;_.hashCode=function(){return this.o()};var Jb,Kb,Lb;Gd(31,1,{},Vd);_.s=function(a){var b;b=new Vd;b.e=4;a>1?(b.c=Zd(this,a-1)):(b.c=this);return b};_.t=function(){Td(this);return this.b};_.u=function(){return Ud(this)};_.v=function(){Td(this);return this.i};_.w=function(){return (this.e&4)!=0};_.A=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Sd=1;var jc=Xd(1);var bc=Xd(31);Gd(5,1,{3:1,5:1});_.p=function(a){return new Error(a)};_.q=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=Ud(this.V),c==null?a:a+': '+c);r(this,s(this.p(b)));X(this)};_.b=ai;_.d=true;var mc=Xd(5);Gd(26,5,{3:1,5:1});var ec=Xd(26);Gd(7,26,ci);var kc=Xd(7);Gd(32,7,ci);var gc=Xd(32);Gd(43,32,ci);var Xb=Xd(43);Gd(24,43,{24:1,3:1,7:1,5:1},w);_.r=function(){return Sb(this.a)===Sb(u)?null:this.a};var u;var Ub=Xd(24);var Vb=Xd(0);Gd(86,1,{});var Wb=Xd(86);var B=0,C=0,D=-1;Gd(58,86,{},S);var O;var Yb=Xd(58);var V;Gd(99,1,{});var $b=Xd(99);Gd(44,99,{},Z);var Zb=Xd(44);var gb;var Eb,Fb,Gb,Hb;var Nd;Gd(56,7,ci,Qd);var _b=Xd(56);Jb={3:1,18:1};var ac=Xd(96);Gd(97,1,{3:1});var ic=Xd(97);Kb={3:1,18:1};var cc=Xd(98);Gd(21,1,{3:1,18:1,21:1});_.o=ui;_.b=0;var dc=Xd(21);Gd(46,7,ci,de);var fc=Xd(46);Gd(160,1,{});Gd(55,32,ci,he);_.p=function(a){return new TypeError(a)};var hc=Xd(55);Lb={3:1,39:1,18:1,2:1};var lc=Xd(2);Gd(164,1,{});Gd(54,7,ci,le);var nc=Xd(54);Gd(100,1,{83:1});_.B=function(a){ge(this,a)};_.C=function(a){throw pd(new le)};var oc=Xd(100);Gd(101,100,{83:1,108:1});_.C=function(a){me(this,this.a.length,a);return true};_.o=function(){return we(this)};var pc=Xd(101);Gd(10,101,{3:1,10:1,83:1,108:1},se);_.C=function(a){return ne(this,a)};_.B=function(a){oe(this,a)};var rc=Xd(10);Gd(15,1,{},ve);_.a=0;_.b=-1;var qc=Xd(15);Gd(28,1,{3:1,18:1,28:1},xe);_.o=function(){var a;a=sd(this.a.getTime());return vd(xd(a,rd(zb(Qb(a)?ud(a):a,32))))};var sc=Xd(28);Gd(62,1,{});_.G=function(a){Be(this,a)};_.D=function(){return this.d};_.F=function(){return this.e};_.d=0;_.e=0;var uc=Xd(62);Gd(35,62,{});var tc=Xd(35);Gd(11,1,{},Ee);_.D=function(){return this.a};_.F=function(){De(this);return this.c};_.G=function(a){De(this);ye(this.d,a)};_.H=function(a){De(this);if(te(this.d)){a.I(ue(this.d));return true}return false};_.a=0;_.c=0;var vc=Xd(11);Gd(61,1,{});_.c=false;var Ec=Xd(61);Gd(9,61,{},Ne);var Dc=Xd(9);Gd(64,35,{},Re);_.H=function(a){this.b=false;while(!this.b&&this.c.H(new Se(this,a)));return this.b};_.b=false;var xc=Xd(64);Gd(67,1,{},Se);_.I=function(a){Qe(this.a,this.b,a)};var wc=Xd(67);Gd(63,35,{},Ue);_.H=function(a){return this.a.H(new Ve(a))};var zc=Xd(63);Gd(66,1,{},Ve);_.I=function(a){Te(this.a,a)};var yc=Xd(66);Gd(65,1,{},Xe);_.I=function(a){We(this,a)};var Ac=Xd(65);Gd(68,1,{},Ye);_.I=function(a){};var Bc=Xd(68);Gd(69,1,{},Ze);_.I=function(a){Pe(this.a,a)};var Cc=Xd(69);Gd(162,1,{});Gd(159,1,{});var cf=0;var ef,ff=0,gf;Gd(539,1,{});Gd(602,1,{});Gd(102,1,{});_.K=function(a,b){};_.L=function(){};var Fc=Xd(102);Gd(20,$wnd.React.Component,{});Fd(Dd[1],_);_.render=function(){return this.a.M()};var Gc=Xd(20);Gd(6,21,{3:1,18:1,21:1,6:1},cg);var Hf,If,Jf,Kf,Lf,Mf,Nf,Of,Pf,Qf,Rf,Sf,Tf,Uf,Vf,Wf,Xf,Yf,Zf,$f,_f,ag;var Hc=Yd(6,dg);Gd(112,$wnd.Function,{38:1},eg);_.Q=vi;Gd(113,$wnd.Function,{38:1},fg);_.Q=vi;Gd(105,102,{});_.M=function(){var a,b,c;a=(ph(),c=(b=(Od(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),je(mi,c)||je(ni,c)||je('',c)?je(mi,c)?(th(),qh):je(ni,c)?(th(),sh):(th(),rh):(th(),rh));return $wnd.React.createElement('footer',tf(new $wnd.Object,fb($(lc,1),ki,2,6,['footer'])),ig(new jg),$wnd.React.createElement('ul',tf(new $wnd.Object,fb($(lc,1),ki,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',vf(tf(new $wnd.Object,fb($(lc,1),ki,2,6,[(th(),rh)==a?oi:''])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',vf(tf(new $wnd.Object,fb($(lc,1),ki,2,6,[qh==a?oi:''])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',vf(tf(new $wnd.Object,fb($(lc,1),ki,2,6,[sh==a?oi:''])),'#completed'),'Completed'))),Ah(nh)>0?$wnd.React.createElement(li,wf(tf(new $wnd.Object,fb($(lc,1),ki,2,6,['clear-completed'])),this.a),'Clear Completed'):null)};var Lc=Xd(105);Gd(72,1,{},hg);var Ic=Xd(72);Gd(107,102,{});_.M=function(){var a,b;b=vd(Ie(new Ne(null,new Ee((ph(),nh).a))));a='item'+(b==1?'':'s');return $wnd.React.createElement('span',tf(new $wnd.Object,fb($(lc,1),ki,2,6,['todo-count'])),$wnd.React.createElement('strong',null,''+b),' '+a+' left')};var Kc=Xd(107);Gd(80,1,{},jg);var Jc=Xd(80);Gd(75,105,{},mg);var kg;var Pc=Xd(75);Gd(134,$wnd.Function,{},ng);_.O=function(a){return new og(a)};Gd(76,20,{},og);_.P=function(){return new mg};var Mc=Xd(76);Gd(135,$wnd.Function,{},pg);_.U=function(a){zh((ph(),nh))};Gd(81,107,{},sg);var qg;var Oc=Xd(81);Gd(145,$wnd.Function,{},tg);_.O=function(a){return new ug(a)};Gd(82,20,{},ug);_.P=function(){return new sg};var Nc=Xd(82);Gd(104,102,{});_.L=function(){qf(this,of(pi,''))};_.M=function(){return $wnd.React.createElement(qi,xf(Bf(Cf(Ff(Df(tf(new $wnd.Object,fb($(lc,1),ki,2,6,['new-todo']))),this.j.state[pi]),this.b),this.a)))};var Xc=Xd(104);Gd(73,104,{},zg);var wg;var Rc=Xd(73);Gd(131,$wnd.Function,{},Ag);_.O=function(a){return new Bg(a)};Gd(74,20,{},Bg);_.P=function(){return new zg};var Qc=Xd(74);Gd(110,$wnd.Function,{},Cg);_.N=function(a,b){return xg(),of(pi,this.a)};Gd(132,$wnd.Function,{},Dg);_.T=function(a){vg(this.a,a)};Gd(133,$wnd.Function,{},Eg);_.S=function(a){yg(this.a,a)};Gd(106,102,{});_.K=function(a,b){var c;c=(ph(),oh).b==this.j.props[ri];if(!this.i&&c){this.i=true;pf(this,Id(Sg.prototype.N,Sg,[this.j.props[ri].c]));this.g.focus();this.g.select()}else this.i&&!c&&(this.i=false)};_.L=function(){qf(this,of(si,mf(this.j.props,ri).c))};_.M=function(){var a,b;b=this.j.props[ri];a=b.a;return $wnd.React.createElement('li',tf(new $wnd.Object,fb($(lc,1),ki,2,6,[Ig(a,(ph(),oh).b==this.j.props[ri])])),$wnd.React.createElement('div',tf(new $wnd.Object,fb($(lc,1),ki,2,6,['view'])),$wnd.React.createElement(qi,Bf(yf(Ef(tf(new $wnd.Object,fb($(lc,1),ki,2,6,['toggle'])),(bg(),If)),a),this.f)),$wnd.React.createElement('label',Gf(new $wnd.Object,this.d),b.c),$wnd.React.createElement(li,wf(tf(new $wnd.Object,fb($(lc,1),ki,2,6,['destroy'])),this.c))),$wnd.React.createElement(qi,Cf(Bf(Af(zf(tf(uf(new $wnd.Object,Id(gh.prototype.I,gh,[this])),fb($(lc,1),ki,2,6,['edit'])),this.j.state[si]),this.e),this.a),this.b)))};_.i=false;var Zc=Xd(106);Gd(78,106,{},Pg);var Jg;var Tc=Xd(78);Gd(136,$wnd.Function,{},Qg);_.O=function(a){return new Rg(a)};Gd(79,20,{},Rg);_.P=function(){return new Pg};_.componentDidUpdate=function(a,b){this.a.K(a,b)};var Sc=Xd(79);Gd(30,$wnd.Function,{},Sg);_.N=function(a,b){return Kg(),of(si,this.a)};Gd(137,$wnd.Function,{},Tg);_.T=function(a){Lg(this.a,a)};Gd(138,$wnd.Function,{},Ug);_.R=function(a){Hg(this.a)};Gd(139,$wnd.Function,{},Vg);_.S=function(a){Mg(this.a)};Gd(140,$wnd.Function,{},Wg);_.U=function(a){Ng(this.a)};Gd(141,$wnd.Function,{},Xg);_.U=function(a){Og(this.a)};Gd(142,$wnd.Function,{},Yg);_.S=function(a){Fg(this.a,a)};Gd(103,102,{});_.M=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(ti,tf(new $wnd.Object,fb($(lc,1),ki,2,6,[ti])),$wnd.React.createElement('h1',null,'todos'),eh(new fh)),0!=vd(Ie(new Ne(null,new Ee((ph(),nh).a))))?$wnd.React.createElement('section',tf(new $wnd.Object,fb($(lc,1),ki,2,6,[ti])),$wnd.React.createElement(qi,Bf(Ef(tf(new $wnd.Object,fb($(lc,1),ki,2,6,['toggle-all'])),(bg(),If)),this.a)),$wnd.React.createElement.apply(null,['ul',tf(new $wnd.Object,fb($(lc,1),ki,2,6,['todo-list']))].concat((a=Me(Le(new Ne(null,new Ee(Oh(oh)))),(b=new se,b)),re(a,eb(a.a.length)))))):null,0!=vd(Ie(new Ne(null,new Ee(nh.a))))?gg(new hg):null))};var _c=Xd(103);Gd(59,103,{},_g);var Zg;var Vc=Xd(59);Gd(129,$wnd.Function,{},ah);_.O=function(a){return new bh(a)};Gd(60,20,{},bh);_.P=function(){return new _g};var Uc=Xd(60);Gd(130,$wnd.Function,{},dh);_.S=function(a){var b;b=a.target;Gh((ph(),nh),b.checked)};Gd(71,1,{},fh);var Wc=Xd(71);Gd(144,$wnd.Function,{},gh);_.I=function(a){Gg(this.a,a)};Gd(77,1,{},kh);var Yc=Xd(77);Gd(25,1,{},mh);var $c=Xd(25);var nh,oh;Gd(22,21,{3:1,18:1,21:1,22:1},uh);var qh,rh,sh;var ad=Yd(22,vh);Gd(34,1,{34:1},xh);_.a=false;var hd=Xd(34);Gd(33,1,{33:1},Hh);var gd=Xd(33);Gd(49,1,{},Jh);_.J=function(a){return a.a};var bd=Xd(49);Gd(50,1,{},Kh);_.I=function(a){Ch(this.a,a)};var cd=Xd(50);Gd(19,1,{},Lh);_.I=wi;var dd=Xd(19);Gd(47,1,{},Mh);_.J=function(a){return !a.a};var ed=Xd(47);Gd(48,1,{},Nh);_.I=function(a){Ih(this.a,a)};_.a=false;var fd=Xd(48);Gd(51,1,{},Uh);var md=Xd(51);Gd(52,1,{},Wh);_.handleEvent=function(a){Ph(this.a,a)};var jd=Xd(52);Gd(118,$wnd.Function,{38:1},Xh);_.Q=function(){Th(this.a)};Gd(27,1,{},Yh);_.I=wi;var kd=Xd(27);Gd(53,1,{},Zh);_.J=function(a){return Vh(this.a,a)};var ld=Xd(53);var $h=(F(),I);var gwtOnLoad=gwtOnLoad=Bd;zd(Md);Cd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();