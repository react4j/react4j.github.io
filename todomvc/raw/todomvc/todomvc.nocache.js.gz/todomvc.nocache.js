function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='37920764280D529BD0CC3804D9022577',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '37920764280D529BD0CC3804D9022577';function n(){}
function s(){}
function X(){}
function Xd(){}
function _d(){}
function db(){}
function lf(){}
function mf(){}
function Wg(){}
function Zg(){}
function bh(){}
function gh(){}
function kh(){}
function oh(){}
function Hh(){}
function Vh(){}
function fi(){}
function hi(){}
function ii(){}
function ti(){}
function t(a){Qe(a)}
function bb(a){ab()}
function Si(a){a.p()}
function kf(a,b){a.a=b}
function jf(a){this.a=a}
function nf(a){this.a=a}
function Vg(a){this.a=a}
function sh(a){this.a=a}
function th(a){this.a=a}
function vh(a){this.a=a}
function wh(a){this.a=a}
function xh(a){this.a=a}
function yh(a){this.a=a}
function zh(a){this.a=a}
function Ah(a){this.a=a}
function Bh(a){this.a=a}
function Ch(a){this.a=a}
function Fh(a){this.a=a}
function Gh(a){this.a=a}
function gi(a){this.a=a}
function ji(a){this.a=a}
function ri(a){this.a=a}
function si(a){this.a=a}
function ui(a){this.a=a}
function Me(a){this.c=a}
function fe(){fe=Xd}
function r(){r=Xd;new q}
function D(){D=Xd;C=new n}
function U(){U=Xd;T=new X}
function K(){K=Xd;!!(ab(),$)}
function Cf(a,b){Bf(a,b)}
function Th(a,b){Ee(a.c,b)}
function ai(a,b){Ee(a.b,b)}
function ni(a,b){Ee(a.a,b)}
function De(a,b,c){of(a.a,b,c)}
function Df(a,b){a.key=b}
function pf(a,b){a.splice(b,1)}
function eb(a,b){return oe(a,b)}
function Ig(a,b){return a.a=b}
function Ae(a,b){return a===b}
function Gd(a){return a.b}
function Qi(a){return false}
function Pi(){return tf(this)}
function ye(){v(this);this.r()}
function $e(a,b){Ve(a);a.a.H(b)}
function df(a,b){kf(a,cf(a.a,b))}
function Re(a,b){while(a.I(b));}
function te(a,b){this.a=a;this.b=b}
function gf(a,b){this.a=a;this.b=b}
function Kf(a,b){this.a=a;this.b=b}
function Mf(a,b){a.ref=b;return a}
function Nf(a,b){a.href=b;return a}
function cf(a,b){a.D(b);return a}
function ie(a){he(a);return a.k}
function Fb(a){return a.l|a.m<<22}
function jb(a){return new Array(a)}
function R(a){$wnd.clearTimeout(a)}
function tg(a,b){te.call(this,a,b)}
function Qh(a,b){te.call(this,a,b)}
function of(a,b,c){a.splice(b,0,c)}
function Wf(a,b){a.value=b;return a}
function Qd(){Od==null&&(Od=[])}
function S(){H!=0&&(H=0);J=-1}
function Xg(){this.a=Ef((_g(),$g))}
function Yg(){this.a=Ef((eh(),dh))}
function uh(){this.a=Ef((ih(),hh))}
function Eh(){this.a=Ef((mh(),lh))}
function Ih(){this.a=Ef((qh(),ph))}
function xg(a){this.d=Qe(a);r();++wg}
function zg(a){this.d=Qe(a);r();++yg}
function Fg(a){this.d=Qe(a);r();++Eg}
function Ug(a){this.d=Qe(a);r();++Tg}
function Ue(a){this.b=a;this.a=16464}
function Ri(){this.a.d.forceUpdate()}
function ei(a,b){b.a=a;Fe(b.c,new Vh)}
function Sh(a,b){a.a=b;Fe(a.c,new Vh)}
function mi(a,b){a.b=b;Fe(a.a,new ti)}
function Rf(a,b){a.onBlur=b;return a}
function Of(a,b){a.onClick=b;return a}
function Sf(a,b){a.onChange=b;return a}
function Qf(a,b){a.checked=b;return a}
function Vb(a){return a==null?null:a}
function Tb(a){return typeof a===wi}
function nb(a){return ob(a.l,a.m,a.h)}
function Ke(a){return a.a<a.c.a.length}
function ze(a,b){return a.charCodeAt(b)}
function Zh(a,b){return Ge(a.a,b,0)!=-1}
function ob(a,b,c){return {l:a,m:b,h:c}}
function Rb(a,b){return a!=null&&Pb(a,b)}
function tf(a){return a.$H||(a.$H=++sf)}
function xf(){xf=Xd;uf=new n;wf=new n}
function q(){this.a=new u;new t(this.a)}
function B(a){this.c=a;v(this);this.r()}
function Je(){this.a=gb(rc,xi,1,0,5,1)}
function vg(a){ni((Lh(),Kh),new Vg(a))}
function Bf(a,b){for(var c in a){b(c)}}
function Tf(a,b){a.onKeyDown=b;return a}
function Pf(a){a.autoFocus=true;return a}
function he(a){if(a.k!=null){return}qe(a)}
function w(a,b){a.b=b;b!=null&&rf(b,zi,a)}
function Pg(a,b){a.b=b;a.d.forceUpdate()}
function Dg(a,b){a.a=b;a.d.forceUpdate()}
function $h(a,b){He(a.a,b);Fe(a.b,new hi)}
function bi(a,b){Sh(b,!b.a);Fe(a.b,new hi)}
function di(){this.a=new Je;this.b=new Je}
function bf(a,b){Xe.call(this,a);this.a=b}
function ee(){B.call(this,'divide by zero')}
function Sb(a){return typeof a==='boolean'}
function Ub(a){return typeof a==='string'}
function L(a,b,c){return a.apply(b,c);var d}
function rf(b,c,d){try{b[c]=d}catch(a){}}
function de(a,b,c,d){a.addEventListener(b,c,d)}
function Ee(a,b){a.a[a.a.length]=b;return true}
function Xf(a,b){a.onDoubleClick=b;return a}
function v(a){a.d&&a.b!==yi&&a.r();return a}
function le(a){var b;b=ke(a);se(a,b);return b}
function Ag(a,b){var c;c=b.target;Dg(a,c.value)}
function Le(a){a.b=a.a++;return a.c.a[a.b]}
function Md(a){if(Tb(a)){return a|0}return Fb(a)}
function ne(a){var b;b=ke(a);b.j=a;b.e=1;return b}
function Y(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Nd(a){if(Tb(a)){return ''+a}return Gb(a)}
function _e(a){We(a);return new bf(a,new hf(a.a))}
function Lh(){Lh=Xd;Jh=new di;Kh=new pi(Jh)}
function ab(){ab=Xd;var a;!cb();a=new db;$=a}
function ce(){ce=Xd;be=$wnd.window.document}
function Jg(a){$h((Lh(),Jh),a.d.props['a'])}
function Mg(a){bi((Lh(),Jh),a.d.props['a'])}
function ef(a,b,c){if(a.a.K(c)){a.b=true;b.J(c)}}
function Ve(a){if(!a.b){We(a);a.c=true}else{Ve(a.b)}}
function Xe(a){if(!a){this.b=null;new Je}else{this.b=a}}
function Qe(a){if(a==null){throw Gd(new ye)}return a}
function Af(){if(vf==256){uf=wf;wf=new n;vf=0}++vf}
function Ze(a,b){We(a);return new bf(a,new ff(b,a.a))}
function Sg(a){ai((Lh(),Jh),new Fh(a));ni(Kh,new Gh(a))}
function Te(a){if(!a.d){a.d=new Me(a.b);a.c=a.b.a.length}}
function me(a,b){var c;c=ke(a);se(a,c);c.e=b?8:0;return c}
function Vf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function pe(a){if(a.B()){return null}var b=a.j;return Td[b]}
function ib(a){return Array.isArray(a)&&a.T===_d}
function Qb(a){return !Array.isArray(a)&&a.T===_d}
function qi(a,b){return (Ph(),Nh)==a||(Mh==a?!b.a:b.a)}
function Pe(a,b){return Vb(a)===Vb(b)||!!a&&Vb(a)===Vb(b)}
function Se(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function hf(a){Se.call(this,a.G(),a.F()&-6);this.a=a}
function Q(a){K();$wnd.setTimeout(function(){throw a},0)}
function Rh(){Ph();return kb(eb(qd,1),xi,22,0,[Mh,Oh,Nh])}
function eh(){eh=Xd;var a;dh=(a=Yd(bh.prototype.Q,bh,[]),a)}
function ih(){ih=Xd;var a;hh=(a=Yd(gh.prototype.Q,gh,[]),a)}
function mh(){mh=Xd;var a;lh=(a=Yd(kh.prototype.Q,kh,[]),a)}
function qh(){qh=Xd;var a;ph=(a=Yd(oh.prototype.Q,oh,[]),a)}
function _g(){_g=Xd;var a;$g=(a=Yd(Zg.prototype.Q,Zg,[]),a)}
function Zd(a){function b(){}
;b.prototype=a||{};return new b}
function A(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Uf(a){a.placeholder='What needs to be done?';return a}
function Ce(){B.call(this,'Add not supported on this collection')}
function ff(a,b){Se.call(this,b.G(),b.F()&-16449);this.a=a;this.c=b}
function _h(a,b,c){b.d=Qe(c);Fe(b.c,new Vh);Fe(a.b,new hi)}
function fh(a){$wnd.React.Component.call(this,a);new zg(this)}
function ah(a){$wnd.React.Component.call(this,a);this.a=new xg(this)}
function jh(a){$wnd.React.Component.call(this,a);this.a=new Fg(this)}
function nh(a){$wnd.React.Component.call(this,a);this.a=new Rg(this)}
function rh(a){$wnd.React.Component.call(this,a);this.a=new Ug(this)}
function We(a){if(a.b){We(a.b)}else if(a.c){throw Gd(new ue)}}
function P(a){a&&W((U(),T));--H;if(a){if(J!=-1){R(J);J=-1}}}
function Kg(a){mi((Lh(),Kh),a.d.props['a']);Pg(a,a.d.props['a'].d)}
function Oe(a,b){while(a.a<a.c.a.length){b.J((a.b=a.a++,a.c.a[a.b]))}}
function oe(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.t(b))}
function O(a,b,c){var d;d=M();try{return L(a,b,c)}finally{P(d)}}
function Vd(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Jf(a,b,c){!Ae(c,'key')&&!Ae(c,'ref')&&(a[c]=b[c],undefined)}
function oi(a){var b;b=a.b;!!b&&!Zh(a.c,b)&&(a.b=null,Fe(a.a,new ti))}
function ci(a,b){$e(new bf(null,new Ue(a.a)),new ji(b));Fe(a.b,new hi)}
function Wh(a,b){Ee(a.a,new Uh(''+Nd(Jd(Date.now())),b));Fe(a.b,new hi)}
function Uh(a,b){this.c=new Je;this.b=Qe(a);this.d=Qe(b);this.a=false}
function af(a,b){var c;Ve(a);c=new lf;c.a=b;a.a.H(new nf(c));return c.a}
function Ye(a){var b;Ve(a);b=0;while(a.a.I(new mf)){b=Hd(b,1)}return b}
function mb(a){var b,c,d;b=a&Bi;c=a>>22&Bi;d=a<0?Ci:0;return ob(b,c,d)}
function Fe(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.J(c)}}
function He(a,b){var c;c=Ge(a,b,0);if(c==-1){return false}pf(a.a,c);return true}
function gb(a,b,c,d,e,f){var g;g=hb(e,d);e!=10&&kb(eb(a,f),b,c,e,g);return g}
function Ge(a,b,c){for(;c<a.a.length;++c){if(Pe(b,a.a[c])){return c}}return -1}
function N(b){K();return function(){return O(b,this,arguments);var a}}
function G(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Wb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function qf(a,b){return fb(b)!=10&&kb(o(b),b.S,b.__elementTypeId$,fb(b),a),a}
function fb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Hf(a){var b;return Ff($wnd.React.StrictMode,null,null,(b={},b[Hi]=Qe(a),b))}
function W(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Z(b,c)}while(a.b);a.b=c}}
function V(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Z(b,c)}while(a.a);a.a=c}}
function u(){var a;this.a=gb(Zb,xi,27,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function Lb(){Lb=Xd;Hb=ob(Bi,Bi,524287);Ib=ob(0,0,Di);Jb=mb(1);mb(2);Kb=mb(0)}
function Fd(a){var b;if(Rb(a,5)){return a}b=a&&a[zi];if(!b){b=new F(a);bb(b)}return b}
function se(a,b){var c;if(!a){return}b.j=a;var d=pe(b);if(!d){Td[a]=[b];return}d.R=b}
function we(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function Yd(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Gg(a,b){var c;if((Lh(),Kh).b==a.d.props['a']){c=b.target;Pg(a,c.value)}}
function Hg(a,b){27==b.which?(mi((Lh(),Kh),null),Pg(a,a.d.props['a'].d)):13==b.which&&Lg(a)}
function Dh(a,b){Df(a.a,(he(ld),ld.k+(''+(b?b.b:null))));Qe(b);a.a.props['a']=b;return a.a}
function Ff(a,b,c,d){var e;e=Gf($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Qe(d);return e}
function Ef(a){var b;b=Gf($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function ke(a){var b;b=new je;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Id(a){var b;b=a.h;if(b==0){return a.l+a.m*Fi}if(b==Ci){return a.l+a.m*Fi-Ei}return a}
function Jd(a){if(Gi<a&&a<Ei){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Id(Ab(a))}
function Pd(){Qd();var a=Od;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function xe(a,b){var c,d;for(d=new Me(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);$h(b.a,c)}}
function Xh(a){var b;af(Ze(new bf(null,new Ue(a.a)),new fi),(b=new Je,b)).C(new gi(a))}
function Ph(){Ph=Xd;Mh=new Qh('ACTIVE',0);Oh=new Qh('COMPLETED',1);Nh=new Qh('ALL',2)}
function ae(){$wnd.ReactDOM.render(Hf([(new Ih).a]),(ce(),be).getElementById('app'),null)}
function ue(){B.call(this,"Stream already terminated, can't be modified or used")}
function F(a){D();v(this);this.b=a;a!=null&&rf(a,zi,this);this.c=a==null?'null':$d(a);this.a=a}
function Rg(a){this.d=Qe(a);r();++Qg;this.b=this.d.props['a'].d;Th(this.d.props['a'],new vh(this))}
function Yh(a){return Md(Ye(new bf(null,new Ue(a.a))))-Md(Ye(Ze(new bf(null,new Ue(a.a)),new ii)))}
function o(a){return Ub(a)?tc:Tb(a)?kc:Sb(a)?ic:Qb(a)?a.R:ib(a)?a.R:a.R||Array.isArray(a)&&eb(bc,1)||bc}
function Ld(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Ei;d=Ci}c=Wb(e/Fi);b=Wb(e-c*Fi);return ob(b,c,d)}
function Bb(a){var b,c,d;b=~a.l+1&Bi;c=~a.m+(b==0?1:0)&Bi;d=~a.h+(b==0&&c==0?1:0)&Ci;return ob(b,c,d)}
function ub(a){var b,c,d;b=~a.l+1&Bi;c=~a.m+(b==0?1:0)&Bi;d=~a.h+(b==0&&c==0?1:0)&Ci;a.l=b;a.m=c;a.h=d}
function yb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ob(c&Bi,d&Bi,e&Ci)}
function Eb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return ob(c&Bi,d&Bi,e&Ci)}
function kb(a,b,c,d,e){e.R=a;e.S=b;e.T=_d;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function rb(a,b,c,d,e){var f;f=Db(a,b);c&&ub(f);if(e){a=tb(a,b);d?(lb=Bb(a)):(lb=ob(a.l,a.m,a.h))}return f}
function vb(a){var b,c;c=ve(a.h);if(c==32){b=ve(a.m);return b==32?ve(a.l)+32:b+20-10}else{return c-12}}
function zf(a){xf();var b,c,d;c=':'+a;d=wf[c];if(d!=null){return Wb(d)}d=uf[c];b=d==null?yf(a):Wb(d);Af();wf[c]=b;return b}
function Hd(a,b){var c;if(Tb(a)&&Tb(b)){c=a+b;if(Gi<c&&c<Ei){return c}}return Id(yb(Tb(a)?Ld(a):a,Tb(b)?Ld(b):b))}
function Sd(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function je(){this.g=ge++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function pi(a){this.a=new Je;this.c=Qe(a);de((ce(),$wnd.window.window),'hashchange',new ri(this),false);ai(a,new si(this))}
function $d(a){var b;if(Array.isArray(a)&&a.T===_d){return ie(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function qb(a,b){if(a.h==Di&&a.m==0&&a.l==0){b&&(lb=ob(0,0,0));return nb((Lb(),Jb))}b&&(lb=ob(a.l,a.m,a.h));return ob(0,0,0)}
function M(){var a;if(H!=0){a=G();if(a-I>2000){I=a;J=$wnd.setTimeout(S,10)}}if(H++==0){V((U(),T));return true}return false}
function Bg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=Be(a.a);if(c.length>0){Wh((Lh(),Jh),c);a.a='';a.d.forceUpdate()}}}
function re(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ie(a,b){var c,d;d=a.a.length;b.length<d&&(b=qf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Ne(a){var b,c,d;d=1;for(c=new Me(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function Lf(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function ug(){sg();return kb(eb(Nc,1),xi,6,0,[Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg,rg])}
function p(a){return Ub(a)?zf(a):Tb(a)?Wb(a):Sb(a)?a?1231:1237:Qb(a)?a.o():ib(a)?tf(a):!!a&&!!a.hashCode?a.hashCode():tf(a)}
function cb(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Lg(a){if(null!=a.b&&a.b.length!=0){_h((Lh(),Jh),a.d.props['a'],a.b);mi(Kh,null);Pg(a,a.b)}else{$h((Lh(),Jh),a.d.props['a'])}}
function Pb(a,b){if(Ub(a)){return !!Ob[b]}else if(a.S){return !!a.S[b]}else if(Tb(a)){return !!Nb[b]}else if(Sb(a)){return !!Mb[b]}return false}
function Ng(a){var b;b=(Lh(),Kh).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();Pg(a,a.d.props['a'].d)}else a.c&&!b&&(a.c=false)}
function Be(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function tb(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return ob(c,d,e)}
function Cb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return ob(c&Bi,d&Bi,e&Ci)}
function hb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function xb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&Bi;a.m=d&Bi;a.h=e&Ci;return true}
function Cg(a){return If(Ji,Pf(Sf(Tf(Wf(Uf(Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,['new-todo']))),a.a),Yd(sh.prototype.O,sh,[a])),Yd(th.prototype.N,th,[a]))),null)}
function zb(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Rd(b,c,d,e){Qd();var f=Od;$moduleName=c;$moduleBase=d;Ed=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{vi(g)()}catch(a){b(c,a)}}else{vi(g)()}}
function Gf(a,b){var c;c=new $wnd.Object;c.$$typeof=Qe(a);c.type=Qe(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Z(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].U()&&(c=Y(c,g)):g[0].U()}catch(a){a=Fd(a);if(Rb(a,5)){d=a;K();Q(Rb(d,24)?d.s():d)}else throw Gd(a)}}return c}
function Ud(){Td={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function yf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ze(a,c++)}b=b|0;return b}
function ki(a){var b,c,d,e;b=(e=(c=(ce(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),Ae(Li,e)?(Ph(),Mh):Ae(Mi,e)?(Ph(),Oh):(Ph(),Nh));return af(Ze(new bf(null,new Ue(a.c.a)),new ui(b)),(d=new Je,d))}
function ve(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Wd(a,b,c){var d=Td,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Td[b]),Zd(h));_.S=c;!b&&(_.T=_d);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.R=f)}
function Db(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&Di)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?Ci:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?Ci:0;f=d?Bi:0;e=c>>b-44}return ob(e&Bi,f&Bi,g&Ci)}
function qe(a){if(a.A()){var b=a.c;b.B()?(a.k='['+b.j):!b.A()?(a.k='[L'+b.v()+';'):(a.k='['+b.v());a.b=b.u()+'[]';a.i=b.w()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=re('.',[c,re('$',d)]);a.b=re('.',[c,re('.',d)]);a.i=d[d.length-1]}
function If(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Cf(b,Yd(Kf.prototype.L,Kf,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Hi]=c[0],undefined):(d[Hi]=c,undefined));return Ff(a,e,f,d)}
function wb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return we(c)}if(b==0&&d!=0&&c==0){return we(d)+22}if(b!=0&&d==0&&c==0){return we(b)+44}return -1}
function Ab(a){var b,c,d,e,f;if(isNaN(a)){return Lb(),Kb}if(a<-9223372036854775808){return Lb(),Ib}if(a>=9223372036854775807){return Lb(),Hb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=Ei){d=Wb(a/Ei);a-=d*Ei}c=0;if(a>=Fi){c=Wb(a/Fi);a-=c*Fi}b=Wb(a);f=ob(b,c,d);e&&ub(f);return f}
function li(a,b){var c,d,e;b.preventDefault();c=(d=(ce(),$wnd.window.window).location.hash,null==d?'':d.substr(1));if(Ae(Li,c)||Ae(Mi,c)||Ae('',c)){Fe(a.a,new ti)}else{e=$wnd.window.window.location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',be.title,e)}}
function Gb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==Di&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Gb(Bb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=mb(1000000000);c=pb(c,e,true);b=''+Fb(lb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function sb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=vb(b)-vb(a);g=Cb(b,j);i=ob(0,0,0);while(j>=0){h=xb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&ub(i);if(f){if(d){lb=Bb(a);e&&(lb=Eb(lb,(Lb(),Jb)))}else{lb=ob(a.l,a.m,a.h)}}return i}
function sg(){sg=Xd;Yf=new tg(Ii,0);Zf=new tg('checkbox',1);$f=new tg('color',2);_f=new tg('date',3);ag=new tg('datetime',4);bg=new tg('email',5);cg=new tg('file',6);dg=new tg('hidden',7);eg=new tg('image',8);fg=new tg('month',9);gg=new tg(wi,10);hg=new tg('password',11);ig=new tg('radio',12);jg=new tg('range',13);kg=new tg('reset',14);lg=new tg('search',15);mg=new tg('submit',16);ng=new tg('tel',17);og=new tg('text',18);pg=new tg('time',19);qg=new tg('url',20);rg=new tg('week',21)}
function pb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Gd(new ee)}if(a.l==0&&a.m==0&&a.h==0){c&&(lb=ob(0,0,0));return ob(0,0,0)}if(b.h==Di&&b.m==0&&b.l==0){return qb(a,c)}i=false;if(b.h>>19!=0){b=Bb(b);i=true}g=wb(b);f=false;e=false;d=false;if(a.h==Di&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=nb((Lb(),Hb));d=true;i=!i}else{h=Db(a,g);i&&ub(h);c&&(lb=ob(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Bb(a);d=true;i=!i}if(g!=-1){return rb(a,g,i,f,c)}if(zb(a,b)<0){c&&(f?(lb=Bb(a)):(lb=ob(a.l,a.m,a.h)));return ob(0,0,0)}return sb(d?a:ob(a.l,a.m,a.h),b,i,f,e,c)}
function Og(a){var b,c;c=a.d.props['a'];b=c.a;return If('li',Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,[b?'checked':null,(Lh(),Kh).b==a.d.props['a']?'editing':null])),[If('div',Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,['view'])),[If(Ji,Sf(Qf(Vf(Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,['toggle'])),(sg(),Zf)),b),Yd(yh.prototype.N,yh,[a])),null),If('label',Xf(new $wnd.Object,Yd(zh.prototype.P,zh,[a])),[c.d]),If(Ii,Of(Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,['destroy'])),Yd(Ah.prototype.P,Ah,[a])),null)]),If(Ji,Tf(Sf(Rf(Wf(Lf(Mf(new $wnd.Object,Yd(Bh.prototype.J,Bh,[a])),kb(eb(tc,1),xi,2,6,['edit'])),a.b),Yd(Ch.prototype.M,Ch,[a])),Yd(wh.prototype.N,wh,[a])),Yd(xh.prototype.O,xh,[a])),null)])}
var wi='number',xi={3:1,4:1},yi='__noinit__',zi='__java$exception',Ai={3:1,7:1,5:1},Bi=4194303,Ci=1048575,Di=524288,Ei=17592186044416,Fi=4194304,Gi=-17592186044416,Hi='children',Ii='button',Ji='input',Ki={32:1},Li='active',Mi='completed',Ni='selected',Oi='header';var _,Td,Od,Ed=-1;Ud();Wd(1,null,{},n);_.n=function(){return this.R};_.o=Pi;_.hashCode=function(){return this.o()};var Mb,Nb,Ob;Wd(34,1,{},je);_.t=function(a){var b;b=new je;b.e=4;a>1?(b.c=oe(this,a-1)):(b.c=this);return b};_.u=function(){he(this);return this.b};_.v=function(){return ie(this)};_.w=function(){he(this);return this.i};_.A=function(){return (this.e&4)!=0};_.B=function(){return (this.e&1)!=0};_.e=0;_.g=0;var ge=1;var rc=le(1);var jc=le(34);Wd(61,1,{},q);var Yb=le(61);Wd(27,1,{27:1},s);var Zb=le(27);Wd(72,1,{},t);var $b=le(72);Wd(37,1,{37:1},u);var _b=le(37);Wd(5,1,{3:1,5:1});_.q=function(a){return new Error(a)};_.r=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=ie(this.R),c==null?a:a+': '+c);w(this,A(this.q(b)));bb(this)};_.b=yi;_.d=true;var uc=le(5);Wd(25,5,{3:1,5:1});var mc=le(25);Wd(7,25,Ai);var sc=le(7);Wd(35,7,Ai);var oc=le(35);Wd(47,35,Ai);var dc=le(47);Wd(24,47,{24:1,3:1,7:1,5:1},F);_.s=function(){return Vb(this.a)===Vb(C)?null:this.a};var C;var ac=le(24);var bc=le(0);Wd(103,1,{});var cc=le(103);var H=0,I=0,J=-1;Wd(55,103,{},X);var T;var ec=le(55);var $;Wd(116,1,{});var gc=le(116);Wd(48,116,{},db);var fc=le(48);var lb;var Hb,Ib,Jb,Kb;var be;Wd(53,7,Ai,ee);var hc=le(53);Mb={3:1,23:1};var ic=le(113);Wd(114,1,{3:1});var qc=le(114);Nb={3:1,23:1};var kc=le(115);Wd(20,1,{3:1,23:1,20:1});_.o=Pi;_.b=0;var lc=le(20);Wd(50,7,Ai,ue);var nc=le(50);Wd(176,1,{});Wd(52,35,Ai,ye);_.q=function(a){return new TypeError(a)};var pc=le(52);Ob={3:1,43:1,23:1,2:1};var tc=le(2);Wd(180,1,{});Wd(51,7,Ai,Ce);var vc=le(51);Wd(117,1,{100:1});_.C=function(a){xe(this,a)};_.D=function(a){throw Gd(new Ce)};var wc=le(117);Wd(118,117,{100:1,124:1});_.D=function(a){De(this,this.a.length,a);return true};_.o=function(){return Ne(this)};var xc=le(118);Wd(12,118,{3:1,12:1,100:1,124:1},Je);_.D=function(a){return Ee(this,a)};_.C=function(a){Fe(this,a)};var zc=le(12);Wd(17,1,{},Me);_.a=0;_.b=-1;var yc=le(17);Wd(75,1,{});_.H=function(a){Re(this,a)};_.F=function(){return this.d};_.G=function(){return this.e};_.d=0;_.e=0;var Bc=le(75);Wd(38,75,{});var Ac=le(38);Wd(13,1,{},Ue);_.F=function(){return this.a};_.G=function(){Te(this);return this.c};_.H=function(a){Te(this);Oe(this.d,a)};_.I=function(a){Te(this);if(Ke(this.d)){a.J(Le(this.d));return true}return false};_.a=0;_.c=0;var Cc=le(13);Wd(74,1,{});_.c=false;var Lc=le(74);Wd(10,74,{147:1,10:1},bf);var Kc=le(10);Wd(77,38,{},ff);_.I=function(a){this.b=false;while(!this.b&&this.c.I(new gf(this,a)));return this.b};_.b=false;var Ec=le(77);Wd(80,1,{},gf);_.J=function(a){ef(this.a,this.b,a)};var Dc=le(80);Wd(76,38,{},hf);_.I=function(a){return this.a.I(new jf(a))};var Gc=le(76);Wd(79,1,{},jf);_.J=function(a){this.a.J(Dh(new Eh,a))};var Fc=le(79);Wd(78,1,{},lf);_.J=function(a){kf(this,a)};var Hc=le(78);Wd(81,1,{},mf);_.J=function(a){};var Ic=le(81);Wd(82,1,{},nf);_.J=function(a){df(this.a,a)};var Jc=le(82);Wd(178,1,{});Wd(175,1,{});var sf=0;var uf,vf=0,wf;Wd(786,1,{});Wd(807,1,{});Wd(119,1,{});var Mc=le(119);Wd(146,$wnd.Function,{},Kf);_.L=function(a){Jf(this.a,this.b,a)};Wd(6,20,{3:1,23:1,20:1,6:1},tg);var Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg,rg;var Nc=me(6,ug);Wd(122,119,{});var Xc=le(122);Wd(92,122,{});var _c=le(92);Wd(93,92,{},xg);_.o=Pi;var wg=0;var Pc=le(93);Wd(123,119,{});var Wc=le(123);Wd(98,123,{});var $c=le(98);Wd(99,98,{},zg);_.o=Pi;var yg=0;var Oc=le(99);Wd(89,119,{});_.a='';var hd=le(89);Wd(90,89,{});var bd=le(90);Wd(91,90,{},Fg);_.o=Pi;var Eg=0;var Qc=le(91);Wd(121,119,{});_.c=false;var ld=le(121);Wd(95,121,{});var dd=le(95);Wd(96,95,{},Rg);_.o=Pi;var Qg=0;var Rc=le(96);Wd(120,119,{});var pd=le(120);Wd(59,120,{});var fd=le(59);Wd(60,59,{},Ug);_.o=Pi;var Tg=0;var Sc=le(60);Wd(85,1,Ki,Vg);_.p=Ri;var Tc=le(85);Wd(152,$wnd.Function,{},Wg);_.P=function(a){Xh((Lh(),Jh))};Wd(67,1,{},Xg);var Uc=le(67);Wd(94,1,{},Yg);var Vc=le(94);Wd(151,$wnd.Function,{},Zg);_.Q=function(a){return new ah(a)};var $g;Wd(84,$wnd.React.Component,{},ah);Vd(Td[1],_);_.componentDidMount=function(){vg(this.a)};_.render=function(){var a,b,c;return a=(c=(Lh(),b=(ce(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),Ae(Li,c)?(Ph(),Mh):Ae(Mi,c)?(Ph(),Oh):(Ph(),Nh)),If('footer',Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,['footer'])),[(new Yg).a,If('ul',Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,['filters'])),[If('li',null,[If('a',Nf(Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,[(Ph(),Nh)==a?Ni:null])),'#'),['All'])]),If('li',null,[If('a',Nf(Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,[Mh==a?Ni:null])),'#active'),['Active'])]),If('li',null,[If('a',Nf(Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,[Oh==a?Ni:null])),'#completed'),['Completed'])])]),Yh(Jh)>0?If(Ii,Of(Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,['clear-completed'])),Yd(Wg.prototype.P,Wg,[])),['Clear Completed']):null])};_.shouldComponentUpdate=Qi;var Yc=le(84);Wd(162,$wnd.Function,{},bh);_.Q=function(a){return new fh(a)};var dh;Wd(97,$wnd.React.Component,{},fh);Vd(Td[1],_);_.render=function(){var a,b;return a=Md(Ye(new bf(null,new Ue((Lh(),Jh).a)))),b='item'+(a==1?'':'s'),If('span',Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,['todo-count'])),[If('strong',null,[a]),' '+b+' left'])};_.shouldComponentUpdate=Qi;var Zc=le(97);Wd(148,$wnd.Function,{},gh);_.Q=function(a){return new jh(a)};var hh;Wd(73,$wnd.React.Component,{},jh);Vd(Td[1],_);_.render=function(){return Cg(this.a)};_.shouldComponentUpdate=Qi;var ad=le(73);Wd(161,$wnd.Function,{},kh);_.Q=function(a){return new nh(a)};var lh;Wd(88,$wnd.React.Component,{},nh);Vd(Td[1],_);_.componentDidUpdate=function(a){Ng(this.a)};_.render=function(){return Og(this.a)};_.shouldComponentUpdate=Qi;var cd=le(88);Wd(144,$wnd.Function,{},oh);_.Q=function(a){return new rh(a)};var ph;Wd(56,$wnd.React.Component,{},rh);Vd(Td[1],_);_.componentDidMount=function(){Sg(this.a)};_.render=function(){var a,b;return If('div',null,[If('div',null,[If(Oi,Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,[Oi])),[If('h1',null,['todos']),(new uh).a]),0!=Md(Ye(new bf(null,new Ue((Lh(),Jh).a))))?If('section',Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,[Oi])),[If(Ji,Sf(Vf(Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,['toggle-all'])),(sg(),Zf)),Yd(Hh.prototype.N,Hh,[])),null),If('ul',Lf(new $wnd.Object,kb(eb(tc,1),xi,2,6,['todo-list'])),(a=af(Qe(_e(new bf(null,new Ue(ki(Kh))))),(b=new Je,b)),Ie(a,jb(a.a.length))))]):null,0!=Md(Ye(new bf(null,new Ue(Jh.a))))?(new Xg).a:null])])};_.shouldComponentUpdate=Qi;var ed=le(56);Wd(149,$wnd.Function,{},sh);_.O=function(a){Bg(this.a,a)};Wd(150,$wnd.Function,{},th);_.N=function(a){Ag(this.a,a)};Wd(62,1,{},uh);var gd=le(62);Wd(87,1,Ki,vh);_.p=Ri;var jd=le(87);Wd(159,$wnd.Function,{},wh);_.N=function(a){Gg(this.a,a)};Wd(160,$wnd.Function,{},xh);_.O=function(a){Hg(this.a,a)};Wd(153,$wnd.Function,{},yh);_.N=function(a){Mg(this.a)};Wd(155,$wnd.Function,{},zh);_.P=function(a){Kg(this.a)};Wd(156,$wnd.Function,{},Ah);_.P=function(a){Jg(this.a)};Wd(157,$wnd.Function,{},Bh);_.J=function(a){Ig(this.a,a)};Wd(158,$wnd.Function,{},Ch);_.M=function(a){Lg(this.a)};Wd(86,1,{},Eh);var kd=le(86);Wd(57,1,Ki,Fh);_.p=Ri;var md=le(57);Wd(58,1,Ki,Gh);_.p=Ri;var nd=le(58);Wd(145,$wnd.Function,{},Hh);_.N=function(a){var b;b=a.target;ci((Lh(),Jh),b.checked)};Wd(42,1,{},Ih);var od=le(42);var Jh,Kh;Wd(22,20,{3:1,23:1,20:1,22:1},Qh);var Mh,Nh,Oh;var qd=me(22,Rh);Wd(39,1,{39:1},Uh);_.a=false;var yd=le(39);Wd(28,1,{},Vh);_.J=Si;var rd=le(28);Wd(36,1,{36:1},di);var xd=le(36);Wd(65,1,{},fi);_.K=function(a){return a.a};var sd=le(65);Wd(66,1,{},gi);_.J=function(a){$h(this.a,a)};var td=le(66);Wd(21,1,{},hi);_.J=Si;var ud=le(21);Wd(63,1,{},ii);_.K=function(a){return !a.a};var vd=le(63);Wd(64,1,{},ji);_.J=function(a){ei(this.a,a)};_.a=false;var wd=le(64);Wd(68,1,{},pi);var Dd=le(68);Wd(69,1,{},ri);_.handleEvent=function(a){li(this.a,a)};var zd=le(69);Wd(70,1,Ki,si);_.p=function(){oi(this.a)};var Ad=le(70);Wd(26,1,{},ti);_.J=Si;var Bd=le(26);Wd(71,1,{},ui);_.K=function(a){return qi(this.a,a)};var Cd=le(71);var Xb=ne('D');var vi=(K(),N);var gwtOnLoad=gwtOnLoad=Rd;Pd(ae);Sd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();