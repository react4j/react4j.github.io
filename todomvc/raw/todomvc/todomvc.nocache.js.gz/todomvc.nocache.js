function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='A79ACC13B26BF24521CBB10FA9B3BB19',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'A79ACC13B26BF24521CBB10FA9B3BB19';function n(){}
function N(){}
function Ae(){}
function we(){}
function nb(){}
function ub(){}
function ug(){}
function bf(){}
function Cf(){}
function Rf(){}
function Zf(){}
function $f(){}
function Ih(){}
function Lh(){}
function Ph(){}
function Th(){}
function Xh(){}
function _h(){}
function si(){}
function ti(){}
function Hi(){}
function Ti(){}
function Vi(){}
function Wi(){}
function fj(){}
function sb(a){rb()}
function Fj(a){a.p()}
function Yf(a,b){a.a=b}
function Df(a){this.a=a}
function _f(a){this.a=a}
function t(a){this.a=a}
function Hh(a){this.a=a}
function di(a){this.a=a}
function ei(a){this.a=a}
function gi(a){this.a=a}
function hi(a){this.a=a}
function ii(a){this.a=a}
function ji(a){this.a=a}
function ki(a){this.a=a}
function li(a){this.a=a}
function mi(a){this.a=a}
function ni(a){this.a=a}
function qi(a){this.a=a}
function ri(a){this.a=a}
function Ui(a){this.a=a}
function Xi(a){this.a=a}
function dj(a){this.a=a}
function ej(a){this.a=a}
function gj(a){this.a=a}
function nf(a){this.c=a}
function Cj(){M(this.a.a)}
function Aj(a){tf(this,a)}
function Fi(a,b){ef(a.c,b)}
function Oi(a,b){ef(a.b,b)}
function _i(a,b){ef(a.a,b)}
function ng(a,b){mg(a,b)}
function pg(a,b){a.key=b}
function He(){He=we}
function v(){v=we;u=new s}
function V(){V=we;U=new n}
function kb(){kb=we;jb=new nb}
function fe(a){return a.b}
function Dj(a){return false}
function Bj(){return this.b}
function zj(){return eg(this)}
function xh(a,b){return a.d=b}
function vb(a,b){return Qe(a,b)}
function Q(a,b){a.b=b;P(a,b)}
function bg(a,b){a.splice(b,1)}
function df(a,b,c){ag(a.a,b,c)}
function yf(a,b,c){b.M(a.a[c])}
function Vf(a,b,c){b.M(a.a.G(c))}
function tf(a,b){while(a.L(b));}
function Qf(a,b){Yf(a,Pf(a.a,b))}
function Kf(a,b){Ef(a);a.a.K(b)}
function Pf(a,b){a.H(b);return a}
function xg(a,b){a.ref=b;return a}
function Ke(a){Je(a);return a.k}
function Ge(a){T.call(this,a)}
function uh(a){Pi((xi(),vi),a.c)}
function wh(a){Mi((xi(),vi),a.c)}
function ib(){Y!=0&&(Y=0);$=-1}
function ab(){ab=we;!!(rb(),qb)}
function pe(){ne==null&&(ne=[])}
function Vb(a){return a.l|a.m<<22}
function F(a){this.d=a;this.b=100}
function Ve(a,b){this.a=a;this.b=b}
function Uf(a,b){this.a=a;this.b=b}
function Xf(a,b){this.a=a;this.b=b}
function vg(a,b){this.a=a;this.b=b}
function fh(a,b){Ve.call(this,a,b)}
function Ci(a,b){Ve.call(this,a,b)}
function ag(a,b,c){a.splice(b,0,c)}
function Hg(a,b){a.value=b;return a}
function yg(a,b){a.href=b;return a}
function hb(a){$wnd.clearTimeout(a)}
function Jh(){this.a=rg((Nh(),Mh))}
function Kh(){this.a=rg((Rh(),Qh))}
function fi(){this.a=rg((Vh(),Uh))}
function pi(){this.a=rg((Zh(),Yh))}
function ui(){this.a=rg((bi(),ai))}
function Ej(){this.a.b.forceUpdate()}
function Bf(a){this.b=a;this.a=16464}
function lh(){v();++kh;this.a=new N}
function ig(){ig=we;fg=new n;hg=new n}
function Bg(a,b){a.checked=b;return a}
function Cg(a,b){a.onBlur=b;return a}
function zg(a,b){a.onClick=b;return a}
function Ei(a,b){a.a=b;ff(a.c,new Hi)}
function Si(a,b){b.a=a;ff(b.c,new Hi)}
function $i(a,b){a.b=b;ff(a.a,new fj)}
function _e(a,b){return jc(a)===jc(b)}
function Db(a){return Eb(a.l,a.m,a.h)}
function lf(a){return a.a<a.c.a.length}
function jc(a){return a==null?null:a}
function hc(a){return typeof a===ij}
function eg(a){return a.$H||(a.$H=++dg)}
function $e(a,b){return a.charCodeAt(b)}
function Li(a,b){return gf(a.a,b,0)!=-1}
function Eb(a,b,c){return {l:a,m:b,h:c}}
function fc(a,b){return a!=null&&dc(a,b)}
function mg(a,b){for(var c in a){b(c)}}
function Dg(a,b){a.onChange=b;return a}
function Eg(a,b){a.onKeyDown=b;return a}
function og(a,b){a.props['a']=b;return a}
function Ag(a){a.autoFocus=true;return a}
function Je(a){if(a.k!=null){return}Se(a)}
function hh(a){_i((xi(),wi),new Hh(a))}
function K(a){++(v(),v(),u).b;this.a=a}
function T(a){this.d=a;O(this);this.t()}
function Of(a,b){Gf.call(this,a);this.a=b}
function oh(a,b){a.c=b;a.b.forceUpdate()}
function Bh(a,b){a.e=b;a.b.forceUpdate()}
function Mi(a,b){hf(a.a,b);ff(a.b,new Vi)}
function Pi(a,b){Ei(b,!b.a);ff(a.b,new Vi)}
function Ri(){this.a=new kf;this.b=new kf}
function kf(){this.a=xb(Lc,kj,1,0,5,1)}
function B(){this.a=xb(Lc,kj,1,100,5,1)}
function mf(a){a.b=a.a++;return a.c.a[a.b]}
function O(a){a.f&&a.b!==lj&&a.t();return a}
function Ig(a,b){a.onDoubleClick=b;return a}
function Ne(a){var b;b=Me(a);Ue(a,b);return b}
function ic(a){return typeof a==='string'}
function gc(a){return typeof a==='boolean'}
function bb(a,b,c){return a.apply(b,c);var d}
function Ee(a,b,c,d){a.addEventListener(b,c,d)}
function ef(a,b){a.a[a.a.length]=b;return true}
function wf(a,b){while(a.c<a.d){yf(a,b,a.c++)}}
function D(a){while(true){if(!C(a)){break}}}
function Fe(){T.call(this,'divide by zero')}
function xi(){xi=we;vi=new Ri;wi=new bj(vi)}
function rb(){rb=we;var a;!tb();a=new ub;qb=a}
function rh(a){this.b=a;v();++qh;this.a=new N}
function jh(a){this.b=a;v();++ih;this.a=new N}
function Gh(a){this.b=a;v();++Fh;this.a=new N}
function vh(a){$i((xi(),wi),a.c);Bh(a,a.c.d)}
function mh(a,b){var c;c=b.target;oh(a,c.value)}
function Hf(a,b){var c;return Mf(a,(c=new kf,c))}
function of(a,b){return uf(b,a.length),new zf(a,b)}
function pf(a){return new Of(null,of(a,a.length))}
function zb(a){return Array.isArray(a)&&a.X===Ae}
function ec(a){return !Array.isArray(a)&&a.X===Ae}
function A(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function ob(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Pe(a){var b;b=Me(a);b.j=a;b.e=1;return b}
function le(a){if(hc(a)){return a|0}return Vb(a)}
function me(a){if(hc(a)){return ''+a}return Wb(a)}
function Lf(a,b){Ff(a);return new Of(a,new Wf(b,a.a))}
function Jf(a,b){Ff(a);return new Of(a,new Tf(b,a.a))}
function Ef(a){if(!a.b){Ff(a);a.c=true}else{Ef(a.b)}}
function Sf(a,b,c){if(a.a.O(c)){a.b=true;b.M(c)}}
function Ni(a,b,c){b.d=c;ff(b.c,new Hi);ff(a.b,new Vi)}
function Eh(a){Oi((xi(),vi),new qi(a));_i(wi,new ri(a))}
function cj(a,b){return (Bi(),zi)==a||(yi==a?!b.a:b.a)}
function sf(a,b){return jc(a)===jc(b)||!!a&&jc(a)===jc(b)}
function vf(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function zf(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Gf(a){if(!a){this.b=null;new kf}else{this.b=a}}
function Af(a){if(!a.d){a.d=new nf(a.b);a.c=a.b.a.length}}
function Re(a){if(a.D()){return null}var b=a.j;return se[b]}
function Gg(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Oe(a,b){var c;c=Me(a);Ue(a,c);c.e=b?8:0;return c}
function R(a,b){var c;c=Ke(a.V);return b==null?c:c+': '+b}
function M(a){var b;if(a.a>=0){a.a=-2;q((b=(v(),v(),u),b))}}
function lg(){if(gg==256){fg=hg;hg=new n;gg=0}++gg}
function De(){De=we;Ce=$wnd.goog.global.document}
function gb(a){ab();$wnd.setTimeout(function(){throw a},0)}
function Ff(a){if(a.b){Ff(a.b)}else if(a.c){throw fe(new We)}}
function ye(a){function b(){}
;b.prototype=a||{};return new b}
function Fg(a){a.placeholder='What needs to be done?';return a}
function s(){this.f=new I;this.a=new F(this.f);new t(this.a)}
function Gi(a,b){this.c=new kf;this.b=a;this.d=b;this.a=false}
function Wf(a,b){vf.call(this,b.J(),b.I()&-6);this.a=a;this.b=b}
function Sh(a){$wnd.React.Component.call(this,a);this.a=new lh}
function Di(){Bi();return Ab(vb(Rd,1),kj,21,0,[yi,Ai,zi])}
function bi(){bi=we;var a;ai=(a=xe(_h.prototype.U,_h,[]),a)}
function Nh(){Nh=we;var a;Mh=(a=xe(Lh.prototype.U,Lh,[]),a)}
function Rh(){Rh=we;var a;Qh=(a=xe(Ph.prototype.U,Ph,[]),a)}
function Vh(){Vh=we;var a;Uh=(a=xe(Th.prototype.U,Th,[]),a)}
function Zh(){Zh=we;var a;Yh=(a=xe(Xh.prototype.U,Xh,[]),a)}
function Qe(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.v(b))}
function ue(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function tg(a,b,c){!_e(c,'key')&&!_e(c,'ref')&&(a[c]=b[c],undefined)}
function eb(a,b,c){var d;d=cb();try{return bb(a,b,c)}finally{fb(d)}}
function S(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function xf(a,b){if(a.c<a.d){yf(a,b,a.c++);return true}return false}
function Tf(a,b){vf.call(this,b.J(),b.I()&-16449);this.a=a;this.c=b}
function cf(){T.call(this,'Add not supported on this collection')}
function ci(a){$wnd.React.Component.call(this,a);this.a=new Gh(this)}
function Oh(a){$wnd.React.Component.call(this,a);this.a=new jh(this)}
function Wh(a){$wnd.React.Component.call(this,a);this.a=new rh(this)}
function $h(a){$wnd.React.Component.call(this,a);this.a=new Dh(this)}
function aj(a){var b;b=a.b;!!b&&!Li(a.c,b)&&(a.b=null,ff(a.a,new fj))}
function Qi(a,b){Kf(new Of(null,new Bf(a.a)),new Xi(b));ff(a.b,new Vi)}
function Ii(a,b){ef(a.a,new Gi(''+me(ie(Date.now())),b));ff(a.b,new Vi)}
function Mf(a,b){var c;Ef(a);c=new Zf;c.a=b;a.a.K(new _f(c));return c.a}
function If(a){var b;Ef(a);b=0;while(a.a.L(new $f)){b=ge(b,1)}return b}
function H(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=A(a.a[c])}return b}
function Cb(a){var b,c,d;b=a&nj;c=a>>22&nj;d=a<0?oj:0;return Eb(b,c,d)}
function Nf(a,b){var c;c=Hf(a,new Df(new Cf));return jf(c,b.N(c.a.length))}
function sh(a,b){var c;if((xi(),wi).b==a.c){c=b.target;Bh(a,c.value)}}
function rf(a,b){while(a.a<a.c.a.length){b.M((a.b=a.a++,a.c.a[a.b]))}}
function ff(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.M(c)}}
function I(){var a;this.a=xb(oc,kj,28,5,0,1);for(a=0;a<5;a++){this.a[a]=new B}}
function L(){var a;try{v()}finally{a=J.a;!a&&((v(),v(),u).d=true);J=J.a}}
function db(b){ab();return function(){return eb(b,this,arguments);var a}}
function X(){if(Date.now){return Date.now()}return (new Date).getTime()}
function kc(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function fb(a){a&&mb((kb(),jb));--Y;if(a){if($!=-1){hb($);$=-1}}}
function _b(){_b=we;Xb=Eb(nj,nj,524287);Yb=Eb(0,0,pj);Zb=Cb(1);Cb(2);$b=Cb(0)}
function xb(a,b,c,d,e,f){var g;g=yb(e,d);e!=10&&Ab(vb(a,f),b,c,e,g);return g}
function hf(a,b){var c;c=gf(a,b,0);if(c==-1){return false}bg(a.a,c);return true}
function oi(a,b){pg(a.a,(b?b.b:null)+(''+(Je(Ld),Ld.k)));og(a.a,b);return a.a}
function gf(a,b,c){for(;c<a.a.length;++c){if(sf(b,a.a[c])){return c}}return -1}
function cg(a,b){return wb(b)!=10&&Ab(o(b),b.W,b.__elementTypeId$,wb(b),a),a}
function wb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Be(){$wnd.ReactDOM.render((new ui).a,(De(),Ce).getElementById('app'),null)}
function Ji(a){Hf(Jf(new Of(null,new Bf(a.a)),new Ti),new Df(new Cf)).F(new Ui(a))}
function Bi(){Bi=we;yi=new Ci('ACTIVE',0);Ai=new Ci('COMPLETED',1);zi=new Ci('ALL',2)}
function th(a,b){27==b.which?($i((xi(),wi),null),Bh(a,a.c.d)):13==b.which&&yh(a)}
function lb(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=pb(b,c)}while(a.a);a.a=c}}
function mb(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=pb(b,c)}while(a.b);a.b=c}}
function Ye(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function he(a){var b;b=a.h;if(b==0){return a.l+a.m*rj}if(b==oj){return a.l+a.m*rj-qj}return a}
function xe(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Ue(a,b){var c;if(!a){return}b.j=a;var d=Re(b);if(!d){se[a]=[b];return}d.V=b}
function Me(a){var b;b=new Le;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function rg(a){var b;b=qg($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function W(a){V();O(this);this.b=a;P(this,a);this.d=a==null?'null':ze(a);this.a=a}
function We(){T.call(this,"Stream already terminated, can't be modified or used")}
function r(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{D(a.a)}finally{a.c=false}}}}
function oe(){pe();var a=ne;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Ze(a,b){var c,d;for(d=new nf(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Mi(b.a,c)}}
function ke(a){var b,c,d,e;e=a;d=0;if(e<0){e+=qj;d=oj}c=kc(e/rj);b=kc(e-c*rj);return Eb(b,c,d)}
function Rb(a){var b,c,d;b=~a.l+1&nj;c=~a.m+(b==0?1:0)&nj;d=~a.h+(b==0&&c==0?1:0)&oj;return Eb(b,c,d)}
function Kb(a){var b,c,d;b=~a.l+1&nj;c=~a.m+(b==0?1:0)&nj;d=~a.h+(b==0&&c==0?1:0)&oj;a.l=b;a.m=c;a.h=d}
function Ob(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return Eb(c&nj,d&nj,e&oj)}
function Ub(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return Eb(c&nj,d&nj,e&oj)}
function Lb(a){var b,c;c=Xe(a.h);if(c==32){b=Xe(a.m);return b==32?Xe(a.l)+32:b+20-10}else{return c-12}}
function ee(a){var b;if(fc(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new W(a);sb(b)}return b}
function ie(a){if(sj<a&&a<qj){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return he(Qb(a))}
function uf(a,b){if(0>a||a>b){throw fe(new Ge('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function re(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Ab(a,b,c,d,e){e.V=a;e.W=b;e.X=Ae;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Hb(a,b,c,d,e){var f;f=Tb(a,b);c&&Kb(f);if(e){a=Jb(a,b);d?(Bb=Rb(a)):(Bb=Eb(a.l,a.m,a.h))}return f}
function Ki(a){return le(If(new Of(null,new Bf(a.a))))-le(If(Jf(new Of(null,new Bf(a.a)),new Wi)))}
function o(a){return ic(a)?Nc:hc(a)?Ec:gc(a)?Cc:ec(a)?a.V:zb(a)?a.V:a.V||Array.isArray(a)&&vb(uc,1)||uc}
function p(a){return ic(a)?kg(a):hc(a)?kc(a):gc(a)?a?1231:1237:ec(a)?a.o():zb(a)?eg(a):!!a&&!!a.hashCode?a.hashCode():eg(a)}
function ge(a,b){var c;if(hc(a)&&hc(b)){c=a+b;if(sj<c&&c<qj){return c}}return he(Ob(hc(a)?ke(a):a,hc(b)?ke(b):b))}
function kg(a){ig();var b,c,d;c=':'+a;d=hg[c];if(d!=null){return kc(d)}d=fg[c];b=d==null?jg(a):kc(d);lg();hg[c]=b;return b}
function ze(a){var b;if(Array.isArray(a)&&a.X===Ae){return Ke(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function Gb(a,b){if(a.h==pj&&a.m==0&&a.l==0){b&&(Bb=Eb(0,0,0));return Db((_b(),Zb))}b&&(Bb=Eb(a.l,a.m,a.h));return Eb(0,0,0)}
function yh(a){if(null!=a.e&&a.e.length!=0){Ni((xi(),vi),a.c,a.e);$i(wi,null);Bh(a,a.e)}else{Mi((xi(),vi),a.c)}}
function zh(a){var b;b=(xi(),wi).b==a.c;if(!a.f&&b){a.f=true;a.d.focus();a.d.select();Bh(a,a.c.d)}else a.f&&!b&&(a.f=false)}
function Dh(a){this.b=a;this.c=a.props['a'];v();++Ch;this.a=new N;this.e=this.c.d;Fi(this.c,new gi(this))}
function Le(){this.g=Ie++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function bj(a){this.a=new kf;this.c=a;Ee((De(),$wnd.goog.global.window),'hashchange',new dj(this),false);Oi(a,new ej(this))}
function gh(){eh();return Ab(vb(md,1),kj,5,0,[Jg,Kg,Lg,Mg,Ng,Og,Pg,Qg,Rg,Sg,Tg,Ug,Vg,Wg,Xg,Yg,Zg,$g,_g,ah,bh,dh])}
function G(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=w(d);return c}}return null}
function qf(a){var b,c,d;d=1;for(c=new nf(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function jf(a,b){var c,d;d=a.a.length;b.length<d&&(b=cg(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Te(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function nh(a,b){var c;if(13==b.keyCode){b.preventDefault();c=af(a.c);if(c.length>0){Ii((xi(),vi),c);a.c='';a.b.forceUpdate()}}}
function cb(){var a;if(Y!=0){a=X();if(a-Z>2000){Z=a;$=$wnd.setTimeout(ib,10)}}if(Y++==0){lb((kb(),jb));return true}return false}
function dc(a,b){if(ic(a)){return !!cc[b]}else if(a.W){return !!a.W[b]}else if(hc(a)){return !!bc[b]}else if(gc(a)){return !!ac[b]}return false}
function tb(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function wg(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function w(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function af(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Jb(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return Eb(c,d,e)}
function yb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Nb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&nj;a.m=d&nj;a.h=e&oj;return true}
function C(a){var b;if(0==a.c){b=H(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;G(a.d);null.Y();return true}
function ph(a){return sg(uj,Ag(Dg(Eg(Hg(Fg(wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,['new-todo']))),a.c),xe(di.prototype.S,di,[a])),xe(ei.prototype.R,ei,[a]))),null)}
function Pb(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function qe(b,c,d,e){pe();var f=ne;$moduleName=c;$moduleBase=d;de=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{hj(g)()}catch(a){b(c,a)}}else{hj(g)()}}
function qg(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function q(b){var c,d;try{if(J){d=null}else{J=new K(J);b.d=false;try{d=null}finally{L()}}return d}catch(a){a=ee(a);if(fc(a,4)){c=a;throw fe(c)}else throw fe(a)}finally{r(b)}}
function pb(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Y()&&(c=ob(c,g)):g[0].Y()}catch(a){a=ee(a);if(fc(a,4)){d=a;ab();gb(fc(d,25)?d.u():d)}else throw fe(a)}}return c}
function te(){se={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return Eb(c&nj,d&nj,e&oj)}
function Tb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&pj)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?oj:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?oj:0;f=d?nj:0;e=c>>b-44}return Eb(e&nj,f&nj,g&oj)}
function jg(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+$e(a,c++)}b=b|0;return b}
function Yi(a){var b,c,d;b=(d=(c=(De(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1)),_e(vj,d)?(Bi(),yi):_e(wj,d)?(Bi(),Ai):(Bi(),zi));return Hf(Jf(new Of(null,new Bf(a.c.a)),new gj(b)),new Df(new Cf))}
function Xe(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function ve(a,b,c){var d=se,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=se[b]),ye(h));_.W=c;!b&&(_.X=Ae);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.V=f)}
function Se(a){if(a.C()){var b=a.c;b.D()?(a.k='['+b.j):!b.C()?(a.k='[L'+b.A()+';'):(a.k='['+b.A());a.b=b.w()+'[]';a.i=b.B()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Te('.',[c,Te('$',d)]);a.b=Te('.',[c,Te('.',d)]);a.i=d[d.length-1]}
function Mb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return Ye(c)}if(b==0&&d!=0&&c==0){return Ye(d)+22}if(b!=0&&d==0&&c==0){return Ye(b)+44}return -1}
function Qb(a){var b,c,d,e,f;if(isNaN(a)){return _b(),$b}if(a<-9223372036854775808){return _b(),Yb}if(a>=9223372036854775807){return _b(),Xb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=qj){d=kc(a/qj);a-=d*qj}c=0;if(a>=rj){c=kc(a/rj);a-=c*rj}b=kc(a);f=Eb(b,c,d);e&&Kb(f);return f}
function P(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.s();return a&&a.q()}},suppressed:{get:function(){return c.r()}}})}catch(a){}}}
function sg(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ng(b,xe(vg.prototype.P,vg,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=qg($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function Zi(a,b){var c,d,e;b.preventDefault();c=(d=(De(),$wnd.goog.global.window).location.hash,null==d?'':d.substr(1));if(_e(vj,c)||_e(wj,c)||_e('',c)){ff(a.a,new fj)}else{e=$wnd.goog.global.window.location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Ce.title,e)}}
function Wb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==pj&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Wb(Rb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=Cb(1000000000);c=Fb(c,e,true);b=''+Vb(Bb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function Ib(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=Lb(b)-Lb(a);g=Sb(b,j);i=Eb(0,0,0);while(j>=0){h=Nb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&Kb(i);if(f){if(d){Bb=Rb(a);e&&(Bb=Ub(Bb,(_b(),Zb)))}else{Bb=Eb(a.l,a.m,a.h)}}return i}
function eh(){eh=we;Jg=new fh(tj,0);Kg=new fh('checkbox',1);Lg=new fh('color',2);Mg=new fh('date',3);Ng=new fh('datetime',4);Og=new fh('email',5);Pg=new fh('file',6);Qg=new fh('hidden',7);Rg=new fh('image',8);Sg=new fh('month',9);Tg=new fh(ij,10);Ug=new fh('password',11);Vg=new fh('radio',12);Wg=new fh('range',13);Xg=new fh('reset',14);Yg=new fh('search',15);Zg=new fh('submit',16);$g=new fh('tel',17);_g=new fh('text',18);ah=new fh('time',19);bh=new fh('url',20);dh=new fh('week',21)}
function Fb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw fe(new Fe)}if(a.l==0&&a.m==0&&a.h==0){c&&(Bb=Eb(0,0,0));return Eb(0,0,0)}if(b.h==pj&&b.m==0&&b.l==0){return Gb(a,c)}i=false;if(b.h>>19!=0){b=Rb(b);i=!i}g=Mb(b);f=false;e=false;d=false;if(a.h==pj&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=Db((_b(),Xb));d=true;i=!i}else{h=Tb(a,g);i&&Kb(h);c&&(Bb=Eb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Rb(a);d=true;i=!i}if(g!=-1){return Hb(a,g,i,f,c)}if(Pb(a,b)<0){c&&(f?(Bb=Rb(a)):(Bb=Eb(a.l,a.m,a.h)));return Eb(0,0,0)}return Ib(d?a:Eb(a.l,a.m,a.h),b,i,f,e,c)}
function Ah(a){var b,c;c=a.c;b=c.a;return sg('li',wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,[b?'checked':null,(xi(),wi).b==a.c?'editing':null])),[sg('div',wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,['view'])),[sg(uj,Dg(Bg(Gg(wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,['toggle'])),(eh(),Kg)),b),xe(ji.prototype.R,ji,[a])),null),sg('label',Ig(new $wnd.Object,xe(ki.prototype.T,ki,[a])),[c.d]),sg(tj,zg(wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,['destroy'])),xe(li.prototype.T,li,[a])),null)]),sg(uj,Eg(Dg(Cg(Hg(wg(xg(new $wnd.Object,xe(mi.prototype.M,mi,[a])),Ab(vb(Nc,1),kj,2,6,['edit'])),a.e),xe(ni.prototype.Q,ni,[a])),xe(hi.prototype.R,hi,[a])),xe(ii.prototype.S,ii,[a])),null)])}
var ij='number',jj={26:1},kj={3:1},lj='__noinit__',mj={3:1,7:1,4:1},nj=4194303,oj=1048575,pj=524288,qj=17592186044416,rj=4194304,sj=-17592186044416,tj='button',uj='input',vj='active',wj='completed',xj='selected',yj='header';var _,se,ne,de=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;te();ve(1,null,{},n);_.n=function(){return this.V};_.o=zj;_.hashCode=function(){return this.o()};var ac,bc,cc;ve(37,1,{},Le);_.v=function(a){var b;b=new Le;b.e=4;a>1?(b.c=Qe(this,a-1)):(b.c=this);return b};_.w=function(){Je(this);return this.b};_.A=function(){return Ke(this)};_.B=function(){Je(this);return this.i};_.C=function(){return (this.e&4)!=0};_.D=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Ie=1;var Lc=Ne(1);var Dc=Ne(37);ve(54,1,{},s);_.b=1;_.c=false;_.d=true;_.e=0;var nc=Ne(54);ve(55,1,jj,t);_.p=function(){D(this.a)};var mc=Ne(55);var u;ve(28,1,{28:1},B);_.b=0;_.c=false;_.d=0;var oc=Ne(28);ve(67,1,{},F);_.a=0;_.b=0;_.c=0;var pc=Ne(67);ve(66,1,{},I);var qc=Ne(66);ve(94,1,{},K);var J;var rc=Ne(94);ve(19,1,{},N);_.a=0;var sc=Ne(19);ve(4,1,{3:1,4:1});_.q=Bj;_.r=function(){return Nf(Lf(pf((this.e==null&&(this.e=xb(Pc,kj,4,0,0,1)),this.e)),new bf),new Rf)};_.s=function(){return this.c};_.t=function(){Q(this,S(new Error(R(this,this.d))));sb(this)};_.b=lj;_.f=true;var Pc=Ne(4);ve(36,4,{3:1,4:1});var Gc=Ne(36);ve(7,36,mj);var Mc=Ne(7);ve(48,7,mj);var Jc=Ne(48);ve(49,48,mj);var wc=Ne(49);ve(25,49,{25:1,3:1,7:1,4:1},W);_.u=function(){return jc(this.a)===jc(U)?null:this.a};var U;var tc=Ne(25);var uc=Ne(0);ve(113,1,{});var vc=Ne(113);var Y=0,Z=0,$=-1;ve(59,113,{},nb);var jb;var xc=Ne(59);var qb;ve(126,1,{});var zc=Ne(126);ve(50,126,{},ub);var yc=Ne(50);var Bb;var Xb,Yb,Zb,$b;var Ce;ve(57,7,mj,Fe);var Ac=Ne(57);ve(53,7,mj);var Ic=Ne(53);ve(80,53,mj,Ge);var Bc=Ne(80);ac={3:1,24:1};var Cc=Ne(123);ve(124,1,kj);var Kc=Ne(124);bc={3:1,24:1};var Ec=Ne(125);ve(18,1,{3:1,24:1,18:1});_.o=zj;_.b=0;var Fc=Ne(18);ve(52,7,mj,We);var Hc=Ne(52);ve(187,1,{});cc={3:1,44:1,24:1,2:1};var Nc=Ne(2);ve(191,1,{});ve(42,1,{},bf);_.G=function(a){return a.b};var Oc=Ne(42);ve(56,7,mj,cf);var Qc=Ne(56);ve(127,1,{110:1});_.F=function(a){Ze(this,a)};_.H=function(a){throw fe(new cf)};var Rc=Ne(127);ve(128,127,{110:1,134:1});_.H=function(a){df(this,this.a.length,a);return true};_.o=function(){return qf(this)};var Sc=Ne(128);ve(11,128,{3:1,11:1,110:1,134:1},kf);_.H=function(a){return ef(this,a)};_.F=function(a){ff(this,a)};var Uc=Ne(11);ve(16,1,{},nf);_.a=0;_.b=-1;var Tc=Ne(16);ve(69,1,{});_.K=Aj;_.I=function(){return this.d};_.J=function(){return this.e};_.d=0;_.e=0;var Yc=Ne(69);ve(38,69,{});var Vc=Ne(38);ve(60,1,{});_.K=Aj;_.I=Bj;_.J=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Xc=Ne(60);ve(61,60,{},zf);_.K=function(a){wf(this,a)};_.L=function(a){return xf(this,a)};var Wc=Ne(61);ve(12,1,{},Bf);_.I=function(){return this.a};_.J=function(){Af(this);return this.c};_.K=function(a){Af(this);rf(this.d,a)};_.L=function(a){Af(this);if(lf(this.d)){a.M(mf(this.d));return true}return false};_.a=0;_.c=0;var Zc=Ne(12);ve(27,1,{},Cf);_.G=function(a){return a};var $c=Ne(27);ve(30,1,{},Df);var _c=Ne(30);ve(68,1,{});_.c=false;var kd=Ne(68);ve(9,68,{},Of);var jd=Ne(9);ve(43,1,{},Rf);_.N=function(a){return xb(Lc,kj,1,a,5,1)};var ad=Ne(43);ve(71,38,{},Tf);_.L=function(a){this.b=false;while(!this.b&&this.c.L(new Uf(this,a)));return this.b};_.b=false;var cd=Ne(71);ve(74,1,{},Uf);_.M=function(a){Sf(this.a,this.b,a)};var bd=Ne(74);ve(70,38,{},Wf);_.L=function(a){return this.b.L(new Xf(this,a))};var ed=Ne(70);ve(73,1,{},Xf);_.M=function(a){Vf(this.a,this.b,a)};var dd=Ne(73);ve(72,1,{},Zf);_.M=function(a){Yf(this,a)};var fd=Ne(72);ve(75,1,{},$f);_.M=function(a){};var gd=Ne(75);ve(76,1,{},_f);_.M=function(a){Qf(this.a,a)};var hd=Ne(76);ve(189,1,{});ve(186,1,{});var dg=0;var fg,gg=0,hg;ve(800,1,{});ve(823,1,{});ve(81,1,{},ug);_.N=function(a){return new Array(a)};var ld=Ne(81);ve(155,$wnd.Function,{},vg);_.P=function(a){tg(this.a,this.b,a)};ve(5,18,{3:1,24:1,18:1,5:1},fh);var Jg,Kg,Lg,Mg,Ng,Og,Pg,Qg,Rg,Sg,Tg,Ug,Vg,Wg,Xg,Yg,Zg,$g,_g,ah,bh,dh;var md=Oe(5,gh);ve(131,1,{});var wd=Ne(131);ve(103,131,{});var Ad=Ne(103);ve(104,103,{},jh);var ih=0;var od=Ne(104);ve(132,1,{});var vd=Ne(132);ve(133,132,{});var zd=Ne(133);ve(109,133,{},lh);var kh=0;var nd=Ne(109);ve(100,1,{});_.c='';var Id=Ne(100);ve(101,100,{});var Cd=Ne(101);ve(102,101,{},rh);var qh=0;var pd=Ne(102);ve(130,1,{});_.f=false;var Ld=Ne(130);ve(106,130,{});var Ed=Ne(106);ve(107,106,{},Dh);var Ch=0;var qd=Ne(107);ve(129,1,{});var Qd=Ne(129);ve(78,129,{});var Gd=Ne(78);ve(79,78,{},Gh);var Fh=0;var rd=Ne(79);ve(97,1,jj,Hh);_.p=Ej;var sd=Ne(97);ve(160,$wnd.Function,{},Ih);_.T=function(a){Ji((xi(),vi))};ve(88,1,{},Jh);var td=Ne(88);ve(105,1,{},Kh);var ud=Ne(105);ve(159,$wnd.Function,{},Lh);_.U=function(a){return new Oh(a)};var Mh;ve(96,$wnd.React.Component,{},Oh);ue(se[1],_);_.componentDidMount=function(){hh(this.a)};_.componentWillUnmount=Cj;_.render=function(){var a,b,c;return a=(c=(xi(),b=(De(),$wnd.goog.global.window).location.hash,null==b?'':b.substr(1)),_e(vj,c)?(Bi(),yi):_e(wj,c)?(Bi(),Ai):(Bi(),zi)),sg('footer',wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,['footer'])),[(new Kh).a,sg('ul',wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,['filters'])),[sg('li',null,[sg('a',yg(wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,[(Bi(),zi)==a?xj:null])),'#'),['All'])]),sg('li',null,[sg('a',yg(wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,[yi==a?xj:null])),'#active'),['Active'])]),sg('li',null,[sg('a',yg(wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,[Ai==a?xj:null])),'#completed'),['Completed'])])]),Ki(vi)>0?sg(tj,zg(wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,['clear-completed'])),xe(Ih.prototype.T,Ih,[])),['Clear Completed']):null])};_.shouldComponentUpdate=Dj;var xd=Ne(96);ve(170,$wnd.Function,{},Ph);_.U=function(a){return new Sh(a)};var Qh;ve(108,$wnd.React.Component,{},Sh);ue(se[1],_);_.componentWillUnmount=Cj;_.render=function(){var a;return a=le(If(new Of(null,new Bf((xi(),vi).a)))),sg('span',wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,['todo-count'])),[sg('strong',null,[a]),' item'+(a==1?'':'s')+' left'])};_.shouldComponentUpdate=Dj;var yd=Ne(108);ve(158,$wnd.Function,{},Th);_.U=function(a){return new Wh(a)};var Uh;ve(95,$wnd.React.Component,{},Wh);ue(se[1],_);_.componentWillUnmount=Cj;_.render=function(){return ph(this.a)};_.shouldComponentUpdate=Dj;var Bd=Ne(95);ve(161,$wnd.Function,{},Xh);_.U=function(a){return new $h(a)};var Yh;ve(98,$wnd.React.Component,{},$h);ue(se[1],_);_.componentDidUpdate=function(a){zh(this.a)};_.componentWillUnmount=Cj;_.render=function(){return Ah(this.a)};_.shouldComponentUpdate=Dj;var Dd=Ne(98);ve(153,$wnd.Function,{},_h);_.U=function(a){return new ci(a)};var ai;ve(62,$wnd.React.Component,{},ci);ue(se[1],_);_.componentDidMount=function(){Eh(this.a)};_.componentWillUnmount=Cj;_.render=function(){return sg('div',null,[sg('div',null,[sg(yj,wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,[yj])),[sg('h1',null,['todos']),(new fi).a]),0!=le(If(new Of(null,new Bf((xi(),vi).a))))?sg('section',wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,[yj])),[sg(uj,Dg(Gg(wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,['toggle-all'])),(eh(),Kg)),xe(si.prototype.R,si,[])),null),sg('ul',wg(new $wnd.Object,Ab(vb(Nc,1),kj,2,6,['todo-list'])),Nf(Lf(new Of(null,new Bf(Yi(wi))),new ti),new ug))]):null,0!=le(If(new Of(null,new Bf(vi.a))))?(new Jh).a:null])])};_.shouldComponentUpdate=Dj;var Fd=Ne(62);ve(156,$wnd.Function,{},di);_.S=function(a){nh(this.a,a)};ve(157,$wnd.Function,{},ei);_.R=function(a){mh(this.a,a)};ve(82,1,{},fi);var Hd=Ne(82);ve(99,1,jj,gi);_.p=Ej;var Jd=Ne(99);ve(168,$wnd.Function,{},hi);_.R=function(a){sh(this.a,a)};ve(169,$wnd.Function,{},ii);_.S=function(a){th(this.a,a)};ve(162,$wnd.Function,{},ji);_.R=function(a){uh(this.a)};ve(164,$wnd.Function,{},ki);_.T=function(a){vh(this.a)};ve(165,$wnd.Function,{},li);_.T=function(a){wh(this.a)};ve(166,$wnd.Function,{},mi);_.M=function(a){xh(this.a,a)};ve(167,$wnd.Function,{},ni);_.Q=function(a){yh(this.a)};ve(93,1,{},pi);var Kd=Ne(93);ve(63,1,jj,qi);_.p=Ej;var Md=Ne(63);ve(64,1,jj,ri);_.p=Ej;var Nd=Ne(64);ve(154,$wnd.Function,{},si);_.R=function(a){var b;b=a.target;Qi((xi(),vi),b.checked)};ve(65,1,{},ti);_.G=function(a){return oi(new pi,a)};var Od=Ne(65);ve(41,1,{},ui);var Pd=Ne(41);var vi,wi;ve(21,18,{3:1,24:1,18:1,21:1},Ci);var yi,zi,Ai;var Rd=Oe(21,Di);ve(39,1,{39:1},Gi);_.a=false;var Zd=Ne(39);ve(31,1,{},Hi);_.M=Fj;var Sd=Ne(31);ve(83,1,{},Ri);var Yd=Ne(83);ve(86,1,{},Ti);_.O=function(a){return a.a};var Td=Ne(86);ve(87,1,{},Ui);_.M=function(a){Mi(this.a,a)};var Ud=Ne(87);ve(20,1,{},Vi);_.M=Fj;var Vd=Ne(20);ve(84,1,{},Wi);_.O=function(a){return !a.a};var Wd=Ne(84);ve(85,1,{},Xi);_.M=function(a){Si(this.a,a)};_.a=false;var Xd=Ne(85);ve(89,1,{},bj);var ce=Ne(89);ve(90,1,{},dj);_.handleEvent=function(a){Zi(this.a,a)};var $d=Ne(90);ve(91,1,jj,ej);_.p=function(){aj(this.a)};var _d=Ne(91);ve(29,1,{},fj);_.M=Fj;var ae=Ne(29);ve(92,1,{},gj);_.O=function(a){return cj(this.a,a)};var be=Ne(92);var lc=Pe('D');var hj=(ab(),db);var gwtOnLoad=gwtOnLoad=qe;oe(Be);re('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();