function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='BF8C4D7300DBBDD7DD21ADB86C8DBAF0',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'BF8C4D7300DBBDD7DD21ADB86C8DBAF0';function n(){}
function S(){}
function Z(){}
function Hd(){}
function Dd(){}
function Se(){}
function Te(){}
function _f(){}
function ag(){}
function ig(){}
function kg(){}
function og(){}
function vg(){}
function Kg(){}
function Wg(){}
function Yg(){}
function Dh(){}
function Fh(){}
function Gh(){}
function Sh(){}
function X(a){W()}
function pi(a){a()}
function ng(){mg()}
function Nd(){Nd=Dd}
function Re(a,b){a.a=b}
function Ch(a,b){b.a=a}
function Qe(a){this.a=a}
function Ue(a){this.a=a}
function re(a){this.c=a}
function xg(a){this.a=a}
function yg(a){this.a=a}
function zg(a){this.a=a}
function Mg(a){this.a=a}
function Ng(a){this.a=a}
function Og(a){this.a=a}
function Pg(a){this.a=a}
function Qg(a){this.a=a}
function Rg(a){this.a=a}
function Sg(a){this.a=a}
function _g(a){this.a=a}
function Eh(a){this.a=a}
function Hh(a){this.a=a}
function Qh(a){this.a=a}
function Rh(a){this.a=a}
function Th(a){this.a=a}
function eh(){this.a={}}
function eg(){this.a={}}
function cg(){this.a={}}
function $g(){this.a={}}
function gh(){this.a={}}
function Mh(a,b){je(a.a,b)}
function yh(a,b){je(a.b,b)}
function lf(a,b){mf(a.j,b)}
function hf(a,b,c){a[b]=c}
function gf(a,b){return a[b]}
function md(a){return a.b}
function Bg(a,b){return a.g=b}
function fe(a,b){return a===b}
function $(a,b){return Vd(a,b)}
function ni(){return $e(this)}
function de(){q(this);this.q()}
function jg(a){nf.call(this,a)}
function pg(a){nf.call(this,a)}
function wg(a){nf.call(this,a)}
function Lg(a){nf.call(this,a)}
function Xg(a){nf.call(this,a)}
function F(){F=Dd;!!(W(),V)}
function v(){v=Dd;u=new n}
function P(){P=Dd;O=new S}
function N(){B!=0&&(B=0);D=-1}
function wd(){ud==null&&(ud=[])}
function Qd(a){Pd(a);return a.k}
function Je(a,b){a.C(b);return a}
function pf(a,b){a.ref=b;return a}
function mf(a,b){a.state=ve(b)}
function We(a,b){a.splice(b,1)}
function Ve(a,b,c){a.splice(b,0,c)}
function ie(a,b,c){Ve(a.a,b,c)}
function Fe(a,b){Ae(a);a.a.G(b)}
function Ke(a,b){Re(a,Je(a.a,b))}
function we(a,b){while(a.H(b));}
function Ne(a,b){this.a=a;this.b=b}
function $d(a,b){this.a=a;this.b=b}
function Zf(a,b){$d.call(this,a,b)}
function oh(a,b){$d.call(this,a,b)}
function Oe(a,b){a.I(dh(ah(b.b),b))}
function qf(a,b){a.href=b;return a}
function Af(a,b){a.value=b;return a}
function vf(a,b){a.onBlur=b;return a}
function kf(a,b){a.j.setState(b,null)}
function rf(a,b){a.onClick=b;return a}
function tf(a,b){a.checked=b;return a}
function Lh(a,b){a.b=b;ke(a.a,new Sh)}
function ah(a){return bh(new eh,a)}
function eb(a){return new Array(a)}
function Ab(a){return a.l|a.m<<22}
function ib(a){return jb(a.l,a.m,a.h)}
function Ob(a){return typeof a===Vh}
function Qb(a){return a==null?null:a}
function pe(a){return a.a<a.c.a.length}
function $e(a){return a.$H||(a.$H=++Ze)}
function ee(a,b){return a.charCodeAt(b)}
function Mb(a,b){return a!=null&&Kb(a,b)}
function jb(a,b,c){return {l:a,m:b,h:c}}
function vh(a,b){return le(a.a,b,0)!=-1}
function M(a){$wnd.clearTimeout(a)}
function ze(a){this.b=a;this.a=16464}
function t(a){this.c=a;q(this);this.q()}
function oe(){this.a=bb(hc,ei,1,0,5,1)}
function Pd(a){if(a.k!=null){return}Xd(a)}
function r(a,b){a.b=b;b!=null&&Ye(b,Xh,a)}
function wf(a,b){a.onChange=b;return a}
function xf(a,b){a.onKeyDown=b;return a}
function sf(a){a.autoFocus=true;return a}
function uf(a,b){a.defaultValue=b;return a}
function Ie(a,b){Ce.call(this,a);this.a=b}
function wh(a,b){me(a.a,b);ke(a.b,new Fh)}
function zh(a,b){Re(b,!b.a);ke(a.b,new Fh)}
function Bh(){this.a=new oe;this.b=new oe}
function cf(){cf=Dd;_e=new n;bf=new n}
function W(){W=Dd;var a;!Y();a=new Z;V=a}
function jf(a,b){var c;c={};c[a]=b;return c}
function Bf(a,b){a.onDoubleClick=b;return a}
function q(a){a.d&&a.b!==Wh&&a.q();return a}
function qe(a){a.b=a.a++;return a.c.a[a.b]}
function G(a,b,c){return a.apply(b,c);var d}
function Pb(a){return typeof a==='string'}
function Nb(a){return typeof a==='boolean'}
function Md(){t.call(this,'divide by zero')}
function Kd(){Kd=Dd;Jd=$wnd.window.document}
function jh(){jh=Dd;hh=new Bh;ih=new Oh(hh)}
function xh(a,b,c){b.c=ve(c);ke(a.b,new Fh)}
function Td(a){var b;b=Sd(a);Zd(a,b);return b}
function bh(a,b){ve(b);hf(a.a,'key',b);return a}
function T(a,b){!a&&(a=[]);a[a.length]=b;return a}
function je(a,b){a.a[a.a.length]=b;return true}
function Le(a,b,c){if(a.a.J(c)){a.b=true;b.I(c)}}
function Ye(b,c,d){try{b[c]=d}catch(a){}}
function Gg(a){zh((jh(),hh),a.j.props['a'])}
function Ig(a){wh((jh(),hh),gf(a.j.props,'a'))}
function sd(a){if(Ob(a)){return a|0}return Ab(a)}
function td(a){if(Ob(a)){return ''+a}return Bb(a)}
function Ge(a){Be(a);return new Ie(a,new Pe(a.a))}
function Ee(a,b){Be(a);return new Ie(a,new Me(b,a.a))}
function Ae(a){if(!a.b){Be(a);a.c=true}else{Ae(a.b)}}
function ve(a){if(a==null){throw md(new de)}return a}
function ff(){if(af==256){_e=bf;bf=new n;af=0}++af}
function Ce(a){if(!a){this.b=null;new oe}else{this.b=a}}
function Pe(a){xe.call(this,a.F(),a.D()&-6);this.a=a}
function rh(a,b){this.b=ve(a);this.c=ve(b);this.a=false}
function xe(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function zf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Ud(a,b){var c;c=Sd(a);Zd(a,c);c.e=b?8:0;return c}
function Wd(a){if(a.A()){return null}var b=a.j;return zd[b]}
function db(a){return Array.isArray(a)&&a.X===Hd}
function Lb(a){return !Array.isArray(a)&&a.X===Hd}
function Ph(a,b){return (nh(),lh)==a||(kh==a?!b.a:b.a)}
function ue(a,b){return Qb(a)===Qb(b)||!!a&&Qb(a)===Qb(b)}
function ph(){nh();return fb($(Zc,1),ei,21,0,[kh,mh,lh])}
function hg(){gg();this.a=Ed(kg.prototype.U,kg,[])}
function Vg(){Ug();this.a=Ed(Yg.prototype.S,Yg,[])}
function Ug(){Ug=Dd;var a;Tg=(a=Ed(Wg.prototype.O,Wg,[]),a)}
function gg(){gg=Dd;var a;fg=(a=Ed(ig.prototype.O,ig,[]),a)}
function mg(){mg=Dd;var a;lg=(a=Ed(og.prototype.O,og,[]),a)}
function sg(){sg=Dd;var a;rg=(a=Ed(vg.prototype.O,vg,[]),a)}
function Eg(){Eg=Dd;var a;Dg=(a=Ed(Kg.prototype.O,Kg,[]),a)}
function Fd(a){function b(){}
;b.prototype=a||{};return new b}
function s(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function ye(a){if(!a.d){a.d=new re(a.b);a.c=a.b.a.length}}
function Be(a){if(a.b){Be(a.b)}else if(a.c){throw md(new _d)}}
function L(a){F();$wnd.setTimeout(function(){throw a},0)}
function Ld(a,b,c,d){a.addEventListener(b,c,(Nd(),d?true:false))}
function J(a,b,c){var d;d=H();try{return G(a,b,c)}finally{K(d)}}
function Vd(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.s(b))}
function Bd(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function te(a,b){while(a.a<a.c.a.length){b.I((a.b=a.a++,a.c.a[a.b]))}}
function Me(a,b){xe.call(this,b.F(),b.D()&-16449);this.a=a;this.c=b}
function he(){t.call(this,'Add not supported on this collection')}
function yf(a){a.placeholder='What needs to be done?';return a}
function De(a){var b;Ae(a);b=0;while(a.a.H(new Te)){b=nd(b,1)}return b}
function He(a,b){var c;Ae(a);c=new Se;c.a=b;a.a.G(new Ue(c));return c.a}
function Ah(a,b){Fe(new Ie(null,new ze(a.a)),new Hh(b));ke(a.b,new Fh)}
function Nh(a){var b;b=a.b;!!b&&!vh(a.c,b)&&(a.b=null,ke(a.a,new Sh))}
function tg(a,b){var c;c=b.target;kf(a,Ed(xg.prototype.N,xg,[c.value]))}
function hb(a){var b,c,d;b=a&Zh;c=a>>22&Zh;d=a<0?$h:0;return jb(b,c,d)}
function bg(a){return $wnd.React.createElement((gg(),fg),a.a,undefined)}
function dg(a){return $wnd.React.createElement((mg(),lg),a.a,undefined)}
function Zg(a){return $wnd.React.createElement((sg(),rg),a.a,undefined)}
function fh(a){return $wnd.React.createElement((Ug(),Tg),a.a,undefined)}
function Rb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function K(a){a&&R((P(),O));--B;if(a){if(D!=-1){M(D);D=-1}}}
function I(b){F();return function(){return J(b,this,arguments);var a}}
function A(){if(Date.now){return Date.now()}return (new Date).getTime()}
function sh(a,b){je(a.a,new rh(''+td(pd(Date.now())),b));ke(a.b,new Fh)}
function le(a,b,c){for(;c<a.a.length;++c){if(ue(b,a.a[c])){return c}}return -1}
function me(a,b){var c;c=le(a,b,0);if(c==-1){return false}We(a.a,c);return true}
function bb(a,b,c,d,e,f){var g;g=cb(e,d);e!=10&&fb($(a,f),b,c,e,g);return g}
function ke(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.I(c)}}
function Q(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=U(b,c)}while(a.a);a.a=c}}
function R(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=U(b,c)}while(a.b);a.b=c}}
function ld(a){var b;if(Mb(a,5)){return a}b=a&&a[Xh];if(!b){b=new w(a);X(b)}return b}
function Zd(a,b){var c;if(!a){return}b.j=a;var d=Wd(b);if(!d){zd[a]=[b];return}d.V=b}
function Ed(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Sd(a){var b;b=new Rd;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function be(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function th(a){var b;He(Ee(new Ie(null,new ze(a.a)),new Dh),(b=new oe,b)).B(new Eh(a))}
function nh(){nh=Dd;kh=new oh('ACTIVE',0);mh=new oh('COMPLETED',1);lh=new oh('ALL',2)}
function Gb(){Gb=Dd;Cb=jb(Zh,Zh,524287);Db=jb(0,0,_h);Eb=hb(1);hb(2);Fb=hb(0)}
function Xe(a,b){return ab(b)!=10&&fb(o(b),b.W,b.__elementTypeId$,ab(b),a),a}
function ab(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function oi(){$wnd.ReactDOM.render(fh(new gh),(Kd(),Jd).getElementById(di),null)}
function nf(a){$wnd.React.Component.call(this,a);this.a=this.P();this.a.j=ve(this);this.a.L()}
function w(a){v();q(this);this.b=a;a!=null&&Ye(a,Xh,this);this.c=a==null?'null':Gd(a);this.a=a}
function ug(){sg();this.b=Ed(yg.prototype.T,yg,[this]);this.a=Ed(zg.prototype.S,zg,[this])}
function Hg(a){Lh((jh(),ih),gf(a.j.props,'a'));kf(a,Ed(Mg.prototype.N,Mg,[gf(a.j.props,'a').c]))}
function dh(a,b){hf(a.a,(Eg(),'a'),b);return $wnd.React.createElement(Dg,a.a,undefined)}
function pd(a){if(ci<a&&a<ai){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return od(vb(a))}
function od(a){var b;b=a.h;if(b==0){return a.l+a.m*bi}if(b==$h){return a.l+a.m*bi-ai}return a}
function rd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=ai;d=$h}c=Rb(e/bi);b=Rb(e-c*bi);return jb(b,c,d)}
function wb(a){var b,c,d;b=~a.l+1&Zh;c=~a.m+(b==0?1:0)&Zh;d=~a.h+(b==0&&c==0?1:0)&$h;return jb(b,c,d)}
function pb(a){var b,c,d;b=~a.l+1&Zh;c=~a.m+(b==0?1:0)&Zh;d=~a.h+(b==0&&c==0?1:0)&$h;a.l=b;a.m=c;a.h=d}
function tb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return jb(c&Zh,d&Zh,e&$h)}
function zb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return jb(c&Zh,d&Zh,e&$h)}
function ce(a,b){var c,d;for(d=new re(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);wh(b.a,c)}}
function vd(){wd();var a=ud;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function _d(){t.call(this,"Stream already terminated, can't be modified or used")}
function uh(a){return sd(De(new Ie(null,new ze(a.a))))-sd(De(Ee(new Ie(null,new ze(a.a)),new Gh)))}
function o(a){return Pb(a)?jc:Ob(a)?ac:Nb(a)?$b:Lb(a)?a.V:db(a)?a.V:a.V||Array.isArray(a)&&$(Tb,1)||Tb}
function qb(a){var b,c;c=ae(a.h);if(c==32){b=ae(a.m);return b==32?ae(a.l)+32:b+20-10}else{return c-12}}
function mb(a,b,c,d,e){var f;f=yb(a,b);c&&pb(f);if(e){a=ob(a,b);d?(gb=wb(a)):(gb=jb(a.l,a.m,a.h))}return f}
function fb(a,b,c,d,e){e.V=a;e.W=b;e.X=Hd;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function yd(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Ag(a,b){var c;if((jh(),ih).b==a.j.props['a']){c=b.target;kf(a,Ed(Mg.prototype.N,Mg,[c.value]))}}
function nd(a,b){var c;if(Ob(a)&&Ob(b)){c=a+b;if(ci<c&&c<ai){return c}}return od(tb(Ob(a)?rd(a):a,Ob(b)?rd(b):b))}
function Gd(a){var b;if(Array.isArray(a)&&a.X===Hd){return Qd(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function lb(a,b){if(a.h==_h&&a.m==0&&a.l==0){b&&(gb=jb(0,0,0));return ib((Gb(),Eb))}b&&(gb=jb(a.l,a.m,a.h));return jb(0,0,0)}
function ef(a){cf();var b,c,d;c=':'+a;d=bf[c];if(d!=null){return Rb(d)}d=_e[c];b=d==null?df(a):Rb(d);ff();bf[c]=b;return b}
function se(a){var b,c,d;d=1;for(c=new re(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function ne(a,b){var c,d;d=a.a.length;b.length<d&&(b=Xe(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Yd(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Rd(){this.g=Od++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Fg(a,b){27==b.which?(kf(a,Ed(Mg.prototype.N,Mg,[gf(a.j.props,'a').c])),Lh((jh(),ih),null)):13==b.which&&Cg(a)}
function $f(){Yf();return fb($(Ec,1),ei,6,0,[Cf,Df,Ef,Ff,Gf,Hf,If,Jf,Kf,Lf,Mf,Nf,Of,Pf,Qf,Rf,Sf,Tf,Uf,Vf,Wf,Xf])}
function H(){var a;if(B!=0){a=A();if(a-C>2000){C=a;D=$wnd.setTimeout(N,10)}}if(B++==0){Q((P(),O));return true}return false}
function Y(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function p(a){return Pb(a)?ef(a):Ob(a)?Rb(a):Nb(a)?a?1231:1237:Lb(a)?a.o():db(a)?$e(a):!!a&&!!a.hashCode?a.hashCode():$e(a)}
function Oh(a){this.a=new oe;this.c=ve(a);Ld((Kd(),$wnd.window.window),'hashchange',new Qh(this),false);yh(a,Ed(Rh.prototype.Q,Rh,[this]))}
function qg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=ge(a.j.state[ji]);if(c.length>0){sh((jh(),hh),c);kf(a,Ed(xg.prototype.N,xg,['']))}}}
function of(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Kb(a,b){if(Pb(a)){return !!Jb[b]}else if(a.W){return !!a.W[b]}else if(Ob(a)){return !!Ib[b]}else if(Nb(a)){return !!Hb[b]}return false}
function Id(){yh((jh(),hh),Ed(_f.prototype.Q,_f,[]));Mh(ih,Ed(ag.prototype.Q,ag,[]));$wnd.ReactDOM.render(fh(new gh),(Kd(),Jd).getElementById(di),null)}
function ge(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ob(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return jb(c,d,e)}
function xb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return jb(c&Zh,d&Zh,e&$h)}
function cb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function sb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&Zh;a.m=d&Zh;a.h=e&$h;return true}
function Jh(a,b){var c,d;b.preventDefault();c=(d=(Kd(),$wnd.window.window).location.hash,null==d?'':d.substr(1));fe(gi,c)||fe(hi,c)||fe('',c)?ke(a.a,new Sh):Kh()}
function Cg(a){var b;b=a.j.state[li];if(b.length!=0){xh((jh(),hh),a.j.props['a'],b);Lh(ih,null);kf(a,Ed(Mg.prototype.N,Mg,[b]))}else{wh((jh(),hh),a.j.props['a'])}}
function ub(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function xd(b,c,d,e){wd();var f=ud;$moduleName=c;$moduleBase=d;kd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Uh(g)()}catch(a){b(c,a)}}else{Uh(g)()}}
function U(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Y()&&(c=T(c,g)):g[0].Y()}catch(a){a=ld(a);if(Mb(a,5)){d=a;F();L(Mb(d,24)?d.r():d)}else throw md(a)}}return c}
function Ad(){zd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function df(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ee(a,c++)}b=b|0;return b}
function Kh(){var a;if(0==''.length){a=(Kd(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Jd.title,a)}else{(Kd(),$wnd.window.window).location.hash=''}}
function ae(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Cd(a,b,c){var d=zd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=zd[b]),Fd(h));_.W=c;!b&&(_.X=Hd);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.V=f)}
function Jg(){Eg();this.b=Ed(Ng.prototype.T,Ng,[this]);this.e=Ed(Og.prototype.R,Og,[this]);this.f=Ed(Pg.prototype.S,Pg,[this]);this.d=Ed(Qg.prototype.U,Qg,[this]);this.c=Ed(Rg.prototype.U,Rg,[this]);this.a=Ed(Sg.prototype.S,Sg,[this])}
function yb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&_h)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?$h:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?$h:0;f=d?Zh:0;e=c>>b-44}return jb(e&Zh,f&Zh,g&$h)}
function Xd(a){if(a.w()){var b=a.c;b.A()?(a.k='['+b.j):!b.w()?(a.k='[L'+b.u()+';'):(a.k='['+b.u());a.b=b.t()+'[]';a.i=b.v()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Yd('.',[c,Yd('$',d)]);a.b=Yd('.',[c,Yd('.',d)]);a.i=d[d.length-1]}
function Ih(a){var b,c,d,e;b=(e=(c=(Kd(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),fe(gi,e)||fe(hi,e)||fe('',e)?fe(gi,e)?(nh(),kh):fe(hi,e)?(nh(),mh):(nh(),lh):(nh(),lh));return He(Ee(new Ie(null,new ze(a.c.a)),new Th(b)),(d=new oe,d))}
function rb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return be(c)}if(b==0&&d!=0&&c==0){return be(d)+22}if(b!=0&&d==0&&c==0){return be(b)+44}return -1}
function vb(a){var b,c,d,e,f;if(isNaN(a)){return Gb(),Fb}if(a<-9223372036854775808){return Gb(),Db}if(a>=9223372036854775807){return Gb(),Cb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=ai){d=Rb(a/ai);a-=d*ai}c=0;if(a>=bi){c=Rb(a/bi);a-=c*bi}b=Rb(a);f=jb(b,c,d);e&&pb(f);return f}
function Bb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==_h&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Bb(wb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=hb(1000000000);c=kb(c,e,true);b=''+Ab(gb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function nb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=qb(b)-qb(a);g=xb(b,j);i=jb(0,0,0);while(j>=0){h=sb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&pb(i);if(f){if(d){gb=wb(a);e&&(gb=zb(gb,(Gb(),Eb)))}else{gb=jb(a.l,a.m,a.h)}}return i}
function Yf(){Yf=Dd;Cf=new Zf(fi,0);Df=new Zf('checkbox',1);Ef=new Zf('color',2);Ff=new Zf('date',3);Gf=new Zf('datetime',4);Hf=new Zf('email',5);If=new Zf('file',6);Jf=new Zf('hidden',7);Kf=new Zf('image',8);Lf=new Zf('month',9);Mf=new Zf(Vh,10);Nf=new Zf('password',11);Of=new Zf('radio',12);Pf=new Zf('range',13);Qf=new Zf('reset',14);Rf=new Zf('search',15);Sf=new Zf('submit',16);Tf=new Zf('tel',17);Uf=new Zf('text',18);Vf=new Zf('time',19);Wf=new Zf('url',20);Xf=new Zf('week',21)}
function kb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw md(new Md)}if(a.l==0&&a.m==0&&a.h==0){c&&(gb=jb(0,0,0));return jb(0,0,0)}if(b.h==_h&&b.m==0&&b.l==0){return lb(a,c)}i=false;if(b.h>>19!=0){b=wb(b);i=true}g=rb(b);f=false;e=false;d=false;if(a.h==_h&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ib((Gb(),Cb));d=true;i=!i}else{h=yb(a,g);i&&pb(h);c&&(gb=jb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=wb(a);d=true;i=!i}if(g!=-1){return mb(a,g,i,f,c)}if(ub(a,b)<0){c&&(f?(gb=wb(a)):(gb=jb(a.l,a.m,a.h)));return jb(0,0,0)}return nb(d?a:jb(a.l,a.m,a.h),b,i,f,e,c)}
var Vh='number',Wh='__noinit__',Xh='__java$exception',Yh={3:1,7:1,5:1},Zh=4194303,$h=1048575,_h=524288,ai=17592186044416,bi=4194304,ci=-17592186044416,di='todoapp',ei={3:1,4:1},fi='button',gi='active',hi='completed',ii='selected',ji='todoText',ki='input',li='editText',mi='header';var _,zd,ud,kd=-1;Ad();Cd(1,null,{},n);_.n=function(){return this.V};_.o=ni;_.hashCode=function(){return this.o()};var Hb,Ib,Jb;Cd(30,1,{},Rd);_.s=function(a){var b;b=new Rd;b.e=4;a>1?(b.c=Vd(this,a-1)):(b.c=this);return b};_.t=function(){Pd(this);return this.b};_.u=function(){return Qd(this)};_.v=function(){Pd(this);return this.i};_.w=function(){return (this.e&4)!=0};_.A=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Od=1;var hc=Td(1);var _b=Td(30);Cd(5,1,{3:1,5:1});_.p=function(a){return new Error(a)};_.q=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=Qd(this.V),c==null?a:a+': '+c);r(this,s(this.p(b)));X(this)};_.b=Wh;_.d=true;var kc=Td(5);Cd(26,5,{3:1,5:1});var cc=Td(26);Cd(7,26,Yh);var ic=Td(7);Cd(31,7,Yh);var ec=Td(31);Cd(42,31,Yh);var Vb=Td(42);Cd(24,42,{24:1,3:1,7:1,5:1},w);_.r=function(){return Qb(this.a)===Qb(u)?null:this.a};var u;var Sb=Td(24);var Tb=Td(0);Cd(85,1,{});var Ub=Td(85);var B=0,C=0,D=-1;Cd(57,85,{},S);var O;var Wb=Td(57);var V;Cd(98,1,{});var Yb=Td(98);Cd(43,98,{},Z);var Xb=Td(43);var gb;var Cb,Db,Eb,Fb;var Jd;Cd(55,7,Yh,Md);var Zb=Td(55);Hb={3:1,23:1};var $b=Td(95);Cd(96,1,{3:1});var gc=Td(96);Ib={3:1,23:1};var ac=Td(97);Cd(20,1,{3:1,23:1,20:1});_.o=ni;_.b=0;var bc=Td(20);Cd(45,7,Yh,_d);var dc=Td(45);Cd(158,1,{});Cd(54,31,Yh,de);_.p=function(a){return new TypeError(a)};var fc=Td(54);Jb={3:1,38:1,23:1,2:1};var jc=Td(2);Cd(162,1,{});Cd(53,7,Yh,he);var lc=Td(53);Cd(99,1,{82:1});_.B=function(a){ce(this,a)};_.C=function(a){throw md(new he)};var mc=Td(99);Cd(100,99,{82:1,107:1});_.C=function(a){ie(this,this.a.length,a);return true};_.o=function(){return se(this)};var nc=Td(100);Cd(10,100,{3:1,10:1,82:1,107:1},oe);_.C=function(a){return je(this,a)};_.B=function(a){ke(this,a)};var pc=Td(10);Cd(15,1,{},re);_.a=0;_.b=-1;var oc=Td(15);Cd(61,1,{});_.G=function(a){we(this,a)};_.D=function(){return this.d};_.F=function(){return this.e};_.d=0;_.e=0;var rc=Td(61);Cd(34,61,{});var qc=Td(34);Cd(11,1,{},ze);_.D=function(){return this.a};_.F=function(){ye(this);return this.c};_.G=function(a){ye(this);te(this.d,a)};_.H=function(a){ye(this);if(pe(this.d)){a.I(qe(this.d));return true}return false};_.a=0;_.c=0;var sc=Td(11);Cd(60,1,{});_.c=false;var Bc=Td(60);Cd(9,60,{},Ie);var Ac=Td(9);Cd(63,34,{},Me);_.H=function(a){this.b=false;while(!this.b&&this.c.H(new Ne(this,a)));return this.b};_.b=false;var uc=Td(63);Cd(66,1,{},Ne);_.I=function(a){Le(this.a,this.b,a)};var tc=Td(66);Cd(62,34,{},Pe);_.H=function(a){return this.a.H(new Qe(a))};var wc=Td(62);Cd(65,1,{},Qe);_.I=function(a){Oe(this.a,a)};var vc=Td(65);Cd(64,1,{},Se);_.I=function(a){Re(this,a)};var xc=Td(64);Cd(67,1,{},Te);_.I=function(a){};var yc=Td(67);Cd(68,1,{},Ue);_.I=function(a){Ke(this.a,a)};var zc=Td(68);Cd(160,1,{});Cd(157,1,{});var Ze=0;var _e,af=0,bf;Cd(537,1,{});Cd(601,1,{});Cd(101,1,{});_.K=function(a,b){};_.L=function(){};var Cc=Td(101);Cd(19,$wnd.React.Component,{});Bd(zd[1],_);_.render=function(){return this.a.M()};var Dc=Td(19);Cd(6,20,{3:1,23:1,20:1,6:1},Zf);var Cf,Df,Ef,Ff,Gf,Hf,If,Jf,Kf,Lf,Mf,Nf,Of,Pf,Qf,Rf,Sf,Tf,Uf,Vf,Wf,Xf;var Ec=Ud(6,$f);Cd(111,$wnd.Function,{37:1},_f);_.Q=oi;Cd(112,$wnd.Function,{37:1},ag);_.Q=oi;Cd(104,101,{});_.M=function(){var a,b,c;a=(jh(),c=(b=(Kd(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),fe(gi,c)||fe(hi,c)||fe('',c)?fe(gi,c)?(nh(),kh):fe(hi,c)?(nh(),mh):(nh(),lh):(nh(),lh));return $wnd.React.createElement('footer',of(new $wnd.Object,fb($(jc,1),ei,2,6,['footer'])),dg(new eg),$wnd.React.createElement('ul',of(new $wnd.Object,fb($(jc,1),ei,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',qf(of(new $wnd.Object,fb($(jc,1),ei,2,6,[(nh(),lh)==a?ii:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',qf(of(new $wnd.Object,fb($(jc,1),ei,2,6,[kh==a?ii:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',qf(of(new $wnd.Object,fb($(jc,1),ei,2,6,[mh==a?ii:null])),'#completed'),'Completed'))),uh(hh)>0?$wnd.React.createElement(fi,rf(of(new $wnd.Object,fb($(jc,1),ei,2,6,['clear-completed'])),this.a),'Clear Completed'):null)};var Ic=Td(104);Cd(71,1,{},cg);var Fc=Td(71);Cd(106,101,{});_.M=function(){var a,b;b=sd(De(new Ie(null,new ze((jh(),hh).a))));a='item'+(b==1?'':'s');return $wnd.React.createElement('span',of(new $wnd.Object,fb($(jc,1),ei,2,6,['todo-count'])),$wnd.React.createElement('strong',null,b),' '+a+' left')};var Hc=Td(106);Cd(79,1,{},eg);var Gc=Td(79);Cd(74,104,{},hg);var fg;var Mc=Td(74);Cd(133,$wnd.Function,{},ig);_.O=function(a){return new jg(a)};Cd(75,19,{},jg);_.P=function(){return new hg};var Jc=Td(75);Cd(134,$wnd.Function,{},kg);_.U=function(a){th((jh(),hh))};Cd(80,106,{},ng);var lg;var Lc=Td(80);Cd(144,$wnd.Function,{},og);_.O=function(a){return new pg(a)};Cd(81,19,{},pg);_.P=function(){return new ng};var Kc=Td(81);Cd(103,101,{});_.L=function(){lf(this,jf(ji,''))};_.M=function(){return $wnd.React.createElement(ki,sf(wf(xf(Af(yf(of(new $wnd.Object,fb($(jc,1),ei,2,6,['new-todo']))),this.j.state[ji]),this.b),this.a)))};var Uc=Td(103);Cd(72,103,{},ug);var rg;var Oc=Td(72);Cd(130,$wnd.Function,{},vg);_.O=function(a){return new wg(a)};Cd(73,19,{},wg);_.P=function(){return new ug};var Nc=Td(73);Cd(109,$wnd.Function,{},xg);_.N=function(a,b){return sg(),jf(ji,this.a)};Cd(131,$wnd.Function,{},yg);_.T=function(a){qg(this.a,a)};Cd(132,$wnd.Function,{},zg);_.S=function(a){tg(this.a,a)};Cd(105,101,{});_.K=function(a,b){var c;c=(jh(),ih).b==this.j.props['a'];if(!this.i&&c){this.i=true;kf(this,Ed(Mg.prototype.N,Mg,[this.j.props['a'].c]));this.g.focus();this.g.select()}else this.i&&!c&&(this.i=false)};_.L=function(){lf(this,jf(li,gf(this.j.props,'a').c))};_.M=function(){var a,b;b=this.j.props['a'];a=b.a;return $wnd.React.createElement('li',of(new $wnd.Object,fb($(jc,1),ei,2,6,[a?hi:null,(jh(),ih).b==this.j.props['a']?'editing':null])),$wnd.React.createElement('div',of(new $wnd.Object,fb($(jc,1),ei,2,6,['view'])),$wnd.React.createElement(ki,wf(tf(zf(of(new $wnd.Object,fb($(jc,1),ei,2,6,['toggle'])),(Yf(),Df)),a),this.f)),$wnd.React.createElement('label',Bf(new $wnd.Object,this.d),b.c),$wnd.React.createElement(fi,rf(of(new $wnd.Object,fb($(jc,1),ei,2,6,['destroy'])),this.c))),$wnd.React.createElement(ki,xf(wf(vf(uf(of(pf(new $wnd.Object,Ed(_g.prototype.I,_g,[this])),fb($(jc,1),ei,2,6,['edit'])),this.j.state[li]),this.e),this.a),this.b)))};_.i=false;var Wc=Td(105);Cd(77,105,{},Jg);var Dg;var Qc=Td(77);Cd(135,$wnd.Function,{},Kg);_.O=function(a){return new Lg(a)};Cd(78,19,{},Lg);_.P=function(){return new Jg};_.componentDidUpdate=function(a,b){this.a.K(a,b)};var Pc=Td(78);Cd(29,$wnd.Function,{},Mg);_.N=function(a,b){return Eg(),jf(li,this.a)};Cd(136,$wnd.Function,{},Ng);_.T=function(a){Fg(this.a,a)};Cd(137,$wnd.Function,{},Og);_.R=function(a){Cg(this.a)};Cd(138,$wnd.Function,{},Pg);_.S=function(a){Gg(this.a)};Cd(139,$wnd.Function,{},Qg);_.U=function(a){Hg(this.a)};Cd(140,$wnd.Function,{},Rg);_.U=function(a){Ig(this.a)};Cd(141,$wnd.Function,{},Sg);_.S=function(a){Ag(this.a,a)};Cd(102,101,{});_.M=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(mi,of(new $wnd.Object,fb($(jc,1),ei,2,6,[mi])),$wnd.React.createElement('h1',null,'todos'),Zg(new $g)),0!=sd(De(new Ie(null,new ze((jh(),hh).a))))?$wnd.React.createElement('section',of(new $wnd.Object,fb($(jc,1),ei,2,6,[mi])),$wnd.React.createElement(ki,wf(zf(of(new $wnd.Object,fb($(jc,1),ei,2,6,['toggle-all'])),(Yf(),Df)),this.a)),$wnd.React.createElement.apply(null,['ul',of(new $wnd.Object,fb($(jc,1),ei,2,6,['todo-list']))].concat((a=He(Ge(new Ie(null,new ze(Ih(ih)))),(b=new oe,b)),ne(a,eb(a.a.length)))))):null,0!=sd(De(new Ie(null,new ze(hh.a))))?bg(new cg):null))};var Yc=Td(102);Cd(58,102,{},Vg);var Tg;var Sc=Td(58);Cd(128,$wnd.Function,{},Wg);_.O=function(a){return new Xg(a)};Cd(59,19,{},Xg);_.P=function(){return new Vg};var Rc=Td(59);Cd(129,$wnd.Function,{},Yg);_.S=function(a){var b;b=a.target;Ah((jh(),hh),b.checked)};Cd(70,1,{},$g);var Tc=Td(70);Cd(143,$wnd.Function,{},_g);_.I=function(a){Bg(this.a,a)};Cd(76,1,{},eh);var Vc=Td(76);Cd(25,1,{},gh);var Xc=Td(25);var hh,ih;Cd(21,20,{3:1,23:1,20:1,21:1},oh);var kh,lh,mh;var Zc=Ud(21,ph);Cd(33,1,{33:1},rh);_.a=false;var ed=Td(33);Cd(32,1,{32:1},Bh);var dd=Td(32);Cd(48,1,{},Dh);_.J=function(a){return a.a};var $c=Td(48);Cd(49,1,{},Eh);_.I=function(a){wh(this.a,a)};var _c=Td(49);Cd(18,1,{},Fh);_.I=pi;var ad=Td(18);Cd(46,1,{},Gh);_.J=function(a){return !a.a};var bd=Td(46);Cd(47,1,{},Hh);_.I=function(a){Ch(this.a,a)};_.a=false;var cd=Td(47);Cd(50,1,{},Oh);var jd=Td(50);Cd(51,1,{},Qh);_.handleEvent=function(a){Jh(this.a,a)};var fd=Td(51);Cd(117,$wnd.Function,{37:1},Rh);_.Q=function(){Nh(this.a)};Cd(27,1,{},Sh);_.I=pi;var gd=Td(27);Cd(52,1,{},Th);_.J=function(a){return Ph(this.a,a)};var hd=Td(52);var Uh=(F(),I);var gwtOnLoad=gwtOnLoad=xd;vd(Id);yd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();