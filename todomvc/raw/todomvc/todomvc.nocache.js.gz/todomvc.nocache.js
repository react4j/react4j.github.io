function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='E5361835B35C4F0E5D549CC55A938A12',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'E5361835B35C4F0E5D549CC55A938A12';function n(){}
function U(){}
function Od(){}
function Kd(){}
function ab(){}
function ef(){}
function ff(){}
function qg(){}
function rg(){}
function sg(){}
function xg(){}
function yg(){}
function Cg(){}
function Dg(){}
function Kg(){}
function Lg(){}
function Xg(){}
function Yg(){}
function ah(){}
function bh(){}
function vh(){}
function Uh(){}
function Wh(){}
function Xh(){}
function hi(){}
function Fi(){}
function Hi(a){a()}
function Z(a){Y()}
function Ud(){Ud=Kd}
function df(a,b){a.a=b}
function Th(a,b){b.a=a}
function gh(a){this.a=a}
function gf(a){this.a=a}
function cf(a){this.a=a}
function qe(a){this.a=a}
function se(a){this.b=a}
function De(a){this.c=a}
function hh(a){this.a=a}
function kh(a){this.a=a}
function lh(a){this.a=a}
function mh(a){this.a=a}
function nh(a){this.a=a}
function oh(a){this.a=a}
function ph(a){this.a=a}
function qh(a){this.a=a}
function Vh(a){this.a=a}
function Yh(a){this.a=a}
function fi(a){this.a=a}
function gi(a){this.a=a}
function ii(a){this.a=a}
function ug(){this.a={}}
function wg(){this.a={}}
function jh(){this.a={}}
function uh(){this.a={}}
function xh(){this.a={}}
function td(a){return a.e}
function xf(a,b){return a[b]}
function me(a,b){return a===b}
function Rg(a,b){return a.a=b}
function bi(a,b){ue(a.a,b)}
function Ph(a,b){ue(a.b,b)}
function wf(a,b){vf(a,b)}
function te(a,b,c){hf(a.a,b,c)}
function we(a,b){return a.a[b]}
function Ei(){return this.a}
function Di(){return nf(this)}
function ke(){q(this);this.s()}
function Bg(a){yf.call(this,a)}
function Gg(a){yf.call(this,a)}
function Og(a){yf.call(this,a)}
function _g(a){yf.call(this,a)}
function fh(a){yf.call(this,a)}
function H(){H=Kd;!!(Y(),X)}
function w(){w=Kd;v=new n}
function R(){R=Kd;Q=new U}
function P(){D!=0&&(D=0);G=-1}
function Dd(){Bd==null&&(Bd=[])}
function Xd(a){Wd(a);return a.k}
function Xe(a,b){a.F(b);return a}
function Gf(a,b){a.ref=b;return a}
function jf(a,b){a.splice(b,1)}
function hf(a,b,c){a.splice(b,0,c)}
function bb(a,b){return ae(a,b)}
function Cb(a){return a.l|a.m<<22}
function gb(a){return new Array(a)}
function O(a){$wnd.clearTimeout(a)}
function rh(a){return sh(new uh,a)}
function Fh(a,b){fe.call(this,a,b)}
function og(a,b){fe.call(this,a,b)}
function fe(a,b){this.a=a;this.b=b}
function _e(a,b){this.a=a;this.b=b}
function Cf(a,b){this.a=a;this.b=b}
function Df(a,b){this.a=a;this.b=b}
function Le(a){this.b=a;this.a=16464}
function Ie(a,b){while(a.M(b));}
function Ye(a,b){df(a,Xe(a.a,b))}
function Te(a,b){Oe(a);a.a.L(b)}
function af(a,b){a.N(th(rh(b.b),b))}
function Hf(a,b){a.href=b;return a}
function Rf(a,b){a.value=b;return a}
function Mf(a,b){a.onBlur=b;return a}
function If(a,b){a.onClick=b;return a}
function Kf(a,b){a.checked=b;return a}
function Nf(a,b){a.onChange=b;return a}
function oe(a,b){a.a+=''+b;return a}
function ai(a,b){a.b=b;ve(a.a,new hi)}
function kb(a){return lb(a.l,a.m,a.h)}
function Be(a){return a.a<a.c.a.length}
function Tb(a){return a==null?null:a}
function Qb(a){return typeof a===li}
function nf(a){return a.$H||(a.$H=++mf)}
function le(a,b){return a.charCodeAt(b)}
function Ob(a,b){return a!=null&&Mb(a,b)}
function lb(a,b,c){return {l:a,m:b,h:c}}
function Mh(a,b){return xe(a.a,b,0)!=-1}
function vf(a,b){for(var c in a){b(c)}}
function Of(a,b){a.onKeyDown=b;return a}
function Jf(a){a.autoFocus=true;return a}
function Jg(a,b){a.a=b;a.d.forceUpdate()}
function Wg(a,b){a.b=b;a.d.forceUpdate()}
function r(a,b){a.e=b;b!=null&&lf(b,ni,a)}
function Wd(a){if(a.k!=null){return}ce(a)}
function rf(){rf=Kd;of=new n;qf=new n}
function Sh(){this.a=new Ae;this.b=new Ae}
function Ae(){this.a=db(lc,wi,1,0,5,1)}
function u(a){this.f=a;q(this);this.s()}
function We(a,b){Qe.call(this,a);this.a=b}
function Nh(a,b){ye(a.a,b);ve(a.b,new Wh)}
function Qh(a,b){df(b,!b.a);ve(a.b,new Wh)}
function Lf(a,b){a.defaultValue=b;return a}
function Sf(a,b){a.onDoubleClick=b;return a}
function q(a){a.g&&a.e!==mi&&a.s();return a}
function Ce(a){a.b=a.a++;return a.c.a[a.b]}
function I(a,b,c){return a.apply(b,c);var d}
function Sb(a){return typeof a==='string'}
function Pb(a){return typeof a==='boolean'}
function tg(a){return zf((Ag(),zg),a.a,null)}
function vg(a){return zf((Fg(),Eg),a.a,null)}
function ih(a){return zf((Ng(),Mg),a.a,null)}
function wh(a){return zf((eh(),dh),a.a,null)}
function Vg(a){Qh((Ah(),yh),a.d.props['a'])}
function Sg(a){Nh((Ah(),yh),xf(a.d.props,'a'))}
function Td(){u.call(this,'divide by zero')}
function Rd(){Rd=Kd;Qd=$wnd.window.document}
function Ah(){Ah=Kd;yh=new Sh;zh=new di(yh)}
function Y(){Y=Kd;var a;!$();a=new ab;X=a}
function $d(a){var b;b=Zd(a);ee(a,b);return b}
function sh(a,b){He(b);a.a['key']=b;return a}
function V(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ue(a,b){a.a[a.a.length]=b;return true}
function Ze(a,b,c){if(a.a.O(c)){a.b=true;b.N(c)}}
function Oh(a,b,c){b.c=He(c);ve(a.b,new Wh)}
function lf(b,c,d){try{b[c]=d}catch(a){}}
function Hg(a,b){var c;c=b.target;Jg(a,c.value)}
function Ue(a){Pe(a);return new We(a,new bf(a.a))}
function Se(a,b){Pe(a);return new We(a,new $e(b,a.a))}
function zd(a){if(Qb(a)){return a|0}return Cb(a)}
function Ad(a){if(Qb(a)){return ''+a}return Db(a)}
function He(a){if(a==null){throw td(new ke)}return a}
function uf(){if(pf==256){of=qf;qf=new n;pf=0}++pf}
function Oe(a){if(!a.b){Pe(a);a.c=true}else{Oe(a.b)}}
function Qe(a){if(!a){this.b=null;new Ae}else{this.b=a}}
function bf(a){Je.call(this,a.K(),a.J()&-6);this.a=a}
function Ih(a,b){this.b=He(a);this.c=He(b);this.a=false}
function Je(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Qf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function _d(a,b){var c;c=Zd(a);ee(a,c);c.e=b?8:0;return c}
function s(a,b){var c;c=Xd(a.$);return b==null?c:c+': '+b}
function ei(a,b){return (Eh(),Ch)==a||(Bh==a?!b.a:b.a)}
function Ge(a,b){return Tb(a)===Tb(b)||!!a&&Tb(a)===Tb(b)}
function fb(a){return Array.isArray(a)&&a.ab===Od}
function Nb(a){return !Array.isArray(a)&&a.ab===Od}
function Ke(a){if(!a.d){a.d=new De(a.b);a.c=a.b.a.length}}
function be(a){if(a.C()){return null}var b=a.j;return Gd[b]}
function N(a){H();$wnd.setTimeout(function(){throw a},0)}
function th(a,b){a.a['a']=b;return zf(($g(),Zg),a.a,null)}
function ae(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.u(b))}
function Bf(a,b,c){a[c]===undefined&&(a[c]=b[c],undefined)}
function Pe(a){if(a.b){Pe(a.b)}else if(a.c){throw td(new ge)}}
function M(a){a&&T((R(),Q));--D;if(a){if(G!=-1){O(G);G=-1}}}
function Md(a){function b(){}
;b.prototype=a||{};return new b}
function Pf(a){a.placeholder='What needs to be done?';return a}
function t(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Id(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Gh(){Eh();return hb(bb(ed,1),wi,21,0,[Bh,Dh,Ch])}
function eh(){eh=Kd;var a;dh=(a=Ld(bh.prototype.T,bh,[]),a)}
function Ag(){Ag=Kd;var a;zg=(a=Ld(yg.prototype.T,yg,[]),a)}
function Fg(){Fg=Kd;var a;Eg=(a=Ld(Dg.prototype.T,Dg,[]),a)}
function Ng(){Ng=Kd;var a;Mg=(a=Ld(Lg.prototype.T,Lg,[]),a)}
function $g(){$g=Kd;var a;Zg=(a=Ld(Yg.prototype.T,Yg,[]),a)}
function L(a,b,c){var d;d=J();try{return I(a,b,c)}finally{M(d)}}
function Sd(a,b,c,d){a.addEventListener(b,c,(Ud(),d?true:false))}
function Af(a,b,c){!me(c,'key')&&!me(c,'ref')&&(a[c]=b[c],undefined)}
function ci(a){var b;b=a.b;!!b&&!Mh(a.c,b)&&(a.b=null,ve(a.a,new hi))}
function Rh(a,b){Te(new We(null,new Le(a.a)),new Yh(b));ve(a.b,new Wh)}
function Me(a,b){!a.a?(a.a=new qe(a.d)):oe(a.a,a.b);oe(a.a,b);return a}
function Ve(a,b){var c;Oe(a);c=new ef;c.a=b;a.a.L(new gf(c));return c.a}
function Re(a){var b;Oe(a);b=0;while(a.a.M(new ff)){b=ud(b,1)}return b}
function jb(a){var b,c,d;b=a&pi;c=a>>22&pi;d=a<0?qi:0;return lb(b,c,d)}
function Ub(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function $e(a,b){Je.call(this,b.K(),b.J()&-16449);this.a=a;this.c=b}
function re(){u.call(this,'Add not supported on this collection')}
function Ne(){this.b=', ';this.d='[';this.e=']';this.c=this.d+(''+this.e)}
function Fe(a,b){while(a.a<a.c.a.length){b.N((a.b=a.a++,a.c.a[a.b]))}}
function xe(a,b,c){for(;c<a.a.length;++c){if(Ge(b,a.a[c])){return c}}return -1}
function Jh(a,b){ue(a.a,new Ih(''+Ad(wd(Date.now())),b));ve(a.b,new Wh)}
function C(){if(Date.now){return Date.now()}return (new Date).getTime()}
function K(b){H();return function(){return L(b,this,arguments);var a}}
function ye(a,b){var c;c=xe(a,b,0);if(c==-1){return false}jf(a.a,c);return true}
function db(a,b,c,d,e,f){var g;g=eb(e,d);e!=10&&hb(bb(a,f),b,c,e,g);return g}
function ve(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.N(c)}}
function Pg(a,b){var c;if((Ah(),zh).b==a.d.props['a']){c=b.target;Wg(a,c.value)}}
function S(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=W(b,c)}while(a.a);a.a=c}}
function T(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=W(b,c)}while(a.b);a.b=c}}
function sd(a){var b;if(Ob(a,5)){return a}b=a&&a[ni];if(!b){b=new B(a);Z(b)}return b}
function ee(a,b){var c;if(!a){return}b.j=a;var d=be(b);if(!d){Gd[a]=[b];return}d.$=b}
function Zd(a){var b;b=new Yd;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Ld(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Cd(){Dd();var a=Bd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ge(){u.call(this,"Stream already terminated, can't be modified or used")}
function Gi(){$wnd.ReactDOM.render(wh(new xh),(Rd(),Qd).getElementById(vi),null)}
function kf(a,b){return cb(b)!=10&&hb(o(b),b._,b.__elementTypeId$,cb(b),a),a}
function cb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Rb(a){return a!=null&&(typeof a===ki||typeof a==='function')&&!(a.ab===Od)}
function Fd(a,b){typeof window===ki&&typeof window['$gwt']===ki&&(window['$gwt'][a]=b)}
function Ib(){Ib=Kd;Eb=lb(pi,pi,524287);Fb=lb(0,0,ri);Gb=jb(1);jb(2);Hb=jb(0)}
function Eh(){Eh=Kd;Bh=new Fh('ACTIVE',0);Dh=new Fh('COMPLETED',1);Ch=new Fh('ALL',2)}
function Kh(a){var b;Ve(Se(new We(null,new Le(a.a)),new Uh),(b=new Ae,b)).D(new Vh(a))}
function Lh(a){return zd(Re(new We(null,new Le(a.a))))-zd(Re(Se(new We(null,new Le(a.a)),new Xh)))}
function je(a,b){var c,d;for(d=new De(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Nh(b.a,c)}}
function ie(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function vd(a){var b;b=a.h;if(b==0){return a.l+a.m*ti}if(b==qi){return a.l+a.m*ti-si}return a}
function sb(a){var b,c;c=he(a.h);if(c==32){b=he(a.m);return b==32?he(a.l)+32:b+20-10}else{return c-12}}
function yd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=si;d=qi}c=Ub(e/ti);b=Ub(e-c*ti);return lb(b,c,d)}
function yb(a){var b,c,d;b=~a.l+1&pi;c=~a.m+(b==0?1:0)&pi;d=~a.h+(b==0&&c==0?1:0)&qi;return lb(b,c,d)}
function rb(a){var b,c,d;b=~a.l+1&pi;c=~a.m+(b==0?1:0)&pi;d=~a.h+(b==0&&c==0?1:0)&qi;a.l=b;a.m=c;a.h=d}
function vb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return lb(c&pi,d&pi,e&qi)}
function Bb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return lb(c&pi,d&pi,e&qi)}
function Tg(a){ai((Ah(),zh),xf(a.d.props,'a'));a.b=xf(a.d.props,'a').c;a.d.forceUpdate()}
function Qg(a,b){27==b.which?(ai((Ah(),zh),null),a.b=xf(a.d.props,'a').c,a.d.forceUpdate()):13==b.which&&Ug(a)}
function yf(a){$wnd.React.Component.call(this,a);this.a=this.U();this.a.d=He(this);this.a.R()}
function Yd(){this.g=Vd++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function B(a){w();q(this);this.e=a;a!=null&&lf(a,ni,this);this.f=a==null?'null':Nd(a);this.a='';this.b=a;this.a=''}
function wd(a){if(ui<a&&a<si){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return vd(xb(a))}
function Nd(a){var b;if(Array.isArray(a)&&a.ab===Od){return Xd(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function ob(a,b,c,d,e){var f;f=Ab(a,b);c&&rb(f);if(e){a=qb(a,b);d?(ib=yb(a)):(ib=lb(a.l,a.m,a.h))}return f}
function hb(a,b,c,d,e){e.$=a;e._=b;e.ab=Od;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function o(a){return Sb(a)?oc:Qb(a)?ec:Pb(a)?cc:Nb(a)?a.$:fb(a)?a.$:a.$||Array.isArray(a)&&bb(Wb,1)||Wb}
function p(a){return Sb(a)?tf(a):Qb(a)?Ub(a):Pb(a)?a?1231:1237:Nb(a)?a.o():fb(a)?nf(a):!!a&&!!a.hashCode?a.hashCode():nf(a)}
function ud(a,b){var c;if(Qb(a)&&Qb(b)){c=a+b;if(ui<c&&c<si){return c}}return vd(vb(Qb(a)?yd(a):a,Qb(b)?yd(b):b))}
function nb(a,b){if(a.h==ri&&a.m==0&&a.l==0){b&&(ib=lb(0,0,0));return kb((Ib(),Gb))}b&&(ib=lb(a.l,a.m,a.h));return lb(0,0,0)}
function tf(a){rf();var b,c,d;c=':'+a;d=qf[c];if(d!=null){return Ub(d)}d=of[c];b=d==null?sf(a):Ub(d);uf();qf[c]=b;return b}
function Ee(a){var b,c,d;d=1;for(c=new De(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function ze(a,b){var c,d;d=a.a.length;b.length<d&&(b=kf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function de(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ig(a,b){var c;if(13==b.keyCode){b.preventDefault();c=ne(a.a);if(c.length>0){Jh((Ah(),yh),c);a.a='';a.d.forceUpdate()}}}
function J(){var a;if(D!=0){a=C();if(a-F>2000){F=a;G=$wnd.setTimeout(P,10)}}if(D++==0){S((R(),Q));return true}return false}
function $(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function pg(){ng();return hb(bb(Lc,1),wi,6,0,[Tf,Uf,Vf,Wf,Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg])}
function Ug(a){if(null!=a.b&&a.b.length!=0){Oh((Ah(),yh),a.d.props['a'],a.b);ai(zh,null);Wg(a,a.b)}else{Nh((Ah(),yh),a.d.props['a'])}}
function di(a){this.a=new Ae;this.c=He(a);Sd((Rd(),$wnd.window.window),'hashchange',new fi(this),false);Ph(a,Ld(gi.prototype.V,gi,[this]))}
function Ef(a,b,c,d,e){var f;f=new $wnd.Object;f.$$typeof=$wnd.React.Element;f.type=He(a);f.key=b;f.ref=c;f.props=He(d);f._owner=e;return f}
function Ff(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Mb(a,b){if(Sb(a)){return !!Lb[b]}else if(a._){return !!a._[b]}else if(Qb(a)){return !!Kb[b]}else if(Pb(a)){return !!Jb[b]}return false}
function Pd(){Ph((Ah(),yh),Ld(qg.prototype.V,qg,[]));bi(zh,Ld(rg.prototype.V,rg,[]));$wnd.ReactDOM.render(wh(new xh),(Rd(),Qd).getElementById(vi),null)}
function ne(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function qb(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return lb(c,d,e)}
function zb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return lb(c&pi,d&pi,e&qi)}
function eb(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function ub(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&pi;a.m=d&pi;a.h=e&qi;return true}
function $h(a,b){var c,d;b.preventDefault();c=(d=(Rd(),$wnd.window.window).location.hash,null==d?'':d.substr(1));me(yi,c)||me(zi,c)||me('',c)?ve(a.a,new hi):_h()}
function wb(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Ed(b,c,d,e){Dd();var f=Bd;$moduleName=c;$moduleBase=d;rd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ji(g)()}catch(a){b(c,a)}}else{ji(g)()}}
function W(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].bb()&&(c=V(c,g)):g[0].bb()}catch(a){a=sd(a);if(Ob(a,5)){d=a;H();N(Ob(d,24)?d.t():d)}else throw td(a)}}return c}
function Hd(){Gd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function A(a){var b;if(a.c==null){b=Tb(a.b)===Tb(v)?null:a.b;a.d=b==null?'null':Rb(b)?b==null?null:b.name:Sb(b)?'String':Xd(o(b));a.a=a.a+': '+(Rb(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function sf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+le(a,c++)}b=b|0;return b}
function _h(){var a;if(0==''.length){a=(Rd(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Qd.title,a)}else{(Rd(),$wnd.window.window).location.hash=''}}
function he(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Jd(a,b,c){var d=Gd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Gd[b]),Md(h));_._=c;!b&&(_.ab=Od);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.$=f)}
function Ab(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&ri)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?qi:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?qi:0;f=d?pi:0;e=c>>b-44}return lb(e&pi,f&pi,g&qi)}
function ce(a){if(a.B()){var b=a.c;b.C()?(a.k='['+b.j):!b.B()?(a.k='[L'+b.w()+';'):(a.k='['+b.w());a.b=b.v()+'[]';a.i=b.A()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=de('.',[c,de('$',d)]);a.b=de('.',[c,de('.',d)]);a.i=d[d.length-1]}
function Zh(a){var b,c,d,e;b=(e=(c=(Rd(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),me(yi,e)||me(zi,e)||me('',e)?me(yi,e)?(Eh(),Bh):me(zi,e)?(Eh(),Dh):(Eh(),Ch):(Eh(),Ch));return Ve(Se(new We(null,new Le(a.c.a)),new ii(b)),(d=new Ae,d))}
function tb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return ie(c)}if(b==0&&d!=0&&c==0){return ie(d)+22}if(b!=0&&d==0&&c==0){return ie(b)+44}return -1}
function xb(a){var b,c,d,e,f;if(isNaN(a)){return Ib(),Hb}if(a<-9223372036854775808){return Ib(),Fb}if(a>=9223372036854775807){return Ib(),Eb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=si){d=Ub(a/si);a-=d*si}c=0;if(a>=ti){c=Ub(a/ti);a-=c*ti}b=Ub(a);f=lb(b,c,d);e&&rb(f);return f}
function Db(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==ri&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Db(yb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=jb(1000000000);c=mb(c,e,true);b=''+Cb(ib);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function pb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=sb(b)-sb(a);g=zb(b,j);i=lb(0,0,0);while(j>=0){h=ub(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&rb(i);if(f){if(d){ib=yb(a);e&&(ib=Bb(ib,(Ib(),Gb)))}else{ib=lb(a.l,a.m,a.h)}}return i}
function zf(a,b,c){var d,e,f,g,h;d={};f=null;g=null;if(null!=b){f='key' in b?''+b['key']:null;g='ref' in b?b['ref']:null;wf(b,Ld(Cf.prototype.P,Cf,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));h=a;e=h['defaultProps'];null!=e&&wf(e,Ld(Df.prototype.P,Df,[d,e]));return Ef(a,f,g,d,$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current)}
function ng(){ng=Kd;Tf=new og(xi,0);Uf=new og('checkbox',1);Vf=new og('color',2);Wf=new og('date',3);Xf=new og('datetime',4);Yf=new og('email',5);Zf=new og('file',6);$f=new og('hidden',7);_f=new og('image',8);ag=new og('month',9);bg=new og(li,10);cg=new og('password',11);dg=new og('radio',12);eg=new og('range',13);fg=new og('reset',14);gg=new og('search',15);hg=new og('submit',16);ig=new og('tel',17);jg=new og('text',18);kg=new og('time',19);lg=new og('url',20);mg=new og('week',21)}
function mb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw td(new Td)}if(a.l==0&&a.m==0&&a.h==0){c&&(ib=lb(0,0,0));return lb(0,0,0)}if(b.h==ri&&b.m==0&&b.l==0){return nb(a,c)}i=false;if(b.h>>19!=0){b=yb(b);i=true}g=tb(b);f=false;e=false;d=false;if(a.h==ri&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=kb((Ib(),Eb));d=true;i=!i}else{h=Ab(a,g);i&&rb(h);c&&(ib=lb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=yb(a);d=true;i=!i}if(g!=-1){return ob(a,g,i,f,c)}if(wb(a,b)<0){c&&(f?(ib=yb(a)):(ib=lb(a.l,a.m,a.h)));return lb(0,0,0)}return pb(d?a:lb(a.l,a.m,a.h),b,i,f,e,c)}
var ki='object',li='number',mi='__noinit__',ni='__java$exception',oi={3:1,7:1,5:1},pi=4194303,qi=1048575,ri=524288,si=17592186044416,ti=4194304,ui=-17592186044416,vi='todoapp',wi={3:1,4:1},xi='button',yi='active',zi='completed',Ai='selected',Bi='input',Ci='header';var _,Gd,Bd,rd=-1;Hd();Jd(1,null,{},n);_.n=function(){return this.$};_.o=Di;_.p=function(){var a;return Xd(o(this))+'@'+(a=p(this)>>>0,a.toString(16))};_.hashCode=function(){return this.o()};_.toString=function(){return this.p()};var Jb,Kb,Lb;Jd(29,1,{},Yd);_.u=function(a){var b;b=new Yd;b.e=4;a>1?(b.c=ae(this,a-1)):(b.c=this);return b};_.v=function(){Wd(this);return this.b};_.w=function(){return Xd(this)};_.A=function(){Wd(this);return this.i};_.B=function(){return (this.e&4)!=0};_.C=function(){return (this.e&1)!=0};_.p=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Wd(this),this.k)};_.e=0;_.g=0;var Vd=1;var lc=$d(1);var dc=$d(29);Jd(5,1,{3:1,5:1});_.q=function(a){return new Error(a)};_.r=function(){return this.f};_.s=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Xd(this.$),c==null?a:a+': '+c);r(this,t(this.q(b)));Z(this)};_.p=function(){return s(this,this.r())};_.e=mi;_.g=true;var pc=$d(5);Jd(26,5,{3:1,5:1});var gc=$d(26);Jd(7,26,oi);var mc=$d(7);Jd(30,7,oi);var ic=$d(30);Jd(41,30,oi);var Yb=$d(41);Jd(24,41,{24:1,3:1,7:1,5:1},B);_.r=function(){A(this);return this.c};_.t=function(){return Tb(this.b)===Tb(v)?null:this.b};var v;var Vb=$d(24);var Wb=$d(0);Jd(85,1,{});var Xb=$d(85);var D=0,F=0,G=-1;Jd(56,85,{},U);var Q;var Zb=$d(56);var X;Jd(98,1,{});var _b=$d(98);Jd(42,98,{},ab);var $b=$d(42);var ib;var Eb,Fb,Gb,Hb;var Qd;Jd(39,1,{37:1});_.p=Ei;var ac=$d(39);Jd(54,7,oi,Td);var bc=$d(54);Jb={3:1,23:1};var cc=$d(95);Jd(96,1,{3:1});var kc=$d(96);Kb={3:1,23:1};var ec=$d(97);Jd(20,1,{3:1,23:1,20:1});_.o=Di;_.p=function(){return this.a!=null?this.a:''+this.b};_.b=0;var fc=$d(20);Jd(44,7,oi,ge);var hc=$d(44);Jd(159,1,{});Jd(53,30,oi,ke);_.q=function(a){return new TypeError(a)};var jc=$d(53);Lb={3:1,37:1,23:1,2:1};var oc=$d(2);Jd(40,39,{37:1},qe);var nc=$d(40);Jd(163,1,{});Jd(52,7,oi,re);var qc=$d(52);Jd(99,1,{82:1});_.D=function(a){je(this,a)};_.F=function(a){throw td(new re)};_.p=function(){var a,b,c;c=new Ne;for(b=this.G();b.H();){a=b.I();Me(c,a===this?'(this Collection)':a==null?'null':Nd(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var rc=$d(99);Jd(100,99,{82:1,106:1});_.F=function(a){te(this,this.a.length,a);return true};_.o=function(){return Ee(this)};_.G=function(){return new se(this)};var tc=$d(100);Jd(55,1,{},se);_.H=function(){return this.a<this.b.a.length};_.I=function(){return we(this.b,this.a++)};_.a=0;var sc=$d(55);Jd(10,100,{3:1,10:1,82:1,106:1},Ae);_.F=function(a){return ue(this,a)};_.D=function(a){ve(this,a)};_.G=function(){return new De(this)};var vc=$d(10);Jd(15,1,{},De);_.H=function(){return Be(this)};_.I=function(){return Ce(this)};_.a=0;_.b=-1;var uc=$d(15);Jd(60,1,{});_.L=function(a){Ie(this,a)};_.J=function(){return this.d};_.K=function(){return this.e};_.d=0;_.e=0;var xc=$d(60);Jd(33,60,{});var wc=$d(33);Jd(11,1,{},Le);_.J=Ei;_.K=function(){Ke(this);return this.c};_.L=function(a){Ke(this);Fe(this.d,a)};_.M=function(a){Ke(this);if(Be(this.d)){a.N(Ce(this.d));return true}return false};_.a=0;_.c=0;var yc=$d(11);Jd(43,1,{},Ne);_.p=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var zc=$d(43);Jd(59,1,{});_.c=false;var Ic=$d(59);Jd(9,59,{},We);var Hc=$d(9);Jd(62,33,{},$e);_.M=function(a){this.b=false;while(!this.b&&this.c.M(new _e(this,a)));return this.b};_.b=false;var Bc=$d(62);Jd(65,1,{},_e);_.N=function(a){Ze(this.a,this.b,a)};var Ac=$d(65);Jd(61,33,{},bf);_.M=function(a){return this.a.M(new cf(a))};var Dc=$d(61);Jd(64,1,{},cf);_.N=function(a){af(this.a,a)};var Cc=$d(64);Jd(63,1,{},ef);_.N=function(a){df(this,a)};var Ec=$d(63);Jd(66,1,{},ff);_.N=function(a){};var Fc=$d(66);Jd(67,1,{},gf);_.N=function(a){Ye(this.a,a)};var Gc=$d(67);Jd(161,1,{});Jd(158,1,{});var mf=0;var of,pf=0,qf;Jd(538,1,{});Jd(601,1,{});Jd(101,1,{});_.Q=Fi;_.R=Fi;var Jc=$d(101);Jd(19,$wnd.React.Component,{});Id(Gd[1],_);_.render=function(){return this.a.S()};var Kc=$d(19);Jd(125,$wnd.Function,{},Cf);_.P=function(a){Af(this.a,this.b,a)};Jd(126,$wnd.Function,{},Df);_.P=function(a){Bf(this.a,this.b,a)};Jd(6,20,{3:1,23:1,20:1,6:1},og);var Tf,Uf,Vf,Wf,Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg;var Lc=_d(6,pg);Jd(109,$wnd.Function,{36:1},qg);_.V=Gi;Jd(110,$wnd.Function,{36:1},rg);_.V=Gi;Jd(103,101,{});_.S=function(){var a,b,c;a=(Ah(),c=(b=(Rd(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),me(yi,c)||me(zi,c)||me('',c)?me(yi,c)?(Eh(),Bh):me(zi,c)?(Eh(),Dh):(Eh(),Ch):(Eh(),Ch));return zf('footer',Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,['footer'])),[vg(new wg),zf('ul',Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,['filters'])),[zf('li',null,[zf('a',Hf(Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,[(Eh(),Ch)==a?Ai:null])),'#'),['All'])]),zf('li',null,[zf('a',Hf(Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,[Bh==a?Ai:null])),'#active'),['Active'])]),zf('li',null,[zf('a',Hf(Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,[Dh==a?Ai:null])),'#completed'),['Completed'])])]),Lh(yh)>0?zf(xi,If(Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,['clear-completed'])),Ld(sg.prototype.Z,sg,[])),['Clear Completed']):null])};var Pc=$d(103);Jd(135,$wnd.Function,{},sg);_.Z=function(a){Kh((Ah(),yh))};Jd(70,1,{},ug);var Mc=$d(70);Jd(105,101,{});_.S=function(){var a,b;b=zd(Re(new We(null,new Le((Ah(),yh).a))));a='item'+(b==1?'':'s');return zf('span',Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,['todo-count'])),[zf('strong',null,[b]),' '+a+' left'])};var Oc=$d(105);Jd(79,1,{},wg);var Nc=$d(79);Jd(74,103,{},xg);var Tc=$d(74);Jd(134,$wnd.Function,{},yg);_.T=function(a){return new Bg(a)};var zg;Jd(75,19,{},Bg);_.U=function(){return new xg};var Qc=$d(75);Jd(80,105,{},Cg);var Sc=$d(80);Jd(145,$wnd.Function,{},Dg);_.T=function(a){return new Gg(a)};var Eg;Jd(81,19,{},Gg);_.U=function(){return new Cg};var Rc=$d(81);Jd(71,101,{});_.S=function(){return zf(Bi,Jf(Nf(Of(Rf(Pf(Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,['new-todo']))),this.a),Ld(gh.prototype.Y,gh,[this])),Ld(hh.prototype.X,hh,[this]))),null)};_.a='';var _c=$d(71);Jd(72,71,{},Kg);var Vc=$d(72);Jd(131,$wnd.Function,{},Lg);_.T=function(a){return new Og(a)};var Mg;Jd(73,19,{},Og);_.U=function(){return new Kg};var Uc=$d(73);Jd(104,101,{});_.Q=function(){var a;a=(Ah(),zh).b==this.d.props['a'];if(!this.c&&a){this.c=true;this.a.focus();this.a.select();this.b=this.d.props['a'].c;this.d.forceUpdate()}else this.c&&!a&&(this.c=false)};_.R=function(){this.b=xf(this.d.props,'a').c};_.S=function(){var a,b;b=this.d.props['a'];a=b.a;return zf('li',Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,[a?zi:null,(Ah(),zh).b==this.d.props['a']?'editing':null])),[zf('div',Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,['view'])),[zf(Bi,Nf(Kf(Qf(Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,['toggle'])),(ng(),Uf)),a),Ld(mh.prototype.X,mh,[this])),null),zf('label',Sf(new $wnd.Object,Ld(nh.prototype.Z,nh,[this])),[b.c]),zf(xi,If(Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,['destroy'])),Ld(oh.prototype.Z,oh,[this])),null)]),zf(Bi,Of(Nf(Mf(Lf(Ff(Gf(new $wnd.Object,Ld(ph.prototype.N,ph,[this])),hb(bb(oc,1),wi,2,6,['edit'])),this.b),Ld(qh.prototype.W,qh,[this])),Ld(kh.prototype.X,kh,[this])),Ld(lh.prototype.Y,lh,[this])),null)])};_.c=false;var bd=$d(104);Jd(77,104,{},Xg);var Xc=$d(77);Jd(136,$wnd.Function,{},Yg);_.T=function(a){return new _g(a)};var Zg;Jd(78,19,{},_g);_.U=function(){return new Xg};_.componentDidUpdate=function(a){this.a.Q()};var Wc=$d(78);Jd(102,101,{});_.S=function(){var a,b;return zf('div',null,[zf('div',null,[zf(Ci,Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,[Ci])),[zf('h1',null,['todos']),ih(new jh)]),0!=zd(Re(new We(null,new Le((Ah(),yh).a))))?zf('section',Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,[Ci])),[zf(Bi,Nf(Qf(Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,['toggle-all'])),(ng(),Uf)),Ld(vh.prototype.X,vh,[])),null),zf('ul',Ff(new $wnd.Object,hb(bb(oc,1),wi,2,6,['todo-list'])),(a=Ve(Ue(new We(null,new Le(Zh(zh)))),(b=new Ae,b)),ze(a,gb(a.a.length))))]):null,0!=zd(Re(new We(null,new Le(yh.a))))?tg(new ug):null])])};var dd=$d(102);Jd(57,102,{},ah);var Zc=$d(57);Jd(129,$wnd.Function,{},bh);_.T=function(a){return new fh(a)};var dh;Jd(58,19,{},fh);_.U=function(){return new ah};var Yc=$d(58);Jd(132,$wnd.Function,{},gh);_.Y=function(a){Ig(this.a,a)};Jd(133,$wnd.Function,{},hh);_.X=function(a){Hg(this.a,a)};Jd(69,1,{},jh);var $c=$d(69);Jd(143,$wnd.Function,{},kh);_.X=function(a){Pg(this.a,a)};Jd(144,$wnd.Function,{},lh);_.Y=function(a){Qg(this.a,a)};Jd(137,$wnd.Function,{},mh);_.X=function(a){Vg(this.a)};Jd(139,$wnd.Function,{},nh);_.Z=function(a){Tg(this.a)};Jd(140,$wnd.Function,{},oh);_.Z=function(a){Sg(this.a)};Jd(141,$wnd.Function,{},ph);_.N=function(a){Rg(this.a,a)};Jd(142,$wnd.Function,{},qh);_.W=function(a){Ug(this.a)};Jd(76,1,{},uh);var ad=$d(76);Jd(130,$wnd.Function,{},vh);_.X=function(a){var b;b=a.target;Rh((Ah(),yh),b.checked)};Jd(25,1,{},xh);var cd=$d(25);var yh,zh;Jd(21,20,{3:1,23:1,20:1,21:1},Fh);var Bh,Ch,Dh;var ed=_d(21,Gh);Jd(32,1,{32:1},Ih);_.a=false;var md=$d(32);Jd(31,1,{31:1},Sh);var ld=$d(31);Jd(47,1,{},Uh);_.O=function(a){return a.a};var fd=$d(47);Jd(48,1,{},Vh);_.N=function(a){Nh(this.a,a)};var gd=$d(48);Jd(18,1,{},Wh);_.N=Hi;var hd=$d(18);Jd(45,1,{},Xh);_.O=function(a){return !a.a};var jd=$d(45);Jd(46,1,{},Yh);_.N=function(a){Th(this.a,a)};_.a=false;var kd=$d(46);Jd(49,1,{},di);var qd=$d(49);Jd(50,1,{},fi);_.handleEvent=function(a){$h(this.a,a)};var nd=$d(50);Jd(115,$wnd.Function,{36:1},gi);_.V=function(){ci(this.a)};Jd(27,1,{},hi);_.N=Hi;var od=$d(27);Jd(51,1,{},ii);_.O=function(a){return ei(this.a,a)};var pd=$d(51);var ji=(H(),K);var gwtOnLoad=gwtOnLoad=Ed;Cd(Pd);Fd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();