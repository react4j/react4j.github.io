function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='6BAC54C1A9C63BBB02B2E1C73D510A9D',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '6BAC54C1A9C63BBB02B2E1C73D510A9D';function n(){}
function s(){}
function Y(){}
function he(){}
function de(){}
function Ke(){}
function eb(){}
function jf(){}
function yf(){}
function Gf(){}
function Hf(){}
function cg(){}
function qh(){}
function th(){}
function xh(){}
function Bh(){}
function Fh(){}
function Jh(){}
function ai(){}
function bi(){}
function pi(){}
function Bi(){}
function Di(){}
function Ei(){}
function Pi(){}
function q(){new t}
function oe(){oe=de}
function cb(a){bb()}
function nj(a){a.p()}
function Ff(a,b){a.a=b}
function kf(a){this.a=a}
function If(a){this.a=a}
function ph(a){this.a=a}
function Nh(a){this.a=a}
function Oh(a){this.a=a}
function Qh(a){this.a=a}
function Rh(a){this.a=a}
function Sh(a){this.a=a}
function Th(a){this.a=a}
function Uh(a){this.a=a}
function Vh(a){this.a=a}
function Wh(a){this.a=a}
function Xh(a){this.a=a}
function $h(a){this.a=a}
function _h(a){this.a=a}
function Ci(a){this.a=a}
function Fi(a){this.a=a}
function Ni(a){this.a=a}
function Oi(a){this.a=a}
function Qi(a){this.a=a}
function Ve(a){this.c=a}
function jj(a){_e(this,a)}
function Od(a){return a.b}
function lj(a){return false}
function kj(){return this.b}
function r(){r=de;new q}
function F(){F=de;D=new n}
function V(){V=de;U=new Y}
function L(){L=de;!!(bb(),ab)}
function w(a,b){a.b=b;v(a,b)}
function Wf(a,b){Vf(a,b)}
function ni(a,b){Ne(a.c,b)}
function wi(a,b){Ne(a.b,b)}
function Ji(a,b){Ne(a.a,b)}
function Me(a,b,c){Jf(a.a,b,c)}
function ef(a,b,c){b.M(a.a[c])}
function Xf(a,b){a.key=b}
function Kf(a,b){a.splice(b,1)}
function fb(a,b){return xe(a,b)}
function fh(a,b){return a.a=b}
function re(a){qe(a);return a.k}
function wf(a,b){a.H(b);return a}
function rf(a,b){lf(a);a.a.K(b)}
function xf(a,b){Ff(a,wf(a.a,b))}
function _e(a,b){while(a.L(b));}
function Cf(a,b,c){b.M(a.a.G(c))}
function ne(a){C.call(this,a)}
function ij(){return Nf(this)}
function Fb(a){return a.l|a.m<<22}
function Sg(a){this.d=a;r();++Rg}
function Ug(a){this.d=a;r();++Tg}
function $g(a){this.d=a;r();++Zg}
function oh(a){this.d=a;r();++nh}
function Ce(a,b){this.a=a;this.b=b}
function Bf(a,b){this.a=a;this.b=b}
function Ef(a,b){this.a=a;this.b=b}
function dg(a,b){this.a=a;this.b=b}
function Og(a,b){Ce.call(this,a,b)}
function Jf(a,b,c){a.splice(b,0,c)}
function fg(a,b){a.ref=b;return a}
function gg(a,b){a.href=b;return a}
function ki(a,b){Ce.call(this,a,b)}
function pg(a,b){a.value=b;return a}
function S(a){$wnd.clearTimeout(a)}
function Yd(){Wd==null&&(Wd=[])}
function T(){I!=0&&(I=0);K=-1}
function ci(){this.a=Yf((Lh(),Kh))}
function rh(){this.a=Yf((vh(),uh))}
function sh(){this.a=Yf((zh(),yh))}
function Ph(){this.a=Yf((Dh(),Ch))}
function Zh(){this.a=Yf((Hh(),Gh))}
function mj(){this.a.d.forceUpdate()}
function hf(a){this.b=a;this.a=16464}
function Tb(a){return typeof a===Si}
function Vb(a){return a==null?null:a}
function nb(a){return ob(a.l,a.m,a.h)}
function Te(a){return a.a<a.c.a.length}
function Ie(a,b){return Vb(a)===Vb(b)}
function Vf(a,b){for(var c in a){b(c)}}
function kg(a,b){a.onBlur=b;return a}
function hg(a,b){a.onClick=b;return a}
function lg(a,b){a.onChange=b;return a}
function jg(a,b){a.checked=b;return a}
function mi(a,b){a.a=b;Oe(a.c,new pi)}
function Ai(a,b){b.a=a;Oe(b.c,new pi)}
function Ii(a,b){a.b=b;Oe(a.a,new Pi)}
function ti(a,b){return Pe(a.a,b,0)!=-1}
function ob(a,b,c){return {l:a,m:b,h:c}}
function He(a,b){return a.charCodeAt(b)}
function Rb(a,b){return a!=null&&Pb(a,b)}
function Nf(a){return a.$H||(a.$H=++Mf)}
function Ub(a){return typeof a==='string'}
function mg(a,b){a.onKeyDown=b;return a}
function ig(a){a.autoFocus=true;return a}
function Yg(a,b){a.a=b;a.d.forceUpdate()}
function jh(a,b){a.b=b;a.d.forceUpdate()}
function ui(a,b){Qe(a.a,b);Oe(a.b,new Di)}
function xi(a,b){mi(b,!b.a);Oe(a.b,new Di)}
function Qg(a){Ji((fi(),ei),new ph(a))}
function qe(a){if(a.k!=null){return}ze(a)}
function Ue(a){a.b=a.a++;return a.c.a[a.b]}
function u(a){a.f&&a.b!==Ui&&a.t();return a}
function qg(a,b){a.onDoubleClick=b;return a}
function vf(a,b){nf.call(this,a);this.a=b}
function C(a){this.d=a;u(this);this.t()}
function Se(){this.a=hb(rc,Ti,1,0,5,1)}
function zi(){this.a=new Se;this.b=new Se}
function Rf(){Rf=de;Of=new n;Qf=new n}
function fi(){fi=de;di=new zi;ei=new Li(di)}
function bb(){bb=de;var a;!db();a=new eb;ab=a}
function Sb(a){return typeof a==='boolean'}
function jb(a){return Array.isArray(a)&&a.X===he}
function M(a,b,c){return a.apply(b,c);var d}
function Ud(a){if(Tb(a)){return a|0}return Fb(a)}
function ue(a){var b;b=te(a);Be(a,b);return b}
function Vg(a,b){var c;c=b.target;Yg(a,c.value)}
function of(a,b){var c;return tf(a,(c=new Se,c))}
function cf(a,b){while(a.c<a.d){ef(a,b,a.c++)}}
function zf(a,b,c){if(a.a.O(c)){a.b=true;b.M(c)}}
function le(a,b,c,d){a.addEventListener(b,c,d)}
function Ne(a,b){a.a[a.a.length]=b;return true}
function Z(a,b){!a&&(a=[]);a[a.length]=b;return a}
function we(a){var b;b=te(a);b.j=a;b.e=1;return b}
function Vd(a){if(Tb(a)){return ''+a}return Gb(a)}
function We(a,b){return af(b,a.length),new ff(a,b)}
function Xe(a){return new vf(null,We(a,a.length))}
function qf(a,b){mf(a);return new vf(a,new Af(b,a.a))}
function sf(a,b){mf(a);return new vf(a,new Df(b,a.a))}
function vi(a,b,c){b.d=c;Oe(b.c,new pi);Oe(a.b,new Di)}
function og(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function bf(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Mi(a,b){return (ji(),hi)==a||(gi==a?!b.a:b.a)}
function eh(a){ui((fi(),di),a.d.props['a'])}
function bh(a){xi((fi(),di),a.d.props['a'])}
function mh(a){wi((fi(),di),new $h(a));Ji(ei,new _h(a))}
function me(){C.call(this,'divide by zero')}
function ke(){ke=de;je=$wnd.goog.global.document}
function Qb(a){return !Array.isArray(a)&&a.X===he}
function $e(a,b){return Vb(a)===Vb(b)||!!a&&Vb(a)===Vb(b)}
function li(){ji();return kb(fb(yd,1),Ti,20,0,[gi,ii,hi])}
function ye(a){if(a.D()){return null}var b=a.j;return _d[b]}
function nf(a){if(!a){this.b=null;new Se}else{this.b=a}}
function lf(a){if(!a.b){mf(a);a.c=true}else{lf(a.b)}}
function gf(a){if(!a.d){a.d=new Ve(a.b);a.c=a.b.a.length}}
function ve(a,b){var c;c=te(a);Be(a,c);c.e=b?8:0;return c}
function A(a,b){var c;c=re(a.V);return b==null?c:c+': '+b}
function ff(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Uf(){if(Pf==256){Of=Qf;Qf=new n;Pf=0}++Pf}
function mf(a){if(a.b){mf(a.b)}else if(a.c){throw Od(new De)}}
function R(a){L();$wnd.setTimeout(function(){throw a},0)}
function Ah(a){$wnd.React.Component.call(this,a);new Ug(this)}
function Dh(){Dh=de;var a;Ch=(a=ee(Bh.prototype.U,Bh,[]),a)}
function vh(){vh=de;var a;uh=(a=ee(th.prototype.U,th,[]),a)}
function zh(){zh=de;var a;yh=(a=ee(xh.prototype.U,xh,[]),a)}
function Hh(){Hh=de;var a;Gh=(a=ee(Fh.prototype.U,Fh,[]),a)}
function Lh(){Lh=de;var a;Kh=(a=ee(Jh.prototype.U,Jh,[]),a)}
function fe(a){function b(){}
;b.prototype=a||{};return new b}
function B(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function ng(a){a.placeholder='What needs to be done?';return a}
function Le(){C.call(this,'Add not supported on this collection')}
function Df(a,b){bf.call(this,b.J(),b.I()&-6);this.a=a;this.b=b}
function Af(a,b){bf.call(this,b.J(),b.I()&-16449);this.a=a;this.c=b}
function oi(a,b){this.c=new Se;this.b=a;this.d=b;this.a=false}
function df(a,b){if(a.c<a.d){ef(a,b,a.c++);return true}return false}
function xe(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.v(b))}
function be(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function P(a,b,c){var d;d=N();try{return M(a,b,c)}finally{Q(d)}}
function O(b){L();return function(){return P(b,this,arguments);var a}}
function Wb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Q(a){a&&X((V(),U));--I;if(a){if(K!=-1){S(K);K=-1}}}
function dh(a){Ii((fi(),ei),a.d.props['a']);jh(a,a.d.props['a'].d)}
function Ze(a,b){while(a.a<a.c.a.length){b.M((a.b=a.a++,a.c.a[a.b]))}}
function Ki(a){var b;b=a.b;!!b&&!ti(a.c,b)&&(a.b=null,Oe(a.a,new Pi))}
function yi(a,b){rf(new vf(null,new hf(a.a)),new Fi(b));Oe(a.b,new Di)}
function qi(a,b){Ne(a.a,new oi(''+Vd(Rd(Date.now())),b));Oe(a.b,new Di)}
function uf(a,b){var c;c=of(a,new kf(new jf));return Re(c,b.N(c.a.length))}
function tf(a,b){var c;lf(a);c=new Gf;c.a=b;a.a.K(new If(c));return c.a}
function pf(a){var b;lf(a);b=0;while(a.a.L(new Hf)){b=Pd(b,1)}return b}
function mb(a){var b,c,d;b=a&Wi;c=a>>22&Wi;d=a<0?Xi:0;return ob(b,c,d)}
function Mh(a){$wnd.React.Component.call(this,a);this.a=new oh(this)}
function Ih(a){$wnd.React.Component.call(this,a);this.a=new lh(this)}
function wh(a){$wnd.React.Component.call(this,a);this.a=new Sg(this)}
function Eh(a){$wnd.React.Component.call(this,a);this.a=new $g(this)}
function H(){if(Date.now){return Date.now()}return (new Date).getTime()}
function bg(a,b,c){!Ie(c,'key')&&!Ie(c,'ref')&&(a[c]=b[c],undefined)}
function hb(a,b,c,d,e,f){var g;g=ib(e,d);e!=10&&kb(fb(a,f),b,c,e,g);return g}
function Qe(a,b){var c;c=Pe(a,b,0);if(c==-1){return false}Kf(a.a,c);return true}
function Oe(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.M(c)}}
function t(){var a;this.a=hb(Zb,Ti,26,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function W(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=$(b,c)}while(a.a);a.a=c}}
function X(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=$(b,c)}while(a.b);a.b=c}}
function _g(a,b){var c;if((fi(),ei).b==a.d.props['a']){c=b.target;jh(a,c.value)}}
function Be(a,b){var c;if(!a){return}b.j=a;var d=ye(b);if(!d){_d[a]=[b];return}d.V=b}
function Pe(a,b,c){for(;c<a.a.length;++c){if($e(b,a.a[c])){return c}}return -1}
function Yh(a,b){Xf(a.a,(qe(sd),sd.k+(''+(b?b.b:null))));a.a.props['a']=b;return a.a}
function te(a){var b;b=new se;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function ee(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Fe(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function Zf(a,b,c,d){var e;e=$f($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function _f(a){var b;return Zf($wnd.React.StrictMode,null,null,(b={},b[aj]=a,b))}
function Yf(a){var b;b=$f($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function G(a){F();u(this);this.b=a;v(this,a);this.d=a==null?'null':ge(a);this.a=a}
function De(){C.call(this,"Stream already terminated, can't be modified or used")}
function ri(a){of(qf(new vf(null,new hf(a.a)),new Bi),new kf(new jf)).F(new Ci(a))}
function ji(){ji=de;gi=new ki('ACTIVE',0);ii=new ki('COMPLETED',1);hi=new ki('ALL',2)}
function Lb(){Lb=de;Hb=ob(Wi,Wi,524287);Ib=ob(0,0,Yi);Jb=mb(1);mb(2);Kb=mb(0)}
function Lf(a,b){return gb(b)!=10&&kb(o(b),b.W,b.__elementTypeId$,gb(b),a),a}
function gb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ie(){$wnd.ReactDOM.render(_f([(new ci).a]),(ke(),je).getElementById('app'),null)}
function Xd(){Yd();var a=Wd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Ge(a,b){var c,d;for(d=new Ve(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);ui(b.a,c)}}
function Td(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Zi;d=Xi}c=Wb(e/$i);b=Wb(e-c*$i);return ob(b,c,d)}
function yb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ob(c&Wi,d&Wi,e&Xi)}
function Eb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return ob(c&Wi,d&Wi,e&Xi)}
function Bb(a){var b,c,d;b=~a.l+1&Wi;c=~a.m+(b==0?1:0)&Wi;d=~a.h+(b==0&&c==0?1:0)&Xi;return ob(b,c,d)}
function ub(a){var b,c,d;b=~a.l+1&Wi;c=~a.m+(b==0?1:0)&Wi;d=~a.h+(b==0&&c==0?1:0)&Xi;a.l=b;a.m=c;a.h=d}
function Qd(a){var b;b=a.h;if(b==0){return a.l+a.m*$i}if(b==Xi){return a.l+a.m*$i-Zi}return a}
function Nd(a){var b;if(Rb(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new G(a);cb(b)}return b}
function Rd(a){if(_i<a&&a<Zi){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Qd(Ab(a))}
function af(a,b){if(0>a||a>b){throw Od(new ne('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function lh(a){this.d=a;r();++kh;this.b=this.d.props['a'].d;ni(this.d.props['a'],new Qh(this))}
function ah(a,b){27==b.which?(Ii((fi(),ei),null),jh(a,a.d.props['a'].d)):13==b.which&&gh(a)}
function $d(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function kb(a,b,c,d,e){e.V=a;e.W=b;e.X=he;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function rb(a,b,c,d,e){var f;f=Db(a,b);c&&ub(f);if(e){a=tb(a,b);d?(lb=Bb(a)):(lb=ob(a.l,a.m,a.h))}return f}
function vb(a){var b,c;c=Ee(a.h);if(c==32){b=Ee(a.m);return b==32?Ee(a.l)+32:b+20-10}else{return c-12}}
function si(a){return Ud(pf(new vf(null,new hf(a.a))))-Ud(pf(qf(new vf(null,new hf(a.a)),new Ei)))}
function o(a){return Ub(a)?tc:Tb(a)?kc:Sb(a)?ic:Qb(a)?a.V:jb(a)?a.V:a.V||Array.isArray(a)&&fb(ac,1)||ac}
function p(a){return Ub(a)?Tf(a):Tb(a)?Wb(a):Sb(a)?a?1231:1237:Qb(a)?a.o():jb(a)?Nf(a):!!a&&!!a.hashCode?a.hashCode():Nf(a)}
function Pd(a,b){var c;if(Tb(a)&&Tb(b)){c=a+b;if(_i<c&&c<Zi){return c}}return Qd(yb(Tb(a)?Td(a):a,Tb(b)?Td(b):b))}
function qb(a,b){if(a.h==Yi&&a.m==0&&a.l==0){b&&(lb=ob(0,0,0));return nb((Lb(),Jb))}b&&(lb=ob(a.l,a.m,a.h));return ob(0,0,0)}
function ge(a){var b;if(Array.isArray(a)&&a.X===he){return re(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function N(){var a;if(I!=0){a=H();if(a-J>2000){J=a;K=$wnd.setTimeout(T,10)}}if(I++==0){W((V(),U));return true}return false}
function Tf(a){Rf();var b,c,d;c=':'+a;d=Qf[c];if(d!=null){return Wb(d)}d=Of[c];b=d==null?Sf(a):Wb(d);Uf();Qf[c]=b;return b}
function Ye(a){var b,c,d;d=1;for(c=new Ve(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function Re(a,b){var c,d;d=a.a.length;b.length<d&&(b=Lf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Ae(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Wg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=Je(a.a);if(c.length>0){qi((fi(),di),c);a.a='';a.d.forceUpdate()}}}
function se(){this.g=pe++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Li(a){this.a=new Se;this.c=a;le((ke(),$wnd.goog.global.window),'hashchange',new Ni(this),false);wi(a,new Oi(this))}
function Pg(){Ng();return kb(fb(Uc,1),Ti,5,0,[rg,sg,tg,ug,vg,wg,xg,yg,zg,Ag,Bg,Cg,Dg,Eg,Fg,Gg,Hg,Ig,Jg,Kg,Lg,Mg])}
function db(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function gh(a){if(null!=a.b&&a.b.length!=0){vi((fi(),di),a.d.props['a'],a.b);Ii(ei,null);jh(a,a.b)}else{ui((fi(),di),a.d.props['a'])}}
function Pb(a,b){if(Ub(a)){return !!Ob[b]}else if(a.W){return !!a.W[b]}else if(Tb(a)){return !!Nb[b]}else if(Sb(a)){return !!Mb[b]}return false}
function hh(a){var b;b=(fi(),ei).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();jh(a,a.d.props['a'].d)}else a.c&&!b&&(a.c=false)}
function eg(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Je(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function tb(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return ob(c,d,e)}
function Cb(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return ob(c&Wi,d&Wi,e&Xi)}
function ib(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function xb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&Wi;a.m=d&Wi;a.h=e&Xi;return true}
function Xg(a){return ag(cj,ig(lg(mg(pg(ng(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['new-todo']))),a.a),ee(Nh.prototype.S,Nh,[a])),ee(Oh.prototype.R,Oh,[a]))),null)}
function zb(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Zd(b,c,d,e){Yd();var f=Wd;$moduleName=c;$moduleBase=d;Md=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Ri(g)()}catch(a){b(c,a)}}else{Ri(g)()}}
function $f(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function $(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Y()&&(c=Z(c,g)):g[0].Y()}catch(a){a=Nd(a);if(Rb(a,4)){d=a;L();R(Rb(d,24)?d.u():d)}else throw Od(a)}}return c}
function ae(){_d={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+He(a,c++)}b=b|0;return b}
function Gi(a){var b,c,d;b=(d=(c=(ke(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1)),Ie(ej,d)?(ji(),gi):Ie(fj,d)?(ji(),ii):(ji(),hi));return of(qf(new vf(null,new hf(a.c.a)),new Qi(b)),new kf(new jf))}
function Ee(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function ce(a,b,c){var d=_d,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=_d[b]),fe(h));_.W=c;!b&&(_.X=he);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.V=f)}
function Db(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&Yi)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?Xi:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?Xi:0;f=d?Wi:0;e=c>>b-44}return ob(e&Wi,f&Wi,g&Xi)}
function ze(a){if(a.C()){var b=a.c;b.D()?(a.k='['+b.j):!b.C()?(a.k='[L'+b.A()+';'):(a.k='['+b.A());a.b=b.w()+'[]';a.i=b.B()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Ae('.',[c,Ae('$',d)]);a.b=Ae('.',[c,Ae('.',d)]);a.i=d[d.length-1]}
function ag(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Wf(b,ee(dg.prototype.P,dg,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[aj]=c[0],undefined):(d[aj]=c,undefined));return Zf(a,e,f,d)}
function wb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return Fe(c)}if(b==0&&d!=0&&c==0){return Fe(d)+22}if(b!=0&&d==0&&c==0){return Fe(b)+44}return -1}
function Ab(a){var b,c,d,e,f;if(isNaN(a)){return Lb(),Kb}if(a<-9223372036854775808){return Lb(),Ib}if(a>=9223372036854775807){return Lb(),Hb}e=false;if(a<0){e=true;a=-a}d=0;if(a>=Zi){d=Wb(a/Zi);a-=d*Zi}c=0;if(a>=$i){c=Wb(a/$i);a-=c*$i}b=Wb(a);f=ob(b,c,d);e&&ub(f);return f}
function v(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.s();return a&&a.q()}},suppressed:{get:function(){return c.r()}}})}catch(a){}}}
function Hi(a,b){var c,d,e;b.preventDefault();c=(d=(ke(),$wnd.goog.global.window).location.hash,null==d?'':d.substr(1));if(Ie(ej,c)||Ie(fj,c)||Ie('',c)){Oe(a.a,new Pi)}else{e=$wnd.goog.global.window.location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',je.title,e)}}
function Gb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==Yi&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Gb(Bb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=mb(1000000000);c=pb(c,e,true);b=''+Fb(lb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function sb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=vb(b)-vb(a);g=Cb(b,j);i=ob(0,0,0);while(j>=0){h=xb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&ub(i);if(f){if(d){lb=Bb(a);e&&(lb=Eb(lb,(Lb(),Jb)))}else{lb=ob(a.l,a.m,a.h)}}return i}
function Ng(){Ng=de;rg=new Og(bj,0);sg=new Og('checkbox',1);tg=new Og('color',2);ug=new Og('date',3);vg=new Og('datetime',4);wg=new Og('email',5);xg=new Og('file',6);yg=new Og('hidden',7);zg=new Og('image',8);Ag=new Og('month',9);Bg=new Og(Si,10);Cg=new Og('password',11);Dg=new Og('radio',12);Eg=new Og('range',13);Fg=new Og('reset',14);Gg=new Og('search',15);Hg=new Og('submit',16);Ig=new Og('tel',17);Jg=new Og('text',18);Kg=new Og('time',19);Lg=new Og('url',20);Mg=new Og('week',21)}
function pb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Od(new me)}if(a.l==0&&a.m==0&&a.h==0){c&&(lb=ob(0,0,0));return ob(0,0,0)}if(b.h==Yi&&b.m==0&&b.l==0){return qb(a,c)}i=false;if(b.h>>19!=0){b=Bb(b);i=!i}g=wb(b);f=false;e=false;d=false;if(a.h==Yi&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=nb((Lb(),Hb));d=true;i=!i}else{h=Db(a,g);i&&ub(h);c&&(lb=ob(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Bb(a);d=true;i=!i}if(g!=-1){return rb(a,g,i,f,c)}if(zb(a,b)<0){c&&(f?(lb=Bb(a)):(lb=ob(a.l,a.m,a.h)));return ob(0,0,0)}return sb(d?a:ob(a.l,a.m,a.h),b,i,f,e,c)}
function ih(a){var b,c;c=a.d.props['a'];b=c.a;return ag('li',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[b?'checked':null,(fi(),ei).b==a.d.props['a']?'editing':null])),[ag('div',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['view'])),[ag(cj,lg(jg(og(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['toggle'])),(Ng(),sg)),b),ee(Th.prototype.R,Th,[a])),null),ag('label',qg(new $wnd.Object,ee(Uh.prototype.T,Uh,[a])),[c.d]),ag(bj,hg(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['destroy'])),ee(Vh.prototype.T,Vh,[a])),null)]),ag(cj,mg(lg(kg(pg(eg(fg(new $wnd.Object,ee(Wh.prototype.M,Wh,[a])),kb(fb(tc,1),Ti,2,6,['edit'])),a.b),ee(Xh.prototype.Q,Xh,[a])),ee(Rh.prototype.R,Rh,[a])),ee(Sh.prototype.S,Sh,[a])),null)])}
var Si='number',Ti={3:1},Ui='__noinit__',Vi={3:1,7:1,4:1},Wi=4194303,Xi=1048575,Yi=524288,Zi=17592186044416,$i=4194304,_i=-17592186044416,aj='children',bj='button',cj='input',dj={33:1},ej='active',fj='completed',gj='selected',hj='header';var _,_d,Wd,Md=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;ae();ce(1,null,{},n);_.n=function(){return this.V};_.o=ij;_.hashCode=function(){return this.o()};var Mb,Nb,Ob;ce(36,1,{},se);_.v=function(a){var b;b=new se;b.e=4;a>1?(b.c=xe(this,a-1)):(b.c=this);return b};_.w=function(){qe(this);return this.b};_.A=function(){return re(this)};_.B=function(){qe(this);return this.i};_.C=function(){return (this.e&4)!=0};_.D=function(){return (this.e&1)!=0};_.e=0;_.g=0;var pe=1;var rc=ue(1);var jc=ue(36);ce(55,1,{},q);var Yb=ue(55);ce(26,1,{26:1},s);var Zb=ue(26);ce(64,1,{},t);var $b=ue(64);ce(4,1,{3:1,4:1});_.q=kj;_.r=function(){return uf(sf(Xe((this.e==null&&(this.e=hb(vc,Ti,4,0,0,1)),this.e)),new Ke),new yf)};_.s=function(){return this.c};_.t=function(){w(this,B(new Error(A(this,this.d))));cb(this)};_.b=Ui;_.f=true;var vc=ue(4);ce(35,4,{3:1,4:1});var mc=ue(35);ce(7,35,Vi);var sc=ue(7);ce(47,7,Vi);var pc=ue(47);ce(48,47,Vi);var cc=ue(48);ce(24,48,{24:1,3:1,7:1,4:1},G);_.u=function(){return Vb(this.a)===Vb(D)?null:this.a};var D;var _b=ue(24);var ac=ue(0);ce(110,1,{});var bc=ue(110);var I=0,J=0,K=-1;ce(57,110,{},Y);var U;var dc=ue(57);var ab;ce(123,1,{});var fc=ue(123);ce(49,123,{},eb);var ec=ue(49);var lb;var Hb,Ib,Jb,Kb;var je;ce(54,7,Vi,me);var gc=ue(54);ce(52,7,Vi);var oc=ue(52);ce(77,52,Vi,ne);var hc=ue(77);Mb={3:1,23:1};var ic=ue(120);ce(121,1,Ti);var qc=ue(121);Nb={3:1,23:1};var kc=ue(122);ce(18,1,{3:1,23:1,18:1});_.o=ij;_.b=0;var lc=ue(18);ce(51,7,Vi,De);var nc=ue(51);ce(184,1,{});Ob={3:1,43:1,23:1,2:1};var tc=ue(2);ce(188,1,{});ce(41,1,{},Ke);_.G=function(a){return a.b};var uc=ue(41);ce(53,7,Vi,Le);var wc=ue(53);ce(124,1,{107:1});_.F=function(a){Ge(this,a)};_.H=function(a){throw Od(new Le)};var xc=ue(124);ce(125,124,{107:1,131:1});_.H=function(a){Me(this,this.a.length,a);return true};_.o=function(){return Ye(this)};var yc=ue(125);ce(11,125,{3:1,11:1,107:1,131:1},Se);_.H=function(a){return Ne(this,a)};_.F=function(a){Oe(this,a)};var Ac=ue(11);ce(16,1,{},Ve);_.a=0;_.b=-1;var zc=ue(16);ce(66,1,{});_.K=jj;_.I=function(){return this.d};_.J=function(){return this.e};_.d=0;_.e=0;var Ec=ue(66);ce(37,66,{});var Bc=ue(37);ce(58,1,{});_.K=jj;_.I=kj;_.J=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Dc=ue(58);ce(59,58,{},ff);_.K=function(a){cf(this,a)};_.L=function(a){return df(this,a)};var Cc=ue(59);ce(12,1,{},hf);_.I=function(){return this.a};_.J=function(){gf(this);return this.c};_.K=function(a){gf(this);Ze(this.d,a)};_.L=function(a){gf(this);if(Te(this.d)){a.M(Ue(this.d));return true}return false};_.a=0;_.c=0;var Fc=ue(12);ce(25,1,{},jf);_.G=function(a){return a};var Gc=ue(25);ce(29,1,{},kf);var Hc=ue(29);ce(65,1,{});_.c=false;var Rc=ue(65);ce(9,65,{},vf);var Qc=ue(9);ce(42,1,{},yf);_.N=function(a){return hb(rc,Ti,1,a,5,1)};var Ic=ue(42);ce(68,37,{},Af);_.L=function(a){this.b=false;while(!this.b&&this.c.L(new Bf(this,a)));return this.b};_.b=false;var Kc=ue(68);ce(71,1,{},Bf);_.M=function(a){zf(this.a,this.b,a)};var Jc=ue(71);ce(67,37,{},Df);_.L=function(a){return this.b.L(new Ef(this,a))};var Mc=ue(67);ce(70,1,{},Ef);_.M=function(a){Cf(this.a,this.b,a)};var Lc=ue(70);ce(69,1,{},Gf);_.M=function(a){Ff(this,a)};var Nc=ue(69);ce(72,1,{},Hf);_.M=function(a){};var Oc=ue(72);ce(73,1,{},If);_.M=function(a){xf(this.a,a)};var Pc=ue(73);ce(186,1,{});ce(183,1,{});var Mf=0;var Of,Pf=0,Qf;ce(798,1,{});ce(819,1,{});ce(126,1,{});var Sc=ue(126);ce(78,1,{},cg);_.N=function(a){return new Array(a)};var Tc=ue(78);ce(152,$wnd.Function,{},dg);_.P=function(a){bg(this.a,this.b,a)};ce(5,18,{3:1,23:1,18:1,5:1},Og);var rg,sg,tg,ug,vg,wg,xg,yg,zg,Ag,Bg,Cg,Dg,Eg,Fg,Gg,Hg,Ig,Jg,Kg,Lg,Mg;var Uc=ve(5,Pg);ce(129,126,{});var cd=ue(129);ce(99,129,{});var gd=ue(99);ce(100,99,{},Sg);_.o=ij;var Rg=0;var Wc=ue(100);ce(130,126,{});var bd=ue(130);ce(105,130,{});var fd=ue(105);ce(106,105,{},Ug);_.o=ij;var Tg=0;var Vc=ue(106);ce(96,126,{});_.a='';var pd=ue(96);ce(97,96,{});var jd=ue(97);ce(98,97,{},$g);_.o=ij;var Zg=0;var Xc=ue(98);ce(128,126,{});_.c=false;var sd=ue(128);ce(102,128,{});var ld=ue(102);ce(103,102,{},lh);_.o=ij;var kh=0;var Yc=ue(103);ce(127,126,{});var xd=ue(127);ce(75,127,{});var nd=ue(75);ce(76,75,{},oh);_.o=ij;var nh=0;var Zc=ue(76);ce(93,1,dj,ph);_.p=mj;var $c=ue(93);ce(157,$wnd.Function,{},qh);_.T=function(a){ri((fi(),di))};ce(85,1,{},rh);var _c=ue(85);ce(101,1,{},sh);var ad=ue(101);ce(156,$wnd.Function,{},th);_.U=function(a){return new wh(a)};var uh;ce(92,$wnd.React.Component,{},wh);be(_d[1],_);_.componentDidMount=function(){Qg(this.a)};_.render=function(){var a,b,c;return a=(c=(fi(),b=(ke(),$wnd.goog.global.window).location.hash,null==b?'':b.substr(1)),Ie(ej,c)?(ji(),gi):Ie(fj,c)?(ji(),ii):(ji(),hi)),ag('footer',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['footer'])),[(new sh).a,ag('ul',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['filters'])),[ag('li',null,[ag('a',gg(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[(ji(),hi)==a?gj:null])),'#'),['All'])]),ag('li',null,[ag('a',gg(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[gi==a?gj:null])),'#active'),['Active'])]),ag('li',null,[ag('a',gg(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[ii==a?gj:null])),'#completed'),['Completed'])])]),si(di)>0?ag(bj,hg(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['clear-completed'])),ee(qh.prototype.T,qh,[])),['Clear Completed']):null])};_.shouldComponentUpdate=lj;var dd=ue(92);ce(167,$wnd.Function,{},xh);_.U=function(a){return new Ah(a)};var yh;ce(104,$wnd.React.Component,{},Ah);be(_d[1],_);_.render=function(){var a,b;return a=Ud(pf(new vf(null,new hf((fi(),di).a)))),b='item'+(a==1?'':'s'),ag('span',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['todo-count'])),[ag('strong',null,[a]),' '+b+' left'])};_.shouldComponentUpdate=lj;var ed=ue(104);ce(153,$wnd.Function,{},Bh);_.U=function(a){return new Eh(a)};var Ch;ce(91,$wnd.React.Component,{},Eh);be(_d[1],_);_.render=function(){return Xg(this.a)};_.shouldComponentUpdate=lj;var hd=ue(91);ce(158,$wnd.Function,{},Fh);_.U=function(a){return new Ih(a)};var Gh;ce(94,$wnd.React.Component,{},Ih);be(_d[1],_);_.componentDidUpdate=function(a){hh(this.a)};_.render=function(){return ih(this.a)};_.shouldComponentUpdate=lj;var kd=ue(94);ce(150,$wnd.Function,{},Jh);_.U=function(a){return new Mh(a)};var Kh;ce(60,$wnd.React.Component,{},Mh);be(_d[1],_);_.componentDidMount=function(){mh(this.a)};_.render=function(){return ag('div',null,[ag('div',null,[ag(hj,eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[hj])),[ag('h1',null,['todos']),(new Ph).a]),0!=Ud(pf(new vf(null,new hf((fi(),di).a))))?ag('section',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,[hj])),[ag(cj,lg(og(eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['toggle-all'])),(Ng(),sg)),ee(ai.prototype.R,ai,[])),null),ag('ul',eg(new $wnd.Object,kb(fb(tc,1),Ti,2,6,['todo-list'])),uf(sf(new vf(null,new hf(Gi(ei))),new bi),new cg))]):null,0!=Ud(pf(new vf(null,new hf(di.a))))?(new rh).a:null])])};_.shouldComponentUpdate=lj;var md=ue(60);ce(154,$wnd.Function,{},Nh);_.S=function(a){Wg(this.a,a)};ce(155,$wnd.Function,{},Oh);_.R=function(a){Vg(this.a,a)};ce(79,1,{},Ph);var od=ue(79);ce(95,1,dj,Qh);_.p=mj;var qd=ue(95);ce(165,$wnd.Function,{},Rh);_.R=function(a){_g(this.a,a)};ce(166,$wnd.Function,{},Sh);_.S=function(a){ah(this.a,a)};ce(159,$wnd.Function,{},Th);_.R=function(a){bh(this.a)};ce(161,$wnd.Function,{},Uh);_.T=function(a){dh(this.a)};ce(162,$wnd.Function,{},Vh);_.T=function(a){eh(this.a)};ce(163,$wnd.Function,{},Wh);_.M=function(a){fh(this.a,a)};ce(164,$wnd.Function,{},Xh);_.Q=function(a){gh(this.a)};ce(90,1,{},Zh);var rd=ue(90);ce(61,1,dj,$h);_.p=mj;var td=ue(61);ce(62,1,dj,_h);_.p=mj;var ud=ue(62);ce(151,$wnd.Function,{},ai);_.R=function(a){var b;b=a.target;yi((fi(),di),b.checked)};ce(63,1,{},bi);_.G=function(a){return Yh(new Zh,a)};var vd=ue(63);ce(40,1,{},ci);var wd=ue(40);var di,ei;ce(20,18,{3:1,23:1,18:1,20:1},ki);var gi,hi,ii;var yd=ve(20,li);ce(38,1,{38:1},oi);_.a=false;var Gd=ue(38);ce(28,1,{},pi);_.M=nj;var zd=ue(28);ce(80,1,{},zi);var Fd=ue(80);ce(83,1,{},Bi);_.O=function(a){return a.a};var Ad=ue(83);ce(84,1,{},Ci);_.M=function(a){ui(this.a,a)};var Bd=ue(84);ce(19,1,{},Di);_.M=nj;var Cd=ue(19);ce(81,1,{},Ei);_.O=function(a){return !a.a};var Dd=ue(81);ce(82,1,{},Fi);_.M=function(a){Ai(this.a,a)};_.a=false;var Ed=ue(82);ce(86,1,{},Li);var Ld=ue(86);ce(87,1,{},Ni);_.handleEvent=function(a){Hi(this.a,a)};var Hd=ue(87);ce(88,1,dj,Oi);_.p=function(){Ki(this.a)};var Id=ue(88);ce(27,1,{},Pi);_.M=nj;var Jd=ue(27);ce(89,1,{},Qi);_.O=function(a){return Mi(this.a,a)};var Kd=ue(89);var Xb=we('D');var Ri=(L(),O);var gwtOnLoad=gwtOnLoad=Zd;Xd(ie);$d('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();