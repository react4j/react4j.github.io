function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='F25A14CB984DC9F6631B0CF31738CF57',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'F25A14CB984DC9F6631B0CF31738CF57';function n(){}
function s(){}
function Y(){}
function Yd(){}
function Ud(){}
function Ug(){}
function rg(){}
function sg(){}
function Rg(){}
function Yg(){}
function eb(){}
function ff(){}
function gf(){}
function ah(){}
function fh(){}
function jh(){}
function Ah(){}
function Oh(){}
function $h(){}
function ai(){}
function bi(){}
function ni(){}
function Mi(a){a()}
function cb(a){bb()}
function v(a){Le(a)}
function u(){new Ee}
function ce(){ce=Ud}
function ef(a,b){a.a=b}
function df(a){this.a=a}
function hf(a){this.a=a}
function nh(a){this.a=a}
function oh(a){this.a=a}
function qh(a){this.a=a}
function rh(a){this.a=a}
function sh(a){this.a=a}
function th(a){this.a=a}
function uh(a){this.a=a}
function vh(a){this.a=a}
function wh(a){this.a=a}
function xh(a){this.a=a}
function _h(a){this.a=a}
function ci(a){this.a=a}
function li(a){this.a=a}
function mi(a){this.a=a}
function oi(a){this.a=a}
function He(a){this.c=a}
function yf(a,b){a.key=b}
function xf(a,b){wf(a,b)}
function Mh(a,b){ze(a.c,b)}
function Vh(a,b){ze(a.b,b)}
function hi(a,b){ze(a.a,b)}
function Fg(a,b){return a.a=b}
function we(a,b){return a===b}
function Dd(a){return a.b}
function Li(a){return false}
function Ji(){return of(this)}
function ye(a){C.call(this,a)}
function ue(){w(this);this.q()}
function r(){r=Ud;new q}
function F(){F=Ud;D=new n}
function V(){V=Ud;U=new Y}
function L(){L=Ud;!!(bb(),ab)}
function T(){I!=0&&(I=0);K=-1}
function Nd(){Ld==null&&(Ld=[])}
function kf(a,b){a.splice(b,1)}
function fb(a,b){return ke(a,b)}
function $e(a,b){ef(a,Ze(a.a,b))}
function Me(a,b){while(a.J(b));}
function Ve(a,b){Qe(a);a.a.I(b)}
function Ze(a,b){a.C(b);return a}
function Hf(a,b){a.ref=b;return a}
function If(a,b){a.href=b;return a}
function fe(a){ee(a);return a.k}
function Gb(a){return a.l|a.m<<22}
function kb(a){return new Array(a)}
function S(a){$wnd.clearTimeout(a)}
function pg(a,b){pe.call(this,a,b)}
function Jh(a,b){pe.call(this,a,b)}
function pe(a,b){this.a=a;this.b=b}
function bf(a,b){this.a=a;this.b=b}
function Ff(a,b){this.a=a;this.b=b}
function Pe(a){this.b=a;this.a=16464}
function Sg(){this.a=zf((Wg(),Vg))}
function Tg(){this.a=zf(($g(),Zg))}
function ph(){this.a=zf((dh(),bh))}
function zh(){this.a=zf((hh(),gh))}
function Bh(){this.a=zf((lh(),kh))}
function ug(a){this.d=Le(a);r();++tg}
function wg(a){this.d=Le(a);r();++vg}
function Cg(a){this.d=Le(a);r();++Bg}
function Qg(a){this.d=Le(a);r();++Pg}
function Sf(a,b){a.value=b;return a}
function Nf(a,b){a.onBlur=b;return a}
function Jf(a,b){a.onClick=b;return a}
function Lf(a,b){a.checked=b;return a}
function Lh(a,b){a.a=b;Ae(a.c,new Oh)}
function Zh(a,b){b.a=a;Ae(b.c,new Oh)}
function gi(a,b){a.b=b;Ae(a.a,new ni)}
function jf(a,b,c){a.splice(b,0,c)}
function pb(a,b,c){return {l:a,m:b,h:c}}
function ob(a){return pb(a.l,a.m,a.h)}
function Fe(a){return a.a<a.c.a.length}
function Wb(a){return a==null?null:a}
function Ub(a){return typeof a===qi}
function of(a){return a.$H||(a.$H=++nf)}
function ve(a,b){return a.charCodeAt(b)}
function Sb(a,b){return a!=null&&Qb(a,b)}
function Sh(a,b){return Be(a.a,b,0)!=-1}
function wf(a,b){for(var c in a){b(c)}}
function Of(a,b){a.onChange=b;return a}
function Pf(a,b){a.onKeyDown=b;return a}
function Kf(a){a.autoFocus=true;return a}
function ee(a){if(a.k!=null){return}me(a)}
function A(a,b){a.b=b;b!=null&&mf(b,ti,a)}
function Ag(a,b){a.a=b;a.d.forceUpdate()}
function Mg(a,b){a.b=b;a.d.forceUpdate()}
function Th(a,b){Ce(a.a,b);Ae(a.b,new ai)}
function Ye(a,b){Se.call(this,a);this.a=b}
function C(a){this.c=a;w(this);this.q()}
function Ee(){this.a=hb(sc,ri,1,0,5,1)}
function Yh(){this.a=new Ee;this.b=new Ee}
function sf(){sf=Ud;pf=new n;rf=new n}
function _d(){_d=Ud;$d=$wnd.window.document}
function be(){C.call(this,'divide by zero')}
function Tb(a){return typeof a==='boolean'}
function Vb(a){return typeof a==='string'}
function M(a,b,c){return a.apply(b,c);var d}
function Wh(a,b){Lh(b,!b.a);Ae(a.b,new ai)}
function ie(a){var b;b=he(a);oe(a,b);return b}
function Mf(a,b){a.defaultValue=b;return a}
function Tf(a,b){a.onDoubleClick=b;return a}
function ze(a,b){a.a[a.a.length]=b;return true}
function w(a){a.d&&a.b!==si&&a.q();return a}
function Ge(a){a.b=a.a++;return a.c.a[a.b]}
function Jd(a){if(Ub(a)){return a|0}return Gb(a)}
function Jg(a){Wh((Eh(),Ch),a.d.props['a'])}
function Gg(a){Th((Eh(),Ch),a.d.props['a'])}
function _e(a,b,c){if(a.a.L(c)){a.b=true;b.K(c)}}
function mf(b,c,d){try{b[c]=d}catch(a){}}
function bb(){bb=Ud;var a;!db();a=new eb;ab=a}
function Eh(){Eh=Ud;Ch=new Yh;Dh=new ji(Ch)}
function We(a){Re(a);return new Ye(a,new cf(a.a))}
function Kd(a){if(Ub(a)){return ''+a}return Hb(a)}
function Le(a){if(a==null){throw Dd(new ue)}return a}
function Z(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Rf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function xg(a,b){var c;c=b.target;Ag(a,c.value)}
function Ue(a,b){Re(a);return new Ye(a,new af(b,a.a))}
function Qe(a){if(!a.b){Re(a);a.c=true}else{Qe(a.b)}}
function Se(a){if(!a){this.b=null;new Ee}else{this.b=a}}
function q(){this.a=new t;new v(this.a);new u}
function jb(a){return Array.isArray(a)&&a.V===Yd}
function Rb(a){return !Array.isArray(a)&&a.V===Yd}
function ki(a,b){return (Ih(),Gh)==a||(Fh==a?!b.a:b.a)}
function Ke(a,b){return Wb(a)===Wb(b)||!!a&&Wb(a)===Wb(b)}
function Ne(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function cf(a){Ne.call(this,a.H(),a.G()&-6);this.a=a}
function R(a){L();$wnd.setTimeout(function(){throw a},0)}
function le(a){if(a.A()){return null}var b=a.j;return Qd[b]}
function Oe(a){if(!a.d){a.d=new He(a.b);a.c=a.b.a.length}}
function je(a,b){var c;c=he(a);oe(a,c);c.e=b?8:0;return c}
function Uh(a,b,c){b.d=Le(c);Ae(b.c,new Oh);Ae(a.b,new ai)}
function Kh(){Ih();return lb(fb(od,1),ri,20,0,[Fh,Hh,Gh])}
function dh(){dh=Ud;var a;bh=(a=Vd(ah.prototype.S,ah,[]),a)}
function hh(){hh=Ud;var a;gh=(a=Vd(fh.prototype.S,fh,[]),a)}
function lh(){lh=Ud;var a;kh=(a=Vd(jh.prototype.S,jh,[]),a)}
function Wg(){Wg=Ud;var a;Vg=(a=Vd(Ug.prototype.S,Ug,[]),a)}
function $g(){$g=Ud;var a;Zg=(a=Vd(Yg.prototype.S,Yg,[]),a)}
function Wd(a){function b(){}
;b.prototype=a||{};return new b}
function yh(a,b){yf(a.a,b.b);Le(b);a.a.props['a']=b;return a.a}
function Re(a){if(a.b){Re(a.b)}else if(a.c){throw Dd(new qe)}}
function Q(a){a&&X((V(),U));--I;if(a){if(K!=-1){S(K);K=-1}}}
function vf(){if(qf==256){pf=rf;rf=new n;qf=0}++qf}
function Sd(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ke(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.s(b))}
function P(a,b,c){var d;d=N();try{return M(a,b,c)}finally{Q(d)}}
function ae(a,b,c,d){a.addEventListener(b,c,(ce(),d?true:false))}
function Xg(a){$wnd.React.Component.call(this,a);new ug(this)}
function _g(a){$wnd.React.Component.call(this,a);new wg(this)}
function mh(a){$wnd.React.Component.call(this,a);new Qg(this)}
function eh(a){$wnd.React.Component.call(this,a);this.a=new Cg(this)}
function ih(a){$wnd.React.Component.call(this,a);this.a=new Og(this)}
function Nh(a,b){this.c=new Ee;this.b=Le(a);this.d=Le(b);this.a=false}
function af(a,b){Ne.call(this,b.H(),b.G()&-16449);this.a=a;this.c=b}
function Ef(a,b,c){!we(c,'key')&&!we(c,'ref')&&(a[c]=b[c],undefined)}
function ii(a){var b;b=a.b;!!b&&!Sh(a.c,b)&&(a.b=null,Ae(a.a,new ni))}
function Xh(a,b){Ve(new Ye(null,new Pe(a.a)),new ci(b));Ae(a.b,new ai)}
function Ph(a,b){ze(a.a,new Nh(''+Kd(Gd(Date.now())),b));Ae(a.b,new ai)}
function Xe(a,b){var c;Qe(a);c=new ff;c.a=b;a.a.I(new hf(c));return c.a}
function Te(a){var b;Qe(a);b=0;while(a.a.J(new gf)){b=Ed(b,1)}return b}
function Qf(a){a.placeholder='What needs to be done?';return a}
function B(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function O(b){L();return function(){return P(b,this,arguments);var a}}
function H(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Xb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Je(a,b){while(a.a<a.c.a.length){b.K((a.b=a.a++,a.c.a[a.b]))}}
function Be(a,b,c){for(;c<a.a.length;++c){if(Ke(b,a.a[c])){return c}}return -1}
function Ce(a,b){var c;c=Be(a,b,0);if(c==-1){return false}kf(a.a,c);return true}
function hb(a,b,c,d,e,f){var g;g=ib(e,d);e!=10&&lb(fb(a,f),b,c,e,g);return g}
function nb(a){var b,c,d;b=a&vi;c=a>>22&vi;d=a<0?wi:0;return pb(b,c,d)}
function Ae(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.K(c)}}
function t(){var a;this.a=hb(Zb,ri,28,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function W(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=$(b,c)}while(a.a);a.a=c}}
function X(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=$(b,c)}while(a.b);a.b=c}}
function Dg(a,b){var c;if((Eh(),Dh).b==a.d.props['a']){c=b.target;Mg(a,c.value)}}
function Hg(a){gi((Eh(),Dh),a.d.props['a']);a.b=a.d.props['a'].d;a.d.forceUpdate()}
function gb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function lf(a,b){return gb(b)!=10&&lb(o(b),b.U,b.__elementTypeId$,gb(b),a),a}
function Cf(a){var b;return Af($wnd.React.StrictMode,null,null,(b={},b[Bi]=Le(a),b))}
function Qh(a){var b;Xe(Ue(new Ye(null,new Pe(a.a)),new $h),(b=new Ee,b)).B(new _h(a))}
function Cd(a){var b;if(Sb(a,5)){return a}b=a&&a[ti];if(!b){b=new G(a);cb(b)}return b}
function oe(a,b){var c;if(!a){return}b.j=a;var d=le(b);if(!d){Qd[a]=[b];return}d.T=b}
function se(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function Fd(a){var b;b=a.h;if(b==0){return a.l+a.m*zi}if(b==wi){return a.l+a.m*zi-yi}return a}
function Vd(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Af(a,b,c,d){var e;e=Bf($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Le(d);return e}
function zf(a){var b;b=Bf($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function he(a){var b;b=new ge;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Id(a){var b,c,d,e;e=a;d=0;if(e<0){e+=yi;d=wi}c=Xb(e/zi);b=Xb(e-c*zi);return pb(b,c,d)}
function Mb(){Mb=Ud;Ib=pb(vi,vi,524287);Jb=pb(0,0,xi);Kb=nb(1);nb(2);Lb=nb(0)}
function Ih(){Ih=Ud;Fh=new Jh('ACTIVE',0);Hh=new Jh('COMPLETED',1);Gh=new Jh('ALL',2)}
function Ki(){$wnd.ReactDOM.render(Cf([(new Bh).a]),(_d(),$d).getElementById('app'),null)}
function qe(){C.call(this,"Stream already terminated, can't be modified or used")}
function Md(){Nd();var a=Ld;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function te(a,b){var c,d;for(d=new He(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);Th(b.a,c)}}
function zb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return pb(c&vi,d&vi,e&wi)}
function Fb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return pb(c&vi,d&vi,e&wi)}
function Cb(a){var b,c,d;b=~a.l+1&vi;c=~a.m+(b==0?1:0)&vi;d=~a.h+(b==0&&c==0?1:0)&wi;return pb(b,c,d)}
function vb(a){var b,c,d;b=~a.l+1&vi;c=~a.m+(b==0?1:0)&vi;d=~a.h+(b==0&&c==0?1:0)&wi;a.l=b;a.m=c;a.h=d}
function wb(a){var b,c;c=re(a.h);if(c==32){b=re(a.m);return b==32?re(a.l)+32:b+20-10}else{return c-12}}
function sb(a,b,c,d,e){var f;f=Eb(a,b);c&&vb(f);if(e){a=ub(a,b);d?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h))}return f}
function lb(a,b,c,d,e){e.T=a;e.U=b;e.V=Yd;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Pd(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Gd(a){if(Ai<a&&a<yi){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Fd(Bb(a))}
function G(a){F();w(this);this.b=a;a!=null&&mf(a,ti,this);this.c=a==null?'null':Xd(a);this.a=a}
function ge(){this.g=de++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Og(a){this.d=Le(a);r();++Ng;this.b=this.d.props['a'].d;Mh(this.d.props['a'],Vd(qh.prototype.N,qh,[this]))}
function Eg(a,b){27==b.which?(gi((Eh(),Dh),null),a.b=a.d.props['a'].d,a.d.forceUpdate()):13==b.which&&Ig(a)}
function Rh(a){return Jd(Te(new Ye(null,new Pe(a.a))))-Jd(Te(Ue(new Ye(null,new Pe(a.a)),new bi)))}
function o(a){return Vb(a)?uc:Ub(a)?lc:Tb(a)?jc:Rb(a)?a.T:jb(a)?a.T:a.T||Array.isArray(a)&&fb(cc,1)||cc}
function p(a){return Vb(a)?uf(a):Ub(a)?Xb(a):Tb(a)?a?1231:1237:Rb(a)?a.o():jb(a)?of(a):!!a&&!!a.hashCode?a.hashCode():of(a)}
function Ed(a,b){var c;if(Ub(a)&&Ub(b)){c=a+b;if(Ai<c&&c<yi){return c}}return Fd(zb(Ub(a)?Id(a):a,Ub(b)?Id(b):b))}
function rb(a,b){if(a.h==xi&&a.m==0&&a.l==0){b&&(mb=pb(0,0,0));return ob((Mb(),Kb))}b&&(mb=pb(a.l,a.m,a.h));return pb(0,0,0)}
function Xd(a){var b;if(Array.isArray(a)&&a.V===Yd){return fe(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function uf(a){sf();var b,c,d;c=':'+a;d=rf[c];if(d!=null){return Xb(d)}d=pf[c];b=d==null?tf(a):Xb(d);vf();rf[c]=b;return b}
function Ie(a){var b,c,d;d=1;for(c=new He(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function De(a,b){var c,d;d=a.a.length;b.length<d&&(b=lf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function ne(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function yg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=xe(a.a);if(c.length>0){Ph((Eh(),Ch),c);a.a='';a.d.forceUpdate()}}}
function N(){var a;if(I!=0){a=H();if(a-J>2000){J=a;K=$wnd.setTimeout(T,10)}}if(I++==0){W((V(),U));return true}return false}
function db(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function qg(){og();return lb(fb(Pc,1),ri,6,0,[Uf,Vf,Wf,Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng])}
function Ig(a){if(null!=a.b&&a.b.length!=0){Uh((Eh(),Ch),a.d.props['a'],a.b);gi(Dh,null);Mg(a,a.b)}else{Th((Eh(),Ch),a.d.props['a'])}}
function ji(a){this.a=new Ee;this.c=Le(a);ae((_d(),$wnd.window.window),'hashchange',new li(this),false);Vh(a,Vd(mi.prototype.N,mi,[this]))}
function Gf(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Qb(a,b){if(Vb(a)){return !!Pb[b]}else if(a.U){return !!a.U[b]}else if(Ub(a)){return !!Ob[b]}else if(Tb(a)){return !!Nb[b]}return false}
function xe(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ub(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return pb(c,d,e)}
function ib(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function yb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&vi;a.m=d&vi;a.h=e&wi;return true}
function Zd(){Vh((Eh(),Ch),Vd(rg.prototype.N,rg,[]));hi(Dh,Vd(sg.prototype.N,sg,[]));$wnd.ReactDOM.render(Cf([(new Bh).a]),(_d(),$d).getElementById('app'),null)}
function Kg(a){var b;b=(Eh(),Dh).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();a.b=a.d.props['a'].d;a.d.forceUpdate()}else a.c&&!b&&(a.c=false)}
function ei(a,b){var c,d;b.preventDefault();c=(d=(_d(),$wnd.window.window).location.hash,null==d?'':d.substr(1));we(Gi,c)||we(Fi,c)||we('',c)?Ae(a.a,new ni):fi()}
function zg(a){return Df(Ei,Kf(Of(Pf(Sf(Qf(Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,['new-todo']))),a.a),Vd(nh.prototype.Q,nh,[a])),Vd(oh.prototype.P,oh,[a]))),null)}
function Ab(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Od(b,c,d,e){Nd();var f=Ld;$moduleName=c;$moduleBase=d;Bd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{pi(g)()}catch(a){b(c,a)}}else{pi(g)()}}
function Bf(a,b){var c;c=new $wnd.Object;c.$$typeof=Le(a);c.type=Le(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function $(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].W()&&(c=Z(c,g)):g[0].W()}catch(a){a=Cd(a);if(Sb(a,5)){d=a;L();R(Sb(d,23)?d.r():d)}else throw Dd(a)}}return c}
function Rd(){Qd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Db(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return pb(c&vi,d&vi,e&wi)}
function Eb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&xi)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?wi:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?wi:0;f=d?vi:0;e=c>>b-44}return pb(e&vi,f&vi,g&wi)}
function tf(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ve(a,c++)}b=b|0;return b}
function fi(){var a;if(0==''.length){a=(_d(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',$d.title,a)}else{(_d(),$wnd.window.window).location.hash=''}}
function re(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Td(a,b,c){var d=Qd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Qd[b]),Wd(h));_.U=c;!b&&(_.V=Yd);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.T=f)}
function me(a){if(a.w()){var b=a.c;b.A()?(a.k='['+b.j):!b.w()?(a.k='[L'+b.u()+';'):(a.k='['+b.u());a.b=b.t()+'[]';a.i=b.v()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=ne('.',[c,ne('$',d)]);a.b=ne('.',[c,ne('.',d)]);a.i=d[d.length-1]}
function Df(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;xf(b,Vd(Ff.prototype.M,Ff,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Bi]=c[0],undefined):(d[Bi]=c,undefined));return Af(a,e,f,d)}
function di(a){var b,c,d,e;b=(e=(c=(_d(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),we(Gi,e)||we(Fi,e)||we('',e)?we(Gi,e)?(Ih(),Fh):we(Fi,e)?(Ih(),Hh):(Ih(),Gh):(Ih(),Gh));return Xe(Ue(new Ye(null,new Pe(a.c.a)),new oi(b)),(d=new Ee,d))}
function xb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return se(c)}if(b==0&&d!=0&&c==0){return se(d)+22}if(b!=0&&d==0&&c==0){return se(b)+44}return -1}
function Bb(a){var b,c,d,e,f;if(isNaN(a)){return Mb(),Lb}if(a<-9223372036854775808){return Mb(),Jb}if(a>=9223372036854775807){return Mb(),Ib}e=false;if(a<0){e=true;a=-a}d=0;if(a>=yi){d=Xb(a/yi);a-=d*yi}c=0;if(a>=zi){c=Xb(a/zi);a-=c*zi}b=Xb(a);f=pb(b,c,d);e&&vb(f);return f}
function Hb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==xi&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Hb(Cb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=nb(1000000000);c=qb(c,e,true);b=''+Gb(mb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function tb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=wb(b)-wb(a);g=Db(b,j);i=pb(0,0,0);while(j>=0){h=yb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&vb(i);if(f){if(d){mb=Cb(a);e&&(mb=Fb(mb,(Mb(),Kb)))}else{mb=pb(a.l,a.m,a.h)}}return i}
function og(){og=Ud;Uf=new pg(Ci,0);Vf=new pg('checkbox',1);Wf=new pg('color',2);Xf=new pg('date',3);Yf=new pg('datetime',4);Zf=new pg('email',5);$f=new pg('file',6);_f=new pg('hidden',7);ag=new pg('image',8);bg=new pg('month',9);cg=new pg(qi,10);dg=new pg('password',11);eg=new pg('radio',12);fg=new pg('range',13);gg=new pg('reset',14);hg=new pg('search',15);ig=new pg('submit',16);jg=new pg('tel',17);kg=new pg('text',18);lg=new pg('time',19);mg=new pg('url',20);ng=new pg('week',21)}
function qb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Dd(new be)}if(a.l==0&&a.m==0&&a.h==0){c&&(mb=pb(0,0,0));return pb(0,0,0)}if(b.h==xi&&b.m==0&&b.l==0){return rb(a,c)}i=false;if(b.h>>19!=0){b=Cb(b);i=true}g=xb(b);f=false;e=false;d=false;if(a.h==xi&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ob((Mb(),Ib));d=true;i=!i}else{h=Eb(a,g);i&&vb(h);c&&(mb=pb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Cb(a);d=true;i=!i}if(g!=-1){return sb(a,g,i,f,c)}if(Ab(a,b)<0){c&&(f?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h)));return pb(0,0,0)}return tb(d?a:pb(a.l,a.m,a.h),b,i,f,e,c)}
function Lg(a){var b,c;c=a.d.props['a'];b=c.a;return Df('li',Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,[b?Fi:null,(Eh(),Dh).b==a.d.props['a']?'editing':null])),[Df('div',Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,['view'])),[Df(Ei,Of(Lf(Rf(Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,['toggle'])),(og(),Vf)),b),Vd(th.prototype.P,th,[a])),null),Df('label',Tf(new $wnd.Object,Vd(uh.prototype.R,uh,[a])),[c.d]),Df(Ci,Jf(Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,['destroy'])),Vd(vh.prototype.R,vh,[a])),null)]),Df(Ei,Pf(Of(Nf(Mf(Gf(Hf(new $wnd.Object,Vd(wh.prototype.K,wh,[a])),lb(fb(uc,1),ri,2,6,['edit'])),a.b),Vd(xh.prototype.O,xh,[a])),Vd(rh.prototype.P,rh,[a])),Vd(sh.prototype.Q,sh,[a])),null)])}
var qi='number',ri={3:1,4:1},si='__noinit__',ti='__java$exception',ui={3:1,7:1,5:1},vi=4194303,wi=1048575,xi=524288,yi=17592186044416,zi=4194304,Ai=-17592186044416,Bi='children',Ci='button',Di={31:1},Ei='input',Fi='completed',Gi='active',Hi='selected',Ii='header';var _,Qd,Ld,Bd=-1;Rd();Td(1,null,{},n);_.n=function(){return this.T};_.o=Ji;_.hashCode=function(){return this.o()};var Nb,Ob,Pb;Td(32,1,{},ge);_.s=function(a){var b;b=new ge;b.e=4;a>1?(b.c=ke(this,a-1)):(b.c=this);return b};_.t=function(){ee(this);return this.b};_.u=function(){return fe(this)};_.v=function(){ee(this);return this.i};_.w=function(){return (this.e&4)!=0};_.A=function(){return (this.e&1)!=0};_.e=0;_.g=0;var de=1;var sc=ie(1);var kc=ie(32);Td(62,1,{},q);var Yb=ie(62);Td(28,1,{28:1},s);var Zb=ie(28);Td(65,1,{142:1},t);var $b=ie(65);Td(67,1,{},u);var _b=ie(67);Td(66,1,{},v);var ac=ie(66);Td(5,1,{3:1,5:1});_.p=function(a){return new Error(a)};_.q=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=fe(this.T),c==null?a:a+': '+c);A(this,B(this.p(b)));cb(this)};_.b=si;_.d=true;var vc=ie(5);Td(25,5,{3:1,5:1});var nc=ie(25);Td(7,25,ui);var tc=ie(7);Td(33,7,ui);var pc=ie(33);Td(44,33,ui);var ec=ie(44);Td(23,44,{23:1,3:1,7:1,5:1},G);_.r=function(){return Wb(this.a)===Wb(D)?null:this.a};var D;var bc=ie(23);var cc=ie(0);Td(96,1,{});var dc=ie(96);var I=0,J=0,K=-1;Td(58,96,{},Y);var U;var fc=ie(58);var ab;Td(109,1,{});var hc=ie(109);Td(45,109,{},eb);var gc=ie(45);var mb;var Ib,Jb,Kb,Lb;var $d;Td(56,7,ui,be);var ic=ie(56);Nb={3:1,22:1};var jc=ie(106);Td(107,1,{3:1});var rc=ie(107);Ob={3:1,22:1};var lc=ie(108);Td(19,1,{3:1,22:1,19:1});_.o=Ji;_.b=0;var mc=ie(19);Td(47,7,ui,qe);var oc=ie(47);Td(172,1,{});Td(55,33,ui,ue);_.p=function(a){return new TypeError(a)};var qc=ie(55);Pb={3:1,40:1,22:1,2:1};var uc=ie(2);Td(176,1,{});Td(35,7,ui,ye);var wc=ie(35);Td(110,1,{93:1});_.B=function(a){te(this,a)};_.C=function(a){throw Dd(new ye('Add not supported on this collection'))};var xc=ie(110);Td(111,110,{93:1,118:1});_.F=function(a,b){throw Dd(new ye('Add not supported on this list'))};_.C=function(a){this.F(this.D(),a);return true};_.o=function(){return Ie(this)};var yc=ie(111);Td(9,111,{3:1,9:1,93:1,118:1},Ee);_.F=function(a,b){jf(this.a,a,b)};_.C=function(a){return ze(this,a)};_.B=function(a){Ae(this,a)};_.D=function(){return this.a.length};var Ac=ie(9);Td(15,1,{},He);_.a=0;_.b=-1;var zc=ie(15);Td(70,1,{});_.I=function(a){Me(this,a)};_.G=function(){return this.d};_.H=function(){return this.e};_.d=0;_.e=0;var Cc=ie(70);Td(37,70,{});var Bc=ie(37);Td(11,1,{},Pe);_.G=function(){return this.a};_.H=function(){Oe(this);return this.c};_.I=function(a){Oe(this);Je(this.d,a)};_.J=function(a){Oe(this);if(Fe(this.d)){a.K(Ge(this.d));return true}return false};_.a=0;_.c=0;var Dc=ie(11);Td(69,1,{});_.c=false;var Mc=ie(69);Td(10,69,{141:1,10:1},Ye);var Lc=ie(10);Td(72,37,{},af);_.J=function(a){this.b=false;while(!this.b&&this.c.J(new bf(this,a)));return this.b};_.b=false;var Fc=ie(72);Td(75,1,{},bf);_.K=function(a){_e(this.a,this.b,a)};var Ec=ie(75);Td(71,37,{},cf);_.J=function(a){return this.a.J(new df(a))};var Hc=ie(71);Td(74,1,{},df);_.K=function(a){this.a.K(yh(new zh,a))};var Gc=ie(74);Td(73,1,{},ff);_.K=function(a){ef(this,a)};var Ic=ie(73);Td(76,1,{},gf);_.K=function(a){};var Jc=ie(76);Td(77,1,{},hf);_.K=function(a){$e(this.a,a)};var Kc=ie(77);Td(174,1,{});Td(115,1,{});var Nc=ie(115);Td(171,1,{});var nf=0;var pf,qf=0,rf;Td(551,1,{});Td(608,1,{});Td(112,1,{});var Oc=ie(112);Td(140,$wnd.Function,{},Ff);_.M=function(a){Ef(this.a,this.b,a)};Td(6,19,{3:1,22:1,19:1,6:1},pg);var Uf,Vf,Wf,Xf,Yf,Zf,$f,_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng;var Pc=je(6,qg);Td(121,$wnd.Function,Di,rg);_.N=Ki;Td(122,$wnd.Function,Di,sg);_.N=Ki;Td(114,112,{});var Yc=ie(114);Td(85,114,{});var ad=ie(85);Td(86,85,{},ug);_.o=Ji;var tg=0;var Rc=ie(86);Td(117,112,{});var Xc=ie(117);Td(91,117,{});var _c=ie(91);Td(92,91,{},wg);_.o=Ji;var vg=0;var Qc=ie(92);Td(82,112,{});_.a='';var jd=ie(82);Td(83,82,{});var cd=ie(83);Td(84,83,{},Cg);_.o=Ji;var Bg=0;var Sc=ie(84);Td(116,112,{});_.c=false;var ld=ie(116);Td(88,116,{});var ed=ie(88);Td(89,88,{},Og);_.o=Ji;var Ng=0;var Tc=ie(89);Td(113,112,{});var nd=ie(113);Td(60,113,{});var gd=ie(60);Td(61,60,{},Qg);_.o=Ji;var Pg=0;var Uc=ie(61);Td(147,$wnd.Function,{},Rg);_.R=function(a){Qh((Eh(),Ch))};Td(64,1,{},Sg);var Vc=ie(64);Td(87,1,{},Tg);var Wc=ie(87);Td(146,$wnd.Function,{},Ug);_.S=function(a){return new Xg(a)};var Vg;Td(79,$wnd.React.Component,{},Xg);Sd(Qd[1],_);_.render=function(){var a,b,c;return a=(Eh(),c=(b=(_d(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),we(Gi,c)||we(Fi,c)||we('',c)?we(Gi,c)?(Ih(),Fh):we(Fi,c)?(Ih(),Hh):(Ih(),Gh):(Ih(),Gh)),Df('footer',Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,['footer'])),[(new Tg).a,Df('ul',Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,['filters'])),[Df('li',null,[Df('a',If(Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,[(Ih(),Gh)==a?Hi:null])),'#'),['All'])]),Df('li',null,[Df('a',If(Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,[Fh==a?Hi:null])),'#active'),['Active'])]),Df('li',null,[Df('a',If(Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,[Hh==a?Hi:null])),'#completed'),['Completed'])])]),Rh(Ch)>0?Df(Ci,Jf(Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,['clear-completed'])),Vd(Rg.prototype.R,Rg,[])),['Clear Completed']):null])};_.shouldComponentUpdate=Li;var Zc=ie(79);Td(158,$wnd.Function,{},Yg);_.S=function(a){return new _g(a)};var Zg;Td(90,$wnd.React.Component,{},_g);Sd(Qd[1],_);_.render=function(){var a,b;return a=Jd(Te(new Ye(null,new Pe((Eh(),Ch).a)))),b='item'+(a==1?'':'s'),Df('span',Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,['todo-count'])),[Df('strong',null,[a]),' '+b+' left'])};_.shouldComponentUpdate=Li;var $c=ie(90);Td(143,$wnd.Function,{},ah);_.S=function(a){return new eh(a)};var bh;Td(68,$wnd.React.Component,{},eh);Sd(Qd[1],_);_.render=function(){return zg(this.a)};_.shouldComponentUpdate=Li;var bd=ie(68);Td(148,$wnd.Function,{},fh);_.S=function(a){return new ih(a)};var gh;Td(81,$wnd.React.Component,{},ih);Sd(Qd[1],_);_.componentDidUpdate=function(a){Kg(this.a)};_.render=function(){return Lg(this.a)};_.shouldComponentUpdate=Li;var dd=ie(81);Td(138,$wnd.Function,{},jh);_.S=function(a){return new mh(a)};var kh;Td(59,$wnd.React.Component,{},mh);Sd(Qd[1],_);_.render=function(){var a,b;return Df('div',null,[Df('div',null,[Df(Ii,Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,[Ii])),[Df('h1',null,['todos']),(new ph).a]),0!=Jd(Te(new Ye(null,new Pe((Eh(),Ch).a))))?Df('section',Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,[Ii])),[Df(Ei,Of(Rf(Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,['toggle-all'])),(og(),Vf)),Vd(Ah.prototype.P,Ah,[])),null),Df('ul',Gf(new $wnd.Object,lb(fb(uc,1),ri,2,6,['todo-list'])),(a=Xe(Le(We(new Ye(null,new Pe(di(Dh))))),(b=new Ee,b)),De(a,kb(a.a.length))))]):null,0!=Jd(Te(new Ye(null,new Pe(Ch.a))))?(new Sg).a:null])])};_.shouldComponentUpdate=Li;var fd=ie(59);Td(144,$wnd.Function,{},nh);_.Q=function(a){yg(this.a,a)};Td(145,$wnd.Function,{},oh);_.P=function(a){xg(this.a,a)};Td(63,1,{},ph);var hd=ie(63);Td(157,$wnd.Function,Di,qh);_.N=function(){this.a.d.forceUpdate()};Td(155,$wnd.Function,{},rh);_.P=function(a){Dg(this.a,a)};Td(156,$wnd.Function,{},sh);_.Q=function(a){Eg(this.a,a)};Td(149,$wnd.Function,{},th);_.P=function(a){Jg(this.a)};Td(151,$wnd.Function,{},uh);_.R=function(a){Hg(this.a)};Td(152,$wnd.Function,{},vh);_.R=function(a){Gg(this.a)};Td(153,$wnd.Function,{},wh);_.K=function(a){Fg(this.a,a)};Td(154,$wnd.Function,{},xh);_.O=function(a){Ig(this.a)};Td(80,1,{},zh);var kd=ie(80);Td(139,$wnd.Function,{},Ah);_.P=function(a){var b;b=a.target;Xh((Eh(),Ch),b.checked)};Td(24,1,{},Bh);var md=ie(24);var Ch,Dh;Td(20,19,{3:1,22:1,19:1,20:1},Jh);var Fh,Gh,Hh;var od=je(20,Kh);Td(36,1,{36:1},Nh);_.a=false;var wd=ie(36);Td(27,1,{},Oh);_.K=Mi;var pd=ie(27);Td(34,1,{34:1},Yh);var vd=ie(34);Td(50,1,{},$h);_.L=function(a){return a.a};var qd=ie(50);Td(51,1,{},_h);_.K=function(a){Th(this.a,a)};var rd=ie(51);Td(18,1,{},ai);_.K=Mi;var sd=ie(18);Td(48,1,{},bi);_.L=function(a){return !a.a};var td=ie(48);Td(49,1,{},ci);_.K=function(a){Zh(this.a,a)};_.a=false;var ud=ie(49);Td(52,1,{},ji);var Ad=ie(52);Td(53,1,{},li);_.handleEvent=function(a){ei(this.a,a)};var xd=ie(53);Td(127,$wnd.Function,Di,mi);_.N=function(){ii(this.a)};Td(26,1,{},ni);_.K=Mi;var yd=ie(26);Td(54,1,{},oi);_.L=function(a){return ki(this.a,a)};var zd=ie(54);var pi=(L(),O);var gwtOnLoad=gwtOnLoad=Od;Md(Zd);Pd('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();