function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='CBB22FFB8624886154DC938065FDFFBA',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'CBB22FFB8624886154DC938065FDFFBA';function n(){}
function s(){}
function Y(){}
function Yg(){}
function yg(){}
function zg(){}
function _g(){}
function be(){}
function Zd(){}
function eb(){}
function eh(){}
function ih(){}
function mh(){}
function qh(){}
function Hh(){}
function Vh(){}
function nf(){}
function of(){}
function fi(){}
function hi(){}
function ii(){}
function ti(){}
function cb(a){bb()}
function v(a){Se(a)}
function Si(a){a.p()}
function mf(a,b){a.a=b}
function lf(a){this.a=a}
function pf(a){this.a=a}
function uh(a){this.a=a}
function vh(a){this.a=a}
function xh(a){this.a=a}
function yh(a){this.a=a}
function zh(a){this.a=a}
function Ah(a){this.a=a}
function Bh(a){this.a=a}
function Ch(a){this.a=a}
function Dh(a){this.a=a}
function Eh(a){this.a=a}
function gi(a){this.a=a}
function ji(a){this.a=a}
function ri(a){this.a=a}
function si(a){this.a=a}
function ui(a){this.a=a}
function Oe(a){this.c=a}
function he(){he=Zd}
function u(){new Le}
function r(){r=Zd;new q}
function F(){F=Zd;D=new n}
function V(){V=Zd;U=new Y}
function L(){L=Zd;!!(bb(),ab)}
function Ef(a,b){Df(a,b)}
function Th(a,b){Ge(a.c,b)}
function ai(a,b){Ge(a.b,b)}
function ni(a,b){Ge(a.a,b)}
function Fe(a,b,c){qf(a.a,b,c)}
function Ff(a,b){a.key=b}
function rf(a,b){a.splice(b,1)}
function fb(a,b){return qe(a,b)}
function Mg(a,b){return a.a=b}
function Ce(a,b){return a===b}
function Id(a){return a.b}
function Ri(a){return false}
function Pi(){return vf(this)}
function Ae(){w(this);this.r()}
function ke(a){je(a);return a.k}
function ef(a,b){a.D(b);return a}
function Of(a,b){a.ref=b;return a}
function af(a,b){Xe(a);a.a.H(b)}
function ff(a,b){mf(a,ef(a.a,b))}
function Te(a,b){while(a.I(b));}
function ve(a,b){this.a=a;this.b=b}
function jf(a,b){this.a=a;this.b=b}
function Mf(a,b){this.a=a;this.b=b}
function wg(a,b){ve.call(this,a,b)}
function qf(a,b,c){a.splice(b,0,c)}
function Pf(a,b){a.href=b;return a}
function S(a){$wnd.clearTimeout(a)}
function kb(a){return new Array(a)}
function Gb(a){return a.l|a.m<<22}
function Ub(a){return typeof a===wi}
function Wb(a){return a==null?null:a}
function Sd(){Qd==null&&(Qd=[])}
function T(){I!=0&&(I=0);K=-1}
function Zg(){this.a=Gf((bh(),ah))}
function $g(){this.a=Gf((gh(),fh))}
function wh(){this.a=Gf((kh(),jh))}
function Gh(){this.a=Gf((oh(),nh))}
function Ih(){this.a=Gf((sh(),rh))}
function Bg(a){this.d=Se(a);r();++Ag}
function Dg(a){this.d=Se(a);r();++Cg}
function Jg(a){this.d=Se(a);r();++Ig}
function Xg(a){this.d=Se(a);r();++Wg}
function We(a){this.b=a;this.a=16464}
function Qh(a,b){ve.call(this,a,b)}
function Zf(a,b){a.value=b;return a}
function Uf(a,b){a.onBlur=b;return a}
function Qf(a,b){a.onClick=b;return a}
function Vf(a,b){a.onChange=b;return a}
function Sf(a,b){a.checked=b;return a}
function Sh(a,b){a.a=b;He(a.c,new Vh)}
function ei(a,b){b.a=a;He(b.c,new Vh)}
function mi(a,b){a.b=b;He(a.a,new ti)}
function ob(a){return pb(a.l,a.m,a.h)}
function Me(a){return a.a<a.c.a.length}
function Be(a,b){return a.charCodeAt(b)}
function Sb(a,b){return a!=null&&Qb(a,b)}
function pb(a,b,c){return {l:a,m:b,h:c}}
function Zh(a,b){return Ie(a.a,b,0)!=-1}
function vf(a){return a.$H||(a.$H=++uf)}
function Vb(a){return typeof a==='string'}
function Wf(a,b){a.onKeyDown=b;return a}
function Rf(a){a.autoFocus=true;return a}
function je(a){if(a.k!=null){return}se(a)}
function A(a,b){a.b=b;b!=null&&tf(b,zi,a)}
function Tg(a,b){a.b=b;a.d.forceUpdate()}
function Hg(a,b){a.a=b;a.d.forceUpdate()}
function $h(a,b){Je(a.a,b);He(a.b,new hi)}
function Df(a,b){for(var c in a){b(c)}}
function tf(b,c,d){try{b[c]=d}catch(a){}}
function df(a,b){Ze.call(this,a);this.a=b}
function C(a){this.c=a;w(this);this.r()}
function Le(){this.a=hb(tc,xi,1,0,5,1)}
function di(){this.a=new Le;this.b=new Le}
function zf(){zf=Zd;wf=new n;yf=new n}
function ee(){ee=Zd;de=$wnd.window.document}
function ge(){C.call(this,'divide by zero')}
function Lh(){Lh=Zd;Jh=new di;Kh=new pi(Jh)}
function bi(a,b){Sh(b,!b.a);He(a.b,new hi)}
function ne(a){var b;b=me(a);ue(a,b);return b}
function Tf(a,b){a.defaultValue=b;return a}
function $f(a,b){a.onDoubleClick=b;return a}
function Ge(a,b){a.a[a.a.length]=b;return true}
function w(a){a.d&&a.b!==yi&&a.r();return a}
function Ne(a){a.b=a.a++;return a.c.a[a.b]}
function Od(a){if(Ub(a)){return a|0}return Gb(a)}
function M(a,b,c){return a.apply(b,c);var d}
function Tb(a){return typeof a==='boolean'}
function jb(a){return Array.isArray(a)&&a.T===be}
function Rb(a){return !Array.isArray(a)&&a.T===be}
function bb(){bb=Zd;var a;!db();a=new eb;ab=a}
function bf(a){Ye(a);return new df(a,new kf(a.a))}
function Pd(a){if(Ub(a)){return ''+a}return Hb(a)}
function Se(a){if(a==null){throw Id(new Ae)}return a}
function pe(a){var b;b=me(a);b.j=a;b.e=1;return b}
function Z(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Eg(a,b){var c;c=b.target;Hg(a,c.value)}
function fe(a,b,c,d){a.addEventListener(b,c,d)}
function gf(a,b,c){if(a.a.K(c)){a.b=true;b.J(c)}}
function Xe(a){if(!a.b){Ye(a);a.c=true}else{Xe(a.b)}}
function Ze(a){if(!a){this.b=null;new Le}else{this.b=a}}
function q(){this.a=new t;new v(this.a);new u}
function Ng(a){$h((Lh(),Jh),a.d.props['a'])}
function Qg(a){bi((Lh(),Jh),a.d.props['a'])}
function qi(a,b){return (Ph(),Nh)==a||(Mh==a?!b.a:b.a)}
function Re(a,b){return Wb(a)===Wb(b)||!!a&&Wb(a)===Wb(b)}
function Ue(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Yf(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function oe(a,b){var c;c=me(a);ue(a,c);c.e=b?8:0;return c}
function Ve(a){if(!a.d){a.d=new Oe(a.b);a.c=a.b.a.length}}
function _e(a,b){Ye(a);return new df(a,new hf(b,a.a))}
function _h(a,b,c){b.d=Se(c);He(b.c,new Vh);He(a.b,new hi)}
function Rh(){Ph();return lb(fb(sd,1),xi,21,0,[Mh,Oh,Nh])}
function gh(){gh=Zd;var a;fh=(a=$d(eh.prototype.Q,eh,[]),a)}
function kh(){kh=Zd;var a;jh=(a=$d(ih.prototype.Q,ih,[]),a)}
function oh(){oh=Zd;var a;nh=(a=$d(mh.prototype.Q,mh,[]),a)}
function sh(){sh=Zd;var a;rh=(a=$d(qh.prototype.Q,qh,[]),a)}
function bh(){bh=Zd;var a;ah=(a=$d(_g.prototype.Q,_g,[]),a)}
function _d(a){function b(){}
;b.prototype=a||{};return new b}
function re(a){if(a.B()){return null}var b=a.j;return Vd[b]}
function Ye(a){if(a.b){Ye(a.b)}else if(a.c){throw Id(new we)}}
function R(a){L();$wnd.setTimeout(function(){throw a},0)}
function kf(a){Ue.call(this,a.G(),a.F()&-6);this.a=a}
function Cf(){if(xf==256){wf=yf;yf=new n;xf=0}++xf}
function Q(a){a&&X((V(),U));--I;if(a){if(K!=-1){S(K);K=-1}}}
function dh(a){$wnd.React.Component.call(this,a);new Bg(this)}
function hh(a){$wnd.React.Component.call(this,a);new Dg(this)}
function th(a){$wnd.React.Component.call(this,a);new Xg(this)}
function Xf(a){a.placeholder='What needs to be done?';return a}
function Fh(a,b){Ff(a.a,b.b);Se(b);a.a.props['a']=b;return a.a}
function qe(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.t(b))}
function P(a,b,c){var d;d=N();try{return M(a,b,c)}finally{Q(d)}}
function Xd(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Lf(a,b,c){!Ce(c,'key')&&!Ce(c,'ref')&&(a[c]=b[c],undefined)}
function hf(a,b){Ue.call(this,b.G(),b.F()&-16449);this.a=a;this.c=b}
function Uh(a,b){this.c=new Le;this.b=Se(a);this.d=Se(b);this.a=false}
function lh(a){$wnd.React.Component.call(this,a);this.a=new Jg(this)}
function ph(a){$wnd.React.Component.call(this,a);this.a=new Vg(this)}
function oi(a){var b;b=a.b;!!b&&!Zh(a.c,b)&&(a.b=null,He(a.a,new ti))}
function ci(a,b){af(new df(null,new We(a.a)),new ji(b));He(a.b,new hi)}
function Wh(a,b){Ge(a.a,new Uh(''+Pd(Ld(Date.now())),b));He(a.b,new hi)}
function cf(a,b){var c;Xe(a);c=new nf;c.a=b;a.a.H(new pf(c));return c.a}
function $e(a){var b;Xe(a);b=0;while(a.a.I(new of)){b=Jd(b,1)}return b}
function B(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ee(){C.call(this,'Add not supported on this collection')}
function O(b){L();return function(){return P(b,this,arguments);var a}}
function H(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Xb(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Qe(a,b){while(a.a<a.c.a.length){b.J((a.b=a.a++,a.c.a[a.b]))}}
function Ie(a,b,c){for(;c<a.a.length;++c){if(Re(b,a.a[c])){return c}}return -1}
function Je(a,b){var c;c=Ie(a,b,0);if(c==-1){return false}rf(a.a,c);return true}
function hb(a,b,c,d,e,f){var g;g=ib(e,d);e!=10&&lb(fb(a,f),b,c,e,g);return g}
function nb(a){var b,c,d;b=a&Bi;c=a>>22&Bi;d=a<0?Ci:0;return pb(b,c,d)}
function He(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.J(c)}}
function t(){var a;this.a=hb($b,xi,29,5,0,1);for(a=0;a<5;a++){this.a[a]=new s}}
function W(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=$(b,c)}while(a.a);a.a=c}}
function X(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=$(b,c)}while(a.b);a.b=c}}
function Kg(a,b){var c;if((Lh(),Kh).b==a.d.props['a']){c=b.target;Tg(a,c.value)}}
function Og(a){mi((Lh(),Kh),a.d.props['a']);a.b=a.d.props['a'].d;a.d.forceUpdate()}
function gb(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function sf(a,b){return gb(b)!=10&&lb(o(b),b.S,b.__elementTypeId$,gb(b),a),a}
function Jf(a){var b;return Hf($wnd.React.StrictMode,null,null,(b={},b[Hi]=Se(a),b))}
function Xh(a){var b;cf(_e(new df(null,new We(a.a)),new fi),(b=new Le,b)).C(new gi(a))}
function Hd(a){var b;if(Sb(a,5)){return a}b=a&&a[zi];if(!b){b=new G(a);cb(b)}return b}
function ue(a,b){var c;if(!a){return}b.j=a;var d=re(b);if(!d){Vd[a]=[b];return}d.R=b}
function ye(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function Kd(a){var b;b=a.h;if(b==0){return a.l+a.m*Fi}if(b==Ci){return a.l+a.m*Fi-Ei}return a}
function $d(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Hf(a,b,c,d){var e;e=If($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Se(d);return e}
function Gf(a){var b;b=If($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function me(a){var b;b=new le;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Nd(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Ei;d=Ci}c=Xb(e/Fi);b=Xb(e-c*Fi);return pb(b,c,d)}
function Mb(){Mb=Zd;Ib=pb(Bi,Bi,524287);Jb=pb(0,0,Di);Kb=nb(1);nb(2);Lb=nb(0)}
function Ph(){Ph=Zd;Mh=new Qh('ACTIVE',0);Oh=new Qh('COMPLETED',1);Nh=new Qh('ALL',2)}
function Qi(){$wnd.ReactDOM.render(Jf([(new Ih).a]),(ee(),de).getElementById('app'),null)}
function we(){C.call(this,"Stream already terminated, can't be modified or used")}
function Rd(){Sd();var a=Qd;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ze(a,b){var c,d;for(d=new Oe(a);d.a<d.c.a.length;){c=(d.b=d.a++,d.c.a[d.b]);$h(b.a,c)}}
function zb(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return pb(c&Bi,d&Bi,e&Ci)}
function Fb(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return pb(c&Bi,d&Bi,e&Ci)}
function Cb(a){var b,c,d;b=~a.l+1&Bi;c=~a.m+(b==0?1:0)&Bi;d=~a.h+(b==0&&c==0?1:0)&Ci;return pb(b,c,d)}
function vb(a){var b,c,d;b=~a.l+1&Bi;c=~a.m+(b==0?1:0)&Bi;d=~a.h+(b==0&&c==0?1:0)&Ci;a.l=b;a.m=c;a.h=d}
function wb(a){var b,c;c=xe(a.h);if(c==32){b=xe(a.m);return b==32?xe(a.l)+32:b+20-10}else{return c-12}}
function sb(a,b,c,d,e){var f;f=Eb(a,b);c&&vb(f);if(e){a=ub(a,b);d?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h))}return f}
function lb(a,b,c,d,e){e.R=a;e.S=b;e.T=be;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ud(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function G(a){F();w(this);this.b=a;a!=null&&tf(a,zi,this);this.c=a==null?'null':ae(a);this.a=a}
function le(){this.g=ie++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Vg(a){this.d=Se(a);r();++Ug;this.b=this.d.props['a'].d;Th(this.d.props['a'],new xh(this))}
function Lg(a,b){27==b.which?(mi((Lh(),Kh),null),a.b=a.d.props['a'].d,a.d.forceUpdate()):13==b.which&&Pg(a)}
function Ld(a){if(Gi<a&&a<Ei){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return Kd(Bb(a))}
function ae(a){var b;if(Array.isArray(a)&&a.T===be){return ke(o(a))+'@'+(b=p(a)>>>0,b.toString(16))}return a.toString()}
function rb(a,b){if(a.h==Di&&a.m==0&&a.l==0){b&&(mb=pb(0,0,0));return ob((Mb(),Kb))}b&&(mb=pb(a.l,a.m,a.h));return pb(0,0,0)}
function Jd(a,b){var c;if(Ub(a)&&Ub(b)){c=a+b;if(Gi<c&&c<Ei){return c}}return Kd(zb(Ub(a)?Nd(a):a,Ub(b)?Nd(b):b))}
function o(a){return Vb(a)?vc:Ub(a)?mc:Tb(a)?kc:Rb(a)?a.R:jb(a)?a.R:a.R||Array.isArray(a)&&fb(dc,1)||dc}
function p(a){return Vb(a)?Bf(a):Ub(a)?Xb(a):Tb(a)?a?1231:1237:Rb(a)?a.o():jb(a)?vf(a):!!a&&!!a.hashCode?a.hashCode():vf(a)}
function Yh(a){return Od($e(new df(null,new We(a.a))))-Od($e(_e(new df(null,new We(a.a)),new ii)))}
function pi(a){this.a=new Le;this.c=Se(a);fe((ee(),$wnd.window.window),'hashchange',new ri(this),false);ai(a,new si(this))}
function ce(){ai((Lh(),Jh),new yg);ni(Kh,new zg);$wnd.ReactDOM.render(Jf([(new Ih).a]),(ee(),de).getElementById('app'),null)}
function N(){var a;if(I!=0){a=H();if(a-J>2000){J=a;K=$wnd.setTimeout(T,10)}}if(I++==0){W((V(),U));return true}return false}
function Fg(a,b){var c;if(13==b.keyCode){b.preventDefault();c=De(a.a);if(c.length>0){Wh((Lh(),Jh),c);a.a='';a.d.forceUpdate()}}}
function te(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ke(a,b){var c,d;d=a.a.length;b.length<d&&(b=sf(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Pe(a){var b,c,d;d=1;for(c=new Oe(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?p(b):0);d=d|0}return d}
function Bf(a){zf();var b,c,d;c=':'+a;d=yf[c];if(d!=null){return Xb(d)}d=wf[c];b=d==null?Af(a):Xb(d);Cf();yf[c]=b;return b}
function Nf(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function xg(){vg();return lb(fb(Qc,1),xi,6,0,[_f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg,rg,sg,tg,ug])}
function db(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Pg(a){if(null!=a.b&&a.b.length!=0){_h((Lh(),Jh),a.d.props['a'],a.b);mi(Kh,null);Tg(a,a.b)}else{$h((Lh(),Jh),a.d.props['a'])}}
function Qb(a,b){if(Vb(a)){return !!Pb[b]}else if(a.S){return !!a.S[b]}else if(Ub(a)){return !!Ob[b]}else if(Tb(a)){return !!Nb[b]}return false}
function De(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ub(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return pb(c,d,e)}
function Db(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return pb(c&Bi,d&Bi,e&Ci)}
function ib(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function yb(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&Bi;a.m=d&Bi;a.h=e&Ci;return true}
function Rg(a){var b;b=(Lh(),Kh).b==a.d.props['a'];if(!a.c&&b){a.c=true;a.a.focus();a.a.select();a.b=a.d.props['a'].d;a.d.forceUpdate()}else a.c&&!b&&(a.c=false)}
function Gg(a){return Kf(Ki,Rf(Vf(Wf(Zf(Xf(Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,['new-todo']))),a.a),$d(uh.prototype.O,uh,[a])),$d(vh.prototype.N,vh,[a]))),null)}
function Ab(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Td(b,c,d,e){Sd();var f=Qd;$moduleName=c;$moduleBase=d;Gd=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{vi(g)()}catch(a){b(c,a)}}else{vi(g)()}}
function If(a,b){var c;c=new $wnd.Object;c.$$typeof=Se(a);c.type=Se(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function $(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].U()&&(c=Z(c,g)):g[0].U()}catch(a){a=Hd(a);if(Sb(a,5)){d=a;L();R(Sb(d,24)?d.s():d)}else throw Id(a)}}return c}
function Wd(){Vd={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Af(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Be(a,c++)}b=b|0;return b}
function ki(a){var b,c,d,e;b=(e=(c=(ee(),$wnd.window.window).location.hash,null==c?'':c.substr(1)),Ce(Li,e)?(Ph(),Mh):Ce(Mi,e)?(Ph(),Oh):(Ph(),Nh));return cf(_e(new df(null,new We(a.c.a)),new ui(b)),(d=new Le,d))}
function xe(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Yd(a,b,c){var d=Vd,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Vd[b]),_d(h));_.S=c;!b&&(_.T=be);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.R=f)}
function Eb(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&Di)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?Ci:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?Ci:0;f=d?Bi:0;e=c>>b-44}return pb(e&Bi,f&Bi,g&Ci)}
function se(a){if(a.A()){var b=a.c;b.B()?(a.k='['+b.j):!b.A()?(a.k='[L'+b.v()+';'):(a.k='['+b.v());a.b=b.u()+'[]';a.i=b.w()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=te('.',[c,te('$',d)]);a.b=te('.',[c,te('.',d)]);a.i=d[d.length-1]}
function Kf(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Ef(b,$d(Mf.prototype.L,Mf,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Hi]=c[0],undefined):(d[Hi]=c,undefined));return Hf(a,e,f,d)}
function xb(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return ye(c)}if(b==0&&d!=0&&c==0){return ye(d)+22}if(b!=0&&d==0&&c==0){return ye(b)+44}return -1}
function Bb(a){var b,c,d,e,f;if(isNaN(a)){return Mb(),Lb}if(a<-9223372036854775808){return Mb(),Jb}if(a>=9223372036854775807){return Mb(),Ib}e=false;if(a<0){e=true;a=-a}d=0;if(a>=Ei){d=Xb(a/Ei);a-=d*Ei}c=0;if(a>=Fi){c=Xb(a/Fi);a-=c*Fi}b=Xb(a);f=pb(b,c,d);e&&vb(f);return f}
function li(a,b){var c,d,e;b.preventDefault();c=(d=(ee(),$wnd.window.window).location.hash,null==d?'':d.substr(1));if(Ce(Li,c)||Ce(Mi,c)||Ce('',c)){He(a.a,new ti)}else{e=$wnd.window.window.location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',de.title,e)}}
function Hb(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==Di&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Hb(Cb(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=nb(1000000000);c=qb(c,e,true);b=''+Gb(mb);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function tb(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=wb(b)-wb(a);g=Db(b,j);i=pb(0,0,0);while(j>=0){h=yb(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&vb(i);if(f){if(d){mb=Cb(a);e&&(mb=Fb(mb,(Mb(),Kb)))}else{mb=pb(a.l,a.m,a.h)}}return i}
function vg(){vg=Zd;_f=new wg(Ii,0);ag=new wg('checkbox',1);bg=new wg('color',2);cg=new wg('date',3);dg=new wg('datetime',4);eg=new wg('email',5);fg=new wg('file',6);gg=new wg('hidden',7);hg=new wg('image',8);ig=new wg('month',9);jg=new wg(wi,10);kg=new wg('password',11);lg=new wg('radio',12);mg=new wg('range',13);ng=new wg('reset',14);og=new wg('search',15);pg=new wg('submit',16);qg=new wg('tel',17);rg=new wg('text',18);sg=new wg('time',19);tg=new wg('url',20);ug=new wg('week',21)}
function qb(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw Id(new ge)}if(a.l==0&&a.m==0&&a.h==0){c&&(mb=pb(0,0,0));return pb(0,0,0)}if(b.h==Di&&b.m==0&&b.l==0){return rb(a,c)}i=false;if(b.h>>19!=0){b=Cb(b);i=true}g=xb(b);f=false;e=false;d=false;if(a.h==Di&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=ob((Mb(),Ib));d=true;i=!i}else{h=Eb(a,g);i&&vb(h);c&&(mb=pb(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Cb(a);d=true;i=!i}if(g!=-1){return sb(a,g,i,f,c)}if(Ab(a,b)<0){c&&(f?(mb=Cb(a)):(mb=pb(a.l,a.m,a.h)));return pb(0,0,0)}return tb(d?a:pb(a.l,a.m,a.h),b,i,f,e,c)}
function Sg(a){var b,c;c=a.d.props['a'];b=c.a;return Kf('li',Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,[b?'checked':null,(Lh(),Kh).b==a.d.props['a']?'editing':null])),[Kf('div',Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,['view'])),[Kf(Ki,Vf(Sf(Yf(Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,['toggle'])),(vg(),ag)),b),$d(Ah.prototype.N,Ah,[a])),null),Kf('label',$f(new $wnd.Object,$d(Bh.prototype.P,Bh,[a])),[c.d]),Kf(Ii,Qf(Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,['destroy'])),$d(Ch.prototype.P,Ch,[a])),null)]),Kf(Ki,Wf(Vf(Uf(Tf(Nf(Of(new $wnd.Object,$d(Dh.prototype.J,Dh,[a])),lb(fb(vc,1),xi,2,6,['edit'])),a.b),$d(Eh.prototype.M,Eh,[a])),$d(yh.prototype.N,yh,[a])),$d(zh.prototype.O,zh,[a])),null)])}
var wi='number',xi={3:1,4:1},yi='__noinit__',zi='__java$exception',Ai={3:1,7:1,5:1},Bi=4194303,Ci=1048575,Di=524288,Ei=17592186044416,Fi=4194304,Gi=-17592186044416,Hi='children',Ii='button',Ji={34:1},Ki='input',Li='active',Mi='completed',Ni='selected',Oi='header';var _,Vd,Qd,Gd=-1;Wd();Yd(1,null,{},n);_.n=function(){return this.R};_.o=Pi;_.hashCode=function(){return this.o()};var Nb,Ob,Pb;Yd(35,1,{},le);_.t=function(a){var b;b=new le;b.e=4;a>1?(b.c=qe(this,a-1)):(b.c=this);return b};_.u=function(){je(this);return this.b};_.v=function(){return ke(this)};_.w=function(){je(this);return this.i};_.A=function(){return (this.e&4)!=0};_.B=function(){return (this.e&1)!=0};_.e=0;_.g=0;var ie=1;var tc=ne(1);var lc=ne(35);Yd(68,1,{},q);var Zb=ne(68);Yd(825,1,{});Yd(29,1,{29:1},s);var $b=ne(29);Yd(71,1,{148:1},t);var _b=ne(71);Yd(73,1,{},u);var ac=ne(73);Yd(72,1,{},v);var bc=ne(72);Yd(5,1,{3:1,5:1});_.q=function(a){return new Error(a)};_.r=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=ke(this.R),c==null?a:a+': '+c);A(this,B(this.q(b)));cb(this)};_.b=yi;_.d=true;var wc=ne(5);Yd(26,5,{3:1,5:1});var oc=ne(26);Yd(7,26,Ai);var uc=ne(7);Yd(36,7,Ai);var qc=ne(36);Yd(48,36,Ai);var fc=ne(48);Yd(24,48,{24:1,3:1,7:1,5:1},G);_.s=function(){return Wb(this.a)===Wb(D)?null:this.a};var D;var cc=ne(24);var dc=ne(0);Yd(103,1,{});var ec=ne(103);var I=0,J=0,K=-1;Yd(64,103,{},Y);var U;var gc=ne(64);var ab;Yd(116,1,{});var ic=ne(116);Yd(49,116,{},eb);var hc=ne(49);var mb;var Ib,Jb,Kb,Lb;var de;Yd(62,7,Ai,ge);var jc=ne(62);Nb={3:1,23:1};var kc=ne(113);Yd(114,1,{3:1});var sc=ne(114);Ob={3:1,23:1};var mc=ne(115);Yd(20,1,{3:1,23:1,20:1});_.o=Pi;_.b=0;var nc=ne(20);Yd(51,7,Ai,we);var pc=ne(51);Yd(177,1,{});Yd(61,36,Ai,Ae);_.q=function(a){return new TypeError(a)};var rc=ne(61);Pb={3:1,44:1,23:1,2:1};var vc=ne(2);Yd(181,1,{});Yd(60,7,Ai,Ee);var xc=ne(60);Yd(117,1,{100:1});_.C=function(a){ze(this,a)};_.D=function(a){throw Id(new Ee)};var yc=ne(117);Yd(118,117,{100:1,125:1});_.D=function(a){Fe(this,this.a.length,a);return true};_.o=function(){return Pe(this)};var zc=ne(118);Yd(10,118,{3:1,10:1,100:1,125:1},Le);_.D=function(a){return Ge(this,a)};_.C=function(a){He(this,a)};var Bc=ne(10);Yd(16,1,{},Oe);_.a=0;_.b=-1;var Ac=ne(16);Yd(76,1,{});_.H=function(a){Te(this,a)};_.F=function(){return this.d};_.G=function(){return this.e};_.d=0;_.e=0;var Dc=ne(76);Yd(39,76,{});var Cc=ne(39);Yd(13,1,{},We);_.F=function(){return this.a};_.G=function(){Ve(this);return this.c};_.H=function(a){Ve(this);Qe(this.d,a)};_.I=function(a){Ve(this);if(Me(this.d)){a.J(Ne(this.d));return true}return false};_.a=0;_.c=0;var Ec=ne(13);Yd(75,1,{});_.c=false;var Nc=ne(75);Yd(11,75,{147:1,11:1},df);var Mc=ne(11);Yd(78,39,{},hf);_.I=function(a){this.b=false;while(!this.b&&this.c.I(new jf(this,a)));return this.b};_.b=false;var Gc=ne(78);Yd(81,1,{},jf);_.J=function(a){gf(this.a,this.b,a)};var Fc=ne(81);Yd(77,39,{},kf);_.I=function(a){return this.a.I(new lf(a))};var Ic=ne(77);Yd(80,1,{},lf);_.J=function(a){this.a.J(Fh(new Gh,a))};var Hc=ne(80);Yd(79,1,{},nf);_.J=function(a){mf(this,a)};var Jc=ne(79);Yd(82,1,{},of);_.J=function(a){};var Kc=ne(82);Yd(83,1,{},pf);_.J=function(a){ff(this.a,a)};var Lc=ne(83);Yd(179,1,{});Yd(122,1,{});var Oc=ne(122);Yd(176,1,{});var uf=0;var wf,xf=0,yf;Yd(624,1,{});Yd(780,1,{});Yd(119,1,{});var Pc=ne(119);Yd(146,$wnd.Function,{},Mf);_.L=function(a){Lf(this.a,this.b,a)};Yd(6,20,{3:1,23:1,20:1,6:1},wg);var _f,ag,bg,cg,dg,eg,fg,gg,hg,ig,jg,kg,lg,mg,ng,og,pg,qg,rg,sg,tg,ug;var Qc=oe(6,xg);Yd(42,1,Ji,yg);_.p=Qi;var Rc=ne(42);Yd(43,1,Ji,zg);_.p=Qi;var Sc=ne(43);Yd(121,119,{});var _c=ne(121);Yd(92,121,{});var dd=ne(92);Yd(93,92,{},Bg);_.o=Pi;var Ag=0;var Uc=ne(93);Yd(124,119,{});var $c=ne(124);Yd(98,124,{});var cd=ne(98);Yd(99,98,{},Dg);_.o=Pi;var Cg=0;var Tc=ne(99);Yd(89,119,{});_.a='';var md=ne(89);Yd(90,89,{});var fd=ne(90);Yd(91,90,{},Jg);_.o=Pi;var Ig=0;var Vc=ne(91);Yd(123,119,{});_.c=false;var pd=ne(123);Yd(95,123,{});var hd=ne(95);Yd(96,95,{},Vg);_.o=Pi;var Ug=0;var Wc=ne(96);Yd(120,119,{});var rd=ne(120);Yd(66,120,{});var kd=ne(66);Yd(67,66,{},Xg);_.o=Pi;var Wg=0;var Xc=ne(67);Yd(153,$wnd.Function,{},Yg);_.P=function(a){Xh((Lh(),Jh))};Yd(70,1,{},Zg);var Yc=ne(70);Yd(94,1,{},$g);var Zc=ne(94);Yd(152,$wnd.Function,{},_g);_.Q=function(a){return new dh(a)};var ah;Yd(85,$wnd.React.Component,{},dh);Xd(Vd[1],_);_.render=function(){var a,b,c;return a=(c=(Lh(),b=(ee(),$wnd.window.window).location.hash,null==b?'':b.substr(1)),Ce(Li,c)?(Ph(),Mh):Ce(Mi,c)?(Ph(),Oh):(Ph(),Nh)),Kf('footer',Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,['footer'])),[(new $g).a,Kf('ul',Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,['filters'])),[Kf('li',null,[Kf('a',Pf(Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,[(Ph(),Nh)==a?Ni:null])),'#'),['All'])]),Kf('li',null,[Kf('a',Pf(Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,[Mh==a?Ni:null])),'#active'),['Active'])]),Kf('li',null,[Kf('a',Pf(Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,[Oh==a?Ni:null])),'#completed'),['Completed'])])]),Yh(Jh)>0?Kf(Ii,Qf(Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,['clear-completed'])),$d(Yg.prototype.P,Yg,[])),['Clear Completed']):null])};_.shouldComponentUpdate=Ri;var ad=ne(85);Yd(163,$wnd.Function,{},eh);_.Q=function(a){return new hh(a)};var fh;Yd(97,$wnd.React.Component,{},hh);Xd(Vd[1],_);_.render=function(){var a,b;return a=Od($e(new df(null,new We((Lh(),Jh).a)))),b='item'+(a==1?'':'s'),Kf('span',Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,['todo-count'])),[Kf('strong',null,[a]),' '+b+' left'])};_.shouldComponentUpdate=Ri;var bd=ne(97);Yd(149,$wnd.Function,{},ih);_.Q=function(a){return new lh(a)};var jh;Yd(74,$wnd.React.Component,{},lh);Xd(Vd[1],_);_.render=function(){return Gg(this.a)};_.shouldComponentUpdate=Ri;var ed=ne(74);Yd(154,$wnd.Function,{},mh);_.Q=function(a){return new ph(a)};var nh;Yd(87,$wnd.React.Component,{},ph);Xd(Vd[1],_);_.componentDidUpdate=function(a){Rg(this.a)};_.render=function(){return Sg(this.a)};_.shouldComponentUpdate=Ri;var gd=ne(87);Yd(144,$wnd.Function,{},qh);_.Q=function(a){return new th(a)};var rh;Yd(65,$wnd.React.Component,{},th);Xd(Vd[1],_);_.render=function(){var a,b;return Kf('div',null,[Kf('div',null,[Kf(Oi,Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,[Oi])),[Kf('h1',null,['todos']),(new wh).a]),0!=Od($e(new df(null,new We((Lh(),Jh).a))))?Kf('section',Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,[Oi])),[Kf(Ki,Vf(Yf(Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,['toggle-all'])),(vg(),ag)),$d(Hh.prototype.N,Hh,[])),null),Kf('ul',Nf(new $wnd.Object,lb(fb(vc,1),xi,2,6,['todo-list'])),(a=cf(Se(bf(new df(null,new We(ki(Kh))))),(b=new Le,b)),Ke(a,kb(a.a.length))))]):null,0!=Od($e(new df(null,new We(Jh.a))))?(new Zg).a:null])])};_.shouldComponentUpdate=Ri;var jd=ne(65);Yd(150,$wnd.Function,{},uh);_.O=function(a){Fg(this.a,a)};Yd(151,$wnd.Function,{},vh);_.N=function(a){Eg(this.a,a)};Yd(69,1,{},wh);var ld=ne(69);Yd(88,1,Ji,xh);_.p=function(){this.a.d.forceUpdate()};var nd=ne(88);Yd(161,$wnd.Function,{},yh);_.N=function(a){Kg(this.a,a)};Yd(162,$wnd.Function,{},zh);_.O=function(a){Lg(this.a,a)};Yd(155,$wnd.Function,{},Ah);_.N=function(a){Qg(this.a)};Yd(157,$wnd.Function,{},Bh);_.P=function(a){Og(this.a)};Yd(158,$wnd.Function,{},Ch);_.P=function(a){Ng(this.a)};Yd(159,$wnd.Function,{},Dh);_.J=function(a){Mg(this.a,a)};Yd(160,$wnd.Function,{},Eh);_.M=function(a){Pg(this.a)};Yd(86,1,{},Gh);var od=ne(86);Yd(145,$wnd.Function,{},Hh);_.N=function(a){var b;b=a.target;ci((Lh(),Jh),b.checked)};Yd(25,1,{},Ih);var qd=ne(25);var Jh,Kh;Yd(21,20,{3:1,23:1,20:1,21:1},Qh);var Mh,Nh,Oh;var sd=oe(21,Rh);Yd(38,1,{38:1},Uh);_.a=false;var Ad=ne(38);Yd(28,1,{},Vh);_.J=Si;var td=ne(28);Yd(37,1,{37:1},di);var zd=ne(37);Yd(54,1,{},fi);_.K=function(a){return a.a};var ud=ne(54);Yd(55,1,{},gi);_.J=function(a){$h(this.a,a)};var vd=ne(55);Yd(19,1,{},hi);_.J=Si;var wd=ne(19);Yd(52,1,{},ii);_.K=function(a){return !a.a};var xd=ne(52);Yd(53,1,{},ji);_.J=function(a){ei(this.a,a)};_.a=false;var yd=ne(53);Yd(56,1,{},pi);var Fd=ne(56);Yd(57,1,{},ri);_.handleEvent=function(a){li(this.a,a)};var Bd=ne(57);Yd(58,1,Ji,si);_.p=function(){oi(this.a)};var Cd=ne(58);Yd(27,1,{},ti);_.J=Si;var Dd=ne(27);Yd(59,1,{},ui);_.K=function(a){return qi(this.a,a)};var Ed=ne(59);var Yb=pe('D');var vi=(L(),O);var gwtOnLoad=gwtOnLoad=Td;Rd(ce);Ud('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();