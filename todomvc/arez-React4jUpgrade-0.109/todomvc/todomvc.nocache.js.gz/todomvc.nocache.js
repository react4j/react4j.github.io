function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='48271345F71320A722DE779739AEBEDD',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '48271345F71320A722DE779739AEBEDD';function o(){}
function kh(){}
function gh(){}
function Ib(){}
function Oc(){}
function Vc(){}
function uj(){}
function vj(){}
function Zj(){}
function Zn(){}
function nn(){}
function Sk(){}
function em(){}
function hm(){}
function lm(){}
function pm(){}
function tm(){}
function xm(){}
function Pm(){}
function xo(){}
function yo(){}
function xp(){}
function Tc(a){Sc()}
function qh(){qh=gh}
function ri(){ii(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function mb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function hc(a){this.a=a}
function nc(a){this.a=a}
function Fh(a){this.a=a}
function Qh(a){this.a=a}
function Qk(a){this.a=a}
function Pk(a){this.a=a}
function Rk(a){this.a=a}
function Tk(a){this.a=a}
function Zk(a){this.a=a}
function $k(a){this.a=a}
function _k(a){this.a=a}
function ai(a){this.a=a}
function fi(a){this.a=a}
function gi(a){this.a=a}
function ei(a){this.b=a}
function ti(a){this.c=a}
function sj(a){this.a=a}
function xj(a){this.a=a}
function al(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function pl(a){this.a=a}
function Ml(a){this.a=a}
function Nl(a){this.a=a}
function Ol(a){this.a=a}
function Ul(a){this.a=a}
function Wl(a){this.a=a}
function Xl(a){this.a=a}
function am(a){this.a=a}
function bm(a){this.a=a}
function cm(a){this.a=a}
function dm(a){this.a=a}
function Bm(a){this.a=a}
function Cm(a){this.a=a}
function Em(a){this.a=a}
function Fm(a){this.a=a}
function Hm(a){this.a=a}
function Im(a){this.a=a}
function gn(a){this.a=a}
function hn(a){this.a=a}
function jn(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function Jn(a){this.a=a}
function Kn(a){this.a=a}
function Nn(a){this.a=a}
function On(a){this.a=a}
function Pn(a){this.a=a}
function Qn(a){this.a=a}
function ao(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function oo(a){this.a=a}
function po(a){this.a=a}
function qo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function tj(a,b){a.a=b}
function Tj(a,b){a.key=b}
function Oj(a,b){Nj(a,b)}
function Sn(a,b){un(b,a)}
function lp(a){Vi(this,a)}
function op(a){Jh(this,a)}
function sp(){jc(this.c)}
function tp(){jc(this.b)}
function Di(){this.a=Mi()}
function Ri(){this.a=Mi()}
function kc(a){!!a&&a.u()}
function w(a){--a.e;D(a)}
function gb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function kb(a){Yb((J(),a))}
function cc(a,b){Yh(a.b,b)}
function Rn(a,b){Cn(a.b,b)}
function wj(a,b){mj(a.a,b)}
function C(a,b){ab(a.f,b.f)}
function tb(a,b){a.b=Yi(b)}
function Lb(a){a.a=-4&a.a|1}
function Sg(a){return a.e}
function kp(){return this.a}
function np(){return this.b}
function Mh(a,b){return a===b}
function rl(a,b){return a.f=b}
function up(){jc(this.a.c)}
function vp(){jc(this.a.b)}
function qp(){this.a.k=true}
function dc(){this.b=new xi}
function J(){J=gh;I=new F}
function uc(){uc=gh;tc=new o}
function Lc(){Lc=gh;Kc=new Oc}
function Ii(){Ii=gh;Hi=Ki()}
function V(a){jd(a,8)&&a.t()}
function _m(a){R(a.a);cb(a.b)}
function Bj(a,b){a.splice(b,1)}
function ac(a,b,c){Xh(a.b,b,c)}
function Rh(a){sc.call(this,a)}
function km(a){Pj.call(this,a)}
function om(a){Pj.call(this,a)}
function sm(a){Pj.call(this,a)}
function wm(a){Pj.call(this,a)}
function Am(a){Pj.call(this,a)}
function jp(){return Fj(this)}
function wp(){return this.c.c}
function ip(a){return this===a}
function pp(){return J(),J(),I}
function Wc(a,b){return yh(a,b)}
function li(a,b){return a.a[b]}
function th(a){sh(a);return a.k}
function pn(a){cb(a.b);cb(a.a)}
function Xk(a){a.k=true;nb(a.a)}
function xl(a){Dn((Um(),Rm),a)}
function rp(){Xj(this.a,false)}
function Kh(){oc(this);this.C()}
function mp(){return $h(this.a)}
function W(a){return !!a&&a.c.i<0}
function db(a){J();Xb(a);a.e=-2}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function mj(a,b){tj(a,lj(a.a,b))}
function Zi(a,b){while(a._(b));}
function lj(a,b){a.O(b);return a}
function _j(a,b){a.ref=b;return a}
function bn(a){ib(a.b);return a.e}
function sn(a){ib(a.a);return a.d}
function fo(a){ib(a.d);return a.f}
function Mi(){Ii();return new Hi}
function _c(a){return new Array(a)}
function $h(a){return a.a.b+a.b.b}
function Oi(a,b){return a.a.get(b)}
function hi(a,b){this.a=a;this.b=b}
function ic(a,b){this.a=a;this.b=b}
function Dh(a,b){this.a=a;this.b=b}
function pj(a,b){this.a=a;this.b=b}
function Sj(a,b){this.a=a;this.b=b}
function ol(a,b){this.a=a;this.b=b}
function Pl(a,b){this.a=a;this.b=b}
function Ql(a,b){this.a=a;this.b=b}
function Rl(a,b){this.a=a;this.b=b}
function Sl(a,b){this.a=a;this.b=b}
function Tl(a,b){this.a=a;this.b=b}
function Vl(a,b){this.a=a;this.b=b}
function Jk(a,b){Dh.call(this,a,b)}
function Gm(a,b){this.a=a;this.b=b}
function Jm(a,b){this.a=a;this.b=b}
function Km(a,b){this.a=a;this.b=b}
function ak(a,b){a.href=b;return a}
function zj(a,b,c){a.splice(b,0,c)}
function v(a,b,c){s(a,new H(c),b)}
function Lm(a){return Mm(new Om,a)}
function gm(){this.a=Vj((nm(),mm))}
function fm(){this.a=Vj((jm(),im))}
function Dm(){this.a=Vj((rm(),qm))}
function Om(){this.a=Vj((vm(),um))}
function Qm(){this.a=Vj((zm(),ym))}
function Bc(){Bc=gh;!!(Sc(),Rc)}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function $g(){Yg==null&&(Yg=[])}
function vo(a,b){Dh.call(this,a,b)}
function kn(a,b){this.a=a;this.b=b}
function Ln(a,b){this.a=a;this.b=b}
function $n(a,b){this.a=a;this.b=b}
function _n(a,b){this.b=a;this.a=b}
function kk(a,b){a.value=b;return a}
function Oh(a,b){a.a+=''+b;return a}
function Zh(a){a.a=new Di;a.b=new Ri}
function cn(a){an(a,(ib(a.b),a.e))}
function tn(a){un(a,(ib(a.a),!a.d))}
function Sb(a){return !a.d?a:Sb(a.d)}
function Wh(a){return !a?null:a.X()}
function od(a){return a==null?null:a}
function Xi(a){return a!=null?r(a):0}
function ld(a){return typeof a===Eo}
function Ic(a){$wnd.clearTimeout(a)}
function ii(a){a.a=Yc(fe,Go,1,0,5,1)}
function sb(a){J();rb(a);vb(a,2,true)}
function B(a,b,c){return t(a,c,2048,b)}
function A(a,b,c){t(a,new G(b),c,null)}
function Aj(a,b){yj(b,0,a,0,b.length)}
function qj(a,b){a.v(Nm(Lm(b.c.e),b))}
function fk(a,b){a.onBlur=b;return a}
function bk(a,b){a.onClick=b;return a}
function gk(a,b){a.onChange=b;return a}
function dk(a,b){a.checked=b;return a}
function Nk(a){a.k=true;nb(a.b);R(a.a)}
function gc(a,b){ec(a,b,false);hb(a.d)}
function Nj(a,b){for(var c in a){b(c)}}
function bd(a,b,c){return {l:a,m:b,h:c}}
function Lh(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function X(a){return !(!!a&&1==(a.c&7))}
function Fj(a){return a.$H||(a.$H=++Ej)}
function nd(a){return typeof a==='string'}
function hk(a,b){a.onKeyDown=b;return a}
function ck(a){a.autoFocus=true;return a}
function fl(a){a.k=true;nb(a.a);cb(a.b)}
function ib(a){var b;Tb((J(),b=Ob,b),a)}
function Gb(a){this.d=Yi(a);this.b=100}
function lb(a){this.c=new ri;this.b=a}
function xi(){this.a=new Di;this.b=new Ri}
function Jj(){Jj=gh;Gj=new o;Ij=new o}
function P(){this.a=Yc(fe,Go,1,100,5,1)}
function sc(a){this.f=a;oc(this);this.C()}
function kj(a,b){fj.call(this,a);this.a=b}
function ek(a,b){a.defaultValue=b;return a}
function sh(a){if(a.k!=null){return}Ah(a)}
function pc(a,b){a.e=b;b!=null&&Dj(b,Oo,a)}
function Vi(a,b){while(a.T()){wj(b,a.U())}}
function Fi(a,b){var c;c=a[To];c.call(a,b)}
function u(a,b){return new yb(Yi(a),null,b)}
function Mm(a,b){return Tj(a.a,Yi(''+b)),a}
function kd(a){return typeof a==='boolean'}
function Jb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&vb(a.f,5,true)}
function Tn(a){A((J(),J(),I),new ao(a),_o)}
function dn(a){A((J(),J(),I),new ln(a),_o)}
function wn(a){A((J(),J(),I),new zn(a),_o)}
function yl(a){A((J(),J(),I),new Ul(a),_o)}
function ho(a){W((ib(a.d),a.f))&&jo(a,null)}
function Hn(a){return Gh(S(a.e).a-S(a.a).a)}
function Cc(a,b,c){return a.apply(b,c);var d}
function fc(a,b){cc(b.w(),a);jd(b,8)&&b.t()}
function $(a,b,c){Lb(Yi(c));K(a.a[b],Yi(c))}
function Dj(b,c,d){try{b[c]=d}catch(a){}}
function Nm(a,b){a.a.props['a']=b;return a.a}
function lk(a,b){a.onDoubleClick=b;return a}
function ji(a,b){a.a[a.a.length]=b;return true}
function oc(a){a.g&&a.e!==No&&a.C();return a}
function wh(a){var b;b=vh(a);Ch(a,b);return b}
function Ih(){Ih=gh;Hh=Yc(be,Go,29,256,0,1)}
function nh(){nh=gh;mh=$wnd.window.document}
function Sc(){Sc=gh;var a;!Uc();a=new Vc;Rc=a}
function Ui(a,b,c){this.a=a;this.b=b;this.c=c}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function gl(a,b){A((J(),J(),I),new ol(a,b),_o)}
function El(a,b){A((J(),J(),I),new Tl(a,b),_o)}
function Hl(a,b){A((J(),J(),I),new Rl(a,b),_o)}
function Il(a,b){A((J(),J(),I),new Ql(a,b),_o)}
function Jl(a,b){A((J(),J(),I),new Pl(a,b),_o)}
function Dn(a,b){A((J(),J(),I),new Ln(a,b),_o)}
function Wn(a,b){A((J(),J(),I),new _n(a,b),_o)}
function Xn(a,b){A((J(),J(),I),new $n(a,b),_o)}
function Fn(a){Jh(new fi(a.g),new hc(a));Zh(a.g)}
function Fb(a){while(true){if(!Eb(a)){break}}}
function Fl(a,b){return qh(),zl(a,b)?true:false}
function Ni(a,b){return !(a.a.get(b)===undefined)}
function hl(a,b){var c;c=b.target;il(a,c.value)}
function qb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function Mn(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new bb;this.a=new Gb(this.f)}
function ij(a){ej(a);return new kj(a,new rj(a.a))}
function Hb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function _i(a){if(!a.d){a.d=a.b.N();a.c=a.b.P()}}
function nj(a,b,c){if(a.a.ab(c)){a.b=true;b.v(c)}}
function ni(a,b){var c;c=a.a[b];Bj(a.a,b);return c}
function pi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ci(a){var b;b=a.a.U();a.b=bi(a);return b}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function $c(a){return Array.isArray(a)&&a.ob===kh}
function hd(a){return !Array.isArray(a)&&a.ob===kh}
function Gn(a){return qh(),0==S(a.e).a?true:false}
function bo(a){return Mh(hp,a)||Mh(bp,a)||Mh('',a)}
function _h(a,b){if(b){return Uh(a.a,b)}return false}
function Yi(a){if(a==null){throw Sg(new Kh)}return a}
function Mj(){if(Hj==256){Gj=Ij;Ij=new o;Hj=0}++Hj}
function dj(a){if(!a.b){ej(a);a.c=true}else{dj(a.b)}}
function eo(a){nb(a.e);nb(a.a);R(a.b);R(a.c);cb(a.d)}
function il(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.b)}}
function un(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function Kl(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function Cl(a){a.k=true;nb(a.b);R(a.d);cb(a.c);cb(a.a)}
function rj(a){$i.call(this,a.$(),a.Z()&-6);this.a=a}
function fj(a){if(!a){this.b=null;new ri}else{this.b=a}}
function hj(a,b){ej(a);return new kj(a,new oj(b,a.a))}
function an(a,b){A((J(),J(),I),new kn(a,b),75497472)}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function $i(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function aj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function jk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Vk(a){var b;a.j=false;Yj(a);b=Uk();return b}
function xh(a,b){var c;c=vh(a);Ch(a,c);c.e=b?8:0;return c}
function en(a,b){var c;c=a.e;if(b!=c){a.e=Yi(b);hb(a.b)}}
function $m(a){var b;T(a.a);b=S(a.a);Mh(a.f,b)&&en(a,b)}
function jb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function ob(a){C((J(),J(),I),a);0==(a.f.a&Ko)&&D((null,I))}
function Cn(a,b){return t((J(),J(),I),new Mn(a,b),_o,null)}
function wi(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function wo(){uo();return ad(Wc(Gg,1),Go,33,0,[ro,to,so])}
function Wm(a){oh((nh(),$wnd.window.window),ep,a.d,false)}
function Xm(a){ph((nh(),$wnd.window.window),ep,a.d,false)}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function lc(a){kc(a.g);V(a.c);V(a.a);V(a.d);kc(a.b);kc(a.f)}
function Pb(a){if(a.e){2==(a.e.c&7)||vb(a.e,4,true);rb(a.e)}}
function zh(a){if(a.L()){return null}var b=a.j;return bh[b]}
function Xg(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function qc(a,b){var c;c=th(a.mb);return b==null?c:c+': '+b}
function Vj(a){var b;b=Uj(a);b.props={};b.ref=null;return b}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function ql(a,b){var c;if(S(a.d)){c=b.target;Kl(a,c.value)}}
function Un(a,b){var c;jj(En(a.b),(c=new ri,c)).M(new Ao(b))}
function Um(){Um=gh;Rm=new In;Sm=new Yn(Rm);Tm=new ko(Rm)}
function jm(){jm=gh;var a;im=(a=hh(hm.prototype.eb,hm,[]),a)}
function nm(){nm=gh;var a;mm=(a=hh(lm.prototype.eb,lm,[]),a)}
function rm(){rm=gh;var a;qm=(a=hh(pm.prototype.eb,pm,[]),a)}
function vm(){vm=gh;var a;um=(a=hh(tm.prototype.eb,tm,[]),a)}
function zm(){zm=gh;var a;ym=(a=hh(xm.prototype.eb,xm,[]),a)}
function ih(a){function b(){}
;b.prototype=a||{};return new b}
function ik(a){a.placeholder='What needs to be done?';return a}
function Ym(a,b){b.preventDefault();A((J(),J(),I),new mn(a),_o)}
function tl(a,b){jo((Um(),Tm),b);A((J(),J(),I),new Pl(a,b),_o)}
function Dl(a,b){return t((J(),J(),I),new Vl(a,b),75497472,null)}
function Vh(a,b){return b===a?'(this Map)':b==null?Qo:jh(b)}
function zi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function yh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.G(b))}
function Jh(a,b){var c,d;for(d=a.N();d.T();){c=d.U();b.v(c)}}
function eh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Ai(a,b){var c;return yi(b,zi(a,b==null?0:(c=r(b),c|0)))}
function En(a){ib(a.d);return new kj(null,new aj(new fi(a.g),0))}
function ej(a){if(a.b){ej(a.b)}else if(a.c){throw Sg(new Eh)}}
function Mb(b){try{b.b.u()}catch(a){a=Rg(a);if(!jd(a,6))throw Sg(a)}}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function si(a){ii(this);Aj(this.a,Th(a,Yc(fe,Go,1,$h(a.a),5,1)))}
function Ei(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function oj(a,b){$i.call(this,b.$(),b.Z()&-16449);this.a=a;this.c=b}
function eb(a,b){var c,d;ji(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function jo(a,b){var c;c=a.f;if(!(b==c||!!b&&qn(b,c))){a.f=b;hb(a.d)}}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function oh(a,b,c,d){a.addEventListener(b,c,(qh(),d?true:false))}
function ph(a,b,c,d){a.removeEventListener(b,c,(qh(),d?true:false))}
function Rj(a,b,c){!Mh(c,'key')&&!Mh(c,'ref')&&(a[c]=b[c],undefined)}
function bj(a,b){!a.a?(a.a=new Qh(a.d)):Oh(a.a,a.b);Oh(a.a,b);return a}
function jj(a,b){var c;dj(a);c=new uj;c.a=b;a.a.S(new xj(c));return c.a}
function gj(a){var b;dj(a);b=0;while(a.a._(new vj)){b=Tg(b,1)}return b}
function Vn(a){var b;jj(hj(En(a.b),new yo),(b=new ri,b)).M(new zo(a.b))}
function Yn(a){this.b=Yi(a);J();this.a=new mc(0,null,new Zn,true,false)}
function Si(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function cj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function di(a){this.d=a;this.c=new Si(this.d.b);this.a=this.c;this.b=bi(this)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function ki(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function Yh(a,b){return nd(b)?b==null?Ci(a.a,null):Qi(a.b,b):Ci(a.a,b)}
function co(a,b){return (uo(),so)==a||(ro==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function Xh(a,b,c){return nd(b)?b==null?Bi(a.a,null,c):Pi(a.b,b,c):Bi(a.a,b,c)}
function Cj(a,b){return Xc(b)!=10&&ad(q(b),b.nb,b.__elementTypeId$,Xc(b),a),a}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function go(a){var b,c;return b=S(a.b),jj(hj(En(a.j),new Bo(b)),(c=new ri,c))}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function mi(a,b,c){for(;c<a.a.length;++c){if(wi(b,a.a[c])){return c}}return -1}
function Ti(a){if(a.a.c!=a.c){return Oi(a.a,a.b.value[0])}return a.b.value[1]}
function qn(a,b){var c;if(jd(b,48)){c=b;return a.c.e==c.c.e}else{return false}}
function oi(a,b){var c;c=mi(a,b,0);if(c==-1){return false}Bj(a.a,c);return true}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function Vm(a,b){a.f=b;Mh(b,S(a.a))&&en(a,b);Zm(b);A((J(),J(),I),new mn(a),_o)}
function bl(a){var b;b=Nh((ib(a.b),a.d));if(b.length>0){Rn((Um(),Sm),b);il(a,'')}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new mb(a)),0,null);!!a.b&&nb(a.b)}}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new nc(a)),67108864,null)}}
function Xj(a,b){if(!a.j){a.j=true;a.k||(b?a.n.setState({}):a.n.forceUpdate())}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||nb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Fb(a.a)}finally{a.c=false}}}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function Bn(a){Jh(new fi(a.g),new hc(a));Zh(a.g);R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function Gl(a){return qh(),fo((Um(),Tm))==(jb(a.c),a.n.props['a'])?true:false}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function md(a){return a!=null&&(typeof a===Do||typeof a==='function')&&!(a.ob===kh)}
function ah(a,b){typeof window===Do&&typeof window['$gwt']===Do&&(window['$gwt'][a]=b)}
function cl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new nl(a),_o)}}
function ub(b){if(b){try{b.u()}catch(a){a=Rg(a);if(jd(a,6)){J()}else throw Sg(a)}}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function bb(){var a;this.a=Yc(td,Go,46,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Ch(a,b){var c;if(!a){return}b.j=a;var d=zh(b);if(!d){bh[a]=[b];return}d.mb=b}
function Rg(a){var b;if(jd(a,6)){return a}b=a&&a[Oo];if(!b){b=new wc(a);Tc(b)}return b}
function hh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function vh(a){var b;b=new uh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Qi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Fi(a.a,b);--a.b}return c}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;ji((!a.b&&(a.b=new ri),a.b),b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new ri);a.c=c.c}b.d=true;ji(a.c,Yi(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Yi(b))}
function rb(a){var b,c;for(c=new ti(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function ui(a){var b,c,d;d=0;for(c=new di(a.a);c.b;){b=ci(c);d=d+(b?r(b):0);d=d|0}return d}
function Sh(a,b){var c,d;for(d=new di(b.a);d.b;){c=ci(d);if(!_h(a,c)){return false}}return true}
function zl(a,b){var c,d;d=a.n.props;c=false;if(!(d['a']===b['a'])){hb(a.c);c=true}return c||a.j}
function Wg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Ro;d=1048575}c=pd(e/Lo);b=pd(e-c*Lo);return bd(b,c,d)}
function yi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(wi(a,c.W())){return c}}return null}
function Ug(a){var b;b=a.h;if(b==0){return a.l+a.m*Lo}if(b==1048575){return a.l+a.m*Lo-Ro}return a}
function bi(a){if(a.a.T()){return true}if(a.a!=a.c){return false}a.a=new Ei(a.d.a);return a.a.T()}
function Eh(){sc.call(this,"Stream already terminated, can't be modified or used")}
function Zg(){$g();var a=Yg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function lh(){Um();$wnd.ReactDOM.render((new Qm).a,(nh(),mh).getElementById('app'),null)}
function uo(){uo=gh;ro=new vo('ACTIVE',0);to=new vo('COMPLETED',1);so=new vo('ALL',2)}
function Nb(a,b){this.b=Yi(a);this.a=b|0|(0==(b&6291456)?Lo:0)|(0!=(b&229376)?0:98304)}
function yb(a,b,c){xb.call(this,null,a,b,c|(!a?262144:Ho)|(0==(c&6291456)?!a?Ko:Lo:0)|0|0|0)}
function ec(a,b,c){var d;d=Yh(a.g,b?Gh(b.c.e):null);if(null!=d){cc(b.c.c,a);c&&!!b&&jc(b.c);hb(a.d)}}
function An(a,b,c){var d;d=new xn(b,c);ac(d.c.c,a,new ic(a,d));Xh(a.g,Gh(d.c.e),d);hb(a.d);return d}
function Pi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ad(a,b,c,d,e){e.mb=a;e.nb=b;e.ob=kh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function S(a){ib(a.e);wb(a.f)&&pb(a.f);if(a.b){if(jd(a.b,9)){throw Sg(a.b)}else{throw Sg(a.b)}}return a.k}
function io(a){var b;b=S(a.i.a);Mh(hp,b)||Mh(bp,b)||Mh('',b)?an(a.i,b):bo(bn(a.i))?dn(a.i):an(a.i,'')}
function Pj(a){$wnd.React.Component.call(this,a);this.a=this.fb();this.a.n=Yi(this);this.a.cb()}
function uh(){this.g=rh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function wc(a){uc();oc(this);this.e=a;a!=null&&Dj(a,Oo,this);this.f=a==null?Qo:jh(a);this.a='';this.b=a;this.a=''}
function Yj(a){if(!Wj){Wj=(++a.gb().e,new Ib);$wnd.Promise.resolve(null).then(hh(Zj.prototype.F,Zj,[]))}}
function nb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Cb(a)),67108864,null);!!a.a&&R(a.a);Jb(a.f);a.c=a.c&-8|1}}
function sl(a,b,c){27==c.which?A((J(),J(),I),new Sl(a,b),_o):13==c.which&&A((J(),J(),I),new Ql(a,b),_o)}
function fb(a,b){var c,d;d=a.c;oi(d,b);!!a.b&&Ho!=(a.b.c&Io)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function Al(a){var b,c;a.j=false;Yj(a);b=(jb(a.c),a.n.props['a']);if(!!b&&b.c.i<0){return null}c=wl(a);return c}
function Gh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Ih(),Hh)[b];!c&&(c=Hh[b]=new Fh(a));return c}return new Fh(a)}
function jh(a){var b;if(Array.isArray(a)&&a.ob===kh){return th(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Lj(a){Jj();var b,c,d;c=':'+a;d=Ij[c];if(d!=null){return pd(d)}d=Gj[c];b=d==null?Kj(a):pd(d);Mj();Ij[c]=b;return b}
function ul(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){Wn((Um(),b),c);jo(Tm,null);Kl(a,c)}else{Dn((Um(),Rm),b)}}
function Tg(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<Ro){return c}}return Ug(cd(ld(a)?Wg(a):a,ld(b)?Wg(b):b))}
function q(a){return nd(a)?ie:ld(a)?Zd:kd(a)?Xd:hd(a)?a.mb:$c(a)?a.mb:a.mb||Array.isArray(a)&&Wc(Qd,1)||Qd}
function r(a){return nd(a)?Lj(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.q():$c(a)?Fj(a):!!a&&!!a.hashCode?a.hashCode():Fj(a)}
function p(a,b){return nd(a)?Mh(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.o(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function Kb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Ho)?Mb(a):a.b.u();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function zb(a,b){xb.call(this,a,new Ab(a),null,b|(Ho==(b&Io)?0:524288)|(0==(b&6291456)?Ho==(b&Io)?Lo:Ko:0)|0|268435456|0)}
function Kk(){Ik();return ad(Wc(Xe,1),Go,7,0,[mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk])}
function bc(a){var b,c;if(!a.a){for(c=new ti(new si(new fi(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.u()}a.a=true}}
function vi(a){var b,c,d;d=1;for(c=new ti(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function $j(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function qi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Cj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Bh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function vl(a){var b;b=S(a.d);if(!a.i&&b){a.i=true;Jl(a,(jb(a.c),a.n.props['a']));a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Yk(){var a;J();a=++Wk;this.b=new mc(a,new $k(this),new Zk(this),false,false);this.a=new yb(null,Yi(new _k(this)),$o);D((null,I))}
function _l(){var a;J();a=++Zl;this.b=new mc(a,new bm(this),new am(this),false,false);this.a=new yb(null,Yi(new cm(this)),$o);D((null,I))}
function mc(a,b,c,d,e){var f;this.e=a;this.c=d?new dc:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new lb((J(),null)),f):null;this.d=null}
function U(a,b,c,d){this.c=Yi(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new zb(this,d);this.e=new lb(this.f);Ho==(d&Io)&&ob(this.f)}
function xn(a,b){var c,d,e;this.e=Yi(a);this.d=b;J();c=++on;this.c=new mc(c,null,new yn(this),true,true);this.b=(e=new lb(null),e);this.a=(d=new lb(null),d)}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.nb){return !!a.nb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ti(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&vb(b,5,true)}}}
function Xb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ti(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&vb(b,6,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ti(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?vb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Nh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ub(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=ni(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&vb(c.b,3,true);++b}}}return b}
function s(b,c,d){var e,f;try{$b(b,d);try{f=(c.a.u(),null)}finally{_b()}return f}catch(a){a=Rg(a);if(jd(a,6)){e=a;throw Sg(e)}else throw Sg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.s()}else{$b(b,e);try{g=c.s()}finally{_b()}}return g}catch(a){a=Rg(a);if(jd(a,6)){f=a;throw Sg(f)}else throw Sg(a)}finally{D(b)}}
function Eb(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Kb(c);return true}
function jl(){var a,b;J();a=++el;this.c=new mc(a,new ll(this),new kl(this),false,false);this.b=(b=new lb(null),b);this.a=new yb(null,Yi(new pl(this)),$o);D((null,I))}
function Ok(){var a;J();a=++Mk;this.c=new mc(a,new Qk(this),new Pk(this),false,false);this.a=new U(new Sk,null,null,136478720);this.b=new yb(null,Yi(new Tk(this)),$o);D((null,I))}
function _g(b,c,d,e){$g();var f=Yg;$moduleName=c;$moduleBase=d;Qg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Co(g)()}catch(a){b(c,a)}}else{Co(g)()}}
function Uk(){var a,b;b=S((Um(),Rm).e).a;a='item'+(b==1?'':'s');return Qj('span',$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,['todo-count'])),[Qj('strong',null,[b]),' '+a+' left'])}
function Ki(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Li()}}
function Uj(a){var b;b=new $wnd.Object;b.$$typeof=$wnd.React.Element;b.type=Yi(a);b._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return b}
function Th(a,b){var c,d,e,f,g;g=$h(a.a);b.length<g&&(b=Cj(new Array(g),b));e=(f=new di((new ai(a.a)).a),new gi(f));for(d=0;d<g;++d){b[d]=(c=ci(e.a),c.X())}b.length>g&&(b[g]=null);return b}
function dh(){bh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].pb()&&(c=Pc(c,g)):g[0].pb()}catch(a){a=Rg(a);if(jd(a,6)){d=a;Bc();Hc(jd(d,35)?d.D():d)}else throw Sg(a)}}return c}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?Qo:md(b)?b==null?null:b.name:nd(b)?'String':th(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function dl(a){var b;a.j=false;Yj(a);b=Qj(ap,ck(gk(hk(kk(ik($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,['new-todo']))),(ib(a.b),a.d)),hh(Bm.prototype.jb,Bm,[a])),hh(Cm.prototype.ib,Cm,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.s();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Rg(a);if(jd(a,12)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Sg(c)}else throw Sg(a)}}
function Bi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=yi(b,e);if(f){return f.Y(c)}}e[e.length]=new hi(b,c);++a.b;return null}
function yj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Kj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Lh(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Yc(fe,Go,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function pb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.u()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Rg(a);if(jd(a,6)){J()}else throw Sg(a)}}}
function Zm(a){var b;if(0==a.length){b=(nh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',mh.title,b)}else{(nh(),$wnd.window.window).location.hash=a}}
function xb(a,b,c,d){this.b=new ri;this.f=new Nb(new Bb(this),d&6520832|262144|Ho);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Ko)&&D((null,I)))}
function Ci(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(wi(b,e.W())){if(d.length==1){d.length=0;Fi(a.a,g)}else{d.splice(h,1)}--a.b;return e.X()}}return null}
function fh(a,b,c){var d=bh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=bh[b]),ih(h));_.nb=c;!b&&(_.ob=kh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.mb=f)}
function Ah(a){if(a.K()){var b=a.c;b.L()?(a.k='['+b.j):!b.K()?(a.k='[L'+b.I()+';'):(a.k='['+b.I());a.b=b.H()+'[]';a.i=b.J()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Bh('.',[c,Bh('$',d)]);a.b=Bh('.',[c,Bh('.',d)]);a.i=d[d.length-1]}
function Ll(){var a,b,c;J();a=++Bl;this.e=new mc(a,new Nl(this),new Ml(this),false,false);this.c=(c=new lb(null),c);this.a=(b=new lb(null),b);this.d=new U(new Wl(this),null,null,136478720);this.b=new yb(null,Yi(new Xl(this)),$o);D((null,I))}
function Uh(a,b){var c,d,e;c=b.W();e=b.X();d=nd(c)?c==null?Wh(Ai(a.a,null)):Oi(a.b,c):Wh(Ai(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!Ai(a.a,null):Ni(a.b,c):!!Ai(a.a,c))){return false}return true}
function fn(){var a,b;this.d=new qo(this);this.f=this.e=(b=(nh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new mc(0,null,new gn(this),true,false);this.b=(a=new lb(null),a);this.a=new U(new nn,new hn(this),new jn(this),35749888)}
function In(){var a;this.g=new xi;J();this.f=new mc(0,new Kn(this),new Jn(this),true,false);this.d=(a=new lb(null),a);this.c=new U(new Nn(this),null,null,gp);this.e=new U(new On(this),null,null,gp);this.a=new U(new Pn(this),null,null,gp);this.b=new U(new Qn(this),null,null,gp)}
function ko(a){var b;this.j=Yi(a);this.i=new fn;J();this.g=new mc(0,null,new lo(this),true,false);this.d=(b=new lb(null),b);this.b=new U(new mo(this),null,null,gp);this.c=new U(new no(this),null,null,gp);this.e=u(new oo(this),413138944);this.a=u(new po(this),681574400);D((null,I))}
function wb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ti(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Rg(a);if(!jd(a,6))throw Sg(a)}if(6==(b.c&7)){return true}}}}}rb(b);return false}
function Qj(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?''+b['key']:null;f='ref' in b?b['ref']:null;Oj(b,hh(Sj.prototype.bb,Sj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=Uj(a),g.key=e,g.ref=f,g.props=Yi(d),g}
function Ji(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function vb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){kb(a.a.e);ub((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;ub((e=d.i,e));d.k=null}ki(a.b,new Db(a));a.b.a=Yc(fe,Go,1,0,5,1)}else 3==g&&!!a.a&&ub((f=a.a.g,f))}}
function Ik(){Ik=gh;mk=new Jk(Uo,0);nk=new Jk('checkbox',1);ok=new Jk('color',2);pk=new Jk('date',3);qk=new Jk('datetime',4);rk=new Jk('email',5);sk=new Jk('file',6);tk=new Jk('hidden',7);uk=new Jk('image',8);vk=new Jk('month',9);wk=new Jk(Eo,10);xk=new Jk('password',11);yk=new Jk('radio',12);zk=new Jk('range',13);Ak=new Jk('reset',14);Bk=new Jk('search',15);Ck=new Jk('submit',16);Dk=new Jk('tel',17);Ek=new Jk('text',18);Fk=new Jk('time',19);Gk=new Jk('url',20);Hk=new Jk('week',21)}
function Yl(a){var b,c,d;a.j=false;Yj(a);d=Qj('div',null,[Qj('div',null,[Qj(cp,$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[cp])),[Qj('h1',null,['todos']),(new Dm).a]),S((Um(),Rm).c)?null:Qj('section',$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[cp])),[Qj(ap,gk(jk($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[dp])),(Ik(),nk)),hh(Pm.prototype.ib,Pm,[])),null),Qj('ul',$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,['todo-list'])),(b=jj(ij(S(Tm.c).R()),(c=new ri,c)),qi(b,_c(b.a.length))))]),S(Rm.c)?null:(new fm).a])]);return d}
function Lk(a){var b,c;a.j=false;Yj(a);c=(b=S((Um(),Tm).b),Qj(Vo,$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[Vo])),[(new gm).a,Qj('ul',$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,['filters'])),[Qj('li',null,[Qj('a',ak($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[(uo(),so)==b?Wo:null])),'#'),['All'])]),Qj('li',null,[Qj('a',ak($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[ro==b?Wo:null])),'#active'),['Active'])]),Qj('li',null,[Qj('a',ak($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[to==b?Wo:null])),Xo),['Completed'])])]),S(a.a)?Qj(Uo,bk($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[Yo])),hh(em.prototype.kb,em,[])),[Zo]):null]));return c}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=li(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&pi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&vb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=li(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ni(a.b,g)}e&&tb(a.e,a.b)}else{e&&tb(a.e,new ri)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Ho!=(k.b.c&Io)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function wl(a){var b,c;c=(jb(a.c),a.n.props['a']);b=(ib(c.a),c.d);return Qj('li',$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[b?bp:null,S(a.d)?'editing':null])),[Qj('div',$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,['view'])),[Qj(ap,gk(dk(jk($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,['toggle'])),(Ik(),nk)),b),hh(Fm.prototype.ib,Fm,[c])),null),Qj('label',lk(new $wnd.Object,hh(Gm.prototype.kb,Gm,[a,c])),[(ib(c.b),c.e)]),Qj(Uo,bk($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,['destroy'])),hh(Hm.prototype.kb,Hm,[c])),null)]),Qj(ap,hk(gk(fk(ek($j(_j(new $wnd.Object,hh(Im.prototype.v,Im,[a])),ad(Wc(ie,1),Go,2,6,['edit'])),(ib(a.a),a.g)),hh(Jm.prototype.hb,Jm,[a,c])),hh(Em.prototype.ib,Em,[a])),hh(Km.prototype.jb,Km,[a,c])),null)])}
function Li(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[To]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ji()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[To]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Do='object',Eo='number',Fo={11:1},Go={3:1,4:1},Ho=1048576,Io=1835008,Jo={5:1},Ko=2097152,Lo=4194304,Mo={21:1},No='__noinit__',Oo='__java$exception',Po={3:1,12:1,9:1,6:1},Qo='null',Ro=17592186044416,So={42:1},To='delete',Uo='button',Vo='footer',Wo='selected',Xo='#completed',Yo='clear-completed',Zo='Clear Completed',$o=1478627328,_o=142606336,ap='input',bp='completed',cp='header',dp='toggle-all',ep='hashchange',fp={8:1,49:1},gp=136413184,hp='active';var _,bh,Yg,Qg=-1;dh();fh(1,null,{},o);_.o=ip;_.p=function(){return this.mb};_.q=jp;_.r=function(){var a;return th(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var dd,ed,fd;fh(51,1,{},uh);_.G=function(a){var b;b=new uh;b.e=4;a>1?(b.c=yh(this,a-1)):(b.c=this);return b};_.H=function(){sh(this);return this.b};_.I=function(){return th(this)};_.J=function(){sh(this);return this.i};_.K=function(){return (this.e&4)!=0};_.L=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(sh(this),this.k)};_.e=0;_.g=0;var rh=1;var fe=wh(1);var Yd=wh(51);fh(87,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var sd=wh(87);fh(36,1,Fo,G);_.s=function(){return this.a.u(),null};var qd=wh(36);fh(88,1,{},H);var rd=wh(88);var I;fh(46,1,{46:1},P);_.b=0;_.c=false;_.d=0;var td=wh(46);fh(210,1,{8:1});_.r=function(){var a;return th(this.mb)+'@'+(a=r(this)>>>0,a.toString(16))};var wd=wh(210);fh(19,210,{8:1},U);_.t=function(){R(this)};_.a=false;_.d=0;var ud=wh(19);fh(141,1,{249:1},bb);var vd=wh(141);fh(14,210,{8:1,14:1},lb);_.t=function(){cb(this)};_.a=4;_.d=false;_.e=0;var yd=wh(14);fh(121,1,Jo,mb);_.u=function(){db(this.a)};var xd=wh(121);fh(17,210,{8:1,17:1},yb,zb);_.t=function(){nb(this)};_.c=0;var Dd=wh(17);fh(122,1,Mo,Ab);_.u=function(){Q(this.a)};var zd=wh(122);fh(123,1,Jo,Bb);_.u=function(){pb(this.a)};var Ad=wh(123);fh(124,1,Jo,Cb);_.u=function(){sb(this.a)};var Bd=wh(124);fh(125,1,{},Db);_.v=function(a){qb(this.a,a)};var Cd=wh(125);fh(140,1,{},Gb);_.a=0;_.b=0;_.c=0;var Ed=wh(140);fh(158,1,{8:1},Ib);_.t=function(){Hb(this)};_.a=false;var Fd=wh(158);fh(60,210,{8:1,60:1},Nb);_.t=function(){Jb(this)};_.a=0;var Gd=wh(60);fh(143,1,{},Zb);_.r=function(){var a;return sh(Hd),Hd.k+'@'+(a=Fj(this)>>>0,a.toString(16))};_.a=0;var Ob;var Hd=wh(143);fh(126,1,{8:1},dc);_.t=function(){bc(this)};_.a=false;var Id=wh(126);fh(109,1,{});var Ld=wh(109);fh(55,1,{},hc);_.v=function(a){fc(this.a,a)};var Jd=wh(55);fh(89,1,Jo,ic);_.u=function(){gc(this.a,this.b)};var Kd=wh(89);fh(110,109,{});var Md=wh(110);fh(16,1,{8:1},mc);_.t=function(){jc(this)};_.r=function(){var a;return sh(Od),Od.k+'@'+(a=Fj(this)>>>0,a.toString(16))};_.e=0;_.i=0;var Od=wh(16);fh(120,1,Jo,nc);_.u=function(){lc(this.a)};var Nd=wh(120);fh(6,1,{3:1,6:1});_.A=function(a){return new Error(a)};_.B=function(){return this.f};_.C=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=th(this.mb),c==null?a:a+': '+c);pc(this,rc(this.A(b)));Tc(this)};_.r=function(){return qc(this,this.B())};_.e=No;_.g=true;var je=wh(6);fh(12,6,{3:1,12:1,6:1});var _d=wh(12);fh(9,12,Po);var ge=wh(9);fh(52,9,Po);var ce=wh(52);fh(81,52,Po);var Sd=wh(81);fh(35,81,{35:1,3:1,12:1,9:1,6:1},wc);_.B=function(){vc(this);return this.c};_.D=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Pd=wh(35);var Qd=wh(0);fh(196,1,{});var Rd=wh(196);var yc=0,zc=0,Ac=-1;fh(108,196,{},Oc);var Kc;var Td=wh(108);var Rc;fh(207,1,{});var Vd=wh(207);fh(82,207,{},Vc);var Ud=wh(82);var mh;fh(79,1,{76:1});_.r=kp;var Wd=wh(79);dd={3:1,77:1,28:1};var Xd=wh(77);fh(44,1,{3:1,44:1});var ee=wh(44);ed={3:1,28:1,44:1};var Zd=wh(206);fh(31,1,{3:1,28:1,31:1});_.o=ip;_.q=jp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var $d=wh(31);fh(83,9,Po,Eh);var ae=wh(83);fh(29,44,{3:1,28:1,29:1,44:1},Fh);_.o=function(a){return jd(a,29)&&a.a==this.a};_.q=kp;_.r=function(){return ''+this.a};_.a=0;var be=wh(29);var Hh;fh(275,1,{});fh(85,52,Po,Kh);_.A=function(a){return new TypeError(a)};var de=wh(85);fd={3:1,76:1,28:1,2:1};var ie=wh(2);fh(80,79,{76:1},Qh);var he=wh(80);fh(279,1,{});fh(54,9,Po,Rh);var ke=wh(54);fh(208,1,{40:1});_.M=op;_.Q=function(){return new aj(this,0)};_.R=function(){return new kj(null,this.Q())};_.O=function(a){throw Sg(new Rh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new cj('[',']');for(b=this.N();b.T();){a=b.U();bj(c,a===this?'(this Collection)':a==null?Qo:jh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var le=wh(208);fh(211,1,{194:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!jd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new di((new ai(d)).a);c.b;){b=ci(c);if(!Uh(this,b)){return false}}return true};_.q=function(){return ui(new ai(this))};_.r=function(){var a,b,c;c=new cj('{','}');for(b=new di((new ai(this)).a);b.b;){a=ci(b);bj(c,Vh(this,a.W())+'='+Vh(this,a.X()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var we=wh(211);fh(129,211,{194:1});var oe=wh(129);fh(212,208,{40:1,228:1});_.Q=function(){return new aj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!jd(a,24)){return false}b=a;if($h(b.a)!=this.P()){return false}return Sh(this,b)};_.q=function(){return ui(this)};var xe=wh(212);fh(24,212,{24:1,40:1,228:1},ai);_.N=function(){return new di(this.a)};_.P=mp;var ne=wh(24);fh(25,1,{},di);_.S=lp;_.U=function(){return ci(this)};_.T=np;_.b=false;var me=wh(25);fh(209,208,{40:1,225:1});_.Q=function(){return new aj(this,16)};_.V=function(a,b){throw Sg(new Rh('Add not supported on this list'))};_.O=function(a){this.V(this.P(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,10)){return false}f=a;if(this.P()!=f.a.length){return false}e=new ti(f);for(c=new ti(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return vi(this)};_.N=function(){return new ei(this)};var qe=wh(209);fh(107,1,{},ei);_.S=lp;_.T=function(){return this.a<this.b.a.length};_.U=function(){return li(this.b,this.a++)};_.a=0;var pe=wh(107);fh(38,208,{40:1},fi);_.N=function(){var a;return a=new di((new ai(this.a)).a),new gi(a)};_.P=mp;var se=wh(38);fh(56,1,{},gi);_.S=lp;_.T=function(){return this.a.b};_.U=function(){var a;return a=ci(this.a),a.X()};var re=wh(56);fh(130,1,So);_.o=function(a){var b;if(!jd(a,42)){return false}b=a;return wi(this.a,b.W())&&wi(this.b,b.X())};_.W=kp;_.X=np;_.q=function(){return Xi(this.a)^Xi(this.b)};_.Y=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var te=wh(130);fh(131,130,So,hi);var ue=wh(131);fh(213,1,So);_.o=function(a){var b;if(!jd(a,42)){return false}b=a;return wi(this.b.value[0],b.W())&&wi(Ti(this),b.X())};_.q=function(){return Xi(this.b.value[0])^Xi(Ti(this))};_.r=function(){return this.b.value[0]+'='+Ti(this)};var ve=wh(213);fh(10,209,{3:1,10:1,40:1,225:1},ri,si);_.V=function(a,b){zj(this.a,a,b)};_.O=function(a){return ji(this,a)};_.M=function(a){ki(this,a)};_.N=function(){return new ti(this)};_.P=function(){return this.a.length};var ze=wh(10);fh(18,1,{},ti);_.S=lp;_.T=function(){return this.a<this.c.a.length};_.U=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ye=wh(18);fh(37,129,{3:1,37:1,194:1},xi);var Ae=wh(37);fh(61,1,{},Di);_.M=op;_.N=function(){return new Ei(this)};_.b=0;var Ce=wh(61);fh(62,1,{},Ei);_.S=lp;_.U=function(){return this.d=this.a[this.c++],this.d};_.T=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Be=wh(62);var Hi;fh(58,1,{},Ri);_.M=op;_.N=function(){return new Si(this)};_.b=0;_.c=0;var Fe=wh(58);fh(59,1,{},Si);_.S=lp;_.U=function(){return this.c=this.a,this.a=this.b.next(),new Ui(this.d,this.c,this.d.c)};_.T=function(){return !this.a.done};var De=wh(59);fh(142,213,So,Ui);_.W=function(){return this.b.value[0]};_.X=function(){return Ti(this)};_.Y=function(a){return Pi(this.a,this.b.value[0],a)};_.c=0;var Ee=wh(142);fh(145,1,{});_.S=function(a){Zi(this,a)};_.Z=function(){return this.d};_.$=function(){return this.e};_.d=0;_.e=0;var He=wh(145);fh(63,145,{});var Ge=wh(63);fh(23,1,{},aj);_.Z=kp;_.$=function(){_i(this);return this.c};_.S=function(a){_i(this);this.d.S(a)};_._=function(a){_i(this);if(this.d.T()){a.v(this.d.U());return true}return false};_.a=0;_.c=0;var Ie=wh(23);fh(53,1,{},cj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Je=wh(53);fh(144,1,{});_.c=false;var Se=wh(144);fh(32,144,{},kj);var Re=wh(32);fh(147,63,{},oj);_._=function(a){this.b=false;while(!this.b&&this.c._(new pj(this,a)));return this.b};_.b=false;var Le=wh(147);fh(150,1,{},pj);_.v=function(a){nj(this.a,this.b,a)};var Ke=wh(150);fh(146,63,{},rj);_._=function(a){return this.a._(new sj(a))};var Ne=wh(146);fh(149,1,{},sj);_.v=function(a){qj(this.a,a)};var Me=wh(149);fh(148,1,{},uj);_.v=function(a){tj(this,a)};var Oe=wh(148);fh(151,1,{},vj);_.v=function(a){};var Pe=wh(151);fh(152,1,{},xj);_.v=function(a){wj(this,a)};var Qe=wh(152);fh(277,1,{});fh(218,1,{});var Te=wh(218);fh(274,1,{});var Ej=0;var Gj,Hj=0,Ij;fh(701,1,{});fh(727,1,{});fh(214,1,{});_.cb=xp;var Ue=wh(214);fh(30,$wnd.React.Component,{});eh(bh[1],_);_.render=function(){return this.a.db()};var Ve=wh(30);fh(248,$wnd.Function,{},Sj);_.bb=function(a){Rj(this.a,this.b,a)};fh(215,214,{});_.j=false;_.k=false;var Wj;var We=wh(215);fh(247,$wnd.Function,{},Zj);_.F=function(a){return Hb(Wj),Wj=null,null};fh(7,31,{3:1,28:1,31:1,7:1},Jk);var mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk;var Xe=xh(7,Kk);fh(219,215,{});_.db=function(){var a;return a=S((Um(),Tm).b),Qj(Vo,$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[Vo])),[(new gm).a,Qj('ul',$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,['filters'])),[Qj('li',null,[Qj('a',ak($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[(uo(),so)==a?Wo:null])),'#'),['All'])]),Qj('li',null,[Qj('a',ak($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[ro==a?Wo:null])),'#active'),['Active'])]),Qj('li',null,[Qj('a',ak($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[to==a?Wo:null])),Xo),['Completed'])])]),S(this.a)?Qj(Uo,bk($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[Yo])),hh(em.prototype.kb,em,[])),[Zo]):null])};var Kf=wh(219);fh(220,219,{});_.db=function(){return Lk(this)};var Of=wh(220);fh(68,220,{8:1,68:1},Ok);_.t=sp;_.o=ip;_.gb=pp;_.q=jp;_.db=function(){return B((J(),J(),I),this.b,new Rk(this))};_.r=function(){var a;return sh(gf),gf.k+'@'+(a=Fj(this)>>>0,a.toString(16))};var Mk=0;var gf=wh(68);fh(172,1,Jo,Pk);_.u=function(){Nk(this.a)};var Ye=wh(172);fh(171,1,Jo,Qk);_.u=qp;var Ze=wh(171);fh(175,1,Fo,Rk);_.s=function(){return Lk(this.a)};var $e=wh(175);fh(173,1,Fo,Sk);_.s=function(){return qh(),S((Um(),Rm).b).a>0?true:false};var _e=wh(173);fh(174,1,Mo,Tk);_.u=rp;var af=wh(174);fh(223,215,{});_.db=function(){return Uk()};var Jf=wh(223);fh(224,223,{});_.db=function(){return Vk(this)};var Nf=wh(224);fh(73,224,{8:1,73:1},Yk);_.t=tp;_.o=ip;_.gb=pp;_.q=jp;_.db=function(){return B((J(),J(),I),this.a,new al(this))};_.r=function(){var a;return sh(ff),ff.k+'@'+(a=Fj(this)>>>0,a.toString(16))};var Wk=0;var ff=wh(73);fh(190,1,Jo,Zk);_.u=function(){Xk(this.a)};var bf=wh(190);fh(189,1,Jo,$k);_.u=qp;var cf=wh(189);fh(191,1,Mo,_k);_.u=rp;var df=wh(191);fh(192,1,Fo,al);_.s=function(){return Vk(this.a)};var ef=wh(192);fh(163,215,{});_.db=function(){return Qj(ap,ck(gk(hk(kk(ik($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,['new-todo']))),(ib(this.b),this.d)),hh(Bm.prototype.jb,Bm,[this])),hh(Cm.prototype.ib,Cm,[this]))),null)};_.d='';var Wf=wh(163);fh(164,163,{});_.db=function(){return dl(this)};var Qf=wh(164);fh(67,164,{8:1,67:1},jl);_.t=sp;_.o=ip;_.gb=pp;_.q=jp;_.db=function(){return B((J(),J(),I),this.a,new ml(this))};_.r=function(){var a;return sh(of),of.k+'@'+(a=Fj(this)>>>0,a.toString(16))};var el=0;var of=wh(67);fh(166,1,Jo,kl);_.u=function(){fl(this.a)};var hf=wh(166);fh(165,1,Jo,ll);_.u=qp;var jf=wh(165);fh(168,1,Fo,ml);_.s=function(){return dl(this.a)};var kf=wh(168);fh(169,1,Jo,nl);_.u=function(){bl(this.a)};var lf=wh(169);fh(170,1,Jo,ol);_.u=function(){hl(this.a,this.b)};var mf=wh(170);fh(167,1,Mo,pl);_.u=rp;var nf=wh(167);fh(221,215,{});_.cb=function(){Jl(this,this.lb())};_.db=function(){return wl(this)};_.i=false;var Yf=wh(221);fh(222,221,{});_.lb=function(){return this.n.props['a']};_.db=function(){return Al(this)};var Sf=wh(222);fh(70,222,{8:1,70:1},Ll);_.t=function(){jc(this.e)};_.o=ip;_.gb=pp;_.lb=function(){return jb(this.c),this.n.props['a']};_.q=jp;_.db=function(){return B((J(),J(),I),this.b,new Ol(this))};_.r=function(){var a;return sh(Bf),Bf.k+'@'+(a=Fj(this)>>>0,a.toString(16))};var Bl=0;var Bf=wh(70);fh(177,1,Jo,Ml);_.u=function(){Cl(this.a)};var pf=wh(177);fh(176,1,Jo,Nl);_.u=qp;var qf=wh(176);fh(180,1,Fo,Ol);_.s=function(){return Al(this.a)};var rf=wh(180);fh(71,1,Jo,Pl);_.u=function(){Kl(this.a,bn(this.b))};var sf=wh(71);fh(72,1,Jo,Ql);_.u=function(){ul(this.a,this.b)};var tf=wh(72);fh(181,1,Jo,Rl);_.u=function(){tl(this.a,this.b)};var uf=wh(181);fh(182,1,Jo,Sl);_.u=function(){Jl(this.a,this.b);jo((Um(),Tm),null)};var vf=wh(182);fh(183,1,Jo,Tl);_.u=function(){ql(this.a,this.b)};var wf=wh(183);fh(184,1,Jo,Ul);_.u=function(){vl(this.a)};var xf=wh(184);fh(185,1,Fo,Vl);_.s=function(){return Fl(this.a,this.b)};var yf=wh(185);fh(178,1,Fo,Wl);_.s=function(){return Gl(this.a)};var zf=wh(178);fh(179,1,Mo,Xl);_.u=function(){Xj(this.a,true)};var Af=wh(179);fh(216,215,{});_.db=function(){var a;return Qj('div',null,[Qj('div',null,[Qj(cp,$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[cp])),[Qj('h1',null,['todos']),(new Dm).a]),S((Um(),Rm).c)?null:Qj('section',$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[cp])),[Qj(ap,gk(jk($j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,[dp])),(Ik(),nk)),hh(Pm.prototype.ib,Pm,[])),null),Qj('ul',$j(new $wnd.Object,ad(Wc(ie,1),Go,2,6,['todo-list'])),(a=jj(ij(S(Tm.c).R()),new ri),qi(a,_c(a.a.length))))]),S(Rm.c)?null:(new fm).a])])};var $f=wh(216);fh(217,216,{});_.db=function(){return Yl(this)};var Uf=wh(217);fh(64,217,{8:1,64:1},_l);_.t=tp;_.o=ip;_.gb=pp;_.q=jp;_.db=function(){return B((J(),J(),I),this.a,new dm(this))};_.r=function(){var a;return sh(Gf),Gf.k+'@'+(a=Fj(this)>>>0,a.toString(16))};var Zl=0;var Gf=wh(64);fh(155,1,Jo,am);_.u=function(){Xk(this.a)};var Cf=wh(155);fh(154,1,Jo,bm);_.u=qp;var Df=wh(154);fh(156,1,Mo,cm);_.u=rp;var Ef=wh(156);fh(157,1,Fo,dm);_.s=function(){return Yl(this.a)};var Ff=wh(157);fh(231,$wnd.Function,{},em);_.kb=function(a){Tn((Um(),Sm))};fh(66,1,{},fm);var Hf=wh(66);fh(69,1,{},gm);var If=wh(69);fh(251,$wnd.Function,{},hm);_.eb=function(a){return new km(a)};var im;fh(160,30,{},km);_.fb=function(){return new Ok};_.componentWillUnmount=up;var Lf=wh(160);fh(261,$wnd.Function,{},lm);_.eb=function(a){return new om(a)};var mm;fh(186,30,{},om);_.fb=function(){return new Yk};_.componentWillUnmount=vp;var Mf=wh(186);fh(250,$wnd.Function,{},pm);_.eb=function(a){return new sm(a)};var qm;fh(159,30,{},sm);_.fb=function(){return new jl};_.componentWillUnmount=up;var Pf=wh(159);fh(252,$wnd.Function,{},tm);_.eb=function(a){return new wm(a)};var um;fh(162,30,{},wm);_.fb=function(){return new Ll};_.componentDidUpdate=function(a){yl(this.a)};_.componentWillUnmount=function(){jc(this.a.e)};_.shouldComponentUpdate=function(a){return Dl(this.a,a)};var Rf=wh(162);fh(246,$wnd.Function,{},xm);_.eb=function(a){return new Am(a)};var ym;fh(128,30,{},Am);_.fb=function(){return new _l};_.componentWillUnmount=vp;var Tf=wh(128);fh(229,$wnd.Function,{},Bm);_.jb=function(a){cl(this.a,a)};fh(230,$wnd.Function,{},Cm);_.ib=function(a){gl(this.a,a)};fh(65,1,{},Dm);var Vf=wh(65);fh(259,$wnd.Function,{},Em);_.ib=function(a){El(this.a,a)};fh(253,$wnd.Function,{},Fm);_.ib=function(a){wn(this.a)};fh(255,$wnd.Function,{},Gm);_.kb=function(a){Hl(this.a,this.b)};fh(256,$wnd.Function,{},Hm);_.kb=function(a){xl(this.a)};fh(257,$wnd.Function,{},Im);_.v=function(a){rl(this.a,a)};fh(258,$wnd.Function,{},Jm);_.hb=function(a){Il(this.a,this.b)};fh(260,$wnd.Function,{},Km);_.jb=function(a){sl(this.a,this.b,a)};fh(161,1,{},Om);var Xf=wh(161);fh(227,$wnd.Function,{},Pm);_.ib=function(a){var b;b=a.target;Xn((Um(),Sm),b.checked)};fh(75,1,{},Qm);var Zf=wh(75);var Rm,Sm,Tm;fh(132,1,{});var Fg=wh(132);fh(133,132,fp,fn);_.t=sp;_.o=ip;_.w=wp;_.q=jp;_.r=function(){var a;return sh(gg),gg.k+'@'+(a=Fj(this)>>>0,a.toString(16))};var gg=wh(133);fh(134,1,Jo,gn);_.u=function(){_m(this.a)};var _f=wh(134);fh(136,1,Mo,hn);_.u=function(){Wm(this.a)};var ag=wh(136);fh(137,1,Mo,jn);_.u=function(){Xm(this.a)};var bg=wh(137);fh(138,1,Jo,kn);_.u=function(){Vm(this.a,this.b)};var cg=wh(138);fh(139,1,Jo,ln);_.u=function(){cn(this.a)};var dg=wh(139);fh(57,1,Jo,mn);_.u=function(){$m(this.a)};var eg=wh(57);fh(135,1,Fo,nn);_.s=function(){var a;return a=(nh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var fg=wh(135);fh(47,1,{47:1});_.d=false;var Ng=wh(47);fh(48,47,{8:1,49:1,48:1,47:1},xn);_.t=sp;_.o=function(a){return qn(this,a)};_.w=wp;_.q=function(){return this.c.e};_.r=function(){var a;return sh(xg),xg.k+'@'+(a=this.c.e>>>0,a.toString(16))};var on=0;var xg=wh(48);fh(187,1,Jo,yn);_.u=function(){pn(this.a)};var hg=wh(187);fh(188,1,Jo,zn);_.u=function(){tn(this.a)};var ig=wh(188);fh(45,110,{45:1});var Ig=wh(45);fh(111,45,{8:1,49:1,45:1},In);_.t=function(){jc(this.f)};_.o=ip;_.w=function(){return this.f.c};_.q=jp;_.r=function(){var a;return sh(rg),rg.k+'@'+(a=Fj(this)>>>0,a.toString(16))};var rg=wh(111);fh(113,1,Jo,Jn);_.u=function(){Bn(this.a)};var jg=wh(113);fh(112,1,Jo,Kn);_.u=function(){Fn(this.a)};var kg=wh(112);fh(118,1,Jo,Ln);_.u=function(){ec(this.a,this.b,true)};var lg=wh(118);fh(119,1,Fo,Mn);_.s=function(){return An(this.a,this.c,this.b)};_.b=false;var mg=wh(119);fh(114,1,Fo,Nn);_.s=function(){return Gn(this.a)};var ng=wh(114);fh(115,1,Fo,On);_.s=function(){return Gh(Xg(gj(En(this.a))))};var og=wh(115);fh(116,1,Fo,Pn);_.s=function(){return Gh(Xg(gj(hj(En(this.a),new xo))))};var pg=wh(116);fh(117,1,Fo,Qn);_.s=function(){return Hn(this.a)};var qg=wh(117);fh(94,1,{});var Mg=wh(94);fh(95,94,fp,Yn);_.t=function(){jc(this.a)};_.o=ip;_.w=function(){return this.a.c};_.q=jp;_.r=function(){var a;return sh(wg),wg.k+'@'+(a=Fj(this)>>>0,a.toString(16))};var wg=wh(95);fh(96,1,Jo,Zn);_.u=xp;var sg=wh(96);fh(97,1,Jo,$n);_.u=function(){Un(this.a,this.b)};_.b=false;var tg=wh(97);fh(98,1,Jo,_n);_.u=function(){en(this.b,this.a)};var ug=wh(98);fh(99,1,Jo,ao);_.u=function(){Vn(this.a)};var vg=wh(99);fh(100,1,{});var Pg=wh(100);fh(101,100,fp,ko);_.t=function(){jc(this.g)};_.o=ip;_.w=function(){return this.g.c};_.q=jp;_.r=function(){var a;return sh(Dg),Dg.k+'@'+(a=Fj(this)>>>0,a.toString(16))};var Dg=wh(101);fh(102,1,Jo,lo);_.u=function(){eo(this.a)};var yg=wh(102);fh(103,1,Fo,mo);_.s=function(){var a;return a=bn(this.a.i),Mh(hp,a)||Mh(bp,a)||Mh('',a)?Mh(hp,a)?(uo(),ro):Mh(bp,a)?(uo(),to):(uo(),so):(uo(),so)};var zg=wh(103);fh(104,1,Fo,no);_.s=function(){return go(this.a)};var Ag=wh(104);fh(105,1,Mo,oo);_.u=function(){ho(this.a)};var Bg=wh(105);fh(106,1,Mo,po);_.u=function(){io(this.a)};var Cg=wh(106);fh(127,1,{},qo);_.handleEvent=function(a){Ym(this.a,a)};var Eg=wh(127);fh(33,31,{3:1,28:1,31:1,33:1},vo);var ro,so,to;var Gg=xh(33,wo);fh(90,1,{},xo);_.ab=function(a){return !sn(a)};var Hg=wh(90);fh(92,1,{},yo);_.ab=function(a){return sn(a)};var Jg=wh(92);fh(93,1,{},zo);_.v=function(a){Dn(this.a,a)};var Kg=wh(93);fh(91,1,{},Ao);_.v=function(a){Sn(this.a,a)};_.a=false;var Lg=wh(91);fh(84,1,{},Bo);_.ab=function(a){return co(this.a,a)};var Og=wh(84);var Co=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=_g;Zg(lh);ah('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();