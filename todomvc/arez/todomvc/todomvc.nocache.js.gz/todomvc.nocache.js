function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='B09EC254D0230E0F2B9BAE82B50BB1A3',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'B09EC254D0230E0F2B9BAE82B50BB1A3';function o(){}
function oj(){}
function nj(){}
function dh(){}
function dm(){}
function hm(){}
function lm(){}
function pm(){}
function Fm(){}
function $g(){}
function Jb(){}
function Oc(){}
function Vc(){}
function Ck(){}
function Lk(){}
function Yl(){}
function _l(){}
function cn(){}
function oo(){}
function po(){}
function Tc(a){Sc()}
function jh(){jh=$g}
function li(){ci(this)}
function F(a){this.a=a}
function G(a){this.a=a}
function W(a){this.a=a}
function nb(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function Eb(a){this.a=a}
function ec(a){this.a=a}
function nc(a){this.a=a}
function zh(a){this.a=a}
function Kh(a){this.a=a}
function Wh(a){this.a=a}
function _h(a){this.a=a}
function $h(a){this.b=a}
function ai(a){this.a=a}
function ni(a){this.c=a}
function lj(a){this.a=a}
function qj(a){this.a=a}
function Kk(a){this.a=a}
function Mk(a){this.a=a}
function Nk(a){this.a=a}
function Tk(a){this.a=a}
function Uk(a){this.a=a}
function Vk(a){this.a=a}
function gl(a){this.a=a}
function hl(a){this.a=a}
function il(a){this.a=a}
function kl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function Jl(a){this.a=a}
function Ol(a){this.a=a}
function Pl(a){this.a=a}
function Vl(a){this.a=a}
function Wl(a){this.a=a}
function Xl(a){this.a=a}
function tm(a){this.a=a}
function um(a){this.a=a}
function wm(a){this.a=a}
function xm(a){this.a=a}
function zm(a){this.a=a}
function Am(a){this.a=a}
function Ym(a){this.a=a}
function Zm(a){this.a=a}
function $m(a){this.a=a}
function an(a){this.a=a}
function bn(a){this.a=a}
function pn(a){this.a=a}
function qn(a){this.a=a}
function An(a){this.a=a}
function Bn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Hn(a){this.a=a}
function Sn(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function co(a){this.a=a}
function eo(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function ho(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function so(a){this.a=a}
function mj(a,b){a.a=b}
function Ij(a,b){a.key=b}
function Hj(a,b){Gj(a,b)}
function Jn(a,b){El(b,a)}
function X(a){!!a&&db(a)}
function ic(a){!!a&&a.v()}
function v(a){--a.e;C(a)}
function _o(a){Pi(this,a)}
function cp(a){Dh(this,a)}
function dp(){hc(this.c)}
function fp(){hc(this.b)}
function lp(){hc(this.f)}
function xi(){this.a=Gi()}
function Li(){this.a=Gi()}
function hp(){ob(this.a.a)}
function hb(a){Xb((I(),a))}
function ib(a){Yb((I(),a))}
function lb(a){Zb((I(),a))}
function lc(a,b){Sh(a.e,b)}
function pj(a,b){gj(a.a,b)}
function In(a,b){tn(a.b,b)}
function B(a,b){bb(a.f,b.f)}
function ub(a,b){a.b=Si(b)}
function Mb(a){a.a=-4&a.a|1}
function Dk(a){a.d=2;hc(a.c)}
function Ok(a){a.c=2;hc(a.b)}
function sl(a){a.f=2;hc(a.e)}
function Lg(a){return a.e}
function Yo(){return this.a}
function bp(){return this.b}
function Gh(a,b){return a===b}
function ml(a,b){return a.g=b}
function $o(){return yj(this)}
function Lh(a){sc.call(this,a)}
function kp(a){lc(this.c,a)}
function np(a){lc(this.f,a)}
function Hk(a){ob(a.b);Q(a.a)}
function al(a){ob(a.a);db(a.b)}
function Rm(a){Q(a.a);db(a.b)}
function en(a){db(a.b);db(a.a)}
function rl(a){un((Km(),Hm),a)}
function gc(a,b,c){Rh(a.e,b,c)}
function fn(a,b,c){gc(a.c,b,c)}
function uj(a,b){a.splice(b,1)}
function J(a,b){N(a);K(a,Si(b))}
function fi(a,b){return a.a[b]}
function Wc(a,b){return sh(a,b)}
function Zo(a){return this===a}
function ap(){return Uh(this.a)}
function ep(){return this.c.i<0}
function gp(){return this.b.i<0}
function mp(){return this.f.i<0}
function Eh(){oc(this);this.D()}
function Ci(){Ci=$g;Bi=Ei()}
function I(){I=$g;H=new D}
function uc(){uc=$g;tc=new o}
function Lc(){Lc=$g;Kc=new Oc}
function Bc(){Bc=$g;!!(Sc(),Rc)}
function Tg(){Rg==null&&(Rg=[])}
function eb(a){I();Yb(a);a.e=-2}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function S(a){qb(a.f);return U(a)}
function Tm(a){jb(a.b);return a.e}
function jn(a){jb(a.a);return a.d}
function Xn(a){jb(a.d);return a.e}
function mh(a){lh(a);return a.k}
function fj(a,b){a.P(b);return a}
function Rj(a,b){a.ref=b;return a}
function gj(a,b){mj(a,fj(a.a,b))}
function Ti(a,b){while(a.ab(b));}
function bi(a,b){this.a=a;this.b=b}
function fc(a,b){this.a=a;this.b=b}
function xh(a,b){this.a=a;this.b=b}
function jj(a,b){this.a=a;this.b=b}
function Pj(a,b){this.a=a;this.b=b}
function ip(a){return 1==this.a.d}
function jp(a){return 1==this.a.c}
function Uh(a){return a.a.b+a.b.b}
function Ii(a,b){return a.a.get(b)}
function _c(a){return new Array(a)}
function Gi(){Ci();return new Bi}
function Sj(a,b){a.href=b;return a}
function jl(a,b){this.a=a;this.b=b}
function Il(a,b){this.a=a;this.b=b}
function Kl(a,b){this.a=a;this.b=b}
function Ll(a,b){this.a=a;this.b=b}
function Ml(a,b){this.a=a;this.b=b}
function Nl(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function Bm(a,b){this.a=a;this.b=b}
function Cm(a,b){this.a=a;this.b=b}
function yk(a,b){xh.call(this,a,b)}
function _m(a,b){this.a=a;this.b=b}
function Cn(a,b){this.a=a;this.b=b}
function Qn(a,b){this.a=a;this.b=b}
function Rn(a,b){this.b=a;this.a=b}
function mo(a,b){xh.call(this,a,b)}
function sj(a,b,c){a.splice(b,0,c)}
function u(a,b,c){s(a,new G(c),b)}
function Um(a){Sm(a,(jb(a.b),a.e))}
function Zl(){this.a=Jj((bm(),am))}
function $l(){this.a=Jj((fm(),em))}
function vm(){this.a=Jj((jm(),im))}
function Em(){this.a=Jj((nm(),mm))}
function Gm(){this.a=Jj((rm(),qm))}
function kn(a){El(a,(jb(a.a),!a.d))}
function Tb(a){return !a.d?a:Tb(a.d)}
function Qh(a){return !a?null:a.Y()}
function od(a){return a==null?null:a}
function Ri(a){return a!=null?r(a):0}
function ld(a){return typeof a===vo}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function Ic(a){$wnd.clearTimeout(a)}
function ci(a){a.a=Yc(ge,xo,1,0,5,1)}
function Th(a){a.a=new xi;a.b=new Li}
function mb(a){this.c=new li;this.b=a}
function Cj(){Cj=$g;zj=new o;Bj=new o}
function _j(a,b){a.value=b;return a}
function Wj(a,b){a.onBlur=b;return a}
function Tj(a,b){a.onClick=b;return a}
function Vj(a,b){a.checked=b;return a}
function Ih(a,b){a.a+=''+b;return a}
function Xj(a,b){a.onChange=b;return a}
function tj(a,b){rj(b,0,a,0,b.length)}
function dc(a,b){bc(a,b,false);ib(a.d)}
function wl(a){ob(a.b);Q(a.c);db(a.a)}
function tb(a){I();sb(a);wb(a,2,true)}
function jb(a){var b;Ub((I(),b=Pb,b),a)}
function Hb(a){this.d=Si(a);this.b=100}
function O(){this.a=Yc(ge,xo,1,100,5,1)}
function A(a,b,c){return t(a,c,2048,b)}
function bd(a,b,c){return {l:a,m:b,h:c}}
function Fh(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function Y(a){return !(!!a&&1==(a.c&7))}
function yj(a){return a.$H||(a.$H=++xj)}
function nd(a){return typeof a==='string'}
function Yj(a,b){a.onKeyDown=b;return a}
function Uj(a){a.autoFocus=true;return a}
function lh(a){if(a.k!=null){return}uh(a)}
function sc(a){this.f=a;oc(this);this.D()}
function ej(a,b){_i.call(this,a);this.a=b}
function cc(a,b){b.A(a);jd(b,9)&&b.t()}
function Gj(a,b){for(var c in a){b(c)}}
function wj(b,c,d){try{b[c]=d}catch(a){}}
function w(a,b,c){t(a,new F(b),c,null)}
function Bl(a){w((I(),I(),H),new Pl(a),Qo)}
function Vm(a){w((I(),I(),H),new an(a),Qo)}
function nn(a){w((I(),I(),H),new qn(a),Qo)}
function Kn(a){w((I(),I(),H),new Sn(a),Qo)}
function Kb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&wb(a.f,5,true)}
function Wn(a){var b;b=a.e;!!b&&lc(b.c,a)}
function zi(a,b){var c;c=a[Lo];c.call(a,b)}
function pc(a,b){a.e=b;b!=null&&wj(b,Go,a)}
function Pi(a,b){while(a.U()){pj(b,a.V())}}
function ab(a,b,c){Mb(Si(c));J(a.a[b],Si(c))}
function Cc(a,b,c){return a.apply(b,c);var d}
function yn(a){return Ah(R(a.e).a-R(a.a).a)}
function kd(a){return typeof a==='boolean'}
function oc(a){a.g&&a.e!==Fo&&a.D();return a}
function ak(a,b){a.onDoubleClick=b;return a}
function ph(a){var b;b=oh(a);wh(a,b);return b}
function Vn(a){ob(a.a);Q(a.b);Q(a.c);db(a.d)}
function bb(a,b){ab(a,((b.a&229376)>>15)-1,b)}
function bl(a,b){w((I(),I(),H),new jl(a,b),Qo)}
function xl(a,b){w((I(),I(),H),new Nl(a,b),Qo)}
function zl(a,b){w((I(),I(),H),new Ll(a,b),Qo)}
function Al(a,b){w((I(),I(),H),new Kl(a,b),Qo)}
function Dl(a,b){w((I(),I(),H),new Il(a,b),Qo)}
function un(a,b){w((I(),I(),H),new Cn(a,b),Qo)}
function Nn(a,b){w((I(),I(),H),new Rn(a,b),Qo)}
function On(a,b){w((I(),I(),H),new Qn(a,b),Qo)}
function cl(a,b){var c;c=b.target;el(a,c.value)}
function Dn(a,b){this.a=a;this.c=b;this.b=false}
function Oi(a,b,c){this.a=a;this.b=b;this.c=c}
function ri(){this.a=new xi;this.b=new Li}
function D(){this.f=new cb;this.a=new Hb(this.f)}
function wn(a){Dh(new _h(a.g),new ec(a));Th(a.g)}
function Gb(a){while(true){if(!Fb(a)){break}}}
function Ib(a){if(!a.a){a.a=true;v((I(),I(),H))}}
function Vi(a){if(!a.d){a.d=a.b.O();a.c=a.b.Q()}}
function Yh(a){var b;b=a.a.V();a.b=Xh(a);return b}
function rh(a){var b;b=oh(a);b.j=a;b.e=1;return b}
function di(a,b){a.a[a.a.length]=b;return true}
function rb(a,b){gb(b,a);b.c.a.length>0||(b.a=4)}
function hj(a,b,c){if(a.a.bb(c)){a.b=true;b.w(c)}}
function hh(a,b,c,d){a.addEventListener(b,c,d)}
function ih(a,b,c,d){a.removeEventListener(b,c,d)}
function Hi(a,b){return !(a.a.get(b)===undefined)}
function $c(a){return Array.isArray(a)&&a.kb===dh}
function hd(a){return !Array.isArray(a)&&a.kb===dh}
function xn(a){return jh(),0==R(a.e).a?true:false}
function Ik(a){return A((I(),I(),H),a.b,new Nk(a))}
function Rk(a){return A((I(),I(),H),a.a,new Vk(a))}
function dl(a){return A((I(),I(),H),a.a,new hl(a))}
function cj(a){$i(a);return new ej(a,new kj(a.a))}
function Cl(a){return A((I(),I(),H),a.b,new Hl(a))}
function Tl(a){return A((I(),I(),H),a.a,new Xl(a))}
function sn(a){Q(a.c);Q(a.e);Q(a.a);Q(a.b);db(a.d)}
function hi(a,b){var c;c=a.a[b];uj(a.a,b);return c}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ji(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Vh(a,b){if(b){return Oh(a.a,b)}return false}
function Si(a){if(a==null){throw Lg(new Eh)}return a}
function Fj(){if(Aj==256){zj=Bj;Bj=new o;Aj=0}++Aj}
function Sc(){Sc=$g;var a;!Uc();a=new Vc;Rc=a}
function gh(){gh=$g;fh=$wnd.window.document}
function Ch(){Ch=$g;Bh=Yc(ce,xo,32,256,0,1)}
function Tn(a){return Gh(Wo,a)||Gh(Xo,a)||Gh('',a)}
function M(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Pk(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function Ek(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function tl(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function Zi(a){if(!a.b){$i(a);a.c=true}else{Zi(a.b)}}
function bj(a,b){$i(a);return new ej(a,new ij(b,a.a))}
function Sm(a,b){w((I(),I(),H),new _m(a,b),75497472)}
function el(a,b){var c;c=a.e;if(b!=c){a.e=b;ib(a.b)}}
function El(a,b){var c;c=a.d;if(b!=c){a.d=b;ib(a.a)}}
function Wm(a,b){var c;c=a.e;if(b!=c){a.e=Si(b);ib(a.b)}}
function qh(a,b){var c;c=oh(a);wh(a,c);c.e=b?8:0;return c}
function $j(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Ui(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Wi(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function $b(a,b){this.a=(I(),I(),H).b++;this.d=a;this.e=b}
function kj(a){Ui.call(this,a._(),a.$()&-6);this.a=a}
function _i(a){if(!a){this.b=null;new li}else{this.b=a}}
function Qg(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function kb(a){var b;I();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function Qm(a){var b;T(a.a);b=R(a.a);Gh(a.f,b)&&Wm(a,b)}
function qi(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function tn(a,b){return t((I(),I(),H),new Dn(a,b),Qo,null)}
function pb(a){B((I(),I(),H),a);0==(a.f.a&Co)&&C((null,H))}
function Mm(a){hh((gh(),$wnd.window.window),To,a.d,false)}
function Nm(a){ih((gh(),$wnd.window.window),To,a.d,false)}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function th(a){if(a.M()){return null}var b=a.j;return Wg[b]}
function Qb(a){if(a.e){2==(a.e.c&7)||wb(a.e,4,true);sb(a.e)}}
function ll(a,b){var c;if(R(a.c)){c=b.target;El(a,c.value)}}
function qc(a,b){var c;c=mh(a.ib);return b==null?c:c+': '+b}
function Ph(a,b){return b===a?'(this Map)':b==null?Io:bh(b)}
function Dh(a,b){var c,d;for(d=a.O();d.U();){c=d.V();b.w(c)}}
function Ln(a,b){var c;dj(vn(a.b),(c=new li,c)).N(new ro(b))}
function sh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function bm(){bm=$g;var a;am=(a=_g(_l.prototype.hb,_l,[]),a)}
function fm(){fm=$g;var a;em=(a=_g(dm.prototype.hb,dm,[]),a)}
function jm(){jm=$g;var a;im=(a=_g(hm.prototype.hb,hm,[]),a)}
function nm(){nm=$g;var a;mm=(a=_g(lm.prototype.hb,lm,[]),a)}
function rm(){rm=$g;var a;qm=(a=_g(pm.prototype.hb,pm,[]),a)}
function Km(){Km=$g;Hm=new zn;Im=new Pn(Hm);Jm=new _n(Hm)}
function Om(a,b){b.preventDefault();w((I(),I(),H),new bn(a),Qo)}
function ol(a,b){$n((Km(),Jm),b);w((I(),I(),H),new Il(a,b),Qo)}
function vn(a){jb(a.d);return new ej(null,new Wi(new _h(a.g),0))}
function no(){lo();return ad(Wc(zg,1),xo,34,0,[io,ko,jo])}
function mi(a){ci(this);tj(this.a,Nh(a,Yc(ge,xo,1,Uh(a.a),5,1)))}
function yi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function $i(a){if(a.b){$i(a.b)}else if(a.c){throw Lg(new yh)}}
function kc(a){ic(a.g);!!a.e&&jc(a);X(a.a);X(a.c);ic(a.b);ic(a.f)}
function ui(a,b){var c;return si(b,ti(a,b==null?0:(c=r(b),c|0)))}
function ti(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function Yg(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function ah(a){function b(){}
;b.prototype=a||{};return new b}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Zj(a){a.placeholder='What needs to be done?';return a}
function cm(a){$wnd.React.Component.call(this,a);this.a=new Jk(this)}
function gm(a){$wnd.React.Component.call(this,a);this.a=new Sk(this)}
function km(a){$wnd.React.Component.call(this,a);this.a=new fl(this)}
function om(a){$wnd.React.Component.call(this,a);this.a=new Fl(this)}
function sm(a){$wnd.React.Component.call(this,a);this.a=new Ul(this)}
function ij(a,b){Ui.call(this,b._(),b.$()&-16449);this.a=a;this.c=b}
function Mi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Pn(a){this.b=Si(a);I();this.a=new mc(0,null,null,true,false)}
function yl(a){return jh(),Xn((Km(),Jm))==a.j.props['a']?true:false}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Sh(a,b){return nd(b)?b==null?wi(a.a,null):Ki(a.b,b):wi(a.a,b)}
function fb(a,b){var c,d;di(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function dj(a,b){var c;Zi(a);c=new nj;c.a=b;a.a.T(new qj(c));return c.a}
function aj(a){var b;Zi(a);b=0;while(a.a.ab(new oj)){b=Mg(b,1)}return b}
function $(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=M(a.a[c])}return b}
function K(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Xi(a,b){!a.a?(a.a=new Kh(a.d)):Ih(a.a,a.b);Ih(a.a,b);return a}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function Oj(a,b,c){!Gh(c,'key')&&!Gh(c,'ref')&&(a[c]=b[c],undefined)}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function Nb(b){try{b.b.v()}catch(a){a=Kg(a);if(!jd(a,5))throw Lg(a)}}
function Mn(a){var b;dj(bj(vn(a.b),new po),(b=new li,b)).N(new qo(a.b))}
function Yn(a){var b,c;return b=R(a.b),dj(bj(vn(a.i),new so(b)),(c=new li,c))}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function gn(a,b){var c;if(jd(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function Ni(a){if(a.a.c!=a.c){return Ii(a.a,a.b.value[0])}return a.b.value[1]}
function gi(a,b,c){for(;c<a.a.length;++c){if(qi(b,a.a[c])){return c}}return -1}
function ii(a,b){var c;c=gi(a,b,0);if(c==-1){return false}uj(a.a,c);return true}
function ei(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function cb(){var a;this.a=Yc(ud,xo,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new O}}
function Zh(a){this.d=a;this.c=new Mi(this.d.b);this.a=this.c;this.b=Xh(this)}
function Yi(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Un(a,b){return (lo(),jo)==a||(io==a?(jb(b.a),!b.d):(jb(b.a),b.d))}
function Rh(a,b,c){return nd(b)?b==null?vi(a.a,null,c):Ji(a.b,b,c):vi(a.a,b,c)}
function vj(a,b){return Xc(b)!=10&&ad(q(b),b.jb,b.__elementTypeId$,Xc(b),a),a}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Q(a){if(!a.a){a.a=true;a.n=null;a.b=null;db(a.e);2==(a.f.c&7)||ob(a.f)}}
function C(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Gb(a.a)}finally{a.c=false}}}}
function db(a){if(-2!=a.e){t((I(),I(),H),new F(new nb(a)),0,null);!!a.b&&ob(a.b)}}
function hc(a){if(a.i>=0){a.i=-2;t((I(),I(),H),new F(new nc(a)),67108864,null)}}
function Lm(a,b){a.f=b;Gh(b,R(a.a))&&Wm(a,b);Pm(b);w((I(),I(),H),new bn(a),Qo)}
function Xk(a,b){if(13==b.keyCode){b.preventDefault();w((I(),I(),H),new il(a),Qo)}}
function Wk(a){var b;b=Hh((jb(a.b),a.e));if(b.length>0){In((Km(),Im),b);el(a,'')}}
function ac(){var a;try{Rb(Pb);I()}finally{a=Pb.d;!a&&((I(),I(),H).d=true);Pb=Pb.d}}
function vb(b){if(b){try{b.v()}catch(a){a=Kg(a);if(jd(a,5)){I()}else throw Lg(a)}}}
function U(a){if(a.b){if(jd(a.b,8)){throw Lg(a.b)}else{throw Lg(a.b)}}return a.n}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Mj(a){var b;return Kj($wnd.React.StrictMode,null,null,(b={},b[Mo]=Si(a),b))}
function oh(a){var b;b=new nh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Kg(a){var b;if(jd(a,5)){return a}b=a&&a[Go];if(!b){b=new wc(a);Tc(b)}return b}
function wh(a,b){var c;if(!a){return}b.j=a;var d=th(b);if(!d){Wg[a]=[b];return}d.ib=b}
function _g(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Ki(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{zi(a.a,b);--a.b}return c}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;di((!a.b&&(a.b=new li),a.b),b)}}}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new li);a.c=c.c}b.d=true;di(a.c,Si(b))}
function sb(a){var b,c;for(c=new ni(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function oi(a){var b,c,d;d=0;for(c=new Zh(a.a);c.b;){b=Yh(c);d=d+(b?r(b):0);d=d|0}return d}
function Jj(a){var b;b=Lj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Kj(a,b,c,d){var e;e=Lj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Si(d);return e}
function rn(a,b,c){var d;d=new on(b,c);fn(d,a,new fc(a,d));Rh(a.g,Ah(d.c.d),d);ib(a.d);return d}
function Mh(a,b){var c,d;for(d=new Zh(b.a);d.b;){c=Yh(d);if(!Vh(a,c)){return false}}return true}
function Dm(a,b){Ij(a.a,(lh(Rf),Rf.k+(''+(b?Ah(b.c.d):null))));Si(b);a.a.props['a']=b;return a.a}
function Xh(a){if(a.a.U()){return true}if(a.a!=a.c){return false}a.a=new yi(a.d.a);return a.a.U()}
function Ng(a){var b;b=a.h;if(b==0){return a.l+a.m*Do}if(b==1048575){return a.l+a.m*Do-Jo}return a}
function Pg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Jo;d=1048575}c=pd(e/Do);b=pd(e-c*Do);return bd(b,c,d)}
function si(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(qi(a,c.X())){return c}}return null}
function Sg(){Tg();var a=Rg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function yh(){sc.call(this,"Stream already terminated, can't be modified or used")}
function zb(a,b,c){yb.call(this,null,a,b,c|(!a?262144:zo)|(0==(c&6291456)?!a?Co:Do:0)|0|0|0)}
function Ob(a,b){this.b=Si(a);this.a=b|0|(0==(b&6291456)?Do:0)|(0!=(b&229376)?0:98304)}
function Vg(a,b){typeof window===uo&&typeof window['$gwt']===uo&&(window['$gwt'][a]=b)}
function md(a){return a!=null&&(typeof a===uo||typeof a==='function')&&!(a.kb===dh)}
function lo(){lo=$g;io=new mo('ACTIVE',0);ko=new mo('COMPLETED',1);jo=new mo('ALL',2)}
function eh(){Km();$wnd.ReactDOM.render(Mj([(new Gm).a]),(gh(),fh).getElementById('app'),null)}
function nl(a,b,c){27==c.which?w((I(),I(),H),new Ml(a,b),Qo):13==c.which&&w((I(),I(),H),new Kl(a,b),Qo)}
function ob(a){if(2<(a.c&7)){t((I(),I(),H),new F(new Db(a)),67108864,null);!!a.a&&Q(a.a);Kb(a.f);a.c=a.c&-8|1}}
function Bk(){if(!Ak){Ak=(++(I(),I(),H).e,new Jb);$wnd.Promise.resolve(null).then(_g(Ck.prototype.G,Ck,[]))}}
function Zn(a){var b;b=R(a.g.a);Gh(Wo,b)||Gh(Xo,b)||Gh('',b)?Sm(a.g,b):Tn(Tm(a.g))?Vm(a.g):Sm(a.g,'')}
function bc(a,b,c){var d;d=Sh(a.g,b?Ah(b.c.d):null);if(null!=d){lc(b.c,a);c&&!!b&&hc(b.c);ib(a.d)}}
function $n(a,b){var c;c=a.e;if(!(b==c||!!b&&gn(b,c))){!!c&&lc(c.c,a);a.e=b;!!b&&fn(b,a,new co(a));ib(a.d)}}
function gb(a,b){var c,d;d=a.c;ii(d,b);!!a.b&&zo!=(a.b.c&Ao)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((I(),c=Pb,c),a))}
function Ji(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ad(a,b,c,d,e){e.ib=a;e.jb=b;e.kb=dh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function pl(a,b){var c;c=(jb(a.a),a.d);if(null!=c&&c.length!=0){Nn((Km(),b),c);$n(Jm,null);El(a,c)}else{un((Km(),Hm),b)}}
function ql(a){var b;b=R(a.c);if(!a.i&&b){a.i=true;Dl(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Lb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&zo)?Nb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function q(a){return nd(a)?je:ld(a)?$d:kd(a)?Yd:hd(a)?a.ib:$c(a)?a.ib:a.ib||Array.isArray(a)&&Wc(Rd,1)||Rd}
function r(a){return nd(a)?Ej(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.q():$c(a)?yj(a):!!a&&!!a.hashCode?a.hashCode():yj(a)}
function p(a,b){return nd(a)?Gh(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.o(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function Ah(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Ch(),Bh)[b];!c&&(c=Bh[b]=new zh(a));return c}return new zh(a)}
function bh(a){var b;if(Array.isArray(a)&&a.kb===dh){return mh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Ej(a){Cj();var b,c,d;c=':'+a;d=Bj[c];if(d!=null){return pd(d)}d=zj[c];b=d==null?Dj(a):pd(d);Fj();Bj[c]=b;return b}
function wc(a){uc();oc(this);this.e=a;a!=null&&wj(a,Go,this);this.f=a==null?Io:bh(a);this.a='';this.b=a;this.a=''}
function nh(){this.g=kh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Ul(a){var b;this.j=Si(a);I();b=++Sl;this.b=new mc(b,null,new Vl(this),false,false);this.a=new zb(null,Si(new Wl(this)),Po)}
function Sk(a){var b;this.j=Si(a);I();b=++Qk;this.b=new mc(b,null,new Tk(this),false,false);this.a=new zb(null,Si(new Uk(this)),Po)}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=hi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&wb(b.b,3,true)}}}
function Z(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=L(d);return c}}return null}
function pi(a){var b,c,d;d=1;for(c=new ni(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function jc(a){var b,c,d;for(c=new ni(new mi(new Wh(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.X();jd(d,9)&&d.u()||b.Y().v()}}
function zk(){xk();return ad(Wc(We,1),xo,7,0,[bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk])}
function Ab(a,b){yb.call(this,a,new Bb(a),null,b|(zo==(b&Ao)?0:524288)|(0==(b&6291456)?zo==(b&Ao)?Do:Co:0)|0|268435456|0)}
function Mg(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<Jo){return c}}return Ng(cd(ld(a)?Pg(a):a,ld(b)?Pg(b):b))}
function vh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function ki(a,b){var c,d;d=a.a.length;b.length<d&&(b=vj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Nh(a,b){var c,d,e;e=Uh(a.a);b.length<e&&(b=vj(new Array(e),b));d=new Zh(a.a);for(c=0;c<e;++c){b[c]=Yh(d)}b.length>e&&(b[e]=null);return b}
function Qj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function mc(a,b,c,d,e){var f;this.d=a;this.e=d?new ri:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new mb((I(),null)),f):null;this.c=null}
function on(a,b){var c,d,e;this.e=Si(a);this.d=b;I();c=++dn;this.c=new mc(c,null,new pn(this),true,true);this.b=(e=new mb(null),e);this.a=(d=new mb(null),d)}
function fl(a){var b,c;this.j=Si(a);I();b=++_k;this.c=new mc(b,null,new gl(this),false,false);this.b=(c=new mb(null),c);this.a=new zb(null,Si(new kl(this)),Po)}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.jb){return !!a.jb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function L(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function R(a){a.k?kb(a.e):jb(a.e);if(xb(a.f)){if(a.k&&(I(),!(!!Pb&&!!Pb.e))){return t((I(),I(),H),new W(a),83888128,null)}else{qb(a.f)}}return U(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ni(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&wb(b,5,true)}}}
function Yb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ni(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&wb(b,6,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ni(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?wb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Hh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=Kg(a);if(jd(a,5)){e=a;throw Lg(e)}else throw Lg(a)}finally{C(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=Kg(a);if(jd(a,5)){f=a;throw Lg(f)}else throw Lg(a)}finally{C(b)}}
function Fb(a){var b,c;if(0==a.c){b=$(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Z(a.d);Lb(c);return true}
function Ug(b,c,d,e){Tg();var f=Rg;$moduleName=c;$moduleBase=d;Jg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{to(g)()}catch(a){b(c,a)}}else{to(g)()}}
function V(a,b,c,d){this.c=Si(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new Ab(this,d&-16385);this.e=new mb(this.f);zo==(d&Ao)&&pb(this.f)}
function Jk(a){var b;this.j=Si(a);I();b=++Gk;this.c=new mc(b,null,new Kk(this),false,false);this.a=new V(new Lk,null,null,136478720);this.b=new zb(null,Si(new Mk(this)),Po)}
function Lj(a,b){var c;c=new $wnd.Object;c.$$typeof=Si(a);c.type=Si(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ei(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Fi()}}
function Xg(){Wg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].lb()&&(c=Pc(c,g)):g[0].lb()}catch(a){a=Kg(a);if(jd(a,5)){d=a;Bc();Hc(jd(d,35)?d.F():d)}else throw Lg(a)}}return c}
function $k(a){var b;a.d=0;Bk();b=Nj(Ro,Uj(Xj(Yj(_j(Zj(Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,['new-todo']))),(jb(a.b),a.e)),_g(tm.prototype.fb,tm,[a])),_g(um.prototype.eb,um,[a]))),null);return b}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?Io:md(b)?b==null?null:b.name:nd(b)?'String':mh(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function P(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.n=d;b.b=null;hb(b.e)}}catch(a){a=Kg(a);if(jd(a,12)){c=a;if(!b.b){b.n=null;b.b=c;hb(b.e)}throw Lg(c)}else throw Lg(a)}}
function vi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=si(b,e);if(f){return f.Z(c)}}e[e.length]=new bi(b,c);++a.b;return null}
function rj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Dj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Fh(a,c++)}b=b|0;return b}
function qb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;u((I(),I(),H),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Kg(a);if(jd(a,5)){I()}else throw Lg(a)}}}
function N(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Yc(ge,xo,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Pm(a){var b;if(0==a.length){b=(gh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',fh.title,b)}else{(gh(),$wnd.window.window).location.hash=a}}
function yb(a,b,c,d){this.b=new li;this.f=new Ob(new Cb(this),d&6520832|262144|zo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(B((I(),I(),H),this),0==(this.f.a&Co)&&C((null,H)))}
function wi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(qi(b,e.X())){if(d.length==1){d.length=0;zi(a.a,g)}else{d.splice(h,1)}--a.b;return e.Y()}}return null}
function Fl(a){var b,c;this.j=Si(a);I();b=++vl;this.e=new mc(b,null,new Gl(this),false,false);this.a=(c=new mb(null),c);this.c=new V(new Jl(this),null,null,136478720);this.b=new zb(null,Si(new Ol(this)),Po);Dl(this,this.j.props['a'])}
function Zg(a,b,c){var d=Wg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Wg[b]),ah(h));_.jb=c;!b&&(_.kb=dh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ib=f)}
function uh(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=vh('.',[c,vh('$',d)]);a.b=vh('.',[c,vh('.',d)]);a.i=d[d.length-1]}
function Oh(a,b){var c,d,e;c=b.X();e=b.Y();d=nd(c)?c==null?Qh(ui(a.a,null)):Ii(a.b,c):Qh(ui(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!ui(a.a,null):Hi(a.b,c):!!ui(a.a,c))){return false}return true}
function Nj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Hj(b,_g(Pj.prototype.cb,Pj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Mo]=c[0],undefined):(d[Mo]=c,undefined));return Kj(a,e,f,d)}
function Xm(){var a,b;this.d=new ho(this);this.f=this.e=(b=(gh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));I();this.c=new mc(0,null,new Ym(this),true,false);this.b=(a=new mb(null),a);this.a=new V(new cn,new Zm(this),new $m(this),35651584)}
function _n(a){var b;this.i=Si(a);this.g=new Xm;I();this.f=new mc(0,new ao(this),new bo(this),true,false);this.d=(b=new mb(null),b);this.b=new V(new eo(this),null,null,Vo);this.c=new V(new fo(this),null,null,Vo);this.a=new zb(Si(new go(this)),null,681574400);C((null,H))}
function zn(){var a;this.g=new ri;I();this.f=new mc(0,new Bn(this),new An(this),true,false);this.d=(a=new mb(null),a);this.c=new V(new En(this),null,null,Vo);this.e=new V(new Fn(this),null,null,Vo);this.a=new V(new Gn(this),null,null,Vo);this.b=new V(new Hn(this),null,null,Vo)}
function xb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ni(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{R(c)}catch(a){a=Kg(a);if(!jd(a,5))throw Lg(a)}if(6==(b.c&7)){return true}}}}}sb(b);return false}
function Di(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function wb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||B((I(),I(),H),a))}else if(!!a.a&&4==g&&(6==b||5==b)){lb(a.a.e);vb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||B((I(),I(),H),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;vb((e=d.i,e));d.n=null}ei(a.b,new Eb(a));a.b.a=Yc(ge,xo,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&vb((f=a.a.g,f))}}
function xk(){xk=$g;bk=new yk(No,0);ck=new yk('checkbox',1);dk=new yk('color',2);ek=new yk('date',3);fk=new yk('datetime',4);gk=new yk('email',5);hk=new yk('file',6);ik=new yk('hidden',7);jk=new yk('image',8);kk=new yk('month',9);lk=new yk(vo,10);mk=new yk('password',11);nk=new yk('radio',12);ok=new yk('range',13);pk=new yk('reset',14);qk=new yk('search',15);rk=new yk('submit',16);sk=new yk('tel',17);tk=new yk('text',18);uk=new yk('time',19);vk=new yk('url',20);wk=new yk('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=fi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ji(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{gb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&wb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=fi(a.b,g);if(-1==k.e){k.e=0;fb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){hi(a.b,g)}e&&ub(a.e,a.b)}else{e&&ub(a.e,new li)}if(Y(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&zo!=(k.b.c&Ao)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function Fk(a){var b,c;a.d=0;Bk();c=(b=R((Km(),Jm).b),Nj('footer',Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,['footer'])),[(new $l).a,Nj('ul',Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,['filters'])),[Nj('li',null,[Nj('a',Sj(Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,[(lo(),jo)==b?Oo:null])),'#'),['All'])]),Nj('li',null,[Nj('a',Sj(Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,[io==b?Oo:null])),'#active'),['Active'])]),Nj('li',null,[Nj('a',Sj(Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,[ko==b?Oo:null])),'#completed'),['Completed'])])]),R(a.a)?Nj(No,Tj(Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,['clear-completed'])),_g(Yl.prototype.gb,Yl,[])),['Clear Completed']):null]));return c}
function ul(a){var b,c,d,e;a.f=0;Bk();b=a.j.props['a'];if(b.c.i<0){return null}c=(d=a.j.props['a'],e=(jb(d.a),d.d),Nj('li',Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,[e?'checked':null,R(a.c)?'editing':null])),[Nj('div',Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,['view'])),[Nj(Ro,Xj(Vj($j(Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,['toggle'])),(xk(),ck)),e),_g(xm.prototype.eb,xm,[d])),null),Nj('label',ak(new $wnd.Object,_g(ym.prototype.gb,ym,[a,d])),[(jb(d.b),d.e)]),Nj(No,Tj(Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,['destroy'])),_g(zm.prototype.gb,zm,[d])),null)]),Nj(Ro,Yj(Xj(Wj(_j(Qj(Rj(new $wnd.Object,_g(Am.prototype.w,Am,[a])),ad(Wc(je,1),xo,2,6,['edit'])),(jb(a.a),a.d)),_g(Bm.prototype.db,Bm,[a,d])),_g(wm.prototype.eb,wm,[a])),_g(Cm.prototype.fb,Cm,[a,d])),null)]));return c}
function Fi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Lo]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Di()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Lo]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var uo='object',vo='number',wo={11:1},xo={3:1,4:1},yo={9:1},zo=1048576,Ao=1835008,Bo={6:1},Co=2097152,Do=4194304,Eo={26:1},Fo='__noinit__',Go='__java$exception',Ho={3:1,12:1,8:1,5:1},Io='null',Jo=17592186044416,Ko={40:1},Lo='delete',Mo='children',No='button',Oo='selected',Po=1411518464,Qo=142606336,Ro='input',So='header',To='hashchange',Uo={9:1,49:1},Vo=136314880,Wo='active',Xo='completed';var _,Wg,Rg,Jg=-1;Xg();Zg(1,null,{},o);_.o=Zo;_.p=function(){return this.ib};_.q=$o;_.r=function(){var a;return mh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var dd,ed,fd;Zg(51,1,{},nh);_.H=function(a){var b;b=new nh;b.e=4;a>1?(b.c=sh(this,a-1)):(b.c=this);return b};_.I=function(){lh(this);return this.b};_.J=function(){return mh(this)};_.K=function(){lh(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(lh(this),this.k)};_.e=0;_.g=0;var kh=1;var ge=ph(1);var Zd=ph(51);Zg(79,1,{},D);_.b=1;_.c=false;_.d=true;_.e=0;var td=ph(79);Zg(36,1,wo,F);_.s=function(){return this.a.v(),null};var rd=ph(36);Zg(80,1,{},G);var sd=ph(80);var H;Zg(43,1,{43:1},O);_.b=0;_.c=false;_.d=0;var ud=ph(43);Zg(210,1,yo);_.r=function(){var a;return mh(this.ib)+'@'+(a=r(this)>>>0,a.toString(16))};var yd=ph(210);Zg(20,210,yo,V);_.t=function(){Q(this)};_.u=Yo;_.a=false;_.d=0;_.k=false;var wd=ph(20);Zg(115,1,wo,W);_.s=function(){return S(this.a)};var vd=ph(115);Zg(135,1,{242:1},cb);var xd=ph(135);Zg(17,210,{9:1,17:1},mb);_.t=function(){db(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Ad=ph(17);Zg(114,1,Bo,nb);_.v=function(){eb(this.a)};var zd=ph(114);Zg(18,210,{9:1,18:1},zb,Ab);_.t=function(){ob(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Fd=ph(18);Zg(116,1,Eo,Bb);_.v=function(){P(this.a)};var Bd=ph(116);Zg(117,1,Bo,Cb);_.v=function(){qb(this.a)};var Cd=ph(117);Zg(118,1,Bo,Db);_.v=function(){tb(this.a)};var Dd=ph(118);Zg(119,1,{},Eb);_.w=function(a){rb(this.a,a)};var Ed=ph(119);Zg(134,1,{},Hb);_.a=0;_.b=0;_.c=0;var Gd=ph(134);Zg(155,1,yo,Jb);_.t=function(){Ib(this)};_.u=Yo;_.a=false;var Hd=ph(155);Zg(61,210,{9:1,61:1},Ob);_.t=function(){Kb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Id=ph(61);Zg(137,1,{},$b);_.r=function(){var a;return lh(Jd),Jd.k+'@'+(a=yj(this)>>>0,a.toString(16))};_.a=0;var Pb;var Jd=ph(137);Zg(102,1,{});var Md=ph(102);Zg(81,1,{},ec);_.w=function(a){cc(this.a,a)};var Kd=ph(81);Zg(82,1,Bo,fc);_.v=function(){dc(this.a,this.b)};var Ld=ph(82);Zg(103,102,{});var Nd=ph(103);Zg(16,1,yo,mc);_.t=function(){hc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return lh(Pd),Pd.k+'@'+(a=yj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Pd=ph(16);Zg(113,1,Bo,nc);_.v=function(){kc(this.a)};var Od=ph(113);Zg(5,1,{3:1,5:1});_.B=function(a){return new Error(a)};_.C=function(){return this.f};_.D=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=mh(this.ib),c==null?a:a+': '+c);pc(this,rc(this.B(b)));Tc(this)};_.r=function(){return qc(this,this.C())};_.e=Fo;_.g=true;var ke=ph(5);Zg(12,5,{3:1,12:1,5:1});var ae=ph(12);Zg(8,12,Ho);var he=ph(8);Zg(52,8,Ho);var de=ph(52);Zg(73,52,Ho);var Td=ph(73);Zg(35,73,{35:1,3:1,12:1,8:1,5:1},wc);_.C=function(){vc(this);return this.c};_.F=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Qd=ph(35);var Rd=ph(0);Zg(196,1,{});var Sd=ph(196);var yc=0,zc=0,Ac=-1;Zg(101,196,{},Oc);var Kc;var Ud=ph(101);var Rc;Zg(207,1,{});var Wd=ph(207);Zg(74,207,{},Vc);var Vd=ph(74);var fh;Zg(71,1,{68:1});_.r=Yo;var Xd=ph(71);dd={3:1,69:1,31:1};var Yd=ph(69);Zg(41,1,{3:1,41:1});var fe=ph(41);ed={3:1,31:1,41:1};var $d=ph(206);Zg(33,1,{3:1,31:1,33:1});_.o=Zo;_.q=$o;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var _d=ph(33);Zg(75,8,Ho,yh);var be=ph(75);Zg(32,41,{3:1,31:1,32:1,41:1},zh);_.o=function(a){return jd(a,32)&&a.a==this.a};_.q=Yo;_.r=function(){return ''+this.a};_.a=0;var ce=ph(32);var Bh;Zg(274,1,{});Zg(77,52,Ho,Eh);_.B=function(a){return new TypeError(a)};var ee=ph(77);fd={3:1,68:1,31:1,2:1};var je=ph(2);Zg(72,71,{68:1},Kh);var ie=ph(72);Zg(278,1,{});Zg(54,8,Ho,Lh);var le=ph(54);Zg(208,1,{39:1});_.N=cp;_.R=function(){return new Wi(this,0)};_.S=function(){return new ej(null,this.R())};_.P=function(a){throw Lg(new Lh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Yi('[',']');for(b=this.O();b.U();){a=b.V();Xi(c,a===this?'(this Collection)':a==null?Io:bh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var me=ph(208);Zg(211,1,{194:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!jd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Zh((new Wh(d)).a);c.b;){b=Yh(c);if(!Oh(this,b)){return false}}return true};_.q=function(){return oi(new Wh(this))};_.r=function(){var a,b,c;c=new Yi('{','}');for(b=new Zh((new Wh(this)).a);b.b;){a=Yh(b);Xi(c,Ph(this,a.X())+'='+Ph(this,a.Y()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var xe=ph(211);Zg(120,211,{194:1});var pe=ph(120);Zg(212,208,{39:1,223:1});_.R=function(){return new Wi(this,1)};_.o=function(a){var b;if(a===this){return true}if(!jd(a,22)){return false}b=a;if(Uh(b.a)!=this.Q()){return false}return Mh(this,b)};_.q=function(){return oi(this)};var ye=ph(212);Zg(22,212,{22:1,39:1,223:1},Wh);_.O=function(){return new Zh(this.a)};_.Q=ap;var oe=ph(22);Zg(23,1,{},Zh);_.T=_o;_.V=function(){return Yh(this)};_.U=bp;_.b=false;var ne=ph(23);Zg(209,208,{39:1,220:1});_.R=function(){return new Wi(this,16)};_.W=function(a,b){throw Lg(new Lh('Add not supported on this list'))};_.P=function(a){this.W(this.Q(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,14)){return false}f=a;if(this.Q()!=f.a.length){return false}e=new ni(f);for(c=new ni(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return pi(this)};_.O=function(){return new $h(this)};var re=ph(209);Zg(100,1,{},$h);_.T=_o;_.U=function(){return this.a<this.b.a.length};_.V=function(){return fi(this.b,this.a++)};_.a=0;var qe=ph(100);Zg(55,208,{39:1},_h);_.O=function(){var a;a=new Zh((new Wh(this.a)).a);return new ai(a)};_.Q=ap;var te=ph(55);Zg(123,1,{},ai);_.T=_o;_.U=function(){return this.a.b};_.V=function(){var a;a=Yh(this.a);return a.Y()};var se=ph(123);Zg(121,1,Ko);_.o=function(a){var b;if(!jd(a,40)){return false}b=a;return qi(this.a,b.X())&&qi(this.b,b.Y())};_.X=Yo;_.Y=bp;_.q=function(){return Ri(this.a)^Ri(this.b)};_.Z=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ue=ph(121);Zg(122,121,Ko,bi);var ve=ph(122);Zg(213,1,Ko);_.o=function(a){var b;if(!jd(a,40)){return false}b=a;return qi(this.b.value[0],b.X())&&qi(Ni(this),b.Y())};_.q=function(){return Ri(this.b.value[0])^Ri(Ni(this))};_.r=function(){return this.b.value[0]+'='+Ni(this)};var we=ph(213);Zg(14,209,{3:1,14:1,39:1,220:1},li,mi);_.W=function(a,b){sj(this.a,a,b)};_.P=function(a){return di(this,a)};_.N=function(a){ei(this,a)};_.O=function(){return new ni(this)};_.Q=function(){return this.a.length};var Ae=ph(14);Zg(19,1,{},ni);_.T=_o;_.U=function(){return this.a<this.c.a.length};_.V=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ze=ph(19);Zg(37,120,{3:1,37:1,194:1},ri);var Be=ph(37);Zg(59,1,{},xi);_.N=cp;_.O=function(){return new yi(this)};_.b=0;var De=ph(59);Zg(60,1,{},yi);_.T=_o;_.V=function(){return this.d=this.a[this.c++],this.d};_.U=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ce=ph(60);var Bi;Zg(57,1,{},Li);_.N=cp;_.O=function(){return new Mi(this)};_.b=0;_.c=0;var Ge=ph(57);Zg(58,1,{},Mi);_.T=_o;_.V=function(){return this.c=this.a,this.a=this.b.next(),new Oi(this.d,this.c,this.d.c)};_.U=function(){return !this.a.done};var Ee=ph(58);Zg(136,213,Ko,Oi);_.X=function(){return this.b.value[0]};_.Y=function(){return Ni(this)};_.Z=function(a){return Ji(this.a,this.b.value[0],a)};_.c=0;var Fe=ph(136);Zg(139,1,{});_.T=function(a){Ti(this,a)};_.$=function(){return this.d};_._=function(){return this.e};_.d=0;_.e=0;var Ie=ph(139);Zg(62,139,{});var He=ph(62);Zg(24,1,{},Wi);_.$=Yo;_._=function(){Vi(this);return this.c};_.T=function(a){Vi(this);this.d.T(a)};_.ab=function(a){Vi(this);if(this.d.U()){a.w(this.d.V());return true}return false};_.a=0;_.c=0;var Je=ph(24);Zg(53,1,{},Yi);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ke=ph(53);Zg(138,1,{});_.c=false;var Te=ph(138);Zg(28,138,{243:1,28:1},ej);var Se=ph(28);Zg(141,62,{},ij);_.ab=function(a){this.b=false;while(!this.b&&this.c.ab(new jj(this,a)));return this.b};_.b=false;var Me=ph(141);Zg(144,1,{},jj);_.w=function(a){hj(this.a,this.b,a)};var Le=ph(144);Zg(140,62,{},kj);_.ab=function(a){return this.a.ab(new lj(a))};var Oe=ph(140);Zg(143,1,{},lj);_.w=function(a){this.a.w(Dm(new Em,a))};var Ne=ph(143);Zg(142,1,{},nj);_.w=function(a){mj(this,a)};var Pe=ph(142);Zg(145,1,{},oj);_.w=function(a){};var Qe=ph(145);Zg(146,1,{},qj);_.w=function(a){pj(this,a)};var Re=ph(146);Zg(276,1,{});Zg(217,1,{});var Ue=ph(217);Zg(273,1,{});var xj=0;var zj,Aj=0,Bj;Zg(894,1,{});Zg(916,1,{});Zg(214,1,{});var Ve=ph(214);Zg(244,$wnd.Function,{},Pj);_.cb=function(a){Oj(this.a,this.b,a)};Zg(7,33,{3:1,31:1,33:1,7:1},yk);var bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk;var We=qh(7,zk);var Ak;Zg(245,$wnd.Function,{},Ck);_.G=function(a){return Ib(Ak),Ak=null,null};Zg(218,214,{});var Df=ph(218);Zg(168,218,{});_.d=0;var Hf=ph(168);Zg(169,168,yo,Jk);_.t=dp;_.o=Zo;_.q=$o;_.u=ep;_.r=function(){var a;return lh(df),df.k+'@'+(a=yj(this)>>>0,a.toString(16))};var Gk=0;var df=ph(169);Zg(170,1,Bo,Kk);_.v=function(){Hk(this.a)};var Xe=ph(170);Zg(171,1,wo,Lk);_.s=function(){return jh(),R((Km(),Hm).b).a>0?true:false};var Ye=ph(171);Zg(172,1,Eo,Mk);_.v=function(){Ek(this.a)};var Ze=ph(172);Zg(173,1,wo,Nk);_.s=function(){return Fk(this.a)};var $e=ph(173);Zg(219,214,{});var Cf=ph(219);Zg(188,219,{});_.c=0;var Gf=ph(188);Zg(189,188,yo,Sk);_.t=fp;_.o=Zo;_.q=$o;_.u=gp;_.r=function(){var a;return lh(cf),cf.k+'@'+(a=yj(this)>>>0,a.toString(16))};var Qk=0;var cf=ph(189);Zg(190,1,Bo,Tk);_.v=hp;var _e=ph(190);Zg(191,1,Eo,Uk);_.v=function(){Pk(this.a)};var af=ph(191);Zg(192,1,wo,Vk);_.s=function(){var a,b;return this.a.c=0,Bk(),a=R((Km(),Hm).e).a,b='item'+(a==1?'':'s'),Nj('span',Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,['todo-count'])),[Nj('strong',null,[a]),' '+b+' left'])};var bf=ph(192);Zg(160,214,{});_.e='';var Pf=ph(160);Zg(161,160,{});_.d=0;var Jf=ph(161);Zg(162,161,yo,fl);_.t=dp;_.o=Zo;_.q=$o;_.u=ep;_.r=function(){var a;return lh(kf),kf.k+'@'+(a=yj(this)>>>0,a.toString(16))};var _k=0;var kf=ph(162);Zg(163,1,Bo,gl);_.v=function(){al(this.a)};var ef=ph(163);Zg(165,1,wo,hl);_.s=function(){return $k(this.a)};var ff=ph(165);Zg(166,1,Bo,il);_.v=function(){Wk(this.a)};var gf=ph(166);Zg(167,1,Bo,jl);_.v=function(){cl(this.a,this.b)};var hf=ph(167);Zg(164,1,Eo,kl);_.v=function(){Ek(this.a)};var jf=ph(164);Zg(216,214,{});_.i=false;var Rf=ph(216);Zg(175,216,{});_.f=0;var Lf=ph(175);Zg(176,175,yo,Fl);_.t=function(){hc(this.e)};_.o=Zo;_.q=$o;_.u=function(){return this.e.i<0};_.r=function(){var a;return lh(vf),vf.k+'@'+(a=yj(this)>>>0,a.toString(16))};var vl=0;var vf=ph(176);Zg(177,1,Bo,Gl);_.v=function(){wl(this.a)};var lf=ph(177);Zg(180,1,wo,Hl);_.s=function(){return ul(this.a)};var mf=ph(180);Zg(63,1,Bo,Il);_.v=function(){El(this.a,Tm(this.b))};var nf=ph(63);Zg(178,1,wo,Jl);_.s=function(){return yl(this.a)};var of=ph(178);Zg(64,1,Bo,Kl);_.v=function(){pl(this.a,this.b)};var pf=ph(64);Zg(181,1,Bo,Ll);_.v=function(){ol(this.a,this.b)};var qf=ph(181);Zg(182,1,Bo,Ml);_.v=function(){Dl(this.a,this.b);$n((Km(),Jm),null)};var rf=ph(182);Zg(183,1,Bo,Nl);_.v=function(){ll(this.a,this.b)};var sf=ph(183);Zg(179,1,Eo,Ol);_.v=function(){tl(this.a)};var tf=ph(179);Zg(184,1,Bo,Pl);_.v=function(){ql(this.a)};var uf=ph(184);Zg(215,214,{});var Tf=ph(215);Zg(148,215,{});_.c=0;var Nf=ph(148);Zg(149,148,yo,Ul);_.t=fp;_.o=Zo;_.q=$o;_.u=gp;_.r=function(){var a;return lh(zf),zf.k+'@'+(a=yj(this)>>>0,a.toString(16))};var Sl=0;var zf=ph(149);Zg(150,1,Bo,Vl);_.v=hp;var wf=ph(150);Zg(151,1,Eo,Wl);_.v=function(){Pk(this.a)};var xf=ph(151);Zg(152,1,wo,Xl);_.s=function(){var a;return this.a.c=0,Bk(),Nj('div',null,[Nj('div',null,[Nj(So,Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,[So])),[Nj('h1',null,['todos']),(new vm).a]),R((Km(),Hm).c)?null:Nj('section',Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,[So])),[Nj(Ro,Xj($j(Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,['toggle-all'])),(xk(),ck)),_g(Fm.prototype.eb,Fm,[])),null),Nj('ul',Qj(new $wnd.Object,ad(Wc(je,1),xo,2,6,['todo-list'])),(a=dj(Si(cj(R(Jm.c).S())),new li),ki(a,_c(a.a.length))))]),R(Hm.c)?null:(new Zl).a])])};var yf=ph(152);Zg(249,$wnd.Function,{},Yl);_.gb=function(a){Kn((Km(),Im))};Zg(154,1,{},Zl);var Af=ph(154);Zg(174,1,{},$l);var Bf=ph(174);Zg(250,$wnd.Function,{},_l);_.hb=function(a){return new cm(a)};var am;Zg(158,$wnd.React.Component,{},cm);Yg(Wg[1],_);_.componentWillUnmount=function(){Dk(this.a)};_.render=function(){return Ik(this.a)};_.shouldComponentUpdate=ip;var Ef=ph(158);Zg(260,$wnd.Function,{},dm);_.hb=function(a){return new gm(a)};var em;Zg(185,$wnd.React.Component,{},gm);Yg(Wg[1],_);_.componentWillUnmount=function(){Ok(this.a)};_.render=function(){return Rk(this.a)};_.shouldComponentUpdate=jp;var Ff=ph(185);Zg(248,$wnd.Function,{},hm);_.hb=function(a){return new km(a)};var im;Zg(156,$wnd.React.Component,{},km);Yg(Wg[1],_);_.componentWillUnmount=function(){Dk(this.a)};_.render=function(){return dl(this.a)};_.shouldComponentUpdate=ip;var If=ph(156);Zg(259,$wnd.Function,{},lm);_.hb=function(a){return new om(a)};var mm;Zg(159,$wnd.React.Component,{},om);Yg(Wg[1],_);_.componentDidUpdate=function(a){Bl(this.a)};_.componentWillUnmount=function(){sl(this.a)};_.render=function(){return Cl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Kf=ph(159);Zg(241,$wnd.Function,{},pm);_.hb=function(a){return new sm(a)};var qm;Zg(125,$wnd.React.Component,{},sm);Yg(Wg[1],_);_.componentWillUnmount=function(){Ok(this.a)};_.render=function(){return Tl(this.a)};_.shouldComponentUpdate=jp;var Mf=ph(125);Zg(246,$wnd.Function,{},tm);_.fb=function(a){Xk(this.a,a)};Zg(247,$wnd.Function,{},um);_.eb=function(a){bl(this.a,a)};Zg(153,1,{},vm);var Of=ph(153);Zg(257,$wnd.Function,{},wm);_.eb=function(a){xl(this.a,a)};Zg(251,$wnd.Function,{},xm);_.eb=function(a){nn(this.a)};Zg(253,$wnd.Function,{},ym);_.gb=function(a){zl(this.a,this.b)};Zg(254,$wnd.Function,{},zm);_.gb=function(a){rl(this.a)};Zg(255,$wnd.Function,{},Am);_.w=function(a){ml(this.a,a)};Zg(256,$wnd.Function,{},Bm);_.db=function(a){Al(this.a,this.b)};Zg(258,$wnd.Function,{},Cm);_.fb=function(a){nl(this.a,this.b,a)};Zg(157,1,{},Em);var Qf=ph(157);Zg(240,$wnd.Function,{},Fm);_.eb=function(a){var b;b=a.target;On((Km(),Im),b.checked)};Zg(67,1,{},Gm);var Sf=ph(67);var Hm,Im,Jm;Zg(126,1,{});var yg=ph(126);Zg(127,126,Uo,Xm);_.t=dp;_.o=Zo;_.q=$o;_.u=ep;_.A=kp;_.r=function(){var a;return lh(_f),_f.k+'@'+(a=yj(this)>>>0,a.toString(16))};var _f=ph(127);Zg(128,1,Bo,Ym);_.v=function(){Rm(this.a)};var Uf=ph(128);Zg(130,1,Eo,Zm);_.v=function(){Mm(this.a)};var Vf=ph(130);Zg(131,1,Eo,$m);_.v=function(){Nm(this.a)};var Wf=ph(131);Zg(132,1,Bo,_m);_.v=function(){Lm(this.a,this.b)};var Xf=ph(132);Zg(133,1,Bo,an);_.v=function(){Um(this.a)};var Yf=ph(133);Zg(56,1,Bo,bn);_.v=function(){Qm(this.a)};var Zf=ph(56);Zg(129,1,wo,cn);_.s=function(){var a;return a=(gh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var $f=ph(129);Zg(44,1,{44:1});_.d=false;var Gg=ph(44);Zg(45,44,{9:1,49:1,45:1,44:1},on);_.t=dp;_.o=function(a){return gn(this,a)};_.q=function(){return this.c.d};_.u=ep;_.A=kp;_.r=function(){var a;return lh(pg),pg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var dn=0;var pg=ph(45);Zg(186,1,Bo,pn);_.v=function(){en(this.a)};var ag=ph(186);Zg(187,1,Bo,qn);_.v=function(){kn(this.a)};var bg=ph(187);Zg(42,103,{42:1});var Bg=ph(42);Zg(104,42,{9:1,49:1,42:1},zn);_.t=lp;_.o=Zo;_.q=$o;_.u=mp;_.A=np;_.r=function(){var a;return lh(kg),kg.k+'@'+(a=yj(this)>>>0,a.toString(16))};var kg=ph(104);Zg(106,1,Bo,An);_.v=function(){sn(this.a)};var cg=ph(106);Zg(105,1,Bo,Bn);_.v=function(){wn(this.a)};var dg=ph(105);Zg(111,1,Bo,Cn);_.v=function(){bc(this.a,this.b,true)};var eg=ph(111);Zg(112,1,wo,Dn);_.s=function(){return rn(this.a,this.c,this.b)};_.b=false;var fg=ph(112);Zg(107,1,wo,En);_.s=function(){return xn(this.a)};var gg=ph(107);Zg(108,1,wo,Fn);_.s=function(){return Ah(Qg(aj(vn(this.a))))};var hg=ph(108);Zg(109,1,wo,Gn);_.s=function(){return Ah(Qg(aj(bj(vn(this.a),new oo))))};var ig=ph(109);Zg(110,1,wo,Hn);_.s=function(){return yn(this.a)};var jg=ph(110);Zg(87,1,{});var Fg=ph(87);Zg(88,87,Uo,Pn);_.t=function(){hc(this.a)};_.o=Zo;_.q=$o;_.u=function(){return this.a.i<0};_.A=function(a){lc(this.a,a)};_.r=function(){var a;return lh(og),og.k+'@'+(a=yj(this)>>>0,a.toString(16))};var og=ph(88);Zg(89,1,Bo,Qn);_.v=function(){Ln(this.a,this.b)};_.b=false;var lg=ph(89);Zg(90,1,Bo,Rn);_.v=function(){Wm(this.b,this.a)};var mg=ph(90);Zg(91,1,Bo,Sn);_.v=function(){Mn(this.a)};var ng=ph(91);Zg(92,1,{});var Ig=ph(92);Zg(93,92,Uo,_n);_.t=lp;_.o=Zo;_.q=$o;_.u=mp;_.A=np;_.r=function(){var a;return lh(wg),wg.k+'@'+(a=yj(this)>>>0,a.toString(16))};var wg=ph(93);Zg(94,1,Bo,ao);_.v=function(){Wn(this.a)};var qg=ph(94);Zg(95,1,Bo,bo);_.v=function(){Vn(this.a)};var rg=ph(95);Zg(99,1,Bo,co);_.v=function(){$n(this.a,null)};var sg=ph(99);Zg(96,1,wo,eo);_.s=function(){var a;return a=Tm(this.a.g),Gh(Wo,a)?(lo(),io):Gh(Xo,a)?(lo(),ko):(lo(),jo)};var tg=ph(96);Zg(97,1,wo,fo);_.s=function(){return Yn(this.a)};var ug=ph(97);Zg(98,1,Eo,go);_.v=function(){Zn(this.a)};var vg=ph(98);Zg(124,1,{},ho);_.handleEvent=function(a){Om(this.a,a)};var xg=ph(124);Zg(34,33,{3:1,31:1,33:1,34:1},mo);var io,jo,ko;var zg=qh(34,no);Zg(83,1,{},oo);_.bb=function(a){return !jn(a)};var Ag=ph(83);Zg(85,1,{},po);_.bb=function(a){return jn(a)};var Cg=ph(85);Zg(86,1,{},qo);_.w=function(a){un(this.a,a)};var Dg=ph(86);Zg(84,1,{},ro);_.w=function(a){Jn(this.a,a)};_.a=false;var Eg=ph(84);Zg(76,1,{},so);_.bb=function(a){return Un(this.a,a)};var Hg=ph(76);var qd=rh('D');var to=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=Ug;Sg(eh);Vg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();