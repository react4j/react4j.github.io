function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='CD37F362FB6CBA44730E9AB39328FEC5',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'CD37F362FB6CBA44730E9AB39328FEC5';function o(){}
function fh(){}
function ah(){}
function ak(){}
function Rk(){}
function Rl(){}
function Ol(){}
function Oc(){}
function Vc(){}
function Vl(){}
function Zl(){}
function Ib(){}
function pj(){}
function qj(){}
function bm(){}
function fm(){}
function xm(){}
function Wm(){}
function Hn(){}
function fo(){}
function go(){}
function Vo(){}
function Tc(a){Sc()}
function lh(){lh=ah}
function G(a){this.a=a}
function H(a){this.a=a}
function mb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function hc(a){this.a=a}
function nc(a){this.a=a}
function nj(a){this.a=a}
function sj(a){this.a=a}
function Ah(a){this.a=a}
function Lh(a){this.a=a}
function Xh(a){this.a=a}
function _h(a){this.b=a}
function ai(a){this.a=a}
function bi(a){this.a=a}
function oi(a){this.c=a}
function Qk(a){this.a=a}
function Sk(a){this.a=a}
function Tk(a){this.a=a}
function Vk(a){this.a=a}
function Wk(a){this.a=a}
function Xk(a){this.a=a}
function dl(a){this.a=a}
function el(a){this.a=a}
function fl(a){this.a=a}
function hl(a){this.a=a}
function zl(a){this.a=a}
function Al(a){this.a=a}
function Bl(a){this.a=a}
function Gl(a){this.a=a}
function Jl(a){this.a=a}
function Ll(a){this.a=a}
function Ml(a){this.a=a}
function Nl(a){this.a=a}
function jm(a){this.a=a}
function km(a){this.a=a}
function mm(a){this.a=a}
function nm(a){this.a=a}
function pm(a){this.a=a}
function qm(a){this.a=a}
function Qm(a){this.a=a}
function Rm(a){this.a=a}
function Sm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function fn(a){this.a=a}
function gn(a){this.a=a}
function rn(a){this.a=a}
function sn(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function Kn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function ho(a){this.a=a}
function io(a){this.a=a}
function jo(a){this.a=a}
function Yo(){Wj(this.a)}
function gp(){Yj(this.a)}
function cp(){jc(this.b)}
function $o(){jc(this.c)}
function mi(){di(this)}
function yi(){this.a=Hi()}
function Mi(){this.a=Hi()}
function _j(){this.j=Uj++}
function oj(a,b){a.a=b}
function Rj(a,b){a.key=b}
function Jj(a,b){Ij(a,b)}
function An(a,b){bn(b,a)}
function tb(a,b){a.b=Ti(b)}
function cc(a,b){Th(a.b,b)}
function rj(a,b){hj(a.a,b)}
function zn(a,b){kn(a.b,b)}
function Ro(a){Qi(this,a)}
function Uo(a){Eh(this,a)}
function fp(){nb(this.a.a)}
function gb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function kb(a){Yb((J(),a))}
function w(a){--a.e;D(a)}
function kc(a){!!a&&a.A()}
function V(a){jd(a,8)&&a.v()}
function Lb(a){a.a=-4&a.a|1}
function Ng(a){return a.e}
function Oo(){return this.a}
function To(){return this.b}
function Hh(a,b){return a===b}
function kl(a,b){return a.f=b}
function C(a,b){ab(a.f,b.f)}
function Ok(a){nb(a.b);R(a.a)}
function Jm(a){R(a.a);cb(a.b)}
function J(){J=ah;I=new F}
function uc(){uc=ah;tc=new o}
function Lc(){Lc=ah;Kc=new Oc}
function dc(){this.b=new si}
function Di(){Di=ah;Ci=Fi()}
function Qo(){return Aj(this)}
function _o(){return this.c.c}
function dp(){return this.b.c}
function gi(a,b){return a.a[b]}
function wj(a,b){a.splice(b,1)}
function ac(a,b,c){Sh(a.b,b,c)}
function Ym(a){cb(a.b);cb(a.a)}
function $k(a){nb(a.a);cb(a.b)}
function ol(a){ln((Cm(),zm),a)}
function Ul(a){Nj.call(this,a)}
function Yl(a){Nj.call(this,a)}
function am(a){Nj.call(this,a)}
function em(a){Nj.call(this,a)}
function im(a){Nj.call(this,a)}
function Mh(a){sc.call(this,a)}
function Fh(){oc(this);this.G()}
function So(){return Vh(this.a)}
function Zo(){return $j(this.a)}
function Po(a){return this===a}
function ap(){return this.c.i<0}
function ep(){return this.b.i<0}
function Xo(){return J(),J(),I}
function Wc(a,b){return th(a,b)}
function hj(a,b){oj(a,gj(a.a,b))}
function Ui(a,b){while(a.cb(b));}
function gj(a,b){a.R(b);return a}
function ck(a,b){a.ref=b;return a}
function oh(a){nh(a);return a.k}
function Lm(a){ib(a.b);return a.e}
function _m(a){ib(a.a);return a.d}
function On(a){ib(a.d);return a.f}
function Hi(){Di();return new Ci}
function _c(a){return new Array(a)}
function Vh(a){return a.a.b+a.b.b}
function Ji(a,b){return a.a.get(b)}
function W(a){return !!a&&a.c.i<0}
function db(a){J();Xb(a);a.e=-2}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function Bc(){Bc=ah;!!(Sc(),Rc)}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function Vg(){Tg==null&&(Tg=[])}
function Mk(a,b){yh.call(this,a,b)}
function ic(a,b){this.a=a;this.b=b}
function yh(a,b){this.a=a;this.b=b}
function ci(a,b){this.a=a;this.b=b}
function kj(a,b){this.a=a;this.b=b}
function Qj(a,b){this.a=a;this.b=b}
function gl(a,b){this.a=a;this.b=b}
function Dl(a,b){this.a=a;this.b=b}
function El(a,b){this.a=a;this.b=b}
function Fl(a,b){this.a=a;this.b=b}
function Hl(a,b){this.a=a;this.b=b}
function Il(a,b){this.a=a;this.b=b}
function om(a,b){this.a=a;this.b=b}
function rm(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function Tm(a,b){this.a=a;this.b=b}
function tn(a,b){this.a=a;this.b=b}
function In(a,b){this.a=a;this.b=b}
function Jn(a,b){this.b=a;this.a=b}
function co(a,b){yh.call(this,a,b)}
function uj(a,b,c){a.splice(b,0,c)}
function dk(a,b){a.href=b;return a}
function Jh(a,b){a.a+=''+b;return a}
function tm(a){return um(new wm,a)}
function Rh(a){return !a?null:a.$()}
function ld(a){return typeof a===mo}
function od(a){return a==null?null:a}
function Sb(a){return !a.d?a:Sb(a.d)}
function an(a){bn(a,(ib(a.a),!a.d))}
function Mm(a){Km(a,(ib(a.b),a.e))}
function lm(){this.a=Tj((_l(),$l))}
function Pl(){this.a=Tj((Tl(),Sl))}
function Ql(){this.a=Tj((Xl(),Wl))}
function wm(){this.a=Tj((dm(),cm))}
function ym(){this.a=Tj((hm(),gm))}
function lb(a){this.c=new mi;this.b=a}
function Uh(a){a.a=new yi;a.b=new Mi}
function Ej(){Ej=ah;Bj=new o;Dj=new o}
function nk(a,b){a.value=b;return a}
function ik(a,b){a.onBlur=b;return a}
function ek(a,b){a.onClick=b;return a}
function gk(a,b){a.checked=b;return a}
function lj(a,b){a.B(vm(tm(b.c.e),b))}
function vj(a,b){tj(b,0,a,0,b.length)}
function gc(a,b){ec(a,b,false);hb(a.d)}
function A(a,b,c){t(a,new G(b),c,null)}
function sb(a){J();rb(a);vb(a,2,true)}
function di(a){a.a=Yc(fe,po,1,0,5,1)}
function P(){this.a=Yc(fe,po,1,100,5,1)}
function Gb(a){this.d=Ti(a);this.b=100}
function ib(a){var b;Tb((J(),b=Ob,b),a)}
function Wo(){return S((Cm(),zm).b).a>0}
function Si(a){return a!=null?r(a):0}
function jd(a,b){return a!=null&&gd(a,b)}
function Gh(a,b){return a.charCodeAt(b)}
function bd(a,b,c){return {l:a,m:b,h:c}}
function Ij(a,b){for(var c in a){b(c)}}
function Ic(a){$wnd.clearTimeout(a)}
function jk(a,b){a.onChange=b;return a}
function kk(a,b){a.onKeyDown=b;return a}
function fk(a){a.autoFocus=true;return a}
function nh(a){if(a.k!=null){return}vh(a)}
function sc(a){this.f=a;oc(this);this.G()}
function fj(a,b){aj.call(this,a);this.a=b}
function pc(a,b){a.e=b;b!=null&&yj(b,xo,a)}
function Qi(a,b){while(a.W()){rj(b,a.X())}}
function Ai(a,b){var c;c=a[Co];c.call(a,b)}
function yj(b,c,d){try{b[c]=d}catch(a){}}
function Aj(a){return a.$H||(a.$H=++zj)}
function X(a){return !(!!a&&1==(a.c&7))}
function nd(a){return typeof a==='string'}
function kd(a){return typeof a==='boolean'}
function um(a,b){return Rj(a.a,Ti(''+b)),a}
function u(a,b){return new yb(Ti(a),null,b)}
function si(){this.a=new yi;this.b=new Mi}
function ih(){ih=ah;hh=$wnd.window.document}
function Dh(){Dh=ah;Ch=Yc(be,po,30,256,0,1)}
function T(a){4==(a.f.c&7)&&vb(a.f,5,true)}
function Jb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function pn(a){return Bh(S(a.e).a-S(a.a).a)}
function Qn(a){W((ib(a.d),a.f))&&Sn(a,null)}
function dn(a){A((J(),J(),I),new gn(a),Ho)}
function Bn(a){A((J(),J(),I),new Kn(a),Ho)}
function Nm(a){A((J(),J(),I),new Um(a),Ho)}
function fc(a,b){cc(b.C(),a);jd(b,8)&&b.v()}
function Cc(a,b,c){return a.apply(b,c);var d}
function Pi(a,b,c){this.a=a;this.b=b;this.c=c}
function $(a,b,c){Lb(Ti(c));K(a.a[b],Ti(c))}
function ql(a){nb(a.b);R(a.d);cb(a.c);cb(a.a)}
function rh(a){var b;b=qh(a);xh(a,b);return b}
function oc(a){a.g&&a.e!==wo&&a.G();return a}
function hk(a,b){a.defaultValue=b;return a}
function ok(a,b){a.onDoubleClick=b;return a}
function vm(a,b){a.a.props['a']=b;return a.a}
function ei(a,b){a.a[a.a.length]=b;return true}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function _k(a,b){A((J(),J(),I),new gl(a,b),Ho)}
function rl(a,b){A((J(),J(),I),new Il(a,b),Ho)}
function ul(a,b){A((J(),J(),I),new Fl(a,b),Ho)}
function vl(a,b){A((J(),J(),I),new El(a,b),Ho)}
function wl(a,b){A((J(),J(),I),new Dl(a,b),Ho)}
function ln(a,b){A((J(),J(),I),new tn(a,b),Ho)}
function En(a,b){A((J(),J(),I),new Jn(a,b),Ho)}
function Fn(a,b){A((J(),J(),I),new In(a,b),Ho)}
function nn(a){Eh(new ai(a.g),new hc(a));Uh(a.g)}
function Fb(a){while(true){if(!Eb(a)){break}}}
function un(a,b){this.a=a;this.c=b;this.b=false}
function Vi(a,b){this.e=a;this.d=(b&64)!=0?b|no:b}
function F(){this.f=new bb;this.a=new Gb(this.f)}
function Sc(){Sc=ah;var a;!Uc();a=new Vc;Rc=a}
function dj(a){_i(a);return new fj(a,new mj(a.a))}
function al(a,b){var c;c=b.target;bl(a,c.value)}
function qb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ii(a,b){var c;c=a.a[b];wj(a.a,b);return c}
function Zh(a){var b;b=a.a.X();a.b=Yh(a);return b}
function Wi(a){if(!a.d){a.d=a.b.Q();a.c=a.b.S()}}
function Hb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function ij(a,b,c){if(a.a.db(c)){a.b=true;b.B(c)}}
function ki(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Ii(a,b){return !(a.a.get(b)===undefined)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function $c(a){return Array.isArray(a)&&a.xb===fh}
function hd(a){return !Array.isArray(a)&&a.xb===fh}
function on(a){return lh(),0==S(a.e).a?true:false}
function Ln(a){return Hh(No,a)||Hh(Jo,a)||Hh('',a)}
function Nn(a){nb(a.e);nb(a.a);R(a.b);R(a.c);cb(a.d)}
function $i(a){if(!a.b){_i(a);a.c=true}else{$i(a.b)}}
function Ti(a){if(a==null){throw Ng(new Fh)}return a}
function Wh(a,b){if(b){return Ph(a.a,b)}return false}
function cj(a,b){_i(a);return new fj(a,new jj(b,a.a))}
function Km(a,b){A((J(),J(),I),new Tm(a,b),75505664)}
function bl(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.b)}}
function bn(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function xl(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function jb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function mk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ri(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function Zj(a){Xj(a);return jd(a,8)&&a.w()?null:a.nb()}
function Sg(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function Wj(a){if(!a.k){a.k=true;a.n||a.o.forceUpdate()}}
function aj(a){if(!a){this.b=null;new mi}else{this.b=a}}
function mj(a){Vi.call(this,a.bb(),a.ab()&-6);this.a=a}
function Cl(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Xi(a,b){this.b=a;this.a=(b&4096)==0?b|64|no:b}
function Om(a,b){var c;c=a.e;if(b!=c){a.e=Ti(b);hb(a.b)}}
function sh(a,b){var c;c=qh(a);xh(a,c);c.e=b?8:0;return c}
function Im(a){var b;T(a.a);b=S(a.a);Hh(a.f,b)&&Om(a,b)}
function ob(a){C((J(),J(),I),a);0==(a.f.a&to)&&D((null,I))}
function kn(a,b){return t((J(),J(),I),new un(a,b),Ho,null)}
function eo(){bo();return ad(Wc(Bg,1),po,34,0,[$n,ao,_n])}
function sl(a,b,c,d){return lh(),pl(a,b,c,d)?true:false}
function Kj(a,b){null!=b&&a.ib(b,a.o.props,true);a.fb()}
function Qh(a,b){return b===a?'(this Map)':b==null?zo:eh(b)}
function qc(a,b){var c;c=oh(a.vb);return b==null?c:c+': '+b}
function Tj(a){var b;b=Sj(a);b.props={};b.ref=null;return b}
function uh(a){if(a.O()){return null}var b=a.j;return Yg[b]}
function Pb(a){if(a.e){2==(a.e.c&7)||vb(a.e,4,true);rb(a.e)}}
function lc(a){kc(a.g);V(a.c);V(a.a);V(a.d);kc(a.b);kc(a.f)}
function Fm(a){kh((ih(),$wnd.window.window),Lo,a.d,false)}
function Em(a){jh((ih(),$wnd.window.window),Lo,a.d,false)}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function Hj(){if(Cj==256){Bj=Dj;Dj=new o;Cj=0}++Cj}
function Cm(){Cm=ah;zm=new qn;Am=new Gn(zm);Bm=new Tn(zm)}
function Cn(a,b){var c;ej(mn(a.b),(c=new mi,c)).P(new io(b))}
function jl(a,b){var c;if(S(a.d)){c=b.target;xl(a,c.value)}}
function Eh(a,b){var c,d;for(d=a.Q();d.W();){c=d.X();b.B(c)}}
function th(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function ui(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function dh(a){function b(){}
;b.prototype=a||{};return new b}
function dm(){dm=ah;var a;cm=(a=bh(bm.prototype.jb,bm,[]),a)}
function hm(){hm=ah;var a;gm=(a=bh(fm.prototype.jb,fm,[]),a)}
function Tl(){Tl=ah;var a;Sl=(a=bh(Rl.prototype.jb,Rl,[]),a)}
function Xl(){Xl=ah;var a;Wl=(a=bh(Vl.prototype.jb,Vl,[]),a)}
function _l(){_l=ah;var a;$l=(a=bh(Zl.prototype.jb,Zl,[]),a)}
function ni(a){di(this);vj(this.a,Oh(a,Yc(fe,po,1,Vh(a.a),5,1)))}
function vi(a,b){var c;return ti(b,ui(a,b==null?0:(c=r(b),c|0)))}
function mn(a){ib(a.d);return new fj(null,new Xi(new ai(a.g),0))}
function _i(a){if(a.b){_i(a.b)}else if(a.c){throw Ng(new zh)}}
function zi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Gn(a){this.b=Ti(a);J();this.a=new mc(0,null,new Hn,false)}
function jh(a,b,c,d){a.addEventListener(b,c,(lh(),d?true:false))}
function kh(a,b,c,d){a.removeEventListener(b,c,(lh(),d?true:false))}
function Gm(a,b){b.preventDefault();A((J(),J(),I),new Vm(a),Ho)}
function ml(a,b){Sn((Cm(),Bm),b);A((J(),J(),I),new Dl(a,b),Ho)}
function bp(){return On((Cm(),Bm))==(jb(this.c),this.o.props['a'])}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&no)?no:8192)|0|0,b)}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&no)?no:8192)|0|0,b)}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function eb(a,b){var c,d;ei(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Sn(a,b){var c;c=a.f;if(!(b==c||!!b&&Zm(b,c))){a.f=b;hb(a.d)}}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function $g(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Pj(a,b,c){!Hh(c,'key')&&!Hh(c,'ref')&&(a[c]=b[c],undefined)}
function jj(a,b){Vi.call(this,b.bb(),b.ab()&-16449);this.a=a;this.c=b}
function Ni(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function lk(a){a.placeholder='What needs to be done?';return a}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Yi(a,b){!a.a?(a.a=new Lh(a.d)):Jh(a.a,a.b);Jh(a.a,b);return a}
function ej(a,b){var c;$i(a);c=new pj;c.a=b;a.a.V(new sj(c));return c.a}
function bj(a){var b;$i(a);b=0;while(a.a.cb(new qj)){b=Og(b,1)}return b}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Dn(a){var b;ej(cj(mn(a.b),new go),(b=new mi,b)).P(new ho(a.b))}
function Mb(b){try{b.b.A()}catch(a){a=Mg(a);if(!jd(a,5))throw Ng(a)}}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Th(a,b){return nd(b)?b==null?xi(a.a,null):Li(a.b,b):xi(a.a,b)}
function Mn(a,b){return (bo(),_n)==a||($n==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function xj(a,b){return Xc(b)!=10&&ad(q(b),b.wb,b.__elementTypeId$,Xc(b),a),a}
function tl(a){return lh(),On((Cm(),Bm))==(jb(a.c),a.o.props['a'])?true:false}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Oi(a){if(a.a.c!=a.c){return Ji(a.a,a.b.value[0])}return a.b.value[1]}
function Zm(a,b){var c;if(jd(b,48)){c=b;return a.c.e==c.c.e}else{return false}}
function $j(a){var b;a.k=false;if(a.lb()){return null}else{b=a.hb();return b}}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function ji(a,b){var c;c=hi(a,b,0);if(c==-1){return false}wj(a.a,c);return true}
function fi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.B(c)}}
function Pn(a){var b,c;return b=S(a.b),ej(cj(mn(a.j),new jo(b)),(c=new mi,c))}
function Dm(a,b){a.f=b;Hh(b,S(a.a))&&Om(a,b);Hm(b);A((J(),J(),I),new Vm(a),Ho)}
function Sh(a,b,c){return nd(b)?b==null?wi(a.a,null,c):Ki(a.b,b,c):wi(a.a,b,c)}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||nb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Fb(a.a)}finally{a.c=false}}}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new mb(a)),0,null);!!a.b&&nb(a.b)}}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new nc(a)),67108864,null)}}
function ub(b){if(b){try{b.A()}catch(a){a=Mg(a);if(jd(a,5)){J()}else throw Ng(a)}}}
function Zk(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new fl(a),Ho)}}
function Yk(a){var b;b=Ih((ib(a.b),a.d));if(b.length>0){zn((Cm(),Am),b);bl(a,'')}}
function Lj(a,b){var c;c=null!=b&&a.ib(a.o.props,b,false);c||(a.p=false);return c}
function Mj(a,b){var c;if(b){c=a.p;a.p=false;return !c}else{a.p=true;return true}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function jn(a){Eh(new ai(a.g),new hc(a));Uh(a.g);R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function $h(a){this.d=a;this.c=new Ni(this.d.b);this.a=this.c;this.b=Yh(this)}
function Zi(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function bb(){var a;this.a=Yc(td,po,46,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function Yj(a){var b;b=(++a.mb().e,new Ib);try{a.n=true;jd(a,8)&&a.v()}finally{Hb(b)}}
function qh(a){var b;b=new ph;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function bh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function xh(a,b){var c;if(!a){return}b.j=a;var d=uh(b);if(!d){Yg[a]=[b];return}d.vb=b}
function Mg(a){var b;if(jd(a,5)){return a}b=a&&a[xo];if(!b){b=new wc(a);Tc(b)}return b}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;ei((!a.b&&(a.b=new mi),a.b),b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new mi);a.c=c.c}b.d=true;ei(a.c,Ti(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Ti(b))}
function hi(a,b,c){for(;c<a.a.length;++c){if(ri(b,a.a[c])){return c}}return -1}
function Li(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ai(a.a,b);--a.b}return c}
function pi(a){var b,c,d;d=0;for(c=new $h(a.a);c.b;){b=Zh(c);d=d+(b?r(b):0);d=d|0}return d}
function Nh(a,b){var c,d;for(d=new $h(b.a);d.b;){c=Zh(d);if(!Wh(a,c)){return false}}return true}
function rb(a){var b,c;for(c=new oi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ug(){Vg();var a=Tg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function zh(){sc.call(this,"Stream already terminated, can't be modified or used")}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function md(a){return a!=null&&(typeof a===lo||typeof a==='function')&&!(a.xb===fh)}
function Xg(a,b){typeof window===lo&&typeof window['$gwt']===lo&&(window['$gwt'][a]=b)}
function Nb(a,b){this.b=Ti(a);this.a=b|0|(0==(b&6291456)?uo:0)|(0!=(b&229376)?0:98304)}
function bo(){bo=ah;$n=new co('ACTIVE',0);ao=new co('COMPLETED',1);_n=new co('ALL',2)}
function gh(){Cm();$wnd.ReactDOM.render((new ym).a,(ih(),hh).getElementById('todoapp'),null)}
function Nj(a){$wnd.React.Component.call(this,a);this.a=this.kb();this.a.o=Ti(this);this.a.gb()}
function Yh(a){if(a.a.W()){return true}if(a.a!=a.c){return false}a.a=new zi(a.d.a);return a.a.W()}
function Pg(a){var b;b=a.h;if(b==0){return a.l+a.m*uo}if(b==1048575){return a.l+a.m*uo-Ao}return a}
function Rg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Ao;d=1048575}c=pd(e/uo);b=pd(e-c*uo);return bd(b,c,d)}
function ti(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(ri(a,c.Z())){return c}}return null}
function hn(a,b,c){var d;d=new en(b,c);ac(d.c.c,a,new ic(a,d));Sh(a.g,Bh(d.c.e),d);hb(a.d);return d}
function Ki(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ec(a,b,c){var d;d=Th(a.g,b?Bh(b.c.e):null);if(null!=d){cc(b.c.c,a);c&&!!b&&jc(b.c);hb(a.d)}}
function Rn(a){var b;b=S(a.i.a);Hh(No,b)||Hh(Jo,b)||Hh('',b)?Km(a.i,b):Ln(Lm(a.i))?Nm(a.i):Km(a.i,'')}
function S(a){ib(a.e);wb(a.f)&&pb(a.f);if(a.b){if(jd(a.b,9)){throw Ng(a.b)}else{throw Ng(a.b)}}return a.k}
function pl(a,b,c,d){var e,f;e=false;f=Mj(a,d);if(!(b['a']===c['a'])){f&&hb(a.c);e=true}return e||a.k}
function ad(a,b,c,d,e){e.vb=a;e.wb=b;e.xb=fh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Xj(a){if(!Vj){Vj=(++a.mb().e,new Ib);$wnd.Promise.resolve(null).then(bh(ak.prototype.I,ak,[]))}}
function nb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Cb(a)),67108864,null);!!a.a&&R(a.a);Jb(a.f);a.c=a.c&-8|1}}
function ll(a,b,c){27==c.which?A((J(),J(),I),new Hl(a,b),Ho):13==c.which&&A((J(),J(),I),new El(a,b),Ho)}
function fb(a,b){var c,d;d=a.c;ji(d,b);!!a.b&&qo!=(a.b.c&ro)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function nl(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){En((Cm(),b),c);Sn(Bm,null);xl(a,c)}else{ln((Cm(),zm),b)}}
function Bh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Dh(),Ch)[b];!c&&(c=Ch[b]=new Ah(a));return c}return new Ah(a)}
function eh(a){var b;if(Array.isArray(a)&&a.xb===fh){return oh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Gj(a){Ej();var b,c,d;c=':'+a;d=Dj[c];if(d!=null){return pd(d)}d=Bj[c];b=d==null?Fj(a):pd(d);Hj();Dj[c]=b;return b}
function wc(a){uc();oc(this);this.e=a;a!=null&&yj(a,xo,this);this.f=a==null?zo:eh(a);this.a='';this.b=a;this.a=''}
function ph(){this.g=mh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function q(a){return nd(a)?ie:ld(a)?Zd:kd(a)?Xd:hd(a)?a.vb:$c(a)?a.vb:a.vb||Array.isArray(a)&&Wc(Qd,1)||Qd}
function r(a){return nd(a)?Gj(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.s():$c(a)?Aj(a):!!a&&!!a.hashCode?a.hashCode():Aj(a)}
function p(a,b){return nd(a)?Hh(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.q(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function Kb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&qo)?Mb(a):a.b.A();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function yb(a,b,c){xb.call(this,null,a,b,c|(!a?262144:qo)|(a?no:0!=(c&24576)?0:8192)|(0==(c&6291456)?!a?to:uo:0)|0|0|0)}
function Nk(){Lk();return ad(Wc(Xe,1),po,7,0,[pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk])}
function bc(a){var b,c;if(!a.a){for(c=new oi(new ni(new ai(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.A()}a.a=true}}
function qi(a){var b,c,d;d=1;for(c=new oi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function bk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function li(a,b){var c,d;d=a.a.length;b.length<d&&(b=xj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function wh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Og(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<Ao){return c}}return Pg(cd(ld(a)?Rg(a):a,ld(b)?Rg(b):b))}
function mc(a,b,c,d){var e;this.e=a;this.c=new dc;this.g=b;this.b=c;this.f=null;this.a=d?(e=new lb((J(),null)),e):null;this.d=null}
function U(a,b,c,d){this.c=Ti(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new zb(this,d);this.e=new lb(this.f);qo==(d&ro)&&ob(this.f)}
function Uk(){_j.call(this);J();Bh(this.j);this.b=new mc(0,null,new Vk(this),false);this.a=new yb(null,Ti(new Wk(this)),Fo);D((null,I))}
function Kl(){_j.call(this);J();Bh(this.j);this.b=new mc(0,null,new Ll(this),false);this.a=new yb(null,Ti(new Ml(this)),Fo);D((null,I))}
function en(a,b){var c,d,e;this.e=Ti(a);this.d=b;J();c=++Xm;this.c=new mc(c,null,new fn(this),true);this.b=(e=new lb(null),e);this.a=(d=new lb(null),d)}
function il(a){var b;b=S(a.d);if(!a.i&&b){a.i=true;wl(a,(jb(a.c),a.o.props['a']));a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function zb(a,b){xb.call(this,a,new Ab(a),null,b|(qo==(b&ro)?0:524288)|(0==(b&6291456)?qo==(b&ro)?uo:to:0)|(0!=(b&24576)?0:8192)|0|268435456|0)}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.wb){return !!a.wb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&vb(b,5,true)}}}
function Xb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new oi(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&vb(b,6,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?vb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Ih(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ub(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=ii(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&vb(c.b,3,true);++b}}}return b}
function Eb(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Kb(c);return true}
function Wg(b,c,d,e){Vg();var f=Tg;$moduleName=c;$moduleBase=d;Lg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ko(g)()}catch(a){b(c,a)}}else{ko(g)()}}
function cl(){var a;_j.call(this);J();Bh(this.j);this.c=new mc(0,null,new dl(this),false);this.b=(a=new lb(null),a);this.a=new yb(null,Ti(new hl(this)),Fo);D((null,I))}
function Pk(){_j.call(this);J();Bh(this.j);this.c=new mc(0,null,new Qk(this),false);this.a=new U(new Rk,null,null,136486912);this.b=new yb(null,Ti(new Sk(this)),Fo);D((null,I))}
function Fi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Gi()}}
function Sj(a){var b;b=new $wnd.Object;b.$$typeof=$wnd.React.Element;b.type=Ti(a);b._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return b}
function Oh(a,b){var c,d,e,f,g;g=Vh(a.a);b.length<g&&(b=xj(new Array(g),b));e=(f=new $h((new Xh(a.a)).a),new bi(f));for(d=0;d<g;++d){b[d]=(c=Zh(e.a),c.$())}b.length>g&&(b[g]=null);return b}
function Zg(){Yg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].yb()&&(c=Pc(c,g)):g[0].yb()}catch(a){a=Mg(a);if(jd(a,5)){d=a;Bc();Hc(jd(d,37)?d.H():d)}else throw Ng(a)}}return c}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?zo:md(b)?b==null?null:b.name:nd(b)?'String':oh(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.k;try{d=b.c.u();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Mg(a);if(jd(a,11)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Ng(c)}else throw Ng(a)}}
function wi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=ti(b,e);if(f){return f._(c)}}e[e.length]=new ci(b,c);++a.b;return null}
function tj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Fj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Gh(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Yc(fe,po,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=no==(d&no)?c.u():c.u()}else{$b(b,e);try{g=no==(d&no)?c.u():c.u()}finally{_b()}}return g}catch(a){a=Mg(a);if(jd(a,5)){f=a;throw Ng(f)}else throw Ng(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=no==(d&no)?(c.a.A(),null):(c.a.A(),null)}else{$b(b,e);try{g=no==(d&no)?(c.a.A(),null):(c.a.A(),null)}finally{_b()}}return g}catch(a){a=Mg(a);if(jd(a,5)){f=a;throw Ng(f)}else throw Ng(a)}finally{D(b)}}
function pb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.A()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Mg(a);if(jd(a,5)){J()}else throw Ng(a)}}}
function Hm(a){var b;if(0==a.length){b=(ih(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',hh.title,b)}else{(ih(),$wnd.window.window).location.hash=a}}
function xb(a,b,c,d){this.b=new mi;this.f=new Nb(new Bb(this),d&6520832|262144|qo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&to)&&D((null,I)))}
function xi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(ri(b,e.Z())){if(d.length==1){d.length=0;Ai(a.a,g)}else{d.splice(h,1)}--a.b;return e.$()}}return null}
function _g(a,b,c){var d=Yg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Yg[b]),dh(h));_.wb=c;!b&&(_.xb=fh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.vb=f)}
function vh(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=wh('.',[c,wh('$',d)]);a.b=wh('.',[c,wh('.',d)]);a.i=d[d.length-1]}
function Ph(a,b){var c,d,e;c=b.Z();e=b.$();d=nd(c)?c==null?Rh(vi(a.a,null)):Ji(a.b,c):Rh(vi(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!vi(a.a,null):Ii(a.b,c):!!vi(a.a,c))){return false}return true}
function yl(){var a,b;_j.call(this);J();Bh(this.j);this.e=new mc(0,null,new zl(this),false);this.c=(b=new lb(null),b);this.a=(a=new lb(null),a);this.d=new U(new Gl(this),null,null,136486912);this.b=new yb(null,Ti(new Jl(this)),Fo);D((null,I))}
function Pm(){var a,b;this.d=new Zn(this);this.f=this.e=(b=(ih(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new mc(0,null,new Qm(this),false);this.b=(a=new lb(null),a);this.a=new U(new Wm,new Rm(this),new Sm(this),35758080)}
function qn(){var a;this.g=new si;J();this.f=new mc(0,new sn(this),new rn(this),false);this.d=(a=new lb(null),a);this.c=new U(new vn(this),null,null,Mo);this.e=new U(new wn(this),null,null,Mo);this.a=new U(new xn(this),null,null,Mo);this.b=new U(new yn(this),null,null,Mo)}
function Tn(a){var b;this.j=Ti(a);this.i=new Pm;J();this.g=new mc(0,null,new Un(this),false);this.d=(b=new lb(null),b);this.b=new U(new Vn(this),null,null,Mo);this.c=new U(new Wn(this),null,null,Mo);this.e=u(new Xn(this),413155328);this.a=u(new Yn(this),681590784);D((null,I))}
function wb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new oi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Mg(a);if(!jd(a,5))throw Ng(a)}if(6==(b.c&7)){return true}}}}}rb(b);return false}
function Oj(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?''+b['key']:null;f='ref' in b?b['ref']:null;Jj(b,bh(Qj.prototype.eb,Qj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=Sj(a),g.key=e,g.ref=f,g.props=Ti(d),g}
function Ei(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function vb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){kb(a.a.e);ub((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;ub((e=d.i,e));d.k=null}fi(a.b,new Db(a));a.b.a=Yc(fe,po,1,0,5,1)}else 3==g&&!!a.a&&ub((f=a.a.g,f))}}
function Lk(){Lk=ah;pk=new Mk(Do,0);qk=new Mk('checkbox',1);rk=new Mk('color',2);sk=new Mk('date',3);tk=new Mk('datetime',4);uk=new Mk('email',5);vk=new Mk('file',6);wk=new Mk('hidden',7);xk=new Mk('image',8);yk=new Mk('month',9);zk=new Mk(mo,10);Ak=new Mk('password',11);Bk=new Mk('radio',12);Ck=new Mk('range',13);Dk=new Mk('reset',14);Ek=new Mk('search',15);Fk=new Mk('submit',16);Gk=new Mk('tel',17);Hk=new Mk('text',18);Ik=new Mk('time',19);Jk=new Mk('url',20);Kk=new Mk('week',21)}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=gi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ki(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&vb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=gi(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ii(a.b,g)}e&&tb(a.e,a.b)}else{e&&tb(a.e,new mi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&qo!=(k.b.c&ro)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function Gi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Co]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ei()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Co]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var lo='object',mo='number',no=16384,oo={10:1},po={3:1,4:1},qo=1048576,ro=1835008,so={6:1},to=2097152,uo=4194304,vo={21:1},wo='__noinit__',xo='__java$exception',yo={3:1,11:1,9:1,5:1},zo='null',Ao=17592186044416,Bo={43:1},Co='delete',Do='button',Eo='selected',Fo=1478635520,Go={8:1,20:1},Ho=142614528,Io='input',Jo='completed',Ko='header',Lo='hashchange',Mo=136421376,No='active';var _,Yg,Tg,Lg=-1;Zg();_g(1,null,{},o);_.q=Po;_.r=function(){return this.vb};_.s=Qo;_.t=function(){var a;return oh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.q(a)};_.hashCode=function(){return this.s()};_.toString=function(){return this.t()};var dd,ed,fd;_g(50,1,{},ph);_.J=function(a){var b;b=new ph;b.e=4;a>1?(b.c=th(this,a-1)):(b.c=this);return b};_.K=function(){nh(this);return this.b};_.L=function(){return oh(this)};_.M=function(){nh(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.t=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(nh(this),this.k)};_.e=0;_.g=0;var mh=1;var fe=rh(1);var Yd=rh(50);_g(80,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var sd=rh(80);_g(38,1,oo,G);_.u=function(){return this.a.A(),null};var qd=rh(38);_g(81,1,{},H);var rd=rh(81);var I;_g(46,1,{46:1},P);_.b=0;_.c=false;_.d=0;var td=rh(46);_g(213,1,{8:1});_.t=function(){var a;return oh(this.vb)+'@'+(a=r(this)>>>0,a.toString(16))};var wd=rh(213);_g(18,213,{8:1},U);_.v=function(){R(this)};_.w=Oo;_.a=false;_.d=0;var ud=rh(18);_g(133,1,{241:1},bb);var vd=rh(133);_g(14,213,{8:1,14:1},lb);_.v=function(){cb(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var yd=rh(14);_g(114,1,so,mb);_.A=function(){db(this.a)};var xd=rh(114);_g(16,213,{8:1,16:1},yb,zb);_.v=function(){nb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Dd=rh(16);_g(115,1,vo,Ab);_.A=function(){Q(this.a)};var zd=rh(115);_g(116,1,so,Bb);_.A=function(){pb(this.a)};var Ad=rh(116);_g(117,1,so,Cb);_.A=function(){sb(this.a)};var Bd=rh(117);_g(118,1,{},Db);_.B=function(a){qb(this.a,a)};var Cd=rh(118);_g(134,1,{},Gb);_.a=0;_.b=0;_.c=0;var Ed=rh(134);_g(63,1,{8:1},Ib);_.v=function(){Hb(this)};_.w=Oo;_.a=false;var Fd=rh(63);_g(60,213,{8:1,60:1},Nb);_.v=function(){Jb(this)};_.w=function(){return 2==(3&this.a)};_.a=0;var Gd=rh(60);_g(146,1,{},Zb);_.t=function(){var a;return nh(Hd),Hd.k+'@'+(a=Aj(this)>>>0,a.toString(16))};_.a=0;var Ob;var Hd=rh(146);_g(119,1,{8:1},dc);_.v=function(){bc(this)};_.w=Oo;_.a=false;var Id=rh(119);_g(102,1,{});var Ld=rh(102);_g(54,1,{},hc);_.B=function(a){fc(this.a,a)};var Jd=rh(54);_g(82,1,so,ic);_.A=function(){gc(this.a,this.b)};var Kd=rh(82);_g(103,102,{});var Md=rh(103);_g(15,1,{8:1},mc);_.v=function(){jc(this)};_.w=function(){return this.i<0};_.t=function(){var a;return nh(Od),Od.k+'@'+(a=Aj(this)>>>0,a.toString(16))};_.e=0;_.i=0;var Od=rh(15);_g(113,1,so,nc);_.A=function(){lc(this.a)};var Nd=rh(113);_g(5,1,{3:1,5:1});_.D=function(a){return new Error(a)};_.F=function(){return this.f};_.G=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=oh(this.vb),c==null?a:a+': '+c);pc(this,rc(this.D(b)));Tc(this)};_.t=function(){return qc(this,this.F())};_.e=wo;_.g=true;var je=rh(5);_g(11,5,{3:1,11:1,5:1});var _d=rh(11);_g(9,11,yo);var ge=rh(9);_g(51,9,yo);var ce=rh(51);_g(74,51,yo);var Sd=rh(74);_g(37,74,{37:1,3:1,11:1,9:1,5:1},wc);_.F=function(){vc(this);return this.c};_.H=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Pd=rh(37);var Qd=rh(0);_g(199,1,{});var Rd=rh(199);var yc=0,zc=0,Ac=-1;_g(101,199,{},Oc);var Kc;var Td=rh(101);var Rc;_g(210,1,{});var Vd=rh(210);_g(75,210,{},Vc);var Ud=rh(75);var hh;_g(72,1,{69:1});_.t=Oo;var Wd=rh(72);dd={3:1,70:1,29:1};var Xd=rh(70);_g(44,1,{3:1,44:1});var ee=rh(44);ed={3:1,29:1,44:1};var Zd=rh(209);_g(33,1,{3:1,29:1,33:1});_.q=Po;_.s=Qo;_.t=function(){return this.a!=null?this.a:''+this.b};_.b=0;var $d=rh(33);_g(76,9,yo,zh);var ae=rh(76);_g(30,44,{3:1,29:1,30:1,44:1},Ah);_.q=function(a){return jd(a,30)&&a.a==this.a};_.s=Oo;_.t=function(){return ''+this.a};_.a=0;var be=rh(30);var Ch;_g(270,1,{});_g(78,51,yo,Fh);_.D=function(a){return new TypeError(a)};var de=rh(78);fd={3:1,69:1,29:1,2:1};var ie=rh(2);_g(73,72,{69:1},Lh);var he=rh(73);_g(274,1,{});_g(53,9,yo,Mh);var ke=rh(53);_g(211,1,{42:1});_.P=Uo;_.T=function(){return new Xi(this,0)};_.U=function(){return new fj(null,this.T())};_.R=function(a){throw Ng(new Mh('Add not supported on this collection'))};_.t=function(){var a,b,c;c=new Zi('[',']');for(b=this.Q();b.W();){a=b.X();Yi(c,a===this?'(this Collection)':a==null?zo:eh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var le=rh(211);_g(214,1,{197:1});_.q=function(a){var b,c,d;if(a===this){return true}if(!jd(a,39)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new $h((new Xh(d)).a);c.b;){b=Zh(c);if(!Ph(this,b)){return false}}return true};_.s=function(){return pi(new Xh(this))};_.t=function(){var a,b,c;c=new Zi('{','}');for(b=new $h((new Xh(this)).a);b.b;){a=Zh(b);Yi(c,Qh(this,a.Z())+'='+Qh(this,a.$()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var we=rh(214);_g(122,214,{197:1});var oe=rh(122);_g(215,211,{42:1,221:1});_.T=function(){return new Xi(this,1)};_.q=function(a){var b;if(a===this){return true}if(!jd(a,24)){return false}b=a;if(Vh(b.a)!=this.S()){return false}return Nh(this,b)};_.s=function(){return pi(this)};var xe=rh(215);_g(24,215,{24:1,42:1,221:1},Xh);_.Q=function(){return new $h(this.a)};_.S=So;var ne=rh(24);_g(25,1,{},$h);_.V=Ro;_.X=function(){return Zh(this)};_.W=To;_.b=false;var me=rh(25);_g(212,211,{42:1,219:1});_.T=function(){return new Xi(this,16)};_.Y=function(a,b){throw Ng(new Mh('Add not supported on this list'))};_.R=function(a){this.Y(this.S(),a);return true};_.q=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,13)){return false}f=a;if(this.S()!=f.a.length){return false}e=new oi(f);for(c=new oi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.s=function(){return qi(this)};_.Q=function(){return new _h(this)};var qe=rh(212);_g(100,1,{},_h);_.V=Ro;_.W=function(){return this.a<this.b.a.length};_.X=function(){return gi(this.b,this.a++)};_.a=0;var pe=rh(100);_g(40,211,{42:1},ai);_.Q=function(){var a;return a=new $h((new Xh(this.a)).a),new bi(a)};_.S=So;var se=rh(40);_g(55,1,{},bi);_.V=Ro;_.W=function(){return this.a.b};_.X=function(){var a;return a=Zh(this.a),a.$()};var re=rh(55);_g(123,1,Bo);_.q=function(a){var b;if(!jd(a,43)){return false}b=a;return ri(this.a,b.Z())&&ri(this.b,b.$())};_.Z=Oo;_.$=To;_.s=function(){return Si(this.a)^Si(this.b)};_._=function(a){var b;b=this.b;this.b=a;return b};_.t=function(){return this.a+'='+this.b};var te=rh(123);_g(124,123,Bo,ci);var ue=rh(124);_g(216,1,Bo);_.q=function(a){var b;if(!jd(a,43)){return false}b=a;return ri(this.b.value[0],b.Z())&&ri(Oi(this),b.$())};_.s=function(){return Si(this.b.value[0])^Si(Oi(this))};_.t=function(){return this.b.value[0]+'='+Oi(this)};var ve=rh(216);_g(13,212,{3:1,13:1,42:1,219:1},mi,ni);_.Y=function(a,b){uj(this.a,a,b)};_.R=function(a){return ei(this,a)};_.P=function(a){fi(this,a)};_.Q=function(){return new oi(this)};_.S=function(){return this.a.length};var ze=rh(13);_g(17,1,{},oi);_.V=Ro;_.W=function(){return this.a<this.c.a.length};_.X=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ye=rh(17);_g(39,122,{3:1,39:1,197:1},si);var Ae=rh(39);_g(61,1,{},yi);_.P=Uo;_.Q=function(){return new zi(this)};_.b=0;var Ce=rh(61);_g(62,1,{},zi);_.V=Ro;_.X=function(){return this.d=this.a[this.c++],this.d};_.W=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Be=rh(62);var Ci;_g(58,1,{},Mi);_.P=Uo;_.Q=function(){return new Ni(this)};_.b=0;_.c=0;var Fe=rh(58);_g(59,1,{},Ni);_.V=Ro;_.X=function(){return this.c=this.a,this.a=this.b.next(),new Pi(this.d,this.c,this.d.c)};_.W=function(){return !this.a.done};var De=rh(59);_g(145,216,Bo,Pi);_.Z=function(){return this.b.value[0]};_.$=function(){return Oi(this)};_._=function(a){return Ki(this.a,this.b.value[0],a)};_.c=0;var Ee=rh(145);_g(136,1,{});_.V=function(a){Ui(this,a)};_.ab=function(){return this.d};_.bb=function(){return this.e};_.d=0;_.e=0;var He=rh(136);_g(57,136,{});var Ge=rh(57);_g(23,1,{},Xi);_.ab=Oo;_.bb=function(){Wi(this);return this.c};_.V=function(a){Wi(this);this.d.V(a)};_.cb=function(a){Wi(this);if(this.d.W()){a.B(this.d.X());return true}return false};_.a=0;_.c=0;var Ie=rh(23);_g(52,1,{},Zi);_.t=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Je=rh(52);_g(135,1,{});_.c=false;var Se=rh(135);_g(32,135,{},fj);var Re=rh(32);_g(138,57,{},jj);_.cb=function(a){this.b=false;while(!this.b&&this.c.cb(new kj(this,a)));return this.b};_.b=false;var Le=rh(138);_g(141,1,{},kj);_.B=function(a){ij(this.a,this.b,a)};var Ke=rh(141);_g(137,57,{},mj);_.cb=function(a){return this.a.cb(new nj(a))};var Ne=rh(137);_g(140,1,{},nj);_.B=function(a){lj(this.a,a)};var Me=rh(140);_g(139,1,{},pj);_.B=function(a){oj(this,a)};var Oe=rh(139);_g(142,1,{},qj);_.B=function(a){};var Pe=rh(142);_g(143,1,{},sj);_.B=function(a){rj(this,a)};var Qe=rh(143);_g(272,1,{});_g(218,1,{});var Te=rh(218);_g(269,1,{});var zj=0;var Bj,Cj=0,Dj;_g(696,1,{});_g(713,1,{});_g(217,1,{});_.fb=Vo;_.gb=Vo;_.ib=function(a,b,c){return false};_.p=false;var Ue=rh(217);_g(31,$wnd.React.Component,{});$g(Yg[1],_);_.render=function(){return Zj(this.a)};var Ve=rh(31);_g(235,$wnd.Function,{},Qj);_.eb=function(a){Pj(this.a,this.b,a)};_g(35,217,{});_.lb=function(){return false};_.nb=function(){return $j(this)};_.j=0;_.k=false;_.n=false;var Uj=1,Vj;var We=rh(35);_g(240,$wnd.Function,{},ak);_.I=function(a){return Hb(Vj),Vj=null,null};_g(7,33,{3:1,29:1,33:1,7:1},Mk);var pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk;var Xe=sh(7,Nk);_g(167,35,{});_.sb=Wo;_.hb=function(){var a;a=S((Cm(),Bm).b);return Oj('footer',bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,['footer'])),[(new Ql).a,Oj('ul',bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,['filters'])),[Oj('li',null,[Oj('a',dk(bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,[(bo(),_n)==a?Eo:null])),'#'),['All'])]),Oj('li',null,[Oj('a',dk(bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,[$n==a?Eo:null])),'#active'),['Active'])]),Oj('li',null,[Oj('a',dk(bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,[ao==a?Eo:null])),'#completed'),['Completed'])])]),this.sb()?Oj(Do,ek(bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,['clear-completed'])),bh(Ol.prototype.rb,Ol,[])),['Clear Completed']):null])};var Ff=rh(167);_g(168,167,{});_.sb=Wo;var Jf=rh(168);_g(169,168,Go,Pk);_.v=$o;_.q=Po;_.mb=Xo;_.C=_o;_.sb=function(){return S(this.a)};_.s=Qo;_.w=ap;_.t=function(){var a;return nh(ef),ef.k+'@'+(a=Aj(this)>>>0,a.toString(16))};_.nb=function(){return B((J(),J(),I),this.b,new Tk(this))};var ef=rh(169);_g(170,1,so,Qk);_.A=function(){Ok(this.a)};var Ye=rh(170);_g(171,1,oo,Rk);_.u=function(){return lh(),S((Cm(),zm).b).a>0?true:false};var Ze=rh(171);_g(172,1,vo,Sk);_.A=Yo;var $e=rh(172);_g(173,1,oo,Tk);_.u=Zo;var _e=rh(173);_g(190,35,{});_.hb=function(){var a,b;b=S((Cm(),zm).e).a;a='item'+(b==1?'':'s');return Oj('span',bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,['todo-count'])),[Oj('strong',null,[b]),' '+a+' left'])};var Ef=rh(190);_g(191,190,{});var If=rh(191);_g(192,191,Go,Uk);_.v=cp;_.q=Po;_.mb=Xo;_.C=dp;_.s=Qo;_.w=ep;_.t=function(){var a;return nh(df),df.k+'@'+(a=Aj(this)>>>0,a.toString(16))};_.nb=function(){return B((J(),J(),I),this.a,new Xk(this))};var df=rh(192);_g(193,1,so,Vk);_.A=fp;var af=rh(193);_g(194,1,vo,Wk);_.A=Yo;var bf=rh(194);_g(195,1,oo,Xk);_.u=Zo;var cf=rh(195);_g(159,35,{});_.hb=function(){return Oj(Io,fk(jk(kk(nk(lk(bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,['new-todo']))),(ib(this.b),this.d)),bh(jm.prototype.qb,jm,[this])),bh(km.prototype.pb,km,[this]))),null)};_.d='';var Rf=rh(159);_g(160,159,{});var Lf=rh(160);_g(161,160,Go,cl);_.v=$o;_.q=Po;_.mb=Xo;_.C=_o;_.s=Qo;_.w=ap;_.t=function(){var a;return nh(lf),lf.k+'@'+(a=Aj(this)>>>0,a.toString(16))};_.nb=function(){return B((J(),J(),I),this.a,new el(this))};var lf=rh(161);_g(162,1,so,dl);_.A=function(){$k(this.a)};var ff=rh(162);_g(164,1,oo,el);_.u=Zo;var gf=rh(164);_g(165,1,so,fl);_.A=function(){Yk(this.a)};var hf=rh(165);_g(166,1,so,gl);_.A=function(){al(this.a,this.b)};var jf=rh(166);_g(163,1,vo,hl);_.A=Yo;var kf=rh(163);_g(175,35,{});_.fb=function(){il(this)};_.ub=bp;_.gb=function(){wl(this,this.tb())};_.hb=function(){var a,b;b=this.tb();a=(ib(b.a),b.d);return Oj('li',bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,[a?Jo:null,this.ub()?'editing':null])),[Oj('div',bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,['view'])),[Oj(Io,jk(gk(mk(bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,['toggle'])),(Lk(),qk)),a),bh(nm.prototype.pb,nm,[b])),null),Oj('label',ok(new $wnd.Object,bh(om.prototype.rb,om,[this,b])),[(ib(b.b),b.e)]),Oj(Do,ek(bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,['destroy'])),bh(pm.prototype.rb,pm,[b])),null)]),Oj(Io,kk(jk(ik(hk(bk(ck(new $wnd.Object,bh(qm.prototype.B,qm,[this])),ad(Wc(ie,1),po,2,6,['edit'])),(ib(this.a),this.g)),bh(rm.prototype.ob,rm,[this,b])),bh(mm.prototype.pb,mm,[this])),bh(sm.prototype.qb,sm,[this,b])),null)])};_.i=false;var Tf=rh(175);_g(176,175,{});_.lb=function(){var a;a=(jb(this.c),this.o.props['a']);if(!!a&&a.c.i<0){return true}return false};_.tb=function(){return this.o.props['a']};_.ub=bp;_.ib=function(a,b,c){return pl(this,a,b,c)};var Nf=rh(176);_g(177,176,Go,yl);_.fb=function(){A((J(),J(),I),new Bl(this),Ho)};_.v=function(){jc(this.e)};_.q=Po;_.mb=Xo;_.C=function(){return this.e.c};_.tb=function(){return jb(this.c),this.o.props['a']};_.s=Qo;_.w=function(){return this.e.i<0};_.ub=function(){return S(this.d)};_.ib=function(a,b,c){return t((J(),J(),I),new Cl(this,a,b,c),75505664,null)};_.t=function(){var a;return nh(xf),xf.k+'@'+(a=Aj(this)>>>0,a.toString(16))};_.nb=function(){return B((J(),J(),I),this.b,new Al(this))};var xf=rh(177);_g(178,1,so,zl);_.A=function(){ql(this.a)};var mf=rh(178);_g(181,1,oo,Al);_.u=Zo;var nf=rh(181);_g(182,1,so,Bl);_.A=function(){il(this.a)};var of=rh(182);_g(183,1,oo,Cl);_.u=function(){return sl(this.a,this.d,this.c,this.b)};_.b=false;var pf=rh(183);_g(64,1,so,Dl);_.A=function(){xl(this.a,Lm(this.b))};var qf=rh(64);_g(65,1,so,El);_.A=function(){nl(this.a,this.b)};var rf=rh(65);_g(184,1,so,Fl);_.A=function(){ml(this.a,this.b)};var sf=rh(184);_g(179,1,oo,Gl);_.u=function(){return tl(this.a)};var tf=rh(179);_g(185,1,so,Hl);_.A=function(){wl(this.a,this.b);Sn((Cm(),Bm),null)};var uf=rh(185);_g(186,1,so,Il);_.A=function(){jl(this.a,this.b)};var vf=rh(186);_g(180,1,vo,Jl);_.A=Yo;var wf=rh(180);_g(147,35,{});_.hb=function(){var a,b;return Oj('div',null,[Oj('div',null,[Oj(Ko,bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,[Ko])),[Oj('h1',null,['todos']),(new lm).a]),S((Cm(),zm).c)?null:Oj('section',bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,[Ko])),[Oj(Io,jk(mk(bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,['toggle-all'])),(Lk(),qk)),bh(xm.prototype.pb,xm,[])),null),Oj('ul',bk(new $wnd.Object,ad(Wc(ie,1),po,2,6,['todo-list'])),(a=ej(dj(S(Bm.c).U()),(b=new mi,b)),li(a,_c(a.a.length))))]),S(zm.c)?null:(new Pl).a])])};var Vf=rh(147);_g(148,147,{});var Pf=rh(148);_g(149,148,Go,Kl);_.v=cp;_.q=Po;_.mb=Xo;_.C=dp;_.s=Qo;_.w=ep;_.t=function(){var a;return nh(Bf),Bf.k+'@'+(a=Aj(this)>>>0,a.toString(16))};_.nb=function(){return B((J(),J(),I),this.a,new Nl(this))};var Bf=rh(149);_g(150,1,so,Ll);_.A=fp;var yf=rh(150);_g(151,1,vo,Ml);_.A=Yo;var zf=rh(151);_g(152,1,oo,Nl);_.u=Zo;var Af=rh(152);_g(246,$wnd.Function,{},Ol);_.rb=function(a){Bn((Cm(),Am))};_g(154,1,{},Pl);var Cf=rh(154);_g(174,1,{},Ql);var Df=rh(174);_g(245,$wnd.Function,{},Rl);_.jb=function(a){return new Ul(a)};var Sl;_g(156,31,{},Ul);_.kb=function(){return new Pk};_.componentWillUnmount=gp;var Gf=rh(156);_g(256,$wnd.Function,{},Vl);_.jb=function(a){return new Yl(a)};var Wl;_g(187,31,{},Yl);_.kb=function(){return new Uk};_.componentWillUnmount=gp;var Hf=rh(187);_g(242,$wnd.Function,{},Zl);_.jb=function(a){return new am(a)};var $l;_g(155,31,{},am);_.kb=function(){return new cl};_.componentWillUnmount=gp;var Kf=rh(155);_g(247,$wnd.Function,{},bm);_.jb=function(a){return new em(a)};var cm;_g(158,31,{},em);_.kb=function(){return new yl};_.componentDidUpdate=function(a){Kj(this.a,a)};_.componentWillUnmount=gp;_.shouldComponentUpdate=function(a){return Lj(this.a,a)};var Mf=rh(158);_g(238,$wnd.Function,{},fm);_.jb=function(a){return new im(a)};var gm;_g(121,31,{},im);_.kb=function(){return new Kl};_.componentWillUnmount=gp;var Of=rh(121);_g(243,$wnd.Function,{},jm);_.qb=function(a){Zk(this.a,a)};_g(244,$wnd.Function,{},km);_.pb=function(a){_k(this.a,a)};_g(153,1,{},lm);var Qf=rh(153);_g(254,$wnd.Function,{},mm);_.pb=function(a){rl(this.a,a)};_g(248,$wnd.Function,{},nm);_.pb=function(a){dn(this.a)};_g(250,$wnd.Function,{},om);_.rb=function(a){ul(this.a,this.b)};_g(251,$wnd.Function,{},pm);_.rb=function(a){ol(this.a)};_g(252,$wnd.Function,{},qm);_.B=function(a){kl(this.a,a)};_g(253,$wnd.Function,{},rm);_.ob=function(a){vl(this.a,this.b)};_g(255,$wnd.Function,{},sm);_.qb=function(a){ll(this.a,this.b,a)};_g(157,1,{},wm);var Sf=rh(157);_g(239,$wnd.Function,{},xm);_.pb=function(a){var b;b=a.target;Fn((Cm(),Am),b.checked)};_g(68,1,{},ym);var Uf=rh(68);var zm,Am,Bm;_g(125,1,{});var Ag=rh(125);_g(126,125,Go,Pm);_.v=$o;_.q=Po;_.C=_o;_.s=Qo;_.w=ap;_.t=function(){var a;return nh(bg),bg.k+'@'+(a=Aj(this)>>>0,a.toString(16))};var bg=rh(126);_g(127,1,so,Qm);_.A=function(){Jm(this.a)};var Wf=rh(127);_g(129,1,vo,Rm);_.A=function(){Em(this.a)};var Xf=rh(129);_g(130,1,vo,Sm);_.A=function(){Fm(this.a)};var Yf=rh(130);_g(131,1,so,Tm);_.A=function(){Dm(this.a,this.b)};var Zf=rh(131);_g(132,1,so,Um);_.A=function(){Mm(this.a)};var $f=rh(132);_g(56,1,so,Vm);_.A=function(){Im(this.a)};var _f=rh(56);_g(128,1,oo,Wm);_.u=function(){var a;return a=(ih(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var ag=rh(128);_g(47,1,{47:1});_.d=false;var Ig=rh(47);_g(48,47,{8:1,20:1,48:1,47:1},en);_.v=$o;_.q=function(a){return Zm(this,a)};_.C=_o;_.s=function(){return this.c.e};_.w=ap;_.t=function(){var a;return nh(sg),sg.k+'@'+(a=this.c.e>>>0,a.toString(16))};var Xm=0;var sg=rh(48);_g(188,1,so,fn);_.A=function(){Ym(this.a)};var cg=rh(188);_g(189,1,so,gn);_.A=function(){an(this.a)};var dg=rh(189);_g(45,103,{45:1});var Dg=rh(45);_g(104,45,{8:1,20:1,45:1},qn);_.v=function(){jc(this.f)};_.q=Po;_.C=function(){return this.f.c};_.s=Qo;_.w=function(){return this.f.i<0};_.t=function(){var a;return nh(mg),mg.k+'@'+(a=Aj(this)>>>0,a.toString(16))};var mg=rh(104);_g(106,1,so,rn);_.A=function(){jn(this.a)};var eg=rh(106);_g(105,1,so,sn);_.A=function(){nn(this.a)};var fg=rh(105);_g(111,1,so,tn);_.A=function(){ec(this.a,this.b,true)};var gg=rh(111);_g(112,1,oo,un);_.u=function(){return hn(this.a,this.c,this.b)};_.b=false;var hg=rh(112);_g(107,1,oo,vn);_.u=function(){return on(this.a)};var ig=rh(107);_g(108,1,oo,wn);_.u=function(){return Bh(Sg(bj(mn(this.a))))};var jg=rh(108);_g(109,1,oo,xn);_.u=function(){return Bh(Sg(bj(cj(mn(this.a),new fo))))};var kg=rh(109);_g(110,1,oo,yn);_.u=function(){return pn(this.a)};var lg=rh(110);_g(87,1,{});var Hg=rh(87);_g(88,87,Go,Gn);_.v=function(){jc(this.a)};_.q=Po;_.C=function(){return this.a.c};_.s=Qo;_.w=function(){return this.a.i<0};_.t=function(){var a;return nh(rg),rg.k+'@'+(a=Aj(this)>>>0,a.toString(16))};var rg=rh(88);_g(89,1,so,Hn);_.A=Vo;var ng=rh(89);_g(90,1,so,In);_.A=function(){Cn(this.a,this.b)};_.b=false;var og=rh(90);_g(91,1,so,Jn);_.A=function(){Om(this.b,this.a)};var pg=rh(91);_g(92,1,so,Kn);_.A=function(){Dn(this.a)};var qg=rh(92);_g(93,1,{});var Kg=rh(93);_g(94,93,Go,Tn);_.v=function(){jc(this.g)};_.q=Po;_.C=function(){return this.g.c};_.s=Qo;_.w=function(){return this.g.i<0};_.t=function(){var a;return nh(yg),yg.k+'@'+(a=Aj(this)>>>0,a.toString(16))};var yg=rh(94);_g(95,1,so,Un);_.A=function(){Nn(this.a)};var tg=rh(95);_g(96,1,oo,Vn);_.u=function(){var a;return a=Lm(this.a.i),Hh(No,a)||Hh(Jo,a)||Hh('',a)?Hh(No,a)?(bo(),$n):Hh(Jo,a)?(bo(),ao):(bo(),_n):(bo(),_n)};var ug=rh(96);_g(97,1,oo,Wn);_.u=function(){return Pn(this.a)};var vg=rh(97);_g(98,1,vo,Xn);_.A=function(){Qn(this.a)};var wg=rh(98);_g(99,1,vo,Yn);_.A=function(){Rn(this.a)};var xg=rh(99);_g(120,1,{},Zn);_.handleEvent=function(a){Gm(this.a,a)};var zg=rh(120);_g(34,33,{3:1,29:1,33:1,34:1},co);var $n,_n,ao;var Bg=sh(34,eo);_g(83,1,{},fo);_.db=function(a){return !_m(a)};var Cg=rh(83);_g(85,1,{},go);_.db=function(a){return _m(a)};var Eg=rh(85);_g(86,1,{},ho);_.B=function(a){ln(this.a,a)};var Fg=rh(86);_g(84,1,{},io);_.B=function(a){An(this.a,a)};_.a=false;var Gg=rh(84);_g(77,1,{},jo);_.db=function(a){return Mn(this.a,a)};var Jg=rh(77);var ko=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=Wg;Ug(gh);Xg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();