function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='D6BAFEC2CD1F347E24501A4C0547AB47',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'D6BAFEC2CD1F347E24501A4C0547AB47';function p(){}
function mh(){}
function ih(){}
function Uh(){}
function Gb(){}
function Sc(){}
function Zc(){}
function nj(){}
function Bj(){}
function Jj(){}
function Kj(){}
function Km(){}
function rm(){}
function um(){}
function ym(){}
function Cm(){}
function Gm(){}
function $m(){}
function _m(){}
function hk(){}
function Xk(){}
function el(){}
function An(){}
function Io(){}
function Jo(){}
function Xc(a){Wc()}
function th(){th=ih}
function vi(){mi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function hc(a){this.a=a}
function qc(a){this.a=a}
function Jh(a){this.a=a}
function Th(a){this.a=a}
function ei(a){this.a=a}
function ji(a){this.a=a}
function ki(a){this.a=a}
function ii(a){this.b=a}
function xi(a){this.c=a}
function oj(a){this.a=a}
function Mj(a){this.a=a}
function dl(a){this.a=a}
function fl(a){this.a=a}
function gl(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function Bl(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function El(a){this.a=a}
function _l(a){this.a=a}
function am(a){this.a=a}
function bm(a){this.a=a}
function gm(a){this.a=a}
function im(a){this.a=a}
function om(a){this.a=a}
function pm(a){this.a=a}
function qm(a){this.a=a}
function Om(a){this.a=a}
function Pm(a){this.a=a}
function Rm(a){this.a=a}
function Sm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function un(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function Mn(a){this.a=a}
function Nn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function no(a){this.a=a}
function wo(a){this.a=a}
function xo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function Ij(a,b){a.a=b}
function rb(a,b){a.b=b}
function ck(a,b){a.key=b}
function ak(a,b){_j(a,b)}
function eo(a,b){Zl(b,a)}
function Z(a){!!a&&ab(a)}
function lc(a){!!a&&a.r()}
function w(a){--a.e;D(a)}
function np(a){_i(this,a)}
function qp(a){Nh(this,a)}
function sp(a){cj(this,a)}
function tp(){kc(this.c)}
function vp(){kc(this.b)}
function Ap(){kc(this.f)}
function Ji(){this.a=Si()}
function Xi(){this.a=Si()}
function xp(){lb(this.a.a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function Ug(a){return a.e}
function rp(){return this.e}
function lp(){return this.a}
function pp(){return this.b}
function K(){K=ih;J=new F}
function yc(){yc=ih;xc=new p}
function Pc(){Pc=ih;Oc=new Sc}
function Oi(){Oi=ih;Ni=Qi()}
function Yk(a){a.e=2;kc(a.c)}
function hl(a){a.d=2;kc(a.b)}
function Ml(a){a.g=2;kc(a.e)}
function al(a){lb(a.b);S(a.a)}
function nn(a){S(a.a);ab(a.b)}
function L(a,b){P(a);M(a,b)}
function Lj(a,b){Aj(a.a,b)}
function oc(a,b){ai(a.e,b)}
function co(a,b){Qn(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function jc(a,b,c){_h(a.e,b,c)}
function hj(a,b,c){b.v(a.a[c])}
function pi(a,b){return a.a[b]}
function Hl(a,b){return a.i=b}
function mp(){return Tj(this)}
function sh(a){wc.call(this,a)}
function Vh(a){wc.call(this,a)}
function Ll(a){Rn((fn(),cn),a)}
function vl(a){lb(a.a);ab(a.b)}
function Cn(a){ab(a.b);ab(a.a)}
function tc(a,b){a.e=b;sc(a,b)}
function Qj(a,b){a.splice(b,1)}
function Dn(a,b,c){jc(a.c,b,c)}
function $c(a,b){return Ch(a,b)}
function op(){return ci(this.a)}
function up(){return this.c.i<0}
function wp(){return this.b.i<0}
function Bp(){return this.f.i<0}
function Si(){Oi();return new Ni}
function wh(a){vh(a);return a.k}
function zj(a,b){a.Q(b);return a}
function U(a){nb(a.f);return W(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function bb(a){K();Zb(a);a.e=-2}
function Aj(a,b){Ij(a,zj(a.a,b))}
function cj(a,b){while(a.bb(b));}
function Fj(a,b,c){b.v(a.a.P(c))}
function v(a,b,c){t(a,new I(c),b)}
function ah(){$g==null&&($g=[])}
function Fc(){Fc=ih;!!(Wc(),Vc)}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function yp(a){return 1==this.a.e}
function zp(a){return 1==this.a.d}
function ci(a){return a.a.b+a.b.b}
function Ui(a,b){return a.a.get(b)}
function li(a,b){this.a=a;this.b=b}
function ic(a,b){this.a=a;this.b=b}
function ik(a,b){this.a=a;this.b=b}
function Hh(a,b){this.a=a;this.b=b}
function Hj(a,b){this.a=a;this.b=b}
function Ej(a,b){this.a=a;this.b=b}
function Fl(a,b){this.a=a;this.b=b}
function cm(a,b){this.a=a;this.b=b}
function dm(a,b){this.a=a;this.b=b}
function em(a,b){this.a=a;this.b=b}
function fm(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function sm(){this.a=ek((wm(),vm))}
function tm(){this.a=ek((Am(),zm))}
function Qm(){this.a=ek((Em(),Dm))}
function Tm(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function Tk(a,b){Hh.call(this,a,b)}
function xn(a,b){this.a=a;this.b=b}
function Yn(a,b){this.a=a;this.b=b}
function lo(a,b){this.a=a;this.b=b}
function mo(a,b){this.b=a;this.a=b}
function Go(a,b){Hh.call(this,a,b)}
function Oj(a,b,c){a.splice(b,0,c)}
function kk(a,b){a.ref=b;return a}
function lk(a,b){a.href=b;return a}
function Rh(a,b){a.a+=''+b;return a}
function uk(a,b){a.value=b;return a}
function pn(a){gb(a.b);return a.e}
function Gn(a){gb(a.a);return a.d}
function ro(a){gb(a.d);return a.e}
function qn(a){on(a,(gb(a.b),a.e))}
function Hn(a){Zl(a,(gb(a.a),!a.d))}
function an(){this.a=ek((Mm(),Lm))}
function Zm(){this.a=ek((Im(),Hm))}
function Mc(a){$wnd.clearTimeout(a)}
function $h(a){return !a?null:a.Z()}
function Ub(a){return !a.d?a:Ub(a.d)}
function bj(a){return a!=null?s(a):0}
function rd(a){return a==null?null:a}
function od(a){return typeof a===Po}
function o(a,b){return rd(a)===rd(b)}
function pk(a,b){a.onBlur=b;return a}
function mk(a,b){a.onClick=b;return a}
function ok(a,b){a.checked=b;return a}
function mi(a){a.a=ad(ke,Ro,1,0,5,1)}
function bi(a){a.a=new Ji;a.b=new Xi}
function jb(a){this.c=new vi;this.b=a}
function Xj(){Xj=ih;Uj=new p;Wj=new p}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function $(a){return !(!!a&&1==(a.c&7))}
function ed(a,b,c){return {l:a,m:b,h:c}}
function Oh(a,b){return a.charCodeAt(b)}
function Tj(a){return a.$H||(a.$H=++Sj)}
function qb(a){K();pb(a);tb(a,2,true)}
function Ql(a){lb(a.b);S(a.c);ab(a.a)}
function gc(a,b){cc(a,b,false);fb(a.c)}
function Pj(a,b){Nj(b,0,a,0,b.length)}
function go(a,b){oi(ec(a.b),new Lo(b))}
function _j(a,b){for(var c in a){b(c)}}
function qk(a,b){a.onChange=b;return a}
function rk(a,b){a.onKeyDown=b;return a}
function bk(a,b){a.props['a']=b;return a}
function nk(a){a.autoFocus=true;return a}
function vh(a){if(a.k!=null){return}Eh(a)}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Q(){this.a=ad(ke,Ro,1,100,5,1)}
function wc(a){this.g=a;rc(this);this.D()}
function yj(a,b){rj.call(this,a);this.a=b}
function fc(a,b){oc(b.c,a);md(b,9)&&b.t()}
function _i(a,b){while(a.V()){Lj(b,a.W())}}
function md(a,b){return a!=null&&kd(a,b)}
function Li(a,b){var c;c=a[ap];c.call(a,b)}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function Un(a){return Kh(T(a.e).a-T(a.a).a)}
function qd(a){return typeof a==='string'}
function nd(a){return typeof a==='boolean'}
function Gc(a,b,c){return a.apply(b,c);var d}
function vk(a,b){a.onDoubleClick=b;return a}
function rc(a){a.j&&a.e!==Xo&&a.D();return a}
function zh(a){var b;b=yh(a);Gh(a,b);return b}
function qo(a){lb(a.a);S(a.b);S(a.c);ab(a.d)}
function fo(a){A((K(),K(),J),new no(a),ep)}
function Xl(a){A((K(),K(),J),new im(a),ep)}
function rn(a){A((K(),K(),J),new yn(a),ep)}
function Kn(a){A((K(),K(),J),new Nn(a),ep)}
function xl(a,b){A((K(),K(),J),new Fl(a,b),ep)}
function Sl(a,b){A((K(),K(),J),new hm(a,b),ep)}
function Vl(a,b){A((K(),K(),J),new em(a,b),ep)}
function Wl(a,b){A((K(),K(),J),new dm(a,b),ep)}
function Yl(a,b){A((K(),K(),J),new cm(a,b),ep)}
function Rn(a,b){A((K(),K(),J),new Yn(a,b),ep)}
function io(a,b){A((K(),K(),J),new mo(a,b),ep)}
function jo(a,b){A((K(),K(),J),new lo(a,b),ep)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function yl(a,b){var c;c=b.target;zl(a,c.value)}
function fj(a,b){while(a.c<a.d){hj(a,b,a.c++)}}
function Db(a){while(true){if(!Cb(a)){break}}}
function Di(){this.a=new Ji;this.b=new Xi}
function Zn(a,b){this.a=a;this.c=b;this.b=false}
function $i(a,b,c){this.a=a;this.b=b;this.c=c}
function qh(a,b,c,d){a.addEventListener(b,c,d)}
function ni(a,b){a.a[a.a.length]=b;return true}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function jj(a){if(!a.d){a.d=a.b.O();a.c=a.b.R()}}
function gi(a){var b;b=a.a.W();a.b=fi(a);return b}
function Bh(a){var b;b=yh(a);b.j=a;b.e=1;return b}
function sj(a,b){var c;return wj(a,(c=new vi,c))}
function Ti(a,b){return !(a.a.get(b)===undefined)}
function oo(a){return o(jp,a)||o(kp,a)||o('',a)}
function zi(a){return new yj(null,yi(a,a.length))}
function cd(a){return Array.isArray(a)&&a.mb===mh}
function ld(a){return !Array.isArray(a)&&a.mb===mh}
function Tn(a){return th(),0!=T(a.e).a?true:false}
function yi(a,b){return dj(b,a.length),new ij(a,b)}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ri(a,b){var c;c=a.a[b];Qj(a.a,b);return c}
function Cj(a,b,c){if(a.a.db(c)){a.b=true;b.v(c)}}
function il(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function $k(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function Ol(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function $j(){if(Vj==256){Uj=Wj;Wj=new p;Vj=0}++Vj}
function Wc(){Wc=ih;var a;!Yc();a=new Zc;Vc=a}
function Mh(){Mh=ih;Lh=ad(he,Ro,28,256,0,1)}
function ph(){ph=ih;oh=$wnd.goog.global.document}
function Sn(a){Nh(new ji(a.g),new hc(a));bi(a.g)}
function Pn(a){S(a.d);S(a.e);S(a.a);S(a.b);ab(a.c)}
function Rl(a){return B((K(),K(),J),a.b,new am(a))}
function bl(a){return B((K(),K(),J),a.b,new fl(a))}
function kl(a){return B((K(),K(),J),a.a,new ol(a))}
function wl(a){return B((K(),K(),J),a.a,new Cl(a))}
function mm(a){return B((K(),K(),J),a.a,new qm(a))}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function zl(a,b){var c;c=a.f;if(b!=c){a.f=b;fb(a.b)}}
function Zl(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function sn(a,b){var c;c=a.e;if(b!=c){a.e=b;fb(a.b)}}
function ti(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function tk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function di(a,b){if(b){return Yh(a.a,b)}return false}
function uj(a,b){qj(a);return new yj(a,new Dj(b,a.a))}
function vj(a,b){qj(a);return new yj(a,new Gj(b,a.a))}
function on(a,b){A((K(),K(),J),new xn(a,b),75497472)}
function rh(a,b,c,d){a.removeEventListener(b,c,d)}
function pj(a){if(!a.b){qj(a);a.c=true}else{pj(a.b)}}
function rj(a){if(!a){this.b=null;new vi}else{this.b=a}}
function ij(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function ej(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function kj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function Ah(a,b){var c;c=yh(a);Gh(a,c);c.e=b?8:0;return c}
function uc(a,b){var c;c=wh(a.kb);return b==null?c:c+': '+b}
function Zh(a,b){return b===a?'(this Map)':b==null?Zo:lh(b)}
function Ci(a,b){return rd(a)===rd(b)||a!=null&&q(a,b)}
function mn(a){var b;V(a.a);b=T(a.a);o(a.f,b)&&sn(a,b)}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&Vo)&&D((null,J))}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function Dh(a){if(a.M()){return null}var b=a.j;return eh[b]}
function Zg(a){if(od(a)){return a|0}return a.l|a.m<<22}
function Gl(a,b){var c;if(T(a.c)){c=b.target;Zl(a,c.value)}}
function Nh(a,b){var c,d;for(d=a.O();d.V();){c=d.W();b.v(c)}}
function Ch(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function kh(a){function b(){}
;b.prototype=a||{};return new b}
function wm(){wm=ih;var a;vm=(a=jh(um.prototype.jb,um,[]),a)}
function Am(){Am=ih;var a;zm=(a=jh(ym.prototype.jb,ym,[]),a)}
function Em(){Em=ih;var a;Dm=(a=jh(Cm.prototype.jb,Cm,[]),a)}
function Im(){Im=ih;var a;Hm=(a=jh(Gm.prototype.jb,Gm,[]),a)}
function Mm(){Mm=ih;var a;Lm=(a=jh(Km.prototype.jb,Km,[]),a)}
function Ho(){Fo();return dd($c(Ig,1),Ro,30,0,[Co,Eo,Do])}
function Ul(a,b){uo((fn(),en),b);A((K(),K(),J),new cm(a,b),ep)}
function kn(a,b){b.preventDefault();A((K(),K(),J),new zn(a),ep)}
function Fi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Gi(a,b){var c;return Ei(b,Fi(a,b==null?0:(c=s(b),c|0)))}
function dc(a){gb(a.c);return new yj(null,new kj(new ji(a.g),0))}
function qj(a){if(a.b){qj(a.b)}else if(a.c){throw Ug(new Ih)}}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function hn(a){qh((ph(),$wnd.goog.global.window),hp,a.d,false)}
function jn(a){rh((ph(),$wnd.goog.global.window),hp,a.d,false)}
function wi(a){mi(this);Pj(this.a,Xh(a,ad(ke,Ro,1,ci(a.a),5,1)))}
function nc(a){lc(a.g);!!a.e&&mc(a);Z(a.a);Z(a.c);lc(a.b);lc(a.f)}
function gj(a,b){if(a.c<a.d){hj(a,b,a.c++);return true}return false}
function sk(a){a.placeholder='What needs to be done?';return a}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function gh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function gk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function ko(a){this.b=a;K();this.a=new pc(0,null,null,false,false)}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function Ki(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Fm(a){$wnd.React.Component.call(this,a);this.a=new Al(this)}
function xm(a){$wnd.React.Component.call(this,a);this.a=new cl(this)}
function Bm(a){$wnd.React.Component.call(this,a);this.a=new ll(this)}
function Jm(a){$wnd.React.Component.call(this,a);this.a=new $l(this)}
function Nm(a){$wnd.React.Component.call(this,a);this.a=new nm(this)}
function Gj(a,b){ej.call(this,b.ab(),b._()&-6);this.a=a;this.b=b}
function Dj(a,b){ej.call(this,b.ab(),b._()&-16449);this.a=a;this.c=b}
function Yi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function lj(a,b){!a.a?(a.a=new Th(a.d)):Rh(a.a,a.b);Rh(a.a,b);return a}
function tj(a){var b;pj(a);b=0;while(a.a.bb(new Kj)){b=Vg(b,1)}return b}
function wj(a,b){var c;pj(a);c=new Jj;c.a=b;a.a.U(new Mj(c));return c.a}
function ho(a){sj(uj(dc(a.b),new Jo),new oj(new nj)).N(new Ko(a.b))}
function fn(){fn=ih;cn=new Vn;dn=new ko(cn);bn=new tn;en=new vo(cn,bn)}
function Qn(a,b){var c;return u((K(),K(),J),new Zn(a,b),ep,(c=null,c))}
function cb(a,b){var c,d;ni(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function ai(a,b){return qd(b)?b==null?Ii(a.a,null):Wi(a.b,b):Ii(a.a,b)}
function po(a,b){return (Fo(),Do)==a||(Co==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function Tl(a){return th(),ro((fn(),en))==a.f.props['a']?true:false}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function Jb(b){try{nb(b.b.a)}catch(a){a=Tg(a);if(!md(a,4))throw Ug(a)}}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Zi(a){if(a.a.c!=a.c){return Ui(a.a,a.b.value[0])}return a.b.value[1]}
function hi(a){this.d=a;this.c=new Yi(this.d.b);this.a=this.c;this.b=fi(this)}
function mj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function xj(a,b){var c;c=sj(a,new oj(new nj));return ui(c,b.cb(c.a.length))}
function En(a,b){var c;if(md(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function si(a,b){var c;c=qi(a,b,0);if(c==-1){return false}Qj(a.a,c);return true}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function qi(a,b,c){for(;c<a.a.length;++c){if(Ci(b,a.a[c])){return c}}return -1}
function W(a){if(a.b){if(md(a.b,8)){throw Ug(a.b)}else{throw Ug(a.b)}}return a.k}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function S(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function ab(a){if(-2!=a.e){u((K(),K(),J),new H(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function kc(a){if(a.i>=0){a.i=-2;u((K(),K(),J),new H(new qc(a)),67108864,null)}}
function so(a){var b;return b=T(a.b),sj(uj(dc(a.i),new Mo(b)),new oj(new nj))}
function pl(a){var b;b=Qh((gb(a.b),a.f));if(b.length>0){co((fn(),dn),b);zl(a,'')}}
function gn(a,b){a.f=b;o(b,T(a.a))&&sn(a,b);ln(b);A((K(),K(),J),new zn(a),ep)}
function ql(a,b){if(13==b.keyCode){b.preventDefault();A((K(),K(),J),new Dl(a),ep)}}
function sb(b){if(b){try{b.r()}catch(a){a=Tg(a);if(md(a,4)){K()}else throw Ug(a)}}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function Qc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Uc(b,c)}while(a.a);a.a=c}}
function Rc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function _h(a,b,c){return qd(b)?b==null?Hi(a.a,null,c):Vi(a.b,b,c):Hi(a.a,b,c)}
function Rj(a,b){return _c(b)!=10&&dd(r(b),b.lb,b.__elementTypeId$,_c(b),a),a}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function pd(a){return a!=null&&(typeof a===Oo||typeof a==='function')&&!(a.mb===mh)}
function ec(a){return gb(a.c),sj(new yj(null,new kj(new ji(a.g),0)),new oj(new nj))}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new vi);a.c=c.c}b.d=true;ni(a.c,b)}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new vi);ni(a.b,b)}}}
function Gh(a,b){var c;if(!a){return}b.j=a;var d=Dh(b);if(!d){eh[a]=[b];return}d.kb=b}
function jh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function yh(a){var b;b=new xh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Ym(a,b){ck(a.a,(b?Kh(b.c.d):null)+(''+(vh($f),$f.k)));bk(a.a,b);return a.a}
function Wi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Li(a.a,b);--a.b}return c}
function oi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function Pb(){var a;this.a=ad(yd,Ro,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Wo:0)|(0!=(b&229376)?0:98304)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:To)|(0==(c&6291456)?!a?Vo:Wo:0)|0|0|0)}
function Ih(){wc.call(this,"Stream already terminated, can't be modified or used")}
function _g(){ah();var a=$g;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function pb(a){var b,c;for(c=new xi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ai(a){var b,c,d;d=0;for(c=new hi(a.a);c.b;){b=gi(c);d=d+(b?s(b):0);d=d|0}return d}
function Wh(a,b){var c,d;for(d=new hi(b.a);d.b;){c=gi(d);if(!di(a,c)){return false}}return true}
function On(a,b,c){var d;d=new Ln(b,c);Dn(d,a,new ic(a,d));_h(a.g,Kh(d.c.d),d);fb(a.c);return d}
function cc(a,b,c){var d;d=ai(a.g,b?Kh(b.c.d):null);if(null!=d){oc(b.c,a);c&&!!b&&kc(b.c);fb(a.c)}}
function to(a){var b;b=T(a.g.a);o(jp,b)||o(kp,b)||o('',b)?on(a.g,b):oo(pn(a.g))?rn(a.g):on(a.g,'')}
function ek(a){var b;b=dk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Wg(a){var b;b=a.h;if(b==0){return a.l+a.m*Wo}if(b==1048575){return a.l+a.m*Wo-$o}return a}
function Tg(a){var b;if(md(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function fi(a){if(a.a.V()){return true}if(a.a!=a.c){return false}a.a=new Ki(a.d.a);return a.a.V()}
function dj(a,b){if(0>a||a>b){throw Ug(new sh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function dh(a,b){typeof window===Oo&&typeof window['$gwt']===Oo&&(window['$gwt'][a]=b)}
function Fo(){Fo=ih;Co=new Go('ACTIVE',0);Eo=new Go('COMPLETED',1);Do=new Go('ALL',2)}
function nh(){fn();$wnd.ReactDOM.render((new an).a,(ph(),oh).getElementById('app'),null)}
function Ac(a){yc();rc(this);this.e=a;sc(this,a);this.g=a==null?Zo:lh(a);this.a='';this.b=a;this.a=''}
function xh(){this.g=uh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Vi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function dd(a,b,c,d,e){e.kb=a;e.lb=b;e.mb=mh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ei(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ci(a,c.Y())){return c}}return null}
function Yg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=$o;d=1048575}c=sd(e/Wo);b=sd(e-c*Wo);return ed(b,c,d)}
function Kh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Mh(),Lh)[b];!c&&(c=Lh[b]=new Jh(a));return c}return new Jh(a)}
function lh(a){var b;if(Array.isArray(a)&&a.mb===mh){return wh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function uo(a,b){var c;c=a.e;if(!(b==c||!!b&&En(b,c))){!!c&&oc(c.c,a);a.e=b;!!b&&Dn(b,a,new xo(a));fb(a.d)}}
function db(a,b){var c,d;d=a.c;si(d,b);!!a.b&&To!=(a.b.c&Uo)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function fd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ed(c&4194303,d&4194303,e&1048575)}
function Jl(a,b){var c;c=(gb(a.a),a.d);if(null!=c&&c.length!=0){io((fn(),b),c);uo(en,null);Zl(a,c)}else{Rn((fn(),cn),b)}}
function Il(a,b,c){27==c.which?A((K(),K(),J),new fm(a,b),ep):13==c.which&&A((K(),K(),J),new dm(a,b),ep)}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function Wk(){if(!Vk){Vk=(++(K(),K(),J).e,new Gb);$wnd.Promise.resolve(null).then(jh(Xk.prototype.G,Xk,[]))}}
function Uk(){Sk();return dd($c(df,1),Ro,6,0,[wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk])}
function r(a){return qd(a)?ne:od(a)?ce:nd(a)?ae:ld(a)?a.kb:cd(a)?a.kb:a.kb||Array.isArray(a)&&$c(Ud,1)||Ud}
function s(a){return qd(a)?Zj(a):od(a)?sd(a):nd(a)?a?1231:1237:ld(a)?a.p():cd(a)?Tj(a):!!a&&!!a.hashCode?a.hashCode():Tj(a)}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&To)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Kl(a){var b;b=T(a.c);if(!a.j&&b){a.j=true;Yl(a,a.f.props['a']);a.i.focus();a.i.select()}else a.j&&!b&&(a.j=false)}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=ri(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Bi(a){var b,c,d;d=1;for(c=new xi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function mc(a){var b,c,d;for(c=new xi(new wi(new ei(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.Y();md(d,9)&&d.u()||b.Z().r()}}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(To==(b&Uo)?0:524288)|(0==(b&6291456)?To==(b&Uo)?Wo:Vo:0)|0|268435456|0)}
function Zj(a){Xj();var b,c,d;c=':'+a;d=Wj[c];if(d!=null){return sd(d)}d=Uj[c];b=d==null?Yj(a):sd(d);$j();Wj[c]=b;return b}
function ui(a,b){var c,d;d=a.a.length;b.length<d&&(b=Rj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Fh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function ll(a){var b;this.c=a;K();b=++jl;this.b=new pc(b,null,new ml(this),false,false);this.a=new wb(null,new nl(this),dp)}
function nm(a){var b;this.c=a;K();b=++lm;this.b=new pc(b,null,new om(this),false,false);this.a=new wb(null,new pm(this),dp)}
function pc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Di:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new jb((f=null,K(),f)),g):null;this.c=null}
function Vg(a,b){var c;if(od(a)&&od(b)){c=a+b;if(-17592186044416<c&&c<$o){return c}}return Wg(fd(od(a)?Yg(a):a,od(b)?Yg(b):b))}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return qd(a)?o(a,b):od(a)?rd(a)===rd(b):nd(a)?rd(a)===rd(b):ld(a)?a.n(b):cd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function kd(a,b){if(qd(a)){return !!jd[b]}else if(a.lb){return !!a.lb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function jk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function T(a){a.j?hb(a.e):gb(a.e);if(ub(a.f)){if(a.j&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new xi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new xi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new xi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Qh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Xh(a,b){var c,d,e,f;f=ci(a.a);b.length<f&&(b=Rj(new Array(f),b));e=b;d=new hi(a.a);for(c=0;c<f;++c){e[c]=gi(d)}b.length>f&&(b[f]=null);return b}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.r(),null)}finally{bc()}return f}catch(a){a=Tg(a);if(md(a,4)){e=a;throw Ug(e)}else throw Ug(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.s()}else{ac(b,e);try{g=c.s()}finally{bc()}}return g}catch(a){a=Tg(a);if(md(a,4)){f=a;throw Ug(f)}else throw Ug(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.i=c;this.k=null;this.j=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);To==(d&Uo)&&mb(this.f)}
function Al(a){var b,c,d;this.d=a;K();b=++ul;this.c=new pc(b,null,new Bl(this),false,false);this.b=(d=new jb((c=null,c)),d);this.a=new wb(null,new El(this),dp)}
function cl(a){var b;this.d=a;K();b=++_k;this.c=new pc(b,null,new dl(this),false,false);this.a=new X(new el,null,null,136478720);this.b=new wb(null,new gl(this),dp)}
function Ln(a,b){var c,d,e,f,g;this.e=a;this.d=b;K();c=++Bn;this.c=new pc(c,null,new Mn(this),true,true);this.b=(g=new jb((e=null,e)),g);this.a=(f=new jb((d=null,d)),f)}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function bh(b,c,d,e){ah();var f=$g;$moduleName=c;$moduleBase=d;Sg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{No(g)()}catch(a){b(c,a)}}else{No(g)()}}
function dk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Qi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ri()}}
function fh(){eh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].nb()&&(c=Tc(c,g)):g[0].nb()}catch(a){a=Tg(a);if(md(a,4)){d=a;Fc();Lc(md(d,34)?d.F():d)}else throw Ug(a)}}return c}
function sl(a){var b;a.e=0;Wk();b=fk(fp,nk(qk(rk(uk(sk(jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,['new-todo']))),(gb(a.b),a.f)),jh(Om.prototype.hb,Om,[a])),jh(Pm.prototype.gb,Pm,[a]))),null);return b}
function zc(a){var b;if(a.c==null){b=rd(a.b)===rd(xc)?null:a.b;a.d=b==null?Zo:pd(b)?b==null?null:b.name:qd(b)?'String':wh(r(b));a.a=a.a+': '+(pd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.k;try{d=b.c.s();if(!(rd(e)===rd(d)||e!=null&&q(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=Tg(a);if(md(a,10)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw Ug(c)}else throw Ug(a)}}
function Hi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ei(b,e);if(f){return f.$(c)}}e[e.length]=new li(b,c);++a.b;return null}
function Nj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Yj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Oh(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{b.e.r()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Tg(a);if(md(a,4)){K()}else throw Ug(a)}}}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=ad(ke,Ro,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function vb(a,b,c,d){this.b=new vi;this.f=new Kb(new zb(this),d&6520832|262144|To);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&Vo)&&D((null,J)))}
function Ii(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ci(b,e.Y())){if(d.length==1){d.length=0;Li(a.a,g)}else{d.splice(h,1)}--a.b;return e.Z()}}return null}
function $l(a){var b,c,d;this.f=a;K();b=++Pl;this.e=new pc(b,null,new _l(this),false,false);this.a=(d=new jb((c=null,c)),d);this.c=new X(new bm(this),null,null,136478720);this.b=new wb(null,new gm(this),dp);Yl(this,this.f.props['a'])}
function hh(a,b,c){var d=eh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=eh[b]),kh(h));_.lb=c;!b&&(_.mb=mh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.kb=f)}
function Eh(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Fh('.',[c,Fh('$',d)]);a.b=Fh('.',[c,Fh('.',d)]);a.i=d[d.length-1]}
function Yh(a,b){var c,d,e;c=b.Y();e=b.Z();d=qd(c)?c==null?$h(Gi(a.a,null)):Ui(a.b,c):$h(Gi(a.a,c));if(!(rd(e)===rd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(qd(c)?c==null?!!Gi(a.a,null):Ti(a.b,c):!!Gi(a.a,c))){return false}return true}
function ln(a){var b;if(0==a.length){b=(ph(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',oh.title,b)}else{(ph(),$wnd.goog.global.window).location.hash=a}}
function vo(a,b){var c,d;this.i=a;this.g=b;K();this.f=new pc(0,null,new wo(this),false,false);this.d=(d=new jb((c=null,c)),d);this.b=new X(new yo(this),null,null,ip);this.c=new X(new zo(this),null,null,ip);this.a=new wb(new Ao(this),null,681574400);D((null,J))}
function Vn(){var a;this.g=new Di;K();this.f=new pc(0,new Xn(this),new Wn(this),false,false);this.c=(a=new jb(null),a);this.d=new X(new $n(this),null,null,ip);this.e=new X(new _n(this),null,null,ip);this.a=new X(new ao(this),null,null,ip);this.b=new X(new bo(this),null,null,ip)}
function tn(){var a,b,c;this.d=new Bo(this);this.f=this.e=(c=(ph(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));K();this.c=new pc(0,null,new un(this),false,false);this.b=(b=new jb((a=null,a)),b);this.a=new X(new An,new vn(this),new wn(this),35651584)}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new xi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Tg(a);if(!md(a,4))throw Ug(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.B();return a&&a.w()}},suppressed:{get:function(){return c.A()}}})}catch(a){}}}
function fk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ak(b,jh(ik.prototype.eb,ik,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=dk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function Pi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}oi(a.b,new Bb(a));a.b.a=ad(ke,Ro,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function Sk(){Sk=ih;wk=new Tk(bp,0);xk=new Tk('checkbox',1);yk=new Tk('color',2);zk=new Tk('date',3);Ak=new Tk('datetime',4);Bk=new Tk('email',5);Ck=new Tk('file',6);Dk=new Tk('hidden',7);Ek=new Tk('image',8);Fk=new Tk('month',9);Gk=new Tk(Po,10);Hk=new Tk('password',11);Ik=new Tk('radio',12);Jk=new Tk('range',13);Kk=new Tk('reset',14);Lk=new Tk('search',15);Mk=new Tk('submit',16);Nk=new Tk('tel',17);Ok=new Tk('text',18);Pk=new Tk('time',19);Qk=new Tk('url',20);Rk=new Tk('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=pi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ti(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=pi(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ri(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new vi)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&To!=(k.b.c&Uo)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function Zk(a){var b,c;a.e=0;Wk();c=(b=T((fn(),en).b),fk('footer',jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,['footer'])),[(new tm).a,fk('ul',jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,['filters'])),[fk('li',null,[fk('a',lk(jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,[(Fo(),Do)==b?cp:null])),'#'),['All'])]),fk('li',null,[fk('a',lk(jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,[Co==b?cp:null])),'#active'),['Active'])]),fk('li',null,[fk('a',lk(jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,[Eo==b?cp:null])),'#completed'),['Completed'])])]),T(a.a)?fk(bp,mk(jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,['clear-completed'])),jh(rm.prototype.ib,rm,[])),['Clear Completed']):null]));return c}
function Nl(a){var b,c,d,e;a.g=0;Wk();b=a.f.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.f.props['a'],e=(gb(d.a),d.d),fk('li',jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,[e?'checked':null,T(a.c)?'editing':null])),[fk('div',jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,['view'])),[fk(fp,qk(ok(tk(jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,['toggle'])),(Sk(),xk)),e),jh(Sm.prototype.gb,Sm,[d])),null),fk('label',vk(new $wnd.Object,jh(Tm.prototype.ib,Tm,[a,d])),[(gb(d.b),d.e)]),fk(bp,mk(jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,['destroy'])),jh(Um.prototype.ib,Um,[d])),null)]),fk(fp,rk(qk(pk(uk(jk(kk(new $wnd.Object,jh(Vm.prototype.v,Vm,[a])),dd($c(ne,1),Ro,2,6,['edit'])),(gb(a.a),a.d)),jh(Wm.prototype.fb,Wm,[a,d])),jh(Rm.prototype.gb,Rm,[a])),jh(Xm.prototype.hb,Xm,[a,d])),null)]));return c}
function Ri(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[ap]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Pi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[ap]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Oo='object',Po='number',Qo={5:1},Ro={3:1},So={9:1},To=1048576,Uo=1835008,Vo=2097152,Wo=4194304,Xo='__noinit__',Yo={3:1,10:1,8:1,4:1},Zo='null',$o=17592186044416,_o={40:1},ap='delete',bp='button',cp='selected',dp=1411518464,ep=142606336,fp='input',gp='header',hp='hashchange',ip=136314880,jp='active',kp='completed';var _,eh,$g,Sg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;fh();hh(1,null,{},p);_.n=function(a){return o(this,a)};_.o=function(){return this.kb};_.p=mp;_.q=function(){var a;return wh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.n(a)};_.hashCode=function(){return this.p()};_.toString=function(){return this.q()};var gd,hd,jd;hh(50,1,{},xh);_.H=function(a){var b;b=new xh;b.e=4;a>1?(b.c=Ch(this,a-1)):(b.c=this);return b};_.I=function(){vh(this);return this.b};_.J=function(){return wh(this)};_.K=function(){vh(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.q=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(vh(this),this.k)};_.e=0;_.g=0;var uh=1;var ke=zh(1);var be=zh(50);hh(78,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var xd=zh(78);hh(79,1,Qo,G);_.r=function(){Db(this.a)};var ud=zh(79);hh(35,1,{},H);_.s=function(){return this.a.r(),null};var vd=zh(35);hh(80,1,{},I);var wd=zh(80);var J;hh(43,1,{43:1},Q);_.b=0;_.c=false;_.d=0;var yd=zh(43);hh(214,1,So);_.q=function(){var a;return wh(this.kb)+'@'+(a=s(this)>>>0,a.toString(16))};var Bd=zh(214);hh(18,214,So,X);_.t=function(){S(this)};_.u=lp;_.a=false;_.d=0;_.j=false;var Ad=zh(18);hh(123,1,{},Y);_.s=function(){return U(this.a)};var zd=zh(123);hh(15,214,{9:1,15:1},jb);_.t=function(){ab(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Dd=zh(15);hh(122,1,Qo,kb);_.r=function(){bb(this.a)};var Cd=zh(122);hh(16,214,{9:1,16:1},wb,xb);_.t=function(){lb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Id=zh(16);hh(124,1,{},yb);_.r=function(){R(this.a)};var Ed=zh(124);hh(125,1,Qo,zb);_.r=function(){nb(this.a)};var Fd=zh(125);hh(126,1,Qo,Ab);_.r=function(){qb(this.a)};var Gd=zh(126);hh(127,1,{},Bb);_.v=function(a){ob(this.a,a)};var Hd=zh(127);hh(132,1,{},Eb);_.a=0;_.b=0;_.c=0;var Jd=zh(132);hh(159,1,So,Gb);_.t=function(){Fb(this)};_.u=lp;_.a=false;var Kd=zh(159);hh(58,214,{9:1,58:1},Kb);_.t=function(){Hb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Md=zh(58);hh(137,1,{},Pb);var Ld=zh(137);hh(139,1,{},_b);_.q=function(){var a;return vh(Nd),Nd.k+'@'+(a=Tj(this)>>>0,a.toString(16))};_.a=0;var Qb;var Nd=zh(139);hh(110,1,{});var Qd=zh(110);hh(82,1,{},hc);_.v=function(a){fc(this.a,a)};var Od=zh(82);hh(83,1,Qo,ic);_.r=function(){gc(this.a,this.b)};var Pd=zh(83);hh(14,1,So,pc);_.t=function(){kc(this)};_.u=function(){return this.i<0};_.q=function(){var a;return vh(Sd),Sd.k+'@'+(a=Tj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Sd=zh(14);hh(121,1,Qo,qc);_.r=function(){nc(this.a)};var Rd=zh(121);hh(4,1,{3:1,4:1});_.w=rp;_.A=function(){return xj(vj(zi((this.i==null&&(this.i=ad(pe,Ro,4,0,0,1)),this.i)),new Uh),new Bj)};_.B=function(){return this.f};_.C=function(){return this.g};_.D=function(){tc(this,vc(new Error(uc(this,this.g))));Xc(this)};_.q=function(){return uc(this,this.C())};_.e=Xo;_.j=true;var pe=zh(4);hh(10,4,{3:1,10:1,4:1});var ee=zh(10);hh(8,10,Yo);var le=zh(8);hh(71,8,Yo);var ie=zh(71);hh(72,71,Yo);var Wd=zh(72);hh(34,72,{34:1,3:1,10:1,8:1,4:1},Ac);_.C=function(){zc(this);return this.c};_.F=function(){return rd(this.b)===rd(xc)?null:this.b};var xc;var Td=zh(34);var Ud=zh(0);hh(200,1,{});var Vd=zh(200);var Cc=0,Dc=0,Ec=-1;hh(109,200,{},Sc);var Oc;var Xd=zh(109);var Vc;hh(211,1,{});var Zd=zh(211);hh(73,211,{},Zc);var Yd=zh(73);var oh;hh(69,1,{66:1});_.q=lp;var $d=zh(69);hh(75,8,Yo);var ge=zh(75);hh(155,75,Yo,sh);var _d=zh(155);gd={3:1,67:1,27:1};var ae=zh(67);hh(41,1,{3:1,41:1});var je=zh(41);hd={3:1,27:1,41:1};var ce=zh(210);hh(29,1,{3:1,27:1,29:1});_.n=function(a){return this===a};_.p=mp;_.q=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=zh(29);hh(74,8,Yo,Ih);var fe=zh(74);hh(28,41,{3:1,27:1,28:1,41:1},Jh);_.n=function(a){return md(a,28)&&a.a==this.a};_.p=lp;_.q=function(){return ''+this.a};_.a=0;var he=zh(28);var Lh;hh(277,1,{});jd={3:1,66:1,27:1,2:1};var ne=zh(2);hh(70,69,{66:1},Th);var me=zh(70);hh(281,1,{});hh(64,1,{},Uh);_.P=function(a){return a.e};var oe=zh(64);hh(52,8,Yo,Vh);var qe=zh(52);hh(212,1,{39:1});_.N=qp;_.S=function(){return new kj(this,0)};_.T=function(){return new yj(null,this.S())};_.Q=function(a){throw Ug(new Vh('Add not supported on this collection'))};_.q=function(){var a,b,c;c=new mj('[',']');for(b=this.O();b.V();){a=b.W();lj(c,a===this?'(this Collection)':a==null?Zo:lh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var re=zh(212);hh(215,1,{198:1});_.n=function(a){var b,c,d;if(a===this){return true}if(!md(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new hi((new ei(d)).a);c.b;){b=gi(c);if(!Yh(this,b)){return false}}return true};_.p=function(){return Ai(new ei(this))};_.q=function(){var a,b,c;c=new mj('{','}');for(b=new hi((new ei(this)).a);b.b;){a=gi(b);lj(c,Zh(this,a.Y())+'='+Zh(this,a.Z()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ce=zh(215);hh(128,215,{198:1});var ue=zh(128);hh(216,212,{39:1,225:1});_.S=function(){return new kj(this,1)};_.n=function(a){var b;if(a===this){return true}if(!md(a,21)){return false}b=a;if(ci(b.a)!=this.R()){return false}return Wh(this,b)};_.p=function(){return Ai(this)};var De=zh(216);hh(21,216,{21:1,39:1,225:1},ei);_.O=function(){return new hi(this.a)};_.R=op;var te=zh(21);hh(22,1,{},hi);_.U=np;_.W=function(){return gi(this)};_.V=pp;_.b=false;var se=zh(22);hh(213,212,{39:1,222:1});_.S=function(){return new kj(this,16)};_.X=function(a,b){throw Ug(new Vh('Add not supported on this list'))};_.Q=function(a){this.X(this.R(),a);return true};_.n=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,13)){return false}f=a;if(this.R()!=f.a.length){return false}e=new xi(f);for(c=new xi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(rd(b)===rd(d)||b!=null&&q(b,d))){return false}}return true};_.p=function(){return Bi(this)};_.O=function(){return new ii(this)};var we=zh(213);hh(108,1,{},ii);_.U=np;_.V=function(){return this.a<this.b.a.length};_.W=function(){return pi(this.b,this.a++)};_.a=0;var ve=zh(108);hh(42,212,{39:1},ji);_.O=function(){var a;a=new hi((new ei(this.a)).a);return new ki(a)};_.R=op;var ye=zh(42);hh(131,1,{},ki);_.U=np;_.V=function(){return this.a.b};_.W=function(){var a;a=gi(this.a);return a.Z()};var xe=zh(131);hh(129,1,_o);_.n=function(a){var b;if(!md(a,40)){return false}b=a;return Ci(this.a,b.Y())&&Ci(this.b,b.Z())};_.Y=lp;_.Z=pp;_.p=function(){return bj(this.a)^bj(this.b)};_.$=function(a){var b;b=this.b;this.b=a;return b};_.q=function(){return this.a+'='+this.b};var ze=zh(129);hh(130,129,_o,li);var Ae=zh(130);hh(217,1,_o);_.n=function(a){var b;if(!md(a,40)){return false}b=a;return Ci(this.b.value[0],b.Y())&&Ci(Zi(this),b.Z())};_.p=function(){return bj(this.b.value[0])^bj(Zi(this))};_.q=function(){return this.b.value[0]+'='+Zi(this)};var Be=zh(217);hh(13,213,{3:1,13:1,39:1,222:1},vi,wi);_.X=function(a,b){Oj(this.a,a,b)};_.Q=function(a){return ni(this,a)};_.N=function(a){oi(this,a)};_.O=function(){return new xi(this)};_.R=function(){return this.a.length};var Fe=zh(13);hh(17,1,{},xi);_.U=np;_.V=function(){return this.a<this.c.a.length};_.W=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ee=zh(17);hh(36,128,{3:1,36:1,198:1},Di);var Ge=zh(36);hh(56,1,{},Ji);_.N=qp;_.O=function(){return new Ki(this)};_.b=0;var Ie=zh(56);hh(57,1,{},Ki);_.U=np;_.W=function(){return this.d=this.a[this.c++],this.d};_.V=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var He=zh(57);var Ni;hh(54,1,{},Xi);_.N=qp;_.O=function(){return new Yi(this)};_.b=0;_.c=0;var Le=zh(54);hh(55,1,{},Yi);_.U=np;_.W=function(){return this.c=this.a,this.a=this.b.next(),new $i(this.d,this.c,this.d.c)};_.V=function(){return !this.a.done};var Je=zh(55);hh(138,217,_o,$i);_.Y=function(){return this.b.value[0]};_.Z=function(){return Zi(this)};_.$=function(a){return Vi(this.a,this.b.value[0],a)};_.c=0;var Ke=zh(138);hh(141,1,{});_.U=sp;_._=function(){return this.d};_.ab=rp;_.d=0;_.e=0;var Pe=zh(141);hh(59,141,{});var Me=zh(59);hh(133,1,{});_.U=sp;_._=pp;_.ab=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Oe=zh(133);hh(134,133,{},ij);_.U=function(a){fj(this,a)};_.bb=function(a){return gj(this,a)};var Ne=zh(134);hh(19,1,{},kj);_._=lp;_.ab=function(){jj(this);return this.c};_.U=function(a){jj(this);this.d.U(a)};_.bb=function(a){jj(this);if(this.d.V()){a.v(this.d.W());return true}return false};_.a=0;_.c=0;var Qe=zh(19);hh(51,1,{},mj);_.q=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Re=zh(51);hh(33,1,{},nj);_.P=function(a){return a};var Se=zh(33);hh(37,1,{},oj);var Te=zh(37);hh(140,1,{});_.c=false;var bf=zh(140);hh(23,140,{},yj);var af=zh(23);hh(65,1,{},Bj);_.cb=function(a){return ad(ke,Ro,1,a,5,1)};var Ue=zh(65);hh(143,59,{},Dj);_.bb=function(a){this.b=false;while(!this.b&&this.c.bb(new Ej(this,a)));return this.b};_.b=false;var We=zh(143);hh(146,1,{},Ej);_.v=function(a){Cj(this.a,this.b,a)};var Ve=zh(146);hh(142,59,{},Gj);_.bb=function(a){return this.b.bb(new Hj(this,a))};var Ye=zh(142);hh(145,1,{},Hj);_.v=function(a){Fj(this.a,this.b,a)};var Xe=zh(145);hh(144,1,{},Jj);_.v=function(a){Ij(this,a)};var Ze=zh(144);hh(147,1,{},Kj);_.v=function(a){};var $e=zh(147);hh(148,1,{},Mj);_.v=function(a){Lj(this,a)};var _e=zh(148);hh(279,1,{});hh(276,1,{});var Sj=0;var Uj,Vj=0,Wj;hh(894,1,{});hh(918,1,{});hh(156,1,{},hk);_.cb=function(a){return new Array(a)};var cf=zh(156);hh(244,$wnd.Function,{},ik);_.eb=function(a){gk(this.a,this.b,a)};hh(6,29,{3:1,27:1,29:1,6:1},Tk);var wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk;var df=Ah(6,Uk);var Vk;hh(245,$wnd.Function,{},Xk);_.G=function(a){return Fb(Vk),Vk=null,null};hh(220,1,{});var Mf=zh(220);hh(172,220,{});_.e=0;var Qf=zh(172);hh(173,172,So,cl);_.t=tp;_.u=up;_.q=function(){var a;return vh(nf),nf.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var _k=0;var nf=zh(173);hh(174,1,Qo,dl);_.r=function(){al(this.a)};var ef=zh(174);hh(175,1,{},el);_.s=function(){return th(),T((fn(),cn).b).a>0?true:false};var ff=zh(175);hh(177,1,{},fl);_.s=function(){return Zk(this.a)};var gf=zh(177);hh(176,1,{},gl);_.r=function(){$k(this.a)};var hf=zh(176);hh(221,1,{});var Lf=zh(221);hh(192,221,{});_.d=0;var Pf=zh(192);hh(193,192,So,ll);_.t=vp;_.u=wp;_.q=function(){var a;return vh(mf),mf.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var jl=0;var mf=zh(193);hh(194,1,Qo,ml);_.r=xp;var jf=zh(194);hh(195,1,{},nl);_.r=function(){il(this.a)};var kf=zh(195);hh(196,1,{},ol);_.s=function(){var a;return this.a.d=0,Wk(),a=T((fn(),cn).e).a,fk('span',jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,['todo-count'])),[fk('strong',null,[a]),' item'+(a==1?'':'s')+' left'])};var lf=zh(196);hh(164,1,{});_.f='';var Yf=zh(164);hh(165,164,{});_.e=0;var Sf=zh(165);hh(166,165,So,Al);_.t=tp;_.u=up;_.q=function(){var a;return vh(tf),tf.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var ul=0;var tf=zh(166);hh(167,1,Qo,Bl);_.r=function(){vl(this.a)};var of=zh(167);hh(169,1,{},Cl);_.s=function(){return sl(this.a)};var pf=zh(169);hh(170,1,Qo,Dl);_.r=function(){pl(this.a)};var qf=zh(170);hh(168,1,{},El);_.r=function(){$k(this.a)};var rf=zh(168);hh(171,1,Qo,Fl);_.r=function(){yl(this.a,this.b)};var sf=zh(171);hh(219,1,{});_.j=false;var $f=zh(219);hh(179,219,{});_.g=0;var Uf=zh(179);hh(180,179,So,$l);_.t=function(){kc(this.e)};_.u=function(){return this.e.i<0};_.q=function(){var a;return vh(Ef),Ef.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var Pl=0;var Ef=zh(180);hh(181,1,Qo,_l);_.r=function(){Ql(this.a)};var uf=zh(181);hh(184,1,{},am);_.s=function(){return Nl(this.a)};var vf=zh(184);hh(182,1,{},bm);_.s=function(){return Tl(this.a)};var wf=zh(182);hh(60,1,Qo,cm);_.r=function(){Zl(this.a,pn(this.b))};var xf=zh(60);hh(61,1,Qo,dm);_.r=function(){Jl(this.a,this.b)};var yf=zh(61);hh(185,1,Qo,em);_.r=function(){Ul(this.a,this.b)};var zf=zh(185);hh(186,1,Qo,fm);_.r=function(){Yl(this.a,this.b);uo((fn(),en),null)};var Af=zh(186);hh(183,1,{},gm);_.r=function(){Ol(this.a)};var Bf=zh(183);hh(187,1,Qo,hm);_.r=function(){Gl(this.a,this.b)};var Cf=zh(187);hh(188,1,Qo,im);_.r=function(){Kl(this.a)};var Df=zh(188);hh(218,1,{});var bg=zh(218);hh(150,218,{});_.d=0;var Wf=zh(150);hh(151,150,So,nm);_.t=vp;_.u=wp;_.q=function(){var a;return vh(If),If.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var lm=0;var If=zh(151);hh(152,1,Qo,om);_.r=xp;var Ff=zh(152);hh(153,1,{},pm);_.r=function(){il(this.a)};var Gf=zh(153);hh(154,1,{},qm);_.s=function(){return this.a.d=0,Wk(),fk('div',null,[fk('div',null,[fk(gp,jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,[gp])),[fk('h1',null,['todos']),(new Qm).a]),T((fn(),cn).d)?fk('section',jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,[gp])),[fk(fp,qk(tk(jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,['toggle-all'])),(Sk(),xk)),jh($m.prototype.gb,$m,[])),null),fk('ul',jk(new $wnd.Object,dd($c(ne,1),Ro,2,6,['todo-list'])),xj(vj(T(en.c).T(),new _m),new hk))]):null,T(cn.d)?(new sm).a:null])])};var Hf=zh(154);hh(249,$wnd.Function,{},rm);_.ib=function(a){fo((fn(),dn))};hh(158,1,{},sm);var Jf=zh(158);hh(178,1,{},tm);var Kf=zh(178);hh(250,$wnd.Function,{},um);_.jb=function(a){return new xm(a)};var vm;hh(162,$wnd.React.Component,{},xm);gh(eh[1],_);_.componentWillUnmount=function(){Yk(this.a)};_.render=function(){return bl(this.a)};_.shouldComponentUpdate=yp;var Nf=zh(162);hh(260,$wnd.Function,{},ym);_.jb=function(a){return new Bm(a)};var zm;hh(189,$wnd.React.Component,{},Bm);gh(eh[1],_);_.componentWillUnmount=function(){hl(this.a)};_.render=function(){return kl(this.a)};_.shouldComponentUpdate=zp;var Of=zh(189);hh(248,$wnd.Function,{},Cm);_.jb=function(a){return new Fm(a)};var Dm;hh(161,$wnd.React.Component,{},Fm);gh(eh[1],_);_.componentWillUnmount=function(){Yk(this.a)};_.render=function(){return wl(this.a)};_.shouldComponentUpdate=yp;var Rf=zh(161);hh(251,$wnd.Function,{},Gm);_.jb=function(a){return new Jm(a)};var Hm;hh(163,$wnd.React.Component,{},Jm);gh(eh[1],_);_.componentDidUpdate=function(a){Xl(this.a)};_.componentWillUnmount=function(){Ml(this.a)};_.render=function(){return Rl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.g};var Tf=zh(163);hh(242,$wnd.Function,{},Km);_.jb=function(a){return new Nm(a)};var Lm;hh(135,$wnd.React.Component,{},Nm);gh(eh[1],_);_.componentWillUnmount=function(){hl(this.a)};_.render=function(){return mm(this.a)};_.shouldComponentUpdate=zp;var Vf=zh(135);hh(246,$wnd.Function,{},Om);_.hb=function(a){ql(this.a,a)};hh(247,$wnd.Function,{},Pm);_.gb=function(a){xl(this.a,a)};hh(157,1,{},Qm);var Xf=zh(157);hh(258,$wnd.Function,{},Rm);_.gb=function(a){Sl(this.a,a)};hh(252,$wnd.Function,{},Sm);_.gb=function(a){Kn(this.a)};hh(254,$wnd.Function,{},Tm);_.ib=function(a){Vl(this.a,this.b)};hh(255,$wnd.Function,{},Um);_.ib=function(a){Ll(this.a)};hh(256,$wnd.Function,{},Vm);_.v=function(a){Hl(this.a,a)};hh(257,$wnd.Function,{},Wm);_.fb=function(a){Wl(this.a,this.b)};hh(259,$wnd.Function,{},Xm);_.hb=function(a){Il(this.a,this.b,a)};hh(160,1,{},Zm);var Zf=zh(160);hh(241,$wnd.Function,{},$m);_.gb=function(a){var b;b=a.target;jo((fn(),dn),b.checked)};hh(136,1,{},_m);_.P=function(a){return Ym(new Zm,a)};var _f=zh(136);hh(63,1,{},an);var ag=zh(63);var bn,cn,dn,en;hh(93,1,{});var Hg=zh(93);hh(94,93,So,tn);_.t=tp;_.u=up;_.q=function(){var a;return vh(jg),jg.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var jg=zh(94);hh(95,1,Qo,un);_.r=function(){nn(this.a)};var cg=zh(95);hh(97,1,{},vn);_.r=function(){hn(this.a)};var dg=zh(97);hh(98,1,{},wn);_.r=function(){jn(this.a)};var eg=zh(98);hh(99,1,Qo,xn);_.r=function(){gn(this.a,this.b)};var fg=zh(99);hh(100,1,Qo,yn);_.r=function(){qn(this.a)};var gg=zh(100);hh(53,1,Qo,zn);_.r=function(){mn(this.a)};var hg=zh(53);hh(96,1,{},An);_.s=function(){var a;return a=(ph(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var ig=zh(96);hh(44,1,{44:1});_.d=false;var Pg=zh(44);hh(45,44,{9:1,243:1,45:1,44:1},Ln);_.t=tp;_.n=function(a){return En(this,a)};_.p=function(){return this.c.d};_.u=up;_.q=function(){var a;return vh(zg),zg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Bn=0;var zg=zh(45);hh(190,1,Qo,Mn);_.r=function(){Cn(this.a)};var kg=zh(190);hh(191,1,Qo,Nn);_.r=function(){Hn(this.a)};var lg=zh(191);hh(111,110,{});var Kg=zh(111);hh(112,111,So,Vn);_.t=Ap;_.u=Bp;_.q=function(){var a;return vh(ug),ug.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var ug=zh(112);hh(114,1,Qo,Wn);_.r=function(){Pn(this.a)};var mg=zh(114);hh(113,1,Qo,Xn);_.r=function(){Sn(this.a)};var ng=zh(113);hh(119,1,Qo,Yn);_.r=function(){cc(this.a,this.b,true)};var og=zh(119);hh(120,1,{},Zn);_.s=function(){return On(this.a,this.c,this.b)};_.b=false;var pg=zh(120);hh(115,1,{},$n);_.s=function(){return Tn(this.a)};var qg=zh(115);hh(116,1,{},_n);_.s=function(){return Kh(Zg(tj(dc(this.a))))};var rg=zh(116);hh(117,1,{},ao);_.s=function(){return Kh(Zg(tj(uj(dc(this.a),new Io))))};var sg=zh(117);hh(118,1,{},bo);_.s=function(){return Un(this.a)};var tg=zh(118);hh(87,1,{});var Og=zh(87);hh(88,87,So,ko);_.t=function(){kc(this.a)};_.u=function(){return this.a.i<0};_.q=function(){var a;return vh(yg),yg.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var yg=zh(88);hh(89,1,Qo,lo);_.r=function(){go(this.a,this.b)};_.b=false;var vg=zh(89);hh(90,1,Qo,mo);_.r=function(){sn(this.b,this.a)};var wg=zh(90);hh(91,1,Qo,no);_.r=function(){ho(this.a)};var xg=zh(91);hh(101,1,{});var Rg=zh(101);hh(102,101,So,vo);_.t=Ap;_.u=Bp;_.q=function(){var a;return vh(Fg),Fg.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var Fg=zh(102);hh(103,1,Qo,wo);_.r=function(){qo(this.a)};var Ag=zh(103);hh(107,1,Qo,xo);_.r=function(){uo(this.a,null)};var Bg=zh(107);hh(104,1,{},yo);_.s=function(){var a;return a=pn(this.a.g),o(jp,a)?(Fo(),Co):o(kp,a)?(Fo(),Eo):(Fo(),Do)};var Cg=zh(104);hh(105,1,{},zo);_.s=function(){return so(this.a)};var Dg=zh(105);hh(106,1,{},Ao);_.r=function(){to(this.a)};var Eg=zh(106);hh(92,1,{},Bo);_.handleEvent=function(a){kn(this.a,a)};var Gg=zh(92);hh(30,29,{3:1,27:1,29:1,30:1},Go);var Co,Do,Eo;var Ig=Ah(30,Ho);hh(81,1,{},Io);_.db=function(a){return !Gn(a)};var Jg=zh(81);hh(85,1,{},Jo);_.db=function(a){return Gn(a)};var Lg=zh(85);hh(86,1,{},Ko);_.v=function(a){Rn(this.a,a)};var Mg=zh(86);hh(84,1,{},Lo);_.v=function(a){eo(this.a,a)};_.a=false;var Ng=zh(84);hh(76,1,{},Mo);_.db=function(a){return po(this.a,a)};var Qg=zh(76);var td=Bh('D');var No=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=bh;_g(nh);dh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();