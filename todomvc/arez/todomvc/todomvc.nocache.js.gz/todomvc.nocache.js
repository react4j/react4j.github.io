function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='E95420463A276AF20263A8AD78E122D1',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'E95420463A276AF20263A8AD78E122D1';function o(){}
function Tg(){}
function Pg(){}
function Pl(){}
function Il(){}
function Ll(){}
function Tl(){}
function Xl(){}
function _l(){}
function Hb(){}
function Kc(){}
function Rc(){}
function Yi(){}
function Zi(){}
function Zn(){}
function Yn(){}
function mk(){}
function vk(){}
function pm(){}
function Om(){}
function Pc(a){Oc()}
function Zg(){Zg=Pg}
function Yh(){Ph(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function Hh(a){this.a=a}
function nh(a){this.a=a}
function Mh(a){this.a=a}
function Nh(a){this.a=a}
function lb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function cc(a){this.a=a}
function lc(a){this.a=a}
function Wi(a){this.a=a}
function _i(a){this.a=a}
function uk(a){this.a=a}
function wk(a){this.a=a}
function xk(a){this.a=a}
function Dk(a){this.a=a}
function Ek(a){this.a=a}
function Fk(a){this.a=a}
function Sk(a){this.a=a}
function Tk(a){this.a=a}
function Uk(a){this.a=a}
function Wk(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function tl(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function dm(a){this.a=a}
function em(a){this.a=a}
function gm(a){this.a=a}
function hm(a){this.a=a}
function jm(a){this.a=a}
function km(a){this.a=a}
function Im(a){this.a=a}
function Jm(a){this.a=a}
function Km(a){this.a=a}
function Mm(a){this.a=a}
function Nm(a){this.a=a}
function $m(a){this.a=a}
function _m(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function on(a){this.a=a}
function pn(a){this.a=a}
function qn(a){this.a=a}
function rn(a){this.a=a}
function Cn(a){this.a=a}
function Mn(a){this.a=a}
function Nn(a){this.a=a}
function On(a){this.a=a}
function Pn(a){this.a=a}
function Qn(a){this.a=a}
function Rn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function Lh(a){this.b=a}
function $h(a){this.c=a}
function Mo(){fc(this.c)}
function Oo(){fc(this.b)}
function ii(){this.a=ri()}
function wi(){this.a=ri()}
function Xi(a,b){a.a=b}
function rj(a,b){a.key=b}
function qj(a,b){pj(a,b)}
function tn(a,b){Wm(b,a)}
function Io(a){Ai(this,a)}
function Lo(a){rh(this,a)}
function gb(a){Vb((J(),a))}
function hb(a){Wb((J(),a))}
function jb(a){Xb((J(),a))}
function w(a){--a.e;D(a)}
function V(a){!!a&&cb(a)}
function gc(a){!!a&&a.t()}
function Kb(a){a.a=-4&a.a|1}
function Ag(a){return a.b}
function Ko(){return this.b}
function Fo(){return this.a}
function Qo(){mb(this.a.a)}
function To(a){jc(this.c,a)}
function jc(a,b){Dh(a.e,b)}
function $i(a,b){Ri(a.a,b)}
function sn(a,b){cn(a.b,b)}
function C(a,b){ab(a.f,b.f)}
function sb(a,b){a.b=Di(b)}
function yk(a){a.c=2;fc(a.b)}
function nk(a){a.d=2;fc(a.c)}
function cl(a){a.e=2;fc(a.d)}
function Bm(a){R(a.a);cb(a.b)}
function rk(a){mb(a.b);R(a.a)}
function xh(a){pc.call(this,a)}
function Ho(){return hj(this)}
function uh(a,b){return a===b}
function Yk(a,b){return a.f=b}
function Sh(a,b){return a.a[b]}
function dj(a,b){a.splice(b,1)}
function ec(a,b,c){Ch(a.e,b,c)}
function Rm(a,b,c){ec(a.c,b,c)}
function Qm(a){cb(a.b);cb(a.a)}
function Mk(a){mb(a.a);cb(a.b)}
function bl(a){dn((um(),rm),a)}
function ni(){ni=Pg;mi=pi()}
function J(){J=Pg;I=new F}
function rc(){rc=Pg;qc=new o}
function Hc(){Hc=Pg;Gc=new Kc}
function xc(){xc=Pg;!!(Oc(),Nc)}
function Ig(){Gg==null&&(Gg=[])}
function Go(a){return this===a}
function No(){return this.c.i<0}
function Po(){return this.b.i<0}
function Jo(){return Fh(this.a)}
function Sc(a,b){return gh(a,b)}
function Ri(a,b){Xi(a,Qi(a.a,b))}
function Ei(a,b){while(a.Z(b));}
function Qi(a,b){a.M(b);return a}
function Aj(a,b){a.ref=b;return a}
function ah(a){_g(a);return a.k}
function Dm(a){ib(a.b);return a.e}
function Um(a){ib(a.a);return a.d}
function Gn(a){ib(a.d);return a.f}
function ri(){ni();return new mi}
function db(a){J();Wb(a);a.e=-2}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function sh(){mc(this);this.A()}
function lh(a,b){this.a=a;this.b=b}
function Oh(a,b){this.a=a;this.b=b}
function dc(a,b){this.a=a;this.b=b}
function Ui(a,b){this.a=a;this.b=b}
function yj(a,b){this.a=a;this.b=b}
function Ro(a){return 1==this.a.d}
function So(a){return 1==this.a.c}
function Fh(a){return a.a.b+a.b.b}
function ti(a,b){return a.a.get(b)}
function W(a){return !!a&&a.c.i<0}
function Xc(a){return new Array(a)}
function v(a,b,c){s(a,new H(c),b)}
function bj(a,b,c){a.splice(b,0,c)}
function ik(a,b){lh.call(this,a,b)}
function Vk(a,b){this.a=a;this.b=b}
function sl(a,b){this.a=a;this.b=b}
function ul(a,b){this.a=a;this.b=b}
function vl(a,b){this.a=a;this.b=b}
function wl(a,b){this.a=a;this.b=b}
function xl(a,b){this.a=a;this.b=b}
function im(a,b){this.a=a;this.b=b}
function lm(a,b){this.a=a;this.b=b}
function mm(a,b){this.a=a;this.b=b}
function Lm(a,b){this.a=a;this.b=b}
function mn(a,b){this.a=a;this.b=b}
function An(a,b){this.a=a;this.b=b}
function Bn(a,b){this.b=a;this.a=b}
function Wn(a,b){lh.call(this,a,b)}
function Bj(a,b){a.href=b;return a}
function Ec(a){$wnd.clearTimeout(a)}
function qm(){this.a=sj((bm(),am))}
function fm(){this.a=sj((Vl(),Ul))}
function om(){this.a=sj((Zl(),Yl))}
function Jl(){this.a=sj((Nl(),Ml))}
function Kl(){this.a=sj((Rl(),Ql))}
function Em(a){Cm(a,(ib(a.b),a.e))}
function Vm(a){Wm(a,(ib(a.a),!a.d))}
function Rb(a){return !a.d?a:Rb(a.d)}
function Bh(a){return !a?null:a.V()}
function jd(a){return a==null?null:a}
function Ci(a){return a!=null?r(a):0}
function gd(a){return typeof a===co}
function Fc(){uc!=0&&(uc=0);wc=-1}
function Ph(a){a.a=Uc($d,fo,1,0,5,1)}
function Eh(a){a.a=new ii;a.b=new wi}
function lj(){lj=Pg;ij=new o;kj=new o}
function kb(a){this.c=new Yh;this.b=a}
function Fb(a){this.d=Di(a);this.b=100}
function gl(a){mb(a.b);R(a.c);cb(a.a)}
function bc(a,b){_b(a,b,false);hb(a.d)}
function cj(a,b){aj(b,0,a,0,b.length)}
function Lj(a,b){a.value=b;return a}
function Gj(a,b){a.onBlur=b;return a}
function Cj(a,b){a.onClick=b;return a}
function Hj(a,b){a.onChange=b;return a}
function Ej(a,b){a.checked=b;return a}
function ac(a,b){b.v(a);ed(b,9)&&b.r()}
function pj(a,b){for(var c in a){b(c)}}
function Zc(a,b,c){return {l:a,m:b,h:c}}
function B(a,b,c){return t(a,c,2048,b)}
function th(a,b){return a.charCodeAt(b)}
function ed(a,b){return a!=null&&cd(a,b)}
function wh(a){return !a?'null':''+a.a}
function hj(a){return a.$H||(a.$H=++gj)}
function X(a){return !(!!a&&1==(a.c&7))}
function hd(a){return typeof a==='string'}
function Ij(a,b){a.onKeyDown=b;return a}
function Dj(a){a.autoFocus=true;return a}
function _g(a){if(a.k!=null){return}ih(a)}
function rb(a){J();qb(a);ub(a,2,true)}
function T(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function ib(a){var b;Sb((J(),b=Nb,b),a)}
function nc(a,b){a.b=b;b!=null&&fj(b,oo,a)}
function ki(a,b){var c;c=a[so];c.call(a,b)}
function Pi(a,b){Ki.call(this,a);this.a=b}
function pc(a){this.c=a;mc(this);this.A()}
function ci(){this.a=new ii;this.b=new wi}
function P(){this.a=Uc($d,fo,1,100,5,1)}
function A(a,b,c){t(a,new G(b),c,null)}
function u(a,b){return new xb(Di(a),null,b)}
function fd(a){return typeof a==='boolean'}
function fj(b,c,d){try{b[c]=d}catch(a){}}
function $(a,b,c){Kb(Di(c));K(a.a[b],Di(c))}
function Ai(a,b){while(a.R()){$i(b,a.S())}}
function Fj(a,b){a.defaultValue=b;return a}
function Mj(a,b){a.onDoubleClick=b;return a}
function mc(a){a.d&&a.b!==no&&a.A();return a}
function In(a){W((ib(a.d),a.f))&&Kn(a,null)}
function un(a){A((J(),J(),I),new Cn(a),xo)}
function ll(a){A((J(),J(),I),new zl(a),xo)}
function Fm(a){A((J(),J(),I),new Mm(a),xo)}
function Ym(a){A((J(),J(),I),new _m(a),xo)}
function hn(a){return oh(S(a.e).a-S(a.a).a)}
function yc(a,b,c){return a.apply(b,c);var d}
function zi(a,b,c){this.a=a;this.b=b;this.c=c}
function Qh(a,b){a.a[a.a.length]=b;return true}
function eh(a){var b;b=dh(a);kh(a,b);return b}
function qh(){qh=Pg;ph=Uc(Wd,fo,30,256,0,1)}
function Wg(){Wg=Pg;Vg=$wnd.window.document}
function Oc(){Oc=Pg;var a;!Qc();a=new Rc;Nc=a}
function Eb(a){while(true){if(!Db(a)){break}}}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function Nk(a,b){A((J(),J(),I),new Vk(a,b),xo)}
function hl(a,b){A((J(),J(),I),new xl(a,b),xo)}
function jl(a,b){A((J(),J(),I),new vl(a,b),xo)}
function kl(a,b){A((J(),J(),I),new ul(a,b),xo)}
function nl(a,b){A((J(),J(),I),new sl(a,b),xo)}
function dn(a,b){A((J(),J(),I),new mn(a,b),xo)}
function xn(a,b){A((J(),J(),I),new Bn(a,b),xo)}
function yn(a,b){A((J(),J(),I),new An(a,b),xo)}
function fn(a){rh(new Mh(a.g),new cc(a));Eh(a.g)}
function F(){this.f=new bb;this.a=new Fb(this.f)}
function nn(a,b){this.a=a;this.c=b;this.b=false}
function Ok(a,b){var c;c=b.target;Qk(a,c.value)}
function pb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function Lc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Uh(a,b){var c;c=a.a[b];dj(a.a,b);return c}
function Jh(a){var b;b=a.a.S();a.b=Ih(a);return b}
function Si(a,b,c){if(a.a.$(c)){a.b=true;b.u(c)}}
function Gb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Gi(a){if(!a.d){a.d=a.b.L();a.c=a.b.N()}}
function ok(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function zk(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function dl(a){if(0==a.e){a.e=1;a.j.forceUpdate()}}
function oj(){if(jj==256){ij=kj;kj=new o;jj=0}++jj}
function Ni(a){Ji(a);return new Pi(a,new Vi(a.a))}
function sk(a){return B((J(),J(),I),a.b,new xk(a))}
function Bk(a){return B((J(),J(),I),a.a,new Fk(a))}
function Pk(a){return B((J(),J(),I),a.a,new Tk(a))}
function Dl(a){return B((J(),J(),I),a.a,new Hl(a))}
function ml(a){return B((J(),J(),I),a.b,new rl(a))}
function gn(a){return Zg(),0==S(a.e).a?true:false}
function Dn(a){return uh(Eo,a)||uh(zo,a)||uh('',a)}
function Wc(a){return Array.isArray(a)&&a.hb===Tg}
function dd(a){return !Array.isArray(a)&&a.hb===Tg}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function si(a,b){return !(a.a.get(b)===undefined)}
function Gh(a,b){if(b){return Ah(a.a,b)}return false}
function Di(a){if(a==null){throw Ag(new sh)}return a}
function Vi(a){Fi.call(this,a.Y(),a.X()&-6);this.a=a}
function bn(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function Fn(a){mb(a.e);mb(a.a);R(a.b);R(a.c);cb(a.d)}
function Ii(a){if(!a.b){Ji(a);a.c=true}else{Ii(a.b)}}
function Mi(a,b){Ji(a);return new Pi(a,new Ti(b,a.a))}
function Cm(a,b){A((J(),J(),I),new Lm(a,b),75497472)}
function Wm(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function ol(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function Qk(a,b){var c;c=a.e;if(b!=c){a.e=b;hb(a.b)}}
function Gm(a,b){var c;c=a.e;if(b!=c){a.e=Di(b);hb(a.b)}}
function fh(a,b){var c;c=dh(a);kh(a,c);c.e=b?8:0;return c}
function Wh(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Kj(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Fi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Hi(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Ki(a){if(!a){this.b=null;new Yh}else{this.b=a}}
function Fg(a){if(gd(a)){return a|0}return a.l|a.m<<22}
function hh(a){if(a.J()){return null}var b=a.j;return Lg[b]}
function bi(a,b){return jd(a)===jd(b)||a!=null&&p(a,b)}
function cn(a,b){return t((J(),J(),I),new nn(a,b),xo,null)}
function Xn(){Vn();return Yc(Sc(og,1),fo,32,0,[Sn,Un,Tn])}
function wm(a){Xg((Wg(),$wnd.window.window),Bo,a.d,false)}
function xm(a){Yg((Wg(),$wnd.window.window),Bo,a.d,false)}
function Dc(a){xc();$wnd.setTimeout(function(){throw a},0)}
function Am(a){var b;T(a.a);b=S(a.a);uh(a.f,b)&&Gm(a,b)}
function nb(a){C((J(),J(),I),a);0==(a.f.a&ko)&&D((null,I))}
function Ob(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);qb(a.e)}}
function Xk(a,b){var c;if(S(a.c)){c=b.target;ol(a,c.value)}}
function vn(a,b){var c;Oi(en(a.b),(c=new Yh,c)).K(new _n(b))}
function um(){um=Pg;rm=new jn;sm=new zn(rm);tm=new Ln(rm)}
function bm(){bm=Pg;var a;am=(a=Qg(_l.prototype.eb,_l,[]),a)}
function Nl(){Nl=Pg;var a;Ml=(a=Qg(Ll.prototype.eb,Ll,[]),a)}
function Rl(){Rl=Pg;var a;Ql=(a=Qg(Pl.prototype.eb,Pl,[]),a)}
function Vl(){Vl=Pg;var a;Ul=(a=Qg(Tl.prototype.eb,Tl,[]),a)}
function Zl(){Zl=Pg;var a;Yl=(a=Qg(Xl.prototype.eb,Xl,[]),a)}
function Rg(a){function b(){}
;b.prototype=a||{};return new b}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function rh(a,b){var c,d;for(d=a.L();d.R();){c=d.S();b.u(c)}}
function gh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.D(b))}
function ei(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function fi(a,b){var c;return di(b,ei(a,b==null?0:(c=r(b),c|0)))}
function en(a){ib(a.d);return new Pi(null,new Hi(new Mh(a.g),0))}
function Ji(a){if(a.b){Ji(a.b)}else if(a.c){throw Ag(new mh)}}
function ic(a){gc(a.g);!!a.e&&hc(a);V(a.a);V(a.c);gc(a.b);gc(a.f)}
function Zh(a){Ph(this);cj(this.a,zh(a,Uc($d,fo,1,Fh(a.a),5,1)))}
function $k(a,b){Kn((um(),tm),b);A((J(),J(),I),new sl(a,b),xo)}
function ym(a,b){b.preventDefault();A((J(),J(),I),new Nm(a),xo)}
function Xg(a,b,c,d){a.addEventListener(b,c,(Zg(),d?true:false))}
function Yg(a,b,c,d){a.removeEventListener(b,c,(Zg(),d?true:false))}
function Bc(a,b,c){var d;d=zc();try{return yc(a,b,c)}finally{Cc(d)}}
function Ng(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function xj(a,b,c){!uh(c,'key')&&!uh(c,'ref')&&(a[c]=b[c],undefined)}
function Ti(a,b){Fi.call(this,b.Y(),b.X()&-16449);this.a=a;this.c=b}
function ji(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Ol(a){$wnd.React.Component.call(this,a);this.a=new tk(this)}
function Sl(a){$wnd.React.Component.call(this,a);this.a=new Ck(this)}
function Wl(a){$wnd.React.Component.call(this,a);this.a=new Rk(this)}
function $l(a){$wnd.React.Component.call(this,a);this.a=new pl(this)}
function cm(a){$wnd.React.Component.call(this,a);this.a=new El(this)}
function Jj(a){a.placeholder='What needs to be done?';return a}
function oc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function il(a){return Zg(),Gn((um(),tm))==a.j.props['a']?true:false}
function zn(a){this.b=Di(a);J();this.a=new kc(0,null,null,true,false)}
function xi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Kn(a,b){var c;c=a.f;if(!(b==c||!!b&&Sm(b,c))){a.f=b;hb(a.d)}}
function eb(a,b){var c,d;Qh(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Dh(a,b){return hd(b)?b==null?hi(a.a,null):vi(a.b,b):hi(a.a,b)}
function En(a,b){return (Vn(),Tn)==a||(Sn==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function kd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Cc(a){a&&Jc((Hc(),Gc));--uc;if(a){if(wc!=-1){Ec(wc);wc=-1}}}
function Lb(b){try{b.b.t()}catch(a){a=zg(a);if(!ed(a,5))throw Ag(a)}}
function wn(a){var b;Oi(Mi(en(a.b),new Zn),(b=new Yh,b)).K(new $n(a.b))}
function Li(a){var b;Ii(a);b=0;while(a.a.Z(new Zi)){b=Bg(b,1)}return b}
function Oi(a,b){var c;Ii(a);c=new Yi;c.a=b;a.a.Q(new _i(c));return c.a}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Th(a,b,c){for(;c<a.a.length;++c){if(bi(b,a.a[c])){return c}}return -1}
function yi(a){if(a.a.c!=a.c){return ti(a.a,a.b.value[0])}return a.b.value[1]}
function tc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ac(b){xc();return function(){return Bc(b,this,arguments);var a}}
function Sm(a,b){var c;if(ed(b,44)){c=b;return a.c.d==c.c.d}else{return false}}
function Vh(a,b){var c;c=Th(a,b,0);if(c==-1){return false}dj(a.a,c);return true}
function Uc(a,b,c,d,e,f){var g;g=Vc(e,d);e!=10&&Yc(Sc(a,f),b,c,e,g);return g}
function Rh(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.u(c)}}
function Hn(a){var b,c;return b=S(a.b),Oi(Mi(en(a.j),new ao(b)),(c=new Yh,c))}
function vm(a,b){a.f=b;uh(b,S(a.a))&&Gm(a,b);zm(b);A((J(),J(),I),new Nm(a),xo)}
function nm(a,b){rj(a.a,wh(b?oh(b.c.d):null));Di(b);a.a.props['a']=b;return a.a}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||mb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new lb(a)),0,null);!!a.b&&mb(a.b)}}
function fc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new lc(a)),67108864,null)}}
function Hk(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Uk(a),xo)}}
function Gk(a){var b;b=vh((ib(a.b),a.e));if(b.length>0){sn((um(),sm),b);Qk(a,'')}}
function Jc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Mc(b,c)}while(a.b);a.b=c}}
function Ic(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Mc(b,c)}while(a.a);a.a=c}}
function Ch(a,b,c){return hd(b)?b==null?gi(a.a,null,c):ui(a.b,b,c):gi(a.a,b,c)}
function ej(a,b){return Tc(b)!=10&&Yc(q(b),b.gb,b.__elementTypeId$,Tc(b),a),a}
function Tc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function vj(a){var b;return tj($wnd.React.StrictMode,null,null,(b={},b[to]=Di(a),b))}
function dh(a){var b;b=new bh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Qg(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function kh(a,b){var c;if(!a){return}b.j=a;var d=hh(b);if(!d){Lg[a]=[b];return}d.fb=b}
function zg(a){var b;if(ed(a,5)){return a}b=a&&a[oo];if(!b){b=new sc(a);Pc(b)}return b}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Qh((!a.b&&(a.b=new Yh),a.b),b)}}}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new Yh);a.c=c.c}b.d=true;Qh(a.c,Di(b))}
function vi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{ki(a.a,b);--a.b}return c}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Di(b))}
function Kh(a){this.d=a;this.c=new xi(this.d.b);this.a=this.c;this.b=Ih(this)}
function bb(){var a;this.a=Uc(od,fo,42,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function tb(b){if(b){try{b.t()}catch(a){a=zg(a);if(ed(a,5)){J()}else throw Ag(a)}}}
function mh(){pc.call(this,"Stream already terminated, can't be modified or used")}
function Hg(){Ig();var a=Gg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function qb(a){var b,c;for(c=new $h(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function _h(a){var b,c,d;d=0;for(c=new Kh(a.a);c.b;){b=Jh(c);d=d+(b?r(b):0);d=d|0}return d}
function yh(a,b){var c,d;for(d=new Kh(b.a);d.b;){c=Jh(d);if(!Gh(a,c)){return false}}return true}
function an(a,b,c){var d;d=new Zm(b,c);Rm(d,a,new dc(a,d));Ch(a.g,oh(d.c.d),d);hb(a.d);return d}
function tj(a,b,c,d){var e;e=uj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Di(d);return e}
function sj(a){var b;b=uj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Cg(a){var b;b=a.h;if(b==0){return a.l+a.m*lo}if(b==1048575){return a.l+a.m*lo-qo}return a}
function Ih(a){if(a.a.R()){return true}if(a.a!=a.c){return false}a.a=new ji(a.d.a);return a.a.R()}
function Eg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=qo;d=1048575}c=kd(e/lo);b=kd(e-c*lo);return Zc(b,c,d)}
function di(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(bi(a,c.U())){return c}}return null}
function _b(a,b,c){var d;d=Dh(a.g,b?oh(b.c.d):null);if(null!=d){jc(b.c,a);c&&!!b&&fc(b.c);hb(a.d)}}
function ui(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Yc(a,b,c,d,e){e.fb=a;e.gb=b;e.hb=Tg;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function S(a){ib(a.e);vb(a.f)&&ob(a.f);if(a.b){if(ed(a.b,8)){throw Ag(a.b)}else{throw Ag(a.b)}}return a.k}
function sc(a){rc();mc(this);this.b=a;a!=null&&fj(a,oo,this);this.c=a==null?'null':Sg(a);this.a=a}
function bh(){this.g=$g++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Mb(a,b){this.b=Di(a);this.a=b|0|(0==(b&6291456)?lo:0)|(0!=(b&229376)?0:98304)}
function xb(a,b,c){wb.call(this,null,a,b,c|(!a?262144:ho)|(0==(c&6291456)?!a?ko:lo:0)|0|0|0)}
function Zk(a,b,c){27==c.which?A((J(),J(),I),new wl(a,b),xo):13==c.which&&A((J(),J(),I),new ul(a,b),xo)}
function mb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Bb(a)),67108864,null);!!a.a&&R(a.a);Ib(a.f);a.c=a.c&-8|1}}
function lk(){if(!kk){kk=(++(J(),J(),I).e,new Hb);$wnd.Promise.resolve(null).then(Qg(mk.prototype.C,mk,[]))}}
function Ug(){um();$wnd.ReactDOM.render(vj([(new qm).a]),(Wg(),Vg).getElementById('app'),null)}
function Vn(){Vn=Pg;Sn=new Wn('ACTIVE',0);Un=new Wn('COMPLETED',1);Tn=new Wn('ALL',2)}
function Kg(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Jn(a){var b;b=S(a.i.a);uh(Eo,b)||uh(zo,b)||uh('',b)?Cm(a.i,b):Dn(Dm(a.i))?Fm(a.i):Cm(a.i,'')}
function _k(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){xn((um(),b),c);Kn(tm,null);ol(a,c)}else{dn((um(),rm),b)}}
function fb(a,b){var c,d;d=a.c;Vh(d,b);!!a.b&&ho!=(a.b.c&io)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function $c(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return Zc(c&4194303,d&4194303,e&1048575)}
function Bg(a,b){var c;if(gd(a)&&gd(b)){c=a+b;if(-17592186044416<c&&c<qo){return c}}return Cg($c(gd(a)?Eg(a):a,gd(b)?Eg(b):b))}
function oh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(qh(),ph)[b];!c&&(c=ph[b]=new nh(a));return c}return new nh(a)}
function Sg(a){var b;if(Array.isArray(a)&&a.hb===Tg){return ah(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function nj(a){lj();var b,c,d;c=':'+a;d=kj[c];if(d!=null){return kd(d)}d=ij[c];b=d==null?mj(a):kd(d);oj();kj[c]=b;return b}
function ai(a){var b,c,d;d=1;for(c=new $h(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=Uh(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function al(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;nl(a,a.j.props['a']);a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&ho)?Lb(a):a.b.t();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function q(a){return hd(a)?ae:gd(a)?Sd:fd(a)?Qd:dd(a)?a.fb:Wc(a)?a.fb:a.fb||Array.isArray(a)&&Sc(Kd,1)||Kd}
function r(a){return hd(a)?nj(a):gd(a)?kd(a):fd(a)?a?1231:1237:dd(a)?a.p():Wc(a)?hj(a):!!a&&!!a.hashCode?a.hashCode():hj(a)}
function p(a,b){return hd(a)?uh(a,b):gd(a)?a===b:fd(a)?a===b:dd(a)?a.n(b):Wc(a)?a===b:!!a&&!!a.equals?a.equals(b):jd(a)===jd(b)}
function yb(a,b){wb.call(this,a,new zb(a),null,b|(ho==(b&io)?0:524288)|(0==(b&6291456)?ho==(b&io)?lo:ko:0)|0|268435456|0)}
function jk(){hk();return Yc(Sc(Me,1),fo,7,0,[Nj,Oj,Pj,Qj,Rj,Sj,Tj,Uj,Vj,Wj,Xj,Yj,Zj,$j,_j,ak,bk,ck,dk,ek,fk,gk])}
function Ck(a){var b;this.j=Di(a);J();b=++Ak;this.b=new kc(b,null,new Dk(this),false,false);this.a=new xb(null,Di(new Ek(this)),wo)}
function El(a){var b;this.j=Di(a);J();b=++Cl;this.b=new kc(b,null,new Fl(this),false,false);this.a=new xb(null,Di(new Gl(this)),wo)}
function U(a,b,c,d){this.c=Di(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new yb(this,d);this.e=new kb(this.f);ho==(d&io)&&nb(this.f)}
function kc(a,b,c,d,e){var f;this.d=a;this.e=d?new ci:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new kb((J(),null)),f):null;this.c=null}
function jh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Xh(a,b){var c,d;d=a.a.length;b.length<d&&(b=ej(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function zh(a,b){var c,d,e;e=Fh(a.a);b.length<e&&(b=ej(new Array(e),b));d=new Kh(a.a);for(c=0;c<e;++c){b[c]=Jh(d)}b.length>e&&(b[e]=null);return b}
function zj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function zc(){var a;if(uc!=0){a=tc();if(a-vc>2000){vc=a;wc=$wnd.setTimeout(Fc,10)}}if(uc++==0){Ic((Hc(),Gc));return true}return false}
function Qc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function hc(a){var b,c,d;for(c=new $h(new Zh(new Hh(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.U();ed(d,9)&&d.s()||b.V().t()}}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new $h(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Wb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new $h(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&ub(b,6,true)}}}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new $h(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function cd(a,b){if(hd(a)){return !!bd[b]}else if(a.gb){return !!a.gb[b]}else if(gd(a)){return !!ad[b]}else if(fd(a)){return !!_c[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function vh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Vc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{Zb(b,d);try{f=(c.a.t(),null)}finally{$b()}return f}catch(a){a=zg(a);if(ed(a,5)){e=a;throw Ag(e)}else throw Ag(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.q()}else{Zb(b,e);try{g=c.q()}finally{$b()}}return g}catch(a){a=zg(a);if(ed(a,5)){f=a;throw Ag(f)}else throw Ag(a)}finally{D(b)}}
function Zm(a,b){var c,d,e;this.e=Di(a);this.d=b;J();c=++Pm;this.c=new kc(c,null,new $m(this),true,true);this.b=(e=new kb(null),e);this.a=(d=new kb(null),d)}
function Rk(a){var b,c;this.j=Di(a);J();b=++Lk;this.c=new kc(b,null,new Sk(this),false,false);this.b=(c=new kb(null),c);this.a=new xb(null,Di(new Wk(this)),wo)}
function tk(a){var b;this.j=Di(a);J();b=++qk;this.c=new kc(b,null,new uk(this),false,false);this.a=new U(new vk,null,null,136478720);this.b=new xb(null,Di(new wk(this)),wo)}
function Db(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Jb(c);return true}
function Jg(b,c,d,e){Ig();var f=Gg;$moduleName=c;$moduleBase=d;yg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{bo(g)()}catch(a){b(c,a)}}else{bo(g)()}}
function uj(a,b){var c;c=new $wnd.Object;c.$$typeof=Di(a);c.type=Di(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function pi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return qi()}}
function Mg(){Lg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Mc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].ib()&&(c=Lc(c,g)):g[0].ib()}catch(a){a=zg(a);if(ed(a,5)){d=a;xc();Dc(ed(d,34)?d.B():d)}else throw Ag(a)}}return c}
function Kk(a){var b;a.d=0;lk();b=wj(yo,Dj(Hj(Ij(Lj(Jj(zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,['new-todo']))),(ib(a.b),a.e)),Qg(dm.prototype.cb,dm,[a])),Qg(em.prototype.bb,em,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.q();if(!(jd(e)===jd(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=zg(a);if(ed(a,10)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Ag(c)}else throw Ag(a)}}
function gi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=di(b,e);if(f){return f.W(c)}}e[e.length]=new Oh(b,c);++a.b;return null}
function aj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function mj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+th(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Uc($d,fo,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function ob(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.t()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=zg(a);if(ed(a,5)){J()}else throw Ag(a)}}}
function zm(a){var b;if(0==a.length){b=(Wg(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Vg.title,b)}else{(Wg(),$wnd.window.window).location.hash=a}}
function wb(a,b,c,d){this.b=new Yh;this.f=new Mb(new Ab(this),d&6520832|262144|ho);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&ko)&&D((null,I)))}
function hi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(bi(b,e.U())){if(d.length==1){d.length=0;ki(a.a,g)}else{d.splice(h,1)}--a.b;return e.V()}}return null}
function pl(a){var b,c;this.j=Di(a);J();b=++fl;this.d=new kc(b,null,new ql(this),false,false);this.a=(c=new kb(null),c);this.c=new U(new tl(this),null,null,136478720);this.b=new xb(null,Di(new yl(this)),wo);nl(this,this.j.props['a'])}
function Og(a,b,c){var d=Lg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Lg[b]),Rg(h));_.gb=c;!b&&(_.hb=Tg);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.fb=f)}
function ih(a){if(a.I()){var b=a.c;b.J()?(a.k='['+b.j):!b.I()?(a.k='[L'+b.G()+';'):(a.k='['+b.G());a.b=b.F()+'[]';a.i=b.H()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=jh('.',[c,jh('$',d)]);a.b=jh('.',[c,jh('.',d)]);a.i=d[d.length-1]}
function Ah(a,b){var c,d,e;c=b.U();e=b.V();d=hd(c)?c==null?Bh(fi(a.a,null)):ti(a.b,c):Bh(fi(a.a,c));if(!(jd(e)===jd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(hd(c)?c==null?!!fi(a.a,null):si(a.b,c):!!fi(a.a,c))){return false}return true}
function wj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;qj(b,Qg(yj.prototype._,yj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[to]=c[0],undefined):(d[to]=c,undefined));return tj(a,e,f,d)}
function Hm(){var a,b;this.d=new Rn(this);this.f=this.e=(b=(Wg(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new kc(0,null,new Im(this),true,false);this.b=(a=new kb(null),a);this.a=new U(new Om,new Jm(this),new Km(this),35749888)}
function jn(){var a;this.g=new ci;J();this.f=new kc(0,new ln(this),new kn(this),true,false);this.d=(a=new kb(null),a);this.c=new U(new on(this),null,null,Do);this.e=new U(new pn(this),null,null,Do);this.a=new U(new qn(this),null,null,Do);this.b=new U(new rn(this),null,null,Do)}
function Ln(a){var b;this.j=Di(a);this.i=new Hm;J();this.g=new kc(0,null,new Mn(this),true,false);this.d=(b=new kb(null),b);this.b=new U(new Nn(this),null,null,Do);this.c=new U(new On(this),null,null,Do);this.e=u(new Pn(this),413138944);this.a=u(new Qn(this),681574400);D((null,I))}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new $h(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=zg(a);if(!ed(a,5))throw Ag(a)}if(6==(b.c&7)){return true}}}}}qb(b);return false}
function oi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ub(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){jb(a.a.e);tb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;tb((e=d.i,e));d.k=null}Rh(a.b,new Cb(a));a.b.a=Uc($d,fo,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&tb((f=a.a.g,f))}}
function hk(){hk=Pg;Nj=new ik(uo,0);Oj=new ik('checkbox',1);Pj=new ik('color',2);Qj=new ik('date',3);Rj=new ik('datetime',4);Sj=new ik('email',5);Tj=new ik('file',6);Uj=new ik('hidden',7);Vj=new ik('image',8);Wj=new ik('month',9);Xj=new ik(co,10);Yj=new ik('password',11);Zj=new ik('radio',12);$j=new ik('range',13);_j=new ik('reset',14);ak=new ik('search',15);bk=new ik('submit',16);ck=new ik('tel',17);dk=new ik('text',18);ek=new ik('time',19);fk=new ik('url',20);gk=new ik('week',21)}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Sh(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Wh(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Sh(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Uh(a.b,g)}e&&sb(a.e,a.b)}else{e&&sb(a.e,new Yh)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&ho!=(k.b.c&io)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function pk(a){var b,c;a.d=0;lk();c=(b=S((um(),tm).b),wj('footer',zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,['footer'])),[(new Kl).a,wj('ul',zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,['filters'])),[wj('li',null,[wj('a',Bj(zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,[(Vn(),Tn)==b?vo:null])),'#'),['All'])]),wj('li',null,[wj('a',Bj(zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,[Sn==b?vo:null])),'#active'),['Active'])]),wj('li',null,[wj('a',Bj(zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,[Un==b?vo:null])),'#completed'),['Completed'])])]),S(a.a)?wj(uo,Cj(zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,['clear-completed'])),Qg(Il.prototype.db,Il,[])),['Clear Completed']):null]));return c}
function el(a){var b,c,d,e;a.e=0;lk();b=a.j.props['a'];if(b.c.i<0){return null}c=(d=a.j.props['a'],e=(ib(d.a),d.d),wj('li',zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,[e?zo:null,S(a.c)?'editing':null])),[wj('div',zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,['view'])),[wj(yo,Hj(Ej(Kj(zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,['toggle'])),(hk(),Oj)),e),Qg(hm.prototype.bb,hm,[d])),null),wj('label',Mj(new $wnd.Object,Qg(im.prototype.db,im,[a,d])),[(ib(d.b),d.e)]),wj(uo,Cj(zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,['destroy'])),Qg(jm.prototype.db,jm,[d])),null)]),wj(yo,Ij(Hj(Gj(Fj(zj(Aj(new $wnd.Object,Qg(km.prototype.u,km,[a])),Yc(Sc(ae,1),fo,2,6,['edit'])),(ib(a.a),a.g)),Qg(lm.prototype.ab,lm,[a,d])),Qg(gm.prototype.bb,gm,[a])),Qg(mm.prototype.cb,mm,[a,d])),null)]));return c}
function qi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[so]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!oi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[so]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var co='number',eo={13:1},fo={3:1,4:1},go={9:1},ho=1048576,io=1835008,jo={6:1},ko=2097152,lo=4194304,mo={20:1},no='__noinit__',oo='__java$exception',po={3:1,10:1,8:1,5:1},qo=17592186044416,ro={39:1},so='delete',to='children',uo='button',vo='selected',wo=1411518464,xo=142606336,yo='input',zo='completed',Ao='header',Bo='hashchange',Co={9:1,46:1},Do=136413184,Eo='active';var _,Lg,Gg,yg=-1;Mg();Og(1,null,{},o);_.n=Go;_.o=function(){return this.fb};_.p=Ho;_.equals=function(a){return this.n(a)};_.hashCode=function(){return this.p()};var _c,ad,bd;Og(48,1,{},bh);_.D=function(a){var b;b=new bh;b.e=4;a>1?(b.c=gh(this,a-1)):(b.c=this);return b};_.F=function(){_g(this);return this.b};_.G=function(){return ah(this)};_.H=function(){_g(this);return this.i};_.I=function(){return (this.e&4)!=0};_.J=function(){return (this.e&1)!=0};_.e=0;_.g=0;var $g=1;var $d=eh(1);var Rd=eh(48);Og(76,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var nd=eh(76);Og(35,1,eo,G);_.q=function(){return this.a.t(),null};var ld=eh(35);Og(77,1,{},H);var md=eh(77);var I;Og(42,1,{42:1},P);_.b=0;_.c=false;_.d=0;var od=eh(42);Og(205,1,go);var rd=eh(205);Og(18,205,go,U);_.r=function(){R(this)};_.s=Fo;_.a=false;_.d=0;var pd=eh(18);Og(130,1,{234:1},bb);var qd=eh(130);Og(15,205,{9:1,15:1},kb);_.r=function(){cb(this)};_.s=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var td=eh(15);Og(110,1,jo,lb);_.t=function(){db(this.a)};var sd=eh(110);Og(16,205,{9:1,16:1},xb,yb);_.r=function(){mb(this)};_.s=function(){return 1==(this.c&7)};_.c=0;var yd=eh(16);Og(111,1,mo,zb);_.t=function(){Q(this.a)};var ud=eh(111);Og(112,1,jo,Ab);_.t=function(){ob(this.a)};var vd=eh(112);Og(113,1,jo,Bb);_.t=function(){rb(this.a)};var wd=eh(113);Og(114,1,{},Cb);_.u=function(a){pb(this.a,a)};var xd=eh(114);Og(129,1,{},Fb);_.a=0;_.b=0;_.c=0;var zd=eh(129);Og(150,1,go,Hb);_.r=function(){Gb(this)};_.s=Fo;_.a=false;var Ad=eh(150);Og(58,205,{9:1,58:1},Mb);_.r=function(){Ib(this)};_.s=function(){return 2==(3&this.a)};_.a=0;var Bd=eh(58);Og(132,1,{},Yb);_.a=0;var Nb;var Cd=eh(132);Og(98,1,{});var Fd=eh(98);Og(78,1,{},cc);_.u=function(a){ac(this.a,a)};var Dd=eh(78);Og(79,1,jo,dc);_.t=function(){bc(this.a,this.b)};var Ed=eh(79);Og(99,98,{});var Gd=eh(99);Og(14,1,go,kc);_.r=function(){fc(this)};_.s=function(){return this.i<0};_.d=0;_.i=0;var Id=eh(14);Og(109,1,jo,lc);_.t=function(){ic(this.a)};var Hd=eh(109);Og(5,1,{3:1,5:1});_.w=function(a){return new Error(a)};_.A=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=ah(this.fb),c==null?a:a+': '+c);nc(this,oc(this.w(b)));Pc(this)};_.b=no;_.d=true;var be=eh(5);Og(10,5,{3:1,10:1,5:1});var Ud=eh(10);Og(8,10,po);var _d=eh(8);Og(49,8,po);var Xd=eh(49);Og(70,49,po);var Md=eh(70);Og(34,70,{34:1,3:1,10:1,8:1,5:1},sc);_.B=function(){return jd(this.a)===jd(qc)?null:this.a};var qc;var Jd=eh(34);var Kd=eh(0);Og(191,1,{});var Ld=eh(191);var uc=0,vc=0,wc=-1;Og(97,191,{},Kc);var Gc;var Nd=eh(97);var Nc;Og(202,1,{});var Pd=eh(202);Og(71,202,{},Rc);var Od=eh(71);var Vg;_c={3:1,66:1,29:1};var Qd=eh(66);Og(40,1,{3:1,40:1});var Zd=eh(40);ad={3:1,29:1,40:1};var Sd=eh(201);Og(31,1,{3:1,29:1,31:1});_.n=Go;_.p=Ho;_.b=0;var Td=eh(31);Og(72,8,po,mh);var Vd=eh(72);Og(30,40,{3:1,29:1,30:1,40:1},nh);_.n=function(a){return ed(a,30)&&a.a==this.a};_.p=Fo;_.a=0;var Wd=eh(30);var ph;Og(266,1,{});Og(74,49,po,sh);_.w=function(a){return new TypeError(a)};var Yd=eh(74);bd={3:1,65:1,29:1,2:1};var ae=eh(2);Og(270,1,{});Og(51,8,po,xh);var ce=eh(51);Og(203,1,{38:1});_.K=Lo;_.O=function(){return new Hi(this,0)};_.P=function(){return new Pi(null,this.O())};_.M=function(a){throw Ag(new xh('Add not supported on this collection'))};var de=eh(203);Og(206,1,{189:1});_.n=function(a){var b,c,d;if(a===this){return true}if(!ed(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Kh((new Hh(d)).a);c.b;){b=Jh(c);if(!Ah(this,b)){return false}}return true};_.p=function(){return _h(new Hh(this))};var oe=eh(206);Og(115,206,{189:1});var ge=eh(115);Og(207,203,{38:1,217:1});_.O=function(){return new Hi(this,1)};_.n=function(a){var b;if(a===this){return true}if(!ed(a,22)){return false}b=a;if(Fh(b.a)!=this.N()){return false}return yh(this,b)};_.p=function(){return _h(this)};var pe=eh(207);Og(22,207,{22:1,38:1,217:1},Hh);_.L=function(){return new Kh(this.a)};_.N=Jo;var fe=eh(22);Og(23,1,{},Kh);_.Q=Io;_.S=function(){return Jh(this)};_.R=Ko;_.b=false;var ee=eh(23);Og(204,203,{38:1,215:1});_.O=function(){return new Hi(this,16)};_.T=function(a,b){throw Ag(new xh('Add not supported on this list'))};_.M=function(a){this.T(this.N(),a);return true};_.n=function(a){var b,c,d,e,f;if(a===this){return true}if(!ed(a,12)){return false}f=a;if(this.N()!=f.a.length){return false}e=new $h(f);for(c=new $h(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(jd(b)===jd(d)||b!=null&&p(b,d))){return false}}return true};_.p=function(){return ai(this)};_.L=function(){return new Lh(this)};var ie=eh(204);Og(96,1,{},Lh);_.Q=Io;_.R=function(){return this.a<this.b.a.length};_.S=function(){return Sh(this.b,this.a++)};_.a=0;var he=eh(96);Og(52,203,{38:1},Mh);_.L=function(){var a;a=new Kh((new Hh(this.a)).a);return new Nh(a)};_.N=Jo;var ke=eh(52);Og(118,1,{},Nh);_.Q=Io;_.R=function(){return this.a.b};_.S=function(){var a;a=Jh(this.a);return a.V()};var je=eh(118);Og(116,1,ro);_.n=function(a){var b;if(!ed(a,39)){return false}b=a;return bi(this.a,b.U())&&bi(this.b,b.V())};_.U=Fo;_.V=Ko;_.p=function(){return Ci(this.a)^Ci(this.b)};_.W=function(a){var b;b=this.b;this.b=a;return b};var le=eh(116);Og(117,116,ro,Oh);var me=eh(117);Og(208,1,ro);_.n=function(a){var b;if(!ed(a,39)){return false}b=a;return bi(this.b.value[0],b.U())&&bi(yi(this),b.V())};_.p=function(){return Ci(this.b.value[0])^Ci(yi(this))};var ne=eh(208);Og(12,204,{3:1,12:1,38:1,215:1},Yh,Zh);_.T=function(a,b){bj(this.a,a,b)};_.M=function(a){return Qh(this,a)};_.K=function(a){Rh(this,a)};_.L=function(){return new $h(this)};_.N=function(){return this.a.length};var re=eh(12);Og(17,1,{},$h);_.Q=Io;_.R=function(){return this.a<this.c.a.length};_.S=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var qe=eh(17);Og(36,115,{3:1,36:1,189:1},ci);var se=eh(36);Og(56,1,{},ii);_.K=Lo;_.L=function(){return new ji(this)};_.b=0;var ue=eh(56);Og(57,1,{},ji);_.Q=Io;_.S=function(){return this.d=this.a[this.c++],this.d};_.R=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var te=eh(57);var mi;Og(54,1,{},wi);_.K=Lo;_.L=function(){return new xi(this)};_.b=0;_.c=0;var xe=eh(54);Og(55,1,{},xi);_.Q=Io;_.S=function(){return this.c=this.a,this.a=this.b.next(),new zi(this.d,this.c,this.d.c)};_.R=function(){return !this.a.done};var ve=eh(55);Og(131,208,ro,zi);_.U=function(){return this.b.value[0]};_.V=function(){return yi(this)};_.W=function(a){return ui(this.a,this.b.value[0],a)};_.c=0;var we=eh(131);Og(134,1,{});_.Q=function(a){Ei(this,a)};_.X=function(){return this.d};_.Y=function(){return this.e};_.d=0;_.e=0;var ze=eh(134);Og(59,134,{});var ye=eh(59);Og(24,1,{},Hi);_.X=Fo;_.Y=function(){Gi(this);return this.c};_.Q=function(a){Gi(this);this.d.Q(a)};_.Z=function(a){Gi(this);if(this.d.R()){a.u(this.d.S());return true}return false};_.a=0;_.c=0;var Ae=eh(24);Og(133,1,{});_.c=false;var Je=eh(133);Og(26,133,{235:1,26:1},Pi);var Ie=eh(26);Og(136,59,{},Ti);_.Z=function(a){this.b=false;while(!this.b&&this.c.Z(new Ui(this,a)));return this.b};_.b=false;var Ce=eh(136);Og(139,1,{},Ui);_.u=function(a){Si(this.a,this.b,a)};var Be=eh(139);Og(135,59,{},Vi);_.Z=function(a){return this.a.Z(new Wi(a))};var Ee=eh(135);Og(138,1,{},Wi);_.u=function(a){this.a.u(nm(new om,a))};var De=eh(138);Og(137,1,{},Yi);_.u=function(a){Xi(this,a)};var Fe=eh(137);Og(140,1,{},Zi);_.u=function(a){};var Ge=eh(140);Og(141,1,{},_i);_.u=function(a){$i(this,a)};var He=eh(141);Og(268,1,{});Og(211,1,{});var Ke=eh(211);Og(265,1,{});var gj=0;var ij,jj=0,kj;Og(696,1,{});Og(709,1,{});Og(209,1,{});var Le=eh(209);Og(236,$wnd.Function,{},yj);_._=function(a){xj(this.a,this.b,a)};Og(7,31,{3:1,29:1,31:1,7:1},ik);var Nj,Oj,Pj,Qj,Rj,Sj,Tj,Uj,Vj,Wj,Xj,Yj,Zj,$j,_j,ak,bk,ck,dk,ek,fk,gk;var Me=fh(7,jk);var kk;Og(237,$wnd.Function,{},mk);_.C=function(a){return Gb(kk),kk=null,null};Og(212,209,{});var tf=eh(212);Og(163,212,{});_.d=0;var xf=eh(163);Og(164,163,go,tk);_.r=Mo;_.n=Go;_.p=Ho;_.s=No;var qk=0;var Ve=eh(164);Og(165,1,jo,uk);_.t=function(){rk(this.a)};var Ne=eh(165);Og(166,1,eo,vk);_.q=function(){return Zg(),S((um(),rm).b).a>0?true:false};var Oe=eh(166);Og(167,1,mo,wk);_.t=function(){ok(this.a)};var Pe=eh(167);Og(168,1,eo,xk);_.q=function(){return pk(this.a)};var Qe=eh(168);Og(214,209,{});var sf=eh(214);Og(183,214,{});_.c=0;var wf=eh(183);Og(184,183,go,Ck);_.r=Oo;_.n=Go;_.p=Ho;_.s=Po;var Ak=0;var Ue=eh(184);Og(185,1,jo,Dk);_.t=Qo;var Re=eh(185);Og(186,1,mo,Ek);_.t=function(){zk(this.a)};var Se=eh(186);Og(187,1,eo,Fk);_.q=function(){var a,b;return this.a.c=0,lk(),a=S((um(),rm).e).a,b='item'+(a==1?'':'s'),wj('span',zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,['todo-count'])),[wj('strong',null,[a]),' '+b+' left'])};var Te=eh(187);Og(155,209,{});_.e='';var Ff=eh(155);Og(156,155,{});_.d=0;var zf=eh(156);Og(157,156,go,Rk);_.r=Mo;_.n=Go;_.p=Ho;_.s=No;var Lk=0;var _e=eh(157);Og(158,1,jo,Sk);_.t=function(){Mk(this.a)};var We=eh(158);Og(160,1,eo,Tk);_.q=function(){return Kk(this.a)};var Xe=eh(160);Og(161,1,jo,Uk);_.t=function(){Gk(this.a)};var Ye=eh(161);Og(162,1,jo,Vk);_.t=function(){Ok(this.a,this.b)};var Ze=eh(162);Og(159,1,mo,Wk);_.t=function(){ok(this.a)};var $e=eh(159);Og(213,209,{});_.i=false;var Hf=eh(213);Og(170,213,{});_.e=0;var Bf=eh(170);Og(171,170,go,pl);_.r=function(){fc(this.d)};_.n=Go;_.p=Ho;_.s=function(){return this.d.i<0};var fl=0;var lf=eh(171);Og(172,1,jo,ql);_.t=function(){gl(this.a)};var af=eh(172);Og(175,1,eo,rl);_.q=function(){return el(this.a)};var bf=eh(175);Og(60,1,jo,sl);_.t=function(){ol(this.a,Dm(this.b))};var cf=eh(60);Og(173,1,eo,tl);_.q=function(){return il(this.a)};var df=eh(173);Og(61,1,jo,ul);_.t=function(){_k(this.a,this.b)};var ef=eh(61);Og(176,1,jo,vl);_.t=function(){$k(this.a,this.b)};var ff=eh(176);Og(177,1,jo,wl);_.t=function(){nl(this.a,this.b);Kn((um(),tm),null)};var gf=eh(177);Og(178,1,jo,xl);_.t=function(){Xk(this.a,this.b)};var hf=eh(178);Og(174,1,mo,yl);_.t=function(){dl(this.a)};var jf=eh(174);Og(179,1,jo,zl);_.t=function(){al(this.a)};var kf=eh(179);Og(210,209,{});var Jf=eh(210);Og(143,210,{});_.c=0;var Df=eh(143);Og(144,143,go,El);_.r=Oo;_.n=Go;_.p=Ho;_.s=Po;var Cl=0;var pf=eh(144);Og(145,1,jo,Fl);_.t=Qo;var mf=eh(145);Og(146,1,mo,Gl);_.t=function(){zk(this.a)};var nf=eh(146);Og(147,1,eo,Hl);_.q=function(){var a;return this.a.c=0,lk(),wj('div',null,[wj('div',null,[wj(Ao,zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,[Ao])),[wj('h1',null,['todos']),(new fm).a]),S((um(),rm).c)?null:wj('section',zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,[Ao])),[wj(yo,Hj(Kj(zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,['toggle-all'])),(hk(),Oj)),Qg(pm.prototype.bb,pm,[])),null),wj('ul',zj(new $wnd.Object,Yc(Sc(ae,1),fo,2,6,['todo-list'])),(a=Oi(Di(Ni(S(tm.c).P())),new Yh),Xh(a,Xc(a.a.length))))]),S(rm.c)?null:(new Jl).a])])};var of=eh(147);Og(241,$wnd.Function,{},Il);_.db=function(a){un((um(),sm))};Og(149,1,{},Jl);var qf=eh(149);Og(169,1,{},Kl);var rf=eh(169);Og(242,$wnd.Function,{},Ll);_.eb=function(a){return new Ol(a)};var Ml;Og(153,$wnd.React.Component,{},Ol);Ng(Lg[1],_);_.componentWillUnmount=function(){nk(this.a)};_.render=function(){return sk(this.a)};_.shouldComponentUpdate=Ro;var uf=eh(153);Og(252,$wnd.Function,{},Pl);_.eb=function(a){return new Sl(a)};var Ql;Og(180,$wnd.React.Component,{},Sl);Ng(Lg[1],_);_.componentWillUnmount=function(){yk(this.a)};_.render=function(){return Bk(this.a)};_.shouldComponentUpdate=So;var vf=eh(180);Og(240,$wnd.Function,{},Tl);_.eb=function(a){return new Wl(a)};var Ul;Og(151,$wnd.React.Component,{},Wl);Ng(Lg[1],_);_.componentWillUnmount=function(){nk(this.a)};_.render=function(){return Pk(this.a)};_.shouldComponentUpdate=Ro;var yf=eh(151);Og(243,$wnd.Function,{},Xl);_.eb=function(a){return new $l(a)};var Yl;Og(154,$wnd.React.Component,{},$l);Ng(Lg[1],_);_.componentDidUpdate=function(a){ll(this.a)};_.componentWillUnmount=function(){cl(this.a)};_.render=function(){return ml(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.e};var Af=eh(154);Og(233,$wnd.Function,{},_l);_.eb=function(a){return new cm(a)};var am;Og(120,$wnd.React.Component,{},cm);Ng(Lg[1],_);_.componentWillUnmount=function(){yk(this.a)};_.render=function(){return Dl(this.a)};_.shouldComponentUpdate=So;var Cf=eh(120);Og(238,$wnd.Function,{},dm);_.cb=function(a){Hk(this.a,a)};Og(239,$wnd.Function,{},em);_.bb=function(a){Nk(this.a,a)};Og(148,1,{},fm);var Ef=eh(148);Og(250,$wnd.Function,{},gm);_.bb=function(a){hl(this.a,a)};Og(244,$wnd.Function,{},hm);_.bb=function(a){Ym(this.a)};Og(246,$wnd.Function,{},im);_.db=function(a){jl(this.a,this.b)};Og(247,$wnd.Function,{},jm);_.db=function(a){bl(this.a)};Og(248,$wnd.Function,{},km);_.u=function(a){Yk(this.a,a)};Og(249,$wnd.Function,{},lm);_.ab=function(a){kl(this.a,this.b)};Og(251,$wnd.Function,{},mm);_.cb=function(a){Zk(this.a,this.b,a)};Og(152,1,{},om);var Gf=eh(152);Og(232,$wnd.Function,{},pm);_.bb=function(a){var b;b=a.target;yn((um(),sm),b.checked)};Og(64,1,{},qm);var If=eh(64);var rm,sm,tm;Og(121,1,{});var ng=eh(121);Og(122,121,Co,Hm);_.r=Mo;_.n=Go;_.p=Ho;_.s=No;_.v=To;var Rf=eh(122);Og(123,1,jo,Im);_.t=function(){Bm(this.a)};var Kf=eh(123);Og(125,1,mo,Jm);_.t=function(){wm(this.a)};var Lf=eh(125);Og(126,1,mo,Km);_.t=function(){xm(this.a)};var Mf=eh(126);Og(127,1,jo,Lm);_.t=function(){vm(this.a,this.b)};var Nf=eh(127);Og(128,1,jo,Mm);_.t=function(){Em(this.a)};var Of=eh(128);Og(53,1,jo,Nm);_.t=function(){Am(this.a)};var Pf=eh(53);Og(124,1,eo,Om);_.q=function(){var a;return a=(Wg(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var Qf=eh(124);Og(43,1,{43:1});_.d=false;var vg=eh(43);Og(44,43,{9:1,46:1,44:1,43:1},Zm);_.r=Mo;_.n=function(a){return Sm(this,a)};_.p=function(){return this.c.d};_.s=No;_.v=To;var Pm=0;var fg=eh(44);Og(181,1,jo,$m);_.t=function(){Qm(this.a)};var Sf=eh(181);Og(182,1,jo,_m);_.t=function(){Vm(this.a)};var Tf=eh(182);Og(41,99,{41:1});var qg=eh(41);Og(100,41,{9:1,46:1,41:1},jn);_.r=function(){fc(this.f)};_.n=Go;_.p=Ho;_.s=function(){return this.f.i<0};_.v=function(a){jc(this.f,a)};var ag=eh(100);Og(102,1,jo,kn);_.t=function(){bn(this.a)};var Uf=eh(102);Og(101,1,jo,ln);_.t=function(){fn(this.a)};var Vf=eh(101);Og(107,1,jo,mn);_.t=function(){_b(this.a,this.b,true)};var Wf=eh(107);Og(108,1,eo,nn);_.q=function(){return an(this.a,this.c,this.b)};_.b=false;var Xf=eh(108);Og(103,1,eo,on);_.q=function(){return gn(this.a)};var Yf=eh(103);Og(104,1,eo,pn);_.q=function(){return oh(Fg(Li(en(this.a))))};var Zf=eh(104);Og(105,1,eo,qn);_.q=function(){return oh(Fg(Li(Mi(en(this.a),new Yn))))};var $f=eh(105);Og(106,1,eo,rn);_.q=function(){return hn(this.a)};var _f=eh(106);Og(84,1,{});var ug=eh(84);Og(85,84,Co,zn);_.r=function(){fc(this.a)};_.n=Go;_.p=Ho;_.s=function(){return this.a.i<0};_.v=function(a){jc(this.a,a)};var eg=eh(85);Og(86,1,jo,An);_.t=function(){vn(this.a,this.b)};_.b=false;var bg=eh(86);Og(87,1,jo,Bn);_.t=function(){Gm(this.b,this.a)};var cg=eh(87);Og(88,1,jo,Cn);_.t=function(){wn(this.a)};var dg=eh(88);Og(89,1,{});var xg=eh(89);Og(90,89,Co,Ln);_.r=function(){fc(this.g)};_.n=Go;_.p=Ho;_.s=function(){return this.g.i<0};_.v=function(a){jc(this.g,a)};var lg=eh(90);Og(91,1,jo,Mn);_.t=function(){Fn(this.a)};var gg=eh(91);Og(92,1,eo,Nn);_.q=function(){var a;return a=Dm(this.a.i),uh(Eo,a)||uh(zo,a)||uh('',a)?uh(Eo,a)?(Vn(),Sn):uh(zo,a)?(Vn(),Un):(Vn(),Tn):(Vn(),Tn)};var hg=eh(92);Og(93,1,eo,On);_.q=function(){return Hn(this.a)};var ig=eh(93);Og(94,1,mo,Pn);_.t=function(){In(this.a)};var jg=eh(94);Og(95,1,mo,Qn);_.t=function(){Jn(this.a)};var kg=eh(95);Og(119,1,{},Rn);_.handleEvent=function(a){ym(this.a,a)};var mg=eh(119);Og(32,31,{3:1,29:1,31:1,32:1},Wn);var Sn,Tn,Un;var og=fh(32,Xn);Og(80,1,{},Yn);_.$=function(a){return !Um(a)};var pg=eh(80);Og(82,1,{},Zn);_.$=function(a){return Um(a)};var rg=eh(82);Og(83,1,{},$n);_.u=function(a){dn(this.a,a)};var sg=eh(83);Og(81,1,{},_n);_.u=function(a){tn(this.a,a)};_.a=false;var tg=eh(81);Og(73,1,{},ao);_.$=function(a){return En(this.a,a)};var wg=eh(73);var bo=(xc(),Ac);var gwtOnLoad=gwtOnLoad=Jg;Hg(Ug);Kg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();