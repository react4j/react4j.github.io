function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='3CE1350452EE5DE3B8FDE78263E4EDC3',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '3CE1350452EE5DE3B8FDE78263E4EDC3';function p(){}
function pj(){}
function Dj(){}
function Lj(){}
function Mj(){}
function mh(){}
function ih(){}
function Vh(){}
function Fb(){}
function Fm(){}
function um(){}
function xm(){}
function Bm(){}
function Jm(){}
function Nm(){}
function Qc(){}
function Xc(){}
function kk(){}
function $k(){}
function hl(){}
function bn(){}
function cn(){}
function Dn(){}
function Oo(){}
function Po(){}
function Vc(a){Uc()}
function th(){th=ih}
function wi(){ni(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function fc(a){this.a=a}
function oc(a){this.a=a}
function Jh(a){this.a=a}
function Uh(a){this.a=a}
function fi(a){this.a=a}
function ki(a){this.a=a}
function li(a){this.a=a}
function ji(a){this.b=a}
function yi(a){this.c=a}
function qj(a){this.a=a}
function Oj(a){this.a=a}
function gl(a){this.a=a}
function il(a){this.a=a}
function jl(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function El(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Il(a){this.a=a}
function cm(a){this.a=a}
function dm(a){this.a=a}
function im(a){this.a=a}
function km(a){this.a=a}
function lm(a){this.a=a}
function rm(a){this.a=a}
function sm(a){this.a=a}
function tm(a){this.a=a}
function Rm(a){this.a=a}
function Sm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function Xm(a){this.a=a}
function Ym(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function Bn(a){this.a=a}
function Cn(a){this.a=a}
function Pn(a){this.a=a}
function Qn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function co(a){this.a=a}
function eo(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function ro(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Eo(a){this.a=a}
function Fo(a){this.a=a}
function Go(a){this.a=a}
function Ho(a){this.a=a}
function Qo(a){this.a=a}
function Ro(a){this.a=a}
function So(a){this.a=a}
function Kj(a,b){a.a=b}
function dk(a,b){a.key=b}
function ck(a,b){bk(a,b)}
function io(a,b){am(b,a)}
function Y(a){!!a&&$(a)}
function jc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function wp(a){aj(this,a)}
function Bp(a){ej(this,a)}
function zp(a){Nh(this,a)}
function Dp(){ic(this.c)}
function Fp(){ic(this.b)}
function Lp(){ic(this.f)}
function Ki(){this.a=Ti()}
function Yi(){this.a=Ti()}
function Hp(){kb(this.a.a)}
function db(a){Yb((J(),a))}
function eb(a){Zb((J(),a))}
function hb(a){$b((J(),a))}
function mc(a,b){bi(a.e,b)}
function Nj(a,b){Cj(a.a,b)}
function ho(a,b){Tn(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function qb(a,b){a.b=dj(b)}
function Ib(a){a.a=-4&a.a|1}
function _k(a){a.d=2;ic(a.c)}
function kl(a){a.c=2;ic(a.b)}
function Pl(a){a.f=2;ic(a.e)}
function qn(a){R(a.a);$(a.b)}
function Fn(a){$(a.b);$(a.a)}
function Ug(a){return a.e}
function Ap(){return this.e}
function up(){return this.a}
function yp(){return this.b}
function vp(){return Vj(this)}
function Kl(a,b){return a.g=b}
function rc(a,b){a.e=b;qc(a,b)}
function yl(a){kb(a.a);$(a.b)}
function dl(a){kb(a.b);R(a.a)}
function Kp(a){mc(this.c,a)}
function Np(a){mc(this.f,a)}
function sh(a){uc.call(this,a)}
function Wh(a){uc.call(this,a)}
function Ol(a){Un((jn(),fn),a)}
function hc(a,b,c){ai(a.e,b,c)}
function Gn(a,b,c){hc(a.c,b,c)}
function jj(a,b,c){b.w(a.a[c])}
function qi(a,b){return a.a[b]}
function Cp(a){return this===a}
function wh(a){vh(a);return a.k}
function Yc(a,b){return Ch(a,b)}
function Sj(a,b){a.splice(b,1)}
function K(a,b){O(a);L(a,dj(b))}
function ab(a){J();Zb(a);a.e=-2}
function J(){J=ih;I=new F}
function wc(){wc=ih;vc=new p}
function Nc(){Nc=ih;Mc=new Qc}
function Pi(){Pi=ih;Oi=Ri()}
function Dc(){Dc=ih;!!(Uc(),Tc)}
function Oh(){pc(this);this.H()}
function xp(){return di(this.a)}
function Ep(){return this.c.i<0}
function Gp(){return this.b.i<0}
function Mp(){return this.f.i<0}
function Ti(){Pi();return new Oi}
function T(a){mb(a.f);return V(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function Cj(a,b){Kj(a,Bj(a.a,b))}
function ej(a,b){while(a.eb(b));}
function Hj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function Bj(a,b){a.T(b);return a}
function nk(a,b){a.ref=b;return a}
function sn(a){fb(a.b);return a.e}
function Jn(a){fb(a.a);return a.d}
function wo(a){fb(a.d);return a.e}
function Ip(a){return 1==this.a.d}
function Jp(a){return 1==this.a.c}
function di(a){return a.a.b+a.b.b}
function Vi(a,b){return a.a.get(b)}
function mi(a,b){this.a=a;this.b=b}
function gc(a,b){this.a=a;this.b=b}
function Hh(a,b){this.a=a;this.b=b}
function Hl(a,b){this.a=a;this.b=b}
function Gj(a,b){this.a=a;this.b=b}
function Jj(a,b){this.a=a;this.b=b}
function lk(a,b){this.a=a;this.b=b}
function em(a,b){this.a=a;this.b=b}
function fm(a,b){this.a=a;this.b=b}
function gm(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function jm(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function Zm(a,b){this.a=a;this.b=b}
function $m(a,b){this.a=a;this.b=b}
function Wk(a,b){Hh.call(this,a,b)}
function Qj(a,b,c){a.splice(b,0,c)}
function ok(a,b){a.href=b;return a}
function An(a,b){this.a=a;this.b=b}
function ao(a,b){this.a=a;this.b=b}
function po(a,b){this.a=a;this.b=b}
function qo(a,b){this.b=a;this.a=b}
function Mo(a,b){Hh.call(this,a,b)}
function tn(a){rn(a,(fb(a.b),a.e))}
function an(){this.a=ek((Lm(),Km))}
function dn(){this.a=ek((Pm(),Om))}
function vm(){this.a=ek((zm(),ym))}
function wm(){this.a=ek((Dm(),Cm))}
function Tm(){this.a=ek((Hm(),Gm))}
function ah(){$g==null&&($g=[])}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function md(a){return typeof a===Vo}
function pd(a){return a==null?null:a}
function cj(a){return a!=null?s(a):0}
function _h(a){return !a?null:a.ab()}
function Ub(a){return !a.d?a:Ub(a.d)}
function o(a,b){return pd(a)===pd(b)}
function Kn(a){am(a,(fb(a.a),!a.d))}
function Tl(a){kb(a.b);R(a.c);$(a.a)}
function Kc(a){$wnd.clearTimeout(a)}
function ni(a){a.a=$c(ie,Xo,1,0,5,1)}
function ci(a){a.a=new Ki;a.b=new Yi}
function ib(a){this.c=new wi;this.b=a}
function Zj(){Zj=ih;Wj=new p;Yj=new p}
function Sh(a,b){a.a+=''+b;return a}
function xk(a,b){a.value=b;return a}
function sk(a,b){a.onBlur=b;return a}
function pk(a,b){a.onClick=b;return a}
function tk(a,b){a.onChange=b;return a}
function rk(a,b){a.checked=b;return a}
function dc(a,b){b.A(a);kd(b,9)&&b.t()}
function ec(a,b){cc(a,b,false);eb(a.d)}
function Rj(a,b){Pj(b,0,a,0,b.length)}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function cd(a,b,c){return {l:a,m:b,h:c}}
function Ph(a,b){return a.charCodeAt(b)}
function kd(a,b){return a!=null&&hd(a,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function Vj(a){return a.$H||(a.$H=++Uj)}
function od(a){return typeof a==='string'}
function uk(a,b){a.onKeyDown=b;return a}
function qk(a){a.autoFocus=true;return a}
function vh(a){if(a.k!=null){return}Eh(a)}
function Db(a){this.d=dj(a);this.b=100}
function uc(a){this.g=a;pc(this);this.H()}
function Aj(a,b){tj.call(this,a);this.a=b}
function bk(a,b){for(var c in a){b(c)}}
function aj(a,b){while(a.Y()){Nj(b,a.Z())}}
function pb(a){J();ob(a);sb(a,2,true)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function fb(a){var b;Vb((J(),b=Qb,b),a)}
function vo(a){var b;b=a.e;!!b&&mc(b.c,a)}
function Mi(a,b){var c;c=a[ip];c.call(a,b)}
function Zl(a){A((J(),J(),I),new km(a),np)}
function un(a){A((J(),J(),I),new Bn(a),np)}
function Nn(a){A((J(),J(),I),new Qn(a),np)}
function jo(a){A((J(),J(),I),new ro(a),np)}
function uo(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function Yn(a){return Kh(S(a.e).a-S(a.a).a)}
function ld(a){return typeof a==='boolean'}
function Ec(a,b,c){return a.apply(b,c);var d}
function Nb(a,b,c){Ib(dj(c));K(a.a[b],dj(c))}
function _i(a,b,c){this.a=a;this.b=b;this.c=c}
function Ei(){this.a=new Ki;this.b=new Yi}
function P(){this.a=$c(ie,Xo,1,100,5,1)}
function Mh(){Mh=ih;Lh=$c(ee,Xo,30,256,0,1)}
function zh(a){var b;b=yh(a);Gh(a,b);return b}
function pc(a){a.j&&a.e!==dp&&a.H();return a}
function yk(a,b){a.onDoubleClick=b;return a}
function oi(a,b){a.a[a.a.length]=b;return true}
function qh(a,b,c,d){a.addEventListener(b,c,d)}
function _l(a,b){A((J(),J(),I),new em(a,b),np)}
function Ul(a,b){A((J(),J(),I),new jm(a,b),np)}
function Xl(a,b){A((J(),J(),I),new gm(a,b),np)}
function Yl(a,b){A((J(),J(),I),new fm(a,b),np)}
function zl(a,b){A((J(),J(),I),new Hl(a,b),np)}
function Un(a,b){A((J(),J(),I),new ao(a,b),np)}
function mo(a,b){A((J(),J(),I),new qo(a,b),np)}
function no(a,b){A((J(),J(),I),new po(a,b),np)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Al(a,b){var c;c=b.target;Cl(a,c.value)}
function uj(a,b){var c;return yj(a,(c=new wi,c))}
function Uc(){Uc=ih;var a;!Wc();a=new Xc;Tc=a}
function F(){this.f=new Pb;this.a=new Db(this.f)}
function bo(a,b){this.a=a;this.c=b;this.b=false}
function Cb(a){while(true){if(!Bb(a)){break}}}
function hj(a,b){while(a.c<a.d){jj(a,b,a.c++)}}
function lj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Ej(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function rh(a,b,c,d){a.removeEventListener(b,c,d)}
function Ui(a,b){return !(a.a.get(b)===undefined)}
function so(a){return o(sp,a)||o(tp,a)||o('',a)}
function ad(a){return Array.isArray(a)&&a.pb===mh}
function jd(a){return !Array.isArray(a)&&a.pb===mh}
function Ai(a){return new Aj(null,zi(a,a.length))}
function Xn(a){return th(),0==S(a.e).a?true:false}
function zi(a,b){return fj(b,a.length),new kj(a,b)}
function el(a){return B((J(),J(),I),a.b,new jl(a))}
function Sn(a){R(a.c);R(a.e);R(a.a);R(a.b);$(a.d)}
function Wn(a){Nh(new ki(a.g),new fc(a));ci(a.g)}
function hi(a){var b;b=a.a.Z();a.b=gi(a);return b}
function Bh(a){var b;b=yh(a);b.j=a;b.e=1;return b}
function si(a,b){var c;c=a.a[b];Sj(a.a,b);return c}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function $l(a){return B((J(),J(),I),a.b,new dm(a))}
function nl(a){return B((J(),J(),I),a.a,new rl(a))}
function Bl(a){return B((J(),J(),I),a.a,new Fl(a))}
function pm(a){return B((J(),J(),I),a.a,new tm(a))}
function ei(a,b){if(b){return Zh(a.a,b)}return false}
function dj(a){if(a==null){throw Ug(new Oh)}return a}
function ak(){if(Xj==256){Wj=Yj;Yj=new p;Xj=0}++Xj}
function al(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function ll(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function Ql(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function rj(a){if(!a.b){sj(a);a.c=true}else{rj(a.b)}}
function wj(a,b){sj(a);return new Aj(a,new Fj(b,a.a))}
function xj(a,b){sj(a);return new Aj(a,new Ij(b,a.a))}
function rn(a,b){A((J(),J(),I),new An(a,b),75497472)}
function Cl(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function am(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function ui(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function wk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function gj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function kj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function mj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function tj(a){if(!a){this.b=null;new wi}else{this.b=a}}
function Zg(a){if(md(a)){return a|0}return a.l|a.m<<22}
function ph(){ph=ih;oh=$wnd.goog.global.document}
function pn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&vn(a,b)}
function vn(a,b){var c;c=a.e;if(b!=c){a.e=dj(b);eb(a.b)}}
function Ah(a,b){var c;c=yh(a);Gh(a,c);c.e=b?8:0;return c}
function sc(a,b){var c;c=wh(a.nb);return b==null?c:c+': '+b}
function Jl(a,b){var c;if(S(a.c)){c=b.target;am(a,c.value)}}
function gb(a){var b;J();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&ap)&&D((null,I))}
function ko(a,b){uj(Vn(a.b),new qj(new pj)).Q(new Ro(b))}
function Di(a,b){return pd(a)===pd(b)||a!=null&&q(a,b)}
function $h(a,b){return b===a?'(this Map)':b==null?fp:lh(b)}
function Nh(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function Rb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function Dh(a){if(a.P()){return null}var b=a.j;return eh[b]}
function kh(a){function b(){}
;b.prototype=a||{};return new b}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function sj(a){if(a.b){sj(a.b)}else if(a.c){throw Ug(new Ih)}}
function Vl(a,b){zo((jn(),hn),b);A((J(),J(),I),new em(a,b),np)}
function No(){Lo();return bd(Yc(Ig,1),Xo,32,0,[Io,Ko,Jo])}
function Lm(){Lm=ih;var a;Km=(a=jh(Jm.prototype.mb,Jm,[]),a)}
function zm(){zm=ih;var a;ym=(a=jh(xm.prototype.mb,xm,[]),a)}
function Dm(){Dm=ih;var a;Cm=(a=jh(Bm.prototype.mb,Bm,[]),a)}
function Hm(){Hm=ih;var a;Gm=(a=jh(Fm.prototype.mb,Fm,[]),a)}
function Pm(){Pm=ih;var a;Om=(a=jh(Nm.prototype.mb,Nm,[]),a)}
function Ch(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function Gi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Hi(a,b){var c;return Fi(b,Gi(a,b==null?0:(c=s(b),c|0)))}
function Vn(a){fb(a.d);return new Aj(null,new mj(new ki(a.g),0))}
function nn(a,b){b.preventDefault();A((J(),J(),I),new Cn(a),np)}
function vk(a){a.placeholder='What needs to be done?';return a}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function gh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function jk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function lc(a){jc(a.g);!!a.e&&kc(a);Y(a.a);Y(a.c);jc(a.b);jc(a.f)}
function xi(a){ni(this);Rj(this.a,Yh(a,$c(ie,Xo,1,di(a.a),5,1)))}
function Li(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Ij(a,b){gj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function ij(a,b){if(a.c<a.d){jj(a,b,a.c++);return true}return false}
function Wl(a){return th(),wo((jn(),hn))==a.j.props['a']?true:false}
function mn(a){rh((ph(),$wnd.goog.global.window),qp,a.d,false)}
function ln(a){qh((ph(),$wnd.goog.global.window),qp,a.d,false)}
function lo(a){uj(wj(Vn(a.b),new Po),new qj(new pj)).Q(new Qo(a.b))}
function Am(a){$wnd.React.Component.call(this,a);this.a=new fl(this)}
function Em(a){$wnd.React.Component.call(this,a);this.a=new ol(this)}
function Im(a){$wnd.React.Component.call(this,a);this.a=new Dl(this)}
function Mm(a){$wnd.React.Component.call(this,a);this.a=new bm(this)}
function Qm(a){$wnd.React.Component.call(this,a);this.a=new qm(this)}
function Zi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Fj(a,b){gj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function bb(a,b){var c,d;oi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function bi(a,b){return od(b)?b==null?Ji(a.a,null):Xi(a.b,b):Ji(a.a,b)}
function nj(a,b){!a.a?(a.a=new Uh(a.d)):Sh(a.a,a.b);Sh(a.a,b);return a}
function yj(a,b){var c;rj(a);c=new Lj;c.a=b;a.a.X(new Oj(c));return c.a}
function vj(a){var b;rj(a);b=0;while(a.a.eb(new Mj)){b=Vg(b,1)}return b}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Jb(b){try{b.b.v()}catch(a){a=Tg(a);if(!kd(a,4))throw Ug(a)}}
function oo(a){this.b=dj(a);J();this.a=new nc(0,null,null,true,false)}
function oj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function ii(a){this.d=a;this.c=new Zi(this.d.b);this.a=this.c;this.b=gi(this)}
function jn(){jn=ih;fn=new Zn;gn=new oo(fn);en=new wn;hn=new Ao(fn,en)}
function Tn(a,b){var c;return u((J(),J(),I),new bo(a,b),np,(c=null,c))}
function zj(a,b){var c;c=uj(a,new qj(new pj));return vi(c,b.fb(c.a.length))}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function to(a,b){return (Lo(),Jo)==a||(Io==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function ai(a,b,c){return od(b)?b==null?Ii(a.a,null,c):Wi(a.b,b,c):Ii(a.a,b,c)}
function Tj(a,b){return Zc(b)!=10&&bd(r(b),b.ob,b.__elementTypeId$,Zc(b),a),a}
function kn(a,b){a.f=b;o(b,S(a.a))&&vn(a,b);on(b);A((J(),J(),I),new Cn(a),np)}
function xo(a){var b;return b=S(a.b),uj(wj(Vn(a.i),new So(b)),new qj(new pj))}
function ic(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new oc(a)),67108864,null)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function $i(a){if(a.a.c!=a.c){return Vi(a.a,a.b.value[0])}return a.b.value[1]}
function Hn(a,b){var c;if(kd(b,48)){c=b;return a.c.d==c.c.d}else{return false}}
function ti(a,b){var c;c=ri(a,b,0);if(c==-1){return false}Sj(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&bd(Yc(a,f),b,c,e,g);return g}
function ri(a,b,c){for(;c<a.a.length;++c){if(Di(b,a.a[c])){return c}}return -1}
function V(a){if(a.b){if(kd(a.b,7)){throw Ug(a.b)}else{throw Ug(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=Tg(a);if(kd(a,4)){J()}else throw Ug(a)}}}
function bc(){var a;try{Sb(Qb);J()}finally{a=Qb.d;!a&&((J(),J(),I).d=true);Qb=Qb.d}}
function sl(a){var b;b=Rh((fb(a.b),a.e));if(b.length>0){ho((jn(),gn),b);Cl(a,'')}}
function pi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Pb(){var a;this.a=$c(vd,Xo,46,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new wi);oi(a.b,b)}}}
function Gh(a,b){var c;if(!a){return}b.j=a;var d=Dh(b);if(!d){eh[a]=[b];return}d.nb=b}
function jh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function yh(a){var b;b=new xh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function hk(a){var b;return fk($wnd.React.StrictMode,null,null,(b={},b[jp]=dj(a),b))}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nd(a){return a!=null&&(typeof a===Uo||typeof a==='function')&&!(a.pb===mh)}
function dh(a,b){typeof window===Uo&&typeof window['$gwt']===Uo&&(window['$gwt'][a]=b)}
function tl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Gl(a),np)}}
function _g(){ah();var a=$g;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ob(a){var b,c;for(c=new yi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Bi(a){var b,c,d;d=0;for(c=new ii(a.a);c.b;){b=hi(c);d=d+(b?s(b):0);d=d|0}return d}
function ek(a){var b;b=gk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function fk(a,b,c,d){var e;e=gk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=dj(d);return e}
function Rn(a,b,c){var d;d=new On(b,c);Gn(d,a,new gc(a,d));ai(a.g,Kh(d.c.d),d);eb(a.d);return d}
function Xi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Mi(a.a,b);--a.b}return c}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new wi);a.c=c.c}b.d=true;oi(a.c,dj(b))}
function Xh(a,b){var c,d;for(d=new ii(b.a);d.b;){c=hi(d);if(!ei(a,c)){return false}}return true}
function Wg(a){var b;b=a.h;if(b==0){return a.l+a.m*bp}if(b==1048575){return a.l+a.m*bp-gp}return a}
function gi(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new Li(a.d.a);return a.a.Y()}
function Tg(a){var b;if(kd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new yc(a);Vc(b)}return b}
function Yg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=gp;d=1048575}c=qd(e/bp);b=qd(e-c*bp);return cd(b,c,d)}
function yo(a){var b;b=S(a.g.a);o(sp,b)||o(tp,b)||o('',b)?rn(a.g,b):so(sn(a.g))?un(a.g):rn(a.g,'')}
function cc(a,b,c){var d;d=bi(a.g,b?Kh(b.c.d):null);if(null!=d){mc(b.c,a);c&&!!b&&ic(b.c);eb(a.d)}}
function _m(a,b){dk(a.a,(vh(Zf),Zf.k+(''+(b?Kh(b.c.d):null))));dj(b);a.a.props['a']=b;return a.a}
function Wi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function bd(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=mh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Fi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Di(a,c._())){return c}}return null}
function nh(){jn();$wnd.ReactDOM.render(hk([(new dn).a]),(ph(),oh).getElementById('app'),null)}
function Ih(){uc.call(this,"Stream already terminated, can't be modified or used")}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:Zo)|(0==(c&6291456)?!a?ap:bp:0)|0|0|0)}
function Kb(a,b){this.b=dj(a);this.a=b|0|(0==(b&6291456)?bp:0)|(0!=(b&229376)?0:98304)}
function fj(a,b){if(0>a||a>b){throw Ug(new sh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Lo(){Lo=ih;Io=new Mo('ACTIVE',0);Ko=new Mo('COMPLETED',1);Jo=new Mo('ALL',2)}
function Ll(a,b,c){27==c.which?A((J(),J(),I),new hm(a,b),np):13==c.which&&A((J(),J(),I),new fm(a,b),np)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function Zk(){if(!Yk){Yk=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(jh($k.prototype.J,$k,[]))}}
function yc(a){wc();pc(this);this.e=a;qc(this,a);this.g=a==null?fp:lh(a);this.a='';this.b=a;this.a=''}
function xh(){this.g=uh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function zo(a,b){var c;c=a.e;if(!(b==c||!!b&&Hn(b,c))){!!c&&mc(c.c,a);a.e=b;!!b&&Gn(b,a,new Fo(a));eb(a.d)}}
function cb(a,b){var c,d;d=a.c;ti(d,b);!!a.b&&Zo!=(a.b.c&$o)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((J(),c=Qb,c),a))}
function dd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return cd(c&4194303,d&4194303,e&1048575)}
function Ml(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){mo((jn(),b),c);zo(hn,null);am(a,c)}else{Un((jn(),fn),b)}}
function Nl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;_l(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Zo)?Jb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function r(a){return od(a)?le:md(a)?_d:ld(a)?Zd:jd(a)?a.nb:ad(a)?a.nb:a.nb||Array.isArray(a)&&Yc(Rd,1)||Rd}
function s(a){return od(a)?_j(a):md(a)?qd(a):ld(a)?a?1231:1237:jd(a)?a.q():ad(a)?Vj(a):!!a&&!!a.hashCode?a.hashCode():Vj(a)}
function Kh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Mh(),Lh)[b];!c&&(c=Lh[b]=new Jh(a));return c}return new Jh(a)}
function lh(a){var b;if(Array.isArray(a)&&a.pb===mh){return wh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function _j(a){Zj();var b,c,d;c=':'+a;d=Yj[c];if(d!=null){return qd(d)}d=Wj[c];b=d==null?$j(a):qd(d);ak();Yj[c]=b;return b}
function Ci(a){var b,c,d;d=1;for(c=new yi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=si(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function kc(a){var b,c,d;for(c=new yi(new xi(new fi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();kd(d,9)&&d.u()||b.ab().v()}}
function Xk(){Vk();return bd(Yc(cf,1),Xo,6,0,[zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk])}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(Zo==(b&$o)?0:524288)|(0==(b&6291456)?Zo==(b&$o)?bp:ap:0)|0|268435456|0)}
function Vg(a,b){var c;if(md(a)&&md(b)){c=a+b;if(-17592186044416<c&&c<gp){return c}}return Wg(dd(md(a)?Yg(a):a,md(b)?Yg(b):b))}
function ol(a){var b;this.j=dj(a);J();b=++ml;this.b=new nc(b,null,new pl(this),false,false);this.a=new vb(null,dj(new ql(this)),mp)}
function qm(a){var b;this.j=dj(a);J();b=++om;this.b=new nc(b,null,new rm(this),false,false);this.a=new vb(null,dj(new sm(this)),mp)}
function nc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ei:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Fh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function vi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Tj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return od(a)?o(a,b):md(a)?pd(a)===pd(b):ld(a)?pd(a)===pd(b):jd(a)?a.o(b):ad(a)?o(a,b):!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function hd(a,b){if(od(a)){return !!gd[b]}else if(a.ob){return !!a.ob[b]}else if(md(a)){return !!fd[b]}else if(ld(a)){return !!ed[b]}return false}
function mk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Qb&&!!Qb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new yi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new yi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new yi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Rh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Yh(a,b){var c,d,e,f;f=di(a.a);b.length<f&&(b=Tj(new Array(f),b));e=b;d=new ii(a.a);for(c=0;c<f;++c){e[c]=hi(d)}b.length>f&&(b[f]=null);return b}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.v(),null)}finally{bc()}return f}catch(a){a=Tg(a);if(kd(a,4)){e=a;throw Ug(e)}else throw Ug(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.s()}else{ac(b,e);try{g=c.s()}finally{bc()}}return g}catch(a){a=Tg(a);if(kd(a,4)){f=a;throw Ug(f)}else throw Ug(a)}finally{D(b)}}
function Bb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Hb(c);return true}
function bh(b,c,d,e){ah();var f=$g;$moduleName=c;$moduleBase=d;Sg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{To(g)()}catch(a){b(c,a)}}else{To(g)()}}
function Dl(a){var b,c,d;this.j=dj(a);J();b=++xl;this.c=new nc(b,null,new El(this),false,false);this.b=(d=new ib((c=null,c)),d);this.a=new vb(null,dj(new Il(this)),mp)}
function fl(a){var b;this.j=dj(a);J();b=++cl;this.c=new nc(b,null,new gl(this),false,false);this.a=new W(new hl,null,null,136478720);this.b=new vb(null,dj(new il(this)),mp)}
function On(a,b){var c,d,e,f,g;this.e=dj(a);this.d=b;J();c=++En;this.c=new nc(c,null,new Pn(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function W(a,b,c,d){this.c=dj(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);Zo==(d&$o)&&lb(this.f)}
function gk(a,b){var c;c=new $wnd.Object;c.$$typeof=dj(a);c.type=dj(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ri(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Si()}}
function fh(){eh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Rc(c,g)):g[0].qb()}catch(a){a=Tg(a);if(kd(a,4)){d=a;Dc();Jc(kd(d,36)?d.I():d)}else throw Ug(a)}}return c}
function wl(a){var b;a.d=0;Zk();b=ik(op,qk(tk(uk(xk(vk(mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,['new-todo']))),(fb(a.b),a.e)),jh(Rm.prototype.kb,Rm,[a])),jh(Sm.prototype.jb,Sm,[a]))),null);return b}
function xc(a){var b;if(a.c==null){b=pd(a.b)===pd(vc)?null:a.b;a.d=b==null?fp:nd(b)?b==null?null:b.name:od(b)?'String':wh(r(b));a.a=a.a+': '+(nd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(pd(e)===pd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=Tg(a);if(kd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw Ug(c)}else throw Ug(a)}}
function Pj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Ii(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Fi(b,e);if(f){return f.bb(c)}}e[e.length]=new mi(b,c);++a.b;return null}
function $j(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ph(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Tg(a);if(kd(a,4)){J()}else throw Ug(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=$c(ie,Xo,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function ub(a,b,c,d){this.b=new wi;this.f=new Kb(new yb(this),d&6520832|262144|Zo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&ap)&&D((null,I)))}
function Ji(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Di(b,e._())){if(d.length==1){d.length=0;Mi(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function hh(a,b,c){var d=eh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=eh[b]),kh(h));_.ob=c;!b&&(_.pb=mh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Eh(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Fh('.',[c,Fh('$',d)]);a.b=Fh('.',[c,Fh('.',d)]);a.i=d[d.length-1]}
function bm(a){var b,c,d;this.j=dj(a);J();b=++Sl;this.e=new nc(b,null,new cm(this),false,false);this.a=(d=new ib((c=null,c)),d);this.c=new W(new im(this),null,null,136478720);this.b=new vb(null,dj(new lm(this)),mp);_l(this,this.j.props['a'])}
function on(a){var b;if(0==a.length){b=(ph(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',oh.title,b)}else{(ph(),$wnd.goog.global.window).location.hash=a}}
function Zh(a,b){var c,d,e;c=b._();e=b.ab();d=od(c)?c==null?_h(Hi(a.a,null)):Vi(a.b,c):_h(Hi(a.a,c));if(!(pd(e)===pd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(od(c)?c==null?!!Hi(a.a,null):Ui(a.b,c):!!Hi(a.a,c))){return false}return true}
function ik(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ck(b,jh(lk.prototype.hb,lk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[jp]=c[0],undefined):(d[jp]=c,undefined));return fk(a,e,f,d)}
function wn(){var a,b,c;this.d=new Ho(this);this.f=this.e=(c=(ph(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new nc(0,null,new xn(this),true,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new Dn,new yn(this),new zn(this),35651584)}
function Zn(){var a;this.g=new Ei;J();this.f=new nc(0,new _n(this),new $n(this),true,false);this.d=(a=new ib(null),a);this.c=new W(new co(this),null,null,rp);this.e=new W(new eo(this),null,null,rp);this.a=new W(new fo(this),null,null,rp);this.b=new W(new go(this),null,null,rp)}
function Ao(a,b){var c,d;this.i=dj(a);this.g=dj(b);J();this.f=new nc(0,new Bo(this),new Co(this),true,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new Go(this),null,null,rp);this.c=new W(new Do(this),null,null,rp);this.a=new vb(dj(new Eo(this)),null,681574400);D((null,I))}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new yi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Tg(a);if(!kd(a,4))throw Ug(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function qc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.F();return a&&a.C()}},suppressed:{get:function(){return c.D()}}})}catch(a){}}}
function Qi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}pi(a.b,new Ab(a));a.b.a=$c(ie,Xo,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Vk(){Vk=ih;zk=new Wk(kp,0);Ak=new Wk('checkbox',1);Bk=new Wk('color',2);Ck=new Wk('date',3);Dk=new Wk('datetime',4);Ek=new Wk('email',5);Fk=new Wk('file',6);Gk=new Wk('hidden',7);Hk=new Wk('image',8);Ik=new Wk('month',9);Jk=new Wk(Vo,10);Kk=new Wk('password',11);Lk=new Wk('radio',12);Mk=new Wk('range',13);Nk=new Wk('reset',14);Ok=new Wk('search',15);Pk=new Wk('submit',16);Qk=new Wk('tel',17);Rk=new Wk('text',18);Sk=new Wk('time',19);Tk=new Wk('url',20);Uk=new Wk('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=qi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ui(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=qi(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){si(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new wi)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Zo!=(k.b.c&$o)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function bl(a){var b,c;a.d=0;Zk();c=(b=S((jn(),hn).b),ik('footer',mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,['footer'])),[(new wm).a,ik('ul',mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,['filters'])),[ik('li',null,[ik('a',ok(mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,[(Lo(),Jo)==b?lp:null])),'#'),['All'])]),ik('li',null,[ik('a',ok(mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,[Io==b?lp:null])),'#active'),['Active'])]),ik('li',null,[ik('a',ok(mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,[Ko==b?lp:null])),'#completed'),['Completed'])])]),S(a.a)?ik(kp,pk(mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,['clear-completed'])),jh(um.prototype.lb,um,[])),['Clear Completed']):null]));return c}
function Rl(a){var b,c,d,e;a.f=0;Zk();b=a.j.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.j.props['a'],e=(fb(d.a),d.d),ik('li',mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,[e?'checked':null,S(a.c)?'editing':null])),[ik('div',mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,['view'])),[ik(op,tk(rk(wk(mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,['toggle'])),(Vk(),Ak)),e),jh(Vm.prototype.jb,Vm,[d])),null),ik('label',yk(new $wnd.Object,jh(Wm.prototype.lb,Wm,[a,d])),[(fb(d.b),d.e)]),ik(kp,pk(mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,['destroy'])),jh(Xm.prototype.lb,Xm,[d])),null)]),ik(op,uk(tk(sk(xk(mk(nk(new $wnd.Object,jh(Ym.prototype.w,Ym,[a])),bd(Yc(le,1),Xo,2,6,['edit'])),(fb(a.a),a.d)),jh(Zm.prototype.ib,Zm,[a,d])),jh(Um.prototype.jb,Um,[a])),jh($m.prototype.kb,$m,[a,d])),null)]));return c}
function Si(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[ip]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Qi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[ip]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Uo='object',Vo='number',Wo={11:1},Xo={3:1},Yo={9:1},Zo=1048576,$o=1835008,_o={5:1},ap=2097152,bp=4194304,cp={25:1},dp='__noinit__',ep={3:1,10:1,7:1,4:1},fp='null',gp=17592186044416,hp={42:1},ip='delete',jp='children',kp='button',lp='selected',mp=1411518464,np=142606336,op='input',pp='header',qp='hashchange',rp=136314880,sp='active',tp='completed';var _,eh,$g,Sg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;fh();hh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=vp;_.r=function(){var a;return wh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var ed,fd,gd;hh(54,1,{},xh);_.K=function(a){var b;b=new xh;b.e=4;a>1?(b.c=Ch(this,a-1)):(b.c=this);return b};_.L=function(){vh(this);return this.b};_.M=function(){return wh(this)};_.N=function(){vh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(vh(this),this.k)};_.e=0;_.g=0;var uh=1;var ie=zh(1);var $d=zh(54);hh(85,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var ud=zh(85);hh(37,1,Wo,G);_.s=function(){return this.a.v(),null};var sd=zh(37);hh(86,1,{},H);var td=zh(86);var I;hh(46,1,{46:1},P);_.b=0;_.c=false;_.d=0;var vd=zh(46);hh(218,1,Yo);_.r=function(){var a;return wh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var yd=zh(218);hh(19,218,Yo,W);_.t=function(){R(this)};_.u=up;_.a=false;_.d=0;_.k=false;var xd=zh(19);hh(128,1,Wo,X);_.s=function(){return T(this.a)};var wd=zh(128);hh(16,218,{9:1,16:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Ad=zh(16);hh(127,1,_o,jb);_.v=function(){ab(this.a)};var zd=zh(127);hh(17,218,{9:1,17:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Fd=zh(17);hh(129,1,cp,xb);_.v=function(){Q(this.a)};var Bd=zh(129);hh(130,1,_o,yb);_.v=function(){mb(this.a)};var Cd=zh(130);hh(131,1,_o,zb);_.v=function(){pb(this.a)};var Dd=zh(131);hh(132,1,{},Ab);_.w=function(a){nb(this.a,a)};var Ed=zh(132);hh(137,1,{},Db);_.a=0;_.b=0;_.c=0;var Gd=zh(137);hh(163,1,Yo,Fb);_.t=function(){Eb(this)};_.u=up;_.a=false;var Hd=zh(163);hh(65,218,{9:1,65:1},Kb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Jd=zh(65);hh(60,1,{60:1},Pb);var Id=zh(60);hh(143,1,{},_b);_.r=function(){var a;return vh(Kd),Kd.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.a=0;var Qb;var Kd=zh(143);hh(116,1,{});var Nd=zh(116);hh(87,1,{},fc);_.w=function(a){dc(this.a,a)};var Ld=zh(87);hh(88,1,_o,gc);_.v=function(){ec(this.a,this.b)};var Md=zh(88);hh(15,1,Yo,nc);_.t=function(){ic(this)};_.u=function(){return this.i<0};_.r=function(){var a;return vh(Pd),Pd.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Pd=zh(15);hh(126,1,_o,oc);_.v=function(){lc(this.a)};var Od=zh(126);hh(4,1,{3:1,4:1});_.B=function(a){return new Error(a)};_.C=Ap;_.D=function(){return zj(xj(Ai((this.i==null&&(this.i=$c(ne,Xo,4,0,0,1)),this.i)),new Vh),new Dj)};_.F=function(){return this.f};_.G=function(){return this.g};_.H=function(){rc(this,tc(this.B(sc(this,this.g))));Vc(this)};_.r=function(){return sc(this,this.G())};_.e=dp;_.j=true;var ne=zh(4);hh(10,4,{3:1,10:1,4:1});var be=zh(10);hh(7,10,ep);var je=zh(7);hh(55,7,ep);var fe=zh(55);hh(78,55,ep);var Td=zh(78);hh(36,78,{36:1,3:1,10:1,7:1,4:1},yc);_.G=function(){xc(this);return this.c};_.I=function(){return pd(this.b)===pd(vc)?null:this.b};var vc;var Qd=zh(36);var Rd=zh(0);hh(204,1,{});var Sd=zh(204);var Ac=0,Bc=0,Cc=-1;hh(115,204,{},Qc);var Mc;var Ud=zh(115);var Tc;hh(215,1,{});var Wd=zh(215);hh(79,215,{},Xc);var Vd=zh(79);var oh;hh(76,1,{73:1});_.r=up;var Xd=zh(76);hh(81,7,ep);var de=zh(81);hh(159,81,ep,sh);var Yd=zh(159);ed={3:1,74:1,29:1};var Zd=zh(74);hh(43,1,{3:1,43:1});var he=zh(43);fd={3:1,29:1,43:1};var _d=zh(214);hh(31,1,{3:1,29:1,31:1});_.o=Cp;_.q=vp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ae=zh(31);hh(80,7,ep,Ih);var ce=zh(80);hh(30,43,{3:1,29:1,30:1,43:1},Jh);_.o=function(a){return kd(a,30)&&a.a==this.a};_.q=up;_.r=function(){return ''+this.a};_.a=0;var ee=zh(30);var Lh;hh(283,1,{});hh(83,55,ep,Oh);_.B=function(a){return new TypeError(a)};var ge=zh(83);gd={3:1,73:1,29:1,2:1};var le=zh(2);hh(77,76,{73:1},Uh);var ke=zh(77);hh(287,1,{});hh(71,1,{},Vh);_.S=function(a){return a.e};var me=zh(71);hh(57,7,ep,Wh);var oe=zh(57);hh(216,1,{41:1});_.Q=zp;_.V=function(){return new mj(this,0)};_.W=function(){return new Aj(null,this.V())};_.T=function(a){throw Ug(new Wh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new oj('[',']');for(b=this.R();b.Y();){a=b.Z();nj(c,a===this?'(this Collection)':a==null?fp:lh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=zh(216);hh(219,1,{202:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!kd(a,38)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ii((new fi(d)).a);c.b;){b=hi(c);if(!Zh(this,b)){return false}}return true};_.q=function(){return Bi(new fi(this))};_.r=function(){var a,b,c;c=new oj('{','}');for(b=new ii((new fi(this)).a);b.b;){a=hi(b);nj(c,$h(this,a._())+'='+$h(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=zh(219);hh(133,219,{202:1});var se=zh(133);hh(220,216,{41:1,230:1});_.V=function(){return new mj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!kd(a,21)){return false}b=a;if(di(b.a)!=this.U()){return false}return Xh(this,b)};_.q=function(){return Bi(this)};var Be=zh(220);hh(21,220,{21:1,41:1,230:1},fi);_.R=function(){return new ii(this.a)};_.U=xp;var re=zh(21);hh(22,1,{},ii);_.X=wp;_.Z=function(){return hi(this)};_.Y=yp;_.b=false;var qe=zh(22);hh(217,216,{41:1,227:1});_.V=function(){return new mj(this,16)};_.$=function(a,b){throw Ug(new Wh('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!kd(a,14)){return false}f=a;if(this.U()!=f.a.length){return false}e=new yi(f);for(c=new yi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(pd(b)===pd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Ci(this)};_.R=function(){return new ji(this)};var ue=zh(217);hh(114,1,{},ji);_.X=wp;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return qi(this.b,this.a++)};_.a=0;var te=zh(114);hh(59,216,{41:1},ki);_.R=function(){var a;a=new ii((new fi(this.a)).a);return new li(a)};_.U=xp;var we=zh(59);hh(136,1,{},li);_.X=wp;_.Y=function(){return this.a.b};_.Z=function(){var a;a=hi(this.a);return a.ab()};var ve=zh(136);hh(134,1,hp);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Di(this.a,b._())&&Di(this.b,b.ab())};_._=up;_.ab=yp;_.q=function(){return cj(this.a)^cj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var xe=zh(134);hh(135,134,hp,mi);var ye=zh(135);hh(221,1,hp);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Di(this.b.value[0],b._())&&Di($i(this),b.ab())};_.q=function(){return cj(this.b.value[0])^cj($i(this))};_.r=function(){return this.b.value[0]+'='+$i(this)};var ze=zh(221);hh(14,217,{3:1,14:1,41:1,227:1},wi,xi);_.$=function(a,b){Qj(this.a,a,b)};_.T=function(a){return oi(this,a)};_.Q=function(a){pi(this,a)};_.R=function(){return new yi(this)};_.U=function(){return this.a.length};var De=zh(14);hh(18,1,{},yi);_.X=wp;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=zh(18);hh(38,133,{3:1,38:1,202:1},Ei);var Ee=zh(38);hh(63,1,{},Ki);_.Q=zp;_.R=function(){return new Li(this)};_.b=0;var Ge=zh(63);hh(64,1,{},Li);_.X=wp;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=zh(64);var Oi;hh(61,1,{},Yi);_.Q=zp;_.R=function(){return new Zi(this)};_.b=0;_.c=0;var Je=zh(61);hh(62,1,{},Zi);_.X=wp;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new _i(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var He=zh(62);hh(142,221,hp,_i);_._=function(){return this.b.value[0]};_.ab=function(){return $i(this)};_.bb=function(a){return Wi(this.a,this.b.value[0],a)};_.c=0;var Ie=zh(142);hh(145,1,{});_.X=Bp;_.cb=function(){return this.d};_.db=Ap;_.d=0;_.e=0;var Ne=zh(145);hh(66,145,{});var Ke=zh(66);hh(138,1,{});_.X=Bp;_.cb=yp;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Me=zh(138);hh(139,138,{},kj);_.X=function(a){hj(this,a)};_.eb=function(a){return ij(this,a)};var Le=zh(139);hh(23,1,{},mj);_.cb=up;_.db=function(){lj(this);return this.c};_.X=function(a){lj(this);this.d.X(a)};_.eb=function(a){lj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Oe=zh(23);hh(56,1,{},oj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Pe=zh(56);hh(35,1,{},pj);_.S=function(a){return a};var Qe=zh(35);hh(39,1,{},qj);var Re=zh(39);hh(144,1,{});_.c=false;var _e=zh(144);hh(27,144,{249:1},Aj);var $e=zh(27);hh(72,1,{},Dj);_.fb=function(a){return $c(ie,Xo,1,a,5,1)};var Se=zh(72);hh(147,66,{},Fj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Gj(this,a)));return this.b};_.b=false;var Ue=zh(147);hh(150,1,{},Gj);_.w=function(a){Ej(this.a,this.b,a)};var Te=zh(150);hh(146,66,{},Ij);_.eb=function(a){return this.b.eb(new Jj(this,a))};var We=zh(146);hh(149,1,{},Jj);_.w=function(a){Hj(this.a,this.b,a)};var Ve=zh(149);hh(148,1,{},Lj);_.w=function(a){Kj(this,a)};var Xe=zh(148);hh(151,1,{},Mj);_.w=function(a){};var Ye=zh(151);hh(152,1,{},Oj);_.w=function(a){Nj(this,a)};var Ze=zh(152);hh(285,1,{});hh(282,1,{});var Uj=0;var Wj,Xj=0,Yj;hh(900,1,{});hh(922,1,{});hh(222,1,{});var af=zh(222);hh(160,1,{},kk);_.fb=function(a){return new Array(a)};var bf=zh(160);hh(250,$wnd.Function,{},lk);_.hb=function(a){jk(this.a,this.b,a)};hh(6,31,{3:1,29:1,31:1,6:1},Wk);var zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk;var cf=Ah(6,Xk);var Yk;hh(251,$wnd.Function,{},$k);_.J=function(a){return Eb(Yk),Yk=null,null};hh(225,222,{});var Lf=zh(225);hh(176,225,{});_.d=0;var Pf=zh(176);hh(177,176,Yo,fl);_.t=Dp;_.o=Cp;_.q=vp;_.u=Ep;_.r=function(){var a;return vh(mf),mf.k+'@'+(a=Vj(this)>>>0,a.toString(16))};var cl=0;var mf=zh(177);hh(178,1,_o,gl);_.v=function(){dl(this.a)};var df=zh(178);hh(179,1,Wo,hl);_.s=function(){return th(),S((jn(),fn).b).a>0?true:false};var ef=zh(179);hh(180,1,cp,il);_.v=function(){al(this.a)};var ff=zh(180);hh(181,1,Wo,jl);_.s=function(){return bl(this.a)};var gf=zh(181);hh(226,222,{});var Kf=zh(226);hh(196,226,{});_.c=0;var Of=zh(196);hh(197,196,Yo,ol);_.t=Fp;_.o=Cp;_.q=vp;_.u=Gp;_.r=function(){var a;return vh(lf),lf.k+'@'+(a=Vj(this)>>>0,a.toString(16))};var ml=0;var lf=zh(197);hh(198,1,_o,pl);_.v=Hp;var hf=zh(198);hh(199,1,cp,ql);_.v=function(){ll(this.a)};var jf=zh(199);hh(200,1,Wo,rl);_.s=function(){var a,b;return this.a.c=0,Zk(),a=S((jn(),fn).e).a,b='item'+(a==1?'':'s'),ik('span',mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,['todo-count'])),[ik('strong',null,[a]),' '+b+' left'])};var kf=zh(200);hh(168,222,{});_.e='';var Xf=zh(168);hh(169,168,{});_.d=0;var Rf=zh(169);hh(170,169,Yo,Dl);_.t=Dp;_.o=Cp;_.q=vp;_.u=Ep;_.r=function(){var a;return vh(sf),sf.k+'@'+(a=Vj(this)>>>0,a.toString(16))};var xl=0;var sf=zh(170);hh(171,1,_o,El);_.v=function(){yl(this.a)};var nf=zh(171);hh(173,1,Wo,Fl);_.s=function(){return wl(this.a)};var of=zh(173);hh(174,1,_o,Gl);_.v=function(){sl(this.a)};var pf=zh(174);hh(175,1,_o,Hl);_.v=function(){Al(this.a,this.b)};var qf=zh(175);hh(172,1,cp,Il);_.v=function(){al(this.a)};var rf=zh(172);hh(224,222,{});_.i=false;var Zf=zh(224);hh(183,224,{});_.f=0;var Tf=zh(183);hh(184,183,Yo,bm);_.t=function(){ic(this.e)};_.o=Cp;_.q=vp;_.u=function(){return this.e.i<0};_.r=function(){var a;return vh(Df),Df.k+'@'+(a=Vj(this)>>>0,a.toString(16))};var Sl=0;var Df=zh(184);hh(185,1,_o,cm);_.v=function(){Tl(this.a)};var tf=zh(185);hh(188,1,Wo,dm);_.s=function(){return Rl(this.a)};var uf=zh(188);hh(67,1,_o,em);_.v=function(){am(this.a,sn(this.b))};var vf=zh(67);hh(68,1,_o,fm);_.v=function(){Ml(this.a,this.b)};var wf=zh(68);hh(189,1,_o,gm);_.v=function(){Vl(this.a,this.b)};var xf=zh(189);hh(190,1,_o,hm);_.v=function(){_l(this.a,this.b);zo((jn(),hn),null)};var yf=zh(190);hh(186,1,Wo,im);_.s=function(){return Wl(this.a)};var zf=zh(186);hh(191,1,_o,jm);_.v=function(){Jl(this.a,this.b)};var Af=zh(191);hh(192,1,_o,km);_.v=function(){Nl(this.a)};var Bf=zh(192);hh(187,1,cp,lm);_.v=function(){Ql(this.a)};var Cf=zh(187);hh(223,222,{});var ag=zh(223);hh(154,223,{});_.c=0;var Vf=zh(154);hh(155,154,Yo,qm);_.t=Fp;_.o=Cp;_.q=vp;_.u=Gp;_.r=function(){var a;return vh(Hf),Hf.k+'@'+(a=Vj(this)>>>0,a.toString(16))};var om=0;var Hf=zh(155);hh(156,1,_o,rm);_.v=Hp;var Ef=zh(156);hh(157,1,cp,sm);_.v=function(){ll(this.a)};var Ff=zh(157);hh(158,1,Wo,tm);_.s=function(){return this.a.c=0,Zk(),ik('div',null,[ik('div',null,[ik(pp,mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,[pp])),[ik('h1',null,['todos']),(new Tm).a]),S((jn(),fn).c)?null:ik('section',mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,[pp])),[ik(op,tk(wk(mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,['toggle-all'])),(Vk(),Ak)),jh(bn.prototype.jb,bn,[])),null),ik('ul',mk(new $wnd.Object,bd(Yc(le,1),Xo,2,6,['todo-list'])),zj(dj(xj(S(hn.c).W(),new cn)),new kk))]),S(fn.c)?null:(new vm).a])])};var Gf=zh(158);hh(255,$wnd.Function,{},um);_.lb=function(a){jo((jn(),gn))};hh(162,1,{},vm);var If=zh(162);hh(182,1,{},wm);var Jf=zh(182);hh(256,$wnd.Function,{},xm);_.mb=function(a){return new Am(a)};var ym;hh(166,$wnd.React.Component,{},Am);gh(eh[1],_);_.componentWillUnmount=function(){_k(this.a)};_.render=function(){return el(this.a)};_.shouldComponentUpdate=Ip;var Mf=zh(166);hh(266,$wnd.Function,{},Bm);_.mb=function(a){return new Em(a)};var Cm;hh(193,$wnd.React.Component,{},Em);gh(eh[1],_);_.componentWillUnmount=function(){kl(this.a)};_.render=function(){return nl(this.a)};_.shouldComponentUpdate=Jp;var Nf=zh(193);hh(254,$wnd.Function,{},Fm);_.mb=function(a){return new Im(a)};var Gm;hh(165,$wnd.React.Component,{},Im);gh(eh[1],_);_.componentWillUnmount=function(){_k(this.a)};_.render=function(){return Bl(this.a)};_.shouldComponentUpdate=Ip;var Qf=zh(165);hh(257,$wnd.Function,{},Jm);_.mb=function(a){return new Mm(a)};var Km;hh(167,$wnd.React.Component,{},Mm);gh(eh[1],_);_.componentDidUpdate=function(a){Zl(this.a)};_.componentWillUnmount=function(){Pl(this.a)};_.render=function(){return $l(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Sf=zh(167);hh(248,$wnd.Function,{},Nm);_.mb=function(a){return new Qm(a)};var Om;hh(140,$wnd.React.Component,{},Qm);gh(eh[1],_);_.componentWillUnmount=function(){kl(this.a)};_.render=function(){return pm(this.a)};_.shouldComponentUpdate=Jp;var Uf=zh(140);hh(252,$wnd.Function,{},Rm);_.kb=function(a){tl(this.a,a)};hh(253,$wnd.Function,{},Sm);_.jb=function(a){zl(this.a,a)};hh(161,1,{},Tm);var Wf=zh(161);hh(264,$wnd.Function,{},Um);_.jb=function(a){Ul(this.a,a)};hh(258,$wnd.Function,{},Vm);_.jb=function(a){Nn(this.a)};hh(260,$wnd.Function,{},Wm);_.lb=function(a){Xl(this.a,this.b)};hh(261,$wnd.Function,{},Xm);_.lb=function(a){Ol(this.a)};hh(262,$wnd.Function,{},Ym);_.w=function(a){Kl(this.a,a)};hh(263,$wnd.Function,{},Zm);_.ib=function(a){Yl(this.a,this.b)};hh(265,$wnd.Function,{},$m);_.kb=function(a){Ll(this.a,this.b,a)};hh(164,1,{},an);var Yf=zh(164);hh(247,$wnd.Function,{},bn);_.jb=function(a){var b;b=a.target;no((jn(),gn),b.checked)};hh(141,1,{},cn);_.S=function(a){return _m(new an,a)};var $f=zh(141);hh(70,1,{},dn);var _f=zh(70);var en,fn,gn,hn;hh(44,1,{44:1});var Hg=zh(44);hh(99,44,{9:1,52:1,44:1},wn);_.t=Dp;_.o=Cp;_.q=vp;_.u=Ep;_.A=Kp;_.r=function(){var a;return vh(ig),ig.k+'@'+(a=Vj(this)>>>0,a.toString(16))};var ig=zh(99);hh(100,1,_o,xn);_.v=function(){qn(this.a)};var bg=zh(100);hh(102,1,cp,yn);_.v=function(){ln(this.a)};var cg=zh(102);hh(103,1,cp,zn);_.v=function(){mn(this.a)};var dg=zh(103);hh(104,1,_o,An);_.v=function(){kn(this.a,this.b)};var eg=zh(104);hh(105,1,_o,Bn);_.v=function(){tn(this.a)};var fg=zh(105);hh(58,1,_o,Cn);_.v=function(){pn(this.a)};var gg=zh(58);hh(101,1,Wo,Dn);_.s=function(){var a;return a=(ph(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var hg=zh(101);hh(47,1,{47:1});_.d=false;var Pg=zh(47);hh(48,47,{9:1,52:1,48:1,47:1},On);_.t=Dp;_.o=function(a){return Hn(this,a)};_.q=function(){return this.c.d};_.u=Ep;_.A=Kp;_.r=function(){var a;return vh(yg),yg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var En=0;var yg=zh(48);hh(194,1,_o,Pn);_.v=function(){Fn(this.a)};var jg=zh(194);hh(195,1,_o,Qn);_.v=function(){Kn(this.a)};var kg=zh(195);hh(45,116,{45:1});var Kg=zh(45);hh(117,45,{9:1,52:1,45:1},Zn);_.t=Lp;_.o=Cp;_.q=vp;_.u=Mp;_.A=Np;_.r=function(){var a;return vh(tg),tg.k+'@'+(a=Vj(this)>>>0,a.toString(16))};var tg=zh(117);hh(119,1,_o,$n);_.v=function(){Sn(this.a)};var lg=zh(119);hh(118,1,_o,_n);_.v=function(){Wn(this.a)};var mg=zh(118);hh(124,1,_o,ao);_.v=function(){cc(this.a,this.b,true)};var ng=zh(124);hh(125,1,Wo,bo);_.s=function(){return Rn(this.a,this.c,this.b)};_.b=false;var og=zh(125);hh(120,1,Wo,co);_.s=function(){return Xn(this.a)};var pg=zh(120);hh(121,1,Wo,eo);_.s=function(){return Kh(Zg(vj(Vn(this.a))))};var qg=zh(121);hh(122,1,Wo,fo);_.s=function(){return Kh(Zg(vj(wj(Vn(this.a),new Oo))))};var rg=zh(122);hh(123,1,Wo,go);_.s=function(){return Yn(this.a)};var sg=zh(123);hh(93,1,{});var Og=zh(93);hh(94,93,{9:1,52:1},oo);_.t=function(){ic(this.a)};_.o=Cp;_.q=vp;_.u=function(){return this.a.i<0};_.A=function(a){mc(this.a,a)};_.r=function(){var a;return vh(xg),xg.k+'@'+(a=Vj(this)>>>0,a.toString(16))};var xg=zh(94);hh(95,1,_o,po);_.v=function(){ko(this.a,this.b)};_.b=false;var ug=zh(95);hh(96,1,_o,qo);_.v=function(){vn(this.b,this.a)};var vg=zh(96);hh(97,1,_o,ro);_.v=function(){lo(this.a)};var wg=zh(97);hh(106,1,{});var Rg=zh(106);hh(107,106,{9:1,52:1},Ao);_.t=Lp;_.o=Cp;_.q=vp;_.u=Mp;_.A=Np;_.r=function(){var a;return vh(Fg),Fg.k+'@'+(a=Vj(this)>>>0,a.toString(16))};var Fg=zh(107);hh(108,1,_o,Bo);_.v=function(){vo(this.a)};var zg=zh(108);hh(109,1,_o,Co);_.v=function(){uo(this.a)};var Ag=zh(109);hh(111,1,Wo,Do);_.s=function(){return xo(this.a)};var Bg=zh(111);hh(112,1,cp,Eo);_.v=function(){yo(this.a)};var Cg=zh(112);hh(113,1,_o,Fo);_.v=function(){zo(this.a,null)};var Dg=zh(113);hh(110,1,Wo,Go);_.s=function(){var a;return a=sn(this.a.g),o(sp,a)?(Lo(),Io):o(tp,a)?(Lo(),Ko):(Lo(),Jo)};var Eg=zh(110);hh(98,1,{},Ho);_.handleEvent=function(a){nn(this.a,a)};var Gg=zh(98);hh(32,31,{3:1,29:1,31:1,32:1},Mo);var Io,Jo,Ko;var Ig=Ah(32,No);hh(89,1,{},Oo);_.gb=function(a){return !Jn(a)};var Jg=zh(89);hh(91,1,{},Po);_.gb=function(a){return Jn(a)};var Lg=zh(91);hh(92,1,{},Qo);_.w=function(a){Un(this.a,a)};var Mg=zh(92);hh(90,1,{},Ro);_.w=function(a){io(this.a,a)};_.a=false;var Ng=zh(90);hh(82,1,{},So);_.gb=function(a){return to(this.a,a)};var Qg=zh(82);var rd=Bh('D');var To=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=bh;_g(nh);dh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();