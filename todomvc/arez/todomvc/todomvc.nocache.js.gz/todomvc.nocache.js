function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='D9B7C956610EA51FA9CE97F6C285B173',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'D9B7C956610EA51FA9CE97F6C285B173';function p(){}
function mh(){}
function ih(){}
function Uh(){}
function Fb(){}
function Rc(){}
function Yc(){}
function Yk(){}
function ik(){}
function nj(){}
function Bj(){}
function Jj(){}
function Kj(){}
function fl(){}
function sm(){}
function vm(){}
function zm(){}
function Dm(){}
function Hm(){}
function Lm(){}
function _m(){}
function an(){}
function Bn(){}
function Lo(){}
function Mo(){}
function Wc(a){Vc()}
function th(){th=ih}
function vi(){mi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function gc(a){this.a=a}
function pc(a){this.a=a}
function Jh(a){this.a=a}
function Th(a){this.a=a}
function ei(a){this.a=a}
function ji(a){this.a=a}
function ki(a){this.a=a}
function ii(a){this.b=a}
function xi(a){this.c=a}
function oj(a){this.a=a}
function Mj(a){this.a=a}
function el(a){this.a=a}
function gl(a){this.a=a}
function hl(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function pl(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function El(a){this.a=a}
function Gl(a){this.a=a}
function am(a){this.a=a}
function bm(a){this.a=a}
function gm(a){this.a=a}
function im(a){this.a=a}
function jm(a){this.a=a}
function pm(a){this.a=a}
function qm(a){this.a=a}
function rm(a){this.a=a}
function Pm(a){this.a=a}
function Qm(a){this.a=a}
function Sm(a){this.a=a}
function Tm(a){this.a=a}
function Vm(a){this.a=a}
function Wm(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function zn(a){this.a=a}
function An(a){this.a=a}
function Nn(a){this.a=a}
function On(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function co(a){this.a=a}
function oo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Eo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Ij(a,b){a.a=b}
function qb(a,b){a.b=b}
function bk(a,b){a.key=b}
function ak(a,b){_j(a,b)}
function fo(a,b){$l(b,a)}
function Y(a){!!a&&$(a)}
function kc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function sp(a){_i(this,a)}
function vp(a){Nh(this,a)}
function xp(a){cj(this,a)}
function zp(){jc(this.c)}
function Bp(){jc(this.b)}
function Hp(){jc(this.f)}
function Ji(){this.a=Si()}
function Xi(){this.a=Si()}
function Dp(){kb(this.a.a)}
function db(a){Xb((J(),a))}
function eb(a){Yb((J(),a))}
function hb(a){Zb((J(),a))}
function Ug(a){return a.e}
function wp(){return this.e}
function qp(){return this.a}
function up(){return this.b}
function Gp(a){nc(this.c,a)}
function nc(a,b){ai(a.e,b)}
function Lj(a,b){Aj(a.a,b)}
function eo(a,b){Rn(a.b,b)}
function C(a,b){Nb(a.f,b.f)}
function K(a,b){O(a);L(a,b)}
function on(a){R(a.a);$(a.b)}
function Dn(a){$(a.b);$(a.a)}
function bl(a){kb(a.b);R(a.a)}
function wl(a){kb(a.a);$(a.b)}
function il(a){a.c=2;jc(a.b)}
function Nl(a){a.f=2;jc(a.e)}
function Zk(a){a.d=2;jc(a.c)}
function sc(a,b){a.e=b;rc(a,b)}
function Il(a,b){return a.g=b}
function pi(a,b){return a.a[b]}
function rp(){return Tj(this)}
function sh(a){vc.call(this,a)}
function Vh(a){vc.call(this,a)}
function Ml(a){Sn((gn(),dn),a)}
function ic(a,b,c){_h(a.e,b,c)}
function En(a,b,c){ic(a.c,b,c)}
function hj(a,b,c){b.w(a.a[c])}
function Qj(a,b){a.splice(b,1)}
function Zc(a,b){return Ch(a,b)}
function yp(a){return this===a}
function Ap(){return this.c.i<0}
function Cp(){return this.b.i<0}
function Ip(){return this.f.i<0}
function tp(){return ci(this.a)}
function Oi(){Oi=ih;Ni=Qi()}
function Oc(){Oc=ih;Nc=new Rc}
function xc(){xc=ih;wc=new p}
function J(){J=ih;I=new F}
function Ec(){Ec=ih;!!(Vc(),Uc)}
function ah(){$g==null&&($g=[])}
function ab(a){J();Yb(a);a.e=-2}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function T(a){mb(a.f);return V(a)}
function wh(a){vh(a);return a.k}
function qn(a){fb(a.b);return a.e}
function Hn(a){fb(a.a);return a.d}
function to(a){fb(a.d);return a.e}
function zj(a,b){a.S(b);return a}
function lk(a,b){a.ref=b;return a}
function Si(){Oi();return new Ni}
function ci(a){return a.a.b+a.b.b}
function Ep(a){return 1==this.a.d}
function Fp(a){return 1==this.a.c}
function Ui(a,b){return a.a.get(b)}
function cj(a,b){while(a.db(b));}
function Aj(a,b){Ij(a,zj(a.a,b))}
function Fj(a,b,c){b.w(a.a.R(c))}
function v(a,b,c){t(a,new H(c),b)}
function Oj(a,b,c){a.splice(b,0,c)}
function Uk(a,b){Hh.call(this,a,b)}
function jk(a,b){this.a=a;this.b=b}
function hc(a,b){this.a=a;this.b=b}
function Hh(a,b){this.a=a;this.b=b}
function Hj(a,b){this.a=a;this.b=b}
function Ej(a,b){this.a=a;this.b=b}
function li(a,b){this.a=a;this.b=b}
function Fl(a,b){this.a=a;this.b=b}
function cm(a,b){this.a=a;this.b=b}
function dm(a,b){this.a=a;this.b=b}
function em(a,b){this.a=a;this.b=b}
function fm(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function Um(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function Ym(a,b){this.a=a;this.b=b}
function yn(a,b){this.a=a;this.b=b}
function Zn(a,b){this.a=a;this.b=b}
function mo(a,b){this.a=a;this.b=b}
function no(a,b){this.b=a;this.a=b}
function Db(a){this.d=a;this.b=100}
function tm(){this.a=ck((xm(),wm))}
function um(){this.a=ck((Bm(),Am))}
function Rm(){this.a=ck((Fm(),Em))}
function $m(){this.a=ck((Jm(),Im))}
function bn(){this.a=ck((Nm(),Mm))}
function rn(a){pn(a,(fb(a.b),a.e))}
function In(a){$l(a,(fb(a.a),!a.d))}
function $h(a){return !a?null:a._()}
function Tb(a){return !a.d?a:Tb(a.d)}
function nd(a){return typeof a===So}
function qd(a){return a==null?null:a}
function bj(a){return a!=null?s(a):0}
function o(a,b){return qd(a)===qd(b)}
function Jo(a,b){Hh.call(this,a,b)}
function vk(a,b){a.value=b;return a}
function qk(a,b){a.onBlur=b;return a}
function mk(a,b){a.href=b;return a}
function Rh(a,b){a.a+=''+b;return a}
function nk(a,b){a.onClick=b;return a}
function pk(a,b){a.checked=b;return a}
function Lc(a){$wnd.clearTimeout(a)}
function mi(a){a.a=_c(ie,To,1,0,5,1)}
function bi(a){a.a=new Ji;a.b=new Xi}
function ib(a){this.c=new vi;this.b=a}
function Xj(){Xj=ih;Uj=new p;Wj=new p}
function Mc(){Bc!=0&&(Bc=0);Dc=-1}
function Rl(a){kb(a.b);R(a.c);$(a.a)}
function fc(a,b){bc(a,b,false);eb(a.c)}
function ec(a,b){b.A(a);ld(b,9)&&b.t()}
function Pj(a,b){Nj(b,0,a,0,b.length)}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function Oh(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function Tj(a){return a.$H||(a.$H=++Sj)}
function pd(a){return typeof a==='string'}
function pb(a){J();ob(a);sb(a,2,true)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function ho(a,b){oi(dc(a.b),new Oo(b))}
function _j(a,b){for(var c in a){b(c)}}
function rk(a,b){a.onChange=b;return a}
function sk(a,b){a.onKeyDown=b;return a}
function ok(a){a.autoFocus=true;return a}
function vh(a){if(a.k!=null){return}Eh(a)}
function vc(a){this.g=a;qc(this);this.G()}
function yj(a,b){rj.call(this,a);this.a=b}
function Li(a,b){var c;c=a[dp];c.call(a,b)}
function so(a){var b;b=a.e;!!b&&nc(b.c,a)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function P(){this.a=_c(ie,To,1,100,5,1)}
function Mh(){Mh=ih;Lh=_c(fe,To,28,256,0,1)}
function Di(){this.a=new Ji;this.b=new Xi}
function _i(a,b){while(a.X()){Lj(b,a.Y())}}
function Xl(a){A((J(),J(),I),new im(a),ip)}
function sn(a){A((J(),J(),I),new zn(a),ip)}
function Ln(a){A((J(),J(),I),new On(a),ip)}
function go(a){A((J(),J(),I),new oo(a),ip)}
function ro(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function Vn(a){return Kh(S(a.e).a-S(a.a).a)}
function md(a){return typeof a==='boolean'}
function Fc(a,b,c){return a.apply(b,c);var d}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function qh(a,b,c,d){a.addEventListener(b,c,d)}
function $i(a,b,c){this.a=a;this.b=b;this.c=c}
function wk(a,b){a.onDoubleClick=b;return a}
function ni(a,b){a.a[a.a.length]=b;return true}
function qc(a){a.j&&a.e!==$o&&a.G();return a}
function zh(a){var b;b=yh(a);Gh(a,b);return b}
function Cb(a){while(true){if(!Bb(a)){break}}}
function fj(a,b){while(a.c<a.d){hj(a,b,a.c++)}}
function Sl(a,b){A((J(),J(),I),new hm(a,b),ip)}
function Vl(a,b){A((J(),J(),I),new em(a,b),ip)}
function Wl(a,b){A((J(),J(),I),new dm(a,b),ip)}
function Zl(a,b){A((J(),J(),I),new cm(a,b),ip)}
function xl(a,b){A((J(),J(),I),new Fl(a,b),ip)}
function Sn(a,b){A((J(),J(),I),new Zn(a,b),ip)}
function jo(a,b){A((J(),J(),I),new no(a,b),ip)}
function ko(a,b){A((J(),J(),I),new mo(a,b),ip)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function yl(a,b){var c;c=b.target;Al(a,c.value)}
function sj(a,b){var c;return wj(a,(c=new vi,c))}
function Vc(){Vc=ih;var a;!Xc();a=new Yc;Uc=a}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function $n(a,b){this.a=a;this.c=b;this.b=false}
function jj(a){if(!a.d){a.d=a.b.Q();a.c=a.b.T()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Cj(a,b,c){if(a.a.fb(c)){a.b=true;b.w(c)}}
function rh(a,b,c,d){a.removeEventListener(b,c,d)}
function Ti(a,b){return !(a.a.get(b)===undefined)}
function po(a){return o(op,a)||o(pp,a)||o('',a)}
function bd(a){return Array.isArray(a)&&a.ob===mh}
function kd(a){return !Array.isArray(a)&&a.ob===mh}
function zi(a){return new yj(null,yi(a,a.length))}
function Un(a){return th(),0!=S(a.e).a?true:false}
function yi(a,b){return dj(b,a.length),new ij(a,b)}
function cl(a){return B((J(),J(),I),a.b,new hl(a))}
function Qn(a){R(a.d);R(a.e);R(a.a);R(a.b);$(a.c)}
function Tn(a){Nh(new ji(a.g),new gc(a));bi(a.g)}
function gi(a){var b;b=a.a.Y();a.b=fi(a);return b}
function Bh(a){var b;b=yh(a);b.j=a;b.e=1;return b}
function ri(a,b){var c;c=a.a[b];Qj(a.a,b);return c}
function Sc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Yl(a){return B((J(),J(),I),a.b,new bm(a))}
function ll(a){return B((J(),J(),I),a.a,new pl(a))}
function zl(a){return B((J(),J(),I),a.a,new Dl(a))}
function nm(a){return B((J(),J(),I),a.a,new rm(a))}
function di(a,b){if(b){return Yh(a.a,b)}return false}
function ti(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Al(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function $l(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function $k(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function jl(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function Ol(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function pj(a){if(!a.b){qj(a);a.c=true}else{pj(a.b)}}
function uj(a,b){qj(a);return new yj(a,new Dj(b,a.a))}
function vj(a,b){qj(a);return new yj(a,new Gj(b,a.a))}
function pn(a,b){A((J(),J(),I),new yn(a,b),75497472)}
function Ci(a,b){return qd(a)===qd(b)||a!=null&&q(a,b)}
function nn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&Al(a,b)}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function Ah(a,b){var c;c=yh(a);Gh(a,c);c.e=b?8:0;return c}
function uk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ej(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function kj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function ij(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function rj(a){if(!a){this.b=null;new vi}else{this.b=a}}
function Dh(a){if(a.O()){return null}var b=a.j;return eh[b]}
function Zg(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function $j(){if(Vj==256){Uj=Wj;Wj=new p;Vj=0}++Vj}
function ph(){ph=ih;oh=$wnd.goog.global.document}
function xm(){xm=ih;var a;wm=(a=jh(vm.prototype.lb,vm,[]),a)}
function Bm(){Bm=ih;var a;Am=(a=jh(zm.prototype.lb,zm,[]),a)}
function Fm(){Fm=ih;var a;Em=(a=jh(Dm.prototype.lb,Dm,[]),a)}
function Jm(){Jm=ih;var a;Im=(a=jh(Hm.prototype.lb,Hm,[]),a)}
function Nm(){Nm=ih;var a;Mm=(a=jh(Lm.prototype.lb,Lm,[]),a)}
function Ko(){Io();return cd(Zc(Ig,1),To,30,0,[Fo,Ho,Go])}
function Kc(a){Ec();$wnd.setTimeout(function(){throw a},0)}
function qj(a){if(a.b){qj(a.b)}else if(a.c){throw Ug(new Ih)}}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function Hl(a,b){var c;if(S(a.c)){c=b.target;$l(a,c.value)}}
function tc(a,b){var c;c=wh(a.mb);return b==null?c:c+': '+b}
function Fi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ch(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function Nh(a,b){var c,d;for(d=a.Q();d.X();){c=d.Y();b.w(c)}}
function Zh(a,b){return b===a?'(this Map)':b==null?ap:lh(b)}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function kh(a){function b(){}
;b.prototype=a||{};return new b}
function tk(a){a.placeholder='What needs to be done?';return a}
function ln(a,b){b.preventDefault();A((J(),J(),I),new An(a),ip)}
function Tl(a,b){wo((gn(),fn),b);A((J(),J(),I),new cm(a,b),ip)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Yo)&&D((null,I))}
function jn(a){qh((ph(),$wnd.goog.global.window),lp,a.d,false)}
function kn(a){rh((ph(),$wnd.goog.global.window),lp,a.d,false)}
function lo(a){this.b=a;J();this.a=new oc(0,null,null,true,false)}
function cc(a){fb(a.c);return new yj(null,new kj(new ji(a.g),0))}
function Gi(a,b){var c;return Ei(b,Fi(a,b==null?0:(c=s(b),c|0)))}
function gh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function hk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Ic(a,b,c){var d;d=Gc();try{return Fc(a,b,c)}finally{Jc(d)}}
function mc(a){kc(a.g);!!a.e&&lc(a);Y(a.a);Y(a.c);kc(a.b);kc(a.f)}
function wi(a){mi(this);Pj(this.a,Xh(a,_c(ie,To,1,ci(a.a),5,1)))}
function Ki(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function ym(a){$wnd.React.Component.call(this,a);this.a=new dl(this)}
function Cm(a){$wnd.React.Component.call(this,a);this.a=new ml(this)}
function Gm(a){$wnd.React.Component.call(this,a);this.a=new Bl(this)}
function Km(a){$wnd.React.Component.call(this,a);this.a=new _l(this)}
function Om(a){$wnd.React.Component.call(this,a);this.a=new om(this)}
function Gj(a,b){ej.call(this,b.cb(),b.bb()&-6);this.a=a;this.b=b}
function Dj(a,b){ej.call(this,b.cb(),b.bb()&-16449);this.a=a;this.c=b}
function bb(a,b){var c,d;ni(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function ai(a,b){return pd(b)?b==null?Ii(a.a,null):Wi(a.b,b):Ii(a.a,b)}
function lj(a,b){!a.a?(a.a=new Th(a.d)):Rh(a.a,a.b);Rh(a.a,b);return a}
function gj(a,b){if(a.c<a.d){hj(a,b,a.c++);return true}return false}
function uc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function tj(a){var b;pj(a);b=0;while(a.a.db(new Kj)){b=Vg(b,1)}return b}
function wj(a,b){var c;pj(a);c=new Jj;c.a=b;a.a.W(new Mj(c));return c.a}
function Rn(a,b){var c;return u((J(),J(),I),new $n(a,b),ip,(c=null,c))}
function Hc(b){Ec();return function(){return Ic(b,this,arguments);var a}}
function Ac(){if(Date.now){return Date.now()}return (new Date).getTime()}
function io(a){sj(uj(cc(a.b),new Mo),new oj(new nj)).P(new No(a.b))}
function gn(){gn=ih;dn=new Wn;en=new lo(dn);cn=new un;fn=new xo(dn,cn)}
function xj(a,b){var c;c=sj(a,new oj(new nj));return ui(c,b.eb(c.a.length))}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function oi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Yi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function hi(a){this.d=a;this.c=new Yi(this.d.b);this.a=this.c;this.b=fi(this)}
function mj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function qo(a,b){return (Io(),Go)==a||(Fo==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function _h(a,b,c){return pd(b)?b==null?Hi(a.a,null,c):Vi(a.b,b,c):Hi(a.a,b,c)}
function Rj(a,b){return $c(b)!=10&&cd(r(b),b.nb,b.__elementTypeId$,$c(b),a),a}
function Ul(a){return th(),to((gn(),fn))==a.j.props['a']?true:false}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Jc(a){a&&Qc((Oc(),Nc));--Bc;if(a){if(Dc!=-1){Lc(Dc);Dc=-1}}}
function Ib(b){try{mb(b.b.a)}catch(a){a=Tg(a);if(!ld(a,4))throw Ug(a)}}
function hn(a,b){a.f=b;o(b,S(a.a))&&Al(a,b);mn(b);A((J(),J(),I),new An(a),ip)}
function uo(a){var b;return b=S(a.b),sj(uj(cc(a.i),new Po(b)),new oj(new nj))}
function jc(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new pc(a)),67108864,null)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function Zi(a){if(a.a.c!=a.c){return Ui(a.a,a.b.value[0])}return a.b.value[1]}
function Fn(a,b){var c;if(ld(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function si(a,b){var c;c=qi(a,b,0);if(c==-1){return false}Qj(a.a,c);return true}
function _c(a,b,c,d,e,f){var g;g=ad(e,d);e!=10&&cd(Zc(a,f),b,c,e,g);return g}
function qi(a,b,c){for(;c<a.a.length;++c){if(Ci(b,a.a[c])){return c}}return -1}
function V(a){if(a.b){if(ld(a.b,8)){throw Ug(a.b)}else{throw Ug(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=Tg(a);if(ld(a,4)){J()}else throw Ug(a)}}}
function rl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new El(a),ip)}}
function ql(a){var b;b=Qh((fb(a.b),a.e));if(b.length>0){eo((gn(),en),b);Al(a,'')}}
function Qc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Tc(b,c)}while(a.b);a.b=c}}
function Pc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Tc(b,c)}while(a.a);a.a=c}}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new vi);ni(a.b,b)}}}
function Ob(){var a;this.a=_c(wd,To,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function fk(a){var b;return dk($wnd.React.StrictMode,null,null,(b={},b[ep]=a,b))}
function $c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===Ro||typeof a==='function')&&!(a.ob===mh)}
function dh(a,b){typeof window===Ro&&typeof window['$gwt']===Ro&&(window['$gwt'][a]=b)}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Zo:0)|(0!=(b&229376)?0:98304)}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new vi);a.c=c.c}b.d=true;ni(a.c,b)}
function Gh(a,b){var c;if(!a){return}b.j=a;var d=Dh(b);if(!d){eh[a]=[b];return}d.mb=b}
function jh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function dk(a,b,c,d){var e;e=ek($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function ck(a){var b;b=ek($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function yh(a){var b;b=new xh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Ai(a){var b,c,d;d=0;for(c=new hi(a.a);c.b;){b=gi(c);d=d+(b?s(b):0);d=d|0}return d}
function ob(a){var b,c;for(c=new xi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function _g(){ah();var a=$g;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Ih(){vc.call(this,"Stream already terminated, can't be modified or used")}
function dc(a){return fb(a.c),sj(new yj(null,new kj(new ji(a.g),0)),new oj(new nj))}
function Io(){Io=ih;Fo=new Jo('ACTIVE',0);Ho=new Jo('COMPLETED',1);Go=new Jo('ALL',2)}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function Pn(a,b,c){var d;d=new Mn(b,c);En(d,a,new hc(a,d));_h(a.g,Kh(d.c.d),d);eb(a.c);return d}
function Wi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Li(a.a,b);--a.b}return c}
function Wh(a,b){var c,d;for(d=new hi(b.a);d.b;){c=gi(d);if(!di(a,c)){return false}}return true}
function Zm(a,b){bk(a.a,(b?Kh(b.c.d):null)+(''+(vh(Zf),Zf.k)));a.a.props['a']=b;return a.a}
function bc(a,b,c){var d;d=ai(a.g,b?Kh(b.c.d):null);if(null!=d){nc(b.c,a);c&&!!b&&jc(b.c);eb(a.c)}}
function vo(a){var b;b=S(a.g.a);o(op,b)||o(pp,b)||o('',b)?pn(a.g,b):po(qn(a.g))?sn(a.g):pn(a.g,'')}
function Wg(a){var b;b=a.h;if(b==0){return a.l+a.m*Zo}if(b==1048575){return a.l+a.m*Zo-bp}return a}
function Tg(a){var b;if(ld(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new zc(a);Wc(b)}return b}
function fi(a){if(a.a.X()){return true}if(a.a!=a.c){return false}a.a=new Ki(a.d.a);return a.a.X()}
function dj(a,b){if(0>a||a>b){throw Ug(new sh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:Vo)|(0==(c&6291456)?!a?Yo:Zo:0)|0|0|0)}
function Jl(a,b,c){27==c.which?A((J(),J(),I),new fm(a,b),ip):13==c.which&&A((J(),J(),I),new dm(a,b),ip)}
function wo(a,b){var c;c=a.e;if(!(b==c||!!b&&Fn(b,c))){!!c&&nc(c.c,a);a.e=b;!!b&&En(b,a,new Co(a));eb(a.d)}}
function Vi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function cd(a,b,c,d,e){e.mb=a;e.nb=b;e.ob=mh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ei(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ci(a,c.$())){return c}}return null}
function Yg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=bp;d=1048575}c=rd(e/Zo);b=rd(e-c*Zo);return dd(b,c,d)}
function Kh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Mh(),Lh)[b];!c&&(c=Lh[b]=new Jh(a));return c}return new Jh(a)}
function zc(a){xc();qc(this);this.e=a;rc(this,a);this.g=a==null?ap:lh(a);this.a='';this.b=a;this.a=''}
function xh(){this.g=uh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function nh(){gn();$wnd.ReactDOM.render(fk([(new bn).a]),(ph(),oh).getElementById('app'),null)}
function Xk(){if(!Wk){Wk=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(jh(Yk.prototype.I,Yk,[]))}}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Vo)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function cb(a,b){var c,d;d=a.c;si(d,b);!!a.b&&Vo!=(a.b.c&Wo)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function Kl(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){jo((gn(),b),c);wo(fn,null);$l(a,c)}else{Sn((gn(),dn),b)}}
function Ll(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Zl(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function ml(a){var b;this.j=a;J();b=++kl;this.b=new oc(b,null,new nl(this),false,false);this.a=new vb(null,new ol(this),hp)}
function om(a){var b;this.j=a;J();b=++mm;this.b=new oc(b,null,new pm(this),false,false);this.a=new vb(null,new qm(this),hp)}
function lh(a){var b;if(Array.isArray(a)&&a.ob===mh){return wh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function Zj(a){Xj();var b,c,d;c=':'+a;d=Wj[c];if(d!=null){return rd(d)}d=Uj[c];b=d==null?Yj(a):rd(d);$j();Wj[c]=b;return b}
function Bi(a){var b,c,d;d=1;for(c=new xi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=ri(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function lc(a){var b,c,d;for(c=new xi(new wi(new ei(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.$();ld(d,9)&&d.u()||b._().v()}}
function r(a){return pd(a)?le:nd(a)?ae:md(a)?$d:kd(a)?a.mb:bd(a)?a.mb:a.mb||Array.isArray(a)&&Zc(Sd,1)||Sd}
function s(a){return pd(a)?Zj(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.q():bd(a)?Tj(a):!!a&&!!a.hashCode?a.hashCode():Tj(a)}
function q(a,b){return pd(a)?o(a,b):nd(a)?qd(a)===qd(b):md(a)?qd(a)===qd(b):kd(a)?a.o(b):bd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function Vk(){Tk();return cd(Zc(cf,1),To,6,0,[xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk])}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(Vo==(b&Wo)?0:524288)|(0==(b&6291456)?Vo==(b&Wo)?Zo:Yo:0)|0|268435456|0)}
function Vg(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<bp){return c}}return Wg(ed(nd(a)?Yg(a):a,nd(b)?Yg(b):b))}
function Fh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function ui(a,b){var c,d;d=a.a.length;b.length<d&&(b=Rj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Gc(){var a;if(Bc!=0){a=Ac();if(a-Cc>2000){Cc=a;Dc=$wnd.setTimeout(Mc,10)}}if(Bc++==0){Pc((Oc(),Nc));return true}return false}
function Xc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.nb){return !!a.nb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function oc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Di:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Bl(a){var b,c,d;this.j=a;J();b=++vl;this.c=new oc(b,null,new Cl(this),false,false);this.b=(d=new ib((c=null,c)),d);this.a=new vb(null,new Gl(this),hp)}
function dl(a){var b;this.j=a;J();b=++al;this.c=new oc(b,null,new el(this),false,false);this.a=new W(new fl,null,null,136478720);this.b=new vb(null,new gl(this),hp)}
function kk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new xi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new xi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new xi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Qh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Xh(a,b){var c,d,e,f;f=ci(a.a);b.length<f&&(b=Rj(new Array(f),b));e=b;d=new hi(a.a);for(c=0;c<f;++c){e[c]=gi(d)}b.length>f&&(b[f]=null);return b}
function ad(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=Tg(a);if(ld(a,4)){e=a;throw Ug(e)}else throw Ug(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=Tg(a);if(ld(a,4)){f=a;throw Ug(f)}else throw Ug(a)}finally{D(b)}}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function bh(b,c,d,e){ah();var f=$g;$moduleName=c;$moduleBase=d;Sg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Qo(g)()}catch(a){b(c,a)}}else{Qo(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);Vo==(d&Wo)&&lb(this.f)}
function ek(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Mn(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++Cn;this.c=new oc(c,null,new Nn(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Qi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ri()}}
function fh(){eh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Tc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].pb()&&(c=Sc(c,g)):g[0].pb()}catch(a){a=Tg(a);if(ld(a,4)){d=a;Ec();Kc(ld(d,34)?d.H():d)}else throw Ug(a)}}return c}
function ul(a){var b;a.d=0;Xk();b=gk(jp,ok(rk(sk(vk(tk(kk(new $wnd.Object,cd(Zc(le,1),To,2,6,['new-todo']))),(fb(a.b),a.e)),jh(Pm.prototype.jb,Pm,[a])),jh(Qm.prototype.ib,Qm,[a]))),null);return b}
function yc(a){var b;if(a.c==null){b=qd(a.b)===qd(wc)?null:a.b;a.d=b==null?ap:od(b)?b==null?null:b.name:pd(b)?'String':wh(r(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(qd(e)===qd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=Tg(a);if(ld(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw Ug(c)}else throw Ug(a)}}
function Nj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Hi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ei(b,e);if(f){return f.ab(c)}}e[e.length]=new li(b,c);++a.b;return null}
function Yj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Oh(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Tg(a);if(ld(a,4)){J()}else throw Ug(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=_c(ie,To,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function ub(a,b,c,d){this.b=new vi;this.f=new Jb(new yb(this),d&6520832|262144|Vo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Yo)&&D((null,I)))}
function Ii(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ci(b,e.$())){if(d.length==1){d.length=0;Li(a.a,g)}else{d.splice(h,1)}--a.b;return e._()}}return null}
function _l(a){var b,c,d;this.j=a;J();b=++Ql;this.e=new oc(b,null,new am(this),false,false);this.a=(d=new ib((c=null,c)),d);this.c=new W(new gm(this),null,null,136478720);this.b=new vb(null,new jm(this),hp);Zl(this,this.j.props['a'])}
function hh(a,b,c){var d=eh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=eh[b]),kh(h));_.nb=c;!b&&(_.ob=mh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.mb=f)}
function Eh(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Fh('.',[c,Fh('$',d)]);a.b=Fh('.',[c,Fh('.',d)]);a.i=d[d.length-1]}
function Yh(a,b){var c,d,e;c=b.$();e=b._();d=pd(c)?c==null?$h(Gi(a.a,null)):Ui(a.b,c):$h(Gi(a.a,c));if(!(qd(e)===qd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Gi(a.a,null):Ti(a.b,c):!!Gi(a.a,c))){return false}return true}
function mn(a){var b;if(0==a.length){b=(ph(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',oh.title,b)}else{(ph(),$wnd.goog.global.window).location.hash=a}}
function gk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ak(b,jh(jk.prototype.gb,jk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[ep]=c[0],undefined):(d[ep]=c,undefined));return dk(a,e,f,d)}
function un(){var a,b,c;this.d=new Eo(this);this.f=this.e=(c=(ph(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new oc(0,null,new vn(this),true,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new Bn,new wn(this),new xn(this),35651584)}
function xo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new oc(0,new yo(this),new zo(this),true,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new Do(this),null,null,np);this.c=new W(new Ao(this),null,null,np);this.a=new vb(new Bo(this),null,681574400);D((null,I))}
function Wn(){var a;this.g=new Di;J();this.f=new oc(0,new Yn(this),new Xn(this),false,false);this.c=(a=new ib(null),a);this.d=new W(new _n(this),null,null,np);this.e=new W(new ao(this),null,null,np);this.a=new W(new bo(this),null,null,np);this.b=new W(new co(this),null,null,np)}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new xi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Tg(a);if(!ld(a,4))throw Ug(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function rc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function Pi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}oi(a.b,new Ab(a));a.b.a=_c(ie,To,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Tk(){Tk=ih;xk=new Uk(fp,0);yk=new Uk('checkbox',1);zk=new Uk('color',2);Ak=new Uk('date',3);Bk=new Uk('datetime',4);Ck=new Uk('email',5);Dk=new Uk('file',6);Ek=new Uk('hidden',7);Fk=new Uk('image',8);Gk=new Uk('month',9);Hk=new Uk(So,10);Ik=new Uk('password',11);Jk=new Uk('radio',12);Kk=new Uk('range',13);Lk=new Uk('reset',14);Mk=new Uk('search',15);Nk=new Uk('submit',16);Ok=new Uk('tel',17);Pk=new Uk('text',18);Qk=new Uk('time',19);Rk=new Uk('url',20);Sk=new Uk('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=pi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ti(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=pi(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ri(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new vi)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Vo!=(k.b.c&Wo)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function _k(a){var b,c;a.d=0;Xk();c=(b=S((gn(),fn).b),gk('footer',kk(new $wnd.Object,cd(Zc(le,1),To,2,6,['footer'])),[(new um).a,gk('ul',kk(new $wnd.Object,cd(Zc(le,1),To,2,6,['filters'])),[gk('li',null,[gk('a',mk(kk(new $wnd.Object,cd(Zc(le,1),To,2,6,[(Io(),Go)==b?gp:null])),'#'),['All'])]),gk('li',null,[gk('a',mk(kk(new $wnd.Object,cd(Zc(le,1),To,2,6,[Fo==b?gp:null])),'#active'),['Active'])]),gk('li',null,[gk('a',mk(kk(new $wnd.Object,cd(Zc(le,1),To,2,6,[Ho==b?gp:null])),'#completed'),['Completed'])])]),S(a.a)?gk(fp,nk(kk(new $wnd.Object,cd(Zc(le,1),To,2,6,['clear-completed'])),jh(sm.prototype.kb,sm,[])),['Clear Completed']):null]));return c}
function Pl(a){var b,c,d,e;a.f=0;Xk();b=a.j.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.j.props['a'],e=(fb(d.a),d.d),gk('li',kk(new $wnd.Object,cd(Zc(le,1),To,2,6,[e?'checked':null,S(a.c)?'editing':null])),[gk('div',kk(new $wnd.Object,cd(Zc(le,1),To,2,6,['view'])),[gk(jp,rk(pk(uk(kk(new $wnd.Object,cd(Zc(le,1),To,2,6,['toggle'])),(Tk(),yk)),e),jh(Tm.prototype.ib,Tm,[d])),null),gk('label',wk(new $wnd.Object,jh(Um.prototype.kb,Um,[a,d])),[(fb(d.b),d.e)]),gk(fp,nk(kk(new $wnd.Object,cd(Zc(le,1),To,2,6,['destroy'])),jh(Vm.prototype.kb,Vm,[d])),null)]),gk(jp,sk(rk(qk(vk(kk(lk(new $wnd.Object,jh(Wm.prototype.w,Wm,[a])),cd(Zc(le,1),To,2,6,['edit'])),(fb(a.a),a.d)),jh(Xm.prototype.hb,Xm,[a,d])),jh(Sm.prototype.ib,Sm,[a])),jh(Ym.prototype.jb,Ym,[a,d])),null)]));return c}
function Ri(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[dp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Pi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[dp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Ro='object',So='number',To={3:1},Uo={9:1},Vo=1048576,Wo=1835008,Xo={5:1},Yo=2097152,Zo=4194304,$o='__noinit__',_o={3:1,10:1,8:1,4:1},ap='null',bp=17592186044416,cp={40:1},dp='delete',ep='children',fp='button',gp='selected',hp=1411518464,ip=142606336,jp='input',kp='header',lp='hashchange',mp={9:1,62:1},np=136314880,op='active',pp='completed';var _,eh,$g,Sg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;fh();hh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.mb};_.q=rp;_.r=function(){var a;return wh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var fd,gd,hd;hh(50,1,{},xh);_.J=function(a){var b;b=new xh;b.e=4;a>1?(b.c=Ch(this,a-1)):(b.c=this);return b};_.K=function(){vh(this);return this.b};_.L=function(){return wh(this)};_.M=function(){vh(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(vh(this),this.k)};_.e=0;_.g=0;var uh=1;var ie=zh(1);var _d=zh(50);hh(79,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var vd=zh(79);hh(35,1,{},G);_.s=function(){return this.a.v(),null};var td=zh(35);hh(80,1,{},H);var ud=zh(80);var I;hh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var wd=zh(43);hh(215,1,Uo);_.r=function(){var a;return wh(this.mb)+'@'+(a=s(this)>>>0,a.toString(16))};var zd=zh(215);hh(18,215,Uo,W);_.t=function(){R(this)};_.u=qp;_.a=false;_.d=0;_.k=false;var yd=zh(18);hh(124,1,{},X);_.s=function(){return T(this.a)};var xd=zh(124);hh(15,215,{9:1,15:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Bd=zh(15);hh(123,1,Xo,jb);_.v=function(){ab(this.a)};var Ad=zh(123);hh(16,215,{9:1,16:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Gd=zh(16);hh(125,1,{},xb);_.v=function(){Q(this.a)};var Cd=zh(125);hh(126,1,Xo,yb);_.v=function(){mb(this.a)};var Dd=zh(126);hh(127,1,Xo,zb);_.v=function(){pb(this.a)};var Ed=zh(127);hh(128,1,{},Ab);_.w=function(a){nb(this.a,a)};var Fd=zh(128);hh(133,1,{},Db);_.a=0;_.b=0;_.c=0;var Hd=zh(133);hh(160,1,Uo,Fb);_.t=function(){Eb(this)};_.u=qp;_.a=false;var Id=zh(160);hh(58,215,{9:1,58:1},Jb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Kd=zh(58);hh(138,1,{},Ob);var Jd=zh(138);hh(140,1,{},$b);_.r=function(){var a;return vh(Ld),Ld.k+'@'+(a=Tj(this)>>>0,a.toString(16))};_.a=0;var Pb;var Ld=zh(140);hh(111,1,{});var Od=zh(111);hh(82,1,{},gc);_.w=function(a){ec(this.a,a)};var Md=zh(82);hh(83,1,Xo,hc);_.v=function(){fc(this.a,this.b)};var Nd=zh(83);hh(14,1,Uo,oc);_.t=function(){jc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return vh(Qd),Qd.k+'@'+(a=Tj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Qd=zh(14);hh(122,1,Xo,pc);_.v=function(){mc(this.a)};var Pd=zh(122);hh(4,1,{3:1,4:1});_.B=wp;_.C=function(){return xj(vj(zi((this.i==null&&(this.i=_c(ne,To,4,0,0,1)),this.i)),new Uh),new Bj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){sc(this,uc(new Error(tc(this,this.g))));Wc(this)};_.r=function(){return tc(this,this.F())};_.e=$o;_.j=true;var ne=zh(4);hh(10,4,{3:1,10:1,4:1});var ce=zh(10);hh(8,10,_o);var je=zh(8);hh(72,8,_o);var ge=zh(72);hh(73,72,_o);var Ud=zh(73);hh(34,73,{34:1,3:1,10:1,8:1,4:1},zc);_.F=function(){yc(this);return this.c};_.H=function(){return qd(this.b)===qd(wc)?null:this.b};var wc;var Rd=zh(34);var Sd=zh(0);hh(201,1,{});var Td=zh(201);var Bc=0,Cc=0,Dc=-1;hh(110,201,{},Rc);var Nc;var Vd=zh(110);var Uc;hh(212,1,{});var Xd=zh(212);hh(74,212,{},Yc);var Wd=zh(74);var oh;hh(70,1,{67:1});_.r=qp;var Yd=zh(70);hh(76,8,_o);var ee=zh(76);hh(156,76,_o,sh);var Zd=zh(156);fd={3:1,68:1,27:1};var $d=zh(68);hh(41,1,{3:1,41:1});var he=zh(41);gd={3:1,27:1,41:1};var ae=zh(211);hh(29,1,{3:1,27:1,29:1});_.o=yp;_.q=rp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=zh(29);hh(75,8,_o,Ih);var de=zh(75);hh(28,41,{3:1,27:1,28:1,41:1},Jh);_.o=function(a){return ld(a,28)&&a.a==this.a};_.q=qp;_.r=function(){return ''+this.a};_.a=0;var fe=zh(28);var Lh;hh(278,1,{});hd={3:1,67:1,27:1,2:1};var le=zh(2);hh(71,70,{67:1},Th);var ke=zh(71);hh(282,1,{});hh(65,1,{},Uh);_.R=function(a){return a.e};var me=zh(65);hh(52,8,_o,Vh);var oe=zh(52);hh(213,1,{39:1});_.P=vp;_.U=function(){return new kj(this,0)};_.V=function(){return new yj(null,this.U())};_.S=function(a){throw Ug(new Vh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new mj('[',']');for(b=this.Q();b.X();){a=b.Y();lj(c,a===this?'(this Collection)':a==null?ap:lh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=zh(213);hh(216,1,{199:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ld(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new hi((new ei(d)).a);c.b;){b=gi(c);if(!Yh(this,b)){return false}}return true};_.q=function(){return Ai(new ei(this))};_.r=function(){var a,b,c;c=new mj('{','}');for(b=new hi((new ei(this)).a);b.b;){a=gi(b);lj(c,Zh(this,a.$())+'='+Zh(this,a._()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=zh(216);hh(129,216,{199:1});var se=zh(129);hh(217,213,{39:1,227:1});_.U=function(){return new kj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ld(a,21)){return false}b=a;if(ci(b.a)!=this.T()){return false}return Wh(this,b)};_.q=function(){return Ai(this)};var Be=zh(217);hh(21,217,{21:1,39:1,227:1},ei);_.Q=function(){return new hi(this.a)};_.T=tp;var re=zh(21);hh(22,1,{},hi);_.W=sp;_.Y=function(){return gi(this)};_.X=up;_.b=false;var qe=zh(22);hh(214,213,{39:1,224:1});_.U=function(){return new kj(this,16)};_.Z=function(a,b){throw Ug(new Vh('Add not supported on this list'))};_.S=function(a){this.Z(this.T(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,13)){return false}f=a;if(this.T()!=f.a.length){return false}e=new xi(f);for(c=new xi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Bi(this)};_.Q=function(){return new ii(this)};var ue=zh(214);hh(109,1,{},ii);_.W=sp;_.X=function(){return this.a<this.b.a.length};_.Y=function(){return pi(this.b,this.a++)};_.a=0;var te=zh(109);hh(42,213,{39:1},ji);_.Q=function(){var a;a=new hi((new ei(this.a)).a);return new ki(a)};_.T=tp;var we=zh(42);hh(132,1,{},ki);_.W=sp;_.X=function(){return this.a.b};_.Y=function(){var a;a=gi(this.a);return a._()};var ve=zh(132);hh(130,1,cp);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Ci(this.a,b.$())&&Ci(this.b,b._())};_.$=qp;_._=up;_.q=function(){return bj(this.a)^bj(this.b)};_.ab=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var xe=zh(130);hh(131,130,cp,li);var ye=zh(131);hh(218,1,cp);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Ci(this.b.value[0],b.$())&&Ci(Zi(this),b._())};_.q=function(){return bj(this.b.value[0])^bj(Zi(this))};_.r=function(){return this.b.value[0]+'='+Zi(this)};var ze=zh(218);hh(13,214,{3:1,13:1,39:1,224:1},vi,wi);_.Z=function(a,b){Oj(this.a,a,b)};_.S=function(a){return ni(this,a)};_.P=function(a){oi(this,a)};_.Q=function(){return new xi(this)};_.T=function(){return this.a.length};var De=zh(13);hh(17,1,{},xi);_.W=sp;_.X=function(){return this.a<this.c.a.length};_.Y=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=zh(17);hh(36,129,{3:1,36:1,199:1},Di);var Ee=zh(36);hh(56,1,{},Ji);_.P=vp;_.Q=function(){return new Ki(this)};_.b=0;var Ge=zh(56);hh(57,1,{},Ki);_.W=sp;_.Y=function(){return this.d=this.a[this.c++],this.d};_.X=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=zh(57);var Ni;hh(54,1,{},Xi);_.P=vp;_.Q=function(){return new Yi(this)};_.b=0;_.c=0;var Je=zh(54);hh(55,1,{},Yi);_.W=sp;_.Y=function(){return this.c=this.a,this.a=this.b.next(),new $i(this.d,this.c,this.d.c)};_.X=function(){return !this.a.done};var He=zh(55);hh(139,218,cp,$i);_.$=function(){return this.b.value[0]};_._=function(){return Zi(this)};_.ab=function(a){return Vi(this.a,this.b.value[0],a)};_.c=0;var Ie=zh(139);hh(142,1,{});_.W=xp;_.bb=function(){return this.d};_.cb=wp;_.d=0;_.e=0;var Ne=zh(142);hh(59,142,{});var Ke=zh(59);hh(134,1,{});_.W=xp;_.bb=up;_.cb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Me=zh(134);hh(135,134,{},ij);_.W=function(a){fj(this,a)};_.db=function(a){return gj(this,a)};var Le=zh(135);hh(19,1,{},kj);_.bb=qp;_.cb=function(){jj(this);return this.c};_.W=function(a){jj(this);this.d.W(a)};_.db=function(a){jj(this);if(this.d.X()){a.w(this.d.Y());return true}return false};_.a=0;_.c=0;var Oe=zh(19);hh(51,1,{},mj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Pe=zh(51);hh(33,1,{},nj);_.R=function(a){return a};var Qe=zh(33);hh(37,1,{},oj);var Re=zh(37);hh(141,1,{});_.c=false;var _e=zh(141);hh(23,141,{},yj);var $e=zh(23);hh(66,1,{},Bj);_.eb=function(a){return _c(ie,To,1,a,5,1)};var Se=zh(66);hh(144,59,{},Dj);_.db=function(a){this.b=false;while(!this.b&&this.c.db(new Ej(this,a)));return this.b};_.b=false;var Ue=zh(144);hh(147,1,{},Ej);_.w=function(a){Cj(this.a,this.b,a)};var Te=zh(147);hh(143,59,{},Gj);_.db=function(a){return this.b.db(new Hj(this,a))};var We=zh(143);hh(146,1,{},Hj);_.w=function(a){Fj(this.a,this.b,a)};var Ve=zh(146);hh(145,1,{},Jj);_.w=function(a){Ij(this,a)};var Xe=zh(145);hh(148,1,{},Kj);_.w=function(a){};var Ye=zh(148);hh(149,1,{},Mj);_.w=function(a){Lj(this,a)};var Ze=zh(149);hh(280,1,{});hh(277,1,{});var Sj=0;var Uj,Vj=0,Wj;hh(897,1,{});hh(919,1,{});hh(219,1,{});var af=zh(219);hh(157,1,{},ik);_.eb=function(a){return new Array(a)};var bf=zh(157);hh(245,$wnd.Function,{},jk);_.gb=function(a){hk(this.a,this.b,a)};hh(6,29,{3:1,27:1,29:1,6:1},Uk);var xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk;var cf=Ah(6,Vk);var Wk;hh(246,$wnd.Function,{},Yk);_.I=function(a){return Eb(Wk),Wk=null,null};hh(222,219,{});var Lf=zh(222);hh(173,222,{});_.d=0;var Pf=zh(173);hh(174,173,Uo,dl);_.t=zp;_.o=yp;_.q=rp;_.u=Ap;_.r=function(){var a;return vh(mf),mf.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var al=0;var mf=zh(174);hh(175,1,Xo,el);_.v=function(){bl(this.a)};var df=zh(175);hh(176,1,{},fl);_.s=function(){return th(),S((gn(),dn).b).a>0?true:false};var ef=zh(176);hh(177,1,{},gl);_.v=function(){$k(this.a)};var ff=zh(177);hh(178,1,{},hl);_.s=function(){return _k(this.a)};var gf=zh(178);hh(223,219,{});var Kf=zh(223);hh(193,223,{});_.c=0;var Of=zh(193);hh(194,193,Uo,ml);_.t=Bp;_.o=yp;_.q=rp;_.u=Cp;_.r=function(){var a;return vh(lf),lf.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var kl=0;var lf=zh(194);hh(195,1,Xo,nl);_.v=Dp;var hf=zh(195);hh(196,1,{},ol);_.v=function(){jl(this.a)};var jf=zh(196);hh(197,1,{},pl);_.s=function(){var a,b;return this.a.c=0,Xk(),a=S((gn(),dn).e).a,b='item'+(a==1?'':'s'),gk('span',kk(new $wnd.Object,cd(Zc(le,1),To,2,6,['todo-count'])),[gk('strong',null,[a]),' '+b+' left'])};var kf=zh(197);hh(165,219,{});_.e='';var Xf=zh(165);hh(166,165,{});_.d=0;var Rf=zh(166);hh(167,166,Uo,Bl);_.t=zp;_.o=yp;_.q=rp;_.u=Ap;_.r=function(){var a;return vh(sf),sf.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var vl=0;var sf=zh(167);hh(168,1,Xo,Cl);_.v=function(){wl(this.a)};var nf=zh(168);hh(170,1,{},Dl);_.s=function(){return ul(this.a)};var of=zh(170);hh(171,1,Xo,El);_.v=function(){ql(this.a)};var pf=zh(171);hh(172,1,Xo,Fl);_.v=function(){yl(this.a,this.b)};var qf=zh(172);hh(169,1,{},Gl);_.v=function(){$k(this.a)};var rf=zh(169);hh(221,219,{});_.i=false;var Zf=zh(221);hh(180,221,{});_.f=0;var Tf=zh(180);hh(181,180,Uo,_l);_.t=function(){jc(this.e)};_.o=yp;_.q=rp;_.u=function(){return this.e.i<0};_.r=function(){var a;return vh(Df),Df.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var Ql=0;var Df=zh(181);hh(182,1,Xo,am);_.v=function(){Rl(this.a)};var tf=zh(182);hh(185,1,{},bm);_.s=function(){return Pl(this.a)};var uf=zh(185);hh(60,1,Xo,cm);_.v=function(){$l(this.a,qn(this.b))};var vf=zh(60);hh(61,1,Xo,dm);_.v=function(){Kl(this.a,this.b)};var wf=zh(61);hh(186,1,Xo,em);_.v=function(){Tl(this.a,this.b)};var xf=zh(186);hh(187,1,Xo,fm);_.v=function(){Zl(this.a,this.b);wo((gn(),fn),null)};var yf=zh(187);hh(183,1,{},gm);_.s=function(){return Ul(this.a)};var zf=zh(183);hh(188,1,Xo,hm);_.v=function(){Hl(this.a,this.b)};var Af=zh(188);hh(189,1,Xo,im);_.v=function(){Ll(this.a)};var Bf=zh(189);hh(184,1,{},jm);_.v=function(){Ol(this.a)};var Cf=zh(184);hh(220,219,{});var ag=zh(220);hh(151,220,{});_.c=0;var Vf=zh(151);hh(152,151,Uo,om);_.t=Bp;_.o=yp;_.q=rp;_.u=Cp;_.r=function(){var a;return vh(Hf),Hf.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var mm=0;var Hf=zh(152);hh(153,1,Xo,pm);_.v=Dp;var Ef=zh(153);hh(154,1,{},qm);_.v=function(){jl(this.a)};var Ff=zh(154);hh(155,1,{},rm);_.s=function(){return this.a.c=0,Xk(),gk('div',null,[gk('div',null,[gk(kp,kk(new $wnd.Object,cd(Zc(le,1),To,2,6,[kp])),[gk('h1',null,['todos']),(new Rm).a]),S((gn(),dn).d)?gk('section',kk(new $wnd.Object,cd(Zc(le,1),To,2,6,[kp])),[gk(jp,rk(uk(kk(new $wnd.Object,cd(Zc(le,1),To,2,6,['toggle-all'])),(Tk(),yk)),jh(_m.prototype.ib,_m,[])),null),gk('ul',kk(new $wnd.Object,cd(Zc(le,1),To,2,6,['todo-list'])),xj(vj(S(fn.c).V(),new an),new ik))]):null,S(dn.d)?(new tm).a:null])])};var Gf=zh(155);hh(250,$wnd.Function,{},sm);_.kb=function(a){go((gn(),en))};hh(159,1,{},tm);var If=zh(159);hh(179,1,{},um);var Jf=zh(179);hh(251,$wnd.Function,{},vm);_.lb=function(a){return new ym(a)};var wm;hh(163,$wnd.React.Component,{},ym);gh(eh[1],_);_.componentWillUnmount=function(){Zk(this.a)};_.render=function(){return cl(this.a)};_.shouldComponentUpdate=Ep;var Mf=zh(163);hh(261,$wnd.Function,{},zm);_.lb=function(a){return new Cm(a)};var Am;hh(190,$wnd.React.Component,{},Cm);gh(eh[1],_);_.componentWillUnmount=function(){il(this.a)};_.render=function(){return ll(this.a)};_.shouldComponentUpdate=Fp;var Nf=zh(190);hh(249,$wnd.Function,{},Dm);_.lb=function(a){return new Gm(a)};var Em;hh(162,$wnd.React.Component,{},Gm);gh(eh[1],_);_.componentWillUnmount=function(){Zk(this.a)};_.render=function(){return zl(this.a)};_.shouldComponentUpdate=Ep;var Qf=zh(162);hh(252,$wnd.Function,{},Hm);_.lb=function(a){return new Km(a)};var Im;hh(164,$wnd.React.Component,{},Km);gh(eh[1],_);_.componentDidUpdate=function(a){Xl(this.a)};_.componentWillUnmount=function(){Nl(this.a)};_.render=function(){return Yl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Sf=zh(164);hh(244,$wnd.Function,{},Lm);_.lb=function(a){return new Om(a)};var Mm;hh(136,$wnd.React.Component,{},Om);gh(eh[1],_);_.componentWillUnmount=function(){il(this.a)};_.render=function(){return nm(this.a)};_.shouldComponentUpdate=Fp;var Uf=zh(136);hh(247,$wnd.Function,{},Pm);_.jb=function(a){rl(this.a,a)};hh(248,$wnd.Function,{},Qm);_.ib=function(a){xl(this.a,a)};hh(158,1,{},Rm);var Wf=zh(158);hh(259,$wnd.Function,{},Sm);_.ib=function(a){Sl(this.a,a)};hh(253,$wnd.Function,{},Tm);_.ib=function(a){Ln(this.a)};hh(255,$wnd.Function,{},Um);_.kb=function(a){Vl(this.a,this.b)};hh(256,$wnd.Function,{},Vm);_.kb=function(a){Ml(this.a)};hh(257,$wnd.Function,{},Wm);_.w=function(a){Il(this.a,a)};hh(258,$wnd.Function,{},Xm);_.hb=function(a){Wl(this.a,this.b)};hh(260,$wnd.Function,{},Ym);_.jb=function(a){Jl(this.a,this.b,a)};hh(161,1,{},$m);var Yf=zh(161);hh(243,$wnd.Function,{},_m);_.ib=function(a){var b;b=a.target;ko((gn(),en),b.checked)};hh(137,1,{},an);_.R=function(a){return Zm(new $m,a)};var $f=zh(137);hh(64,1,{},bn);var _f=zh(64);var cn,dn,en,fn;hh(93,1,{});var Hg=zh(93);hh(94,93,mp,un);_.t=zp;_.o=yp;_.q=rp;_.u=Ap;_.A=Gp;_.r=function(){var a;return vh(ig),ig.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var ig=zh(94);hh(95,1,Xo,vn);_.v=function(){on(this.a)};var bg=zh(95);hh(97,1,{},wn);_.v=function(){jn(this.a)};var cg=zh(97);hh(98,1,{},xn);_.v=function(){kn(this.a)};var dg=zh(98);hh(99,1,Xo,yn);_.v=function(){hn(this.a,this.b)};var eg=zh(99);hh(100,1,Xo,zn);_.v=function(){rn(this.a)};var fg=zh(100);hh(53,1,Xo,An);_.v=function(){nn(this.a)};var gg=zh(53);hh(96,1,{},Bn);_.s=function(){var a;return a=(ph(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var hg=zh(96);hh(44,1,{44:1});_.d=false;var Pg=zh(44);hh(45,44,{9:1,62:1,45:1,44:1},Mn);_.t=zp;_.o=function(a){return Fn(this,a)};_.q=function(){return this.c.d};_.u=Ap;_.A=Gp;_.r=function(){var a;return vh(yg),yg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Cn=0;var yg=zh(45);hh(191,1,Xo,Nn);_.v=function(){Dn(this.a)};var jg=zh(191);hh(192,1,Xo,On);_.v=function(){In(this.a)};var kg=zh(192);hh(112,111,{});var Kg=zh(112);hh(113,112,Uo,Wn);_.t=Hp;_.o=yp;_.q=rp;_.u=Ip;_.r=function(){var a;return vh(tg),tg.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var tg=zh(113);hh(115,1,Xo,Xn);_.v=function(){Qn(this.a)};var lg=zh(115);hh(114,1,Xo,Yn);_.v=function(){Tn(this.a)};var mg=zh(114);hh(120,1,Xo,Zn);_.v=function(){bc(this.a,this.b,true)};var ng=zh(120);hh(121,1,{},$n);_.s=function(){return Pn(this.a,this.c,this.b)};_.b=false;var og=zh(121);hh(116,1,{},_n);_.s=function(){return Un(this.a)};var pg=zh(116);hh(117,1,{},ao);_.s=function(){return Kh(Zg(tj(cc(this.a))))};var qg=zh(117);hh(118,1,{},bo);_.s=function(){return Kh(Zg(tj(uj(cc(this.a),new Lo))))};var rg=zh(118);hh(119,1,{},co);_.s=function(){return Vn(this.a)};var sg=zh(119);hh(87,1,{});var Og=zh(87);hh(88,87,mp,lo);_.t=function(){jc(this.a)};_.o=yp;_.q=rp;_.u=function(){return this.a.i<0};_.A=function(a){nc(this.a,a)};_.r=function(){var a;return vh(xg),xg.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var xg=zh(88);hh(89,1,Xo,mo);_.v=function(){ho(this.a,this.b)};_.b=false;var ug=zh(89);hh(90,1,Xo,no);_.v=function(){Al(this.b,this.a)};var vg=zh(90);hh(91,1,Xo,oo);_.v=function(){io(this.a)};var wg=zh(91);hh(101,1,{});var Rg=zh(101);hh(102,101,mp,xo);_.t=Hp;_.o=yp;_.q=rp;_.u=Ip;_.A=function(a){nc(this.f,a)};_.r=function(){var a;return vh(Fg),Fg.k+'@'+(a=Tj(this)>>>0,a.toString(16))};var Fg=zh(102);hh(103,1,Xo,yo);_.v=function(){so(this.a)};var zg=zh(103);hh(104,1,Xo,zo);_.v=function(){ro(this.a)};var Ag=zh(104);hh(106,1,{},Ao);_.s=function(){return uo(this.a)};var Bg=zh(106);hh(107,1,{},Bo);_.v=function(){vo(this.a)};var Cg=zh(107);hh(108,1,Xo,Co);_.v=function(){wo(this.a,null)};var Dg=zh(108);hh(105,1,{},Do);_.s=function(){var a;return a=qn(this.a.g),o(op,a)?(Io(),Fo):o(pp,a)?(Io(),Ho):(Io(),Go)};var Eg=zh(105);hh(92,1,{},Eo);_.handleEvent=function(a){ln(this.a,a)};var Gg=zh(92);hh(30,29,{3:1,27:1,29:1,30:1},Jo);var Fo,Go,Ho;var Ig=Ah(30,Ko);hh(81,1,{},Lo);_.fb=function(a){return !Hn(a)};var Jg=zh(81);hh(85,1,{},Mo);_.fb=function(a){return Hn(a)};var Lg=zh(85);hh(86,1,{},No);_.w=function(a){Sn(this.a,a)};var Mg=zh(86);hh(84,1,{},Oo);_.w=function(a){fo(this.a,a)};_.a=false;var Ng=zh(84);hh(77,1,{},Po);_.fb=function(a){return qo(this.a,a)};var Qg=zh(77);var sd=Bh('D');var Qo=(Ec(),Hc);var gwtOnLoad=gwtOnLoad=bh;_g(nh);dh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();