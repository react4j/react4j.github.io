function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='42F01659B10C0AC38DFEA9608CDEEF6B',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '42F01659B10C0AC38DFEA9608CDEEF6B';function p(){}
function lh(){}
function hh(){}
function Th(){}
function Fb(){}
function Rc(){}
function Yc(){}
function mj(){}
function Aj(){}
function Ij(){}
function Jj(){}
function hk(){}
function Xk(){}
function el(){}
function rm(){}
function um(){}
function ym(){}
function Cm(){}
function Gm(){}
function Km(){}
function $m(){}
function _m(){}
function An(){}
function Io(){}
function Jo(){}
function Wc(a){Vc()}
function sh(){sh=hh}
function ui(){li(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function gc(a){this.a=a}
function pc(a){this.a=a}
function Ih(a){this.a=a}
function Sh(a){this.a=a}
function di(a){this.a=a}
function ii(a){this.a=a}
function ji(a){this.a=a}
function hi(a){this.b=a}
function wi(a){this.c=a}
function nj(a){this.a=a}
function Lj(a){this.a=a}
function dl(a){this.a=a}
function fl(a){this.a=a}
function gl(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function Bl(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function Fl(a){this.a=a}
function _l(a){this.a=a}
function am(a){this.a=a}
function fm(a){this.a=a}
function hm(a){this.a=a}
function im(a){this.a=a}
function om(a){this.a=a}
function pm(a){this.a=a}
function qm(a){this.a=a}
function Om(a){this.a=a}
function Pm(a){this.a=a}
function Rm(a){this.a=a}
function Sm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function un(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function Mn(a){this.a=a}
function Nn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function no(a){this.a=a}
function wo(a){this.a=a}
function xo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function Hj(a,b){a.a=b}
function qb(a,b){a.b=b}
function ak(a,b){a.key=b}
function _j(a,b){$j(a,b)}
function eo(a,b){Zl(b,a)}
function Y(a){!!a&&$(a)}
function kc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function op(a){$i(this,a)}
function rp(a){Mh(this,a)}
function tp(a){bj(this,a)}
function vp(){jc(this.c)}
function xp(){jc(this.b)}
function Cp(){jc(this.f)}
function Ii(){this.a=Ri()}
function Wi(){this.a=Ri()}
function zp(){kb(this.a.a)}
function db(a){Xb((J(),a))}
function eb(a){Yb((J(),a))}
function hb(a){Zb((J(),a))}
function Tg(a){return a.e}
function sp(){return this.e}
function mp(){return this.a}
function qp(){return this.b}
function J(){J=hh;I=new F}
function xc(){xc=hh;wc=new p}
function Ni(){Ni=hh;Mi=Pi()}
function Yk(a){a.d=2;jc(a.c)}
function hl(a){a.c=2;jc(a.b)}
function Ml(a){a.f=2;jc(a.e)}
function nn(a){R(a.a);$(a.b)}
function Cn(a){$(a.b);$(a.a)}
function al(a){kb(a.b);R(a.a)}
function vl(a){kb(a.a);$(a.b)}
function K(a,b){O(a);L(a,b)}
function Kj(a,b){zj(a.a,b)}
function nc(a,b){_h(a.e,b)}
function co(a,b){Qn(a.b,b)}
function C(a,b){Nb(a.f,b.f)}
function ic(a,b,c){$h(a.e,b,c)}
function gj(a,b,c){b.w(a.a[c])}
function Dn(a,b,c){ic(a.c,b,c)}
function Pj(a,b){a.splice(b,1)}
function sc(a,b){a.e=b;rc(a,b)}
function Hl(a,b){return a.g=b}
function oi(a,b){return a.a[b]}
function up(a){return this===a}
function np(){return Sj(this)}
function pp(){return bi(this.a)}
function wp(){return this.c.i<0}
function yp(){return this.b.i<0}
function Dp(){return this.f.i<0}
function Zc(a,b){return Bh(a,b)}
function vh(a){uh(a);return a.k}
function Ri(){Ni();return new Mi}
function yj(a,b){a.R(b);return a}
function bj(a,b){while(a.cb(b));}
function zj(a,b){Hj(a,yj(a.a,b))}
function Ej(a,b,c){b.w(a.a.Q(c))}
function v(a,b,c){t(a,new H(c),b)}
function Ll(a){Rn((fn(),cn),a)}
function rh(a){vc.call(this,a)}
function Uh(a){vc.call(this,a)}
function Ec(){Ec=hh;!!(Vc(),Uc)}
function Oc(){Oc=hh;Nc=new Rc}
function Mc(){Bc!=0&&(Bc=0);Dc=-1}
function ab(a){J();Yb(a);a.e=-2}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function T(a){mb(a.f);return V(a)}
function pn(a){fb(a.b);return a.e}
function Gn(a){fb(a.a);return a.d}
function ro(a){fb(a.d);return a.e}
function kk(a,b){a.ref=b;return a}
function ki(a,b){this.a=a;this.b=b}
function hc(a,b){this.a=a;this.b=b}
function Gh(a,b){this.a=a;this.b=b}
function Gj(a,b){this.a=a;this.b=b}
function Dj(a,b){this.a=a;this.b=b}
function ik(a,b){this.a=a;this.b=b}
function El(a,b){this.a=a;this.b=b}
function bm(a,b){this.a=a;this.b=b}
function cm(a,b){this.a=a;this.b=b}
function dm(a,b){this.a=a;this.b=b}
function em(a,b){this.a=a;this.b=b}
function gm(a,b){this.a=a;this.b=b}
function Db(a){this.d=a;this.b=100}
function Ap(a){return 1==this.a.d}
function Bp(a){return 1==this.a.c}
function bi(a){return a.a.b+a.b.b}
function Ti(a,b){return a.a.get(b)}
function Tk(a,b){Gh.call(this,a,b)}
function Tm(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function xn(a,b){this.a=a;this.b=b}
function Yn(a,b){this.a=a;this.b=b}
function lo(a,b){this.a=a;this.b=b}
function mo(a,b){this.b=a;this.a=b}
function Go(a,b){Gh.call(this,a,b)}
function Nj(a,b,c){a.splice(b,0,c)}
function lk(a,b){a.href=b;return a}
function Qh(a,b){a.a+=''+b;return a}
function Qm(){this.a=bk((Em(),Dm))}
function sm(){this.a=bk((wm(),vm))}
function tm(){this.a=bk((Am(),zm))}
function Zm(){this.a=bk((Im(),Hm))}
function an(){this.a=bk((Mm(),Lm))}
function qn(a){on(a,(fb(a.b),a.e))}
function Hn(a){Zl(a,(fb(a.a),!a.d))}
function Tb(a){return !a.d?a:Tb(a.d)}
function Zh(a){return !a?null:a.$()}
function qd(a){return a==null?null:a}
function aj(a){return a!=null?s(a):0}
function nd(a){return typeof a===Po}
function o(a,b){return qd(a)===qd(b)}
function Oj(a,b){Mj(b,0,a,0,b.length)}
function uk(a,b){a.value=b;return a}
function pk(a,b){a.onBlur=b;return a}
function mk(a,b){a.onClick=b;return a}
function ok(a,b){a.checked=b;return a}
function Lc(a){$wnd.clearTimeout(a)}
function li(a){a.a=_c(ie,Qo,1,0,5,1)}
function ai(a){a.a=new Ii;a.b=new Wi}
function ib(a){this.c=new ui;this.b=a}
function Wj(){Wj=hh;Tj=new p;Vj=new p}
function _g(){Zg==null&&(Zg=[])}
function Ql(a){kb(a.b);R(a.c);$(a.a)}
function fc(a,b){bc(a,b,false);eb(a.c)}
function $j(a,b){for(var c in a){b(c)}}
function go(a,b){ni(dc(a.b),new Lo(b))}
function Nh(a,b){return a.charCodeAt(b)}
function B(a,b,c){return u(a,c,2048,b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function ld(a,b){return a!=null&&jd(a,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function Sj(a){return a.$H||(a.$H=++Rj)}
function pd(a){return typeof a==='string'}
function pb(a){J();ob(a);sb(a,2,true)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function ec(a,b){nc(b.c,a);ld(b,9)&&b.t()}
function vc(a){this.g=a;qc(this);this.F()}
function xj(a,b){qj.call(this,a);this.a=b}
function qk(a,b){a.onChange=b;return a}
function rk(a,b){a.onKeyDown=b;return a}
function nk(a){a.autoFocus=true;return a}
function uh(a){if(a.k!=null){return}Dh(a)}
function rn(a){A((J(),J(),I),new yn(a),fp)}
function Kn(a){A((J(),J(),I),new Nn(a),fp)}
function Wl(a){A((J(),J(),I),new hm(a),fp)}
function fo(a){A((J(),J(),I),new no(a),fp)}
function A(a,b,c){u(a,new G(b),c,null)}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function Ki(a,b){var c;c=a[ap];c.call(a,b)}
function qo(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function P(){this.a=_c(ie,Qo,1,100,5,1)}
function Lh(){Lh=hh;Kh=_c(fe,Qo,28,256,0,1)}
function Ci(){this.a=new Ii;this.b=new Wi}
function $i(a,b){while(a.W()){Kj(b,a.X())}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function md(a){return typeof a==='boolean'}
function Un(a){return Jh(S(a.e).a-S(a.a).a)}
function Fc(a,b,c){return a.apply(b,c);var d}
function Zi(a,b,c){this.a=a;this.b=b;this.c=c}
function vk(a,b){a.onDoubleClick=b;return a}
function mi(a,b){a.a[a.a.length]=b;return true}
function qc(a){a.j&&a.e!==Xo&&a.F();return a}
function yh(a){var b;b=xh(a);Fh(a,b);return b}
function Vc(){Vc=hh;var a;!Xc();a=new Yc;Uc=a}
function ph(a,b,c,d){a.addEventListener(b,c,d)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function wl(a,b){A((J(),J(),I),new El(a,b),fp)}
function Rl(a,b){A((J(),J(),I),new gm(a,b),fp)}
function Ul(a,b){A((J(),J(),I),new dm(a,b),fp)}
function Vl(a,b){A((J(),J(),I),new cm(a,b),fp)}
function Yl(a,b){A((J(),J(),I),new bm(a,b),fp)}
function Rn(a,b){A((J(),J(),I),new Yn(a,b),fp)}
function io(a,b){A((J(),J(),I),new mo(a,b),fp)}
function jo(a,b){A((J(),J(),I),new lo(a,b),fp)}
function ej(a,b){while(a.c<a.d){gj(a,b,a.c++)}}
function ij(a){if(!a.d){a.d=a.b.P();a.c=a.b.S()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function xl(a,b){var c;c=b.target;zl(a,c.value)}
function rj(a,b){var c;return vj(a,(c=new ui,c))}
function qh(a,b,c,d){a.removeEventListener(b,c,d)}
function Si(a,b){return !(a.a.get(b)===undefined)}
function oo(a){return o(kp,a)||o(lp,a)||o('',a)}
function bd(a){return Array.isArray(a)&&a.nb===lh}
function yi(a){return new xj(null,xi(a,a.length))}
function Tn(a){return sh(),0!=S(a.e).a?true:false}
function kd(a){return !Array.isArray(a)&&a.nb===lh}
function Sn(a){Mh(new ii(a.g),new gc(a));ai(a.g)}
function Pn(a){R(a.d);R(a.e);R(a.a);R(a.b);$(a.c)}
function fi(a){var b;b=a.a.X();a.b=ei(a);return b}
function Ah(a){var b;b=xh(a);b.j=a;b.e=1;return b}
function qi(a,b){var c;c=a.a[b];Pj(a.a,b);return c}
function Sc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function xi(a,b){return cj(b,a.length),new hj(a,b)}
function bl(a){return B((J(),J(),I),a.b,new gl(a))}
function kl(a){return B((J(),J(),I),a.a,new ol(a))}
function yl(a){return B((J(),J(),I),a.a,new Cl(a))}
function Xl(a){return B((J(),J(),I),a.b,new am(a))}
function mm(a){return B((J(),J(),I),a.a,new qm(a))}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function il(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function Nl(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function Zk(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function oj(a){if(!a.b){pj(a);a.c=true}else{oj(a.b)}}
function Bj(a,b,c){if(a.a.eb(c)){a.b=true;b.w(c)}}
function zl(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function Zl(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function si(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ci(a,b){if(b){return Xh(a.a,b)}return false}
function tj(a,b){pj(a);return new xj(a,new Cj(b,a.a))}
function uj(a,b){pj(a);return new xj(a,new Fj(b,a.a))}
function on(a,b){A((J(),J(),I),new xn(a,b),75497472)}
function Zn(a,b){this.a=a;this.c=b;this.b=false}
function dj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function hj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function jj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function tk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function zh(a,b){var c;c=xh(a);Fh(a,c);c.e=b?8:0;return c}
function mn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&zl(a,b)}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Vo)&&D((null,I))}
function Bi(a,b){return qd(a)===qd(b)||a!=null&&q(a,b)}
function Yh(a,b){return b===a?'(this Map)':b==null?Zo:kh(b)}
function tc(a,b){var c;c=vh(a.lb);return b==null?c:c+': '+b}
function Gl(a,b){var c;if(S(a.c)){c=b.target;Zl(a,c.value)}}
function Mh(a,b){var c,d;for(d=a.P();d.W();){c=d.X();b.w(c)}}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function qj(a){if(!a){this.b=null;new ui}else{this.b=a}}
function Ch(a){if(a.N()){return null}var b=a.j;return dh[b]}
function Yg(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function Zj(){if(Uj==256){Tj=Vj;Vj=new p;Uj=0}++Uj}
function oh(){oh=hh;nh=$wnd.goog.global.document}
function wm(){wm=hh;var a;vm=(a=ih(um.prototype.kb,um,[]),a)}
function Am(){Am=hh;var a;zm=(a=ih(ym.prototype.kb,ym,[]),a)}
function Em(){Em=hh;var a;Dm=(a=ih(Cm.prototype.kb,Cm,[]),a)}
function Im(){Im=hh;var a;Hm=(a=ih(Gm.prototype.kb,Gm,[]),a)}
function Mm(){Mm=hh;var a;Lm=(a=ih(Km.prototype.kb,Km,[]),a)}
function Ho(){Fo();return cd(Zc(Hg,1),Qo,30,0,[Co,Eo,Do])}
function Sl(a,b){uo((fn(),en),b);A((J(),J(),I),new bm(a,b),fp)}
function Kc(a){Ec();$wnd.setTimeout(function(){throw a},0)}
function pj(a){if(a.b){pj(a.b)}else if(a.c){throw Tg(new Hh)}}
function cc(a){fb(a.c);return new xj(null,new jj(new ii(a.g),0))}
function kn(a,b){b.preventDefault();A((J(),J(),I),new zn(a),fp)}
function Ei(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Bh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.I(b))}
function fh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Fi(a,b){var c;return Di(b,Ei(a,b==null?0:(c=s(b),c|0)))}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function jh(a){function b(){}
;b.prototype=a||{};return new b}
function uc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function sk(a){a.placeholder='What needs to be done?';return a}
function fj(a,b){if(a.c<a.d){gj(a,b,a.c++);return true}return false}
function mc(a){kc(a.g);!!a.e&&lc(a);Y(a.a);Y(a.c);kc(a.b);kc(a.f)}
function vi(a){li(this);Oj(this.a,Wh(a,_c(ie,Qo,1,bi(a.a),5,1)))}
function ko(a){this.b=a;J();this.a=new oc(0,null,null,false,false)}
function Ji(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Fj(a,b){dj.call(this,b.bb(),b.ab()&-6);this.a=a;this.b=b}
function xm(a){$wnd.React.Component.call(this,a);this.a=new cl(this)}
function Bm(a){$wnd.React.Component.call(this,a);this.a=new ll(this)}
function Fm(a){$wnd.React.Component.call(this,a);this.a=new Al(this)}
function Jm(a){$wnd.React.Component.call(this,a);this.a=new $l(this)}
function Nm(a){$wnd.React.Component.call(this,a);this.a=new nm(this)}
function ho(a){rj(tj(cc(a.b),new Jo),new nj(new mj)).O(new Ko(a.b))}
function hn(a){ph((oh(),$wnd.goog.global.window),ip,a.d,false)}
function jn(a){qh((oh(),$wnd.goog.global.window),ip,a.d,false)}
function Tl(a){return sh(),ro((fn(),en))==a.j.props['a']?true:false}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function _h(a,b){return pd(b)?b==null?Hi(a.a,null):Vi(a.b,b):Hi(a.a,b)}
function kj(a,b){!a.a?(a.a=new Sh(a.d)):Qh(a.a,a.b);Qh(a.a,b);return a}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function bb(a,b){var c,d;mi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Ic(a,b,c){var d;d=Gc();try{return Fc(a,b,c)}finally{Jc(d)}}
function Qn(a,b){var c;return u((J(),J(),I),new Zn(a,b),fp,(c=null,c))}
function vj(a,b){var c;oj(a);c=new Ij;c.a=b;a.a.V(new Lj(c));return c.a}
function sj(a){var b;oj(a);b=0;while(a.a.cb(new Jj)){b=Ug(b,1)}return b}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Xi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function lj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Cj(a,b){dj.call(this,b.bb(),b.ab()&-16449);this.a=a;this.c=b}
function gi(a){this.d=a;this.c=new Xi(this.d.b);this.a=this.c;this.b=ei(this)}
function wj(a,b){var c;c=rj(a,new nj(new mj));return ti(c,b.db(c.a.length))}
function Hc(b){Ec();return function(){return Ic(b,this,arguments);var a}}
function Ac(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Yi(a){if(a.a.c!=a.c){return Ti(a.a,a.b.value[0])}return a.b.value[1]}
function Ib(b){try{mb(b.b.a)}catch(a){a=Sg(a);if(!ld(a,4))throw Tg(a)}}
function gn(a,b){a.f=b;o(b,S(a.a))&&zl(a,b);ln(b);A((J(),J(),I),new zn(a),fp)}
function gk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function pi(a,b,c){for(;c<a.a.length;++c){if(Bi(b,a.a[c])){return c}}return -1}
function _c(a,b,c,d,e,f){var g;g=ad(e,d);e!=10&&cd(Zc(a,f),b,c,e,g);return g}
function En(a,b){var c;if(ld(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function ni(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Ob(){var a;this.a=_c(wd,Qo,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function so(a){var b;return b=S(a.b),rj(tj(cc(a.i),new Mo(b)),new nj(new mj))}
function fn(){fn=hh;cn=new Vn;dn=new ko(cn);bn=new tn;en=new vo(cn,bn)}
function Jc(a){a&&Qc((Oc(),Nc));--Bc;if(a){if(Dc!=-1){Lc(Dc);Dc=-1}}}
function po(a,b){return (Fo(),Do)==a||(Co==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function $h(a,b,c){return pd(b)?b==null?Gi(a.a,null,c):Ui(a.b,b,c):Gi(a.a,b,c)}
function Qj(a,b){return $c(b)!=10&&cd(r(b),b.mb,b.__elementTypeId$,$c(b),a),a}
function $c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ek(a){var b;return ck($wnd.React.StrictMode,null,null,(b={},b[bp]=a,b))}
function pl(a){var b;b=Ph((fb(a.b),a.e));if(b.length>0){co((fn(),dn),b);zl(a,'')}}
function ql(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Dl(a),fp)}}
function jc(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new pc(a)),67108864,null)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function V(a){if(a.b){if(ld(a.b,8)){throw Tg(a.b)}else{throw Tg(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=Sg(a);if(ld(a,4)){J()}else throw Tg(a)}}}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function Pc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Tc(b,c)}while(a.a);a.a=c}}
function Qc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Tc(b,c)}while(a.b);a.b=c}}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new ui);mi(a.b,b)}}}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new ui);a.c=c.c}b.d=true;mi(a.c,b)}
function Fh(a,b){var c;if(!a){return}b.j=a;var d=Ch(b);if(!d){dh[a]=[b];return}d.lb=b}
function ri(a,b){var c;c=pi(a,b,0);if(c==-1){return false}Pj(a.a,c);return true}
function ih(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ck(a,b,c,d){var e;e=dk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function bk(a){var b;b=dk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function xh(a){var b;b=new wh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Vi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ki(a.a,b);--a.b}return c}
function zi(a){var b,c,d;d=0;for(c=new gi(a.a);c.b;){b=fi(c);d=d+(b?s(b):0);d=d|0}return d}
function ob(a){var b,c;for(c=new wi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function $g(){_g();var a=Zg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Hh(){vc.call(this,"Stream already terminated, can't be modified or used")}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:So)|(0==(c&6291456)?!a?Vo:Wo:0)|0|0|0)}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Wo:0)|(0!=(b&229376)?0:98304)}
function od(a){return a!=null&&(typeof a===Oo||typeof a==='function')&&!(a.nb===lh)}
function bh(a,b){typeof window===Oo&&typeof window['$gwt']===Oo&&(window['$gwt'][a]=b)}
function dc(a){return fb(a.c),rj(new xj(null,new jj(new ii(a.g),0)),new nj(new mj))}
function Fo(){Fo=hh;Co=new Go('ACTIVE',0);Eo=new Go('COMPLETED',1);Do=new Go('ALL',2)}
function mh(){fn();$wnd.ReactDOM.render(ek([(new an).a]),(oh(),nh).getElementById('app'),null)}
function On(a,b,c){var d;d=new Ln(b,c);Dn(d,a,new hc(a,d));$h(a.g,Jh(d.c.d),d);eb(a.c);return d}
function Vh(a,b){var c,d;for(d=new gi(b.a);d.b;){c=fi(d);if(!ci(a,c)){return false}}return true}
function Ym(a,b){ak(a.a,(b?Jh(b.c.d):null)+(''+(uh(Zf),Zf.k)));a.a.props['a']=b;return a.a}
function bc(a,b,c){var d;d=_h(a.g,b?Jh(b.c.d):null);if(null!=d){nc(b.c,a);c&&!!b&&jc(b.c);eb(a.c)}}
function Ui(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Vg(a){var b;b=a.h;if(b==0){return a.l+a.m*Wo}if(b==1048575){return a.l+a.m*Wo-$o}return a}
function Sg(a){var b;if(ld(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new zc(a);Wc(b)}return b}
function ei(a){if(a.a.W()){return true}if(a.a!=a.c){return false}a.a=new Ji(a.d.a);return a.a.W()}
function cj(a,b){if(0>a||a>b){throw Tg(new rh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function to(a){var b;b=S(a.g.a);o(kp,b)||o(lp,b)||o('',b)?on(a.g,b):oo(pn(a.g))?rn(a.g):on(a.g,'')}
function Xg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=$o;d=1048575}c=rd(e/Wo);b=rd(e-c*Wo);return dd(b,c,d)}
function Di(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Bi(a,c.Z())){return c}}return null}
function Jh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Lh(),Kh)[b];!c&&(c=Kh[b]=new Ih(a));return c}return new Ih(a)}
function uo(a,b){var c;c=a.e;if(!(b==c||!!b&&En(b,c))){!!c&&nc(c.c,a);a.e=b;!!b&&Dn(b,a,new xo(a));eb(a.d)}}
function cb(a,b){var c,d;d=a.c;ri(d,b);!!a.b&&So!=(a.b.c&To)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function cd(a,b,c,d,e){e.lb=a;e.mb=b;e.nb=lh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Il(a,b,c){27==c.which?A((J(),J(),I),new em(a,b),fp):13==c.which&&A((J(),J(),I),new cm(a,b),fp)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function Wk(){if(!Vk){Vk=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(ih(Xk.prototype.H,Xk,[]))}}
function zc(a){xc();qc(this);this.e=a;rc(this,a);this.g=a==null?Zo:kh(a);this.a='';this.b=a;this.a=''}
function wh(){this.g=th++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function ll(a){var b;this.j=a;J();b=++jl;this.b=new oc(b,null,new ml(this),false,false);this.a=new vb(null,new nl(this),ep)}
function nm(a){var b;this.j=a;J();b=++lm;this.b=new oc(b,null,new om(this),false,false);this.a=new vb(null,new pm(this),ep)}
function Jl(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){io((fn(),b),c);uo(en,null);Zl(a,c)}else{Rn((fn(),cn),b)}}
function Ug(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<$o){return c}}return Vg(ed(nd(a)?Xg(a):a,nd(b)?Xg(b):b))}
function r(a){return pd(a)?le:nd(a)?ae:md(a)?$d:kd(a)?a.lb:bd(a)?a.lb:a.lb||Array.isArray(a)&&Zc(Sd,1)||Sd}
function s(a){return pd(a)?Yj(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.q():bd(a)?Sj(a):!!a&&!!a.hashCode?a.hashCode():Sj(a)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&So)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Kl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Yl(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=qi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Ai(a){var b,c,d;d=1;for(c=new wi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function lc(a){var b,c,d;for(c=new wi(new vi(new di(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.Z();ld(d,9)&&d.u()||b.$().v()}}
function Uk(){Sk();return cd(Zc(cf,1),Qo,6,0,[wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk])}
function kh(a){var b;if(Array.isArray(a)&&a.nb===lh){return vh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function Yj(a){Wj();var b,c,d;c=':'+a;d=Vj[c];if(d!=null){return rd(d)}d=Tj[c];b=d==null?Xj(a):rd(d);Zj();Vj[c]=b;return b}
function ti(a,b){var c,d;d=a.a.length;b.length<d&&(b=Qj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Eh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(So==(b&To)?0:524288)|(0==(b&6291456)?So==(b&To)?Wo:Vo:0)|0|268435456|0)}
function Gc(){var a;if(Bc!=0){a=Ac();if(a-Cc>2000){Cc=a;Dc=$wnd.setTimeout(Mc,10)}}if(Bc++==0){Pc((Oc(),Nc));return true}return false}
function Xc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return pd(a)?o(a,b):nd(a)?qd(a)===qd(b):md(a)?qd(a)===qd(b):kd(a)?a.o(b):bd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.mb){return !!a.mb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function oc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ci:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Al(a){var b,c,d;this.j=a;J();b=++ul;this.c=new oc(b,null,new Bl(this),false,false);this.b=(d=new ib((c=null,c)),d);this.a=new vb(null,new Fl(this),ep)}
function jk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new wi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new wi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new wi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Ph(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Wh(a,b){var c,d,e,f;f=bi(a.a);b.length<f&&(b=Qj(new Array(f),b));e=b;d=new gi(a.a);for(c=0;c<f;++c){e[c]=fi(d)}b.length>f&&(b[f]=null);return b}
function ad(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=Sg(a);if(ld(a,4)){e=a;throw Tg(e)}else throw Tg(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=Sg(a);if(ld(a,4)){f=a;throw Tg(f)}else throw Tg(a)}finally{D(b)}}
function cl(a){var b;this.j=a;J();b=++_k;this.c=new oc(b,null,new dl(this),false,false);this.a=new W(new el,null,null,136478720);this.b=new vb(null,new fl(this),ep)}
function Ln(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++Bn;this.c=new oc(c,null,new Mn(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function ah(b,c,d,e){_g();var f=Zg;$moduleName=c;$moduleBase=d;Rg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{No(g)()}catch(a){b(c,a)}}else{No(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);So==(d&To)&&lb(this.f)}
function dk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Pi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Qi()}}
function eh(){dh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Tc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].ob()&&(c=Sc(c,g)):g[0].ob()}catch(a){a=Sg(a);if(ld(a,4)){d=a;Ec();Kc(ld(d,34)?d.G():d)}else throw Tg(a)}}return c}
function tl(a){var b;a.d=0;Wk();b=fk(gp,nk(qk(rk(uk(sk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['new-todo']))),(fb(a.b),a.e)),ih(Om.prototype.ib,Om,[a])),ih(Pm.prototype.hb,Pm,[a]))),null);return b}
function yc(a){var b;if(a.c==null){b=qd(a.b)===qd(wc)?null:a.b;a.d=b==null?Zo:od(b)?b==null?null:b.name:pd(b)?'String':vh(r(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(qd(e)===qd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=Sg(a);if(ld(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw Tg(c)}else throw Tg(a)}}
function Gi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Di(b,e);if(f){return f._(c)}}e[e.length]=new ki(b,c);++a.b;return null}
function Mj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Xj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Nh(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Sg(a);if(ld(a,4)){J()}else throw Tg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=_c(ie,Qo,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function ub(a,b,c,d){this.b=new ui;this.f=new Jb(new yb(this),d&6520832|262144|So);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Vo)&&D((null,I)))}
function Hi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Bi(b,e.Z())){if(d.length==1){d.length=0;Ki(a.a,g)}else{d.splice(h,1)}--a.b;return e.$()}}return null}
function $l(a){var b,c,d;this.j=a;J();b=++Pl;this.e=new oc(b,null,new _l(this),false,false);this.a=(d=new ib((c=null,c)),d);this.c=new W(new fm(this),null,null,136478720);this.b=new vb(null,new im(this),ep);Yl(this,this.j.props['a'])}
function gh(a,b,c){var d=dh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=dh[b]),jh(h));_.mb=c;!b&&(_.nb=lh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.lb=f)}
function Dh(a){if(a.M()){var b=a.c;b.N()?(a.k='['+b.j):!b.M()?(a.k='[L'+b.K()+';'):(a.k='['+b.K());a.b=b.J()+'[]';a.i=b.L()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Eh('.',[c,Eh('$',d)]);a.b=Eh('.',[c,Eh('.',d)]);a.i=d[d.length-1]}
function Xh(a,b){var c,d,e;c=b.Z();e=b.$();d=pd(c)?c==null?Zh(Fi(a.a,null)):Ti(a.b,c):Zh(Fi(a.a,c));if(!(qd(e)===qd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Fi(a.a,null):Si(a.b,c):!!Fi(a.a,c))){return false}return true}
function ln(a){var b;if(0==a.length){b=(oh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',nh.title,b)}else{(oh(),$wnd.goog.global.window).location.hash=a}}
function fk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;_j(b,ih(ik.prototype.fb,ik,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[bp]=c[0],undefined):(d[bp]=c,undefined));return ck(a,e,f,d)}
function vo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new oc(0,null,new wo(this),false,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new yo(this),null,null,jp);this.c=new W(new zo(this),null,null,jp);this.a=new vb(new Ao(this),null,681574400);D((null,I))}
function Vn(){var a;this.g=new Ci;J();this.f=new oc(0,new Xn(this),new Wn(this),false,false);this.c=(a=new ib(null),a);this.d=new W(new $n(this),null,null,jp);this.e=new W(new _n(this),null,null,jp);this.a=new W(new ao(this),null,null,jp);this.b=new W(new bo(this),null,null,jp)}
function tn(){var a,b,c;this.d=new Bo(this);this.f=this.e=(c=(oh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new oc(0,null,new un(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new An,new vn(this),new wn(this),35651584)}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new wi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Sg(a);if(!ld(a,4))throw Tg(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function rc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.C();return a&&a.A()}},suppressed:{get:function(){return c.B()}}})}catch(a){}}}
function Oi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}ni(a.b,new Ab(a));a.b.a=_c(ie,Qo,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Sk(){Sk=hh;wk=new Tk(cp,0);xk=new Tk('checkbox',1);yk=new Tk('color',2);zk=new Tk('date',3);Ak=new Tk('datetime',4);Bk=new Tk('email',5);Ck=new Tk('file',6);Dk=new Tk('hidden',7);Ek=new Tk('image',8);Fk=new Tk('month',9);Gk=new Tk(Po,10);Hk=new Tk('password',11);Ik=new Tk('radio',12);Jk=new Tk('range',13);Kk=new Tk('reset',14);Lk=new Tk('search',15);Mk=new Tk('submit',16);Nk=new Tk('tel',17);Ok=new Tk('text',18);Pk=new Tk('time',19);Qk=new Tk('url',20);Rk=new Tk('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=oi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&si(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=oi(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){qi(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new ui)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&So!=(k.b.c&To)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function $k(a){var b,c;a.d=0;Wk();c=(b=S((fn(),en).b),fk('footer',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['footer'])),[(new tm).a,fk('ul',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['filters'])),[fk('li',null,[fk('a',lk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[(Fo(),Do)==b?dp:null])),'#'),['All'])]),fk('li',null,[fk('a',lk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[Co==b?dp:null])),'#active'),['Active'])]),fk('li',null,[fk('a',lk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[Eo==b?dp:null])),'#completed'),['Completed'])])]),S(a.a)?fk(cp,mk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['clear-completed'])),ih(rm.prototype.jb,rm,[])),['Clear Completed']):null]));return c}
function Ol(a){var b,c,d,e;a.f=0;Wk();b=a.j.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.j.props['a'],e=(fb(d.a),d.d),fk('li',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[e?'checked':null,S(a.c)?'editing':null])),[fk('div',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['view'])),[fk(gp,qk(ok(tk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['toggle'])),(Sk(),xk)),e),ih(Sm.prototype.hb,Sm,[d])),null),fk('label',vk(new $wnd.Object,ih(Tm.prototype.jb,Tm,[a,d])),[(fb(d.b),d.e)]),fk(cp,mk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['destroy'])),ih(Um.prototype.jb,Um,[d])),null)]),fk(gp,rk(qk(pk(uk(jk(kk(new $wnd.Object,ih(Vm.prototype.w,Vm,[a])),cd(Zc(le,1),Qo,2,6,['edit'])),(fb(a.a),a.d)),ih(Wm.prototype.gb,Wm,[a,d])),ih(Rm.prototype.hb,Rm,[a])),ih(Xm.prototype.ib,Xm,[a,d])),null)]));return c}
function Qi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[ap]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Oi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[ap]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Oo='object',Po='number',Qo={3:1},Ro={9:1},So=1048576,To=1835008,Uo={5:1},Vo=2097152,Wo=4194304,Xo='__noinit__',Yo={3:1,10:1,8:1,4:1},Zo='null',$o=17592186044416,_o={40:1},ap='delete',bp='children',cp='button',dp='selected',ep=1411518464,fp=142606336,gp='input',hp='header',ip='hashchange',jp=136314880,kp='active',lp='completed';var _,dh,Zg,Rg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;eh();gh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.lb};_.q=np;_.r=function(){var a;return vh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var fd,gd,hd;gh(50,1,{},wh);_.I=function(a){var b;b=new wh;b.e=4;a>1?(b.c=Bh(this,a-1)):(b.c=this);return b};_.J=function(){uh(this);return this.b};_.K=function(){return vh(this)};_.L=function(){uh(this);return this.i};_.M=function(){return (this.e&4)!=0};_.N=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(uh(this),this.k)};_.e=0;_.g=0;var th=1;var ie=yh(1);var _d=yh(50);gh(78,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var vd=yh(78);gh(35,1,{},G);_.s=function(){return this.a.v(),null};var td=yh(35);gh(79,1,{},H);var ud=yh(79);var I;gh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var wd=yh(43);gh(213,1,Ro);_.r=function(){var a;return vh(this.lb)+'@'+(a=s(this)>>>0,a.toString(16))};var zd=yh(213);gh(18,213,Ro,W);_.t=function(){R(this)};_.u=mp;_.a=false;_.d=0;_.k=false;var yd=yh(18);gh(122,1,{},X);_.s=function(){return T(this.a)};var xd=yh(122);gh(15,213,{9:1,15:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Bd=yh(15);gh(121,1,Uo,jb);_.v=function(){ab(this.a)};var Ad=yh(121);gh(16,213,{9:1,16:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Gd=yh(16);gh(123,1,{},xb);_.v=function(){Q(this.a)};var Cd=yh(123);gh(124,1,Uo,yb);_.v=function(){mb(this.a)};var Dd=yh(124);gh(125,1,Uo,zb);_.v=function(){pb(this.a)};var Ed=yh(125);gh(126,1,{},Ab);_.w=function(a){nb(this.a,a)};var Fd=yh(126);gh(131,1,{},Db);_.a=0;_.b=0;_.c=0;var Hd=yh(131);gh(158,1,Ro,Fb);_.t=function(){Eb(this)};_.u=mp;_.a=false;var Id=yh(158);gh(58,213,{9:1,58:1},Jb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Kd=yh(58);gh(136,1,{},Ob);var Jd=yh(136);gh(138,1,{},$b);_.r=function(){var a;return uh(Ld),Ld.k+'@'+(a=Sj(this)>>>0,a.toString(16))};_.a=0;var Pb;var Ld=yh(138);gh(109,1,{});var Od=yh(109);gh(81,1,{},gc);_.w=function(a){ec(this.a,a)};var Md=yh(81);gh(82,1,Uo,hc);_.v=function(){fc(this.a,this.b)};var Nd=yh(82);gh(14,1,Ro,oc);_.t=function(){jc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return uh(Qd),Qd.k+'@'+(a=Sj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Qd=yh(14);gh(120,1,Uo,pc);_.v=function(){mc(this.a)};var Pd=yh(120);gh(4,1,{3:1,4:1});_.A=sp;_.B=function(){return wj(uj(yi((this.i==null&&(this.i=_c(ne,Qo,4,0,0,1)),this.i)),new Th),new Aj)};_.C=function(){return this.f};_.D=function(){return this.g};_.F=function(){sc(this,uc(new Error(tc(this,this.g))));Wc(this)};_.r=function(){return tc(this,this.D())};_.e=Xo;_.j=true;var ne=yh(4);gh(10,4,{3:1,10:1,4:1});var ce=yh(10);gh(8,10,Yo);var je=yh(8);gh(71,8,Yo);var ge=yh(71);gh(72,71,Yo);var Ud=yh(72);gh(34,72,{34:1,3:1,10:1,8:1,4:1},zc);_.D=function(){yc(this);return this.c};_.G=function(){return qd(this.b)===qd(wc)?null:this.b};var wc;var Rd=yh(34);var Sd=yh(0);gh(199,1,{});var Td=yh(199);var Bc=0,Cc=0,Dc=-1;gh(108,199,{},Rc);var Nc;var Vd=yh(108);var Uc;gh(210,1,{});var Xd=yh(210);gh(73,210,{},Yc);var Wd=yh(73);var nh;gh(69,1,{66:1});_.r=mp;var Yd=yh(69);gh(75,8,Yo);var ee=yh(75);gh(154,75,Yo,rh);var Zd=yh(154);fd={3:1,67:1,27:1};var $d=yh(67);gh(41,1,{3:1,41:1});var he=yh(41);gd={3:1,27:1,41:1};var ae=yh(209);gh(29,1,{3:1,27:1,29:1});_.o=up;_.q=np;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=yh(29);gh(74,8,Yo,Hh);var de=yh(74);gh(28,41,{3:1,27:1,28:1,41:1},Ih);_.o=function(a){return ld(a,28)&&a.a==this.a};_.q=mp;_.r=function(){return ''+this.a};_.a=0;var fe=yh(28);var Kh;gh(277,1,{});hd={3:1,66:1,27:1,2:1};var le=yh(2);gh(70,69,{66:1},Sh);var ke=yh(70);gh(281,1,{});gh(64,1,{},Th);_.Q=function(a){return a.e};var me=yh(64);gh(52,8,Yo,Uh);var oe=yh(52);gh(211,1,{39:1});_.O=rp;_.T=function(){return new jj(this,0)};_.U=function(){return new xj(null,this.T())};_.R=function(a){throw Tg(new Uh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new lj('[',']');for(b=this.P();b.W();){a=b.X();kj(c,a===this?'(this Collection)':a==null?Zo:kh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=yh(211);gh(214,1,{197:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ld(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new gi((new di(d)).a);c.b;){b=fi(c);if(!Xh(this,b)){return false}}return true};_.q=function(){return zi(new di(this))};_.r=function(){var a,b,c;c=new lj('{','}');for(b=new gi((new di(this)).a);b.b;){a=fi(b);kj(c,Yh(this,a.Z())+'='+Yh(this,a.$()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=yh(214);gh(127,214,{197:1});var se=yh(127);gh(215,211,{39:1,225:1});_.T=function(){return new jj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ld(a,21)){return false}b=a;if(bi(b.a)!=this.S()){return false}return Vh(this,b)};_.q=function(){return zi(this)};var Be=yh(215);gh(21,215,{21:1,39:1,225:1},di);_.P=function(){return new gi(this.a)};_.S=pp;var re=yh(21);gh(22,1,{},gi);_.V=op;_.X=function(){return fi(this)};_.W=qp;_.b=false;var qe=yh(22);gh(212,211,{39:1,222:1});_.T=function(){return new jj(this,16)};_.Y=function(a,b){throw Tg(new Uh('Add not supported on this list'))};_.R=function(a){this.Y(this.S(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,13)){return false}f=a;if(this.S()!=f.a.length){return false}e=new wi(f);for(c=new wi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Ai(this)};_.P=function(){return new hi(this)};var ue=yh(212);gh(107,1,{},hi);_.V=op;_.W=function(){return this.a<this.b.a.length};_.X=function(){return oi(this.b,this.a++)};_.a=0;var te=yh(107);gh(42,211,{39:1},ii);_.P=function(){var a;a=new gi((new di(this.a)).a);return new ji(a)};_.S=pp;var we=yh(42);gh(130,1,{},ji);_.V=op;_.W=function(){return this.a.b};_.X=function(){var a;a=fi(this.a);return a.$()};var ve=yh(130);gh(128,1,_o);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Bi(this.a,b.Z())&&Bi(this.b,b.$())};_.Z=mp;_.$=qp;_.q=function(){return aj(this.a)^aj(this.b)};_._=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var xe=yh(128);gh(129,128,_o,ki);var ye=yh(129);gh(216,1,_o);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Bi(this.b.value[0],b.Z())&&Bi(Yi(this),b.$())};_.q=function(){return aj(this.b.value[0])^aj(Yi(this))};_.r=function(){return this.b.value[0]+'='+Yi(this)};var ze=yh(216);gh(13,212,{3:1,13:1,39:1,222:1},ui,vi);_.Y=function(a,b){Nj(this.a,a,b)};_.R=function(a){return mi(this,a)};_.O=function(a){ni(this,a)};_.P=function(){return new wi(this)};_.S=function(){return this.a.length};var De=yh(13);gh(17,1,{},wi);_.V=op;_.W=function(){return this.a<this.c.a.length};_.X=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=yh(17);gh(36,127,{3:1,36:1,197:1},Ci);var Ee=yh(36);gh(56,1,{},Ii);_.O=rp;_.P=function(){return new Ji(this)};_.b=0;var Ge=yh(56);gh(57,1,{},Ji);_.V=op;_.X=function(){return this.d=this.a[this.c++],this.d};_.W=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=yh(57);var Mi;gh(54,1,{},Wi);_.O=rp;_.P=function(){return new Xi(this)};_.b=0;_.c=0;var Je=yh(54);gh(55,1,{},Xi);_.V=op;_.X=function(){return this.c=this.a,this.a=this.b.next(),new Zi(this.d,this.c,this.d.c)};_.W=function(){return !this.a.done};var He=yh(55);gh(137,216,_o,Zi);_.Z=function(){return this.b.value[0]};_.$=function(){return Yi(this)};_._=function(a){return Ui(this.a,this.b.value[0],a)};_.c=0;var Ie=yh(137);gh(140,1,{});_.V=tp;_.ab=function(){return this.d};_.bb=sp;_.d=0;_.e=0;var Ne=yh(140);gh(59,140,{});var Ke=yh(59);gh(132,1,{});_.V=tp;_.ab=qp;_.bb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Me=yh(132);gh(133,132,{},hj);_.V=function(a){ej(this,a)};_.cb=function(a){return fj(this,a)};var Le=yh(133);gh(19,1,{},jj);_.ab=mp;_.bb=function(){ij(this);return this.c};_.V=function(a){ij(this);this.d.V(a)};_.cb=function(a){ij(this);if(this.d.W()){a.w(this.d.X());return true}return false};_.a=0;_.c=0;var Oe=yh(19);gh(51,1,{},lj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Pe=yh(51);gh(33,1,{},mj);_.Q=function(a){return a};var Qe=yh(33);gh(37,1,{},nj);var Re=yh(37);gh(139,1,{});_.c=false;var _e=yh(139);gh(23,139,{},xj);var $e=yh(23);gh(65,1,{},Aj);_.db=function(a){return _c(ie,Qo,1,a,5,1)};var Se=yh(65);gh(142,59,{},Cj);_.cb=function(a){this.b=false;while(!this.b&&this.c.cb(new Dj(this,a)));return this.b};_.b=false;var Ue=yh(142);gh(145,1,{},Dj);_.w=function(a){Bj(this.a,this.b,a)};var Te=yh(145);gh(141,59,{},Fj);_.cb=function(a){return this.b.cb(new Gj(this,a))};var We=yh(141);gh(144,1,{},Gj);_.w=function(a){Ej(this.a,this.b,a)};var Ve=yh(144);gh(143,1,{},Ij);_.w=function(a){Hj(this,a)};var Xe=yh(143);gh(146,1,{},Jj);_.w=function(a){};var Ye=yh(146);gh(147,1,{},Lj);_.w=function(a){Kj(this,a)};var Ze=yh(147);gh(279,1,{});gh(276,1,{});var Rj=0;var Tj,Uj=0,Vj;gh(896,1,{});gh(918,1,{});gh(217,1,{});var af=yh(217);gh(155,1,{},hk);_.db=function(a){return new Array(a)};var bf=yh(155);gh(244,$wnd.Function,{},ik);_.fb=function(a){gk(this.a,this.b,a)};gh(6,29,{3:1,27:1,29:1,6:1},Tk);var wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk;var cf=zh(6,Uk);var Vk;gh(245,$wnd.Function,{},Xk);_.H=function(a){return Eb(Vk),Vk=null,null};gh(220,217,{});var Lf=yh(220);gh(171,220,{});_.d=0;var Pf=yh(171);gh(172,171,Ro,cl);_.t=vp;_.o=up;_.q=np;_.u=wp;_.r=function(){var a;return uh(mf),mf.k+'@'+(a=Sj(this)>>>0,a.toString(16))};var _k=0;var mf=yh(172);gh(173,1,Uo,dl);_.v=function(){al(this.a)};var df=yh(173);gh(174,1,{},el);_.s=function(){return sh(),S((fn(),cn).b).a>0?true:false};var ef=yh(174);gh(175,1,{},fl);_.v=function(){Zk(this.a)};var ff=yh(175);gh(176,1,{},gl);_.s=function(){return $k(this.a)};var gf=yh(176);gh(221,217,{});var Kf=yh(221);gh(191,221,{});_.c=0;var Of=yh(191);gh(192,191,Ro,ll);_.t=xp;_.o=up;_.q=np;_.u=yp;_.r=function(){var a;return uh(lf),lf.k+'@'+(a=Sj(this)>>>0,a.toString(16))};var jl=0;var lf=yh(192);gh(193,1,Uo,ml);_.v=zp;var hf=yh(193);gh(194,1,{},nl);_.v=function(){il(this.a)};var jf=yh(194);gh(195,1,{},ol);_.s=function(){var a,b;return this.a.c=0,Wk(),a=S((fn(),cn).e).a,b='item'+(a==1?'':'s'),fk('span',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['todo-count'])),[fk('strong',null,[a]),' '+b+' left'])};var kf=yh(195);gh(163,217,{});_.e='';var Xf=yh(163);gh(164,163,{});_.d=0;var Rf=yh(164);gh(165,164,Ro,Al);_.t=vp;_.o=up;_.q=np;_.u=wp;_.r=function(){var a;return uh(sf),sf.k+'@'+(a=Sj(this)>>>0,a.toString(16))};var ul=0;var sf=yh(165);gh(166,1,Uo,Bl);_.v=function(){vl(this.a)};var nf=yh(166);gh(168,1,{},Cl);_.s=function(){return tl(this.a)};var of=yh(168);gh(169,1,Uo,Dl);_.v=function(){pl(this.a)};var pf=yh(169);gh(170,1,Uo,El);_.v=function(){xl(this.a,this.b)};var qf=yh(170);gh(167,1,{},Fl);_.v=function(){Zk(this.a)};var rf=yh(167);gh(219,217,{});_.i=false;var Zf=yh(219);gh(178,219,{});_.f=0;var Tf=yh(178);gh(179,178,Ro,$l);_.t=function(){jc(this.e)};_.o=up;_.q=np;_.u=function(){return this.e.i<0};_.r=function(){var a;return uh(Df),Df.k+'@'+(a=Sj(this)>>>0,a.toString(16))};var Pl=0;var Df=yh(179);gh(180,1,Uo,_l);_.v=function(){Ql(this.a)};var tf=yh(180);gh(183,1,{},am);_.s=function(){return Ol(this.a)};var uf=yh(183);gh(60,1,Uo,bm);_.v=function(){Zl(this.a,pn(this.b))};var vf=yh(60);gh(61,1,Uo,cm);_.v=function(){Jl(this.a,this.b)};var wf=yh(61);gh(184,1,Uo,dm);_.v=function(){Sl(this.a,this.b)};var xf=yh(184);gh(185,1,Uo,em);_.v=function(){Yl(this.a,this.b);uo((fn(),en),null)};var yf=yh(185);gh(181,1,{},fm);_.s=function(){return Tl(this.a)};var zf=yh(181);gh(186,1,Uo,gm);_.v=function(){Gl(this.a,this.b)};var Af=yh(186);gh(187,1,Uo,hm);_.v=function(){Kl(this.a)};var Bf=yh(187);gh(182,1,{},im);_.v=function(){Nl(this.a)};var Cf=yh(182);gh(218,217,{});var ag=yh(218);gh(149,218,{});_.c=0;var Vf=yh(149);gh(150,149,Ro,nm);_.t=xp;_.o=up;_.q=np;_.u=yp;_.r=function(){var a;return uh(Hf),Hf.k+'@'+(a=Sj(this)>>>0,a.toString(16))};var lm=0;var Hf=yh(150);gh(151,1,Uo,om);_.v=zp;var Ef=yh(151);gh(152,1,{},pm);_.v=function(){il(this.a)};var Ff=yh(152);gh(153,1,{},qm);_.s=function(){return this.a.c=0,Wk(),fk('div',null,[fk('div',null,[fk(hp,jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[hp])),[fk('h1',null,['todos']),(new Qm).a]),S((fn(),cn).d)?fk('section',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[hp])),[fk(gp,qk(tk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['toggle-all'])),(Sk(),xk)),ih($m.prototype.hb,$m,[])),null),fk('ul',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['todo-list'])),wj(uj(S(en.c).U(),new _m),new hk))]):null,S(cn.d)?(new sm).a:null])])};var Gf=yh(153);gh(249,$wnd.Function,{},rm);_.jb=function(a){fo((fn(),dn))};gh(157,1,{},sm);var If=yh(157);gh(177,1,{},tm);var Jf=yh(177);gh(250,$wnd.Function,{},um);_.kb=function(a){return new xm(a)};var vm;gh(161,$wnd.React.Component,{},xm);fh(dh[1],_);_.componentWillUnmount=function(){Yk(this.a)};_.render=function(){return bl(this.a)};_.shouldComponentUpdate=Ap;var Mf=yh(161);gh(260,$wnd.Function,{},ym);_.kb=function(a){return new Bm(a)};var zm;gh(188,$wnd.React.Component,{},Bm);fh(dh[1],_);_.componentWillUnmount=function(){hl(this.a)};_.render=function(){return kl(this.a)};_.shouldComponentUpdate=Bp;var Nf=yh(188);gh(248,$wnd.Function,{},Cm);_.kb=function(a){return new Fm(a)};var Dm;gh(160,$wnd.React.Component,{},Fm);fh(dh[1],_);_.componentWillUnmount=function(){Yk(this.a)};_.render=function(){return yl(this.a)};_.shouldComponentUpdate=Ap;var Qf=yh(160);gh(251,$wnd.Function,{},Gm);_.kb=function(a){return new Jm(a)};var Hm;gh(162,$wnd.React.Component,{},Jm);fh(dh[1],_);_.componentDidUpdate=function(a){Wl(this.a)};_.componentWillUnmount=function(){Ml(this.a)};_.render=function(){return Xl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Sf=yh(162);gh(242,$wnd.Function,{},Km);_.kb=function(a){return new Nm(a)};var Lm;gh(134,$wnd.React.Component,{},Nm);fh(dh[1],_);_.componentWillUnmount=function(){hl(this.a)};_.render=function(){return mm(this.a)};_.shouldComponentUpdate=Bp;var Uf=yh(134);gh(246,$wnd.Function,{},Om);_.ib=function(a){ql(this.a,a)};gh(247,$wnd.Function,{},Pm);_.hb=function(a){wl(this.a,a)};gh(156,1,{},Qm);var Wf=yh(156);gh(258,$wnd.Function,{},Rm);_.hb=function(a){Rl(this.a,a)};gh(252,$wnd.Function,{},Sm);_.hb=function(a){Kn(this.a)};gh(254,$wnd.Function,{},Tm);_.jb=function(a){Ul(this.a,this.b)};gh(255,$wnd.Function,{},Um);_.jb=function(a){Ll(this.a)};gh(256,$wnd.Function,{},Vm);_.w=function(a){Hl(this.a,a)};gh(257,$wnd.Function,{},Wm);_.gb=function(a){Vl(this.a,this.b)};gh(259,$wnd.Function,{},Xm);_.ib=function(a){Il(this.a,this.b,a)};gh(159,1,{},Zm);var Yf=yh(159);gh(241,$wnd.Function,{},$m);_.hb=function(a){var b;b=a.target;jo((fn(),dn),b.checked)};gh(135,1,{},_m);_.Q=function(a){return Ym(new Zm,a)};var $f=yh(135);gh(63,1,{},an);var _f=yh(63);var bn,cn,dn,en;gh(92,1,{});var Gg=yh(92);gh(93,92,Ro,tn);_.t=vp;_.o=up;_.q=np;_.u=wp;_.r=function(){var a;return uh(ig),ig.k+'@'+(a=Sj(this)>>>0,a.toString(16))};var ig=yh(93);gh(94,1,Uo,un);_.v=function(){nn(this.a)};var bg=yh(94);gh(96,1,{},vn);_.v=function(){hn(this.a)};var cg=yh(96);gh(97,1,{},wn);_.v=function(){jn(this.a)};var dg=yh(97);gh(98,1,Uo,xn);_.v=function(){gn(this.a,this.b)};var eg=yh(98);gh(99,1,Uo,yn);_.v=function(){qn(this.a)};var fg=yh(99);gh(53,1,Uo,zn);_.v=function(){mn(this.a)};var gg=yh(53);gh(95,1,{},An);_.s=function(){var a;return a=(oh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var hg=yh(95);gh(44,1,{44:1});_.d=false;var Og=yh(44);gh(45,44,{9:1,243:1,45:1,44:1},Ln);_.t=vp;_.o=function(a){return En(this,a)};_.q=function(){return this.c.d};_.u=wp;_.r=function(){var a;return uh(yg),yg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Bn=0;var yg=yh(45);gh(189,1,Uo,Mn);_.v=function(){Cn(this.a)};var jg=yh(189);gh(190,1,Uo,Nn);_.v=function(){Hn(this.a)};var kg=yh(190);gh(110,109,{});var Jg=yh(110);gh(111,110,Ro,Vn);_.t=Cp;_.o=up;_.q=np;_.u=Dp;_.r=function(){var a;return uh(tg),tg.k+'@'+(a=Sj(this)>>>0,a.toString(16))};var tg=yh(111);gh(113,1,Uo,Wn);_.v=function(){Pn(this.a)};var lg=yh(113);gh(112,1,Uo,Xn);_.v=function(){Sn(this.a)};var mg=yh(112);gh(118,1,Uo,Yn);_.v=function(){bc(this.a,this.b,true)};var ng=yh(118);gh(119,1,{},Zn);_.s=function(){return On(this.a,this.c,this.b)};_.b=false;var og=yh(119);gh(114,1,{},$n);_.s=function(){return Tn(this.a)};var pg=yh(114);gh(115,1,{},_n);_.s=function(){return Jh(Yg(sj(cc(this.a))))};var qg=yh(115);gh(116,1,{},ao);_.s=function(){return Jh(Yg(sj(tj(cc(this.a),new Io))))};var rg=yh(116);gh(117,1,{},bo);_.s=function(){return Un(this.a)};var sg=yh(117);gh(86,1,{});var Ng=yh(86);gh(87,86,Ro,ko);_.t=function(){jc(this.a)};_.o=up;_.q=np;_.u=function(){return this.a.i<0};_.r=function(){var a;return uh(xg),xg.k+'@'+(a=Sj(this)>>>0,a.toString(16))};var xg=yh(87);gh(88,1,Uo,lo);_.v=function(){go(this.a,this.b)};_.b=false;var ug=yh(88);gh(89,1,Uo,mo);_.v=function(){zl(this.b,this.a)};var vg=yh(89);gh(90,1,Uo,no);_.v=function(){ho(this.a)};var wg=yh(90);gh(100,1,{});var Qg=yh(100);gh(101,100,Ro,vo);_.t=Cp;_.o=up;_.q=np;_.u=Dp;_.r=function(){var a;return uh(Eg),Eg.k+'@'+(a=Sj(this)>>>0,a.toString(16))};var Eg=yh(101);gh(102,1,Uo,wo);_.v=function(){qo(this.a)};var zg=yh(102);gh(106,1,Uo,xo);_.v=function(){uo(this.a,null)};var Ag=yh(106);gh(103,1,{},yo);_.s=function(){var a;return a=pn(this.a.g),o(kp,a)?(Fo(),Co):o(lp,a)?(Fo(),Eo):(Fo(),Do)};var Bg=yh(103);gh(104,1,{},zo);_.s=function(){return so(this.a)};var Cg=yh(104);gh(105,1,{},Ao);_.v=function(){to(this.a)};var Dg=yh(105);gh(91,1,{},Bo);_.handleEvent=function(a){kn(this.a,a)};var Fg=yh(91);gh(30,29,{3:1,27:1,29:1,30:1},Go);var Co,Do,Eo;var Hg=zh(30,Ho);gh(80,1,{},Io);_.eb=function(a){return !Gn(a)};var Ig=yh(80);gh(84,1,{},Jo);_.eb=function(a){return Gn(a)};var Kg=yh(84);gh(85,1,{},Ko);_.w=function(a){Rn(this.a,a)};var Lg=yh(85);gh(83,1,{},Lo);_.w=function(a){eo(this.a,a)};_.a=false;var Mg=yh(83);gh(76,1,{},Mo);_.eb=function(a){return po(this.a,a)};var Pg=yh(76);var sd=Ah('D');var No=(Ec(),Hc);var gwtOnLoad=gwtOnLoad=ah;$g(mh);bh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();