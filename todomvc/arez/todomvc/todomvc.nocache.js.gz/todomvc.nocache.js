function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='04FEB954AE2FB42FBA83FD653D6A6906',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '04FEB954AE2FB42FBA83FD653D6A6906';function p(){}
function kh(){}
function gh(){}
function Sh(){}
function Fb(){}
function Pc(){}
function Wc(){}
function Wk(){}
function gk(){}
function lj(){}
function zj(){}
function Hj(){}
function Ij(){}
function dl(){}
function qm(){}
function tm(){}
function xm(){}
function Bm(){}
function Fm(){}
function Jm(){}
function Zm(){}
function $m(){}
function zn(){}
function Ko(){}
function Lo(){}
function Uc(a){Tc()}
function rh(){rh=gh}
function ti(){ki(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function ec(a){this.a=a}
function nc(a){this.a=a}
function Hh(a){this.a=a}
function Rh(a){this.a=a}
function ci(a){this.a=a}
function hi(a){this.a=a}
function ii(a){this.a=a}
function gi(a){this.b=a}
function vi(a){this.c=a}
function mj(a){this.a=a}
function Kj(a){this.a=a}
function cl(a){this.a=a}
function el(a){this.a=a}
function fl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function Al(a){this.a=a}
function Bl(a){this.a=a}
function Cl(a){this.a=a}
function El(a){this.a=a}
function $l(a){this.a=a}
function _l(a){this.a=a}
function em(a){this.a=a}
function gm(a){this.a=a}
function hm(a){this.a=a}
function nm(a){this.a=a}
function om(a){this.a=a}
function pm(a){this.a=a}
function Nm(a){this.a=a}
function Om(a){this.a=a}
function Qm(a){this.a=a}
function Rm(a){this.a=a}
function Tm(a){this.a=a}
function Um(a){this.a=a}
function tn(a){this.a=a}
function un(a){this.a=a}
function vn(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function Ln(a){this.a=a}
function Mn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function no(a){this.a=a}
function xo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Gj(a,b){a.a=b}
function qb(a,b){a.b=b}
function _j(a,b){a.key=b}
function $j(a,b){Zj(a,b)}
function eo(a,b){Yl(b,a)}
function Y(a){!!a&&$(a)}
function ic(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function wp(a){aj(this,a)}
function rp(a){Zi(this,a)}
function up(a){Lh(this,a)}
function yp(){hc(this.c)}
function Ap(){hc(this.b)}
function Gp(){hc(this.f)}
function Hi(){this.a=Qi()}
function Vi(){this.a=Qi()}
function Cp(){kb(this.a.a)}
function db(a){Xb((J(),a))}
function eb(a){Yb((J(),a))}
function hb(a){Zb((J(),a))}
function Sg(a){return a.e}
function vp(){return this.e}
function pp(){return this.a}
function tp(){return this.b}
function Fp(a){lc(this.c,a)}
function lc(a,b){$h(a.e,b)}
function Jj(a,b){yj(a.a,b)}
function co(a,b){Pn(a.b,b)}
function C(a,b){Nb(a.f,b.f)}
function K(a,b){O(a);L(a,b)}
function mn(a){R(a.a);$(a.b)}
function Bn(a){$(a.b);$(a.a)}
function _k(a){kb(a.b);R(a.a)}
function ul(a){kb(a.a);$(a.b)}
function gl(a){a.c=2;hc(a.b)}
function Ll(a){a.f=2;hc(a.e)}
function Xk(a){a.d=2;hc(a.c)}
function qc(a,b){a.e=b;pc(a,b)}
function gc(a,b,c){Zh(a.e,b,c)}
function fj(a,b,c){b.w(a.a[c])}
function ni(a,b){return a.a[b]}
function Gl(a,b){return a.g=b}
function qp(){return Rj(this)}
function xp(a){return this===a}
function qh(a){tc.call(this,a)}
function Th(a){tc.call(this,a)}
function Kl(a){Qn((en(),bn),a)}
function Oj(a,b){a.splice(b,1)}
function Cn(a,b,c){gc(a.c,b,c)}
function Cc(){Cc=gh;!!(Tc(),Sc)}
function vc(){vc=gh;uc=new p}
function Mc(){Mc=gh;Lc=new Pc}
function J(){J=gh;I=new F}
function Mi(){Mi=gh;Li=Oi()}
function sp(){return ai(this.a)}
function zp(){return this.c.i<0}
function Bp(){return this.b.i<0}
function Hp(){return this.f.i<0}
function Xc(a,b){return Ah(a,b)}
function yj(a,b){Gj(a,xj(a.a,b))}
function aj(a,b){while(a.db(b));}
function Dj(a,b,c){b.w(a.a.R(c))}
function v(a,b,c){t(a,new H(c),b)}
function uh(a){th(a);return a.k}
function on(a){fb(a.b);return a.e}
function Fn(a){fb(a.a);return a.d}
function so(a){fb(a.d);return a.e}
function T(a){mb(a.f);return V(a)}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function ab(a){J();Yb(a);a.e=-2}
function Qi(){Mi();return new Li}
function xj(a,b){a.S(b);return a}
function jk(a,b){a.ref=b;return a}
function ji(a,b){this.a=a;this.b=b}
function fc(a,b){this.a=a;this.b=b}
function Fh(a,b){this.a=a;this.b=b}
function Fj(a,b){this.a=a;this.b=b}
function Cj(a,b){this.a=a;this.b=b}
function hk(a,b){this.a=a;this.b=b}
function Db(a){this.d=a;this.b=100}
function Dl(a,b){this.a=a;this.b=b}
function am(a,b){this.a=a;this.b=b}
function bm(a,b){this.a=a;this.b=b}
function cm(a,b){this.a=a;this.b=b}
function dm(a,b){this.a=a;this.b=b}
function fm(a,b){this.a=a;this.b=b}
function Sk(a,b){Fh.call(this,a,b)}
function Si(a,b){return a.a.get(b)}
function ai(a){return a.a.b+a.b.b}
function Dp(a){return 1==this.a.d}
function Ep(a){return 1==this.a.c}
function Sm(a,b){this.a=a;this.b=b}
function Vm(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function rm(){this.a=ak((vm(),um))}
function sm(){this.a=ak((zm(),ym))}
function Pm(){this.a=ak((Dm(),Cm))}
function Ym(){this.a=ak((Hm(),Gm))}
function _m(){this.a=ak((Lm(),Km))}
function wn(a,b){this.a=a;this.b=b}
function Yn(a,b){this.a=a;this.b=b}
function lo(a,b){this.a=a;this.b=b}
function mo(a,b){this.b=a;this.a=b}
function Io(a,b){Fh.call(this,a,b)}
function Mj(a,b,c){a.splice(b,0,c)}
function tk(a,b){a.value=b;return a}
function kk(a,b){a.href=b;return a}
function Ph(a,b){a.a+=''+b;return a}
function $g(){Yg==null&&(Yg=[])}
function Kc(){zc!=0&&(zc=0);Bc=-1}
function pn(a){nn(a,(fb(a.b),a.e))}
function Gn(a){Yl(a,(fb(a.a),!a.d))}
function Tb(a){return !a.d?a:Tb(a.d)}
function Yh(a){return !a?null:a._()}
function od(a){return a==null?null:a}
function _i(a){return a!=null?s(a):0}
function ld(a){return typeof a===Ro}
function o(a,b){return od(a)===od(b)}
function ok(a,b){a.onBlur=b;return a}
function lk(a,b){a.onClick=b;return a}
function nk(a,b){a.checked=b;return a}
function Jc(a){$wnd.clearTimeout(a)}
function ki(a){a.a=Zc(ge,So,1,0,5,1)}
function _h(a){a.a=new Hi;a.b=new Vi}
function ib(a){this.c=new ti;this.b=a}
function Vj(){Vj=gh;Sj=new p;Uj=new p}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function Pl(a){kb(a.b);R(a.c);$(a.a)}
function dc(a,b){bc(a,b,false);eb(a.c)}
function cc(a,b){b.A(a);jd(b,9)&&b.t()}
function Nj(a,b){Lj(b,0,a,0,b.length)}
function Zj(a,b){for(var c in a){b(c)}}
function bd(a,b,c){return {l:a,m:b,h:c}}
function Mh(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function Rj(a){return a.$H||(a.$H=++Qj)}
function nd(a){return typeof a==='string'}
function qk(a,b){a.onKeyDown=b;return a}
function pk(a,b){a.onChange=b;return a}
function mk(a){a.autoFocus=true;return a}
function th(a){if(a.k!=null){return}Ch(a)}
function pb(a){J();ob(a);sb(a,2,true)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function ro(a){var b;b=a.e;!!b&&lc(b.c,a)}
function Ji(a,b){var c;c=a[cp];c.call(a,b)}
function wj(a,b){pj.call(this,a);this.a=b}
function tc(a){this.g=a;oc(this);this.G()}
function Bi(){this.a=new Hi;this.b=new Vi}
function P(){this.a=Zc(ge,So,1,100,5,1)}
function Kh(){Kh=gh;Jh=Zc(de,So,28,256,0,1)}
function Vl(a){A((J(),J(),I),new gm(a),hp)}
function qn(a){A((J(),J(),I),new xn(a),hp)}
function Jn(a){A((J(),J(),I),new Mn(a),hp)}
function fo(a){A((J(),J(),I),new no(a),hp)}
function qo(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function Un(a){return Ih(S(a.e).a-S(a.a).a)}
function kd(a){return typeof a==='boolean'}
function Dc(a,b,c){return a.apply(b,c);var d}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function oh(a,b,c,d){a.addEventListener(b,c,d)}
function Yi(a,b,c){this.a=a;this.b=b;this.c=c}
function Zi(a,b){while(a.X()){Jj(b,a.Y())}}
function dj(a,b){while(a.c<a.d){fj(a,b,a.c++)}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function uk(a,b){a.onDoubleClick=b;return a}
function li(a,b){a.a[a.a.length]=b;return true}
function oc(a){a.j&&a.e!==Zo&&a.G();return a}
function xh(a){var b;b=wh(a);Eh(a,b);return b}
function Tc(){Tc=gh;var a;!Vc();a=new Wc;Sc=a}
function wl(a,b){var c;c=b.target;yl(a,c.value)}
function vl(a,b){A((J(),J(),I),new Dl(a,b),hp)}
function Ql(a,b){A((J(),J(),I),new fm(a,b),hp)}
function Tl(a,b){A((J(),J(),I),new cm(a,b),hp)}
function Ul(a,b){A((J(),J(),I),new bm(a,b),hp)}
function Xl(a,b){A((J(),J(),I),new am(a,b),hp)}
function Qn(a,b){A((J(),J(),I),new Yn(a,b),hp)}
function io(a,b){A((J(),J(),I),new mo(a,b),hp)}
function jo(a,b){A((J(),J(),I),new lo(a,b),hp)}
function Sn(a){Lh(new hi(a.g),new ec(a));_h(a.g)}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function Zn(a,b){this.a=a;this.c=b;this.b=false}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function hj(a){if(!a.d){a.d=a.b.Q();a.c=a.b.T()}}
function Aj(a,b,c){if(a.a.fb(c)){a.b=true;b.w(c)}}
function ph(a,b,c,d){a.removeEventListener(b,c,d)}
function qj(a,b){var c;return uj(a,(c=new ti,c))}
function Ri(a,b){return !(a.a.get(b)===undefined)}
function oo(a){return o(np,a)||o(op,a)||o('',a)}
function _c(a){return Array.isArray(a)&&a.ob===kh}
function hd(a){return !Array.isArray(a)&&a.ob===kh}
function xi(a){return new wj(null,wi(a,a.length))}
function Tn(a){return rh(),0!=S(a.e).a?true:false}
function al(a){return B((J(),J(),I),a.b,new fl(a))}
function wi(a,b){return bj(b,a.length),new gj(a,b)}
function jl(a){return B((J(),J(),I),a.a,new nl(a))}
function xl(a){return B((J(),J(),I),a.a,new Bl(a))}
function On(a){R(a.d);R(a.e);R(a.a);R(a.b);$(a.c)}
function ei(a){var b;b=a.a.Y();a.b=di(a);return b}
function zh(a){var b;b=wh(a);b.j=a;b.e=1;return b}
function pi(a,b){var c;c=a.a[b];Oj(a.a,b);return c}
function ri(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Qc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Wl(a){return B((J(),J(),I),a.b,new _l(a))}
function lm(a){return B((J(),J(),I),a.a,new pm(a))}
function bi(a,b){if(b){return Wh(a.a,b)}return false}
function nn(a,b){A((J(),J(),I),new wn(a,b),75497472)}
function yl(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function Yl(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function Yk(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function hl(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function Ml(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function nj(a){if(!a.b){oj(a);a.c=true}else{nj(a.b)}}
function sj(a,b){oj(a);return new wj(a,new Bj(b,a.a))}
function tj(a,b){oj(a);return new wj(a,new Ej(b,a.a))}
function Xg(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function Yj(){if(Tj==256){Sj=Uj;Uj=new p;Tj=0}++Tj}
function pj(a){if(!a){this.b=null;new ti}else{this.b=a}}
function gj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function cj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function ij(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function sk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function yh(a,b){var c;c=wh(a);Eh(a,c);c.e=b?8:0;return c}
function ln(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&yl(a,b)}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Xo)&&D((null,I))}
function go(a,b){qj(Rn(a.b),new mj(new lj)).P(new No(b))}
function Ai(a,b){return od(a)===od(b)||a!=null&&q(a,b)}
function Xh(a,b){return b===a?'(this Map)':b==null?_o:jh(b)}
function rc(a,b){var c;c=uh(a.mb);return b==null?c:c+': '+b}
function Fl(a,b){var c;if(S(a.c)){c=b.target;Yl(a,c.value)}}
function Lh(a,b){var c,d;for(d=a.Q();d.X();){c=d.Y();b.w(c)}}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function Bh(a){if(a.O()){return null}var b=a.j;return bh[b]}
function ih(a){function b(){}
;b.prototype=a||{};return new b}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function nh(){nh=gh;mh=$wnd.goog.global.document}
function vm(){vm=gh;var a;um=(a=hh(tm.prototype.lb,tm,[]),a)}
function zm(){zm=gh;var a;ym=(a=hh(xm.prototype.lb,xm,[]),a)}
function Dm(){Dm=gh;var a;Cm=(a=hh(Bm.prototype.lb,Bm,[]),a)}
function Hm(){Hm=gh;var a;Gm=(a=hh(Fm.prototype.lb,Fm,[]),a)}
function Lm(){Lm=gh;var a;Km=(a=hh(Jm.prototype.lb,Jm,[]),a)}
function Jo(){Ho();return ad(Xc(Gg,1),So,30,0,[Eo,Go,Fo])}
function Rl(a,b){vo((en(),dn),b);A((J(),J(),I),new am(a,b),hp)}
function jn(a,b){b.preventDefault();A((J(),J(),I),new yn(a),hp)}
function Di(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ah(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function eh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Ei(a,b){var c;return Ci(b,Di(a,b==null?0:(c=s(b),c|0)))}
function Rn(a){fb(a.c);return new wj(null,new ij(new hi(a.g),0))}
function oj(a){if(a.b){oj(a.b)}else if(a.c){throw Sg(new Gh)}}
function Ic(a){Cc();$wnd.setTimeout(function(){throw a},0)}
function gn(a){oh((nh(),$wnd.goog.global.window),kp,a.d,false)}
function hn(a){ph((nh(),$wnd.goog.global.window),kp,a.d,false)}
function ko(a){this.b=a;J();this.a=new mc(0,null,null,true,false)}
function ui(a){ki(this);Nj(this.a,Vh(a,Zc(ge,So,1,ai(a.a),5,1)))}
function Ii(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Ej(a,b){cj.call(this,b.cb(),b.bb()&-6);this.a=a;this.b=b}
function ej(a,b){if(a.c<a.d){fj(a,b,a.c++);return true}return false}
function rk(a){a.placeholder='What needs to be done?';return a}
function sc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function kc(a){ic(a.g);!!a.e&&jc(a);Y(a.a);Y(a.c);ic(a.b);ic(a.f)}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Hc(a){a&&Oc((Mc(),Lc));--zc;if(a){if(Bc!=-1){Jc(Bc);Bc=-1}}}
function Gc(a,b,c){var d;d=Ec();try{return Dc(a,b,c)}finally{Hc(d)}}
function bb(a,b){var c,d;li(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Bj(a,b){cj.call(this,b.cb(),b.bb()&-16449);this.a=a;this.c=b}
function wm(a){$wnd.React.Component.call(this,a);this.a=new bl(this)}
function Am(a){$wnd.React.Component.call(this,a);this.a=new kl(this)}
function Em(a){$wnd.React.Component.call(this,a);this.a=new zl(this)}
function Im(a){$wnd.React.Component.call(this,a);this.a=new Zl(this)}
function Mm(a){$wnd.React.Component.call(this,a);this.a=new mm(this)}
function Wi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function ho(a){qj(sj(Rn(a.b),new Lo),new mj(new lj)).P(new Mo(a.b))}
function en(){en=gh;bn=new Vn;cn=new ko(bn);an=new sn;dn=new wo(bn,an)}
function Pn(a,b){var c;return u((J(),J(),I),new Zn(a,b),hp,(c=null,c))}
function uj(a,b){var c;nj(a);c=new Hj;c.a=b;a.a.W(new Kj(c));return c.a}
function rj(a){var b;nj(a);b=0;while(a.a.db(new Ij)){b=Tg(b,1)}return b}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function jj(a,b){!a.a?(a.a=new Rh(a.d)):Ph(a.a,a.b);Ph(a.a,b);return a}
function $h(a,b){return nd(b)?b==null?Gi(a.a,null):Ui(a.b,b):Gi(a.a,b)}
function po(a,b){return (Ho(),Fo)==a||(Eo==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function Sl(a){return rh(),so((en(),dn))==a.j.props['a']?true:false}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ib(b){try{mb(b.b.a)}catch(a){a=Rg(a);if(!jd(a,4))throw Sg(a)}}
function Fc(b){Cc();return function(){return Gc(b,this,arguments);var a}}
function yc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Xi(a){if(a.a.c!=a.c){return Si(a.a,a.b.value[0])}return a.b.value[1]}
function fi(a){this.d=a;this.c=new Wi(this.d.b);this.a=this.c;this.b=di(this)}
function kj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function fk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function oi(a,b,c){for(;c<a.a.length;++c){if(Ai(b,a.a[c])){return c}}return -1}
function Zc(a,b,c,d,e,f){var g;g=$c(e,d);e!=10&&ad(Xc(a,f),b,c,e,g);return g}
function Dn(a,b){var c;if(jd(b,44)){c=b;return a.c.d==c.c.d}else{return false}}
function qi(a,b){var c;c=oi(a,b,0);if(c==-1){return false}Oj(a.a,c);return true}
function vj(a,b){var c;c=qj(a,new mj(new lj));return si(c,b.eb(c.a.length))}
function mi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Ob(){var a;this.a=Zc(ud,So,42,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function to(a){var b;return b=S(a.b),qj(sj(Rn(a.i),new Oo(b)),new mj(new lj))}
function dk(a){var b;return bk($wnd.React.StrictMode,null,null,(b={},b[dp]=a,b))}
function Zh(a,b,c){return nd(b)?b==null?Fi(a.a,null,c):Ti(a.b,b,c):Fi(a.a,b,c)}
function Pj(a,b){return Yc(b)!=10&&ad(r(b),b.nb,b.__elementTypeId$,Yc(b),a),a}
function Yc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function hc(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new nc(a)),67108864,null)}}
function fn(a,b){a.f=b;o(b,S(a.a))&&yl(a,b);kn(b);A((J(),J(),I),new yn(a),hp)}
function pl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Cl(a),hp)}}
function ol(a){var b;b=Oh((fb(a.b),a.e));if(b.length>0){co((en(),cn),b);yl(a,'')}}
function Oc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Rc(b,c)}while(a.b);a.b=c}}
function Nc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Rc(b,c)}while(a.a);a.a=c}}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new ti);li(a.b,b)}}}
function Eh(a,b){var c;if(!a){return}b.j=a;var d=Bh(b);if(!d){bh[a]=[b];return}d.mb=b}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new ti);a.c=c.c}b.d=true;li(a.c,b)}
function wh(a){var b;b=new vh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function V(a){if(a.b){if(jd(a.b,8)){throw Sg(a.b)}else{throw Sg(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=Rg(a);if(jd(a,4)){J()}else throw Sg(a)}}}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function md(a){return a!=null&&(typeof a===Qo||typeof a==='function')&&!(a.ob===kh)}
function ah(a,b){typeof window===Qo&&typeof window['$gwt']===Qo&&(window['$gwt'][a]=b)}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Yo:0)|(0!=(b&229376)?0:98304)}
function Gh(){tc.call(this,"Stream already terminated, can't be modified or used")}
function Zg(){$g();var a=Yg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ob(a){var b,c;for(c=new vi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function yi(a){var b,c,d;d=0;for(c=new fi(a.a);c.b;){b=ei(c);d=d+(b?s(b):0);d=d|0}return d}
function Uh(a,b){var c,d;for(d=new fi(b.a);d.b;){c=ei(d);if(!bi(a,c)){return false}}return true}
function Ui(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ji(a.a,b);--a.b}return c}
function Nn(a,b,c){var d;d=new Kn(b,c);Cn(d,a,new fc(a,d));Zh(a.g,Ih(d.c.d),d);eb(a.c);return d}
function hh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function bk(a,b,c,d){var e;e=ck($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function ak(a){var b;b=ck($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Ug(a){var b;b=a.h;if(b==0){return a.l+a.m*Yo}if(b==1048575){return a.l+a.m*Yo-ap}return a}
function Rg(a){var b;if(jd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new xc(a);Uc(b)}return b}
function di(a){if(a.a.X()){return true}if(a.a!=a.c){return false}a.a=new Ii(a.d.a);return a.a.X()}
function Xm(a,b){_j(a.a,(th(Xf),Xf.k+(''+(b?Ih(b.c.d):null))));a.a.props['a']=b;return a.a}
function bc(a,b,c){var d;d=$h(a.g,b?Ih(b.c.d):null);if(null!=d){lc(b.c,a);c&&!!b&&hc(b.c);eb(a.c)}}
function Ti(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ad(a,b,c,d,e){e.mb=a;e.nb=b;e.ob=kh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ci(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ai(a,c.$())){return c}}return null}
function Wg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=ap;d=1048575}c=pd(e/Yo);b=pd(e-c*Yo);return bd(b,c,d)}
function uo(a){var b;b=S(a.g.a);o(np,b)||o(op,b)||o('',b)?nn(a.g,b):oo(on(a.g))?qn(a.g):nn(a.g,'')}
function Ho(){Ho=gh;Eo=new Io('ACTIVE',0);Go=new Io('COMPLETED',1);Fo=new Io('ALL',2)}
function lh(){en();$wnd.ReactDOM.render(dk([(new _m).a]),(nh(),mh).getElementById('app'),null)}
function bj(a,b){if(0>a||a>b){throw Sg(new qh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:Uo)|(0==(c&6291456)?!a?Xo:Yo:0)|0|0|0)}
function Hl(a,b,c){27==c.which?A((J(),J(),I),new dm(a,b),hp):13==c.which&&A((J(),J(),I),new bm(a,b),hp)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function Vk(){if(!Uk){Uk=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(hh(Wk.prototype.I,Wk,[]))}}
function xc(a){vc();oc(this);this.e=a;pc(this,a);this.g=a==null?_o:jh(a);this.a='';this.b=a;this.a=''}
function vh(){this.g=sh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function vo(a,b){var c;c=a.e;if(!(b==c||!!b&&Dn(b,c))){!!c&&lc(c.c,a);a.e=b;!!b&&Cn(b,a,new Bo(a));eb(a.d)}}
function cb(a,b){var c,d;d=a.c;qi(d,b);!!a.b&&Uo!=(a.b.c&Vo)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function Il(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){io((en(),b),c);vo(dn,null);Yl(a,c)}else{Qn((en(),bn),b)}}
function Jl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Xl(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Ih(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Kh(),Jh)[b];!c&&(c=Jh[b]=new Hh(a));return c}return new Hh(a)}
function jh(a){var b;if(Array.isArray(a)&&a.ob===kh){return uh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function Xj(a){Vj();var b,c,d;c=':'+a;d=Uj[c];if(d!=null){return pd(d)}d=Sj[c];b=d==null?Wj(a):pd(d);Yj();Uj[c]=b;return b}
function zi(a){var b,c,d;d=1;for(c=new vi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=pi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function kl(a){var b;this.j=a;J();b=++il;this.b=new mc(b,null,new ll(this),false,false);this.a=new vb(null,new ml(this),gp)}
function mm(a){var b;this.j=a;J();b=++km;this.b=new mc(b,null,new nm(this),false,false);this.a=new vb(null,new om(this),gp)}
function r(a){return nd(a)?je:ld(a)?$d:kd(a)?Yd:hd(a)?a.mb:_c(a)?a.mb:a.mb||Array.isArray(a)&&Xc(Qd,1)||Qd}
function s(a){return nd(a)?Xj(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.q():_c(a)?Rj(a):!!a&&!!a.hashCode?a.hashCode():Rj(a)}
function q(a,b){return nd(a)?o(a,b):ld(a)?od(a)===od(b):kd(a)?od(a)===od(b):hd(a)?a.o(b):_c(a)?o(a,b):!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function Tk(){Rk();return ad(Xc(af,1),So,6,0,[vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk])}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Uo)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(Uo==(b&Vo)?0:524288)|(0==(b&6291456)?Uo==(b&Vo)?Yo:Xo:0)|0|268435456|0)}
function Tg(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<ap){return c}}return Ug(cd(ld(a)?Wg(a):a,ld(b)?Wg(b):b))}
function Dh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function si(a,b){var c,d;d=a.a.length;b.length<d&&(b=Pj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Ec(){var a;if(zc!=0){a=yc();if(a-Ac>2000){Ac=a;Bc=$wnd.setTimeout(Kc,10)}}if(zc++==0){Nc((Mc(),Lc));return true}return false}
function Vc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function jc(a){var b,c,d;for(c=new vi(new ui(new ci(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.$();jd(d,9)&&d.u()||b._().v()}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new vi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new vi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new vi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.nb){return !!a.nb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function mc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Bi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function zl(a){var b,c,d;this.j=a;J();b=++tl;this.c=new mc(b,null,new Al(this),false,false);this.b=(d=new ib((c=null,c)),d);this.a=new vb(null,new El(this),gp)}
function bl(a){var b;this.j=a;J();b=++$k;this.c=new mc(b,null,new cl(this),false,false);this.a=new W(new dl,null,null,136478720);this.b=new vb(null,new el(this),gp)}
function ik(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Oh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Vh(a,b){var c,d,e,f;f=ai(a.a);b.length<f&&(b=Pj(new Array(f),b));e=b;d=new fi(a.a);for(c=0;c<f;++c){e[c]=ei(d)}b.length>f&&(b[f]=null);return b}
function $c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=Rg(a);if(jd(a,4)){e=a;throw Sg(e)}else throw Sg(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=Rg(a);if(jd(a,4)){f=a;throw Sg(f)}else throw Sg(a)}finally{D(b)}}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function _g(b,c,d,e){$g();var f=Yg;$moduleName=c;$moduleBase=d;Qg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Po(g)()}catch(a){b(c,a)}}else{Po(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);Uo==(d&Vo)&&lb(this.f)}
function ck(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Kn(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++An;this.c=new mc(c,null,new Ln(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Oi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Pi()}}
function dh(){bh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Rc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].pb()&&(c=Qc(c,g)):g[0].pb()}catch(a){a=Rg(a);if(jd(a,4)){d=a;Cc();Ic(jd(d,34)?d.H():d)}else throw Sg(a)}}return c}
function sl(a){var b;a.d=0;Vk();b=ek(ip,mk(pk(qk(tk(rk(ik(new $wnd.Object,ad(Xc(je,1),So,2,6,['new-todo']))),(fb(a.b),a.e)),hh(Nm.prototype.jb,Nm,[a])),hh(Om.prototype.ib,Om,[a]))),null);return b}
function wc(a){var b;if(a.c==null){b=od(a.b)===od(uc)?null:a.b;a.d=b==null?_o:md(b)?b==null?null:b.name:nd(b)?'String':uh(r(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(od(e)===od(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=Rg(a);if(jd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw Sg(c)}else throw Sg(a)}}
function Lj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Fi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ci(b,e);if(f){return f.ab(c)}}e[e.length]=new ji(b,c);++a.b;return null}
function Wj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Mh(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Rg(a);if(jd(a,4)){J()}else throw Sg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Zc(ge,So,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function ub(a,b,c,d){this.b=new ti;this.f=new Jb(new yb(this),d&6520832|262144|Uo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Xo)&&D((null,I)))}
function Gi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ai(b,e.$())){if(d.length==1){d.length=0;Ji(a.a,g)}else{d.splice(h,1)}--a.b;return e._()}}return null}
function Zl(a){var b,c,d;this.j=a;J();b=++Ol;this.e=new mc(b,null,new $l(this),false,false);this.a=(d=new ib((c=null,c)),d);this.c=new W(new em(this),null,null,136478720);this.b=new vb(null,new hm(this),gp);Xl(this,this.j.props['a'])}
function fh(a,b,c){var d=bh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=bh[b]),ih(h));_.nb=c;!b&&(_.ob=kh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.mb=f)}
function Ch(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Dh('.',[c,Dh('$',d)]);a.b=Dh('.',[c,Dh('.',d)]);a.i=d[d.length-1]}
function Wh(a,b){var c,d,e;c=b.$();e=b._();d=nd(c)?c==null?Yh(Ei(a.a,null)):Si(a.b,c):Yh(Ei(a.a,c));if(!(od(e)===od(d)||e!=null&&q(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!Ei(a.a,null):Ri(a.b,c):!!Ei(a.a,c))){return false}return true}
function kn(a){var b;if(0==a.length){b=(nh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',mh.title,b)}else{(nh(),$wnd.goog.global.window).location.hash=a}}
function ek(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;$j(b,hh(hk.prototype.gb,hk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[dp]=c[0],undefined):(d[dp]=c,undefined));return bk(a,e,f,d)}
function sn(){var a,b,c;this.d=new Do(this);this.f=this.e=(c=(nh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new mc(0,null,new tn(this),true,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new zn,new un(this),new vn(this),35651584)}
function wo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new mc(0,new xo(this),new yo(this),true,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new Co(this),null,null,mp);this.c=new W(new zo(this),null,null,mp);this.a=new vb(new Ao(this),null,681574400);D((null,I))}
function Vn(){var a;this.g=new Bi;J();this.f=new mc(0,new Xn(this),new Wn(this),false,false);this.c=(a=new ib(null),a);this.d=new W(new $n(this),null,null,mp);this.e=new W(new _n(this),null,null,mp);this.a=new W(new ao(this),null,null,mp);this.b=new W(new bo(this),null,null,mp)}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new vi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Rg(a);if(!jd(a,4))throw Sg(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function pc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function Ni(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}mi(a.b,new Ab(a));a.b.a=Zc(ge,So,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Rk(){Rk=gh;vk=new Sk(ep,0);wk=new Sk('checkbox',1);xk=new Sk('color',2);yk=new Sk('date',3);zk=new Sk('datetime',4);Ak=new Sk('email',5);Bk=new Sk('file',6);Ck=new Sk('hidden',7);Dk=new Sk('image',8);Ek=new Sk('month',9);Fk=new Sk(Ro,10);Gk=new Sk('password',11);Hk=new Sk('radio',12);Ik=new Sk('range',13);Jk=new Sk('reset',14);Kk=new Sk('search',15);Lk=new Sk('submit',16);Mk=new Sk('tel',17);Nk=new Sk('text',18);Ok=new Sk('time',19);Pk=new Sk('url',20);Qk=new Sk('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ni(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ri(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ni(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){pi(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new ti)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Uo!=(k.b.c&Vo)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function Zk(a){var b,c;a.d=0;Vk();c=(b=S((en(),dn).b),ek('footer',ik(new $wnd.Object,ad(Xc(je,1),So,2,6,['footer'])),[(new sm).a,ek('ul',ik(new $wnd.Object,ad(Xc(je,1),So,2,6,['filters'])),[ek('li',null,[ek('a',kk(ik(new $wnd.Object,ad(Xc(je,1),So,2,6,[(Ho(),Fo)==b?fp:null])),'#'),['All'])]),ek('li',null,[ek('a',kk(ik(new $wnd.Object,ad(Xc(je,1),So,2,6,[Eo==b?fp:null])),'#active'),['Active'])]),ek('li',null,[ek('a',kk(ik(new $wnd.Object,ad(Xc(je,1),So,2,6,[Go==b?fp:null])),'#completed'),['Completed'])])]),S(a.a)?ek(ep,lk(ik(new $wnd.Object,ad(Xc(je,1),So,2,6,['clear-completed'])),hh(qm.prototype.kb,qm,[])),['Clear Completed']):null]));return c}
function Nl(a){var b,c,d,e;a.f=0;Vk();b=a.j.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.j.props['a'],e=(fb(d.a),d.d),ek('li',ik(new $wnd.Object,ad(Xc(je,1),So,2,6,[e?'checked':null,S(a.c)?'editing':null])),[ek('div',ik(new $wnd.Object,ad(Xc(je,1),So,2,6,['view'])),[ek(ip,pk(nk(sk(ik(new $wnd.Object,ad(Xc(je,1),So,2,6,['toggle'])),(Rk(),wk)),e),hh(Rm.prototype.ib,Rm,[d])),null),ek('label',uk(new $wnd.Object,hh(Sm.prototype.kb,Sm,[a,d])),[(fb(d.b),d.e)]),ek(ep,lk(ik(new $wnd.Object,ad(Xc(je,1),So,2,6,['destroy'])),hh(Tm.prototype.kb,Tm,[d])),null)]),ek(ip,qk(pk(ok(tk(ik(jk(new $wnd.Object,hh(Um.prototype.w,Um,[a])),ad(Xc(je,1),So,2,6,['edit'])),(fb(a.a),a.d)),hh(Vm.prototype.hb,Vm,[a,d])),hh(Qm.prototype.ib,Qm,[a])),hh(Wm.prototype.jb,Wm,[a,d])),null)]));return c}
function Pi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[cp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ni()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[cp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Qo='object',Ro='number',So={3:1},To={9:1},Uo=1048576,Vo=1835008,Wo={5:1},Xo=2097152,Yo=4194304,Zo='__noinit__',$o={3:1,10:1,8:1,4:1},_o='null',ap=17592186044416,bp={40:1},cp='delete',dp='children',ep='button',fp='selected',gp=1411518464,hp=142606336,ip='input',jp='header',kp='hashchange',lp={9:1,62:1},mp=136314880,np='active',op='completed';var _,bh,Yg,Qg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;dh();fh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.mb};_.q=qp;_.r=function(){var a;return uh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var dd,ed,fd;fh(49,1,{},vh);_.J=function(a){var b;b=new vh;b.e=4;a>1?(b.c=Ah(this,a-1)):(b.c=this);return b};_.K=function(){th(this);return this.b};_.L=function(){return uh(this)};_.M=function(){th(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(th(this),this.k)};_.e=0;_.g=0;var sh=1;var ge=xh(1);var Zd=xh(49);fh(79,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var td=xh(79);fh(35,1,{},G);_.s=function(){return this.a.v(),null};var rd=xh(35);fh(80,1,{},H);var sd=xh(80);var I;fh(42,1,{42:1},P);_.b=0;_.c=false;_.d=0;var ud=xh(42);fh(215,1,To);_.r=function(){var a;return uh(this.mb)+'@'+(a=s(this)>>>0,a.toString(16))};var xd=xh(215);fh(18,215,To,W);_.t=function(){R(this)};_.u=pp;_.a=false;_.d=0;_.k=false;var wd=xh(18);fh(124,1,{},X);_.s=function(){return T(this.a)};var vd=xh(124);fh(15,215,{9:1,15:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=xh(15);fh(123,1,Wo,jb);_.v=function(){ab(this.a)};var yd=xh(123);fh(16,215,{9:1,16:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Ed=xh(16);fh(125,1,{},xb);_.v=function(){Q(this.a)};var Ad=xh(125);fh(126,1,Wo,yb);_.v=function(){mb(this.a)};var Bd=xh(126);fh(127,1,Wo,zb);_.v=function(){pb(this.a)};var Cd=xh(127);fh(128,1,{},Ab);_.w=function(a){nb(this.a,a)};var Dd=xh(128);fh(133,1,{},Db);_.a=0;_.b=0;_.c=0;var Fd=xh(133);fh(160,1,To,Fb);_.t=function(){Eb(this)};_.u=pp;_.a=false;var Gd=xh(160);fh(58,215,{9:1,58:1},Jb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Id=xh(58);fh(138,1,{},Ob);var Hd=xh(138);fh(140,1,{},$b);_.r=function(){var a;return th(Jd),Jd.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.a=0;var Pb;var Jd=xh(140);fh(111,1,{});var Md=xh(111);fh(82,1,{},ec);_.w=function(a){cc(this.a,a)};var Kd=xh(82);fh(83,1,Wo,fc);_.v=function(){dc(this.a,this.b)};var Ld=xh(83);fh(14,1,To,mc);_.t=function(){hc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return th(Od),Od.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Od=xh(14);fh(122,1,Wo,nc);_.v=function(){kc(this.a)};var Nd=xh(122);fh(4,1,{3:1,4:1});_.B=vp;_.C=function(){return vj(tj(xi((this.i==null&&(this.i=Zc(le,So,4,0,0,1)),this.i)),new Sh),new zj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){qc(this,sc(new Error(rc(this,this.g))));Uc(this)};_.r=function(){return rc(this,this.F())};_.e=Zo;_.j=true;var le=xh(4);fh(10,4,{3:1,10:1,4:1});var ae=xh(10);fh(8,10,$o);var he=xh(8);fh(72,8,$o);var ee=xh(72);fh(73,72,$o);var Sd=xh(73);fh(34,73,{34:1,3:1,10:1,8:1,4:1},xc);_.F=function(){wc(this);return this.c};_.H=function(){return od(this.b)===od(uc)?null:this.b};var uc;var Pd=xh(34);var Qd=xh(0);fh(201,1,{});var Rd=xh(201);var zc=0,Ac=0,Bc=-1;fh(110,201,{},Pc);var Lc;var Td=xh(110);var Sc;fh(212,1,{});var Vd=xh(212);fh(74,212,{},Wc);var Ud=xh(74);var mh;fh(70,1,{67:1});_.r=pp;var Wd=xh(70);fh(76,8,$o);var ce=xh(76);fh(156,76,$o,qh);var Xd=xh(156);dd={3:1,68:1,27:1};var Yd=xh(68);fh(41,1,{3:1,41:1});var fe=xh(41);ed={3:1,27:1,41:1};var $d=xh(211);fh(29,1,{3:1,27:1,29:1});_.o=xp;_.q=qp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var _d=xh(29);fh(75,8,$o,Gh);var be=xh(75);fh(28,41,{3:1,27:1,28:1,41:1},Hh);_.o=function(a){return jd(a,28)&&a.a==this.a};_.q=pp;_.r=function(){return ''+this.a};_.a=0;var de=xh(28);var Jh;fh(278,1,{});fd={3:1,67:1,27:1,2:1};var je=xh(2);fh(71,70,{67:1},Rh);var ie=xh(71);fh(282,1,{});fh(65,1,{},Sh);_.R=function(a){return a.e};var ke=xh(65);fh(51,8,$o,Th);var me=xh(51);fh(213,1,{39:1});_.P=up;_.U=function(){return new ij(this,0)};_.V=function(){return new wj(null,this.U())};_.S=function(a){throw Sg(new Th('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new kj('[',']');for(b=this.Q();b.X();){a=b.Y();jj(c,a===this?'(this Collection)':a==null?_o:jh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ne=xh(213);fh(216,1,{199:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!jd(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new fi((new ci(d)).a);c.b;){b=ei(c);if(!Wh(this,b)){return false}}return true};_.q=function(){return yi(new ci(this))};_.r=function(){var a,b,c;c=new kj('{','}');for(b=new fi((new ci(this)).a);b.b;){a=ei(b);jj(c,Xh(this,a.$())+'='+Xh(this,a._()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ye=xh(216);fh(129,216,{199:1});var qe=xh(129);fh(217,213,{39:1,227:1});_.U=function(){return new ij(this,1)};_.o=function(a){var b;if(a===this){return true}if(!jd(a,20)){return false}b=a;if(ai(b.a)!=this.T()){return false}return Uh(this,b)};_.q=function(){return yi(this)};var ze=xh(217);fh(20,217,{20:1,39:1,227:1},ci);_.Q=function(){return new fi(this.a)};_.T=sp;var pe=xh(20);fh(21,1,{},fi);_.W=rp;_.Y=function(){return ei(this)};_.X=tp;_.b=false;var oe=xh(21);fh(214,213,{39:1,224:1});_.U=function(){return new ij(this,16)};_.Z=function(a,b){throw Sg(new Th('Add not supported on this list'))};_.S=function(a){this.Z(this.T(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,13)){return false}f=a;if(this.T()!=f.a.length){return false}e=new vi(f);for(c=new vi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return zi(this)};_.Q=function(){return new gi(this)};var se=xh(214);fh(109,1,{},gi);_.W=rp;_.X=function(){return this.a<this.b.a.length};_.Y=function(){return ni(this.b,this.a++)};_.a=0;var re=xh(109);fh(53,213,{39:1},hi);_.Q=function(){var a;a=new fi((new ci(this.a)).a);return new ii(a)};_.T=sp;var ue=xh(53);fh(132,1,{},ii);_.W=rp;_.X=function(){return this.a.b};_.Y=function(){var a;a=ei(this.a);return a._()};var te=xh(132);fh(130,1,bp);_.o=function(a){var b;if(!jd(a,40)){return false}b=a;return Ai(this.a,b.$())&&Ai(this.b,b._())};_.$=pp;_._=tp;_.q=function(){return _i(this.a)^_i(this.b)};_.ab=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ve=xh(130);fh(131,130,bp,ji);var we=xh(131);fh(218,1,bp);_.o=function(a){var b;if(!jd(a,40)){return false}b=a;return Ai(this.b.value[0],b.$())&&Ai(Xi(this),b._())};_.q=function(){return _i(this.b.value[0])^_i(Xi(this))};_.r=function(){return this.b.value[0]+'='+Xi(this)};var xe=xh(218);fh(13,214,{3:1,13:1,39:1,224:1},ti,ui);_.Z=function(a,b){Mj(this.a,a,b)};_.S=function(a){return li(this,a)};_.P=function(a){mi(this,a)};_.Q=function(){return new vi(this)};_.T=function(){return this.a.length};var Be=xh(13);fh(17,1,{},vi);_.W=rp;_.X=function(){return this.a<this.c.a.length};_.Y=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ae=xh(17);fh(36,129,{3:1,36:1,199:1},Bi);var Ce=xh(36);fh(56,1,{},Hi);_.P=up;_.Q=function(){return new Ii(this)};_.b=0;var Ee=xh(56);fh(57,1,{},Ii);_.W=rp;_.Y=function(){return this.d=this.a[this.c++],this.d};_.X=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var De=xh(57);var Li;fh(54,1,{},Vi);_.P=up;_.Q=function(){return new Wi(this)};_.b=0;_.c=0;var He=xh(54);fh(55,1,{},Wi);_.W=rp;_.Y=function(){return this.c=this.a,this.a=this.b.next(),new Yi(this.d,this.c,this.d.c)};_.X=function(){return !this.a.done};var Fe=xh(55);fh(139,218,bp,Yi);_.$=function(){return this.b.value[0]};_._=function(){return Xi(this)};_.ab=function(a){return Ti(this.a,this.b.value[0],a)};_.c=0;var Ge=xh(139);fh(142,1,{});_.W=wp;_.bb=function(){return this.d};_.cb=vp;_.d=0;_.e=0;var Le=xh(142);fh(59,142,{});var Ie=xh(59);fh(134,1,{});_.W=wp;_.bb=tp;_.cb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Ke=xh(134);fh(135,134,{},gj);_.W=function(a){dj(this,a)};_.db=function(a){return ej(this,a)};var Je=xh(135);fh(22,1,{},ij);_.bb=pp;_.cb=function(){hj(this);return this.c};_.W=function(a){hj(this);this.d.W(a)};_.db=function(a){hj(this);if(this.d.X()){a.w(this.d.Y());return true}return false};_.a=0;_.c=0;var Me=xh(22);fh(50,1,{},kj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ne=xh(50);fh(33,1,{},lj);_.R=function(a){return a};var Oe=xh(33);fh(37,1,{},mj);var Pe=xh(37);fh(141,1,{});_.c=false;var Ze=xh(141);fh(25,141,{},wj);var Ye=xh(25);fh(66,1,{},zj);_.eb=function(a){return Zc(ge,So,1,a,5,1)};var Qe=xh(66);fh(144,59,{},Bj);_.db=function(a){this.b=false;while(!this.b&&this.c.db(new Cj(this,a)));return this.b};_.b=false;var Se=xh(144);fh(147,1,{},Cj);_.w=function(a){Aj(this.a,this.b,a)};var Re=xh(147);fh(143,59,{},Ej);_.db=function(a){return this.b.db(new Fj(this,a))};var Ue=xh(143);fh(146,1,{},Fj);_.w=function(a){Dj(this.a,this.b,a)};var Te=xh(146);fh(145,1,{},Hj);_.w=function(a){Gj(this,a)};var Ve=xh(145);fh(148,1,{},Ij);_.w=function(a){};var We=xh(148);fh(149,1,{},Kj);_.w=function(a){Jj(this,a)};var Xe=xh(149);fh(280,1,{});fh(277,1,{});var Qj=0;var Sj,Tj=0,Uj;fh(897,1,{});fh(919,1,{});fh(219,1,{});var $e=xh(219);fh(157,1,{},gk);_.eb=function(a){return new Array(a)};var _e=xh(157);fh(245,$wnd.Function,{},hk);_.gb=function(a){fk(this.a,this.b,a)};fh(6,29,{3:1,27:1,29:1,6:1},Sk);var vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk;var af=yh(6,Tk);var Uk;fh(246,$wnd.Function,{},Wk);_.I=function(a){return Eb(Uk),Uk=null,null};fh(222,219,{});var Jf=xh(222);fh(173,222,{});_.d=0;var Nf=xh(173);fh(174,173,To,bl);_.t=yp;_.o=xp;_.q=qp;_.u=zp;_.r=function(){var a;return th(kf),kf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var $k=0;var kf=xh(174);fh(175,1,Wo,cl);_.v=function(){_k(this.a)};var bf=xh(175);fh(176,1,{},dl);_.s=function(){return rh(),S((en(),bn).b).a>0?true:false};var cf=xh(176);fh(177,1,{},el);_.v=function(){Yk(this.a)};var df=xh(177);fh(178,1,{},fl);_.s=function(){return Zk(this.a)};var ef=xh(178);fh(223,219,{});var If=xh(223);fh(193,223,{});_.c=0;var Mf=xh(193);fh(194,193,To,kl);_.t=Ap;_.o=xp;_.q=qp;_.u=Bp;_.r=function(){var a;return th(jf),jf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var il=0;var jf=xh(194);fh(195,1,Wo,ll);_.v=Cp;var ff=xh(195);fh(196,1,{},ml);_.v=function(){hl(this.a)};var gf=xh(196);fh(197,1,{},nl);_.s=function(){var a,b;return this.a.c=0,Vk(),a=S((en(),bn).e).a,b='item'+(a==1?'':'s'),ek('span',ik(new $wnd.Object,ad(Xc(je,1),So,2,6,['todo-count'])),[ek('strong',null,[a]),' '+b+' left'])};var hf=xh(197);fh(165,219,{});_.e='';var Vf=xh(165);fh(166,165,{});_.d=0;var Pf=xh(166);fh(167,166,To,zl);_.t=yp;_.o=xp;_.q=qp;_.u=zp;_.r=function(){var a;return th(qf),qf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var tl=0;var qf=xh(167);fh(168,1,Wo,Al);_.v=function(){ul(this.a)};var lf=xh(168);fh(170,1,{},Bl);_.s=function(){return sl(this.a)};var mf=xh(170);fh(171,1,Wo,Cl);_.v=function(){ol(this.a)};var nf=xh(171);fh(172,1,Wo,Dl);_.v=function(){wl(this.a,this.b)};var of=xh(172);fh(169,1,{},El);_.v=function(){Yk(this.a)};var pf=xh(169);fh(221,219,{});_.i=false;var Xf=xh(221);fh(180,221,{});_.f=0;var Rf=xh(180);fh(181,180,To,Zl);_.t=function(){hc(this.e)};_.o=xp;_.q=qp;_.u=function(){return this.e.i<0};_.r=function(){var a;return th(Bf),Bf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var Ol=0;var Bf=xh(181);fh(182,1,Wo,$l);_.v=function(){Pl(this.a)};var rf=xh(182);fh(185,1,{},_l);_.s=function(){return Nl(this.a)};var sf=xh(185);fh(60,1,Wo,am);_.v=function(){Yl(this.a,on(this.b))};var tf=xh(60);fh(61,1,Wo,bm);_.v=function(){Il(this.a,this.b)};var uf=xh(61);fh(186,1,Wo,cm);_.v=function(){Rl(this.a,this.b)};var vf=xh(186);fh(187,1,Wo,dm);_.v=function(){Xl(this.a,this.b);vo((en(),dn),null)};var wf=xh(187);fh(183,1,{},em);_.s=function(){return Sl(this.a)};var xf=xh(183);fh(188,1,Wo,fm);_.v=function(){Fl(this.a,this.b)};var yf=xh(188);fh(189,1,Wo,gm);_.v=function(){Jl(this.a)};var zf=xh(189);fh(184,1,{},hm);_.v=function(){Ml(this.a)};var Af=xh(184);fh(220,219,{});var $f=xh(220);fh(151,220,{});_.c=0;var Tf=xh(151);fh(152,151,To,mm);_.t=Ap;_.o=xp;_.q=qp;_.u=Bp;_.r=function(){var a;return th(Ff),Ff.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var km=0;var Ff=xh(152);fh(153,1,Wo,nm);_.v=Cp;var Cf=xh(153);fh(154,1,{},om);_.v=function(){hl(this.a)};var Df=xh(154);fh(155,1,{},pm);_.s=function(){return this.a.c=0,Vk(),ek('div',null,[ek('div',null,[ek(jp,ik(new $wnd.Object,ad(Xc(je,1),So,2,6,[jp])),[ek('h1',null,['todos']),(new Pm).a]),S((en(),bn).d)?ek('section',ik(new $wnd.Object,ad(Xc(je,1),So,2,6,[jp])),[ek(ip,pk(sk(ik(new $wnd.Object,ad(Xc(je,1),So,2,6,['toggle-all'])),(Rk(),wk)),hh(Zm.prototype.ib,Zm,[])),null),ek('ul',ik(new $wnd.Object,ad(Xc(je,1),So,2,6,['todo-list'])),vj(tj(S(dn.c).V(),new $m),new gk))]):null,S(bn.d)?(new rm).a:null])])};var Ef=xh(155);fh(250,$wnd.Function,{},qm);_.kb=function(a){fo((en(),cn))};fh(159,1,{},rm);var Gf=xh(159);fh(179,1,{},sm);var Hf=xh(179);fh(251,$wnd.Function,{},tm);_.lb=function(a){return new wm(a)};var um;fh(163,$wnd.React.Component,{},wm);eh(bh[1],_);_.componentWillUnmount=function(){Xk(this.a)};_.render=function(){return al(this.a)};_.shouldComponentUpdate=Dp;var Kf=xh(163);fh(261,$wnd.Function,{},xm);_.lb=function(a){return new Am(a)};var ym;fh(190,$wnd.React.Component,{},Am);eh(bh[1],_);_.componentWillUnmount=function(){gl(this.a)};_.render=function(){return jl(this.a)};_.shouldComponentUpdate=Ep;var Lf=xh(190);fh(249,$wnd.Function,{},Bm);_.lb=function(a){return new Em(a)};var Cm;fh(162,$wnd.React.Component,{},Em);eh(bh[1],_);_.componentWillUnmount=function(){Xk(this.a)};_.render=function(){return xl(this.a)};_.shouldComponentUpdate=Dp;var Of=xh(162);fh(252,$wnd.Function,{},Fm);_.lb=function(a){return new Im(a)};var Gm;fh(164,$wnd.React.Component,{},Im);eh(bh[1],_);_.componentDidUpdate=function(a){Vl(this.a)};_.componentWillUnmount=function(){Ll(this.a)};_.render=function(){return Wl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Qf=xh(164);fh(244,$wnd.Function,{},Jm);_.lb=function(a){return new Mm(a)};var Km;fh(136,$wnd.React.Component,{},Mm);eh(bh[1],_);_.componentWillUnmount=function(){gl(this.a)};_.render=function(){return lm(this.a)};_.shouldComponentUpdate=Ep;var Sf=xh(136);fh(247,$wnd.Function,{},Nm);_.jb=function(a){pl(this.a,a)};fh(248,$wnd.Function,{},Om);_.ib=function(a){vl(this.a,a)};fh(158,1,{},Pm);var Uf=xh(158);fh(259,$wnd.Function,{},Qm);_.ib=function(a){Ql(this.a,a)};fh(253,$wnd.Function,{},Rm);_.ib=function(a){Jn(this.a)};fh(255,$wnd.Function,{},Sm);_.kb=function(a){Tl(this.a,this.b)};fh(256,$wnd.Function,{},Tm);_.kb=function(a){Kl(this.a)};fh(257,$wnd.Function,{},Um);_.w=function(a){Gl(this.a,a)};fh(258,$wnd.Function,{},Vm);_.hb=function(a){Ul(this.a,this.b)};fh(260,$wnd.Function,{},Wm);_.jb=function(a){Hl(this.a,this.b,a)};fh(161,1,{},Ym);var Wf=xh(161);fh(243,$wnd.Function,{},Zm);_.ib=function(a){var b;b=a.target;jo((en(),cn),b.checked)};fh(137,1,{},$m);_.R=function(a){return Xm(new Ym,a)};var Yf=xh(137);fh(64,1,{},_m);var Zf=xh(64);var an,bn,cn,dn;fh(93,1,{});var Fg=xh(93);fh(94,93,lp,sn);_.t=yp;_.o=xp;_.q=qp;_.u=zp;_.A=Fp;_.r=function(){var a;return th(gg),gg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var gg=xh(94);fh(95,1,Wo,tn);_.v=function(){mn(this.a)};var _f=xh(95);fh(97,1,{},un);_.v=function(){gn(this.a)};var ag=xh(97);fh(98,1,{},vn);_.v=function(){hn(this.a)};var bg=xh(98);fh(99,1,Wo,wn);_.v=function(){fn(this.a,this.b)};var cg=xh(99);fh(100,1,Wo,xn);_.v=function(){pn(this.a)};var dg=xh(100);fh(52,1,Wo,yn);_.v=function(){ln(this.a)};var eg=xh(52);fh(96,1,{},zn);_.s=function(){var a;return a=(nh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var fg=xh(96);fh(43,1,{43:1});_.d=false;var Ng=xh(43);fh(44,43,{9:1,62:1,44:1,43:1},Kn);_.t=yp;_.o=function(a){return Dn(this,a)};_.q=function(){return this.c.d};_.u=zp;_.A=Fp;_.r=function(){var a;return th(wg),wg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var An=0;var wg=xh(44);fh(191,1,Wo,Ln);_.v=function(){Bn(this.a)};var hg=xh(191);fh(192,1,Wo,Mn);_.v=function(){Gn(this.a)};var ig=xh(192);fh(112,111,{});var Ig=xh(112);fh(113,112,To,Vn);_.t=Gp;_.o=xp;_.q=qp;_.u=Hp;_.r=function(){var a;return th(rg),rg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var rg=xh(113);fh(115,1,Wo,Wn);_.v=function(){On(this.a)};var jg=xh(115);fh(114,1,Wo,Xn);_.v=function(){Sn(this.a)};var kg=xh(114);fh(120,1,Wo,Yn);_.v=function(){bc(this.a,this.b,true)};var lg=xh(120);fh(121,1,{},Zn);_.s=function(){return Nn(this.a,this.c,this.b)};_.b=false;var mg=xh(121);fh(116,1,{},$n);_.s=function(){return Tn(this.a)};var ng=xh(116);fh(117,1,{},_n);_.s=function(){return Ih(Xg(rj(Rn(this.a))))};var og=xh(117);fh(118,1,{},ao);_.s=function(){return Ih(Xg(rj(sj(Rn(this.a),new Ko))))};var pg=xh(118);fh(119,1,{},bo);_.s=function(){return Un(this.a)};var qg=xh(119);fh(87,1,{});var Mg=xh(87);fh(88,87,lp,ko);_.t=function(){hc(this.a)};_.o=xp;_.q=qp;_.u=function(){return this.a.i<0};_.A=function(a){lc(this.a,a)};_.r=function(){var a;return th(vg),vg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var vg=xh(88);fh(89,1,Wo,lo);_.v=function(){go(this.a,this.b)};_.b=false;var sg=xh(89);fh(90,1,Wo,mo);_.v=function(){yl(this.b,this.a)};var tg=xh(90);fh(91,1,Wo,no);_.v=function(){ho(this.a)};var ug=xh(91);fh(101,1,{});var Pg=xh(101);fh(102,101,lp,wo);_.t=Gp;_.o=xp;_.q=qp;_.u=Hp;_.A=function(a){lc(this.f,a)};_.r=function(){var a;return th(Dg),Dg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var Dg=xh(102);fh(103,1,Wo,xo);_.v=function(){ro(this.a)};var xg=xh(103);fh(104,1,Wo,yo);_.v=function(){qo(this.a)};var yg=xh(104);fh(106,1,{},zo);_.s=function(){return to(this.a)};var zg=xh(106);fh(107,1,{},Ao);_.v=function(){uo(this.a)};var Ag=xh(107);fh(108,1,Wo,Bo);_.v=function(){vo(this.a,null)};var Bg=xh(108);fh(105,1,{},Co);_.s=function(){var a;return a=on(this.a.g),o(np,a)?(Ho(),Eo):o(op,a)?(Ho(),Go):(Ho(),Fo)};var Cg=xh(105);fh(92,1,{},Do);_.handleEvent=function(a){jn(this.a,a)};var Eg=xh(92);fh(30,29,{3:1,27:1,29:1,30:1},Io);var Eo,Fo,Go;var Gg=yh(30,Jo);fh(81,1,{},Ko);_.fb=function(a){return !Fn(a)};var Hg=xh(81);fh(85,1,{},Lo);_.fb=function(a){return Fn(a)};var Jg=xh(85);fh(86,1,{},Mo);_.w=function(a){Qn(this.a,a)};var Kg=xh(86);fh(84,1,{},No);_.w=function(a){eo(this.a,a)};_.a=false;var Lg=xh(84);fh(77,1,{},Oo);_.fb=function(a){return po(this.a,a)};var Og=xh(77);var qd=zh('D');var Po=(Cc(),Fc);var gwtOnLoad=gwtOnLoad=_g;Zg(lh);ah('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();