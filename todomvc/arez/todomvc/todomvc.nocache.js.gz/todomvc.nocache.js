function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='35942CDC2FFD9CD15390EBBA608FB6EA',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '35942CDC2FFD9CD15390EBBA608FB6EA';function o(){}
function Zg(){}
function Vg(){}
function Vl(){}
function Ml(){}
function Rl(){}
function Zl(){}
function Ab(){}
function Pc(){}
function Wc(){}
function Wj(){}
function kj(){}
function lj(){}
function Kk(){}
function bm(){}
function fm(){}
function ym(){}
function Nn(){}
function On(){}
function Do(){}
function Uc(a){Tc()}
function eh(){eh=Vg}
function hi(){$h(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function eb(a){this.a=a}
function rb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function bc(a){this.a=a}
function dc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function jc(a){this.a=a}
function vh(a){this.a=a}
function Gh(a){this.a=a}
function Sh(a){this.a=a}
function Xh(a){this.a=a}
function Yh(a){this.a=a}
function Wh(a){this.b=a}
function ji(a){this.c=a}
function ij(a){this.a=a}
function nj(a){this.a=a}
function Lk(a){this.a=a}
function Mk(a){this.a=a}
function Nk(a){this.a=a}
function Qk(a){this.a=a}
function Rk(a){this.a=a}
function Sk(a){this.a=a}
function _k(a){this.a=a}
function al(a){this.a=a}
function cl(a){this.a=a}
function dl(a){this.a=a}
function wl(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function Dl(a){this.a=a}
function Gl(a){this.a=a}
function Jl(a){this.a=a}
function Kl(a){this.a=a}
function Ll(a){this.a=a}
function jm(a){this.a=a}
function km(a){this.a=a}
function nm(a){this.a=a}
function om(a){this.a=a}
function qm(a){this.a=a}
function rm(a){this.a=a}
function Rm(a){this.a=a}
function Sm(a){this.a=a}
function _m(a){this.a=a}
function bn(a){this.a=a}
function dn(a){this.a=a}
function en(a){this.a=a}
function fn(a){this.a=a}
function qn(a){this.a=a}
function rn(a){this.a=a}
function Cn(a){this.a=a}
function Dn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Pn(a){this.a=a}
function Qn(a){this.a=a}
function Rn(a){this.a=a}
function Ol(){this.a={}}
function Ql(){this.a={}}
function mm(){this.a={}}
function xm(){this.a={}}
function Am(){this.a={}}
function Io(){Rj(this.a)}
function No(){Tj(this.a)}
function ti(){this.a=Ci()}
function Hi(){this.a=Ci()}
function zo(a){Li(this,a)}
function Co(a){zh(this,a)}
function Z(a){Jb((J(),a))}
function $(a){Kb((J(),a))}
function cb(a){Lb((J(),a))}
function w(a){--a.e;D(a)}
function C(a,b){xb(a.b,b)}
function nc(a,b){Oh(a.b,b)}
function mj(a,b){cj(a.a,b)}
function Ej(a,b){Dj(a,b)}
function jj(a,b){a.a=b}
function lb(a,b){a.b=Oi(b)}
function gn(a,b){Um(a.c,b)}
function hn(a,b){Nm(b,a)}
function Gg(a){return a.e}
function Lo(){return this.e}
function wo(){return this.a}
function Bo(){return this.b}
function Fo(){return this.c}
function Po(){return this.f}
function Go(){return this.d<0}
function Mo(){return this.c<0}
function Oo(){return this.f<0}
function yo(){return vj(this)}
function Ch(a,b){return a===b}
function gl(a,b){return a.g=b}
function bi(a,b){return a.a[b]}
function rj(a,b){a.splice(b,1)}
function lc(a,b,c){Nh(a.b,b,c)}
function Ok(a){mc(a.b);fb(a.a)}
function kl(a){Vm((Fm(),Cm),a)}
function Ul(a){Ij.call(this,a)}
function Yl(a){Ij.call(this,a)}
function am(a){Ij.call(this,a)}
function em(a){Ij.call(this,a)}
function im(a){Ij.call(this,a)}
function Hh(a){tc.call(this,a)}
function xo(a){return this===a}
function Ho(){return J(),J(),I}
function yi(){yi=Vg;xi=Ai()}
function J(){J=Vg;I=new F}
function vc(){vc=Vg;uc=new o}
function Mc(){Mc=Vg;Lc=new Pc}
function oc(){this.b=new ni}
function F(){this.b=new yb}
function Ah(){pc(this);this.G()}
function Ao(){return Qh(this.a)}
function Jo(){return Vj(this.a)}
function Xc(a,b){return nh(a,b)}
function cj(a,b){jj(a,bj(a.a,b))}
function Pi(a,b){while(a.cb(b));}
function bj(a,b){a.R(b);return a}
function hh(a){gh(a);return a.k}
function Ub(a){ab(a.a);return a.e}
function Vb(a){ab(a.b);return a.g}
function Jm(a){ab(a.b);return a.i}
function Km(a){ab(a.a);return a.g}
function vn(a){ab(a.d);return a.f}
function Yj(a,b){a.ref=b;return a}
function cc(a,b){this.a=a;this.b=b}
function kc(a,b){this.a=a;this.b=b}
function sh(a,b){this.a=a;this.b=b}
function Zh(a,b){this.a=a;this.b=b}
function Qh(a){return a.a.b+a.b.b}
function Ei(a,b){return a.a.get(b)}
function ad(a){return new Array(a)}
function Ci(){yi();return new xi}
function W(a){J();Kb(a);a.e=-2}
function Xb(a){Tb(a,(ab(a.b),a.g))}
function Db(a){Eb(a);!a.d&&Hb(a)}
function Cc(){Cc=Vg;!!(Tc(),Sc)}
function Kc(){zc!=0&&(zc=0);Bc=-1}
function Og(){Mg==null&&(Mg=[])}
function Gk(a,b){sh.call(this,a,b)}
function fj(a,b){this.a=a;this.b=b}
function Mj(a,b){this.a=a;this.b=b}
function Nj(a,b){this.a=a;this.b=b}
function bl(a,b){this.a=a;this.b=b}
function Al(a,b){this.a=a;this.b=b}
function Bl(a,b){this.a=a;this.b=b}
function Cl(a,b){this.a=a;this.b=b}
function El(a,b){this.a=a;this.b=b}
function Fl(a,b){this.a=a;this.b=b}
function pm(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function tm(a,b){this.a=a;this.b=b}
function an(a,b){this.a=a;this.b=b}
function sn(a,b){this.a=a;this.b=b}
function pn(a,b){this.b=a;this.a=b}
function Ln(a,b){sh.call(this,a,b)}
function pj(a,b,c){a.splice(b,0,c)}
function gj(a,b){a.B(wm(um(b.e),b))}
function Zj(a,b){a.href=b;return a}
function hk(a,b){a.value=b;return a}
function Eh(a,b){a.a+=''+b;return a}
function Ph(a){a.a=new ti;a.b=new Hi}
function $h(a){a.a=Zc(ie,Xn,1,0,5,1)}
function um(a){return vm(new xm,a)}
function Mh(a){return !a?null:a.$()}
function Fb(a){return !a.d?a:Fb(a.d)}
function Ni(a){return a!=null?r(a):0}
function pd(a){return a==null?null:a}
function md(a){return typeof a===Un}
function Jc(a){$wnd.clearTimeout(a)}
function Ik(a){mc(a.c);fb(a.b);R(a.a)}
function Yk(a){mc(a.c);fb(a.a);V(a.b)}
function Mm(a){Nm(a,(ab(a.a),!a.g))}
function ic(a,b){gc(a,b,false);$(a.d)}
function qj(a,b){oj(b,0,a,0,b.length)}
function $j(a,b){a.onClick=b;return a}
function ck(a,b){a.onBlur=b;return a}
function dk(a,b){a.onChange=b;return a}
function ak(a,b){a.checked=b;return a}
function db(a){this.c=new hi;this.b=a}
function zj(){zj=Vg;wj=new o;yj=new o}
function A(a,b,c){t(a,new G(b),c,null)}
function cd(a,b,c){return {l:a,m:b,h:c}}
function Bh(a,b){return a.charCodeAt(b)}
function kd(a,b){return a!=null&&hd(a,b)}
function U(a){return !(!!a&&1==(a.c&7))}
function vj(a){return a.$H||(a.$H=++uj)}
function od(a){return typeof a==='string'}
function Eo(){return S((Fm(),Cm).b).a>0}
function il(a,b){An((Fm(),Em),b);tl(a,b)}
function Dj(a,b){for(var c in a){b(c)}}
function tj(b,c,d){try{b[c]=d}catch(a){}}
function kb(a){J();jb(a);mb(a,2,true)}
function ab(a){var b;Gb((J(),b=Bb,b),a)}
function qc(a,b){a.e=b;b!=null&&tj(b,ho,a)}
function gh(a){if(a.k!=null){return}ph(a)}
function ek(a,b){a.onKeyDown=b;return a}
function bk(a,b){a.defaultValue=b;return a}
function _j(a){a.autoFocus=true;return a}
function tc(a){this.f=a;pc(this);this.G()}
function aj(a,b){Xi.call(this,a);this.a=b}
function on(a){this.c=Oi(a);this.a=new oc}
function ni(){this.a=new ti;this.b=new Hi}
function P(){this.a=Zc(ie,Xn,1,100,5,1)}
function yh(){yh=Vg;xh=Zc(ee,Xn,33,256,0,1)}
function ah(){ah=Vg;_g=$wnd.window.document}
function ld(a){return typeof a==='boolean'}
function u(a,b){return new pb(Oi(a),null,b)}
function Nl(a){return Jj((Tl(),Sl),a.a,null)}
function Pl(a){return Jj((Xl(),Wl),a.a,null)}
function lm(a){return Jj((_l(),$l),a.a,null)}
function zm(a){return Jj((hm(),gm),a.a,null)}
function Zm(a){return wh(S(a.e).a-S(a.a).a)}
function Lm(a){mc(a.c);V(a.d);V(a.b);V(a.a)}
function vi(a,b){var c;c=a[mo];c.call(a,b)}
function Li(a,b){while(a.W()){mj(b,a.X())}}
function hc(a,b){nc(b.C(),a);kd(b,11)&&b.v()}
function Dc(a,b,c){return a.apply(b,c);var d}
function vm(a,b){Oi(b);a.a['key']=b;return a}
function ik(a,b){a.onDoubleClick=b;return a}
function _h(a,b){a.a[a.a.length]=b;return true}
function pc(a){a.g&&a.e!==go&&a.G();return a}
function mh(){var a;a=jh(null);a.e=2;return a}
function kh(a){var b;b=jh(a);rh(a,b);return b}
function Uh(a){var b;b=a.a.X();a.b=Th(a);return b}
function Xk(a,b){var c;c=b.target;Zk(a,c.value)}
function ib(a,b){Y(b,a);b.c.a.length>0||(b.a=4)}
function Qb(a,b){a.i&&b.preventDefault();_b(a)}
function cn(a,b){this.a=a;this.c=b;this.b=false}
function Ki(a,b,c){this.a=a;this.b=b;this.c=c}
function Qi(a,b){this.e=a;this.d=(b&64)!=0?b|Vn:b}
function Ri(a){if(!a.d){a.d=a.b.Q();a.c=a.b.S()}}
function zb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function dj(a,b,c){if(a.a.db(c)){a.b=true;b.B(c)}}
function di(a,b){var c;c=a.a[b];rj(a.a,b);return c}
function Qc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function fi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Zk(a,b){var c;c=a.e;if(b!=c){a.e=b;$(a.b)}}
function Di(a,b){return !(a.a.get(b)===undefined)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function _c(a){return Array.isArray(a)&&a.xb===Zg}
function jd(a){return !Array.isArray(a)&&a.xb===Zg}
function Ym(a){return eh(),0==S(a.e).a?true:false}
function tn(a){return Ch(vo,a)||Ch(so,a)||Ch('',a)}
function $i(a){Wi(a);return new aj(a,new hj(a.a))}
function Rh(a,b){if(b){return Kh(a.a,b)}return false}
function Zi(a,b){Wi(a);return new aj(a,new ej(b,a.a))}
function ul(a,b){var c;c=a.i;if(b!=c){a.i=b;$(a.a)}}
function Nm(a,b){var c;c=a.g;if(b!=c){a.g=b;$(a.a)}}
function nl(a){mc(a.e);fb(a.b);R(a.d);V(a.c);V(a.a)}
function Vi(a){if(!a.b){Wi(a);a.c=true}else{Vi(a.b)}}
function Lg(a){if(md(a)){return a|0}return a.l|a.m<<22}
function Oi(a){if(a==null){throw Gg(new Ah)}return a}
function Cj(){if(xj==256){wj=yj;yj=new o;xj=0}++xj}
function Tc(){Tc=Vg;var a;!Vc();a=new Wc;Sc=a}
function hj(a){Qi.call(this,a.bb(),a.ab()&-6);this.a=a}
function Xi(a){if(!a){this.b=null;new hi}else{this.b=a}}
function Si(a,b){this.b=a;this.a=(b&4096)==0?b|64|Vn:b}
function gk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function mi(a,b){return pd(a)===pd(b)||a!=null&&p(a,b)}
function Uj(a){Sj(a);return kd(a,11)&&a.w()?null:a.nb()}
function ol(a,b,c,d){return eh(),ll(a,b,c,d)?true:false}
function zl(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function Mb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function Zb(a,b){var c;c=a.e;if(b!=c){a.e=Oi(b);$(a.a)}}
function $b(a,b){var c;c=a.g;if(b!=c){a.g=Oi(b);$(a.b)}}
function Om(a,b){var c;c=a.i;if(b!=c){a.i=Oi(b);$(a.b)}}
function lh(a,b){var c;c=jh(a);rh(a,c);c.e=b?8:0;return c}
function Nb(a,b){Bb=new Mb(Bb,b);a.d=false;Cb(Bb);return Bb}
function wb(a){while(true){if(!ub(a)&&!vb(a)){break}}}
function bb(a){var b;J();!!Bb&&!!Bb.e&&Gb((b=Bb,b),a)}
function Fj(a,b){null!=b&&a.ib(b,a.o.props,true);a.fb()}
function Rj(a){if(!a.k){a.k=true;a.n||a.o.forceUpdate()}}
function oh(a){if(a.O()){return null}var b=a.j;return Rg[b]}
function Mn(){Kn();return bd(Xc(ug,1),Xn,37,0,[Hn,Jn,In])}
function wm(a,b){a.a['a']=b;return Jj((dm(),cm),a.a,null)}
function rc(a,b){var c;c=hh(a.vb);return b==null?c:c+': '+b}
function fl(a,b){var c;if(S(a.d)){c=b.target;ul(a,c.value)}}
function zh(a,b){var c,d;for(d=a.Q();d.W();){c=d.X();b.B(c)}}
function uh(a){this.f=!a?null:rc(a,a.F());pc(this);this.G()}
function wn(a){mc(a.g);fb(a.e);fb(a.a);R(a.b);R(a.c);V(a.d)}
function Cb(a){if(a.e){2==(a.e.c&7)||mb(a.e,4,true);jb(a.e)}}
function Uk(a,b){if(13==b.keyCode){b.preventDefault();Vk(a)}}
function xb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],Oi(b))}
function ln(a,b){var c;_i(Wm(a.c),(c=new hi,c)).P(new Qn(b))}
function hl(a,b,c){27==c.which?ql(a,b):13==c.which&&sl(a,b)}
function Lj(a,b,c){a[c]===undefined&&(a[c]=b[c],undefined)}
function Ic(a){Cc();$wnd.setTimeout(function(){throw a},0)}
function Wi(a){if(a.b){Wi(a.b)}else if(a.c){throw Gg(new th)}}
function Xg(a){function b(){}
;b.prototype=a||{};return new b}
function fk(a){a.placeholder='What needs to be done?';return a}
function Lh(a,b){return b===a?'(this Map)':b==null?jo:Yg(b)}
function pi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function nh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function Tg(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Tl(){Tl=Vg;var a;Sl=(a=Wg(Rl.prototype.jb,Rl,[]),a)}
function Xl(){Xl=Vg;var a;Wl=(a=Wg(Vl.prototype.jb,Vl,[]),a)}
function _l(){_l=Vg;var a;$l=(a=Wg(Zl.prototype.jb,Zl,[]),a)}
function dm(){dm=Vg;var a;cm=(a=Wg(bm.prototype.jb,bm,[]),a)}
function hm(){hm=Vg;var a;gm=(a=Wg(fm.prototype.jb,fm,[]),a)}
function ii(a){$h(this);qj(this.a,Jh(a,Zc(ie,Xn,1,Qh(a.a),5,1)))}
function Wm(a){ab(a.d);return new aj(null,new Si(new Xh(a.i),0))}
function qi(a,b){var c;return oi(b,pi(a,b==null?0:(c=r(b),c|0)))}
function gb(a){var b;b=(J(),J(),I);xb(b.b,a);0!=(a.c&bo)&&D(b)}
function yn(a){var b;b=(ab(a.d),a.f);!!b&&!!b&&b.f<0&&An(a,null)}
function Pb(a,b){a.j=b;Ch(b,(ab(a.a),a.e))&&$b(a,b);Rb(b);_b(a)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function X(a,b){var c,d;_h(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&Vn)?Vn:8192)|0|0,b)}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&Vn)?Vn:8192)|0|0,b)}
function bh(a,b,c,d){a.addEventListener(b,c,(eh(),d?true:false))}
function dh(a,b,c,d){a.removeEventListener(b,c,(eh(),d?true:false))}
function Gc(a,b,c){var d;d=Ec();try{return Dc(a,b,c)}finally{Hc(d)}}
function An(a,b){var c;c=a.f;if(!(b==c||!!b&&Im(b,c))){a.f=b;$(a.d)}}
function ej(a,b){Qi.call(this,b.bb(),b.ab()&-16449);this.a=a;this.c=b}
function ui(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Ii(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Ko(){return vn((Fm(),Em))==(bb(this.c),this.o.props['a'])}
function Oh(a,b){return od(b)?b==null?si(a.a,null):Gi(a.b,b):si(a.a,b)}
function Ti(a,b){!a.a?(a.a=new Gh(a.d)):Eh(a.a,a.b);Eh(a.a,b);return a}
function _i(a,b){var c;Vi(a);c=new kj;c.a=b;a.a.V(new nj(c));return c.a}
function Yi(a){var b;Vi(a);b=0;while(a.a.cb(new lj)){b=Hg(b,1)}return b}
function kn(a){var b;_i(Zi(Wm(a.c),new On),(b=new hi,b)).P(new Pn(a.c))}
function Fm(){Fm=Vg;Bm=new ac;Cm=new $m;Dm=new on(Cm);Em=new Bn(Cm,Bm)}
function yc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Fc(b){Cc();return function(){return Gc(b,this,arguments);var a}}
function sc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Im(a,b){var c;if(kd(b,50)){c=b;return a.e==c.e}else{return false}}
function Ji(a){if(a.a.c!=a.c){return Ei(a.a,a.b.value[0])}return a.b.value[1]}
function Hm(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Rm(a)),ao,null)}}
function Hc(a){a&&Oc((Mc(),Lc));--zc;if(a){if(Bc!=-1){Jc(Bc);Bc=-1}}}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function un(a,b){return (Kn(),In)==a||(Hn==a?(ab(b.a),!b.g):(ab(b.a),b.g))}
function Nh(a,b,c){return od(b)?b==null?ri(a.a,null,c):Fi(a.b,b,c):ri(a.a,b,c)}
function sj(a,b){return Yc(b)!=10&&bd(q(b),b.wb,b.__elementTypeId$,Yc(b),a),a}
function pl(a){return eh(),vn((Fm(),Em))==(bb(a.c),a.o.props['a'])?true:false}
function xn(a){var b,c;return b=S(a.b),_i(Zi(Wm(a.k),new Rn(b)),(c=new hi,c))}
function ai(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.B(c)}}
function ei(a,b){var c;c=ci(a,b,0);if(c==-1){return false}rj(a.a,c);return true}
function Vj(a){var b;a.k=false;if(a.lb()){return null}else{b=a.hb();return b}}
function Zc(a,b,c,d,e,f){var g;g=$c(e,d);e!=10&&bd(Xc(a,f),b,c,e,g);return g}
function Kj(a,b,c){!Ch(c,'key')&&!Ch(c,'ref')&&(a[c]=b[c],undefined)}
function ci(a,b,c){for(;c<a.a.length;++c){if(mi(b,a.a[c])){return c}}return -1}
function Gj(a,b){var c;c=null!=b&&a.ib(a.o.props,b,false);c||(a.p=false);return c}
function Hj(a,b){var c;if(b){c=a.p;a.p=false;return !c}else{a.p=true;return true}}
function Ui(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Vh(a){this.d=a;this.c=new Ii(this.d.b);this.a=this.c;this.b=Th(this)}
function Wb(a){dh((ah(),$wnd.window.window),eo,a.f,false);mc(a.c);V(a.b);V(a.a)}
function R(a){if(!a.a){a.a=true;a.g=null;a.b=null;V(a.d);2==(a.e.c&7)||fb(a.e)}}
function V(a){if(-2!=a.e){t((J(),J(),I),new G(new eb(a)),0,null);!!a.b&&fb(a.b)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{wb(a.b)}finally{a.c=false}}}}
function Nc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Rc(b,c)}while(a.a);a.a=c}}
function Oc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Rc(b,c)}while(a.b);a.b=c}}
function Tk(a){var b;b=Dh((ab(a.b),a.e));if(b.length>0){gn((Fm(),Dm),b);Zk(a,'')}}
function ub(a){var b;if(0==O(a.c)){return false}else{b=N(a.c);!!b&&b.v();return true}}
function rh(a,b){var c;if(!a){return}b.j=a;var d=oh(b);if(!d){Rg[a]=[b];return}d.vb=b}
function Wg(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Fg(a){var b;if(kd(a,4)){return a}b=a&&a[ho];if(!b){b=new xc(a);Uc(b)}return b}
function jh(a){var b;b=new ih;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Ib(a,b){var c;if(!a.c){c=Fb(a);!c.c&&(c.c=new hi);a.c=c.c}b.d=true;_h(a.c,Oi(b))}
function Gb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;_h((!a.b&&(a.b=new hi),a.b),b)}}}
function Tj(a){var b;b=(++a.mb().e,new Ab);try{a.n=true;kd(a,11)&&a.v()}finally{zb(b)}}
function Ob(){var a;try{Db(Bb);J()}finally{a=Bb.d;!a&&((J(),J(),I).d=true);Bb=Bb.d}}
function Ng(){Og();var a=Mg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function th(){tc.call(this,"Stream already terminated, can't be modified or used")}
function Yc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nd(a){return a!=null&&(typeof a===Tn||typeof a==='function')&&!(a.xb===Zg)}
function Qg(a,b){typeof window===Tn&&typeof window['$gwt']===Tn&&(window['$gwt'][a]=b)}
function Kn(){Kn=Vg;Hn=new Ln('ACTIVE',0);Jn=new Ln('COMPLETED',1);In=new Ln('ALL',2)}
function Pk(){++Pj;this.b=new oc;this.a=new pb(null,Oi((J(),new Qk(this))),po);D((null,I))}
function Il(){++Pj;this.b=new oc;this.a=new pb(null,Oi((J(),new Jl(this))),po);D((null,I))}
function $g(){Fm();$wnd.ReactDOM.render(zm(new Am),(ah(),_g).getElementById('todoapp'),null)}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Oi(b))}
function Gi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{vi(a.a,b);--a.b}return c}
function Tm(a,b,c){var d;d=new Qm(b,c);lc(d.c,a,new kc(a,d));Nh(a.i,wh(d.e),d);$(a.d);return d}
function Ih(a,b){var c,d;for(d=new Vh(b.a);d.b;){c=Uh(d);if(!Rh(a,c)){return false}}return true}
function oi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(mi(a,c.Z())){return c}}return null}
function ki(a){var b,c,d;d=0;for(c=new Vh(a.a);c.b;){b=Uh(c);d=d+(b?r(b):0);d=d|0}return d}
function jb(a){var b,c;for(c=new ji(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Xm(a){zh(new Xh(a.i),new jc(a));Ph(a.i);mc(a.f);R(a.c);R(a.e);R(a.a);R(a.b);V(a.d)}
function gc(a,b,c){var d;d=Oh(a.i,b?wh(b.e):null);if(null!=d){nc(b.c,a);c&&!!b&&Hm(b);$(a.d)}}
function Fi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Ig(a){var b;b=a.h;if(b==0){return a.l+a.m*bo}if(b==1048575){return a.l+a.m*bo-ko}return a}
function Th(a){if(a.a.W()){return true}if(a.a!=a.c){return false}a.a=new ui(a.d.a);return a.a.W()}
function S(a){ab(a.d);nb(a.e)&&hb(a.e);if(a.b){if(kd(a.b,5)){throw Gg(a.b)}else{throw Gg(a.b)}}return a.g}
function ll(a,b,c,d){var e,f;e=false;f=Hj(a,d);if(!(b['a']===c['a'])){f&&$(a.c);e=true}return e||a.k}
function bd(a,b,c,d,e){e.vb=a;e.wb=b;e.xb=Zg;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Kg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=ko;d=1048575}c=qd(e/bo);b=qd(e-c*bo);return cd(b,c,d)}
function Y(a,b){var c,d;d=a.c;ei(d,b);d.a.length==0&&!!a.b&&Zn!=(a.b.c&$n)&&(a.d||Ib((J(),c=Bb,c),a))}
function zn(a){var b;b=Ub(a.j);Ch(vo,b)||Ch(so,b)||Ch('',b)?Tb(a.j,b):tn(Vb(a.j))?Yb(a.j):Tb(a.j,'')}
function fb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new sb(a)),ao,null);!!a.a&&R(a.a);a.c=a.c&-8|1}}
function Sj(a){if(!Qj){Qj=(++a.mb().e,new Ab);$wnd.Promise.resolve(null).then(Wg(Wj.prototype.I,Wj,[]))}}
function Ij(a){$wnd.React.Component.call(this,a);this.a=this.kb();this.a.o=Oi(this);this.a.gb()}
function ih(){this.g=fh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function T(a,b){this.c=Oi(a);this.f=null;this.g=null;this.e=new qb(this,b);this.d=new db(this.e);Zn==(b&$n)&&gb(this.e)}
function xc(a){vc();pc(this);this.e=a;a!=null&&tj(a,ho,this);this.f=a==null?jo:Yg(a);this.a='';this.b=a;this.a=''}
function $k(){var a;++Pj;this.c=new oc;this.b=(a=new db((J(),null)),a);this.a=new pb(null,Oi(new cl(this)),po);D((null,I))}
function Jk(){++Pj;this.c=new oc;this.a=new T((J(),new Kk),136486912);this.b=new pb(null,Oi(new Mk(this)),po);D((null,I))}
function ob(a,b,c,d){this.b=new hi;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&gb(this)}
function Sb(a){var b,c;c=(b=(ah(),$wnd.window.window).location.hash,null==b?'':b.substr(1));Zb(a,c);Ch(a.j,c)&&$b(a,c)}
function jl(a,b){var c;c=(ab(a.a),a.i);if(null!=c&&c.length!=0){mn((Fm(),b),c);An(Em,null);ul(a,c)}else{Vm((Fm(),Cm),b)}}
function dd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return cd(c&4194303,d&4194303,e&1048575)}
function Hg(a,b){var c;if(md(a)&&md(b)){c=a+b;if(-17592186044416<c&&c<ko){return c}}return Ig(dd(md(a)?Kg(a):a,md(b)?Kg(b):b))}
function wh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(yh(),xh)[b];!c&&(c=xh[b]=new vh(a));return c}return new vh(a)}
function Yg(a){var b;if(Array.isArray(a)&&a.xb===Zg){return hh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Bj(a){zj();var b,c,d;c=':'+a;d=yj[c];if(d!=null){return qd(d)}d=wj[c];b=d==null?Aj(a):qd(d);Cj();yj[c]=b;return b}
function li(a){var b,c,d;d=1;for(c=new ji(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function mc(a){var b,c;if(!a.a){for(c=new ji(new ii(new Xh(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.A()}a.a=true}}
function el(a){var b;b=S(a.d);if(!a.j&&b){a.j=true;tl(a,(bb(a.c),a.o.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function q(a){return od(a)?le:md(a)?ae:ld(a)?$d:jd(a)?a.vb:_c(a)?a.vb:a.vb||Array.isArray(a)&&Xc(Td,1)||Td}
function r(a){return od(a)?Bj(a):md(a)?qd(a):ld(a)?a?1231:1237:jd(a)?a.s():_c(a)?vj(a):!!a&&!!a.hashCode?a.hashCode():vj(a)}
function p(a,b){return od(a)?Ch(a,b):md(a)?a===b:ld(a)?a===b:jd(a)?a.q(b):_c(a)?a===b:!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function Hk(){Fk();return bd(Xc(_e,1),Xn,10,0,[jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek])}
function yb(){this.c=new P;this.d=Zc(ud,Xn,22,5,0,1);this.d[0]=new P;this.d[1]=new P;this.d[2]=new P;this.d[3]=new P;this.d[4]=new P}
function qh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function gi(a,b){var c,d;d=a.a.length;b.length<d&&(b=sj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Xj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Ec(){var a;if(zc!=0){a=yc();if(a-Ac>2000){Ac=a;Bc=$wnd.setTimeout(Kc,10)}}if(zc++==0){Nc((Mc(),Lc));return true}return false}
function Vc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Oj(a,b,c,d,e){var f;f=new $wnd.Object;f.$$typeof=$wnd.React.Element;f.type=Oi(a);f.key=b;f.ref=c;f.props=Oi(d);f._owner=e;return f}
function hd(a,b){if(od(a)){return !!gd[b]}else if(a.wb){return !!a.wb[b]}else if(md(a)){return !!fd[b]}else if(ld(a)){return !!ed[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function pb(a,b,c){ob.call(this,null,a,b,c|(!a?262144:Zn)|(a?Vn:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:bo)|(0!=(c&229376)?0:98304)|0|0|0)}
function Lb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&mb(b,5,true)}}}
function Kb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ji(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&mb(b,6,true)}}}
function Jb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?mb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Dh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function $c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Hb(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=di(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&mb(c.b,3,true);++b}}}return b}
function Qm(a,b){var c,d,e;this.i=Oi(a);this.g=b;this.e=Gm++;this.d=(d=new db((J(),null)),d);this.c=new oc;this.b=(e=new db(null),e);this.a=(c=new db(null),c)}
function Yb(b){var c;try{A((J(),J(),I),new dc(b),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){c=a;throw Gg(c)}else if(kd(a,4)){c=a;throw Gg(new uh(c))}else throw Gg(a)}}
function _b(b){var c;try{A((J(),J(),I),new ec(b),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){c=a;throw Gg(c)}else if(kd(a,4)){c=a;throw Gg(new uh(c))}else throw Gg(a)}}
function Vk(b){var c;try{A((J(),J(),I),new al(b),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){c=a;throw Gg(c)}else if(kd(a,4)){c=a;throw Gg(new uh(c))}else throw Gg(a)}}
function Pm(b){var c;try{A((J(),J(),I),new Sm(b),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){c=a;throw Gg(c)}else if(kd(a,4)){c=a;throw Gg(new uh(c))}else throw Gg(a)}}
function jn(b){var c;try{A((J(),J(),I),new qn(b),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){c=a;throw Gg(c)}else if(kd(a,4)){c=a;throw Gg(new uh(c))}else throw Gg(a)}}
function mn(b,c){var d;try{A((J(),J(),I),new pn(b,c),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function nn(b,c){var d;try{A((J(),J(),I),new sn(b,c),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function Vm(b,c){var d;try{A((J(),J(),I),new an(b,c),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function Wk(b,c){var d;try{A((J(),J(),I),new bl(b,c),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function ml(b,c){var d;try{A((J(),J(),I),new Fl(b,c),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function ql(b,c){var d;try{A((J(),J(),I),new El(b,c),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function rl(b,c){var d;try{A((J(),J(),I),new Cl(b,c),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function sl(b,c){var d;try{A((J(),J(),I),new Bl(b,c),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function tl(b,c){var d;try{A((J(),J(),I),new Al(b,c),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function Tb(b,c){var d;try{A((J(),J(),I),new cc(b,c),75505664)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function Um(b,c){var d;try{return t((J(),J(),I),new cn(b,c),fo,null)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){d=a;throw Gg(d)}else if(kd(a,4)){d=a;throw Gg(new uh(d))}else throw Gg(a)}}
function Pg(b,c,d,e){Og();var f=Mg;$moduleName=c;$moduleBase=d;Eg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Sn(g)()}catch(a){b(c,a)}}else{Sn(g)()}}
function qb(a,b){ob.call(this,a,new rb(a),null,b|(Zn==(b&$n)?0:524288)|(0!=(b&6291456)?0:Zn==(b&$n)?bo:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function Ai(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Bi()}}
function vl(){var a,b;++Pj;this.e=new oc;this.c=(b=new db((J(),null)),b);this.a=(a=new db(null),a);this.d=new T(new Dl(this),136486912);this.b=new pb(null,Oi(new Gl(this)),po);D((null,I))}
function $m(){var a;this.i=new ni;this.f=new oc;this.d=(a=new db((J(),null)),a);this.c=new T(new bn(this),uo);this.e=new T(new dn(this),uo);this.a=new T(new en(this),uo);this.b=new T(new fn(this),uo)}
function Jh(a,b){var c,d,e,f,g;g=Qh(a.a);b.length<g&&(b=sj(new Array(g),b));e=(f=new Vh((new Sh(a.a)).a),new Yh(f));for(d=0;d<g;++d){b[d]=(c=Uh(e.a),c.$())}b.length>g&&(b[g]=null);return b}
function Sg(){Rg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Rc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].yb()&&(c=Qc(c,g)):g[0].yb()}catch(a){a=Fg(a);if(kd(a,4)){d=a;Cc();Ic(kd(d,40)?d.H():d)}else throw Gg(a)}}return c}
function wc(a){var b;if(a.c==null){b=pd(a.b)===pd(uc)?null:a.b;a.d=b==null?jo:nd(b)?b==null?null:b.name:od(b)?'String':hh(q(b));a.a=a.a+': '+(nd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.g;try{d=b.c.u();if(!(pd(e)===pd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;Z(b.d)}}catch(a){a=Fg(a);if(kd(a,12)){c=a;if(!b.b){b.g=null;b.b=c;Z(b.d)}throw Gg(c)}else throw Gg(a)}}
function ri(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=oi(b,e);if(f){return f._(c)}}e[e.length]=new Zh(b,c);++a.b;return null}
function oj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Aj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Bh(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Zc(ie,Xn,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Bb){g=Vn==(d&Vn)?c.u():c.u()}else{Nb(b,e);try{g=Vn==(d&Vn)?c.u():c.u()}finally{Ob()}}return g}catch(a){a=Fg(a);if(kd(a,4)){f=a;throw Gg(f)}else throw Gg(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Bb){g=Vn==(d&Vn)?(c.a.A(),null):(c.a.A(),null)}else{Nb(b,e);try{g=Vn==(d&Vn)?(c.a.A(),null):(c.a.A(),null)}finally{Ob()}}return g}catch(a){a=Fg(a);if(kd(a,4)){f=a;throw Gg(f)}else throw Gg(a)}finally{D(b)}}
function Rb(a){var b;if(0==a.length){b=(ah(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',_g.title,b)}else{(ah(),$wnd.window.window).location.hash=a}}
function hb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.A()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=Fg(a);if(kd(a,4)){J()}else throw Gg(a)}}}
function si(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(mi(b,e.Z())){if(d.length==1){d.length=0;vi(a.a,g)}else{d.splice(h,1)}--a.b;return e.$()}}return null}
function Bn(a,b){var c;this.k=Oi(a);this.j=Oi(b);this.g=new oc;this.d=(c=new db((J(),null)),c);this.b=new T(new Dn(this),uo);this.c=new T(new En(this),uo);this.e=u(new Fn(this),413155328);this.a=u(new Gn(this),681590784);D((null,I))}
function Ug(a,b,c){var d=Rg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Rg[b]),Xg(h));_.wb=c;!b&&(_.xb=Zg);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.vb=f)}
function ph(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=qh('.',[c,qh('$',d)]);a.b=qh('.',[c,qh('.',d)]);a.i=d[d.length-1]}
function ac(){var a,b,c;this.f=new fc(this);this.c=new oc;this.b=(c=new db((J(),null)),c);this.a=(b=new db(null),b);bh((ah(),$wnd.window.window),eo,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function Kh(a,b){var c,d,e;c=b.Z();e=b.$();d=od(c)?c==null?Mh(qi(a.a,null)):Ei(a.b,c):Mh(qi(a.a,c));if(!(pd(e)===pd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(od(c)?c==null?!!qi(a.a,null):Di(a.b,c):!!qi(a.a,c))){return false}return true}
function nb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ji(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Fg(a);if(!kd(a,4))throw Gg(a)}if(6==(b.c&7)){return true}}}}}jb(b);return false}
function vb(a){var b,c,d,e,f,g,h,i;d=O(a.d[0]);c=O(a.d[1]);g=O(a.d[2]);e=O(a.d[3]);f=O(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=N(b);h.c&=-513;hb(h);return true}
function zi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function mb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){cb(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}ai(a.b,new tb(a));a.b.a=Zc(ie,Xn,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function Jj(a,b,c){var d,e,f,g,h;d={};f=null;g=null;if(null!=b){f='key' in b?''+b['key']:null;g='ref' in b?b['ref']:null;Ej(b,Wg(Mj.prototype.eb,Mj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));h=a;e=h['defaultProps'];null!=e&&Ej(e,Wg(Nj.prototype.eb,Nj,[d,e]));return Oj(a,f,g,d,$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current)}
function Fk(){Fk=Vg;jk=new Gk(no,0);kk=new Gk('checkbox',1);lk=new Gk('color',2);mk=new Gk('date',3);nk=new Gk('datetime',4);ok=new Gk('email',5);pk=new Gk('file',6);qk=new Gk('hidden',7);rk=new Gk('image',8);sk=new Gk('month',9);tk=new Gk(Un,10);uk=new Gk('password',11);vk=new Gk('radio',12);wk=new Gk('range',13);xk=new Gk('reset',14);yk=new Gk('search',15);zk=new Gk('submit',16);Ak=new Gk('tel',17);Bk=new Gk('text',18);Ck=new Gk('time',19);Dk=new Gk('url',20);Ek=new Gk('week',21)}
function Eb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=bi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&fi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Y(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&mb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=bi(a.b,g);if(-1==k.e){k.e=0;X(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){di(a.b,g)}e&&lb(a.e,a.b)}else{e&&lb(a.e,new hi)}if(U(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&Zn!=(b.e.c&$n)&&Ib(a,k)}}
function Bi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[mo]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!zi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[mo]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Tn='object',Un='number',Vn=16384,Wn={15:1},Xn={3:1,6:1},Yn={11:1},Zn=1048576,$n=1835008,_n={8:1},ao=67108864,bo=4194304,co={30:1},eo='hashchange',fo=142614528,go='__noinit__',ho='__java$exception',io={3:1,12:1,5:1,4:1},jo='null',ko=17592186044416,lo={44:1},mo='delete',no='button',oo='selected',po=1478635520,qo={11:1,24:1},ro='input',so='completed',to='header',uo=136421376,vo='active';var _,Rg,Mg,Eg=-1;Sg();Ug(1,null,{},o);_.q=xo;_.r=function(){return this.vb};_.s=yo;_.t=function(){var a;return hh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.q(a)};_.hashCode=function(){return this.s()};_.toString=function(){return this.t()};var ed,fd,gd;Ug(52,1,{},ih);_.J=function(a){var b;b=new ih;b.e=4;a>1?(b.c=nh(this,a-1)):(b.c=this);return b};_.K=function(){gh(this);return this.b};_.L=function(){return hh(this)};_.M=function(){gh(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.t=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(gh(this),this.k)};_.e=0;_.g=0;var fh=1;var ie=kh(1);var _d=kh(52);Ug(76,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var td=kh(76);Ug(16,1,Wn,G);_.u=function(){return this.a.A(),null};var rd=kh(16);Ug(77,1,{},H);var sd=kh(77);var I;Ug(22,1,{22:1},P);_.b=0;_.c=false;_.d=0;var ud=kh(22);Ug(204,1,Yn);_.t=function(){var a;return hh(this.vb)+'@'+(a=r(this)>>>0,a.toString(16))};var wd=kh(204);Ug(21,204,Yn,T);_.v=function(){R(this)};_.w=wo;_.a=false;var vd=kh(21);Ug(17,204,{11:1,17:1},db);_.v=function(){V(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var yd=kh(17);Ug(116,1,_n,eb);_.A=function(){W(this.a)};var xd=kh(116);Ug(19,204,{11:1,19:1},pb,qb);_.v=function(){fb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Cd=kh(19);Ug(117,1,co,rb);_.A=function(){Q(this.a)};var zd=kh(117);Ug(118,1,_n,sb);_.A=function(){kb(this.a)};var Ad=kh(118);Ug(119,1,{},tb);_.B=function(a){ib(this.a,a)};var Bd=kh(119);Ug(121,1,{},yb);_.a=0;_.b=100;_.e=0;var Dd=kh(121);Ug(62,1,Yn,Ab);_.v=function(){zb(this)};_.w=wo;_.a=false;var Ed=kh(62);Ug(135,1,{},Mb);_.t=function(){var a;return gh(Fd),Fd.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.a=0;var Bb;var Fd=kh(135);Ug(46,1,{46:1});_.e='';_.g='';_.i=true;_.j='';var Md=kh(46);Ug(101,46,{11:1,46:1,24:1},ac);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new bc(this)),ao,null)}};_.q=xo;_.C=Fo;_.s=yo;_.w=Go;_.t=function(){var a;return gh(Kd),Kd.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.d=0;var Kd=kh(101);Ug(102,1,_n,bc);_.A=function(){Wb(this.a)};var Gd=kh(102);Ug(103,1,_n,cc);_.A=function(){Pb(this.a,this.b)};var Hd=kh(103);Ug(104,1,_n,dc);_.A=function(){Xb(this.a)};var Id=kh(104);Ug(105,1,_n,ec);_.A=function(){Sb(this.a)};var Jd=kh(105);Ug(78,1,{},fc);_.handleEvent=function(a){Qb(this.a,a)};var Ld=kh(78);Ug(106,1,{});var Pd=kh(106);Ug(79,1,{},jc);_.B=function(a){hc(this.a,a)};var Nd=kh(79);Ug(80,1,_n,kc);_.A=function(){ic(this.a,this.b)};var Od=kh(80);Ug(107,106,{});var Qd=kh(107);Ug(18,1,Yn,oc);_.v=function(){mc(this)};_.w=wo;_.a=false;var Rd=kh(18);Ug(4,1,{3:1,4:1});_.D=function(a){return new Error(a)};_.F=Po;_.G=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=hh(this.vb),c==null?a:a+': '+c);qc(this,sc(this.D(b)));Uc(this)};_.t=function(){return rc(this,this.F())};_.e=go;_.g=true;var me=kh(4);Ug(12,4,{3:1,12:1,4:1});var ce=kh(12);Ug(5,12,io);var je=kh(5);Ug(53,5,io);var fe=kh(53);Ug(71,53,io);var Vd=kh(71);Ug(40,71,{40:1,3:1,12:1,5:1,4:1},xc);_.F=function(){wc(this);return this.c};_.H=function(){return pd(this.b)===pd(uc)?null:this.b};var uc;var Sd=kh(40);var Td=kh(0);Ug(190,1,{});var Ud=kh(190);var zc=0,Ac=0,Bc=-1;Ug(100,190,{},Pc);var Lc;var Wd=kh(100);var Sc;Ug(201,1,{});var Yd=kh(201);Ug(72,201,{},Wc);var Xd=kh(72);var _g;Ug(69,1,{66:1});_.t=wo;var Zd=kh(69);ed={3:1,67:1,32:1};var $d=kh(67);Ug(45,1,{3:1,45:1});var he=kh(45);fd={3:1,32:1,45:1};var ae=kh(200);Ug(36,1,{3:1,32:1,36:1});_.q=xo;_.s=yo;_.t=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=kh(36);Ug(9,5,io,th,uh);var de=kh(9);Ug(33,45,{3:1,32:1,33:1,45:1},vh);_.q=function(a){return kd(a,33)&&a.a==this.a};_.s=wo;_.t=function(){return ''+this.a};_.a=0;var ee=kh(33);var xh;Ug(261,1,{});Ug(74,53,io,Ah);_.D=function(a){return new TypeError(a)};var ge=kh(74);gd={3:1,66:1,32:1,2:1};var le=kh(2);Ug(70,69,{66:1},Gh);var ke=kh(70);Ug(265,1,{});Ug(55,5,io,Hh);var ne=kh(55);Ug(202,1,{43:1});_.P=Co;_.T=function(){return new Si(this,0)};_.U=function(){return new aj(null,this.T())};_.R=function(a){throw Gg(new Hh('Add not supported on this collection'))};_.t=function(){var a,b,c;c=new Ui('[',']');for(b=this.Q();b.W();){a=b.X();Ti(c,a===this?'(this Collection)':a==null?jo:Yg(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var oe=kh(202);Ug(205,1,{188:1});_.q=function(a){var b,c,d;if(a===this){return true}if(!kd(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Vh((new Sh(d)).a);c.b;){b=Uh(c);if(!Kh(this,b)){return false}}return true};_.s=function(){return ki(new Sh(this))};_.t=function(){var a,b,c;c=new Ui('{','}');for(b=new Vh((new Sh(this)).a);b.b;){a=Uh(b);Ti(c,Lh(this,a.Z())+'='+Lh(this,a.$()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ze=kh(205);Ug(122,205,{188:1});var re=kh(122);Ug(206,202,{43:1,212:1});_.T=function(){return new Si(this,1)};_.q=function(a){var b;if(a===this){return true}if(!kd(a,27)){return false}b=a;if(Qh(b.a)!=this.S()){return false}return Ih(this,b)};_.s=function(){return ki(this)};var Ae=kh(206);Ug(27,206,{27:1,43:1,212:1},Sh);_.Q=function(){return new Vh(this.a)};_.S=Ao;var qe=kh(27);Ug(28,1,{},Vh);_.V=zo;_.X=function(){return Uh(this)};_.W=Bo;_.b=false;var pe=kh(28);Ug(203,202,{43:1,210:1});_.T=function(){return new Si(this,16)};_.Y=function(a,b){throw Gg(new Hh('Add not supported on this list'))};_.R=function(a){this.Y(this.S(),a);return true};_.q=function(a){var b,c,d,e,f;if(a===this){return true}if(!kd(a,14)){return false}f=a;if(this.S()!=f.a.length){return false}e=new ji(f);for(c=new ji(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(pd(b)===pd(d)||b!=null&&p(b,d))){return false}}return true};_.s=function(){return li(this)};_.Q=function(){return new Wh(this)};var te=kh(203);Ug(98,1,{},Wh);_.V=zo;_.W=function(){return this.a<this.b.a.length};_.X=function(){return bi(this.b,this.a++)};_.a=0;var se=kh(98);Ug(48,202,{43:1},Xh);_.Q=function(){var a;return a=new Vh((new Sh(this.a)).a),new Yh(a)};_.S=Ao;var ve=kh(48);Ug(57,1,{},Yh);_.V=zo;_.W=function(){return this.a.b};_.X=function(){var a;return a=Uh(this.a),a.$()};var ue=kh(57);Ug(123,1,lo);_.q=function(a){var b;if(!kd(a,44)){return false}b=a;return mi(this.a,b.Z())&&mi(this.b,b.$())};_.Z=wo;_.$=Bo;_.s=function(){return Ni(this.a)^Ni(this.b)};_._=function(a){var b;b=this.b;this.b=a;return b};_.t=function(){return this.a+'='+this.b};var we=kh(123);Ug(124,123,lo,Zh);var xe=kh(124);Ug(207,1,lo);_.q=function(a){var b;if(!kd(a,44)){return false}b=a;return mi(this.b.value[0],b.Z())&&mi(Ji(this),b.$())};_.s=function(){return Ni(this.b.value[0])^Ni(Ji(this))};_.t=function(){return this.b.value[0]+'='+Ji(this)};var ye=kh(207);Ug(14,203,{3:1,14:1,43:1,210:1},hi,ii);_.Y=function(a,b){pj(this.a,a,b)};_.R=function(a){return _h(this,a)};_.P=function(a){ai(this,a)};_.Q=function(){return new ji(this)};_.S=function(){return this.a.length};var Ce=kh(14);Ug(20,1,{},ji);_.V=zo;_.W=function(){return this.a<this.c.a.length};_.X=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Be=kh(20);Ug(41,122,{3:1,41:1,188:1},ni);var De=kh(41);Ug(60,1,{},ti);_.P=Co;_.Q=function(){return new ui(this)};_.b=0;var Fe=kh(60);Ug(61,1,{},ui);_.V=zo;_.X=function(){return this.d=this.a[this.c++],this.d};_.W=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ee=kh(61);var xi;Ug(58,1,{},Hi);_.P=Co;_.Q=function(){return new Ii(this)};_.b=0;_.c=0;var Ie=kh(58);Ug(59,1,{},Ii);_.V=zo;_.X=function(){return this.c=this.a,this.a=this.b.next(),new Ki(this.d,this.c,this.d.c)};_.W=function(){return !this.a.done};var Ge=kh(59);Ug(134,207,lo,Ki);_.Z=function(){return this.b.value[0]};_.$=function(){return Ji(this)};_._=function(a){return Fi(this.a,this.b.value[0],a)};_.c=0;var He=kh(134);Ug(99,1,{});_.V=function(a){Pi(this,a)};_.ab=function(){return this.d};_.bb=Lo;_.d=0;_.e=0;var Ke=kh(99);Ug(56,99,{});var Je=kh(56);Ug(26,1,{},Si);_.ab=wo;_.bb=function(){Ri(this);return this.c};_.V=function(a){Ri(this);this.d.V(a)};_.cb=function(a){Ri(this);if(this.d.W()){a.B(this.d.X());return true}return false};_.a=0;_.c=0;var Le=kh(26);Ug(54,1,{},Ui);_.t=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Me=kh(54);var Ve=mh();Ug(125,1,{});_.c=false;var We=kh(125);Ug(35,125,{},aj);var Ue=kh(35);Ug(127,56,{},ej);_.cb=function(a){this.b=false;while(!this.b&&this.c.cb(new fj(this,a)));return this.b};_.b=false;var Oe=kh(127);Ug(130,1,{},fj);_.B=function(a){dj(this.a,this.b,a)};var Ne=kh(130);Ug(126,56,{},hj);_.cb=function(a){return this.a.cb(new ij(a))};var Qe=kh(126);Ug(129,1,{},ij);_.B=function(a){gj(this.a,a)};var Pe=kh(129);Ug(128,1,{},kj);_.B=function(a){jj(this,a)};var Re=kh(128);Ug(131,1,{},lj);_.B=function(a){};var Se=kh(131);Ug(132,1,{},nj);_.B=function(a){mj(this,a)};var Te=kh(132);Ug(263,1,{});Ug(209,1,{});var Xe=kh(209);Ug(260,1,{});var uj=0;var wj,xj=0,yj;Ug(687,1,{});Ug(711,1,{});Ug(208,1,{});_.fb=Do;_.gb=Do;_.ib=function(a,b,c){return false};_.p=false;var Ye=kh(208);Ug(34,$wnd.React.Component,{});Tg(Rg[1],_);_.render=function(){return Uj(this.a)};var Ze=kh(34);Ug(226,$wnd.Function,{},Mj);_.eb=function(a){Kj(this.a,this.b,a)};Ug(227,$wnd.Function,{},Nj);_.eb=function(a){Lj(this.a,this.b,a)};Ug(38,208,{});_.lb=function(){return false};_.nb=function(){return Vj(this)};_.k=false;_.n=false;var Pj=1,Qj;var $e=kh(38);Ug(232,$wnd.Function,{},Wj);_.I=function(a){return zb(Qj),Qj=null,null};Ug(10,36,{3:1,32:1,36:1,10:1},Gk);var jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek;var _e=lh(10,Hk);Ug(156,38,{});_.sb=Eo;_.hb=function(){var a;a=S((Fm(),Em).b);return Jj('footer',Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,['footer'])),[Pl(new Ql),Jj('ul',Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,['filters'])),[Jj('li',null,[Jj('a',Zj(Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,[(Kn(),In)==a?oo:null])),'#'),['All'])]),Jj('li',null,[Jj('a',Zj(Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,[Hn==a?oo:null])),'#active'),['Active'])]),Jj('li',null,[Jj('a',Zj(Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,[Jn==a?oo:null])),'#completed'),['Completed'])])]),this.sb()?Jj(no,$j(Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,['clear-completed'])),Wg(Ml.prototype.rb,Ml,[])),['Clear Completed']):null])};var Jf=kh(156);Ug(157,156,{});_.sb=Eo;var Nf=kh(157);Ug(158,157,qo,Jk);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Nk(this)),ao,null)}};_.q=xo;_.mb=Ho;_.C=Fo;_.sb=function(){return S(this.a)};_.s=yo;_.w=Go;_.t=function(){var a;return gh(jf),jf.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.nb=function(){var b;try{return B((J(),J(),I),this.b,new Lk(this))}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){b=a;throw Gg(b)}else if(kd(a,4)){b=a;throw Gg(new uh(b))}else throw Gg(a)}};_.d=0;var jf=kh(158);Ug(159,1,Wn,Kk);_.u=function(){return eh(),S((Fm(),Cm).b).a>0?true:false};var af=kh(159);Ug(162,1,Wn,Lk);_.u=Jo;var bf=kh(162);Ug(160,1,co,Mk);_.A=Io;var cf=kh(160);Ug(161,1,_n,Nk);_.A=function(){Ik(this.a)};var df=kh(161);Ug(181,38,{});_.hb=function(){var a,b;b=S((Fm(),Cm).e).a;a='item'+(b==1?'':'s');return Jj('span',Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,['todo-count'])),[Jj('strong',null,[b]),' '+a+' left'])};var If=kh(181);Ug(182,181,{});var Mf=kh(182);Ug(183,182,qo,Pk);_.v=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Rk(this)),ao,null)}};_.q=xo;_.mb=Ho;_.C=Bo;_.s=yo;_.w=Mo;_.t=function(){var a;return gh(hf),hf.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.nb=function(){var b;try{return B((J(),J(),I),this.a,new Sk(this))}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){b=a;throw Gg(b)}else if(kd(a,4)){b=a;throw Gg(new uh(b))}else throw Gg(a)}};_.c=0;var hf=kh(183);Ug(184,1,co,Qk);_.A=Io;var ef=kh(184);Ug(185,1,_n,Rk);_.A=function(){Ok(this.a)};var ff=kh(185);Ug(186,1,Wn,Sk);_.u=Jo;var gf=kh(186);Ug(148,38,{});_.hb=function(){return Jj(ro,_j(dk(ek(hk(fk(Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,['new-todo']))),(ab(this.b),this.e)),Wg(jm.prototype.qb,jm,[this])),Wg(km.prototype.pb,km,[this]))),null)};_.e='';var Vf=kh(148);Ug(149,148,{});var Pf=kh(149);Ug(150,149,qo,$k);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new dl(this)),ao,null)}};_.q=xo;_.mb=Ho;_.C=Fo;_.s=yo;_.w=Go;_.t=function(){var a;return gh(pf),pf.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.nb=function(){var b;try{return B((J(),J(),I),this.a,new _k(this))}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){b=a;throw Gg(b)}else if(kd(a,4)){b=a;throw Gg(new uh(b))}else throw Gg(a)}};_.d=0;var pf=kh(150);Ug(153,1,Wn,_k);_.u=Jo;var kf=kh(153);Ug(154,1,_n,al);_.A=function(){Tk(this.a)};var lf=kh(154);Ug(155,1,_n,bl);_.A=function(){Xk(this.a,this.b)};var mf=kh(155);Ug(151,1,co,cl);_.A=Io;var nf=kh(151);Ug(152,1,_n,dl);_.A=function(){Yk(this.a)};var of=kh(152);Ug(165,38,{});_.fb=function(){el(this)};_.ub=Ko;_.gb=function(){tl(this,this.tb())};_.hb=function(){var a,b;b=this.tb();a=(ab(b.a),b.g);return Jj('li',Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,[a?so:null,this.ub()?'editing':null])),[Jj('div',Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,['view'])),[Jj(ro,dk(ak(gk(Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,['toggle'])),(Fk(),kk)),a),Wg(om.prototype.pb,om,[b])),null),Jj('label',ik(new $wnd.Object,Wg(pm.prototype.rb,pm,[this,b])),[(ab(b.b),b.i)]),Jj(no,$j(Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,['destroy'])),Wg(qm.prototype.rb,qm,[b])),null)]),Jj(ro,ek(dk(ck(bk(Xj(Yj(new $wnd.Object,Wg(rm.prototype.B,rm,[this])),bd(Xc(le,1),Xn,2,6,['edit'])),(ab(this.a),this.i)),Wg(sm.prototype.ob,sm,[this,b])),Wg(nm.prototype.pb,nm,[this])),Wg(tm.prototype.qb,tm,[this,b])),null)])};_.j=false;var Xf=kh(165);Ug(166,165,{});_.lb=function(){var a;a=(bb(this.c),this.o.props['a']);if(!!a&&a.f<0){return true}return false};_.tb=function(){return this.o.props['a']};_.ub=Ko;_.ib=function(a,b,c){return ll(this,a,b,c)};var Rf=kh(166);Ug(167,166,qo,vl);_.fb=function(){var b;try{A((J(),J(),I),new yl(this),fo)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){b=a;throw Gg(b)}else if(kd(a,4)){b=a;throw Gg(new uh(b))}else throw Gg(a)}};_.v=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new wl(this)),ao,null)}};_.q=xo;_.mb=Ho;_.C=Lo;_.tb=function(){return bb(this.c),this.o.props['a']};_.s=yo;_.w=Oo;_.ub=function(){return S(this.d)};_.ib=function(b,c,d){var e;try{return t((J(),J(),I),new zl(this,b,c,d),75505664,null)}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){e=a;throw Gg(e)}else if(kd(a,4)){e=a;throw Gg(new uh(e))}else throw Gg(a)}};_.t=function(){var a;return gh(Bf),Bf.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.nb=function(){var b;try{return B((J(),J(),I),this.b,new xl(this))}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){b=a;throw Gg(b)}else if(kd(a,4)){b=a;throw Gg(new uh(b))}else throw Gg(a)}};_.f=0;var Bf=kh(167);Ug(170,1,_n,wl);_.A=function(){nl(this.a)};var qf=kh(170);Ug(171,1,Wn,xl);_.u=Jo;var rf=kh(171);Ug(172,1,_n,yl);_.A=function(){el(this.a)};var sf=kh(172);Ug(173,1,Wn,zl);_.u=function(){return ol(this.a,this.d,this.c,this.b)};_.b=false;var tf=kh(173);Ug(174,1,_n,Al);_.A=function(){ul(this.a,Jm(this.b))};var uf=kh(174);Ug(175,1,_n,Bl);_.A=function(){jl(this.a,this.b)};var vf=kh(175);Ug(176,1,_n,Cl);_.A=function(){il(this.a,this.b)};var wf=kh(176);Ug(168,1,Wn,Dl);_.u=function(){return pl(this.a)};var xf=kh(168);Ug(177,1,_n,El);_.A=function(){tl(this.a,this.b);An((Fm(),Em),null)};var yf=kh(177);Ug(178,1,_n,Fl);_.A=function(){fl(this.a,this.b)};var zf=kh(178);Ug(169,1,co,Gl);_.A=Io;var Af=kh(169);Ug(136,38,{});_.hb=function(){var a,b;return Jj('div',null,[Jj('div',null,[Jj(to,Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,[to])),[Jj('h1',null,['todos']),lm(new mm)]),S((Fm(),Cm).c)?null:Jj('section',Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,[to])),[Jj(ro,dk(gk(Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,['toggle-all'])),(Fk(),kk)),Wg(ym.prototype.pb,ym,[])),null),Jj('ul',Xj(new $wnd.Object,bd(Xc(le,1),Xn,2,6,['todo-list'])),(a=_i($i(S(Em.c).U()),(b=new hi,b)),gi(a,ad(a.a.length))))]),S(Cm.c)?null:Nl(new Ol)])])};var Zf=kh(136);Ug(137,136,{});var Tf=kh(137);Ug(138,137,qo,Il);_.v=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Kl(this)),ao,null)}};_.q=xo;_.mb=Ho;_.C=Bo;_.s=yo;_.w=Mo;_.t=function(){var a;return gh(Ff),Ff.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.nb=function(){var b;try{return B((J(),J(),I),this.a,new Ll(this))}catch(a){a=Fg(a);if(kd(a,5)||kd(a,7)){b=a;throw Gg(b)}else if(kd(a,4)){b=a;throw Gg(new uh(b))}else throw Gg(a)}};_.c=0;var Ff=kh(138);Ug(139,1,co,Jl);_.A=Io;var Cf=kh(139);Ug(140,1,_n,Kl);_.A=function(){Ok(this.a)};var Df=kh(140);Ug(141,1,Wn,Ll);_.u=Jo;var Ef=kh(141);Ug(237,$wnd.Function,{},Ml);_.rb=function(a){jn((Fm(),Dm))};Ug(143,1,{},Ol);var Gf=kh(143);Ug(163,1,{},Ql);var Hf=kh(163);Ug(236,$wnd.Function,{},Rl);_.jb=function(a){return new Ul(a)};var Sl;Ug(145,34,{},Ul);_.kb=function(){return new Jk};_.componentWillUnmount=No;var Kf=kh(145);Ug(247,$wnd.Function,{},Vl);_.jb=function(a){return new Yl(a)};var Wl;Ug(164,34,{},Yl);_.kb=function(){return new Pk};_.componentWillUnmount=No;var Lf=kh(164);Ug(233,$wnd.Function,{},Zl);_.jb=function(a){return new am(a)};var $l;Ug(144,34,{},am);_.kb=function(){return new $k};_.componentWillUnmount=No;var Of=kh(144);Ug(238,$wnd.Function,{},bm);_.jb=function(a){return new em(a)};var cm;Ug(147,34,{},em);_.kb=function(){return new vl};_.componentDidUpdate=function(a){Fj(this.a,a)};_.componentWillUnmount=No;_.shouldComponentUpdate=function(a){return Gj(this.a,a)};var Qf=kh(147);Ug(230,$wnd.Function,{},fm);_.jb=function(a){return new im(a)};var gm;Ug(120,34,{},im);_.kb=function(){return new Il};_.componentWillUnmount=No;var Sf=kh(120);Ug(234,$wnd.Function,{},jm);_.qb=function(a){Uk(this.a,a)};Ug(235,$wnd.Function,{},km);_.pb=function(a){Wk(this.a,a)};Ug(142,1,{},mm);var Uf=kh(142);Ug(245,$wnd.Function,{},nm);_.pb=function(a){ml(this.a,a)};Ug(239,$wnd.Function,{},om);_.pb=function(a){Pm(this.a)};Ug(241,$wnd.Function,{},pm);_.rb=function(a){rl(this.a,this.b)};Ug(242,$wnd.Function,{},qm);_.rb=function(a){kl(this.a)};Ug(243,$wnd.Function,{},rm);_.B=function(a){gl(this.a,a)};Ug(244,$wnd.Function,{},sm);_.ob=function(a){sl(this.a,this.b)};Ug(246,$wnd.Function,{},tm);_.qb=function(a){hl(this.a,this.b,a)};Ug(146,1,{},xm);var Wf=kh(146);Ug(231,$wnd.Function,{},ym);_.pb=function(a){var b;b=a.target;nn((Fm(),Dm),b.checked)};Ug(65,1,{},Am);var Yf=kh(65);var Bm,Cm,Dm,Em;Ug(49,1,{49:1});_.g=false;var Bg=kh(49);Ug(50,49,{11:1,24:1,50:1,49:1},Qm);_.v=function(){Hm(this)};_.q=function(a){return Im(this,a)};_.C=Fo;_.s=Lo;_.w=Oo;_.t=function(){var a;return gh(ng),ng.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var Gm=0;var ng=kh(50);Ug(179,1,_n,Rm);_.A=function(){Lm(this.a)};var $f=kh(179);Ug(180,1,_n,Sm);_.A=function(){Mm(this.a)};var _f=kh(180);Ug(47,107,{47:1});var wg=kh(47);Ug(108,47,{11:1,24:1,47:1},$m);_.v=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new _m(this)),ao,null)}};_.q=xo;_.C=Po;_.s=yo;_.w=function(){return this.g<0};_.t=function(){var a;return gh(hg),hg.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.g=0;var hg=kh(108);Ug(113,1,_n,_m);_.A=function(){Xm(this.a)};var ag=kh(113);Ug(114,1,_n,an);_.A=function(){gc(this.a,this.b,true)};var bg=kh(114);Ug(109,1,Wn,bn);_.u=function(){return Ym(this.a)};var cg=kh(109);Ug(115,1,Wn,cn);_.u=function(){return Tm(this.a,this.c,this.b)};_.b=false;var dg=kh(115);Ug(110,1,Wn,dn);_.u=function(){return wh(Lg(Yi(Wm(this.a))))};var eg=kh(110);Ug(111,1,Wn,en);_.u=function(){return wh(Lg(Yi(Zi(Wm(this.a),new Nn))))};var fg=kh(111);Ug(112,1,Wn,fn);_.u=function(){return Zm(this.a)};var gg=kh(112);Ug(85,1,{});var Ag=kh(85);Ug(86,85,qo,on);_.v=function(){if(this.b>=0){this.b=-2;t((J(),J(),I),new G(new rn(this)),ao,null)}};_.q=xo;_.C=wo;_.s=yo;_.w=function(){return this.b<0};_.t=function(){var a;return gh(mg),mg.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.b=0;var mg=kh(86);Ug(89,1,_n,pn);_.A=function(){Om(this.b,this.a)};var ig=kh(89);Ug(90,1,_n,qn);_.A=function(){kn(this.a)};var jg=kh(90);Ug(87,1,_n,rn);_.A=function(){mc(this.a.a)};var kg=kh(87);Ug(88,1,_n,sn);_.A=function(){ln(this.a,this.b)};_.b=false;var lg=kh(88);Ug(91,1,{});var Dg=kh(91);Ug(92,91,qo,Bn);_.v=function(){if(this.i>=0){this.i=-2;t((J(),J(),I),new G(new Cn(this)),ao,null)}};_.q=xo;_.C=function(){return this.g};_.s=yo;_.w=function(){return this.i<0};_.t=function(){var a;return gh(tg),tg.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.i=0;var tg=kh(92);Ug(97,1,_n,Cn);_.A=function(){wn(this.a)};var og=kh(97);Ug(93,1,Wn,Dn);_.u=function(){var a;return a=Vb(this.a.j),Ch(vo,a)||Ch(so,a)||Ch('',a)?Ch(vo,a)?(Kn(),Hn):Ch(so,a)?(Kn(),Jn):(Kn(),In):(Kn(),In)};var pg=kh(93);Ug(94,1,Wn,En);_.u=function(){return xn(this.a)};var qg=kh(94);Ug(95,1,co,Fn);_.A=function(){yn(this.a)};var rg=kh(95);Ug(96,1,co,Gn);_.A=function(){zn(this.a)};var sg=kh(96);Ug(37,36,{3:1,32:1,36:1,37:1},Ln);var Hn,In,Jn;var ug=lh(37,Mn);Ug(81,1,{},Nn);_.db=function(a){return !Km(a)};var vg=kh(81);Ug(83,1,{},On);_.db=function(a){return Km(a)};var xg=kh(83);Ug(84,1,{},Pn);_.B=function(a){Vm(this.a,a)};var yg=kh(84);Ug(82,1,{},Qn);_.B=function(a){hn(this.a,a)};_.a=false;var zg=kh(82);Ug(73,1,{},Rn);_.db=function(a){return un(this.a,a)};var Cg=kh(73);var Sn=(Cc(),Fc);var gwtOnLoad=gwtOnLoad=Pg;Ng($g);Qg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();