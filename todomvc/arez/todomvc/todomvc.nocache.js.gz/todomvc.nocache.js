function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='F3ED3156B12904A3407F2B9096FB3CAC',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'F3ED3156B12904A3407F2B9096FB3CAC';function o(){}
function Yg(){}
function Ug(){}
function Bb(){}
function Qc(){}
function Xc(){}
function jj(){}
function kj(){}
function Mj(){}
function Ck(){}
function Il(){}
function Nl(){}
function Pl(){}
function Rl(){}
function Tl(){}
function Vl(){}
function km(){}
function zn(){}
function An(){}
function Vc(a){Uc()}
function dh(){dh=Ug}
function gi(){Zh(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function fb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function ub(a){this.a=a}
function uh(a){this.a=a}
function Fh(a){this.a=a}
function Rh(a){this.a=a}
function Wh(a){this.a=a}
function Xh(a){this.a=a}
function cc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function gc(a){this.a=a}
function kc(a){this.a=a}
function hj(a){this.a=a}
function mj(a){this.a=a}
function Dk(a){this.a=a}
function Ek(a){this.a=a}
function Fk(a){this.a=a}
function Kk(a){this.a=a}
function Lk(a){this.a=a}
function Mk(a){this.a=a}
function Xk(a){this.a=a}
function Yk(a){this.a=a}
function $k(a){this.a=a}
function _k(a){this.a=a}
function sl(a){this.a=a}
function tl(a){this.a=a}
function zl(a){this.a=a}
function Al(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function Xl(a){this.a=a}
function Yl(a){this.a=a}
function _l(a){this.a=a}
function am(a){this.a=a}
function cm(a){this.a=a}
function dm(a){this.a=a}
function Dm(a){this.a=a}
function Em(a){this.a=a}
function Nm(a){this.a=a}
function Pm(a){this.a=a}
function Rm(a){this.a=a}
function Sm(a){this.a=a}
function Tm(a){this.a=a}
function bn(a){this.a=a}
function cn(a){this.a=a}
function on(a){this.a=a}
function pn(a){this.a=a}
function qn(a){this.a=a}
function rn(a){this.a=a}
function sn(a){this.a=a}
function Bn(a){this.a=a}
function Cn(a){this.a=a}
function Dn(a){this.a=a}
function Vh(a){this.b=a}
function ii(a){this.c=a}
function Kl(){this.a={}}
function Ml(){this.a={}}
function $l(){this.a={}}
function jm(){this.a={}}
function mm(){this.a={}}
function to(){Gj(this.a)}
function yo(){Ij(this.a)}
function si(){this.a=Bi()}
function Gi(){this.a=Bi()}
function lo(a){Ki(this,a)}
function oo(a){yh(this,a)}
function $(a){Kb((J(),a))}
function ab(a){Lb((J(),a))}
function db(a){Mb((J(),a))}
function w(a){--a.e;D(a)}
function C(a,b){yb(a.b,b)}
function oc(a,b){Nh(a.b,b)}
function lj(a,b){bj(a.a,b)}
function Um(a,b){Gm(a.c,b)}
function Vm(a,b){zm(b,a)}
function ij(a,b){a.a=b}
function Cj(a,b,c){a[b]=c}
function mb(a,b){a.b=Ni(b)}
function Fg(a){return a.e}
function wo(){return this.e}
function io(){return this.a}
function no(){return this.b}
function qo(){return this.c}
function Bo(){return this.f}
function ro(){return this.d<0}
function xo(){return this.c<0}
function Ao(){return this.f<0}
function ko(){return uj(this)}
function Bh(a,b){return a===b}
function dl(a,b){return a.g=b}
function ai(a,b){return a.a[b]}
function qj(a,b){a.splice(b,1)}
function mc(a,b,c){Mh(a.b,b,c)}
function Ik(a){nc(a.b);gb(a.a)}
function Gh(a){uc.call(this,a)}
function Ol(a){Dj.call(this,a)}
function Ql(a){Dj.call(this,a)}
function Sl(a){Dj.call(this,a)}
function Ul(a){Dj.call(this,a)}
function Wl(a){Dj.call(this,a)}
function gl(a){Hm((rm(),om),a)}
function so(){return J(),J(),I}
function jo(a){return this===a}
function gh(a){fh(a);return a.k}
function Yc(a,b){return mh(a,b)}
function F(){this.b=new zb}
function pc(){this.b=new mi}
function J(){J=Ug;I=new F}
function wc(){wc=Ug;vc=new o}
function Nc(){Nc=Ug;Mc=new Qc}
function xi(){xi=Ug;wi=zi()}
function Dc(){Dc=Ug;!!(Uc(),Tc)}
function Ng(){Lg==null&&(Lg=[])}
function zh(){qc(this);this.F()}
function mo(){return Ph(this.a)}
function uo(){return Lj(this.a)}
function Ph(a){return a.a.b+a.b.b}
function X(a){J();Lb(a);a.e=-2}
function Eb(a){Fb(a);!a.d&&Ib(a)}
function Vb(a){bb(a.a);return a.e}
function Wb(a){bb(a.b);return a.g}
function vm(a){bb(a.b);return a.i}
function wm(a){bb(a.a);return a.g}
function gn(a){bb(a.d);return a.f}
function aj(a,b){a.Q(b);return a}
function Oj(a,b){a.ref=b;return a}
function Oi(a,b){while(a.bb(b));}
function bj(a,b){ij(a,aj(a.a,b))}
function Yb(a){Ub(a,(bb(a.b),a.g))}
function bd(a){return new Array(a)}
function Di(a,b){return a.a.get(b)}
function Bi(){xi();return new wi}
function Pj(a,b){a.href=b;return a}
function ej(a,b){this.a=a;this.b=b}
function dc(a,b){this.a=a;this.b=b}
function lc(a,b){this.a=a;this.b=b}
function rh(a,b){this.a=a;this.b=b}
function Yh(a,b){this.a=a;this.b=b}
function Zk(a,b){this.a=a;this.b=b}
function vl(a,b){this.a=a;this.b=b}
function wl(a,b){this.a=a;this.b=b}
function xl(a,b){this.a=a;this.b=b}
function yl(a,b){this.a=a;this.b=b}
function bm(a,b){this.a=a;this.b=b}
function em(a,b){this.a=a;this.b=b}
function fm(a,b){this.a=a;this.b=b}
function Om(a,b){this.a=a;this.b=b}
function dn(a,b){this.a=a;this.b=b}
function an(a,b){this.b=a;this.a=b}
function xn(a,b){rh.call(this,a,b)}
function wk(a,b){rh.call(this,a,b)}
function oj(a,b,c){a.splice(b,0,c)}
function fj(a,b){a.A(im(gm(b.e),b))}
function Zj(a,b){a.value=b;return a}
function Dh(a,b){a.a+=''+b;return a}
function Oh(a){a.a=new si;a.b=new Gi}
function L(a){a.b=0;a.d=0;a.c=false}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function gm(a){return hm(new jm,a)}
function zo(a,b){return Kj(this.a,a)}
function Lh(a){return !a?null:a.Z()}
function Gb(a){return !a.d?a:Gb(a.d)}
function Mi(a){return a!=null?r(a):0}
function qd(a){return a==null?null:a}
function nd(a){return typeof a===Gn}
function Kc(a){$wnd.clearTimeout(a)}
function Ak(a){nc(a.c);gb(a.b);S(a.a)}
function Uk(a){nc(a.c);gb(a.a);W(a.b)}
function ym(a){zm(a,(bb(a.a),!a.g))}
function jc(a,b){hc(a,b,false);ab(a.d)}
function pj(a,b){nj(b,0,a,0,b.length)}
function Uj(a,b){a.onBlur=b;return a}
function Qj(a,b){a.onClick=b;return a}
function Vj(a,b){a.onChange=b;return a}
function Sj(a,b){a.checked=b;return a}
function Zh(a){a.a=$c(je,Jn,1,0,5,1)}
function Q(){this.a=$c(je,Jn,1,100,5,1)}
function eb(a){this.c=new gi;this.b=a}
function yj(){yj=Ug;vj=new o;xj=new o}
function A(a,b,c){t(a,new G(b),c,null)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function Ah(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function V(a){return !(!!a&&1==(a.c&7))}
function uj(a){return a.$H||(a.$H=++tj)}
function pd(a){return typeof a==='string'}
function po(){return T((rm(),om).b).a>0}
function cl(a,b){mn((rm(),qm),b);pl(a,b)}
function _i(a,b){Wi.call(this,a);this.a=b}
function uc(a){this.f=a;qc(this);this.F()}
function _m(a){this.c=Ni(a);this.a=new pc}
function mi(){this.a=new si;this.b=new Gi}
function Wj(a,b){a.onKeyDown=b;return a}
function Tj(a,b){a.defaultValue=b;return a}
function Rj(a){a.autoFocus=true;return a}
function fh(a){if(a.k!=null){return}oh(a)}
function rc(a,b){a.e=b;b!=null&&sj(b,Tn,a)}
function bb(a){var b;Hb((J(),b=Cb,b),a)}
function lb(a){J();kb(a);nb(a,2,true)}
function xm(a){nc(a.c);W(a.d);W(a.b);W(a.a)}
function Lm(a){return vh(T(a.e).a-T(a.a).a)}
function md(a){return typeof a==='boolean'}
function u(a,b){return new qb(Ni(a),null,b)}
function ui(a,b){var c;c=a[Yn];c.call(a,b)}
function sj(b,c,d){try{b[c]=d}catch(a){}}
function Ec(a,b,c){return a.apply(b,c);var d}
function ic(a,b){oc(b.B(),a);ld(b,11)&&b.u()}
function Ki(a,b){while(a.V()){lj(b,a.W())}}
function Ji(a,b,c){this.a=a;this.b=b;this.c=c}
function ul(a,b,c){this.a=a;this.b=b;this.c=c}
function $j(a,b){a.onDoubleClick=b;return a}
function $h(a,b){a.a[a.a.length]=b;return true}
function hm(a,b){Cj(a.a,'key',Ni(b));return a}
function qc(a){a.g&&a.e!==Sn&&a.F();return a}
function lh(){var a;a=ih(null);a.e=2;return a}
function jh(a){var b;b=ih(a);qh(a,b);return b}
function Kj(a,b){var c;c=a.kb(b);return c||a.k}
function Tk(a,b){var c;c=b.target;Vk(a,c.value)}
function Rb(a,b){a.i&&b.preventDefault();ac(a)}
function jb(a,b){Z(b,a);b.c.a.length>0||(b.a=4)}
function Qm(a,b){this.a=a;this.c=b;this.b=false}
function Pi(a,b){this.e=a;this.d=(b&64)!=0?b|Hn:b}
function Qi(a){if(!a.d){a.d=a.b.P();a.c=a.b.R()}}
function Ab(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function cj(a,b,c){if(a.a.cb(c)){a.b=true;b.A(c)}}
function ml(a,b){return dh(),jl(a,b)?true:false}
function Km(a){return dh(),0==T(a.e).a?true:false}
function Ci(a,b){return !(a.a.get(b)===undefined)}
function ad(a){return Array.isArray(a)&&a.vb===Yg}
function kd(a){return !Array.isArray(a)&&a.vb===Yg}
function P(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ci(a,b){var c;c=a.a[b];qj(a.a,b);return c}
function ei(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Th(a){var b;b=a.a.W();a.b=Sh(a);return b}
function ll(a){nc(a.e);gb(a.b);S(a.d);W(a.c);W(a.a)}
function Ui(a){if(!a.b){Vi(a);a.c=true}else{Ui(a.b)}}
function Zi(a){Vi(a);return new _i(a,new gj(a.a))}
function Qh(a,b){if(b){return Jh(a.a,b)}return false}
function Ni(a){if(a==null){throw Fg(new zh)}return a}
function Bj(){if(wj==256){vj=xj;xj=new o;wj=0}++wj}
function Uc(){Uc=Ug;var a;!Wc();a=new Xc;Tc=a}
function _g(){_g=Ug;$g=$wnd.window.document}
function xh(){xh=Ug;wh=$c(fe,Jn,33,256,0,1)}
function en(a){return Bh(ho,a)||Bh(eo,a)||Bh('',a)}
function li(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function Vk(a,b){var c;c=a.e;if(b!=c){a.e=b;ab(a.b)}}
function ql(a,b){var c;c=a.i;if(b!=c){a.i=b;ab(a.a)}}
function zm(a,b){var c;c=a.g;if(b!=c){a.g=b;ab(a.a)}}
function $b(a,b){var c;c=a.e;if(b!=c){a.e=Ni(b);ab(a.a)}}
function _b(a,b){var c;c=a.g;if(b!=c){a.g=Ni(b);ab(a.b)}}
function cb(a){var b;J();!!Cb&&!!Cb.e&&Hb((b=Cb,b),a)}
function xb(a){while(true){if(!vb(a)&&!wb(a)){break}}}
function Am(a,b){var c;c=a.i;if(b!=c){a.i=Ni(b);ab(a.b)}}
function kh(a,b){var c;c=ih(a);qh(a,c);c.e=b?8:0;return c}
function Yj(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Yi(a,b){Vi(a);return new _i(a,new dj(b,a.a))}
function Jj(a){Hj(a);return ld(a,11)&&a.v()?null:a.lb()}
function yn(){wn();return cd(Yc(tg,1),Jn,37,0,[tn,vn,un])}
function Kg(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function nh(a){if(a.N()){return null}var b=a.j;return Qg[b]}
function Wi(a){if(!a){this.b=null;new gi}else{this.b=a}}
function gj(a){Pi.call(this,a.ab(),a._()&-6);this.a=a}
function th(a){this.f=!a?null:sc(a,a.D());qc(this);this.F()}
function Nb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function Ri(a,b){this.b=a;this.a=(b&4096)==0?b|64|Hn:b}
function Kh(a,b){return b===a?'(this Map)':b==null?Vn:Xg(b)}
function sc(a,b){var c;c=gh(a.tb);return b==null?c:c+': '+b}
function bl(a,b){var c;if(T(a.d)){c=b.target;ql(a,c.value)}}
function yh(a,b){var c,d;for(d=a.P();d.V();){c=d.W();b.A(c)}}
function yb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],Ni(b))}
function Ok(a,b){if(13==b.keyCode){b.preventDefault();Rk(a)}}
function Db(a){if(a.e){2==(a.e.c&7)||nb(a.e,4,true);kb(a.e)}}
function Gj(a){if(!a.k){a.k=true;a.n||a.o.forceUpdate()}}
function hn(a){nc(a.g);gb(a.e);gb(a.a);S(a.b);S(a.c);W(a.d)}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Ym(a,b){var c;$i(Im(a.c),(c=new gi,c)).O(new Cn(b))}
function mh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.I(b))}
function el(a,b,c){27==c.which?ol(a,b):13==c.which&&fl(a,b)}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&Hn)?Hn:8192)|0,b)}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&Hn)?Hn:8192)|0,b)}
function Ob(a,b){Cb=new Nb(Cb,b);a.d=false;Db(Cb);return Cb}
function Wg(a){function b(){}
;b.prototype=a||{};return new b}
function Xj(a){a.placeholder='What needs to be done?';return a}
function Qb(a,b){a.j=b;Bh(b,(bb(a.a),a.e))&&_b(a,b);Sb(b);ac(a)}
function hb(a){var b;b=(J(),J(),I);yb(b.b,a);0!=(a.c&Pn)&&D(b)}
function oi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function pi(a,b){var c;return ni(b,oi(a,b==null?0:(c=r(b),c|0)))}
function Im(a){bb(a.d);return new _i(null,new Ri(new Wh(a.i),0))}
function Vi(a){if(a.b){Vi(a.b)}else if(a.c){throw Fg(new sh)}}
function ah(a,b,c,d){a.addEventListener(b,c,(dh(),d?true:false))}
function Sg(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function zk(){zk=Ug;var a;yk=(a=Vg(Nl.prototype.fb,Nl,[]),a)}
function Hk(){Hk=Ug;var a;Gk=(a=Vg(Pl.prototype.fb,Pl,[]),a)}
function Qk(){Qk=Ug;var a;Pk=(a=Vg(Rl.prototype.fb,Rl,[]),a)}
function il(){il=Ug;var a;hl=(a=Vg(Tl.prototype.fb,Tl,[]),a)}
function Cl(){Cl=Ug;var a;Bl=(a=Vg(Vl.prototype.fb,Vl,[]),a)}
function hi(a){Zh(this);pj(this.a,Ih(a,$c(je,Jn,1,Ph(a.a),5,1)))}
function ti(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function dj(a,b){Pi.call(this,b.ab(),b._()&-16449);this.a=a;this.c=b}
function Y(a,b){var c,d;$h(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function mn(a,b){var c;c=a.f;if(!(b==c||!!b&&um(b,c))){a.f=b;ab(a.d)}}
function kn(a){var b;b=(bb(a.d),a.f);!!b&&!!b&&b.f<0&&mn(a,null)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function bh(a,b,c,d){a.removeEventListener(b,c,(dh(),d?true:false))}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Si(a,b){!a.a?(a.a=new Fh(a.d)):Dh(a.a,a.b);Dh(a.a,b);return a}
function $i(a,b){var c;Ui(a);c=new jj;c.a=b;a.a.U(new mj(c));return c.a}
function Xi(a){var b;Ui(a);b=0;while(a.a.bb(new kj)){b=Gg(b,1)}return b}
function Nh(a,b){return pd(b)?b==null?ri(a.a,null):Fi(a.b,b):ri(a.a,b)}
function vo(){return gn((rm(),qm))==(cb(this.c),this.o.props['a'])}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Jl(a){return $wnd.React.createElement((zk(),yk),a.a,undefined)}
function Ll(a){return $wnd.React.createElement((Hk(),Gk),a.a,undefined)}
function Zl(a){return $wnd.React.createElement((Qk(),Pk),a.a,undefined)}
function lm(a){return $wnd.React.createElement((Cl(),Bl),a.a,undefined)}
function fn(a,b){return (wn(),un)==a||(tn==a?(bb(b.a),!b.g):(bb(b.a),b.g))}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function N(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Hi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Uh(a){this.d=a;this.c=new Hi(this.d.b);this.a=this.c;this.b=Sh(this)}
function Ti(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function _h(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.A(c)}}
function Xm(a){var b;$i(Yi(Im(a.c),new An),(b=new gi,b)).O(new Bn(a.c))}
function jn(a){var b,c;return b=T(a.b),$i(Yi(Im(a.k),new Dn(b)),(c=new gi,c))}
function rm(){rm=Ug;nm=new bc;om=new Mm;pm=new _m(om);qm=new nn(om,nm)}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function Lj(a){var b;a.k=false;if(a.hb()){return null}else{b=a.eb();return b}}
function di(a,b){var c;c=bi(a,b,0);if(c==-1){return false}qj(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function bi(a,b,c){for(;c<a.a.length;++c){if(li(b,a.a[c])){return c}}return -1}
function Ii(a){if(a.a.c!=a.c){return Di(a.a,a.b.value[0])}return a.b.value[1]}
function tm(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Dm(a)),On,null)}}
function W(a){if(-2!=a.e){t((J(),J(),I),new G(new fb(a)),0,null);!!a.b&&gb(a.b)}}
function S(a){if(!a.a){a.a=true;a.g=null;a.b=null;W(a.d);2==(a.e.c&7)||gb(a.e)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{xb(a.b)}finally{a.c=false}}}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Mh(a,b,c){return pd(b)?b==null?qi(a.a,null,c):Ei(a.b,b,c):qi(a.a,b,c)}
function rj(a,b){return Zc(b)!=10&&cd(q(b),b.ub,b.__elementTypeId$,Zc(b),a),a}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===Fn||typeof a==='function')&&!(a.vb===Yg)}
function nl(a){return dh(),gn((rm(),qm))==(cb(a.c),a.o.props['a'])?true:false}
function Nk(a){var b;b=Ch((bb(a.b),a.e));if(b.length>0){Um((rm(),pm),b);Vk(a,'')}}
function vb(a){var b;if(0==P(a.c)){return false}else{b=O(a.c);!!b&&b.u();return true}}
function qh(a,b){var c;if(!a){return}b.j=a;var d=nh(b);if(!d){Qg[a]=[b];return}d.tb=b}
function Eg(a){var b;if(ld(a,4)){return a}b=a&&a[Tn];if(!b){b=new yc(a);Vc(b)}return b}
function Vg(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ih(a){var b;b=new hh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Jb(a,b){var c;if(!a.c){c=Gb(a);!c.c&&(c.c=new gi);a.c=c.c}b.d=true;$h(a.c,Ni(b))}
function Hb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;$h((!a.b&&(a.b=new gi),a.b),b)}}}
function Ij(a){var b;b=(++a.jb().e,new Bb);try{a.n=true;ld(a,11)&&a.u()}finally{Ab(b)}}
function Pb(){var a;try{Eb(Cb);J()}finally{a=Cb.d;!a&&((J(),J(),I).d=true);Cb=Cb.d}}
function Xb(a){bh((_g(),$wnd.window.window),Rn,a.f,false);nc(a.c);W(a.b);W(a.a)}
function Jm(a){yh(new Wh(a.i),new kc(a));Oh(a.i);nc(a.f);S(a.c);S(a.e);S(a.a);S(a.b);W(a.d)}
function kb(a){var b,c;for(c=new ii(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function ji(a){var b,c,d;d=0;for(c=new Uh(a.a);c.b;){b=Th(c);d=d+(b?r(b):0);d=d|0}return d}
function Hh(a,b){var c,d;for(d=new Uh(b.a);d.b;){c=Th(d);if(!Qh(a,c)){return false}}return true}
function Fi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{ui(a.a,b);--a.b}return c}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);N(a,Ni(b))}
function hc(a,b,c){var d;d=Nh(a.i,b?vh(b.e):null);if(null!=d){oc(b.c,a);c&&!!b&&tm(b);ab(a.d)}}
function Fm(a,b,c){var d;d=new Cm(b,c);mc(d.c,a,new lc(a,d));Mh(a.i,vh(d.e),d);ab(a.d);return d}
function im(a,b){Cj(a.a,(il(),'a'),b);return $wnd.React.createElement(hl,a.a,undefined)}
function sh(){uc.call(this,"Stream already terminated, can't be modified or used")}
function Mg(){Ng();var a=Lg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function wn(){wn=Ug;tn=new xn('ACTIVE',0);vn=new xn('COMPLETED',1);un=new xn('ALL',2)}
function Zg(){rm();$wnd.ReactDOM.render(lm(new mm),(_g(),$g).getElementById('todoapp'),null)}
function Dj(a){$wnd.React.Component.call(this,a);this.a=this.gb();this.a.o=Ni(this);this.a.db()}
function Sh(a){if(a.a.V()){return true}if(a.a!=a.c){return false}a.a=new ti(a.d.a);return a.a.V()}
function Hg(a){var b;b=a.h;if(b==0){return a.l+a.m*Pn}if(b==1048575){return a.l+a.m*Pn-Wn}return a}
function jl(a,b){var c;c=false;if(!li(a.o.props['a'],null==b?null:b['a'])){ab(a.c);c=true}return c}
function Ei(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Z(a,b){var c,d;d=a.c;di(d,b);d.a.length==0&&!!a.b&&Ln!=(a.b.c&Mn)&&(a.d||Jb((J(),c=Cb,c),a))}
function ln(a){var b;b=Vb(a.j);Bh(ho,b)||Bh(eo,b)||Bh('',b)?Ub(a.j,b):en(Wb(a.j))?Zb(a.j):Ub(a.j,'')}
function gb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new tb(a)),On,null);!!a.a&&S(a.a);a.c=a.c&-8|1}}
function El(){Cl();++Ej;this.b=new pc;this.a=new qb(null,Ni((J(),new Fl(this))),_n);D((null,I))}
function Jk(){Hk();++Ej;this.b=new pc;this.a=new qb(null,Ni((J(),new Kk(this))),_n);D((null,I))}
function hh(){this.g=eh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function yc(a){wc();qc(this);this.e=a;a!=null&&sj(a,Tn,this);this.f=a==null?Vn:Xg(a);this.a='';this.b=a;this.a=''}
function Hj(a){if(!Fj){Fj=(++a.jb().e,new Bb);$wnd.Promise.resolve(null).then(Vg(Mj.prototype.H,Mj,[]))}}
function Jg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Wn;d=1048575}c=rd(e/Pn);b=rd(e-c*Pn);return dd(b,c,d)}
function ni(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(li(a,c.Y())){return c}}return null}
function um(a,b){var c;if(a===b){return true}else if(null==b||!ld(b,50)){return false}else{c=b;return a.e==c.e}}
function T(a){bb(a.d);ob(a.e)&&ib(a.e);if(a.b){if(ld(a.b,6)){throw Fg(a.b)}else{throw Fg(a.b)}}return a.g}
function cd(a,b,c,d,e){e.tb=a;e.ub=b;e.vb=Yg;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Pg(a,b){typeof window===Fn&&typeof window['$gwt']===Fn&&(window['$gwt'][a]=b)}
function q(a){return pd(a)?me:nd(a)?be:md(a)?_d:kd(a)?a.tb:ad(a)?a.tb:a.tb||Array.isArray(a)&&Yc(Ud,1)||Ud}
function r(a){return pd(a)?Aj(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.r():ad(a)?uj(a):!!a&&!!a.hashCode?a.hashCode():uj(a)}
function vh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(xh(),wh)[b];!c&&(c=wh[b]=new uh(a));return c}return new uh(a)}
function Xg(a){var b;if(Array.isArray(a)&&a.vb===Yg){return gh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Aj(a){yj();var b,c,d;c=':'+a;d=xj[c];if(d!=null){return rd(d)}d=vj[c];b=d==null?zj(a):rd(d);Bj();xj[c]=b;return b}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function fl(a,b){var c;c=(bb(a.a),a.i);if(null!=c&&c.length!=0){Zm((rm(),b),c);mn(qm,null);ql(a,c)}else{Hm((rm(),om),b)}}
function Tb(a){var b,c;c=(b=(_g(),$wnd.window.window).location.hash,null==b?'':b.substr(1));$b(a,c);Bh(a.j,c)&&_b(a,c)}
function nc(a){var b,c;if(!a.a){for(c=new ii(new hi(new Wh(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.w()}a.a=true}}
function ki(a){var b,c,d;d=1;for(c=new ii(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function ph(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function xk(){vk();return cd(Yc(af,1),Jn,9,0,[_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk])}
function Bk(){zk();++Ej;this.c=new pc;this.a=new U((J(),new Ck),136486912);this.b=new qb(null,Ni(new Ek(this)),_n);D((null,I))}
function Wk(){Qk();var a;++Ej;this.c=new pc;this.b=(a=new eb((J(),null)),a);this.a=new qb(null,Ni(new $k(this)),_n);D((null,I))}
function U(a,b){this.c=Ni(a);this.f=null;this.g=null;this.e=new rb(this,b);this.d=new eb(this.e);Ln==(b&Mn)&&hb(this.e)}
function pb(a,b,c,d){this.b=new gi;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&hb(this)}
function zb(){this.c=new Q;this.d=$c(vd,Jn,22,5,0,1);this.d[0]=new Q;this.d[1]=new Q;this.d[2]=new Q;this.d[3]=new Q;this.d[4]=new Q}
function Gg(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<Wn){return c}}return Hg(ed(nd(a)?Jg(a):a,nd(b)?Jg(b):b))}
function p(a,b){return pd(a)?Bh(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.p(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function al(a){var b;b=T(a.d);if(!a.j&&b){a.j=true;pl(a,(cb(a.c),a.o.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function fi(a,b){var c,d;d=a.a.length;b.length<d&&(b=rj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function O(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Nj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.ub){return !!a.ub[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function qb(a,b,c){pb.call(this,null,a,b,c|(!a?262144:Ln)|(a?Hn:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:Pn)|(0!=(c&229376)?0:98304)|0|0|0)}
function Mb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ii(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&nb(b,5,true)}}}
function Lb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ii(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&nb(b,6,true)}}}
function Kb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ii(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?nb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Ch(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ib(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=ci(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&nb(c.b,3,true);++b}}}return b}
function Cm(a,b){var c,d,e;this.i=Ni(a);this.g=b;this.e=sm++;this.d=(d=new eb((J(),null)),d);this.c=new pc;this.b=(e=new eb(null),e);this.a=(c=new eb(null),c)}
function Rk(b){var c;try{A((J(),J(),I),new Yk(b),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function Bm(b){var c;try{A((J(),J(),I),new Em(b),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function Wm(b){var c;try{A((J(),J(),I),new bn(b),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function Zm(b,c){var d;try{A((J(),J(),I),new an(b,c),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function $m(b,c){var d;try{A((J(),J(),I),new dn(b,c),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Hm(b,c){var d;try{A((J(),J(),I),new Om(b,c),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Sk(b,c){var d;try{A((J(),J(),I),new Zk(b,c),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function kl(b,c){var d;try{A((J(),J(),I),new yl(b,c),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function ol(b,c){var d;try{A((J(),J(),I),new xl(b,c),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function pl(b,c){var d;try{A((J(),J(),I),new wl(b,c),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Ub(b,c){var d;try{A((J(),J(),I),new dc(b,c),75497472)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Zb(b){var c;try{A((J(),J(),I),new ec(b),142606336)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function ac(b){var c;try{A((J(),J(),I),new fc(b),142606336)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function Gm(b,c){var d;try{return t((J(),J(),I),new Qm(b,c),co,null)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Og(b,c,d,e){Ng();var f=Lg;$moduleName=c;$moduleBase=d;Dg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{En(g)()}catch(a){b(c,a)}}else{En(g)()}}
function rb(a,b){pb.call(this,a,new sb(a),null,b|(Ln==(b&Mn)?0:524288)|(0!=(b&6291456)?0:Ln==(b&Mn)?Pn:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function zi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ai()}}
function Ih(a,b){var c,d,e,f,g;g=Ph(a.a);b.length<g&&(b=rj(new Array(g),b));e=(f=new Uh((new Rh(a.a)).a),new Xh(f));for(d=0;d<g;++d){b[d]=(c=Th(e.a),c.Z())}b.length>g&&(b[g]=null);return b}
function Rg(){Qg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].wb()&&(c=Rc(c,g)):g[0].wb()}catch(a){a=Eg(a);if(ld(a,4)){d=a;Dc();Jc(ld(d,40)?d.G():d)}else throw Fg(a)}}return c}
function rl(){il();var a,b;++Ej;this.e=new pc;this.c=(b=new eb((J(),null)),b);this.a=(a=new eb(null),a);this.d=new U(new zl(this),136486912);this.b=new qb(null,Ni(new Al(this)),_n);D((null,I))}
function Mm(){var a;this.i=new mi;this.f=new pc;this.d=(a=new eb((J(),null)),a);this.c=new U(new Pm(this),go);this.e=new U(new Rm(this),go);this.a=new U(new Sm(this),go);this.b=new U(new Tm(this),go)}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?Vn:od(b)?b==null?null:b.name:pd(b)?'String':gh(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.g;try{d=b.c.t();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;$(b.d)}}catch(a){a=Eg(a);if(ld(a,12)){c=a;if(!b.b){b.g=null;b.b=c;$(b.d)}throw Fg(c)}else throw Fg(a)}}
function qi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=ni(b,e);if(f){return f.$(c)}}e[e.length]=new Yh(b,c);++a.b;return null}
function nj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function zj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ah(a,c++)}b=b|0;return b}
function M(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=$c(je,Jn,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=Hn==(d&Hn)?c.t():c.t()}else{Ob(b,e);try{g=Hn==(d&Hn)?c.t():c.t()}finally{Pb()}}return g}catch(a){a=Eg(a);if(ld(a,4)){f=a;throw Fg(f)}else throw Fg(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=Hn==(d&Hn)?(c.a.w(),null):(c.a.w(),null)}else{Ob(b,e);try{g=Hn==(d&Hn)?(c.a.w(),null):(c.a.w(),null)}finally{Pb()}}return g}catch(a){a=Eg(a);if(ld(a,4)){f=a;throw Fg(f)}else throw Fg(a)}finally{D(b)}}
function Sb(a){var b;if(0==a.length){b=(_g(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',$g.title,b)}else{(_g(),$wnd.window.window).location.hash=a}}
function ib(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.w()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=Eg(a);if(ld(a,4)){J()}else throw Fg(a)}}}
function ri(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(li(b,e.Y())){if(d.length==1){d.length=0;ui(a.a,g)}else{d.splice(h,1)}--a.b;return e.Z()}}return null}
function nn(a,b){var c;this.k=Ni(a);this.j=Ni(b);this.g=new pc;this.d=(c=new eb((J(),null)),c);this.b=new U(new pn(this),go);this.c=new U(new qn(this),go);this.e=u(new rn(this),413155328);this.a=u(new sn(this),681590784);D((null,I))}
function Tg(a,b,c){var d=Qg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Qg[b]),Wg(h));_.ub=c;!b&&(_.vb=Yg);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.tb=f)}
function oh(a){if(a.M()){var b=a.c;b.N()?(a.k='['+b.j):!b.M()?(a.k='[L'+b.K()+';'):(a.k='['+b.K());a.b=b.J()+'[]';a.i=b.L()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=ph('.',[c,ph('$',d)]);a.b=ph('.',[c,ph('.',d)]);a.i=d[d.length-1]}
function bc(){var a,b,c;this.f=new gc(this);this.c=new pc;this.b=(c=new eb((J(),null)),c);this.a=(b=new eb(null),b);ah((_g(),$wnd.window.window),Rn,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function Jh(a,b){var c,d,e;c=b.Y();e=b.Z();d=pd(c)?c==null?Lh(pi(a.a,null)):Di(a.b,c):Lh(pi(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!pi(a.a,null):Ci(a.b,c):!!pi(a.a,c))){return false}return true}
function ob(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ii(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Eg(a);if(!ld(a,4))throw Fg(a)}if(6==(b.c&7)){return true}}}}}kb(b);return false}
function yi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function nb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){db(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}_h(a.b,new ub(a));a.b.a=$c(je,Jn,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function wb(a){var b,c,d,e,f,g,h,i;d=P(a.d[0]);c=P(a.d[1]);g=P(a.d[2]);e=P(a.d[3]);f=P(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;L(a.d[0]);L(a.d[1]);L(a.d[2]);L(a.d[3]);L(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=O(b);h.c&=-513;ib(h);return true}
function vk(){vk=Ug;_j=new wk(Zn,0);ak=new wk('checkbox',1);bk=new wk('color',2);ck=new wk('date',3);dk=new wk('datetime',4);ek=new wk('email',5);fk=new wk('file',6);gk=new wk('hidden',7);hk=new wk('image',8);ik=new wk('month',9);jk=new wk(Gn,10);kk=new wk('password',11);lk=new wk('radio',12);mk=new wk('range',13);nk=new wk('reset',14);ok=new wk('search',15);pk=new wk('submit',16);qk=new wk('tel',17);rk=new wk('text',18);sk=new wk('time',19);tk=new wk('url',20);uk=new wk('week',21)}
function Fb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ai(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ei(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Z(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&nb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ai(a.b,g);if(-1==k.e){k.e=0;Y(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ci(a.b,g)}e&&mb(a.e,a.b)}else{e&&mb(a.e,new gi)}if(V(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&Ln!=(b.e.c&Mn)&&Jb(a,k)}}
function Ai(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Yn]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!yi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Yn]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Fn='object',Gn='number',Hn=16384,In={15:1},Jn={3:1,5:1},Kn={11:1},Ln=1048576,Mn=1835008,Nn={8:1},On=67108864,Pn=4194304,Qn={30:1},Rn='hashchange',Sn='__noinit__',Tn='__java$exception',Un={3:1,12:1,6:1,4:1},Vn='null',Wn=17592186044416,Xn={44:1},Yn='delete',Zn='button',$n='selected',_n=1478631424,ao={11:1,24:1},bo='input',co=142614528,eo='completed',fo='header',go=136323072,ho='active';var _,Qg,Lg,Dg=-1;Rg();Tg(1,null,{},o);_.p=jo;_.q=function(){return this.tb};_.r=ko;_.s=function(){var a;return gh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.p(a)};_.hashCode=function(){return this.r()};_.toString=function(){return this.s()};var fd,gd,hd;Tg(52,1,{},hh);_.I=function(a){var b;b=new hh;b.e=4;a>1?(b.c=mh(this,a-1)):(b.c=this);return b};_.J=function(){fh(this);return this.b};_.K=function(){return gh(this)};_.L=function(){fh(this);return this.i};_.M=function(){return (this.e&4)!=0};_.N=function(){return (this.e&1)!=0};_.s=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(fh(this),this.k)};_.e=0;_.g=0;var eh=1;var je=jh(1);var ae=jh(52);Tg(76,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var ud=jh(76);Tg(16,1,In,G);_.t=function(){return this.a.w(),null};var sd=jh(16);Tg(77,1,{},H);var td=jh(77);var I;Tg(22,1,{22:1},Q);_.b=0;_.c=false;_.d=0;var vd=jh(22);Tg(202,1,Kn);_.s=function(){var a;return gh(this.tb)+'@'+(a=r(this)>>>0,a.toString(16))};var xd=jh(202);Tg(21,202,Kn,U);_.u=function(){S(this)};_.v=io;_.a=false;var wd=jh(21);Tg(17,202,{11:1,17:1},eb);_.u=function(){W(this)};_.v=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=jh(17);Tg(116,1,Nn,fb);_.w=function(){X(this.a)};var yd=jh(116);Tg(19,202,{11:1,19:1},qb,rb);_.u=function(){gb(this)};_.v=function(){return 1==(this.c&7)};_.c=0;var Dd=jh(19);Tg(117,1,Qn,sb);_.w=function(){R(this.a)};var Ad=jh(117);Tg(118,1,Nn,tb);_.w=function(){lb(this.a)};var Bd=jh(118);Tg(119,1,{},ub);_.A=function(a){jb(this.a,a)};var Cd=jh(119);Tg(121,1,{},zb);_.a=0;_.b=100;_.e=0;var Ed=jh(121);Tg(62,1,Kn,Bb);_.u=function(){Ab(this)};_.v=io;_.a=false;var Fd=jh(62);Tg(135,1,{},Nb);_.s=function(){var a;return fh(Gd),Gd.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.a=0;var Cb;var Gd=jh(135);Tg(46,1,{46:1});_.e='';_.g='';_.i=true;_.j='';var Nd=jh(46);Tg(101,46,{11:1,46:1,24:1},bc);_.u=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new cc(this)),On,null)}};_.p=jo;_.B=qo;_.r=ko;_.v=ro;_.s=function(){var a;return fh(Ld),Ld.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.d=0;var Ld=jh(101);Tg(102,1,Nn,cc);_.w=function(){Xb(this.a)};var Hd=jh(102);Tg(103,1,Nn,dc);_.w=function(){Qb(this.a,this.b)};var Id=jh(103);Tg(104,1,Nn,ec);_.w=function(){Yb(this.a)};var Jd=jh(104);Tg(105,1,Nn,fc);_.w=function(){Tb(this.a)};var Kd=jh(105);Tg(78,1,{},gc);_.handleEvent=function(a){Rb(this.a,a)};var Md=jh(78);Tg(106,1,{});var Qd=jh(106);Tg(79,1,{},kc);_.A=function(a){ic(this.a,a)};var Od=jh(79);Tg(80,1,Nn,lc);_.w=function(){jc(this.a,this.b)};var Pd=jh(80);Tg(107,106,{});var Rd=jh(107);Tg(18,1,Kn,pc);_.u=function(){nc(this)};_.v=io;_.a=false;var Sd=jh(18);Tg(4,1,{3:1,4:1});_.C=function(a){return new Error(a)};_.D=Bo;_.F=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=gh(this.tb),c==null?a:a+': '+c);rc(this,tc(this.C(b)));Vc(this)};_.s=function(){return sc(this,this.D())};_.e=Sn;_.g=true;var ne=jh(4);Tg(12,4,{3:1,12:1,4:1});var de=jh(12);Tg(6,12,Un);var ke=jh(6);Tg(53,6,Un);var ge=jh(53);Tg(71,53,Un);var Wd=jh(71);Tg(40,71,{40:1,3:1,12:1,6:1,4:1},yc);_.D=function(){xc(this);return this.c};_.G=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Td=jh(40);var Ud=jh(0);Tg(188,1,{});var Vd=jh(188);var Ac=0,Bc=0,Cc=-1;Tg(100,188,{},Qc);var Mc;var Xd=jh(100);var Tc;Tg(199,1,{});var Zd=jh(199);Tg(72,199,{},Xc);var Yd=jh(72);var $g;Tg(69,1,{66:1});_.s=io;var $d=jh(69);fd={3:1,67:1,32:1};var _d=jh(67);Tg(45,1,{3:1,45:1});var ie=jh(45);gd={3:1,32:1,45:1};var be=jh(198);Tg(36,1,{3:1,32:1,36:1});_.p=jo;_.r=ko;_.s=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ce=jh(36);Tg(10,6,Un,sh,th);var ee=jh(10);Tg(33,45,{3:1,32:1,33:1,45:1},uh);_.p=function(a){return ld(a,33)&&a.a==this.a};_.r=io;_.s=function(){return ''+this.a};_.a=0;var fe=jh(33);var wh;Tg(256,1,{});Tg(74,53,Un,zh);_.C=function(a){return new TypeError(a)};var he=jh(74);hd={3:1,66:1,32:1,2:1};var me=jh(2);Tg(70,69,{66:1},Fh);var le=jh(70);Tg(260,1,{});Tg(55,6,Un,Gh);var oe=jh(55);Tg(200,1,{43:1});_.O=oo;_.S=function(){return new Ri(this,0)};_.T=function(){return new _i(null,this.S())};_.Q=function(a){throw Fg(new Gh('Add not supported on this collection'))};_.s=function(){var a,b,c;c=new Ti('[',']');for(b=this.P();b.V();){a=b.W();Si(c,a===this?'(this Collection)':a==null?Vn:Xg(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=jh(200);Tg(203,1,{186:1});_.p=function(a){var b,c,d;if(a===this){return true}if(!ld(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Uh((new Rh(d)).a);c.b;){b=Th(c);if(!Jh(this,b)){return false}}return true};_.r=function(){return ji(new Rh(this))};_.s=function(){var a,b,c;c=new Ti('{','}');for(b=new Uh((new Rh(this)).a);b.b;){a=Th(b);Si(c,Kh(this,a.Y())+'='+Kh(this,a.Z()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=jh(203);Tg(122,203,{186:1});var se=jh(122);Tg(204,200,{43:1,210:1});_.S=function(){return new Ri(this,1)};_.p=function(a){var b;if(a===this){return true}if(!ld(a,27)){return false}b=a;if(Ph(b.a)!=this.R()){return false}return Hh(this,b)};_.r=function(){return ji(this)};var Be=jh(204);Tg(27,204,{27:1,43:1,210:1},Rh);_.P=function(){return new Uh(this.a)};_.R=mo;var re=jh(27);Tg(28,1,{},Uh);_.U=lo;_.W=function(){return Th(this)};_.V=no;_.b=false;var qe=jh(28);Tg(201,200,{43:1,208:1});_.S=function(){return new Ri(this,16)};_.X=function(a,b){throw Fg(new Gh('Add not supported on this list'))};_.Q=function(a){this.X(this.R(),a);return true};_.p=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.R()!=f.a.length){return false}e=new ii(f);for(c=new ii(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.r=function(){return ki(this)};_.P=function(){return new Vh(this)};var ue=jh(201);Tg(98,1,{},Vh);_.U=lo;_.V=function(){return this.a<this.b.a.length};_.W=function(){return ai(this.b,this.a++)};_.a=0;var te=jh(98);Tg(48,200,{43:1},Wh);_.P=function(){var a;return a=new Uh((new Rh(this.a)).a),new Xh(a)};_.R=mo;var we=jh(48);Tg(57,1,{},Xh);_.U=lo;_.V=function(){return this.a.b};_.W=function(){var a;return a=Th(this.a),a.Z()};var ve=jh(57);Tg(123,1,Xn);_.p=function(a){var b;if(!ld(a,44)){return false}b=a;return li(this.a,b.Y())&&li(this.b,b.Z())};_.Y=io;_.Z=no;_.r=function(){return Mi(this.a)^Mi(this.b)};_.$=function(a){var b;b=this.b;this.b=a;return b};_.s=function(){return this.a+'='+this.b};var xe=jh(123);Tg(124,123,Xn,Yh);var ye=jh(124);Tg(205,1,Xn);_.p=function(a){var b;if(!ld(a,44)){return false}b=a;return li(this.b.value[0],b.Y())&&li(Ii(this),b.Z())};_.r=function(){return Mi(this.b.value[0])^Mi(Ii(this))};_.s=function(){return this.b.value[0]+'='+Ii(this)};var ze=jh(205);Tg(14,201,{3:1,14:1,43:1,208:1},gi,hi);_.X=function(a,b){oj(this.a,a,b)};_.Q=function(a){return $h(this,a)};_.O=function(a){_h(this,a)};_.P=function(){return new ii(this)};_.R=function(){return this.a.length};var De=jh(14);Tg(20,1,{},ii);_.U=lo;_.V=function(){return this.a<this.c.a.length};_.W=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=jh(20);Tg(41,122,{3:1,41:1,186:1},mi);var Ee=jh(41);Tg(60,1,{},si);_.O=oo;_.P=function(){return new ti(this)};_.b=0;var Ge=jh(60);Tg(61,1,{},ti);_.U=lo;_.W=function(){return this.d=this.a[this.c++],this.d};_.V=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=jh(61);var wi;Tg(58,1,{},Gi);_.O=oo;_.P=function(){return new Hi(this)};_.b=0;_.c=0;var Je=jh(58);Tg(59,1,{},Hi);_.U=lo;_.W=function(){return this.c=this.a,this.a=this.b.next(),new Ji(this.d,this.c,this.d.c)};_.V=function(){return !this.a.done};var He=jh(59);Tg(134,205,Xn,Ji);_.Y=function(){return this.b.value[0]};_.Z=function(){return Ii(this)};_.$=function(a){return Ei(this.a,this.b.value[0],a)};_.c=0;var Ie=jh(134);Tg(99,1,{});_.U=function(a){Oi(this,a)};_._=function(){return this.d};_.ab=wo;_.d=0;_.e=0;var Le=jh(99);Tg(56,99,{});var Ke=jh(56);Tg(26,1,{},Ri);_._=io;_.ab=function(){Qi(this);return this.c};_.U=function(a){Qi(this);this.d.U(a)};_.bb=function(a){Qi(this);if(this.d.V()){a.A(this.d.W());return true}return false};_.a=0;_.c=0;var Me=jh(26);Tg(54,1,{},Ti);_.s=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ne=jh(54);var We=lh();Tg(125,1,{});_.c=false;var Xe=jh(125);Tg(35,125,{},_i);var Ve=jh(35);Tg(127,56,{},dj);_.bb=function(a){this.b=false;while(!this.b&&this.c.bb(new ej(this,a)));return this.b};_.b=false;var Pe=jh(127);Tg(130,1,{},ej);_.A=function(a){cj(this.a,this.b,a)};var Oe=jh(130);Tg(126,56,{},gj);_.bb=function(a){return this.a.bb(new hj(a))};var Re=jh(126);Tg(129,1,{},hj);_.A=function(a){fj(this.a,a)};var Qe=jh(129);Tg(128,1,{},jj);_.A=function(a){ij(this,a)};var Se=jh(128);Tg(131,1,{},kj);_.A=function(a){};var Te=jh(131);Tg(132,1,{},mj);_.A=function(a){lj(this,a)};var Ue=jh(132);Tg(258,1,{});Tg(207,1,{});var Ye=jh(207);Tg(255,1,{});var tj=0;var vj,wj=0,xj;Tg(682,1,{});Tg(708,1,{});Tg(206,1,{});_.db=function(){};var Ze=jh(206);Tg(34,$wnd.React.Component,{});Sg(Qg[1],_);_.render=function(){return Jj(this.a)};var $e=jh(34);Tg(38,206,{});_.hb=function(){return false};_.ib=function(a,b){};_.kb=function(a){return false};_.lb=function(){return Lj(this)};_.k=false;_.n=false;var Ej=1,Fj;var _e=jh(38);Tg(227,$wnd.Function,{},Mj);_.H=function(a){return Ab(Fj),Fj=null,null};Tg(9,36,{3:1,32:1,36:1,9:1},wk);var _j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk;var af=kh(9,xk);Tg(156,38,{});_.qb=po;_.eb=function(){var a;a=T((rm(),qm).b);return $wnd.React.createElement('footer',Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,['footer'])),Ll(new Ml),$wnd.React.createElement('ul',Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Pj(Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,[(wn(),un)==a?$n:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Pj(Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,[tn==a?$n:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Pj(Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,[vn==a?$n:null])),'#completed'),'Completed'))),this.qb()?$wnd.React.createElement(Zn,Qj(Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,['clear-completed'])),Vg(Il.prototype.pb,Il,[])),'Clear Completed'):null)};var If=jh(156);Tg(157,156,{});_.qb=po;var yk;var Mf=jh(157);Tg(158,157,ao,Bk);_.u=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Fk(this)),On,null)}};_.p=jo;_.jb=so;_.B=qo;_.qb=function(){return T(this.a)};_.r=ko;_.v=ro;_.s=function(){var a;return fh(kf),kf.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.lb=function(){var b;try{return B((J(),J(),I),this.b,new Dk(this))}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.d=0;var kf=jh(158);Tg(159,1,In,Ck);_.t=function(){return dh(),T((rm(),om).b).a>0?true:false};var bf=jh(159);Tg(162,1,In,Dk);_.t=uo;var cf=jh(162);Tg(160,1,Qn,Ek);_.w=to;var df=jh(160);Tg(161,1,Nn,Fk);_.w=function(){Ak(this.a)};var ef=jh(161);Tg(179,38,{});_.eb=function(){var a,b;b=T((rm(),om).e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,['todo-count'])),$wnd.React.createElement('strong',null,''+b),' '+a+' left')};var Hf=jh(179);Tg(180,179,{});var Gk;var Lf=jh(180);Tg(181,180,ao,Jk);_.u=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Lk(this)),On,null)}};_.p=jo;_.jb=so;_.B=no;_.r=ko;_.v=xo;_.s=function(){var a;return fh(jf),jf.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.lb=function(){var b;try{return B((J(),J(),I),this.a,new Mk(this))}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.c=0;var jf=jh(181);Tg(182,1,Qn,Kk);_.w=to;var ff=jh(182);Tg(183,1,Nn,Lk);_.w=function(){Ik(this.a)};var gf=jh(183);Tg(184,1,In,Mk);_.t=uo;var hf=jh(184);Tg(148,38,{});_.eb=function(){return $wnd.React.createElement(bo,Rj(Vj(Wj(Zj(Xj(Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,['new-todo']))),(bb(this.b),this.e)),Vg(Xl.prototype.ob,Xl,[this])),Vg(Yl.prototype.nb,Yl,[this]))))};_.e='';var Uf=jh(148);Tg(149,148,{});var Pk;var Of=jh(149);Tg(150,149,ao,Wk);_.u=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new _k(this)),On,null)}};_.p=jo;_.jb=so;_.B=qo;_.r=ko;_.v=ro;_.s=function(){var a;return fh(qf),qf.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.lb=function(){var b;try{return B((J(),J(),I),this.a,new Xk(this))}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.d=0;var qf=jh(150);Tg(153,1,In,Xk);_.t=uo;var lf=jh(153);Tg(154,1,Nn,Yk);_.w=function(){Nk(this.a)};var mf=jh(154);Tg(155,1,Nn,Zk);_.w=function(){Tk(this.a,this.b)};var nf=jh(155);Tg(151,1,Qn,$k);_.w=to;var of=jh(151);Tg(152,1,Nn,_k);_.w=function(){Uk(this.a)};var pf=jh(152);Tg(165,38,{});_.ib=function(a,b){al(this)};_.sb=vo;_.db=function(){pl(this,this.rb())};_.eb=function(){var a,b;b=this.rb();a=(bb(b.a),b.g);return $wnd.React.createElement('li',Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,[a?eo:null,this.sb()?'editing':null])),$wnd.React.createElement('div',Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,['view'])),$wnd.React.createElement(bo,Vj(Sj(Yj(Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,['toggle'])),(vk(),ak)),a),Vg(am.prototype.nb,am,[b]))),$wnd.React.createElement('label',$j(new $wnd.Object,Vg(bm.prototype.pb,bm,[this,b])),(bb(b.b),b.i)),$wnd.React.createElement(Zn,Qj(Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,['destroy'])),Vg(cm.prototype.pb,cm,[b])))),$wnd.React.createElement(bo,Wj(Vj(Uj(Tj(Nj(Oj(new $wnd.Object,Vg(dm.prototype.A,dm,[this])),cd(Yc(me,1),Jn,2,6,['edit'])),(bb(this.a),this.i)),Vg(em.prototype.mb,em,[this,b])),Vg(_l.prototype.nb,_l,[this])),Vg(fm.prototype.ob,fm,[this,b]))))};_.j=false;var Wf=jh(165);Tg(166,165,{});_.hb=function(){var a;a=(cb(this.c),this.o.props['a']);if(!!a&&a.f<0){return true}return false};_.rb=function(){return this.o.props['a']};_.sb=vo;_.kb=function(a){return jl(this,a)};var hl;var Qf=jh(166);Tg(167,166,ao,rl);_.ib=function(b,c){var d;try{A((J(),J(),I),new ul(this,b,c),co)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}};_.u=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new sl(this)),On,null)}};_.p=jo;_.jb=so;_.B=wo;_.rb=function(){return cb(this.c),this.o.props['a']};_.r=ko;_.v=Ao;_.sb=function(){return T(this.d)};_.kb=function(b){var c;try{return t((J(),J(),I),new vl(this,b),75505664,null)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}};_.s=function(){var a;return fh(Af),Af.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.lb=function(){var b;try{return B((J(),J(),I),this.b,new tl(this))}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.f=0;var Af=jh(167);Tg(170,1,Nn,sl);_.w=function(){ll(this.a)};var rf=jh(170);Tg(171,1,In,tl);_.t=uo;var sf=jh(171);Tg(172,1,Nn,ul);_.w=function(){al(this.a)};var tf=jh(172);Tg(173,1,In,vl);_.t=function(){return ml(this.a,this.b)};var uf=jh(173);Tg(174,1,Nn,wl);_.w=function(){ql(this.a,vm(this.b))};var vf=jh(174);Tg(175,1,Nn,xl);_.w=function(){pl(this.a,this.b);mn((rm(),qm),null)};var wf=jh(175);Tg(176,1,Nn,yl);_.w=function(){bl(this.a,this.b)};var xf=jh(176);Tg(168,1,In,zl);_.t=function(){return nl(this.a)};var yf=jh(168);Tg(169,1,Qn,Al);_.w=to;var zf=jh(169);Tg(136,38,{});_.eb=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(fo,Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,[fo])),$wnd.React.createElement('h1',null,'todos'),Zl(new $l)),T((rm(),om).c)?null:$wnd.React.createElement('section',Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,[fo])),$wnd.React.createElement(bo,Vj(Yj(Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,['toggle-all'])),(vk(),ak)),Vg(km.prototype.nb,km,[]))),$wnd.React.createElement.apply(null,['ul',Nj(new $wnd.Object,cd(Yc(me,1),Jn,2,6,['todo-list']))].concat((a=$i(Zi(T(qm.c).T()),(b=new gi,b)),fi(a,bd(a.a.length)))))),T(om.c)?null:Jl(new Kl)))};var Yf=jh(136);Tg(137,136,{});var Bl;var Sf=jh(137);Tg(138,137,ao,El);_.u=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Gl(this)),On,null)}};_.p=jo;_.jb=so;_.B=no;_.r=ko;_.v=xo;_.s=function(){var a;return fh(Ef),Ef.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.lb=function(){var b;try{return B((J(),J(),I),this.a,new Hl(this))}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.c=0;var Ef=jh(138);Tg(139,1,Qn,Fl);_.w=to;var Bf=jh(139);Tg(140,1,Nn,Gl);_.w=function(){Ik(this.a)};var Cf=jh(140);Tg(141,1,In,Hl);_.t=uo;var Df=jh(141);Tg(232,$wnd.Function,{},Il);_.pb=function(a){Wm((rm(),pm))};Tg(143,1,{},Kl);var Ff=jh(143);Tg(163,1,{},Ml);var Gf=jh(163);Tg(231,$wnd.Function,{},Nl);_.fb=function(a){return new Ol(a)};Tg(145,34,{},Ol);_.gb=function(){return new Bk};_.componentWillUnmount=yo;_.shouldComponentUpdate=zo;var Jf=jh(145);Tg(242,$wnd.Function,{},Pl);_.fb=function(a){return new Ql(a)};Tg(164,34,{},Ql);_.gb=function(){return new Jk};_.componentWillUnmount=yo;_.shouldComponentUpdate=zo;var Kf=jh(164);Tg(228,$wnd.Function,{},Rl);_.fb=function(a){return new Sl(a)};Tg(144,34,{},Sl);_.gb=function(){return new Wk};_.componentWillUnmount=yo;_.shouldComponentUpdate=zo;var Nf=jh(144);Tg(233,$wnd.Function,{},Tl);_.fb=function(a){return new Ul(a)};Tg(147,34,{},Ul);_.gb=function(){return new rl};_.componentDidUpdate=function(a,b){this.a.ib(a,b)};_.componentWillUnmount=yo;_.shouldComponentUpdate=zo;var Pf=jh(147);Tg(225,$wnd.Function,{},Vl);_.fb=function(a){return new Wl(a)};Tg(120,34,{},Wl);_.gb=function(){return new El};_.componentWillUnmount=yo;_.shouldComponentUpdate=zo;var Rf=jh(120);Tg(229,$wnd.Function,{},Xl);_.ob=function(a){Ok(this.a,a)};Tg(230,$wnd.Function,{},Yl);_.nb=function(a){Sk(this.a,a)};Tg(142,1,{},$l);var Tf=jh(142);Tg(240,$wnd.Function,{},_l);_.nb=function(a){kl(this.a,a)};Tg(234,$wnd.Function,{},am);_.nb=function(a){Bm(this.a)};Tg(236,$wnd.Function,{},bm);_.pb=function(a){cl(this.a,this.b)};Tg(237,$wnd.Function,{},cm);_.pb=function(a){gl(this.a)};Tg(238,$wnd.Function,{},dm);_.A=function(a){dl(this.a,a)};Tg(239,$wnd.Function,{},em);_.mb=function(a){fl(this.a,this.b)};Tg(241,$wnd.Function,{},fm);_.ob=function(a){el(this.a,this.b,a)};Tg(146,1,{},jm);var Vf=jh(146);Tg(226,$wnd.Function,{},km);_.nb=function(a){var b;b=a.target;$m((rm(),pm),b.checked)};Tg(65,1,{},mm);var Xf=jh(65);var nm,om,pm,qm;Tg(49,1,{49:1});_.g=false;var Ag=jh(49);Tg(50,49,{11:1,24:1,50:1,49:1},Cm);_.u=function(){tm(this)};_.p=function(a){return um(this,a)};_.B=qo;_.r=wo;_.v=Ao;_.s=function(){var a;return fh(mg),mg.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var sm=0;var mg=jh(50);Tg(177,1,Nn,Dm);_.w=function(){xm(this.a)};var Zf=jh(177);Tg(178,1,Nn,Em);_.w=function(){ym(this.a)};var $f=jh(178);Tg(47,107,{47:1});var vg=jh(47);Tg(108,47,{11:1,24:1,47:1},Mm);_.u=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new Nm(this)),On,null)}};_.p=jo;_.B=Bo;_.r=ko;_.v=function(){return this.g<0};_.s=function(){var a;return fh(gg),gg.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.g=0;var gg=jh(108);Tg(113,1,Nn,Nm);_.w=function(){Jm(this.a)};var _f=jh(113);Tg(114,1,Nn,Om);_.w=function(){hc(this.a,this.b,true)};var ag=jh(114);Tg(109,1,In,Pm);_.t=function(){return Km(this.a)};var bg=jh(109);Tg(115,1,In,Qm);_.t=function(){return Fm(this.a,this.c,this.b)};_.b=false;var cg=jh(115);Tg(110,1,In,Rm);_.t=function(){return vh(Kg(Xi(Im(this.a))))};var dg=jh(110);Tg(111,1,In,Sm);_.t=function(){return vh(Kg(Xi(Yi(Im(this.a),new zn))))};var eg=jh(111);Tg(112,1,In,Tm);_.t=function(){return Lm(this.a)};var fg=jh(112);Tg(85,1,{});var zg=jh(85);Tg(86,85,ao,_m);_.u=function(){if(this.b>=0){this.b=-2;t((J(),J(),I),new G(new cn(this)),On,null)}};_.p=jo;_.B=io;_.r=ko;_.v=function(){return this.b<0};_.s=function(){var a;return fh(lg),lg.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.b=0;var lg=jh(86);Tg(89,1,Nn,an);_.w=function(){Am(this.b,this.a)};var hg=jh(89);Tg(90,1,Nn,bn);_.w=function(){Xm(this.a)};var ig=jh(90);Tg(87,1,Nn,cn);_.w=function(){nc(this.a.a)};var jg=jh(87);Tg(88,1,Nn,dn);_.w=function(){Ym(this.a,this.b)};_.b=false;var kg=jh(88);Tg(91,1,{});var Cg=jh(91);Tg(92,91,ao,nn);_.u=function(){if(this.i>=0){this.i=-2;t((J(),J(),I),new G(new on(this)),On,null)}};_.p=jo;_.B=function(){return this.g};_.r=ko;_.v=function(){return this.i<0};_.s=function(){var a;return fh(sg),sg.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.i=0;var sg=jh(92);Tg(97,1,Nn,on);_.w=function(){hn(this.a)};var ng=jh(97);Tg(93,1,In,pn);_.t=function(){var a;return a=Wb(this.a.j),Bh(ho,a)||Bh(eo,a)||Bh('',a)?Bh(ho,a)?(wn(),tn):Bh(eo,a)?(wn(),vn):(wn(),un):(wn(),un)};var og=jh(93);Tg(94,1,In,qn);_.t=function(){return jn(this.a)};var pg=jh(94);Tg(95,1,Qn,rn);_.w=function(){kn(this.a)};var qg=jh(95);Tg(96,1,Qn,sn);_.w=function(){ln(this.a)};var rg=jh(96);Tg(37,36,{3:1,32:1,36:1,37:1},xn);var tn,un,vn;var tg=kh(37,yn);Tg(81,1,{},zn);_.cb=function(a){return !wm(a)};var ug=jh(81);Tg(83,1,{},An);_.cb=function(a){return wm(a)};var wg=jh(83);Tg(84,1,{},Bn);_.A=function(a){Hm(this.a,a)};var xg=jh(84);Tg(82,1,{},Cn);_.A=function(a){Vm(this.a,a)};_.a=false;var yg=jh(82);Tg(73,1,{},Dn);_.cb=function(a){return fn(this.a,a)};var Bg=jh(73);var En=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=Og;Mg(Zg);Pg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();