function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='0DD1A14C472D397B6A27DA97B383616C',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '0DD1A14C472D397B6A27DA97B383616C';function o(){}
function $g(){}
function Wg(){}
function Hb(){}
function Mc(){}
function Tc(){}
function kj(){}
function lj(){}
function zk(){}
function Ik(){}
function Vl(){}
function Yl(){}
function am(){}
function em(){}
function im(){}
function mm(){}
function Cm(){}
function _m(){}
function ko(){}
function lo(){}
function Rc(a){Qc()}
function gh(){gh=Wg}
function ii(){_h(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function Hh(a){this.a=a}
function wh(a){this.a=a}
function Th(a){this.a=a}
function Yh(a){this.a=a}
function Zh(a){this.a=a}
function lb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function cc(a){this.a=a}
function lc(a){this.a=a}
function ij(a){this.a=a}
function nj(a){this.a=a}
function Hk(a){this.a=a}
function Jk(a){this.a=a}
function Kk(a){this.a=a}
function Qk(a){this.a=a}
function Rk(a){this.a=a}
function Sk(a){this.a=a}
function dl(a){this.a=a}
function el(a){this.a=a}
function fl(a){this.a=a}
function hl(a){this.a=a}
function Dl(a){this.a=a}
function El(a){this.a=a}
function Gl(a){this.a=a}
function Ll(a){this.a=a}
function Ml(a){this.a=a}
function Sl(a){this.a=a}
function Tl(a){this.a=a}
function Ul(a){this.a=a}
function qm(a){this.a=a}
function rm(a){this.a=a}
function tm(a){this.a=a}
function um(a){this.a=a}
function wm(a){this.a=a}
function xm(a){this.a=a}
function Vm(a){this.a=a}
function Wm(a){this.a=a}
function Xm(a){this.a=a}
function Zm(a){this.a=a}
function $m(a){this.a=a}
function mn(a){this.a=a}
function nn(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function Bn(a){this.a=a}
function Cn(a){this.a=a}
function Dn(a){this.a=a}
function En(a){this.a=a}
function Pn(a){this.a=a}
function Zn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function co(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function oo(a){this.a=a}
function Xh(a){this.b=a}
function ki(a){this.c=a}
function _o(){fc(this.c)}
function bp(){fc(this.b)}
function ui(){this.a=Di()}
function Ii(){this.a=Di()}
function w(a){--a.e;D(a)}
function V(a){!!a&&cb(a)}
function gc(a){!!a&&a.u()}
function Xo(a){Mi(this,a)}
function $o(a){Ah(this,a)}
function gb(a){Vb((J(),a))}
function hb(a){Wb((J(),a))}
function jb(a){Xb((J(),a))}
function Gn(a,b){Bl(b,a)}
function Ej(a,b){Dj(a,b)}
function mj(a,b){dj(a.a,b)}
function jc(a,b){Ph(a.e,b)}
function Fn(a,b){qn(a.b,b)}
function C(a,b){ab(a.f,b.f)}
function jj(a,b){a.a=b}
function Fj(a,b){a.key=b}
function sb(a,b){a.b=Pi(b)}
function Kb(a){a.a=-4&a.a|1}
function Ak(a){a.d=2;fc(a.c)}
function Lk(a){a.c=2;fc(a.b)}
function pl(a){a.f=2;fc(a.e)}
function Hg(a){return a.e}
function Uo(){return this.a}
function Zo(){return this.b}
function Dh(a,b){return a===b}
function jl(a,b){return a.g=b}
function Wo(){return vj(this)}
function Ih(a){qc.call(this,a)}
function gp(a){jc(this.c,a)}
function dp(){mb(this.a.a)}
function Ek(a){mb(a.b);R(a.a)}
function Zk(a){mb(a.a);cb(a.b)}
function Om(a){R(a.a);cb(a.b)}
function bn(a){cb(a.b);cb(a.a)}
function ol(a){rn((Hm(),Em),a)}
function ec(a,b,c){Oh(a.e,b,c)}
function cn(a,b,c){ec(a.c,b,c)}
function rj(a,b){a.splice(b,1)}
function K(a,b){O(a);L(a,Pi(b))}
function ci(a,b){return a.a[b]}
function Uc(a,b){return ph(a,b)}
function Vo(a){return this===a}
function Bh(){mc(this);this.C()}
function Yo(){return Rh(this.a)}
function ap(){return this.c.i<0}
function cp(){return this.b.i<0}
function zi(){zi=Wg;yi=Bi()}
function J(){J=Wg;I=new F}
function Jc(){Jc=Wg;Ic=new Mc}
function sc(){sc=Wg;rc=new o}
function zc(){zc=Wg;!!(Qc(),Pc)}
function Pg(){Ng==null&&(Ng=[])}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function jh(a){ih(a);return a.k}
function cj(a,b){a.O(b);return a}
function Oj(a,b){a.ref=b;return a}
function Qm(a){ib(a.b);return a.e}
function fn(a){ib(a.a);return a.d}
function Tn(a){ib(a.d);return a.f}
function Di(){zi();return new yi}
function db(a){J();Wb(a);a.e=-2}
function dj(a,b){jj(a,cj(a.a,b))}
function Qi(a,b){while(a._(b));}
function dc(a,b){this.a=a;this.b=b}
function uh(a,b){this.a=a;this.b=b}
function $h(a,b){this.a=a;this.b=b}
function gj(a,b){this.a=a;this.b=b}
function Mj(a,b){this.a=a;this.b=b}
function ep(a){return 1==this.a.d}
function fp(a){return 1==this.a.c}
function Rh(a){return a.a.b+a.b.b}
function Fi(a,b){return a.a.get(b)}
function W(a){return !!a&&a.c.i<0}
function Zc(a){return new Array(a)}
function v(a,b,c){s(a,new H(c),b)}
function pj(a,b,c){a.splice(b,0,c)}
function vk(a,b){uh.call(this,a,b)}
function gl(a,b){this.a=a;this.b=b}
function Fl(a,b){this.a=a;this.b=b}
function Hl(a,b){this.a=a;this.b=b}
function Il(a,b){this.a=a;this.b=b}
function Jl(a,b){this.a=a;this.b=b}
function Kl(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function zm(a,b){this.a=a;this.b=b}
function Ym(a,b){this.a=a;this.b=b}
function zn(a,b){this.a=a;this.b=b}
function Nn(a,b){this.a=a;this.b=b}
function On(a,b){this.b=a;this.a=b}
function io(a,b){uh.call(this,a,b)}
function Pj(a,b){a.href=b;return a}
function Fh(a,b){a.a+=''+b;return a}
function Wl(){this.a=Gj(($l(),Zl))}
function Xl(){this.a=Gj((cm(),bm))}
function sm(){this.a=Gj((gm(),fm))}
function Bm(){this.a=Gj((km(),jm))}
function Dm(){this.a=Gj((om(),nm))}
function Rm(a){Pm(a,(ib(a.b),a.e))}
function gn(a){Bl(a,(ib(a.a),!a.d))}
function Rb(a){return !a.d?a:Rb(a.d)}
function Nh(a){return !a?null:a.X()}
function md(a){return a==null?null:a}
function Oi(a){return a!=null?r(a):0}
function jd(a){return typeof a===ro}
function Hc(){wc!=0&&(wc=0);yc=-1}
function Gc(a){$wnd.clearTimeout(a)}
function _h(a){a.a=Wc(de,to,1,0,5,1)}
function Qh(a){a.a=new ui;a.b=new Ii}
function kb(a){this.c=new ii;this.b=a}
function zj(){zj=Wg;wj=new o;yj=new o}
function Yj(a,b){a.value=b;return a}
function Tj(a,b){a.onBlur=b;return a}
function Qj(a,b){a.onClick=b;return a}
function Sj(a,b){a.checked=b;return a}
function Uj(a,b){a.onChange=b;return a}
function qj(a,b){oj(b,0,a,0,b.length)}
function bc(a,b){_b(a,b,false);hb(a.d)}
function tl(a){mb(a.b);R(a.c);cb(a.a)}
function rb(a){J();qb(a);ub(a,2,true)}
function ib(a){var b;Sb((J(),b=Nb,b),a)}
function Fb(a){this.d=Pi(a);this.b=100}
function P(){this.a=Wc(de,to,1,100,5,1)}
function B(a,b,c){return t(a,c,2048,b)}
function _c(a,b,c){return {l:a,m:b,h:c}}
function Ch(a,b){return a.charCodeAt(b)}
function gd(a,b){return a!=null&&ed(a,b)}
function X(a){return !(!!a&&1==(a.c&7))}
function vj(a){return a.$H||(a.$H=++uj)}
function ld(a){return typeof a==='string'}
function Vj(a,b){a.onKeyDown=b;return a}
function Rj(a){a.autoFocus=true;return a}
function ih(a){if(a.k!=null){return}rh(a)}
function qc(a){this.f=a;mc(this);this.C()}
function bj(a,b){Yi.call(this,a);this.a=b}
function ac(a,b){b.w(a);gd(b,9)&&b.s()}
function Dj(a,b){for(var c in a){b(c)}}
function tj(b,c,d){try{b[c]=d}catch(a){}}
function A(a,b,c){t(a,new G(b),c,null)}
function yl(a){A((J(),J(),I),new Ml(a),Mo)}
function Sm(a){A((J(),J(),I),new Zm(a),Mo)}
function kn(a){A((J(),J(),I),new nn(a),Mo)}
function Hn(a){A((J(),J(),I),new Pn(a),Mo)}
function Jm(a){eh((dh(),bh),Po,a.d,false)}
function Km(a){fh((dh(),bh),Po,a.d,false)}
function T(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function vn(a){return xh(S(a.e).a-S(a.a).a)}
function hd(a){return typeof a==='boolean'}
function u(a,b){return new xb(Pi(a),null,b)}
function wi(a,b){var c;c=a[Ho];c.call(a,b)}
function nc(a,b){a.e=b;b!=null&&tj(b,Co,a)}
function Mi(a,b){while(a.T()){mj(b,a.U())}}
function Eb(a){while(true){if(!Db(a)){break}}}
function oi(){this.a=new ui;this.b=new Ii}
function Li(a,b,c){this.a=a;this.b=b;this.c=c}
function $(a,b,c){Kb(Pi(c));K(a.a[b],Pi(c))}
function Ac(a,b,c){return a.apply(b,c);var d}
function Zj(a,b){a.onDoubleClick=b;return a}
function ai(a,b){a.a[a.a.length]=b;return true}
function mc(a){a.g&&a.e!==Bo&&a.C();return a}
function mh(a){var b;b=lh(a);th(a,b);return b}
function zh(){zh=Wg;yh=Wc(_d,to,32,256,0,1)}
function Qc(){Qc=Wg;var a;!Sc();a=new Tc;Pc=a}
function Vn(a){W((ib(a.d),a.f))&&Xn(a,null)}
function rn(a,b){A((J(),J(),I),new zn(a,b),Mo)}
function Kn(a,b){A((J(),J(),I),new On(a,b),Mo)}
function Ln(a,b){A((J(),J(),I),new Nn(a,b),Mo)}
function $k(a,b){A((J(),J(),I),new gl(a,b),Mo)}
function ul(a,b){A((J(),J(),I),new Kl(a,b),Mo)}
function wl(a,b){A((J(),J(),I),new Il(a,b),Mo)}
function xl(a,b){A((J(),J(),I),new Hl(a,b),Mo)}
function Al(a,b){A((J(),J(),I),new Fl(a,b),Mo)}
function tn(a){Ah(new Yh(a.g),new cc(a));Qh(a.g)}
function F(){this.f=new bb;this.a=new Fb(this.f)}
function An(a,b){this.a=a;this.c=b;this.b=false}
function _k(a,b){var c;c=b.target;bl(a,c.value)}
function pb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function eh(a,b,c,d){a.addEventListener(b,c,d)}
function fh(a,b,c,d){a.removeEventListener(b,c,d)}
function ej(a,b,c){if(a.a.ab(c)){a.b=true;b.v(c)}}
function Gb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Si(a){if(!a.d){a.d=a.b.N();a.c=a.b.P()}}
function Vh(a){var b;b=a.a.U();a.b=Uh(a);return b}
function oh(a){var b;b=lh(a);b.j=a;b.e=1;return b}
function ei(a,b){var c;c=a.a[b];rj(a.a,b);return c}
function Nc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ei(a,b){return !(a.a.get(b)===undefined)}
function un(a){return gh(),0==S(a.e).a?true:false}
function al(a){return B((J(),J(),I),a.a,new el(a))}
function zl(a){return B((J(),J(),I),a.b,new El(a))}
function Ql(a){return B((J(),J(),I),a.a,new Ul(a))}
function Ok(a){return B((J(),J(),I),a.a,new Sk(a))}
function Fk(a){return B((J(),J(),I),a.b,new Kk(a))}
function Qn(a){return Dh(So,a)||Dh(To,a)||Dh('',a)}
function Yc(a){return Array.isArray(a)&&a.jb===$g}
function fd(a){return !Array.isArray(a)&&a.jb===$g}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function pn(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function Wi(a){if(!a.b){Xi(a);a.c=true}else{Wi(a.b)}}
function Bk(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function Mk(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function ql(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function Cj(){if(xj==256){wj=yj;yj=new o;xj=0}++xj}
function Pi(a){if(a==null){throw Hg(new Bh)}return a}
function Sh(a,b){if(b){return Lh(a.a,b)}return false}
function $i(a,b){Xi(a);return new bj(a,new fj(b,a.a))}
function _i(a){Xi(a);return new bj(a,new hj(a.a))}
function Pm(a,b){A((J(),J(),I),new Ym(a,b),75497472)}
function Sn(a){mb(a.e);mb(a.a);R(a.b);R(a.c);cb(a.d)}
function Nm(a){var b;T(a.a);b=S(a.a);Dh(a.f,b)&&Tm(a,b)}
function bl(a,b){var c;c=a.e;if(b!=c){a.e=b;hb(a.b)}}
function Bl(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function Tm(a,b){var c;c=a.e;if(b!=c){a.e=Pi(b);hb(a.b)}}
function nh(a,b){var c;c=lh(a);th(a,c);c.e=b?8:0;return c}
function gi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Xj(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Ri(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Ti(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function qn(a,b){return t((J(),J(),I),new An(a,b),Mo,null)}
function ni(a,b){return md(a)===md(b)||a!=null&&p(a,b)}
function jo(){ho();return $c(Uc(vg,1),to,34,0,[eo,go,fo])}
function qh(a){if(a.L()){return null}var b=a.j;return Sg[b]}
function Mg(a){if(jd(a)){return a|0}return a.l|a.m<<22}
function Yi(a){if(!a){this.b=null;new ii}else{this.b=a}}
function hj(a){Ri.call(this,a.$(),a.Z()&-6);this.a=a}
function nb(a){C((J(),J(),I),a);0==(a.f.a&yo)&&D((null,I))}
function Ob(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);qb(a.e)}}
function il(a,b){var c;if(S(a.c)){c=b.target;Bl(a,c.value)}}
function Ah(a,b){var c,d;for(d=a.N();d.T();){c=d.U();b.v(c)}}
function oc(a,b){var c;c=jh(a.hb);return b==null?c:c+': '+b}
function Mh(a,b){return b===a?'(this Map)':b==null?Eo:Zg(b)}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function Yg(a){function b(){}
;b.prototype=a||{};return new b}
function cm(){cm=Wg;var a;bm=(a=Xg(am.prototype.gb,am,[]),a)}
function gm(){gm=Wg;var a;fm=(a=Xg(em.prototype.gb,em,[]),a)}
function km(){km=Wg;var a;jm=(a=Xg(im.prototype.gb,im,[]),a)}
function om(){om=Wg;var a;nm=(a=Xg(mm.prototype.gb,mm,[]),a)}
function $l(){$l=Wg;var a;Zl=(a=Xg(Yl.prototype.gb,Yl,[]),a)}
function Hm(){Hm=Wg;Em=new wn;Fm=new Mn(Em);Gm=new Yn(Em)}
function In(a,b){var c;aj(sn(a.b),(c=new ii,c)).M(new no(b))}
function ph(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.G(b))}
function qi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function ri(a,b){var c;return pi(b,qi(a,b==null?0:(c=r(b),c|0)))}
function sn(a){ib(a.d);return new bj(null,new Ti(new Yh(a.g),0))}
function Xi(a){if(a.b){Xi(a.b)}else if(a.c){throw Hg(new vh)}}
function Fc(a){zc();$wnd.setTimeout(function(){throw a},0)}
function vi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function ji(a){_h(this);qj(this.a,Kh(a,Wc(de,to,1,Rh(a.a),5,1)))}
function ll(a,b){Xn((Hm(),Gm),b);A((J(),J(),I),new Fl(a,b),Mo)}
function Lm(a,b){b.preventDefault();A((J(),J(),I),new $m(a),Mo)}
function Wj(a){a.placeholder='What needs to be done?';return a}
function pc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ug(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Lj(a,b,c){!Dh(c,'key')&&!Dh(c,'ref')&&(a[c]=b[c],undefined)}
function Dc(a,b,c){var d;d=Bc();try{return Ac(a,b,c)}finally{Ec(d)}}
function ic(a){gc(a.g);!!a.e&&hc(a);V(a.a);V(a.c);gc(a.b);gc(a.f)}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function fj(a,b){Ri.call(this,b.$(),b.Z()&-16449);this.a=a;this.c=b}
function _l(a){$wnd.React.Component.call(this,a);this.a=new Gk(this)}
function dm(a){$wnd.React.Component.call(this,a);this.a=new Pk(this)}
function hm(a){$wnd.React.Component.call(this,a);this.a=new cl(this)}
function lm(a){$wnd.React.Component.call(this,a);this.a=new Cl(this)}
function pm(a){$wnd.React.Component.call(this,a);this.a=new Rl(this)}
function Ji(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Mn(a){this.b=Pi(a);J();this.a=new kc(0,null,null,true,false)}
function Zi(a){var b;Wi(a);b=0;while(a.a._(new lj)){b=Ig(b,1)}return b}
function aj(a,b){var c;Wi(a);c=new kj;c.a=b;a.a.S(new nj(c));return c.a}
function Ui(a,b){!a.a?(a.a=new Hh(a.d)):Fh(a.a,a.b);Fh(a.a,b);return a}
function Ph(a,b){return ld(b)?b==null?ti(a.a,null):Hi(a.b,b):ti(a.a,b)}
function eb(a,b){var c,d;ai(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Xn(a,b){var c;c=a.f;if(!(b==c||!!b&&dn(b,c))){a.f=b;hb(a.d)}}
function Jn(a){var b;aj($i(sn(a.b),new lo),(b=new ii,b)).M(new mo(a.b))}
function Lb(b){try{b.b.u()}catch(a){a=Gg(a);if(!gd(a,5))throw Hg(a)}}
function Ec(a){a&&Lc((Jc(),Ic));--wc;if(a){if(yc!=-1){Gc(yc);yc=-1}}}
function nd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function vl(a){return gh(),Tn((Hm(),Gm))==a.j.props['a']?true:false}
function Rn(a,b){return (ho(),fo)==a||(eo==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function sj(a,b){return Vc(b)!=10&&$c(q(b),b.ib,b.__elementTypeId$,Vc(b),a),a}
function Cc(b){zc();return function(){return Dc(b,this,arguments);var a}}
function vc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ki(a){if(a.a.c!=a.c){return Fi(a.a,a.b.value[0])}return a.b.value[1]}
function di(a,b,c){for(;c<a.a.length;++c){if(ni(b,a.a[c])){return c}}return -1}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function bi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function Un(a){var b,c;return b=S(a.b),aj($i(sn(a.j),new oo(b)),(c=new ii,c))}
function Oh(a,b,c){return ld(b)?b==null?si(a.a,null,c):Gi(a.b,b,c):si(a.a,b,c)}
function Wc(a,b,c,d,e,f){var g;g=Xc(e,d);e!=10&&$c(Uc(a,f),b,c,e,g);return g}
function fi(a,b){var c;c=di(a,b,0);if(c==-1){return false}rj(a.a,c);return true}
function dn(a,b){var c;if(gd(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function Vi(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Wh(a){this.d=a;this.c=new Ji(this.d.b);this.a=this.c;this.b=Uh(this)}
function dh(){dh=Wg;ah=$wnd.window.document;bh=$wnd.window.window}
function vh(){qc.call(this,"Stream already terminated, can't be modified or used")}
function bb(){var a;this.a=Wc(sd,to,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function fc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new lc(a)),67108864,null)}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new lb(a)),0,null);!!a.b&&mb(a.b)}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||mb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function Kc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Oc(b,c)}while(a.a);a.a=c}}
function Lc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Oc(b,c)}while(a.b);a.b=c}}
function Tk(a){var b;b=Eh((ib(a.b),a.e));if(b.length>0){Fn((Hm(),Fm),b);bl(a,'')}}
function Im(a,b){a.f=b;Dh(b,S(a.a))&&Tm(a,b);Mm(b);A((J(),J(),I),new $m(a),Mo)}
function Uk(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new fl(a),Mo)}}
function tb(b){if(b){try{b.u()}catch(a){a=Gg(a);if(gd(a,5)){J()}else throw Hg(a)}}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function lh(a){var b;b=new kh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Xg(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Gg(a){var b;if(gd(a,5)){return a}b=a&&a[Co];if(!b){b=new uc(a);Rc(b)}return b}
function th(a,b){var c;if(!a){return}b.j=a;var d=qh(b);if(!d){Sg[a]=[b];return}d.hb=b}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;ai((!a.b&&(a.b=new ii),a.b),b)}}}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new ii);a.c=c.c}b.d=true;ai(a.c,Pi(b))}
function Hi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{wi(a.a,b);--a.b}return c}
function li(a){var b,c,d;d=0;for(c=new Wh(a.a);c.b;){b=Vh(c);d=d+(b?r(b):0);d=d|0}return d}
function qb(a){var b,c;for(c=new ki(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Og(){Pg();var a=Ng;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function kd(a){return a!=null&&(typeof a===qo||typeof a==='function')&&!(a.jb===$g)}
function Vc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Jj(a){var b;return Hj($wnd.React.StrictMode,null,null,(b={},b[Io]=Pi(a),b))}
function Gj(a){var b;b=Ij($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Hj(a,b,c,d){var e;e=Ij($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Pi(d);return e}
function on(a,b,c){var d;d=new ln(b,c);cn(d,a,new dc(a,d));Oh(a.g,xh(d.c.d),d);hb(a.d);return d}
function Jh(a,b){var c,d;for(d=new Wh(b.a);d.b;){c=Vh(d);if(!Sh(a,c)){return false}}return true}
function Jg(a){var b;b=a.h;if(b==0){return a.l+a.m*zo}if(b==1048575){return a.l+a.m*zo-Fo}return a}
function Uh(a){if(a.a.T()){return true}if(a.a!=a.c){return false}a.a=new vi(a.d.a);return a.a.T()}
function Am(a,b){Fj(a.a,(ih(Of),Of.k+(''+(b?xh(b.c.d):null))));Pi(b);a.a.props['a']=b;return a.a}
function _b(a,b,c){var d;d=Ph(a.g,b?xh(b.c.d):null);if(null!=d){jc(b.c,a);c&&!!b&&fc(b.c);hb(a.d)}}
function Mb(a,b){this.b=Pi(a);this.a=b|0|(0==(b&6291456)?zo:0)|(0!=(b&229376)?0:98304)}
function xb(a,b,c){wb.call(this,null,a,b,c|(!a?262144:vo)|(0==(c&6291456)?!a?yo:zo:0)|0|0|0)}
function Rg(a,b){typeof window===qo&&typeof window['$gwt']===qo&&(window['$gwt'][a]=b)}
function ho(){ho=Wg;eo=new io('ACTIVE',0);go=new io('COMPLETED',1);fo=new io('ALL',2)}
function _g(){Hm();$wnd.ReactDOM.render(Jj([(new Dm).a]),(dh(),ah).getElementById('app'),null)}
function pi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(ni(a,c.W())){return c}}return null}
function Lg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Fo;d=1048575}c=nd(e/zo);b=nd(e-c*zo);return _c(b,c,d)}
function Wn(a){var b;b=S(a.i.a);Dh(So,b)||Dh(To,b)||Dh('',b)?Pm(a.i,b):Qn(Qm(a.i))?Sm(a.i):Pm(a.i,'')}
function S(a){ib(a.e);vb(a.f)&&ob(a.f);if(a.b){if(gd(a.b,8)){throw Hg(a.b)}else{throw Hg(a.b)}}return a.k}
function $c(a,b,c,d,e){e.hb=a;e.ib=b;e.jb=$g;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Gi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function kl(a,b,c){27==c.which?A((J(),J(),I),new Jl(a,b),Mo):13==c.which&&A((J(),J(),I),new Hl(a,b),Mo)}
function mb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Bb(a)),67108864,null);!!a.a&&R(a.a);Ib(a.f);a.c=a.c&-8|1}}
function yk(){if(!xk){xk=(++(J(),J(),I).e,new Hb);$wnd.Promise.resolve(null).then(Xg(zk.prototype.F,zk,[]))}}
function wk(){uk();return $c(Uc(Te,1),to,7,0,[$j,_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk])}
function q(a){return ld(a)?ge:jd(a)?Xd:hd(a)?Vd:fd(a)?a.hb:Yc(a)?a.hb:a.hb||Array.isArray(a)&&Uc(Od,1)||Od}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&vo)?Lb(a):a.b.u();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function fb(a,b){var c,d;d=a.c;fi(d,b);!!a.b&&vo!=(a.b.c&wo)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function ad(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return _c(c&4194303,d&4194303,e&1048575)}
function ml(a,b){var c;c=(ib(a.a),a.d);if(null!=c&&c.length!=0){Kn((Hm(),b),c);Xn(Gm,null);Bl(a,c)}else{rn((Hm(),Em),b)}}
function nl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Al(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function xh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(zh(),yh)[b];!c&&(c=yh[b]=new wh(a));return c}return new wh(a)}
function Zg(a){var b;if(Array.isArray(a)&&a.jb===$g){return jh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Bj(a){zj();var b,c,d;c=':'+a;d=yj[c];if(d!=null){return nd(d)}d=wj[c];b=d==null?Aj(a):nd(d);Cj();yj[c]=b;return b}
function uc(a){sc();mc(this);this.e=a;a!=null&&tj(a,Co,this);this.f=a==null?Eo:Zg(a);this.a='';this.b=a;this.a=''}
function kh(){this.g=hh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Rl(a){var b;this.j=Pi(a);J();b=++Pl;this.b=new kc(b,null,new Sl(this),false,false);this.a=new xb(null,Pi(new Tl(this)),Lo)}
function Pk(a){var b;this.j=Pi(a);J();b=++Nk;this.b=new kc(b,null,new Qk(this),false,false);this.a=new xb(null,Pi(new Rk(this)),Lo)}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=ei(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function mi(a){var b,c,d;d=1;for(c=new ki(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function hc(a){var b,c,d;for(c=new ki(new ji(new Th(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.W();gd(d,9)&&d.t()||b.X().u()}}
function yb(a,b){wb.call(this,a,new zb(a),null,b|(vo==(b&wo)?0:524288)|(0==(b&6291456)?vo==(b&wo)?zo:yo:0)|0|268435456|0)}
function p(a,b){return ld(a)?Dh(a,b):jd(a)?a===b:hd(a)?a===b:fd(a)?a.n(b):Yc(a)?a===b:!!a&&!!a.equals?a.equals(b):md(a)===md(b)}
function r(a){return ld(a)?Bj(a):jd(a)?nd(a):hd(a)?a?1231:1237:fd(a)?a.p():Yc(a)?vj(a):!!a&&!!a.hashCode?a.hashCode():vj(a)}
function Ig(a,b){var c;if(jd(a)&&jd(b)){c=a+b;if(-17592186044416<c&&c<Fo){return c}}return Jg(ad(jd(a)?Lg(a):a,jd(b)?Lg(b):b))}
function sh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function hi(a,b){var c,d;d=a.a.length;b.length<d&&(b=sj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Kh(a,b){var c,d,e;e=Rh(a.a);b.length<e&&(b=sj(new Array(e),b));d=new Wh(a.a);for(c=0;c<e;++c){b[c]=Vh(d)}b.length>e&&(b[e]=null);return b}
function Nj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Bc(){var a;if(wc!=0){a=vc();if(a-xc>2000){xc=a;yc=$wnd.setTimeout(Hc,10)}}if(wc++==0){Kc((Jc(),Ic));return true}return false}
function Sc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a,b,c,d,e){var f;this.d=a;this.e=d?new oi:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new kb((J(),null)),f):null;this.c=null}
function U(a,b,c,d){this.c=Pi(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new yb(this,d);this.e=new kb(this.f);vo==(d&wo)&&nb(this.f)}
function ln(a,b){var c,d,e;this.e=Pi(a);this.d=b;J();c=++an;this.c=new kc(c,null,new mn(this),true,true);this.b=(e=new kb(null),e);this.a=(d=new kb(null),d)}
function cl(a){var b,c;this.j=Pi(a);J();b=++Yk;this.c=new kc(b,null,new dl(this),false,false);this.b=(c=new kb(null),c);this.a=new xb(null,Pi(new hl(this)),Lo)}
function ed(a,b){if(ld(a)){return !!dd[b]}else if(a.ib){return !!a.ib[b]}else if(jd(a)){return !!cd[b]}else if(hd(a)){return !!bd[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Wb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ki(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&ub(b,6,true)}}}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Eh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Xc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{Zb(b,d);try{f=(c.a.u(),null)}finally{$b()}return f}catch(a){a=Gg(a);if(gd(a,5)){e=a;throw Hg(e)}else throw Hg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.r()}else{Zb(b,e);try{g=c.r()}finally{$b()}}return g}catch(a){a=Gg(a);if(gd(a,5)){f=a;throw Hg(f)}else throw Hg(a)}finally{D(b)}}
function Mm(a){var b;if(0==a.length){b=(dh(),bh).location.pathname+(''+bh.location.search);bh.history.pushState('',ah.title,b)}else{(dh(),bh).location.hash=a}}
function Db(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Jb(c);return true}
function Qg(b,c,d,e){Pg();var f=Ng;$moduleName=c;$moduleBase=d;Fg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{po(g)()}catch(a){b(c,a)}}else{po(g)()}}
function Gk(a){var b;this.j=Pi(a);J();b=++Dk;this.c=new kc(b,null,new Hk(this),false,false);this.a=new U(new Ik,null,null,136478720);this.b=new xb(null,Pi(new Jk(this)),Lo)}
function Ij(a,b){var c;c=new $wnd.Object;c.$$typeof=Pi(a);c.type=Pi(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Bi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ci()}}
function Tg(){Sg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Oc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].kb()&&(c=Nc(c,g)):g[0].kb()}catch(a){a=Gg(a);if(gd(a,5)){d=a;zc();Fc(gd(d,35)?d.D():d)}else throw Hg(a)}}return c}
function Xk(a){var b;a.d=0;yk();b=Kj(No,Rj(Uj(Vj(Yj(Wj(Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,['new-todo']))),(ib(a.b),a.e)),Xg(qm.prototype.eb,qm,[a])),Xg(rm.prototype.db,rm,[a]))),null);return b}
function tc(a){var b;if(a.c==null){b=md(a.b)===md(rc)?null:a.b;a.d=b==null?Eo:kd(b)?b==null?null:b.name:ld(b)?'String':jh(q(b));a.a=a.a+': '+(kd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.k;try{d=b.c.r();if(!(md(e)===md(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Gg(a);if(gd(a,11)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Hg(c)}else throw Hg(a)}}
function si(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=pi(b,e);if(f){return f.Y(c)}}e[e.length]=new $h(b,c);++a.b;return null}
function oj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Aj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ch(a,c++)}b=b|0;return b}
function ob(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.u()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Gg(a);if(gd(a,5)){J()}else throw Hg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Wc(de,to,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function wb(a,b,c,d){this.b=new ii;this.f=new Mb(new Ab(this),d&6520832|262144|vo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&yo)&&D((null,I)))}
function ti(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(ni(b,e.W())){if(d.length==1){d.length=0;wi(a.a,g)}else{d.splice(h,1)}--a.b;return e.X()}}return null}
function Cl(a){var b,c;this.j=Pi(a);J();b=++sl;this.e=new kc(b,null,new Dl(this),false,false);this.a=(c=new kb(null),c);this.c=new U(new Gl(this),null,null,136478720);this.b=new xb(null,Pi(new Ll(this)),Lo);Al(this,this.j.props['a'])}
function Vg(a,b,c){var d=Sg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Sg[b]),Yg(h));_.ib=c;!b&&(_.jb=$g);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.hb=f)}
function Um(){var a,b;this.d=new co(this);this.f=this.e=(b=(dh(),bh).location.hash,null==b?'':b.substr(1));J();this.c=new kc(0,null,new Vm(this),true,false);this.b=(a=new kb(null),a);this.a=new U(new _m,new Wm(this),new Xm(this),35749888)}
function rh(a){if(a.K()){var b=a.c;b.L()?(a.k='['+b.j):!b.K()?(a.k='[L'+b.I()+';'):(a.k='['+b.I());a.b=b.H()+'[]';a.i=b.J()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=sh('.',[c,sh('$',d)]);a.b=sh('.',[c,sh('.',d)]);a.i=d[d.length-1]}
function Lh(a,b){var c,d,e;c=b.W();e=b.X();d=ld(c)?c==null?Nh(ri(a.a,null)):Fi(a.b,c):Nh(ri(a.a,c));if(!(md(e)===md(d)||e!=null&&p(e,d))){return false}if(d==null&&!(ld(c)?c==null?!!ri(a.a,null):Ei(a.b,c):!!ri(a.a,c))){return false}return true}
function Kj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Ej(b,Xg(Mj.prototype.bb,Mj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Io]=c[0],undefined):(d[Io]=c,undefined));return Hj(a,e,f,d)}
function wn(){var a;this.g=new oi;J();this.f=new kc(0,new yn(this),new xn(this),true,false);this.d=(a=new kb(null),a);this.c=new U(new Bn(this),null,null,Ro);this.e=new U(new Cn(this),null,null,Ro);this.a=new U(new Dn(this),null,null,Ro);this.b=new U(new En(this),null,null,Ro)}
function Yn(a){var b;this.j=Pi(a);this.i=new Um;J();this.g=new kc(0,null,new Zn(this),true,false);this.d=(b=new kb(null),b);this.b=new U(new $n(this),null,null,Ro);this.c=new U(new _n(this),null,null,Ro);this.e=u(new ao(this),413138944);this.a=u(new bo(this),681574400);D((null,I))}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ki(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Gg(a);if(!gd(a,5))throw Hg(a)}if(6==(b.c&7)){return true}}}}}qb(b);return false}
function Ai(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ub(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){jb(a.a.e);tb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;tb((e=d.i,e));d.k=null}bi(a.b,new Cb(a));a.b.a=Wc(de,to,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&tb((f=a.a.g,f))}}
function uk(){uk=Wg;$j=new vk(Jo,0);_j=new vk('checkbox',1);ak=new vk('color',2);bk=new vk('date',3);ck=new vk('datetime',4);dk=new vk('email',5);ek=new vk('file',6);fk=new vk('hidden',7);gk=new vk('image',8);hk=new vk('month',9);ik=new vk(ro,10);jk=new vk('password',11);kk=new vk('radio',12);lk=new vk('range',13);mk=new vk('reset',14);nk=new vk('search',15);ok=new vk('submit',16);pk=new vk('tel',17);qk=new vk('text',18);rk=new vk('time',19);sk=new vk('url',20);tk=new vk('week',21)}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ci(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&gi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ci(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ei(a.b,g)}e&&sb(a.e,a.b)}else{e&&sb(a.e,new ii)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&vo!=(k.b.c&wo)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function Ck(a){var b,c;a.d=0;yk();c=(b=S((Hm(),Gm).b),Kj('footer',Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,['footer'])),[(new Xl).a,Kj('ul',Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,['filters'])),[Kj('li',null,[Kj('a',Pj(Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,[(ho(),fo)==b?Ko:null])),'#'),['All'])]),Kj('li',null,[Kj('a',Pj(Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,[eo==b?Ko:null])),'#active'),['Active'])]),Kj('li',null,[Kj('a',Pj(Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,[go==b?Ko:null])),'#completed'),['Completed'])])]),S(a.a)?Kj(Jo,Qj(Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,['clear-completed'])),Xg(Vl.prototype.fb,Vl,[])),['Clear Completed']):null]));return c}
function rl(a){var b,c,d,e;a.f=0;yk();b=a.j.props['a'];if(b.c.i<0){return null}c=(d=a.j.props['a'],e=(ib(d.a),d.d),Kj('li',Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,[e?'checked':null,S(a.c)?'editing':null])),[Kj('div',Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,['view'])),[Kj(No,Uj(Sj(Xj(Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,['toggle'])),(uk(),_j)),e),Xg(um.prototype.db,um,[d])),null),Kj('label',Zj(new $wnd.Object,Xg(vm.prototype.fb,vm,[a,d])),[(ib(d.b),d.e)]),Kj(Jo,Qj(Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,['destroy'])),Xg(wm.prototype.fb,wm,[d])),null)]),Kj(No,Vj(Uj(Tj(Yj(Nj(Oj(new $wnd.Object,Xg(xm.prototype.v,xm,[a])),$c(Uc(ge,1),to,2,6,['edit'])),(ib(a.a),a.d)),Xg(ym.prototype.cb,ym,[a,d])),Xg(tm.prototype.db,tm,[a])),Xg(zm.prototype.eb,zm,[a,d])),null)]));return c}
function Ci(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Ho]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ai()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Ho]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var qo='object',ro='number',so={14:1},to={3:1,4:1},uo={9:1},vo=1048576,wo=1835008,xo={6:1},yo=2097152,zo=4194304,Ao={21:1},Bo='__noinit__',Co='__java$exception',Do={3:1,11:1,8:1,5:1},Eo='null',Fo=17592186044416,Go={40:1},Ho='delete',Io='children',Jo='button',Ko='selected',Lo=1411518464,Mo=142606336,No='input',Oo='header',Po='hashchange',Qo={9:1,49:1},Ro=136413184,So='active',To='completed';var _,Sg,Ng,Fg=-1;Tg();Vg(1,null,{},o);_.n=Vo;_.o=function(){return this.hb};_.p=Wo;_.q=function(){var a;return jh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.n(a)};_.hashCode=function(){return this.p()};_.toString=function(){return this.q()};var bd,cd,dd;Vg(51,1,{},kh);_.G=function(a){var b;b=new kh;b.e=4;a>1?(b.c=ph(this,a-1)):(b.c=this);return b};_.H=function(){ih(this);return this.b};_.I=function(){return jh(this)};_.J=function(){ih(this);return this.i};_.K=function(){return (this.e&4)!=0};_.L=function(){return (this.e&1)!=0};_.q=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(ih(this),this.k)};_.e=0;_.g=0;var hh=1;var de=mh(1);var Wd=mh(51);Vg(79,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var rd=mh(79);Vg(36,1,so,G);_.r=function(){return this.a.u(),null};var pd=mh(36);Vg(80,1,{},H);var qd=mh(80);var I;Vg(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var sd=mh(43);Vg(208,1,uo);_.q=function(){var a;return jh(this.hb)+'@'+(a=r(this)>>>0,a.toString(16))};var vd=mh(208);Vg(20,208,uo,U);_.s=function(){R(this)};_.t=Uo;_.a=false;_.d=0;var td=mh(20);Vg(133,1,{240:1},bb);var ud=mh(133);Vg(17,208,{9:1,17:1},kb);_.s=function(){cb(this)};_.t=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var xd=mh(17);Vg(113,1,xo,lb);_.u=function(){db(this.a)};var wd=mh(113);Vg(18,208,{9:1,18:1},xb,yb);_.s=function(){mb(this)};_.t=function(){return 1==(this.c&7)};_.c=0;var Cd=mh(18);Vg(114,1,Ao,zb);_.u=function(){Q(this.a)};var yd=mh(114);Vg(115,1,xo,Ab);_.u=function(){ob(this.a)};var zd=mh(115);Vg(116,1,xo,Bb);_.u=function(){rb(this.a)};var Ad=mh(116);Vg(117,1,{},Cb);_.v=function(a){pb(this.a,a)};var Bd=mh(117);Vg(132,1,{},Fb);_.a=0;_.b=0;_.c=0;var Dd=mh(132);Vg(153,1,uo,Hb);_.s=function(){Gb(this)};_.t=Uo;_.a=false;var Ed=mh(153);Vg(61,208,{9:1,61:1},Mb);_.s=function(){Ib(this)};_.t=function(){return 2==(3&this.a)};_.a=0;var Fd=mh(61);Vg(135,1,{},Yb);_.q=function(){var a;return ih(Gd),Gd.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.a=0;var Nb;var Gd=mh(135);Vg(101,1,{});var Jd=mh(101);Vg(81,1,{},cc);_.v=function(a){ac(this.a,a)};var Hd=mh(81);Vg(82,1,xo,dc);_.u=function(){bc(this.a,this.b)};var Id=mh(82);Vg(102,101,{});var Kd=mh(102);Vg(16,1,uo,kc);_.s=function(){fc(this)};_.t=function(){return this.i<0};_.q=function(){var a;return ih(Md),Md.k+'@'+(a=vj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Md=mh(16);Vg(112,1,xo,lc);_.u=function(){ic(this.a)};var Ld=mh(112);Vg(5,1,{3:1,5:1});_.A=function(a){return new Error(a)};_.B=function(){return this.f};_.C=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=jh(this.hb),c==null?a:a+': '+c);nc(this,pc(this.A(b)));Rc(this)};_.q=function(){return oc(this,this.B())};_.e=Bo;_.g=true;var he=mh(5);Vg(11,5,{3:1,11:1,5:1});var Zd=mh(11);Vg(8,11,Do);var ee=mh(8);Vg(52,8,Do);var ae=mh(52);Vg(73,52,Do);var Qd=mh(73);Vg(35,73,{35:1,3:1,11:1,8:1,5:1},uc);_.B=function(){tc(this);return this.c};_.D=function(){return md(this.b)===md(rc)?null:this.b};var rc;var Nd=mh(35);var Od=mh(0);Vg(194,1,{});var Pd=mh(194);var wc=0,xc=0,yc=-1;Vg(100,194,{},Mc);var Ic;var Rd=mh(100);var Pc;Vg(205,1,{});var Td=mh(205);Vg(74,205,{},Tc);var Sd=mh(74);var ah,bh;Vg(71,1,{68:1});_.q=Uo;var Ud=mh(71);bd={3:1,69:1,31:1};var Vd=mh(69);Vg(41,1,{3:1,41:1});var ce=mh(41);cd={3:1,31:1,41:1};var Xd=mh(204);Vg(33,1,{3:1,31:1,33:1});_.n=Vo;_.p=Wo;_.q=function(){return this.a!=null?this.a:''+this.b};_.b=0;var Yd=mh(33);Vg(75,8,Do,vh);var $d=mh(75);Vg(32,41,{3:1,31:1,32:1,41:1},wh);_.n=function(a){return gd(a,32)&&a.a==this.a};_.p=Uo;_.q=function(){return ''+this.a};_.a=0;var _d=mh(32);var yh;Vg(272,1,{});Vg(77,52,Do,Bh);_.A=function(a){return new TypeError(a)};var be=mh(77);dd={3:1,68:1,31:1,2:1};var ge=mh(2);Vg(72,71,{68:1},Hh);var fe=mh(72);Vg(276,1,{});Vg(54,8,Do,Ih);var ie=mh(54);Vg(206,1,{39:1});_.M=$o;_.Q=function(){return new Ti(this,0)};_.R=function(){return new bj(null,this.Q())};_.O=function(a){throw Hg(new Ih('Add not supported on this collection'))};_.q=function(){var a,b,c;c=new Vi('[',']');for(b=this.N();b.T();){a=b.U();Ui(c,a===this?'(this Collection)':a==null?Eo:Zg(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var je=mh(206);Vg(209,1,{192:1});_.n=function(a){var b,c,d;if(a===this){return true}if(!gd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Wh((new Th(d)).a);c.b;){b=Vh(c);if(!Lh(this,b)){return false}}return true};_.p=function(){return li(new Th(this))};_.q=function(){var a,b,c;c=new Vi('{','}');for(b=new Wh((new Th(this)).a);b.b;){a=Vh(b);Ui(c,Mh(this,a.W())+'='+Mh(this,a.X()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ue=mh(209);Vg(118,209,{192:1});var me=mh(118);Vg(210,206,{39:1,221:1});_.Q=function(){return new Ti(this,1)};_.n=function(a){var b;if(a===this){return true}if(!gd(a,23)){return false}b=a;if(Rh(b.a)!=this.P()){return false}return Jh(this,b)};_.p=function(){return li(this)};var ve=mh(210);Vg(23,210,{23:1,39:1,221:1},Th);_.N=function(){return new Wh(this.a)};_.P=Yo;var le=mh(23);Vg(24,1,{},Wh);_.S=Xo;_.U=function(){return Vh(this)};_.T=Zo;_.b=false;var ke=mh(24);Vg(207,206,{39:1,218:1});_.Q=function(){return new Ti(this,16)};_.V=function(a,b){throw Hg(new Ih('Add not supported on this list'))};_.O=function(a){this.V(this.P(),a);return true};_.n=function(a){var b,c,d,e,f;if(a===this){return true}if(!gd(a,13)){return false}f=a;if(this.P()!=f.a.length){return false}e=new ki(f);for(c=new ki(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(md(b)===md(d)||b!=null&&p(b,d))){return false}}return true};_.p=function(){return mi(this)};_.N=function(){return new Xh(this)};var oe=mh(207);Vg(99,1,{},Xh);_.S=Xo;_.T=function(){return this.a<this.b.a.length};_.U=function(){return ci(this.b,this.a++)};_.a=0;var ne=mh(99);Vg(55,206,{39:1},Yh);_.N=function(){var a;a=new Wh((new Th(this.a)).a);return new Zh(a)};_.P=Yo;var qe=mh(55);Vg(121,1,{},Zh);_.S=Xo;_.T=function(){return this.a.b};_.U=function(){var a;a=Vh(this.a);return a.X()};var pe=mh(121);Vg(119,1,Go);_.n=function(a){var b;if(!gd(a,40)){return false}b=a;return ni(this.a,b.W())&&ni(this.b,b.X())};_.W=Uo;_.X=Zo;_.p=function(){return Oi(this.a)^Oi(this.b)};_.Y=function(a){var b;b=this.b;this.b=a;return b};_.q=function(){return this.a+'='+this.b};var re=mh(119);Vg(120,119,Go,$h);var se=mh(120);Vg(211,1,Go);_.n=function(a){var b;if(!gd(a,40)){return false}b=a;return ni(this.b.value[0],b.W())&&ni(Ki(this),b.X())};_.p=function(){return Oi(this.b.value[0])^Oi(Ki(this))};_.q=function(){return this.b.value[0]+'='+Ki(this)};var te=mh(211);Vg(13,207,{3:1,13:1,39:1,218:1},ii,ji);_.V=function(a,b){pj(this.a,a,b)};_.O=function(a){return ai(this,a)};_.M=function(a){bi(this,a)};_.N=function(){return new ki(this)};_.P=function(){return this.a.length};var xe=mh(13);Vg(19,1,{},ki);_.S=Xo;_.T=function(){return this.a<this.c.a.length};_.U=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var we=mh(19);Vg(37,118,{3:1,37:1,192:1},oi);var ye=mh(37);Vg(59,1,{},ui);_.M=$o;_.N=function(){return new vi(this)};_.b=0;var Ae=mh(59);Vg(60,1,{},vi);_.S=Xo;_.U=function(){return this.d=this.a[this.c++],this.d};_.T=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ze=mh(60);var yi;Vg(57,1,{},Ii);_.M=$o;_.N=function(){return new Ji(this)};_.b=0;_.c=0;var De=mh(57);Vg(58,1,{},Ji);_.S=Xo;_.U=function(){return this.c=this.a,this.a=this.b.next(),new Li(this.d,this.c,this.d.c)};_.T=function(){return !this.a.done};var Be=mh(58);Vg(134,211,Go,Li);_.W=function(){return this.b.value[0]};_.X=function(){return Ki(this)};_.Y=function(a){return Gi(this.a,this.b.value[0],a)};_.c=0;var Ce=mh(134);Vg(137,1,{});_.S=function(a){Qi(this,a)};_.Z=function(){return this.d};_.$=function(){return this.e};_.d=0;_.e=0;var Fe=mh(137);Vg(62,137,{});var Ee=mh(62);Vg(25,1,{},Ti);_.Z=Uo;_.$=function(){Si(this);return this.c};_.S=function(a){Si(this);this.d.S(a)};_._=function(a){Si(this);if(this.d.T()){a.v(this.d.U());return true}return false};_.a=0;_.c=0;var Ge=mh(25);Vg(53,1,{},Vi);_.q=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var He=mh(53);Vg(136,1,{});_.c=false;var Qe=mh(136);Vg(28,136,{241:1,28:1},bj);var Pe=mh(28);Vg(139,62,{},fj);_._=function(a){this.b=false;while(!this.b&&this.c._(new gj(this,a)));return this.b};_.b=false;var Je=mh(139);Vg(142,1,{},gj);_.v=function(a){ej(this.a,this.b,a)};var Ie=mh(142);Vg(138,62,{},hj);_._=function(a){return this.a._(new ij(a))};var Le=mh(138);Vg(141,1,{},ij);_.v=function(a){this.a.v(Am(new Bm,a))};var Ke=mh(141);Vg(140,1,{},kj);_.v=function(a){jj(this,a)};var Me=mh(140);Vg(143,1,{},lj);_.v=function(a){};var Ne=mh(143);Vg(144,1,{},nj);_.v=function(a){mj(this,a)};var Oe=mh(144);Vg(274,1,{});Vg(215,1,{});var Re=mh(215);Vg(271,1,{});var uj=0;var wj,xj=0,yj;Vg(885,1,{});Vg(212,1,{});var Se=mh(212);Vg(242,$wnd.Function,{},Mj);_.bb=function(a){Lj(this.a,this.b,a)};Vg(7,33,{3:1,31:1,33:1,7:1},vk);var $j,_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk;var Te=nh(7,wk);var xk;Vg(243,$wnd.Function,{},zk);_.F=function(a){return Gb(xk),xk=null,null};Vg(216,212,{});var Af=mh(216);Vg(166,216,{});_.d=0;var Ef=mh(166);Vg(167,166,uo,Gk);_.s=_o;_.n=Vo;_.p=Wo;_.t=ap;_.q=function(){var a;return ih(af),af.k+'@'+(a=vj(this)>>>0,a.toString(16))};var Dk=0;var af=mh(167);Vg(168,1,xo,Hk);_.u=function(){Ek(this.a)};var Ue=mh(168);Vg(169,1,so,Ik);_.r=function(){return gh(),S((Hm(),Em).b).a>0?true:false};var Ve=mh(169);Vg(170,1,Ao,Jk);_.u=function(){Bk(this.a)};var We=mh(170);Vg(171,1,so,Kk);_.r=function(){return Ck(this.a)};var Xe=mh(171);Vg(217,212,{});var zf=mh(217);Vg(186,217,{});_.c=0;var Df=mh(186);Vg(187,186,uo,Pk);_.s=bp;_.n=Vo;_.p=Wo;_.t=cp;_.q=function(){var a;return ih(_e),_e.k+'@'+(a=vj(this)>>>0,a.toString(16))};var Nk=0;var _e=mh(187);Vg(188,1,xo,Qk);_.u=dp;var Ye=mh(188);Vg(189,1,Ao,Rk);_.u=function(){Mk(this.a)};var Ze=mh(189);Vg(190,1,so,Sk);_.r=function(){var a,b;return this.a.c=0,yk(),a=S((Hm(),Em).e).a,b='item'+(a==1?'':'s'),Kj('span',Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,['todo-count'])),[Kj('strong',null,[a]),' '+b+' left'])};var $e=mh(190);Vg(158,212,{});_.e='';var Mf=mh(158);Vg(159,158,{});_.d=0;var Gf=mh(159);Vg(160,159,uo,cl);_.s=_o;_.n=Vo;_.p=Wo;_.t=ap;_.q=function(){var a;return ih(gf),gf.k+'@'+(a=vj(this)>>>0,a.toString(16))};var Yk=0;var gf=mh(160);Vg(161,1,xo,dl);_.u=function(){Zk(this.a)};var bf=mh(161);Vg(163,1,so,el);_.r=function(){return Xk(this.a)};var cf=mh(163);Vg(164,1,xo,fl);_.u=function(){Tk(this.a)};var df=mh(164);Vg(165,1,xo,gl);_.u=function(){_k(this.a,this.b)};var ef=mh(165);Vg(162,1,Ao,hl);_.u=function(){Bk(this.a)};var ff=mh(162);Vg(214,212,{});_.i=false;var Of=mh(214);Vg(173,214,{});_.f=0;var If=mh(173);Vg(174,173,uo,Cl);_.s=function(){fc(this.e)};_.n=Vo;_.p=Wo;_.t=function(){return this.e.i<0};_.q=function(){var a;return ih(sf),sf.k+'@'+(a=vj(this)>>>0,a.toString(16))};var sl=0;var sf=mh(174);Vg(175,1,xo,Dl);_.u=function(){tl(this.a)};var hf=mh(175);Vg(178,1,so,El);_.r=function(){return rl(this.a)};var jf=mh(178);Vg(63,1,xo,Fl);_.u=function(){Bl(this.a,Qm(this.b))};var kf=mh(63);Vg(176,1,so,Gl);_.r=function(){return vl(this.a)};var lf=mh(176);Vg(64,1,xo,Hl);_.u=function(){ml(this.a,this.b)};var mf=mh(64);Vg(179,1,xo,Il);_.u=function(){ll(this.a,this.b)};var nf=mh(179);Vg(180,1,xo,Jl);_.u=function(){Al(this.a,this.b);Xn((Hm(),Gm),null)};var of=mh(180);Vg(181,1,xo,Kl);_.u=function(){il(this.a,this.b)};var pf=mh(181);Vg(177,1,Ao,Ll);_.u=function(){ql(this.a)};var qf=mh(177);Vg(182,1,xo,Ml);_.u=function(){nl(this.a)};var rf=mh(182);Vg(213,212,{});var Qf=mh(213);Vg(146,213,{});_.c=0;var Kf=mh(146);Vg(147,146,uo,Rl);_.s=bp;_.n=Vo;_.p=Wo;_.t=cp;_.q=function(){var a;return ih(wf),wf.k+'@'+(a=vj(this)>>>0,a.toString(16))};var Pl=0;var wf=mh(147);Vg(148,1,xo,Sl);_.u=dp;var tf=mh(148);Vg(149,1,Ao,Tl);_.u=function(){Mk(this.a)};var uf=mh(149);Vg(150,1,so,Ul);_.r=function(){var a;return this.a.c=0,yk(),Kj('div',null,[Kj('div',null,[Kj(Oo,Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,[Oo])),[Kj('h1',null,['todos']),(new sm).a]),S((Hm(),Em).c)?null:Kj('section',Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,[Oo])),[Kj(No,Uj(Xj(Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,['toggle-all'])),(uk(),_j)),Xg(Cm.prototype.db,Cm,[])),null),Kj('ul',Nj(new $wnd.Object,$c(Uc(ge,1),to,2,6,['todo-list'])),(a=aj(Pi(_i(S(Gm.c).R())),new ii),hi(a,Zc(a.a.length))))]),S(Em.c)?null:(new Wl).a])])};var vf=mh(150);Vg(247,$wnd.Function,{},Vl);_.fb=function(a){Hn((Hm(),Fm))};Vg(152,1,{},Wl);var xf=mh(152);Vg(172,1,{},Xl);var yf=mh(172);Vg(248,$wnd.Function,{},Yl);_.gb=function(a){return new _l(a)};var Zl;Vg(156,$wnd.React.Component,{},_l);Ug(Sg[1],_);_.componentWillUnmount=function(){Ak(this.a)};_.render=function(){return Fk(this.a)};_.shouldComponentUpdate=ep;var Bf=mh(156);Vg(258,$wnd.Function,{},am);_.gb=function(a){return new dm(a)};var bm;Vg(183,$wnd.React.Component,{},dm);Ug(Sg[1],_);_.componentWillUnmount=function(){Lk(this.a)};_.render=function(){return Ok(this.a)};_.shouldComponentUpdate=fp;var Cf=mh(183);Vg(246,$wnd.Function,{},em);_.gb=function(a){return new hm(a)};var fm;Vg(154,$wnd.React.Component,{},hm);Ug(Sg[1],_);_.componentWillUnmount=function(){Ak(this.a)};_.render=function(){return al(this.a)};_.shouldComponentUpdate=ep;var Ff=mh(154);Vg(257,$wnd.Function,{},im);_.gb=function(a){return new lm(a)};var jm;Vg(157,$wnd.React.Component,{},lm);Ug(Sg[1],_);_.componentDidUpdate=function(a){yl(this.a)};_.componentWillUnmount=function(){pl(this.a)};_.render=function(){return zl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Hf=mh(157);Vg(239,$wnd.Function,{},mm);_.gb=function(a){return new pm(a)};var nm;Vg(123,$wnd.React.Component,{},pm);Ug(Sg[1],_);_.componentWillUnmount=function(){Lk(this.a)};_.render=function(){return Ql(this.a)};_.shouldComponentUpdate=fp;var Jf=mh(123);Vg(244,$wnd.Function,{},qm);_.eb=function(a){Uk(this.a,a)};Vg(245,$wnd.Function,{},rm);_.db=function(a){$k(this.a,a)};Vg(151,1,{},sm);var Lf=mh(151);Vg(255,$wnd.Function,{},tm);_.db=function(a){ul(this.a,a)};Vg(249,$wnd.Function,{},um);_.db=function(a){kn(this.a)};Vg(251,$wnd.Function,{},vm);_.fb=function(a){wl(this.a,this.b)};Vg(252,$wnd.Function,{},wm);_.fb=function(a){ol(this.a)};Vg(253,$wnd.Function,{},xm);_.v=function(a){jl(this.a,a)};Vg(254,$wnd.Function,{},ym);_.cb=function(a){xl(this.a,this.b)};Vg(256,$wnd.Function,{},zm);_.eb=function(a){kl(this.a,this.b,a)};Vg(155,1,{},Bm);var Nf=mh(155);Vg(238,$wnd.Function,{},Cm);_.db=function(a){var b;b=a.target;Ln((Hm(),Fm),b.checked)};Vg(67,1,{},Dm);var Pf=mh(67);var Em,Fm,Gm;Vg(124,1,{});var ug=mh(124);Vg(125,124,Qo,Um);_.s=_o;_.n=Vo;_.p=Wo;_.t=ap;_.w=gp;_.q=function(){var a;return ih(Yf),Yf.k+'@'+(a=vj(this)>>>0,a.toString(16))};var Yf=mh(125);Vg(126,1,xo,Vm);_.u=function(){Om(this.a)};var Rf=mh(126);Vg(128,1,Ao,Wm);_.u=function(){Jm(this.a)};var Sf=mh(128);Vg(129,1,Ao,Xm);_.u=function(){Km(this.a)};var Tf=mh(129);Vg(130,1,xo,Ym);_.u=function(){Im(this.a,this.b)};var Uf=mh(130);Vg(131,1,xo,Zm);_.u=function(){Rm(this.a)};var Vf=mh(131);Vg(56,1,xo,$m);_.u=function(){Nm(this.a)};var Wf=mh(56);Vg(127,1,so,_m);_.r=function(){var a;return a=(dh(),bh).location.hash,null==a?'':a.substr(1)};var Xf=mh(127);Vg(44,1,{44:1});_.d=false;var Cg=mh(44);Vg(45,44,{9:1,49:1,45:1,44:1},ln);_.s=_o;_.n=function(a){return dn(this,a)};_.p=function(){return this.c.d};_.t=ap;_.w=gp;_.q=function(){var a;return ih(mg),mg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var an=0;var mg=mh(45);Vg(184,1,xo,mn);_.u=function(){bn(this.a)};var Zf=mh(184);Vg(185,1,xo,nn);_.u=function(){gn(this.a)};var $f=mh(185);Vg(42,102,{42:1});var xg=mh(42);Vg(103,42,{9:1,49:1,42:1},wn);_.s=function(){fc(this.f)};_.n=Vo;_.p=Wo;_.t=function(){return this.f.i<0};_.w=function(a){jc(this.f,a)};_.q=function(){var a;return ih(hg),hg.k+'@'+(a=vj(this)>>>0,a.toString(16))};var hg=mh(103);Vg(105,1,xo,xn);_.u=function(){pn(this.a)};var _f=mh(105);Vg(104,1,xo,yn);_.u=function(){tn(this.a)};var ag=mh(104);Vg(110,1,xo,zn);_.u=function(){_b(this.a,this.b,true)};var bg=mh(110);Vg(111,1,so,An);_.r=function(){return on(this.a,this.c,this.b)};_.b=false;var cg=mh(111);Vg(106,1,so,Bn);_.r=function(){return un(this.a)};var dg=mh(106);Vg(107,1,so,Cn);_.r=function(){return xh(Mg(Zi(sn(this.a))))};var eg=mh(107);Vg(108,1,so,Dn);_.r=function(){return xh(Mg(Zi($i(sn(this.a),new ko))))};var fg=mh(108);Vg(109,1,so,En);_.r=function(){return vn(this.a)};var gg=mh(109);Vg(87,1,{});var Bg=mh(87);Vg(88,87,Qo,Mn);_.s=function(){fc(this.a)};_.n=Vo;_.p=Wo;_.t=function(){return this.a.i<0};_.w=function(a){jc(this.a,a)};_.q=function(){var a;return ih(lg),lg.k+'@'+(a=vj(this)>>>0,a.toString(16))};var lg=mh(88);Vg(89,1,xo,Nn);_.u=function(){In(this.a,this.b)};_.b=false;var ig=mh(89);Vg(90,1,xo,On);_.u=function(){Tm(this.b,this.a)};var jg=mh(90);Vg(91,1,xo,Pn);_.u=function(){Jn(this.a)};var kg=mh(91);Vg(92,1,{});var Eg=mh(92);Vg(93,92,Qo,Yn);_.s=function(){fc(this.g)};_.n=Vo;_.p=Wo;_.t=function(){return this.g.i<0};_.w=function(a){jc(this.g,a)};_.q=function(){var a;return ih(sg),sg.k+'@'+(a=vj(this)>>>0,a.toString(16))};var sg=mh(93);Vg(94,1,xo,Zn);_.u=function(){Sn(this.a)};var ng=mh(94);Vg(95,1,so,$n);_.r=function(){var a;return a=Qm(this.a.i),Dh(So,a)?(ho(),eo):Dh(To,a)?(ho(),go):(ho(),fo)};var og=mh(95);Vg(96,1,so,_n);_.r=function(){return Un(this.a)};var pg=mh(96);Vg(97,1,Ao,ao);_.u=function(){Vn(this.a)};var qg=mh(97);Vg(98,1,Ao,bo);_.u=function(){Wn(this.a)};var rg=mh(98);Vg(122,1,{},co);_.handleEvent=function(a){Lm(this.a,a)};var tg=mh(122);Vg(34,33,{3:1,31:1,33:1,34:1},io);var eo,fo,go;var vg=nh(34,jo);Vg(83,1,{},ko);_.ab=function(a){return !fn(a)};var wg=mh(83);Vg(85,1,{},lo);_.ab=function(a){return fn(a)};var yg=mh(85);Vg(86,1,{},mo);_.v=function(a){rn(this.a,a)};var zg=mh(86);Vg(84,1,{},no);_.v=function(a){Gn(this.a,a)};_.a=false;var Ag=mh(84);Vg(76,1,{},oo);_.ab=function(a){return Rn(this.a,a)};var Dg=mh(76);var od=oh('D');var po=(zc(),Cc);var gwtOnLoad=gwtOnLoad=Qg;Og(_g);Rg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();