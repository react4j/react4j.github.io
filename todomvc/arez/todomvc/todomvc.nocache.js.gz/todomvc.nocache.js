function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='B3C2A756447166AADED976ED14E8BE63',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'B3C2A756447166AADED976ED14E8BE63';function o(){}
function wh(){}
function sh(){}
function Gb(){}
function Gj(){}
function Hj(){}
function pc(){}
function dd(){}
function ld(){}
function rk(){}
function gl(){}
function gm(){}
function dm(){}
function km(){}
function om(){}
function sm(){}
function wm(){}
function Om(){}
function Fn(){}
function bo(){}
function co(){}
function So(){}
function jd(a){hd()}
function Ch(){Ch=sh}
function Di(){ui(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function jc(a){this.a=a}
function kc(a){this.a=a}
function lc(a){this.a=a}
function nc(a){this.a=a}
function oc(a){this.a=a}
function qc(a){this.a=a}
function yc(a){this.a=a}
function Ec(a){this.a=a}
function Ej(a){this.a=a}
function Jj(a){this.a=a}
function Rh(a){this.a=a}
function ai(a){this.a=a}
function mi(a){this.a=a}
function ri(a){this.a=a}
function si(a){this.a=a}
function qi(a){this.b=a}
function Fi(a){this.c=a}
function fl(a){this.a=a}
function hl(a){this.a=a}
function il(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function yl(a){this.a=a}
function Ql(a){this.a=a}
function Rl(a){this.a=a}
function Sl(a){this.a=a}
function Xl(a){this.a=a}
function $l(a){this.a=a}
function am(a){this.a=a}
function bm(a){this.a=a}
function cm(a){this.a=a}
function Am(a){this.a=a}
function Bm(a){this.a=a}
function Dm(a){this.a=a}
function Em(a){this.a=a}
function Gm(a){this.a=a}
function Hm(a){this.a=a}
function dn(a){this.a=a}
function en(a){this.a=a}
function pn(a){this.a=a}
function qn(a){this.a=a}
function tn(a){this.a=a}
function un(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function In(a){this.a=a}
function Sn(a){this.a=a}
function Tn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function Wn(a){this.a=a}
function eo(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function Yo(){lk(this.a)}
function dp(){nk(this.a)}
function Uo(){Ac(this.c)}
function _o(){Ac(this.b)}
function Pi(){this.a=Yi()}
function bj(){this.a=Yi()}
function qk(){this.j=jk++}
function Fj(a,b){a.a=b}
function gk(a,b){a.key=b}
function $j(a,b){Zj(a,b)}
function yn(a,b){_m(b,a)}
function Oo(a){fj(this,a)}
function Ro(a){Vh(this,a)}
function eb(a){Sb((J(),a))}
function fb(a){Tb((J(),a))}
function ib(a){Ub((J(),a))}
function w(a){--a.e;D(a)}
function Bc(a){!!a&&a.A()}
function tc(a,b){ii(a.b,b)}
function xn(a,b){hn(a.b,b)}
function Ij(a,b){yj(a.a,b)}
function rb(a,b){a.b=ij(b)}
function Jb(a){this.c=ij(a)}
function uc(){this.b=new Ji}
function J(){J=sh;I=new F}
function Lc(){Lc=sh;Kc=new o}
function ad(){ad=sh;_c=new dd}
function Ui(){Ui=sh;Ti=Wi()}
function cp(){lb(this.a.a)}
function dl(a){lb(a.b);R(a.a)}
function cc(a){R(a.a);ab(a.b)}
function V(a){Ad(a,8)&&a.v()}
function dh(a){return a.e}
function Yh(a,b){return a===b}
function Bl(a,b){return a.f=b}
function xi(a,b){return a.a[b]}
function Lo(){return this.a}
function Qo(){return this.b}
function Vo(){return this.c.c}
function ap(){return this.b.c}
function No(){return Rj(this)}
function bi(a){Jc.call(this,a)}
function jm(a){ck.call(this,a)}
function nm(a){ck.call(this,a)}
function rm(a){ck.call(this,a)}
function vm(a){ck.call(this,a)}
function zm(a){ck.call(this,a)}
function Fl(a){jn((Um(),Rm),a)}
function pl(a){lb(a.a);ab(a.b)}
function Wm(a){ab(a.b);ab(a.a)}
function Wh(){Fc(this);this.G()}
function Po(){return ki(this.a)}
function Mo(a){return this===a}
function Wo(){return this.c.i<0}
function bp(){return this.b.i<0}
function Zo(){return pk(this.a)}
function Xo(){return J(),J(),I}
function md(a,b){return Kh(a,b)}
function Nj(a,b){a.splice(b,1)}
function jj(a,b){while(a.cb(b));}
function rc(a,b,c){hi(a.b,b,c)}
function yj(a,b){Fj(a,xj(a.a,b))}
function Mb(a){Nb(a);!a.d&&Qb(a)}
function Fh(a){Eh(a);return a.k}
function ec(a){gb(a.b);return a.e}
function Zm(a){gb(a.a);return a.d}
function Mn(a){gb(a.d);return a.f}
function xj(a,b){a.R(b);return a}
function tk(a,b){a.ref=b;return a}
function mc(a,b){this.a=a;this.b=b}
function zc(a,b){this.a=a;this.b=b}
function Ph(a,b){this.a=a;this.b=b}
function ti(a,b){this.a=a;this.b=b}
function Bj(a,b){this.a=a;this.b=b}
function ki(a){return a.a.b+a.b.b}
function $i(a,b){return a.a.get(b)}
function rd(a){return new Array(a)}
function Yi(){Ui();return new Ti}
function bb(a){J();Tb(a);a.e=-2}
function fc(a){dc(a,(gb(a.b),a.e))}
function Sc(){Sc=sh;!!(hd(),gd)}
function lh(){jh==null&&(jh=[])}
function $c(){Pc!=0&&(Pc=0);Rc=-1}
function bl(a,b){Ph.call(this,a,b)}
function xl(a,b){this.a=a;this.b=b}
function Ul(a,b){this.a=a;this.b=b}
function Vl(a,b){this.a=a;this.b=b}
function Wl(a,b){this.a=a;this.b=b}
function Yl(a,b){this.a=a;this.b=b}
function Zl(a,b){this.a=a;this.b=b}
function fk(a,b){this.a=a;this.b=b}
function Fm(a,b){this.a=a;this.b=b}
function Im(a,b){this.a=a;this.b=b}
function Jm(a,b){this.a=a;this.b=b}
function rn(a,b){this.a=a;this.b=b}
function Gn(a,b){this.a=a;this.b=b}
function Hn(a,b){this.b=a;this.a=b}
function _n(a,b){Ph.call(this,a,b)}
function Lj(a,b,c){a.splice(b,0,c)}
function uk(a,b){a.href=b;return a}
function $h(a,b){a.a+=''+b;return a}
function Ek(a,b){a.value=b;return a}
function Km(a){return Lm(new Nm,a)}
function gi(a){return !a?null:a.$()}
function Ob(a){return !a.d?a:Ob(a.d)}
function Cd(a){return typeof a===jo}
function Fd(a){return a==null?null:a}
function hj(a){return a!=null?r(a):0}
function Zc(a){$wnd.clearTimeout(a)}
function em(){this.a=ik((im(),hm))}
function fm(){this.a=ik((mm(),lm))}
function Cm(){this.a=ik((qm(),pm))}
function Nm(){this.a=ik((um(),tm))}
function Pm(){this.a=ik((ym(),xm))}
function $m(a){_m(a,(gb(a.a),!a.d))}
function qb(a){J();pb(a);tb(a,2,true)}
function ui(a){a.a=od(Ge,no,1,0,5,1)}
function ji(a){a.a=new Pi;a.b=new bj}
function jb(a){this.c=new Di;this.b=a}
function Eb(a){this.d=ij(a);this.b=100}
function Cj(a,b){a.B(Mm(Km(b.c.e),b))}
function Mj(a,b){Kj(b,0,a,0,b.length)}
function xc(a,b){vc(a,b,false);fb(a.d)}
function A(a,b,c){t(a,new G(b),c,null)}
function td(a,b,c){return {l:a,m:b,h:c}}
function Xh(a,b){return a.charCodeAt(b)}
function Rj(a){return a.$H||(a.$H=++Qj)}
function W(a){return !(!!a&&1==(a.c&7))}
function To(){return S((Um(),Rm).b).a>0}
function gb(a){var b;Pb((J(),b=Kb,b),a)}
function Zj(a,b){for(var c in a){b(c)}}
function zk(a,b){a.onBlur=b;return a}
function vk(a,b){a.onClick=b;return a}
function Ak(a,b){a.onChange=b;return a}
function xk(a,b){a.checked=b;return a}
function Bk(a,b){a.onKeyDown=b;return a}
function wk(a){a.autoFocus=true;return a}
function Eh(a){if(a.k!=null){return}Mh(a)}
function Ad(a,b){return a!=null&&yd(a,b)}
function Ed(a){return typeof a==='string'}
function Bd(a){return typeof a==='boolean'}
function Vj(){Vj=sh;Sj=new o;Uj=new o}
function Ji(){this.a=new Pi;this.b=new bj}
function Jc(a){this.f=a;Fc(this);this.G()}
function wj(a,b){rj.call(this,a);this.a=b}
function yk(a,b){a.defaultValue=b;return a}
function Gc(a,b){a.e=b;b!=null&&Pj(b,wo,a)}
function fj(a,b){while(a.W()){Ij(b,a.X())}}
function Lm(a,b){return gk(a.a,ij(''+b)),a}
function u(a,b){return new wb(ij(a),null,b)}
function Ri(a,b){var c;c=a[Bo];c.call(a,b)}
function Pj(b,c,d){try{b[c]=d}catch(a){}}
function Ib(a){if(a.b){a.b=false;nb(a.c.a)}}
function Hb(a){if(!a.a){a.a=true;a.b=false}}
function T(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function P(){this.a=od(Ge,no,1,100,5,1)}
function Uh(){Uh=sh;Th=od(Ce,no,30,256,0,1)}
function zh(){zh=sh;yh=$wnd.window.document}
function gc(a){A((J(),J(),I),new nc(a),to)}
function bn(a){A((J(),J(),I),new en(a),to)}
function zn(a){A((J(),J(),I),new In(a),to)}
function wc(a,b){tc(b.C(),a);Ad(b,8)&&b.v()}
function C(a,b){Z(a.f,((b.c&lo)>>15)-1,b.f)}
function Fk(a,b){a.onDoubleClick=b;return a}
function Mm(a,b){a.a.props['a']=b;return a.a}
function vi(a,b){a.a[a.a.length]=b;return true}
function Fc(a){a.g&&a.e!==vo&&a.G();return a}
function Ih(a){var b;b=Hh(a);Oh(a,b);return b}
function Hl(a){lb(a.b);R(a.d);ab(a.c);ab(a.a)}
function nn(a){return Sh(S(a.e).a-S(a.a).a)}
function Tc(a,b,c){return a.apply(b,c);var d}
function ej(a,b,c){this.a=a;this.b=b;this.c=c}
function Z(a,b,c){ij(c).b=true;K(a.a[b],ij(c))}
function ql(a,b){A((J(),J(),I),new xl(a,b),to)}
function Il(a,b){A((J(),J(),I),new Zl(a,b),to)}
function Ll(a,b){A((J(),J(),I),new Wl(a,b),to)}
function Ml(a,b){A((J(),J(),I),new Vl(a,b),to)}
function Nl(a,b){A((J(),J(),I),new Ul(a,b),to)}
function jn(a,b){A((J(),J(),I),new rn(a,b),to)}
function Cn(a,b){A((J(),J(),I),new Hn(a,b),to)}
function Dn(a,b){A((J(),J(),I),new Gn(a,b),to)}
function ln(a){Vh(new ri(a.g),new yc(a));ji(a.g)}
function Db(a){while(true){if(!Cb(a)){break}}}
function sn(a,b){this.a=a;this.c=b;this.b=false}
function kj(a,b){this.e=a;this.d=(b&64)!=0?b|ko:b}
function F(){this.f=new $;this.a=new Eb(this.f)}
function hd(){hd=sh;var a;!kd();a=new ld;gd=a}
function uj(a){qj(a);return new wj(a,new Dj(a.a))}
function rl(a,b){var c;c=b.target;sl(a,c.value)}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function ed(a,b){!a&&(a=[]);a[a.length]=b;return a}
function zi(a,b){var c;c=a.a[b];Nj(a.a,b);return c}
function oi(a){var b;b=a.a.X();a.b=ni(a);return b}
function lj(a){if(!a.d){a.d=a.b.Q();a.c=a.b.S()}}
function Fb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function zj(a,b,c){if(a.a.db(c)){a.b=true;b.B(c)}}
function Bi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function li(a,b){if(b){return ei(a.a,b)}return false}
function Zi(a,b){return !(a.a.get(b)===undefined)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function qd(a){return Array.isArray(a)&&a.xb===wh}
function zd(a){return !Array.isArray(a)&&a.xb===wh}
function mn(a){return Ch(),0==S(a.e).a?true:false}
function Jn(a){return Yh(Ko,a)||Yh(Ho,a)||Yh('',a)}
function Ln(a){lb(a.e);lb(a.a);R(a.b);R(a.c);ab(a.d)}
function pj(a){if(!a.b){qj(a);a.c=true}else{pj(a.b)}}
function tj(a,b){qj(a);return new wj(a,new Aj(b,a.a))}
function dc(a,b){A((J(),J(),I),new mc(a,b),75505664)}
function sl(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.b)}}
function _m(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function Ol(a,b){var c;c=a.g;if(b!=c){a.g=b;fb(a.a)}}
function bc(a){var b;T(a.a);b=S(a.a);Yh(a.g,b)&&hc(a,b)}
function hb(a){var b;J();!!Kb&&!!Kb.e&&Pb((b=Kb,b),a)}
function Dk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ij(a){if(a==null){throw dh(new Wh)}return a}
function Yj(){if(Tj==256){Sj=Uj;Uj=new o;Tj=0}++Tj}
function rj(a){if(!a){this.b=null;new Di}else{this.b=a}}
function Dj(a){kj.call(this,a.bb(),a.ab()&-6);this.a=a}
function Tl(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function Vb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function mj(a,b){this.b=a;this.a=(b&4096)==0?b|64|ko:b}
function hc(a,b){var c;c=a.e;if(b!=c){a.e=ij(b);fb(a.b)}}
function Jh(a,b){var c;c=Hh(a);Oh(a,c);c.e=b?8:0;return c}
function Jl(a,b,c,d){return Ch(),Gl(a,b,c,d)?true:false}
function Ii(a,b){return Fd(a)===Fd(b)||a!=null&&p(a,b)}
function ok(a){mk(a);return Ad(a,8)&&a.w()?null:a.nb()}
function ih(a){if(Cd(a)){return a|0}return a.l|a.m<<22}
function Lh(a){if(a.O()){return null}var b=a.j;return oh[b]}
function lk(a){if(!a.k){a.k=true;a.n||a.o.forceUpdate()}}
function _j(a,b){null!=b&&a.ib(b,a.o.props,true);a.fb()}
function hn(a,b){return t((J(),J(),I),new sn(a,b),to,null)}
function ao(){$n();return sd(md(Sg,1),no,34,0,[Xn,Zn,Yn])}
function Zb(a){Ah((zh(),$wnd.window.window),uo,a.d,false)}
function $b(a){Bh((zh(),$wnd.window.window),uo,a.d,false)}
function Yc(a){Sc();$wnd.setTimeout(function(){throw a},0)}
function Cc(a){Bc(a.g);V(a.c);V(a.a);V(a.d);Bc(a.b);Bc(a.f)}
function Lb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function Al(a,b){var c;if(S(a.d)){c=b.target;Ol(a,c.value)}}
function Hc(a,b){var c;c=Fh(a.vb);return b==null?c:c+': '+b}
function ik(a){var b;b=hk(a);b.props={};b.ref=null;return b}
function uh(a){function b(){}
;b.prototype=a||{};return new b}
function Wb(a,b){Kb=new Vb(Kb,b);a.d=false;Lb(Kb);return Kb}
function fi(a,b){return b===a?'(this Map)':b==null?yo:vh(b)}
function Li(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Kh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function An(a,b){var c;vj(kn(a.b),(c=new Di,c)).P(new fo(b))}
function Vh(a,b){var c,d;for(d=a.Q();d.W();){c=d.X();b.B(c)}}
function qh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Dl(a,b){Qn((Um(),Tm),b);A((J(),J(),I),new Ul(a,b),to)}
function qj(a){if(a.b){qj(a.b)}else if(a.c){throw dh(new Qh)}}
function Ei(a){ui(this);Mj(this.a,di(a,od(Ge,no,1,ki(a.a),5,1)))}
function Mi(a,b){var c;return Ki(b,Li(a,b==null?0:(c=r(b),c|0)))}
function kn(a){gb(a.d);return new wj(null,new mj(new ri(a.g),0))}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&ko)?ko:8192)|0|0,b)}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&ko)?ko:8192)|0|0,b)}
function Ah(a,b,c,d){a.addEventListener(b,c,(Ch(),d?true:false))}
function En(a){this.b=ij(a);J();this.a=new Dc(0,null,new Fn,false)}
function Qi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function um(){um=sh;var a;tm=(a=th(sm.prototype.jb,sm,[]),a)}
function im(){im=sh;var a;hm=(a=th(gm.prototype.jb,gm,[]),a)}
function mm(){mm=sh;var a;lm=(a=th(km.prototype.jb,km,[]),a)}
function qm(){qm=sh;var a;pm=(a=th(om.prototype.jb,om,[]),a)}
function ym(){ym=sh;var a;xm=(a=th(wm.prototype.jb,wm,[]),a)}
function $o(){return Mn((Um(),Tm))==(hb(this.c),this.o.props['a'])}
function Gd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Xc(a){a&&cd((ad(),_c));--Pc;if(a){if(Rc!=-1){Zc(Rc);Rc=-1}}}
function Wc(a,b,c){var d;d=Uc();try{return Tc(a,b,c)}finally{Xc(d)}}
function Qn(a,b){var c;c=a.f;if(!(b==c||!!b&&Xm(b,c))){a.f=b;fb(a.d)}}
function cb(a,b){var c,d;vi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function On(a){var b;b=(gb(a.d),a.f);!!b&&!!b&&b.c.i<0&&Qn(a,null)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function nj(a,b){!a.a?(a.a=new ai(a.d)):$h(a.a,a.b);$h(a.a,b);return a}
function sj(a){var b;pj(a);b=0;while(a.a.cb(new Hj)){b=eh(b,1)}return b}
function vj(a,b){var c;pj(a);c=new Gj;c.a=b;a.a.V(new Jj(c));return c.a}
function Ck(a){a.placeholder='What needs to be done?';return a}
function Ic(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Vc(b){Sc();return function(){return Wc(b,this,arguments);var a}}
function Oc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function _b(a,b){a.f&&b.preventDefault();A((J(),J(),I),new oc(a),to)}
function Bh(a,b,c,d){a.removeEventListener(b,c,(Ch(),d?true:false))}
function ek(a,b,c){!Yh(c,'key')&&!Yh(c,'ref')&&(a[c]=b[c],undefined)}
function Aj(a,b){kj.call(this,b.bb(),b.ab()&-16449);this.a=a;this.c=b}
function cj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function pi(a){this.d=a;this.c=new cj(this.d.b);this.a=this.c;this.b=ni(this)}
function oj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Kn(a,b){return ($n(),Yn)==a||(Xn==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function ii(a,b){return Ed(b)?b==null?Oi(a.a,null):aj(a.b,b):Oi(a.a,b)}
function Oj(a,b){return nd(b)!=10&&sd(q(b),b.wb,b.__elementTypeId$,nd(b),a),a}
function Kl(a){return Ch(),Mn((Um(),Tm))==(hb(a.c),a.o.props['a'])?true:false}
function Nn(a){var b,c;return b=S(a.b),vj(tj(kn(a.j),new go(b)),(c=new Di,c))}
function Bn(a){var b;vj(tj(kn(a.b),new co),(b=new Di,b)).P(new eo(a.b))}
function Um(){Um=sh;Qm=new ic;Rm=new on;Sm=new En(Rm);Tm=new Rn(Rm,Qm)}
function Yb(a,b){a.g=b;Yh(b,S(a.a))&&hc(a,b);ac(b);A((J(),J(),I),new oc(a),to)}
function hi(a,b,c){return Ed(b)?b==null?Ni(a.a,null,c):_i(a.b,b,c):Ni(a.a,b,c)}
function od(a,b,c,d,e,f){var g;g=pd(e,d);e!=10&&sd(md(a,f),b,c,e,g);return g}
function Ai(a,b){var c;c=yi(a,b,0);if(c==-1){return false}Nj(a.a,c);return true}
function pk(a){var b;a.k=false;if(a.lb()){return null}else{b=a.hb();return b}}
function Y(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function yi(a,b,c){for(;c<a.a.length;++c){if(Ii(b,a.a[c])){return c}}return -1}
function dj(a){if(a.a.c!=a.c){return $i(a.a,a.b.value[0])}return a.b.value[1]}
function Xm(a,b){var c;if(Ad(b,49)){c=b;return a.c.e==c.c.e}else{return false}}
function bk(a,b){var c;if(b){c=a.p;a.p=false;return !c}else{a.p=true;return true}}
function ak(a,b){var c;c=null!=b&&a.ib(a.o.props,b,false);c||(a.p=false);return c}
function wi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.B(c)}}
function $(){var a;this.a=od(Kd,no,47,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function mb(a){var b;b=(J(),J(),I);Z(b.f,((a.c&lo)>>15)-1,a.f);0!=(a.c&ro)&&D(b)}
function ab(a){if(-2!=a.e){t((J(),J(),I),new G(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function Ac(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new Ec(a)),67108864,null)}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function bd(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=fd(b,c)}while(a.a);a.a=c}}
function cd(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=fd(b,c)}while(a.b);a.b=c}}
function gn(a){Vh(new ri(a.g),new yc(a));ji(a.g);R(a.c);R(a.e);R(a.a);R(a.b);ab(a.d)}
function nl(a){var b;b=Zh((gb(a.b),a.d));if(b.length>0){xn((Um(),Sm),b);sl(a,'')}}
function nk(a){var b;b=(++a.mb().e,new Gb);try{a.n=true;Ad(a,8)&&a.v()}finally{Fb(b)}}
function Xb(){var a;try{Mb(Kb);J()}finally{a=Kb.d;!a&&((J(),J(),I).d=true);Kb=Kb.d}}
function sb(b){if(b){try{b.A()}catch(a){a=bh(a);if(Ad(a,5)){J()}else throw dh(a)}}}
function Oh(a,b){var c;if(!a){return}b.j=a;var d=Lh(b);if(!d){oh[a]=[b];return}d.vb=b}
function th(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function bh(a){var b;if(Ad(a,5)){return a}b=a&&a[wo];if(!b){b=new Nc(a);jd(b)}return b}
function Hh(a){var b;b=new Gh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function aj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ri(a.a,b);--a.b}return c}
function Pb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;vi((!a.b&&(a.b=new Di),a.b),b)}}}
function Rb(a,b){var c;if(!a.c){c=Ob(a);!c.c&&(c.c=new Di);a.c=c.c}b.d=true;vi(a.c,ij(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,ij(b))}
function pb(a){var b,c;for(c=new Fi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Gi(a){var b,c,d;d=0;for(c=new pi(a.a);c.b;){b=oi(c);d=d+(b?r(b):0);d=d|0}return d}
function ci(a,b){var c,d;for(d=new pi(b.a);d.b;){c=oi(d);if(!li(a,c)){return false}}return true}
function ol(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new wl(a),to)}}
function nd(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Dd(a){return a!=null&&(typeof a===io||typeof a==='function')&&!(a.xb===wh)}
function nh(a,b){typeof window===io&&typeof window['$gwt']===io&&(window['$gwt'][a]=b)}
function Qh(){Jc.call(this,"Stream already terminated, can't be modified or used")}
function kh(){lh();var a=jh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function $n(){$n=sh;Xn=new _n('ACTIVE',0);Zn=new _n('COMPLETED',1);Yn=new _n('ALL',2)}
function fn(a,b,c){var d;d=new cn(b,c);rc(d.c.c,a,new zc(a,d));hi(a.g,Sh(d.c.e),d);fb(a.d);return d}
function vc(a,b,c){var d;d=ii(a.g,b?Sh(b.c.e):null);if(null!=d){tc(b.c.c,a);c&&!!b&&Ac(b.c);fb(a.d)}}
function Pn(a){var b;b=S(a.i.a);Yh(Ko,b)||Yh(Ho,b)||Yh('',b)?dc(a.i,b):Jn(ec(a.i))?gc(a.i):dc(a.i,'')}
function hh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=zo;d=1048575}c=Gd(e/ro);b=Gd(e-c*ro);return td(b,c,d)}
function Ki(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Ii(a,c.Z())){return c}}return null}
function fh(a){var b;b=a.h;if(b==0){return a.l+a.m*ro}if(b==1048575){return a.l+a.m*ro-zo}return a}
function ni(a){if(a.a.W()){return true}if(a.a!=a.c){return false}a.a=new Qi(a.d.a);return a.a.W()}
function S(a){gb(a.e);ub(a.f)&&nb(a.f);if(a.b){if(Ad(a.b,9)){throw dh(a.b)}else{throw dh(a.b)}}return a.k}
function Gl(a,b,c,d){var e,f;e=false;f=bk(a,d);if(!(b['a']===c['a'])){f&&fb(a.c);e=true}return e||a.k}
function sd(a,b,c,d,e){e.vb=a;e.wb=b;e.xb=wh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function _i(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function xh(){Um();$wnd.ReactDOM.render((new Pm).a,(zh(),yh).getElementById('todoapp'),null)}
function ck(a){$wnd.React.Component.call(this,a);this.a=this.kb();this.a.o=ij(this);this.a.gb()}
function Gh(){this.g=Dh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Nc(a){Lc();Fc(this);this.e=a;a!=null&&Pj(a,wo,this);this.f=a==null?yo:vh(a);this.a='';this.b=a;this.a=''}
function mk(a){if(!kk){kk=(++a.mb().e,new Gb);$wnd.Promise.resolve(null).then(th(rk.prototype.I,rk,[]))}}
function lb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Ab(a)),67108864,null);!!a.a&&R(a.a);Hb(a.f);a.c=a.c&-8|1}}
function Cl(a,b,c){27==c.which?A((J(),J(),I),new Yl(a,b),to):13==c.which&&A((J(),J(),I),new Vl(a,b),to)}
function db(a,b){var c,d;d=a.c;Ai(d,b);!!a.b&&oo!=(a.b.c&po)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Rb((J(),c=Kb,c),a))}
function ud(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return td(c&4194303,d&4194303,e&1048575)}
function El(a,b){var c;c=(gb(a.a),a.g);if(null!=c&&c.length!=0){Cn((Um(),b),c);Qn(Tm,null);Ol(a,c)}else{jn((Um(),Rm),b)}}
function eh(a,b){var c;if(Cd(a)&&Cd(b)){c=a+b;if(-17592186044416<c&&c<zo){return c}}return fh(ud(Cd(a)?hh(a):a,Cd(b)?hh(b):b))}
function Sh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Uh(),Th)[b];!c&&(c=Th[b]=new Rh(a));return c}return new Rh(a)}
function vh(a){var b;if(Array.isArray(a)&&a.xb===wh){return Fh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Xj(a){Vj();var b,c,d;c=':'+a;d=Uj[c];if(d!=null){return Gd(d)}d=Sj[c];b=d==null?Wj(a):Gd(d);Yj();Uj[c]=b;return b}
function Hi(a){var b,c,d;d=1;for(c=new Fi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function sc(a){var b,c;if(!a.a){for(c=new Fi(new Ei(new ri(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.A()}a.a=true}}
function X(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Uc(){var a;if(Pc!=0){a=Oc();if(a-Qc>2000){Qc=a;Rc=$wnd.setTimeout($c,10)}}if(Pc++==0){bd((ad(),_c));return true}return false}
function q(a){return Ed(a)?Je:Cd(a)?ye:Bd(a)?we:zd(a)?a.vb:qd(a)?a.vb:a.vb||Array.isArray(a)&&md(pe,1)||pe}
function p(a,b){return Ed(a)?Yh(a,b):Cd(a)?a===b:Bd(a)?a===b:zd(a)?a.q(b):qd(a)?a===b:!!a&&!!a.equals?a.equals(b):Fd(a)===Fd(b)}
function r(a){return Ed(a)?Xj(a):Cd(a)?Gd(a):Bd(a)?a?1231:1237:zd(a)?a.s():qd(a)?Rj(a):!!a&&!!a.hashCode?a.hashCode():Rj(a)}
function cl(){al();return sd(md(xf,1),no,7,0,[Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k])}
function Dc(a,b,c,d){var e;this.e=a;this.c=new uc;this.g=b;this.b=c;this.f=null;this.a=d?(e=new jb((J(),null)),e):null;this.d=null}
function U(a,b,c,d){this.c=ij(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new xb(this,d);this.e=new jb(this.f);oo==(d&po)&&mb(this.f)}
function jl(){qk.call(this);J();Sh(this.j);this.b=new Dc(0,null,new kl(this),false);this.a=new wb(null,ij(new ll(this)),Eo);D((null,I))}
function _l(){qk.call(this);J();Sh(this.j);this.b=new Dc(0,null,new am(this),false);this.a=new wb(null,ij(new bm(this)),Eo);D((null,I))}
function zl(a){var b;b=S(a.d);if(!a.i&&b){a.i=true;Nl(a,(hb(a.c),a.o.props['a']));a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function Nh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ci(a,b){var c,d;d=a.a.length;b.length<d&&(b=Oj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function sk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function kd(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:oo)|(a?ko:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:ro)|(0!=(c&lo)?0:98304)|0|0|0)}
function yd(a,b){if(Ed(a)){return !!xd[b]}else if(a.wb){return !!a.wb[b]}else if(Cd(a)){return !!wd[b]}else if(Bd(a)){return !!vd[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Ub(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Fi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Tb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Fi(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&tb(b,6,true)}}}
function Sb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Fi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Zh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function cn(a,b){var c,d,e;this.e=ij(a);this.d=b;J();c=++Vm;this.c=new Dc(c,null,new dn(this),true);this.b=(e=new jb(null),e);this.a=(d=new jb(null),d)}
function tl(){var a;qk.call(this);J();Sh(this.j);this.c=new Dc(0,null,new ul(this),false);this.b=(a=new jb(null),a);this.a=new wb(null,ij(new yl(this)),Eo);D((null,I))}
function el(){qk.call(this);J();Sh(this.j);this.c=new Dc(0,null,new fl(this),false);this.a=new U(new gl,null,null,136486912);this.b=new wb(null,ij(new hl(this)),Eo);D((null,I))}
function vb(a,b,c,d){this.b=new Di;this.f=new Jb(new zb(this));this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&mb(this)}
function pd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Qb(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=zi(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&tb(c.b,3,true);++b}}}return b}
function Cb(a){var b,c;if(0==a.c){b=Y(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=X(a.d);Ib(c);return true}
function mh(b,c,d,e){lh();var f=jh;$moduleName=c;$moduleBase=d;ah=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ho(g)()}catch(a){b(c,a)}}else{ho(g)()}}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(oo==(b&po)?0:524288)|(0!=(b&6291456)?0:oo==(b&po)?ro:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&lo)?0:98304))}
function Wi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Xi()}}
function hk(a){var b;b=new $wnd.Object;b.$$typeof=$wnd.React.Element;b.type=ij(a);b._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return b}
function di(a,b){var c,d,e,f,g;g=ki(a.a);b.length<g&&(b=Oj(new Array(g),b));e=(f=new pi((new mi(a.a)).a),new si(f));for(d=0;d<g;++d){b[d]=(c=oi(e.a),c.$())}b.length>g&&(b[g]=null);return b}
function ph(){oh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function fd(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].yb()&&(c=ed(c,g)):g[0].yb()}catch(a){a=bh(a);if(Ad(a,5)){d=a;Sc();Yc(Ad(d,37)?d.H():d)}else throw dh(a)}}return c}
function Mc(a){var b;if(a.c==null){b=Fd(a.b)===Fd(Kc)?null:a.b;a.d=b==null?yo:Dd(b)?b==null?null:b.name:Ed(b)?'String':Fh(q(b));a.a=a.a+': '+(Dd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.k;try{d=b.c.u();if(!(Fd(e)===Fd(d)||e!=null&&p(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=bh(a);if(Ad(a,11)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw dh(c)}else throw dh(a)}}
function Ni(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ki(b,e);if(f){return f._(c)}}e[e.length]=new ti(b,c);++a.b;return null}
function Kj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Wj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Xh(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=od(Ge,no,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Kb){g=ko==(d&ko)?c.u():c.u()}else{Wb(b,e);try{g=ko==(d&ko)?c.u():c.u()}finally{Xb()}}return g}catch(a){a=bh(a);if(Ad(a,5)){f=a;throw dh(f)}else throw dh(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Kb){g=ko==(d&ko)?(c.a.A(),null):(c.a.A(),null)}else{Wb(b,e);try{g=ko==(d&ko)?(c.a.A(),null):(c.a.A(),null)}finally{Xb()}}return g}catch(a){a=bh(a);if(Ad(a,5)){f=a;throw dh(f)}else throw dh(a)}finally{D(b)}}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.A()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=bh(a);if(Ad(a,5)){J()}else throw dh(a)}}}
function ac(a){var b;if(0==a.length){b=(zh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',yh.title,b)}else{(zh(),$wnd.window.window).location.hash=a}}
function Oi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ii(b,e.Z())){if(d.length==1){d.length=0;Ri(a.a,g)}else{d.splice(h,1)}--a.b;return e.$()}}return null}
function rh(a,b,c){var d=oh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=oh[b]),uh(h));_.wb=c;!b&&(_.xb=wh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.vb=f)}
function Mh(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Nh('.',[c,Nh('$',d)]);a.b=Nh('.',[c,Nh('.',d)]);a.i=d[d.length-1]}
function ei(a,b){var c,d,e;c=b.Z();e=b.$();d=Ed(c)?c==null?gi(Mi(a.a,null)):$i(a.b,c):gi(Mi(a.a,c));if(!(Fd(e)===Fd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(Ed(c)?c==null?!!Mi(a.a,null):Zi(a.b,c):!!Mi(a.a,c))){return false}return true}
function Pl(){var a,b;qk.call(this);J();Sh(this.j);this.e=new Dc(0,null,new Ql(this),false);this.c=(b=new jb(null),b);this.a=(a=new jb(null),a);this.d=new U(new Xl(this),null,null,136486912);this.b=new wb(null,ij(new $l(this)),Eo);D((null,I))}
function ic(){var a,b;this.d=new qc(this);this.g=this.e=(b=(zh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new Dc(0,null,new jc(this),false);this.b=(a=new jb(null),a);this.a=new U(new pc,new kc(this),new lc(this),35758080)}
function on(){var a;this.g=new Ji;J();this.f=new Dc(0,new qn(this),new pn(this),false);this.d=(a=new jb(null),a);this.c=new U(new tn(this),null,null,Jo);this.e=new U(new un(this),null,null,Jo);this.a=new U(new vn(this),null,null,Jo);this.b=new U(new wn(this),null,null,Jo)}
function Rn(a,b){var c;this.j=ij(a);this.i=ij(b);J();this.g=new Dc(0,null,new Sn(this),false);this.d=(c=new jb(null),c);this.b=new U(new Tn(this),null,null,Jo);this.c=new U(new Un(this),null,null,Jo);this.e=u(new Vn(this),413155328);this.a=u(new Wn(this),681590784);D((null,I))}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Fi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=bh(a);if(!Ad(a,5))throw dh(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function dk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?''+b['key']:null;f='ref' in b?b['ref']:null;$j(b,th(fk.prototype.eb,fk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=hk(a),g.key=e,g.ref=f,g.props=ij(d),g}
function Vi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||a.f.b||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);sb((e=a.a.j,e));c&&(1==(a.c&7)||a.f.b||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}wi(a.b,new Bb(a));a.b.a=od(Ge,no,1,0,5,1)}else 3==g&&!!a.a&&sb((f=a.a.g,f))}}
function al(){al=sh;Gk=new bl(Co,0);Hk=new bl('checkbox',1);Ik=new bl('color',2);Jk=new bl('date',3);Kk=new bl('datetime',4);Lk=new bl('email',5);Mk=new bl('file',6);Nk=new bl('hidden',7);Ok=new bl('image',8);Pk=new bl('month',9);Qk=new bl(jo,10);Rk=new bl('password',11);Sk=new bl('radio',12);Tk=new bl('range',13);Uk=new bl('reset',14);Vk=new bl('search',15);Wk=new bl('submit',16);Xk=new bl('tel',17);Yk=new bl('text',18);Zk=new bl('time',19);$k=new bl('url',20);_k=new bl('week',21)}
function Nb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=xi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Bi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=xi(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){zi(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Di)}if(W(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&oo!=(k.b.c&po)&&k.c.a.length<=0&&0==k.b.a.d&&Rb(a,k)}}
function Xi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Bo]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Vi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Bo]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var io='object',jo='number',ko=16384,lo=229376,mo={10:1},no={3:1,4:1},oo=1048576,po=1835008,qo={6:1},ro=4194304,so={21:1},to=142614528,uo='hashchange',vo='__noinit__',wo='__java$exception',xo={3:1,11:1,9:1,5:1},yo='null',zo=17592186044416,Ao={43:1},Bo='delete',Co='button',Do='selected',Eo=1478635520,Fo={8:1,20:1},Go='input',Ho='completed',Io='header',Jo=136421376,Ko='active';var _,oh,jh,ah=-1;ph();rh(1,null,{},o);_.q=Mo;_.r=function(){return this.vb};_.s=No;_.t=function(){var a;return Fh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.q(a)};_.hashCode=function(){return this.s()};_.toString=function(){return this.t()};var vd,wd,xd;rh(51,1,{},Gh);_.J=function(a){var b;b=new Gh;b.e=4;a>1?(b.c=Kh(this,a-1)):(b.c=this);return b};_.K=function(){Eh(this);return this.b};_.L=function(){return Fh(this)};_.M=function(){Eh(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.t=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Eh(this),this.k)};_.e=0;_.g=0;var Dh=1;var Ge=Ih(1);var xe=Ih(51);rh(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var Jd=Ih(81);rh(38,1,mo,G);_.u=function(){return this.a.A(),null};var Hd=Ih(38);rh(82,1,{},H);var Id=Ih(82);var I;rh(47,1,{47:1},P);_.b=0;_.c=false;_.d=0;var Kd=Ih(47);rh(213,1,{8:1});_.t=function(){var a;return Fh(this.vb)+'@'+(a=r(this)>>>0,a.toString(16))};var Nd=Ih(213);rh(18,213,{8:1},U);_.v=function(){R(this)};_.w=Lo;_.a=false;_.d=0;var Ld=Ih(18);rh(133,1,{242:1},$);var Md=Ih(133);rh(14,213,{8:1,14:1},jb);_.v=function(){ab(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Pd=Ih(14);rh(123,1,qo,kb);_.A=function(){bb(this.a)};var Od=Ih(123);rh(16,213,{8:1,16:1},wb,xb);_.v=function(){lb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Ud=Ih(16);rh(124,1,so,yb);_.A=function(){Q(this.a)};var Qd=Ih(124);rh(125,1,{235:1},zb);var Rd=Ih(125);rh(126,1,qo,Ab);_.A=function(){qb(this.a)};var Sd=Ih(126);rh(127,1,{},Bb);_.B=function(a){ob(this.a,a)};var Td=Ih(127);rh(134,1,{},Eb);_.a=0;_.b=0;_.c=0;var Vd=Ih(134);rh(64,1,{8:1},Gb);_.v=function(){Fb(this)};_.w=Lo;_.a=false;var Wd=Ih(64);rh(63,1,{8:1,63:1},Jb);_.v=function(){Hb(this)};_.w=Lo;_.t=function(){var a;return Eh(Xd),Xd.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.a=false;_.b=false;var Xd=Ih(63);rh(146,1,{},Vb);_.t=function(){var a;return Eh(Yd),Yd.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.a=0;var Kb;var Yd=Ih(146);rh(45,1,{45:1});_.f=true;var ge=Ih(45);rh(104,45,{8:1,45:1,20:1},ic);_.v=Uo;_.q=Mo;_.C=Vo;_.s=No;_.w=Wo;_.t=function(){var a;return Eh(ee),ee.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var ee=Ih(104);rh(105,1,qo,jc);_.A=function(){cc(this.a)};var Zd=Ih(105);rh(107,1,so,kc);_.A=function(){Zb(this.a)};var $d=Ih(107);rh(108,1,so,lc);_.A=function(){$b(this.a)};var _d=Ih(108);rh(109,1,qo,mc);_.A=function(){Yb(this.a,this.b)};var ae=Ih(109);rh(110,1,qo,nc);_.A=function(){fc(this.a)};var be=Ih(110);rh(56,1,qo,oc);_.A=function(){bc(this.a)};var ce=Ih(56);rh(106,1,mo,pc);_.u=function(){var a;return a=(zh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var de=Ih(106);rh(83,1,{},qc);_.handleEvent=function(a){_b(this.a,a)};var fe=Ih(83);rh(128,1,{8:1},uc);_.v=function(){sc(this)};_.w=Lo;_.a=false;var he=Ih(128);rh(111,1,{});var ke=Ih(111);rh(55,1,{},yc);_.B=function(a){wc(this.a,a)};var ie=Ih(55);rh(84,1,qo,zc);_.A=function(){xc(this.a,this.b)};var je=Ih(84);rh(112,111,{});var le=Ih(112);rh(15,1,{8:1},Dc);_.v=function(){Ac(this)};_.w=function(){return this.i<0};_.t=function(){var a;return Eh(ne),ne.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.e=0;_.i=0;var ne=Ih(15);rh(122,1,qo,Ec);_.A=function(){Cc(this.a)};var me=Ih(122);rh(5,1,{3:1,5:1});_.D=function(a){return new Error(a)};_.F=function(){return this.f};_.G=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Fh(this.vb),c==null?a:a+': '+c);Gc(this,Ic(this.D(b)));jd(this)};_.t=function(){return Hc(this,this.F())};_.e=vo;_.g=true;var Ke=Ih(5);rh(11,5,{3:1,11:1,5:1});var Ae=Ih(11);rh(9,11,xo);var He=Ih(9);rh(52,9,xo);var De=Ih(52);rh(75,52,xo);var re=Ih(75);rh(37,75,{37:1,3:1,11:1,9:1,5:1},Nc);_.F=function(){Mc(this);return this.c};_.H=function(){return Fd(this.b)===Fd(Kc)?null:this.b};var Kc;var oe=Ih(37);var pe=Ih(0);rh(199,1,{});var qe=Ih(199);var Pc=0,Qc=0,Rc=-1;rh(103,199,{},dd);var _c;var se=Ih(103);var gd;rh(210,1,{});var ue=Ih(210);rh(76,210,{},ld);var te=Ih(76);var yh;rh(73,1,{70:1});_.t=Lo;var ve=Ih(73);vd={3:1,71:1,29:1};var we=Ih(71);rh(44,1,{3:1,44:1});var Fe=Ih(44);wd={3:1,29:1,44:1};var ye=Ih(209);rh(33,1,{3:1,29:1,33:1});_.q=Mo;_.s=No;_.t=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ze=Ih(33);rh(77,9,xo,Qh);var Be=Ih(77);rh(30,44,{3:1,29:1,30:1,44:1},Rh);_.q=function(a){return Ad(a,30)&&a.a==this.a};_.s=Lo;_.t=function(){return ''+this.a};_.a=0;var Ce=Ih(30);var Th;rh(271,1,{});rh(79,52,xo,Wh);_.D=function(a){return new TypeError(a)};var Ee=Ih(79);xd={3:1,70:1,29:1,2:1};var Je=Ih(2);rh(74,73,{70:1},ai);var Ie=Ih(74);rh(275,1,{});rh(54,9,xo,bi);var Le=Ih(54);rh(211,1,{42:1});_.P=Ro;_.T=function(){return new mj(this,0)};_.U=function(){return new wj(null,this.T())};_.R=function(a){throw dh(new bi('Add not supported on this collection'))};_.t=function(){var a,b,c;c=new oj('[',']');for(b=this.Q();b.W();){a=b.X();nj(c,a===this?'(this Collection)':a==null?yo:vh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Me=Ih(211);rh(214,1,{197:1});_.q=function(a){var b,c,d;if(a===this){return true}if(!Ad(a,39)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new pi((new mi(d)).a);c.b;){b=oi(c);if(!ei(this,b)){return false}}return true};_.s=function(){return Gi(new mi(this))};_.t=function(){var a,b,c;c=new oj('{','}');for(b=new pi((new mi(this)).a);b.b;){a=oi(b);nj(c,fi(this,a.Z())+'='+fi(this,a.$()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Xe=Ih(214);rh(130,214,{197:1});var Pe=Ih(130);rh(215,211,{42:1,221:1});_.T=function(){return new mj(this,1)};_.q=function(a){var b;if(a===this){return true}if(!Ad(a,24)){return false}b=a;if(ki(b.a)!=this.S()){return false}return ci(this,b)};_.s=function(){return Gi(this)};var Ye=Ih(215);rh(24,215,{24:1,42:1,221:1},mi);_.Q=function(){return new pi(this.a)};_.S=Po;var Oe=Ih(24);rh(25,1,{},pi);_.V=Oo;_.X=function(){return oi(this)};_.W=Qo;_.b=false;var Ne=Ih(25);rh(212,211,{42:1,219:1});_.T=function(){return new mj(this,16)};_.Y=function(a,b){throw dh(new bi('Add not supported on this list'))};_.R=function(a){this.Y(this.S(),a);return true};_.q=function(a){var b,c,d,e,f;if(a===this){return true}if(!Ad(a,13)){return false}f=a;if(this.S()!=f.a.length){return false}e=new Fi(f);for(c=new Fi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(Fd(b)===Fd(d)||b!=null&&p(b,d))){return false}}return true};_.s=function(){return Hi(this)};_.Q=function(){return new qi(this)};var Re=Ih(212);rh(102,1,{},qi);_.V=Oo;_.W=function(){return this.a<this.b.a.length};_.X=function(){return xi(this.b,this.a++)};_.a=0;var Qe=Ih(102);rh(40,211,{42:1},ri);_.Q=function(){var a;return a=new pi((new mi(this.a)).a),new si(a)};_.S=Po;var Te=Ih(40);rh(57,1,{},si);_.V=Oo;_.W=function(){return this.a.b};_.X=function(){var a;return a=oi(this.a),a.$()};var Se=Ih(57);rh(131,1,Ao);_.q=function(a){var b;if(!Ad(a,43)){return false}b=a;return Ii(this.a,b.Z())&&Ii(this.b,b.$())};_.Z=Lo;_.$=Qo;_.s=function(){return hj(this.a)^hj(this.b)};_._=function(a){var b;b=this.b;this.b=a;return b};_.t=function(){return this.a+'='+this.b};var Ue=Ih(131);rh(132,131,Ao,ti);var Ve=Ih(132);rh(216,1,Ao);_.q=function(a){var b;if(!Ad(a,43)){return false}b=a;return Ii(this.b.value[0],b.Z())&&Ii(dj(this),b.$())};_.s=function(){return hj(this.b.value[0])^hj(dj(this))};_.t=function(){return this.b.value[0]+'='+dj(this)};var We=Ih(216);rh(13,212,{3:1,13:1,42:1,219:1},Di,Ei);_.Y=function(a,b){Lj(this.a,a,b)};_.R=function(a){return vi(this,a)};_.P=function(a){wi(this,a)};_.Q=function(){return new Fi(this)};_.S=function(){return this.a.length};var $e=Ih(13);rh(17,1,{},Fi);_.V=Oo;_.W=function(){return this.a<this.c.a.length};_.X=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ze=Ih(17);rh(39,130,{3:1,39:1,197:1},Ji);var _e=Ih(39);rh(61,1,{},Pi);_.P=Ro;_.Q=function(){return new Qi(this)};_.b=0;var bf=Ih(61);rh(62,1,{},Qi);_.V=Oo;_.X=function(){return this.d=this.a[this.c++],this.d};_.W=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var af=Ih(62);var Ti;rh(59,1,{},bj);_.P=Ro;_.Q=function(){return new cj(this)};_.b=0;_.c=0;var ef=Ih(59);rh(60,1,{},cj);_.V=Oo;_.X=function(){return this.c=this.a,this.a=this.b.next(),new ej(this.d,this.c,this.d.c)};_.W=function(){return !this.a.done};var cf=Ih(60);rh(145,216,Ao,ej);_.Z=function(){return this.b.value[0]};_.$=function(){return dj(this)};_._=function(a){return _i(this.a,this.b.value[0],a)};_.c=0;var df=Ih(145);rh(136,1,{});_.V=function(a){jj(this,a)};_.ab=function(){return this.d};_.bb=function(){return this.e};_.d=0;_.e=0;var gf=Ih(136);rh(58,136,{});var ff=Ih(58);rh(23,1,{},mj);_.ab=Lo;_.bb=function(){lj(this);return this.c};_.V=function(a){lj(this);this.d.V(a)};_.cb=function(a){lj(this);if(this.d.W()){a.B(this.d.X());return true}return false};_.a=0;_.c=0;var hf=Ih(23);rh(53,1,{},oj);_.t=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var jf=Ih(53);rh(135,1,{});_.c=false;var sf=Ih(135);rh(32,135,{},wj);var rf=Ih(32);rh(138,58,{},Aj);_.cb=function(a){this.b=false;while(!this.b&&this.c.cb(new Bj(this,a)));return this.b};_.b=false;var lf=Ih(138);rh(141,1,{},Bj);_.B=function(a){zj(this.a,this.b,a)};var kf=Ih(141);rh(137,58,{},Dj);_.cb=function(a){return this.a.cb(new Ej(a))};var nf=Ih(137);rh(140,1,{},Ej);_.B=function(a){Cj(this.a,a)};var mf=Ih(140);rh(139,1,{},Gj);_.B=function(a){Fj(this,a)};var of=Ih(139);rh(142,1,{},Hj);_.B=function(a){};var pf=Ih(142);rh(143,1,{},Jj);_.B=function(a){Ij(this,a)};var qf=Ih(143);rh(273,1,{});rh(218,1,{});var tf=Ih(218);rh(270,1,{});var Qj=0;var Sj,Tj=0,Uj;rh(697,1,{});rh(714,1,{});rh(217,1,{});_.fb=So;_.gb=So;_.ib=function(a,b,c){return false};_.p=false;var uf=Ih(217);rh(31,$wnd.React.Component,{});qh(oh[1],_);_.render=function(){return ok(this.a)};var vf=Ih(31);rh(236,$wnd.Function,{},fk);_.eb=function(a){ek(this.a,this.b,a)};rh(35,217,{});_.lb=function(){return false};_.nb=function(){return pk(this)};_.j=0;_.k=false;_.n=false;var jk=1,kk;var wf=Ih(35);rh(241,$wnd.Function,{},rk);_.I=function(a){return Fb(kk),kk=null,null};rh(7,33,{3:1,29:1,33:1,7:1},bl);var Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k;var xf=Jh(7,cl);rh(167,35,{});_.sb=To;_.hb=function(){var a;a=S((Um(),Tm).b);return dk('footer',sk(new $wnd.Object,sd(md(Je,1),no,2,6,['footer'])),[(new fm).a,dk('ul',sk(new $wnd.Object,sd(md(Je,1),no,2,6,['filters'])),[dk('li',null,[dk('a',uk(sk(new $wnd.Object,sd(md(Je,1),no,2,6,[($n(),Yn)==a?Do:null])),'#'),['All'])]),dk('li',null,[dk('a',uk(sk(new $wnd.Object,sd(md(Je,1),no,2,6,[Xn==a?Do:null])),'#active'),['Active'])]),dk('li',null,[dk('a',uk(sk(new $wnd.Object,sd(md(Je,1),no,2,6,[Zn==a?Do:null])),'#completed'),['Completed'])])]),this.sb()?dk(Co,vk(sk(new $wnd.Object,sd(md(Je,1),no,2,6,['clear-completed'])),th(dm.prototype.rb,dm,[])),['Clear Completed']):null])};var eg=Ih(167);rh(168,167,{});_.sb=To;var ig=Ih(168);rh(169,168,Fo,el);_.v=Uo;_.q=Mo;_.mb=Xo;_.C=Vo;_.sb=function(){return S(this.a)};_.s=No;_.w=Wo;_.t=function(){var a;return Eh(Gf),Gf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.nb=function(){return B((J(),J(),I),this.b,new il(this))};var Gf=Ih(169);rh(170,1,qo,fl);_.A=function(){dl(this.a)};var yf=Ih(170);rh(171,1,mo,gl);_.u=function(){return Ch(),S((Um(),Rm).b).a>0?true:false};var zf=Ih(171);rh(172,1,so,hl);_.A=Yo;var Af=Ih(172);rh(173,1,mo,il);_.u=Zo;var Bf=Ih(173);rh(190,35,{});_.hb=function(){var a,b;b=S((Um(),Rm).e).a;a='item'+(b==1?'':'s');return dk('span',sk(new $wnd.Object,sd(md(Je,1),no,2,6,['todo-count'])),[dk('strong',null,[b]),' '+a+' left'])};var dg=Ih(190);rh(191,190,{});var hg=Ih(191);rh(192,191,Fo,jl);_.v=_o;_.q=Mo;_.mb=Xo;_.C=ap;_.s=No;_.w=bp;_.t=function(){var a;return Eh(Ff),Ff.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.nb=function(){return B((J(),J(),I),this.a,new ml(this))};var Ff=Ih(192);rh(193,1,qo,kl);_.A=cp;var Cf=Ih(193);rh(194,1,so,ll);_.A=Yo;var Df=Ih(194);rh(195,1,mo,ml);_.u=Zo;var Ef=Ih(195);rh(159,35,{});_.hb=function(){return dk(Go,wk(Ak(Bk(Ek(Ck(sk(new $wnd.Object,sd(md(Je,1),no,2,6,['new-todo']))),(gb(this.b),this.d)),th(Am.prototype.qb,Am,[this])),th(Bm.prototype.pb,Bm,[this]))),null)};_.d='';var qg=Ih(159);rh(160,159,{});var kg=Ih(160);rh(161,160,Fo,tl);_.v=Uo;_.q=Mo;_.mb=Xo;_.C=Vo;_.s=No;_.w=Wo;_.t=function(){var a;return Eh(Mf),Mf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.nb=function(){return B((J(),J(),I),this.a,new vl(this))};var Mf=Ih(161);rh(162,1,qo,ul);_.A=function(){pl(this.a)};var Hf=Ih(162);rh(164,1,mo,vl);_.u=Zo;var If=Ih(164);rh(165,1,qo,wl);_.A=function(){nl(this.a)};var Jf=Ih(165);rh(166,1,qo,xl);_.A=function(){rl(this.a,this.b)};var Kf=Ih(166);rh(163,1,so,yl);_.A=Yo;var Lf=Ih(163);rh(175,35,{});_.fb=function(){zl(this)};_.ub=$o;_.gb=function(){Nl(this,this.tb())};_.hb=function(){var a,b;b=this.tb();a=(gb(b.a),b.d);return dk('li',sk(new $wnd.Object,sd(md(Je,1),no,2,6,[a?Ho:null,this.ub()?'editing':null])),[dk('div',sk(new $wnd.Object,sd(md(Je,1),no,2,6,['view'])),[dk(Go,Ak(xk(Dk(sk(new $wnd.Object,sd(md(Je,1),no,2,6,['toggle'])),(al(),Hk)),a),th(Em.prototype.pb,Em,[b])),null),dk('label',Fk(new $wnd.Object,th(Fm.prototype.rb,Fm,[this,b])),[(gb(b.b),b.e)]),dk(Co,vk(sk(new $wnd.Object,sd(md(Je,1),no,2,6,['destroy'])),th(Gm.prototype.rb,Gm,[b])),null)]),dk(Go,Bk(Ak(zk(yk(sk(tk(new $wnd.Object,th(Hm.prototype.B,Hm,[this])),sd(md(Je,1),no,2,6,['edit'])),(gb(this.a),this.g)),th(Im.prototype.ob,Im,[this,b])),th(Dm.prototype.pb,Dm,[this])),th(Jm.prototype.qb,Jm,[this,b])),null)])};_.i=false;var sg=Ih(175);rh(176,175,{});_.lb=function(){var a;a=(hb(this.c),this.o.props['a']);if(!!a&&a.c.i<0){return true}return false};_.tb=function(){return this.o.props['a']};_.ub=$o;_.ib=function(a,b,c){return Gl(this,a,b,c)};var mg=Ih(176);rh(177,176,Fo,Pl);_.fb=function(){A((J(),J(),I),new Sl(this),to)};_.v=function(){Ac(this.e)};_.q=Mo;_.mb=Xo;_.C=function(){return this.e.c};_.tb=function(){return hb(this.c),this.o.props['a']};_.s=No;_.w=function(){return this.e.i<0};_.ub=function(){return S(this.d)};_.ib=function(a,b,c){return t((J(),J(),I),new Tl(this,a,b,c),75505664,null)};_.t=function(){var a;return Eh(Yf),Yf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.nb=function(){return B((J(),J(),I),this.b,new Rl(this))};var Yf=Ih(177);rh(178,1,qo,Ql);_.A=function(){Hl(this.a)};var Nf=Ih(178);rh(181,1,mo,Rl);_.u=Zo;var Of=Ih(181);rh(182,1,qo,Sl);_.A=function(){zl(this.a)};var Pf=Ih(182);rh(183,1,mo,Tl);_.u=function(){return Jl(this.a,this.d,this.c,this.b)};_.b=false;var Qf=Ih(183);rh(65,1,qo,Ul);_.A=function(){Ol(this.a,ec(this.b))};var Rf=Ih(65);rh(66,1,qo,Vl);_.A=function(){El(this.a,this.b)};var Sf=Ih(66);rh(184,1,qo,Wl);_.A=function(){Dl(this.a,this.b)};var Tf=Ih(184);rh(179,1,mo,Xl);_.u=function(){return Kl(this.a)};var Uf=Ih(179);rh(185,1,qo,Yl);_.A=function(){Nl(this.a,this.b);Qn((Um(),Tm),null)};var Vf=Ih(185);rh(186,1,qo,Zl);_.A=function(){Al(this.a,this.b)};var Wf=Ih(186);rh(180,1,so,$l);_.A=Yo;var Xf=Ih(180);rh(147,35,{});_.hb=function(){var a,b;return dk('div',null,[dk('div',null,[dk(Io,sk(new $wnd.Object,sd(md(Je,1),no,2,6,[Io])),[dk('h1',null,['todos']),(new Cm).a]),S((Um(),Rm).c)?null:dk('section',sk(new $wnd.Object,sd(md(Je,1),no,2,6,[Io])),[dk(Go,Ak(Dk(sk(new $wnd.Object,sd(md(Je,1),no,2,6,['toggle-all'])),(al(),Hk)),th(Om.prototype.pb,Om,[])),null),dk('ul',sk(new $wnd.Object,sd(md(Je,1),no,2,6,['todo-list'])),(a=vj(uj(S(Tm.c).U()),(b=new Di,b)),Ci(a,rd(a.a.length))))]),S(Rm.c)?null:(new em).a])])};var ug=Ih(147);rh(148,147,{});var og=Ih(148);rh(149,148,Fo,_l);_.v=_o;_.q=Mo;_.mb=Xo;_.C=ap;_.s=No;_.w=bp;_.t=function(){var a;return Eh(ag),ag.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.nb=function(){return B((J(),J(),I),this.a,new cm(this))};var ag=Ih(149);rh(150,1,qo,am);_.A=cp;var Zf=Ih(150);rh(151,1,so,bm);_.A=Yo;var $f=Ih(151);rh(152,1,mo,cm);_.u=Zo;var _f=Ih(152);rh(247,$wnd.Function,{},dm);_.rb=function(a){zn((Um(),Sm))};rh(154,1,{},em);var bg=Ih(154);rh(174,1,{},fm);var cg=Ih(174);rh(246,$wnd.Function,{},gm);_.jb=function(a){return new jm(a)};var hm;rh(156,31,{},jm);_.kb=function(){return new el};_.componentWillUnmount=dp;var fg=Ih(156);rh(257,$wnd.Function,{},km);_.jb=function(a){return new nm(a)};var lm;rh(187,31,{},nm);_.kb=function(){return new jl};_.componentWillUnmount=dp;var gg=Ih(187);rh(243,$wnd.Function,{},om);_.jb=function(a){return new rm(a)};var pm;rh(155,31,{},rm);_.kb=function(){return new tl};_.componentWillUnmount=dp;var jg=Ih(155);rh(248,$wnd.Function,{},sm);_.jb=function(a){return new vm(a)};var tm;rh(158,31,{},vm);_.kb=function(){return new Pl};_.componentDidUpdate=function(a){_j(this.a,a)};_.componentWillUnmount=dp;_.shouldComponentUpdate=function(a){return ak(this.a,a)};var lg=Ih(158);rh(239,$wnd.Function,{},wm);_.jb=function(a){return new zm(a)};var xm;rh(129,31,{},zm);_.kb=function(){return new _l};_.componentWillUnmount=dp;var ng=Ih(129);rh(244,$wnd.Function,{},Am);_.qb=function(a){ol(this.a,a)};rh(245,$wnd.Function,{},Bm);_.pb=function(a){ql(this.a,a)};rh(153,1,{},Cm);var pg=Ih(153);rh(255,$wnd.Function,{},Dm);_.pb=function(a){Il(this.a,a)};rh(249,$wnd.Function,{},Em);_.pb=function(a){bn(this.a)};rh(251,$wnd.Function,{},Fm);_.rb=function(a){Ll(this.a,this.b)};rh(252,$wnd.Function,{},Gm);_.rb=function(a){Fl(this.a)};rh(253,$wnd.Function,{},Hm);_.B=function(a){Bl(this.a,a)};rh(254,$wnd.Function,{},Im);_.ob=function(a){Ml(this.a,this.b)};rh(256,$wnd.Function,{},Jm);_.qb=function(a){Cl(this.a,this.b,a)};rh(157,1,{},Nm);var rg=Ih(157);rh(240,$wnd.Function,{},Om);_.pb=function(a){var b;b=a.target;Dn((Um(),Sm),b.checked)};rh(69,1,{},Pm);var tg=Ih(69);var Qm,Rm,Sm,Tm;rh(48,1,{48:1});_.d=false;var Zg=Ih(48);rh(49,48,{8:1,20:1,49:1,48:1},cn);_.v=Uo;_.q=function(a){return Xm(this,a)};_.C=Vo;_.s=function(){return this.c.e};_.w=Wo;_.t=function(){var a;return Eh(Lg),Lg.k+'@'+(a=this.c.e>>>0,a.toString(16))};var Vm=0;var Lg=Ih(49);rh(188,1,qo,dn);_.A=function(){Wm(this.a)};var vg=Ih(188);rh(189,1,qo,en);_.A=function(){$m(this.a)};var wg=Ih(189);rh(46,112,{46:1});var Ug=Ih(46);rh(113,46,{8:1,20:1,46:1},on);_.v=function(){Ac(this.f)};_.q=Mo;_.C=function(){return this.f.c};_.s=No;_.w=function(){return this.f.i<0};_.t=function(){var a;return Eh(Fg),Fg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var Fg=Ih(113);rh(115,1,qo,pn);_.A=function(){gn(this.a)};var xg=Ih(115);rh(114,1,qo,qn);_.A=function(){ln(this.a)};var yg=Ih(114);rh(120,1,qo,rn);_.A=function(){vc(this.a,this.b,true)};var zg=Ih(120);rh(121,1,mo,sn);_.u=function(){return fn(this.a,this.c,this.b)};_.b=false;var Ag=Ih(121);rh(116,1,mo,tn);_.u=function(){return mn(this.a)};var Bg=Ih(116);rh(117,1,mo,un);_.u=function(){return Sh(ih(sj(kn(this.a))))};var Cg=Ih(117);rh(118,1,mo,vn);_.u=function(){return Sh(ih(sj(tj(kn(this.a),new bo))))};var Dg=Ih(118);rh(119,1,mo,wn);_.u=function(){return nn(this.a)};var Eg=Ih(119);rh(89,1,{});var Yg=Ih(89);rh(90,89,Fo,En);_.v=function(){Ac(this.a)};_.q=Mo;_.C=function(){return this.a.c};_.s=No;_.w=function(){return this.a.i<0};_.t=function(){var a;return Eh(Kg),Kg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var Kg=Ih(90);rh(91,1,qo,Fn);_.A=So;var Gg=Ih(91);rh(92,1,qo,Gn);_.A=function(){An(this.a,this.b)};_.b=false;var Hg=Ih(92);rh(93,1,qo,Hn);_.A=function(){hc(this.b,this.a)};var Ig=Ih(93);rh(94,1,qo,In);_.A=function(){Bn(this.a)};var Jg=Ih(94);rh(95,1,{});var _g=Ih(95);rh(96,95,Fo,Rn);_.v=function(){Ac(this.g)};_.q=Mo;_.C=function(){return this.g.c};_.s=No;_.w=function(){return this.g.i<0};_.t=function(){var a;return Eh(Rg),Rg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var Rg=Ih(96);rh(97,1,qo,Sn);_.A=function(){Ln(this.a)};var Mg=Ih(97);rh(98,1,mo,Tn);_.u=function(){var a;return a=ec(this.a.i),Yh(Ko,a)||Yh(Ho,a)||Yh('',a)?Yh(Ko,a)?($n(),Xn):Yh(Ho,a)?($n(),Zn):($n(),Yn):($n(),Yn)};var Ng=Ih(98);rh(99,1,mo,Un);_.u=function(){return Nn(this.a)};var Og=Ih(99);rh(100,1,so,Vn);_.A=function(){On(this.a)};var Pg=Ih(100);rh(101,1,so,Wn);_.A=function(){Pn(this.a)};var Qg=Ih(101);rh(34,33,{3:1,29:1,33:1,34:1},_n);var Xn,Yn,Zn;var Sg=Jh(34,ao);rh(85,1,{},bo);_.db=function(a){return !Zm(a)};var Tg=Ih(85);rh(87,1,{},co);_.db=function(a){return Zm(a)};var Vg=Ih(87);rh(88,1,{},eo);_.B=function(a){jn(this.a,a)};var Wg=Ih(88);rh(86,1,{},fo);_.B=function(a){yn(this.a,a)};_.a=false;var Xg=Ih(86);rh(78,1,{},go);_.db=function(a){return Kn(this.a,a)};var $g=Ih(78);var ho=(Sc(),Vc);var gwtOnLoad=gwtOnLoad=mh;kh(xh);nh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();