function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='CBC807596C61FF6201CBA5139C54C28F',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'CBC807596C61FF6201CBA5139C54C28F';function o(){}
function oj(){}
function pj(){}
function eh(){}
function em(){}
function am(){}
function im(){}
function mm(){}
function qm(){}
function Gm(){}
function _g(){}
function Lb(){}
function Qc(){}
function Xc(){}
function Dk(){}
function Mk(){}
function Zl(){}
function dn(){}
function oo(){}
function po(){}
function Vc(a){Uc()}
function kh(){kh=_g}
function mi(){di(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function pb(a){this.a=a}
function Db(a){this.a=a}
function Eb(a){this.a=a}
function Fb(a){this.a=a}
function Gb(a){this.a=a}
function gc(a){this.a=a}
function pc(a){this.a=a}
function Ah(a){this.a=a}
function Lh(a){this.a=a}
function Xh(a){this.a=a}
function _h(a){this.b=a}
function ai(a){this.a=a}
function bi(a){this.a=a}
function oi(a){this.c=a}
function mj(a){this.a=a}
function rj(a){this.a=a}
function Lk(a){this.a=a}
function Nk(a){this.a=a}
function Ok(a){this.a=a}
function Uk(a){this.a=a}
function Vk(a){this.a=a}
function Wk(a){this.a=a}
function hl(a){this.a=a}
function il(a){this.a=a}
function jl(a){this.a=a}
function ll(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Kl(a){this.a=a}
function Pl(a){this.a=a}
function Ql(a){this.a=a}
function Wl(a){this.a=a}
function Xl(a){this.a=a}
function Yl(a){this.a=a}
function um(a){this.a=a}
function vm(a){this.a=a}
function xm(a){this.a=a}
function ym(a){this.a=a}
function Am(a){this.a=a}
function Bm(a){this.a=a}
function Zm(a){this.a=a}
function $m(a){this.a=a}
function _m(a){this.a=a}
function bn(a){this.a=a}
function cn(a){this.a=a}
function qn(a){this.a=a}
function rn(a){this.a=a}
function Bn(a){this.a=a}
function Cn(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Hn(a){this.a=a}
function In(a){this.a=a}
function Tn(a){this.a=a}
function bo(a){this.a=a}
function co(a){this.a=a}
function eo(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function ho(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function so(a){this.a=a}
function nj(a,b){a.a=b}
function Jj(a,b){a.key=b}
function Ij(a,b){Hj(a,b)}
function Kn(a,b){Fl(b,a)}
function _o(a){Qi(this,a)}
function cp(a){Eh(this,a)}
function dp(){jc(this.c)}
function fp(){jc(this.b)}
function yi(){this.a=Hi()}
function Mi(){this.a=Hi()}
function kc(a){!!a&&a.v()}
function Y(a){!!a&&fb(a)}
function w(a){--a.e;D(a)}
function wb(a,b){a.b=Ti(b)}
function nc(a,b){Th(a.e,b)}
function qj(a,b){hj(a.a,b)}
function Jn(a,b){un(a.b,b)}
function C(a,b){db(a.f,b.f)}
function jb(a){Zb((J(),a))}
function kb(a){$b((J(),a))}
function nb(a){_b((J(),a))}
function hp(){qb(this.a.a)}
function kp(a){nc(this.c,a)}
function Mg(a){return a.e}
function Yo(){return this.a}
function bp(){return this.b}
function Hh(a,b){return a===b}
function nl(a,b){return a.g=b}
function Ob(a){a.a=-4&a.a|1}
function Ek(a){a.d=2;jc(a.c)}
function Pk(a){a.c=2;jc(a.b)}
function tl(a){a.f=2;jc(a.e)}
function Sm(a){R(a.a);fb(a.b)}
function Ik(a){qb(a.b);R(a.a)}
function bl(a){qb(a.a);fb(a.b)}
function sl(a){vn((Lm(),Im),a)}
function Mh(a){uc.call(this,a)}
function $o(){return zj(this)}
function Zo(a){return this===a}
function gi(a,b){return a.a[b]}
function nh(a){mh(a);return a.k}
function fn(a){fb(a.b);fb(a.a)}
function gn(a,b,c){ic(a.c,b,c)}
function ic(a,b,c){Sh(a.e,b,c)}
function vj(a,b){a.splice(b,1)}
function Yc(a,b){return th(a,b)}
function ap(){return Vh(this.a)}
function ep(){return this.c.i<0}
function gp(){return this.b.i<0}
function Fh(){qc(this);this.D()}
function Di(){Di=_g;Ci=Fi()}
function J(){J=_g;I=new F}
function wc(){wc=_g;vc=new o}
function Nc(){Nc=_g;Mc=new Qc}
function Dc(){Dc=_g;!!(Uc(),Tc)}
function Ug(){Sg==null&&(Sg=[])}
function gb(a){J();$b(a);a.e=-2}
function Tb(a){Ub(a);!a.d&&Xb(a)}
function T(a){sb(a.f);return V(a)}
function gj(a,b){a.P(b);return a}
function Sj(a,b){a.ref=b;return a}
function Um(a){lb(a.b);return a.e}
function kn(a){lb(a.a);return a.d}
function Xn(a){lb(a.d);return a.f}
function Hi(){Di();return new Ci}
function ip(a){return 1==this.a.d}
function jp(a){return 1==this.a.c}
function Vh(a){return a.a.b+a.b.b}
function Z(a){return !!a&&a.c.i<0}
function bd(a){return new Array(a)}
function Ji(a,b){return a.a.get(b)}
function Ui(a,b){while(a.ab(b));}
function K(a,b){O(a);L(a,Ti(b))}
function hj(a,b){nj(a,gj(a.a,b))}
function v(a,b,c){s(a,new H(c),b)}
function tj(a,b,c){a.splice(b,0,c)}
function zk(a,b){yh.call(this,a,b)}
function hc(a,b){this.a=a;this.b=b}
function yh(a,b){this.a=a;this.b=b}
function ci(a,b){this.a=a;this.b=b}
function kj(a,b){this.a=a;this.b=b}
function Qj(a,b){this.a=a;this.b=b}
function kl(a,b){this.a=a;this.b=b}
function Jl(a,b){this.a=a;this.b=b}
function Ll(a,b){this.a=a;this.b=b}
function Ml(a,b){this.a=a;this.b=b}
function Nl(a,b){this.a=a;this.b=b}
function Ol(a,b){this.a=a;this.b=b}
function zm(a,b){this.a=a;this.b=b}
function Cm(a,b){this.a=a;this.b=b}
function Dm(a,b){this.a=a;this.b=b}
function Dn(a,b){this.a=a;this.b=b}
function an(a,b){this.a=a;this.b=b}
function Rn(a,b){this.a=a;this.b=b}
function Sn(a,b){this.b=a;this.a=b}
function mo(a,b){yh.call(this,a,b)}
function Vm(a){Tm(a,(lb(a.b),a.e))}
function wm(){this.a=Kj((km(),jm))}
function Fm(){this.a=Kj((om(),nm))}
function Hm(){this.a=Kj((sm(),rm))}
function $l(){this.a=Kj((cm(),bm))}
function _l(){this.a=Kj((gm(),fm))}
function ln(a){Fl(a,(lb(a.a),!a.d))}
function Vb(a){return !a.d?a:Vb(a.d)}
function Rh(a){return !a?null:a.Y()}
function qd(a){return a==null?null:a}
function Si(a){return a!=null?r(a):0}
function nd(a){return typeof a===vo}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function Kc(a){$wnd.clearTimeout(a)}
function Tj(a,b){a.href=b;return a}
function ak(a,b){a.value=b;return a}
function Xj(a,b){a.onBlur=b;return a}
function Uj(a,b){a.onClick=b;return a}
function Wj(a,b){a.checked=b;return a}
function Jh(a,b){a.a+=''+b;return a}
function Uh(a){a.a=new yi;a.b=new Mi}
function ob(a){this.c=new mi;this.b=a}
function Jb(a){this.d=Ti(a);this.b=100}
function xl(a){qb(a.b);R(a.c);fb(a.a)}
function fc(a,b){dc(a,b,false);kb(a.d)}
function uj(a,b){sj(b,0,a,0,b.length)}
function ec(a,b){b.A(a);ld(b,9)&&b.t()}
function Hj(a,b){for(var c in a){b(c)}}
function Yj(a,b){a.onChange=b;return a}
function di(a){a.a=$c(ie,xo,1,0,5,1)}
function P(){this.a=$c(ie,xo,1,100,5,1)}
function B(a,b,c){return t(a,c,2048,b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function Gh(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function $(a){return !(!!a&&1==(a.c&7))}
function zj(a){return a.$H||(a.$H=++yj)}
function pd(a){return typeof a==='string'}
function Zj(a,b){a.onKeyDown=b;return a}
function Vj(a){a.autoFocus=true;return a}
function mh(a){if(a.k!=null){return}vh(a)}
function vb(a){J();ub(a);yb(a,2,true)}
function U(a){4==(a.f.c&7)&&yb(a.f,5,true)}
function Mb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function lb(a){var b;Wb((J(),b=Rb,b),a)}
function rc(a,b){a.e=b;b!=null&&xj(b,Go,a)}
function Qi(a,b){while(a.U()){qj(b,a.V())}}
function A(a,b,c){t(a,new G(b),c,null)}
function Dj(){Dj=_g;Aj=new o;Cj=new o}
function si(){this.a=new yi;this.b=new Mi}
function uc(a){this.f=a;qc(this);this.D()}
function fj(a,b){aj.call(this,a);this.a=b}
function Ai(a,b){var c;c=a[Lo];c.call(a,b)}
function u(a,b){return new Bb(Ti(a),null,b)}
function md(a){return typeof a==='boolean'}
function zn(a){return Bh(S(a.e).a-S(a.a).a)}
function Zn(a){Z((lb(a.d),a.f))&&_n(a,null)}
function on(a){A((J(),J(),I),new rn(a),Qo)}
function Ln(a){A((J(),J(),I),new Tn(a),Qo)}
function Wm(a){A((J(),J(),I),new bn(a),Qo)}
function Cl(a){A((J(),J(),I),new Ql(a),Qo)}
function xj(b,c,d){try{b[c]=d}catch(a){}}
function Ec(a,b,c){return a.apply(b,c);var d}
function Pi(a,b,c){this.a=a;this.b=b;this.c=c}
function cb(a,b,c){Ob(Ti(c));K(a.a[b],Ti(c))}
function db(a,b){cb(a,((b.a&229376)>>15)-1,b)}
function cl(a,b){A((J(),J(),I),new kl(a,b),Qo)}
function yl(a,b){A((J(),J(),I),new Ol(a,b),Qo)}
function Al(a,b){A((J(),J(),I),new Ml(a,b),Qo)}
function Bl(a,b){A((J(),J(),I),new Ll(a,b),Qo)}
function El(a,b){A((J(),J(),I),new Jl(a,b),Qo)}
function vn(a,b){A((J(),J(),I),new Dn(a,b),Qo)}
function On(a,b){A((J(),J(),I),new Sn(a,b),Qo)}
function Pn(a,b){A((J(),J(),I),new Rn(a,b),Qo)}
function dl(a,b){var c;c=b.target;fl(a,c.value)}
function qh(a){var b;b=ph(a);xh(a,b);return b}
function qc(a){a.g&&a.e!==Fo&&a.D();return a}
function bk(a,b){a.onDoubleClick=b;return a}
function ei(a,b){a.a[a.a.length]=b;return true}
function En(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new eb;this.a=new Jb(this.f)}
function xn(a){Eh(new ai(a.g),new gc(a));Uh(a.g)}
function Ib(a){while(true){if(!Hb(a)){break}}}
function Kb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Wi(a){if(!a.d){a.d=a.b.O();a.c=a.b.Q()}}
function tb(a,b){ib(b,a);b.c.a.length>0||(b.a=4)}
function ih(a,b,c,d){a.addEventListener(b,c,d)}
function jh(a,b,c,d){a.removeEventListener(b,c,d)}
function ij(a,b,c){if(a.a.bb(c)){a.b=true;b.w(c)}}
function Zh(a){var b;b=a.a.V();a.b=Yh(a);return b}
function sh(a){var b;b=ph(a);b.j=a;b.e=1;return b}
function ii(a,b){var c;c=a.a[b];vj(a.a,b);return c}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ii(a,b){return !(a.a.get(b)===undefined)}
function ad(a){return Array.isArray(a)&&a.kb===eh}
function kd(a){return !Array.isArray(a)&&a.kb===eh}
function yn(a){return kh(),0==S(a.e).a?true:false}
function el(a){return B((J(),J(),I),a.a,new il(a))}
function Sk(a){return B((J(),J(),I),a.a,new Wk(a))}
function Jk(a){return B((J(),J(),I),a.b,new Ok(a))}
function Dl(a){return B((J(),J(),I),a.b,new Il(a))}
function Ul(a){return B((J(),J(),I),a.a,new Yl(a))}
function Un(a){return Hh(Wo,a)||Hh(Xo,a)||Hh('',a)}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function tn(a){R(a.c);R(a.e);R(a.a);R(a.b);fb(a.d)}
function dj(a){_i(a);return new fj(a,new lj(a.a))}
function Wh(a,b){if(b){return Ph(a.a,b)}return false}
function Ti(a){if(a==null){throw Mg(new Fh)}return a}
function Gj(){if(Bj==256){Aj=Cj;Cj=new o;Bj=0}++Bj}
function Uc(){Uc=_g;var a;!Wc();a=new Xc;Tc=a}
function hh(){hh=_g;gh=$wnd.window.document}
function Dh(){Dh=_g;Ch=$c(ee,xo,32,256,0,1)}
function Fk(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function Qk(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function ul(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function $i(a){if(!a.b){_i(a);a.c=true}else{$i(a.b)}}
function Wn(a){qb(a.e);qb(a.a);R(a.b);R(a.c);fb(a.d)}
function fl(a,b){var c;c=a.e;if(b!=c){a.e=b;kb(a.b)}}
function Fl(a,b){var c;c=a.d;if(b!=c){a.d=b;kb(a.a)}}
function ki(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function _j(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Vi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function ri(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function Rm(a){var b;U(a.a);b=S(a.a);Hh(a.f,b)&&Xm(a,b)}
function Xm(a,b){var c;c=a.e;if(b!=c){a.e=Ti(b);kb(a.b)}}
function rh(a,b){var c;c=ph(a);xh(a,c);c.e=b?8:0;return c}
function mb(a){var b;J();!!Rb&&!!Rb.e&&Wb((b=Rb,b),a)}
function lj(a){Vi.call(this,a._(),a.$()&-6);this.a=a}
function aj(a){if(!a){this.b=null;new mi}else{this.b=a}}
function cj(a,b){_i(a);return new fj(a,new jj(b,a.a))}
function Tm(a,b){A((J(),J(),I),new an(a,b),75497472)}
function un(a,b){return t((J(),J(),I),new En(a,b),Qo,null)}
function ac(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Xi(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function bc(a,b){Rb=new ac(Rb,b);a.d=false;Sb(Rb);return Rb}
function uh(a){if(a.M()){return null}var b=a.j;return Xg[b]}
function Rg(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function sc(a,b){var c;c=nh(a.ib);return b==null?c:c+': '+b}
function ml(a,b){var c;if(S(a.c)){c=b.target;Fl(a,c.value)}}
function Eh(a,b){var c,d;for(d=a.O();d.U();){c=d.V();b.w(c)}}
function Qh(a,b){return b===a?'(this Map)':b==null?Io:dh(b)}
function no(){lo();return cd(Yc(Ag,1),xo,34,0,[io,ko,jo])}
function Nm(a){ih((hh(),$wnd.window.window),To,a.d,false)}
function Om(a){jh((hh(),$wnd.window.window),To,a.d,false)}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Lm(){Lm=_g;Im=new An;Jm=new Qn(Im);Km=new ao(Im)}
function Mn(a,b){var c;ej(wn(a.b),(c=new mi,c)).N(new ro(b))}
function th(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function ui(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function _i(a){if(a.b){_i(a.b)}else if(a.c){throw Mg(new zh)}}
function Sb(a){if(a.e){2==(a.e.c&7)||yb(a.e,4,true);ub(a.e)}}
function rb(a){C((J(),J(),I),a);0==(a.f.a&Co)&&D((null,I))}
function pl(a,b){_n((Lm(),Km),b);A((J(),J(),I),new Jl(a,b),Qo)}
function Pm(a,b){b.preventDefault();A((J(),J(),I),new cn(a),Qo)}
function vi(a,b){var c;return ti(b,ui(a,b==null?0:(c=r(b),c|0)))}
function wn(a){lb(a.d);return new fj(null,new Xi(new ai(a.g),0))}
function ni(a){di(this);uj(this.a,Oh(a,$c(ie,xo,1,Vh(a.a),5,1)))}
function mc(a){kc(a.g);!!a.e&&lc(a);Y(a.a);Y(a.c);kc(a.b);kc(a.f)}
function cm(){cm=_g;var a;bm=(a=ah(am.prototype.hb,am,[]),a)}
function gm(){gm=_g;var a;fm=(a=ah(em.prototype.hb,em,[]),a)}
function km(){km=_g;var a;jm=(a=ah(im.prototype.hb,im,[]),a)}
function om(){om=_g;var a;nm=(a=ah(mm.prototype.hb,mm,[]),a)}
function sm(){sm=_g;var a;rm=(a=ah(qm.prototype.hb,qm,[]),a)}
function bh(a){function b(){}
;b.prototype=a||{};return new b}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function $j(a){a.placeholder='What needs to be done?';return a}
function zi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function dm(a){$wnd.React.Component.call(this,a);this.a=new Kk(this)}
function hm(a){$wnd.React.Component.call(this,a);this.a=new Tk(this)}
function lm(a){$wnd.React.Component.call(this,a);this.a=new gl(this)}
function pm(a){$wnd.React.Component.call(this,a);this.a=new Gl(this)}
function tm(a){$wnd.React.Component.call(this,a);this.a=new Vl(this)}
function jj(a,b){Vi.call(this,b._(),b.$()&-16449);this.a=a;this.c=b}
function hb(a,b){var c,d;ei(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function _n(a,b){var c;c=a.f;if(!(b==c||!!b&&hn(b,c))){a.f=b;kb(a.d)}}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function Zg(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Pj(a,b,c){!Hh(c,'key')&&!Hh(c,'ref')&&(a[c]=b[c],undefined)}
function zl(a){return kh(),Xn((Lm(),Km))==a.j.props['a']?true:false}
function Qn(a){this.b=Ti(a);J();this.a=new oc(0,null,null,true,false)}
function Ni(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Yi(a,b){!a.a?(a.a=new Lh(a.d)):Jh(a.a,a.b);Jh(a.a,b);return a}
function ej(a,b){var c;$i(a);c=new oj;c.a=b;a.a.T(new rj(c));return c.a}
function bj(a){var b;$i(a);b=0;while(a.a.ab(new pj)){b=Ng(b,1)}return b}
function bb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Nn(a){var b;ej(cj(wn(a.b),new po),(b=new mi,b)).N(new qo(a.b))}
function Pb(b){try{b.b.v()}catch(a){a=Lg(a);if(!ld(a,5))throw Mg(a)}}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Th(a,b){return pd(b)?b==null?xi(a.a,null):Li(a.b,b):xi(a.a,b)}
function Vn(a,b){return (lo(),jo)==a||(io==a?(lb(b.a),!b.d):(lb(b.a),b.d))}
function Sh(a,b,c){return pd(b)?b==null?wi(a.a,null,c):Ki(a.b,b,c):wi(a.a,b,c)}
function wj(a,b){return Zc(b)!=10&&cd(q(b),b.jb,b.__elementTypeId$,Zc(b),a),a}
function Mm(a,b){a.f=b;Hh(b,S(a.a))&&Xm(a,b);Qm(b);A((J(),J(),I),new cn(a),Qo)}
function Yn(a){var b,c;return b=S(a.b),ej(cj(wn(a.j),new so(b)),(c=new mi,c))}
function fi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function eb(){var a;this.a=$c(wd,xo,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function $h(a){this.d=a;this.c=new Ni(this.d.b);this.a=this.c;this.b=Yh(this)}
function Zi(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function hn(a,b){var c;if(ld(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function ji(a,b){var c;c=hi(a,b,0);if(c==-1){return false}vj(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function hi(a,b,c){for(;c<a.a.length;++c){if(ri(b,a.a[c])){return c}}return -1}
function Oi(a){if(a.a.c!=a.c){return Ji(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Ib(a.a)}finally{a.c=false}}}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;fb(a.e);2==(a.f.c&7)||qb(a.f)}}
function fb(a){if(-2!=a.e){t((J(),J(),I),new G(new pb(a)),0,null);!!a.b&&qb(a.b)}}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new pc(a)),67108864,null)}}
function V(a){if(a.b){if(ld(a.b,8)){throw Mg(a.b)}else{throw Mg(a.b)}}return a.n}
function xb(b){if(b){try{b.v()}catch(a){a=Lg(a);if(ld(a,5)){J()}else throw Mg(a)}}}
function cc(){var a;try{Tb(Rb);J()}finally{a=Rb.d;!a&&((J(),J(),I).d=true);Rb=Rb.d}}
function Xk(a){var b;b=Ih((lb(a.b),a.e));if(b.length>0){Jn((Lm(),Jm),b);fl(a,'')}}
function Yk(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new jl(a),Qo)}}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===uo||typeof a==='function')&&!(a.kb===eh)}
function Wg(a,b){typeof window===uo&&typeof window['$gwt']===uo&&(window['$gwt'][a]=b)}
function xh(a,b){var c;if(!a){return}b.j=a;var d=uh(b);if(!d){Xg[a]=[b];return}d.ib=b}
function ah(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Lg(a){var b;if(ld(a,5)){return a}b=a&&a[Go];if(!b){b=new yc(a);Vc(b)}return b}
function ph(a){var b;b=new oh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Li(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ai(a.a,b);--a.b}return c}
function Wb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;ei((!a.b&&(a.b=new mi),a.b),b)}}}
function Yb(a,b){var c;if(!a.c){c=Vb(a);!c.c&&(c.c=new mi);a.c=c.c}b.d=true;ei(a.c,Ti(b))}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function ub(a){var b,c;for(c=new oi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function pi(a){var b,c,d;d=0;for(c=new $h(a.a);c.b;){b=Zh(c);d=d+(b?r(b):0);d=d|0}return d}
function Nh(a,b){var c,d;for(d=new $h(b.a);d.b;){c=Zh(d);if(!Wh(a,c)){return false}}return true}
function sn(a,b,c){var d;d=new pn(b,c);gn(d,a,new hc(a,d));Sh(a.g,Bh(d.c.d),d);kb(a.d);return d}
function Lj(a,b,c,d){var e;e=Mj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Ti(d);return e}
function Kj(a){var b;b=Mj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Nj(a){var b;return Lj($wnd.React.StrictMode,null,null,(b={},b[Mo]=Ti(a),b))}
function zh(){uc.call(this,"Stream already terminated, can't be modified or used")}
function Tg(){Ug();var a=Sg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function lo(){lo=_g;io=new mo('ACTIVE',0);ko=new mo('COMPLETED',1);jo=new mo('ALL',2)}
function fh(){Lm();$wnd.ReactDOM.render(Nj([(new Hm).a]),(hh(),gh).getElementById('app'),null)}
function Yh(a){if(a.a.U()){return true}if(a.a!=a.c){return false}a.a=new zi(a.d.a);return a.a.U()}
function Og(a){var b;b=a.h;if(b==0){return a.l+a.m*Do}if(b==1048575){return a.l+a.m*Do-Jo}return a}
function Qg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Jo;d=1048575}c=rd(e/Do);b=rd(e-c*Do);return dd(b,c,d)}
function ti(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(ri(a,c.X())){return c}}return null}
function Em(a,b){Jj(a.a,(mh(Tf),Tf.k+(''+(b?Bh(b.c.d):null))));Ti(b);a.a.props['a']=b;return a.a}
function dc(a,b,c){var d;d=Th(a.g,b?Bh(b.c.d):null);if(null!=d){nc(b.c,a);c&&!!b&&jc(b.c);kb(a.d)}}
function Ki(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function cd(a,b,c,d,e){e.ib=a;e.jb=b;e.kb=eh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Qb(a,b){this.b=Ti(a);this.a=b|0|(0==(b&6291456)?Do:0)|(0!=(b&229376)?0:98304)}
function Bb(a,b,c){Ab.call(this,null,a,b,c|(!a?262144:zo)|(0==(c&6291456)?!a?Co:Do:0)|0|0|0)}
function ol(a,b,c){27==c.which?A((J(),J(),I),new Nl(a,b),Qo):13==c.which&&A((J(),J(),I),new Ll(a,b),Qo)}
function qb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Fb(a)),67108864,null);!!a.a&&R(a.a);Mb(a.f);a.c=a.c&-8|1}}
function Ck(){if(!Bk){Bk=(++(J(),J(),I).e,new Lb);$wnd.Promise.resolve(null).then(ah(Dk.prototype.G,Dk,[]))}}
function $n(a){var b;b=S(a.i.a);Hh(Wo,b)||Hh(Xo,b)||Hh('',b)?Tm(a.i,b):Un(Um(a.i))?Wm(a.i):Tm(a.i,'')}
function ql(a,b){var c;c=(lb(a.a),a.d);if(null!=c&&c.length!=0){On((Lm(),b),c);_n(Km,null);Fl(a,c)}else{vn((Lm(),Im),b)}}
function ib(a,b){var c,d;d=a.c;ji(d,b);!!a.b&&zo!=(a.b.c&Ao)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Yb((J(),c=Rb,c),a))}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function Bh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Dh(),Ch)[b];!c&&(c=Ch[b]=new Ah(a));return c}return new Ah(a)}
function dh(a){var b;if(Array.isArray(a)&&a.kb===eh){return nh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Fj(a){Dj();var b,c,d;c=':'+a;d=Cj[c];if(d!=null){return rd(d)}d=Aj[c];b=d==null?Ej(a):rd(d);Gj();Cj[c]=b;return b}
function yc(a){wc();qc(this);this.e=a;a!=null&&xj(a,Go,this);this.f=a==null?Io:dh(a);this.a='';this.b=a;this.a=''}
function oh(){this.g=lh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function rl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;El(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Nb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&zo)?Pb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function q(a){return pd(a)?le:nd(a)?ae:md(a)?$d:kd(a)?a.ib:ad(a)?a.ib:a.ib||Array.isArray(a)&&Yc(Td,1)||Td}
function p(a,b){return pd(a)?Hh(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.o(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function r(a){return pd(a)?Fj(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.q():ad(a)?zj(a):!!a&&!!a.hashCode?a.hashCode():zj(a)}
function Ak(){yk();return cd(Yc(Ye,1),xo,7,0,[ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk])}
function Cb(a,b){Ab.call(this,a,new Db(a),null,b|(zo==(b&Ao)?0:524288)|(0==(b&6291456)?zo==(b&Ao)?Do:Co:0)|0|268435456|0)}
function Ng(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<Jo){return c}}return Og(ed(nd(a)?Qg(a):a,nd(b)?Qg(b):b))}
function qi(a){var b,c,d;d=1;for(c=new oi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function lc(a){var b,c,d;for(c=new oi(new ni(new Xh(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.X();ld(d,9)&&d.u()||b.Y().v()}}
function ab(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Rj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function li(a,b){var c,d;d=a.a.length;b.length<d&&(b=wj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Oh(a,b){var c,d,e;e=Vh(a.a);b.length<e&&(b=wj(new Array(e),b));d=new $h(a.a);for(c=0;c<e;++c){b[c]=Zh(d)}b.length>e&&(b[e]=null);return b}
function Tk(a){var b;this.j=Ti(a);J();b=++Rk;this.b=new oc(b,null,new Uk(this),false,false);this.a=new Bb(null,Ti(new Vk(this)),Po)}
function Vl(a){var b;this.j=Ti(a);J();b=++Tl;this.b=new oc(b,null,new Wl(this),false,false);this.a=new Bb(null,Ti(new Xl(this)),Po)}
function oc(a,b,c,d,e){var f;this.d=a;this.e=d?new si:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new ob((J(),null)),f):null;this.c=null}
function Xb(a){var b;if(a.c){while(a.c.a.length!=0){b=ii(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&yb(b.b,3,true)}}}
function _b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&yb(b,5,true)}}}
function $b(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new oi(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&yb(b,6,true)}}}
function wh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.jb){return !!a.jb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function S(a){a.k?mb(a.e):lb(a.e);if(zb(a.f)){if(a.k&&(J(),!(!!Rb&&!!Rb.e))){return t((J(),J(),I),new X(a),83888128,null)}else{sb(a.f)}}return V(a)}
function Ih(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{bc(b,d);try{f=(c.a.v(),null)}finally{cc()}return f}catch(a){a=Lg(a);if(ld(a,5)){e=a;throw Mg(e)}else throw Mg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Rb){g=c.s()}else{bc(b,e);try{g=c.s()}finally{cc()}}return g}catch(a){a=Lg(a);if(ld(a,5)){f=a;throw Mg(f)}else throw Mg(a)}finally{D(b)}}
function pn(a,b){var c,d,e;this.e=Ti(a);this.d=b;J();c=++en;this.c=new oc(c,null,new qn(this),true,true);this.b=(e=new ob(null),e);this.a=(d=new ob(null),d)}
function gl(a){var b,c;this.j=Ti(a);J();b=++al;this.c=new oc(b,null,new hl(this),false,false);this.b=(c=new ob(null),c);this.a=new Bb(null,Ti(new ll(this)),Po)}
function Kk(a){var b;this.j=Ti(a);J();b=++Hk;this.c=new oc(b,null,new Lk(this),false,false);this.a=new W(new Mk,null,null,136478720);this.b=new Bb(null,Ti(new Nk(this)),Po)}
function Zb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?yb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Hb(a){var b,c;if(0==a.c){b=bb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=ab(a.d);Nb(c);return true}
function Vg(b,c,d,e){Ug();var f=Sg;$moduleName=c;$moduleBase=d;Kg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{to(g)()}catch(a){b(c,a)}}else{to(g)()}}
function W(a,b,c,d){this.c=Ti(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new Cb(this,d&-16385);this.e=new ob(this.f);zo==(d&Ao)&&rb(this.f)}
function Mj(a,b){var c;c=new $wnd.Object;c.$$typeof=Ti(a);c.type=Ti(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Fi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Gi()}}
function Yg(){Xg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].lb()&&(c=Rc(c,g)):g[0].lb()}catch(a){a=Lg(a);if(ld(a,5)){d=a;Dc();Jc(ld(d,35)?d.F():d)}else throw Mg(a)}}return c}
function _k(a){var b;a.d=0;Ck();b=Oj(Ro,Vj(Yj(Zj(ak($j(Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,['new-todo']))),(lb(a.b),a.e)),ah(um.prototype.fb,um,[a])),ah(vm.prototype.eb,vm,[a]))),null);return b}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?Io:od(b)?b==null?null:b.name:pd(b)?'String':nh(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.n=d;b.b=null;jb(b.e)}}catch(a){a=Lg(a);if(ld(a,12)){c=a;if(!b.b){b.n=null;b.b=c;jb(b.e)}throw Mg(c)}else throw Mg(a)}}
function wi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=ti(b,e);if(f){return f.Z(c)}}e[e.length]=new ci(b,c);++a.b;return null}
function sj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Ej(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Gh(a,c++)}b=b|0;return b}
function sb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Lg(a);if(ld(a,5)){J()}else throw Mg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=$c(ie,xo,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Qm(a){var b;if(0==a.length){b=(hh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',gh.title,b)}else{(hh(),$wnd.window.window).location.hash=a}}
function Ab(a,b,c,d){this.b=new mi;this.f=new Qb(new Eb(this),d&6520832|262144|zo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Co)&&D((null,I)))}
function xi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(ri(b,e.X())){if(d.length==1){d.length=0;Ai(a.a,g)}else{d.splice(h,1)}--a.b;return e.Y()}}return null}
function Gl(a){var b,c;this.j=Ti(a);J();b=++wl;this.e=new oc(b,null,new Hl(this),false,false);this.a=(c=new ob(null),c);this.c=new W(new Kl(this),null,null,136478720);this.b=new Bb(null,Ti(new Pl(this)),Po);El(this,this.j.props['a'])}
function $g(a,b,c){var d=Xg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Xg[b]),bh(h));_.jb=c;!b&&(_.kb=eh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ib=f)}
function vh(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=wh('.',[c,wh('$',d)]);a.b=wh('.',[c,wh('.',d)]);a.i=d[d.length-1]}
function Ph(a,b){var c,d,e;c=b.X();e=b.Y();d=pd(c)?c==null?Rh(vi(a.a,null)):Ji(a.b,c):Rh(vi(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!vi(a.a,null):Ii(a.b,c):!!vi(a.a,c))){return false}return true}
function Oj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Ij(b,ah(Qj.prototype.cb,Qj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Mo]=c[0],undefined):(d[Mo]=c,undefined));return Lj(a,e,f,d)}
function Ym(){var a,b;this.d=new ho(this);this.f=this.e=(b=(hh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new oc(0,null,new Zm(this),true,false);this.b=(a=new ob(null),a);this.a=new W(new dn,new $m(this),new _m(this),35651584)}
function An(){var a;this.g=new si;J();this.f=new oc(0,new Cn(this),new Bn(this),true,false);this.d=(a=new ob(null),a);this.c=new W(new Fn(this),null,null,Vo);this.e=new W(new Gn(this),null,null,Vo);this.a=new W(new Hn(this),null,null,Vo);this.b=new W(new In(this),null,null,Vo)}
function ao(a){var b;this.j=Ti(a);this.i=new Ym;J();this.g=new oc(0,null,new bo(this),true,false);this.d=(b=new ob(null),b);this.b=new W(new co(this),null,null,Vo);this.c=new W(new eo(this),null,null,Vo);this.e=u(new fo(this),413138944);this.a=u(new go(this),681574400);D((null,I))}
function zb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new oi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Lg(a);if(!ld(a,5))throw Mg(a)}if(6==(b.c&7)){return true}}}}}ub(b);return false}
function Ei(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function yb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){nb(a.a.e);xb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;xb((e=d.i,e));d.n=null}fi(a.b,new Gb(a));a.b.a=$c(ie,xo,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&xb((f=a.a.g,f))}}
function yk(){yk=_g;ck=new zk(No,0);dk=new zk('checkbox',1);ek=new zk('color',2);fk=new zk('date',3);gk=new zk('datetime',4);hk=new zk('email',5);ik=new zk('file',6);jk=new zk('hidden',7);kk=new zk('image',8);lk=new zk('month',9);mk=new zk(vo,10);nk=new zk('password',11);ok=new zk('radio',12);pk=new zk('range',13);qk=new zk('reset',14);rk=new zk('search',15);sk=new zk('submit',16);tk=new zk('tel',17);uk=new zk('text',18);vk=new zk('time',19);wk=new zk('url',20);xk=new zk('week',21)}
function Ub(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=gi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ki(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{ib(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&yb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=gi(a.b,g);if(-1==k.e){k.e=0;hb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ii(a.b,g)}e&&wb(a.e,a.b)}else{e&&wb(a.e,new mi)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&zo!=(k.b.c&Ao)&&k.c.a.length<=0&&0==k.b.a.d&&Yb(a,k)}}
function Gk(a){var b,c;a.d=0;Ck();c=(b=S((Lm(),Km).b),Oj('footer',Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,['footer'])),[(new _l).a,Oj('ul',Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,['filters'])),[Oj('li',null,[Oj('a',Tj(Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,[(lo(),jo)==b?Oo:null])),'#'),['All'])]),Oj('li',null,[Oj('a',Tj(Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,[io==b?Oo:null])),'#active'),['Active'])]),Oj('li',null,[Oj('a',Tj(Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,[ko==b?Oo:null])),'#completed'),['Completed'])])]),S(a.a)?Oj(No,Uj(Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,['clear-completed'])),ah(Zl.prototype.gb,Zl,[])),['Clear Completed']):null]));return c}
function vl(a){var b,c,d,e;a.f=0;Ck();b=a.j.props['a'];if(b.c.i<0){return null}c=(d=a.j.props['a'],e=(lb(d.a),d.d),Oj('li',Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,[e?'checked':null,S(a.c)?'editing':null])),[Oj('div',Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,['view'])),[Oj(Ro,Yj(Wj(_j(Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,['toggle'])),(yk(),dk)),e),ah(ym.prototype.eb,ym,[d])),null),Oj('label',bk(new $wnd.Object,ah(zm.prototype.gb,zm,[a,d])),[(lb(d.b),d.e)]),Oj(No,Uj(Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,['destroy'])),ah(Am.prototype.gb,Am,[d])),null)]),Oj(Ro,Zj(Yj(Xj(ak(Rj(Sj(new $wnd.Object,ah(Bm.prototype.w,Bm,[a])),cd(Yc(le,1),xo,2,6,['edit'])),(lb(a.a),a.d)),ah(Cm.prototype.db,Cm,[a,d])),ah(xm.prototype.eb,xm,[a])),ah(Dm.prototype.fb,Dm,[a,d])),null)]));return c}
function Gi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Lo]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ei()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Lo]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var uo='object',vo='number',wo={11:1},xo={3:1,4:1},yo={9:1},zo=1048576,Ao=1835008,Bo={6:1},Co=2097152,Do=4194304,Eo={21:1},Fo='__noinit__',Go='__java$exception',Ho={3:1,12:1,8:1,5:1},Io='null',Jo=17592186044416,Ko={40:1},Lo='delete',Mo='children',No='button',Oo='selected',Po=1411518464,Qo=142606336,Ro='input',So='header',To='hashchange',Uo={9:1,49:1},Vo=136314880,Wo='active',Xo='completed';var _,Xg,Sg,Kg=-1;Yg();$g(1,null,{},o);_.o=Zo;_.p=function(){return this.ib};_.q=$o;_.r=function(){var a;return nh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var fd,gd,hd;$g(51,1,{},oh);_.H=function(a){var b;b=new oh;b.e=4;a>1?(b.c=th(this,a-1)):(b.c=this);return b};_.I=function(){mh(this);return this.b};_.J=function(){return nh(this)};_.K=function(){mh(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(mh(this),this.k)};_.e=0;_.g=0;var lh=1;var ie=qh(1);var _d=qh(51);$g(79,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var vd=qh(79);$g(36,1,wo,G);_.s=function(){return this.a.v(),null};var td=qh(36);$g(80,1,{},H);var ud=qh(80);var I;$g(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var wd=qh(43);$g(209,1,yo);_.r=function(){var a;return nh(this.ib)+'@'+(a=r(this)>>>0,a.toString(16))};var Ad=qh(209);$g(20,209,yo,W);_.t=function(){R(this)};_.u=Yo;_.a=false;_.d=0;_.k=false;var yd=qh(20);$g(114,1,wo,X);_.s=function(){return T(this.a)};var xd=qh(114);$g(134,1,{241:1},eb);var zd=qh(134);$g(17,209,{9:1,17:1},ob);_.t=function(){fb(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Cd=qh(17);$g(113,1,Bo,pb);_.v=function(){gb(this.a)};var Bd=qh(113);$g(18,209,{9:1,18:1},Bb,Cb);_.t=function(){qb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Hd=qh(18);$g(115,1,Eo,Db);_.v=function(){Q(this.a)};var Dd=qh(115);$g(116,1,Bo,Eb);_.v=function(){sb(this.a)};var Ed=qh(116);$g(117,1,Bo,Fb);_.v=function(){vb(this.a)};var Fd=qh(117);$g(118,1,{},Gb);_.w=function(a){tb(this.a,a)};var Gd=qh(118);$g(133,1,{},Jb);_.a=0;_.b=0;_.c=0;var Id=qh(133);$g(154,1,yo,Lb);_.t=function(){Kb(this)};_.u=Yo;_.a=false;var Jd=qh(154);$g(61,209,{9:1,61:1},Qb);_.t=function(){Mb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Kd=qh(61);$g(136,1,{},ac);_.r=function(){var a;return mh(Ld),Ld.k+'@'+(a=zj(this)>>>0,a.toString(16))};_.a=0;var Rb;var Ld=qh(136);$g(101,1,{});var Od=qh(101);$g(81,1,{},gc);_.w=function(a){ec(this.a,a)};var Md=qh(81);$g(82,1,Bo,hc);_.v=function(){fc(this.a,this.b)};var Nd=qh(82);$g(102,101,{});var Pd=qh(102);$g(16,1,yo,oc);_.t=function(){jc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return mh(Rd),Rd.k+'@'+(a=zj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Rd=qh(16);$g(112,1,Bo,pc);_.v=function(){mc(this.a)};var Qd=qh(112);$g(5,1,{3:1,5:1});_.B=function(a){return new Error(a)};_.C=function(){return this.f};_.D=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=nh(this.ib),c==null?a:a+': '+c);rc(this,tc(this.B(b)));Vc(this)};_.r=function(){return sc(this,this.C())};_.e=Fo;_.g=true;var me=qh(5);$g(12,5,{3:1,12:1,5:1});var ce=qh(12);$g(8,12,Ho);var je=qh(8);$g(52,8,Ho);var fe=qh(52);$g(73,52,Ho);var Vd=qh(73);$g(35,73,{35:1,3:1,12:1,8:1,5:1},yc);_.C=function(){xc(this);return this.c};_.F=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Sd=qh(35);var Td=qh(0);$g(195,1,{});var Ud=qh(195);var Ac=0,Bc=0,Cc=-1;$g(100,195,{},Qc);var Mc;var Wd=qh(100);var Tc;$g(206,1,{});var Yd=qh(206);$g(74,206,{},Xc);var Xd=qh(74);var gh;$g(71,1,{68:1});_.r=Yo;var Zd=qh(71);fd={3:1,69:1,31:1};var $d=qh(69);$g(41,1,{3:1,41:1});var he=qh(41);gd={3:1,31:1,41:1};var ae=qh(205);$g(33,1,{3:1,31:1,33:1});_.o=Zo;_.q=$o;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=qh(33);$g(75,8,Ho,zh);var de=qh(75);$g(32,41,{3:1,31:1,32:1,41:1},Ah);_.o=function(a){return ld(a,32)&&a.a==this.a};_.q=Yo;_.r=function(){return ''+this.a};_.a=0;var ee=qh(32);var Ch;$g(273,1,{});$g(77,52,Ho,Fh);_.B=function(a){return new TypeError(a)};var ge=qh(77);hd={3:1,68:1,31:1,2:1};var le=qh(2);$g(72,71,{68:1},Lh);var ke=qh(72);$g(277,1,{});$g(54,8,Ho,Mh);var ne=qh(54);$g(207,1,{39:1});_.N=cp;_.R=function(){return new Xi(this,0)};_.S=function(){return new fj(null,this.R())};_.P=function(a){throw Mg(new Mh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Zi('[',']');for(b=this.O();b.U();){a=b.V();Yi(c,a===this?'(this Collection)':a==null?Io:dh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var oe=qh(207);$g(210,1,{193:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ld(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new $h((new Xh(d)).a);c.b;){b=Zh(c);if(!Ph(this,b)){return false}}return true};_.q=function(){return pi(new Xh(this))};_.r=function(){var a,b,c;c=new Zi('{','}');for(b=new $h((new Xh(this)).a);b.b;){a=Zh(b);Yi(c,Qh(this,a.X())+'='+Qh(this,a.Y()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ze=qh(210);$g(119,210,{193:1});var re=qh(119);$g(211,207,{39:1,222:1});_.R=function(){return new Xi(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ld(a,23)){return false}b=a;if(Vh(b.a)!=this.Q()){return false}return Nh(this,b)};_.q=function(){return pi(this)};var Ae=qh(211);$g(23,211,{23:1,39:1,222:1},Xh);_.O=function(){return new $h(this.a)};_.Q=ap;var qe=qh(23);$g(24,1,{},$h);_.T=_o;_.V=function(){return Zh(this)};_.U=bp;_.b=false;var pe=qh(24);$g(208,207,{39:1,219:1});_.R=function(){return new Xi(this,16)};_.W=function(a,b){throw Mg(new Mh('Add not supported on this list'))};_.P=function(a){this.W(this.Q(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.Q()!=f.a.length){return false}e=new oi(f);for(c=new oi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return qi(this)};_.O=function(){return new _h(this)};var te=qh(208);$g(99,1,{},_h);_.T=_o;_.U=function(){return this.a<this.b.a.length};_.V=function(){return gi(this.b,this.a++)};_.a=0;var se=qh(99);$g(55,207,{39:1},ai);_.O=function(){var a;a=new $h((new Xh(this.a)).a);return new bi(a)};_.Q=ap;var ve=qh(55);$g(122,1,{},bi);_.T=_o;_.U=function(){return this.a.b};_.V=function(){var a;a=Zh(this.a);return a.Y()};var ue=qh(122);$g(120,1,Ko);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return ri(this.a,b.X())&&ri(this.b,b.Y())};_.X=Yo;_.Y=bp;_.q=function(){return Si(this.a)^Si(this.b)};_.Z=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var we=qh(120);$g(121,120,Ko,ci);var xe=qh(121);$g(212,1,Ko);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return ri(this.b.value[0],b.X())&&ri(Oi(this),b.Y())};_.q=function(){return Si(this.b.value[0])^Si(Oi(this))};_.r=function(){return this.b.value[0]+'='+Oi(this)};var ye=qh(212);$g(14,208,{3:1,14:1,39:1,219:1},mi,ni);_.W=function(a,b){tj(this.a,a,b)};_.P=function(a){return ei(this,a)};_.N=function(a){fi(this,a)};_.O=function(){return new oi(this)};_.Q=function(){return this.a.length};var Ce=qh(14);$g(19,1,{},oi);_.T=_o;_.U=function(){return this.a<this.c.a.length};_.V=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Be=qh(19);$g(37,119,{3:1,37:1,193:1},si);var De=qh(37);$g(59,1,{},yi);_.N=cp;_.O=function(){return new zi(this)};_.b=0;var Fe=qh(59);$g(60,1,{},zi);_.T=_o;_.V=function(){return this.d=this.a[this.c++],this.d};_.U=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ee=qh(60);var Ci;$g(57,1,{},Mi);_.N=cp;_.O=function(){return new Ni(this)};_.b=0;_.c=0;var Ie=qh(57);$g(58,1,{},Ni);_.T=_o;_.V=function(){return this.c=this.a,this.a=this.b.next(),new Pi(this.d,this.c,this.d.c)};_.U=function(){return !this.a.done};var Ge=qh(58);$g(135,212,Ko,Pi);_.X=function(){return this.b.value[0]};_.Y=function(){return Oi(this)};_.Z=function(a){return Ki(this.a,this.b.value[0],a)};_.c=0;var He=qh(135);$g(138,1,{});_.T=function(a){Ui(this,a)};_.$=function(){return this.d};_._=function(){return this.e};_.d=0;_.e=0;var Ke=qh(138);$g(62,138,{});var Je=qh(62);$g(25,1,{},Xi);_.$=Yo;_._=function(){Wi(this);return this.c};_.T=function(a){Wi(this);this.d.T(a)};_.ab=function(a){Wi(this);if(this.d.U()){a.w(this.d.V());return true}return false};_.a=0;_.c=0;var Le=qh(25);$g(53,1,{},Zi);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Me=qh(53);$g(137,1,{});_.c=false;var Ve=qh(137);$g(28,137,{242:1,28:1},fj);var Ue=qh(28);$g(140,62,{},jj);_.ab=function(a){this.b=false;while(!this.b&&this.c.ab(new kj(this,a)));return this.b};_.b=false;var Oe=qh(140);$g(143,1,{},kj);_.w=function(a){ij(this.a,this.b,a)};var Ne=qh(143);$g(139,62,{},lj);_.ab=function(a){return this.a.ab(new mj(a))};var Qe=qh(139);$g(142,1,{},mj);_.w=function(a){this.a.w(Em(new Fm,a))};var Pe=qh(142);$g(141,1,{},oj);_.w=function(a){nj(this,a)};var Re=qh(141);$g(144,1,{},pj);_.w=function(a){};var Se=qh(144);$g(145,1,{},rj);_.w=function(a){qj(this,a)};var Te=qh(145);$g(275,1,{});$g(216,1,{});var We=qh(216);$g(272,1,{});var yj=0;var Aj,Bj=0,Cj;$g(891,1,{});$g(913,1,{});$g(213,1,{});var Xe=qh(213);$g(243,$wnd.Function,{},Qj);_.cb=function(a){Pj(this.a,this.b,a)};$g(7,33,{3:1,31:1,33:1,7:1},zk);var ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk;var Ye=rh(7,Ak);var Bk;$g(244,$wnd.Function,{},Dk);_.G=function(a){return Kb(Bk),Bk=null,null};$g(217,213,{});var Ff=qh(217);$g(167,217,{});_.d=0;var Jf=qh(167);$g(168,167,yo,Kk);_.t=dp;_.o=Zo;_.q=$o;_.u=ep;_.r=function(){var a;return mh(ff),ff.k+'@'+(a=zj(this)>>>0,a.toString(16))};var Hk=0;var ff=qh(168);$g(169,1,Bo,Lk);_.v=function(){Ik(this.a)};var Ze=qh(169);$g(170,1,wo,Mk);_.s=function(){return kh(),S((Lm(),Im).b).a>0?true:false};var $e=qh(170);$g(171,1,Eo,Nk);_.v=function(){Fk(this.a)};var _e=qh(171);$g(172,1,wo,Ok);_.s=function(){return Gk(this.a)};var af=qh(172);$g(218,213,{});var Ef=qh(218);$g(187,218,{});_.c=0;var If=qh(187);$g(188,187,yo,Tk);_.t=fp;_.o=Zo;_.q=$o;_.u=gp;_.r=function(){var a;return mh(ef),ef.k+'@'+(a=zj(this)>>>0,a.toString(16))};var Rk=0;var ef=qh(188);$g(189,1,Bo,Uk);_.v=hp;var bf=qh(189);$g(190,1,Eo,Vk);_.v=function(){Qk(this.a)};var cf=qh(190);$g(191,1,wo,Wk);_.s=function(){var a,b;return this.a.c=0,Ck(),a=S((Lm(),Im).e).a,b='item'+(a==1?'':'s'),Oj('span',Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,['todo-count'])),[Oj('strong',null,[a]),' '+b+' left'])};var df=qh(191);$g(159,213,{});_.e='';var Rf=qh(159);$g(160,159,{});_.d=0;var Lf=qh(160);$g(161,160,yo,gl);_.t=dp;_.o=Zo;_.q=$o;_.u=ep;_.r=function(){var a;return mh(mf),mf.k+'@'+(a=zj(this)>>>0,a.toString(16))};var al=0;var mf=qh(161);$g(162,1,Bo,hl);_.v=function(){bl(this.a)};var gf=qh(162);$g(164,1,wo,il);_.s=function(){return _k(this.a)};var hf=qh(164);$g(165,1,Bo,jl);_.v=function(){Xk(this.a)};var jf=qh(165);$g(166,1,Bo,kl);_.v=function(){dl(this.a,this.b)};var kf=qh(166);$g(163,1,Eo,ll);_.v=function(){Fk(this.a)};var lf=qh(163);$g(215,213,{});_.i=false;var Tf=qh(215);$g(174,215,{});_.f=0;var Nf=qh(174);$g(175,174,yo,Gl);_.t=function(){jc(this.e)};_.o=Zo;_.q=$o;_.u=function(){return this.e.i<0};_.r=function(){var a;return mh(xf),xf.k+'@'+(a=zj(this)>>>0,a.toString(16))};var wl=0;var xf=qh(175);$g(176,1,Bo,Hl);_.v=function(){xl(this.a)};var nf=qh(176);$g(179,1,wo,Il);_.s=function(){return vl(this.a)};var of=qh(179);$g(63,1,Bo,Jl);_.v=function(){Fl(this.a,Um(this.b))};var pf=qh(63);$g(177,1,wo,Kl);_.s=function(){return zl(this.a)};var qf=qh(177);$g(64,1,Bo,Ll);_.v=function(){ql(this.a,this.b)};var rf=qh(64);$g(180,1,Bo,Ml);_.v=function(){pl(this.a,this.b)};var sf=qh(180);$g(181,1,Bo,Nl);_.v=function(){El(this.a,this.b);_n((Lm(),Km),null)};var tf=qh(181);$g(182,1,Bo,Ol);_.v=function(){ml(this.a,this.b)};var uf=qh(182);$g(178,1,Eo,Pl);_.v=function(){ul(this.a)};var vf=qh(178);$g(183,1,Bo,Ql);_.v=function(){rl(this.a)};var wf=qh(183);$g(214,213,{});var Vf=qh(214);$g(147,214,{});_.c=0;var Pf=qh(147);$g(148,147,yo,Vl);_.t=fp;_.o=Zo;_.q=$o;_.u=gp;_.r=function(){var a;return mh(Bf),Bf.k+'@'+(a=zj(this)>>>0,a.toString(16))};var Tl=0;var Bf=qh(148);$g(149,1,Bo,Wl);_.v=hp;var yf=qh(149);$g(150,1,Eo,Xl);_.v=function(){Qk(this.a)};var zf=qh(150);$g(151,1,wo,Yl);_.s=function(){var a;return this.a.c=0,Ck(),Oj('div',null,[Oj('div',null,[Oj(So,Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,[So])),[Oj('h1',null,['todos']),(new wm).a]),S((Lm(),Im).c)?null:Oj('section',Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,[So])),[Oj(Ro,Yj(_j(Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,['toggle-all'])),(yk(),dk)),ah(Gm.prototype.eb,Gm,[])),null),Oj('ul',Rj(new $wnd.Object,cd(Yc(le,1),xo,2,6,['todo-list'])),(a=ej(Ti(dj(S(Km.c).S())),new mi),li(a,bd(a.a.length))))]),S(Im.c)?null:(new $l).a])])};var Af=qh(151);$g(248,$wnd.Function,{},Zl);_.gb=function(a){Ln((Lm(),Jm))};$g(153,1,{},$l);var Cf=qh(153);$g(173,1,{},_l);var Df=qh(173);$g(249,$wnd.Function,{},am);_.hb=function(a){return new dm(a)};var bm;$g(157,$wnd.React.Component,{},dm);Zg(Xg[1],_);_.componentWillUnmount=function(){Ek(this.a)};_.render=function(){return Jk(this.a)};_.shouldComponentUpdate=ip;var Gf=qh(157);$g(259,$wnd.Function,{},em);_.hb=function(a){return new hm(a)};var fm;$g(184,$wnd.React.Component,{},hm);Zg(Xg[1],_);_.componentWillUnmount=function(){Pk(this.a)};_.render=function(){return Sk(this.a)};_.shouldComponentUpdate=jp;var Hf=qh(184);$g(247,$wnd.Function,{},im);_.hb=function(a){return new lm(a)};var jm;$g(155,$wnd.React.Component,{},lm);Zg(Xg[1],_);_.componentWillUnmount=function(){Ek(this.a)};_.render=function(){return el(this.a)};_.shouldComponentUpdate=ip;var Kf=qh(155);$g(258,$wnd.Function,{},mm);_.hb=function(a){return new pm(a)};var nm;$g(158,$wnd.React.Component,{},pm);Zg(Xg[1],_);_.componentDidUpdate=function(a){Cl(this.a)};_.componentWillUnmount=function(){tl(this.a)};_.render=function(){return Dl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Mf=qh(158);$g(240,$wnd.Function,{},qm);_.hb=function(a){return new tm(a)};var rm;$g(124,$wnd.React.Component,{},tm);Zg(Xg[1],_);_.componentWillUnmount=function(){Pk(this.a)};_.render=function(){return Ul(this.a)};_.shouldComponentUpdate=jp;var Of=qh(124);$g(245,$wnd.Function,{},um);_.fb=function(a){Yk(this.a,a)};$g(246,$wnd.Function,{},vm);_.eb=function(a){cl(this.a,a)};$g(152,1,{},wm);var Qf=qh(152);$g(256,$wnd.Function,{},xm);_.eb=function(a){yl(this.a,a)};$g(250,$wnd.Function,{},ym);_.eb=function(a){on(this.a)};$g(252,$wnd.Function,{},zm);_.gb=function(a){Al(this.a,this.b)};$g(253,$wnd.Function,{},Am);_.gb=function(a){sl(this.a)};$g(254,$wnd.Function,{},Bm);_.w=function(a){nl(this.a,a)};$g(255,$wnd.Function,{},Cm);_.db=function(a){Bl(this.a,this.b)};$g(257,$wnd.Function,{},Dm);_.fb=function(a){ol(this.a,this.b,a)};$g(156,1,{},Fm);var Sf=qh(156);$g(239,$wnd.Function,{},Gm);_.eb=function(a){var b;b=a.target;Pn((Lm(),Jm),b.checked)};$g(67,1,{},Hm);var Uf=qh(67);var Im,Jm,Km;$g(125,1,{});var zg=qh(125);$g(126,125,Uo,Ym);_.t=dp;_.o=Zo;_.q=$o;_.u=ep;_.A=kp;_.r=function(){var a;return mh(bg),bg.k+'@'+(a=zj(this)>>>0,a.toString(16))};var bg=qh(126);$g(127,1,Bo,Zm);_.v=function(){Sm(this.a)};var Wf=qh(127);$g(129,1,Eo,$m);_.v=function(){Nm(this.a)};var Xf=qh(129);$g(130,1,Eo,_m);_.v=function(){Om(this.a)};var Yf=qh(130);$g(131,1,Bo,an);_.v=function(){Mm(this.a,this.b)};var Zf=qh(131);$g(132,1,Bo,bn);_.v=function(){Vm(this.a)};var $f=qh(132);$g(56,1,Bo,cn);_.v=function(){Rm(this.a)};var _f=qh(56);$g(128,1,wo,dn);_.s=function(){var a;return a=(hh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var ag=qh(128);$g(44,1,{44:1});_.d=false;var Hg=qh(44);$g(45,44,{9:1,49:1,45:1,44:1},pn);_.t=dp;_.o=function(a){return hn(this,a)};_.q=function(){return this.c.d};_.u=ep;_.A=kp;_.r=function(){var a;return mh(rg),rg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var en=0;var rg=qh(45);$g(185,1,Bo,qn);_.v=function(){fn(this.a)};var cg=qh(185);$g(186,1,Bo,rn);_.v=function(){ln(this.a)};var dg=qh(186);$g(42,102,{42:1});var Cg=qh(42);$g(103,42,{9:1,49:1,42:1},An);_.t=function(){jc(this.f)};_.o=Zo;_.q=$o;_.u=function(){return this.f.i<0};_.A=function(a){nc(this.f,a)};_.r=function(){var a;return mh(mg),mg.k+'@'+(a=zj(this)>>>0,a.toString(16))};var mg=qh(103);$g(105,1,Bo,Bn);_.v=function(){tn(this.a)};var eg=qh(105);$g(104,1,Bo,Cn);_.v=function(){xn(this.a)};var fg=qh(104);$g(110,1,Bo,Dn);_.v=function(){dc(this.a,this.b,true)};var gg=qh(110);$g(111,1,wo,En);_.s=function(){return sn(this.a,this.c,this.b)};_.b=false;var hg=qh(111);$g(106,1,wo,Fn);_.s=function(){return yn(this.a)};var ig=qh(106);$g(107,1,wo,Gn);_.s=function(){return Bh(Rg(bj(wn(this.a))))};var jg=qh(107);$g(108,1,wo,Hn);_.s=function(){return Bh(Rg(bj(cj(wn(this.a),new oo))))};var kg=qh(108);$g(109,1,wo,In);_.s=function(){return zn(this.a)};var lg=qh(109);$g(87,1,{});var Gg=qh(87);$g(88,87,Uo,Qn);_.t=function(){jc(this.a)};_.o=Zo;_.q=$o;_.u=function(){return this.a.i<0};_.A=function(a){nc(this.a,a)};_.r=function(){var a;return mh(qg),qg.k+'@'+(a=zj(this)>>>0,a.toString(16))};var qg=qh(88);$g(89,1,Bo,Rn);_.v=function(){Mn(this.a,this.b)};_.b=false;var ng=qh(89);$g(90,1,Bo,Sn);_.v=function(){Xm(this.b,this.a)};var og=qh(90);$g(91,1,Bo,Tn);_.v=function(){Nn(this.a)};var pg=qh(91);$g(92,1,{});var Jg=qh(92);$g(93,92,Uo,ao);_.t=function(){jc(this.g)};_.o=Zo;_.q=$o;_.u=function(){return this.g.i<0};_.A=function(a){nc(this.g,a)};_.r=function(){var a;return mh(xg),xg.k+'@'+(a=zj(this)>>>0,a.toString(16))};var xg=qh(93);$g(94,1,Bo,bo);_.v=function(){Wn(this.a)};var sg=qh(94);$g(95,1,wo,co);_.s=function(){var a;return a=Um(this.a.i),Hh(Wo,a)?(lo(),io):Hh(Xo,a)?(lo(),ko):(lo(),jo)};var tg=qh(95);$g(96,1,wo,eo);_.s=function(){return Yn(this.a)};var ug=qh(96);$g(97,1,Eo,fo);_.v=function(){Zn(this.a)};var vg=qh(97);$g(98,1,Eo,go);_.v=function(){$n(this.a)};var wg=qh(98);$g(123,1,{},ho);_.handleEvent=function(a){Pm(this.a,a)};var yg=qh(123);$g(34,33,{3:1,31:1,33:1,34:1},mo);var io,jo,ko;var Ag=rh(34,no);$g(83,1,{},oo);_.bb=function(a){return !kn(a)};var Bg=qh(83);$g(85,1,{},po);_.bb=function(a){return kn(a)};var Dg=qh(85);$g(86,1,{},qo);_.w=function(a){vn(this.a,a)};var Eg=qh(86);$g(84,1,{},ro);_.w=function(a){Kn(this.a,a)};_.a=false;var Fg=qh(84);$g(76,1,{},so);_.bb=function(a){return Vn(this.a,a)};var Ig=qh(76);var sd=sh('D');var to=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=Vg;Tg(fh);Wg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();