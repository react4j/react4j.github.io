function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='AC2CF975C891B55841F712E2717DD6F1',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'AC2CF975C891B55841F712E2717DD6F1';function o(){}
function Xg(){}
function Tg(){}
function Tc(){}
function Mc(){}
function Ib(){}
function aj(){}
function bj(){}
function qk(){}
function zk(){}
function Ql(){}
function Tl(){}
function Xl(){}
function _l(){}
function dm(){}
function hm(){}
function xm(){}
function Wm(){}
function eo(){}
function fo(){}
function Rc(a){Qc()}
function bh(){bh=Tg}
function ai(){Th(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function mb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function hc(a){this.a=a}
function nc(a){this.a=a}
function rh(a){this.a=a}
function Lh(a){this.a=a}
function Qh(a){this.a=a}
function Rh(a){this.a=a}
function Ph(a){this.b=a}
function ci(a){this.c=a}
function $i(a){this.a=a}
function dj(a){this.a=a}
function yk(a){this.a=a}
function Ak(a){this.a=a}
function Bk(a){this.a=a}
function Hk(a){this.a=a}
function Ik(a){this.a=a}
function Jk(a){this.a=a}
function Wk(a){this.a=a}
function Xk(a){this.a=a}
function Yk(a){this.a=a}
function $k(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function Cl(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Nl(a){this.a=a}
function Ol(a){this.a=a}
function Pl(a){this.a=a}
function lm(a){this.a=a}
function mm(a){this.a=a}
function om(a){this.a=a}
function pm(a){this.a=a}
function rm(a){this.a=a}
function sm(a){this.a=a}
function Qm(a){this.a=a}
function Rm(a){this.a=a}
function Sm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function fn(a){this.a=a}
function gn(a){this.a=a}
function rn(a){this.a=a}
function sn(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function Jn(a){this.a=a}
function Tn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function go(a){this.a=a}
function ho(a){this.a=a}
function io(a){this.a=a}
function To(){jc(this.c)}
function Uo(){jc(this.b)}
function mi(){this.a=vi()}
function Ai(){this.a=vi()}
function _i(a,b){a.a=b}
function vj(a,b){a.key=b}
function uj(a,b){tj(a,b)}
function An(a,b){bn(b,a)}
function tb(a,b){a.b=Hi(b)}
function cc(a,b){Hh(a.b,b)}
function cj(a,b){Vi(a.a,b)}
function zn(a,b){kn(a.b,b)}
function Oo(a){Ei(this,a)}
function So(a){vh(this,a)}
function Vo(){nb(this.a.a)}
function gb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function kb(a){Yb((J(),a))}
function w(a){--a.e;D(a)}
function kc(a){!!a&&a.s()}
function V(a){gd(a,8)&&a.r()}
function Lb(a){a.a=-4&a.a|1}
function rk(a){a.d=2;jc(a.c)}
function Ck(a){a.c=2;jc(a.b)}
function gl(a){a.f=2;jc(a.e)}
function Eg(a){return a.b}
function Ro(){return this.b}
function Qo(){return this.a}
function yh(a,b){return a===b}
function al(a,b){return a.g=b}
function Wo(){return this.c.c}
function No(){return lj(this)}
function Bh(a){rc.call(this,a)}
function vk(a){nb(a.b);R(a.a)}
function Jm(a){R(a.a);cb(a.b)}
function Qk(a){nb(a.a);cb(a.b)}
function C(a,b){ab(a.f,b.f)}
function ac(a,b,c){Gh(a.b,b,c)}
function hj(a,b){a.splice(b,1)}
function Wh(a,b){return a.a[b]}
function Mo(a){return this===a}
function ri(){ri=Tg;qi=ti()}
function J(){J=Tg;I=new F}
function Jc(){Jc=Tg;Ic=new Mc}
function tc(){tc=Tg;sc=new o}
function dc(){this.b=new gi}
function wh(){oc(this);this.w()}
function Po(){return Jh(this.a)}
function Uc(a,b){return kh(a,b)}
function Ui(a,b){a.L(b);return a}
function fh(a){eh(a);return a.k}
function vi(){ri();return new qi}
function db(a){J();Xb(a);a.e=-2}
function Ym(a){cb(a.b);cb(a.a)}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function fl(a){ln((Cm(),zm),a)}
function zc(){zc=Tg;!!(Qc(),Pc)}
function Hc(){wc!=0&&(wc=0);yc=-1}
function Mg(){Kg==null&&(Kg=[])}
function W(a){return !!a&&a.c.i<0}
function Jh(a){return a.a.b+a.b.b}
function Zc(a){return new Array(a)}
function v(a,b,c){s(a,new H(c),b)}
function Vi(a,b){_i(a,Ui(a.a,b))}
function Ii(a,b){while(a.Y(b));}
function xi(a,b){return a.a.get(b)}
function Lm(a){ib(a.b);return a.e}
function _m(a){ib(a.a);return a.d}
function Nn(a){ib(a.d);return a.f}
function Ej(a,b){a.ref=b;return a}
function Fj(a,b){a.href=b;return a}
function Cj(a,b){this.a=a;this.b=b}
function ic(a,b){this.a=a;this.b=b}
function ph(a,b){this.a=a;this.b=b}
function Sh(a,b){this.a=a;this.b=b}
function Yi(a,b){this.a=a;this.b=b}
function Zk(a,b){this.a=a;this.b=b}
function zl(a,b){this.a=a;this.b=b}
function Al(a,b){this.a=a;this.b=b}
function Bl(a,b){this.a=a;this.b=b}
function Dl(a,b){this.a=a;this.b=b}
function El(a,b){this.a=a;this.b=b}
function Hl(a,b){this.a=a;this.b=b}
function qm(a,b){this.a=a;this.b=b}
function tm(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function Tm(a,b){this.a=a;this.b=b}
function tn(a,b){this.a=a;this.b=b}
function Hn(a,b){this.a=a;this.b=b}
function In(a,b){this.b=a;this.a=b}
function mk(a,b){ph.call(this,a,b)}
function bo(a,b){ph.call(this,a,b)}
function fj(a,b,c){a.splice(b,0,c)}
function Pj(a,b){a.value=b;return a}
function Gc(a){$wnd.clearTimeout(a)}
function nm(){this.a=wj((bm(),am))}
function wm(){this.a=wj((fm(),em))}
function ym(){this.a=wj((jm(),im))}
function Rl(){this.a=wj((Vl(),Ul))}
function Sl(){this.a=wj((Zl(),Yl))}
function Mm(a){Km(a,(ib(a.b),a.e))}
function an(a){bn(a,(ib(a.a),!a.d))}
function Sb(a){return !a.d?a:Sb(a.d)}
function Fh(a){return !a?null:a.U()}
function ld(a){return a==null?null:a}
function Gi(a){return a!=null?r(a):0}
function jd(a){return typeof a===ko}
function Ih(a){a.a=new mi;a.b=new Ai}
function Th(a){a.a=Wc(be,mo,1,0,5,1)}
function sb(a){J();rb(a);vb(a,2,true)}
function B(a,b,c){return t(a,c,2048,b)}
function A(a,b,c){t(a,new G(b),c,null)}
function gj(a,b){ej(b,0,a,0,b.length)}
function gc(a,b){ec(a,b,false);hb(a.d)}
function tj(a,b){for(var c in a){b(c)}}
function Kj(a,b){a.onBlur=b;return a}
function Gj(a,b){a.onClick=b;return a}
function Lj(a,b){a.onChange=b;return a}
function Ij(a,b){a.checked=b;return a}
function lb(a){this.c=new ai;this.b=a}
function Gb(a){this.d=Hi(a);this.b=100}
function P(){this.a=Wc(be,mo,1,100,5,1)}
function ib(a){var b;Tb((J(),b=Ob,b),a)}
function X(a){return !(!!a&&1==(a.c&7))}
function lj(a){return a.$H||(a.$H=++kj)}
function Ah(a){return !a?'null':''+a.a}
function gd(a,b){return a!=null&&ed(a,b)}
function xh(a,b){return a.charCodeAt(b)}
function _c(a,b,c){return {l:a,m:b,h:c}}
function jj(b,c,d){try{b[c]=d}catch(a){}}
function Mj(a,b){a.onKeyDown=b;return a}
function Hj(a){a.autoFocus=true;return a}
function eh(a){if(a.k!=null){return}mh(a)}
function pc(a,b){a.b=b;b!=null&&jj(b,vo,a)}
function Ei(a,b){while(a.Q()){cj(b,a.R())}}
function Ti(a,b){Oi.call(this,a);this.a=b}
function rc(a){this.c=a;oc(this);this.w()}
function gi(){this.a=new mi;this.b=new Ai}
function pj(){pj=Tg;mj=new o;oj=new o}
function kd(a){return typeof a==='string'}
function hd(a){return typeof a==='boolean'}
function u(a,b){return new yb(Hi(a),null,b)}
function oi(a,b){var c;c=a[zo];c.call(a,b)}
function sl(a){A((J(),J(),I),new Fl(a),Eo)}
function Nm(a){A((J(),J(),I),new Um(a),Eo)}
function dn(a){A((J(),J(),I),new gn(a),Eo)}
function Bn(a){A((J(),J(),I),new Jn(a),Eo)}
function Pn(a){W((ib(a.d),a.f))&&Rn(a,null)}
function Jb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&vb(a.f,5,true)}
function oc(a){a.d&&a.b!==uo&&a.w();return a}
function Jj(a,b){a.defaultValue=b;return a}
function Qj(a,b){a.onDoubleClick=b;return a}
function ih(a){var b;b=hh(a);oh(a,b);return b}
function fc(a,b){cc(b.u(),a);gd(b,8)&&b.r()}
function Ac(a,b,c){return a.apply(b,c);var d}
function pn(a){return sh(S(a.e).a-S(a.a).a)}
function ll(a){nb(a.b);R(a.d);cb(a.c);cb(a.a)}
function $(a,b,c){Lb(Hi(c));K(a.a[b],Hi(c))}
function Di(a,b,c){this.a=a;this.b=b;this.c=c}
function Uh(a,b){a.a[a.a.length]=b;return true}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function Rk(a,b){A((J(),J(),I),new Zk(a,b),Eo)}
function nl(a,b){A((J(),J(),I),new El(a,b),Eo)}
function ql(a,b){A((J(),J(),I),new Bl(a,b),Eo)}
function rl(a,b){A((J(),J(),I),new Al(a,b),Eo)}
function ul(a,b){A((J(),J(),I),new zl(a,b),Eo)}
function ln(a,b){A((J(),J(),I),new tn(a,b),Eo)}
function En(a,b){A((J(),J(),I),new In(a,b),Eo)}
function Fn(a,b){A((J(),J(),I),new Hn(a,b),Eo)}
function Sk(a,b){var c;c=b.target;Uk(a,c.value)}
function qb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function un(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new bb;this.a=new Gb(this.f)}
function nn(a){vh(new Qh(a.g),new hc(a));Ih(a.g)}
function Fb(a){while(true){if(!Eb(a)){break}}}
function pl(a,b){return bh(),hl(a,b)?true:false}
function wi(a,b){return !(a.a.get(b)===undefined)}
function Yc(a){return Array.isArray(a)&&a.gb===Xg}
function on(a){return bh(),0==S(a.e).a?true:false}
function fd(a){return !Array.isArray(a)&&a.gb===Xg}
function Ki(a){if(!a.d){a.d=a.b.K();a.c=a.b.M()}}
function Hb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Wi(a,b,c){if(a.a.Z(c)){a.b=true;b.t(c)}}
function Nh(a){var b;b=a.a.R();a.b=Mh(a);return b}
function Yh(a,b){var c;c=a.a[b];hj(a.a,b);return c}
function Nc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Qc(){Qc=Tg;var a;!Sc();a=new Tc;Pc=a}
function $g(){$g=Tg;Zg=$wnd.window.document}
function uh(){uh=Tg;th=Wc(Zd,mo,30,256,0,1)}
function Ri(a){Ni(a);return new Ti(a,new Zi(a.a))}
function wk(a){return B((J(),J(),I),a.b,new Bk(a))}
function Fk(a){return B((J(),J(),I),a.a,new Jk(a))}
function Tk(a){return B((J(),J(),I),a.a,new Xk(a))}
function Ll(a){return B((J(),J(),I),a.a,new Pl(a))}
function tl(a){return B((J(),J(),I),a.b,new yl(a))}
function Kn(a){return yh(Lo,a)||yh(Go,a)||yh('',a)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function jn(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function Mi(a){if(!a.b){Ni(a);a.c=true}else{Mi(a.b)}}
function il(a){if(0==a.f){a.f=1;a.k.setState({})}}
function sk(a){if(0==a.d){a.d=1;a.k.forceUpdate()}}
function Dk(a){if(0==a.c){a.c=1;a.k.forceUpdate()}}
function sj(){if(nj==256){mj=oj;oj=new o;nj=0}++nj}
function Hi(a){if(a==null){throw Eg(new wh)}return a}
function Kh(a,b){if(b){return Eh(a.a,b)}return false}
function Qi(a,b){Ni(a);return new Ti(a,new Xi(b,a.a))}
function Km(a,b){A((J(),J(),I),new Tm(a,b),75497472)}
function Mn(a){nb(a.e);nb(a.a);R(a.b);R(a.c);cb(a.d)}
function bn(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function vl(a,b){var c;c=a.i;if(b!=c){a.i=b;hb(a.a)}}
function Uk(a,b){var c;c=a.e;if(b!=c){a.e=b;hb(a.b)}}
function Om(a,b){var c;c=a.e;if(b!=c){a.e=Hi(b);hb(a.b)}}
function jh(a,b){var c;c=hh(a);oh(a,c);c.e=b?8:0;return c}
function $h(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Oj(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Ji(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Li(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Zi(a){Ji.call(this,a.X(),a.W()&-6);this.a=a}
function Oi(a){if(!a){this.b=null;new ai}else{this.b=a}}
function Jg(a){if(jd(a)){return a|0}return a.l|a.m<<22}
function jb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function Im(a){var b;T(a.a);b=S(a.a);yh(a.f,b)&&Om(a,b)}
function fi(a,b){return ld(a)===ld(b)||a!=null&&p(a,b)}
function kn(a,b){return t((J(),J(),I),new un(a,b),Eo,null)}
function co(){ao();return $c(Uc(sg,1),mo,32,0,[Zn,_n,$n])}
function lh(a){if(a.I()){return null}var b=a.j;return Pg[b]}
function Pb(a){if(a.e){2==(a.e.c&7)||vb(a.e,4,true);rb(a.e)}}
function lc(a){kc(a.g);V(a.c);V(a.a);V(a.d);kc(a.b);kc(a.f)}
function Em(a){_g(($g(),$wnd.window.window),Io,a.d,false)}
function Fm(a){ah(($g(),$wnd.window.window),Io,a.d,false)}
function Fc(a){zc();$wnd.setTimeout(function(){throw a},0)}
function ob(a){C((J(),J(),I),a);0==(a.f.a&ro)&&D((null,I))}
function Cn(a,b){var c;Si(mn(a.b),(c=new ai,c)).J(new ho(b))}
function _k(a,b){var c;if(S(a.d)){c=b.target;vl(a,c.value)}}
function vh(a,b){var c,d;for(d=a.K();d.Q();){c=d.R();b.t(c)}}
function kh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.C(b))}
function ii(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Cm(){Cm=Tg;zm=new qn;Am=new Gn(zm);Bm=new Sn(zm)}
function fm(){fm=Tg;var a;em=(a=Ug(dm.prototype.db,dm,[]),a)}
function jm(){jm=Tg;var a;im=(a=Ug(hm.prototype.db,hm,[]),a)}
function bm(){bm=Tg;var a;am=(a=Ug(_l.prototype.db,_l,[]),a)}
function Vl(){Vl=Tg;var a;Ul=(a=Ug(Tl.prototype.db,Tl,[]),a)}
function Zl(){Zl=Tg;var a;Yl=(a=Ug(Xl.prototype.db,Xl,[]),a)}
function Vg(a){function b(){}
;b.prototype=a||{};return new b}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function Nj(a){a.placeholder='What needs to be done?';return a}
function qc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ni(a){if(a.b){Ni(a.b)}else if(a.c){throw Eg(new qh)}}
function mn(a){ib(a.d);return new Ti(null,new Li(new Qh(a.g),0))}
function ji(a,b){var c;return hi(b,ii(a,b==null?0:(c=r(b),c|0)))}
function Rg(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function cl(a,b){Rn((Cm(),Bm),b);A((J(),J(),I),new zl(a,b),Eo)}
function Gm(a,b){b.preventDefault();A((J(),J(),I),new Vm(a),Eo)}
function ml(a,b){return t((J(),J(),I),new Hl(a,b),75497472,null)}
function md(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function bi(a){Th(this);gj(this.a,Dh(a,Wc(be,mo,1,Jh(a.a),5,1)))}
function ni(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Wl(a){$wnd.React.Component.call(this,a);this.a=new xk(this)}
function $l(a){$wnd.React.Component.call(this,a);this.a=new Gk(this)}
function cm(a){$wnd.React.Component.call(this,a);this.a=new Vk(this)}
function gm(a){$wnd.React.Component.call(this,a);this.a=new wl(this)}
function km(a){$wnd.React.Component.call(this,a);this.a=new Ml(this)}
function Xi(a,b){Ji.call(this,b.X(),b.W()&-16449);this.a=a;this.c=b}
function eb(a,b){var c,d;Uh(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Rn(a,b){var c;c=a.f;if(!(b==c||!!b&&Zm(b,c))){a.f=b;hb(a.d)}}
function Dc(a,b,c){var d;d=Bc();try{return Ac(a,b,c)}finally{Ec(d)}}
function _g(a,b,c,d){a.addEventListener(b,c,(bh(),d?true:false))}
function ah(a,b,c,d){a.removeEventListener(b,c,(bh(),d?true:false))}
function Gn(a){this.b=Hi(a);J();this.a=new mc(0,null,null,true,false)}
function Bi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Pi(a){var b;Mi(a);b=0;while(a.a.Y(new bj)){b=Fg(b,1)}return b}
function Si(a,b){var c;Mi(a);c=new aj;c.a=b;a.a.P(new dj(c));return c.a}
function Dn(a){var b;Si(Qi(mn(a.b),new fo),(b=new ai,b)).J(new go(a.b))}
function Mb(b){try{b.b.s()}catch(a){a=Dg(a);if(!gd(a,5))throw Eg(a)}}
function Ec(a){a&&Lc((Jc(),Ic));--wc;if(a){if(yc!=-1){Gc(yc);yc=-1}}}
function Ln(a,b){return (ao(),$n)==a||(Zn==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function Hh(a,b){return kd(b)?b==null?li(a.a,null):zi(a.b,b):li(a.a,b)}
function ij(a,b){return Vc(b)!=10&&$c(q(b),b.fb,b.__elementTypeId$,Vc(b),a),a}
function Gh(a,b,c){return kd(b)?b==null?ki(a.a,null,c):yi(a.b,b,c):ki(a.a,b,c)}
function Bj(a,b,c){!yh(c,'key')&&!yh(c,'ref')&&(a[c]=b[c],undefined)}
function Xh(a,b,c){for(;c<a.a.length;++c){if(fi(b,a.a[c])){return c}}return -1}
function Ci(a){if(a.a.c!=a.c){return xi(a.a,a.b.value[0])}return a.b.value[1]}
function vc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Cc(b){zc();return function(){return Dc(b,this,arguments);var a}}
function Zh(a,b){var c;c=Xh(a,b,0);if(c==-1){return false}hj(a.a,c);return true}
function Zm(a,b){var c;if(gd(b,45)){c=b;return a.c.e==c.c.e}else{return false}}
function vm(a,b){vj(a.a,Ah(b?sh(b.c.e):null));Hi(b);a.a.props['a']=b;return a.a}
function ol(a){return bh(),Nn((Cm(),Bm))==(jb(a.c),a.k.props['a'])?true:false}
function On(a){var b,c;return b=S(a.b),Si(Qi(mn(a.j),new io(b)),(c=new ai,c))}
function Vh(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.t(c)}}
function Kk(a){var b;b=zh((ib(a.b),a.e));if(b.length>0){zn((Cm(),Am),b);Uk(a,'')}}
function Dm(a,b){a.f=b;yh(b,S(a.a))&&Om(a,b);Hm(b);A((J(),J(),I),new Vm(a),Eo)}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new nc(a)),67108864,null)}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new mb(a)),0,null);!!a.b&&nb(a.b)}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||nb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Fb(a.a)}finally{a.c=false}}}}
function Kc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Oc(b,c)}while(a.a);a.a=c}}
function Lc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Oc(b,c)}while(a.b);a.b=c}}
function Wc(a,b,c,d,e,f){var g;g=Xc(e,d);e!=10&&$c(Uc(a,f),b,c,e,g);return g}
function Lk(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Yk(a),Eo)}}
function ub(b){if(b){try{b.s()}catch(a){a=Dg(a);if(gd(a,5)){J()}else throw Eg(a)}}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function bb(){var a;this.a=Wc(qd,mo,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Oh(a){this.d=a;this.c=new Bi(this.d.b);this.a=this.c;this.b=Mh(this)}
function Nb(a,b){this.b=Hi(a);this.a=b|0|(0==(b&6291456)?so:0)|(0!=(b&229376)?0:98304)}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Uh((!a.b&&(a.b=new ai),a.b),b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new ai);a.c=c.c}b.d=true;Uh(a.c,Hi(b))}
function oh(a,b){var c;if(!a){return}b.j=a;var d=lh(b);if(!d){Pg[a]=[b];return}d.eb=b}
function Dg(a){var b;if(gd(a,5)){return a}b=a&&a[vo];if(!b){b=new uc(a);Rc(b)}return b}
function Ug(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function hh(a){var b;b=new gh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function wj(a){var b;b=yj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function zj(a){var b;return xj($wnd.React.StrictMode,null,null,(b={},b[Ao]=Hi(a),b))}
function xj(a,b,c,d){var e;e=yj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Hi(d);return e}
function zi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{oi(a.a,b);--a.b}return c}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Hi(b))}
function rb(a){var b,c;for(c=new ci(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function di(a){var b,c,d;d=0;for(c=new Oh(a.a);c.b;){b=Nh(c);d=d+(b?r(b):0);d=d|0}return d}
function Ch(a,b){var c,d;for(d=new Oh(b.a);d.b;){c=Nh(d);if(!Kh(a,c)){return false}}return true}
function Gg(a){var b;b=a.h;if(b==0){return a.l+a.m*so}if(b==1048575){return a.l+a.m*so-xo}return a}
function Mh(a){if(a.a.Q()){return true}if(a.a!=a.c){return false}a.a=new ni(a.d.a);return a.a.Q()}
function qh(){rc.call(this,"Stream already terminated, can't be modified or used")}
function Lg(){Mg();var a=Kg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Vc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Yg(){Cm();$wnd.ReactDOM.render(zj([(new ym).a]),($g(),Zg).getElementById('app'),null)}
function ao(){ao=Tg;Zn=new bo('ACTIVE',0);_n=new bo('COMPLETED',1);$n=new bo('ALL',2)}
function hn(a,b,c){var d;d=new en(b,c);ac(d.c.c,a,new ic(a,d));Gh(a.g,sh(d.c.e),d);hb(a.d);return d}
function ec(a,b,c){var d;d=Hh(a.g,b?sh(b.c.e):null);if(null!=d){cc(b.c.c,a);c&&!!b&&jc(b.c);hb(a.d)}}
function yi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function hl(a,b){var c,d;d=a.k.props;c=false;if(!(d['a']===b['a'])){hb(a.c);c=true}return c||1==a.f}
function hi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(fi(a,c.T())){return c}}return null}
function Ig(a){var b,c,d,e;e=a;d=0;if(e<0){e+=xo;d=1048575}c=md(e/so);b=md(e-c*so);return _c(b,c,d)}
function Qn(a){var b;b=S(a.i.a);yh(Lo,b)||yh(Go,b)||yh('',b)?Km(a.i,b):Kn(Lm(a.i))?Nm(a.i):Km(a.i,'')}
function S(a){ib(a.e);wb(a.f)&&pb(a.f);if(a.b){if(gd(a.b,9)){throw Eg(a.b)}else{throw Eg(a.b)}}return a.k}
function uc(a){tc();oc(this);this.b=a;a!=null&&jj(a,vo,this);this.c=a==null?'null':Wg(a);this.a=a}
function gh(){this.g=dh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function yb(a,b,c){xb.call(this,null,a,b,c|(!a?262144:oo)|(0==(c&6291456)?!a?ro:so:0)|0|0|0)}
function bl(a,b,c){27==c.which?A((J(),J(),I),new Dl(a,b),Eo):13==c.which&&A((J(),J(),I),new Al(a,b),Eo)}
function nb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Cb(a)),67108864,null);!!a.a&&R(a.a);Jb(a.f);a.c=a.c&-8|1}}
function pk(){if(!ok){ok=(++(J(),J(),I).e,new Ib);$wnd.Promise.resolve(null).then(Ug(qk.prototype.B,qk,[]))}}
function $c(a,b,c,d,e){e.eb=a;e.fb=b;e.gb=Xg;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Og(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function fb(a,b){var c,d;d=a.c;Zh(d,b);!!a.b&&oo!=(a.b.c&po)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function ad(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return _c(c&4194303,d&4194303,e&1048575)}
function sh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(uh(),th)[b];!c&&(c=th[b]=new rh(a));return c}return new rh(a)}
function Wg(a){var b;if(Array.isArray(a)&&a.gb===Xg){return fh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function rj(a){pj();var b,c,d;c=':'+a;d=oj[c];if(d!=null){return md(d)}d=mj[c];b=d==null?qj(a):md(d);sj();oj[c]=b;return b}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function ei(a){var b,c,d;d=1;for(c=new ci(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function bc(a){var b,c;if(!a.a){for(c=new ci(new bi(new Qh(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.s()}a.a=true}}
function dl(a,b){var c;c=(ib(a.a),a.i);if(null!=c&&c.length!=0){En((Cm(),b),c);Rn(Bm,null);vl(a,c)}else{ln((Cm(),zm),b)}}
function Fg(a,b){var c;if(jd(a)&&jd(b)){c=a+b;if(-17592186044416<c&&c<xo){return c}}return Gg(ad(jd(a)?Ig(a):a,jd(b)?Ig(b):b))}
function q(a){return kd(a)?de:jd(a)?Vd:hd(a)?Td:fd(a)?a.eb:Yc(a)?a.eb:a.eb||Array.isArray(a)&&Uc(Nd,1)||Nd}
function r(a){return kd(a)?rj(a):jd(a)?md(a):hd(a)?a?1231:1237:fd(a)?a.p():Yc(a)?lj(a):!!a&&!!a.hashCode?a.hashCode():lj(a)}
function p(a,b){return kd(a)?yh(a,b):jd(a)?a===b:hd(a)?a===b:fd(a)?a.n(b):Yc(a)?a===b:!!a&&!!a.equals?a.equals(b):ld(a)===ld(b)}
function Kb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&oo)?Mb(a):a.b.s();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function zb(a,b){xb.call(this,a,new Ab(a),null,b|(oo==(b&po)?0:524288)|(0==(b&6291456)?oo==(b&po)?so:ro:0)|0|268435456|0)}
function nk(){lk();return $c(Uc(Pe,1),mo,7,0,[Rj,Sj,Tj,Uj,Vj,Wj,Xj,Yj,Zj,$j,_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk])}
function Gk(a){var b;this.k=Hi(a);J();b=++Ek;this.b=new mc(b,null,new Hk(this),false,false);this.a=new yb(null,Hi(new Ik(this)),Do)}
function Ml(a){var b;this.k=Hi(a);J();b=++Kl;this.b=new mc(b,null,new Nl(this),false,false);this.a=new yb(null,Hi(new Ol(this)),Do)}
function U(a,b,c,d){this.c=Hi(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new zb(this,d);this.e=new lb(this.f);oo==(d&po)&&ob(this.f)}
function mc(a,b,c,d,e){var f;this.e=a;this.c=d?new dc:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new lb((J(),null)),f):null;this.d=null}
function Ub(a){var b;if(a.c){while(a.c.a.length!=0){b=Yh(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&vb(b.b,3,true)}}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ci(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&vb(b,5,true)}}}
function Xb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ci(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&vb(b,6,true)}}}
function el(a){var b;b=S(a.d);if(!a.j&&b){a.j=true;ul(a,(jb(a.c),a.k.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function nh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function _h(a,b){var c,d;d=a.a.length;b.length<d&&(b=ij(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Dj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Bc(){var a;if(wc!=0){a=vc();if(a-xc>2000){xc=a;yc=$wnd.setTimeout(Hc,10)}}if(wc++==0){Kc((Jc(),Ic));return true}return false}
function Sc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function ed(a,b){if(kd(a)){return !!dd[b]}else if(a.fb){return !!a.fb[b]}else if(jd(a)){return !!cd[b]}else if(hd(a)){return !!bd[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function zh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Xc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{$b(b,d);try{f=(c.a.s(),null)}finally{_b()}return f}catch(a){a=Dg(a);if(gd(a,5)){e=a;throw Eg(e)}else throw Eg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.q()}else{$b(b,e);try{g=c.q()}finally{_b()}}return g}catch(a){a=Dg(a);if(gd(a,5)){f=a;throw Eg(f)}else throw Eg(a)}finally{D(b)}}
function en(a,b){var c,d,e;this.e=Hi(a);this.d=b;J();c=++Xm;this.c=new mc(c,null,new fn(this),true,true);this.b=(e=new lb(null),e);this.a=(d=new lb(null),d)}
function Vk(a){var b,c;this.k=Hi(a);J();b=++Pk;this.c=new mc(b,null,new Wk(this),false,false);this.b=(c=new lb(null),c);this.a=new yb(null,Hi(new $k(this)),Do)}
function xk(a){var b;this.k=Hi(a);J();b=++uk;this.c=new mc(b,null,new yk(this),false,false);this.a=new U(new zk,null,null,136478720);this.b=new yb(null,Hi(new Ak(this)),Do)}
function Eb(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Kb(c);return true}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ci(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?vb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Ng(b,c,d,e){Mg();var f=Kg;$moduleName=c;$moduleBase=d;Cg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{jo(g)()}catch(a){b(c,a)}}else{jo(g)()}}
function yj(a,b){var c;c=new $wnd.Object;c.$$typeof=Hi(a);c.type=Hi(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function ti(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return ui()}}
function Dh(a,b){var c,d,e,f,g;g=Jh(a.a);b.length<g&&(b=ij(new Array(g),b));e=(f=new Oh((new Lh(a.a)).a),new Rh(f));for(d=0;d<g;++d){b[d]=(c=Nh(e.a),c.U())}b.length>g&&(b[g]=null);return b}
function Qg(){Pg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Oc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].hb()&&(c=Nc(c,g)):g[0].hb()}catch(a){a=Dg(a);if(gd(a,5)){d=a;zc();Fc(gd(d,34)?d.A():d)}else throw Eg(a)}}return c}
function Ok(a){var b;a.d=0;pk();b=Aj(Fo,Hj(Lj(Mj(Pj(Nj(Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,['new-todo']))),(ib(a.b),a.e)),Ug(lm.prototype.bb,lm,[a])),Ug(mm.prototype.ab,mm,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.q();if(!(ld(e)===ld(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Dg(a);if(gd(a,11)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Eg(c)}else throw Eg(a)}}
function ki(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=hi(b,e);if(f){return f.V(c)}}e[e.length]=new Sh(b,c);++a.b;return null}
function ej(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function qj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+xh(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Wc(be,mo,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function pb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.s()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Dg(a);if(gd(a,5)){J()}else throw Eg(a)}}}
function Hm(a){var b;if(0==a.length){b=($g(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Zg.title,b)}else{($g(),$wnd.window.window).location.hash=a}}
function xb(a,b,c,d){this.b=new ai;this.f=new Nb(new Bb(this),d&6520832|262144|oo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&ro)&&D((null,I)))}
function li(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(fi(b,e.T())){if(d.length==1){d.length=0;oi(a.a,g)}else{d.splice(h,1)}--a.b;return e.U()}}return null}
function Sg(a,b,c){var d=Pg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Pg[b]),Vg(h));_.fb=c;!b&&(_.gb=Xg);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.eb=f)}
function mh(a){if(a.H()){var b=a.c;b.I()?(a.k='['+b.j):!b.H()?(a.k='[L'+b.F()+';'):(a.k='['+b.F());a.b=b.D()+'[]';a.i=b.G()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=nh('.',[c,nh('$',d)]);a.b=nh('.',[c,nh('.',d)]);a.i=d[d.length-1]}
function Eh(a,b){var c,d,e;c=b.T();e=b.U();d=kd(c)?c==null?Fh(ji(a.a,null)):xi(a.b,c):Fh(ji(a.a,c));if(!(ld(e)===ld(d)||e!=null&&p(e,d))){return false}if(d==null&&!(kd(c)?c==null?!!ji(a.a,null):wi(a.b,c):!!ji(a.a,c))){return false}return true}
function Aj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;uj(b,Ug(Cj.prototype.$,Cj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ao]=c[0],undefined):(d[Ao]=c,undefined));return xj(a,e,f,d)}
function Pm(){var a,b;this.d=new Yn(this);this.f=this.e=(b=($g(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new mc(0,null,new Qm(this),true,false);this.b=(a=new lb(null),a);this.a=new U(new Wm,new Rm(this),new Sm(this),35749888)}
function wl(a){var b,c,d;this.k=Hi(a);J();b=++kl;this.e=new mc(b,null,new xl(this),false,false);this.c=(d=new lb(null),d);this.a=(c=new lb(null),c);this.d=new U(new Cl(this),null,null,136478720);this.b=new yb(null,Hi(new Gl(this)),Do);ul(this,(jb(this.c),this.k.props['a']))}
function qn(){var a;this.g=new gi;J();this.f=new mc(0,new sn(this),new rn(this),true,false);this.d=(a=new lb(null),a);this.c=new U(new vn(this),null,null,Ko);this.e=new U(new wn(this),null,null,Ko);this.a=new U(new xn(this),null,null,Ko);this.b=new U(new yn(this),null,null,Ko)}
function Sn(a){var b;this.j=Hi(a);this.i=new Pm;J();this.g=new mc(0,null,new Tn(this),true,false);this.d=(b=new lb(null),b);this.b=new U(new Un(this),null,null,Ko);this.c=new U(new Vn(this),null,null,Ko);this.e=u(new Wn(this),413138944);this.a=u(new Xn(this),681574400);D((null,I))}
function wb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ci(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Dg(a);if(!gd(a,5))throw Eg(a)}if(6==(b.c&7)){return true}}}}}rb(b);return false}
function si(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function vb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){kb(a.a.e);ub((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;ub((e=d.i,e));d.k=null}Vh(a.b,new Db(a));a.b.a=Wc(be,mo,1,0,5,1)}else 3==g&&!!a.a&&ub((f=a.a.g,f))}}
function lk(){lk=Tg;Rj=new mk(Bo,0);Sj=new mk('checkbox',1);Tj=new mk('color',2);Uj=new mk('date',3);Vj=new mk('datetime',4);Wj=new mk('email',5);Xj=new mk('file',6);Yj=new mk('hidden',7);Zj=new mk('image',8);$j=new mk('month',9);_j=new mk(ko,10);ak=new mk('password',11);bk=new mk('radio',12);ck=new mk('range',13);dk=new mk('reset',14);ek=new mk('search',15);fk=new mk('submit',16);gk=new mk('tel',17);hk=new mk('text',18);ik=new mk('time',19);jk=new mk('url',20);kk=new mk('week',21)}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Wh(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&$h(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&vb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Wh(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Yh(a.b,g)}e&&tb(a.e,a.b)}else{e&&tb(a.e,new ai)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&oo!=(k.b.c&po)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function tk(a){var b,c;a.d=0;pk();c=(b=S((Cm(),Bm).b),Aj('footer',Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,['footer'])),[(new Sl).a,Aj('ul',Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,['filters'])),[Aj('li',null,[Aj('a',Fj(Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,[(ao(),$n)==b?Co:null])),'#'),['All'])]),Aj('li',null,[Aj('a',Fj(Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,[Zn==b?Co:null])),'#active'),['Active'])]),Aj('li',null,[Aj('a',Fj(Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,[_n==b?Co:null])),'#completed'),['Completed'])])]),S(a.a)?Aj(Bo,Gj(Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,['clear-completed'])),Ug(Ql.prototype.cb,Ql,[])),['Clear Completed']):null]));return c}
function jl(a){var b,c,d,e;a.f=0;pk();b=(jb(a.c),a.k.props['a']);if(b.c.i<0){return null}c=(d=(jb(a.c),a.k.props['a']),e=(ib(d.a),d.d),Aj('li',Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,[e?Go:null,S(a.d)?'editing':null])),[Aj('div',Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,['view'])),[Aj(Fo,Lj(Ij(Oj(Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,['toggle'])),(lk(),Sj)),e),Ug(pm.prototype.ab,pm,[d])),null),Aj('label',Qj(new $wnd.Object,Ug(qm.prototype.cb,qm,[a,d])),[(ib(d.b),d.e)]),Aj(Bo,Gj(Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,['destroy'])),Ug(rm.prototype.cb,rm,[d])),null)]),Aj(Fo,Mj(Lj(Kj(Jj(Dj(Ej(new $wnd.Object,Ug(sm.prototype.t,sm,[a])),$c(Uc(de,1),mo,2,6,['edit'])),(ib(a.a),a.i)),Ug(tm.prototype._,tm,[a,d])),Ug(om.prototype.ab,om,[a])),Ug(um.prototype.bb,um,[a,d])),null)]));return c}
function ui(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[zo]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!si()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[zo]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var ko='number',lo={10:1},mo={3:1,4:1},no={8:1},oo=1048576,po=1835008,qo={6:1},ro=2097152,so=4194304,to={20:1},uo='__noinit__',vo='__java$exception',wo={3:1,11:1,9:1,5:1},xo=17592186044416,yo={39:1},zo='delete',Ao='children',Bo='button',Co='selected',Do=1478627328,Eo=142606336,Fo='input',Go='completed',Ho='header',Io='hashchange',Jo={8:1,47:1},Ko=136413184,Lo='active';var _,Pg,Kg,Cg=-1;Qg();Sg(1,null,{},o);_.n=Mo;_.o=function(){return this.eb};_.p=No;_.equals=function(a){return this.n(a)};_.hashCode=function(){return this.p()};var bd,cd,dd;Sg(49,1,{},gh);_.C=function(a){var b;b=new gh;b.e=4;a>1?(b.c=kh(this,a-1)):(b.c=this);return b};_.D=function(){eh(this);return this.b};_.F=function(){return fh(this)};_.G=function(){eh(this);return this.i};_.H=function(){return (this.e&4)!=0};_.I=function(){return (this.e&1)!=0};_.e=0;_.g=0;var dh=1;var be=ih(1);var Ud=ih(49);Sg(77,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var pd=ih(77);Sg(35,1,lo,G);_.q=function(){return this.a.s(),null};var nd=ih(35);Sg(78,1,{},H);var od=ih(78);var I;Sg(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var qd=ih(43);Sg(207,1,no);var td=ih(207);Sg(18,207,no,U);_.r=function(){R(this)};_.a=false;_.d=0;var rd=ih(18);Sg(131,1,{236:1},bb);var sd=ih(131);Sg(14,207,{8:1,14:1},lb);_.r=function(){cb(this)};_.a=4;_.d=false;_.e=0;var vd=ih(14);Sg(111,1,qo,mb);_.s=function(){db(this.a)};var ud=ih(111);Sg(16,207,{8:1,16:1},yb,zb);_.r=function(){nb(this)};_.c=0;var Ad=ih(16);Sg(112,1,to,Ab);_.s=function(){Q(this.a)};var wd=ih(112);Sg(113,1,qo,Bb);_.s=function(){pb(this.a)};var xd=ih(113);Sg(114,1,qo,Cb);_.s=function(){sb(this.a)};var yd=ih(114);Sg(115,1,{},Db);_.t=function(a){qb(this.a,a)};var zd=ih(115);Sg(130,1,{},Gb);_.a=0;_.b=0;_.c=0;var Bd=ih(130);Sg(151,1,no,Ib);_.r=function(){Hb(this)};_.a=false;var Cd=ih(151);Sg(57,207,{8:1,57:1},Nb);_.r=function(){Jb(this)};_.a=0;var Dd=ih(57);Sg(133,1,{},Zb);_.a=0;var Ob;var Ed=ih(133);Sg(116,1,no,dc);_.r=function(){bc(this)};_.a=false;var Fd=ih(116);Sg(99,1,{});var Id=ih(99);Sg(79,1,{},hc);_.t=function(a){fc(this.a,a)};var Gd=ih(79);Sg(80,1,qo,ic);_.s=function(){gc(this.a,this.b)};var Hd=ih(80);Sg(100,99,{});var Jd=ih(100);Sg(15,1,no,mc);_.r=function(){jc(this)};_.e=0;_.i=0;var Ld=ih(15);Sg(110,1,qo,nc);_.s=function(){lc(this.a)};var Kd=ih(110);Sg(5,1,{3:1,5:1});_.v=function(a){return new Error(a)};_.w=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=fh(this.eb),c==null?a:a+': '+c);pc(this,qc(this.v(b)));Rc(this)};_.b=uo;_.d=true;var ee=ih(5);Sg(11,5,{3:1,11:1,5:1});var Xd=ih(11);Sg(9,11,wo);var ce=ih(9);Sg(50,9,wo);var $d=ih(50);Sg(71,50,wo);var Pd=ih(71);Sg(34,71,{34:1,3:1,11:1,9:1,5:1},uc);_.A=function(){return ld(this.a)===ld(sc)?null:this.a};var sc;var Md=ih(34);var Nd=ih(0);Sg(193,1,{});var Od=ih(193);var wc=0,xc=0,yc=-1;Sg(98,193,{},Mc);var Ic;var Qd=ih(98);var Pc;Sg(204,1,{});var Sd=ih(204);Sg(72,204,{},Tc);var Rd=ih(72);var Zg;bd={3:1,67:1,29:1};var Td=ih(67);Sg(40,1,{3:1,40:1});var ae=ih(40);cd={3:1,29:1,40:1};var Vd=ih(203);Sg(31,1,{3:1,29:1,31:1});_.n=Mo;_.p=No;_.b=0;var Wd=ih(31);Sg(73,9,wo,qh);var Yd=ih(73);Sg(30,40,{3:1,29:1,30:1,40:1},rh);_.n=function(a){return gd(a,30)&&a.a==this.a};_.p=Qo;_.a=0;var Zd=ih(30);var th;Sg(268,1,{});Sg(75,50,wo,wh);_.v=function(a){return new TypeError(a)};var _d=ih(75);dd={3:1,66:1,29:1,2:1};var de=ih(2);Sg(272,1,{});Sg(52,9,wo,Bh);var fe=ih(52);Sg(205,1,{38:1});_.J=So;_.N=function(){return new Li(this,0)};_.O=function(){return new Ti(null,this.N())};_.L=function(a){throw Eg(new Bh('Add not supported on this collection'))};var ge=ih(205);Sg(208,1,{191:1});_.n=function(a){var b,c,d;if(a===this){return true}if(!gd(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Oh((new Lh(d)).a);c.b;){b=Nh(c);if(!Eh(this,b)){return false}}return true};_.p=function(){return di(new Lh(this))};var re=ih(208);Sg(119,208,{191:1});var je=ih(119);Sg(209,205,{38:1,219:1});_.N=function(){return new Li(this,1)};_.n=function(a){var b;if(a===this){return true}if(!gd(a,22)){return false}b=a;if(Jh(b.a)!=this.M()){return false}return Ch(this,b)};_.p=function(){return di(this)};var se=ih(209);Sg(22,209,{22:1,38:1,219:1},Lh);_.K=function(){return new Oh(this.a)};_.M=Po;var ie=ih(22);Sg(23,1,{},Oh);_.P=Oo;_.R=function(){return Nh(this)};_.Q=Ro;_.b=false;var he=ih(23);Sg(206,205,{38:1,217:1});_.N=function(){return new Li(this,16)};_.S=function(a,b){throw Eg(new Bh('Add not supported on this list'))};_.L=function(a){this.S(this.M(),a);return true};_.n=function(a){var b,c,d,e,f;if(a===this){return true}if(!gd(a,13)){return false}f=a;if(this.M()!=f.a.length){return false}e=new ci(f);for(c=new ci(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(ld(b)===ld(d)||b!=null&&p(b,d))){return false}}return true};_.p=function(){return ei(this)};_.K=function(){return new Ph(this)};var le=ih(206);Sg(97,1,{},Ph);_.P=Oo;_.Q=function(){return this.a<this.b.a.length};_.R=function(){return Wh(this.b,this.a++)};_.a=0;var ke=ih(97);Sg(42,205,{38:1},Qh);_.K=function(){var a;return a=new Oh((new Lh(this.a)).a),new Rh(a)};_.M=Po;var ne=ih(42);Sg(53,1,{},Rh);_.P=Oo;_.Q=function(){return this.a.b};_.R=function(){var a;return a=Nh(this.a),a.U()};var me=ih(53);Sg(120,1,yo);_.n=function(a){var b;if(!gd(a,39)){return false}b=a;return fi(this.a,b.T())&&fi(this.b,b.U())};_.T=Qo;_.U=Ro;_.p=function(){return Gi(this.a)^Gi(this.b)};_.V=function(a){var b;b=this.b;this.b=a;return b};var oe=ih(120);Sg(121,120,yo,Sh);var pe=ih(121);Sg(210,1,yo);_.n=function(a){var b;if(!gd(a,39)){return false}b=a;return fi(this.b.value[0],b.T())&&fi(Ci(this),b.U())};_.p=function(){return Gi(this.b.value[0])^Gi(Ci(this))};var qe=ih(210);Sg(13,206,{3:1,13:1,38:1,217:1},ai,bi);_.S=function(a,b){fj(this.a,a,b)};_.L=function(a){return Uh(this,a)};_.J=function(a){Vh(this,a)};_.K=function(){return new ci(this)};_.M=function(){return this.a.length};var ue=ih(13);Sg(17,1,{},ci);_.P=Oo;_.Q=function(){return this.a<this.c.a.length};_.R=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var te=ih(17);Sg(36,119,{3:1,36:1,191:1},gi);var ve=ih(36);Sg(58,1,{},mi);_.J=So;_.K=function(){return new ni(this)};_.b=0;var xe=ih(58);Sg(59,1,{},ni);_.P=Oo;_.R=function(){return this.d=this.a[this.c++],this.d};_.Q=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var we=ih(59);var qi;Sg(55,1,{},Ai);_.J=So;_.K=function(){return new Bi(this)};_.b=0;_.c=0;var Ae=ih(55);Sg(56,1,{},Bi);_.P=Oo;_.R=function(){return this.c=this.a,this.a=this.b.next(),new Di(this.d,this.c,this.d.c)};_.Q=function(){return !this.a.done};var ye=ih(56);Sg(132,210,yo,Di);_.T=function(){return this.b.value[0]};_.U=function(){return Ci(this)};_.V=function(a){return yi(this.a,this.b.value[0],a)};_.c=0;var ze=ih(132);Sg(135,1,{});_.P=function(a){Ii(this,a)};_.W=function(){return this.d};_.X=function(){return this.e};_.d=0;_.e=0;var Ce=ih(135);Sg(60,135,{});var Be=ih(60);Sg(24,1,{},Li);_.W=Qo;_.X=function(){Ki(this);return this.c};_.P=function(a){Ki(this);this.d.P(a)};_.Y=function(a){Ki(this);if(this.d.Q()){a.t(this.d.R());return true}return false};_.a=0;_.c=0;var De=ih(24);Sg(134,1,{});_.c=false;var Me=ih(134);Sg(26,134,{237:1,26:1},Ti);var Le=ih(26);Sg(137,60,{},Xi);_.Y=function(a){this.b=false;while(!this.b&&this.c.Y(new Yi(this,a)));return this.b};_.b=false;var Fe=ih(137);Sg(140,1,{},Yi);_.t=function(a){Wi(this.a,this.b,a)};var Ee=ih(140);Sg(136,60,{},Zi);_.Y=function(a){return this.a.Y(new $i(a))};var He=ih(136);Sg(139,1,{},$i);_.t=function(a){this.a.t(vm(new wm,a))};var Ge=ih(139);Sg(138,1,{},aj);_.t=function(a){_i(this,a)};var Ie=ih(138);Sg(141,1,{},bj);_.t=function(a){};var Je=ih(141);Sg(142,1,{},dj);_.t=function(a){cj(this,a)};var Ke=ih(142);Sg(270,1,{});Sg(213,1,{});var Ne=ih(213);Sg(267,1,{});var kj=0;var mj,nj=0,oj;Sg(698,1,{});Sg(711,1,{});Sg(211,1,{});var Oe=ih(211);Sg(238,$wnd.Function,{},Cj);_.$=function(a){Bj(this.a,this.b,a)};Sg(7,31,{3:1,29:1,31:1,7:1},mk);var Rj,Sj,Tj,Uj,Vj,Wj,Xj,Yj,Zj,$j,_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk;var Pe=jh(7,nk);var ok;Sg(239,$wnd.Function,{},qk);_.B=function(a){return Hb(ok),ok=null,null};Sg(214,211,{});var xf=ih(214);Sg(164,214,{});_.d=0;var Bf=ih(164);Sg(165,164,no,xk);_.r=To;_.n=Mo;_.p=No;var uk=0;var Ye=ih(165);Sg(166,1,qo,yk);_.s=function(){vk(this.a)};var Qe=ih(166);Sg(167,1,lo,zk);_.q=function(){return bh(),S((Cm(),zm).b).a>0?true:false};var Re=ih(167);Sg(168,1,to,Ak);_.s=function(){sk(this.a)};var Se=ih(168);Sg(169,1,lo,Bk);_.q=function(){return tk(this.a)};var Te=ih(169);Sg(216,211,{});var wf=ih(216);Sg(185,216,{});_.c=0;var Af=ih(185);Sg(186,185,no,Gk);_.r=Uo;_.n=Mo;_.p=No;var Ek=0;var Xe=ih(186);Sg(187,1,qo,Hk);_.s=Vo;var Ue=ih(187);Sg(188,1,to,Ik);_.s=function(){Dk(this.a)};var Ve=ih(188);Sg(189,1,lo,Jk);_.q=function(){var a,b;return this.a.c=0,pk(),a=S((Cm(),zm).e).a,b='item'+(a==1?'':'s'),Aj('span',Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,['todo-count'])),[Aj('strong',null,[a]),' '+b+' left'])};var We=ih(189);Sg(156,211,{});_.e='';var Jf=ih(156);Sg(157,156,{});_.d=0;var Df=ih(157);Sg(158,157,no,Vk);_.r=To;_.n=Mo;_.p=No;var Pk=0;var cf=ih(158);Sg(159,1,qo,Wk);_.s=function(){Qk(this.a)};var Ze=ih(159);Sg(161,1,lo,Xk);_.q=function(){return Ok(this.a)};var $e=ih(161);Sg(162,1,qo,Yk);_.s=function(){Kk(this.a)};var _e=ih(162);Sg(163,1,qo,Zk);_.s=function(){Sk(this.a,this.b)};var af=ih(163);Sg(160,1,to,$k);_.s=function(){sk(this.a)};var bf=ih(160);Sg(215,211,{});_.j=false;var Lf=ih(215);Sg(171,215,{});_.f=0;var Ff=ih(171);Sg(172,171,no,wl);_.r=function(){jc(this.e)};_.n=Mo;_.p=No;var kl=0;var pf=ih(172);Sg(173,1,qo,xl);_.s=function(){ll(this.a)};var df=ih(173);Sg(176,1,lo,yl);_.q=function(){return jl(this.a)};var ef=ih(176);Sg(61,1,qo,zl);_.s=function(){vl(this.a,Lm(this.b))};var ff=ih(61);Sg(62,1,qo,Al);_.s=function(){dl(this.a,this.b)};var gf=ih(62);Sg(177,1,qo,Bl);_.s=function(){cl(this.a,this.b)};var hf=ih(177);Sg(174,1,lo,Cl);_.q=function(){return ol(this.a)};var jf=ih(174);Sg(178,1,qo,Dl);_.s=function(){ul(this.a,this.b);Rn((Cm(),Bm),null)};var kf=ih(178);Sg(179,1,qo,El);_.s=function(){_k(this.a,this.b)};var lf=ih(179);Sg(180,1,qo,Fl);_.s=function(){el(this.a)};var mf=ih(180);Sg(175,1,to,Gl);_.s=function(){il(this.a)};var nf=ih(175);Sg(181,1,lo,Hl);_.q=function(){return pl(this.a,this.b)};var of=ih(181);Sg(212,211,{});var Nf=ih(212);Sg(144,212,{});_.c=0;var Hf=ih(144);Sg(145,144,no,Ml);_.r=Uo;_.n=Mo;_.p=No;var Kl=0;var tf=ih(145);Sg(146,1,qo,Nl);_.s=Vo;var qf=ih(146);Sg(147,1,to,Ol);_.s=function(){Dk(this.a)};var rf=ih(147);Sg(148,1,lo,Pl);_.q=function(){var a;return this.a.c=0,pk(),Aj('div',null,[Aj('div',null,[Aj(Ho,Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,[Ho])),[Aj('h1',null,['todos']),(new nm).a]),S((Cm(),zm).c)?null:Aj('section',Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,[Ho])),[Aj(Fo,Lj(Oj(Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,['toggle-all'])),(lk(),Sj)),Ug(xm.prototype.ab,xm,[])),null),Aj('ul',Dj(new $wnd.Object,$c(Uc(de,1),mo,2,6,['todo-list'])),(a=Si(Hi(Ri(S(Bm.c).O())),new ai),_h(a,Zc(a.a.length))))]),S(zm.c)?null:(new Rl).a])])};var sf=ih(148);Sg(243,$wnd.Function,{},Ql);_.cb=function(a){Bn((Cm(),Am))};Sg(150,1,{},Rl);var uf=ih(150);Sg(170,1,{},Sl);var vf=ih(170);Sg(244,$wnd.Function,{},Tl);_.db=function(a){return new Wl(a)};var Ul;Sg(154,$wnd.React.Component,{},Wl);Rg(Pg[1],_);_.componentWillUnmount=function(){rk(this.a)};_.render=function(){return wk(this.a)};var yf=ih(154);Sg(254,$wnd.Function,{},Xl);_.db=function(a){return new $l(a)};var Yl;Sg(182,$wnd.React.Component,{},$l);Rg(Pg[1],_);_.componentWillUnmount=function(){Ck(this.a)};_.render=function(){return Fk(this.a)};var zf=ih(182);Sg(242,$wnd.Function,{},_l);_.db=function(a){return new cm(a)};var am;Sg(152,$wnd.React.Component,{},cm);Rg(Pg[1],_);_.componentWillUnmount=function(){rk(this.a)};_.render=function(){return Tk(this.a)};var Cf=ih(152);Sg(245,$wnd.Function,{},dm);_.db=function(a){return new gm(a)};var em;Sg(155,$wnd.React.Component,{},gm);Rg(Pg[1],_);_.componentDidUpdate=function(a){sl(this.a)};_.componentWillUnmount=function(){gl(this.a)};_.render=function(){return tl(this.a)};_.shouldComponentUpdate=function(a){return ml(this.a,a)};var Ef=ih(155);Sg(235,$wnd.Function,{},hm);_.db=function(a){return new km(a)};var im;Sg(118,$wnd.React.Component,{},km);Rg(Pg[1],_);_.componentWillUnmount=function(){Ck(this.a)};_.render=function(){return Ll(this.a)};var Gf=ih(118);Sg(240,$wnd.Function,{},lm);_.bb=function(a){Lk(this.a,a)};Sg(241,$wnd.Function,{},mm);_.ab=function(a){Rk(this.a,a)};Sg(149,1,{},nm);var If=ih(149);Sg(252,$wnd.Function,{},om);_.ab=function(a){nl(this.a,a)};Sg(246,$wnd.Function,{},pm);_.ab=function(a){dn(this.a)};Sg(248,$wnd.Function,{},qm);_.cb=function(a){ql(this.a,this.b)};Sg(249,$wnd.Function,{},rm);_.cb=function(a){fl(this.a)};Sg(250,$wnd.Function,{},sm);_.t=function(a){al(this.a,a)};Sg(251,$wnd.Function,{},tm);_._=function(a){rl(this.a,this.b)};Sg(253,$wnd.Function,{},um);_.bb=function(a){bl(this.a,this.b,a)};Sg(153,1,{},wm);var Kf=ih(153);Sg(234,$wnd.Function,{},xm);_.ab=function(a){var b;b=a.target;Fn((Cm(),Am),b.checked)};Sg(65,1,{},ym);var Mf=ih(65);var zm,Am,Bm;Sg(122,1,{});var rg=ih(122);Sg(123,122,Jo,Pm);_.r=To;_.n=Mo;_.u=Wo;_.p=No;var Vf=ih(123);Sg(124,1,qo,Qm);_.s=function(){Jm(this.a)};var Of=ih(124);Sg(126,1,to,Rm);_.s=function(){Em(this.a)};var Pf=ih(126);Sg(127,1,to,Sm);_.s=function(){Fm(this.a)};var Qf=ih(127);Sg(128,1,qo,Tm);_.s=function(){Dm(this.a,this.b)};var Rf=ih(128);Sg(129,1,qo,Um);_.s=function(){Mm(this.a)};var Sf=ih(129);Sg(54,1,qo,Vm);_.s=function(){Im(this.a)};var Tf=ih(54);Sg(125,1,lo,Wm);_.q=function(){var a;return a=($g(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var Uf=ih(125);Sg(44,1,{44:1});_.d=false;var zg=ih(44);Sg(45,44,{8:1,47:1,45:1,44:1},en);_.r=To;_.n=function(a){return Zm(this,a)};_.u=Wo;_.p=function(){return this.c.e};var Xm=0;var jg=ih(45);Sg(183,1,qo,fn);_.s=function(){Ym(this.a)};var Wf=ih(183);Sg(184,1,qo,gn);_.s=function(){an(this.a)};var Xf=ih(184);Sg(41,100,{41:1});var ug=ih(41);Sg(101,41,{8:1,47:1,41:1},qn);_.r=function(){jc(this.f)};_.n=Mo;_.u=function(){return this.f.c};_.p=No;var eg=ih(101);Sg(103,1,qo,rn);_.s=function(){jn(this.a)};var Yf=ih(103);Sg(102,1,qo,sn);_.s=function(){nn(this.a)};var Zf=ih(102);Sg(108,1,qo,tn);_.s=function(){ec(this.a,this.b,true)};var $f=ih(108);Sg(109,1,lo,un);_.q=function(){return hn(this.a,this.c,this.b)};_.b=false;var _f=ih(109);Sg(104,1,lo,vn);_.q=function(){return on(this.a)};var ag=ih(104);Sg(105,1,lo,wn);_.q=function(){return sh(Jg(Pi(mn(this.a))))};var bg=ih(105);Sg(106,1,lo,xn);_.q=function(){return sh(Jg(Pi(Qi(mn(this.a),new eo))))};var cg=ih(106);Sg(107,1,lo,yn);_.q=function(){return pn(this.a)};var dg=ih(107);Sg(85,1,{});var yg=ih(85);Sg(86,85,Jo,Gn);_.r=function(){jc(this.a)};_.n=Mo;_.u=function(){return this.a.c};_.p=No;var ig=ih(86);Sg(87,1,qo,Hn);_.s=function(){Cn(this.a,this.b)};_.b=false;var fg=ih(87);Sg(88,1,qo,In);_.s=function(){Om(this.b,this.a)};var gg=ih(88);Sg(89,1,qo,Jn);_.s=function(){Dn(this.a)};var hg=ih(89);Sg(90,1,{});var Bg=ih(90);Sg(91,90,Jo,Sn);_.r=function(){jc(this.g)};_.n=Mo;_.u=function(){return this.g.c};_.p=No;var pg=ih(91);Sg(92,1,qo,Tn);_.s=function(){Mn(this.a)};var kg=ih(92);Sg(93,1,lo,Un);_.q=function(){var a;return a=Lm(this.a.i),yh(Lo,a)||yh(Go,a)||yh('',a)?yh(Lo,a)?(ao(),Zn):yh(Go,a)?(ao(),_n):(ao(),$n):(ao(),$n)};var lg=ih(93);Sg(94,1,lo,Vn);_.q=function(){return On(this.a)};var mg=ih(94);Sg(95,1,to,Wn);_.s=function(){Pn(this.a)};var ng=ih(95);Sg(96,1,to,Xn);_.s=function(){Qn(this.a)};var og=ih(96);Sg(117,1,{},Yn);_.handleEvent=function(a){Gm(this.a,a)};var qg=ih(117);Sg(32,31,{3:1,29:1,31:1,32:1},bo);var Zn,$n,_n;var sg=jh(32,co);Sg(81,1,{},eo);_.Z=function(a){return !_m(a)};var tg=ih(81);Sg(83,1,{},fo);_.Z=function(a){return _m(a)};var vg=ih(83);Sg(84,1,{},go);_.t=function(a){ln(this.a,a)};var wg=ih(84);Sg(82,1,{},ho);_.t=function(a){An(this.a,a)};_.a=false;var xg=ih(82);Sg(74,1,{},io);_.Z=function(a){return Ln(this.a,a)};var Ag=ih(74);var jo=(zc(),Cc);var gwtOnLoad=gwtOnLoad=Ng;Lg(Yg);Og('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();