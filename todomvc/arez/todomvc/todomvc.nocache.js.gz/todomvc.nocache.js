function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='4F756AFCE82B521EFDD6B8AA76E14F31',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '4F756AFCE82B521EFDD6B8AA76E14F31';function o(){}
function $g(){}
function Wg(){}
function Hb(){}
function Hk(){}
function yk(){}
function Mc(){}
function Tc(){}
function jj(){}
function kj(){}
function ko(){}
function jo(){}
function Ul(){}
function Xl(){}
function _l(){}
function dm(){}
function hm(){}
function lm(){}
function Bm(){}
function $m(){}
function Rc(a){Qc()}
function fh(){fh=Wg}
function hi(){$h(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function lb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function cc(a){this.a=a}
function lc(a){this.a=a}
function vh(a){this.a=a}
function Gh(a){this.a=a}
function Sh(a){this.a=a}
function Xh(a){this.a=a}
function Yh(a){this.a=a}
function Wh(a){this.b=a}
function ji(a){this.c=a}
function hj(a){this.a=a}
function mj(a){this.a=a}
function Gk(a){this.a=a}
function Ik(a){this.a=a}
function Jk(a){this.a=a}
function Pk(a){this.a=a}
function Qk(a){this.a=a}
function Rk(a){this.a=a}
function cl(a){this.a=a}
function dl(a){this.a=a}
function el(a){this.a=a}
function gl(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function Fl(a){this.a=a}
function Kl(a){this.a=a}
function Ll(a){this.a=a}
function Rl(a){this.a=a}
function Sl(a){this.a=a}
function Tl(a){this.a=a}
function pm(a){this.a=a}
function qm(a){this.a=a}
function sm(a){this.a=a}
function tm(a){this.a=a}
function vm(a){this.a=a}
function wm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function Wm(a){this.a=a}
function Ym(a){this.a=a}
function Zm(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function An(a){this.a=a}
function Bn(a){this.a=a}
function Cn(a){this.a=a}
function Dn(a){this.a=a}
function On(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function $o(){fc(this.c)}
function ap(){fc(this.b)}
function ti(){this.a=Ci()}
function Hi(){this.a=Ci()}
function gc(a){!!a&&a.u()}
function V(a){!!a&&cb(a)}
function w(a){--a.e;D(a)}
function Wo(a){Li(this,a)}
function Zo(a){zh(this,a)}
function gb(a){Vb((J(),a))}
function hb(a){Wb((J(),a))}
function jb(a){Xb((J(),a))}
function Fn(a,b){Al(b,a)}
function Dj(a,b){Cj(a,b)}
function lj(a,b){cj(a.a,b)}
function jc(a,b){Oh(a.e,b)}
function En(a,b){pn(a.b,b)}
function C(a,b){ab(a.f,b.f)}
function ij(a,b){a.a=b}
function Ej(a,b){a.key=b}
function sb(a,b){a.b=Oi(b)}
function Kb(a){a.a=-4&a.a|1}
function Kk(a){a.c=2;fc(a.b)}
function zk(a){a.d=2;fc(a.c)}
function ol(a){a.f=2;fc(a.e)}
function Hg(a){return a.e}
function To(){return this.a}
function Yo(){return this.b}
function Ch(a,b){return a===b}
function il(a,b){return a.g=b}
function Vo(){return uj(this)}
function Hh(a){qc.call(this,a)}
function fp(a){jc(this.c,a)}
function cp(){mb(this.a.a)}
function Dk(a){mb(a.b);R(a.a)}
function Yk(a){mb(a.a);cb(a.b)}
function Nm(a){R(a.a);cb(a.b)}
function an(a){cb(a.b);cb(a.a)}
function nl(a){qn((Gm(),Dm),a)}
function ec(a,b,c){Nh(a.e,b,c)}
function bn(a,b,c){ec(a.c,b,c)}
function qj(a,b){a.splice(b,1)}
function K(a,b){O(a);L(a,Oi(b))}
function bi(a,b){return a.a[b]}
function Uc(a,b){return oh(a,b)}
function Uo(a){return this===a}
function Ah(){mc(this);this.C()}
function Xo(){return Qh(this.a)}
function _o(){return this.c.i<0}
function bp(){return this.b.i<0}
function yi(){yi=Wg;xi=Ai()}
function J(){J=Wg;I=new F}
function Jc(){Jc=Wg;Ic=new Mc}
function sc(){sc=Wg;rc=new o}
function zc(){zc=Wg;!!(Qc(),Pc)}
function Pg(){Ng==null&&(Ng=[])}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function ih(a){hh(a);return a.k}
function bj(a,b){a.O(b);return a}
function Nj(a,b){a.ref=b;return a}
function Pm(a){ib(a.b);return a.e}
function en(a){ib(a.a);return a.d}
function Sn(a){ib(a.d);return a.f}
function Ci(){yi();return new xi}
function db(a){J();Wb(a);a.e=-2}
function cj(a,b){ij(a,bj(a.a,b))}
function Pi(a,b){while(a._(b));}
function dc(a,b){this.a=a;this.b=b}
function th(a,b){this.a=a;this.b=b}
function Zh(a,b){this.a=a;this.b=b}
function fj(a,b){this.a=a;this.b=b}
function Lj(a,b){this.a=a;this.b=b}
function dp(a){return 1==this.a.d}
function ep(a){return 1==this.a.c}
function Qh(a){return a.a.b+a.b.b}
function Ei(a,b){return a.a.get(b)}
function W(a){return !!a&&a.c.i<0}
function Zc(a){return new Array(a)}
function v(a,b,c){s(a,new H(c),b)}
function oj(a,b,c){a.splice(b,0,c)}
function uk(a,b){th.call(this,a,b)}
function fl(a,b){this.a=a;this.b=b}
function El(a,b){this.a=a;this.b=b}
function Gl(a,b){this.a=a;this.b=b}
function Hl(a,b){this.a=a;this.b=b}
function Il(a,b){this.a=a;this.b=b}
function Jl(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function xm(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function yn(a,b){this.a=a;this.b=b}
function Mn(a,b){this.a=a;this.b=b}
function Nn(a,b){this.b=a;this.a=b}
function ho(a,b){th.call(this,a,b)}
function Wl(){this.a=Fj((bm(),am))}
function rm(){this.a=Fj((fm(),em))}
function Am(){this.a=Fj((jm(),im))}
function Cm(){this.a=Fj((nm(),mm))}
function Vl(){this.a=Fj((Zl(),Yl))}
function Qm(a){Om(a,(ib(a.b),a.e))}
function fn(a){Al(a,(ib(a.a),!a.d))}
function Rb(a){return !a.d?a:Rb(a.d)}
function Mh(a){return !a?null:a.X()}
function md(a){return a==null?null:a}
function Ni(a){return a!=null?r(a):0}
function jd(a){return typeof a===qo}
function Ph(a){a.a=new ti;a.b=new Hi}
function $h(a){a.a=Wc(de,so,1,0,5,1)}
function Gc(a){$wnd.clearTimeout(a)}
function Oj(a,b){a.href=b;return a}
function Xj(a,b){a.value=b;return a}
function Sj(a,b){a.onBlur=b;return a}
function Pj(a,b){a.onClick=b;return a}
function Rj(a,b){a.checked=b;return a}
function Eh(a,b){a.a+=''+b;return a}
function ac(a,b){b.w(a);gd(b,9)&&b.s()}
function bc(a,b){_b(a,b,false);hb(a.d)}
function sl(a){mb(a.b);R(a.c);cb(a.a)}
function rb(a){J();qb(a);ub(a,2,true)}
function pj(a,b){nj(b,0,a,0,b.length)}
function A(a,b,c){t(a,new G(b),c,null)}
function B(a,b,c){return t(a,c,2048,b)}
function _c(a,b,c){return {l:a,m:b,h:c}}
function Bh(a,b){return a.charCodeAt(b)}
function uj(a){return a.$H||(a.$H=++tj)}
function X(a){return !(!!a&&1==(a.c&7))}
function gd(a,b){return a!=null&&ed(a,b)}
function Cj(a,b){for(var c in a){b(c)}}
function Tj(a,b){a.onChange=b;return a}
function Uj(a,b){a.onKeyDown=b;return a}
function Qj(a){a.autoFocus=true;return a}
function hh(a){if(a.k!=null){return}qh(a)}
function kb(a){this.c=new hi;this.b=a}
function Fb(a){this.d=Oi(a);this.b=100}
function qc(a){this.f=a;mc(this);this.C()}
function aj(a,b){Xi.call(this,a);this.a=b}
function Hc(){wc!=0&&(wc=0);yc=-1}
function yj(){yj=Wg;vj=new o;xj=new o}
function ni(){this.a=new ti;this.b=new Hi}
function P(){this.a=Wc(de,so,1,100,5,1)}
function ib(a){var b;Sb((J(),b=Nb,b),a)}
function nc(a,b){a.e=b;b!=null&&sj(b,Bo,a)}
function Li(a,b){while(a.T()){lj(b,a.U())}}
function vi(a,b){var c;c=a[Go];c.call(a,b)}
function u(a,b){return new xb(Oi(a),null,b)}
function hd(a){return typeof a==='boolean'}
function ld(a){return typeof a==='string'}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function xl(a){A((J(),J(),I),new Ll(a),Lo)}
function Rm(a){A((J(),J(),I),new Ym(a),Lo)}
function jn(a){A((J(),J(),I),new mn(a),Lo)}
function Gn(a){A((J(),J(),I),new On(a),Lo)}
function Un(a){W((ib(a.d),a.f))&&Wn(a,null)}
function un(a){return wh(S(a.e).a-S(a.a).a)}
function Ac(a,b,c){return a.apply(b,c);var d}
function sj(b,c,d){try{b[c]=d}catch(a){}}
function $(a,b,c){Kb(Oi(c));K(a.a[b],Oi(c))}
function Ki(a,b,c){this.a=a;this.b=b;this.c=c}
function Yj(a,b){a.onDoubleClick=b;return a}
function _h(a,b){a.a[a.a.length]=b;return true}
function mc(a){a.g&&a.e!==Ao&&a.C();return a}
function lh(a){var b;b=kh(a);sh(a,b);return b}
function yh(){yh=Wg;xh=Wc(_d,so,32,256,0,1)}
function bh(){bh=Wg;ah=$wnd.window.document}
function Qc(){Qc=Wg;var a;!Sc();a=new Tc;Pc=a}
function Eb(a){while(true){if(!Db(a)){break}}}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function Zk(a,b){A((J(),J(),I),new fl(a,b),Lo)}
function tl(a,b){A((J(),J(),I),new Jl(a,b),Lo)}
function vl(a,b){A((J(),J(),I),new Hl(a,b),Lo)}
function wl(a,b){A((J(),J(),I),new Gl(a,b),Lo)}
function zl(a,b){A((J(),J(),I),new El(a,b),Lo)}
function qn(a,b){A((J(),J(),I),new yn(a,b),Lo)}
function Jn(a,b){A((J(),J(),I),new Nn(a,b),Lo)}
function Kn(a,b){A((J(),J(),I),new Mn(a,b),Lo)}
function sn(a){zh(new Xh(a.g),new cc(a));Ph(a.g)}
function F(){this.f=new bb;this.a=new Fb(this.f)}
function zn(a,b){this.a=a;this.c=b;this.b=false}
function $k(a,b){var c;c=b.target;al(a,c.value)}
function pb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function dj(a,b,c){if(a.a.ab(c)){a.b=true;b.v(c)}}
function Gb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Ri(a){if(!a.d){a.d=a.b.N();a.c=a.b.P()}}
function Uh(a){var b;b=a.a.U();a.b=Th(a);return b}
function nh(a){var b;b=kh(a);b.j=a;b.e=1;return b}
function di(a,b){var c;c=a.a[b];qj(a.a,b);return c}
function Nc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Di(a,b){return !(a.a.get(b)===undefined)}
function tn(a){return fh(),0==S(a.e).a?true:false}
function Ek(a){return B((J(),J(),I),a.b,new Jk(a))}
function Nk(a){return B((J(),J(),I),a.a,new Rk(a))}
function _k(a){return B((J(),J(),I),a.a,new dl(a))}
function yl(a){return B((J(),J(),I),a.b,new Dl(a))}
function Pl(a){return B((J(),J(),I),a.a,new Tl(a))}
function $i(a){Wi(a);return new aj(a,new gj(a.a))}
function on(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function Yc(a){return Array.isArray(a)&&a.jb===$g}
function fd(a){return !Array.isArray(a)&&a.jb===$g}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Pn(a){return Ch(Ro,a)||Ch(So,a)||Ch('',a)}
function Rh(a,b){if(b){return Kh(a.a,b)}return false}
function Oi(a){if(a==null){throw Hg(new Ah)}return a}
function Bj(){if(wj==256){vj=xj;xj=new o;wj=0}++wj}
function Ak(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function Lk(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function pl(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function Vi(a){if(!a.b){Wi(a);a.c=true}else{Vi(a.b)}}
function Rn(a){mb(a.e);mb(a.a);R(a.b);R(a.c);cb(a.d)}
function al(a,b){var c;c=a.e;if(b!=c){a.e=b;hb(a.b)}}
function Al(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function fi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Wj(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Qi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function mi(a,b){return md(a)===md(b)||a!=null&&p(a,b)}
function Mm(a){var b;T(a.a);b=S(a.a);Ch(a.f,b)&&Sm(a,b)}
function Sm(a,b){var c;c=a.e;if(b!=c){a.e=Oi(b);hb(a.b)}}
function mh(a,b){var c;c=kh(a);sh(a,c);c.e=b?8:0;return c}
function gj(a){Qi.call(this,a.$(),a.Z()&-6);this.a=a}
function Xi(a){if(!a){this.b=null;new hi}else{this.b=a}}
function Zi(a,b){Wi(a);return new aj(a,new ej(b,a.a))}
function Om(a,b){A((J(),J(),I),new Xm(a,b),75497472)}
function nb(a){C((J(),J(),I),a);0==(a.f.a&xo)&&D((null,I))}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function pn(a,b){return t((J(),J(),I),new zn(a,b),Lo,null)}
function io(){go();return $c(Uc(vg,1),so,34,0,[co,fo,eo])}
function Im(a){dh((bh(),$wnd.window.window),Oo,a.d,false)}
function Jm(a){eh((bh(),$wnd.window.window),Oo,a.d,false)}
function Fc(a){zc();$wnd.setTimeout(function(){throw a},0)}
function eh(a,b,c,d){a.removeEventListener(b,c,d)}
function dh(a,b,c,d){a.addEventListener(b,c,d)}
function Mg(a){if(jd(a)){return a|0}return a.l|a.m<<22}
function ph(a){if(a.L()){return null}var b=a.j;return Sg[b]}
function Ob(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);qb(a.e)}}
function hl(a,b){var c;if(S(a.c)){c=b.target;Al(a,c.value)}}
function zh(a,b){var c,d;for(d=a.N();d.T();){c=d.U();b.v(c)}}
function oc(a,b){var c;c=ih(a.hb);return b==null?c:c+': '+b}
function Lh(a,b){return b===a?'(this Map)':b==null?Do:Zg(b)}
function Si(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function Yg(a){function b(){}
;b.prototype=a||{};return new b}
function fm(){fm=Wg;var a;em=(a=Xg(dm.prototype.gb,dm,[]),a)}
function jm(){jm=Wg;var a;im=(a=Xg(hm.prototype.gb,hm,[]),a)}
function nm(){nm=Wg;var a;mm=(a=Xg(lm.prototype.gb,lm,[]),a)}
function bm(){bm=Wg;var a;am=(a=Xg(_l.prototype.gb,_l,[]),a)}
function Zl(){Zl=Wg;var a;Yl=(a=Xg(Xl.prototype.gb,Xl,[]),a)}
function Gm(){Gm=Wg;Dm=new vn;Em=new Ln(Dm);Fm=new Xn(Dm)}
function Hn(a,b){var c;_i(rn(a.b),(c=new hi,c)).M(new mo(b))}
function oh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.G(b))}
function pi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function qi(a,b){var c;return oi(b,pi(a,b==null?0:(c=r(b),c|0)))}
function rn(a){ib(a.d);return new aj(null,new Si(new Xh(a.g),0))}
function Wi(a){if(a.b){Wi(a.b)}else if(a.c){throw Hg(new uh)}}
function ic(a){gc(a.g);!!a.e&&hc(a);V(a.a);V(a.c);gc(a.b);gc(a.f)}
function ii(a){$h(this);pj(this.a,Jh(a,Wc(de,so,1,Qh(a.a),5,1)))}
function ui(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function ej(a,b){Qi.call(this,b.$(),b.Z()&-16449);this.a=a;this.c=b}
function kl(a,b){Wn((Gm(),Fm),b);A((J(),J(),I),new El(a,b),Lo)}
function Km(a,b){b.preventDefault();A((J(),J(),I),new Zm(a),Lo)}
function Vj(a){a.placeholder='What needs to be done?';return a}
function pc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ug(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Kj(a,b,c){!Ch(c,'key')&&!Ch(c,'ref')&&(a[c]=b[c],undefined)}
function Dc(a,b,c){var d;d=Bc();try{return Ac(a,b,c)}finally{Ec(d)}}
function Ec(a){a&&Lc((Jc(),Ic));--wc;if(a){if(yc!=-1){Gc(yc);yc=-1}}}
function Lb(b){try{b.b.u()}catch(a){a=Gg(a);if(!gd(a,5))throw Hg(a)}}
function Ln(a){this.b=Oi(a);J();this.a=new kc(0,null,null,true,false)}
function ul(a){return fh(),Sn((Gm(),Fm))==a.j.props['a']?true:false}
function nd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Oh(a,b){return ld(b)?b==null?si(a.a,null):Gi(a.b,b):si(a.a,b)}
function Ti(a,b){!a.a?(a.a=new Gh(a.d)):Eh(a.a,a.b);Eh(a.a,b);return a}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Wn(a,b){var c;c=a.f;if(!(b==c||!!b&&cn(b,c))){a.f=b;hb(a.d)}}
function eb(a,b){var c,d;_h(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function _i(a,b){var c;Vi(a);c=new jj;c.a=b;a.a.S(new mj(c));return c.a}
function Yi(a){var b;Vi(a);b=0;while(a.a._(new kj)){b=Ig(b,1)}return b}
function In(a){var b;_i(Zi(rn(a.b),new ko),(b=new hi,b)).M(new lo(a.b))}
function $l(a){$wnd.React.Component.call(this,a);this.a=new Fk(this)}
function cm(a){$wnd.React.Component.call(this,a);this.a=new Ok(this)}
function gm(a){$wnd.React.Component.call(this,a);this.a=new bl(this)}
function km(a){$wnd.React.Component.call(this,a);this.a=new Bl(this)}
function om(a){$wnd.React.Component.call(this,a);this.a=new Ql(this)}
function Ii(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Vh(a){this.d=a;this.c=new Ii(this.d.b);this.a=this.c;this.b=Th(this)}
function Ui(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Qn(a,b){return (go(),eo)==a||(co==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function Nh(a,b,c){return ld(b)?b==null?ri(a.a,null,c):Fi(a.b,b,c):ri(a.a,b,c)}
function rj(a,b){return Vc(b)!=10&&$c(q(b),b.ib,b.__elementTypeId$,Vc(b),a),a}
function Hm(a,b){a.f=b;Ch(b,S(a.a))&&Sm(a,b);Lm(b);A((J(),J(),I),new Zm(a),Lo)}
function Tn(a){var b,c;return b=S(a.b),_i(Zi(rn(a.j),new no(b)),(c=new hi,c))}
function vc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Cc(b){zc();return function(){return Dc(b,this,arguments);var a}}
function cn(a,b){var c;if(gd(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function ei(a,b){var c;c=ci(a,b,0);if(c==-1){return false}qj(a.a,c);return true}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function ci(a,b,c){for(;c<a.a.length;++c){if(mi(b,a.a[c])){return c}}return -1}
function Ji(a){if(a.a.c!=a.c){return Ei(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||mb(a.f)}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new lb(a)),0,null);!!a.b&&mb(a.b)}}
function fc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new lc(a)),67108864,null)}}
function Tk(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new el(a),Lo)}}
function Sk(a){var b;b=Dh((ib(a.b),a.e));if(b.length>0){En((Gm(),Em),b);al(a,'')}}
function ai(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function bb(){var a;this.a=Wc(sd,so,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Kc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Oc(b,c)}while(a.a);a.a=c}}
function Lc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Oc(b,c)}while(a.b);a.b=c}}
function Wc(a,b,c,d,e,f){var g;g=Xc(e,d);e!=10&&$c(Uc(a,f),b,c,e,g);return g}
function kh(a){var b;b=new jh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function sh(a,b){var c;if(!a){return}b.j=a;var d=ph(b);if(!d){Sg[a]=[b];return}d.hb=b}
function Xg(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Og(){Pg();var a=Ng;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function uh(){qc.call(this,"Stream already terminated, can't be modified or used")}
function Gg(a){var b;if(gd(a,5)){return a}b=a&&a[Bo];if(!b){b=new uc(a);Rc(b)}return b}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;_h((!a.b&&(a.b=new hi),a.b),b)}}}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new hi);a.c=c.c}b.d=true;_h(a.c,Oi(b))}
function Gi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{vi(a.a,b);--a.b}return c}
function ki(a){var b,c,d;d=0;for(c=new Vh(a.a);c.b;){b=Uh(c);d=d+(b?r(b):0);d=d|0}return d}
function qb(a){var b,c;for(c=new ji(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function tb(b){if(b){try{b.u()}catch(a){a=Gg(a);if(gd(a,5)){J()}else throw Hg(a)}}}
function Vc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function kd(a){return a!=null&&(typeof a===po||typeof a==='function')&&!(a.jb===$g)}
function Rg(a,b){typeof window===po&&typeof window['$gwt']===po&&(window['$gwt'][a]=b)}
function Mb(a,b){this.b=Oi(a);this.a=b|0|(0==(b&6291456)?yo:0)|(0!=(b&229376)?0:98304)}
function xb(a,b,c){wb.call(this,null,a,b,c|(!a?262144:uo)|(0==(c&6291456)?!a?xo:yo:0)|0|0|0)}
function _b(a,b,c){var d;d=Oh(a.g,b?wh(b.c.d):null);if(null!=d){jc(b.c,a);c&&!!b&&fc(b.c);hb(a.d)}}
function nn(a,b,c){var d;d=new kn(b,c);bn(d,a,new dc(a,d));Nh(a.g,wh(d.c.d),d);hb(a.d);return d}
function Ih(a,b){var c,d;for(d=new Vh(b.a);d.b;){c=Uh(d);if(!Rh(a,c)){return false}}return true}
function oi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(mi(a,c.W())){return c}}return null}
function Lg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Eo;d=1048575}c=nd(e/yo);b=nd(e-c*yo);return _c(b,c,d)}
function Fj(a){var b;b=Hj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Gj(a,b,c,d){var e;e=Hj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Oi(d);return e}
function Ij(a){var b;return Gj($wnd.React.StrictMode,null,null,(b={},b[Ho]=Oi(a),b))}
function Th(a){if(a.a.T()){return true}if(a.a!=a.c){return false}a.a=new ui(a.d.a);return a.a.T()}
function Jg(a){var b;b=a.h;if(b==0){return a.l+a.m*yo}if(b==1048575){return a.l+a.m*yo-Eo}return a}
function Fi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function zm(a,b){Ej(a.a,(hh(Of),Of.k+(''+(b?wh(b.c.d):null))));Oi(b);a.a.props['a']=b;return a.a}
function S(a){ib(a.e);vb(a.f)&&ob(a.f);if(a.b){if(gd(a.b,8)){throw Hg(a.b)}else{throw Hg(a.b)}}return a.k}
function Vn(a){var b;b=S(a.i.a);Ch(Ro,b)||Ch(So,b)||Ch('',b)?Om(a.i,b):Pn(Pm(a.i))?Rm(a.i):Om(a.i,'')}
function go(){go=Wg;co=new ho('ACTIVE',0);fo=new ho('COMPLETED',1);eo=new ho('ALL',2)}
function _g(){Gm();$wnd.ReactDOM.render(Ij([(new Cm).a]),(bh(),ah).getElementById('app'),null)}
function jl(a,b,c){27==c.which?A((J(),J(),I),new Il(a,b),Lo):13==c.which&&A((J(),J(),I),new Gl(a,b),Lo)}
function mb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Bb(a)),67108864,null);!!a.a&&R(a.a);Ib(a.f);a.c=a.c&-8|1}}
function xk(){if(!wk){wk=(++(J(),J(),I).e,new Hb);$wnd.Promise.resolve(null).then(Xg(yk.prototype.F,yk,[]))}}
function vk(){tk();return $c(Uc(Te,1),so,7,0,[Zj,$j,_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk])}
function q(a){return ld(a)?ge:jd(a)?Xd:hd(a)?Vd:fd(a)?a.hb:Yc(a)?a.hb:a.hb||Array.isArray(a)&&Uc(Od,1)||Od}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&uo)?Lb(a):a.b.u();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function fb(a,b){var c,d;d=a.c;ei(d,b);!!a.b&&uo!=(a.b.c&vo)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function ad(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return _c(c&4194303,d&4194303,e&1048575)}
function $c(a,b,c,d,e){e.hb=a;e.ib=b;e.jb=$g;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function wh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(yh(),xh)[b];!c&&(c=xh[b]=new vh(a));return c}return new vh(a)}
function Zg(a){var b;if(Array.isArray(a)&&a.jb===$g){return ih(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Aj(a){yj();var b,c,d;c=':'+a;d=xj[c];if(d!=null){return nd(d)}d=vj[c];b=d==null?zj(a):nd(d);Bj();xj[c]=b;return b}
function uc(a){sc();mc(this);this.e=a;a!=null&&sj(a,Bo,this);this.f=a==null?Do:Zg(a);this.a='';this.b=a;this.a=''}
function jh(){this.g=gh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Ql(a){var b;this.j=Oi(a);J();b=++Ol;this.b=new kc(b,null,new Rl(this),false,false);this.a=new xb(null,Oi(new Sl(this)),Ko)}
function Ok(a){var b;this.j=Oi(a);J();b=++Mk;this.b=new kc(b,null,new Pk(this),false,false);this.a=new xb(null,Oi(new Qk(this)),Ko)}
function ml(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;zl(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=di(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function li(a){var b,c,d;d=1;for(c=new ji(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function hc(a){var b,c,d;for(c=new ji(new ii(new Sh(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.W();gd(d,9)&&d.t()||b.X().u()}}
function ll(a,b){var c;c=(ib(a.a),a.d);if(null!=c&&c.length!=0){Jn((Gm(),b),c);Wn(Fm,null);Al(a,c)}else{qn((Gm(),Dm),b)}}
function Ig(a,b){var c;if(jd(a)&&jd(b)){c=a+b;if(-17592186044416<c&&c<Eo){return c}}return Jg(ad(jd(a)?Lg(a):a,jd(b)?Lg(b):b))}
function p(a,b){return ld(a)?Ch(a,b):jd(a)?a===b:hd(a)?a===b:fd(a)?a.n(b):Yc(a)?a===b:!!a&&!!a.equals?a.equals(b):md(a)===md(b)}
function r(a){return ld(a)?Aj(a):jd(a)?nd(a):hd(a)?a?1231:1237:fd(a)?a.p():Yc(a)?uj(a):!!a&&!!a.hashCode?a.hashCode():uj(a)}
function yb(a,b){wb.call(this,a,new zb(a),null,b|(uo==(b&vo)?0:524288)|(0==(b&6291456)?uo==(b&vo)?yo:xo:0)|0|268435456|0)}
function rh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function gi(a,b){var c,d;d=a.a.length;b.length<d&&(b=rj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Jh(a,b){var c,d,e;e=Qh(a.a);b.length<e&&(b=rj(new Array(e),b));d=new Vh(a.a);for(c=0;c<e;++c){b[c]=Uh(d)}b.length>e&&(b[e]=null);return b}
function Mj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Bc(){var a;if(wc!=0){a=vc();if(a-xc>2000){xc=a;yc=$wnd.setTimeout(Hc,10)}}if(wc++==0){Kc((Jc(),Ic));return true}return false}
function Sc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a,b,c,d,e){var f;this.d=a;this.e=d?new ni:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new kb((J(),null)),f):null;this.c=null}
function U(a,b,c,d){this.c=Oi(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new yb(this,d);this.e=new kb(this.f);uo==(d&vo)&&nb(this.f)}
function kn(a,b){var c,d,e;this.e=Oi(a);this.d=b;J();c=++_m;this.c=new kc(c,null,new ln(this),true,true);this.b=(e=new kb(null),e);this.a=(d=new kb(null),d)}
function bl(a){var b,c;this.j=Oi(a);J();b=++Xk;this.c=new kc(b,null,new cl(this),false,false);this.b=(c=new kb(null),c);this.a=new xb(null,Oi(new gl(this)),Ko)}
function ed(a,b){if(ld(a)){return !!dd[b]}else if(a.ib){return !!a.ib[b]}else if(jd(a)){return !!cd[b]}else if(hd(a)){return !!bd[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Wb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ji(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&ub(b,6,true)}}}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Dh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Xc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{Zb(b,d);try{f=(c.a.u(),null)}finally{$b()}return f}catch(a){a=Gg(a);if(gd(a,5)){e=a;throw Hg(e)}else throw Hg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.r()}else{Zb(b,e);try{g=c.r()}finally{$b()}}return g}catch(a){a=Gg(a);if(gd(a,5)){f=a;throw Hg(f)}else throw Hg(a)}finally{D(b)}}
function Db(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Jb(c);return true}
function Qg(b,c,d,e){Pg();var f=Ng;$moduleName=c;$moduleBase=d;Fg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{oo(g)()}catch(a){b(c,a)}}else{oo(g)()}}
function Fk(a){var b;this.j=Oi(a);J();b=++Ck;this.c=new kc(b,null,new Gk(this),false,false);this.a=new U(new Hk,null,null,136478720);this.b=new xb(null,Oi(new Ik(this)),Ko)}
function Hj(a,b){var c;c=new $wnd.Object;c.$$typeof=Oi(a);c.type=Oi(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ai(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Bi()}}
function Tg(){Sg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Oc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].kb()&&(c=Nc(c,g)):g[0].kb()}catch(a){a=Gg(a);if(gd(a,5)){d=a;zc();Fc(gd(d,35)?d.D():d)}else throw Hg(a)}}return c}
function Wk(a){var b;a.d=0;xk();b=Jj(Mo,Qj(Tj(Uj(Xj(Vj(Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,['new-todo']))),(ib(a.b),a.e)),Xg(pm.prototype.eb,pm,[a])),Xg(qm.prototype.db,qm,[a]))),null);return b}
function tc(a){var b;if(a.c==null){b=md(a.b)===md(rc)?null:a.b;a.d=b==null?Do:kd(b)?b==null?null:b.name:ld(b)?'String':ih(q(b));a.a=a.a+': '+(kd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.k;try{d=b.c.r();if(!(md(e)===md(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Gg(a);if(gd(a,11)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Hg(c)}else throw Hg(a)}}
function ri(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=oi(b,e);if(f){return f.Y(c)}}e[e.length]=new Zh(b,c);++a.b;return null}
function nj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function zj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Bh(a,c++)}b=b|0;return b}
function ob(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.u()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Gg(a);if(gd(a,5)){J()}else throw Hg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Wc(de,so,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Lm(a){var b;if(0==a.length){b=(bh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',ah.title,b)}else{(bh(),$wnd.window.window).location.hash=a}}
function wb(a,b,c,d){this.b=new hi;this.f=new Mb(new Ab(this),d&6520832|262144|uo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&xo)&&D((null,I)))}
function si(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(mi(b,e.W())){if(d.length==1){d.length=0;vi(a.a,g)}else{d.splice(h,1)}--a.b;return e.X()}}return null}
function Bl(a){var b,c;this.j=Oi(a);J();b=++rl;this.e=new kc(b,null,new Cl(this),false,false);this.a=(c=new kb(null),c);this.c=new U(new Fl(this),null,null,136478720);this.b=new xb(null,Oi(new Kl(this)),Ko);zl(this,this.j.props['a'])}
function Vg(a,b,c){var d=Sg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Sg[b]),Yg(h));_.ib=c;!b&&(_.jb=$g);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.hb=f)}
function qh(a){if(a.K()){var b=a.c;b.L()?(a.k='['+b.j):!b.K()?(a.k='[L'+b.I()+';'):(a.k='['+b.I());a.b=b.H()+'[]';a.i=b.J()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=rh('.',[c,rh('$',d)]);a.b=rh('.',[c,rh('.',d)]);a.i=d[d.length-1]}
function Kh(a,b){var c,d,e;c=b.W();e=b.X();d=ld(c)?c==null?Mh(qi(a.a,null)):Ei(a.b,c):Mh(qi(a.a,c));if(!(md(e)===md(d)||e!=null&&p(e,d))){return false}if(d==null&&!(ld(c)?c==null?!!qi(a.a,null):Di(a.b,c):!!qi(a.a,c))){return false}return true}
function Jj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Dj(b,Xg(Lj.prototype.bb,Lj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ho]=c[0],undefined):(d[Ho]=c,undefined));return Gj(a,e,f,d)}
function Tm(){var a,b;this.d=new bo(this);this.f=this.e=(b=(bh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new kc(0,null,new Um(this),true,false);this.b=(a=new kb(null),a);this.a=new U(new $m,new Vm(this),new Wm(this),35749888)}
function vn(){var a;this.g=new ni;J();this.f=new kc(0,new xn(this),new wn(this),true,false);this.d=(a=new kb(null),a);this.c=new U(new An(this),null,null,Qo);this.e=new U(new Bn(this),null,null,Qo);this.a=new U(new Cn(this),null,null,Qo);this.b=new U(new Dn(this),null,null,Qo)}
function Xn(a){var b;this.j=Oi(a);this.i=new Tm;J();this.g=new kc(0,null,new Yn(this),true,false);this.d=(b=new kb(null),b);this.b=new U(new Zn(this),null,null,Qo);this.c=new U(new $n(this),null,null,Qo);this.e=u(new _n(this),413138944);this.a=u(new ao(this),681574400);D((null,I))}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ji(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Gg(a);if(!gd(a,5))throw Hg(a)}if(6==(b.c&7)){return true}}}}}qb(b);return false}
function zi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ub(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){jb(a.a.e);tb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;tb((e=d.i,e));d.k=null}ai(a.b,new Cb(a));a.b.a=Wc(de,so,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&tb((f=a.a.g,f))}}
function tk(){tk=Wg;Zj=new uk(Io,0);$j=new uk('checkbox',1);_j=new uk('color',2);ak=new uk('date',3);bk=new uk('datetime',4);ck=new uk('email',5);dk=new uk('file',6);ek=new uk('hidden',7);fk=new uk('image',8);gk=new uk('month',9);hk=new uk(qo,10);ik=new uk('password',11);jk=new uk('radio',12);kk=new uk('range',13);lk=new uk('reset',14);mk=new uk('search',15);nk=new uk('submit',16);ok=new uk('tel',17);pk=new uk('text',18);qk=new uk('time',19);rk=new uk('url',20);sk=new uk('week',21)}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=bi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&fi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=bi(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){di(a.b,g)}e&&sb(a.e,a.b)}else{e&&sb(a.e,new hi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&uo!=(k.b.c&vo)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function Bk(a){var b,c;a.d=0;xk();c=(b=S((Gm(),Fm).b),Jj('footer',Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,['footer'])),[(new Wl).a,Jj('ul',Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,['filters'])),[Jj('li',null,[Jj('a',Oj(Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,[(go(),eo)==b?Jo:null])),'#'),['All'])]),Jj('li',null,[Jj('a',Oj(Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,[co==b?Jo:null])),'#active'),['Active'])]),Jj('li',null,[Jj('a',Oj(Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,[fo==b?Jo:null])),'#completed'),['Completed'])])]),S(a.a)?Jj(Io,Pj(Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,['clear-completed'])),Xg(Ul.prototype.fb,Ul,[])),['Clear Completed']):null]));return c}
function ql(a){var b,c,d,e;a.f=0;xk();b=a.j.props['a'];if(b.c.i<0){return null}c=(d=a.j.props['a'],e=(ib(d.a),d.d),Jj('li',Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,[e?'checked':null,S(a.c)?'editing':null])),[Jj('div',Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,['view'])),[Jj(Mo,Tj(Rj(Wj(Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,['toggle'])),(tk(),$j)),e),Xg(tm.prototype.db,tm,[d])),null),Jj('label',Yj(new $wnd.Object,Xg(um.prototype.fb,um,[a,d])),[(ib(d.b),d.e)]),Jj(Io,Pj(Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,['destroy'])),Xg(vm.prototype.fb,vm,[d])),null)]),Jj(Mo,Uj(Tj(Sj(Xj(Mj(Nj(new $wnd.Object,Xg(wm.prototype.v,wm,[a])),$c(Uc(ge,1),so,2,6,['edit'])),(ib(a.a),a.d)),Xg(xm.prototype.cb,xm,[a,d])),Xg(sm.prototype.db,sm,[a])),Xg(ym.prototype.eb,ym,[a,d])),null)]));return c}
function Bi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Go]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!zi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Go]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var po='object',qo='number',ro={14:1},so={3:1,4:1},to={9:1},uo=1048576,vo=1835008,wo={6:1},xo=2097152,yo=4194304,zo={21:1},Ao='__noinit__',Bo='__java$exception',Co={3:1,11:1,8:1,5:1},Do='null',Eo=17592186044416,Fo={40:1},Go='delete',Ho='children',Io='button',Jo='selected',Ko=1411518464,Lo=142606336,Mo='input',No='header',Oo='hashchange',Po={9:1,49:1},Qo=136413184,Ro='active',So='completed';var _,Sg,Ng,Fg=-1;Tg();Vg(1,null,{},o);_.n=Uo;_.o=function(){return this.hb};_.p=Vo;_.q=function(){var a;return ih(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.n(a)};_.hashCode=function(){return this.p()};_.toString=function(){return this.q()};var bd,cd,dd;Vg(51,1,{},jh);_.G=function(a){var b;b=new jh;b.e=4;a>1?(b.c=oh(this,a-1)):(b.c=this);return b};_.H=function(){hh(this);return this.b};_.I=function(){return ih(this)};_.J=function(){hh(this);return this.i};_.K=function(){return (this.e&4)!=0};_.L=function(){return (this.e&1)!=0};_.q=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(hh(this),this.k)};_.e=0;_.g=0;var gh=1;var de=lh(1);var Wd=lh(51);Vg(79,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var rd=lh(79);Vg(36,1,ro,G);_.r=function(){return this.a.u(),null};var pd=lh(36);Vg(80,1,{},H);var qd=lh(80);var I;Vg(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var sd=lh(43);Vg(208,1,to);_.q=function(){var a;return ih(this.hb)+'@'+(a=r(this)>>>0,a.toString(16))};var vd=lh(208);Vg(20,208,to,U);_.s=function(){R(this)};_.t=To;_.a=false;_.d=0;var td=lh(20);Vg(133,1,{240:1},bb);var ud=lh(133);Vg(17,208,{9:1,17:1},kb);_.s=function(){cb(this)};_.t=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var xd=lh(17);Vg(113,1,wo,lb);_.u=function(){db(this.a)};var wd=lh(113);Vg(18,208,{9:1,18:1},xb,yb);_.s=function(){mb(this)};_.t=function(){return 1==(this.c&7)};_.c=0;var Cd=lh(18);Vg(114,1,zo,zb);_.u=function(){Q(this.a)};var yd=lh(114);Vg(115,1,wo,Ab);_.u=function(){ob(this.a)};var zd=lh(115);Vg(116,1,wo,Bb);_.u=function(){rb(this.a)};var Ad=lh(116);Vg(117,1,{},Cb);_.v=function(a){pb(this.a,a)};var Bd=lh(117);Vg(132,1,{},Fb);_.a=0;_.b=0;_.c=0;var Dd=lh(132);Vg(153,1,to,Hb);_.s=function(){Gb(this)};_.t=To;_.a=false;var Ed=lh(153);Vg(61,208,{9:1,61:1},Mb);_.s=function(){Ib(this)};_.t=function(){return 2==(3&this.a)};_.a=0;var Fd=lh(61);Vg(135,1,{},Yb);_.q=function(){var a;return hh(Gd),Gd.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.a=0;var Nb;var Gd=lh(135);Vg(101,1,{});var Jd=lh(101);Vg(81,1,{},cc);_.v=function(a){ac(this.a,a)};var Hd=lh(81);Vg(82,1,wo,dc);_.u=function(){bc(this.a,this.b)};var Id=lh(82);Vg(102,101,{});var Kd=lh(102);Vg(16,1,to,kc);_.s=function(){fc(this)};_.t=function(){return this.i<0};_.q=function(){var a;return hh(Md),Md.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Md=lh(16);Vg(112,1,wo,lc);_.u=function(){ic(this.a)};var Ld=lh(112);Vg(5,1,{3:1,5:1});_.A=function(a){return new Error(a)};_.B=function(){return this.f};_.C=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=ih(this.hb),c==null?a:a+': '+c);nc(this,pc(this.A(b)));Rc(this)};_.q=function(){return oc(this,this.B())};_.e=Ao;_.g=true;var he=lh(5);Vg(11,5,{3:1,11:1,5:1});var Zd=lh(11);Vg(8,11,Co);var ee=lh(8);Vg(52,8,Co);var ae=lh(52);Vg(73,52,Co);var Qd=lh(73);Vg(35,73,{35:1,3:1,11:1,8:1,5:1},uc);_.B=function(){tc(this);return this.c};_.D=function(){return md(this.b)===md(rc)?null:this.b};var rc;var Nd=lh(35);var Od=lh(0);Vg(194,1,{});var Pd=lh(194);var wc=0,xc=0,yc=-1;Vg(100,194,{},Mc);var Ic;var Rd=lh(100);var Pc;Vg(205,1,{});var Td=lh(205);Vg(74,205,{},Tc);var Sd=lh(74);var ah;Vg(71,1,{68:1});_.q=To;var Ud=lh(71);bd={3:1,69:1,31:1};var Vd=lh(69);Vg(41,1,{3:1,41:1});var ce=lh(41);cd={3:1,31:1,41:1};var Xd=lh(204);Vg(33,1,{3:1,31:1,33:1});_.n=Uo;_.p=Vo;_.q=function(){return this.a!=null?this.a:''+this.b};_.b=0;var Yd=lh(33);Vg(75,8,Co,uh);var $d=lh(75);Vg(32,41,{3:1,31:1,32:1,41:1},vh);_.n=function(a){return gd(a,32)&&a.a==this.a};_.p=To;_.q=function(){return ''+this.a};_.a=0;var _d=lh(32);var xh;Vg(272,1,{});Vg(77,52,Co,Ah);_.A=function(a){return new TypeError(a)};var be=lh(77);dd={3:1,68:1,31:1,2:1};var ge=lh(2);Vg(72,71,{68:1},Gh);var fe=lh(72);Vg(276,1,{});Vg(54,8,Co,Hh);var ie=lh(54);Vg(206,1,{39:1});_.M=Zo;_.Q=function(){return new Si(this,0)};_.R=function(){return new aj(null,this.Q())};_.O=function(a){throw Hg(new Hh('Add not supported on this collection'))};_.q=function(){var a,b,c;c=new Ui('[',']');for(b=this.N();b.T();){a=b.U();Ti(c,a===this?'(this Collection)':a==null?Do:Zg(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var je=lh(206);Vg(209,1,{192:1});_.n=function(a){var b,c,d;if(a===this){return true}if(!gd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Vh((new Sh(d)).a);c.b;){b=Uh(c);if(!Kh(this,b)){return false}}return true};_.p=function(){return ki(new Sh(this))};_.q=function(){var a,b,c;c=new Ui('{','}');for(b=new Vh((new Sh(this)).a);b.b;){a=Uh(b);Ti(c,Lh(this,a.W())+'='+Lh(this,a.X()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ue=lh(209);Vg(118,209,{192:1});var me=lh(118);Vg(210,206,{39:1,221:1});_.Q=function(){return new Si(this,1)};_.n=function(a){var b;if(a===this){return true}if(!gd(a,23)){return false}b=a;if(Qh(b.a)!=this.P()){return false}return Ih(this,b)};_.p=function(){return ki(this)};var ve=lh(210);Vg(23,210,{23:1,39:1,221:1},Sh);_.N=function(){return new Vh(this.a)};_.P=Xo;var le=lh(23);Vg(24,1,{},Vh);_.S=Wo;_.U=function(){return Uh(this)};_.T=Yo;_.b=false;var ke=lh(24);Vg(207,206,{39:1,218:1});_.Q=function(){return new Si(this,16)};_.V=function(a,b){throw Hg(new Hh('Add not supported on this list'))};_.O=function(a){this.V(this.P(),a);return true};_.n=function(a){var b,c,d,e,f;if(a===this){return true}if(!gd(a,13)){return false}f=a;if(this.P()!=f.a.length){return false}e=new ji(f);for(c=new ji(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(md(b)===md(d)||b!=null&&p(b,d))){return false}}return true};_.p=function(){return li(this)};_.N=function(){return new Wh(this)};var oe=lh(207);Vg(99,1,{},Wh);_.S=Wo;_.T=function(){return this.a<this.b.a.length};_.U=function(){return bi(this.b,this.a++)};_.a=0;var ne=lh(99);Vg(55,206,{39:1},Xh);_.N=function(){var a;a=new Vh((new Sh(this.a)).a);return new Yh(a)};_.P=Xo;var qe=lh(55);Vg(121,1,{},Yh);_.S=Wo;_.T=function(){return this.a.b};_.U=function(){var a;a=Uh(this.a);return a.X()};var pe=lh(121);Vg(119,1,Fo);_.n=function(a){var b;if(!gd(a,40)){return false}b=a;return mi(this.a,b.W())&&mi(this.b,b.X())};_.W=To;_.X=Yo;_.p=function(){return Ni(this.a)^Ni(this.b)};_.Y=function(a){var b;b=this.b;this.b=a;return b};_.q=function(){return this.a+'='+this.b};var re=lh(119);Vg(120,119,Fo,Zh);var se=lh(120);Vg(211,1,Fo);_.n=function(a){var b;if(!gd(a,40)){return false}b=a;return mi(this.b.value[0],b.W())&&mi(Ji(this),b.X())};_.p=function(){return Ni(this.b.value[0])^Ni(Ji(this))};_.q=function(){return this.b.value[0]+'='+Ji(this)};var te=lh(211);Vg(13,207,{3:1,13:1,39:1,218:1},hi,ii);_.V=function(a,b){oj(this.a,a,b)};_.O=function(a){return _h(this,a)};_.M=function(a){ai(this,a)};_.N=function(){return new ji(this)};_.P=function(){return this.a.length};var xe=lh(13);Vg(19,1,{},ji);_.S=Wo;_.T=function(){return this.a<this.c.a.length};_.U=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var we=lh(19);Vg(37,118,{3:1,37:1,192:1},ni);var ye=lh(37);Vg(59,1,{},ti);_.M=Zo;_.N=function(){return new ui(this)};_.b=0;var Ae=lh(59);Vg(60,1,{},ui);_.S=Wo;_.U=function(){return this.d=this.a[this.c++],this.d};_.T=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ze=lh(60);var xi;Vg(57,1,{},Hi);_.M=Zo;_.N=function(){return new Ii(this)};_.b=0;_.c=0;var De=lh(57);Vg(58,1,{},Ii);_.S=Wo;_.U=function(){return this.c=this.a,this.a=this.b.next(),new Ki(this.d,this.c,this.d.c)};_.T=function(){return !this.a.done};var Be=lh(58);Vg(134,211,Fo,Ki);_.W=function(){return this.b.value[0]};_.X=function(){return Ji(this)};_.Y=function(a){return Fi(this.a,this.b.value[0],a)};_.c=0;var Ce=lh(134);Vg(137,1,{});_.S=function(a){Pi(this,a)};_.Z=function(){return this.d};_.$=function(){return this.e};_.d=0;_.e=0;var Fe=lh(137);Vg(62,137,{});var Ee=lh(62);Vg(25,1,{},Si);_.Z=To;_.$=function(){Ri(this);return this.c};_.S=function(a){Ri(this);this.d.S(a)};_._=function(a){Ri(this);if(this.d.T()){a.v(this.d.U());return true}return false};_.a=0;_.c=0;var Ge=lh(25);Vg(53,1,{},Ui);_.q=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var He=lh(53);Vg(136,1,{});_.c=false;var Qe=lh(136);Vg(28,136,{241:1,28:1},aj);var Pe=lh(28);Vg(139,62,{},ej);_._=function(a){this.b=false;while(!this.b&&this.c._(new fj(this,a)));return this.b};_.b=false;var Je=lh(139);Vg(142,1,{},fj);_.v=function(a){dj(this.a,this.b,a)};var Ie=lh(142);Vg(138,62,{},gj);_._=function(a){return this.a._(new hj(a))};var Le=lh(138);Vg(141,1,{},hj);_.v=function(a){this.a.v(zm(new Am,a))};var Ke=lh(141);Vg(140,1,{},jj);_.v=function(a){ij(this,a)};var Me=lh(140);Vg(143,1,{},kj);_.v=function(a){};var Ne=lh(143);Vg(144,1,{},mj);_.v=function(a){lj(this,a)};var Oe=lh(144);Vg(274,1,{});Vg(215,1,{});var Re=lh(215);Vg(271,1,{});var tj=0;var vj,wj=0,xj;Vg(890,1,{});Vg(912,1,{});Vg(212,1,{});var Se=lh(212);Vg(242,$wnd.Function,{},Lj);_.bb=function(a){Kj(this.a,this.b,a)};Vg(7,33,{3:1,31:1,33:1,7:1},uk);var Zj,$j,_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk;var Te=mh(7,vk);var wk;Vg(243,$wnd.Function,{},yk);_.F=function(a){return Gb(wk),wk=null,null};Vg(216,212,{});var Af=lh(216);Vg(166,216,{});_.d=0;var Ef=lh(166);Vg(167,166,to,Fk);_.s=$o;_.n=Uo;_.p=Vo;_.t=_o;_.q=function(){var a;return hh(af),af.k+'@'+(a=uj(this)>>>0,a.toString(16))};var Ck=0;var af=lh(167);Vg(168,1,wo,Gk);_.u=function(){Dk(this.a)};var Ue=lh(168);Vg(169,1,ro,Hk);_.r=function(){return fh(),S((Gm(),Dm).b).a>0?true:false};var Ve=lh(169);Vg(170,1,zo,Ik);_.u=function(){Ak(this.a)};var We=lh(170);Vg(171,1,ro,Jk);_.r=function(){return Bk(this.a)};var Xe=lh(171);Vg(217,212,{});var zf=lh(217);Vg(186,217,{});_.c=0;var Df=lh(186);Vg(187,186,to,Ok);_.s=ap;_.n=Uo;_.p=Vo;_.t=bp;_.q=function(){var a;return hh(_e),_e.k+'@'+(a=uj(this)>>>0,a.toString(16))};var Mk=0;var _e=lh(187);Vg(188,1,wo,Pk);_.u=cp;var Ye=lh(188);Vg(189,1,zo,Qk);_.u=function(){Lk(this.a)};var Ze=lh(189);Vg(190,1,ro,Rk);_.r=function(){var a,b;return this.a.c=0,xk(),a=S((Gm(),Dm).e).a,b='item'+(a==1?'':'s'),Jj('span',Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,['todo-count'])),[Jj('strong',null,[a]),' '+b+' left'])};var $e=lh(190);Vg(158,212,{});_.e='';var Mf=lh(158);Vg(159,158,{});_.d=0;var Gf=lh(159);Vg(160,159,to,bl);_.s=$o;_.n=Uo;_.p=Vo;_.t=_o;_.q=function(){var a;return hh(gf),gf.k+'@'+(a=uj(this)>>>0,a.toString(16))};var Xk=0;var gf=lh(160);Vg(161,1,wo,cl);_.u=function(){Yk(this.a)};var bf=lh(161);Vg(163,1,ro,dl);_.r=function(){return Wk(this.a)};var cf=lh(163);Vg(164,1,wo,el);_.u=function(){Sk(this.a)};var df=lh(164);Vg(165,1,wo,fl);_.u=function(){$k(this.a,this.b)};var ef=lh(165);Vg(162,1,zo,gl);_.u=function(){Ak(this.a)};var ff=lh(162);Vg(214,212,{});_.i=false;var Of=lh(214);Vg(173,214,{});_.f=0;var If=lh(173);Vg(174,173,to,Bl);_.s=function(){fc(this.e)};_.n=Uo;_.p=Vo;_.t=function(){return this.e.i<0};_.q=function(){var a;return hh(sf),sf.k+'@'+(a=uj(this)>>>0,a.toString(16))};var rl=0;var sf=lh(174);Vg(175,1,wo,Cl);_.u=function(){sl(this.a)};var hf=lh(175);Vg(178,1,ro,Dl);_.r=function(){return ql(this.a)};var jf=lh(178);Vg(63,1,wo,El);_.u=function(){Al(this.a,Pm(this.b))};var kf=lh(63);Vg(176,1,ro,Fl);_.r=function(){return ul(this.a)};var lf=lh(176);Vg(64,1,wo,Gl);_.u=function(){ll(this.a,this.b)};var mf=lh(64);Vg(179,1,wo,Hl);_.u=function(){kl(this.a,this.b)};var nf=lh(179);Vg(180,1,wo,Il);_.u=function(){zl(this.a,this.b);Wn((Gm(),Fm),null)};var of=lh(180);Vg(181,1,wo,Jl);_.u=function(){hl(this.a,this.b)};var pf=lh(181);Vg(177,1,zo,Kl);_.u=function(){pl(this.a)};var qf=lh(177);Vg(182,1,wo,Ll);_.u=function(){ml(this.a)};var rf=lh(182);Vg(213,212,{});var Qf=lh(213);Vg(146,213,{});_.c=0;var Kf=lh(146);Vg(147,146,to,Ql);_.s=ap;_.n=Uo;_.p=Vo;_.t=bp;_.q=function(){var a;return hh(wf),wf.k+'@'+(a=uj(this)>>>0,a.toString(16))};var Ol=0;var wf=lh(147);Vg(148,1,wo,Rl);_.u=cp;var tf=lh(148);Vg(149,1,zo,Sl);_.u=function(){Lk(this.a)};var uf=lh(149);Vg(150,1,ro,Tl);_.r=function(){var a;return this.a.c=0,xk(),Jj('div',null,[Jj('div',null,[Jj(No,Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,[No])),[Jj('h1',null,['todos']),(new rm).a]),S((Gm(),Dm).c)?null:Jj('section',Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,[No])),[Jj(Mo,Tj(Wj(Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,['toggle-all'])),(tk(),$j)),Xg(Bm.prototype.db,Bm,[])),null),Jj('ul',Mj(new $wnd.Object,$c(Uc(ge,1),so,2,6,['todo-list'])),(a=_i(Oi($i(S(Fm.c).R())),new hi),gi(a,Zc(a.a.length))))]),S(Dm.c)?null:(new Vl).a])])};var vf=lh(150);Vg(247,$wnd.Function,{},Ul);_.fb=function(a){Gn((Gm(),Em))};Vg(152,1,{},Vl);var xf=lh(152);Vg(172,1,{},Wl);var yf=lh(172);Vg(248,$wnd.Function,{},Xl);_.gb=function(a){return new $l(a)};var Yl;Vg(156,$wnd.React.Component,{},$l);Ug(Sg[1],_);_.componentWillUnmount=function(){zk(this.a)};_.render=function(){return Ek(this.a)};_.shouldComponentUpdate=dp;var Bf=lh(156);Vg(258,$wnd.Function,{},_l);_.gb=function(a){return new cm(a)};var am;Vg(183,$wnd.React.Component,{},cm);Ug(Sg[1],_);_.componentWillUnmount=function(){Kk(this.a)};_.render=function(){return Nk(this.a)};_.shouldComponentUpdate=ep;var Cf=lh(183);Vg(246,$wnd.Function,{},dm);_.gb=function(a){return new gm(a)};var em;Vg(154,$wnd.React.Component,{},gm);Ug(Sg[1],_);_.componentWillUnmount=function(){zk(this.a)};_.render=function(){return _k(this.a)};_.shouldComponentUpdate=dp;var Ff=lh(154);Vg(257,$wnd.Function,{},hm);_.gb=function(a){return new km(a)};var im;Vg(157,$wnd.React.Component,{},km);Ug(Sg[1],_);_.componentDidUpdate=function(a){xl(this.a)};_.componentWillUnmount=function(){ol(this.a)};_.render=function(){return yl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Hf=lh(157);Vg(239,$wnd.Function,{},lm);_.gb=function(a){return new om(a)};var mm;Vg(123,$wnd.React.Component,{},om);Ug(Sg[1],_);_.componentWillUnmount=function(){Kk(this.a)};_.render=function(){return Pl(this.a)};_.shouldComponentUpdate=ep;var Jf=lh(123);Vg(244,$wnd.Function,{},pm);_.eb=function(a){Tk(this.a,a)};Vg(245,$wnd.Function,{},qm);_.db=function(a){Zk(this.a,a)};Vg(151,1,{},rm);var Lf=lh(151);Vg(255,$wnd.Function,{},sm);_.db=function(a){tl(this.a,a)};Vg(249,$wnd.Function,{},tm);_.db=function(a){jn(this.a)};Vg(251,$wnd.Function,{},um);_.fb=function(a){vl(this.a,this.b)};Vg(252,$wnd.Function,{},vm);_.fb=function(a){nl(this.a)};Vg(253,$wnd.Function,{},wm);_.v=function(a){il(this.a,a)};Vg(254,$wnd.Function,{},xm);_.cb=function(a){wl(this.a,this.b)};Vg(256,$wnd.Function,{},ym);_.eb=function(a){jl(this.a,this.b,a)};Vg(155,1,{},Am);var Nf=lh(155);Vg(238,$wnd.Function,{},Bm);_.db=function(a){var b;b=a.target;Kn((Gm(),Em),b.checked)};Vg(67,1,{},Cm);var Pf=lh(67);var Dm,Em,Fm;Vg(124,1,{});var ug=lh(124);Vg(125,124,Po,Tm);_.s=$o;_.n=Uo;_.p=Vo;_.t=_o;_.w=fp;_.q=function(){var a;return hh(Yf),Yf.k+'@'+(a=uj(this)>>>0,a.toString(16))};var Yf=lh(125);Vg(126,1,wo,Um);_.u=function(){Nm(this.a)};var Rf=lh(126);Vg(128,1,zo,Vm);_.u=function(){Im(this.a)};var Sf=lh(128);Vg(129,1,zo,Wm);_.u=function(){Jm(this.a)};var Tf=lh(129);Vg(130,1,wo,Xm);_.u=function(){Hm(this.a,this.b)};var Uf=lh(130);Vg(131,1,wo,Ym);_.u=function(){Qm(this.a)};var Vf=lh(131);Vg(56,1,wo,Zm);_.u=function(){Mm(this.a)};var Wf=lh(56);Vg(127,1,ro,$m);_.r=function(){var a;return a=(bh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var Xf=lh(127);Vg(44,1,{44:1});_.d=false;var Cg=lh(44);Vg(45,44,{9:1,49:1,45:1,44:1},kn);_.s=$o;_.n=function(a){return cn(this,a)};_.p=function(){return this.c.d};_.t=_o;_.w=fp;_.q=function(){var a;return hh(mg),mg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var _m=0;var mg=lh(45);Vg(184,1,wo,ln);_.u=function(){an(this.a)};var Zf=lh(184);Vg(185,1,wo,mn);_.u=function(){fn(this.a)};var $f=lh(185);Vg(42,102,{42:1});var xg=lh(42);Vg(103,42,{9:1,49:1,42:1},vn);_.s=function(){fc(this.f)};_.n=Uo;_.p=Vo;_.t=function(){return this.f.i<0};_.w=function(a){jc(this.f,a)};_.q=function(){var a;return hh(hg),hg.k+'@'+(a=uj(this)>>>0,a.toString(16))};var hg=lh(103);Vg(105,1,wo,wn);_.u=function(){on(this.a)};var _f=lh(105);Vg(104,1,wo,xn);_.u=function(){sn(this.a)};var ag=lh(104);Vg(110,1,wo,yn);_.u=function(){_b(this.a,this.b,true)};var bg=lh(110);Vg(111,1,ro,zn);_.r=function(){return nn(this.a,this.c,this.b)};_.b=false;var cg=lh(111);Vg(106,1,ro,An);_.r=function(){return tn(this.a)};var dg=lh(106);Vg(107,1,ro,Bn);_.r=function(){return wh(Mg(Yi(rn(this.a))))};var eg=lh(107);Vg(108,1,ro,Cn);_.r=function(){return wh(Mg(Yi(Zi(rn(this.a),new jo))))};var fg=lh(108);Vg(109,1,ro,Dn);_.r=function(){return un(this.a)};var gg=lh(109);Vg(87,1,{});var Bg=lh(87);Vg(88,87,Po,Ln);_.s=function(){fc(this.a)};_.n=Uo;_.p=Vo;_.t=function(){return this.a.i<0};_.w=function(a){jc(this.a,a)};_.q=function(){var a;return hh(lg),lg.k+'@'+(a=uj(this)>>>0,a.toString(16))};var lg=lh(88);Vg(89,1,wo,Mn);_.u=function(){Hn(this.a,this.b)};_.b=false;var ig=lh(89);Vg(90,1,wo,Nn);_.u=function(){Sm(this.b,this.a)};var jg=lh(90);Vg(91,1,wo,On);_.u=function(){In(this.a)};var kg=lh(91);Vg(92,1,{});var Eg=lh(92);Vg(93,92,Po,Xn);_.s=function(){fc(this.g)};_.n=Uo;_.p=Vo;_.t=function(){return this.g.i<0};_.w=function(a){jc(this.g,a)};_.q=function(){var a;return hh(sg),sg.k+'@'+(a=uj(this)>>>0,a.toString(16))};var sg=lh(93);Vg(94,1,wo,Yn);_.u=function(){Rn(this.a)};var ng=lh(94);Vg(95,1,ro,Zn);_.r=function(){var a;return a=Pm(this.a.i),Ch(Ro,a)?(go(),co):Ch(So,a)?(go(),fo):(go(),eo)};var og=lh(95);Vg(96,1,ro,$n);_.r=function(){return Tn(this.a)};var pg=lh(96);Vg(97,1,zo,_n);_.u=function(){Un(this.a)};var qg=lh(97);Vg(98,1,zo,ao);_.u=function(){Vn(this.a)};var rg=lh(98);Vg(122,1,{},bo);_.handleEvent=function(a){Km(this.a,a)};var tg=lh(122);Vg(34,33,{3:1,31:1,33:1,34:1},ho);var co,eo,fo;var vg=mh(34,io);Vg(83,1,{},jo);_.ab=function(a){return !en(a)};var wg=lh(83);Vg(85,1,{},ko);_.ab=function(a){return en(a)};var yg=lh(85);Vg(86,1,{},lo);_.v=function(a){qn(this.a,a)};var zg=lh(86);Vg(84,1,{},mo);_.v=function(a){Fn(this.a,a)};_.a=false;var Ag=lh(84);Vg(76,1,{},no);_.ab=function(a){return Qn(this.a,a)};var Dg=lh(76);var od=nh('D');var oo=(zc(),Cc);var gwtOnLoad=gwtOnLoad=Qg;Og(_g);Rg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();