function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='AA030D871624231AD16C5C1A18A7C5D7',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'AA030D871624231AD16C5C1A18A7C5D7';function o(){}
function $g(){}
function Wg(){}
function Bb(){}
function Qc(){}
function Xc(){}
function Xl(){}
function Ql(){}
function Qj(){}
function lj(){}
function mj(){}
function Gk(){}
function Vl(){}
function Zl(){}
function _l(){}
function bm(){}
function sm(){}
function Hn(){}
function In(){}
function xo(){}
function Vc(a){Uc()}
function fh(){fh=Wg}
function ii(){_h(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function fb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function ub(a){this.a=a}
function cc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function gc(a){this.a=a}
function kc(a){this.a=a}
function wh(a){this.a=a}
function Hh(a){this.a=a}
function Th(a){this.a=a}
function Yh(a){this.a=a}
function Zh(a){this.a=a}
function Xh(a){this.b=a}
function ki(a){this.c=a}
function jj(a){this.a=a}
function oj(a){this.a=a}
function Hk(a){this.a=a}
function Ik(a){this.a=a}
function Jk(a){this.a=a}
function Ok(a){this.a=a}
function Pk(a){this.a=a}
function Qk(a){this.a=a}
function _k(a){this.a=a}
function al(a){this.a=a}
function cl(a){this.a=a}
function dl(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function Al(a){this.a=a}
function Fl(a){this.a=a}
function Il(a){this.a=a}
function Nl(a){this.a=a}
function Ol(a){this.a=a}
function Pl(a){this.a=a}
function dm(a){this.a=a}
function em(a){this.a=a}
function hm(a){this.a=a}
function im(a){this.a=a}
function km(a){this.a=a}
function lm(a){this.a=a}
function Lm(a){this.a=a}
function Mm(a){this.a=a}
function Vm(a){this.a=a}
function Xm(a){this.a=a}
function Zm(a){this.a=a}
function $m(a){this.a=a}
function _m(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function An(a){this.a=a}
function Jn(a){this.a=a}
function Kn(a){this.a=a}
function Ln(a){this.a=a}
function Sl(){this.a={}}
function Ul(){this.a={}}
function gm(){this.a={}}
function rm(){this.a={}}
function um(){this.a={}}
function Co(){Lj(this.a)}
function Ho(){Nj(this.a)}
function ui(){this.a=Di()}
function Ii(){this.a=Di()}
function w(a){--a.e;D(a)}
function wo(a){Ah(this,a)}
function to(a){Mi(this,a)}
function db(a){Mb((J(),a))}
function ab(a){Lb((J(),a))}
function $(a){Kb((J(),a))}
function C(a,b){yb(a.b,b)}
function oc(a,b){Ph(a.b,b)}
function nj(a,b){dj(a.a,b)}
function an(a,b){Om(a.c,b)}
function bn(a,b){Hm(b,a)}
function kj(a,b){a.a=b}
function Ej(a,b,c){a[b]=c}
function mb(a,b){a.b=Pi(b)}
function Hg(a){return a.e}
function Fo(){return this.e}
function qo(){return this.a}
function vo(){return this.b}
function zo(){return this.c}
function Jo(){return this.f}
function Ao(){return this.d<0}
function Go(){return this.c<0}
function Io(){return this.f<0}
function so(){return wj(this)}
function Dh(a,b){return a===b}
function gl(a,b){return a.g=b}
function ci(a,b){return a.a[b]}
function sj(a,b){a.splice(b,1)}
function mc(a,b,c){Oh(a.b,b,c)}
function Mk(a){nc(a.b);gb(a.a)}
function Ih(a){uc.call(this,a)}
function Wl(a){Ij.call(this,a)}
function Yl(a){Ij.call(this,a)}
function $l(a){Ij.call(this,a)}
function am(a){Ij.call(this,a)}
function cm(a){Ij.call(this,a)}
function kl(a){Pm((zm(),wm),a)}
function Bo(){return J(),J(),I}
function ro(a){return this===a}
function ih(a){hh(a);return a.k}
function Yc(a,b){return oh(a,b)}
function F(){this.b=new zb}
function pc(){this.b=new oi}
function J(){J=Wg;I=new F}
function wc(){wc=Wg;vc=new o}
function Nc(){Nc=Wg;Mc=new Qc}
function zi(){zi=Wg;yi=Bi()}
function Dc(){Dc=Wg;!!(Uc(),Tc)}
function Pg(){Ng==null&&(Ng=[])}
function Bh(){qc(this);this.G()}
function uo(){return Rh(this.a)}
function Do(){return Pj(this.a)}
function Rh(a){return a.a.b+a.b.b}
function X(a){J();Lb(a);a.e=-2}
function Eb(a){Fb(a);!a.d&&Ib(a)}
function Vb(a){bb(a.a);return a.e}
function Wb(a){bb(a.b);return a.g}
function Dm(a){bb(a.b);return a.i}
function Em(a){bb(a.a);return a.g}
function pn(a){bb(a.d);return a.f}
function cj(a,b){a.R(b);return a}
function Sj(a,b){a.ref=b;return a}
function dj(a,b){kj(a,cj(a.a,b))}
function Qi(a,b){while(a.cb(b));}
function Fi(a,b){return a.a.get(b)}
function bd(a){return new Array(a)}
function Di(){zi();return new yi}
function Tj(a,b){a.href=b;return a}
function gj(a,b){this.a=a;this.b=b}
function dc(a,b){this.a=a;this.b=b}
function lc(a,b){this.a=a;this.b=b}
function th(a,b){this.a=a;this.b=b}
function $h(a,b){this.a=a;this.b=b}
function bl(a,b){this.a=a;this.b=b}
function Cl(a,b){this.a=a;this.b=b}
function Dl(a,b){this.a=a;this.b=b}
function El(a,b){this.a=a;this.b=b}
function Gl(a,b){this.a=a;this.b=b}
function Hl(a,b){this.a=a;this.b=b}
function jm(a,b){this.a=a;this.b=b}
function mm(a,b){this.a=a;this.b=b}
function nm(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function mn(a,b){this.a=a;this.b=b}
function jn(a,b){this.b=a;this.a=b}
function Fn(a,b){th.call(this,a,b)}
function Ak(a,b){th.call(this,a,b)}
function qj(a,b,c){a.splice(b,0,c)}
function hj(a,b){a.B(qm(om(b.e),b))}
function Yb(a){Ub(a,(bb(a.b),a.g))}
function Gm(a){Hm(a,(bb(a.a),!a.g))}
function Gb(a){return !a.d?a:Gb(a.d)}
function Nh(a){return !a?null:a.$()}
function qd(a){return a==null?null:a}
function Oi(a){return a!=null?r(a):0}
function om(a){return pm(new rm,a)}
function nd(a){return typeof a===On}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function L(a){a.b=0;a.d=0;a.c=false}
function Qh(a){a.a=new ui;a.b=new Ii}
function _h(a){a.a=$c(je,Rn,1,0,5,1)}
function Kc(a){$wnd.clearTimeout(a)}
function Ek(a){nc(a.c);gb(a.b);S(a.a)}
function Yk(a){nc(a.c);gb(a.a);W(a.b)}
function lb(a){J();kb(a);nb(a,2,true)}
function rj(a,b){pj(b,0,a,0,b.length)}
function jc(a,b){hc(a,b,false);ab(a.d)}
function bk(a,b){a.value=b;return a}
function Yj(a,b){a.onBlur=b;return a}
function Uj(a,b){a.onClick=b;return a}
function Zj(a,b){a.onChange=b;return a}
function Wj(a,b){a.checked=b;return a}
function Fh(a,b){a.a+=''+b;return a}
function $j(a,b){a.onKeyDown=b;return a}
function eb(a){this.c=new ii;this.b=a}
function Aj(){Aj=Wg;xj=new o;zj=new o}
function A(a,b,c){t(a,new G(b),c,null)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function Ch(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function V(a){return !(!!a&&1==(a.c&7))}
function wj(a){return a.$H||(a.$H=++vj)}
function pd(a){return typeof a==='string'}
function yo(){return T((zm(),wm).b).a>0}
function il(a,b){un((zm(),ym),b);vl(a,b)}
function bj(a,b){Yi.call(this,a);this.a=b}
function uc(a){this.f=a;qc(this);this.G()}
function hn(a){this.c=Pi(a);this.a=new pc}
function oi(){this.a=new ui;this.b=new Ii}
function Q(){this.a=$c(je,Rn,1,100,5,1)}
function bb(a){var b;Hb((J(),b=Cb,b),a)}
function rc(a,b){a.e=b;b!=null&&uj(b,ao,a)}
function hh(a){if(a.k!=null){return}qh(a)}
function Vj(a){a.autoFocus=true;return a}
function Xj(a,b){a.defaultValue=b;return a}
function ck(a,b){a.onDoubleClick=b;return a}
function Mi(a,b){while(a.W()){nj(b,a.X())}}
function ic(a,b){oc(b.C(),a);ld(b,11)&&b.v()}
function Ec(a,b,c){return a.apply(b,c);var d}
function u(a,b){return new qb(Pi(a),null,b)}
function md(a){return typeof a==='boolean'}
function Tm(a){return xh(T(a.e).a-T(a.a).a)}
function Fm(a){nc(a.c);W(a.d);W(a.b);W(a.a)}
function wi(a,b){var c;c=a[go];c.call(a,b)}
function uj(b,c,d){try{b[c]=d}catch(a){}}
function Li(a,b,c){this.a=a;this.b=b;this.c=c}
function ai(a,b){a.a[a.a.length]=b;return true}
function qc(a){a.g&&a.e!==_n&&a.G();return a}
function nh(){var a;a=kh(null);a.e=2;return a}
function lh(a){var b;b=kh(a);sh(a,b);return b}
function pm(a,b){Pi(b);Ej(a.a,'key',b);return a}
function jb(a,b){Z(b,a);b.c.a.length>0||(b.a=4)}
function Rb(a,b){a.i&&b.preventDefault();ac(a)}
function Xk(a,b){var c;c=b.target;Zk(a,c.value)}
function Ym(a,b){this.a=a;this.c=b;this.b=false}
function Ri(a,b){this.e=a;this.d=(b&64)!=0?b|Pn:b}
function Si(a){if(!a.d){a.d=a.b.Q();a.c=a.b.S()}}
function Ab(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function ej(a,b,c){if(a.a.db(c)){a.b=true;b.B(c)}}
function Vh(a){var b;b=a.a.X();a.b=Uh(a);return b}
function ei(a,b){var c;c=a.a[b];sj(a.a,b);return c}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ei(a,b){return !(a.a.get(b)===undefined)}
function P(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function ad(a){return Array.isArray(a)&&a.wb===$g}
function kd(a){return !Array.isArray(a)&&a.wb===$g}
function Sm(a){return fh(),0==T(a.e).a?true:false}
function nn(a){return Dh(po,a)||Dh(mo,a)||Dh('',a)}
function _i(a){Xi(a);return new bj(a,new ij(a.a))}
function Sh(a,b){if(b){return Lh(a.a,b)}return false}
function Pi(a){if(a==null){throw Hg(new Bh)}return a}
function Dj(){if(yj==256){xj=zj;zj=new o;yj=0}++yj}
function Uc(){Uc=Wg;var a;!Wc();a=new Xc;Tc=a}
function bh(){bh=Wg;ah=$wnd.window.document}
function zh(){zh=Wg;yh=$c(fe,Rn,33,256,0,1)}
function pl(a){nc(a.e);gb(a.b);S(a.d);W(a.c);W(a.a)}
function Wi(a){if(!a.b){Xi(a);a.c=true}else{Wi(a.b)}}
function Zk(a,b){var c;c=a.e;if(b!=c){a.e=b;ab(a.b)}}
function wl(a,b){var c;c=a.i;if(b!=c){a.i=b;ab(a.a)}}
function Hm(a,b){var c;c=a.g;if(b!=c){a.g=b;ab(a.a)}}
function gi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ak(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ni(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function Oj(a){Mj(a);return ld(a,11)&&a.w()?null:a.mb()}
function $i(a,b){Xi(a);return new bj(a,new fj(b,a.a))}
function Mg(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function Lj(a){if(!a.k){a.k=true;a.n||a.o.forceUpdate()}}
function Yi(a){if(!a){this.b=null;new ii}else{this.b=a}}
function ij(a){Ri.call(this,a.bb(),a.ab()&-6);this.a=a}
function Bl(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function Nb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function Ti(a,b){this.b=a;this.a=(b&4096)==0?b|64|Pn:b}
function _b(a,b){var c;c=a.g;if(b!=c){a.g=Pi(b);ab(a.b)}}
function $b(a,b){var c;c=a.e;if(b!=c){a.e=Pi(b);ab(a.a)}}
function Im(a,b){var c;c=a.i;if(b!=c){a.i=Pi(b);ab(a.b)}}
function mh(a,b){var c;c=kh(a);sh(a,c);c.e=b?8:0;return c}
function sc(a,b){var c;c=ih(a.ub);return b==null?c:c+': '+b}
function Mh(a,b){return b===a?'(this Map)':b==null?co:Zg(b)}
function ql(a,b,c,d){return fh(),nl(a,b,c,d)?true:false}
function hl(a,b,c){27==c.which?sl(a,b):13==c.which&&ul(a,b)}
function fl(a,b){var c;if(T(a.d)){c=b.target;wl(a,c.value)}}
function cb(a){var b;J();!!Cb&&!!Cb.e&&Hb((b=Cb,b),a)}
function xb(a){while(true){if(!vb(a)&&!wb(a)){break}}}
function Db(a){if(a.e){2==(a.e.c&7)||nb(a.e,4,true);kb(a.e)}}
function qn(a){nc(a.g);gb(a.e);gb(a.a);S(a.b);S(a.c);W(a.d)}
function vh(a){this.f=!a?null:sc(a,a.F());qc(this);this.G()}
function Fj(a,b){null!=b&&a.hb(b,a.o.props,true);a.eb()}
function Sk(a,b){if(13==b.keyCode){b.preventDefault();Vk(a)}}
function yb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],Pi(b))}
function Ob(a,b){Cb=new Nb(Cb,b);a.d=false;Db(Cb);return Cb}
function ph(a){if(a.O()){return null}var b=a.j;return Sg[b]}
function Yg(a){function b(){}
;b.prototype=a||{};return new b}
function Kl(){Kl=Wg;var a;Jl=(a=Xg(bm.prototype.ib,bm,[]),a)}
function ml(){ml=Wg;var a;ll=(a=Xg(_l.prototype.ib,_l,[]),a)}
function Dk(){Dk=Wg;var a;Ck=(a=Xg(Vl.prototype.ib,Vl,[]),a)}
function Lk(){Lk=Wg;var a;Kk=(a=Xg(Xl.prototype.ib,Xl,[]),a)}
function Uk(){Uk=Wg;var a;Tk=(a=Xg(Zl.prototype.ib,Zl,[]),a)}
function Gn(){En();return cd(Yc(vg,1),Rn,37,0,[Bn,Dn,Cn])}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Rl(a){return $wnd.React.createElement((Dk(),Ck),a.a)}
function Tl(a){return $wnd.React.createElement((Lk(),Kk),a.a)}
function fm(a){return $wnd.React.createElement((Uk(),Tk),a.a)}
function tm(a){return $wnd.React.createElement((Kl(),Jl),a.a)}
function oh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function qi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function en(a,b){var c;aj(Qm(a.c),(c=new ii,c)).P(new Kn(b))}
function Ah(a,b){var c,d;for(d=a.Q();d.W();){c=d.X();b.B(c)}}
function hb(a){var b;b=(J(),J(),I);yb(b.b,a);0!=(a.c&Xn)&&D(b)}
function Qb(a,b){a.j=b;Dh(b,(bb(a.a),a.e))&&_b(a,b);Sb(b);ac(a)}
function sn(a){var b;b=(bb(a.d),a.f);!!b&&!!b&&b.f<0&&un(a,null)}
function Xi(a){if(a.b){Xi(a.b)}else if(a.c){throw Hg(new uh)}}
function Qm(a){bb(a.d);return new bj(null,new Ti(new Yh(a.i),0))}
function ji(a){_h(this);rj(this.a,Kh(a,$c(je,Rn,1,Rh(a.a),5,1)))}
function vi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function _j(a){a.placeholder='What needs to be done?';return a}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ug(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ri(a,b){var c;return pi(b,qi(a,b==null?0:(c=r(b),c|0)))}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function dh(a,b,c,d){a.addEventListener(b,c,(fh(),d?true:false))}
function eh(a,b,c,d){a.removeEventListener(b,c,(fh(),d?true:false))}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&Pn)?Pn:8192)|0|0,b)}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&Pn)?Pn:8192)|0|0,b)}
function Ph(a,b){return pd(b)?b==null?ti(a.a,null):Hi(a.b,b):ti(a.a,b)}
function Eo(){return pn((zm(),ym))==(cb(this.c),this.o.props['a'])}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function N(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Ui(a,b){!a.a?(a.a=new Hh(a.d)):Fh(a.a,a.b);Fh(a.a,b);return a}
function aj(a,b){var c;Wi(a);c=new lj;c.a=b;a.a.V(new oj(c));return c.a}
function Zi(a){var b;Wi(a);b=0;while(a.a.cb(new mj)){b=Ig(b,1)}return b}
function dn(a){var b;aj($i(Qm(a.c),new In),(b=new ii,b)).P(new Jn(a.c))}
function zm(){zm=Wg;vm=new bc;wm=new Um;xm=new hn(wm);ym=new vn(wm,vm)}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function Ji(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Wh(a){this.d=a;this.c=new Ji(this.d.b);this.a=this.c;this.b=Uh(this)}
function Vi(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function fj(a,b){Ri.call(this,b.bb(),b.ab()&-16449);this.a=a;this.c=b}
function Y(a,b){var c,d;ai(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function un(a,b){var c;c=a.f;if(!(b==c||!!b&&Cm(b,c))){a.f=b;ab(a.d)}}
function on(a,b){return (En(),Cn)==a||(Bn==a?(bb(b.a),!b.g):(bb(b.a),b.g))}
function rl(a){return fh(),pn((zm(),ym))==(cb(a.c),a.o.props['a'])?true:false}
function Cm(a,b){var c;if(ld(b,50)){c=b;return a.e==c.e}else{return false}}
function qm(a,b){Ej(a.a,(ml(),'a'),b);return $wnd.React.createElement(ll,a.a)}
function Ki(a){if(a.a.c!=a.c){return Fi(a.a,a.b.value[0])}return a.b.value[1]}
function Bm(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Lm(a)),Wn,null)}}
function rn(a){var b,c;return b=T(a.b),aj($i(Qm(a.k),new Ln(b)),(c=new ii,c))}
function bi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.B(c)}}
function fi(a,b){var c;c=di(a,b,0);if(c==-1){return false}sj(a.a,c);return true}
function Pj(a){var b;a.k=false;if(a.kb()){return null}else{b=a.gb();return b}}
function Gj(a,b){var c;c=null!=b&&a.hb(a.o.props,b,false);c||(a.p=false);return c}
function Hj(a,b){var c;if(b){c=a.p;a.p=false;return !c}else{a.p=true;return true}}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function di(a,b,c){for(;c<a.a.length;++c){if(ni(b,a.a[c])){return c}}return -1}
function Oh(a,b,c){return pd(b)?b==null?si(a.a,null,c):Gi(a.b,b,c):si(a.a,b,c)}
function tj(a,b){return Zc(b)!=10&&cd(q(b),b.vb,b.__elementTypeId$,Zc(b),a),a}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===Nn||typeof a==='function')&&!(a.wb===$g)}
function Xb(a){eh((bh(),$wnd.window.window),Zn,a.f,false);nc(a.c);W(a.b);W(a.a)}
function S(a){if(!a.a){a.a=true;a.g=null;a.b=null;W(a.d);2==(a.e.c&7)||gb(a.e)}}
function W(a){if(-2!=a.e){t((J(),J(),I),new G(new fb(a)),0,null);!!a.b&&gb(a.b)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{xb(a.b)}finally{a.c=false}}}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Rk(a){var b;b=Eh((bb(a.b),a.e));if(b.length>0){an((zm(),xm),b);Zk(a,'')}}
function Pb(){var a;try{Eb(Cb);J()}finally{a=Cb.d;!a&&((J(),J(),I).d=true);Cb=Cb.d}}
function vb(a){var b;if(0==P(a.c)){return false}else{b=O(a.c);!!b&&b.v();return true}}
function Gg(a){var b;if(ld(a,4)){return a}b=a&&a[ao];if(!b){b=new yc(a);Vc(b)}return b}
function sh(a,b){var c;if(!a){return}b.j=a;var d=ph(b);if(!d){Sg[a]=[b];return}d.ub=b}
function Xg(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function kh(a){var b;b=new jh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Hi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{wi(a.a,b);--a.b}return c}
function Hb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;ai((!a.b&&(a.b=new ii),a.b),b)}}}
function Jb(a,b){var c;if(!a.c){c=Gb(a);!c.c&&(c.c=new ii);a.c=c.c}b.d=true;ai(a.c,Pi(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);N(a,Pi(b))}
function Nj(a){var b;b=(++a.lb().e,new Bb);try{a.n=true;ld(a,11)&&a.v()}finally{Ab(b)}}
function li(a){var b,c,d;d=0;for(c=new Wh(a.a);c.b;){b=Vh(c);d=d+(b?r(b):0);d=d|0}return d}
function Jh(a,b){var c,d;for(d=new Wh(b.a);d.b;){c=Vh(d);if(!Sh(a,c)){return false}}return true}
function kb(a){var b,c;for(c=new ki(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Og(){Pg();var a=Ng;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function uh(){uc.call(this,"Stream already terminated, can't be modified or used")}
function En(){En=Wg;Bn=new Fn('ACTIVE',0);Dn=new Fn('COMPLETED',1);Cn=new Fn('ALL',2)}
function Rm(a){Ah(new Yh(a.i),new kc(a));Qh(a.i);nc(a.f);S(a.c);S(a.e);S(a.a);S(a.b);W(a.d)}
function Nm(a,b,c){var d;d=new Km(b,c);mc(d.c,a,new lc(a,d));Oh(a.i,xh(d.e),d);ab(a.d);return d}
function hc(a,b,c){var d;d=Ph(a.i,b?xh(b.e):null);if(null!=d){oc(b.c,a);c&&!!b&&Bm(b);ab(a.d)}}
function gb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new tb(a)),Wn,null);!!a.a&&S(a.a);a.c=a.c&-8|1}}
function Uh(a){if(a.a.W()){return true}if(a.a!=a.c){return false}a.a=new vi(a.d.a);return a.a.W()}
function Jg(a){var b;b=a.h;if(b==0){return a.l+a.m*Xn}if(b==1048575){return a.l+a.m*Xn-eo}return a}
function Lg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=eo;d=1048575}c=rd(e/Xn);b=rd(e-c*Xn);return dd(b,c,d)}
function pi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(ni(a,c.Z())){return c}}return null}
function nl(a,b,c,d){var e,f;e=false;f=Hj(a,d);if(!(b['a']===c['a'])){f&&ab(a.c);e=true}return e||a.k}
function cd(a,b,c,d,e){e.ub=a;e.vb=b;e.wb=$g;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Gi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Z(a,b){var c,d;d=a.c;fi(d,b);d.a.length==0&&!!a.b&&Tn!=(a.b.c&Un)&&(a.d||Jb((J(),c=Cb,c),a))}
function tn(a){var b;b=Vb(a.j);Dh(po,b)||Dh(mo,b)||Dh('',b)?Ub(a.j,b):nn(Wb(a.j))?Zb(a.j):Ub(a.j,'')}
function T(a){bb(a.d);ob(a.e)&&ib(a.e);if(a.b){if(ld(a.b,5)){throw Hg(a.b)}else{throw Hg(a.b)}}return a.g}
function _g(){zm();$wnd.ReactDOM.render(tm(new um),(bh(),ah).getElementById('todoapp'),null)}
function Ij(a){$wnd.React.Component.call(this,a);this.a=this.jb();this.a.o=Pi(this);this.a.fb()}
function jh(){this.g=gh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function yc(a){wc();qc(this);this.e=a;a!=null&&uj(a,ao,this);this.f=a==null?co:Zg(a);this.a='';this.b=a;this.a=''}
function Nk(){Lk();++Jj;this.b=new pc;this.a=new qb(null,Pi((J(),new Ok(this))),jo);D((null,I))}
function Ml(){Kl();++Jj;this.b=new pc;this.a=new qb(null,Pi((J(),new Nl(this))),jo);D((null,I))}
function U(a,b){this.c=Pi(a);this.f=null;this.g=null;this.e=new rb(this,b);this.d=new eb(this.e);Tn==(b&Un)&&hb(this.e)}
function jl(a,b){var c;c=(bb(a.a),a.i);if(null!=c&&c.length!=0){fn((zm(),b),c);un(ym,null);wl(a,c)}else{Pm((zm(),wm),b)}}
function Tb(a){var b,c;c=(b=(bh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));$b(a,c);Dh(a.j,c)&&_b(a,c)}
function Mj(a){if(!Kj){Kj=(++a.lb().e,new Bb);$wnd.Promise.resolve(null).then(Xg(Qj.prototype.I,Qj,[]))}}
function Rg(a,b){typeof window===Nn&&typeof window['$gwt']===Nn&&(window['$gwt'][a]=b)}
function q(a){return pd(a)?me:nd(a)?be:md(a)?_d:kd(a)?a.ub:ad(a)?a.ub:a.ub||Array.isArray(a)&&Yc(Ud,1)||Ud}
function r(a){return pd(a)?Cj(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.s():ad(a)?wj(a):!!a&&!!a.hashCode?a.hashCode():wj(a)}
function p(a,b){return pd(a)?Dh(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.q(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function xh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(zh(),yh)[b];!c&&(c=yh[b]=new wh(a));return c}return new wh(a)}
function Zg(a){var b;if(Array.isArray(a)&&a.wb===$g){return ih(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Cj(a){Aj();var b,c,d;c=':'+a;d=zj[c];if(d!=null){return rd(d)}d=xj[c];b=d==null?Bj(a):rd(d);Dj();zj[c]=b;return b}
function mi(a){var b,c,d;d=1;for(c=new ki(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function nc(a){var b,c;if(!a.a){for(c=new ki(new ji(new Yh(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.A()}a.a=true}}
function el(a){var b;b=T(a.d);if(!a.j&&b){a.j=true;vl(a,(cb(a.c),a.o.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function Ig(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<eo){return c}}return Jg(ed(nd(a)?Lg(a):a,nd(b)?Lg(b):b))}
function Bk(){zk();return cd(Yc(af,1),Rn,10,0,[dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk])}
function Fk(){Dk();++Jj;this.c=new pc;this.a=new U((J(),new Gk),136486912);this.b=new qb(null,Pi(new Ik(this)),jo);D((null,I))}
function $k(){Uk();var a;++Jj;this.c=new pc;this.b=(a=new eb((J(),null)),a);this.a=new qb(null,Pi(new cl(this)),jo);D((null,I))}
function zb(){this.c=new Q;this.d=$c(vd,Rn,22,5,0,1);this.d[0]=new Q;this.d[1]=new Q;this.d[2]=new Q;this.d[3]=new Q;this.d[4]=new Q}
function pb(a,b,c,d){this.b=new ii;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&hb(this)}
function rh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function hi(a,b){var c,d;d=a.a.length;b.length<d&&(b=tj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function O(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Rj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.vb){return !!a.vb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function qb(a,b,c){pb.call(this,null,a,b,c|(!a?262144:Tn)|(a?Pn:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:Xn)|(0!=(c&229376)?0:98304)|0|0|0)}
function Mb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&nb(b,5,true)}}}
function Lb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ki(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&nb(b,6,true)}}}
function Kb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?nb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Eh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ib(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=ei(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&nb(c.b,3,true);++b}}}return b}
function Km(a,b){var c,d,e;this.i=Pi(a);this.g=b;this.e=Am++;this.d=(d=new eb((J(),null)),d);this.c=new pc;this.b=(e=new eb(null),e);this.a=(c=new eb(null),c)}
function Zb(b){var c;try{A((J(),J(),I),new ec(b),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){c=a;throw Hg(c)}else if(ld(a,4)){c=a;throw Hg(new vh(c))}else throw Hg(a)}}
function ac(b){var c;try{A((J(),J(),I),new fc(b),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){c=a;throw Hg(c)}else if(ld(a,4)){c=a;throw Hg(new vh(c))}else throw Hg(a)}}
function Vk(b){var c;try{A((J(),J(),I),new al(b),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){c=a;throw Hg(c)}else if(ld(a,4)){c=a;throw Hg(new vh(c))}else throw Hg(a)}}
function Jm(b){var c;try{A((J(),J(),I),new Mm(b),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){c=a;throw Hg(c)}else if(ld(a,4)){c=a;throw Hg(new vh(c))}else throw Hg(a)}}
function cn(b){var c;try{A((J(),J(),I),new kn(b),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){c=a;throw Hg(c)}else if(ld(a,4)){c=a;throw Hg(new vh(c))}else throw Hg(a)}}
function fn(b,c){var d;try{A((J(),J(),I),new jn(b,c),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function gn(b,c){var d;try{A((J(),J(),I),new mn(b,c),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function Wk(b,c){var d;try{A((J(),J(),I),new bl(b,c),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function ol(b,c){var d;try{A((J(),J(),I),new Hl(b,c),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function sl(b,c){var d;try{A((J(),J(),I),new Gl(b,c),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function tl(b,c){var d;try{A((J(),J(),I),new El(b,c),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function ul(b,c){var d;try{A((J(),J(),I),new Dl(b,c),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function vl(b,c){var d;try{A((J(),J(),I),new Cl(b,c),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function Pm(b,c){var d;try{A((J(),J(),I),new Wm(b,c),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function Ub(b,c){var d;try{A((J(),J(),I),new dc(b,c),75505664)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function Om(b,c){var d;try{return t((J(),J(),I),new Ym(b,c),$n,null)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function Qg(b,c,d,e){Pg();var f=Ng;$moduleName=c;$moduleBase=d;Fg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Mn(g)()}catch(a){b(c,a)}}else{Mn(g)()}}
function rb(a,b){pb.call(this,a,new sb(a),null,b|(Tn==(b&Un)?0:524288)|(0!=(b&6291456)?0:Tn==(b&Un)?Xn:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function Bi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ci()}}
function Kh(a,b){var c,d,e,f,g;g=Rh(a.a);b.length<g&&(b=tj(new Array(g),b));e=(f=new Wh((new Th(a.a)).a),new Zh(f));for(d=0;d<g;++d){b[d]=(c=Vh(e.a),c.$())}b.length>g&&(b[g]=null);return b}
function Tg(){Sg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].xb()&&(c=Rc(c,g)):g[0].xb()}catch(a){a=Gg(a);if(ld(a,4)){d=a;Dc();Jc(ld(d,40)?d.H():d)}else throw Hg(a)}}return c}
function xl(){ml();var a,b;++Jj;this.e=new pc;this.c=(b=new eb((J(),null)),b);this.a=(a=new eb(null),a);this.d=new U(new Fl(this),136486912);this.b=new qb(null,Pi(new Il(this)),jo);D((null,I))}
function Um(){var a;this.i=new oi;this.f=new pc;this.d=(a=new eb((J(),null)),a);this.c=new U(new Xm(this),oo);this.e=new U(new Zm(this),oo);this.a=new U(new $m(this),oo);this.b=new U(new _m(this),oo)}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?co:od(b)?b==null?null:b.name:pd(b)?'String':ih(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.g;try{d=b.c.u();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;$(b.d)}}catch(a){a=Gg(a);if(ld(a,12)){c=a;if(!b.b){b.g=null;b.b=c;$(b.d)}throw Hg(c)}else throw Hg(a)}}
function si(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=pi(b,e);if(f){return f._(c)}}e[e.length]=new $h(b,c);++a.b;return null}
function pj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Bj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ch(a,c++)}b=b|0;return b}
function M(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=$c(je,Rn,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=Pn==(d&Pn)?c.u():c.u()}else{Ob(b,e);try{g=Pn==(d&Pn)?c.u():c.u()}finally{Pb()}}return g}catch(a){a=Gg(a);if(ld(a,4)){f=a;throw Hg(f)}else throw Hg(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=Pn==(d&Pn)?(c.a.A(),null):(c.a.A(),null)}else{Ob(b,e);try{g=Pn==(d&Pn)?(c.a.A(),null):(c.a.A(),null)}finally{Pb()}}return g}catch(a){a=Gg(a);if(ld(a,4)){f=a;throw Hg(f)}else throw Hg(a)}finally{D(b)}}
function Sb(a){var b;if(0==a.length){b=(bh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',ah.title,b)}else{(bh(),$wnd.window.window).location.hash=a}}
function ib(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.A()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=Gg(a);if(ld(a,4)){J()}else throw Hg(a)}}}
function ti(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(ni(b,e.Z())){if(d.length==1){d.length=0;wi(a.a,g)}else{d.splice(h,1)}--a.b;return e.$()}}return null}
function vn(a,b){var c;this.k=Pi(a);this.j=Pi(b);this.g=new pc;this.d=(c=new eb((J(),null)),c);this.b=new U(new xn(this),oo);this.c=new U(new yn(this),oo);this.e=u(new zn(this),413155328);this.a=u(new An(this),681590784);D((null,I))}
function Vg(a,b,c){var d=Sg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Sg[b]),Yg(h));_.vb=c;!b&&(_.wb=$g);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ub=f)}
function qh(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=rh('.',[c,rh('$',d)]);a.b=rh('.',[c,rh('.',d)]);a.i=d[d.length-1]}
function bc(){var a,b,c;this.f=new gc(this);this.c=new pc;this.b=(c=new eb((J(),null)),c);this.a=(b=new eb(null),b);dh((bh(),$wnd.window.window),Zn,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function Lh(a,b){var c,d,e;c=b.Z();e=b.$();d=pd(c)?c==null?Nh(ri(a.a,null)):Fi(a.b,c):Nh(ri(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!ri(a.a,null):Ei(a.b,c):!!ri(a.a,c))){return false}return true}
function ob(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ki(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Gg(a);if(!ld(a,4))throw Hg(a)}if(6==(b.c&7)){return true}}}}}kb(b);return false}
function Ai(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function nb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){db(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}bi(a.b,new ub(a));a.b.a=$c(je,Rn,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function wb(a){var b,c,d,e,f,g,h,i;d=P(a.d[0]);c=P(a.d[1]);g=P(a.d[2]);e=P(a.d[3]);f=P(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;L(a.d[0]);L(a.d[1]);L(a.d[2]);L(a.d[3]);L(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=O(b);h.c&=-513;ib(h);return true}
function zk(){zk=Wg;dk=new Ak(ho,0);ek=new Ak('checkbox',1);fk=new Ak('color',2);gk=new Ak('date',3);hk=new Ak('datetime',4);ik=new Ak('email',5);jk=new Ak('file',6);kk=new Ak('hidden',7);lk=new Ak('image',8);mk=new Ak('month',9);nk=new Ak(On,10);ok=new Ak('password',11);pk=new Ak('radio',12);qk=new Ak('range',13);rk=new Ak('reset',14);sk=new Ak('search',15);tk=new Ak('submit',16);uk=new Ak('tel',17);vk=new Ak('text',18);wk=new Ak('time',19);xk=new Ak('url',20);yk=new Ak('week',21)}
function Fb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ci(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&gi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Z(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&nb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ci(a.b,g);if(-1==k.e){k.e=0;Y(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ei(a.b,g)}e&&mb(a.e,a.b)}else{e&&mb(a.e,new ii)}if(V(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&Tn!=(b.e.c&Un)&&Jb(a,k)}}
function Ci(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[go]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ai()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[go]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Nn='object',On='number',Pn=16384,Qn={15:1},Rn={3:1,6:1},Sn={11:1},Tn=1048576,Un=1835008,Vn={8:1},Wn=67108864,Xn=4194304,Yn={30:1},Zn='hashchange',$n=142614528,_n='__noinit__',ao='__java$exception',bo={3:1,12:1,5:1,4:1},co='null',eo=17592186044416,fo={44:1},go='delete',ho='button',io='selected',jo=1478635520,ko={11:1,24:1},lo='input',mo='completed',no='header',oo=136421376,po='active';var _,Sg,Ng,Fg=-1;Tg();Vg(1,null,{},o);_.q=ro;_.r=function(){return this.ub};_.s=so;_.t=function(){var a;return ih(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.q(a)};_.hashCode=function(){return this.s()};_.toString=function(){return this.t()};var fd,gd,hd;Vg(52,1,{},jh);_.J=function(a){var b;b=new jh;b.e=4;a>1?(b.c=oh(this,a-1)):(b.c=this);return b};_.K=function(){hh(this);return this.b};_.L=function(){return ih(this)};_.M=function(){hh(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.t=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(hh(this),this.k)};_.e=0;_.g=0;var gh=1;var je=lh(1);var ae=lh(52);Vg(76,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var ud=lh(76);Vg(16,1,Qn,G);_.u=function(){return this.a.A(),null};var sd=lh(16);Vg(77,1,{},H);var td=lh(77);var I;Vg(22,1,{22:1},Q);_.b=0;_.c=false;_.d=0;var vd=lh(22);Vg(204,1,Sn);_.t=function(){var a;return ih(this.ub)+'@'+(a=r(this)>>>0,a.toString(16))};var xd=lh(204);Vg(21,204,Sn,U);_.v=function(){S(this)};_.w=qo;_.a=false;var wd=lh(21);Vg(17,204,{11:1,17:1},eb);_.v=function(){W(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=lh(17);Vg(116,1,Vn,fb);_.A=function(){X(this.a)};var yd=lh(116);Vg(19,204,{11:1,19:1},qb,rb);_.v=function(){gb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Dd=lh(19);Vg(117,1,Yn,sb);_.A=function(){R(this.a)};var Ad=lh(117);Vg(118,1,Vn,tb);_.A=function(){lb(this.a)};var Bd=lh(118);Vg(119,1,{},ub);_.B=function(a){jb(this.a,a)};var Cd=lh(119);Vg(121,1,{},zb);_.a=0;_.b=100;_.e=0;var Ed=lh(121);Vg(62,1,Sn,Bb);_.v=function(){Ab(this)};_.w=qo;_.a=false;var Fd=lh(62);Vg(135,1,{},Nb);_.t=function(){var a;return hh(Gd),Gd.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.a=0;var Cb;var Gd=lh(135);Vg(46,1,{46:1});_.e='';_.g='';_.i=true;_.j='';var Nd=lh(46);Vg(101,46,{11:1,46:1,24:1},bc);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new cc(this)),Wn,null)}};_.q=ro;_.C=zo;_.s=so;_.w=Ao;_.t=function(){var a;return hh(Ld),Ld.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.d=0;var Ld=lh(101);Vg(102,1,Vn,cc);_.A=function(){Xb(this.a)};var Hd=lh(102);Vg(103,1,Vn,dc);_.A=function(){Qb(this.a,this.b)};var Id=lh(103);Vg(104,1,Vn,ec);_.A=function(){Yb(this.a)};var Jd=lh(104);Vg(105,1,Vn,fc);_.A=function(){Tb(this.a)};var Kd=lh(105);Vg(78,1,{},gc);_.handleEvent=function(a){Rb(this.a,a)};var Md=lh(78);Vg(106,1,{});var Qd=lh(106);Vg(79,1,{},kc);_.B=function(a){ic(this.a,a)};var Od=lh(79);Vg(80,1,Vn,lc);_.A=function(){jc(this.a,this.b)};var Pd=lh(80);Vg(107,106,{});var Rd=lh(107);Vg(18,1,Sn,pc);_.v=function(){nc(this)};_.w=qo;_.a=false;var Sd=lh(18);Vg(4,1,{3:1,4:1});_.D=function(a){return new Error(a)};_.F=Jo;_.G=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=ih(this.ub),c==null?a:a+': '+c);rc(this,tc(this.D(b)));Vc(this)};_.t=function(){return sc(this,this.F())};_.e=_n;_.g=true;var ne=lh(4);Vg(12,4,{3:1,12:1,4:1});var de=lh(12);Vg(5,12,bo);var ke=lh(5);Vg(53,5,bo);var ge=lh(53);Vg(71,53,bo);var Wd=lh(71);Vg(40,71,{40:1,3:1,12:1,5:1,4:1},yc);_.F=function(){xc(this);return this.c};_.H=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Td=lh(40);var Ud=lh(0);Vg(190,1,{});var Vd=lh(190);var Ac=0,Bc=0,Cc=-1;Vg(100,190,{},Qc);var Mc;var Xd=lh(100);var Tc;Vg(201,1,{});var Zd=lh(201);Vg(72,201,{},Xc);var Yd=lh(72);var ah;Vg(69,1,{66:1});_.t=qo;var $d=lh(69);fd={3:1,67:1,32:1};var _d=lh(67);Vg(45,1,{3:1,45:1});var ie=lh(45);gd={3:1,32:1,45:1};var be=lh(200);Vg(36,1,{3:1,32:1,36:1});_.q=ro;_.s=so;_.t=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ce=lh(36);Vg(9,5,bo,uh,vh);var ee=lh(9);Vg(33,45,{3:1,32:1,33:1,45:1},wh);_.q=function(a){return ld(a,33)&&a.a==this.a};_.s=qo;_.t=function(){return ''+this.a};_.a=0;var fe=lh(33);var yh;Vg(258,1,{});Vg(74,53,bo,Bh);_.D=function(a){return new TypeError(a)};var he=lh(74);hd={3:1,66:1,32:1,2:1};var me=lh(2);Vg(70,69,{66:1},Hh);var le=lh(70);Vg(262,1,{});Vg(55,5,bo,Ih);var oe=lh(55);Vg(202,1,{43:1});_.P=wo;_.T=function(){return new Ti(this,0)};_.U=function(){return new bj(null,this.T())};_.R=function(a){throw Hg(new Ih('Add not supported on this collection'))};_.t=function(){var a,b,c;c=new Vi('[',']');for(b=this.Q();b.W();){a=b.X();Ui(c,a===this?'(this Collection)':a==null?co:Zg(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=lh(202);Vg(205,1,{188:1});_.q=function(a){var b,c,d;if(a===this){return true}if(!ld(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Wh((new Th(d)).a);c.b;){b=Vh(c);if(!Lh(this,b)){return false}}return true};_.s=function(){return li(new Th(this))};_.t=function(){var a,b,c;c=new Vi('{','}');for(b=new Wh((new Th(this)).a);b.b;){a=Vh(b);Ui(c,Mh(this,a.Z())+'='+Mh(this,a.$()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=lh(205);Vg(122,205,{188:1});var se=lh(122);Vg(206,202,{43:1,212:1});_.T=function(){return new Ti(this,1)};_.q=function(a){var b;if(a===this){return true}if(!ld(a,27)){return false}b=a;if(Rh(b.a)!=this.S()){return false}return Jh(this,b)};_.s=function(){return li(this)};var Be=lh(206);Vg(27,206,{27:1,43:1,212:1},Th);_.Q=function(){return new Wh(this.a)};_.S=uo;var re=lh(27);Vg(28,1,{},Wh);_.V=to;_.X=function(){return Vh(this)};_.W=vo;_.b=false;var qe=lh(28);Vg(203,202,{43:1,210:1});_.T=function(){return new Ti(this,16)};_.Y=function(a,b){throw Hg(new Ih('Add not supported on this list'))};_.R=function(a){this.Y(this.S(),a);return true};_.q=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.S()!=f.a.length){return false}e=new ki(f);for(c=new ki(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.s=function(){return mi(this)};_.Q=function(){return new Xh(this)};var ue=lh(203);Vg(98,1,{},Xh);_.V=to;_.W=function(){return this.a<this.b.a.length};_.X=function(){return ci(this.b,this.a++)};_.a=0;var te=lh(98);Vg(48,202,{43:1},Yh);_.Q=function(){var a;return a=new Wh((new Th(this.a)).a),new Zh(a)};_.S=uo;var we=lh(48);Vg(57,1,{},Zh);_.V=to;_.W=function(){return this.a.b};_.X=function(){var a;return a=Vh(this.a),a.$()};var ve=lh(57);Vg(123,1,fo);_.q=function(a){var b;if(!ld(a,44)){return false}b=a;return ni(this.a,b.Z())&&ni(this.b,b.$())};_.Z=qo;_.$=vo;_.s=function(){return Oi(this.a)^Oi(this.b)};_._=function(a){var b;b=this.b;this.b=a;return b};_.t=function(){return this.a+'='+this.b};var xe=lh(123);Vg(124,123,fo,$h);var ye=lh(124);Vg(207,1,fo);_.q=function(a){var b;if(!ld(a,44)){return false}b=a;return ni(this.b.value[0],b.Z())&&ni(Ki(this),b.$())};_.s=function(){return Oi(this.b.value[0])^Oi(Ki(this))};_.t=function(){return this.b.value[0]+'='+Ki(this)};var ze=lh(207);Vg(14,203,{3:1,14:1,43:1,210:1},ii,ji);_.Y=function(a,b){qj(this.a,a,b)};_.R=function(a){return ai(this,a)};_.P=function(a){bi(this,a)};_.Q=function(){return new ki(this)};_.S=function(){return this.a.length};var De=lh(14);Vg(20,1,{},ki);_.V=to;_.W=function(){return this.a<this.c.a.length};_.X=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=lh(20);Vg(41,122,{3:1,41:1,188:1},oi);var Ee=lh(41);Vg(60,1,{},ui);_.P=wo;_.Q=function(){return new vi(this)};_.b=0;var Ge=lh(60);Vg(61,1,{},vi);_.V=to;_.X=function(){return this.d=this.a[this.c++],this.d};_.W=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=lh(61);var yi;Vg(58,1,{},Ii);_.P=wo;_.Q=function(){return new Ji(this)};_.b=0;_.c=0;var Je=lh(58);Vg(59,1,{},Ji);_.V=to;_.X=function(){return this.c=this.a,this.a=this.b.next(),new Li(this.d,this.c,this.d.c)};_.W=function(){return !this.a.done};var He=lh(59);Vg(134,207,fo,Li);_.Z=function(){return this.b.value[0]};_.$=function(){return Ki(this)};_._=function(a){return Gi(this.a,this.b.value[0],a)};_.c=0;var Ie=lh(134);Vg(99,1,{});_.V=function(a){Qi(this,a)};_.ab=function(){return this.d};_.bb=Fo;_.d=0;_.e=0;var Le=lh(99);Vg(56,99,{});var Ke=lh(56);Vg(26,1,{},Ti);_.ab=qo;_.bb=function(){Si(this);return this.c};_.V=function(a){Si(this);this.d.V(a)};_.cb=function(a){Si(this);if(this.d.W()){a.B(this.d.X());return true}return false};_.a=0;_.c=0;var Me=lh(26);Vg(54,1,{},Vi);_.t=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ne=lh(54);var We=nh();Vg(125,1,{});_.c=false;var Xe=lh(125);Vg(35,125,{},bj);var Ve=lh(35);Vg(127,56,{},fj);_.cb=function(a){this.b=false;while(!this.b&&this.c.cb(new gj(this,a)));return this.b};_.b=false;var Pe=lh(127);Vg(130,1,{},gj);_.B=function(a){ej(this.a,this.b,a)};var Oe=lh(130);Vg(126,56,{},ij);_.cb=function(a){return this.a.cb(new jj(a))};var Re=lh(126);Vg(129,1,{},jj);_.B=function(a){hj(this.a,a)};var Qe=lh(129);Vg(128,1,{},lj);_.B=function(a){kj(this,a)};var Se=lh(128);Vg(131,1,{},mj);_.B=function(a){};var Te=lh(131);Vg(132,1,{},oj);_.B=function(a){nj(this,a)};var Ue=lh(132);Vg(260,1,{});Vg(209,1,{});var Ye=lh(209);Vg(257,1,{});var vj=0;var xj,yj=0,zj;Vg(684,1,{});Vg(708,1,{});Vg(208,1,{});_.eb=xo;_.fb=xo;_.hb=function(a,b,c){return false};_.p=false;var Ze=lh(208);Vg(34,$wnd.React.Component,{});Ug(Sg[1],_);_.render=function(){return Oj(this.a)};var $e=lh(34);Vg(38,208,{});_.kb=function(){return false};_.mb=function(){return Pj(this)};_.k=false;_.n=false;var Jj=1,Kj;var _e=lh(38);Vg(229,$wnd.Function,{},Qj);_.I=function(a){return Ab(Kj),Kj=null,null};Vg(10,36,{3:1,32:1,36:1,10:1},Ak);var dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk;var af=mh(10,Bk);Vg(156,38,{});_.rb=yo;_.gb=function(){var a;a=T((zm(),ym).b);return $wnd.React.createElement('footer',Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,['footer'])),Tl(new Ul),$wnd.React.createElement('ul',Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Tj(Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,[(En(),Cn)==a?io:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Tj(Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,[Bn==a?io:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Tj(Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,[Dn==a?io:null])),'#completed'),'Completed'))),this.rb()?$wnd.React.createElement(ho,Uj(Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,['clear-completed'])),Xg(Ql.prototype.qb,Ql,[])),'Clear Completed'):null)};var Kf=lh(156);Vg(157,156,{});_.rb=yo;var Ck;var Of=lh(157);Vg(158,157,ko,Fk);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Jk(this)),Wn,null)}};_.q=ro;_.lb=Bo;_.C=zo;_.rb=function(){return T(this.a)};_.s=so;_.w=Ao;_.t=function(){var a;return hh(kf),kf.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.mb=function(){var b;try{return B((J(),J(),I),this.b,new Hk(this))}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.d=0;var kf=lh(158);Vg(159,1,Qn,Gk);_.u=function(){return fh(),T((zm(),wm).b).a>0?true:false};var bf=lh(159);Vg(162,1,Qn,Hk);_.u=Do;var cf=lh(162);Vg(160,1,Yn,Ik);_.A=Co;var df=lh(160);Vg(161,1,Vn,Jk);_.A=function(){Ek(this.a)};var ef=lh(161);Vg(181,38,{});_.gb=function(){var a,b;b=T((zm(),wm).e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,['todo-count'])),$wnd.React.createElement('strong',null,b),' '+a+' left')};var Jf=lh(181);Vg(182,181,{});var Kk;var Nf=lh(182);Vg(183,182,ko,Nk);_.v=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Pk(this)),Wn,null)}};_.q=ro;_.lb=Bo;_.C=vo;_.s=so;_.w=Go;_.t=function(){var a;return hh(jf),jf.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.mb=function(){var b;try{return B((J(),J(),I),this.a,new Qk(this))}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.c=0;var jf=lh(183);Vg(184,1,Yn,Ok);_.A=Co;var ff=lh(184);Vg(185,1,Vn,Pk);_.A=function(){Mk(this.a)};var gf=lh(185);Vg(186,1,Qn,Qk);_.u=Do;var hf=lh(186);Vg(148,38,{});_.gb=function(){return $wnd.React.createElement(lo,Vj(Zj($j(bk(_j(Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,['new-todo']))),(bb(this.b),this.e)),Xg(dm.prototype.pb,dm,[this])),Xg(em.prototype.ob,em,[this]))))};_.e='';var Wf=lh(148);Vg(149,148,{});var Tk;var Qf=lh(149);Vg(150,149,ko,$k);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new dl(this)),Wn,null)}};_.q=ro;_.lb=Bo;_.C=zo;_.s=so;_.w=Ao;_.t=function(){var a;return hh(qf),qf.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.mb=function(){var b;try{return B((J(),J(),I),this.a,new _k(this))}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.d=0;var qf=lh(150);Vg(153,1,Qn,_k);_.u=Do;var lf=lh(153);Vg(154,1,Vn,al);_.A=function(){Rk(this.a)};var mf=lh(154);Vg(155,1,Vn,bl);_.A=function(){Xk(this.a,this.b)};var nf=lh(155);Vg(151,1,Yn,cl);_.A=Co;var of=lh(151);Vg(152,1,Vn,dl);_.A=function(){Yk(this.a)};var pf=lh(152);Vg(165,38,{});_.eb=function(){el(this)};_.tb=Eo;_.fb=function(){vl(this,this.sb())};_.gb=function(){var a,b;b=this.sb();a=(bb(b.a),b.g);return $wnd.React.createElement('li',Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,[a?mo:null,this.tb()?'editing':null])),$wnd.React.createElement('div',Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,['view'])),$wnd.React.createElement(lo,Zj(Wj(ak(Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,['toggle'])),(zk(),ek)),a),Xg(im.prototype.ob,im,[b]))),$wnd.React.createElement('label',ck(new $wnd.Object,Xg(jm.prototype.qb,jm,[this,b])),(bb(b.b),b.i)),$wnd.React.createElement(ho,Uj(Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,['destroy'])),Xg(km.prototype.qb,km,[b])))),$wnd.React.createElement(lo,$j(Zj(Yj(Xj(Rj(Sj(new $wnd.Object,Xg(lm.prototype.B,lm,[this])),cd(Yc(me,1),Rn,2,6,['edit'])),(bb(this.a),this.i)),Xg(mm.prototype.nb,mm,[this,b])),Xg(hm.prototype.ob,hm,[this])),Xg(nm.prototype.pb,nm,[this,b]))))};_.j=false;var Yf=lh(165);Vg(166,165,{});_.kb=function(){var a;a=(cb(this.c),this.o.props['a']);if(!!a&&a.f<0){return true}return false};_.sb=function(){return this.o.props['a']};_.tb=Eo;_.hb=function(a,b,c){return nl(this,a,b,c)};var ll;var Sf=lh(166);Vg(167,166,ko,xl);_.eb=function(){var b;try{A((J(),J(),I),new Al(this),$n)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.v=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new yl(this)),Wn,null)}};_.q=ro;_.lb=Bo;_.C=Fo;_.sb=function(){return cb(this.c),this.o.props['a']};_.s=so;_.w=Io;_.tb=function(){return T(this.d)};_.hb=function(b,c,d){var e;try{return t((J(),J(),I),new Bl(this,b,c,d),75505664,null)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){e=a;throw Hg(e)}else if(ld(a,4)){e=a;throw Hg(new vh(e))}else throw Hg(a)}};_.t=function(){var a;return hh(Cf),Cf.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.mb=function(){var b;try{return B((J(),J(),I),this.b,new zl(this))}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.f=0;var Cf=lh(167);Vg(170,1,Vn,yl);_.A=function(){pl(this.a)};var rf=lh(170);Vg(171,1,Qn,zl);_.u=Do;var sf=lh(171);Vg(172,1,Vn,Al);_.A=function(){el(this.a)};var tf=lh(172);Vg(173,1,Qn,Bl);_.u=function(){return ql(this.a,this.d,this.c,this.b)};_.b=false;var uf=lh(173);Vg(174,1,Vn,Cl);_.A=function(){wl(this.a,Dm(this.b))};var vf=lh(174);Vg(175,1,Vn,Dl);_.A=function(){jl(this.a,this.b)};var wf=lh(175);Vg(176,1,Vn,El);_.A=function(){il(this.a,this.b)};var xf=lh(176);Vg(168,1,Qn,Fl);_.u=function(){return rl(this.a)};var yf=lh(168);Vg(177,1,Vn,Gl);_.A=function(){vl(this.a,this.b);un((zm(),ym),null)};var zf=lh(177);Vg(178,1,Vn,Hl);_.A=function(){fl(this.a,this.b)};var Af=lh(178);Vg(169,1,Yn,Il);_.A=Co;var Bf=lh(169);Vg(136,38,{});_.gb=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(no,Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,[no])),$wnd.React.createElement('h1',null,'todos'),fm(new gm)),T((zm(),wm).c)?null:$wnd.React.createElement('section',Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,[no])),$wnd.React.createElement(lo,Zj(ak(Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,['toggle-all'])),(zk(),ek)),Xg(sm.prototype.ob,sm,[]))),$wnd.React.createElement.apply(null,['ul',Rj(new $wnd.Object,cd(Yc(me,1),Rn,2,6,['todo-list']))].concat((a=aj(_i(T(ym.c).U()),(b=new ii,b)),hi(a,bd(a.a.length)))))),T(wm.c)?null:Rl(new Sl)))};var $f=lh(136);Vg(137,136,{});var Jl;var Uf=lh(137);Vg(138,137,ko,Ml);_.v=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Ol(this)),Wn,null)}};_.q=ro;_.lb=Bo;_.C=vo;_.s=so;_.w=Go;_.t=function(){var a;return hh(Gf),Gf.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.mb=function(){var b;try{return B((J(),J(),I),this.a,new Pl(this))}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.c=0;var Gf=lh(138);Vg(139,1,Yn,Nl);_.A=Co;var Df=lh(139);Vg(140,1,Vn,Ol);_.A=function(){Mk(this.a)};var Ef=lh(140);Vg(141,1,Qn,Pl);_.u=Do;var Ff=lh(141);Vg(234,$wnd.Function,{},Ql);_.qb=function(a){cn((zm(),xm))};Vg(143,1,{},Sl);var Hf=lh(143);Vg(163,1,{},Ul);var If=lh(163);Vg(233,$wnd.Function,{},Vl);_.ib=function(a){return new Wl(a)};Vg(145,34,{},Wl);_.jb=function(){return new Fk};_.componentWillUnmount=Ho;var Lf=lh(145);Vg(244,$wnd.Function,{},Xl);_.ib=function(a){return new Yl(a)};Vg(164,34,{},Yl);_.jb=function(){return new Nk};_.componentWillUnmount=Ho;var Mf=lh(164);Vg(230,$wnd.Function,{},Zl);_.ib=function(a){return new $l(a)};Vg(144,34,{},$l);_.jb=function(){return new $k};_.componentWillUnmount=Ho;var Pf=lh(144);Vg(235,$wnd.Function,{},_l);_.ib=function(a){return new am(a)};Vg(147,34,{},am);_.jb=function(){return new xl};_.componentDidUpdate=function(a){Fj(this.a,a)};_.componentWillUnmount=Ho;_.shouldComponentUpdate=function(a){return Gj(this.a,a)};var Rf=lh(147);Vg(227,$wnd.Function,{},bm);_.ib=function(a){return new cm(a)};Vg(120,34,{},cm);_.jb=function(){return new Ml};_.componentWillUnmount=Ho;var Tf=lh(120);Vg(231,$wnd.Function,{},dm);_.pb=function(a){Sk(this.a,a)};Vg(232,$wnd.Function,{},em);_.ob=function(a){Wk(this.a,a)};Vg(142,1,{},gm);var Vf=lh(142);Vg(242,$wnd.Function,{},hm);_.ob=function(a){ol(this.a,a)};Vg(236,$wnd.Function,{},im);_.ob=function(a){Jm(this.a)};Vg(238,$wnd.Function,{},jm);_.qb=function(a){tl(this.a,this.b)};Vg(239,$wnd.Function,{},km);_.qb=function(a){kl(this.a)};Vg(240,$wnd.Function,{},lm);_.B=function(a){gl(this.a,a)};Vg(241,$wnd.Function,{},mm);_.nb=function(a){ul(this.a,this.b)};Vg(243,$wnd.Function,{},nm);_.pb=function(a){hl(this.a,this.b,a)};Vg(146,1,{},rm);var Xf=lh(146);Vg(228,$wnd.Function,{},sm);_.ob=function(a){var b;b=a.target;gn((zm(),xm),b.checked)};Vg(65,1,{},um);var Zf=lh(65);var vm,wm,xm,ym;Vg(49,1,{49:1});_.g=false;var Cg=lh(49);Vg(50,49,{11:1,24:1,50:1,49:1},Km);_.v=function(){Bm(this)};_.q=function(a){return Cm(this,a)};_.C=zo;_.s=Fo;_.w=Io;_.t=function(){var a;return hh(og),og.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var Am=0;var og=lh(50);Vg(179,1,Vn,Lm);_.A=function(){Fm(this.a)};var _f=lh(179);Vg(180,1,Vn,Mm);_.A=function(){Gm(this.a)};var ag=lh(180);Vg(47,107,{47:1});var xg=lh(47);Vg(108,47,{11:1,24:1,47:1},Um);_.v=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new Vm(this)),Wn,null)}};_.q=ro;_.C=Jo;_.s=so;_.w=function(){return this.g<0};_.t=function(){var a;return hh(ig),ig.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.g=0;var ig=lh(108);Vg(113,1,Vn,Vm);_.A=function(){Rm(this.a)};var bg=lh(113);Vg(114,1,Vn,Wm);_.A=function(){hc(this.a,this.b,true)};var cg=lh(114);Vg(109,1,Qn,Xm);_.u=function(){return Sm(this.a)};var dg=lh(109);Vg(115,1,Qn,Ym);_.u=function(){return Nm(this.a,this.c,this.b)};_.b=false;var eg=lh(115);Vg(110,1,Qn,Zm);_.u=function(){return xh(Mg(Zi(Qm(this.a))))};var fg=lh(110);Vg(111,1,Qn,$m);_.u=function(){return xh(Mg(Zi($i(Qm(this.a),new Hn))))};var gg=lh(111);Vg(112,1,Qn,_m);_.u=function(){return Tm(this.a)};var hg=lh(112);Vg(85,1,{});var Bg=lh(85);Vg(86,85,ko,hn);_.v=function(){if(this.b>=0){this.b=-2;t((J(),J(),I),new G(new ln(this)),Wn,null)}};_.q=ro;_.C=qo;_.s=so;_.w=function(){return this.b<0};_.t=function(){var a;return hh(ng),ng.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.b=0;var ng=lh(86);Vg(89,1,Vn,jn);_.A=function(){Im(this.b,this.a)};var jg=lh(89);Vg(90,1,Vn,kn);_.A=function(){dn(this.a)};var kg=lh(90);Vg(87,1,Vn,ln);_.A=function(){nc(this.a.a)};var lg=lh(87);Vg(88,1,Vn,mn);_.A=function(){en(this.a,this.b)};_.b=false;var mg=lh(88);Vg(91,1,{});var Eg=lh(91);Vg(92,91,ko,vn);_.v=function(){if(this.i>=0){this.i=-2;t((J(),J(),I),new G(new wn(this)),Wn,null)}};_.q=ro;_.C=function(){return this.g};_.s=so;_.w=function(){return this.i<0};_.t=function(){var a;return hh(ug),ug.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.i=0;var ug=lh(92);Vg(97,1,Vn,wn);_.A=function(){qn(this.a)};var pg=lh(97);Vg(93,1,Qn,xn);_.u=function(){var a;return a=Wb(this.a.j),Dh(po,a)||Dh(mo,a)||Dh('',a)?Dh(po,a)?(En(),Bn):Dh(mo,a)?(En(),Dn):(En(),Cn):(En(),Cn)};var qg=lh(93);Vg(94,1,Qn,yn);_.u=function(){return rn(this.a)};var rg=lh(94);Vg(95,1,Yn,zn);_.A=function(){sn(this.a)};var sg=lh(95);Vg(96,1,Yn,An);_.A=function(){tn(this.a)};var tg=lh(96);Vg(37,36,{3:1,32:1,36:1,37:1},Fn);var Bn,Cn,Dn;var vg=mh(37,Gn);Vg(81,1,{},Hn);_.db=function(a){return !Em(a)};var wg=lh(81);Vg(83,1,{},In);_.db=function(a){return Em(a)};var yg=lh(83);Vg(84,1,{},Jn);_.B=function(a){Pm(this.a,a)};var zg=lh(84);Vg(82,1,{},Kn);_.B=function(a){bn(this.a,a)};_.a=false;var Ag=lh(82);Vg(73,1,{},Ln);_.db=function(a){return on(this.a,a)};var Dg=lh(73);var Mn=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=Qg;Og(_g);Rg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();