function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='C5D782E145970881A77C0953054BF04C',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'C5D782E145970881A77C0953054BF04C';function o(){}
function eh(){}
function _g(){}
function Ib(){}
function Mc(){}
function Tc(){}
function ij(){}
function jj(){}
function Nj(){}
function Gk(){}
function Sl(){}
function Vl(){}
function Zl(){}
function bm(){}
function fm(){}
function jm(){}
function Bm(){}
function $m(){}
function Ln(){}
function jo(){}
function ko(){}
function ip(){}
function Rc(a){Qc()}
function kh(){kh=_g}
function hi(){$h(this)}
function hc(a){this.a=a}
function nc(a){this.a=a}
function G(a){this.a=a}
function H(a){this.a=a}
function mb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function Dk(a){this.a=a}
function Ek(a){this.a=a}
function Fk(a){this.a=a}
function Hk(a){this.a=a}
function Mk(a){this.a=a}
function Nk(a){this.a=a}
function Ok(a){this.a=a}
function Pk(a){this.a=a}
function Zk(a){this.a=a}
function $k(a){this.a=a}
function _k(a){this.a=a}
function zh(a){this.a=a}
function Sh(a){this.a=a}
function Xh(a){this.a=a}
function Yh(a){this.a=a}
function Wh(a){this.b=a}
function ji(a){this.c=a}
function gj(a){this.a=a}
function lj(a){this.a=a}
function al(a){this.a=a}
function cl(a){this.a=a}
function zl(a){this.a=a}
function Al(a){this.a=a}
function Bl(a){this.a=a}
function Hl(a){this.a=a}
function Jl(a){this.a=a}
function Kl(a){this.a=a}
function Ol(a){this.a=a}
function Pl(a){this.a=a}
function Ql(a){this.a=a}
function Rl(a){this.a=a}
function nm(a){this.a=a}
function om(a){this.a=a}
function qm(a){this.a=a}
function rm(a){this.a=a}
function tm(a){this.a=a}
function um(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function Wm(a){this.a=a}
function Ym(a){this.a=a}
function Zm(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function zn(a){this.a=a}
function An(a){this.a=a}
function Bn(a){this.a=a}
function Cn(a){this.a=a}
function On(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function hj(a,b){a.a=b}
function Hj(a,b){a.key=b}
function Cj(a,b){Bj(a,b)}
function En(a,b){fn(b,a)}
function Wo(a){Li(this,a)}
function $o(a){Dh(this,a)}
function cp(){jc(this.c)}
function dp(){jc(this.b)}
function ti(){this.a=Ci()}
function Hi(){this.a=Ci()}
function kc(a){!!a&&a.t()}
function w(a){--a.e;D(a)}
function gb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function kb(a){Yb((J(),a))}
function kj(a,b){aj(a.a,b)}
function cc(a,b){Oh(a.b,b)}
function Dn(a,b){on(a.b,b)}
function C(a,b){ab(a.f,b.f)}
function tb(a,b){a.b=Oi(b)}
function Lb(a){a.a=-4&a.a|1}
function Mg(a){return a.b}
function Zo(){return this.b}
function Yo(){return this.a}
function ep(){nb(this.a.a)}
function fp(){jc(this.a.c)}
function gp(){jc(this.a.b)}
function ap(){this.a.k=true}
function dc(){this.b=new ni}
function J(){J=_g;I=new F}
function Jc(){Jc=_g;Ic=new Mc}
function tc(){tc=_g;sc=new o}
function yi(){yi=_g;xi=Ai()}
function V(a){gd(a,8)&&a.s()}
function Bk(a){nb(a.b);R(a.a)}
function Uk(a){nb(a.a);cb(a.b)}
function Nm(a){R(a.a);cb(a.b)}
function pj(a,b){a.splice(b,1)}
function ac(a,b,c){Nh(a.b,b,c)}
function Gh(a,b){return a===b}
function el(a,b){return a.f=b}
function bi(a,b){return a.a[b]}
function Vo(){return tj(this)}
function hp(){return this.c.c}
function Uo(a){return this===a}
function _o(){return J(),J(),I}
function kl(a){pn((Gm(),Dm),a)}
function Yl(a){Dj.call(this,a)}
function am(a){Dj.call(this,a)}
function em(a){Dj.call(this,a)}
function im(a){Dj.call(this,a)}
function mm(a){Dj.call(this,a)}
function Ih(a){rc.call(this,a)}
function Xo(){return Qh(this.a)}
function Uc(a,b){return sh(a,b)}
function nh(a){mh(a);return a.k}
function _i(a,b){a.M(b);return a}
function Ci(){yi();return new xi}
function db(a){J();Xb(a);a.e=-2}
function an(a){cb(a.b);cb(a.a)}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function aj(a,b){hj(a,_i(a.a,b))}
function Pi(a,b){while(a.Z(b));}
function v(a,b,c){s(a,new H(c),b)}
function bp(){Lj(this.a,false)}
function Eh(){oc(this);this.A()}
function ic(a,b){this.a=a;this.b=b}
function Qh(a){return a.a.b+a.b.b}
function W(a){return !!a&&a.c.i<0}
function Zc(a){return new Array(a)}
function Ei(a,b){return a.a.get(b)}
function Pm(a){ib(a.b);return a.e}
function dn(a){ib(a.a);return a.d}
function Sn(a){ib(a.d);return a.f}
function Pj(a,b){a.ref=b;return a}
function Qj(a,b){a.href=b;return a}
function dj(a,b){this.a=a;this.b=b}
function Gj(a,b){this.a=a;this.b=b}
function xh(a,b){this.a=a;this.b=b}
function Zh(a,b){this.a=a;this.b=b}
function bl(a,b){this.a=a;this.b=b}
function Cl(a,b){this.a=a;this.b=b}
function Dl(a,b){this.a=a;this.b=b}
function El(a,b){this.a=a;this.b=b}
function Fl(a,b){this.a=a;this.b=b}
function Gl(a,b){this.a=a;this.b=b}
function Il(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function wm(a,b){this.a=a;this.b=b}
function xk(a,b){xh.call(this,a,b)}
function nj(a,b,c){a.splice(b,0,c)}
function zc(){zc=_g;!!(Qc(),Pc)}
function Hc(){wc!=0&&(wc=0);yc=-1}
function Ug(){Sg==null&&(Sg=[])}
function Ul(){this.a=Ij((_l(),$l))}
function Tl(){this.a=Ij((Xl(),Wl))}
function pm(){this.a=Ij((dm(),cm))}
function Am(){this.a=Ij((hm(),gm))}
function Cm(){this.a=Ij((lm(),km))}
function Qm(a){Om(a,(ib(a.b),a.e))}
function xm(a){return ym(new Am,a)}
function Mh(a){return !a?null:a.V()}
function ld(a){return a==null?null:a}
function jd(a){return typeof a===po}
function Sb(a){return !a.d?a:Sb(a.d)}
function en(a){fn(a,(ib(a.a),!a.d))}
function xn(a,b){this.a=a;this.b=b}
function Mn(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function Nn(a,b){this.b=a;this.a=b}
function ho(a,b){xh.call(this,a,b)}
function $j(a,b){a.value=b;return a}
function Vj(a,b){a.onBlur=b;return a}
function Rj(a,b){a.onClick=b;return a}
function Tj(a,b){a.checked=b;return a}
function ej(a,b){a.u(zm(xm(b.c.e),b))}
function oj(a,b){mj(b,0,a,0,b.length)}
function A(a,b,c){t(a,new G(b),c,null)}
function B(a,b,c){return t(a,c,2048,b)}
function Ni(a){return a!=null?r(a):0}
function Gc(a){$wnd.clearTimeout(a)}
function $h(a){a.a=Wc(be,ro,1,0,5,1)}
function P(){this.a=Wc(be,ro,1,100,5,1)}
function Gb(a){this.d=Oi(a);this.b=100}
function lb(a){this.c=new hi;this.b=a}
function Ph(a){a.a=new ti;a.b=new Hi}
function xj(){xj=_g;uj=new o;wj=new o}
function Wj(a,b){a.onChange=b;return a}
function Xj(a,b){a.onKeyDown=b;return a}
function Bj(a,b){for(var c in a){b(c)}}
function gc(a,b){ec(a,b,false);hb(a.d)}
function gd(a,b){return a!=null&&ed(a,b)}
function Fh(a,b){return a.charCodeAt(b)}
function _c(a,b,c){return {l:a,m:b,h:c}}
function X(a){return !(!!a&&1==(a.c&7))}
function tj(a){return a.$H||(a.$H=++sj)}
function kd(a){return typeof a==='string'}
function hd(a){return typeof a==='boolean'}
function ib(a){var b;Tb((J(),b=Ob,b),a)}
function sb(a){J();rb(a);vb(a,2,true)}
function T(a){4==(a.f.c&7)&&vb(a.f,5,true)}
function Jb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function rc(a){this.c=a;oc(this);this.A()}
function $i(a,b){Vi.call(this,a);this.a=b}
function Li(a,b){while(a.R()){kj(b,a.S())}}
function pc(a,b){a.b=b;b!=null&&rj(b,zo,a)}
function mh(a){if(a.k!=null){return}uh(a)}
function Sj(a){a.autoFocus=true;return a}
function Uj(a,b){a.defaultValue=b;return a}
function ym(a,b){return Hj(a.a,Oi(''+b)),a}
function u(a,b){return new yb(Oi(a),null,b)}
function vi(a,b){var c;c=a[Do];c.call(a,b)}
function rj(b,c,d){try{b[c]=d}catch(a){}}
function $(a,b,c){Lb(Oi(c));K(a.a[b],Oi(c))}
function fc(a,b){cc(b.v(),a);gd(b,8)&&b.s()}
function ll(a){A((J(),J(),I),new Hl(a),Lo)}
function Rm(a){A((J(),J(),I),new Ym(a),Lo)}
function hn(a){A((J(),J(),I),new ln(a),Lo)}
function Fn(a){A((J(),J(),I),new On(a),Lo)}
function Un(a){W((ib(a.d),a.f))&&Wn(a,null)}
function tn(a){return Ah(S(a.e).a-S(a.a).a)}
function Ac(a,b,c){return a.apply(b,c);var d}
function _j(a,b){a.onDoubleClick=b;return a}
function zm(a,b){a.a.props['a']=b;return a.a}
function oc(a){a.d&&a.b!==yo&&a.A();return a}
function qh(a){var b;b=ph(a);wh(a,b);return b}
function pl(a){nb(a.b);R(a.d);cb(a.c);cb(a.a)}
function rl(a,b){A((J(),J(),I),new Gl(a,b),Lo)}
function ul(a,b){A((J(),J(),I),new El(a,b),Lo)}
function vl(a,b){A((J(),J(),I),new Dl(a,b),Lo)}
function wl(a,b){A((J(),J(),I),new Cl(a,b),Lo)}
function Vk(a,b){A((J(),J(),I),new bl(a,b),Lo)}
function pn(a,b){A((J(),J(),I),new xn(a,b),Lo)}
function In(a,b){A((J(),J(),I),new Nn(a,b),Lo)}
function Jn(a,b){A((J(),J(),I),new Mn(a,b),Lo)}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function Wk(a,b){var c;c=b.target;Xk(a,c.value)}
function yn(a,b){this.a=a;this.c=b;this.b=false}
function Ki(a,b,c){this.a=a;this.b=b;this.c=c}
function ni(){this.a=new ti;this.b=new Hi}
function F(){this.f=new bb;this.a=new Gb(this.f)}
function Qc(){Qc=_g;var a;!Sc();a=new Tc;Pc=a}
function hh(){hh=_g;gh=$wnd.window.document}
function Ch(){Ch=_g;Bh=Wc(Zd,ro,29,256,0,1)}
function Fb(a){while(true){if(!Eb(a)){break}}}
function rn(a){Dh(new Xh(a.g),new hc(a));Ph(a.g)}
function Yi(a){Ui(a);return new $i(a,new fj(a.a))}
function sl(a,b){return kh(),ml(a,b)?true:false}
function sn(a){return kh(),0==S(a.e).a?true:false}
function Yc(a){return Array.isArray(a)&&a.mb===eh}
function fd(a){return !Array.isArray(a)&&a.mb===eh}
function Di(a,b){return !(a.a.get(b)===undefined)}
function _h(a,b){a.a[a.a.length]=b;return true}
function Nc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function di(a,b){var c;c=a.a[b];pj(a.a,b);return c}
function fi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Uh(a){var b;b=a.a.S();a.b=Th(a);return b}
function bj(a,b,c){if(a.a.$(c)){a.b=true;b.u(c)}}
function Hb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Ri(a){if(!a.d){a.d=a.b.L();a.c=a.b.N()}}
function Ti(a){if(!a.b){Ui(a);a.c=true}else{Ti(a.b)}}
function nn(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function Xk(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.b)}}
function xl(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function qb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Pn(a){return Gh(To,a)||Gh(No,a)||Gh('',a)}
function fj(a){Qi.call(this,a.Y(),a.X()&-6);this.a=a}
function Oi(a){if(a==null){throw Mg(new Eh)}return a}
function Rh(a,b){if(b){return Lh(a.a,b)}return false}
function Rg(a){if(jd(a)){return a|0}return a.l|a.m<<22}
function Xi(a,b){Ui(a);return new $i(a,new cj(b,a.a))}
function Om(a,b){A((J(),J(),I),new Xm(a,b),75497472)}
function Rn(a){nb(a.e);nb(a.a);R(a.b);R(a.c);cb(a.d)}
function Mm(a){var b;T(a.a);b=S(a.a);Gh(a.f,b)&&Sm(a,b)}
function Sm(a,b){var c;c=a.e;if(b!=c){a.e=Oi(b);hb(a.b)}}
function fn(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function rh(a,b){var c;c=ph(a);wh(a,c);c.e=b?8:0;return c}
function Jk(a){var b;a.j=false;Mj(a);b=Ik();return b}
function Zj(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Qi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Si(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Vi(a){if(!a){this.b=null;new hi}else{this.b=a}}
function Aj(){if(vj==256){uj=wj;wj=new o;vj=0}++vj}
function Gm(){Gm=_g;Dm=new un;Em=new Kn(Dm);Fm=new Xn(Dm)}
function Im(a){ih((hh(),$wnd.window.window),Qo,a.d,false)}
function Jm(a){jh((hh(),$wnd.window.window),Qo,a.d,false)}
function Fc(a){zc();$wnd.setTimeout(function(){throw a},0)}
function lc(a){kc(a.g);V(a.c);V(a.a);V(a.d);kc(a.b);kc(a.f)}
function Pb(a){if(a.e){2==(a.e.c&7)||vb(a.e,4,true);rb(a.e)}}
function th(a){if(a.J()){return null}var b=a.j;return Xg[b]}
function mi(a,b){return ld(a)===ld(b)||a!=null&&p(a,b)}
function on(a,b){return t((J(),J(),I),new yn(a,b),Lo,null)}
function ob(a){C((J(),J(),I),a);0==(a.f.a&vo)&&D((null,I))}
function jb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function dl(a,b){var c;if(S(a.d)){c=b.target;xl(a,c.value)}}
function Gn(a,b){var c;Zi(qn(a.b),(c=new hi,c)).K(new mo(b))}
function Dh(a,b){var c,d;for(d=a.L();d.R();){c=d.S();b.u(c)}}
function sh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.D(b))}
function pi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function bh(a){function b(){}
;b.prototype=a||{};return new b}
function Yj(a){a.placeholder='What needs to be done?';return a}
function Km(a,b){b.preventDefault();A((J(),J(),I),new Zm(a),Lo)}
function gl(a,b){Wn((Gm(),Fm),b);A((J(),J(),I),new Cl(a,b),Lo)}
function io(){go();return $c(Uc(Ag,1),ro,33,0,[co,fo,eo])}
function hm(){hm=_g;var a;gm=(a=ah(fm.prototype.cb,fm,[]),a)}
function dm(){dm=_g;var a;cm=(a=ah(bm.prototype.cb,bm,[]),a)}
function lm(){lm=_g;var a;km=(a=ah(jm.prototype.cb,jm,[]),a)}
function Xl(){Xl=_g;var a;Wl=(a=ah(Vl.prototype.cb,Vl,[]),a)}
function _l(){_l=_g;var a;$l=(a=ah(Zl.prototype.cb,Zl,[]),a)}
function ii(a){$h(this);oj(this.a,Kh(a,Wc(be,ro,1,Qh(a.a),5,1)))}
function ui(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function cj(a,b){Qi.call(this,b.Y(),b.X()&-16449);this.a=a;this.c=b}
function Ui(a){if(a.b){Ui(a.b)}else if(a.c){throw Mg(new yh)}}
function qn(a){ib(a.d);return new $i(null,new Si(new Xh(a.g),0))}
function qi(a,b){var c;return oi(b,pi(a,b==null?0:(c=r(b),c|0)))}
function Zg(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Fj(a,b,c){!Gh(c,'key')&&!Gh(c,'ref')&&(a[c]=b[c],undefined)}
function Dc(a,b,c){var d;d=Bc();try{return Ac(a,b,c)}finally{Ec(d)}}
function Wn(a,b){var c;c=a.f;if(!(b==c||!!b&&bn(b,c))){a.f=b;hb(a.d)}}
function eb(a,b){var c,d;_h(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Oh(a,b){return kd(b)?b==null?si(a.a,null):Gi(a.b,b):si(a.a,b)}
function ql(a,b){return t((J(),J(),I),new Il(a,b),75497472,null)}
function md(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ec(a){a&&Lc((Jc(),Ic));--wc;if(a){if(yc!=-1){Gc(yc);yc=-1}}}
function Mb(b){try{b.b.t()}catch(a){a=Lg(a);if(!gd(a,6))throw Mg(a)}}
function Hn(a){var b;Zi(Xi(qn(a.b),new ko),(b=new hi,b)).K(new lo(a.b))}
function Wi(a){var b;Ti(a);b=0;while(a.a.Z(new jj)){b=Ng(b,1)}return b}
function Zi(a,b){var c;Ti(a);c=new ij;c.a=b;a.a.Q(new lj(c));return c.a}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Ii(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Vh(a){this.d=a;this.c=new Ii(this.d.b);this.a=this.c;this.b=Th(this)}
function Kn(a){this.b=Oi(a);J();this.a=new mc(0,null,new Ln,true,false)}
function ih(a,b,c,d){a.addEventListener(b,c,(kh(),d?true:false))}
function jh(a,b,c,d){a.removeEventListener(b,c,(kh(),d?true:false))}
function qc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Cc(b){zc();return function(){return Dc(b,this,arguments);var a}}
function vc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ji(a){if(a.a.c!=a.c){return Ei(a.a,a.b.value[0])}return a.b.value[1]}
function bn(a,b){var c;if(gd(b,48)){c=b;return a.c.e==c.c.e}else{return false}}
function Wc(a,b,c,d,e,f){var g;g=Xc(e,d);e!=10&&$c(Uc(a,f),b,c,e,g);return g}
function ci(a,b,c){for(;c<a.a.length;++c){if(mi(b,a.a[c])){return c}}return -1}
function ei(a,b){var c;c=ci(a,b,0);if(c==-1){return false}pj(a.a,c);return true}
function ai(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.u(c)}}
function Tn(a){var b,c;return b=S(a.b),Zi(Xi(qn(a.j),new no(b)),(c=new hi,c))}
function Qn(a,b){return (go(),eo)==a||(co==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function Nh(a,b,c){return kd(b)?b==null?ri(a.a,null,c):Fi(a.b,b,c):ri(a.a,b,c)}
function qj(a,b){return Vc(b)!=10&&$c(q(b),b.lb,b.__elementTypeId$,Vc(b),a),a}
function Vc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function tl(a){return kh(),Sn((Gm(),Fm))==(jb(a.c),a.n.props['a'])?true:false}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new mb(a)),0,null);!!a.b&&nb(a.b)}}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new nc(a)),67108864,null)}}
function Lj(a,b){if(!a.j){a.j=true;a.k||(b?a.n.setState({}):a.n.forceUpdate())}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||nb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Fb(a.a)}finally{a.c=false}}}}
function Kc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Oc(b,c)}while(a.a);a.a=c}}
function Lc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Oc(b,c)}while(a.b);a.b=c}}
function Qk(a){var b;b=Hh((ib(a.b),a.d));if(b.length>0){Dn((Gm(),Em),b);Xk(a,'')}}
function Hm(a,b){a.f=b;Gh(b,S(a.a))&&Sm(a,b);Lm(b);A((J(),J(),I),new Zm(a),Lo)}
function Rk(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new al(a),Lo)}}
function ub(b){if(b){try{b.t()}catch(a){a=Lg(a);if(gd(a,6)){J()}else throw Mg(a)}}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function bb(){var a;this.a=Wc(qd,ro,46,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Tg(){Ug();var a=Sg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ah(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Lg(a){var b;if(gd(a,6)){return a}b=a&&a[zo];if(!b){b=new uc(a);Rc(b)}return b}
function wh(a,b){var c;if(!a){return}b.j=a;var d=th(b);if(!d){Xg[a]=[b];return}d.kb=b}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;_h((!a.b&&(a.b=new hi),a.b),b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new hi);a.c=c.c}b.d=true;_h(a.c,Oi(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Oi(b))}
function Gi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{vi(a.a,b);--a.b}return c}
function ph(a){var b;b=new oh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Ij(a){var b;b=Jj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function ki(a){var b,c,d;d=0;for(c=new Vh(a.a);c.b;){b=Uh(c);d=d+(b?r(b):0);d=d|0}return d}
function Jh(a,b){var c,d;for(d=new Vh(b.a);d.b;){c=Uh(d);if(!Rh(a,c)){return false}}return true}
function rb(a){var b,c;for(c=new ji(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function go(){go=_g;co=new ho('ACTIVE',0);fo=new ho('COMPLETED',1);eo=new ho('ALL',2)}
function fh(){Gm();$wnd.ReactDOM.render((new Cm).a,(hh(),gh).getElementById('app'),null)}
function yh(){rc.call(this,"Stream already terminated, can't be modified or used")}
function yb(a,b,c){xb.call(this,null,a,b,c|(!a?262144:so)|(0==(c&6291456)?!a?vo:wo:0)|0|0|0)}
function Nb(a,b){this.b=Oi(a);this.a=b|0|(0==(b&6291456)?wo:0)|(0!=(b&229376)?0:98304)}
function uc(a){tc();oc(this);this.b=a;a!=null&&rj(a,zo,this);this.c=a==null?'null':dh(a);this.a=a}
function Dj(a){$wnd.React.Component.call(this,a);this.a=this.db();this.a.n=Oi(this);this.a.ab()}
function Th(a){if(a.a.R()){return true}if(a.a!=a.c){return false}a.a=new ui(a.d.a);return a.a.R()}
function Og(a){var b;b=a.h;if(b==0){return a.l+a.m*wo}if(b==1048575){return a.l+a.m*wo-Bo}return a}
function Qg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Bo;d=1048575}c=md(e/wo);b=md(e-c*wo);return _c(b,c,d)}
function oi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(mi(a,c.U())){return c}}return null}
function ml(a,b){var c,d;d=a.n.props;c=false;if(!(d['a']===b['a'])){hb(a.c);c=true}return c||a.j}
function mn(a,b,c){var d;d=new jn(b,c);ac(d.c.c,a,new ic(a,d));Nh(a.g,Ah(d.c.e),d);hb(a.d);return d}
function Fi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ec(a,b,c){var d;d=Oh(a.g,b?Ah(b.c.e):null);if(null!=d){cc(b.c.c,a);c&&!!b&&jc(b.c);hb(a.d)}}
function Vn(a){var b;b=S(a.i.a);Gh(To,b)||Gh(No,b)||Gh('',b)?Om(a.i,b):Pn(Pm(a.i))?Rm(a.i):Om(a.i,'')}
function S(a){ib(a.e);wb(a.f)&&pb(a.f);if(a.b){if(gd(a.b,9)){throw Mg(a.b)}else{throw Mg(a.b)}}return a.k}
function $c(a,b,c,d,e){e.kb=a;e.lb=b;e.mb=eh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Wg(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function fl(a,b,c){27==c.which?A((J(),J(),I),new Fl(a,b),Lo):13==c.which&&A((J(),J(),I),new Dl(a,b),Lo)}
function nb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Cb(a)),67108864,null);!!a.a&&R(a.a);Jb(a.f);a.c=a.c&-8|1}}
function Mj(a){if(!Kj){Kj=(++a.eb().e,new Ib);$wnd.Promise.resolve(null).then(ah(Nj.prototype.C,Nj,[]))}}
function q(a){return kd(a)?de:jd(a)?Vd:hd(a)?Td:fd(a)?a.kb:Yc(a)?a.kb:a.kb||Array.isArray(a)&&Uc(Nd,1)||Nd}
function nl(a){var b,c;a.j=false;Mj(a);b=(jb(a.c),a.n.props['a']);if(!!b&&b.c.i<0){return null}c=jl(a);return c}
function Ah(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Ch(),Bh)[b];!c&&(c=Bh[b]=new zh(a));return c}return new zh(a)}
function dh(a){var b;if(Array.isArray(a)&&a.mb===eh){return nh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function zj(a){xj();var b,c,d;c=':'+a;d=wj[c];if(d!=null){return md(d)}d=uj[c];b=d==null?yj(a):md(d);Aj();wj[c]=b;return b}
function ad(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return _c(c&4194303,d&4194303,e&1048575)}
function fb(a,b){var c,d;d=a.c;ei(d,b);!!a.b&&so!=(a.b.c&to)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function bc(a){var b,c;if(!a.a){for(c=new ji(new ii(new Xh(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.t()}a.a=true}}
function li(a){var b,c,d;d=1;for(c=new ji(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Ub(a){var b;if(a.c){while(a.c.a.length!=0){b=di(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&vb(b.b,3,true)}}}
function il(a){var b;b=S(a.d);if(!a.i&&b){a.i=true;wl(a,(jb(a.c),a.n.props['a']));a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function hl(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){In((Gm(),b),c);Wn(Fm,null);xl(a,c)}else{pn((Gm(),Dm),b)}}
function Ng(a,b){var c;if(jd(a)&&jd(b)){c=a+b;if(-17592186044416<c&&c<Bo){return c}}return Og(ad(jd(a)?Qg(a):a,jd(b)?Qg(b):b))}
function r(a){return kd(a)?zj(a):jd(a)?md(a):hd(a)?a?1231:1237:fd(a)?a.q():Yc(a)?tj(a):!!a&&!!a.hashCode?a.hashCode():tj(a)}
function p(a,b){return kd(a)?Gh(a,b):jd(a)?a===b:hd(a)?a===b:fd(a)?a.o(b):Yc(a)?a===b:!!a&&!!a.equals?a.equals(b):ld(a)===ld(b)}
function Kb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&so)?Mb(a):a.b.t();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function zb(a,b){xb.call(this,a,new Ab(a),null,b|(so==(b&to)?0:524288)|(0==(b&6291456)?so==(b&to)?wo:vo:0)|0|268435456|0)}
function oh(){this.g=lh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function mc(a,b,c,d,e){var f;this.e=a;this.c=d?new dc:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new lb((J(),null)),f):null;this.d=null}
function U(a,b,c,d){this.c=Oi(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new zb(this,d);this.e=new lb(this.f);so==(d&to)&&ob(this.f)}
function Nl(){var a;J();a=++Ml;this.b=new mc(a,new Pl(this),new Ol(this),false,false);this.a=new yb(null,Oi(new Ql(this)),Ko);D((null,I))}
function Lk(){var a;J();a=++Kk;this.b=new mc(a,new Nk(this),new Mk(this),false,false);this.a=new yb(null,Oi(new Ok(this)),Ko);D((null,I))}
function yk(){wk();return $c(Uc(Re,1),ro,7,0,[ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk])}
function vh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function gi(a,b){var c,d;d=a.a.length;b.length<d&&(b=qj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Oj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Bc(){var a;if(wc!=0){a=vc();if(a-xc>2000){xc=a;yc=$wnd.setTimeout(Hc,10)}}if(wc++==0){Kc((Jc(),Ic));return true}return false}
function Sc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function ed(a,b){if(kd(a)){return !!dd[b]}else if(a.lb){return !!a.lb[b]}else if(jd(a)){return !!cd[b]}else if(hd(a)){return !!bd[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&vb(b,5,true)}}}
function Xb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ji(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&vb(b,6,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?vb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Hh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Xc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{$b(b,d);try{f=(c.a.t(),null)}finally{_b()}return f}catch(a){a=Lg(a);if(gd(a,6)){e=a;throw Mg(e)}else throw Mg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.r()}else{$b(b,e);try{g=c.r()}finally{_b()}}return g}catch(a){a=Lg(a);if(gd(a,6)){f=a;throw Mg(f)}else throw Mg(a)}finally{D(b)}}
function jn(a,b){var c,d,e;this.e=Oi(a);this.d=b;J();c=++_m;this.c=new mc(c,null,new kn(this),true,true);this.b=(e=new lb(null),e);this.a=(d=new lb(null),d)}
function Yk(){var a,b;J();a=++Tk;this.c=new mc(a,new $k(this),new Zk(this),false,false);this.b=(b=new lb(null),b);this.a=new yb(null,Oi(new cl(this)),Ko);D((null,I))}
function Ck(){var a;J();a=++Ak;this.c=new mc(a,new Ek(this),new Dk(this),false,false);this.a=new U(new Gk,null,null,136478720);this.b=new yb(null,Oi(new Hk(this)),Ko);D((null,I))}
function Eb(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Kb(c);return true}
function Vg(b,c,d,e){Ug();var f=Sg;$moduleName=c;$moduleBase=d;Kg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{oo(g)()}catch(a){b(c,a)}}else{oo(g)()}}
function Jj(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=Oi(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ik(){var a,b;b=S((Gm(),Dm).e).a;a='item'+(b==1?'':'s');return Ej('span',Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,['todo-count'])),[Ej('strong',null,[b]),' '+a+' left'])}
function Ai(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Bi()}}
function Kh(a,b){var c,d,e,f,g;g=Qh(a.a);b.length<g&&(b=qj(new Array(g),b));e=(f=new Vh((new Sh(a.a)).a),new Yh(f));for(d=0;d<g;++d){b[d]=(c=Uh(e.a),c.V())}b.length>g&&(b[g]=null);return b}
function Yg(){Xg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Oc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].nb()&&(c=Nc(c,g)):g[0].nb()}catch(a){a=Lg(a);if(gd(a,6)){d=a;zc();Fc(gd(d,35)?d.B():d)}else throw Mg(a)}}return c}
function Sk(a){var b;a.j=false;Mj(a);b=Ej(Mo,Sj(Wj(Xj($j(Yj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,['new-todo']))),(ib(a.b),a.d)),ah(nm.prototype.hb,nm,[a])),ah(om.prototype.gb,om,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.r();if(!(ld(e)===ld(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Lg(a);if(gd(a,12)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Mg(c)}else throw Mg(a)}}
function ri(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=oi(b,e);if(f){return f.W(c)}}e[e.length]=new Zh(b,c);++a.b;return null}
function mj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function yj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Fh(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Wc(be,ro,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function pb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.t()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Lg(a);if(gd(a,6)){J()}else throw Mg(a)}}}
function Lm(a){var b;if(0==a.length){b=(hh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',gh.title,b)}else{(hh(),$wnd.window.window).location.hash=a}}
function xb(a,b,c,d){this.b=new hi;this.f=new Nb(new Bb(this),d&6520832|262144|so);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&vo)&&D((null,I)))}
function si(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(mi(b,e.U())){if(d.length==1){d.length=0;vi(a.a,g)}else{d.splice(h,1)}--a.b;return e.V()}}return null}
function $g(a,b,c){var d=Xg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Xg[b]),bh(h));_.lb=c;!b&&(_.mb=eh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.kb=f)}
function uh(a){if(a.I()){var b=a.c;b.J()?(a.k='['+b.j):!b.I()?(a.k='[L'+b.G()+';'):(a.k='['+b.G());a.b=b.F()+'[]';a.i=b.H()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=vh('.',[c,vh('$',d)]);a.b=vh('.',[c,vh('.',d)]);a.i=d[d.length-1]}
function yl(){var a,b,c;J();a=++ol;this.e=new mc(a,new Al(this),new zl(this),false,false);this.c=(c=new lb(null),c);this.a=(b=new lb(null),b);this.d=new U(new Jl(this),null,null,136478720);this.b=new yb(null,Oi(new Kl(this)),Ko);D((null,I))}
function Lh(a,b){var c,d,e;c=b.U();e=b.V();d=kd(c)?c==null?Mh(qi(a.a,null)):Ei(a.b,c):Mh(qi(a.a,c));if(!(ld(e)===ld(d)||e!=null&&p(e,d))){return false}if(d==null&&!(kd(c)?c==null?!!qi(a.a,null):Di(a.b,c):!!qi(a.a,c))){return false}return true}
function Tm(){var a,b;this.d=new bo(this);this.f=this.e=(b=(hh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new mc(0,null,new Um(this),true,false);this.b=(a=new lb(null),a);this.a=new U(new $m,new Vm(this),new Wm(this),35749888)}
function un(){var a;this.g=new ni;J();this.f=new mc(0,new wn(this),new vn(this),true,false);this.d=(a=new lb(null),a);this.c=new U(new zn(this),null,null,So);this.e=new U(new An(this),null,null,So);this.a=new U(new Bn(this),null,null,So);this.b=new U(new Cn(this),null,null,So)}
function Xn(a){var b;this.j=Oi(a);this.i=new Tm;J();this.g=new mc(0,null,new Yn(this),true,false);this.d=(b=new lb(null),b);this.b=new U(new Zn(this),null,null,So);this.c=new U(new $n(this),null,null,So);this.e=u(new _n(this),413138944);this.a=u(new ao(this),681574400);D((null,I))}
function wb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ji(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Lg(a);if(!gd(a,6))throw Mg(a)}if(6==(b.c&7)){return true}}}}}rb(b);return false}
function Ej(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Cj(b,ah(Gj.prototype._,Gj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=Jj($wnd.React.Element,a),g.key=e,g.ref=f,g.props=Oi(d),g}
function zi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function vb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){kb(a.a.e);ub((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;ub((e=d.i,e));d.k=null}ai(a.b,new Db(a));a.b.a=Wc(be,ro,1,0,5,1)}else 3==g&&!!a.a&&ub((f=a.a.g,f))}}
function wk(){wk=_g;ak=new xk(Eo,0);bk=new xk('checkbox',1);ck=new xk('color',2);dk=new xk('date',3);ek=new xk('datetime',4);fk=new xk('email',5);gk=new xk('file',6);hk=new xk('hidden',7);ik=new xk('image',8);jk=new xk('month',9);kk=new xk(po,10);lk=new xk('password',11);mk=new xk('radio',12);nk=new xk('range',13);ok=new xk('reset',14);pk=new xk('search',15);qk=new xk('submit',16);rk=new xk('tel',17);sk=new xk('text',18);tk=new xk('time',19);uk=new xk('url',20);vk=new xk('week',21)}
function Ll(a){var b,c,d;a.j=false;Mj(a);d=Ej('div',null,[Ej('div',null,[Ej(Oo,Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[Oo])),[Ej('h1',null,['todos']),(new pm).a]),S((Gm(),Dm).c)?null:Ej('section',Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[Oo])),[Ej(Mo,Wj(Zj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[Po])),(wk(),bk)),ah(Bm.prototype.gb,Bm,[])),null),Ej('ul',Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,['todo-list'])),(b=Zi(Yi(S(Fm.c).P()),(c=new hi,c)),gi(b,Zc(b.a.length))))]),S(Dm.c)?null:(new Tl).a])]);return d}
function zk(a){var b,c;a.j=false;Mj(a);c=(b=S((Gm(),Fm).b),Ej(Fo,Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[Fo])),[(new Ul).a,Ej('ul',Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,['filters'])),[Ej('li',null,[Ej('a',Qj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[(go(),eo)==b?Go:null])),'#'),['All'])]),Ej('li',null,[Ej('a',Qj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[co==b?Go:null])),'#active'),['Active'])]),Ej('li',null,[Ej('a',Qj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[fo==b?Go:null])),Ho),['Completed'])])]),S(a.a)?Ej(Eo,Rj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[Io])),ah(Sl.prototype.ib,Sl,[])),[Jo]):null]));return c}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=bi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&fi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&vb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=bi(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){di(a.b,g)}e&&tb(a.e,a.b)}else{e&&tb(a.e,new hi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&so!=(k.b.c&to)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function jl(a){var b,c;c=(jb(a.c),a.n.props['a']);b=(ib(c.a),c.d);return Ej('li',Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[b?No:null,S(a.d)?'editing':null])),[Ej('div',Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,['view'])),[Ej(Mo,Wj(Tj(Zj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,['toggle'])),(wk(),bk)),b),ah(rm.prototype.gb,rm,[c])),null),Ej('label',_j(new $wnd.Object,ah(sm.prototype.ib,sm,[a,c])),[(ib(c.b),c.e)]),Ej(Eo,Rj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,['destroy'])),ah(tm.prototype.ib,tm,[c])),null)]),Ej(Mo,Xj(Wj(Vj(Uj(Oj(Pj(new $wnd.Object,ah(um.prototype.u,um,[a])),$c(Uc(de,1),ro,2,6,['edit'])),(ib(a.a),a.g)),ah(vm.prototype.fb,vm,[a,c])),ah(qm.prototype.gb,qm,[a])),ah(wm.prototype.hb,wm,[a,c])),null)])}
function Bi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Do]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!zi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Do]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var po='number',qo={11:1},ro={3:1,4:1},so=1048576,to=1835008,uo={5:1},vo=2097152,wo=4194304,xo={21:1},yo='__noinit__',zo='__java$exception',Ao={3:1,12:1,9:1,6:1},Bo=17592186044416,Co={41:1},Do='delete',Eo='button',Fo='footer',Go='selected',Ho='#completed',Io='clear-completed',Jo='Clear Completed',Ko=1478627328,Lo=142606336,Mo='input',No='completed',Oo='header',Po='toggle-all',Qo='hashchange',Ro={8:1,49:1},So=136413184,To='active';var _,Xg,Sg,Kg=-1;Yg();$g(1,null,{},o);_.o=Uo;_.p=function(){return this.kb};_.q=Vo;_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};var bd,cd,dd;$g(51,1,{},oh);_.D=function(a){var b;b=new oh;b.e=4;a>1?(b.c=sh(this,a-1)):(b.c=this);return b};_.F=function(){mh(this);return this.b};_.G=function(){return nh(this)};_.H=function(){mh(this);return this.i};_.I=function(){return (this.e&4)!=0};_.J=function(){return (this.e&1)!=0};_.e=0;_.g=0;var lh=1;var be=qh(1);var Ud=qh(51);$g(86,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var pd=qh(86);$g(36,1,qo,G);_.r=function(){return this.a.t(),null};var nd=qh(36);$g(87,1,{},H);var od=qh(87);var I;$g(46,1,{46:1},P);_.b=0;_.c=false;_.d=0;var qd=qh(46);$g(210,1,{8:1});var td=qh(210);$g(19,210,{8:1},U);_.s=function(){R(this)};_.a=false;_.d=0;var rd=qh(19);$g(141,1,{249:1},bb);var sd=qh(141);$g(14,210,{8:1,14:1},lb);_.s=function(){cb(this)};_.a=4;_.d=false;_.e=0;var vd=qh(14);$g(121,1,uo,mb);_.t=function(){db(this.a)};var ud=qh(121);$g(17,210,{8:1,17:1},yb,zb);_.s=function(){nb(this)};_.c=0;var Ad=qh(17);$g(122,1,xo,Ab);_.t=function(){Q(this.a)};var wd=qh(122);$g(123,1,uo,Bb);_.t=function(){pb(this.a)};var xd=qh(123);$g(124,1,uo,Cb);_.t=function(){sb(this.a)};var yd=qh(124);$g(125,1,{},Db);_.u=function(a){qb(this.a,a)};var zd=qh(125);$g(140,1,{},Gb);_.a=0;_.b=0;_.c=0;var Bd=qh(140);$g(158,1,{8:1},Ib);_.s=function(){Hb(this)};_.a=false;var Cd=qh(158);$g(59,210,{8:1,59:1},Nb);_.s=function(){Jb(this)};_.a=0;var Dd=qh(59);$g(143,1,{},Zb);_.a=0;var Ob;var Ed=qh(143);$g(126,1,{8:1},dc);_.s=function(){bc(this)};_.a=false;var Fd=qh(126);$g(109,1,{});var Id=qh(109);$g(88,1,{},hc);_.u=function(a){fc(this.a,a)};var Gd=qh(88);$g(89,1,uo,ic);_.t=function(){gc(this.a,this.b)};var Hd=qh(89);$g(110,109,{});var Jd=qh(110);$g(16,1,{8:1},mc);_.s=function(){jc(this)};_.e=0;_.i=0;var Ld=qh(16);$g(120,1,uo,nc);_.t=function(){lc(this.a)};var Kd=qh(120);$g(6,1,{3:1,6:1});_.w=function(a){return new Error(a)};_.A=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=nh(this.kb),c==null?a:a+': '+c);pc(this,qc(this.w(b)));Rc(this)};_.b=yo;_.d=true;var ee=qh(6);$g(12,6,{3:1,12:1,6:1});var Xd=qh(12);$g(9,12,Ao);var ce=qh(9);$g(52,9,Ao);var $d=qh(52);$g(80,52,Ao);var Pd=qh(80);$g(35,80,{35:1,3:1,12:1,9:1,6:1},uc);_.B=function(){return ld(this.a)===ld(sc)?null:this.a};var sc;var Md=qh(35);var Nd=qh(0);$g(196,1,{});var Od=qh(196);var wc=0,xc=0,yc=-1;$g(108,196,{},Mc);var Ic;var Qd=qh(108);var Pc;$g(207,1,{});var Sd=qh(207);$g(81,207,{},Tc);var Rd=qh(81);var gh;bd={3:1,76:1,28:1};var Td=qh(76);$g(43,1,{3:1,43:1});var ae=qh(43);cd={3:1,28:1,43:1};var Vd=qh(206);$g(31,1,{3:1,28:1,31:1});_.o=Uo;_.q=Vo;_.b=0;var Wd=qh(31);$g(82,9,Ao,yh);var Yd=qh(82);$g(29,43,{3:1,28:1,29:1,43:1},zh);_.o=function(a){return gd(a,29)&&a.a==this.a};_.q=Yo;_.a=0;var Zd=qh(29);var Bh;$g(275,1,{});$g(84,52,Ao,Eh);_.w=function(a){return new TypeError(a)};var _d=qh(84);dd={3:1,75:1,28:1,2:1};var de=qh(2);$g(279,1,{});$g(54,9,Ao,Ih);var fe=qh(54);$g(208,1,{39:1});_.K=$o;_.O=function(){return new Si(this,0)};_.P=function(){return new $i(null,this.O())};_.M=function(a){throw Mg(new Ih('Add not supported on this collection'))};var ge=qh(208);$g(211,1,{194:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!gd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Vh((new Sh(d)).a);c.b;){b=Uh(c);if(!Lh(this,b)){return false}}return true};_.q=function(){return ki(new Sh(this))};var re=qh(211);$g(129,211,{194:1});var je=qh(129);$g(212,208,{39:1,228:1});_.O=function(){return new Si(this,1)};_.o=function(a){var b;if(a===this){return true}if(!gd(a,24)){return false}b=a;if(Qh(b.a)!=this.N()){return false}return Jh(this,b)};_.q=function(){return ki(this)};var se=qh(212);$g(24,212,{24:1,39:1,228:1},Sh);_.L=function(){return new Vh(this.a)};_.N=Xo;var ie=qh(24);$g(25,1,{},Vh);_.Q=Wo;_.S=function(){return Uh(this)};_.R=Zo;_.b=false;var he=qh(25);$g(209,208,{39:1,225:1});_.O=function(){return new Si(this,16)};_.T=function(a,b){throw Mg(new Ih('Add not supported on this list'))};_.M=function(a){this.T(this.N(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!gd(a,10)){return false}f=a;if(this.N()!=f.a.length){return false}e=new ji(f);for(c=new ji(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(ld(b)===ld(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return li(this)};_.L=function(){return new Wh(this)};var le=qh(209);$g(107,1,{},Wh);_.Q=Wo;_.R=function(){return this.a<this.b.a.length};_.S=function(){return bi(this.b,this.a++)};_.a=0;var ke=qh(107);$g(45,208,{39:1},Xh);_.L=function(){var a;return a=new Vh((new Sh(this.a)).a),new Yh(a)};_.N=Xo;var ne=qh(45);$g(55,1,{},Yh);_.Q=Wo;_.R=function(){return this.a.b};_.S=function(){var a;return a=Uh(this.a),a.V()};var me=qh(55);$g(130,1,Co);_.o=function(a){var b;if(!gd(a,41)){return false}b=a;return mi(this.a,b.U())&&mi(this.b,b.V())};_.U=Yo;_.V=Zo;_.q=function(){return Ni(this.a)^Ni(this.b)};_.W=function(a){var b;b=this.b;this.b=a;return b};var oe=qh(130);$g(131,130,Co,Zh);var pe=qh(131);$g(213,1,Co);_.o=function(a){var b;if(!gd(a,41)){return false}b=a;return mi(this.b.value[0],b.U())&&mi(Ji(this),b.V())};_.q=function(){return Ni(this.b.value[0])^Ni(Ji(this))};var qe=qh(213);$g(10,209,{3:1,10:1,39:1,225:1},hi,ii);_.T=function(a,b){nj(this.a,a,b)};_.M=function(a){return _h(this,a)};_.K=function(a){ai(this,a)};_.L=function(){return new ji(this)};_.N=function(){return this.a.length};var ue=qh(10);$g(18,1,{},ji);_.Q=Wo;_.R=function(){return this.a<this.c.a.length};_.S=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var te=qh(18);$g(37,129,{3:1,37:1,194:1},ni);var ve=qh(37);$g(60,1,{},ti);_.K=$o;_.L=function(){return new ui(this)};_.b=0;var xe=qh(60);$g(61,1,{},ui);_.Q=Wo;_.S=function(){return this.d=this.a[this.c++],this.d};_.R=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var we=qh(61);var xi;$g(57,1,{},Hi);_.K=$o;_.L=function(){return new Ii(this)};_.b=0;_.c=0;var Ae=qh(57);$g(58,1,{},Ii);_.Q=Wo;_.S=function(){return this.c=this.a,this.a=this.b.next(),new Ki(this.d,this.c,this.d.c)};_.R=function(){return !this.a.done};var ye=qh(58);$g(142,213,Co,Ki);_.U=function(){return this.b.value[0]};_.V=function(){return Ji(this)};_.W=function(a){return Fi(this.a,this.b.value[0],a)};_.c=0;var ze=qh(142);$g(145,1,{});_.Q=function(a){Pi(this,a)};_.X=function(){return this.d};_.Y=function(){return this.e};_.d=0;_.e=0;var Ce=qh(145);$g(62,145,{});var Be=qh(62);$g(23,1,{},Si);_.X=Yo;_.Y=function(){Ri(this);return this.c};_.Q=function(a){Ri(this);this.d.Q(a)};_.Z=function(a){Ri(this);if(this.d.R()){a.u(this.d.S());return true}return false};_.a=0;_.c=0;var De=qh(23);$g(144,1,{});_.c=false;var Me=qh(144);$g(32,144,{},$i);var Le=qh(32);$g(147,62,{},cj);_.Z=function(a){this.b=false;while(!this.b&&this.c.Z(new dj(this,a)));return this.b};_.b=false;var Fe=qh(147);$g(150,1,{},dj);_.u=function(a){bj(this.a,this.b,a)};var Ee=qh(150);$g(146,62,{},fj);_.Z=function(a){return this.a.Z(new gj(a))};var He=qh(146);$g(149,1,{},gj);_.u=function(a){ej(this.a,a)};var Ge=qh(149);$g(148,1,{},ij);_.u=function(a){hj(this,a)};var Ie=qh(148);$g(151,1,{},jj);_.u=function(a){};var Je=qh(151);$g(152,1,{},lj);_.u=function(a){kj(this,a)};var Ke=qh(152);$g(277,1,{});$g(218,1,{});var Ne=qh(218);$g(274,1,{});var sj=0;var uj,vj=0,wj;$g(701,1,{});$g(727,1,{});$g(214,1,{});_.ab=ip;var Oe=qh(214);$g(30,$wnd.React.Component,{});Zg(Xg[1],_);_.render=function(){return this.a.bb()};var Pe=qh(30);$g(248,$wnd.Function,{},Gj);_._=function(a){Fj(this.a,this.b,a)};$g(215,214,{});_.j=false;_.k=false;var Kj;var Qe=qh(215);$g(247,$wnd.Function,{},Nj);_.C=function(a){return Hb(Kj),Kj=null,null};$g(7,31,{3:1,28:1,31:1,7:1},xk);var ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk;var Re=rh(7,yk);$g(219,215,{});_.bb=function(){var a;return a=S((Gm(),Fm).b),Ej(Fo,Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[Fo])),[(new Ul).a,Ej('ul',Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,['filters'])),[Ej('li',null,[Ej('a',Qj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[(go(),eo)==a?Go:null])),'#'),['All'])]),Ej('li',null,[Ej('a',Qj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[co==a?Go:null])),'#active'),['Active'])]),Ej('li',null,[Ej('a',Qj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[fo==a?Go:null])),Ho),['Completed'])])]),S(this.a)?Ej(Eo,Rj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[Io])),ah(Sl.prototype.ib,Sl,[])),[Jo]):null])};var Ef=qh(219);$g(220,219,{});_.bb=function(){return zk(this)};var If=qh(220);$g(67,220,{8:1,67:1},Ck);_.s=cp;_.o=Uo;_.eb=_o;_.q=Vo;_.bb=function(){return B((J(),J(),I),this.b,new Fk(this))};var Ak=0;var af=qh(67);$g(172,1,uo,Dk);_.t=function(){Bk(this.a)};var Se=qh(172);$g(171,1,uo,Ek);_.t=ap;var Te=qh(171);$g(175,1,qo,Fk);_.r=function(){return zk(this.a)};var Ue=qh(175);$g(173,1,qo,Gk);_.r=function(){return kh(),S((Gm(),Dm).b).a>0?true:false};var Ve=qh(173);$g(174,1,xo,Hk);_.t=bp;var We=qh(174);$g(223,215,{});_.bb=function(){return Ik()};var Df=qh(223);$g(224,223,{});_.bb=function(){return Jk(this)};var Hf=qh(224);$g(72,224,{8:1,72:1},Lk);_.s=dp;_.o=Uo;_.eb=_o;_.q=Vo;_.bb=function(){return B((J(),J(),I),this.a,new Pk(this))};var Kk=0;var _e=qh(72);$g(190,1,uo,Mk);_.t=ep;var Xe=qh(190);$g(189,1,uo,Nk);_.t=ap;var Ye=qh(189);$g(191,1,xo,Ok);_.t=bp;var Ze=qh(191);$g(192,1,qo,Pk);_.r=function(){return Jk(this.a)};var $e=qh(192);$g(163,215,{});_.bb=function(){return Ej(Mo,Sj(Wj(Xj($j(Yj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,['new-todo']))),(ib(this.b),this.d)),ah(nm.prototype.hb,nm,[this])),ah(om.prototype.gb,om,[this]))),null)};_.d='';var Qf=qh(163);$g(164,163,{});_.bb=function(){return Sk(this)};var Kf=qh(164);$g(66,164,{8:1,66:1},Yk);_.s=cp;_.o=Uo;_.eb=_o;_.q=Vo;_.bb=function(){return B((J(),J(),I),this.a,new _k(this))};var Tk=0;var hf=qh(66);$g(166,1,uo,Zk);_.t=function(){Uk(this.a)};var bf=qh(166);$g(165,1,uo,$k);_.t=ap;var cf=qh(165);$g(168,1,qo,_k);_.r=function(){return Sk(this.a)};var df=qh(168);$g(169,1,uo,al);_.t=function(){Qk(this.a)};var ef=qh(169);$g(170,1,uo,bl);_.t=function(){Wk(this.a,this.b)};var ff=qh(170);$g(167,1,xo,cl);_.t=bp;var gf=qh(167);$g(221,215,{});_.ab=function(){wl(this,this.jb())};_.bb=function(){return jl(this)};_.i=false;var Sf=qh(221);$g(222,221,{});_.jb=function(){return this.n.props['a']};_.bb=function(){return nl(this)};var Mf=qh(222);$g(69,222,{8:1,69:1},yl);_.s=function(){jc(this.e)};_.o=Uo;_.eb=_o;_.jb=function(){return jb(this.c),this.n.props['a']};_.q=Vo;_.bb=function(){return B((J(),J(),I),this.b,new Bl(this))};var ol=0;var vf=qh(69);$g(177,1,uo,zl);_.t=function(){pl(this.a)};var jf=qh(177);$g(176,1,uo,Al);_.t=ap;var kf=qh(176);$g(180,1,qo,Bl);_.r=function(){return nl(this.a)};var lf=qh(180);$g(70,1,uo,Cl);_.t=function(){xl(this.a,Pm(this.b))};var mf=qh(70);$g(71,1,uo,Dl);_.t=function(){hl(this.a,this.b)};var nf=qh(71);$g(181,1,uo,El);_.t=function(){gl(this.a,this.b)};var of=qh(181);$g(182,1,uo,Fl);_.t=function(){wl(this.a,this.b);Wn((Gm(),Fm),null)};var pf=qh(182);$g(183,1,uo,Gl);_.t=function(){dl(this.a,this.b)};var qf=qh(183);$g(184,1,uo,Hl);_.t=function(){il(this.a)};var rf=qh(184);$g(185,1,qo,Il);_.r=function(){return sl(this.a,this.b)};var sf=qh(185);$g(178,1,qo,Jl);_.r=function(){return tl(this.a)};var tf=qh(178);$g(179,1,xo,Kl);_.t=function(){Lj(this.a,true)};var uf=qh(179);$g(216,215,{});_.bb=function(){var a;return Ej('div',null,[Ej('div',null,[Ej(Oo,Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[Oo])),[Ej('h1',null,['todos']),(new pm).a]),S((Gm(),Dm).c)?null:Ej('section',Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[Oo])),[Ej(Mo,Wj(Zj(Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,[Po])),(wk(),bk)),ah(Bm.prototype.gb,Bm,[])),null),Ej('ul',Oj(new $wnd.Object,$c(Uc(de,1),ro,2,6,['todo-list'])),(a=Zi(Yi(S(Fm.c).P()),new hi),gi(a,Zc(a.a.length))))]),S(Dm.c)?null:(new Tl).a])])};var Uf=qh(216);$g(217,216,{});_.bb=function(){return Ll(this)};var Of=qh(217);$g(63,217,{8:1,63:1},Nl);_.s=dp;_.o=Uo;_.eb=_o;_.q=Vo;_.bb=function(){return B((J(),J(),I),this.a,new Rl(this))};var Ml=0;var Af=qh(63);$g(155,1,uo,Ol);_.t=ep;var wf=qh(155);$g(154,1,uo,Pl);_.t=ap;var xf=qh(154);$g(156,1,xo,Ql);_.t=bp;var yf=qh(156);$g(157,1,qo,Rl);_.r=function(){return Ll(this.a)};var zf=qh(157);$g(231,$wnd.Function,{},Sl);_.ib=function(a){Fn((Gm(),Em))};$g(65,1,{},Tl);var Bf=qh(65);$g(68,1,{},Ul);var Cf=qh(68);$g(251,$wnd.Function,{},Vl);_.cb=function(a){return new Yl(a)};var Wl;$g(160,30,{},Yl);_.db=function(){return new Ck};_.componentWillUnmount=fp;var Ff=qh(160);$g(261,$wnd.Function,{},Zl);_.cb=function(a){return new am(a)};var $l;$g(186,30,{},am);_.db=function(){return new Lk};_.componentWillUnmount=gp;var Gf=qh(186);$g(250,$wnd.Function,{},bm);_.cb=function(a){return new em(a)};var cm;$g(159,30,{},em);_.db=function(){return new Yk};_.componentWillUnmount=fp;var Jf=qh(159);$g(252,$wnd.Function,{},fm);_.cb=function(a){return new im(a)};var gm;$g(162,30,{},im);_.db=function(){return new yl};_.componentDidUpdate=function(a){ll(this.a)};_.componentWillUnmount=function(){jc(this.a.e)};_.shouldComponentUpdate=function(a){return ql(this.a,a)};var Lf=qh(162);$g(246,$wnd.Function,{},jm);_.cb=function(a){return new mm(a)};var km;$g(128,30,{},mm);_.db=function(){return new Nl};_.componentWillUnmount=gp;var Nf=qh(128);$g(229,$wnd.Function,{},nm);_.hb=function(a){Rk(this.a,a)};$g(230,$wnd.Function,{},om);_.gb=function(a){Vk(this.a,a)};$g(64,1,{},pm);var Pf=qh(64);$g(259,$wnd.Function,{},qm);_.gb=function(a){rl(this.a,a)};$g(253,$wnd.Function,{},rm);_.gb=function(a){hn(this.a)};$g(255,$wnd.Function,{},sm);_.ib=function(a){ul(this.a,this.b)};$g(256,$wnd.Function,{},tm);_.ib=function(a){kl(this.a)};$g(257,$wnd.Function,{},um);_.u=function(a){el(this.a,a)};$g(258,$wnd.Function,{},vm);_.fb=function(a){vl(this.a,this.b)};$g(260,$wnd.Function,{},wm);_.hb=function(a){fl(this.a,this.b,a)};$g(161,1,{},Am);var Rf=qh(161);$g(227,$wnd.Function,{},Bm);_.gb=function(a){var b;b=a.target;Jn((Gm(),Em),b.checked)};$g(74,1,{},Cm);var Tf=qh(74);var Dm,Em,Fm;$g(132,1,{});var zg=qh(132);$g(133,132,Ro,Tm);_.s=cp;_.o=Uo;_.v=hp;_.q=Vo;var ag=qh(133);$g(134,1,uo,Um);_.t=function(){Nm(this.a)};var Vf=qh(134);$g(136,1,xo,Vm);_.t=function(){Im(this.a)};var Wf=qh(136);$g(137,1,xo,Wm);_.t=function(){Jm(this.a)};var Xf=qh(137);$g(138,1,uo,Xm);_.t=function(){Hm(this.a,this.b)};var Yf=qh(138);$g(139,1,uo,Ym);_.t=function(){Qm(this.a)};var Zf=qh(139);$g(56,1,uo,Zm);_.t=function(){Mm(this.a)};var $f=qh(56);$g(135,1,qo,$m);_.r=function(){var a;return a=(hh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var _f=qh(135);$g(47,1,{47:1});_.d=false;var Hg=qh(47);$g(48,47,{8:1,49:1,48:1,47:1},jn);_.s=cp;_.o=function(a){return bn(this,a)};_.v=hp;_.q=function(){return this.c.e};var _m=0;var rg=qh(48);$g(187,1,uo,kn);_.t=function(){an(this.a)};var bg=qh(187);$g(188,1,uo,ln);_.t=function(){en(this.a)};var cg=qh(188);$g(44,110,{44:1});var Cg=qh(44);$g(111,44,{8:1,49:1,44:1},un);_.s=function(){jc(this.f)};_.o=Uo;_.v=function(){return this.f.c};_.q=Vo;var lg=qh(111);$g(113,1,uo,vn);_.t=function(){nn(this.a)};var dg=qh(113);$g(112,1,uo,wn);_.t=function(){rn(this.a)};var eg=qh(112);$g(118,1,uo,xn);_.t=function(){ec(this.a,this.b,true)};var fg=qh(118);$g(119,1,qo,yn);_.r=function(){return mn(this.a,this.c,this.b)};_.b=false;var gg=qh(119);$g(114,1,qo,zn);_.r=function(){return sn(this.a)};var hg=qh(114);$g(115,1,qo,An);_.r=function(){return Ah(Rg(Wi(qn(this.a))))};var ig=qh(115);$g(116,1,qo,Bn);_.r=function(){return Ah(Rg(Wi(Xi(qn(this.a),new jo))))};var jg=qh(116);$g(117,1,qo,Cn);_.r=function(){return tn(this.a)};var kg=qh(117);$g(94,1,{});var Gg=qh(94);$g(95,94,Ro,Kn);_.s=function(){jc(this.a)};_.o=Uo;_.v=function(){return this.a.c};_.q=Vo;var qg=qh(95);$g(96,1,uo,Ln);_.t=ip;var mg=qh(96);$g(97,1,uo,Mn);_.t=function(){Gn(this.a,this.b)};_.b=false;var ng=qh(97);$g(98,1,uo,Nn);_.t=function(){Sm(this.b,this.a)};var og=qh(98);$g(99,1,uo,On);_.t=function(){Hn(this.a)};var pg=qh(99);$g(100,1,{});var Jg=qh(100);$g(101,100,Ro,Xn);_.s=function(){jc(this.g)};_.o=Uo;_.v=function(){return this.g.c};_.q=Vo;var xg=qh(101);$g(102,1,uo,Yn);_.t=function(){Rn(this.a)};var sg=qh(102);$g(103,1,qo,Zn);_.r=function(){var a;return a=Pm(this.a.i),Gh(To,a)||Gh(No,a)||Gh('',a)?Gh(To,a)?(go(),co):Gh(No,a)?(go(),fo):(go(),eo):(go(),eo)};var tg=qh(103);$g(104,1,qo,$n);_.r=function(){return Tn(this.a)};var ug=qh(104);$g(105,1,xo,_n);_.t=function(){Un(this.a)};var vg=qh(105);$g(106,1,xo,ao);_.t=function(){Vn(this.a)};var wg=qh(106);$g(127,1,{},bo);_.handleEvent=function(a){Km(this.a,a)};var yg=qh(127);$g(33,31,{3:1,28:1,31:1,33:1},ho);var co,eo,fo;var Ag=rh(33,io);$g(90,1,{},jo);_.$=function(a){return !dn(a)};var Bg=qh(90);$g(92,1,{},ko);_.$=function(a){return dn(a)};var Dg=qh(92);$g(93,1,{},lo);_.u=function(a){pn(this.a,a)};var Eg=qh(93);$g(91,1,{},mo);_.u=function(a){En(this.a,a)};_.a=false;var Fg=qh(91);$g(83,1,{},no);_.$=function(a){return Qn(this.a,a)};var Ig=qh(83);var oo=(zc(),Cc);var gwtOnLoad=gwtOnLoad=Vg;Tg(fh);Wg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();