function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='7E0CACC31B311CCA7A4701B748599301',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '7E0CACC31B311CCA7A4701B748599301';function o(){}
function $g(){}
function Wg(){}
function Wl(){}
function Nl(){}
function Sl(){}
function $l(){}
function Bb(){}
function Qc(){}
function Xc(){}
function Xj(){}
function lj(){}
function mj(){}
function Lk(){}
function cm(){}
function gm(){}
function zm(){}
function On(){}
function Pn(){}
function Eo(){}
function Vc(a){Uc()}
function fh(){fh=Wg}
function ii(){_h(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function fb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function ub(a){this.a=a}
function cc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function gc(a){this.a=a}
function kc(a){this.a=a}
function wh(a){this.a=a}
function Hh(a){this.a=a}
function Th(a){this.a=a}
function Yh(a){this.a=a}
function Zh(a){this.a=a}
function Xh(a){this.b=a}
function ki(a){this.c=a}
function jj(a){this.a=a}
function oj(a){this.a=a}
function Mk(a){this.a=a}
function Nk(a){this.a=a}
function Ok(a){this.a=a}
function Rk(a){this.a=a}
function Sk(a){this.a=a}
function Tk(a){this.a=a}
function al(a){this.a=a}
function bl(a){this.a=a}
function dl(a){this.a=a}
function el(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function El(a){this.a=a}
function Hl(a){this.a=a}
function Kl(a){this.a=a}
function Ll(a){this.a=a}
function Ml(a){this.a=a}
function km(a){this.a=a}
function lm(a){this.a=a}
function om(a){this.a=a}
function pm(a){this.a=a}
function rm(a){this.a=a}
function sm(a){this.a=a}
function Sm(a){this.a=a}
function Tm(a){this.a=a}
function an(a){this.a=a}
function cn(a){this.a=a}
function en(a){this.a=a}
function fn(a){this.a=a}
function gn(a){this.a=a}
function rn(a){this.a=a}
function sn(a){this.a=a}
function Dn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Hn(a){this.a=a}
function Qn(a){this.a=a}
function Rn(a){this.a=a}
function Sn(a){this.a=a}
function Pl(){this.a={}}
function Rl(){this.a={}}
function nm(){this.a={}}
function ym(){this.a={}}
function Bm(){this.a={}}
function Jo(){Sj(this.a)}
function Oo(){Uj(this.a)}
function ui(){this.a=Di()}
function Ii(){this.a=Di()}
function w(a){--a.e;D(a)}
function $(a){Kb((J(),a))}
function ab(a){Lb((J(),a))}
function db(a){Mb((J(),a))}
function Ao(a){Mi(this,a)}
function Do(a){Ah(this,a)}
function jn(a,b){Om(b,a)}
function Fj(a,b){Ej(a,b)}
function nj(a,b){dj(a.a,b)}
function C(a,b){yb(a.b,b)}
function oc(a,b){Ph(a.b,b)}
function hn(a,b){Vm(a.c,b)}
function kj(a,b){a.a=b}
function mb(a,b){a.b=Pi(b)}
function Hg(a){return a.e}
function Mo(){return this.e}
function xo(){return this.a}
function Co(){return this.b}
function Go(){return this.c}
function Qo(){return this.f}
function Ho(){return this.d<0}
function No(){return this.c<0}
function Po(){return this.f<0}
function zo(){return wj(this)}
function Dh(a,b){return a===b}
function hl(a,b){return a.g=b}
function ci(a,b){return a.a[b]}
function sj(a,b){a.splice(b,1)}
function mc(a,b,c){Oh(a.b,b,c)}
function Pk(a){nc(a.b);gb(a.a)}
function Ih(a){uc.call(this,a)}
function Vl(a){Jj.call(this,a)}
function Zl(a){Jj.call(this,a)}
function bm(a){Jj.call(this,a)}
function fm(a){Jj.call(this,a)}
function jm(a){Jj.call(this,a)}
function ll(a){Wm((Gm(),Dm),a)}
function Io(){return J(),J(),I}
function yo(a){return this===a}
function ih(a){hh(a);return a.k}
function Yc(a,b){return oh(a,b)}
function F(){this.b=new zb}
function pc(){this.b=new oi}
function J(){J=Wg;I=new F}
function wc(){wc=Wg;vc=new o}
function Nc(){Nc=Wg;Mc=new Qc}
function zi(){zi=Wg;yi=Bi()}
function Dc(){Dc=Wg;!!(Uc(),Tc)}
function Pg(){Ng==null&&(Ng=[])}
function Bh(){qc(this);this.G()}
function Bo(){return Rh(this.a)}
function Ko(){return Wj(this.a)}
function Rh(a){return a.a.b+a.b.b}
function X(a){J();Lb(a);a.e=-2}
function Eb(a){Fb(a);!a.d&&Ib(a)}
function Vb(a){bb(a.a);return a.e}
function Wb(a){bb(a.b);return a.g}
function Km(a){bb(a.b);return a.i}
function Lm(a){bb(a.a);return a.g}
function wn(a){bb(a.d);return a.f}
function cj(a,b){a.R(b);return a}
function Zj(a,b){a.ref=b;return a}
function dj(a,b){kj(a,cj(a.a,b))}
function Qi(a,b){while(a.cb(b));}
function Fi(a,b){return a.a.get(b)}
function bd(a){return new Array(a)}
function Di(){zi();return new yi}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function Yb(a){Ub(a,(bb(a.b),a.g))}
function Hk(a,b){th.call(this,a,b)}
function dc(a,b){this.a=a;this.b=b}
function lc(a,b){this.a=a;this.b=b}
function th(a,b){this.a=a;this.b=b}
function $h(a,b){this.a=a;this.b=b}
function gj(a,b){this.a=a;this.b=b}
function Nj(a,b){this.a=a;this.b=b}
function Oj(a,b){this.a=a;this.b=b}
function cl(a,b){this.a=a;this.b=b}
function Bl(a,b){this.a=a;this.b=b}
function Cl(a,b){this.a=a;this.b=b}
function Dl(a,b){this.a=a;this.b=b}
function Fl(a,b){this.a=a;this.b=b}
function Gl(a,b){this.a=a;this.b=b}
function qm(a,b){this.a=a;this.b=b}
function tm(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function bn(a,b){this.a=a;this.b=b}
function tn(a,b){this.a=a;this.b=b}
function qn(a,b){this.b=a;this.a=b}
function Mn(a,b){th.call(this,a,b)}
function qj(a,b,c){a.splice(b,0,c)}
function hj(a,b){a.B(xm(vm(b.e),b))}
function $j(a,b){a.href=b;return a}
function ik(a,b){a.value=b;return a}
function Fh(a,b){a.a+=''+b;return a}
function Qh(a){a.a=new ui;a.b=new Ii}
function L(a){a.b=0;a.d=0;a.c=false}
function Gb(a){return !a.d?a:Gb(a.d)}
function Nh(a){return !a?null:a.$()}
function qd(a){return a==null?null:a}
function Oi(a){return a!=null?r(a):0}
function vm(a){return wm(new ym,a)}
function nd(a){return typeof a===Vn}
function Kc(a){$wnd.clearTimeout(a)}
function Jk(a){nc(a.c);gb(a.b);S(a.a)}
function Zk(a){nc(a.c);gb(a.a);W(a.b)}
function Nm(a){Om(a,(bb(a.a),!a.g))}
function jc(a,b){hc(a,b,false);ab(a.d)}
function rj(a,b){pj(b,0,a,0,b.length)}
function _j(a,b){a.onClick=b;return a}
function dk(a,b){a.onBlur=b;return a}
function ek(a,b){a.onChange=b;return a}
function bk(a,b){a.checked=b;return a}
function _h(a){a.a=$c(je,Yn,1,0,5,1)}
function Q(){this.a=$c(je,Yn,1,100,5,1)}
function eb(a){this.c=new ii;this.b=a}
function Aj(){Aj=Wg;xj=new o;zj=new o}
function A(a,b,c){t(a,new G(b),c,null)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function Ch(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function V(a){return !(!!a&&1==(a.c&7))}
function wj(a){return a.$H||(a.$H=++vj)}
function pd(a){return typeof a==='string'}
function Fo(){return T((Gm(),Dm).b).a>0}
function jl(a,b){Bn((Gm(),Fm),b);ul(a,b)}
function Ej(a,b){for(var c in a){b(c)}}
function uj(b,c,d){try{b[c]=d}catch(a){}}
function lb(a){J();kb(a);nb(a,2,true)}
function bb(a){var b;Hb((J(),b=Cb,b),a)}
function rc(a,b){a.e=b;b!=null&&uj(b,io,a)}
function hh(a){if(a.k!=null){return}qh(a)}
function fk(a,b){a.onKeyDown=b;return a}
function ck(a,b){a.defaultValue=b;return a}
function ak(a){a.autoFocus=true;return a}
function uc(a){this.f=a;qc(this);this.G()}
function bj(a,b){Yi.call(this,a);this.a=b}
function pn(a){this.c=Pi(a);this.a=new pc}
function oi(){this.a=new ui;this.b=new Ii}
function u(a,b){return new qb(Pi(a),null,b)}
function md(a){return typeof a==='boolean'}
function $m(a){return xh(T(a.e).a-T(a.a).a)}
function Ol(a){return Kj((Ul(),Tl),a.a,null)}
function Ql(a){return Kj((Yl(),Xl),a.a,null)}
function mm(a){return Kj((am(),_l),a.a,null)}
function Ec(a,b,c){return a.apply(b,c);var d}
function ic(a,b){oc(b.C(),a);ld(b,11)&&b.v()}
function Mi(a,b){while(a.W()){nj(b,a.X())}}
function wi(a,b){var c;c=a[no];c.call(a,b)}
function Mm(a){nc(a.c);W(a.d);W(a.b);W(a.a)}
function lh(a){var b;b=kh(a);sh(a,b);return b}
function nh(){var a;a=kh(null);a.e=2;return a}
function qc(a){a.g&&a.e!==ho&&a.G();return a}
function jk(a,b){a.onDoubleClick=b;return a}
function ai(a,b){a.a[a.a.length]=b;return true}
function wm(a,b){Pi(b);a.a['key']=b;return a}
function Li(a,b,c){this.a=a;this.b=b;this.c=c}
function dn(a,b){this.a=a;this.c=b;this.b=false}
function jb(a,b){Z(b,a);b.c.a.length>0||(b.a=4)}
function Rb(a,b){a.i&&b.preventDefault();ac(a)}
function Yk(a,b){var c;c=b.target;$k(a,c.value)}
function Vh(a){var b;b=a.a.X();a.b=Uh(a);return b}
function Si(a){if(!a.d){a.d=a.b.Q();a.c=a.b.S()}}
function Ab(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function ej(a,b,c){if(a.a.db(c)){a.b=true;b.B(c)}}
function Ei(a,b){return !(a.a.get(b)===undefined)}
function Am(a){return Kj((im(),hm),a.a,null)}
function Zm(a){return fh(),0==T(a.e).a?true:false}
function ad(a){return Array.isArray(a)&&a.xb===$g}
function kd(a){return !Array.isArray(a)&&a.xb===$g}
function P(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function un(a){return Dh(wo,a)||Dh(to,a)||Dh('',a)}
function _i(a){Xi(a);return new bj(a,new ij(a.a))}
function Sh(a,b){if(b){return Lh(a.a,b)}return false}
function ei(a,b){var c;c=a.a[b];sj(a.a,b);return c}
function gi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Pi(a){if(a==null){throw Hg(new Bh)}return a}
function Dj(){if(yj==256){xj=zj;zj=new o;yj=0}++yj}
function Uc(){Uc=Wg;var a;!Wc();a=new Xc;Tc=a}
function bh(){bh=Wg;ah=$wnd.window.document}
function zh(){zh=Wg;yh=$c(fe,Yn,33,256,0,1)}
function Ri(a,b){this.e=a;this.d=(b&64)!=0?b|Wn:b}
function $k(a,b){var c;c=a.e;if(b!=c){a.e=b;ab(a.b)}}
function vl(a,b){var c;c=a.i;if(b!=c){a.i=b;ab(a.a)}}
function Om(a,b){var c;c=a.g;if(b!=c){a.g=b;ab(a.a)}}
function ol(a){nc(a.e);gb(a.b);S(a.d);W(a.c);W(a.a)}
function Wi(a){if(!a.b){Xi(a);a.c=true}else{Wi(a.b)}}
function Yi(a){if(!a){this.b=null;new ii}else{this.b=a}}
function ij(a){Ri.call(this,a.bb(),a.ab()&-6);this.a=a}
function Gj(a,b){null!=b&&a.ib(b,a.o.props,true);a.fb()}
function Vj(a){Tj(a);return ld(a,11)&&a.w()?null:a.nb()}
function $i(a,b){Xi(a);return new bj(a,new fj(b,a.a))}
function Mg(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function Sj(a){if(!a.k){a.k=true;a.n||a.o.forceUpdate()}}
function xb(a){while(true){if(!vb(a)&&!wb(a)){break}}}
function cb(a){var b;J();!!Cb&&!!Cb.e&&Hb((b=Cb,b),a)}
function $b(a,b){var c;c=a.e;if(b!=c){a.e=Pi(b);ab(a.a)}}
function _b(a,b){var c;c=a.g;if(b!=c){a.g=Pi(b);ab(a.b)}}
function Pm(a,b){var c;c=a.i;if(b!=c){a.i=Pi(b);ab(a.b)}}
function mh(a,b){var c;c=kh(a);sh(a,c);c.e=b?8:0;return c}
function hk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ph(a){if(a.O()){return null}var b=a.j;return Sg[b]}
function pl(a,b,c,d){return fh(),ml(a,b,c,d)?true:false}
function ni(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function xm(a,b){a.a['a']=b;return Kj((em(),dm),a.a,null)}
function Nn(){Ln();return cd(Yc(vg,1),Yn,37,0,[In,Kn,Jn])}
function Mh(a,b){return b===a?'(this Map)':b==null?ko:Zg(b)}
function sc(a,b){var c;c=ih(a.vb);return b==null?c:c+': '+b}
function gl(a,b){var c;if(T(a.d)){c=b.target;vl(a,c.value)}}
function Nb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function Al(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function Ti(a,b){this.b=a;this.a=(b&4096)==0?b|64|Wn:b}
function yb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],Pi(b))}
function Vk(a,b){if(13==b.keyCode){b.preventDefault();Wk(a)}}
function Db(a){if(a.e){2==(a.e.c&7)||nb(a.e,4,true);kb(a.e)}}
function xn(a){nc(a.g);gb(a.e);gb(a.a);S(a.b);S(a.c);W(a.d)}
function vh(a){this.f=!a?null:sc(a,a.F());qc(this);this.G()}
function Ah(a,b){var c,d;for(d=a.Q();d.W();){c=d.X();b.B(c)}}
function mn(a,b){var c;aj(Xm(a.c),(c=new ii,c)).P(new Rn(b))}
function il(a,b,c){27==c.which?rl(a,b):13==c.which&&tl(a,b)}
function Mj(a,b,c){a[c]===undefined&&(a[c]=b[c],undefined)}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Xi(a){if(a.b){Xi(a.b)}else if(a.c){throw Hg(new uh)}}
function Yg(a){function b(){}
;b.prototype=a||{};return new b}
function Ob(a,b){Cb=new Nb(Cb,b);a.d=false;Db(Cb);return Cb}
function gk(a){a.placeholder='What needs to be done?';return a}
function Qb(a,b){a.j=b;Dh(b,(bb(a.a),a.e))&&_b(a,b);Sb(b);ac(a)}
function hb(a){var b;b=(J(),J(),I);yb(b.b,a);0!=(a.c&co)&&D(b)}
function oh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function qi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ug(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ri(a,b){var c;return pi(b,qi(a,b==null?0:(c=r(b),c|0)))}
function Xm(a){bb(a.d);return new bj(null,new Ti(new Yh(a.i),0))}
function ji(a){_h(this);rj(this.a,Kh(a,$c(je,Yn,1,Rh(a.a),5,1)))}
function im(){im=Wg;var a;hm=(a=Xg(gm.prototype.jb,gm,[]),a)}
function em(){em=Wg;var a;dm=(a=Xg(cm.prototype.jb,cm,[]),a)}
function am(){am=Wg;var a;_l=(a=Xg($l.prototype.jb,$l,[]),a)}
function Ul(){Ul=Wg;var a;Tl=(a=Xg(Sl.prototype.jb,Sl,[]),a)}
function Yl(){Yl=Wg;var a;Xl=(a=Xg(Wl.prototype.jb,Wl,[]),a)}
function zn(a){var b;b=(bb(a.d),a.f);!!b&&!!b&&b.f<0&&Bn(a,null)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function dh(a,b,c,d){a.addEventListener(b,c,(fh(),d?true:false))}
function eh(a,b,c,d){a.removeEventListener(b,c,(fh(),d?true:false))}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&Wn)?Wn:8192)|0|0,b)}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&Wn)?Wn:8192)|0|0,b)}
function Y(a,b){var c,d;ai(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Bn(a,b){var c;c=a.f;if(!(b==c||!!b&&Jm(b,c))){a.f=b;ab(a.d)}}
function N(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Ui(a,b){!a.a?(a.a=new Hh(a.d)):Fh(a.a,a.b);Fh(a.a,b);return a}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Zi(a){var b;Wi(a);b=0;while(a.a.cb(new mj)){b=Ig(b,1)}return b}
function aj(a,b){var c;Wi(a);c=new lj;c.a=b;a.a.V(new oj(c));return c.a}
function ln(a){var b;aj($i(Xm(a.c),new Pn),(b=new ii,b)).P(new Qn(a.c))}
function Gm(){Gm=Wg;Cm=new bc;Dm=new _m;Em=new pn(Dm);Fm=new Cn(Dm,Cm)}
function vi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Ji(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Vi(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function fj(a,b){Ri.call(this,b.bb(),b.ab()&-16449);this.a=a;this.c=b}
function Lo(){return wn((Gm(),Fm))==(cb(this.c),this.o.props['a'])}
function Ph(a,b){return pd(b)?b==null?ti(a.a,null):Hi(a.b,b):ti(a.a,b)}
function vn(a,b){return (Ln(),Jn)==a||(In==a?(bb(b.a),!b.g):(bb(b.a),b.g))}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Lj(a,b,c){!Dh(c,'key')&&!Dh(c,'ref')&&(a[c]=b[c],undefined)}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function Jm(a,b){var c;if(ld(b,50)){c=b;return a.e==c.e}else{return false}}
function Wj(a){var b;a.k=false;if(a.lb()){return null}else{b=a.hb();return b}}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Im(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Sm(a)),bo,null)}}
function yn(a){var b,c;return b=T(a.b),aj($i(Xm(a.k),new Sn(b)),(c=new ii,c))}
function bi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.B(c)}}
function fi(a,b){var c;c=di(a,b,0);if(c==-1){return false}sj(a.a,c);return true}
function di(a,b,c){for(;c<a.a.length;++c){if(ni(b,a.a[c])){return c}}return -1}
function Ki(a){if(a.a.c!=a.c){return Fi(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{xb(a.b)}finally{a.c=false}}}}
function W(a){if(-2!=a.e){t((J(),J(),I),new G(new fb(a)),0,null);!!a.b&&gb(a.b)}}
function S(a){if(!a.a){a.a=true;a.g=null;a.b=null;W(a.d);2==(a.e.c&7)||gb(a.e)}}
function Xb(a){eh((bh(),$wnd.window.window),fo,a.f,false);nc(a.c);W(a.b);W(a.a)}
function Wh(a){this.d=a;this.c=new Ji(this.d.b);this.a=this.c;this.b=Uh(this)}
function Oh(a,b,c){return pd(b)?b==null?si(a.a,null,c):Gi(a.b,b,c):si(a.a,b,c)}
function tj(a,b){return Zc(b)!=10&&cd(q(b),b.wb,b.__elementTypeId$,Zc(b),a),a}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===Un||typeof a==='function')&&!(a.xb===$g)}
function ql(a){return fh(),wn((Gm(),Fm))==(cb(a.c),a.o.props['a'])?true:false}
function Hj(a,b){var c;c=null!=b&&a.ib(a.o.props,b,false);c||(a.p=false);return c}
function Ij(a,b){var c;if(b){c=a.p;a.p=false;return !c}else{a.p=true;return true}}
function vb(a){var b;if(0==P(a.c)){return false}else{b=O(a.c);!!b&&b.v();return true}}
function sh(a,b){var c;if(!a){return}b.j=a;var d=ph(b);if(!d){Sg[a]=[b];return}d.vb=b}
function Xg(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function kh(a){var b;b=new jh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Gg(a){var b;if(ld(a,4)){return a}b=a&&a[io];if(!b){b=new yc(a);Vc(b)}return b}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Hb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;ai((!a.b&&(a.b=new ii),a.b),b)}}}
function Jb(a,b){var c;if(!a.c){c=Gb(a);!c.c&&(c.c=new ii);a.c=c.c}b.d=true;ai(a.c,Pi(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);N(a,Pi(b))}
function Hi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{wi(a.a,b);--a.b}return c}
function li(a){var b,c,d;d=0;for(c=new Wh(a.a);c.b;){b=Vh(c);d=d+(b?r(b):0);d=d|0}return d}
function kb(a){var b,c;for(c=new ki(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Uk(a){var b;b=Eh((bb(a.b),a.e));if(b.length>0){hn((Gm(),Em),b);$k(a,'')}}
function Uj(a){var b;b=(++a.mb().e,new Bb);try{a.n=true;ld(a,11)&&a.v()}finally{Ab(b)}}
function Pb(){var a;try{Eb(Cb);J()}finally{a=Cb.d;!a&&((J(),J(),I).d=true);Cb=Cb.d}}
function Og(){Pg();var a=Ng;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function uh(){uc.call(this,"Stream already terminated, can't be modified or used")}
function Ln(){Ln=Wg;In=new Mn('ACTIVE',0);Kn=new Mn('COMPLETED',1);Jn=new Mn('ALL',2)}
function Qk(){++Qj;this.b=new pc;this.a=new qb(null,Pi((J(),new Rk(this))),qo);D((null,I))}
function Jl(){++Qj;this.b=new pc;this.a=new qb(null,Pi((J(),new Kl(this))),qo);D((null,I))}
function _g(){Gm();$wnd.ReactDOM.render(Am(new Bm),(bh(),ah).getElementById('todoapp'),null)}
function Jj(a){$wnd.React.Component.call(this,a);this.a=this.kb();this.a.o=Pi(this);this.a.gb()}
function Ym(a){Ah(new Yh(a.i),new kc(a));Qh(a.i);nc(a.f);S(a.c);S(a.e);S(a.a);S(a.b);W(a.d)}
function Um(a,b,c){var d;d=new Rm(b,c);mc(d.c,a,new lc(a,d));Oh(a.i,xh(d.e),d);ab(a.d);return d}
function Jh(a,b){var c,d;for(d=new Wh(b.a);d.b;){c=Vh(d);if(!Sh(a,c)){return false}}return true}
function pi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(ni(a,c.Z())){return c}}return null}
function Lg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=lo;d=1048575}c=rd(e/co);b=rd(e-c*co);return dd(b,c,d)}
function Jg(a){var b;b=a.h;if(b==0){return a.l+a.m*co}if(b==1048575){return a.l+a.m*co-lo}return a}
function Uh(a){if(a.a.W()){return true}if(a.a!=a.c){return false}a.a=new vi(a.d.a);return a.a.W()}
function T(a){bb(a.d);ob(a.e)&&ib(a.e);if(a.b){if(ld(a.b,5)){throw Hg(a.b)}else{throw Hg(a.b)}}return a.g}
function ml(a,b,c,d){var e,f;e=false;f=Ij(a,d);if(!(b['a']===c['a'])){f&&ab(a.c);e=true}return e||a.k}
function hc(a,b,c){var d;d=Ph(a.i,b?xh(b.e):null);if(null!=d){oc(b.c,a);c&&!!b&&Im(b);ab(a.d)}}
function Gi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Z(a,b){var c,d;d=a.c;fi(d,b);d.a.length==0&&!!a.b&&$n!=(a.b.c&_n)&&(a.d||Jb((J(),c=Cb,c),a))}
function An(a){var b;b=Vb(a.j);Dh(wo,b)||Dh(to,b)||Dh('',b)?Ub(a.j,b):un(Wb(a.j))?Zb(a.j):Ub(a.j,'')}
function gb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new tb(a)),bo,null);!!a.a&&S(a.a);a.c=a.c&-8|1}}
function Tj(a){if(!Rj){Rj=(++a.mb().e,new Bb);$wnd.Promise.resolve(null).then(Xg(Xj.prototype.I,Xj,[]))}}
function cd(a,b,c,d,e){e.vb=a;e.wb=b;e.xb=$g;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Rg(a,b){typeof window===Un&&typeof window['$gwt']===Un&&(window['$gwt'][a]=b)}
function jh(){this.g=gh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function U(a,b){this.c=Pi(a);this.f=null;this.g=null;this.e=new rb(this,b);this.d=new eb(this.e);$n==(b&_n)&&hb(this.e)}
function yc(a){wc();qc(this);this.e=a;a!=null&&uj(a,io,this);this.f=a==null?ko:Zg(a);this.a='';this.b=a;this.a=''}
function _k(){var a;++Qj;this.c=new pc;this.b=(a=new eb((J(),null)),a);this.a=new qb(null,Pi(new dl(this)),qo);D((null,I))}
function Kk(){++Qj;this.c=new pc;this.a=new U((J(),new Lk),136486912);this.b=new qb(null,Pi(new Nk(this)),qo);D((null,I))}
function pb(a,b,c,d){this.b=new ii;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&hb(this)}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function Tb(a){var b,c;c=(b=(bh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));$b(a,c);Dh(a.j,c)&&_b(a,c)}
function kl(a,b){var c;c=(bb(a.a),a.i);if(null!=c&&c.length!=0){nn((Gm(),b),c);Bn(Fm,null);vl(a,c)}else{Wm((Gm(),Dm),b)}}
function Ig(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<lo){return c}}return Jg(ed(nd(a)?Lg(a):a,nd(b)?Lg(b):b))}
function xh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(zh(),yh)[b];!c&&(c=yh[b]=new wh(a));return c}return new wh(a)}
function Zg(a){var b;if(Array.isArray(a)&&a.xb===$g){return ih(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Cj(a){Aj();var b,c,d;c=':'+a;d=zj[c];if(d!=null){return rd(d)}d=xj[c];b=d==null?Bj(a):rd(d);Dj();zj[c]=b;return b}
function mi(a){var b,c,d;d=1;for(c=new ki(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function nc(a){var b,c;if(!a.a){for(c=new ki(new ji(new Yh(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.A()}a.a=true}}
function fl(a){var b;b=T(a.d);if(!a.j&&b){a.j=true;ul(a,(cb(a.c),a.o.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function q(a){return pd(a)?me:nd(a)?be:md(a)?_d:kd(a)?a.vb:ad(a)?a.vb:a.vb||Array.isArray(a)&&Yc(Ud,1)||Ud}
function p(a,b){return pd(a)?Dh(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.q(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function r(a){return pd(a)?Cj(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.s():ad(a)?wj(a):!!a&&!!a.hashCode?a.hashCode():wj(a)}
function Ik(){Gk();return cd(Yc(af,1),Yn,10,0,[kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk])}
function zb(){this.c=new Q;this.d=$c(vd,Yn,22,5,0,1);this.d[0]=new Q;this.d[1]=new Q;this.d[2]=new Q;this.d[3]=new Q;this.d[4]=new Q}
function rh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function hi(a,b){var c,d;d=a.a.length;b.length<d&&(b=tj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function O(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Pj(a,b,c,d,e){var f;f=new $wnd.Object;f.$$typeof=$wnd.React.Element;f.type=Pi(a);f.key=b;f.ref=c;f.props=Pi(d);f._owner=e;return f}
function Yj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.wb){return !!a.wb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function qb(a,b,c){pb.call(this,null,a,b,c|(!a?262144:$n)|(a?Wn:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:co)|(0!=(c&229376)?0:98304)|0|0|0)}
function Mb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&nb(b,5,true)}}}
function Lb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ki(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&nb(b,6,true)}}}
function Kb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?nb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Eh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ib(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=ei(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&nb(c.b,3,true);++b}}}return b}
function Rm(a,b){var c,d,e;this.i=Pi(a);this.g=b;this.e=Hm++;this.d=(d=new eb((J(),null)),d);this.c=new pc;this.b=(e=new eb(null),e);this.a=(c=new eb(null),c)}
function Zb(b){var c;try{A((J(),J(),I),new ec(b),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){c=a;throw Hg(c)}else if(ld(a,4)){c=a;throw Hg(new vh(c))}else throw Hg(a)}}
function ac(b){var c;try{A((J(),J(),I),new fc(b),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){c=a;throw Hg(c)}else if(ld(a,4)){c=a;throw Hg(new vh(c))}else throw Hg(a)}}
function Wk(b){var c;try{A((J(),J(),I),new bl(b),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){c=a;throw Hg(c)}else if(ld(a,4)){c=a;throw Hg(new vh(c))}else throw Hg(a)}}
function Qm(b){var c;try{A((J(),J(),I),new Tm(b),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){c=a;throw Hg(c)}else if(ld(a,4)){c=a;throw Hg(new vh(c))}else throw Hg(a)}}
function kn(b){var c;try{A((J(),J(),I),new rn(b),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){c=a;throw Hg(c)}else if(ld(a,4)){c=a;throw Hg(new vh(c))}else throw Hg(a)}}
function nn(b,c){var d;try{A((J(),J(),I),new qn(b,c),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function on(b,c){var d;try{A((J(),J(),I),new tn(b,c),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function Wm(b,c){var d;try{A((J(),J(),I),new bn(b,c),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function Xk(b,c){var d;try{A((J(),J(),I),new cl(b,c),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function nl(b,c){var d;try{A((J(),J(),I),new Gl(b,c),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function rl(b,c){var d;try{A((J(),J(),I),new Fl(b,c),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function sl(b,c){var d;try{A((J(),J(),I),new Dl(b,c),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function tl(b,c){var d;try{A((J(),J(),I),new Cl(b,c),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function ul(b,c){var d;try{A((J(),J(),I),new Bl(b,c),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function Ub(b,c){var d;try{A((J(),J(),I),new dc(b,c),75505664)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function Vm(b,c){var d;try{return t((J(),J(),I),new dn(b,c),go,null)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){d=a;throw Hg(d)}else if(ld(a,4)){d=a;throw Hg(new vh(d))}else throw Hg(a)}}
function Qg(b,c,d,e){Pg();var f=Ng;$moduleName=c;$moduleBase=d;Fg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Tn(g)()}catch(a){b(c,a)}}else{Tn(g)()}}
function rb(a,b){pb.call(this,a,new sb(a),null,b|($n==(b&_n)?0:524288)|(0!=(b&6291456)?0:$n==(b&_n)?co:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function Bi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ci()}}
function wl(){var a,b;++Qj;this.e=new pc;this.c=(b=new eb((J(),null)),b);this.a=(a=new eb(null),a);this.d=new U(new El(this),136486912);this.b=new qb(null,Pi(new Hl(this)),qo);D((null,I))}
function _m(){var a;this.i=new oi;this.f=new pc;this.d=(a=new eb((J(),null)),a);this.c=new U(new cn(this),vo);this.e=new U(new en(this),vo);this.a=new U(new fn(this),vo);this.b=new U(new gn(this),vo)}
function Kh(a,b){var c,d,e,f,g;g=Rh(a.a);b.length<g&&(b=tj(new Array(g),b));e=(f=new Wh((new Th(a.a)).a),new Zh(f));for(d=0;d<g;++d){b[d]=(c=Vh(e.a),c.$())}b.length>g&&(b[g]=null);return b}
function Tg(){Sg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].yb()&&(c=Rc(c,g)):g[0].yb()}catch(a){a=Gg(a);if(ld(a,4)){d=a;Dc();Jc(ld(d,40)?d.H():d)}else throw Hg(a)}}return c}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?ko:od(b)?b==null?null:b.name:pd(b)?'String':ih(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.g;try{d=b.c.u();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;$(b.d)}}catch(a){a=Gg(a);if(ld(a,12)){c=a;if(!b.b){b.g=null;b.b=c;$(b.d)}throw Hg(c)}else throw Hg(a)}}
function si(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=pi(b,e);if(f){return f._(c)}}e[e.length]=new $h(b,c);++a.b;return null}
function pj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Bj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ch(a,c++)}b=b|0;return b}
function M(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=$c(je,Yn,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=Wn==(d&Wn)?c.u():c.u()}else{Ob(b,e);try{g=Wn==(d&Wn)?c.u():c.u()}finally{Pb()}}return g}catch(a){a=Gg(a);if(ld(a,4)){f=a;throw Hg(f)}else throw Hg(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=Wn==(d&Wn)?(c.a.A(),null):(c.a.A(),null)}else{Ob(b,e);try{g=Wn==(d&Wn)?(c.a.A(),null):(c.a.A(),null)}finally{Pb()}}return g}catch(a){a=Gg(a);if(ld(a,4)){f=a;throw Hg(f)}else throw Hg(a)}finally{D(b)}}
function Sb(a){var b;if(0==a.length){b=(bh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',ah.title,b)}else{(bh(),$wnd.window.window).location.hash=a}}
function ib(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.A()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=Gg(a);if(ld(a,4)){J()}else throw Hg(a)}}}
function ti(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(ni(b,e.Z())){if(d.length==1){d.length=0;wi(a.a,g)}else{d.splice(h,1)}--a.b;return e.$()}}return null}
function Cn(a,b){var c;this.k=Pi(a);this.j=Pi(b);this.g=new pc;this.d=(c=new eb((J(),null)),c);this.b=new U(new En(this),vo);this.c=new U(new Fn(this),vo);this.e=u(new Gn(this),413155328);this.a=u(new Hn(this),681590784);D((null,I))}
function Vg(a,b,c){var d=Sg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Sg[b]),Yg(h));_.wb=c;!b&&(_.xb=$g);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.vb=f)}
function qh(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=rh('.',[c,rh('$',d)]);a.b=rh('.',[c,rh('.',d)]);a.i=d[d.length-1]}
function bc(){var a,b,c;this.f=new gc(this);this.c=new pc;this.b=(c=new eb((J(),null)),c);this.a=(b=new eb(null),b);dh((bh(),$wnd.window.window),fo,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function Lh(a,b){var c,d,e;c=b.Z();e=b.$();d=pd(c)?c==null?Nh(ri(a.a,null)):Fi(a.b,c):Nh(ri(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!ri(a.a,null):Ei(a.b,c):!!ri(a.a,c))){return false}return true}
function ob(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ki(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Gg(a);if(!ld(a,4))throw Hg(a)}if(6==(b.c&7)){return true}}}}}kb(b);return false}
function Ai(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function nb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){db(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}bi(a.b,new ub(a));a.b.a=$c(je,Yn,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function wb(a){var b,c,d,e,f,g,h,i;d=P(a.d[0]);c=P(a.d[1]);g=P(a.d[2]);e=P(a.d[3]);f=P(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;L(a.d[0]);L(a.d[1]);L(a.d[2]);L(a.d[3]);L(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=O(b);h.c&=-513;ib(h);return true}
function Kj(a,b,c){var d,e,f,g,h;d={};f=null;g=null;if(null!=b){f='key' in b?''+b['key']:null;g='ref' in b?b['ref']:null;Fj(b,Xg(Nj.prototype.eb,Nj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));h=a;e=h['defaultProps'];null!=e&&Fj(e,Xg(Oj.prototype.eb,Oj,[d,e]));return Pj(a,f,g,d,$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current)}
function Gk(){Gk=Wg;kk=new Hk(oo,0);lk=new Hk('checkbox',1);mk=new Hk('color',2);nk=new Hk('date',3);ok=new Hk('datetime',4);pk=new Hk('email',5);qk=new Hk('file',6);rk=new Hk('hidden',7);sk=new Hk('image',8);tk=new Hk('month',9);uk=new Hk(Vn,10);vk=new Hk('password',11);wk=new Hk('radio',12);xk=new Hk('range',13);yk=new Hk('reset',14);zk=new Hk('search',15);Ak=new Hk('submit',16);Bk=new Hk('tel',17);Ck=new Hk('text',18);Dk=new Hk('time',19);Ek=new Hk('url',20);Fk=new Hk('week',21)}
function Fb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ci(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&gi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Z(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&nb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ci(a.b,g);if(-1==k.e){k.e=0;Y(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ei(a.b,g)}e&&mb(a.e,a.b)}else{e&&mb(a.e,new ii)}if(V(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&$n!=(b.e.c&_n)&&Jb(a,k)}}
function Ci(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[no]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ai()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[no]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Un='object',Vn='number',Wn=16384,Xn={15:1},Yn={3:1,6:1},Zn={11:1},$n=1048576,_n=1835008,ao={8:1},bo=67108864,co=4194304,eo={30:1},fo='hashchange',go=142614528,ho='__noinit__',io='__java$exception',jo={3:1,12:1,5:1,4:1},ko='null',lo=17592186044416,mo={44:1},no='delete',oo='button',po='selected',qo=1478635520,ro={11:1,24:1},so='input',to='completed',uo='header',vo=136421376,wo='active';var _,Sg,Ng,Fg=-1;Tg();Vg(1,null,{},o);_.q=yo;_.r=function(){return this.vb};_.s=zo;_.t=function(){var a;return ih(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.q(a)};_.hashCode=function(){return this.s()};_.toString=function(){return this.t()};var fd,gd,hd;Vg(52,1,{},jh);_.J=function(a){var b;b=new jh;b.e=4;a>1?(b.c=oh(this,a-1)):(b.c=this);return b};_.K=function(){hh(this);return this.b};_.L=function(){return ih(this)};_.M=function(){hh(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.t=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(hh(this),this.k)};_.e=0;_.g=0;var gh=1;var je=lh(1);var ae=lh(52);Vg(76,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var ud=lh(76);Vg(16,1,Xn,G);_.u=function(){return this.a.A(),null};var sd=lh(16);Vg(77,1,{},H);var td=lh(77);var I;Vg(22,1,{22:1},Q);_.b=0;_.c=false;_.d=0;var vd=lh(22);Vg(204,1,Zn);_.t=function(){var a;return ih(this.vb)+'@'+(a=r(this)>>>0,a.toString(16))};var xd=lh(204);Vg(21,204,Zn,U);_.v=function(){S(this)};_.w=xo;_.a=false;var wd=lh(21);Vg(17,204,{11:1,17:1},eb);_.v=function(){W(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=lh(17);Vg(116,1,ao,fb);_.A=function(){X(this.a)};var yd=lh(116);Vg(19,204,{11:1,19:1},qb,rb);_.v=function(){gb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Dd=lh(19);Vg(117,1,eo,sb);_.A=function(){R(this.a)};var Ad=lh(117);Vg(118,1,ao,tb);_.A=function(){lb(this.a)};var Bd=lh(118);Vg(119,1,{},ub);_.B=function(a){jb(this.a,a)};var Cd=lh(119);Vg(121,1,{},zb);_.a=0;_.b=100;_.e=0;var Ed=lh(121);Vg(62,1,Zn,Bb);_.v=function(){Ab(this)};_.w=xo;_.a=false;var Fd=lh(62);Vg(135,1,{},Nb);_.t=function(){var a;return hh(Gd),Gd.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.a=0;var Cb;var Gd=lh(135);Vg(46,1,{46:1});_.e='';_.g='';_.i=true;_.j='';var Nd=lh(46);Vg(101,46,{11:1,46:1,24:1},bc);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new cc(this)),bo,null)}};_.q=yo;_.C=Go;_.s=zo;_.w=Ho;_.t=function(){var a;return hh(Ld),Ld.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.d=0;var Ld=lh(101);Vg(102,1,ao,cc);_.A=function(){Xb(this.a)};var Hd=lh(102);Vg(103,1,ao,dc);_.A=function(){Qb(this.a,this.b)};var Id=lh(103);Vg(104,1,ao,ec);_.A=function(){Yb(this.a)};var Jd=lh(104);Vg(105,1,ao,fc);_.A=function(){Tb(this.a)};var Kd=lh(105);Vg(78,1,{},gc);_.handleEvent=function(a){Rb(this.a,a)};var Md=lh(78);Vg(106,1,{});var Qd=lh(106);Vg(79,1,{},kc);_.B=function(a){ic(this.a,a)};var Od=lh(79);Vg(80,1,ao,lc);_.A=function(){jc(this.a,this.b)};var Pd=lh(80);Vg(107,106,{});var Rd=lh(107);Vg(18,1,Zn,pc);_.v=function(){nc(this)};_.w=xo;_.a=false;var Sd=lh(18);Vg(4,1,{3:1,4:1});_.D=function(a){return new Error(a)};_.F=Qo;_.G=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=ih(this.vb),c==null?a:a+': '+c);rc(this,tc(this.D(b)));Vc(this)};_.t=function(){return sc(this,this.F())};_.e=ho;_.g=true;var ne=lh(4);Vg(12,4,{3:1,12:1,4:1});var de=lh(12);Vg(5,12,jo);var ke=lh(5);Vg(53,5,jo);var ge=lh(53);Vg(71,53,jo);var Wd=lh(71);Vg(40,71,{40:1,3:1,12:1,5:1,4:1},yc);_.F=function(){xc(this);return this.c};_.H=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Td=lh(40);var Ud=lh(0);Vg(190,1,{});var Vd=lh(190);var Ac=0,Bc=0,Cc=-1;Vg(100,190,{},Qc);var Mc;var Xd=lh(100);var Tc;Vg(201,1,{});var Zd=lh(201);Vg(72,201,{},Xc);var Yd=lh(72);var ah;Vg(69,1,{66:1});_.t=xo;var $d=lh(69);fd={3:1,67:1,32:1};var _d=lh(67);Vg(45,1,{3:1,45:1});var ie=lh(45);gd={3:1,32:1,45:1};var be=lh(200);Vg(36,1,{3:1,32:1,36:1});_.q=yo;_.s=zo;_.t=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ce=lh(36);Vg(9,5,jo,uh,vh);var ee=lh(9);Vg(33,45,{3:1,32:1,33:1,45:1},wh);_.q=function(a){return ld(a,33)&&a.a==this.a};_.s=xo;_.t=function(){return ''+this.a};_.a=0;var fe=lh(33);var yh;Vg(261,1,{});Vg(74,53,jo,Bh);_.D=function(a){return new TypeError(a)};var he=lh(74);hd={3:1,66:1,32:1,2:1};var me=lh(2);Vg(70,69,{66:1},Hh);var le=lh(70);Vg(265,1,{});Vg(55,5,jo,Ih);var oe=lh(55);Vg(202,1,{43:1});_.P=Do;_.T=function(){return new Ti(this,0)};_.U=function(){return new bj(null,this.T())};_.R=function(a){throw Hg(new Ih('Add not supported on this collection'))};_.t=function(){var a,b,c;c=new Vi('[',']');for(b=this.Q();b.W();){a=b.X();Ui(c,a===this?'(this Collection)':a==null?ko:Zg(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=lh(202);Vg(205,1,{188:1});_.q=function(a){var b,c,d;if(a===this){return true}if(!ld(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Wh((new Th(d)).a);c.b;){b=Vh(c);if(!Lh(this,b)){return false}}return true};_.s=function(){return li(new Th(this))};_.t=function(){var a,b,c;c=new Vi('{','}');for(b=new Wh((new Th(this)).a);b.b;){a=Vh(b);Ui(c,Mh(this,a.Z())+'='+Mh(this,a.$()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=lh(205);Vg(122,205,{188:1});var se=lh(122);Vg(206,202,{43:1,212:1});_.T=function(){return new Ti(this,1)};_.q=function(a){var b;if(a===this){return true}if(!ld(a,27)){return false}b=a;if(Rh(b.a)!=this.S()){return false}return Jh(this,b)};_.s=function(){return li(this)};var Be=lh(206);Vg(27,206,{27:1,43:1,212:1},Th);_.Q=function(){return new Wh(this.a)};_.S=Bo;var re=lh(27);Vg(28,1,{},Wh);_.V=Ao;_.X=function(){return Vh(this)};_.W=Co;_.b=false;var qe=lh(28);Vg(203,202,{43:1,210:1});_.T=function(){return new Ti(this,16)};_.Y=function(a,b){throw Hg(new Ih('Add not supported on this list'))};_.R=function(a){this.Y(this.S(),a);return true};_.q=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.S()!=f.a.length){return false}e=new ki(f);for(c=new ki(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.s=function(){return mi(this)};_.Q=function(){return new Xh(this)};var ue=lh(203);Vg(98,1,{},Xh);_.V=Ao;_.W=function(){return this.a<this.b.a.length};_.X=function(){return ci(this.b,this.a++)};_.a=0;var te=lh(98);Vg(48,202,{43:1},Yh);_.Q=function(){var a;return a=new Wh((new Th(this.a)).a),new Zh(a)};_.S=Bo;var we=lh(48);Vg(57,1,{},Zh);_.V=Ao;_.W=function(){return this.a.b};_.X=function(){var a;return a=Vh(this.a),a.$()};var ve=lh(57);Vg(123,1,mo);_.q=function(a){var b;if(!ld(a,44)){return false}b=a;return ni(this.a,b.Z())&&ni(this.b,b.$())};_.Z=xo;_.$=Co;_.s=function(){return Oi(this.a)^Oi(this.b)};_._=function(a){var b;b=this.b;this.b=a;return b};_.t=function(){return this.a+'='+this.b};var xe=lh(123);Vg(124,123,mo,$h);var ye=lh(124);Vg(207,1,mo);_.q=function(a){var b;if(!ld(a,44)){return false}b=a;return ni(this.b.value[0],b.Z())&&ni(Ki(this),b.$())};_.s=function(){return Oi(this.b.value[0])^Oi(Ki(this))};_.t=function(){return this.b.value[0]+'='+Ki(this)};var ze=lh(207);Vg(14,203,{3:1,14:1,43:1,210:1},ii,ji);_.Y=function(a,b){qj(this.a,a,b)};_.R=function(a){return ai(this,a)};_.P=function(a){bi(this,a)};_.Q=function(){return new ki(this)};_.S=function(){return this.a.length};var De=lh(14);Vg(20,1,{},ki);_.V=Ao;_.W=function(){return this.a<this.c.a.length};_.X=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=lh(20);Vg(41,122,{3:1,41:1,188:1},oi);var Ee=lh(41);Vg(60,1,{},ui);_.P=Do;_.Q=function(){return new vi(this)};_.b=0;var Ge=lh(60);Vg(61,1,{},vi);_.V=Ao;_.X=function(){return this.d=this.a[this.c++],this.d};_.W=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=lh(61);var yi;Vg(58,1,{},Ii);_.P=Do;_.Q=function(){return new Ji(this)};_.b=0;_.c=0;var Je=lh(58);Vg(59,1,{},Ji);_.V=Ao;_.X=function(){return this.c=this.a,this.a=this.b.next(),new Li(this.d,this.c,this.d.c)};_.W=function(){return !this.a.done};var He=lh(59);Vg(134,207,mo,Li);_.Z=function(){return this.b.value[0]};_.$=function(){return Ki(this)};_._=function(a){return Gi(this.a,this.b.value[0],a)};_.c=0;var Ie=lh(134);Vg(99,1,{});_.V=function(a){Qi(this,a)};_.ab=function(){return this.d};_.bb=Mo;_.d=0;_.e=0;var Le=lh(99);Vg(56,99,{});var Ke=lh(56);Vg(26,1,{},Ti);_.ab=xo;_.bb=function(){Si(this);return this.c};_.V=function(a){Si(this);this.d.V(a)};_.cb=function(a){Si(this);if(this.d.W()){a.B(this.d.X());return true}return false};_.a=0;_.c=0;var Me=lh(26);Vg(54,1,{},Vi);_.t=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ne=lh(54);var We=nh();Vg(125,1,{});_.c=false;var Xe=lh(125);Vg(35,125,{},bj);var Ve=lh(35);Vg(127,56,{},fj);_.cb=function(a){this.b=false;while(!this.b&&this.c.cb(new gj(this,a)));return this.b};_.b=false;var Pe=lh(127);Vg(130,1,{},gj);_.B=function(a){ej(this.a,this.b,a)};var Oe=lh(130);Vg(126,56,{},ij);_.cb=function(a){return this.a.cb(new jj(a))};var Re=lh(126);Vg(129,1,{},jj);_.B=function(a){hj(this.a,a)};var Qe=lh(129);Vg(128,1,{},lj);_.B=function(a){kj(this,a)};var Se=lh(128);Vg(131,1,{},mj);_.B=function(a){};var Te=lh(131);Vg(132,1,{},oj);_.B=function(a){nj(this,a)};var Ue=lh(132);Vg(263,1,{});Vg(209,1,{});var Ye=lh(209);Vg(260,1,{});var vj=0;var xj,yj=0,zj;Vg(687,1,{});Vg(711,1,{});Vg(208,1,{});_.fb=Eo;_.gb=Eo;_.ib=function(a,b,c){return false};_.p=false;var Ze=lh(208);Vg(34,$wnd.React.Component,{});Ug(Sg[1],_);_.render=function(){return Vj(this.a)};var $e=lh(34);Vg(226,$wnd.Function,{},Nj);_.eb=function(a){Lj(this.a,this.b,a)};Vg(227,$wnd.Function,{},Oj);_.eb=function(a){Mj(this.a,this.b,a)};Vg(38,208,{});_.lb=function(){return false};_.nb=function(){return Wj(this)};_.k=false;_.n=false;var Qj=1,Rj;var _e=lh(38);Vg(232,$wnd.Function,{},Xj);_.I=function(a){return Ab(Rj),Rj=null,null};Vg(10,36,{3:1,32:1,36:1,10:1},Hk);var kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk;var af=mh(10,Ik);Vg(156,38,{});_.sb=Fo;_.hb=function(){var a;a=T((Gm(),Fm).b);return Kj('footer',Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,['footer'])),[Ql(new Rl),Kj('ul',Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,['filters'])),[Kj('li',null,[Kj('a',$j(Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,[(Ln(),Jn)==a?po:null])),'#'),['All'])]),Kj('li',null,[Kj('a',$j(Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,[In==a?po:null])),'#active'),['Active'])]),Kj('li',null,[Kj('a',$j(Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,[Kn==a?po:null])),'#completed'),['Completed'])])]),this.sb()?Kj(oo,_j(Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,['clear-completed'])),Xg(Nl.prototype.rb,Nl,[])),['Clear Completed']):null])};var Kf=lh(156);Vg(157,156,{});_.sb=Fo;var Of=lh(157);Vg(158,157,ro,Kk);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Ok(this)),bo,null)}};_.q=yo;_.mb=Io;_.C=Go;_.sb=function(){return T(this.a)};_.s=zo;_.w=Ho;_.t=function(){var a;return hh(kf),kf.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.nb=function(){var b;try{return B((J(),J(),I),this.b,new Mk(this))}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.d=0;var kf=lh(158);Vg(159,1,Xn,Lk);_.u=function(){return fh(),T((Gm(),Dm).b).a>0?true:false};var bf=lh(159);Vg(162,1,Xn,Mk);_.u=Ko;var cf=lh(162);Vg(160,1,eo,Nk);_.A=Jo;var df=lh(160);Vg(161,1,ao,Ok);_.A=function(){Jk(this.a)};var ef=lh(161);Vg(181,38,{});_.hb=function(){var a,b;b=T((Gm(),Dm).e).a;a='item'+(b==1?'':'s');return Kj('span',Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,['todo-count'])),[Kj('strong',null,[b]),' '+a+' left'])};var Jf=lh(181);Vg(182,181,{});var Nf=lh(182);Vg(183,182,ro,Qk);_.v=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Sk(this)),bo,null)}};_.q=yo;_.mb=Io;_.C=Co;_.s=zo;_.w=No;_.t=function(){var a;return hh(jf),jf.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.nb=function(){var b;try{return B((J(),J(),I),this.a,new Tk(this))}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.c=0;var jf=lh(183);Vg(184,1,eo,Rk);_.A=Jo;var ff=lh(184);Vg(185,1,ao,Sk);_.A=function(){Pk(this.a)};var gf=lh(185);Vg(186,1,Xn,Tk);_.u=Ko;var hf=lh(186);Vg(148,38,{});_.hb=function(){return Kj(so,ak(ek(fk(ik(gk(Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,['new-todo']))),(bb(this.b),this.e)),Xg(km.prototype.qb,km,[this])),Xg(lm.prototype.pb,lm,[this]))),null)};_.e='';var Wf=lh(148);Vg(149,148,{});var Qf=lh(149);Vg(150,149,ro,_k);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new el(this)),bo,null)}};_.q=yo;_.mb=Io;_.C=Go;_.s=zo;_.w=Ho;_.t=function(){var a;return hh(qf),qf.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.nb=function(){var b;try{return B((J(),J(),I),this.a,new al(this))}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.d=0;var qf=lh(150);Vg(153,1,Xn,al);_.u=Ko;var lf=lh(153);Vg(154,1,ao,bl);_.A=function(){Uk(this.a)};var mf=lh(154);Vg(155,1,ao,cl);_.A=function(){Yk(this.a,this.b)};var nf=lh(155);Vg(151,1,eo,dl);_.A=Jo;var of=lh(151);Vg(152,1,ao,el);_.A=function(){Zk(this.a)};var pf=lh(152);Vg(165,38,{});_.fb=function(){fl(this)};_.ub=Lo;_.gb=function(){ul(this,this.tb())};_.hb=function(){var a,b;b=this.tb();a=(bb(b.a),b.g);return Kj('li',Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,[a?to:null,this.ub()?'editing':null])),[Kj('div',Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,['view'])),[Kj(so,ek(bk(hk(Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,['toggle'])),(Gk(),lk)),a),Xg(pm.prototype.pb,pm,[b])),null),Kj('label',jk(new $wnd.Object,Xg(qm.prototype.rb,qm,[this,b])),[(bb(b.b),b.i)]),Kj(oo,_j(Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,['destroy'])),Xg(rm.prototype.rb,rm,[b])),null)]),Kj(so,fk(ek(dk(ck(Yj(Zj(new $wnd.Object,Xg(sm.prototype.B,sm,[this])),cd(Yc(me,1),Yn,2,6,['edit'])),(bb(this.a),this.i)),Xg(tm.prototype.ob,tm,[this,b])),Xg(om.prototype.pb,om,[this])),Xg(um.prototype.qb,um,[this,b])),null)])};_.j=false;var Yf=lh(165);Vg(166,165,{});_.lb=function(){var a;a=(cb(this.c),this.o.props['a']);if(!!a&&a.f<0){return true}return false};_.tb=function(){return this.o.props['a']};_.ub=Lo;_.ib=function(a,b,c){return ml(this,a,b,c)};var Sf=lh(166);Vg(167,166,ro,wl);_.fb=function(){var b;try{A((J(),J(),I),new zl(this),go)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.v=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new xl(this)),bo,null)}};_.q=yo;_.mb=Io;_.C=Mo;_.tb=function(){return cb(this.c),this.o.props['a']};_.s=zo;_.w=Po;_.ub=function(){return T(this.d)};_.ib=function(b,c,d){var e;try{return t((J(),J(),I),new Al(this,b,c,d),75505664,null)}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){e=a;throw Hg(e)}else if(ld(a,4)){e=a;throw Hg(new vh(e))}else throw Hg(a)}};_.t=function(){var a;return hh(Cf),Cf.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.nb=function(){var b;try{return B((J(),J(),I),this.b,new yl(this))}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.f=0;var Cf=lh(167);Vg(170,1,ao,xl);_.A=function(){ol(this.a)};var rf=lh(170);Vg(171,1,Xn,yl);_.u=Ko;var sf=lh(171);Vg(172,1,ao,zl);_.A=function(){fl(this.a)};var tf=lh(172);Vg(173,1,Xn,Al);_.u=function(){return pl(this.a,this.d,this.c,this.b)};_.b=false;var uf=lh(173);Vg(174,1,ao,Bl);_.A=function(){vl(this.a,Km(this.b))};var vf=lh(174);Vg(175,1,ao,Cl);_.A=function(){kl(this.a,this.b)};var wf=lh(175);Vg(176,1,ao,Dl);_.A=function(){jl(this.a,this.b)};var xf=lh(176);Vg(168,1,Xn,El);_.u=function(){return ql(this.a)};var yf=lh(168);Vg(177,1,ao,Fl);_.A=function(){ul(this.a,this.b);Bn((Gm(),Fm),null)};var zf=lh(177);Vg(178,1,ao,Gl);_.A=function(){gl(this.a,this.b)};var Af=lh(178);Vg(169,1,eo,Hl);_.A=Jo;var Bf=lh(169);Vg(136,38,{});_.hb=function(){var a,b;return Kj('div',null,[Kj('div',null,[Kj(uo,Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,[uo])),[Kj('h1',null,['todos']),mm(new nm)]),T((Gm(),Dm).c)?null:Kj('section',Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,[uo])),[Kj(so,ek(hk(Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,['toggle-all'])),(Gk(),lk)),Xg(zm.prototype.pb,zm,[])),null),Kj('ul',Yj(new $wnd.Object,cd(Yc(me,1),Yn,2,6,['todo-list'])),(a=aj(_i(T(Fm.c).U()),(b=new ii,b)),hi(a,bd(a.a.length))))]),T(Dm.c)?null:Ol(new Pl)])])};var $f=lh(136);Vg(137,136,{});var Uf=lh(137);Vg(138,137,ro,Jl);_.v=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Ll(this)),bo,null)}};_.q=yo;_.mb=Io;_.C=Co;_.s=zo;_.w=No;_.t=function(){var a;return hh(Gf),Gf.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.nb=function(){var b;try{return B((J(),J(),I),this.a,new Ml(this))}catch(a){a=Gg(a);if(ld(a,5)||ld(a,7)){b=a;throw Hg(b)}else if(ld(a,4)){b=a;throw Hg(new vh(b))}else throw Hg(a)}};_.c=0;var Gf=lh(138);Vg(139,1,eo,Kl);_.A=Jo;var Df=lh(139);Vg(140,1,ao,Ll);_.A=function(){Pk(this.a)};var Ef=lh(140);Vg(141,1,Xn,Ml);_.u=Ko;var Ff=lh(141);Vg(237,$wnd.Function,{},Nl);_.rb=function(a){kn((Gm(),Em))};Vg(143,1,{},Pl);var Hf=lh(143);Vg(163,1,{},Rl);var If=lh(163);Vg(236,$wnd.Function,{},Sl);_.jb=function(a){return new Vl(a)};var Tl;Vg(145,34,{},Vl);_.kb=function(){return new Kk};_.componentWillUnmount=Oo;var Lf=lh(145);Vg(247,$wnd.Function,{},Wl);_.jb=function(a){return new Zl(a)};var Xl;Vg(164,34,{},Zl);_.kb=function(){return new Qk};_.componentWillUnmount=Oo;var Mf=lh(164);Vg(233,$wnd.Function,{},$l);_.jb=function(a){return new bm(a)};var _l;Vg(144,34,{},bm);_.kb=function(){return new _k};_.componentWillUnmount=Oo;var Pf=lh(144);Vg(238,$wnd.Function,{},cm);_.jb=function(a){return new fm(a)};var dm;Vg(147,34,{},fm);_.kb=function(){return new wl};_.componentDidUpdate=function(a){Gj(this.a,a)};_.componentWillUnmount=Oo;_.shouldComponentUpdate=function(a){return Hj(this.a,a)};var Rf=lh(147);Vg(230,$wnd.Function,{},gm);_.jb=function(a){return new jm(a)};var hm;Vg(120,34,{},jm);_.kb=function(){return new Jl};_.componentWillUnmount=Oo;var Tf=lh(120);Vg(234,$wnd.Function,{},km);_.qb=function(a){Vk(this.a,a)};Vg(235,$wnd.Function,{},lm);_.pb=function(a){Xk(this.a,a)};Vg(142,1,{},nm);var Vf=lh(142);Vg(245,$wnd.Function,{},om);_.pb=function(a){nl(this.a,a)};Vg(239,$wnd.Function,{},pm);_.pb=function(a){Qm(this.a)};Vg(241,$wnd.Function,{},qm);_.rb=function(a){sl(this.a,this.b)};Vg(242,$wnd.Function,{},rm);_.rb=function(a){ll(this.a)};Vg(243,$wnd.Function,{},sm);_.B=function(a){hl(this.a,a)};Vg(244,$wnd.Function,{},tm);_.ob=function(a){tl(this.a,this.b)};Vg(246,$wnd.Function,{},um);_.qb=function(a){il(this.a,this.b,a)};Vg(146,1,{},ym);var Xf=lh(146);Vg(231,$wnd.Function,{},zm);_.pb=function(a){var b;b=a.target;on((Gm(),Em),b.checked)};Vg(65,1,{},Bm);var Zf=lh(65);var Cm,Dm,Em,Fm;Vg(49,1,{49:1});_.g=false;var Cg=lh(49);Vg(50,49,{11:1,24:1,50:1,49:1},Rm);_.v=function(){Im(this)};_.q=function(a){return Jm(this,a)};_.C=Go;_.s=Mo;_.w=Po;_.t=function(){var a;return hh(og),og.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var Hm=0;var og=lh(50);Vg(179,1,ao,Sm);_.A=function(){Mm(this.a)};var _f=lh(179);Vg(180,1,ao,Tm);_.A=function(){Nm(this.a)};var ag=lh(180);Vg(47,107,{47:1});var xg=lh(47);Vg(108,47,{11:1,24:1,47:1},_m);_.v=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new an(this)),bo,null)}};_.q=yo;_.C=Qo;_.s=zo;_.w=function(){return this.g<0};_.t=function(){var a;return hh(ig),ig.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.g=0;var ig=lh(108);Vg(113,1,ao,an);_.A=function(){Ym(this.a)};var bg=lh(113);Vg(114,1,ao,bn);_.A=function(){hc(this.a,this.b,true)};var cg=lh(114);Vg(109,1,Xn,cn);_.u=function(){return Zm(this.a)};var dg=lh(109);Vg(115,1,Xn,dn);_.u=function(){return Um(this.a,this.c,this.b)};_.b=false;var eg=lh(115);Vg(110,1,Xn,en);_.u=function(){return xh(Mg(Zi(Xm(this.a))))};var fg=lh(110);Vg(111,1,Xn,fn);_.u=function(){return xh(Mg(Zi($i(Xm(this.a),new On))))};var gg=lh(111);Vg(112,1,Xn,gn);_.u=function(){return $m(this.a)};var hg=lh(112);Vg(85,1,{});var Bg=lh(85);Vg(86,85,ro,pn);_.v=function(){if(this.b>=0){this.b=-2;t((J(),J(),I),new G(new sn(this)),bo,null)}};_.q=yo;_.C=xo;_.s=zo;_.w=function(){return this.b<0};_.t=function(){var a;return hh(ng),ng.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.b=0;var ng=lh(86);Vg(89,1,ao,qn);_.A=function(){Pm(this.b,this.a)};var jg=lh(89);Vg(90,1,ao,rn);_.A=function(){ln(this.a)};var kg=lh(90);Vg(87,1,ao,sn);_.A=function(){nc(this.a.a)};var lg=lh(87);Vg(88,1,ao,tn);_.A=function(){mn(this.a,this.b)};_.b=false;var mg=lh(88);Vg(91,1,{});var Eg=lh(91);Vg(92,91,ro,Cn);_.v=function(){if(this.i>=0){this.i=-2;t((J(),J(),I),new G(new Dn(this)),bo,null)}};_.q=yo;_.C=function(){return this.g};_.s=zo;_.w=function(){return this.i<0};_.t=function(){var a;return hh(ug),ug.k+'@'+(a=wj(this)>>>0,a.toString(16))};_.i=0;var ug=lh(92);Vg(97,1,ao,Dn);_.A=function(){xn(this.a)};var pg=lh(97);Vg(93,1,Xn,En);_.u=function(){var a;return a=Wb(this.a.j),Dh(wo,a)||Dh(to,a)||Dh('',a)?Dh(wo,a)?(Ln(),In):Dh(to,a)?(Ln(),Kn):(Ln(),Jn):(Ln(),Jn)};var qg=lh(93);Vg(94,1,Xn,Fn);_.u=function(){return yn(this.a)};var rg=lh(94);Vg(95,1,eo,Gn);_.A=function(){zn(this.a)};var sg=lh(95);Vg(96,1,eo,Hn);_.A=function(){An(this.a)};var tg=lh(96);Vg(37,36,{3:1,32:1,36:1,37:1},Mn);var In,Jn,Kn;var vg=mh(37,Nn);Vg(81,1,{},On);_.db=function(a){return !Lm(a)};var wg=lh(81);Vg(83,1,{},Pn);_.db=function(a){return Lm(a)};var yg=lh(83);Vg(84,1,{},Qn);_.B=function(a){Wm(this.a,a)};var zg=lh(84);Vg(82,1,{},Rn);_.B=function(a){jn(this.a,a)};_.a=false;var Ag=lh(82);Vg(73,1,{},Sn);_.db=function(a){return vn(this.a,a)};var Dg=lh(73);var Tn=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=Qg;Og(_g);Rg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();