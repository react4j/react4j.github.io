function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='57F0721A31B4E74D0BF8158F4B80A961',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '57F0721A31B4E74D0BF8158F4B80A961';function n(){}
function Oi(){}
function Ki(){}
function db(){}
function Zb(){}
function vc(){}
function wc(){}
function zc(){}
function dd(){}
function ld(){}
function ll(){}
function il(){}
function kl(){}
function ml(){}
function nl(){}
function Pl(){}
function Ql(){}
function Rl(){}
function hn(){}
function jn(){}
function kn(){}
function xn(){}
function Jn(){}
function ro(){}
function so(){}
function Uo(){}
function Zo(){}
function _o(){}
function ap(){}
function cp(){}
function gp(){}
function op(){}
function qp(){}
function yp(){}
function Mq(){}
function Nq(){}
function Qr(){}
function Rr(a){}
function Nr(a){tl()}
function jd(a){hd()}
function Wi(){Wi=Ki}
function X(a){this.a=a}
function Y(a){this.a=a}
function nb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function $b(a){this.a=a}
function _b(a){this.a=a}
function ac(a){this.a=a}
function pc(a){this.a=a}
function rc(a){this.a=a}
function sc(a){this.a=a}
function tc(a){this.a=a}
function xc(a){this.a=a}
function Ac(a){this.a=a}
function kj(a){this.a=a}
function xj(a){this.a=a}
function Qj(a){this.a=a}
function Vj(a){this.a=a}
function Wj(a){this.a=a}
function Xj(a){this.a=a}
function Yj(a){this.a=a}
function Uj(a){this.b=a}
function hk(a){this.c=a}
function mk(a){this.a=a}
function nk(a){this.a=a}
function nn(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function un(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function Mn(a){this.a=a}
function Nn(a){this.a=a}
function On(a){this.a=a}
function Hl(a){this.a=a}
function Tl(a){this.a=a}
function to(a){this.a=a}
function uo(a){this.a=a}
function xo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Fo(a){this.a=a}
function Go(a){this.a=a}
function Ho(a){this.a=a}
function Io(a){this.a=a}
function Qo(a){this.a=a}
function Ro(a){this.a=a}
function So(a){this.a=a}
function To(a){this.a=a}
function ep(a){this.a=a}
function fp(a){this.a=a}
function ip(a){this.a=a}
function jp(a){this.a=a}
function kp(a){this.a=a}
function lp(a){this.a=a}
function mp(a){this.a=a}
function np(a){this.a=a}
function tp(a){this.a=a}
function Pp(a){this.a=a}
function Qp(a){this.a=a}
function Zp(a){this.a=a}
function _p(a){this.a=a}
function bq(a){this.a=a}
function cq(a){this.a=a}
function dq(a){this.a=a}
function pq(a){this.a=a}
function qq(a){this.a=a}
function Bq(a){this.a=a}
function Cq(a){this.a=a}
function Dq(a){this.a=a}
function Eq(a){this.a=a}
function Fq(a){this.a=a}
function Oq(a){this.a=a}
function Pq(a){this.a=a}
function Qq(a){this.a=a}
function Wo(){this.a={}}
function Yo(){this.a={}}
function sp(){this.a={}}
function xp(){this.a={}}
function Ap(){this.a={}}
function Ck(){this.a=Lk()}
function Qk(){this.a=Lk()}
function Wr(){lm(this.a)}
function Dr(a){Uk(this,a)}
function Mr(a){Yk(this,a)}
function Gr(a){qj(this,a)}
function ib(a){Rb((I(),a))}
function jb(a){Sb((I(),a))}
function lb(a){Tb((I(),a))}
function eq(a,b){Lp(b,a)}
function D(a,b){Db(a.b,b)}
function vb(a,b){a.j=b}
function Ol(a,b){a.a=b}
function tb(a,b){a.b=Xk(b)}
function Fb(a){this.a=Xk(a)}
function Gb(a){this.a=Xk(a)}
function Ib(a){this.a=Xk(a)}
function Dc(a){this.a=Xk(a)}
function wk(){this.a=new vk}
function I(){I=Ki;H=new G}
function Lc(){Lc=Ki;Kc=new n}
function cb(){cb=Ki;bb=new db}
function ad(){ad=Ki;_c=new dd}
function Hk(){Hk=Ki;Gk=Jk()}
function tl(){tl=Ki;sl=new Ql}
function rj(){Ic.call(this)}
function yj(){Ic.call(this)}
function Ar(){return am(this)}
function Br(){return this.a}
function Cr(){return this.b}
function Lr(){return this.d}
function Or(){return this.d<0}
function Tr(){return this.c<0}
function Yr(){return this.g<0}
function Fr(){return this.a.b}
function qi(a){return a.e}
function Sn(a,b){return a.q=b}
function tj(a,b){return a===b}
function ak(a,b){return a.a[b]}
function Ul(a,b){El(a.b,a.a,b)}
function bl(a,b,c){b.J(a.a[c])}
function im(a,b,c){a[b]=c}
function Xl(a,b){a.splice(b,1)}
function Vi(a){Jc.call(this,a)}
function zj(a){Jc.call(this,a)}
function $o(a){om.call(this,a)}
function bp(a){om.call(this,a)}
function dp(a){om.call(this,a)}
function hp(a){om.call(this,a)}
function pp(a){om.call(this,a)}
function zr(a){return this===a}
function Sr(){return I(),I(),H}
function Er(){return Oj(this.a)}
function md(a,b){return cj(a,b)}
function Vr(a,b){this.a.rb(a,b)}
function sn(a){fb(a.b);ob(a.a)}
function Z(a){_d(a,12)&&a.D()}
function Lb(a){Mb(a);!a.e&&Pb(a)}
function Zi(a){Yi(a);return a.k}
function Bl(a){pl(a);return a.a}
function Lk(){Hk();return new Gk}
function gc(a){kb(a.a);return a.e}
function hc(a){kb(a.b);return a.g}
function Ic(){Ec(this);this.R()}
function Sc(){Sc=Ki;!!(hd(),gd)}
function Di(){Bi==null&&(Bi=[])}
function G(){this.b=new Eb(this)}
function Eb(a){this.c=new R;Xk(a)}
function gb(a){I();Sb(a);a.e=-2}
function Od(a){return a.l|a.m<<22}
function Oj(a){return a.a.b+a.b.b}
function Bc(a){return !(!a||Gp(a))}
function C(a,b,c){return A(a,c,b)}
function Ll(a,b,c){b.J(a.a.N(c))}
function Yk(a,b){while(a.nb(b));}
function qc(a,b){this.a=a;this.b=b}
function yc(a,b){this.a=a;this.b=b}
function hj(a,b){this.a=a;this.b=b}
function Zj(a,b){this.a=a;this.b=b}
function Kl(a,b){this.a=a;this.b=b}
function Nl(a,b){this.a=a;this.b=b}
function Vl(a,b){this.b=a;this.a=b}
function qm(a,b){a.ref=b;return a}
function rm(a,b){a.href=b;return a}
function uq(a){kb(a.d);return a.j}
function F(a){a.c&&a.d==0&&Cb(a.b)}
function jc(a){fc(a,(kb(a.b),a.g))}
function $c(){Pc!=0&&(Pc=0);Rc=-1}
function rd(a){return new Array(a)}
function Nk(a,b){return a.a.get(b)}
function ui(a,b){return si(a,b)==0}
function up(a){return vp(new xp,a)}
function ok(){this.a=new $wnd.Date}
function oq(a,b){this.b=a;this.a=b}
function nq(a,b){this.a=a;this.b=b}
function rq(a,b){this.a=a;this.b=b}
function Kn(a,b){this.a=a;this.b=b}
function Ln(a,b){this.a=a;this.b=b}
function wo(a,b){this.a=a;this.b=b}
function yo(a,b){this.a=a;this.b=b}
function Eo(a,b){this.a=a;this.b=b}
function $p(a,b){this.a=a;this.b=b}
function $m(a,b){hj.call(this,a,b)}
function Kq(a,b){hj.call(this,a,b)}
function Kr(a){return Gj(this.a,a)}
function Hr(){return new el(this,0)}
function Jr(){return new el(this,1)}
function be(a){return typeof a===Tq}
function ab(a){return !(!!a&&a.F())}
function $(a){return _d(a,12)&&a.F()}
function Fj(a){return !a?null:a.jb()}
function ee(a){return a==null?null:a}
function Wk(a){return a!=null?q(a):0}
function Nb(a){return !a.e?a:Nb(a.e)}
function u(a){++a.d;return new Ib(a)}
function Zc(a){$wnd.clearTimeout(a)}
function Bm(a,b){a.value=b;return a}
function wm(a,b){a.onBlur=b;return a}
function vj(a,b){a.a+=''+b;return a}
function sm(a,b){a.onClick=b;return a}
function um(a,b){a.checked=b;return a}
function Wl(a,b,c){a.splice(b,0,c)}
function Sl(a,b,c){return Dl(a.a,b,c)}
function vd(a){return wd(a.l,a.m,a.h)}
function io(a){return a.t=false,Wn(a)}
function pk(a){return a<10?'0'+a:''+a}
function L(a){a.b=0;a.d=0;a.c=false}
function Nj(a){a.a=new Ck;a.b=new Qk}
function mb(a){this.b=new gk;this.c=a}
function em(){em=Ki;bm=new n;dm=new n}
function xm(a,b){a.onChange=b;return a}
function Xr(a,b){return nm(this.a,a,b)}
function sj(a,b){return a.charCodeAt(b)}
function wd(a,b,c){return {l:a,m:b,h:c}}
function _d(a,b){return a!=null&&Zd(a,b)}
function am(a){return a.$H||(a.$H=++_l)}
function Jp(a){Lp(a,(kb(a.a),!a.e))}
function fn(a){fb(a.c);ob(a.b);T(a.a)}
function Gn(a){fb(a.c);ob(a.a);fb(a.b)}
function Kp(a){fb(a.c);fb(a.b);fb(a.a)}
function Hb(a){if(!a.b){a.b=true;w(a.a)}}
function w(a){--a.d;a.c&&a.d==0&&Cb(a.b)}
function kb(a){var b;Ob((I(),b=Jb,b),a)}
function Ek(a){var b;b=a[kr];b.call(a,0)}
function gk(){this.a=od(mf,Uq,1,0,5,1)}
function R(){this.a=od(mf,Uq,1,100,5,1)}
function Jc(a){this.f=a;Ec(this);this.R()}
function uk(){this.a=new Ck;this.b=new Qk}
function vk(){this.a=new Ck;this.b=new Qk}
function Yi(a){if(a.k!=null){return}ej(a)}
function ym(a,b){a.onKeyDown=b;return a}
function vm(a,b){a.defaultValue=b;return a}
function tm(a){a.autoFocus=true;return a}
function de(a){return typeof a==='string'}
function ae(a){return typeof a==='boolean'}
function Fk(a,b){var c;c=a[kr];c.call(a,b)}
function Gl(a,b){!_d(b,21)||b.L();a.J(b)}
function V(a,b){r((I(),I(),H),new X(a),b)}
function Hn(a,b){if(b!=a.g){a.g=b;jb(a.b)}}
function po(a,b){if(b!=a.r){a.r=b;jb(a.a)}}
function Lp(a,b){if(b!=a.e){a.e=b;jb(a.a)}}
function Xp(a){return nj(U(a.e).a-U(a.a).a)}
function Ir(){return new Cl(null,this.cb())}
function Hj(a,b){return Ij(b,a.b)||Ij(b,a.a)}
function Tc(a,b,c){return a.apply(b,c);var d}
function El(a,b,c){tl();Ol(a,Sl(b,a.a,c))}
function Dl(a,b,c){tl();a.a.ob(b,c);return b}
function aj(a){var b;b=_i(a);gj(a,b);return b}
function Ec(a){a.g&&a.e!==$q&&a.R();return a}
function Cm(a,b){a.onDoubleClick=b;return a}
function Fc(a,b){a.e=b;b!=null&&$l(b,_q,a)}
function Fl(a,b,c){this.a=a;$k.call(this,b,c)}
function jl(a,b,c){this.c=a;this.a=b;this.b=c}
function Tk(a,b,c){this.a=a;this.b=b;this.c=c}
function vo(a,b,c){this.a=a;this.b=b;this.c=c}
function ol(){this.a=' ';this.b='';this.c=''}
function Ui(){Jc.call(this,'divide by zero')}
function Ri(){Ri=Ki;Qi=$wnd.window.document}
function pj(){pj=Ki;oj=od(hf,Uq,32,256,0,1)}
function hd(){hd=Ki;var a;!kd();a=new ld;gd=a}
function Cc(a){if(a.b){ob(a.b);a.b=null}Z(a.a)}
function lc(a,b){if(b!=a.e){a.e=Xk(b);jb(a.a)}}
function mc(a,b){if(b!=a.g){a.g=Xk(b);jb(a.b)}}
function zq(a,b){if(!tk(b,a.j)){a.j=b;jb(a.d)}}
function Uk(a,b){while(a.fb()){Ul(b,a.gb())}}
function _k(a,b){while(a.c<a.d){bl(a,b,a.c++)}}
function Il(a,b,c){if(a.a.M(c)){a.b=true;b.J(c)}}
function vp(a,b){im(a.a,'key',Xk(b));return a}
function $j(a,b){a.a[a.a.length]=b;return true}
function cc(a,b){a.i&&b.preventDefault();nc(a)}
function yn(a,b){var c;c=b.target;Hn(a,c.value)}
function qb(a,b){hb(b,a);b.b.a.length>0||(b.a=1)}
function Cl(a,b){tl();rl.call(this,a);this.a=b}
function Mj(a,b){return b==null?Bk(a.a):Pk(a.b,b)}
function Gj(a,b){return de(b)?Jj(a,b):!!zk(a.a,b)}
function Mk(a,b){return !(a.a.get(b)===undefined)}
function mm(a){return _d(a,12)&&a.F()?null:a.ub()}
function Wp(a){return Wi(),0==U(a.e).a?true:false}
function qd(a){return Array.isArray(a)&&a.Db===Oi}
function $d(a){return !Array.isArray(a)&&a.Db===Oi}
function dl(a){if(!a.d){a.d=a.b.$();a.c=a.b.bb()}}
function en(a){a.t=true;a.u||a.v.forceUpdate()}
function $l(b,c,d){try{b[c]=d}catch(a){}}
function yi(a){if(be(a)){return a|0}return Od(a)}
function zi(a){if(be(a)){return ''+a}return Pd(a)}
function Xk(a){if(a==null){throw qi(new rj)}return a}
function ed(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ek(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ck(a,b){var c;c=a.a[b];Xl(a.a,b);return c}
function Gp(a){var b;b=a.d<0;b||kb(a.c);return !b}
function Sj(a){var b;b=a.a.gb();a.b=Rj(a);return b}
function Q(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Qd(a,b){return wd(a.l^b.l,a.m^b.m,a.h^b.h)}
function Kj(a,b,c){return de(b)?Lj(a,b,c):Ak(a.a,b,c)}
function tk(a,b){return ee(a)===ee(b)||a!=null&&o(a,b)}
function yr(a,b){return ee(a)===ee(b)||a!=null&&o(a,b)}
function sq(a){return tj(xr,a)||tj(ur,a)||tj('',a)}
function pl(a){if(!a.b){ql(a);a.c=true}else{pl(a.b)}}
function Kb(a){if(a.f){a.f.e||wb(a.f,1,true);rb(a.f)}}
function xl(a,b){ql(a);return new Cl(a,new Jl(b,a.a))}
function yl(a,b){ql(a);return new Cl(a,new Ml(b,a.a))}
function Jj(a,b){return b==null?!!zk(a.a,null):Mk(a.b,b)}
function Db(a,b){b.o=true;b.f?K(a.c,Xk(b)):J(a.c,Xk(b))}
function Am(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function bj(a,b){var c;c=_i(a);gj(a,c);c.e=b?8:0;return c}
function cl(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function $k(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function el(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function aq(a,b,c){this.a=a;this.c=b;this.d=c;this.b=false}
function rl(a){if(!a){this.b=null;new gk}else{this.b=a}}
function dj(a){if(a.Y()){return null}var b=a.j;return Gi[b]}
function Pr(){var a;return a=this.d<0,a||kb(this.c),!a}
function Ur(){var a;return a=this.c<0,a||kb(this.b),!a}
function Zr(){var a;return a=this.g<0,a||kb(this.f),!a}
function Lq(){Jq();return sd(md(ei,1),Uq,40,0,[Gq,Iq,Hq])}
function Ai(a,b){return ti(Qd(be(a)?xi(a):a,be(b)?xi(b):b))}
function Ej(a,b){return b===a?'(this Map)':b==null?br:Ni(b)}
function Lj(a,b,c){return b==null?Ak(a.a,null,c):Ok(a.b,b,c)}
function jj(a){this.f=!a?null:Gc(a,a.Q());Ec(this);this.R()}
function lk(a){var b;b=new wk;Kj(b.a,a,b);return new nk(b)}
function Gc(a,b){var c;c=Zi(a.Bb);return b==null?c:c+': '+b}
function Qn(a,b){var c;if(U(a.d)){c=b.target;po(a,c.value)}}
function Bn(){Bn=Ki;var a;An=(a=Li(cp.prototype.vb,cp,[]),a)}
function qn(){qn=Ki;var a;pn=(a=Li(ap.prototype.vb,ap,[]),a)}
function Zn(){Zn=Ki;var a;Yn=(a=Li(gp.prototype.vb,gp,[]),a)}
function bn(){bn=Ki;var a;an=(a=Li(Zo.prototype.vb,Zo,[]),a)}
function Ko(){Ko=Ki;var a;Jo=(a=Li(op.prototype.vb,op,[]),a)}
function jq(a,b){Sp(a.c,''+zi(vi((new ok).a.getTime())),b)}
function vq(a){fb(a.f);ob(a.e);ob(a.a);T(a.b);T(a.c);fb(a.d)}
function co(a){fb(a.f);ob(a.e);ob(a.b);T(a.d);fb(a.c);fb(a.a)}
function Xb(a){if(ab(a.a)&&U(a.a)){v((I(),I(),H),a.b);Z(a.c)}}
function ql(a){if(a.b){ql(a.b)}else if(a.c){throw qi(new ij)}}
function Yc(a){Sc();$wnd.setTimeout(function(){throw a},0)}
function hm(){if(cm==256){bm=dm;dm=new n;cm=0}++cm}
function Mi(a){function b(){}
;b.prototype=a||{};return new b}
function Vb(a,b){Jb=new Ub(a,Jb,b);a.c=false;Kb(Jb);return Jb}
function eb(a,b){var c;$j(a.b,b);c=0==b.p?1:b.p;a.a>c&&(a.a=c)}
function qj(a,b){var c,d;for(d=a.$();d.fb();){c=d.gb();b.J(c)}}
function cj(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.T(b))}
function yk(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function zk(a,b){var c;return xk(b,yk(a,b==null?0:(c=q(b),c|0)))}
function ik(a,b){return new Cl(null,(Zk(b,a.length),new cl(a,b)))}
function eo(a,b){a.v.props[tr]===(null==b?null:b[tr])||jb(a.c)}
function T(a){if(!a.a){a.a=true;a.g=null;a.c=null;a.f.e||ob(a.f)}}
function gl(a){return !a.a?a.c:a.e.length==0?a.a.a:a.a.a+(''+a.e)}
function Wb(){var a;Lb(Jb);a=Jb.e;!a&&(Jb.a.c=true);Jb=Jb.e}
function xq(a){var b;b=(kb(a.d),a.j);!!b&&!!b&&b.d<0&&zq(a,null)}
function bc(a,b){a.j=b;tj(b,(kb(a.a),a.e))&&mc(a,b);dc(b);nc(a)}
function vl(a,b){var c;return b.b.N(Al(a,b.c.O(),(c=new Tl(b),c)))}
function ul(a,b){return (ql(a),Bl(new Cl(a,new Jl(b,a.a)))).nb(sl)}
function Ii(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Si(a,b,c,d){a.addEventListener(b,c,(Wi(),d?true:false))}
function Ti(a,b,c,d){a.removeEventListener(b,c,(Wi(),d?true:false))}
function Wc(a,b,c){var d;d=Uc();try{return Tc(a,b,c)}finally{Xc(d)}}
function Ub(a,b,c){this.a=Xk(a);this.b=a.a++;this.e=b;this.f=c}
function Ml(a,b){$k.call(this,b.mb(),b.lb()&-6);this.a=a;this.b=b}
function Dk(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Jl(a,b){$k.call(this,b.mb(),b.lb()&-16449);this.a=a;this.c=b}
function al(a,b){if(a.c<a.d){bl(a,b,a.c++);return true}return false}
function zm(a){a.placeholder='What needs to be done?';return a}
function Hc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function fl(a,b){!a.a?(a.a=new xj(a.d)):vj(a.a,a.b);vj(a.a,b);return a}
function O(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function $n(a){if(a.g>=0){a.g=-2;v((I(),I(),H),new uo(a));a.g=-1}}
function fb(a){if(-2!=a.e){v((I(),I(),H),new nb(a));!!a.c&&ob(a.c)}}
function hq(a,b){vl(Up(a.c),new jl(new ml,new ll,new il)).Z(new Pq(b))}
function Fp(){Fp=Ki;Bp=new oc;Cp=new Yp;Dp=new mq(Cp);Ep=new Aq(Cp,Bp)}
function wl(a){var b;pl(a);b=0;while(a.a.nb(new Rl)){b=ri(b,1)}return b}
function ud(a){var b,c,d;b=a&cr;c=a>>22&cr;d=a<0?dr:0;return wd(b,c,d)}
function Vo(a){return $wnd.React.createElement((bn(),an),a.a,undefined)}
function Xo(a){return $wnd.React.createElement((qn(),pn),a.a,undefined)}
function rp(a){return $wnd.React.createElement((Bn(),An),a.a,undefined)}
function zp(a){return $wnd.React.createElement((Ko(),Jo),a.a,undefined)}
function fe(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Xc(a){a&&cd((ad(),_c));--Pc;if(a){if(Rc!=-1){Zc(Rc);Rc=-1}}}
function tq(a,b){return (Jq(),Hq)==a||(Gq==a?(kb(b.a),!b.e):(kb(b.a),b.e))}
function hl(a,b,c){this.b=a;this.d=b;this.e=c;this.c=this.d+(''+this.e)}
function Rk(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function _n(a){kb(a.c);return null!=a.v.props[tr]?a.v.props[tr]:null}
function fo(a){po(a,hc((kb(a.c),null!=a.v.props[tr]?a.v.props[tr]:null)))}
function zl(a){var b;ql(a);b=new Fl(a,a.a.mb(),a.a.lb());return new Cl(a,b)}
function Al(a,b,c){var d;pl(a);d=new Pl;d.a=b;a.a.eb(new Vl(d,c));return d.a}
function od(a,b,c,d,e,f){var g;g=pd(e,d);e!=10&&sd(md(a,f),b,c,e,g);return g}
function Cb(a){var b;if(0!=a.a){return 0}else{b=0;while(Bb(a)){++b}return b}}
function Sk(a){if(a.a.c!=a.c){return Nk(a.a,a.b.value[0])}return a.b.value[1]}
function Oc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Vc(b){Sc();return function(){return Wc(b,this,arguments);var a}}
function dk(a,b){var c;c=bk(a,b,0);if(c==-1){return false}Xl(a.a,c);return true}
function bk(a,b,c){for(;c<a.a.length;++c){if(tk(b,a.a[c])){return c}}return -1}
function N(a,b){if(0==a.b){a.b=a.a.length-1;a.c=true}else{--a.b}a.a[a.b]=b}
function Rn(a,b){27==b.which?(oo(a),zq((Fp(),Ep),null)):13==b.which&&mo(a)}
function Yl(a,b){return nd(b)!=10&&sd(p(b),b.Cb,b.__elementTypeId$,nd(b),a),a}
function nd(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function lm(a){var b;b=u(a.sb());try{a.u=true;_d(a,12)&&a.D()}finally{Hb(b)}}
function ub(b){if(b){try{b.G()}catch(a){a=pi(a);if(_d(a,4)){I()}else throw qi(a)}}}
function Tn(a){Tp((Fp(),Cp),(kb(a.c),null!=a.v.props[tr]?a.v.props[tr]:null))}
function ic(a){Ti((Ri(),$wnd.window.window),Yq,a.f,false);fb(a.c);fb(a.b);fb(a.a)}
function bd(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=fd(b,c)}while(a.a);a.a=c}}
function cd(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=fd(b,c)}while(a.b);a.b=c}}
function s(a,b,c){var d,e,f;f=new Fb(b);e=(d=new yb(null,f,c),d);Db(a.b,e);return e}
function _j(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.J(c)}}
function Xn(a,b){var c;c=a?ur:'';if(b){c.length==0||(c+=' ');c+='editing'}return c}
function pm(a,b){a.className=vl(ik(b,b.length),new jl(new ol,new nl,new kl));return a}
function iq(a){vl(xl(Up(a.c),new Nq),new jl(new ml,new ll,new il)).Z(new Oq(a.c))}
function Tj(a){this.d=a;this.c=new Rk(this.d.b);this.a=this.c;this.b=Rj(this)}
function ij(){Jc.call(this,"Stream already terminated, can't be modified or used")}
function Ci(){Di();var a=Bi;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Li(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function pi(a){var b;if(_d(a,4)){return a}b=a&&a[_q];if(!b){b=new Nc(a);jd(b)}return b}
function gj(a,b){var c;if(!a){return}b.j=a;var d=dj(b);if(!d){Gi[a]=[b];return}d.Bb=b}
function Ob(a,b){var c;if(a.f){c=a.b;if(b.e!=c){b.e=c;$j((!a.c&&(a.c=new gk),a.c),b)}}}
function mj(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function _i(a){var b;b=new $i;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Pk(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Fk(a.a,b);--a.b}return c}
function Qb(a,b){var c;if(!a.d){c=Nb(a);!c.d&&(c.d=new gk);a.d=c.d}b.d=true;$j(a.d,Xk(b))}
function sb(a){I();rb(a);_j(a.b,new Ab(a));a.b.a=od(mf,Uq,1,0,5,1);a.d=true;wb(a,0,true)}
function Vd(){Vd=Ki;Rd=wd(cr,cr,524287);Sd=wd(0,0,er);Td=ud(1);ud(2);Ud=ud(0)}
function Jq(){Jq=Ki;Gq=new Kq('ACTIVE',0);Iq=new Kq('COMPLETED',1);Hq=new Kq('ALL',2)}
function Up(a){kb(a.d);return yl(xl(new Cl(null,new el(new Xj(a.i),0)),new vc),new wc)}
function wp(a,b){im(a.a,tr,b);return $wnd.React.createElement((Zn(),Yn),a.a,undefined)}
function Zk(a,b){if(0>a||a>b){throw qi(new Vi('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Fi(a,b){typeof window===Sq&&typeof window['$gwt']===Sq&&(window['$gwt'][a]=b)}
function ce(a){return a!=null&&(typeof a===Sq||typeof a==='function')&&!(a.Db===Oi)}
function Un(a){zq((Fp(),Ep),(kb(a.c),null!=a.v.props[tr]?a.v.props[tr]:null));oo(a)}
function Vp(a){qj(new Xj(a.i),new zc);Nj(a.i);fb(a.f);T(a.c);T(a.e);T(a.a);T(a.b);fb(a.d)}
function J(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);O(a,Xk(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);N(a,Xk(b))}
function rb(a){var b,c;for(c=new hk(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=1}}
function t(a,b,c,d){var e,f;e=new W(a,b,d);f=e.f;f.g=null;f.i=c;f.k=null;f.j=null;return e}
function Bj(a,b){var c,d;for(d=b.$();d.fb();){c=d.gb();if(!a.ab(c)){return false}}return true}
function jk(a){var b,c,d;d=0;for(c=a.$();c.fb();){b=c.gb();d=d+(b!=null?q(b):0);d=d|0}return d}
function Ij(a,b){var c,d;for(d=b.$();d.fb();){c=d.gb();if(tk(a,c.jb())){return true}}return false}
function Gd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return wd(c&cr,d&cr,e&dr)}
function Nd(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return wd(c&cr,d&cr,e&dr)}
function xi(a){var b,c,d,e;e=a;d=0;if(e<0){e+=fr;d=dr}c=fe(e/gr);b=fe(e-c*gr);return wd(b,c,d)}
function xk(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(tk(a,c.ib())){return c}}return null}
function ti(a){var b;b=a.h;if(b==0){return a.l+a.m*gr}if(b==dr){return a.l+a.m*gr-fr}return a}
function Rj(a){if(a.a.fb()){return true}if(a.a!=a.c){return false}a.a=new Dk(a.d.a);return a.a.fb()}
function vi(a){if(hr<a&&a<fr){return a<0?$wnd.Math.ceil(a):$wnd.Math.floor(a)}return ti(Id(a))}
function pb(b){if(!b.d){try{1!=b.p&&b.n.H(b)}catch(a){a=pi(a);if(_d(a,4)){I()}else throw qi(a)}}}
function wq(a){var b;return b=U(a.b),vl(xl(Up(a.k),new Qq(b)),new jl(new ml,new ll,new il))}
function jo(a){return Wi(),ul(zl(yl(new Cl(null,new el(lk(new to(a)),1)),new ro)),new so)?true:false}
function go(a){return Wi(),uq((Fp(),Ep))==(kb(a.c),null!=a.v.props[tr]?a.v.props[tr]:null)?true:false}
function om(a){$wnd.React.Component.call(this,a);this.a=this.wb();this.a.v=Xk(this);this.a.pb()}
function mq(a){var b;this.c=Xk(a);this.b=1;this.a=(b=new mb((I(),null)),b);this.b=2;this.b=4}
function W(a,b,c){this.d=Xk(a);this.b=Xk(b);this.g=null;this.e=false;this.f=new yb(this,new Y(this),c)}
function yb(a,b,c){this.b=new gk;this.a=a;this.n=Xk(b);this.f=c;this.a?(this.c=new mb(this)):(this.c=null)}
function Pi(){Fp();$wnd.ReactDOM.render(zp(new Ap),(Ri(),Qi).getElementById('todoapp'),null)}
function sd(a,b,c,d,e){e.Bb=a;e.Cb=b;e.Db=Oi;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ok(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function hb(a,b){var c,d;d=a.b;dk(d,b);d.a.length==0&&!!a.c&&!a.c.a.e&&(a.d||Qb((I(),c=Jb,c),a))}
function yq(a){var b;b=gc(a.i);tj(xr,b)||tj(ur,b)||tj('',b)?fc(a.i,b):sq(hc(a.i))?kc(a.i):fc(a.i,'')}
function Pn(a){var b;b=U(a.d);if(!a.s&&b){a.s=true;oo(a);a.q.focus();a.q.select()}else a.s&&!b&&(a.s=false)}
function Dd(a){var b,c;c=lj(a.h);if(c==32){b=lj(a.m);return b==32?lj(a.l)+32:b+20-10}else{return c-12}}
function Jd(a){var b,c,d;b=~a.l+1&cr;c=~a.m+(b==0?1:0)&cr;d=~a.h+(b==0&&c==0?1:0)&dr;return wd(b,c,d)}
function Cd(a){var b,c,d;b=~a.l+1&cr;c=~a.m+(b==0?1:0)&cr;d=~a.h+(b==0&&c==0?1:0)&dr;a.l=b;a.m=c;a.h=d}
function si(a,b){var c;if(be(a)&&be(b)){c=a-b;if(!isNaN(c)){return c}}return Hd(be(a)?xi(a):a,be(b)?xi(b):b)}
function ri(a,b){var c;if(be(a)&&be(b)){c=a+b;if(hr<c&&c<fr){return c}}return ti(Gd(be(a)?xi(a):a,be(b)?xi(b):b))}
function nj(a){var b,c;if(a>-129&&a<128){b=a+128;c=(pj(),oj)[b];!c&&(c=oj[b]=new kj(a));return c}return new kj(a)}
function Aj(a,b){var c,d;for(d=a.$();d.fb();){c=d.gb();if(ee(b)===ee(c)||b!=null&&o(b,c)){return true}}return false}
function zd(a,b,c,d,e){var f;f=Ld(a,b);c&&Cd(f);if(e){a=Bd(a,b);d?(td=Jd(a)):(td=wd(a.l,a.m,a.h))}return f}
function U(a){kb(a.f.c);xb(a.f)&&pb(a.f);if(a.c){if(_d(a.c,5)){throw qi(a.c)}else{throw qi(a.c)}}return a.g}
function p(a){return de(a)?pf:be(a)?cf:ae(a)?af:$d(a)?a.Bb:qd(a)?a.Bb:a.Bb||Array.isArray(a)&&md(Te,1)||Te}
function Nc(a){Lc();Ec(this);this.e=a;a!=null&&$l(a,_q,this);this.f=a==null?br:Ni(a);this.a='';this.b=a;this.a=''}
function $i(){this.g=Xi++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function ec(a){var b,c;c=(b=(Ri(),$wnd.window.window).location.hash,null==b?'':b.substr(1));lc(a,c);tj(a.j,c)&&mc(a,c)}
function Pj(a,b){var c;if(b===a){return true}if(!_d(b,47)){return false}c=b;if(c.bb()!=a.bb()){return false}return Bj(a,c)}
function nm(a,b,c){var d;if(a.t){return true}if(a.v.state===c){d=km(a.v.props,b);d&&a.tb(b);return d}else{return true}}
function uc(a,b,c){var d,e;d=Mj(a.i,b?b.f:null);if(d){if(c){!!d&&Cc(d)}else{e=d.b;!!e&&!!e&&ob(e)}jb(a.d)}else{new Ac(b)}}
function gm(a){em();var b,c,d;c=':'+a;d=dm[c];if(d!=null){return fe(d)}d=bm[c];b=d==null?fm(a):fe(d);hm();dm[c]=b;return b}
function kk(a){var b,c,d;d=1;for(c=new hk(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?q(b):0);d=d|0}return d}
function fj(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function fk(a,b){var c,d;d=a.a.length;b.length<d&&(b=Yl(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function zn(a,b){var c;if(13==b.keyCode){b.preventDefault();c=uj((kb(a.b),a.g));if(c.length>0){fq((Fp(),Dp),c);Hn(a,'')}}}
function ob(a){var b;if(!a.d&&!a.e){a.e=true;ub((b=a.j,b));v((I(),I(),H),new zb(a));!!a.a&&T(a.a);!!a.c&&fb(a.c);a.e=false}}
function Ni(a){var b;if(Array.isArray(a)&&a.Db===Oi){return Zi(p(a))+'@'+(b=q(a)>>>0,b.toString(16))}return a.toString()}
function yd(a,b){if(a.h==er&&a.m==0&&a.l==0){b&&(td=wd(0,0,0));return vd((Vd(),Td))}b&&(td=wd(a.l,a.m,a.h));return wd(0,0,0)}
function o(a,b){return de(a)?tj(a,b):be(a)?a===b:ae(a)?a===b:$d(a)?a.w(b):qd(a)?a===b:!!a&&!!a.equals?a.equals(b):ee(a)===ee(b)}
function q(a){return de(a)?gm(a):be(a)?fe(a):ae(a)?a?1231:1237:$d(a)?a.B():qd(a)?am(a):!!a&&!!a.hashCode?a.hashCode():am(a)}
function _m(){Zm();return sd(md(wg,1),Uq,10,0,[Dm,Em,Fm,Gm,Hm,Im,Jm,Km,Lm,Mm,Nm,Om,Pm,Qm,Rm,Sm,Tm,Um,Vm,Wm,Xm,Ym])}
function Uc(){var a;if(Pc!=0){a=Oc();if(a-Qc>2000){Qc=a;Rc=$wnd.setTimeout($c,10)}}if(Pc++==0){bd((ad(),_c));return true}return false}
function kd(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Zl(a){switch(typeof(a)){case 'string':return gm(a);case Tq:return fe(a);case 'boolean':return Wi(),a?1231:1237;default:return am(a);}}
function tn(){qn();var a,b;++jm;this.c=1;this.b=(a=new mb((I(),null)),a);this.a=(b=new yb(null,new Gb(new un(this)),false),b);this.c=2;this.c=4}
function Zd(a,b){if(de(a)){return !!Yd[b]}else if(a.Cb){return !!a.Cb[b]}else if(be(a)){return !!Xd[b]}else if(ae(a)){return !!Wd[b]}return false}
function Tb(a){var b,c,d;if(a.b.a.length>0&&1==a.a){a.a=2;for(c=new hk(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.p;1==d&&wb(b,2,true)}}}
function Sb(a){var b,c,d,e;if(a.b.a.length>0&&3!=a.a){a.a=3;d=a.b;for(c=new hk(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.p;3!=e&&wb(b,3,true)}}}
function Rb(a){var b,c;if(a.b.a.length>0&&3!=a.a){a.a=3;for(c=new hk(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);2==b.p?wb(b,3,true):1==b.p&&(a.a=1)}}}
function P(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function r(b,c,d){var e;try{Vb(b,d);try{c.G()}finally{Wb()}}catch(a){a=pi(a);if(_d(a,4)){e=a;throw qi(e)}else throw qi(a)}finally{b.c&&b.d==0&&Cb(b.b)}}
function v(b,c){var d;try{Vb(b,null);try{c.G()}finally{Wb()}}catch(a){a=pi(a);if(_d(a,4)){d=a;throw qi(d)}else throw qi(a)}finally{b.c&&b.d==0&&Cb(b.b)}}
function kc(b){var c;try{v((I(),I(),H),new rc(b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}}
function nc(b){var c;try{v((I(),I(),H),new sc(b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}}
function ko(b){var c;try{v((I(),I(),H),new Do(b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}}
function lo(b){var c;try{v((I(),I(),H),new Co(b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}}
function mo(b){var c;try{v((I(),I(),H),new zo(b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}}
function no(b){var c;try{v((I(),I(),H),new Ao(b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}}
function oo(b){var c;try{v((I(),I(),H),new xo(b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}}
function Lo(b){var c;try{v((I(),I(),H),new Ro(b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}}
function Np(b){var c;try{v((I(),I(),H),new Pp(b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}}
function gq(b){var c;try{v((I(),I(),H),new pq(b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}}
function cn(){var b;try{v((I(),I(),H),new kn)}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){b=a;throw qi(b)}else if(_d(a,4)){b=a;throw qi(new jj(b))}else throw qi(a)}}
function uj(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Pb(a){var b,c;b=0;if(a.d){while(a.d.a.length!=0){c=ck(a.d,a.d.a.length-1);c.d=false;if(c.b.a.length<=0){0!=c.c.p&&wb(c.c,0,true);++b}}}return b}
function Bd(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return wd(c,d,e)}
function Rp(a,b,c,d){var e,f,g,h;e=new Op(b,c,d);f=new Dc(e);g=e.f;Lj(a.i,g,f);h=(new Yb((I(),new xc(e)),new yc(a,e),true)).c;f.b=Xk(h);jb(a.d);return e}
function pd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Fd(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&cr;a.m=d&cr;a.h=e&dr;return true}
function En(a){return a.t=false,$wnd.React.createElement(sr,tm(xm(ym(Bm(zm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,['new-todo']))),(kb(a.b),a.g)),a.f),a.e)))}
function Yb(a,b,c){Xk(a);this.b=Xk(b);this.a=t((I(),a),new Zb,new $b(this),true);this.c=s((null,H),new _b(this),true);vb(this.c,new ac(this));c&&F((null,H))}
function A(b,c,d){var e,f;try{Vb(b,d);try{f=c.K()}finally{Wb()}return f}catch(a){a=pi(a);if(_d(a,4)){e=a;throw qi(e)}else throw qi(a)}finally{b.c&&b.d==0&&Cb(b.b)}}
function bo(b,c){var d;try{v((I(),I(),H),new yo(b,c))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){d=a;throw qi(d)}else if(_d(a,4)){d=a;throw qi(new jj(d))}else throw qi(a)}}
function ao(b,c){var d;try{v((I(),I(),H),new Eo(b,c))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){d=a;throw qi(d)}else if(_d(a,4)){d=a;throw qi(new jj(d))}else throw qi(a)}}
function fc(b,c){var d;try{v((I(),I(),H),new qc(b,c))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){d=a;throw qi(d)}else if(_d(a,4)){d=a;throw qi(new jj(d))}else throw qi(a)}}
function fq(b,c){var d;try{v((I(),I(),H),new rq(b,c))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){d=a;throw qi(d)}else if(_d(a,4)){d=a;throw qi(new jj(d))}else throw qi(a)}}
function kq(b,c){var d;try{v((I(),I(),H),new oq(b,c))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){d=a;throw qi(d)}else if(_d(a,4)){d=a;throw qi(new jj(d))}else throw qi(a)}}
function Cn(b,c){var d;try{v((I(),I(),H),new Ln(b,c))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){d=a;throw qi(d)}else if(_d(a,4)){d=a;throw qi(new jj(d))}else throw qi(a)}}
function Dn(b,c){var d;try{v((I(),I(),H),new Kn(b,c))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){d=a;throw qi(d)}else if(_d(a,4)){d=a;throw qi(new jj(d))}else throw qi(a)}}
function Tp(b,c){var d;try{v((I(),I(),H),new $p(b,c))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){d=a;throw qi(d)}else if(_d(a,4)){d=a;throw qi(new jj(d))}else throw qi(a)}}
function Hd(a,b){var c,d,e,f,g,h,i,j;i=a.h>>19;j=b.h>>19;if(i!=j){return j-i}e=a.h;h=b.h;if(e!=h){return e-h}d=a.m;g=b.m;if(d!=g){return d-g}c=a.l;f=b.l;return c-f}
function Ei(b,c,d,e){Di();var f=Bi;$moduleName=c;$moduleBase=d;oi=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Rq(g)()}catch(a){b(c,a)}}else{Rq(g)()}}
function Op(a,b,c){var d,e,f;this.f=Xk(a);this.g=Xk(b);this.e=c;this.d=1;this.c=(e=new mb((I(),null)),e);this.b=(f=new mb(null),f);this.a=(d=new mb(null),d);this.d=2;this.d=4}
function Po(){Ko();var a,b;++jm;this.d=Li(qp.prototype.yb,qp,[]);this.c=1;this.b=(a=new mb((I(),null)),a);this.a=(b=new yb(null,new Gb(new Qo(this)),false),b);this.c=2;this.c=4}
function Cj(a){var b,c,d;d=new hl(', ','[',']');for(c=a.$();c.fb();){b=c.gb();fl(d,b===a?'(this Collection)':b==null?br:Ni(b))}return !d.a?d.c:d.e.length==0?d.a.a:d.a.a+(''+d.e)}
function Jk(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Kk()}}
function Bb(a){var b,c;c=Q(a.c);if(0==a.d){if(0==c){a.a=0;return false}else if(a.a+1>a.b){a.a=0;L(a.c);return false}else{a.a=a.a+1;a.d=c}}--a.d;b=P(a.c);b.o=false;pb(b);return true}
function S(b){var c,d,e;e=b.g;try{d=b.d.K();if(!b.b.I(e,d)){b.g=d;b.c=null;ib(b.f.c)}}catch(a){a=pi(a);if(_d(a,13)){c=a;if(!b.c){b.g=null;b.c=c;ib(b.f.c)}throw qi(c)}else throw qi(a)}}
function sk(){sk=Ki;qk=sd(md(pf,1),Uq,2,6,['Sun','Mon','Tue','Wed','Thu','Fri','Sat']);rk=sd(md(pf,1),Uq,2,6,['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])}
function Hi(){Gi={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function fd(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Eb()&&(c=ed(c,g)):g[0].Eb()}catch(a){a=pi(a);if(_d(a,4)){d=a;Sc();Yc(_d(d,43)?d.S():d)}else throw qi(a)}}return c}
function Kd(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return wd(c&cr,d&cr,e&dr)}
function Md(a,b){var c,d,e,f;b&=63;c=a.h&dr;if(b<22){f=c>>>b;e=a.m>>b|c<<22-b;d=a.l>>b|a.m<<22-b}else if(b<44){f=0;e=c>>>b-22;d=a.m>>b-22|a.h<<44-b}else{f=0;e=0;d=c>>>b-44}return wd(d&cr,e&cr,f&dr)}
function Mc(a){var b;if(a.c==null){b=ee(a.b)===ee(Kc)?null:a.b;a.d=b==null?br:ce(b)?b==null?null:b.name:de(b)?'String':Zi(p(b));a.a=a.a+': '+(ce(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Bk(a){var b,c,d,e;c=(b=a.a.get(0),b==null?new Array:b);for(e=0;e<c.length;e++){d=c[e];if(tk(null,d.ib())){if(c.length==1){c.length=0;Ek(a.a)}else{c.splice(e,1)}--a.b;return d.jb()}}return null}
function Ak(a,b,c){var d,e,f,g,h;h=b==null?0:(g=q(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=xk(b,e);if(f){return f.kb(c)}}e[e.length]=new Zj(b,c);++a.b;return null}
function fm(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+sj(a,c++)}b=b|0;return b}
function Vn(a){var b;b=(kb(a.a),a.r);if(null!=b&&b.length!=0){kq((Fp(),kb(a.c),null!=a.v.props[tr]?a.v.props[tr]:null),b);zq(Ep,null);po(a,b)}else{Tp((Fp(),Cp),(kb(a.c),null!=a.v.props[tr]?a.v.props[tr]:null))}}
function lq(b,c){var d,e;try{v((I(),I(),H),(e=new nq(b,c),sd(md(mf,1),Uq,1,5,[(Wi(),c?true:false)]),e))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){d=a;throw qi(d)}else if(_d(a,4)){d=a;throw qi(new jj(d))}else throw qi(a)}}
function Sp(b,c,d){var e,f;try{return A((I(),I(),H),(f=new aq(b,c,d),sd(md(mf,1),Uq,1,5,[c,d,(Wi(),false)]),f),null)}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){e=a;throw qi(e)}else if(_d(a,4)){e=a;throw qi(new jj(e))}else throw qi(a)}}
function on(){var a,b;b=U((Fp(),Cp).e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,['todo-count'])),$wnd.React.createElement('strong',null,''+b),' '+a+' left')}
function M(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=od(mf,Uq,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function Dj(a,b){var c,d,e;c=b.ib();e=b.jb();d=de(c)?c==null?Fj(zk(a.a,null)):Nk(a.b,c):Fj(zk(a.a,c));if(!(ee(e)===ee(d)||e!=null&&o(e,d))){return false}if(d==null&&!(de(c)?Jj(a,c):!!zk(a.a,c))){return false}return true}
function gn(){bn();var a,b;++jm;this.e=Li(_o.prototype.Ab,_o,[]);this.d=1;this.c=(a=new mb((I(),null)),a);this.a=t(new hn,(cb(),cb(),bb),null,false);this.b=(b=new yb(null,new Gb(new mn(this)),false),b);this.d=2;this.d=4}
function In(){Bn();var a,b,c;++jm;this.f=Li(ep.prototype.zb,ep,[this]);this.e=Li(fp.prototype.yb,fp,[this]);this.d=1;this.c=(b=new mb((I(),null)),b);this.b=(a=new mb(null),a);this.a=(c=new yb(null,new Gb(new Nn(this)),false),c);this.d=2;this.d=4}
function dc(a){var b;if(0==a.length){b=(Ri(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Qi.title,b)}else{(Ri(),$wnd.window.window).location.hash=a}}
function lj(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Ld(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&er)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?dr:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?dr:0;f=d?cr:0;e=c>>b-44}return wd(e&cr,f&cr,g&dr)}
function Ji(a,b,c){var d=Gi,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Gi[b]),Mi(h));_.Cb=c;!b&&(_.Db=Oi);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.Bb=f)}
function ej(a){if(a.X()){var b=a.c;b.Y()?(a.k='['+b.j):!b.X()?(a.k='[L'+b.V()+';'):(a.k='['+b.V());a.b=b.U()+'[]';a.i=b.W()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=fj('.',[c,fj('$',d)]);a.b=fj('.',[c,fj('.',d)]);a.i=d[d.length-1]}
function km(a,b){var c,d,e,f;if(null==a||null==b||!tj(typeof(a),Sq)||!tj(typeof(b),Sq)){return !(a===b)}f=$wnd.Object.keys(a);if($wnd.Object.keys(b).length!=f.length){return true}for(d=0,e=f.length;d<e;++d){c=f[d];if(!(a[c]===b[c])){return true}}return false}
function Ed(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return mj(c)}if(b==0&&d!=0&&c==0){return mj(d)+22}if(b!=0&&d==0&&c==0){return mj(b)+44}return -1}
function xb(b){var c,d,e,f;switch(b.p){case 1:return false;case 0:case 3:return true;case 2:{for(e=new hk(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.c){f=d.c;c=f.a;try{U(c)}catch(a){a=pi(a);if(!_d(a,4))throw qi(a)}if(3==b.p){return true}}}}}rb(b);return false}
function Id(a){var b,c,d,e,f;if(isNaN(a)){return Vd(),Ud}if(a<-9223372036854775808){return Vd(),Sd}if(a>=9223372036854775807){return Vd(),Rd}e=false;if(a<0){e=true;a=-a}d=0;if(a>=fr){d=fe(a/fr);a-=d*fr}c=0;if(a>=gr){c=fe(a/gr);a-=c*gr}b=fe(a);f=wd(b,c,d);e&&Cd(f);return f}
function oc(){var a,b,c,d;this.f=new tc(this);this.d=1;this.c=(c=new mb((I(),null)),c);this.b=(d=new mb(null),d);this.a=(b=new mb(null),b);this.d=2;Si((Ri(),$wnd.window.window),Yq,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1));this.d=4}
function wb(a,b,c){var d,e;if(b!=a.p){e=a.p;a.p=b;if(!a.c&&3==b){ub((d=a.k,d));c&&(a.d||a.o||D((I(),I(),H),a))}else if(!!a.c&&1==e&&(3==b||2==b)){lb(a.c);ub((d=a.k,d));c&&(a.d||a.o||D((I(),I(),H),a))}else if(0==a.p){ub((d=a.i,d));_j(a.b,new Ab(a));a.b.a=od(mf,Uq,1,0,5,1)}else 0==e&&ub((d=a.g,d))}}
function Yp(){var a,b;this.i=new uk;this.g=1;this.f=(b=new mb((I(),null)),b);this.d=(a=new mb(null),a);this.c=t(new _p(this),(cb(),cb(),bb),null,false);this.e=t(new bq(this),(null,bb),null,false);this.a=t(new cq(this),(null,bb),null,false);this.b=t(new dq(this),(null,bb),null,false);this.g=2;this.g=4}
function Ik(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function Aq(a,b){var c,d;this.k=Xk(a);this.i=Xk(b);this.g=1;this.f=(d=new mb((I(),null)),d);this.d=(c=new mb(null),c);this.b=t(new Cq(this),(cb(),cb(),bb),null,false);this.c=t(new Dq(this),(null,bb),null,false);this.e=s((null,H),new Eq(this),false);this.a=s((null,H),new Fq(this),false);this.g=2;this.g=3;F((null,H));this.g=4}
function Pd(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return '0'}if(a.h==er&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Pd(Jd(a))}c=a;d='';while(!(c.l==0&&c.m==0&&c.h==0)){e=ud(1000000000);c=xd(c,e,true);b=''+Od(td);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b='0'+b}}d=b+d}return d}
function Ad(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=Dd(b)-Dd(a);g=Kd(b,j);i=wd(0,0,0);while(j>=0){h=Fd(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;g.h=l>>>1;g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&Cd(i);if(f){if(d){td=Jd(a);e&&(td=Nd(td,(Vd(),Td)))}else{td=wd(a.l,a.m,a.h)}}return i}
function Zm(){Zm=Ki;Dm=new $m(lr,0);Em=new $m('checkbox',1);Fm=new $m('color',2);Gm=new $m('date',3);Hm=new $m('datetime',4);Im=new $m('email',5);Jm=new $m('file',6);Km=new $m('hidden',7);Lm=new $m('image',8);Mm=new $m('month',9);Nm=new $m(Tq,10);Om=new $m('password',11);Pm=new $m('radio',12);Qm=new $m('range',13);Rm=new $m('reset',14);Sm=new $m('search',15);Tm=new $m('submit',16);Um=new $m('tel',17);Vm=new $m('text',18);Wm=new $m('time',19);Xm=new $m('url',20);Ym=new $m('week',21)}
function qo(){Zn();var a,b,c,d;++jm;this.j=Li(ip.prototype.zb,ip,[this]);this.o=Li(jp.prototype.xb,jp,[this]);this.p=Li(kp.prototype.yb,kp,[this]);this.n=Li(lp.prototype.Ab,lp,[this]);this.k=Li(mp.prototype.Ab,mp,[this]);this.i=Li(np.prototype.yb,np,[this]);this.g=1;this.f=(b=new mb((I(),null)),b);this.c=(c=new mb(null),c);this.a=(a=new mb(null),a);this.d=t(new Bo(this),(cb(),cb(),bb),null,false);this.b=(d=new yb(null,new Gb(new Fo(this)),false),d);this.e=(new Yb(new Ho(this),new Io(this),false)).c;this.g=2;this.g=4}
function Mb(a){var b,c,d,e,f,g,h,i,j,k,l;if(!a.f){return}i=1;d=false;b=0;if(!!a.c&&!a.f.d){l=a.c.a.length;for(g=0;g<l;g++){j=ak(a.c,g);if(-1!=j.e&&-2!=j.e){j.e=-1;g!=b&&ek(a.c,b,j);++b;if(j.c){k=j.c;e=k.p;e==3&&(i=3)}}}}c=a.f.b;for(h=c.a.length-1;h>=0;h--){j=c.a[h];if(-1==j.e){j.e=0}else{hb(j,a.f);d=true}}!a.f.d&&1!=i&&a.f.p<i&&wb(a.f,i,false);if(a.c){for(f=b-1;f>=0;f--){j=ak(a.c,f);if(-1==j.e){j.e=0;eb(j,a.f);d=true}}}if(a.c){for(f=a.c.a.length-1;f>=b;f--){ck(a.c,f)}d&&tb(a.f,a.c)}else{d&&tb(a.f,new gk)}ab(a.f)&&!!a.f.c&&a.f.c.b.a.length<=0&&!a.f.a.e&&Qb(a,a.f.c)}
function xd(a,b,c){var d,e,f,g,h,i;if(b.l==0&&b.m==0&&b.h==0){throw qi(new Ui)}if(a.l==0&&a.m==0&&a.h==0){c&&(td=wd(0,0,0));return wd(0,0,0)}if(b.h==er&&b.m==0&&b.l==0){return yd(a,c)}i=false;if(b.h>>19!=0){b=Jd(b);i=true}g=Ed(b);f=false;e=false;d=false;if(a.h==er&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=vd((Vd(),Rd));d=true;i=!i}else{h=Ld(a,g);i&&Cd(h);c&&(td=wd(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Jd(a);d=true;i=!i}if(g!=-1){return zd(a,g,i,f,c)}if(Hd(a,b)<0){c&&(f?(td=Jd(a)):(td=wd(a.l,a.m,a.h)));return wd(0,0,0)}return Ad(d?a:wd(a.l,a.m,a.h),b,i,f,e,c)}
function No(a){var b;return a.t=false,$wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(vr,pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[vr])),$wnd.React.createElement('h1',null,'todos'),rp(new sp)),U((Fp(),Cp).c)?null:$wnd.React.createElement('section',pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[vr])),$wnd.React.createElement(sr,xm(Am(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[wr])),(Zm(),Em)),a.d)),$wnd.React.createElement.apply(null,['ul',pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,['todo-list']))].concat((b=vl(yl(U(Ep.c).db(),new yp),new jl(new ml,new ll,new il)),fk(b,rd(b.a.length)))))),U(Cp.c)?null:Vo(new Wo)))}
function Wn(a){var b,c;c=(kb(a.c),null!=a.v.props[tr]?a.v.props[tr]:null);b=(kb(c.a),c.e);return $wnd.React.createElement('li',pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[Xn(b,U(a.d))])),$wnd.React.createElement('div',pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,['view'])),$wnd.React.createElement(sr,xm(um(Am(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,['toggle'])),(Zm(),Em)),b),a.p)),$wnd.React.createElement('label',Cm(new $wnd.Object,a.n),(kb(c.b),c.g)),$wnd.React.createElement(lr,sm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,['destroy'])),a.k))),$wnd.React.createElement(sr,ym(xm(wm(vm(pm(qm(new $wnd.Object,Li(tp.prototype.J,tp,[a])),sd(md(pf,1),Uq,2,6,['edit'])),(kb(a.a),a.r)),a.o),a.i),a.j)))}
function dn(a){var b;return a.t=false,b=U((Fp(),Ep).b),$wnd.React.createElement(mr,pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[mr])),Xo(new Yo),$wnd.React.createElement('ul',pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',rm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[(Jq(),Hq)==b?nr:''])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',rm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[Gq==b?nr:''])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',rm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[Iq==b?nr:''])),or),'Completed'))),U(a.a)?$wnd.React.createElement(lr,sm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[pr])),a.e),qr):null)}
function Kk(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[kr]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ik()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[kr]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Sq='object',Tq='number',Uq={3:1,6:1},Vq={12:1},Wq={22:1},Xq={8:1},Yq='hashchange',Zq={14:1},$q='__noinit__',_q='__java$exception',ar={3:1,13:1,5:1,4:1},br='null',cr=4194303,dr=1048575,er=524288,fr=17592186044416,gr=4194304,hr=-17592186044416,ir={24:1,47:1},jr={42:1},kr='delete',lr='button',mr='footer',nr='selected',or='#completed',pr='clear-completed',qr='Clear Completed',rr={12:1,21:1},sr='input',tr='todo',ur='completed',vr='header',wr='toggle-all',xr='active';var _,Gi,Bi,oi=-1;Hi();Ji(1,null,{},n);_.w=zr;_.A=function(){return this.Bb};_.B=Ar;_.C=function(){var a;return Zi(p(this))+'@'+(a=q(this)>>>0,a.toString(16))};_.equals=function(a){return this.w(a)};_.hashCode=function(){return this.B()};_.toString=function(){return this.C()};var Wd,Xd,Yd;Ji(63,1,{},$i);_.T=function(a){var b;b=new $i;b.e=4;a>1?(b.c=cj(this,a-1)):(b.c=this);return b};_.U=function(){Yi(this);return this.b};_.V=function(){return Zi(this)};_.W=function(){return Yi(this),this.i};_.X=function(){return (this.e&4)!=0};_.Y=function(){return (this.e&1)!=0};_.C=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Yi(this),this.k)};_.e=0;_.g=0;var Xi=1;var mf=aj(1);var bf=aj(63);Ji(65,1,{65:1},G);_.a=1;_.c=true;_.d=0;var ge=aj(65);var H;Ji(167,1,{},R);_.b=0;_.c=false;_.d=0;var he=aj(167);Ji(255,1,Vq);_.C=function(){var a;return Zi(this.Bb)+'@'+(a=q(this)>>>0,a.toString(16))};var me=aj(255);Ji(139,255,Vq,W);_.D=function(){T(this)};_.F=Br;_.a=false;_.e=false;var ke=aj(139);Ji(140,1,Wq,X);_.G=function(){S(this.a)};var ie=aj(140);Ji(141,1,{238:1},Y);_.H=function(a){V(this.a,a)};var je=aj(141);var bb;Ji(142,1,{263:1},db);_.I=yr;var le=aj(142);Ji(11,255,{12:1,11:1},mb);_.D=function(){fb(this)};_.F=function(){return -2==this.e};_.a=1;_.d=false;_.e=0;var oe=aj(11);Ji(138,1,Xq,nb);_.G=function(){gb(this.a)};var ne=aj(138);Ji(23,255,{12:1,23:1},yb);_.D=function(){ob(this)};_.F=Lr;_.d=false;_.e=false;_.f=false;_.o=false;_.p=0;var re=aj(23);Ji(143,1,Xq,zb);_.G=function(){sb(this.a)};var pe=aj(143);Ji(66,1,{},Ab);_.J=function(a){qb(this.a,a)};var qe=aj(66);Ji(145,1,{},Eb);_.a=0;_.b=100;_.d=0;var se=aj(145);Ji(146,1,{238:1},Fb);_.H=function(a){r((I(),I(),H),this.a,a)};var te=aj(146);Ji(39,1,{238:1},Gb);_.H=function(a){this.a.G()};var ue=aj(39);Ji(178,1,Vq,Ib);_.D=function(){Hb(this)};_.F=Cr;_.b=false;var ve=aj(178);Ji(166,1,{},Ub);_.C=function(){var a;return Yi(we),we.k+'@'+(a=am(this)>>>0,a.toString(16))};_.b=0;var Jb;var we=aj(166);Ji(77,255,Vq,Yb);_.D=function(){Z(this.c)};_.F=function(){return $(this.c)};var Be=aj(77);Ji(224,1,{263:1},Zb);_.I=yr;var xe=aj(224);Ji(225,1,Wq,$b);_.G=function(){Z(this.a.c)};var ye=aj(225);Ji(226,1,Wq,_b);_.G=function(){Xb(this.a)};var ze=aj(226);Ji(227,1,Wq,ac);_.G=function(){Z(this.a.a)};var Ae=aj(227);Ji(51,1,{51:1});_.e='';_.g='';_.i=true;_.j='';var Ie=aj(51);Ji(123,51,{12:1,51:1,21:1},oc);_.D=function(){if(this.d>=0){this.d=-2;v((I(),I(),H),new pc(this));this.d=-1}};_.w=zr;_.B=Ar;_.F=Or;_.L=Pr;_.C=function(){var a;return Yi(Ge),Ge.k+'@'+(a=am(this)>>>0,a.toString(16))};_.d=0;var Ge=aj(123);Ji(124,1,Xq,pc);_.G=function(){ic(this.a)};var Ce=aj(124);Ji(125,1,Xq,qc);_.G=function(){bc(this.a,this.b)};var De=aj(125);Ji(126,1,Xq,rc);_.G=function(){jc(this.a)};var Ee=aj(126);Ji(127,1,Xq,sc);_.G=function(){ec(this.a)};var Fe=aj(127);Ji(91,1,{},tc);_.handleEvent=function(a){cc(this.a,a)};var He=aj(91);Ji(128,1,{});var Pe=aj(128);Ji(96,1,{},vc);_.M=function(a){return !(_d(a,12)&&a.F())};var Je=aj(96);Ji(97,1,{},wc);_.N=function(a){return a.a};var Ke=aj(97);Ji(92,1,Zq,xc);_.K=function(){return Wi(),Bc(this.a)?true:false};var Le=aj(92);Ji(93,1,Xq,yc);_.G=function(){uc(this.a,this.b,false)};var Me=aj(93);Ji(94,1,{},zc);_.J=function(a){Z(a)};var Ne=aj(94);Ji(95,1,{},Ac);_.O=function(){return 'Arez-0157: Called detach() passing an entity that was not attached to the container. Entity: '+this.a};var Oe=aj(95);Ji(129,128,{});var Qe=aj(129);Ji(73,1,{12:1,73:1},Dc);_.D=function(){Cc(this)};_.F=function(){return $(this.a)};var Re=aj(73);Ji(4,1,{3:1,4:1});_.P=function(a){return new Error(a)};_.Q=function(){return this.f};_.R=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Zi(this.Bb),c==null?a:a+': '+c);Fc(this,Hc(this.P(b)));jd(this)};_.C=function(){return Gc(this,this.Q())};_.e=$q;_.g=true;var qf=aj(4);Ji(13,4,{3:1,13:1,4:1});var ef=aj(13);Ji(5,13,ar);var nf=aj(5);Ji(64,5,ar);var jf=aj(64);Ji(85,64,ar);var Ve=aj(85);Ji(43,85,{43:1,3:1,13:1,5:1,4:1},Nc);_.Q=function(){Mc(this);return this.c};_.S=function(){return ee(this.b)===ee(Kc)?null:this.b};var Kc;var Se=aj(43);var Te=aj(0);Ji(241,1,{});var Ue=aj(241);var Pc=0,Qc=0,Rc=-1;Ji(122,241,{},dd);var _c;var We=aj(122);var gd;Ji(252,1,{});var Ye=aj(252);Ji(86,252,{},ld);var Xe=aj(86);var td;var Rd,Sd,Td,Ud;var Qi;Ji(83,1,{80:1});_.C=Br;var Ze=aj(83);Ji(90,5,ar,Ui);var $e=aj(90);Ji(87,5,ar);var gf=aj(87);Ji(169,87,ar,Vi);var _e=aj(169);Wd={3:1,81:1,29:1};var af=aj(81);Ji(49,1,{3:1,49:1});var lf=aj(49);Xd={3:1,29:1,49:1};var cf=aj(251);Ji(34,1,{3:1,29:1,34:1});_.w=zr;_.B=Ar;_.C=function(){return this.a!=null?this.a:''+this.b};_.b=0;var df=aj(34);Ji(9,5,ar,ij,jj);var ff=aj(9);Ji(32,49,{3:1,29:1,32:1,49:1},kj);_.w=function(a){return _d(a,32)&&a.a==this.a};_.B=Br;_.C=function(){return ''+this.a};_.a=0;var hf=aj(32);var oj;Ji(309,1,{});Ji(89,64,ar,rj);_.P=function(a){return new TypeError(a)};var kf=aj(89);Yd={3:1,80:1,29:1,2:1};var pf=aj(2);Ji(84,83,{80:1},xj);var of=aj(84);Ji(313,1,{});Ji(50,5,ar,yj,zj);var rf=aj(50);Ji(253,1,{24:1});_.Z=Gr;_.cb=Hr;_.db=Ir;_._=function(a){throw qi(new zj('Add not supported on this collection'))};_.ab=function(a){return Aj(this,a)};_.C=function(){return Cj(this)};var sf=aj(253);Ji(257,1,{239:1});_.w=function(a){var b,c,d;if(a===this){return true}if(!_d(a,45)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Tj((new Qj(d)).a);c.b;){b=Sj(c);if(!Dj(this,b)){return false}}return true};_.B=function(){return jk(new Qj(this))};_.C=function(){var a,b,c;c=new hl(', ','{','}');for(b=new Tj((new Qj(this)).a);b.b;){a=Sj(b);fl(c,Ej(this,a.ib())+'='+Ej(this,a.jb()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ff=aj(257);Ji(55,257,{239:1});var vf=aj(55);Ji(256,253,ir);_.cb=Jr;_.w=function(a){return Pj(this,a)};_.B=function(){return jk(this)};var Gf=aj(256);Ji(27,256,ir,Qj);_.ab=function(a){if(_d(a,42)){return Dj(this.a,a)}return false};_.$=function(){return new Tj(this.a)};_.bb=Er;var uf=aj(27);Ji(28,1,{},Tj);_.eb=Dr;_.gb=function(){return Sj(this)};_.fb=Cr;_.b=false;var tf=aj(28);Ji(254,253,{24:1,261:1});_.cb=function(){return new el(this,16)};_.hb=function(a,b){throw qi(new zj('Add not supported on this list'))};_._=function(a){this.hb(this.bb(),a);return true};_.w=function(a){var b,c,d,e,f;if(a===this){return true}if(!_d(a,18)){return false}f=a;if(this.bb()!=f.a.length){return false}e=new hk(f);for(c=new hk(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(ee(b)===ee(d)||b!=null&&o(b,d))){return false}}return true};_.B=function(){return kk(this)};_.$=function(){return new Uj(this)};var xf=aj(254);Ji(116,1,{},Uj);_.eb=Dr;_.fb=function(){return this.a<this.b.a.length};_.gb=function(){return ak(this.b,this.a++)};_.a=0;var wf=aj(116);Ji(68,256,ir,Vj);_.ab=Kr;_.$=function(){var a;return a=new Tj((new Qj(this.a)).a),new Wj(a)};_.bb=Er;var zf=aj(68);Ji(53,1,{},Wj);_.eb=Dr;_.fb=Fr;_.gb=function(){var a;return a=Sj(this.a),a.ib()};var yf=aj(53);Ji(69,253,{24:1},Xj);_.ab=function(a){return Hj(this.a,a)};_.$=function(){var a;a=new Tj((new Qj(this.a)).a);return new Yj(a)};_.bb=Er;var Bf=aj(69);Ji(152,1,{},Yj);_.eb=Dr;_.fb=Fr;_.gb=function(){var a;a=Sj(this.a);return a.jb()};var Af=aj(152);Ji(150,1,jr);_.w=function(a){var b;if(!_d(a,42)){return false}b=a;return tk(this.a,b.ib())&&tk(this.b,b.jb())};_.ib=Br;_.jb=Cr;_.B=function(){return Wk(this.a)^Wk(this.b)};_.kb=function(a){var b;b=this.b;this.b=a;return b};_.C=function(){return this.a+'='+this.b};var Cf=aj(150);Ji(151,150,jr,Zj);var Df=aj(151);Ji(258,1,jr);_.w=function(a){var b;if(!_d(a,42)){return false}b=a;return tk(this.b.value[0],b.ib())&&tk(Sk(this),b.jb())};_.B=function(){return Wk(this.b.value[0])^Wk(Sk(this))};_.C=function(){return this.b.value[0]+'='+Sk(this)};var Ef=aj(258);Ji(18,254,{3:1,18:1,24:1,261:1},gk);_.hb=function(a,b){Wl(this.a,a,b)};_._=function(a){return $j(this,a)};_.ab=function(a){return bk(this,a,0)!=-1};_.Z=function(a){_j(this,a)};_.$=function(){return new hk(this)};_.bb=function(){return this.a.length};var If=aj(18);Ji(20,1,{},hk);_.eb=Dr;_.fb=function(){return this.a<this.c.a.length};_.gb=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Hf=aj(20);Ji(147,1,{24:1});_.Z=Gr;_.cb=Hr;_.db=Ir;_._=function(a){throw qi(new yj)};_.$=function(){var a;return new mk((a=new Tj((new Qj((new Vj(this.a.a)).a)).a),new Wj(a)))};_.bb=function(){return Oj(this.a.a)};_.C=function(){return Cj(this.a)};var Kf=aj(147);Ji(149,1,{},mk);_.eb=Dr;_.fb=function(){return this.a.a.b};_.gb=function(){var a;return a=Sj(this.a.a),a.ib()};var Jf=aj(149);Ji(148,147,ir,nk);_.cb=Jr;_.w=function(a){return Pj(this.a,a)};_.B=function(){return jk(this.a)};var Lf=aj(148);Ji(58,1,{3:1,29:1,58:1},ok);_.w=function(a){return _d(a,58)&&ui(vi(this.a.getTime()),vi(a.a.getTime()))};_.B=function(){var a;a=vi(this.a.getTime());return yi(Ai(a,ti(Md(be(a)?xi(a):a,32))))};_.C=function(){var a,b,c;c=-this.a.getTimezoneOffset();a=(c>=0?'+':'')+(c/60|0);b=pk($wnd.Math.abs(c)%60);return (sk(),qk)[this.a.getDay()]+' '+rk[this.a.getMonth()]+' '+pk(this.a.getDate())+' '+pk(this.a.getHours())+':'+pk(this.a.getMinutes())+':'+pk(this.a.getSeconds())+' GMT'+a+b+' '+this.a.getFullYear()};var Mf=aj(58);var qk,rk;Ji(45,55,{3:1,45:1,239:1},uk,vk);var Nf=aj(45);Ji(179,256,{3:1,24:1,47:1},wk);_._=function(a){var b;return b=Kj(this.a,a,this),b==null};_.ab=Kr;_.$=function(){var a;return a=new Tj((new Qj((new Vj(this.a)).a)).a),new Wj(a)};_.bb=Er;var Of=aj(179);Ji(57,1,{},Ck);_.Z=Gr;_.$=function(){return new Dk(this)};_.b=0;var Qf=aj(57);Ji(72,1,{},Dk);_.eb=Dr;_.gb=function(){return this.d=this.a[this.c++],this.d};_.fb=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Pf=aj(72);var Gk;Ji(56,1,{},Qk);_.Z=Gr;_.$=function(){return new Rk(this)};_.b=0;_.c=0;var Tf=aj(56);Ji(71,1,{},Rk);_.eb=Dr;_.gb=function(){return this.c=this.a,this.a=this.b.next(),new Tk(this.d,this.c,this.d.c)};_.fb=function(){return !this.a.done};var Rf=aj(71);Ji(168,258,jr,Tk);_.ib=function(){return this.b.value[0]};_.jb=function(){return Sk(this)};_.kb=function(a){return Ok(this.a,this.b.value[0],a)};_.c=0;var Sf=aj(168);Ji(154,1,{});_.eb=Mr;_.lb=Lr;_.mb=function(){return this.e};_.d=0;_.e=0;var Xf=aj(154);Ji(54,154,{});var Uf=aj(54);Ji(117,1,{});_.eb=Mr;_.lb=Cr;_.mb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Wf=aj(117);Ji(118,117,{},cl);_.eb=function(a){_k(this,a)};_.nb=function(a){return al(this,a)};var Vf=aj(118);Ji(17,1,{},el);_.lb=Br;_.mb=function(){dl(this);return this.c};_.eb=function(a){dl(this);this.d.eb(a)};_.nb=function(a){dl(this);if(this.d.fb()){a.J(this.d.gb());return true}return false};_.a=0;_.c=0;var Yf=aj(17);Ji(44,1,{44:1},hl);_.C=function(){return gl(this)};var Zf=aj(44);Ji(33,1,{},il);_.N=function(a){return a};var $f=aj(33);Ji(30,1,{},jl);var _f=aj(30);Ji(121,1,{},kl);_.N=function(a){return gl(a)};var ag=aj(121);Ji(35,1,{},ll);_.ob=function(a,b){a._(b)};var bg=aj(35);Ji(36,1,{},ml);_.O=function(){return new gk};var cg=aj(36);Ji(120,1,{},nl);_.ob=function(a,b){fl(a,b)};var dg=aj(120);Ji(119,1,{},ol);_.O=function(){return new hl(this.a,this.b,this.c)};var eg=aj(119);Ji(153,1,{});_.c=false;var rg=aj(153);Ji(19,153,{},Cl);var sl;var qg=aj(19);Ji(163,54,{},Fl);_.nb=function(a){return this.a.a.nb(new Hl(a))};var gg=aj(163);Ji(164,1,{},Hl);_.J=function(a){Gl(this.a,a)};var fg=aj(164);Ji(70,54,{},Jl);_.nb=function(a){this.b=false;while(!this.b&&this.c.nb(new Kl(this,a)));return this.b};_.b=false;var ig=aj(70);Ji(158,1,{},Kl);_.J=function(a){Il(this.a,this.b,a)};var hg=aj(158);Ji(155,54,{},Ml);_.nb=function(a){return this.b.nb(new Nl(this,a))};var kg=aj(155);Ji(157,1,{},Nl);_.J=function(a){Ll(this.a,this.b,a)};var jg=aj(157);Ji(156,1,{},Pl);_.J=function(a){Ol(this,a)};var lg=aj(156);Ji(159,1,{},Ql);_.J=Nr;var mg=aj(159);Ji(160,1,{},Rl);_.J=Nr;var ng=aj(160);Ji(161,1,{},Tl);var og=aj(161);Ji(162,1,{},Vl);_.J=function(a){Ul(this,a)};var pg=aj(162);Ji(311,1,{});Ji(260,1,{});var sg=aj(260);Ji(308,1,{});var _l=0;var bm,cm=0,dm;Ji(773,1,{});Ji(793,1,{});Ji(259,1,{});_.pb=Qr;var ug=aj(259);Ji(38,259,{});_.rb=function(a,b){};_.ub=function(){return this.t=false,this.qb()};_.t=false;_.u=false;var jm=1;var tg=aj(38);Ji(37,$wnd.React.Component,{});Ii(Gi[1],_);_.render=function(){return mm(this.a)};var vg=aj(37);Ji(10,34,{3:1,29:1,34:1,10:1},$m);var Dm,Em,Fm,Gm,Hm,Im,Jm,Km,Lm,Mm,Nm,Om,Pm,Qm,Rm,Sm,Tm,Um,Vm,Wm,Xm,Ym;var wg=bj(10,_m);Ji(193,38,{});_.qb=function(){var a;return a=U((Fp(),Ep).b),$wnd.React.createElement(mr,pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[mr])),Xo(new Yo),$wnd.React.createElement('ul',pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',rm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[(Jq(),Hq)==a?nr:''])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',rm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[Gq==a?nr:''])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',rm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[Iq==a?nr:''])),or),'Completed'))),U(this.a)?$wnd.React.createElement(lr,sm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[pr])),this.e),qr):null)};var rh=aj(193);Ji(194,193,{});_.tb=Rr;var an;var vh=aj(194);Ji(195,194,rr,gn);_.D=function(){if(this.d>=0){this.d=-2;v((I(),I(),H),new nn(this));this.d=-1}};_.w=zr;_.sb=Sr;_.B=Ar;_.F=Or;_.L=Pr;_.tb=function(b){var c;try{v((I(),I(),H),new jn)}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}};_.C=function(){var a;return Yi(Ig),Ig.k+'@'+(a=am(this)>>>0,a.toString(16))};_.ub=function(){var b;try{return C((I(),I(),H),this.b,new ln(this))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){b=a;throw qi(b)}else if(_d(a,4)){b=a;throw qi(new jj(b))}else throw qi(a)}};_.d=0;var Ig=aj(195);Ji(196,1,Zq,hn);_.K=function(){return Wi(),U((Fp(),Cp).b).a>0?true:false};var xg=aj(196);Ji(199,1,Xq,jn);_.G=Qr;var yg=aj(199);Ji(200,1,Xq,kn);_.G=function(){gq((Fp(),Dp))};var zg=aj(200);Ji(201,1,Zq,ln);_.K=function(){return dn(this.a)};var Ag=aj(201);Ji(197,1,Wq,mn);_.G=function(){en(this.a)};var Bg=aj(197);Ji(198,1,Xq,nn);_.G=function(){fn(this.a)};var Cg=aj(198);Ji(230,38,{});_.qb=function(){return on()};var qh=aj(230);Ji(231,230,{});_.tb=Rr;var pn;var uh=aj(231);Ji(232,231,rr,tn);_.D=function(){if(this.c>=0){this.c=-2;v((I(),I(),H),new wn(this));this.c=-1}};_.w=zr;_.sb=Sr;_.B=Ar;_.F=Tr;_.L=Ur;_.tb=function(b){var c;try{v((I(),I(),H),new xn)}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}};_.C=function(){var a;return Yi(Hg),Hg.k+'@'+(a=am(this)>>>0,a.toString(16))};_.ub=function(){var b;try{return C((I(),I(),H),this.a,new vn(this))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){b=a;throw qi(b)}else if(_d(a,4)){b=a;throw qi(new jj(b))}else throw qi(a)}};_.c=0;var Hg=aj(232);Ji(233,1,Wq,un);_.G=function(){en(this.a)};var Dg=aj(233);Ji(236,1,Zq,vn);_.K=function(){return this.a.t=false,on()};var Eg=aj(236);Ji(234,1,Xq,wn);_.G=function(){sn(this.a)};var Fg=aj(234);Ji(235,1,Xq,xn);_.G=Qr;var Gg=aj(235);Ji(184,38,{});_.qb=function(){return $wnd.React.createElement(sr,tm(xm(ym(Bm(zm(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,['new-todo']))),(kb(this.b),this.g)),this.f),this.e)))};_.g='';var Dh=aj(184);Ji(185,184,{});_.tb=Rr;var An;var xh=aj(185);Ji(186,185,rr,In);_.D=function(){if(this.d>=0){this.d=-2;v((I(),I(),H),new On(this));this.d=-1}};_.w=zr;_.sb=Sr;_.B=Ar;_.F=Or;_.L=Pr;_.tb=function(b){var c;try{v((I(),I(),H),new Jn)}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}};_.C=function(){var a;return Yi(Pg),Pg.k+'@'+(a=am(this)>>>0,a.toString(16))};_.ub=function(){var b;try{return C((I(),I(),H),this.a,new Mn(this))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){b=a;throw qi(b)}else if(_d(a,4)){b=a;throw qi(new jj(b))}else throw qi(a)}};_.d=0;var Pg=aj(186);Ji(189,1,Xq,Jn);_.G=Qr;var Jg=aj(189);Ji(190,1,Xq,Kn);_.G=function(){zn(this.a,this.b)};var Kg=aj(190);Ji(191,1,Xq,Ln);_.G=function(){yn(this.a,this.b)};var Lg=aj(191);Ji(192,1,Zq,Mn);_.K=function(){return En(this.a)};var Mg=aj(192);Ji(187,1,Wq,Nn);_.G=function(){en(this.a)};var Ng=aj(187);Ji(188,1,Xq,On);_.G=function(){Gn(this.a)};var Og=aj(188);Ji(203,38,{});_.rb=function(a,b){Pn(this)};_.pb=function(){oo(this)};_.qb=function(){return Wn(this)};_.s=false;var Fh=aj(203);Ji(204,203,{});_.tb=function(a){this.v.props[tr]===(null==a?null:a[tr])||jb(this.c)};var Yn;var zh=aj(204);Ji(205,204,rr,qo);_.rb=function(b,c){var d;try{v((I(),I(),H),new vo(this,b,c))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){d=a;throw qi(d)}else if(_d(a,4)){d=a;throw qi(new jj(d))}else throw qi(a)}};_.D=function(){$n(this)};_.w=zr;_.sb=Sr;_.B=Ar;_.F=Yr;_.L=Zr;_.tb=function(b){var c;try{v((I(),I(),H),new wo(this,b))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}};_.C=function(){var a;return Yi(hh),hh.k+'@'+(a=am(this)>>>0,a.toString(16))};_.ub=function(){var b;try{return C((I(),I(),H),this.b,new Go(this))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){b=a;throw qi(b)}else if(_d(a,4)){b=a;throw qi(new jj(b))}else throw qi(a)}};_.g=0;var hh=aj(205);Ji(208,1,{},ro);_.N=function(a){return a.K()};var Qg=aj(208);Ji(209,1,{},so);_.M=function(a){return _d(a,12)&&a.F()};var Rg=aj(209);Ji(212,1,Zq,to);_.K=function(){return _n(this.a)};var Sg=aj(212);Ji(213,1,Xq,uo);_.G=function(){co(this.a)};var Tg=aj(213);Ji(214,1,Xq,vo);_.G=function(){Pn(this.a)};var Ug=aj(214);Ji(215,1,Xq,wo);_.G=function(){eo(this.a,this.b)};var Vg=aj(215);Ji(216,1,Xq,xo);_.G=function(){fo(this.a)};var Wg=aj(216);Ji(217,1,Xq,yo);_.G=function(){Rn(this.a,this.b)};var Xg=aj(217);Ji(218,1,Xq,zo);_.G=function(){Vn(this.a)};var Yg=aj(218);Ji(219,1,Xq,Ao);_.G=function(){Np(_n(this.a))};var Zg=aj(219);Ji(206,1,Zq,Bo);_.K=function(){return go(this.a)};var $g=aj(206);Ji(220,1,Xq,Co);_.G=function(){Un(this.a)};var _g=aj(220);Ji(221,1,Xq,Do);_.G=function(){Tn(this.a)};var ah=aj(221);Ji(222,1,Xq,Eo);_.G=function(){Qn(this.a,this.b)};var bh=aj(222);Ji(207,1,Wq,Fo);_.G=function(){en(this.a)};var dh=aj(207);Ji(223,1,Zq,Go);_.K=function(){return io(this.a)};var eh=aj(223);Ji(210,1,Zq,Ho);_.K=function(){return jo(this.a)};var fh=aj(210);Ji(211,1,Xq,Io);_.G=function(){$n(this.a)};var gh=aj(211);Ji(170,38,{});_.qb=function(){var a;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(vr,pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[vr])),$wnd.React.createElement('h1',null,'todos'),rp(new sp)),U((Fp(),Cp).c)?null:$wnd.React.createElement('section',pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[vr])),$wnd.React.createElement(sr,xm(Am(pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,[wr])),(Zm(),Em)),this.d)),$wnd.React.createElement.apply(null,['ul',pm(new $wnd.Object,sd(md(pf,1),Uq,2,6,['todo-list']))].concat((a=vl(yl(U(Ep.c).db(),new yp),new jl(new ml,new ll,new il)),fk(a,rd(a.a.length)))))),U(Cp.c)?null:Vo(new Wo)))};var Ih=aj(170);Ji(171,170,{});_.tb=Rr;var Jo;var Bh=aj(171);Ji(172,171,rr,Po);_.D=function(){if(this.c>=0){this.c=-2;v((I(),I(),H),new To(this));this.c=-1}};_.w=zr;_.sb=Sr;_.B=Ar;_.F=Tr;_.L=Ur;_.tb=function(b){var c;try{v((I(),I(),H),new Uo)}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){c=a;throw qi(c)}else if(_d(a,4)){c=a;throw qi(new jj(c))}else throw qi(a)}};_.C=function(){var a;return Yi(nh),nh.k+'@'+(a=am(this)>>>0,a.toString(16))};_.ub=function(){var b;try{return C((I(),I(),H),this.a,new So(this))}catch(a){a=pi(a);if(_d(a,5)||_d(a,7)){b=a;throw qi(b)}else if(_d(a,4)){b=a;throw qi(new jj(b))}else throw qi(a)}};_.c=0;var nh=aj(172);Ji(173,1,Wq,Qo);_.G=function(){en(this.a)};var ih=aj(173);Ji(176,1,Xq,Ro);_.G=function(){var a;a=this.a.target;lq((Fp(),Dp),a.checked)};var jh=aj(176);Ji(177,1,Zq,So);_.K=function(){return No(this.a)};var kh=aj(177);Ji(174,1,Xq,To);_.G=function(){sn(this.a)};var lh=aj(174);Ji(175,1,Xq,Uo);_.G=Qr;var mh=aj(175);Ji(75,1,{},Wo);var oh=aj(75);Ji(76,1,{},Yo);var ph=aj(76);Ji(282,$wnd.Function,{},Zo);_.vb=function(a){return new $o(a)};Ji(181,37,{},$o);_.wb=function(){return new gn};_.componentDidMount=Qr;_.componentDidUpdate=Vr;_.componentWillUnmount=Wr;_.shouldComponentUpdate=Xr;var sh=aj(181);Ji(283,$wnd.Function,{},_o);_.Ab=function(a){cn()};Ji(293,$wnd.Function,{},ap);_.vb=function(a){return new bp(a)};Ji(202,37,{},bp);_.wb=function(){return new tn};_.componentDidMount=Qr;_.componentDidUpdate=Vr;_.componentWillUnmount=Wr;_.shouldComponentUpdate=Xr;var th=aj(202);Ji(279,$wnd.Function,{},cp);_.vb=function(a){return new dp(a)};Ji(180,37,{},dp);_.wb=function(){return new In};_.componentDidMount=Qr;_.componentDidUpdate=Vr;_.componentWillUnmount=Wr;_.shouldComponentUpdate=Xr;var wh=aj(180);Ji(280,$wnd.Function,{},ep);_.zb=function(a){Dn(this.a,a)};Ji(281,$wnd.Function,{},fp);_.yb=function(a){Cn(this.a,a)};Ji(284,$wnd.Function,{},gp);_.vb=function(a){return new hp(a)};Ji(183,37,{},hp);_.wb=function(){return new qo};_.componentDidMount=Qr;_.componentDidUpdate=Vr;_.componentWillUnmount=Wr;_.shouldComponentUpdate=Xr;var yh=aj(183);Ji(285,$wnd.Function,{},ip);_.zb=function(a){bo(this.a,a)};Ji(286,$wnd.Function,{},jp);_.xb=function(a){mo(this.a)};Ji(287,$wnd.Function,{},kp);_.yb=function(a){no(this.a)};Ji(288,$wnd.Function,{},lp);_.Ab=function(a){lo(this.a)};Ji(289,$wnd.Function,{},mp);_.Ab=function(a){ko(this.a)};Ji(290,$wnd.Function,{},np);_.yb=function(a){ao(this.a,a)};Ji(277,$wnd.Function,{},op);_.vb=function(a){return new pp(a)};Ji(144,37,{},pp);_.wb=function(){return new Po};_.componentDidMount=Qr;_.componentDidUpdate=Vr;_.componentWillUnmount=Wr;_.shouldComponentUpdate=Xr;var Ah=aj(144);Ji(278,$wnd.Function,{},qp);_.yb=function(a){Lo(a)};Ji(74,1,{},sp);var Ch=aj(74);Ji(292,$wnd.Function,{},tp);_.J=function(a){Sn(this.a,a)};Ji(182,1,{},xp);var Eh=aj(182);Ji(67,1,{},yp);_.N=function(a){return wp(up(a.f),a)};var Gh=aj(67);Ji(79,1,{},Ap);var Hh=aj(79);var Bp,Cp,Dp,Ep;Ji(59,1,{59:1});_.e=false;var li=aj(59);Ji(60,59,{12:1,21:1,60:1,59:1},Op);_.D=function(){if(this.d>=0){this.d=-2;v((I(),I(),H),new Qp(this));this.d=-1}};_.w=function(a){var b;if(this===a){return true}else if(null==a||!_d(a,60)){return false}else{b=a;return null!=this.f&&tj(this.f,b.f)}};_.B=function(){return null!=this.f?gm(this.f):Zl(this)};_.F=Or;_.L=function(){return Gp(this)};_.C=function(){var a;return Yi(Zh),Zh.k+'@'+(a=(null!=this.f?gm(this.f):Zl(this))>>>0,a.toString(16))};_.d=0;var Zh=aj(60);Ji(229,1,Xq,Pp);_.G=function(){Jp(this.a)};var Jh=aj(229);Ji(228,1,Xq,Qp);_.G=function(){Kp(this.a)};var Kh=aj(228);Ji(52,129,{52:1});var gi=aj(52);Ji(130,52,{12:1,21:1,52:1},Yp);_.D=function(){if(this.g>=0){this.g=-2;v((I(),I(),H),new Zp(this));this.g=-1}};_.w=zr;_.B=Ar;_.F=Yr;_.L=Zr;_.C=function(){var a;return Yi(Sh),Sh.k+'@'+(a=am(this)>>>0,a.toString(16))};_.g=0;var Sh=aj(130);Ji(135,1,Xq,Zp);_.G=function(){Vp(this.a)};var Lh=aj(135);Ji(136,1,Xq,$p);_.G=function(){uc(this.a,this.b,true)};var Mh=aj(136);Ji(131,1,Zq,_p);_.K=function(){return Wp(this.a)};var Nh=aj(131);Ji(137,1,Zq,aq);_.K=function(){return Rp(this.a,this.c,this.d,this.b)};_.b=false;var Oh=aj(137);Ji(132,1,Zq,bq);_.K=function(){return nj(yi(wl(Up(this.a))))};var Ph=aj(132);Ji(133,1,Zq,cq);_.K=function(){return nj(yi(wl(xl(Up(this.a),new Mq))))};var Qh=aj(133);Ji(134,1,Zq,dq);_.K=function(){return Xp(this.a)};var Rh=aj(134);Ji(102,1,{});var ki=aj(102);Ji(103,102,rr,mq);_.D=function(){if(this.b>=0){this.b=-2;v((I(),I(),H),new qq(this));this.b=-1}};_.w=zr;_.B=Ar;_.F=function(){return this.b<0};_.L=function(){var a;return a=this.b<0,a||kb(this.a),!a};_.C=function(){var a;return Yi(Yh),Yh.k+'@'+(a=am(this)>>>0,a.toString(16))};_.b=0;var Yh=aj(103);Ji(106,1,Xq,nq);_.G=function(){hq(this.a,this.b)};_.b=false;var Th=aj(106);Ji(107,1,Xq,oq);_.G=function(){mc(this.b,this.a)};var Uh=aj(107);Ji(108,1,Xq,pq);_.G=function(){iq(this.a)};var Vh=aj(108);Ji(104,1,Xq,qq);_.G=function(){fb(this.a.a)};var Wh=aj(104);Ji(105,1,Xq,rq);_.G=function(){jq(this.a,this.b)};var Xh=aj(105);Ji(109,1,{});var ni=aj(109);Ji(110,109,rr,Aq);_.D=function(){if(this.g>=0){this.g=-2;v((I(),I(),H),new Bq(this));this.g=-1}};_.w=zr;_.B=Ar;_.F=Yr;_.L=Zr;_.C=function(){var a;return Yi(di),di.k+'@'+(a=am(this)>>>0,a.toString(16))};_.g=0;var di=aj(110);Ji(115,1,Xq,Bq);_.G=function(){vq(this.a)};var $h=aj(115);Ji(111,1,Zq,Cq);_.K=function(){var a;return a=hc(this.a.i),tj(xr,a)||tj(ur,a)||tj('',a)?tj(xr,a)?(Jq(),Gq):tj(ur,a)?(Jq(),Iq):(Jq(),Hq):(Jq(),Hq)};var _h=aj(111);Ji(112,1,Zq,Dq);_.K=function(){return wq(this.a)};var ai=aj(112);Ji(113,1,Wq,Eq);_.G=function(){xq(this.a)};var bi=aj(113);Ji(114,1,Wq,Fq);_.G=function(){yq(this.a)};var ci=aj(114);Ji(40,34,{3:1,29:1,34:1,40:1},Kq);var Gq,Hq,Iq;var ei=bj(40,Lq);Ji(98,1,{},Mq);_.M=function(a){return !gc(a)};var fi=aj(98);Ji(100,1,{},Nq);_.M=function(a){return gc(a)};var hi=aj(100);Ji(101,1,{},Oq);_.J=function(a){Tp(this.a,a)};var ii=aj(101);Ji(99,1,{},Pq);_.J=function(a){eq(this.a,a)};_.a=false;var ji=aj(99);Ji(88,1,{},Qq);_.M=function(a){return tq(this.a,a)};var mi=aj(88);var Rq=(Sc(),Vc);var gwtOnLoad=gwtOnLoad=Ei;Ci(Pi);Fi('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();