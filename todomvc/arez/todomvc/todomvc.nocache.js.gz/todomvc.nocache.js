function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='930C81DC340792D3AC2459BDB4517AF7',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '930C81DC340792D3AC2459BDB4517AF7';function o(){}
function Ug(){}
function Qg(){}
function zb(){}
function Oc(){}
function Vc(){}
function fj(){}
function gj(){}
function Ij(){}
function yk(){}
function El(){}
function Jl(){}
function Ll(){}
function Nl(){}
function Pl(){}
function Rl(){}
function gm(){}
function vn(){}
function wn(){}
function Tc(a){Sc()}
function $g(){$g=Qg}
function ci(){Vh(this)}
function cc(a){this.a=a}
function ac(a){this.a=a}
function dc(a){this.a=a}
function db(a){this.a=a}
function qb(a){this.a=a}
function rb(a){this.a=a}
function sb(a){this.a=a}
function ec(a){this.a=a}
function ic(a){this.a=a}
function ij(a){this.a=a}
function dj(a){this.a=a}
function qh(a){this.a=a}
function Bh(a){this.a=a}
function Nh(a){this.a=a}
function Sh(a){this.a=a}
function Th(a){this.a=a}
function Tk(a){this.a=a}
function zk(a){this.a=a}
function Ak(a){this.a=a}
function Bk(a){this.a=a}
function Gk(a){this.a=a}
function Hk(a){this.a=a}
function Ik(a){this.a=a}
function Uk(a){this.a=a}
function Wk(a){this.a=a}
function Xk(a){this.a=a}
function ol(a){this.a=a}
function pl(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function Bl(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function Tl(a){this.a=a}
function Ul(a){this.a=a}
function Xl(a){this.a=a}
function Yl(a){this.a=a}
function $l(a){this.a=a}
function _l(a){this.a=a}
function zm(a){this.a=a}
function Am(a){this.a=a}
function Jm(a){this.a=a}
function Lm(a){this.a=a}
function Nm(a){this.a=a}
function Om(a){this.a=a}
function Pm(a){this.a=a}
function Zm(a){this.a=a}
function $m(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function nn(a){this.a=a}
function on(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function Rh(a){this.b=a}
function ei(a){this.c=a}
function Gl(){this.a={}}
function Il(){this.a={}}
function Wl(){this.a={}}
function fm(){this.a={}}
function im(){this.a={}}
function oo(){Cj(this.a)}
function to(){Ej(this.a)}
function oi(){this.a=xi()}
function Ci(){this.a=xi()}
function go(a){Gi(this,a)}
function jo(a){uh(this,a)}
function Y(a){Ib((H(),a))}
function Z(a){Jb((H(),a))}
function bb(a){Kb((H(),a))}
function A(a){--a.e;D(a)}
function C(a,b){wb(a.b,b)}
function mc(a,b){Jh(a.b,b)}
function hj(a,b){Zi(a.a,b)}
function Qm(a,b){Cm(a.c,b)}
function Rm(a,b){vm(b,a)}
function ej(a,b){a.a=b}
function yj(a,b,c){a[b]=c}
function w(a,b,c){s(a,c,b)}
function kb(a,b){a.b=Ji(b)}
function Bg(a){return a.e}
function ro(){return this.e}
function co(){return this.a}
function io(){return this.b}
function lo(){return this.c}
function wo(){return this.f}
function mo(){return this.d<0}
function so(){return this.c<0}
function vo(){return this.f<0}
function fo(){return qj(this)}
function xh(a,b){return a===b}
function _k(a,b){return a.g=b}
function Yh(a,b){return a.a[b]}
function mj(a,b){a.splice(b,1)}
function kc(a,b,c){Ih(a.b,b,c)}
function Ek(a){lc(a.b);eb(a.a)}
function Ch(a){sc.call(this,a)}
function Kl(a){zj.call(this,a)}
function Ml(a){zj.call(this,a)}
function Ol(a){zj.call(this,a)}
function Ql(a){zj.call(this,a)}
function Sl(a){zj.call(this,a)}
function cl(a){Dm((nm(),km),a)}
function no(){return H(),H(),G}
function eo(a){return this===a}
function ti(){ti=Qg;si=vi()}
function H(){H=Qg;G=new F}
function uc(){uc=Qg;tc=new o}
function Lc(){Lc=Qg;Kc=new Oc}
function nc(){this.b=new ii}
function F(){this.b=new xb}
function vh(){oc(this);this.F()}
function ho(){return Lh(this.a)}
function po(){return Hj(this.a)}
function Wc(a,b){return ih(a,b)}
function bh(a){ah(a);return a.k}
function Tb(a){$(a.a);return a.e}
function Ub(a){$(a.b);return a.g}
function rm(a){$(a.b);return a.i}
function sm(a){$(a.a);return a.g}
function cn(a){$(a.d);return a.f}
function Yi(a,b){a.Q(b);return a}
function xi(){ti();return new si}
function V(a){H();Jb(a);a.e=-2}
function Wb(a){Sb(a,($(a.b),a.g))}
function Cb(a){Db(a);!a.d&&Gb(a)}
function Zi(a,b){ej(a,Yi(a.a,b))}
function Ki(a,b){while(a.bb(b));}
function bc(a,b){this.a=a;this.b=b}
function jc(a,b){this.a=a;this.b=b}
function nh(a,b){this.a=a;this.b=b}
function Uh(a,b){this.a=a;this.b=b}
function aj(a,b){this.a=a;this.b=b}
function sk(a,b){nh.call(this,a,b)}
function Vk(a,b){this.a=a;this.b=b}
function rl(a,b){this.a=a;this.b=b}
function sl(a,b){this.a=a;this.b=b}
function tl(a,b){this.a=a;this.b=b}
function ul(a,b){this.a=a;this.b=b}
function Zl(a,b){this.a=a;this.b=b}
function am(a,b){this.a=a;this.b=b}
function bm(a,b){this.a=a;this.b=b}
function Lh(a){return a.a.b+a.b.b}
function zi(a,b){return a.a.get(b)}
function _c(a){return new Array(a)}
function cm(a){return dm(new fm,a)}
function um(a){vm(a,($(a.a),!a.g))}
function Bc(){Bc=Qg;!!(Sc(),Rc)}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function Jg(){Hg==null&&(Hg=[])}
function tn(a,b){nh.call(this,a,b)}
function Km(a,b){this.a=a;this.b=b}
function _m(a,b){this.a=a;this.b=b}
function Ym(a,b){this.b=a;this.a=b}
function Kj(a,b){a.ref=b;return a}
function Lj(a,b){a.href=b;return a}
function Vj(a,b){a.value=b;return a}
function zh(a,b){a.a+=''+b;return a}
function bj(a,b){a.w(em(cm(b.e),b))}
function kj(a,b,c){a.splice(b,0,c)}
function Qj(a,b){a.onBlur=b;return a}
function uo(a,b){return Gj(this.a,a)}
function Hh(a){return !a?null:a.Z()}
function Eb(a){return !a.d?a:Eb(a.d)}
function Ii(a){return a!=null?r(a):0}
function od(a){return a==null?null:a}
function ld(a){return typeof a===Cn}
function Kh(a){a.a=new oi;a.b=new Ci}
function J(a){a.b=0;a.d=0;a.c=false}
function Vh(a){a.a=Yc(fe,Dn,1,0,5,1)}
function Ic(a){$wnd.clearTimeout(a)}
function wk(a){lc(a.c);eb(a.b);Q(a.a)}
function Qk(a){lc(a.c);eb(a.a);U(a.b)}
function hc(a,b){fc(a,b,false);Z(a.d)}
function lj(a,b){jj(b,0,a,0,b.length)}
function Mj(a,b){a.onClick=b;return a}
function Rj(a,b){a.onChange=b;return a}
function Oj(a,b){a.checked=b;return a}
function cb(a){this.c=new ci;this.b=a}
function uj(){uj=Qg;rj=new o;tj=new o}
function Sj(a,b){a.onKeyDown=b;return a}
function wh(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function B(a,b,c){return t(a,c,2048,b)}
function bd(a,b,c){return {l:a,m:b,h:c}}
function T(a){return !(!!a&&1==(a.c&7))}
function qj(a){return a.$H||(a.$H=++pj)}
function nd(a){return typeof a==='string'}
function ko(){return R((nm(),km).b).a>0}
function $k(a,b){hn((nm(),mm),b);ll(a,b)}
function $(a){var b;Fb((H(),b=Ab,b),a)}
function jb(a){H();ib(a);lb(a,2,true)}
function sc(a){this.f=a;oc(this);this.F()}
function Xi(a,b){Si.call(this,a);this.a=b}
function Xm(a){this.c=Ji(a);this.a=new nc}
function ii(){this.a=new oi;this.b=new Ci}
function O(){this.a=Yc(fe,Dn,1,100,5,1)}
function ah(a){if(a.k!=null){return}kh(a)}
function Nj(a){a.autoFocus=true;return a}
function Pj(a,b){a.defaultValue=b;return a}
function Wj(a,b){a.onDoubleClick=b;return a}
function pc(a,b){a.e=b;b!=null&&oj(b,On,a)}
function Gi(a,b){while(a.V()){hj(b,a.W())}}
function gc(a,b){mc(b.B(),a);jd(b,11)&&b.t()}
function tm(a){lc(a.c);U(a.d);U(a.b);U(a.a)}
function Hm(a){return rh(R(a.e).a-R(a.a).a)}
function kd(a){return typeof a==='boolean'}
function v(a,b){return new ob(Ji(a),null,b)}
function Cc(a,b,c){return a.apply(b,c);var d}
function oj(b,c,d){try{b[c]=d}catch(a){}}
function qi(a,b){var c;c=a[Tn];c.call(a,b)}
function fh(a){var b;b=eh(a);mh(a,b);return b}
function hh(){var a;a=eh(null);a.e=2;return a}
function oc(a){a.g&&a.e!==Nn&&a.F();return a}
function dm(a,b){yj(a.a,'key',Ji(b));return a}
function Wh(a,b){a.a[a.a.length]=b;return true}
function Gj(a,b){var c;c=a.kb(b);return c||a.k}
function Pk(a,b){var c;c=b.target;Rk(a,c.value)}
function Pb(a,b){a.i&&b.preventDefault();$b(a)}
function hb(a,b){X(b,a);b.c.a.length>0||(b.a=4)}
function Mm(a,b){this.a=a;this.c=b;this.b=false}
function Fi(a,b,c){this.a=a;this.b=b;this.c=c}
function ql(a,b,c){this.a=a;this.b=b;this.c=c}
function Sc(){Sc=Qg;var a;!Uc();a=new Vc;Rc=a}
function Xg(){Xg=Qg;Wg=$wnd.window.document}
function th(){th=Qg;sh=Yc(be,Dn,32,256,0,1)}
function yb(a){if(!a.a){a.a=true;A((H(),H(),G))}}
function Mi(a){if(!a.d){a.d=a.b.P();a.c=a.b.R()}}
function $i(a,b,c){if(a.a.cb(c)){a.b=true;b.w(c)}}
function il(a,b){return $g(),fl(a,b)?true:false}
function Gm(a){return $g(),0==R(a.e).a?true:false}
function an(a){return xh(bo,a)||xh($n,a)||xh('',a)}
function yi(a,b){return !(a.a.get(b)===undefined)}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function $c(a){return Array.isArray(a)&&a.vb===Ug}
function hd(a){return !Array.isArray(a)&&a.vb===Ug}
function Vi(a){Ri(a);return new Xi(a,new cj(a.a))}
function hl(a){lc(a.e);eb(a.b);Q(a.d);U(a.c);U(a.a)}
function ml(a,b){var c;c=a.i;if(b!=c){a.i=b;Z(a.a)}}
function vm(a,b){var c;c=a.g;if(b!=c){a.g=b;Z(a.a)}}
function Rk(a,b){var c;c=a.e;if(b!=c){a.e=b;Z(a.b)}}
function $h(a,b){var c;c=a.a[b];mj(a.a,b);return c}
function ai(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Ph(a){var b;b=a.a.W();a.b=Oh(a);return b}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Uj(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Mh(a,b){if(b){return Fh(a.a,b)}return false}
function Ui(a,b){Ri(a);return new Xi(a,new _i(b,a.a))}
function Qi(a){if(!a.b){Ri(a);a.c=true}else{Qi(a.b)}}
function vb(a){while(true){if(!tb(a)&&!ub(a)){break}}}
function ab(a){var b;H();!!Ab&&!!Ab.e&&Fb((b=Ab,b),a)}
function Yb(a,b){var c;c=a.e;if(b!=c){a.e=Ji(b);Z(a.a)}}
function Zb(a,b){var c;c=a.g;if(b!=c){a.g=Ji(b);Z(a.b)}}
function wm(a,b){var c;c=a.i;if(b!=c){a.i=Ji(b);Z(a.b)}}
function gh(a,b){var c;c=eh(a);mh(a,c);c.e=b?8:0;return c}
function Ji(a){if(a==null){throw Bg(new vh)}return a}
function xj(){if(sj==256){rj=tj;tj=new o;sj=0}++sj}
function Gg(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function Fj(a){Dj(a);return jd(a,11)&&a.u()?null:a.lb()}
function hi(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function Li(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Ni(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Lb(a,b){this.a=(H(),H(),G).a++;this.d=a;this.e=b}
function ph(a){this.f=!a?null:qc(a,a.D());oc(this);this.F()}
function cj(a){Li.call(this,a.ab(),a._()&-6);this.a=a}
function Si(a){if(!a){this.b=null;new ci}else{this.b=a}}
function Cj(a){if(!a.k){a.k=true;a.n||a.o.forceUpdate()}}
function jh(a){if(a.N()){return null}var b=a.j;return Mg[b]}
function Bb(a){if(a.e){2==(a.e.c&7)||lb(a.e,4,true);ib(a.e)}}
function dn(a){lc(a.g);eb(a.e);eb(a.a);Q(a.b);Q(a.c);U(a.d)}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function un(){sn();return ad(Wc(pg,1),Dn,36,0,[pn,rn,qn])}
function Gh(a,b){return b===a?'(this Map)':b==null?Qn:Tg(b)}
function qc(a,b){var c;c=bh(a.tb);return b==null?c:c+': '+b}
function Zk(a,b){var c;if(R(a.d)){c=b.target;ml(a,c.value)}}
function uh(a,b){var c,d;for(d=a.P();d.V();){c=d.W();b.w(c)}}
function Um(a,b){var c;Wi(Em(a.c),(c=new ci,c)).O(new yn(b))}
function wb(a,b){b.c|=512;I(a.d[((b.c&229376)>>15)-1],Ji(b))}
function ih(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.I(b))}
function al(a,b,c){27==c.which?kl(a,b):13==c.which&&bl(a,b)}
function Mb(a,b){Ab=new Lb(Ab,b);a.d=false;Bb(Ab);return Ab}
function Ob(a,b){a.j=b;xh(b,($(a.a),a.e))&&Zb(a,b);Qb(b);$b(a)}
function fb(a){var b;b=(H(),H(),G);wb(b.b,a);0!=(a.c&Jn)&&D(b)}
function ki(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Kk(a,b){if(13==b.keyCode){b.preventDefault();Nk(a)}}
function Og(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Sg(a){function b(){}
;b.prototype=a||{};return new b}
function Tj(a){a.placeholder='What needs to be done?';return a}
function Ri(a){if(a.b){Ri(a.b)}else if(a.c){throw Bg(new oh)}}
function Em(a){$(a.d);return new Xi(null,new Ni(new Sh(a.i),0))}
function li(a,b){var c;return ji(b,ki(a,b==null?0:(c=r(b),c|0)))}
function di(a){Vh(this);lj(this.a,Eh(a,Yc(fe,Dn,1,Lh(a.a),5,1)))}
function pi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function qo(){return cn((nm(),mm))==(ab(this.c),this.o.props['a'])}
function el(){el=Qg;var a;dl=(a=Rg(Pl.prototype.fb,Pl,[]),a)}
function yl(){yl=Qg;var a;xl=(a=Rg(Rl.prototype.fb,Rl,[]),a)}
function vk(){vk=Qg;var a;uk=(a=Rg(Jl.prototype.fb,Jl,[]),a)}
function Dk(){Dk=Qg;var a;Ck=(a=Rg(Ll.prototype.fb,Ll,[]),a)}
function Mk(){Mk=Qg;var a;Lk=(a=Rg(Nl.prototype.fb,Nl,[]),a)}
function fn(a){var b;b=($(a.d),a.f);!!b&&!!b&&b.f<0&&hn(a,null)}
function pm(a){if(a.f>=0){a.f=-2;u((H(),H(),G),new zm(a),In,null)}}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function hn(a,b){var c;c=a.f;if(!(b==c||!!b&&qm(b,c))){a.f=b;Z(a.d)}}
function W(a,b){var c,d;Wh(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Oi(a,b){!a.a?(a.a=new Bh(a.d)):zh(a.a,a.b);zh(a.a,b);return a}
function Wi(a,b){var c;Qi(a);c=new fj;c.a=b;a.a.U(new ij(c));return c.a}
function Ti(a){var b;Qi(a);b=0;while(a.a.bb(new gj)){b=Cg(b,1)}return b}
function Jh(a,b){return nd(b)?b==null?ni(a.a,null):Bi(a.b,b):ni(a.a,b)}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Fl(a){return $wnd.React.createElement((vk(),uk),a.a,undefined)}
function Hl(a){return $wnd.React.createElement((Dk(),Ck),a.a,undefined)}
function Vl(a){return $wnd.React.createElement((Mk(),Lk),a.a,undefined)}
function hm(a){return $wnd.React.createElement((yl(),xl),a.a,undefined)}
function Yg(a,b,c,d){a.addEventListener(b,c,($g(),d?true:false))}
function Zg(a,b,c,d){a.removeEventListener(b,c,($g(),d?true:false))}
function _i(a,b){Li.call(this,b.ab(),b._()&-16449);this.a=a;this.c=b}
function Di(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Qh(a){this.d=a;this.c=new Di(this.d.b);this.a=this.c;this.b=Oh(this)}
function Pi(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function bn(a,b){return (sn(),qn)==a||(pn==a?($(b.a),!b.g):($(b.a),b.g))}
function nj(a,b){return Xc(b)!=10&&ad(q(b),b.ub,b.__elementTypeId$,Xc(b),a),a}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ei(a){if(a.a.c!=a.c){return zi(a.a,a.b.value[0])}return a.b.value[1]}
function U(a){if(-2!=a.e){u((H(),H(),G),new db(a),0,null);!!a.b&&eb(a.b)}}
function Tm(a){var b;Wi(Ui(Em(a.c),new wn),(b=new ci,b)).O(new xn(a.c))}
function en(a){var b,c;return b=R(a.b),Wi(Ui(Em(a.k),new zn(b)),(c=new ci,c))}
function nm(){nm=Qg;jm=new _b;km=new Im;lm=new Xm(km);mm=new jn(km,jm)}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function _h(a,b){var c;c=Zh(a,b,0);if(c==-1){return false}mj(a.a,c);return true}
function Hj(a){var b;a.k=false;if(a.hb()){return null}else{b=a.eb();return b}}
function Zh(a,b,c){for(;c<a.a.length;++c){if(hi(b,a.a[c])){return c}}return -1}
function Ih(a,b,c){return nd(b)?b==null?mi(a.a,null,c):Ai(a.b,b,c):mi(a.a,b,c)}
function jl(a){return $g(),cn((nm(),mm))==(ab(a.c),a.o.props['a'])?true:false}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function md(a){return a!=null&&(typeof a===Bn||typeof a==='function')&&!(a.vb===Ug)}
function Vb(a){Zg((Xg(),$wnd.window.window),Ln,a.f,false);lc(a.c);U(a.b);U(a.a)}
function Q(a){if(!a.a){a.a=true;a.g=null;a.b=null;U(a.d);2==(a.e.c&7)||eb(a.e)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{vb(a.b)}finally{a.c=false}}}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function Jk(a){var b;b=yh(($(a.b),a.e));if(b.length>0){Qm((nm(),lm),b);Rk(a,'')}}
function Xh(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Ig(){Jg();var a=Hg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Rg(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Ag(a){var b;if(jd(a,4)){return a}b=a&&a[On];if(!b){b=new wc(a);Tc(b)}return b}
function tb(a){var b;if(0==N(a.c)){return false}else{b=M(a.c);!!b&&b.t();return true}}
function mh(a,b){var c;if(!a){return}b.j=a;var d=jh(b);if(!d){Mg[a]=[b];return}d.tb=b}
function Fb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Wh((!a.b&&(a.b=new ci),a.b),b)}}}
function Hb(a,b){var c;if(!a.c){c=Eb(a);!c.c&&(c.c=new ci);a.c=c.c}b.d=true;Wh(a.c,Ji(b))}
function I(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&K(a,c);L(a,Ji(b))}
function Bi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{qi(a.a,b);--a.b}return c}
function eh(a){var b;b=new dh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function fi(a){var b,c,d;d=0;for(c=new Qh(a.a);c.b;){b=Ph(c);d=d+(b?r(b):0);d=d|0}return d}
function ib(a){var b,c;for(c=new ei(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Fm(a){uh(new Sh(a.i),new ic(a));Kh(a.i);lc(a.f);Q(a.c);Q(a.e);Q(a.a);Q(a.b);U(a.d)}
function eb(a){if(2<(a.c&7)){u((H(),H(),G),new rb(a),In,null);!!a.a&&Q(a.a);a.c=a.c&-8|1}}
function Ej(a){var b;b=(++a.jb().e,new zb);try{a.n=true;jd(a,11)&&a.t()}finally{yb(b)}}
function Nb(){var a;try{Cb(Ab);H()}finally{a=Ab.d;!a&&((H(),H(),G).d=true);Ab=Ab.d}}
function fc(a,b,c){var d;d=Jh(a.i,b?rh(b.e):null);if(null!=d){mc(b.c,a);c&&!!b&&pm(b);Z(a.d)}}
function Bm(a,b,c){var d;d=new ym(b,c);kc(d.c,a,new jc(a,d));Ih(a.i,rh(d.e),d);Z(a.d);return d}
function Dh(a,b){var c,d;for(d=new Qh(b.a);d.b;){c=Ph(d);if(!Mh(a,c)){return false}}return true}
function fl(a,b){var c;c=false;if(!hi(a.o.props['a'],null==b?null:b['a'])){Z(a.c);c=true}return c}
function Dg(a){var b;b=a.h;if(b==0){return a.l+a.m*Jn}if(b==1048575){return a.l+a.m*Jn-Rn}return a}
function Oh(a){if(a.a.V()){return true}if(a.a!=a.c){return false}a.a=new pi(a.d.a);return a.a.V()}
function oh(){sc.call(this,"Stream already terminated, can't be modified or used")}
function em(a,b){yj(a.a,(el(),'a'),b);return $wnd.React.createElement(dl,a.a,undefined)}
function Lg(a,b){typeof window===Bn&&typeof window['$gwt']===Bn&&(window['$gwt'][a]=b)}
function sn(){sn=Qg;pn=new tn('ACTIVE',0);rn=new tn('COMPLETED',1);qn=new tn('ALL',2)}
function Vg(){nm();$wnd.ReactDOM.render(hm(new im),(Xg(),Wg).getElementById('todoapp'),null)}
function Fk(){Dk();++Aj;this.b=new nc;this.a=new ob(null,Ji((H(),new Gk(this))),Wn);D((null,G))}
function Al(){yl();++Aj;this.b=new nc;this.a=new ob(null,Ji((H(),new Bl(this))),Wn);D((null,G))}
function zj(a){$wnd.React.Component.call(this,a);this.a=this.gb();this.a.o=Ji(this);this.a.db()}
function dh(){this.g=_g++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function ji(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(hi(a,c.Y())){return c}}return null}
function Fg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Rn;d=1048575}c=pd(e/Jn);b=pd(e-c*Jn);return bd(b,c,d)}
function X(a,b){var c,d;d=a.c;_h(d,b);d.a.length==0&&!!a.b&&Fn!=(a.b.c&Gn)&&(a.d||Hb((H(),c=Ab,c),a))}
function gn(a){var b;b=Tb(a.j);xh(bo,b)||xh($n,b)||xh('',b)?Sb(a.j,b):an(Ub(a.j))?Xb(a.j):Sb(a.j,'')}
function R(a){$(a.d);mb(a.e)&&gb(a.e);if(a.b){if(jd(a.b,6)){throw Bg(a.b)}else{throw Bg(a.b)}}return a.g}
function ad(a,b,c,d,e){e.tb=a;e.ub=b;e.vb=Ug;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ai(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function qm(a,b){var c;if(a===b){return true}else if(null==b||!jd(b,49)){return false}else{c=b;return a.e==c.e}}
function rh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(th(),sh)[b];!c&&(c=sh[b]=new qh(a));return c}return new qh(a)}
function Tg(a){var b;if(Array.isArray(a)&&a.vb===Ug){return bh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function wj(a){uj();var b,c,d;c=':'+a;d=tj[c];if(d!=null){return pd(d)}d=rj[c];b=d==null?vj(a):pd(d);xj();tj[c]=b;return b}
function wc(a){uc();oc(this);this.e=a;a!=null&&oj(a,On,this);this.f=a==null?Qn:Tg(a);this.a='';this.b=a;this.a=''}
function S(a,b){this.c=Ji(a);this.f=null;this.g=null;this.e=new pb(this,b);this.d=new cb(this.e);Fn==(b&Gn)&&fb(this.e)}
function nb(a,b,c,d){this.b=new ci;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&fb(this)}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function Cg(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<Rn){return c}}return Dg(cd(ld(a)?Fg(a):a,ld(b)?Fg(b):b))}
function bl(a,b){var c;c=($(a.a),a.i);if(null!=c&&c.length!=0){Vm((nm(),b),c);hn(mm,null);ml(a,c)}else{Dm((nm(),km),b)}}
function Rb(a){var b,c;c=(b=(Xg(),$wnd.window.window).location.hash,null==b?'':b.substr(1));Yb(a,c);xh(a.j,c)&&Zb(a,c)}
function Dj(a){if(!Bj){Bj=(++a.jb().e,new zb);$wnd.Promise.resolve(null).then(Rg(Ij.prototype.H,Ij,[]))}}
function q(a){return nd(a)?ie:ld(a)?Zd:kd(a)?Xd:hd(a)?a.tb:$c(a)?a.tb:a.tb||Array.isArray(a)&&Wc(Qd,1)||Qd}
function r(a){return nd(a)?wj(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.r():$c(a)?qj(a):!!a&&!!a.hashCode?a.hashCode():qj(a)}
function p(a,b){return nd(a)?xh(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.p(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function tk(){rk();return ad(Wc(Ye,1),Dn,9,0,[Xj,Yj,Zj,$j,_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk])}
function xk(){vk();++Aj;this.c=new nc;this.a=new S((H(),new yk),136478720);this.b=new ob(null,Ji(new Ak(this)),Wn);D((null,G))}
function Sk(){Mk();var a;++Aj;this.c=new nc;this.b=(a=new cb((H(),null)),a);this.a=new ob(null,Ji(new Wk(this)),Wn);D((null,G))}
function xb(){this.c=new O;this.d=Yc(rd,Dn,21,5,0,1);this.d[0]=new O;this.d[1]=new O;this.d[2]=new O;this.d[3]=new O;this.d[4]=new O}
function ob(a,b,c){nb.call(this,null,a,b,c|(!a?262144:Fn)|(0!=(c&6291456)?0:!a?2097152:Jn)|(0!=(c&229376)?0:98304)|0|0|0)}
function lc(a){var b,c;if(!a.a){for(c=new ei(new di(new Sh(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.v()}a.a=true}}
function gi(a){var b,c,d;d=1;for(c=new ei(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Kb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&lb(b,5,true)}}}
function Yk(a){var b;b=R(a.d);if(!a.j&&b){a.j=true;ll(a,(ab(a.c),a.o.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function lh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function bi(a,b){var c,d;d=a.a.length;b.length<d&&(b=nj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Jj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function s(b,c,d){var e;try{Mb(b,d);try{c.v()}finally{Nb()}}catch(a){a=Ag(a);if(jd(a,4)){e=a;throw Bg(e)}else throw Bg(a)}finally{D(b)}}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.ub){return !!a.ub[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function pb(a,b){nb.call(this,a,new qb(a),null,b|(Fn==(b&Gn)?0:524288)|(0!=(b&6291456)?0:Fn==(b&Gn)?Jn:2097152)|0|268435456|0|(0!=(b&229376)?0:98304))}
function yh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Jb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ei(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&lb(b,6,true)}}}
function Ib(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?lb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Gb(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=$h(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&lb(c.b,3,true);++b}}}return b}
function ym(a,b){var c,d,e;this.i=Ji(a);this.g=b;this.e=om++;this.d=(d=new cb((H(),null)),d);this.c=new nc;this.b=(e=new cb(null),e);this.a=(c=new cb(null),c)}
function Kg(b,c,d,e){Jg();var f=Hg;$moduleName=c;$moduleBase=d;zg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{An(g)()}catch(a){b(c,a)}}else{An(g)()}}
function Xb(b){var c;try{u((H(),H(),G),new cc(b),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){c=a;throw Bg(c)}else if(jd(a,4)){c=a;throw Bg(new ph(c))}else throw Bg(a)}}
function $b(b){var c;try{u((H(),H(),G),new dc(b),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){c=a;throw Bg(c)}else if(jd(a,4)){c=a;throw Bg(new ph(c))}else throw Bg(a)}}
function Nk(b){var c;try{u((H(),H(),G),new Uk(b),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){c=a;throw Bg(c)}else if(jd(a,4)){c=a;throw Bg(new ph(c))}else throw Bg(a)}}
function xm(b){var c;try{u((H(),H(),G),new Am(b),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){c=a;throw Bg(c)}else if(jd(a,4)){c=a;throw Bg(new ph(c))}else throw Bg(a)}}
function Sm(b){var c;try{u((H(),H(),G),new Zm(b),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){c=a;throw Bg(c)}else if(jd(a,4)){c=a;throw Bg(new ph(c))}else throw Bg(a)}}
function Dm(b,c){var d;try{u((H(),H(),G),new Km(b,c),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){d=a;throw Bg(d)}else if(jd(a,4)){d=a;throw Bg(new ph(d))}else throw Bg(a)}}
function Vm(b,c){var d;try{u((H(),H(),G),new Ym(b,c),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){d=a;throw Bg(d)}else if(jd(a,4)){d=a;throw Bg(new ph(d))}else throw Bg(a)}}
function Wm(b,c){var d;try{u((H(),H(),G),new _m(b,c),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){d=a;throw Bg(d)}else if(jd(a,4)){d=a;throw Bg(new ph(d))}else throw Bg(a)}}
function Ok(b,c){var d;try{u((H(),H(),G),new Vk(b,c),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){d=a;throw Bg(d)}else if(jd(a,4)){d=a;throw Bg(new ph(d))}else throw Bg(a)}}
function gl(b,c){var d;try{u((H(),H(),G),new ul(b,c),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){d=a;throw Bg(d)}else if(jd(a,4)){d=a;throw Bg(new ph(d))}else throw Bg(a)}}
function kl(b,c){var d;try{u((H(),H(),G),new tl(b,c),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){d=a;throw Bg(d)}else if(jd(a,4)){d=a;throw Bg(new ph(d))}else throw Bg(a)}}
function ll(b,c){var d;try{u((H(),H(),G),new sl(b,c),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){d=a;throw Bg(d)}else if(jd(a,4)){d=a;throw Bg(new ph(d))}else throw Bg(a)}}
function Cm(b,c){var d;try{return t((H(),H(),G),new Mm(b,c),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){d=a;throw Bg(d)}else if(jd(a,4)){d=a;throw Bg(new ph(d))}else throw Bg(a)}}
function Sb(b,c){var d;try{u((H(),H(),G),new bc(b,c),75497472,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){d=a;throw Bg(d)}else if(jd(a,4)){d=a;throw Bg(new ph(d))}else throw Bg(a)}}
function u(b,c,d,e){var f;try{if(0==(d&2048)&&!!Ab){c.v()}else{Mb(b,e);try{c.v()}finally{Nb()}}}catch(a){a=Ag(a);if(jd(a,4)){f=a;throw Bg(f)}else throw Bg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ab){g=c.A()}else{Mb(b,e);try{g=c.A()}finally{Nb()}}return g}catch(a){a=Ag(a);if(jd(a,4)){f=a;throw Bg(f)}else throw Bg(a)}finally{D(b)}}
function vi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return wi()}}
function Eh(a,b){var c,d,e,f,g;g=Lh(a.a);b.length<g&&(b=nj(new Array(g),b));e=(f=new Qh((new Nh(a.a)).a),new Th(f));for(d=0;d<g;++d){b[d]=(c=Ph(e.a),c.Z())}b.length>g&&(b[g]=null);return b}
function Ng(){Mg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].wb()&&(c=Pc(c,g)):g[0].wb()}catch(a){a=Ag(a);if(jd(a,4)){d=a;Bc();Hc(jd(d,39)?d.G():d)}else throw Bg(a)}}return c}
function nl(){el();var a,b;++Aj;this.e=new nc;this.c=(b=new cb((H(),null)),b);this.a=(a=new cb(null),a);this.d=new S(new vl(this),136478720);this.b=new ob(null,Ji(new wl(this)),Wn);D((null,G))}
function Im(){var a;this.i=new ii;this.f=new nc;this.d=(a=new cb((H(),null)),a);this.c=new S(new Lm(this),ao);this.e=new S(new Nm(this),ao);this.a=new S(new Om(this),ao);this.b=new S(new Pm(this),ao)}
function jn(a,b){var c;this.k=Ji(a);this.j=Ji(b);this.g=new nc;this.d=(c=new cb((H(),null)),c);this.b=new S(new ln(this),ao);this.c=new S(new mn(this),ao);this.e=v(new nn(this),413138944);this.a=v(new on(this),681574400);D((null,G))}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?Qn:md(b)?b==null?null:b.name:nd(b)?'String':bh(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function P(b){var c,d,e;e=b.g;try{d=b.c.A();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.g=d;b.b=null;Y(b.d)}}catch(a){a=Ag(a);if(jd(a,12)){c=a;if(!b.b){b.g=null;b.b=c;Y(b.d)}throw Bg(c)}else throw Bg(a)}}
function mi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=ji(b,e);if(f){return f.$(c)}}e[e.length]=new Uh(b,c);++a.b;return null}
function jj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function vj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+wh(a,c++)}b=b|0;return b}
function K(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Yc(fe,Dn,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function Qb(a){var b;if(0==a.length){b=(Xg(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Wg.title,b)}else{(Xg(),$wnd.window.window).location.hash=a}}
function gb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;w((H(),H(),G),b,c)}else{b.e.v()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=Ag(a);if(jd(a,4)){H()}else throw Bg(a)}}}
function ni(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(hi(b,e.Y())){if(d.length==1){d.length=0;qi(a.a,g)}else{d.splice(h,1)}--a.b;return e.Z()}}return null}
function Pg(a,b,c){var d=Mg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Mg[b]),Sg(h));_.ub=c;!b&&(_.vb=Ug);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.tb=f)}
function kh(a){if(a.M()){var b=a.c;b.N()?(a.k='['+b.j):!b.M()?(a.k='[L'+b.K()+';'):(a.k='['+b.K());a.b=b.J()+'[]';a.i=b.L()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=lh('.',[c,lh('$',d)]);a.b=lh('.',[c,lh('.',d)]);a.i=d[d.length-1]}
function _b(){var a,b,c;this.f=new ec(this);this.c=new nc;this.b=(c=new cb((H(),null)),c);this.a=(b=new cb(null),b);Yg((Xg(),$wnd.window.window),Ln,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function Fh(a,b){var c,d,e;c=b.Y();e=b.Z();d=nd(c)?c==null?Hh(li(a.a,null)):zi(a.b,c):Hh(li(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!li(a.a,null):yi(a.b,c):!!li(a.a,c))){return false}return true}
function mb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ei(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{R(c)}catch(a){a=Ag(a);if(!jd(a,4))throw Bg(a)}if(6==(b.c&7)){return true}}}}}ib(b);return false}
function ui(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function lb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((H(),H(),G),a))}else if(!!a.a&&4==f&&(6==b||5==b)){bb(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((H(),H(),G),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}Xh(a.b,new sb(a));a.b.a=Yc(fe,Dn,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function ub(a){var b,c,d,e,f,g,h,i;d=N(a.d[0]);c=N(a.d[1]);g=N(a.d[2]);e=N(a.d[3]);f=N(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;J(a.d[0]);J(a.d[1]);J(a.d[2]);J(a.d[3]);J(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=M(b);h.c&=-513;gb(h);return true}
function rk(){rk=Qg;Xj=new sk(Un,0);Yj=new sk('checkbox',1);Zj=new sk('color',2);$j=new sk('date',3);_j=new sk('datetime',4);ak=new sk('email',5);bk=new sk('file',6);ck=new sk('hidden',7);dk=new sk('image',8);ek=new sk('month',9);fk=new sk(Cn,10);gk=new sk('password',11);hk=new sk('radio',12);ik=new sk('range',13);jk=new sk('reset',14);kk=new sk('search',15);lk=new sk('submit',16);mk=new sk('tel',17);nk=new sk('text',18);ok=new sk('time',19);pk=new sk('url',20);qk=new sk('week',21)}
function Db(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Yh(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ai(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{X(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&lb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Yh(a.b,g);if(-1==k.e){k.e=0;W(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){$h(a.b,g)}e&&kb(a.e,a.b)}else{e&&kb(a.e,new ci)}if(T(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&Fn!=(b.e.c&Gn)&&Hb(a,k)}}
function wi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Tn]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!ui()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Tn]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Bn='object',Cn='number',Dn={3:1,5:1},En={11:1},Fn=1048576,Gn=1835008,Hn={8:1},In=67108864,Jn=4194304,Kn={29:1},Ln='hashchange',Mn=142606336,Nn='__noinit__',On='__java$exception',Pn={3:1,12:1,6:1,4:1},Qn='null',Rn=17592186044416,Sn={43:1},Tn='delete',Un='button',Vn='selected',Wn=1478623232,Xn={11:1,23:1},Yn={15:1},Zn='input',$n='completed',_n='header',ao=136314880,bo='active';var _,Mg,Hg,zg=-1;Ng();Pg(1,null,{},o);_.p=eo;_.q=function(){return this.tb};_.r=fo;_.s=function(){var a;return bh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.p(a)};_.hashCode=function(){return this.r()};_.toString=function(){return this.s()};var dd,ed,fd;Pg(51,1,{},dh);_.I=function(a){var b;b=new dh;b.e=4;a>1?(b.c=ih(this,a-1)):(b.c=this);return b};_.J=function(){ah(this);return this.b};_.K=function(){return bh(this)};_.L=function(){ah(this);return this.i};_.M=function(){return (this.e&4)!=0};_.N=function(){return (this.e&1)!=0};_.s=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(ah(this),this.k)};_.e=0;_.g=0;var _g=1;var fe=fh(1);var Yd=fh(51);Pg(75,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var qd=fh(75);var G;Pg(21,1,{21:1},O);_.b=0;_.c=false;_.d=0;var rd=fh(21);Pg(200,1,En);_.s=function(){var a;return bh(this.tb)+'@'+(a=r(this)>>>0,a.toString(16))};var td=fh(200);Pg(20,200,En,S);_.t=function(){Q(this)};_.u=co;_.a=false;var sd=fh(20);Pg(16,200,{11:1,16:1},cb);_.t=function(){U(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var vd=fh(16);Pg(114,1,Hn,db);_.v=function(){V(this.a)};var ud=fh(114);Pg(18,200,{11:1,18:1},ob,pb);_.t=function(){eb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var zd=fh(18);Pg(115,1,Kn,qb);_.v=function(){P(this.a)};var wd=fh(115);Pg(116,1,Hn,rb);_.v=function(){jb(this.a)};var xd=fh(116);Pg(117,1,{},sb);_.w=function(a){hb(this.a,a)};var yd=fh(117);Pg(119,1,{},xb);_.a=0;_.b=100;_.e=0;var Ad=fh(119);Pg(61,1,En,zb);_.t=function(){yb(this)};_.u=co;_.a=false;var Bd=fh(61);Pg(133,1,{},Lb);_.s=function(){var a;return ah(Cd),Cd.k+'@'+(a=qj(this)>>>0,a.toString(16))};_.a=0;var Ab;var Cd=fh(133);Pg(45,1,{45:1});_.e='';_.g='';_.i=true;_.j='';var Jd=fh(45);Pg(99,45,{11:1,45:1,23:1},_b);_.t=function(){if(this.d>=0){this.d=-2;u((H(),H(),G),new ac(this),In,null)}};_.p=eo;_.B=lo;_.r=fo;_.u=mo;_.s=function(){var a;return ah(Hd),Hd.k+'@'+(a=qj(this)>>>0,a.toString(16))};_.d=0;var Hd=fh(99);Pg(100,1,Hn,ac);_.v=function(){Vb(this.a)};var Dd=fh(100);Pg(101,1,Hn,bc);_.v=function(){Ob(this.a,this.b)};var Ed=fh(101);Pg(102,1,Hn,cc);_.v=function(){Wb(this.a)};var Fd=fh(102);Pg(103,1,Hn,dc);_.v=function(){Rb(this.a)};var Gd=fh(103);Pg(76,1,{},ec);_.handleEvent=function(a){Pb(this.a,a)};var Id=fh(76);Pg(104,1,{});var Md=fh(104);Pg(77,1,{},ic);_.w=function(a){gc(this.a,a)};var Kd=fh(77);Pg(78,1,Hn,jc);_.v=function(){hc(this.a,this.b)};var Ld=fh(78);Pg(105,104,{});var Nd=fh(105);Pg(17,1,En,nc);_.t=function(){lc(this)};_.u=co;_.a=false;var Od=fh(17);Pg(4,1,{3:1,4:1});_.C=function(a){return new Error(a)};_.D=wo;_.F=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=bh(this.tb),c==null?a:a+': '+c);pc(this,rc(this.C(b)));Tc(this)};_.s=function(){return qc(this,this.D())};_.e=Nn;_.g=true;var je=fh(4);Pg(12,4,{3:1,12:1,4:1});var _d=fh(12);Pg(6,12,Pn);var ge=fh(6);Pg(52,6,Pn);var ce=fh(52);Pg(70,52,Pn);var Sd=fh(70);Pg(39,70,{39:1,3:1,12:1,6:1,4:1},wc);_.D=function(){vc(this);return this.c};_.G=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Pd=fh(39);var Qd=fh(0);Pg(186,1,{});var Rd=fh(186);var yc=0,zc=0,Ac=-1;Pg(98,186,{},Oc);var Kc;var Td=fh(98);var Rc;Pg(197,1,{});var Vd=fh(197);Pg(71,197,{},Vc);var Ud=fh(71);var Wg;Pg(68,1,{65:1});_.s=co;var Wd=fh(68);dd={3:1,66:1,31:1};var Xd=fh(66);Pg(44,1,{3:1,44:1});var ee=fh(44);ed={3:1,31:1,44:1};var Zd=fh(196);Pg(35,1,{3:1,31:1,35:1});_.p=eo;_.r=fo;_.s=function(){return this.a!=null?this.a:''+this.b};_.b=0;var $d=fh(35);Pg(10,6,Pn,oh,ph);var ae=fh(10);Pg(32,44,{3:1,31:1,32:1,44:1},qh);_.p=function(a){return jd(a,32)&&a.a==this.a};_.r=co;_.s=function(){return ''+this.a};_.a=0;var be=fh(32);var sh;Pg(254,1,{});Pg(73,52,Pn,vh);_.C=function(a){return new TypeError(a)};var de=fh(73);fd={3:1,65:1,31:1,2:1};var ie=fh(2);Pg(69,68,{65:1},Bh);var he=fh(69);Pg(258,1,{});Pg(54,6,Pn,Ch);var ke=fh(54);Pg(198,1,{42:1});_.O=jo;_.S=function(){return new Ni(this,0)};_.T=function(){return new Xi(null,this.S())};_.Q=function(a){throw Bg(new Ch('Add not supported on this collection'))};_.s=function(){var a,b,c;c=new Pi('[',']');for(b=this.P();b.V();){a=b.W();Oi(c,a===this?'(this Collection)':a==null?Qn:Tg(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var le=fh(198);Pg(201,1,{184:1});_.p=function(a){var b,c,d;if(a===this){return true}if(!jd(a,40)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Qh((new Nh(d)).a);c.b;){b=Ph(c);if(!Fh(this,b)){return false}}return true};_.r=function(){return fi(new Nh(this))};_.s=function(){var a,b,c;c=new Pi('{','}');for(b=new Qh((new Nh(this)).a);b.b;){a=Ph(b);Oi(c,Gh(this,a.Y())+'='+Gh(this,a.Z()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var we=fh(201);Pg(120,201,{184:1});var oe=fh(120);Pg(202,198,{42:1,208:1});_.S=function(){return new Ni(this,1)};_.p=function(a){var b;if(a===this){return true}if(!jd(a,26)){return false}b=a;if(Lh(b.a)!=this.R()){return false}return Dh(this,b)};_.r=function(){return fi(this)};var xe=fh(202);Pg(26,202,{26:1,42:1,208:1},Nh);_.P=function(){return new Qh(this.a)};_.R=ho;var ne=fh(26);Pg(27,1,{},Qh);_.U=go;_.W=function(){return Ph(this)};_.V=io;_.b=false;var me=fh(27);Pg(199,198,{42:1,206:1});_.S=function(){return new Ni(this,16)};_.X=function(a,b){throw Bg(new Ch('Add not supported on this list'))};_.Q=function(a){this.X(this.R(),a);return true};_.p=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,14)){return false}f=a;if(this.R()!=f.a.length){return false}e=new ei(f);for(c=new ei(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.r=function(){return gi(this)};_.P=function(){return new Rh(this)};var qe=fh(199);Pg(96,1,{},Rh);_.U=go;_.V=function(){return this.a<this.b.a.length};_.W=function(){return Yh(this.b,this.a++)};_.a=0;var pe=fh(96);Pg(47,198,{42:1},Sh);_.P=function(){var a;return a=new Qh((new Nh(this.a)).a),new Th(a)};_.R=ho;var se=fh(47);Pg(56,1,{},Th);_.U=go;_.V=function(){return this.a.b};_.W=function(){var a;return a=Ph(this.a),a.Z()};var re=fh(56);Pg(121,1,Sn);_.p=function(a){var b;if(!jd(a,43)){return false}b=a;return hi(this.a,b.Y())&&hi(this.b,b.Z())};_.Y=co;_.Z=io;_.r=function(){return Ii(this.a)^Ii(this.b)};_.$=function(a){var b;b=this.b;this.b=a;return b};_.s=function(){return this.a+'='+this.b};var te=fh(121);Pg(122,121,Sn,Uh);var ue=fh(122);Pg(203,1,Sn);_.p=function(a){var b;if(!jd(a,43)){return false}b=a;return hi(this.b.value[0],b.Y())&&hi(Ei(this),b.Z())};_.r=function(){return Ii(this.b.value[0])^Ii(Ei(this))};_.s=function(){return this.b.value[0]+'='+Ei(this)};var ve=fh(203);Pg(14,199,{3:1,14:1,42:1,206:1},ci,di);_.X=function(a,b){kj(this.a,a,b)};_.Q=function(a){return Wh(this,a)};_.O=function(a){Xh(this,a)};_.P=function(){return new ei(this)};_.R=function(){return this.a.length};var ze=fh(14);Pg(19,1,{},ei);_.U=go;_.V=function(){return this.a<this.c.a.length};_.W=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ye=fh(19);Pg(40,120,{3:1,40:1,184:1},ii);var Ae=fh(40);Pg(59,1,{},oi);_.O=jo;_.P=function(){return new pi(this)};_.b=0;var Ce=fh(59);Pg(60,1,{},pi);_.U=go;_.W=function(){return this.d=this.a[this.c++],this.d};_.V=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Be=fh(60);var si;Pg(57,1,{},Ci);_.O=jo;_.P=function(){return new Di(this)};_.b=0;_.c=0;var Fe=fh(57);Pg(58,1,{},Di);_.U=go;_.W=function(){return this.c=this.a,this.a=this.b.next(),new Fi(this.d,this.c,this.d.c)};_.V=function(){return !this.a.done};var De=fh(58);Pg(132,203,Sn,Fi);_.Y=function(){return this.b.value[0]};_.Z=function(){return Ei(this)};_.$=function(a){return Ai(this.a,this.b.value[0],a)};_.c=0;var Ee=fh(132);Pg(97,1,{});_.U=function(a){Ki(this,a)};_._=function(){return this.d};_.ab=ro;_.d=0;_.e=0;var He=fh(97);Pg(55,97,{});var Ge=fh(55);Pg(25,1,{},Ni);_._=co;_.ab=function(){Mi(this);return this.c};_.U=function(a){Mi(this);this.d.U(a)};_.bb=function(a){Mi(this);if(this.d.V()){a.w(this.d.W());return true}return false};_.a=0;_.c=0;var Ie=fh(25);Pg(53,1,{},Pi);_.s=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Je=fh(53);var Se=hh();Pg(123,1,{});_.c=false;var Te=fh(123);Pg(34,123,{},Xi);var Re=fh(34);Pg(125,55,{},_i);_.bb=function(a){this.b=false;while(!this.b&&this.c.bb(new aj(this,a)));return this.b};_.b=false;var Le=fh(125);Pg(128,1,{},aj);_.w=function(a){$i(this.a,this.b,a)};var Ke=fh(128);Pg(124,55,{},cj);_.bb=function(a){return this.a.bb(new dj(a))};var Ne=fh(124);Pg(127,1,{},dj);_.w=function(a){bj(this.a,a)};var Me=fh(127);Pg(126,1,{},fj);_.w=function(a){ej(this,a)};var Oe=fh(126);Pg(129,1,{},gj);_.w=function(a){};var Pe=fh(129);Pg(130,1,{},ij);_.w=function(a){hj(this,a)};var Qe=fh(130);Pg(256,1,{});Pg(205,1,{});var Ue=fh(205);Pg(253,1,{});var pj=0;var rj,sj=0,tj;Pg(678,1,{});Pg(703,1,{});Pg(204,1,{});_.db=function(){};var Ve=fh(204);Pg(33,$wnd.React.Component,{});Og(Mg[1],_);_.render=function(){return Fj(this.a)};var We=fh(33);Pg(37,204,{});_.hb=function(){return false};_.ib=function(a,b){};_.kb=function(a){return false};_.lb=function(){return Hj(this)};_.k=false;_.n=false;var Aj=1,Bj;var Xe=fh(37);Pg(225,$wnd.Function,{},Ij);_.H=function(a){return yb(Bj),Bj=null,null};Pg(9,35,{3:1,31:1,35:1,9:1},sk);var Xj,Yj,Zj,$j,_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk;var Ye=gh(9,tk);Pg(154,37,{});_.qb=ko;_.eb=function(){var a;a=R((nm(),mm).b);return $wnd.React.createElement('footer',Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,['footer'])),Hl(new Il),$wnd.React.createElement('ul',Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Lj(Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,[(sn(),qn)==a?Vn:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Lj(Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,[pn==a?Vn:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Lj(Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,[rn==a?Vn:null])),'#completed'),'Completed'))),this.qb()?$wnd.React.createElement(Un,Mj(Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,['clear-completed'])),Rg(El.prototype.pb,El,[])),'Clear Completed'):null)};var Ef=fh(154);Pg(155,154,{});_.qb=ko;var uk;var If=fh(155);Pg(156,155,Xn,xk);_.t=function(){if(this.d>=0){this.d=-2;u((H(),H(),G),new Bk(this),In,null)}};_.p=eo;_.jb=no;_.B=lo;_.qb=function(){return R(this.a)};_.r=fo;_.u=mo;_.s=function(){var a;return ah(ff),ff.k+'@'+(a=qj(this)>>>0,a.toString(16))};_.lb=function(){var b;try{return B((H(),H(),G),this.b,new zk(this))}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){b=a;throw Bg(b)}else if(jd(a,4)){b=a;throw Bg(new ph(b))}else throw Bg(a)}};_.d=0;var ff=fh(156);Pg(157,1,Yn,yk);_.A=function(){return $g(),R((nm(),km).b).a>0?true:false};var Ze=fh(157);Pg(160,1,Yn,zk);_.A=po;var $e=fh(160);Pg(158,1,Kn,Ak);_.v=oo;var _e=fh(158);Pg(159,1,Hn,Bk);_.v=function(){wk(this.a)};var af=fh(159);Pg(177,37,{});_.eb=function(){var a,b;b=R((nm(),km).e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,['todo-count'])),$wnd.React.createElement('strong',null,''+b),' '+a+' left')};var Df=fh(177);Pg(178,177,{});var Ck;var Hf=fh(178);Pg(179,178,Xn,Fk);_.t=function(){if(this.c>=0){this.c=-2;u((H(),H(),G),new Hk(this),In,null)}};_.p=eo;_.jb=no;_.B=io;_.r=fo;_.u=so;_.s=function(){var a;return ah(ef),ef.k+'@'+(a=qj(this)>>>0,a.toString(16))};_.lb=function(){var b;try{return B((H(),H(),G),this.a,new Ik(this))}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){b=a;throw Bg(b)}else if(jd(a,4)){b=a;throw Bg(new ph(b))}else throw Bg(a)}};_.c=0;var ef=fh(179);Pg(180,1,Kn,Gk);_.v=oo;var bf=fh(180);Pg(181,1,Hn,Hk);_.v=function(){Ek(this.a)};var cf=fh(181);Pg(182,1,Yn,Ik);_.A=po;var df=fh(182);Pg(146,37,{});_.eb=function(){return $wnd.React.createElement(Zn,Nj(Rj(Sj(Vj(Tj(Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,['new-todo']))),($(this.b),this.e)),Rg(Tl.prototype.ob,Tl,[this])),Rg(Ul.prototype.nb,Ul,[this]))))};_.e='';var Qf=fh(146);Pg(147,146,{});var Lk;var Kf=fh(147);Pg(148,147,Xn,Sk);_.t=function(){if(this.d>=0){this.d=-2;u((H(),H(),G),new Xk(this),In,null)}};_.p=eo;_.jb=no;_.B=lo;_.r=fo;_.u=mo;_.s=function(){var a;return ah(mf),mf.k+'@'+(a=qj(this)>>>0,a.toString(16))};_.lb=function(){var b;try{return B((H(),H(),G),this.a,new Tk(this))}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){b=a;throw Bg(b)}else if(jd(a,4)){b=a;throw Bg(new ph(b))}else throw Bg(a)}};_.d=0;var mf=fh(148);Pg(151,1,Yn,Tk);_.A=po;var gf=fh(151);Pg(152,1,Hn,Uk);_.v=function(){Jk(this.a)};var hf=fh(152);Pg(153,1,Hn,Vk);_.v=function(){Pk(this.a,this.b)};var jf=fh(153);Pg(149,1,Kn,Wk);_.v=oo;var kf=fh(149);Pg(150,1,Hn,Xk);_.v=function(){Qk(this.a)};var lf=fh(150);Pg(163,37,{});_.ib=function(a,b){Yk(this)};_.sb=qo;_.db=function(){ll(this,this.rb())};_.eb=function(){var a,b;b=this.rb();a=($(b.a),b.g);return $wnd.React.createElement('li',Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,[a?$n:null,this.sb()?'editing':null])),$wnd.React.createElement('div',Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,['view'])),$wnd.React.createElement(Zn,Rj(Oj(Uj(Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,['toggle'])),(rk(),Yj)),a),Rg(Yl.prototype.nb,Yl,[b]))),$wnd.React.createElement('label',Wj(new $wnd.Object,Rg(Zl.prototype.pb,Zl,[this,b])),($(b.b),b.i)),$wnd.React.createElement(Un,Mj(Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,['destroy'])),Rg($l.prototype.pb,$l,[b])))),$wnd.React.createElement(Zn,Sj(Rj(Qj(Pj(Jj(Kj(new $wnd.Object,Rg(_l.prototype.w,_l,[this])),ad(Wc(ie,1),Dn,2,6,['edit'])),($(this.a),this.i)),Rg(am.prototype.mb,am,[this,b])),Rg(Xl.prototype.nb,Xl,[this])),Rg(bm.prototype.ob,bm,[this,b]))))};_.j=false;var Sf=fh(163);Pg(164,163,{});_.hb=function(){var a;a=(ab(this.c),this.o.props['a']);if(!!a&&a.f<0){return true}return false};_.rb=function(){return this.o.props['a']};_.sb=qo;_.kb=function(a){return fl(this,a)};var dl;var Mf=fh(164);Pg(165,164,Xn,nl);_.ib=function(b,c){var d;try{u((H(),H(),G),new ql(this,b,c),Mn,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){d=a;throw Bg(d)}else if(jd(a,4)){d=a;throw Bg(new ph(d))}else throw Bg(a)}};_.t=function(){if(this.f>=0){this.f=-2;u((H(),H(),G),new ol(this),In,null)}};_.p=eo;_.jb=no;_.B=ro;_.rb=function(){return ab(this.c),this.o.props['a']};_.r=fo;_.u=vo;_.sb=function(){return R(this.d)};_.kb=function(b){var c;try{return t((H(),H(),G),new rl(this,b),75497472,null)}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){c=a;throw Bg(c)}else if(jd(a,4)){c=a;throw Bg(new ph(c))}else throw Bg(a)}};_.s=function(){var a;return ah(wf),wf.k+'@'+(a=qj(this)>>>0,a.toString(16))};_.lb=function(){var b;try{return B((H(),H(),G),this.b,new pl(this))}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){b=a;throw Bg(b)}else if(jd(a,4)){b=a;throw Bg(new ph(b))}else throw Bg(a)}};_.f=0;var wf=fh(165);Pg(168,1,Hn,ol);_.v=function(){hl(this.a)};var nf=fh(168);Pg(169,1,Yn,pl);_.A=po;var of=fh(169);Pg(170,1,Hn,ql);_.v=function(){Yk(this.a)};var pf=fh(170);Pg(171,1,Yn,rl);_.A=function(){return il(this.a,this.b)};var qf=fh(171);Pg(172,1,Hn,sl);_.v=function(){ml(this.a,rm(this.b))};var rf=fh(172);Pg(173,1,Hn,tl);_.v=function(){ll(this.a,this.b);hn((nm(),mm),null)};var sf=fh(173);Pg(174,1,Hn,ul);_.v=function(){Zk(this.a,this.b)};var tf=fh(174);Pg(166,1,Yn,vl);_.A=function(){return jl(this.a)};var uf=fh(166);Pg(167,1,Kn,wl);_.v=oo;var vf=fh(167);Pg(134,37,{});_.eb=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(_n,Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,[_n])),$wnd.React.createElement('h1',null,'todos'),Vl(new Wl)),R((nm(),km).c)?null:$wnd.React.createElement('section',Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,[_n])),$wnd.React.createElement(Zn,Rj(Uj(Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,['toggle-all'])),(rk(),Yj)),Rg(gm.prototype.nb,gm,[]))),$wnd.React.createElement.apply(null,['ul',Jj(new $wnd.Object,ad(Wc(ie,1),Dn,2,6,['todo-list']))].concat((a=Wi(Vi(R(mm.c).T()),(b=new ci,b)),bi(a,_c(a.a.length)))))),R(km.c)?null:Fl(new Gl)))};var Uf=fh(134);Pg(135,134,{});var xl;var Of=fh(135);Pg(136,135,Xn,Al);_.t=function(){if(this.c>=0){this.c=-2;u((H(),H(),G),new Cl(this),In,null)}};_.p=eo;_.jb=no;_.B=io;_.r=fo;_.u=so;_.s=function(){var a;return ah(Af),Af.k+'@'+(a=qj(this)>>>0,a.toString(16))};_.lb=function(){var b;try{return B((H(),H(),G),this.a,new Dl(this))}catch(a){a=Ag(a);if(jd(a,6)||jd(a,7)){b=a;throw Bg(b)}else if(jd(a,4)){b=a;throw Bg(new ph(b))}else throw Bg(a)}};_.c=0;var Af=fh(136);Pg(137,1,Kn,Bl);_.v=oo;var xf=fh(137);Pg(138,1,Hn,Cl);_.v=function(){Ek(this.a)};var yf=fh(138);Pg(139,1,Yn,Dl);_.A=po;var zf=fh(139);Pg(230,$wnd.Function,{},El);_.pb=function(a){Sm((nm(),lm))};Pg(141,1,{},Gl);var Bf=fh(141);Pg(161,1,{},Il);var Cf=fh(161);Pg(229,$wnd.Function,{},Jl);_.fb=function(a){return new Kl(a)};Pg(143,33,{},Kl);_.gb=function(){return new xk};_.componentWillUnmount=to;_.shouldComponentUpdate=uo;var Ff=fh(143);Pg(240,$wnd.Function,{},Ll);_.fb=function(a){return new Ml(a)};Pg(162,33,{},Ml);_.gb=function(){return new Fk};_.componentWillUnmount=to;_.shouldComponentUpdate=uo;var Gf=fh(162);Pg(226,$wnd.Function,{},Nl);_.fb=function(a){return new Ol(a)};Pg(142,33,{},Ol);_.gb=function(){return new Sk};_.componentWillUnmount=to;_.shouldComponentUpdate=uo;var Jf=fh(142);Pg(231,$wnd.Function,{},Pl);_.fb=function(a){return new Ql(a)};Pg(145,33,{},Ql);_.gb=function(){return new nl};_.componentDidUpdate=function(a,b){this.a.ib(a,b)};_.componentWillUnmount=to;_.shouldComponentUpdate=uo;var Lf=fh(145);Pg(223,$wnd.Function,{},Rl);_.fb=function(a){return new Sl(a)};Pg(118,33,{},Sl);_.gb=function(){return new Al};_.componentWillUnmount=to;_.shouldComponentUpdate=uo;var Nf=fh(118);Pg(227,$wnd.Function,{},Tl);_.ob=function(a){Kk(this.a,a)};Pg(228,$wnd.Function,{},Ul);_.nb=function(a){Ok(this.a,a)};Pg(140,1,{},Wl);var Pf=fh(140);Pg(238,$wnd.Function,{},Xl);_.nb=function(a){gl(this.a,a)};Pg(232,$wnd.Function,{},Yl);_.nb=function(a){xm(this.a)};Pg(234,$wnd.Function,{},Zl);_.pb=function(a){$k(this.a,this.b)};Pg(235,$wnd.Function,{},$l);_.pb=function(a){cl(this.a)};Pg(236,$wnd.Function,{},_l);_.w=function(a){_k(this.a,a)};Pg(237,$wnd.Function,{},am);_.mb=function(a){bl(this.a,this.b)};Pg(239,$wnd.Function,{},bm);_.ob=function(a){al(this.a,this.b,a)};Pg(144,1,{},fm);var Rf=fh(144);Pg(224,$wnd.Function,{},gm);_.nb=function(a){var b;b=a.target;Wm((nm(),lm),b.checked)};Pg(64,1,{},im);var Tf=fh(64);var jm,km,lm,mm;Pg(48,1,{48:1});_.g=false;var wg=fh(48);Pg(49,48,{11:1,23:1,49:1,48:1},ym);_.t=function(){pm(this)};_.p=function(a){return qm(this,a)};_.B=lo;_.r=ro;_.u=vo;_.s=function(){var a;return ah(ig),ig.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var om=0;var ig=fh(49);Pg(175,1,Hn,zm);_.v=function(){tm(this.a)};var Vf=fh(175);Pg(176,1,Hn,Am);_.v=function(){um(this.a)};var Wf=fh(176);Pg(46,105,{46:1});var rg=fh(46);Pg(106,46,{11:1,23:1,46:1},Im);_.t=function(){if(this.g>=0){this.g=-2;u((H(),H(),G),new Jm(this),In,null)}};_.p=eo;_.B=wo;_.r=fo;_.u=function(){return this.g<0};_.s=function(){var a;return ah(cg),cg.k+'@'+(a=qj(this)>>>0,a.toString(16))};_.g=0;var cg=fh(106);Pg(111,1,Hn,Jm);_.v=function(){Fm(this.a)};var Xf=fh(111);Pg(112,1,Hn,Km);_.v=function(){fc(this.a,this.b,true)};var Yf=fh(112);Pg(107,1,Yn,Lm);_.A=function(){return Gm(this.a)};var Zf=fh(107);Pg(113,1,Yn,Mm);_.A=function(){return Bm(this.a,this.c,this.b)};_.b=false;var $f=fh(113);Pg(108,1,Yn,Nm);_.A=function(){return rh(Gg(Ti(Em(this.a))))};var _f=fh(108);Pg(109,1,Yn,Om);_.A=function(){return rh(Gg(Ti(Ui(Em(this.a),new vn))))};var ag=fh(109);Pg(110,1,Yn,Pm);_.A=function(){return Hm(this.a)};var bg=fh(110);Pg(83,1,{});var vg=fh(83);Pg(84,83,Xn,Xm);_.t=function(){if(this.b>=0){this.b=-2;u((H(),H(),G),new $m(this),In,null)}};_.p=eo;_.B=co;_.r=fo;_.u=function(){return this.b<0};_.s=function(){var a;return ah(hg),hg.k+'@'+(a=qj(this)>>>0,a.toString(16))};_.b=0;var hg=fh(84);Pg(87,1,Hn,Ym);_.v=function(){wm(this.b,this.a)};var dg=fh(87);Pg(88,1,Hn,Zm);_.v=function(){Tm(this.a)};var eg=fh(88);Pg(85,1,Hn,$m);_.v=function(){lc(this.a.a)};var fg=fh(85);Pg(86,1,Hn,_m);_.v=function(){Um(this.a,this.b)};_.b=false;var gg=fh(86);Pg(89,1,{});var yg=fh(89);Pg(90,89,Xn,jn);_.t=function(){if(this.i>=0){this.i=-2;u((H(),H(),G),new kn(this),In,null)}};_.p=eo;_.B=function(){return this.g};_.r=fo;_.u=function(){return this.i<0};_.s=function(){var a;return ah(og),og.k+'@'+(a=qj(this)>>>0,a.toString(16))};_.i=0;var og=fh(90);Pg(95,1,Hn,kn);_.v=function(){dn(this.a)};var jg=fh(95);Pg(91,1,Yn,ln);_.A=function(){var a;return a=Ub(this.a.j),xh(bo,a)||xh($n,a)||xh('',a)?xh(bo,a)?(sn(),pn):xh($n,a)?(sn(),rn):(sn(),qn):(sn(),qn)};var kg=fh(91);Pg(92,1,Yn,mn);_.A=function(){return en(this.a)};var lg=fh(92);Pg(93,1,Kn,nn);_.v=function(){fn(this.a)};var mg=fh(93);Pg(94,1,Kn,on);_.v=function(){gn(this.a)};var ng=fh(94);Pg(36,35,{3:1,31:1,35:1,36:1},tn);var pn,qn,rn;var pg=gh(36,un);Pg(79,1,{},vn);_.cb=function(a){return !sm(a)};var qg=fh(79);Pg(81,1,{},wn);_.cb=function(a){return sm(a)};var sg=fh(81);Pg(82,1,{},xn);_.w=function(a){Dm(this.a,a)};var tg=fh(82);Pg(80,1,{},yn);_.w=function(a){Rm(this.a,a)};_.a=false;var ug=fh(80);Pg(72,1,{},zn);_.cb=function(a){return bn(this.a,a)};var xg=fh(72);var An=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=Kg;Ig(Vg);Lg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();