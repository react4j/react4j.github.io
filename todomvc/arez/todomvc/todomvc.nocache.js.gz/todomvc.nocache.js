function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='AA43106D977028DE5B0EFE1509884C1B',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'AA43106D977028DE5B0EFE1509884C1B';function o(){}
function Yg(){}
function Ug(){}
function Ul(){}
function Wl(){}
function Xl(){}
function Zl(){}
function zb(){}
function Oc(){}
function Vc(){}
function jj(){}
function kj(){}
function Ak(){}
function bm(){}
function jm(){}
function lm(){}
function Hn(){}
function In(){}
function Go(){}
function Tc(a){Sc()}
function dh(){dh=Ug}
function gi(){Zh(this)}
function db(a){this.a=a}
function qb(a){this.a=a}
function rb(a){this.a=a}
function sb(a){this.a=a}
function ac(a){this.a=a}
function cc(a){this.a=a}
function dc(a){this.a=a}
function ec(a){this.a=a}
function ic(a){this.a=a}
function uh(a){this.a=a}
function Fh(a){this.a=a}
function Rh(a){this.a=a}
function Wh(a){this.a=a}
function Xh(a){this.a=a}
function Vh(a){this.b=a}
function ii(a){this.c=a}
function hj(a){this.a=a}
function mj(a){this.a=a}
function Bk(a){this.a=a}
function Ck(a){this.a=a}
function Dk(a){this.a=a}
function Ik(a){this.a=a}
function Jk(a){this.a=a}
function Kk(a){this.a=a}
function Vk(a){this.a=a}
function Wk(a){this.a=a}
function Yk(a){this.a=a}
function Zk(a){this.a=a}
function wl(a){this.a=a}
function xl(a){this.a=a}
function Al(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function El(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function Nl(a){this.a=a}
function Ol(a){this.a=a}
function Pl(a){this.a=a}
function _l(a){this.a=a}
function am(a){this.a=a}
function dm(a){this.a=a}
function em(a){this.a=a}
function fm(a){this.a=a}
function gm(a){this.a=a}
function hm(a){this.a=a}
function im(a){this.a=a}
function om(a){this.a=a}
function Lm(a){this.a=a}
function Mm(a){this.a=a}
function Vm(a){this.a=a}
function Xm(a){this.a=a}
function Zm(a){this.a=a}
function $m(a){this.a=a}
function _m(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function An(a){this.a=a}
function Jn(a){this.a=a}
function Kn(a){this.a=a}
function Ln(a){this.a=a}
function Rl(){this.a={}}
function Tl(){this.a={}}
function nm(){this.a={}}
function sm(){this.a={}}
function um(){this.a={}}
function Bo(){Gj(this.a)}
function Io(){Hj(this.a)}
function si(){this.a=Bi()}
function Gi(){this.a=Bi()}
function to(a){Ki(this,a)}
function wo(a){yh(this,a)}
function Y(a){Ib((H(),a))}
function Z(a){Jb((H(),a))}
function bb(a){Kb((H(),a))}
function bn(a,b){Hm(b,a)}
function C(a,b){wb(a.b,b)}
function mc(a,b){Nh(a.b,b)}
function lj(a,b){bj(a.a,b)}
function an(a,b){Om(a.c,b)}
function w(a,b,c){s(a,c,b)}
function Dj(a,b,c){a[b]=c}
function ij(a,b){a.a=b}
function kb(a,b){a.b=Ni(b)}
function A(a){--a.e;D(a)}
function Fg(a){return a.e}
function Eo(){return this.e}
function qo(){return this.a}
function vo(){return this.b}
function yo(){return this.c}
function Lo(){return this.f}
function so(){return uj(this)}
function zo(){return this.d<0}
function Fo(){return this.c<0}
function Ko(){return this.f<0}
function Mo(){return this.g<0}
function bl(a,b){return a.p=b}
function Bh(a,b){return a===b}
function Cj(a,b){return a[b]}
function ai(a,b){return a.a[b]}
function qj(a,b){a.splice(b,1)}
function kc(a,b,c){Mh(a.b,b,c)}
function Gk(a){lc(a.b);eb(a.a)}
function Gh(a){sc.call(this,a)}
function Vl(a){Ej.call(this,a)}
function Yl(a){Ej.call(this,a)}
function $l(a){Ej.call(this,a)}
function cm(a){Ej.call(this,a)}
function km(a){Ej.call(this,a)}
function ro(a){return this===a}
function Ao(){return H(),H(),G}
function xi(){xi=Ug;wi=zi()}
function H(){H=Ug;G=new F}
function uc(){uc=Ug;tc=new o}
function Lc(){Lc=Ug;Kc=new Oc}
function nc(){this.b=new mi}
function F(){this.b=new xb}
function Ho(a,b){this.a.nb(a,b)}
function Wc(a,b){return mh(a,b)}
function uo(){return Ph(this.a)}
function Co(){return Kj(this.a)}
function zh(){oc(this);this.L()}
function gh(a){fh(a);return a.k}
function Tb(a){$(a.a);return a.e}
function Ub(a){$(a.b);return a.g}
function Dm(a){$(a.b);return a.i}
function Em(a){$(a.a);return a.g}
function pn(a){$(a.d);return a.j}
function aj(a,b){a.V(b);return a}
function Bi(){xi();return new wi}
function V(a){H();Jb(a);a.e=-2}
function Wb(a){Sb(a,($(a.b),a.g))}
function Cb(a){Db(a);!a.d&&Gb(a)}
function bj(a,b){ij(a,aj(a.a,b))}
function Oi(a,b){while(a.gb(b));}
function bc(a,b){this.a=a;this.b=b}
function jc(a,b){this.a=a;this.b=b}
function rh(a,b){this.a=a;this.b=b}
function Yh(a,b){this.a=a;this.b=b}
function ej(a,b){this.a=a;this.b=b}
function uk(a,b){rh.call(this,a,b)}
function Xk(a,b){this.a=a;this.b=b}
function zl(a,b){this.a=a;this.b=b}
function Bl(a,b){this.a=a;this.b=b}
function Il(a,b){this.a=a;this.b=b}
function Ph(a){return a.a.b+a.b.b}
function Di(a,b){return a.a.get(b)}
function _c(a){return new Array(a)}
function pm(a){return qm(new sm,a)}
function Gm(a){Hm(a,($(a.a),!a.g))}
function Bc(){Bc=Ug;!!(Sc(),Rc)}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function J(a){a.b=0;a.d=0;a.c=false}
function Mj(a,b){a.ref=b;return a}
function Nj(a,b){a.href=b;return a}
function Dh(a,b){a.a+=''+b;return a}
function Xj(a,b){a.value=b;return a}
function oj(a,b,c){a.splice(b,0,c)}
function fj(a,b){a.G(rm(pm(b.e),b))}
function Fn(a,b){rh.call(this,a,b)}
function jn(a,b){this.b=a;this.a=b}
function mn(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function Jj(a,b){return a.s||a.pb(b)}
function Eb(a){return !a.d?a:Eb(a.d)}
function Lh(a){return !a?null:a.cb()}
function od(a){return a==null?null:a}
function Mi(a){return a!=null?r(a):0}
function ld(a){return typeof a===On}
function Jo(a,b){return Jj(this.a,a)}
function cb(a){this.c=new gi;this.b=a}
function Oh(a){a.a=new si;a.b=new Gi}
function Zh(a){a.a=Yc(fe,Pn,1,0,5,1)}
function Ic(a){$wnd.clearTimeout(a)}
function yk(a){lc(a.c);eb(a.b);Q(a.a)}
function Sk(a){lc(a.c);eb(a.a);U(a.b)}
function hc(a,b){fc(a,b,false);Z(a.d)}
function pj(a,b){nj(b,0,a,0,b.length)}
function Sj(a,b){a.onBlur=b;return a}
function Oj(a,b){a.onClick=b;return a}
function Tj(a,b){a.onChange=b;return a}
function Qj(a,b){a.checked=b;return a}
function yj(){yj=Ug;vj=new o;xj=new o}
function Ng(){Lg==null&&(Lg=[])}
function jb(a){H();ib(a);lb(a,2,true)}
function $(a){var b;Fb((H(),b=Ab,b),a)}
function xo(){return R((zm(),wm).b).a>0}
function T(a){return !(!!a&&1==(a.c&7))}
function uj(a){return a.$H||(a.$H=++tj)}
function Ah(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function B(a,b,c){return t(a,c,2048,b)}
function bd(a,b,c){return {l:a,m:b,h:c}}
function nd(a){return typeof a==='string'}
function kd(a){return typeof a==='boolean'}
function Pj(a){a.autoFocus=true;return a}
function Uj(a,b){a.onKeyDown=b;return a}
function fh(a){if(a.k!=null){return}oh(a)}
function pc(a,b){a.e=b;b!=null&&sj(b,$n,a)}
function Rj(a,b){a.defaultValue=b;return a}
function _i(a,b){Wi.call(this,a);this.a=b}
function sc(a){this.f=a;oc(this);this.L()}
function hn(a){this.c=Ni(a);this.a=new nc}
function mi(){this.a=new si;this.b=new Gi}
function O(){this.a=Yc(fe,Pn,1,100,5,1)}
function xh(){xh=Ug;wh=Yc(be,Pn,32,256,0,1)}
function _g(){_g=Ug;$g=$wnd.window.document}
function oc(a){a.g&&a.e!==Zn&&a.L();return a}
function Yj(a,b){a.onDoubleClick=b;return a}
function lh(){var a;a=ih(null);a.e=2;return a}
function jh(a){var b;b=ih(a);qh(a,b);return b}
function Fm(a){lc(a.c);U(a.d);U(a.b);U(a.a)}
function Tm(a){return vh(R(a.e).a-R(a.a).a)}
function v(a,b){return new ob(Ni(a),null,b)}
function Cc(a,b,c){return a.apply(b,c);var d}
function Ki(a,b){while(a.$()){lj(b,a._())}}
function gc(a,b){mc(b.I(),a);jd(b,11)&&b.C()}
function qm(a,b){Dj(a.a,'key',Ni(b));return a}
function $h(a,b){a.a[a.a.length]=b;return true}
function Pb(a,b){a.i&&b.preventDefault();$b(a)}
function ui(a,b){var c;c=a[eo];c.call(a,b)}
function Mk(a,b){var c;c=b.target;Tk(a,c.value)}
function hb(a,b){X(b,a);b.c.a.length>0||(b.a=4)}
function Ym(a,b){this.a=a;this.c=b;this.b=false}
function Ji(a,b,c){this.a=a;this.b=b;this.c=c}
function yl(a,b,c){this.a=a;this.b=b;this.c=c}
function sj(b,c,d){try{b[c]=d}catch(a){}}
function Sc(){Sc=Ug;var a;!Uc();a=new Vc;Rc=a}
function Zi(a){Vi(a);return new _i(a,new gj(a.a))}
function il(a){ab(a.c);return Cj(a.u.props,lo)}
function nl(a){ul(a,Dm((ab(a.c),a.u.props[lo])))}
function cj(a,b,c){if(a.a.hb(c)){a.b=true;b.G(c)}}
function yb(a){if(!a.a){a.a=true;A((H(),H(),G))}}
function Qi(a){if(!a.d){a.d=a.b.U();a.c=a.b.W()}}
function Th(a){var b;b=a.a._();a.b=Sh(a);return b}
function ci(a,b){var c;c=a.a[b];qj(a.a,b);return c}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ei(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Tk(a,b){var c;c=a.g;if(b!=c){a.g=b;Z(a.b)}}
function Ci(a,b){return !(a.a.get(b)===undefined)}
function ml(a,b){return dh(),hl(a,b)?true:false}
function Sm(a){return dh(),0==R(a.e).a?true:false}
function Ij(a){return jd(a,11)&&a.D()?null:a.qb()}
function $c(a){return Array.isArray(a)&&a.Ab===Yg}
function hd(a){return !Array.isArray(a)&&a.Ab===Yg}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function nn(a){return Bh(po,a)||Bh(mo,a)||Bh('',a)}
function ll(a){lc(a.e);eb(a.b);Q(a.d);U(a.c);U(a.a)}
function ul(a,b){var c;c=a.q;if(b!=c){a.q=b;Z(a.a)}}
function Hm(a,b){var c;c=a.g;if(b!=c){a.g=b;Z(a.a)}}
function Pi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function li(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function Qh(a,b){if(b){return Jh(a.a,b)}return false}
function Yi(a,b){Vi(a);return new _i(a,new dj(b,a.a))}
function Kg(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function Ni(a){if(a==null){throw Fg(new zh)}return a}
function Bj(){if(wj==256){vj=xj;xj=new o;wj=0}++wj}
function Ui(a){if(!a.b){Vi(a);a.c=true}else{Ui(a.b)}}
function Wi(a){if(!a){this.b=null;new gi}else{this.b=a}}
function gj(a){Pi.call(this,a.fb(),a.eb()&-6);this.a=a}
function Lb(a,b){this.a=(H(),H(),G).a++;this.d=a;this.e=b}
function Ri(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Wj(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function kh(a,b){var c;c=ih(a);qh(a,c);c.e=b?8:0;return c}
function Yb(a,b){var c;c=a.e;if(b!=c){a.e=Ni(b);Z(a.a)}}
function Zb(a,b){var c;c=a.g;if(b!=c){a.g=Ni(b);Z(a.b)}}
function Im(a,b){var c;c=a.i;if(b!=c){a.i=Ni(b);Z(a.b)}}
function ab(a){var b;H();!!Ab&&!!Ab.e&&Fb((b=Ab,b),a)}
function vb(a){while(true){if(!tb(a)&&!ub(a)){break}}}
function cl(a){Pm((zm(),wm),(ab(a.c),Cj(a.u.props,lo)))}
function Gj(a){if(!a.s){a.s=true;a.t||a.u.forceUpdate()}}
function nh(a){if(a.S()){return null}var b=a.j;return Qg[b]}
function Bb(a){if(a.e){2==(a.e.c&7)||lb(a.e,4,true);ib(a.e)}}
function qn(a){lc(a.f);eb(a.e);eb(a.a);Q(a.b);Q(a.c);U(a.d)}
function th(a){this.f=!a?null:qc(a,a.K());oc(this);this.L()}
function yh(a,b){var c,d;for(d=a.U();d.$();){c=d._();b.G(c)}}
function _k(a,b){var c;if(R(a.d)){c=b.target;ul(a,c.value)}}
function qc(a,b){var c;c=gh(a.yb);return b==null?c:c+': '+b}
function Kh(a,b){return b===a?'(this Map)':b==null?ao:Xg(b)}
function Gn(){En();return ad(Wc(tg,1),Pn,36,0,[Bn,Dn,Cn])}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function en(a,b){var c;$i(Qm(a.c),(c=new gi,c)).T(new Kn(b))}
function mh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.N(b))}
function wb(a,b){b.c|=512;I(a.d[((b.c&229376)>>15)-1],Ni(b))}
function Nk(a,b){if(13==b.keyCode){b.preventDefault();Qk(a)}}
function Vi(a){if(a.b){Vi(a.b)}else if(a.c){throw Fg(new sh)}}
function Wg(a){function b(){}
;b.prototype=a||{};return new b}
function Mb(a,b){Ab=new Lb(Ab,b);a.d=false;Bb(Ab);return Ab}
function Ob(a,b){a.j=b;Bh(b,($(a.a),a.e))&&Zb(a,b);Qb(b);$b(a)}
function fb(a){var b;b=(H(),H(),G);wb(b.b,a);0!=(a.c&Vn)&&D(b)}
function dl(a){un((zm(),ym),(ab(a.c),Cj(a.u.props,lo)));tl(a)}
function gl(){gl=Ug;var a;fl=(a=Vg(bm.prototype.kb,bm,[]),a)}
function Kl(){Kl=Ug;var a;Jl=(a=Vg(jm.prototype.kb,jm,[]),a)}
function xk(){xk=Ug;var a;wk=(a=Vg(Ul.prototype.kb,Ul,[]),a)}
function Fk(){Fk=Ug;var a;Ek=(a=Vg(Xl.prototype.kb,Xl,[]),a)}
function Pk(){Pk=Ug;var a;Ok=(a=Vg(Zl.prototype.kb,Zl,[]),a)}
function oi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function pi(a,b){var c;return ni(b,oi(a,b==null?0:(c=r(b),c|0)))}
function Qm(a){$(a.d);return new _i(null,new Ri(new Wh(a.i),0))}
function hi(a){Zh(this);pj(this.a,Ih(a,Yc(fe,Pn,1,Ph(a.a),5,1)))}
function ti(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Do(){return pn((zm(),ym))==(ab(this.c),this.u.props[lo])}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function sn(a){var b;b=($(a.d),a.j);!!b&&!!b&&b.f<0&&un(a,null)}
function Bm(a){if(a.f>=0){a.f=-2;u((H(),H(),G),new Lm(a),Un,null)}}
function Vj(a){a.placeholder='What needs to be done?';return a}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Sg(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function un(a,b){var c;c=a.j;if(!(b==c||!!b&&Cm(b,c))){a.j=b;Z(a.d)}}
function W(a,b){var c,d;$h(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function ah(a,b,c,d){a.addEventListener(b,c,(dh(),d?true:false))}
function bh(a,b,c,d){a.removeEventListener(b,c,(dh(),d?true:false))}
function Ql(a){return $wnd.React.createElement((xk(),wk),a.a,undefined)}
function Sl(a){return $wnd.React.createElement((Fk(),Ek),a.a,undefined)}
function mm(a){return $wnd.React.createElement((Pk(),Ok),a.a,undefined)}
function tm(a){return $wnd.React.createElement((Kl(),Jl),a.a,undefined)}
function Nh(a,b){return nd(b)?b==null?ri(a.a,null):Fi(a.b,b):ri(a.a,b)}
function Si(a,b){!a.a?(a.a=new Fh(a.d)):Dh(a.a,a.b);Dh(a.a,b);return a}
function $i(a,b){var c;Ui(a);c=new jj;c.a=b;a.a.Z(new mj(c));return c.a}
function Xi(a){var b;Ui(a);b=0;while(a.a.gb(new kj)){b=Gg(b,1)}return b}
function dn(a){var b;$i(Yi(Qm(a.c),new In),(b=new gi,b)).T(new Jn(a.c))}
function zm(){zm=Ug;vm=new _b;wm=new Um;xm=new hn(wm);ym=new vn(wm,vm)}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function Hi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Uh(a){this.d=a;this.c=new Hi(this.d.b);this.a=this.c;this.b=Sh(this)}
function Ti(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function dj(a,b){Pi.call(this,b.fb(),b.eb()&-16449);this.a=a;this.c=b}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function _h(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.G(c)}}
function rn(a){var b,c;return b=R(a.b),$i(Yi(Qm(a.k),new Ln(b)),(c=new gi,c))}
function on(a,b){return (En(),Cn)==a||(Bn==a?($(b.a),!b.g):($(b.a),b.g))}
function Mh(a,b,c){return nd(b)?b==null?qi(a.a,null,c):Ei(a.b,b,c):qi(a.a,b,c)}
function rj(a,b){return Xc(b)!=10&&ad(q(b),b.zb,b.__elementTypeId$,Xc(b),a),a}
function ol(a){return dh(),pn((zm(),ym))==(ab(a.c),a.u.props[lo])?true:false}
function U(a){if(-2!=a.e){u((H(),H(),G),new db(a),0,null);!!a.b&&eb(a.b)}}
function Q(a){if(!a.a){a.a=true;a.g=null;a.b=null;U(a.d);2==(a.e.c&7)||eb(a.e)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{vb(a.b)}finally{a.c=false}}}}
function Ii(a){if(a.a.c!=a.c){return Di(a.a,a.b.value[0])}return a.b.value[1]}
function bi(a,b,c){for(;c<a.a.length;++c){if(li(b,a.a[c])){return c}}return -1}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function di(a,b){var c;c=bi(a,b,0);if(c==-1){return false}qj(a.a,c);return true}
function Kj(a){var b;a.s=false;if(a.mb()){return null}else{b=a.jb();return b}}
function Lk(a){var b;b=Ch(($(a.b),a.g));if(b.length>0){an((zm(),xm),b);Tk(a,'')}}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function Vb(a){bh((_g(),$wnd.window.window),Xn,a.f,false);lc(a.c);U(a.b);U(a.a)}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function Nb(){var a;try{Cb(Ab);H()}finally{a=Ab.d;!a&&((H(),H(),G).d=true);Ab=Ab.d}}
function tb(a){var b;if(0==N(a.c)){return false}else{b=M(a.c);!!b&&b.C();return true}}
function qh(a,b){var c;if(!a){return}b.j=a;var d=nh(b);if(!d){Qg[a]=[b];return}d.yb=b}
function Vg(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Eg(a){var b;if(jd(a,4)){return a}b=a&&a[$n];if(!b){b=new wc(a);Tc(b)}return b}
function ih(a){var b;b=new hh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function al(a,b){27==b.which?(tl(a),un((zm(),ym),null)):13==b.which&&rl(a)}
function eb(a){if(2<(a.c&7)){u((H(),H(),G),new rb(a),Un,null);!!a.a&&Q(a.a);a.c=a.c&-8|1}}
function Fb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;$h((!a.b&&(a.b=new gi),a.b),b)}}}
function Hb(a,b){var c;if(!a.c){c=Eb(a);!c.c&&(c.c=new gi);a.c=c.c}b.d=true;$h(a.c,Ni(b))}
function I(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&K(a,c);L(a,Ni(b))}
function Fi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{ui(a.a,b);--a.b}return c}
function ji(a){var b,c,d;d=0;for(c=new Uh(a.a);c.b;){b=Th(c);d=d+(b?r(b):0);d=d|0}return d}
function ib(a){var b,c;for(c=new ii(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Mg(){Ng();var a=Lg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function sh(){sc.call(this,"Stream already terminated, can't be modified or used")}
function rm(a,b){Dj(a.a,lo,b);return $wnd.React.createElement((gl(),fl),a.a,undefined)}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function md(a){return a!=null&&(typeof a===Nn||typeof a==='function')&&!(a.Ab===Yg)}
function Pg(a,b){typeof window===Nn&&typeof window['$gwt']===Nn&&(window['$gwt'][a]=b)}
function En(){En=Ug;Bn=new Fn('ACTIVE',0);Dn=new Fn('COMPLETED',1);Cn=new Fn('ALL',2)}
function Hj(a){var b;b=(++a.ob().e,new zb);try{a.t=true;jd(a,11)&&a.C()}finally{yb(b)}}
function fc(a,b,c){var d;d=Nh(a.i,b?vh(b.e):null);if(null!=d){mc(b.c,a);c&&!!b&&Bm(b);Z(a.d)}}
function Rm(a){yh(new Wh(a.i),new ic(a));Oh(a.i);lc(a.f);Q(a.c);Q(a.e);Q(a.a);Q(a.b);U(a.d)}
function Nm(a,b,c){var d;d=new Km(b,c);kc(d.c,a,new jc(a,d));Mh(a.i,vh(d.e),d);Z(a.d);return d}
function Hh(a,b){var c,d;for(d=new Uh(b.a);d.b;){c=Th(d);if(!Qh(a,c)){return false}}return true}
function ni(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(li(a,c.bb())){return c}}return null}
function Jg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=bo;d=1048575}c=pd(e/Vn);b=pd(e-c*Vn);return bd(b,c,d)}
function Hg(a){var b;b=a.h;if(b==0){return a.l+a.m*Vn}if(b==1048575){return a.l+a.m*Vn-bo}return a}
function Sh(a){if(a.a.$()){return true}if(a.a!=a.c){return false}a.a=new ti(a.d.a);return a.a.$()}
function R(a){$(a.d);mb(a.e)&&gb(a.e);if(a.b){if(jd(a.b,5)){throw Fg(a.b)}else{throw Fg(a.b)}}return a.g}
function hl(a,b){var c;c=false;if(!(a.u.props[lo]===(null==b?null:b[lo]))){c=true;Z(a.c)}return c}
function Ei(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function X(a,b){var c,d;d=a.c;di(d,b);d.a.length==0&&!!a.b&&Rn!=(a.b.c&Sn)&&(a.d||Hb((H(),c=Ab,c),a))}
function tn(a){var b;b=Tb(a.i);Bh(po,b)||Bh(mo,b)||Bh('',b)?Sb(a.i,b):nn(Ub(a.i))?Xb(a.i):Sb(a.i,'')}
function $k(a){var b;b=R(a.d);if(!a.r&&b){a.r=true;tl(a);a.p.focus();a.p.select()}else a.r&&!b&&(a.r=false)}
function Cm(a,b){var c;if(a===b){return true}else if(null==b||!jd(b,49)){return false}else{c=b;return a.e==c.e}}
function vh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(xh(),wh)[b];!c&&(c=wh[b]=new uh(a));return c}return new uh(a)}
function Ej(a){$wnd.React.Component.call(this,a);this.a=this.lb();this.a.u=Ni(this);this.a.ib()}
function hh(){this.g=eh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function S(a,b){this.c=Ni(a);this.f=null;this.g=null;this.e=new pb(this,b);this.d=new cb(this.e);Rn==(b&Sn)&&fb(this.e)}
function Hk(){Fk();++Fj;this.b=new nc;this.a=new ob(null,Ni((H(),new Ik(this))),ho);D((null,G))}
function Zg(){zm();$wnd.ReactDOM.render(tm(new um),(_g(),$g).getElementById('todoapp'),null)}
function ad(a,b,c,d,e){e.yb=a;e.zb=b;e.Ab=Yg;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function q(a){return nd(a)?ie:ld(a)?Zd:kd(a)?Xd:hd(a)?a.yb:$c(a)?a.yb:a.yb||Array.isArray(a)&&Wc(Qd,1)||Qd}
function r(a){return nd(a)?Aj(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.A():$c(a)?uj(a):!!a&&!!a.hashCode?a.hashCode():uj(a)}
function p(a,b){return nd(a)?Bh(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.v(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function Gg(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<bo){return c}}return Hg(cd(ld(a)?Jg(a):a,ld(b)?Jg(b):b))}
function lc(a){var b,c;if(!a.a){for(c=new ii(new hi(new Wh(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.F()}a.a=true}}
function ki(a){var b,c,d;d=1;for(c=new ii(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Aj(a){yj();var b,c,d;c=':'+a;d=xj[c];if(d!=null){return pd(d)}d=vj[c];b=d==null?zj(a):pd(d);Bj();xj[c]=b;return b}
function wc(a){uc();oc(this);this.e=a;a!=null&&sj(a,$n,this);this.f=a==null?ao:Xg(a);this.a='';this.b=a;this.a=''}
function nb(a,b,c,d){this.b=new gi;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&fb(this)}
function xb(){this.c=new O;this.d=Yc(rd,Pn,21,5,0,1);this.d[0]=new O;this.d[1]=new O;this.d[2]=new O;this.d[3]=new O;this.d[4]=new O}
function Ml(){Kl();++Fj;this.d=Vg(lm.prototype.sb,lm,[]);this.b=new nc;this.a=new ob(null,Ni((H(),new Nl(this))),ho);D((null,G))}
function vk(){tk();return ad(Wc(Ye,1),Pn,10,0,[Zj,$j,_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk])}
function Rb(a){var b,c;c=(b=(_g(),$wnd.window.window).location.hash,null==b?'':b.substr(1));Yb(a,c);Bh(a.j,c)&&Zb(a,c)}
function Xg(a){var b;if(Array.isArray(a)&&a.Ab===Yg){return gh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function ob(a,b,c){nb.call(this,null,a,b,c|(!a?262144:Rn)|(0!=(c&6291456)?0:!a?2097152:Vn)|(0!=(c&229376)?0:98304)|0|0|0)}
function pb(a,b){nb.call(this,a,new qb(a),null,b|(Rn==(b&Sn)?0:524288)|(0!=(b&6291456)?0:Rn==(b&Sn)?Vn:2097152)|0|268435456|0|(0!=(b&229376)?0:98304))}
function ph(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function fi(a,b){var c,d;d=a.a.length;b.length<d&&(b=rj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function s(b,c,d){var e;try{Mb(b,d);try{c.F()}finally{Nb()}}catch(a){a=Eg(a);if(jd(a,4)){e=a;throw Fg(e)}else throw Fg(a)}finally{D(b)}}
function Lj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.zb){return !!a.zb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function Kb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ii(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&lb(b,5,true)}}}
function Jb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ii(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&lb(b,6,true)}}}
function Ib(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ii(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?lb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Ch(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Gb(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=ci(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&lb(c.b,3,true);++b}}}return b}
function Km(a,b){var c,d,e;this.i=Ni(a);this.g=b;this.e=Am++;this.d=(d=new cb((H(),null)),d);this.c=new nc;this.b=(e=new cb(null),e);this.a=(c=new cb(null),c)}
function zk(){xk();++Fj;this.e=Vg(Wl.prototype.ub,Wl,[]);this.c=new nc;this.a=new S((H(),new Ak),136478720);this.b=new ob(null,Ni(new Ck(this)),ho);D((null,G))}
function el(a){var b;b=($(a.a),a.q);if(null!=b&&b.length!=0){fn((zm(),ab(a.c),a.u.props[lo]),b);un(ym,null);ul(a,b)}else{Pm((zm(),wm),(ab(a.c),a.u.props[lo]))}}
function Og(b,c,d,e){Ng();var f=Lg;$moduleName=c;$moduleBase=d;Dg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Mn(g)()}catch(a){b(c,a)}}else{Mn(g)()}}
function Xb(b){var c;try{u((H(),H(),G),new cc(b),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function $b(b){var c;try{u((H(),H(),G),new dc(b),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function Qk(b){var c;try{u((H(),H(),G),new Wk(b),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function pl(b){var c;try{u((H(),H(),G),new Gl(b),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function ql(b){var c;try{u((H(),H(),G),new Fl(b),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function rl(b){var c;try{u((H(),H(),G),new Cl(b),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function sl(b){var c;try{u((H(),H(),G),new El(b),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function tl(b){var c;try{u((H(),H(),G),new Al(b),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function Jm(b){var c;try{u((H(),H(),G),new Mm(b),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function cn(b){var c;try{u((H(),H(),G),new kn(b),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function fn(b,c){var d;try{u((H(),H(),G),new jn(b,c),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){d=a;throw Fg(d)}else if(jd(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function gn(b,c){var d;try{u((H(),H(),G),new mn(b,c),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){d=a;throw Fg(d)}else if(jd(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Rk(b,c){var d;try{u((H(),H(),G),new Xk(b,c),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){d=a;throw Fg(d)}else if(jd(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function jl(b,c){var d;try{u((H(),H(),G),new Il(b,c),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){d=a;throw Fg(d)}else if(jd(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function kl(b,c){var d;try{u((H(),H(),G),new Bl(b,c),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){d=a;throw Fg(d)}else if(jd(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Pm(b,c){var d;try{u((H(),H(),G),new Wm(b,c),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){d=a;throw Fg(d)}else if(jd(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Om(b,c){var d;try{return t((H(),H(),G),new Ym(b,c),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){d=a;throw Fg(d)}else if(jd(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Sb(b,c){var d;try{u((H(),H(),G),new bc(b,c),75497472,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){d=a;throw Fg(d)}else if(jd(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function u(b,c,d,e){var f;try{if(0==(d&2048)&&!!Ab){c.F()}else{Mb(b,e);try{c.F()}finally{Nb()}}}catch(a){a=Eg(a);if(jd(a,4)){f=a;throw Fg(f)}else throw Fg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ab){g=c.H()}else{Mb(b,e);try{g=c.H()}finally{Nb()}}return g}catch(a){a=Eg(a);if(jd(a,4)){f=a;throw Fg(f)}else throw Fg(a)}finally{D(b)}}
function zi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ai()}}
function Ih(a,b){var c,d,e,f,g;g=Ph(a.a);b.length<g&&(b=rj(new Array(g),b));e=(f=new Uh((new Rh(a.a)).a),new Xh(f));for(d=0;d<g;++d){b[d]=(c=Th(e.a),c.cb())}b.length>g&&(b[g]=null);return b}
function Rg(){Qg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Bb()&&(c=Pc(c,g)):g[0].Bb()}catch(a){a=Eg(a);if(jd(a,4)){d=a;Bc();Hc(jd(d,39)?d.M():d)}else throw Fg(a)}}return c}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?ao:md(b)?b==null?null:b.name:nd(b)?'String':gh(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function P(b){var c,d,e;e=b.g;try{d=b.c.H();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.g=d;b.b=null;Y(b.d)}}catch(a){a=Eg(a);if(jd(a,12)){c=a;if(!b.b){b.g=null;b.b=c;Y(b.d)}throw Fg(c)}else throw Fg(a)}}
function Um(){var a;this.i=new mi;this.f=new nc;this.d=(a=new cb((H(),null)),a);this.c=new S(new Xm(this),oo);this.e=new S(new Zm(this),oo);this.a=new S(new $m(this),oo);this.b=new S(new _m(this),oo)}
function vn(a,b){var c;this.k=Ni(a);this.i=Ni(b);this.f=new nc;this.d=(c=new cb((H(),null)),c);this.b=new S(new xn(this),oo);this.c=new S(new yn(this),oo);this.e=v(new zn(this),413138944);this.a=v(new An(this),681574400);D((null,G))}
function nj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Uk(){Pk();var a;++Fj;this.f=Vg(_l.prototype.tb,_l,[this]);this.e=Vg(am.prototype.sb,am,[this]);this.c=new nc;this.b=(a=new cb((H(),null)),a);this.a=new ob(null,Ni(new Yk(this)),ho);D((null,G))}
function qi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=ni(b,e);if(f){return f.db(c)}}e[e.length]=new Yh(b,c);++a.b;return null}
function zj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ah(a,c++)}b=b|0;return b}
function K(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Yc(fe,Pn,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function Qb(a){var b;if(0==a.length){b=(_g(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',$g.title,b)}else{(_g(),$wnd.window.window).location.hash=a}}
function gb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;w((H(),H(),G),b,c)}else{b.e.F()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=Eg(a);if(jd(a,4)){H()}else throw Fg(a)}}}
function ri(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(li(b,e.bb())){if(d.length==1){d.length=0;ui(a.a,g)}else{d.splice(h,1)}--a.b;return e.cb()}}return null}
function Tg(a,b,c){var d=Qg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Qg[b]),Wg(h));_.zb=c;!b&&(_.Ab=Yg);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.yb=f)}
function oh(a){if(a.R()){var b=a.c;b.S()?(a.k='['+b.j):!b.R()?(a.k='[L'+b.P()+';'):(a.k='['+b.P());a.b=b.O()+'[]';a.i=b.Q()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=ph('.',[c,ph('$',d)]);a.b=ph('.',[c,ph('.',d)]);a.i=d[d.length-1]}
function _b(){var a,b,c;this.f=new ec(this);this.c=new nc;this.b=(c=new cb((H(),null)),c);this.a=(b=new cb(null),b);ah((_g(),$wnd.window.window),Xn,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function Jh(a,b){var c,d,e;c=b.bb();e=b.cb();d=nd(c)?c==null?Lh(pi(a.a,null)):Di(a.b,c):Lh(pi(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!pi(a.a,null):Ci(a.b,c):!!pi(a.a,c))){return false}return true}
function mb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ii(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{R(c)}catch(a){a=Eg(a);if(!jd(a,4))throw Fg(a)}if(6==(b.c&7)){return true}}}}}ib(b);return false}
function yi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function lb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((H(),H(),G),a))}else if(!!a.a&&4==f&&(6==b||5==b)){bb(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((H(),H(),G),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}_h(a.b,new sb(a));a.b.a=Yc(fe,Pn,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function ub(a){var b,c,d,e,f,g,h,i;d=N(a.d[0]);c=N(a.d[1]);g=N(a.d[2]);e=N(a.d[3]);f=N(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;J(a.d[0]);J(a.d[1]);J(a.d[2]);J(a.d[3]);J(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=M(b);h.c&=-513;gb(h);return true}
function vl(){gl();var a,b;++Fj;this.i=Vg(dm.prototype.tb,dm,[this]);this.n=Vg(em.prototype.rb,em,[this]);this.o=Vg(fm.prototype.sb,fm,[this]);this.k=Vg(gm.prototype.ub,gm,[this]);this.j=Vg(hm.prototype.ub,hm,[this]);this.g=Vg(im.prototype.sb,im,[this]);this.e=new nc;this.c=(b=new cb((H(),null)),b);this.a=(a=new cb(null),a);this.d=new S(new Dl(this),136478720);this.b=new ob(null,Ni(new Hl(this)),ho);D((null,G))}
function tk(){tk=Ug;Zj=new uk(fo,0);$j=new uk('checkbox',1);_j=new uk('color',2);ak=new uk('date',3);bk=new uk('datetime',4);ck=new uk('email',5);dk=new uk('file',6);ek=new uk('hidden',7);fk=new uk('image',8);gk=new uk('month',9);hk=new uk(On,10);ik=new uk('password',11);jk=new uk('radio',12);kk=new uk('range',13);lk=new uk('reset',14);mk=new uk('search',15);nk=new uk('submit',16);ok=new uk('tel',17);pk=new uk('text',18);qk=new uk('time',19);rk=new uk('url',20);sk=new uk('week',21)}
function Db(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ai(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ei(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{X(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&lb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ai(a.b,g);if(-1==k.e){k.e=0;W(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ci(a.b,g)}e&&kb(a.e,a.b)}else{e&&kb(a.e,new gi)}if(T(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&Rn!=(b.e.c&Sn)&&Hb(a,k)}}
function Ai(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[eo]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!yi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[eo]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Nn='object',On='number',Pn={3:1,6:1},Qn={11:1},Rn=1048576,Sn=1835008,Tn={8:1},Un=67108864,Vn=4194304,Wn={29:1},Xn='hashchange',Yn=142606336,Zn='__noinit__',$n='__java$exception',_n={3:1,12:1,5:1,4:1},ao='null',bo=17592186044416,co={43:1},eo='delete',fo='button',go='selected',ho=1478623232,io={11:1,23:1},jo={15:1},ko='input',lo='todo',mo='completed',no='header',oo=136314880,po='active';var _,Qg,Lg,Dg=-1;Rg();Tg(1,null,{},o);_.v=ro;_.w=function(){return this.yb};_.A=so;_.B=function(){var a;return gh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.v(a)};_.hashCode=function(){return this.A()};_.toString=function(){return this.B()};var dd,ed,fd;Tg(51,1,{},hh);_.N=function(a){var b;b=new hh;b.e=4;a>1?(b.c=mh(this,a-1)):(b.c=this);return b};_.O=function(){fh(this);return this.b};_.P=function(){return gh(this)};_.Q=function(){fh(this);return this.i};_.R=function(){return (this.e&4)!=0};_.S=function(){return (this.e&1)!=0};_.B=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(fh(this),this.k)};_.e=0;_.g=0;var eh=1;var fe=jh(1);var Yd=jh(51);Tg(74,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var qd=jh(74);var G;Tg(21,1,{21:1},O);_.b=0;_.c=false;_.d=0;var rd=jh(21);Tg(204,1,Qn);_.B=function(){var a;return gh(this.yb)+'@'+(a=r(this)>>>0,a.toString(16))};var td=jh(204);Tg(20,204,Qn,S);_.C=function(){Q(this)};_.D=qo;_.a=false;var sd=jh(20);Tg(16,204,{11:1,16:1},cb);_.C=function(){U(this)};_.D=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var vd=jh(16);Tg(113,1,Tn,db);_.F=function(){V(this.a)};var ud=jh(113);Tg(18,204,{11:1,18:1},ob,pb);_.C=function(){eb(this)};_.D=function(){return 1==(this.c&7)};_.c=0;var zd=jh(18);Tg(114,1,Wn,qb);_.F=function(){P(this.a)};var wd=jh(114);Tg(115,1,Tn,rb);_.F=function(){jb(this.a)};var xd=jh(115);Tg(116,1,{},sb);_.G=function(a){hb(this.a,a)};var yd=jh(116);Tg(118,1,{},xb);_.a=0;_.b=100;_.e=0;var Ad=jh(118);Tg(141,1,Qn,zb);_.C=function(){yb(this)};_.D=qo;_.a=false;var Bd=jh(141);Tg(132,1,{},Lb);_.B=function(){var a;return fh(Cd),Cd.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.a=0;var Ab;var Cd=jh(132);Tg(45,1,{45:1});_.e='';_.g='';_.i=true;_.j='';var Jd=jh(45);Tg(98,45,{11:1,45:1,23:1},_b);_.C=function(){if(this.d>=0){this.d=-2;u((H(),H(),G),new ac(this),Un,null)}};_.v=ro;_.I=yo;_.A=so;_.D=zo;_.B=function(){var a;return fh(Hd),Hd.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.d=0;var Hd=jh(98);Tg(99,1,Tn,ac);_.F=function(){Vb(this.a)};var Dd=jh(99);Tg(100,1,Tn,bc);_.F=function(){Ob(this.a,this.b)};var Ed=jh(100);Tg(101,1,Tn,cc);_.F=function(){Wb(this.a)};var Fd=jh(101);Tg(102,1,Tn,dc);_.F=function(){Rb(this.a)};var Gd=jh(102);Tg(75,1,{},ec);_.handleEvent=function(a){Pb(this.a,a)};var Id=jh(75);Tg(103,1,{});var Md=jh(103);Tg(76,1,{},ic);_.G=function(a){gc(this.a,a)};var Kd=jh(76);Tg(77,1,Tn,jc);_.F=function(){hc(this.a,this.b)};var Ld=jh(77);Tg(104,103,{});var Nd=jh(104);Tg(17,1,Qn,nc);_.C=function(){lc(this)};_.D=qo;_.a=false;var Od=jh(17);Tg(4,1,{3:1,4:1});_.J=function(a){return new Error(a)};_.K=Lo;_.L=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=gh(this.yb),c==null?a:a+': '+c);pc(this,rc(this.J(b)));Tc(this)};_.B=function(){return qc(this,this.K())};_.e=Zn;_.g=true;var je=jh(4);Tg(12,4,{3:1,12:1,4:1});var _d=jh(12);Tg(5,12,_n);var ge=jh(5);Tg(52,5,_n);var ce=jh(52);Tg(69,52,_n);var Sd=jh(69);Tg(39,69,{39:1,3:1,12:1,5:1,4:1},wc);_.K=function(){vc(this);return this.c};_.M=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Pd=jh(39);var Qd=jh(0);Tg(190,1,{});var Rd=jh(190);var yc=0,zc=0,Ac=-1;Tg(97,190,{},Oc);var Kc;var Td=jh(97);var Rc;Tg(201,1,{});var Vd=jh(201);Tg(70,201,{},Vc);var Ud=jh(70);var $g;Tg(67,1,{64:1});_.B=qo;var Wd=jh(67);dd={3:1,65:1,31:1};var Xd=jh(65);Tg(44,1,{3:1,44:1});var ee=jh(44);ed={3:1,31:1,44:1};var Zd=jh(200);Tg(35,1,{3:1,31:1,35:1});_.v=ro;_.A=so;_.B=function(){return this.a!=null?this.a:''+this.b};_.b=0;var $d=jh(35);Tg(9,5,_n,sh,th);var ae=jh(9);Tg(32,44,{3:1,31:1,32:1,44:1},uh);_.v=function(a){return jd(a,32)&&a.a==this.a};_.A=qo;_.B=function(){return ''+this.a};_.a=0;var be=jh(32);var wh;Tg(257,1,{});Tg(72,52,_n,zh);_.J=function(a){return new TypeError(a)};var de=jh(72);fd={3:1,64:1,31:1,2:1};var ie=jh(2);Tg(68,67,{64:1},Fh);var he=jh(68);Tg(261,1,{});Tg(54,5,_n,Gh);var ke=jh(54);Tg(202,1,{42:1});_.T=wo;_.X=function(){return new Ri(this,0)};_.Y=function(){return new _i(null,this.X())};_.V=function(a){throw Fg(new Gh('Add not supported on this collection'))};_.B=function(){var a,b,c;c=new Ti('[',']');for(b=this.U();b.$();){a=b._();Si(c,a===this?'(this Collection)':a==null?ao:Xg(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var le=jh(202);Tg(205,1,{188:1});_.v=function(a){var b,c,d;if(a===this){return true}if(!jd(a,40)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Uh((new Rh(d)).a);c.b;){b=Th(c);if(!Jh(this,b)){return false}}return true};_.A=function(){return ji(new Rh(this))};_.B=function(){var a,b,c;c=new Ti('{','}');for(b=new Uh((new Rh(this)).a);b.b;){a=Th(b);Si(c,Kh(this,a.bb())+'='+Kh(this,a.cb()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var we=jh(205);Tg(119,205,{188:1});var oe=jh(119);Tg(206,202,{42:1,212:1});_.X=function(){return new Ri(this,1)};_.v=function(a){var b;if(a===this){return true}if(!jd(a,26)){return false}b=a;if(Ph(b.a)!=this.W()){return false}return Hh(this,b)};_.A=function(){return ji(this)};var xe=jh(206);Tg(26,206,{26:1,42:1,212:1},Rh);_.U=function(){return new Uh(this.a)};_.W=uo;var ne=jh(26);Tg(27,1,{},Uh);_.Z=to;_._=function(){return Th(this)};_.$=vo;_.b=false;var me=jh(27);Tg(203,202,{42:1,210:1});_.X=function(){return new Ri(this,16)};_.ab=function(a,b){throw Fg(new Gh('Add not supported on this list'))};_.V=function(a){this.ab(this.W(),a);return true};_.v=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,14)){return false}f=a;if(this.W()!=f.a.length){return false}e=new ii(f);for(c=new ii(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.A=function(){return ki(this)};_.U=function(){return new Vh(this)};var qe=jh(203);Tg(95,1,{},Vh);_.Z=to;_.$=function(){return this.a<this.b.a.length};_._=function(){return ai(this.b,this.a++)};_.a=0;var pe=jh(95);Tg(47,202,{42:1},Wh);_.U=function(){var a;return a=new Uh((new Rh(this.a)).a),new Xh(a)};_.W=uo;var se=jh(47);Tg(56,1,{},Xh);_.Z=to;_.$=function(){return this.a.b};_._=function(){var a;return a=Th(this.a),a.cb()};var re=jh(56);Tg(120,1,co);_.v=function(a){var b;if(!jd(a,43)){return false}b=a;return li(this.a,b.bb())&&li(this.b,b.cb())};_.bb=qo;_.cb=vo;_.A=function(){return Mi(this.a)^Mi(this.b)};_.db=function(a){var b;b=this.b;this.b=a;return b};_.B=function(){return this.a+'='+this.b};var te=jh(120);Tg(121,120,co,Yh);var ue=jh(121);Tg(207,1,co);_.v=function(a){var b;if(!jd(a,43)){return false}b=a;return li(this.b.value[0],b.bb())&&li(Ii(this),b.cb())};_.A=function(){return Mi(this.b.value[0])^Mi(Ii(this))};_.B=function(){return this.b.value[0]+'='+Ii(this)};var ve=jh(207);Tg(14,203,{3:1,14:1,42:1,210:1},gi,hi);_.ab=function(a,b){oj(this.a,a,b)};_.V=function(a){return $h(this,a)};_.T=function(a){_h(this,a)};_.U=function(){return new ii(this)};_.W=function(){return this.a.length};var ze=jh(14);Tg(19,1,{},ii);_.Z=to;_.$=function(){return this.a<this.c.a.length};_._=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ye=jh(19);Tg(40,119,{3:1,40:1,188:1},mi);var Ae=jh(40);Tg(59,1,{},si);_.T=wo;_.U=function(){return new ti(this)};_.b=0;var Ce=jh(59);Tg(60,1,{},ti);_.Z=to;_._=function(){return this.d=this.a[this.c++],this.d};_.$=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Be=jh(60);var wi;Tg(57,1,{},Gi);_.T=wo;_.U=function(){return new Hi(this)};_.b=0;_.c=0;var Fe=jh(57);Tg(58,1,{},Hi);_.Z=to;_._=function(){return this.c=this.a,this.a=this.b.next(),new Ji(this.d,this.c,this.d.c)};_.$=function(){return !this.a.done};var De=jh(58);Tg(131,207,co,Ji);_.bb=function(){return this.b.value[0]};_.cb=function(){return Ii(this)};_.db=function(a){return Ei(this.a,this.b.value[0],a)};_.c=0;var Ee=jh(131);Tg(96,1,{});_.Z=function(a){Oi(this,a)};_.eb=function(){return this.d};_.fb=Eo;_.d=0;_.e=0;var He=jh(96);Tg(55,96,{});var Ge=jh(55);Tg(25,1,{},Ri);_.eb=qo;_.fb=function(){Qi(this);return this.c};_.Z=function(a){Qi(this);this.d.Z(a)};_.gb=function(a){Qi(this);if(this.d.$()){a.G(this.d._());return true}return false};_.a=0;_.c=0;var Ie=jh(25);Tg(53,1,{},Ti);_.B=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Je=jh(53);var Se=lh();Tg(122,1,{});_.c=false;var Te=jh(122);Tg(34,122,{},_i);var Re=jh(34);Tg(124,55,{},dj);_.gb=function(a){this.b=false;while(!this.b&&this.c.gb(new ej(this,a)));return this.b};_.b=false;var Le=jh(124);Tg(127,1,{},ej);_.G=function(a){cj(this.a,this.b,a)};var Ke=jh(127);Tg(123,55,{},gj);_.gb=function(a){return this.a.gb(new hj(a))};var Ne=jh(123);Tg(126,1,{},hj);_.G=function(a){fj(this.a,a)};var Me=jh(126);Tg(125,1,{},jj);_.G=function(a){ij(this,a)};var Oe=jh(125);Tg(128,1,{},kj);_.G=function(a){};var Pe=jh(128);Tg(129,1,{},mj);_.G=function(a){lj(this,a)};var Qe=jh(129);Tg(259,1,{});Tg(209,1,{});var Ue=jh(209);Tg(256,1,{});var tj=0;var vj,wj=0,xj;Tg(681,1,{});Tg(705,1,{});Tg(208,1,{});_.ib=Go;var Ve=jh(208);Tg(33,$wnd.React.Component,{});Sg(Qg[1],_);_.render=function(){return Ij(this.a)};var We=jh(33);Tg(37,208,{});_.mb=function(){return false};_.nb=function(a,b){};_.pb=function(a){return false};_.qb=function(){return Kj(this)};_.s=false;_.t=false;var Fj=1;var Xe=jh(37);Tg(10,35,{3:1,31:1,35:1,10:1},uk);var Zj,$j,_j,ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk;var Ye=kh(10,vk);Tg(154,37,{});_.vb=xo;_.jb=function(){var a;a=R((zm(),ym).b);return $wnd.React.createElement('footer',Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,['footer'])),Sl(new Tl),$wnd.React.createElement('ul',Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Nj(Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,[(En(),Cn)==a?go:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Nj(Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,[Bn==a?go:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Nj(Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,[Dn==a?go:null])),'#completed'),'Completed'))),this.vb()?$wnd.React.createElement(fo,Oj(Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,['clear-completed'])),this.e),'Clear Completed'):null)};var If=jh(154);Tg(155,154,{});_.vb=xo;var wk;var Mf=jh(155);Tg(156,155,io,zk);_.C=function(){if(this.d>=0){this.d=-2;u((H(),H(),G),new Dk(this),Un,null)}};_.v=ro;_.ob=Ao;_.I=yo;_.vb=function(){return R(this.a)};_.A=so;_.D=zo;_.B=function(){var a;return fh(ff),ff.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((H(),H(),G),this.b,new Bk(this))}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){b=a;throw Fg(b)}else if(jd(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.d=0;var ff=jh(156);Tg(157,1,jo,Ak);_.H=function(){return dh(),R((zm(),wm).b).a>0?true:false};var Ze=jh(157);Tg(160,1,jo,Bk);_.H=Co;var $e=jh(160);Tg(158,1,Wn,Ck);_.F=Bo;var _e=jh(158);Tg(159,1,Tn,Dk);_.F=function(){yk(this.a)};var af=jh(159);Tg(181,37,{});_.jb=function(){var a,b;b=R((zm(),wm).e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,['todo-count'])),$wnd.React.createElement('strong',null,''+b),' '+a+' left')};var Hf=jh(181);Tg(182,181,{});var Ek;var Lf=jh(182);Tg(183,182,io,Hk);_.C=function(){if(this.c>=0){this.c=-2;u((H(),H(),G),new Jk(this),Un,null)}};_.v=ro;_.ob=Ao;_.I=vo;_.A=so;_.D=Fo;_.B=function(){var a;return fh(ef),ef.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((H(),H(),G),this.a,new Kk(this))}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){b=a;throw Fg(b)}else if(jd(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.c=0;var ef=jh(183);Tg(184,1,Wn,Ik);_.F=Bo;var bf=jh(184);Tg(185,1,Tn,Jk);_.F=function(){Gk(this.a)};var cf=jh(185);Tg(186,1,jo,Kk);_.H=Co;var df=jh(186);Tg(146,37,{});_.jb=function(){return $wnd.React.createElement(ko,Pj(Tj(Uj(Xj(Vj(Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,['new-todo']))),($(this.b),this.g)),this.f),this.e)))};_.g='';var Uf=jh(146);Tg(147,146,{});var Ok;var Of=jh(147);Tg(148,147,io,Uk);_.C=function(){if(this.d>=0){this.d=-2;u((H(),H(),G),new Zk(this),Un,null)}};_.v=ro;_.ob=Ao;_.I=yo;_.A=so;_.D=zo;_.B=function(){var a;return fh(mf),mf.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((H(),H(),G),this.a,new Vk(this))}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){b=a;throw Fg(b)}else if(jd(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.d=0;var mf=jh(148);Tg(151,1,jo,Vk);_.H=Co;var gf=jh(151);Tg(152,1,Tn,Wk);_.F=function(){Lk(this.a)};var hf=jh(152);Tg(153,1,Tn,Xk);_.F=function(){Mk(this.a,this.b)};var jf=jh(153);Tg(149,1,Wn,Yk);_.F=Bo;var kf=jh(149);Tg(150,1,Tn,Zk);_.F=function(){Sk(this.a)};var lf=jh(150);Tg(163,37,{});_.nb=function(a,b){$k(this)};_.xb=Do;_.ib=function(){tl(this)};_.jb=function(){var a,b;b=this.wb();a=($(b.a),b.g);return $wnd.React.createElement('li',Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,[a?mo:null,this.xb()?'editing':null])),$wnd.React.createElement('div',Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,['view'])),$wnd.React.createElement(ko,Tj(Qj(Wj(Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,['toggle'])),(tk(),$j)),a),this.o)),$wnd.React.createElement('label',Yj(new $wnd.Object,this.k),($(b.b),b.i)),$wnd.React.createElement(fo,Oj(Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,['destroy'])),this.j))),$wnd.React.createElement(ko,Uj(Tj(Sj(Rj(Lj(Mj(new $wnd.Object,Vg(om.prototype.G,om,[this])),ad(Wc(ie,1),Pn,2,6,['edit'])),($(this.a),this.q)),this.n),this.g),this.i)))};_.r=false;var Wf=jh(163);Tg(164,163,{});_.mb=function(){var a;a=(ab(this.c),this.u.props[lo]);if(!!a&&a.f<0){return true}return false};_.wb=function(){return this.u.props[lo]};_.xb=Do;_.pb=function(a){return hl(this,a)};var fl;var Qf=jh(164);Tg(165,164,io,vl);_.nb=function(b,c){var d;try{u((H(),H(),G),new yl(this,b,c),Yn,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){d=a;throw Fg(d)}else if(jd(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}};_.C=function(){if(this.f>=0){this.f=-2;u((H(),H(),G),new wl(this),Un,null)}};_.v=ro;_.ob=Ao;_.I=Eo;_.wb=function(){return il(this)};_.A=so;_.D=Ko;_.xb=function(){return R(this.d)};_.pb=function(b){var c;try{return t((H(),H(),G),new zl(this,b),75497472,null)}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){c=a;throw Fg(c)}else if(jd(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}};_.B=function(){var a;return fh(Af),Af.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((H(),H(),G),this.b,new xl(this))}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){b=a;throw Fg(b)}else if(jd(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.f=0;var Af=jh(165);Tg(168,1,Tn,wl);_.F=function(){ll(this.a)};var nf=jh(168);Tg(169,1,jo,xl);_.H=Co;var of=jh(169);Tg(170,1,Tn,yl);_.F=function(){$k(this.a)};var pf=jh(170);Tg(171,1,jo,zl);_.H=function(){return ml(this.a,this.b)};var qf=jh(171);Tg(172,1,Tn,Al);_.F=function(){nl(this.a)};var rf=jh(172);Tg(173,1,Tn,Bl);_.F=function(){al(this.a,this.b)};var sf=jh(173);Tg(174,1,Tn,Cl);_.F=function(){el(this.a)};var tf=jh(174);Tg(166,1,jo,Dl);_.H=function(){return ol(this.a)};var uf=jh(166);Tg(175,1,Tn,El);_.F=function(){Jm(il(this.a))};var vf=jh(175);Tg(176,1,Tn,Fl);_.F=function(){dl(this.a)};var wf=jh(176);Tg(177,1,Tn,Gl);_.F=function(){cl(this.a)};var xf=jh(177);Tg(167,1,Wn,Hl);_.F=Bo;var yf=jh(167);Tg(178,1,Tn,Il);_.F=function(){_k(this.a,this.b)};var zf=jh(178);Tg(133,37,{});_.jb=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(no,Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,[no])),$wnd.React.createElement('h1',null,'todos'),mm(new nm)),R((zm(),wm).c)?null:$wnd.React.createElement('section',Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,[no])),$wnd.React.createElement(ko,Tj(Wj(Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,['toggle-all'])),(tk(),$j)),this.d)),$wnd.React.createElement.apply(null,['ul',Lj(new $wnd.Object,ad(Wc(ie,1),Pn,2,6,['todo-list']))].concat((a=$i(Zi(R(ym.c).Y()),(b=new gi,b)),fi(a,_c(a.a.length)))))),R(wm.c)?null:Ql(new Rl)))};var Yf=jh(133);Tg(134,133,{});var Jl;var Sf=jh(134);Tg(135,134,io,Ml);_.C=function(){if(this.c>=0){this.c=-2;u((H(),H(),G),new Ol(this),Un,null)}};_.v=ro;_.ob=Ao;_.I=vo;_.A=so;_.D=Fo;_.B=function(){var a;return fh(Ef),Ef.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((H(),H(),G),this.a,new Pl(this))}catch(a){a=Eg(a);if(jd(a,5)||jd(a,7)){b=a;throw Fg(b)}else if(jd(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.c=0;var Ef=jh(135);Tg(136,1,Wn,Nl);_.F=Bo;var Bf=jh(136);Tg(137,1,Tn,Ol);_.F=function(){Gk(this.a)};var Cf=jh(137);Tg(138,1,jo,Pl);_.H=Co;var Df=jh(138);Tg(140,1,{},Rl);var Ff=jh(140);Tg(161,1,{},Tl);var Gf=jh(161);Tg(232,$wnd.Function,{},Ul);_.kb=function(a){return new Vl(a)};Tg(143,33,{},Vl);_.lb=function(){return new zk};_.componentDidMount=Go;_.componentDidUpdate=Ho;_.componentWillUnmount=Io;_.shouldComponentUpdate=Jo;var Jf=jh(143);Tg(233,$wnd.Function,{},Wl);_.ub=function(a){cn((zm(),xm))};Tg(243,$wnd.Function,{},Xl);_.kb=function(a){return new Yl(a)};Tg(162,33,{},Yl);_.lb=function(){return new Hk};_.componentDidMount=Go;_.componentDidUpdate=Ho;_.componentWillUnmount=Io;_.shouldComponentUpdate=Jo;var Kf=jh(162);Tg(229,$wnd.Function,{},Zl);_.kb=function(a){return new $l(a)};Tg(142,33,{},$l);_.lb=function(){return new Uk};_.componentDidMount=Go;_.componentDidUpdate=Ho;_.componentWillUnmount=Io;_.shouldComponentUpdate=Jo;var Nf=jh(142);Tg(230,$wnd.Function,{},_l);_.tb=function(a){Nk(this.a,a)};Tg(231,$wnd.Function,{},am);_.sb=function(a){Rk(this.a,a)};Tg(234,$wnd.Function,{},bm);_.kb=function(a){return new cm(a)};Tg(145,33,{},cm);_.lb=function(){return new vl};_.componentDidMount=Go;_.componentDidUpdate=Ho;_.componentWillUnmount=Io;_.shouldComponentUpdate=Jo;var Pf=jh(145);Tg(235,$wnd.Function,{},dm);_.tb=function(a){kl(this.a,a)};Tg(236,$wnd.Function,{},em);_.rb=function(a){rl(this.a)};Tg(237,$wnd.Function,{},fm);_.sb=function(a){sl(this.a)};Tg(238,$wnd.Function,{},gm);_.ub=function(a){ql(this.a)};Tg(239,$wnd.Function,{},hm);_.ub=function(a){pl(this.a)};Tg(240,$wnd.Function,{},im);_.sb=function(a){jl(this.a,a)};Tg(227,$wnd.Function,{},jm);_.kb=function(a){return new km(a)};Tg(117,33,{},km);_.lb=function(){return new Ml};_.componentDidMount=Go;_.componentDidUpdate=Ho;_.componentWillUnmount=Io;_.shouldComponentUpdate=Jo;var Rf=jh(117);Tg(228,$wnd.Function,{},lm);_.sb=function(a){var b;b=a.target;gn((zm(),xm),b.checked)};Tg(139,1,{},nm);var Tf=jh(139);Tg(242,$wnd.Function,{},om);_.G=function(a){bl(this.a,a)};Tg(144,1,{},sm);var Vf=jh(144);Tg(63,1,{},um);var Xf=jh(63);var vm,wm,xm,ym;Tg(48,1,{48:1});_.g=false;var Ag=jh(48);Tg(49,48,{11:1,23:1,49:1,48:1},Km);_.C=function(){Bm(this)};_.v=function(a){return Cm(this,a)};_.I=yo;_.A=Eo;_.D=Ko;_.B=function(){var a;return fh(mg),mg.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var Am=0;var mg=jh(49);Tg(179,1,Tn,Lm);_.F=function(){Fm(this.a)};var Zf=jh(179);Tg(180,1,Tn,Mm);_.F=function(){Gm(this.a)};var $f=jh(180);Tg(46,104,{46:1});var vg=jh(46);Tg(105,46,{11:1,23:1,46:1},Um);_.C=function(){if(this.g>=0){this.g=-2;u((H(),H(),G),new Vm(this),Un,null)}};_.v=ro;_.I=Lo;_.A=so;_.D=Mo;_.B=function(){var a;return fh(gg),gg.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.g=0;var gg=jh(105);Tg(110,1,Tn,Vm);_.F=function(){Rm(this.a)};var _f=jh(110);Tg(111,1,Tn,Wm);_.F=function(){fc(this.a,this.b,true)};var ag=jh(111);Tg(106,1,jo,Xm);_.H=function(){return Sm(this.a)};var bg=jh(106);Tg(112,1,jo,Ym);_.H=function(){return Nm(this.a,this.c,this.b)};_.b=false;var cg=jh(112);Tg(107,1,jo,Zm);_.H=function(){return vh(Kg(Xi(Qm(this.a))))};var dg=jh(107);Tg(108,1,jo,$m);_.H=function(){return vh(Kg(Xi(Yi(Qm(this.a),new Hn))))};var eg=jh(108);Tg(109,1,jo,_m);_.H=function(){return Tm(this.a)};var fg=jh(109);Tg(82,1,{});var zg=jh(82);Tg(83,82,io,hn);_.C=function(){if(this.b>=0){this.b=-2;u((H(),H(),G),new ln(this),Un,null)}};_.v=ro;_.I=qo;_.A=so;_.D=function(){return this.b<0};_.B=function(){var a;return fh(lg),lg.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.b=0;var lg=jh(83);Tg(86,1,Tn,jn);_.F=function(){Im(this.b,this.a)};var hg=jh(86);Tg(87,1,Tn,kn);_.F=function(){dn(this.a)};var ig=jh(87);Tg(84,1,Tn,ln);_.F=function(){lc(this.a.a)};var jg=jh(84);Tg(85,1,Tn,mn);_.F=function(){en(this.a,this.b)};_.b=false;var kg=jh(85);Tg(88,1,{});var Cg=jh(88);Tg(89,88,io,vn);_.C=function(){if(this.g>=0){this.g=-2;u((H(),H(),G),new wn(this),Un,null)}};_.v=ro;_.I=Lo;_.A=so;_.D=Mo;_.B=function(){var a;return fh(sg),sg.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.g=0;var sg=jh(89);Tg(94,1,Tn,wn);_.F=function(){qn(this.a)};var ng=jh(94);Tg(90,1,jo,xn);_.H=function(){var a;return a=Ub(this.a.i),Bh(po,a)||Bh(mo,a)||Bh('',a)?Bh(po,a)?(En(),Bn):Bh(mo,a)?(En(),Dn):(En(),Cn):(En(),Cn)};var og=jh(90);Tg(91,1,jo,yn);_.H=function(){return rn(this.a)};var pg=jh(91);Tg(92,1,Wn,zn);_.F=function(){sn(this.a)};var qg=jh(92);Tg(93,1,Wn,An);_.F=function(){tn(this.a)};var rg=jh(93);Tg(36,35,{3:1,31:1,35:1,36:1},Fn);var Bn,Cn,Dn;var tg=kh(36,Gn);Tg(78,1,{},Hn);_.hb=function(a){return !Em(a)};var ug=jh(78);Tg(80,1,{},In);_.hb=function(a){return Em(a)};var wg=jh(80);Tg(81,1,{},Jn);_.G=function(a){Pm(this.a,a)};var xg=jh(81);Tg(79,1,{},Kn);_.G=function(a){bn(this.a,a)};_.a=false;var yg=jh(79);Tg(71,1,{},Ln);_.hb=function(a){return on(this.a,a)};var Bg=jh(71);var Mn=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=Og;Mg(Zg);Pg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();