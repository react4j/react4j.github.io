function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='2A257EFA10A969610BFCFA72AB6DAD91',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '2A257EFA10A969610BFCFA72AB6DAD91';function p(){}
function nh(){}
function jh(){}
function Wh(){}
function Fb(){}
function Qc(){}
function Xc(){}
function qj(){}
function Ej(){}
function Mj(){}
function Nj(){}
function lk(){}
function _k(){}
function il(){}
function vm(){}
function ym(){}
function Cm(){}
function Gm(){}
function Km(){}
function Om(){}
function Oo(){}
function Po(){}
function cn(){}
function dn(){}
function Dn(){}
function Vc(a){Uc()}
function uh(){uh=jh}
function xi(){oi(this)}
function xb(a){this.a=a}
function jb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function fc(a){this.a=a}
function oc(a){this.a=a}
function Kh(a){this.a=a}
function Vh(a){this.a=a}
function gi(a){this.a=a}
function li(a){this.a=a}
function mi(a){this.a=a}
function ki(a){this.b=a}
function zi(a){this.c=a}
function rj(a){this.a=a}
function Pj(a){this.a=a}
function hl(a){this.a=a}
function jl(a){this.a=a}
function kl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function Jl(a){this.a=a}
function dm(a){this.a=a}
function em(a){this.a=a}
function jm(a){this.a=a}
function lm(a){this.a=a}
function mm(a){this.a=a}
function sm(a){this.a=a}
function tm(a){this.a=a}
function um(a){this.a=a}
function Sm(a){this.a=a}
function Tm(a){this.a=a}
function Vm(a){this.a=a}
function Wm(a){this.a=a}
function Ym(a){this.a=a}
function Zm(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function Bn(a){this.a=a}
function Cn(a){this.a=a}
function Pn(a){this.a=a}
function Qn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function co(a){this.a=a}
function eo(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function ro(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Eo(a){this.a=a}
function Fo(a){this.a=a}
function Go(a){this.a=a}
function Ho(a){this.a=a}
function Qo(a){this.a=a}
function Ro(a){this.a=a}
function So(a){this.a=a}
function Lj(a,b){a.a=b}
function ek(a,b){a.key=b}
function dk(a,b){ck(a,b)}
function io(a,b){bm(b,a)}
function Y(a){!!a&&$(a)}
function jc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function xp(a){bj(this,a)}
function Cp(a){fj(this,a)}
function Ap(a){Oh(this,a)}
function Ep(){ic(this.c)}
function Gp(){ic(this.b)}
function Mp(){ic(this.f)}
function Li(){this.a=Ui()}
function Zi(){this.a=Ui()}
function Ip(){kb(this.a.a)}
function db(a){Yb((J(),a))}
function eb(a){Zb((J(),a))}
function hb(a){$b((J(),a))}
function ho(a,b){Tn(a.b,b)}
function mc(a,b){ci(a.e,b)}
function Oj(a,b){Dj(a.a,b)}
function C(a,b){Ob(a.f,b.f)}
function qb(a,b){a.b=ej(b)}
function Ib(a){a.a=-4&a.a|1}
function al(a){a.d=2;ic(a.c)}
function ll(a){a.c=2;ic(a.b)}
function Ql(a){a.f=2;ic(a.e)}
function qn(a){R(a.a);$(a.b)}
function Fn(a){$(a.b);$(a.a)}
function Vg(a){return a.e}
function Bp(){return this.e}
function vp(){return this.a}
function zp(){return this.b}
function wp(){return Wj(this)}
function Ll(a,b){return a.g=b}
function rc(a,b){a.e=b;qc(a,b)}
function zl(a){kb(a.a);$(a.b)}
function el(a){kb(a.b);R(a.a)}
function Lp(a){mc(this.c,a)}
function Op(a){mc(this.f,a)}
function th(a){uc.call(this,a)}
function Xh(a){uc.call(this,a)}
function Pl(a){Un((jn(),fn),a)}
function J(){J=jh;I=new F}
function wc(){wc=jh;vc=new p}
function Nc(){Nc=jh;Mc=new Qc}
function Qi(){Qi=jh;Pi=Si()}
function ri(a,b){return a.a[b]}
function Dp(a){return this===a}
function Yc(a,b){return Dh(a,b)}
function Tj(a,b){a.splice(b,1)}
function hc(a,b,c){bi(a.e,b,c)}
function Gn(a,b,c){hc(a.c,b,c)}
function kj(a,b,c){b.w(a.a[c])}
function K(a,b){O(a);L(a,ej(b))}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function xh(a){wh(a);return a.k}
function Ui(){Qi();return new Pi}
function Cj(a,b){a.T(b);return a}
function fj(a,b){while(a.eb(b));}
function Dj(a,b){Lj(a,Cj(a.a,b))}
function Ij(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function bh(){_g==null&&(_g=[])}
function Dc(){Dc=jh;!!(Uc(),Tc)}
function Ph(){pc(this);this.H()}
function yp(){return ei(this.a)}
function Fp(){return this.c.i<0}
function Hp(){return this.b.i<0}
function Np(){return this.f.i<0}
function Jp(a){return 1==this.a.d}
function Kp(a){return 1==this.a.c}
function ei(a){return a.a.b+a.b.b}
function ni(a,b){this.a=a;this.b=b}
function gc(a,b){this.a=a;this.b=b}
function Ih(a,b){this.a=a;this.b=b}
function Hj(a,b){this.a=a;this.b=b}
function Kj(a,b){this.a=a;this.b=b}
function mk(a,b){this.a=a;this.b=b}
function ok(a,b){a.ref=b;return a}
function pk(a,b){a.href=b;return a}
function T(a){mb(a.f);return V(a)}
function sn(a){fb(a.b);return a.e}
function Jn(a){fb(a.a);return a.d}
function wo(a){fb(a.d);return a.e}
function ab(a){J();Zb(a);a.e=-2}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function wm(){this.a=fk((Am(),zm))}
function xm(){this.a=fk((Em(),Dm))}
function Um(){this.a=fk((Im(),Hm))}
function fm(a,b){this.a=a;this.b=b}
function gm(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function im(a,b){this.a=a;this.b=b}
function km(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function $m(a,b){this.a=a;this.b=b}
function _m(a,b){this.a=a;this.b=b}
function Il(a,b){this.a=a;this.b=b}
function An(a,b){this.a=a;this.b=b}
function ao(a,b){this.a=a;this.b=b}
function po(a,b){this.a=a;this.b=b}
function qo(a,b){this.b=a;this.a=b}
function Mo(a,b){Ih.call(this,a,b)}
function Xk(a,b){Ih.call(this,a,b)}
function Rj(a,b,c){a.splice(b,0,c)}
function yk(a,b){a.value=b;return a}
function Th(a,b){a.a+=''+b;return a}
function Wi(a,b){return a.a.get(b)}
function o(a,b){return pd(a)===pd(b)}
function md(a){return typeof a===Vo}
function pd(a){return a==null?null:a}
function dj(a){return a!=null?s(a):0}
function ai(a){return !a?null:a.ab()}
function Ub(a){return !a.d?a:Ub(a.d)}
function Kn(a){bm(a,(fb(a.a),!a.d))}
function tn(a){rn(a,(fb(a.b),a.e))}
function Ul(a){kb(a.b);R(a.c);$(a.a)}
function Kc(a){$wnd.clearTimeout(a)}
function bn(){this.a=fk((Mm(),Lm))}
function en(){this.a=fk((Qm(),Pm))}
function ib(a){this.c=new xi;this.b=a}
function di(a){a.a=new Li;a.b=new Zi}
function oi(a){a.a=$c(je,Xo,1,0,5,1)}
function pb(a){J();ob(a);sb(a,2,true)}
function dc(a,b){b.A(a);kd(b,9)&&b.t()}
function ec(a,b){cc(a,b,false);eb(a.d)}
function Sj(a,b){Qj(b,0,a,0,b.length)}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function cd(a,b,c){return {l:a,m:b,h:c}}
function Qh(a,b){return a.charCodeAt(b)}
function Wj(a){return a.$H||(a.$H=++Vj)}
function $j(){$j=jh;Xj=new p;Zj=new p}
function sk(a,b){a.checked=b;return a}
function tk(a,b){a.onBlur=b;return a}
function qk(a,b){a.onClick=b;return a}
function uk(a,b){a.onChange=b;return a}
function vk(a,b){a.onKeyDown=b;return a}
function rk(a){a.autoFocus=true;return a}
function wh(a){if(a.k!=null){return}Fh(a)}
function Db(a){this.d=ej(a);this.b=100}
function Fi(){this.a=new Li;this.b=new Zi}
function uc(a){this.g=a;pc(this);this.H()}
function Bj(a,b){uj.call(this,a);this.a=b}
function ck(a,b){for(var c in a){b(c)}}
function kd(a,b){return a!=null&&hd(a,b)}
function Ni(a,b){var c;c=a[ip];c.call(a,b)}
function vo(a){var b;b=a.e;!!b&&mc(b.c,a)}
function fb(a){var b;Vb((J(),b=Qb,b),a)}
function Nn(a){A((J(),J(),I),new Qn(a),np)}
function un(a){A((J(),J(),I),new Bn(a),np)}
function $l(a){A((J(),J(),I),new lm(a),np)}
function jo(a){A((J(),J(),I),new ro(a),np)}
function uo(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function P(){this.a=$c(je,Xo,1,100,5,1)}
function Nh(){Nh=jh;Mh=$c(fe,Xo,30,256,0,1)}
function Ah(a){var b;b=zh(a);Hh(a,b);return b}
function pc(a){a.j&&a.e!==dp&&a.H();return a}
function zk(a,b){a.onDoubleClick=b;return a}
function od(a){return typeof a==='string'}
function ld(a){return typeof a==='boolean'}
function Yn(a){return Lh(S(a.e).a-S(a.a).a)}
function Ec(a,b,c){return a.apply(b,c);var d}
function bj(a,b){while(a.Y()){Oj(b,a.Z())}}
function ij(a,b){while(a.c<a.d){kj(a,b,a.c++)}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function Nb(a,b,c){Ib(ej(c));K(a.a[b],ej(c))}
function aj(a,b,c){this.a=a;this.b=b;this.c=c}
function rh(a,b,c,d){a.addEventListener(b,c,d)}
function pi(a,b){a.a[a.a.length]=b;return true}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Al(a,b){A((J(),J(),I),new Il(a,b),np)}
function Vl(a,b){A((J(),J(),I),new km(a,b),np)}
function Yl(a,b){A((J(),J(),I),new hm(a,b),np)}
function Zl(a,b){A((J(),J(),I),new gm(a,b),np)}
function am(a,b){A((J(),J(),I),new fm(a,b),np)}
function Un(a,b){A((J(),J(),I),new ao(a,b),np)}
function mo(a,b){A((J(),J(),I),new qo(a,b),np)}
function no(a,b){A((J(),J(),I),new po(a,b),np)}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Bl(a,b){var c;c=b.target;Dl(a,c.value)}
function vj(a,b){var c;return zj(a,(c=new xi,c))}
function Uc(){Uc=jh;var a;!Wc();a=new Xc;Tc=a}
function F(){this.f=new Pb;this.a=new Db(this.f)}
function bo(a,b){this.a=a;this.c=b;this.b=false}
function mj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Fj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function sh(a,b,c,d){a.removeEventListener(b,c,d)}
function Vi(a,b){return !(a.a.get(b)===undefined)}
function so(a){return o(tp,a)||o(up,a)||o('',a)}
function ad(a){return Array.isArray(a)&&a.pb===nh}
function jd(a){return !Array.isArray(a)&&a.pb===nh}
function Bi(a){return new Bj(null,Ai(a,a.length))}
function Xn(a){return uh(),0==S(a.e).a?true:false}
function Ai(a,b){return gj(b,a.length),new lj(a,b)}
function fl(a){return B((J(),J(),I),a.b,new kl(a))}
function Sn(a){R(a.c);R(a.e);R(a.a);R(a.b);$(a.d)}
function Wn(a){Oh(new li(a.g),new fc(a));di(a.g)}
function ii(a){var b;b=a.a.Z();a.b=hi(a);return b}
function Ch(a){var b;b=zh(a);b.j=a;b.e=1;return b}
function ti(a,b){var c;c=a.a[b];Tj(a.a,b);return c}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function _l(a){return B((J(),J(),I),a.b,new em(a))}
function ol(a){return B((J(),J(),I),a.a,new sl(a))}
function Cl(a){return B((J(),J(),I),a.a,new Gl(a))}
function qm(a){return B((J(),J(),I),a.a,new um(a))}
function fi(a,b){if(b){return $h(a.a,b)}return false}
function ej(a){if(a==null){throw Vg(new Ph)}return a}
function bk(){if(Yj==256){Xj=Zj;Zj=new p;Yj=0}++Yj}
function bl(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function ml(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function Rl(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function sj(a){if(!a.b){tj(a);a.c=true}else{sj(a.b)}}
function xj(a,b){tj(a);return new Bj(a,new Gj(b,a.a))}
function yj(a,b){tj(a);return new Bj(a,new Jj(b,a.a))}
function rn(a,b){A((J(),J(),I),new An(a,b),75497472)}
function Dl(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function bm(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function vi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function xk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function hj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function lj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function nj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function uj(a){if(!a){this.b=null;new xi}else{this.b=a}}
function $g(a){if(md(a)){return a|0}return a.l|a.m<<22}
function ko(a,b){vj(Vn(a.b),new rj(new qj)).Q(new Ro(b))}
function jn(){jn=jh;fn=new Zn;gn=new oo(fn);hn=new Ao(fn)}
function qh(){qh=jh;ph=$wnd.goog.global.document}
function pn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&vn(a,b)}
function vn(a,b){var c;c=a.e;if(b!=c){a.e=ej(b);eb(a.b)}}
function Bh(a,b){var c;c=zh(a);Hh(a,c);c.e=b?8:0;return c}
function sc(a,b){var c;c=xh(a.nb);return b==null?c:c+': '+b}
function Kl(a,b){var c;if(S(a.c)){c=b.target;bm(a,c.value)}}
function Oh(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function Ei(a,b){return pd(a)===pd(b)||a!=null&&q(a,b)}
function _h(a,b){return b===a?'(this Map)':b==null?fp:mh(b)}
function No(){Lo();return bd(Yc(Jg,1),Xo,32,0,[Io,Ko,Jo])}
function Eh(a){if(a.P()){return null}var b=a.j;return fh[b]}
function Rb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function gb(a){var b;J();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&ap)&&D((null,I))}
function tj(a){if(a.b){tj(a.b)}else if(a.c){throw Vg(new Jh)}}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function lh(a){function b(){}
;b.prototype=a||{};return new b}
function wk(a){a.placeholder='What needs to be done?';return a}
function Hi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Dh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function hh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Wl(a,b){zo((jn(),hn),b);A((J(),J(),I),new fm(a,b),np)}
function nn(a,b){b.preventDefault();A((J(),J(),I),new Cn(a),np)}
function Vn(a){fb(a.d);return new Bj(null,new nj(new li(a.g),0))}
function Ii(a,b){var c;return Gi(b,Hi(a,b==null?0:(c=s(b),c|0)))}
function yi(a){oi(this);Sj(this.a,Zh(a,$c(je,Xo,1,ei(a.a),5,1)))}
function ln(a){rh((qh(),$wnd.goog.global.window),qp,a.d,false)}
function mn(a){sh((qh(),$wnd.goog.global.window),qp,a.d,false)}
function Am(){Am=jh;var a;zm=(a=kh(ym.prototype.mb,ym,[]),a)}
function Em(){Em=jh;var a;Dm=(a=kh(Cm.prototype.mb,Cm,[]),a)}
function Im(){Im=jh;var a;Hm=(a=kh(Gm.prototype.mb,Gm,[]),a)}
function Mm(){Mm=jh;var a;Lm=(a=kh(Km.prototype.mb,Km,[]),a)}
function Qm(){Qm=jh;var a;Pm=(a=kh(Om.prototype.mb,Om,[]),a)}
function lc(a){jc(a.g);!!a.e&&kc(a);Y(a.a);Y(a.c);jc(a.b);jc(a.f)}
function jj(a,b){if(a.c<a.d){kj(a,b,a.c++);return true}return false}
function Jj(a,b){hj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function Mi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Bm(a){$wnd.React.Component.call(this,a);this.a=new gl(this)}
function Fm(a){$wnd.React.Component.call(this,a);this.a=new pl(this)}
function Jm(a){$wnd.React.Component.call(this,a);this.a=new El(this)}
function Nm(a){$wnd.React.Component.call(this,a);this.a=new cm(this)}
function Rm(a){$wnd.React.Component.call(this,a);this.a=new rm(this)}
function lo(a){vj(xj(Vn(a.b),new Po),new rj(new qj)).Q(new Qo(a.b))}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function bb(a,b){var c,d;pi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Gj(a,b){hj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function $i(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function oo(a){this.b=ej(a);J();this.a=new nc(0,null,null,true,false)}
function Xl(a){return uh(),wo((jn(),hn))==a.j.props['a']?true:false}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function ci(a,b){return od(b)?b==null?Ki(a.a,null):Yi(a.b,b):Ki(a.a,b)}
function oj(a,b){!a.a?(a.a=new Vh(a.d)):Th(a.a,a.b);Th(a.a,b);return a}
function zj(a,b){var c;sj(a);c=new Mj;c.a=b;a.a.X(new Pj(c));return c.a}
function wj(a){var b;sj(a);b=0;while(a.a.eb(new Nj)){b=Wg(b,1)}return b}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function pj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function ji(a){this.d=a;this.c=new $i(this.d.b);this.a=this.c;this.b=hi(this)}
function Aj(a,b){var c;c=vj(a,new rj(new qj));return wi(c,b.fb(c.a.length))}
function Tn(a,b){var c;return u((J(),J(),I),new bo(a,b),np,(c=null,c))}
function to(a,b){return (Lo(),Jo)==a||(Io==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function Uj(a,b){return Zc(b)!=10&&bd(r(b),b.ob,b.__elementTypeId$,Zc(b),a),a}
function kn(a,b){a.f=b;o(b,S(a.a))&&vn(a,b);on(b);A((J(),J(),I),new Cn(a),np)}
function Jb(b){try{b.b.v()}catch(a){a=Ug(a);if(!kd(a,4))throw Vg(a)}}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function kk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function si(a,b,c){for(;c<a.a.length;++c){if(Ei(b,a.a[c])){return c}}return -1}
function _i(a){if(a.a.c!=a.c){return Wi(a.a,a.b.value[0])}return a.b.value[1]}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function xo(a){var b;return b=S(a.b),vj(xj(Vn(a.i),new So(b)),new rj(new qj))}
function ic(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new oc(a)),67108864,null)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function V(a){if(a.b){if(kd(a.b,7)){throw Vg(a.b)}else{throw Vg(a.b)}}return a.n}
function Hn(a,b){var c;if(kd(b,47)){c=b;return a.c.d==c.c.d}else{return false}}
function ui(a,b){var c;c=si(a,b,0);if(c==-1){return false}Tj(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&bd(Yc(a,f),b,c,e,g);return g}
function qi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function tl(a){var b;b=Sh((fb(a.b),a.e));if(b.length>0){ho((jn(),gn),b);Dl(a,'')}}
function ul(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Hl(a),np)}}
function rb(b){if(b){try{b.v()}catch(a){a=Ug(a);if(kd(a,4)){J()}else throw Vg(a)}}}
function bc(){var a;try{Sb(Qb);J()}finally{a=Qb.d;!a&&((J(),J(),I).d=true);Qb=Qb.d}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new xi);pi(a.b,b)}}}
function Hh(a,b){var c;if(!a){return}b.j=a;var d=Eh(b);if(!d){fh[a]=[b];return}d.nb=b}
function zh(a){var b;b=new yh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function kh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function bi(a,b,c){return od(b)?b==null?Ji(a.a,null,c):Xi(a.b,b,c):Ji(a.a,b,c)}
function ik(a){var b;return gk($wnd.React.StrictMode,null,null,(b={},b[jp]=ej(a),b))}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nd(a){return a!=null&&(typeof a===Uo||typeof a==='function')&&!(a.pb===nh)}
function eh(a,b){typeof window===Uo&&typeof window['$gwt']===Uo&&(window['$gwt'][a]=b)}
function ah(){bh();var a=_g;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ob(a){var b,c;for(c=new zi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ci(a){var b,c,d;d=0;for(c=new ji(a.a);c.b;){b=ii(c);d=d+(b?s(b):0);d=d|0}return d}
function fk(a){var b;b=hk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function gk(a,b,c,d){var e;e=hk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=ej(d);return e}
function Yi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ni(a.a,b);--a.b}return c}
function Rn(a,b,c){var d;d=new On(b,c);Gn(d,a,new gc(a,d));bi(a.g,Lh(d.c.d),d);eb(a.d);return d}
function Yh(a,b){var c,d;for(d=new ji(b.a);d.b;){c=ii(d);if(!fi(a,c)){return false}}return true}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new xi);a.c=c.c}b.d=true;pi(a.c,ej(b))}
function Pb(){var a;this.a=$c(vd,Xo,45,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Jh(){uc.call(this,"Stream already terminated, can't be modified or used")}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:Zo)|(0==(c&6291456)?!a?ap:bp:0)|0|0|0)}
function Kb(a,b){this.b=ej(a);this.a=b|0|(0==(b&6291456)?bp:0)|(0!=(b&229376)?0:98304)}
function gj(a,b){if(0>a||a>b){throw Vg(new th('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function hi(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new Mi(a.d.a);return a.a.Y()}
function Ug(a){var b;if(kd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new yc(a);Vc(b)}return b}
function Xg(a){var b;b=a.h;if(b==0){return a.l+a.m*bp}if(b==1048575){return a.l+a.m*bp-gp}return a}
function Zg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=gp;d=1048575}c=qd(e/bp);b=qd(e-c*bp);return cd(b,c,d)}
function Gi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ei(a,c._())){return c}}return null}
function an(a,b){ek(a.a,(wh($f),$f.k+(''+(b?Lh(b.c.d):null))));ej(b);a.a.props['a']=b;return a.a}
function cc(a,b,c){var d;d=ci(a.g,b?Lh(b.c.d):null);if(null!=d){mc(b.c,a);c&&!!b&&ic(b.c);eb(a.d)}}
function zo(a,b){var c;c=a.e;if(!(b==c||!!b&&Hn(b,c))){!!c&&mc(c.c,a);a.e=b;!!b&&Gn(b,a,new Fo(a));eb(a.d)}}
function yo(a){var b;b=S(a.g.a);o(tp,b)||o(up,b)||o('',b)?rn(a.g,b):so(sn(a.g))?un(a.g):rn(a.g,'')}
function Lo(){Lo=jh;Io=new Mo('ACTIVE',0);Ko=new Mo('COMPLETED',1);Jo=new Mo('ALL',2)}
function oh(){jn();$wnd.ReactDOM.render(ik([(new en).a]),(qh(),ph).getElementById('app'),null)}
function yc(a){wc();pc(this);this.e=a;qc(this,a);this.g=a==null?fp:mh(a);this.a='';this.b=a;this.a=''}
function yh(){this.g=vh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Xi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function bd(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=nh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ml(a,b,c){27==c.which?A((J(),J(),I),new im(a,b),np):13==c.which&&A((J(),J(),I),new gm(a,b),np)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function $k(){if(!Zk){Zk=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(kh(_k.prototype.J,_k,[]))}}
function Yk(){Wk();return bd(Yc(df,1),Xo,6,0,[Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk])}
function r(a){return od(a)?me:md(a)?ae:ld(a)?$d:jd(a)?a.nb:ad(a)?a.nb:a.nb||Array.isArray(a)&&Yc(Sd,1)||Sd}
function s(a){return od(a)?ak(a):md(a)?qd(a):ld(a)?a?1231:1237:jd(a)?a.q():ad(a)?Wj(a):!!a&&!!a.hashCode?a.hashCode():Wj(a)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Zo)?Jb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function cb(a,b){var c,d;d=a.c;ui(d,b);!!a.b&&Zo!=(a.b.c&$o)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((J(),c=Qb,c),a))}
function dd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return cd(c&4194303,d&4194303,e&1048575)}
function Wg(a,b){var c;if(md(a)&&md(b)){c=a+b;if(-17592186044416<c&&c<gp){return c}}return Xg(dd(md(a)?Zg(a):a,md(b)?Zg(b):b))}
function Lh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Nh(),Mh)[b];!c&&(c=Mh[b]=new Kh(a));return c}return new Kh(a)}
function mh(a){var b;if(Array.isArray(a)&&a.pb===nh){return xh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function ak(a){$j();var b,c,d;c=':'+a;d=Zj[c];if(d!=null){return qd(d)}d=Xj[c];b=d==null?_j(a):qd(d);bk();Zj[c]=b;return b}
function Di(a){var b,c,d;d=1;for(c=new zi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=ti(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function Ol(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;am(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Nl(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){mo((jn(),b),c);zo(hn,null);bm(a,c)}else{Un((jn(),fn),b)}}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(Zo==(b&$o)?0:524288)|(0==(b&6291456)?Zo==(b&$o)?bp:ap:0)|0|268435456|0)}
function pl(a){var b;this.j=ej(a);J();b=++nl;this.b=new nc(b,null,new ql(this),false,false);this.a=new vb(null,ej(new rl(this)),mp)}
function rm(a){var b;this.j=ej(a);J();b=++pm;this.b=new nc(b,null,new sm(this),false,false);this.a=new vb(null,ej(new tm(this)),mp)}
function nc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Fi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Gh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function wi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Uj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a){var b,c,d;for(c=new zi(new yi(new gi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();kd(d,9)&&d.u()||b.ab().v()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new zi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new zi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new zi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function q(a,b){return od(a)?o(a,b):md(a)?pd(a)===pd(b):ld(a)?pd(a)===pd(b):jd(a)?a.o(b):ad(a)?o(a,b):!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function hd(a,b){if(od(a)){return !!gd[b]}else if(a.ob){return !!a.ob[b]}else if(md(a)){return !!fd[b]}else if(ld(a)){return !!ed[b]}return false}
function nk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Qb&&!!Qb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Sh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Zh(a,b){var c,d,e,f;f=ei(a.a);b.length<f&&(b=Uj(new Array(f),b));e=b;d=new ji(a.a);for(c=0;c<f;++c){e[c]=ii(d)}b.length>f&&(b[f]=null);return b}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.v(),null)}finally{bc()}return f}catch(a){a=Ug(a);if(kd(a,4)){e=a;throw Vg(e)}else throw Vg(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.s()}else{ac(b,e);try{g=c.s()}finally{bc()}}return g}catch(a){a=Ug(a);if(kd(a,4)){f=a;throw Vg(f)}else throw Vg(a)}finally{D(b)}}
function Bb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Hb(c);return true}
function dh(b,c,d,e){bh();var f=_g;$moduleName=c;$moduleBase=d;Tg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{To(g)()}catch(a){b(c,a)}}else{To(g)()}}
function El(a){var b,c,d;this.j=ej(a);J();b=++yl;this.c=new nc(b,null,new Fl(this),false,false);this.b=(d=new ib((c=null,c)),d);this.a=new vb(null,ej(new Jl(this)),mp)}
function gl(a){var b;this.j=ej(a);J();b=++dl;this.c=new nc(b,null,new hl(this),false,false);this.a=new W(new il,null,null,136478720);this.b=new vb(null,ej(new jl(this)),mp)}
function On(a,b){var c,d,e,f,g;this.e=ej(a);this.d=b;J();c=++En;this.c=new nc(c,null,new Pn(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function W(a,b,c,d){this.c=ej(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);Zo==(d&$o)&&lb(this.f)}
function hk(a,b){var c;c=new $wnd.Object;c.$$typeof=ej(a);c.type=ej(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Si(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ti()}}
function gh(){fh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Rc(c,g)):g[0].qb()}catch(a){a=Ug(a);if(kd(a,4)){d=a;Dc();Jc(kd(d,36)?d.I():d)}else throw Vg(a)}}return c}
function xl(a){var b;a.d=0;$k();b=jk(op,rk(uk(vk(yk(wk(nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,['new-todo']))),(fb(a.b),a.e)),kh(Sm.prototype.kb,Sm,[a])),kh(Tm.prototype.jb,Tm,[a]))),null);return b}
function xc(a){var b;if(a.c==null){b=pd(a.b)===pd(vc)?null:a.b;a.d=b==null?fp:nd(b)?b==null?null:b.name:od(b)?'String':xh(r(b));a.a=a.a+': '+(nd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(pd(e)===pd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=Ug(a);if(kd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw Vg(c)}else throw Vg(a)}}
function Qj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Ji(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Gi(b,e);if(f){return f.bb(c)}}e[e.length]=new ni(b,c);++a.b;return null}
function _j(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Qh(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Ug(a);if(kd(a,4)){J()}else throw Vg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=$c(je,Xo,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function ub(a,b,c,d){this.b=new xi;this.f=new Kb(new yb(this),d&6520832|262144|Zo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&ap)&&D((null,I)))}
function Ki(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ei(b,e._())){if(d.length==1){d.length=0;Ni(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function ih(a,b,c){var d=fh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=fh[b]),lh(h));_.ob=c;!b&&(_.pb=nh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Fh(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Gh('.',[c,Gh('$',d)]);a.b=Gh('.',[c,Gh('.',d)]);a.i=d[d.length-1]}
function cm(a){var b,c,d;this.j=ej(a);J();b=++Tl;this.e=new nc(b,null,new dm(this),false,false);this.a=(d=new ib((c=null,c)),d);this.c=new W(new jm(this),null,null,136478720);this.b=new vb(null,ej(new mm(this)),mp);am(this,this.j.props['a'])}
function on(a){var b;if(0==a.length){b=(qh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',ph.title,b)}else{(qh(),$wnd.goog.global.window).location.hash=a}}
function $h(a,b){var c,d,e;c=b._();e=b.ab();d=od(c)?c==null?ai(Ii(a.a,null)):Wi(a.b,c):ai(Ii(a.a,c));if(!(pd(e)===pd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(od(c)?c==null?!!Ii(a.a,null):Vi(a.b,c):!!Ii(a.a,c))){return false}return true}
function jk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;dk(b,kh(mk.prototype.hb,mk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[jp]=c[0],undefined):(d[jp]=c,undefined));return gk(a,e,f,d)}
function wn(){var a,b,c;this.d=new Ho(this);this.f=this.e=(c=(qh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new nc(0,null,new xn(this),true,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new Dn,new yn(this),new zn(this),35651584)}
function Zn(){var a;this.g=new Fi;J();this.f=new nc(0,new _n(this),new $n(this),true,false);this.d=(a=new ib(null),a);this.c=new W(new co(this),null,null,sp);this.e=new W(new eo(this),null,null,sp);this.a=new W(new fo(this),null,null,sp);this.b=new W(new go(this),null,null,sp)}
function Ao(a){var b,c;this.i=ej(a);this.g=new wn;J();this.f=new nc(0,new Bo(this),new Co(this),true,false);this.d=(c=new ib((b=null,b)),c);this.b=new W(new Go(this),null,null,sp);this.c=new W(new Do(this),null,null,sp);this.a=new vb(ej(new Eo(this)),null,681574400);D((null,I))}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new zi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Ug(a);if(!kd(a,4))throw Vg(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function qc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.F();return a&&a.C()}},suppressed:{get:function(){return c.D()}}})}catch(a){}}}
function Ri(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}qi(a.b,new Ab(a));a.b.a=$c(je,Xo,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Wk(){Wk=jh;Ak=new Xk(kp,0);Bk=new Xk('checkbox',1);Ck=new Xk('color',2);Dk=new Xk('date',3);Ek=new Xk('datetime',4);Fk=new Xk('email',5);Gk=new Xk('file',6);Hk=new Xk('hidden',7);Ik=new Xk('image',8);Jk=new Xk('month',9);Kk=new Xk(Vo,10);Lk=new Xk('password',11);Mk=new Xk('radio',12);Nk=new Xk('range',13);Ok=new Xk('reset',14);Pk=new Xk('search',15);Qk=new Xk('submit',16);Rk=new Xk('tel',17);Sk=new Xk('text',18);Tk=new Xk('time',19);Uk=new Xk('url',20);Vk=new Xk('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ri(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&vi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ri(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ti(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new xi)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Zo!=(k.b.c&$o)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function cl(a){var b,c;a.d=0;$k();c=(b=S((jn(),hn).b),jk('footer',nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,['footer'])),[(new xm).a,jk('ul',nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,['filters'])),[jk('li',null,[jk('a',pk(nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,[(Lo(),Jo)==b?lp:null])),'#'),['All'])]),jk('li',null,[jk('a',pk(nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,[Io==b?lp:null])),'#active'),['Active'])]),jk('li',null,[jk('a',pk(nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,[Ko==b?lp:null])),'#completed'),['Completed'])])]),S(a.a)?jk(kp,qk(nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,['clear-completed'])),kh(vm.prototype.lb,vm,[])),['Clear Completed']):null]));return c}
function Sl(a){var b,c,d,e;a.f=0;$k();b=a.j.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.j.props['a'],e=(fb(d.a),d.d),jk('li',nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,[e?'checked':null,S(a.c)?'editing':null])),[jk('div',nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,['view'])),[jk(op,uk(sk(xk(nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,['toggle'])),(Wk(),Bk)),e),kh(Wm.prototype.jb,Wm,[d])),null),jk('label',zk(new $wnd.Object,kh(Xm.prototype.lb,Xm,[a,d])),[(fb(d.b),d.e)]),jk(kp,qk(nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,['destroy'])),kh(Ym.prototype.lb,Ym,[d])),null)]),jk(op,vk(uk(tk(yk(nk(ok(new $wnd.Object,kh(Zm.prototype.w,Zm,[a])),bd(Yc(me,1),Xo,2,6,['edit'])),(fb(a.a),a.d)),kh($m.prototype.ib,$m,[a,d])),kh(Vm.prototype.jb,Vm,[a])),kh(_m.prototype.kb,_m,[a,d])),null)]));return c}
function Ti(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[ip]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ri()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[ip]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Uo='object',Vo='number',Wo={11:1},Xo={3:1},Yo={9:1},Zo=1048576,$o=1835008,_o={5:1},ap=2097152,bp=4194304,cp={25:1},dp='__noinit__',ep={3:1,10:1,7:1,4:1},fp='null',gp=17592186044416,hp={42:1},ip='delete',jp='children',kp='button',lp='selected',mp=1411518464,np=142606336,op='input',pp='header',qp='hashchange',rp={9:1,51:1},sp=136314880,tp='active',up='completed';var _,fh,_g,Tg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;gh();ih(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=wp;_.r=function(){var a;return xh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var ed,fd,gd;ih(53,1,{},yh);_.K=function(a){var b;b=new yh;b.e=4;a>1?(b.c=Dh(this,a-1)):(b.c=this);return b};_.L=function(){wh(this);return this.b};_.M=function(){return xh(this)};_.N=function(){wh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(wh(this),this.k)};_.e=0;_.g=0;var vh=1;var je=Ah(1);var _d=Ah(53);ih(84,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var ud=Ah(84);ih(37,1,Wo,G);_.s=function(){return this.a.v(),null};var sd=Ah(37);ih(85,1,{},H);var td=Ah(85);var I;ih(45,1,{45:1},P);_.b=0;_.c=false;_.d=0;var vd=Ah(45);ih(219,1,Yo);_.r=function(){var a;return xh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var yd=Ah(219);ih(19,219,Yo,W);_.t=function(){R(this)};_.u=vp;_.a=false;_.d=0;_.k=false;var xd=Ah(19);ih(120,1,Wo,X);_.s=function(){return T(this.a)};var wd=Ah(120);ih(16,219,{9:1,16:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Ad=Ah(16);ih(119,1,_o,jb);_.v=function(){ab(this.a)};var zd=Ah(119);ih(17,219,{9:1,17:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Fd=Ah(17);ih(121,1,cp,xb);_.v=function(){Q(this.a)};var Bd=Ah(121);ih(122,1,_o,yb);_.v=function(){mb(this.a)};var Cd=Ah(122);ih(123,1,_o,zb);_.v=function(){pb(this.a)};var Dd=Ah(123);ih(124,1,{},Ab);_.w=function(a){nb(this.a,a)};var Ed=Ah(124);ih(140,1,{},Db);_.a=0;_.b=0;_.c=0;var Gd=Ah(140);ih(164,1,Yo,Fb);_.t=function(){Eb(this)};_.u=vp;_.a=false;var Hd=Ah(164);ih(64,219,{9:1,64:1},Kb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Jd=Ah(64);ih(59,1,{59:1},Pb);var Id=Ah(59);ih(144,1,{},_b);_.r=function(){var a;return wh(Kd),Kd.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.a=0;var Qb;var Kd=Ah(144);ih(107,1,{});var Nd=Ah(107);ih(86,1,{},fc);_.w=function(a){dc(this.a,a)};var Ld=Ah(86);ih(87,1,_o,gc);_.v=function(){ec(this.a,this.b)};var Md=Ah(87);ih(108,107,{});var Od=Ah(108);ih(15,1,Yo,nc);_.t=function(){ic(this)};_.u=function(){return this.i<0};_.r=function(){var a;return wh(Qd),Qd.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Qd=Ah(15);ih(118,1,_o,oc);_.v=function(){lc(this.a)};var Pd=Ah(118);ih(4,1,{3:1,4:1});_.B=function(a){return new Error(a)};_.C=Bp;_.D=function(){return Aj(yj(Bi((this.i==null&&(this.i=$c(oe,Xo,4,0,0,1)),this.i)),new Wh),new Ej)};_.F=function(){return this.f};_.G=function(){return this.g};_.H=function(){rc(this,tc(this.B(sc(this,this.g))));Vc(this)};_.r=function(){return sc(this,this.G())};_.e=dp;_.j=true;var oe=Ah(4);ih(10,4,{3:1,10:1,4:1});var ce=Ah(10);ih(7,10,ep);var ke=Ah(7);ih(54,7,ep);var ge=Ah(54);ih(77,54,ep);var Ud=Ah(77);ih(36,77,{36:1,3:1,10:1,7:1,4:1},yc);_.G=function(){xc(this);return this.c};_.I=function(){return pd(this.b)===pd(vc)?null:this.b};var vc;var Rd=Ah(36);var Sd=Ah(0);ih(205,1,{});var Td=Ah(205);var Ac=0,Bc=0,Cc=-1;ih(106,205,{},Qc);var Mc;var Vd=Ah(106);var Tc;ih(216,1,{});var Xd=Ah(216);ih(78,216,{},Xc);var Wd=Ah(78);var ph;ih(75,1,{72:1});_.r=vp;var Yd=Ah(75);ih(80,7,ep);var ee=Ah(80);ih(163,80,ep,th);var Zd=Ah(163);ed={3:1,73:1,29:1};var $d=Ah(73);ih(43,1,{3:1,43:1});var ie=Ah(43);fd={3:1,29:1,43:1};var ae=Ah(215);ih(31,1,{3:1,29:1,31:1});_.o=Dp;_.q=wp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=Ah(31);ih(79,7,ep,Jh);var de=Ah(79);ih(30,43,{3:1,29:1,30:1,43:1},Kh);_.o=function(a){return kd(a,30)&&a.a==this.a};_.q=vp;_.r=function(){return ''+this.a};_.a=0;var fe=Ah(30);var Mh;ih(284,1,{});ih(82,54,ep,Ph);_.B=function(a){return new TypeError(a)};var he=Ah(82);gd={3:1,72:1,29:1,2:1};var me=Ah(2);ih(76,75,{72:1},Vh);var le=Ah(76);ih(288,1,{});ih(70,1,{},Wh);_.S=function(a){return a.e};var ne=Ah(70);ih(56,7,ep,Xh);var pe=Ah(56);ih(217,1,{41:1});_.Q=Ap;_.V=function(){return new nj(this,0)};_.W=function(){return new Bj(null,this.V())};_.T=function(a){throw Vg(new Xh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new pj('[',']');for(b=this.R();b.Y();){a=b.Z();oj(c,a===this?'(this Collection)':a==null?fp:mh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var qe=Ah(217);ih(220,1,{203:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!kd(a,38)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ji((new gi(d)).a);c.b;){b=ii(c);if(!$h(this,b)){return false}}return true};_.q=function(){return Ci(new gi(this))};_.r=function(){var a,b,c;c=new pj('{','}');for(b=new ji((new gi(this)).a);b.b;){a=ii(b);oj(c,_h(this,a._())+'='+_h(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Be=Ah(220);ih(125,220,{203:1});var te=Ah(125);ih(221,217,{41:1,231:1});_.V=function(){return new nj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!kd(a,21)){return false}b=a;if(ei(b.a)!=this.U()){return false}return Yh(this,b)};_.q=function(){return Ci(this)};var Ce=Ah(221);ih(21,221,{21:1,41:1,231:1},gi);_.R=function(){return new ji(this.a)};_.U=yp;var se=Ah(21);ih(22,1,{},ji);_.X=xp;_.Z=function(){return ii(this)};_.Y=zp;_.b=false;var re=Ah(22);ih(218,217,{41:1,228:1});_.V=function(){return new nj(this,16)};_.$=function(a,b){throw Vg(new Xh('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!kd(a,14)){return false}f=a;if(this.U()!=f.a.length){return false}e=new zi(f);for(c=new zi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(pd(b)===pd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Di(this)};_.R=function(){return new ki(this)};var ve=Ah(218);ih(105,1,{},ki);_.X=xp;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return ri(this.b,this.a++)};_.a=0;var ue=Ah(105);ih(57,217,{41:1},li);_.R=function(){var a;a=new ji((new gi(this.a)).a);return new mi(a)};_.U=yp;var xe=Ah(57);ih(128,1,{},mi);_.X=xp;_.Y=function(){return this.a.b};_.Z=function(){var a;a=ii(this.a);return a.ab()};var we=Ah(128);ih(126,1,hp);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Ei(this.a,b._())&&Ei(this.b,b.ab())};_._=vp;_.ab=zp;_.q=function(){return dj(this.a)^dj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ye=Ah(126);ih(127,126,hp,ni);var ze=Ah(127);ih(222,1,hp);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Ei(this.b.value[0],b._())&&Ei(_i(this),b.ab())};_.q=function(){return dj(this.b.value[0])^dj(_i(this))};_.r=function(){return this.b.value[0]+'='+_i(this)};var Ae=Ah(222);ih(14,218,{3:1,14:1,41:1,228:1},xi,yi);_.$=function(a,b){Rj(this.a,a,b)};_.T=function(a){return pi(this,a)};_.Q=function(a){qi(this,a)};_.R=function(){return new zi(this)};_.U=function(){return this.a.length};var Ee=Ah(14);ih(18,1,{},zi);_.X=xp;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var De=Ah(18);ih(38,125,{3:1,38:1,203:1},Fi);var Fe=Ah(38);ih(62,1,{},Li);_.Q=Ap;_.R=function(){return new Mi(this)};_.b=0;var He=Ah(62);ih(63,1,{},Mi);_.X=xp;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ge=Ah(63);var Pi;ih(60,1,{},Zi);_.Q=Ap;_.R=function(){return new $i(this)};_.b=0;_.c=0;var Ke=Ah(60);ih(61,1,{},$i);_.X=xp;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new aj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Ie=Ah(61);ih(143,222,hp,aj);_._=function(){return this.b.value[0]};_.ab=function(){return _i(this)};_.bb=function(a){return Xi(this.a,this.b.value[0],a)};_.c=0;var Je=Ah(143);ih(146,1,{});_.X=Cp;_.cb=function(){return this.d};_.db=Bp;_.d=0;_.e=0;var Oe=Ah(146);ih(65,146,{});var Le=Ah(65);ih(141,1,{});_.X=Cp;_.cb=zp;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Ne=Ah(141);ih(142,141,{},lj);_.X=function(a){ij(this,a)};_.eb=function(a){return jj(this,a)};var Me=Ah(142);ih(23,1,{},nj);_.cb=vp;_.db=function(){mj(this);return this.c};_.X=function(a){mj(this);this.d.X(a)};_.eb=function(a){mj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Pe=Ah(23);ih(55,1,{},pj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Qe=Ah(55);ih(35,1,{},qj);_.S=function(a){return a};var Re=Ah(35);ih(39,1,{},rj);var Se=Ah(39);ih(145,1,{});_.c=false;var af=Ah(145);ih(27,145,{250:1},Bj);var _e=Ah(27);ih(71,1,{},Ej);_.fb=function(a){return $c(je,Xo,1,a,5,1)};var Te=Ah(71);ih(148,65,{},Gj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Hj(this,a)));return this.b};_.b=false;var Ve=Ah(148);ih(151,1,{},Hj);_.w=function(a){Fj(this.a,this.b,a)};var Ue=Ah(151);ih(147,65,{},Jj);_.eb=function(a){return this.b.eb(new Kj(this,a))};var Xe=Ah(147);ih(150,1,{},Kj);_.w=function(a){Ij(this.a,this.b,a)};var We=Ah(150);ih(149,1,{},Mj);_.w=function(a){Lj(this,a)};var Ye=Ah(149);ih(152,1,{},Nj);_.w=function(a){};var Ze=Ah(152);ih(153,1,{},Pj);_.w=function(a){Oj(this,a)};var $e=Ah(153);ih(286,1,{});ih(283,1,{});var Vj=0;var Xj,Yj=0,Zj;ih(901,1,{});ih(923,1,{});ih(223,1,{});var bf=Ah(223);ih(160,1,{},lk);_.fb=function(a){return new Array(a)};var cf=Ah(160);ih(251,$wnd.Function,{},mk);_.hb=function(a){kk(this.a,this.b,a)};ih(6,31,{3:1,29:1,31:1,6:1},Xk);var Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk;var df=Bh(6,Yk);var Zk;ih(252,$wnd.Function,{},_k);_.J=function(a){return Eb(Zk),Zk=null,null};ih(226,223,{});var Mf=Ah(226);ih(177,226,{});_.d=0;var Qf=Ah(177);ih(178,177,Yo,gl);_.t=Ep;_.o=Dp;_.q=wp;_.u=Fp;_.r=function(){var a;return wh(nf),nf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};var dl=0;var nf=Ah(178);ih(179,1,_o,hl);_.v=function(){el(this.a)};var ef=Ah(179);ih(180,1,Wo,il);_.s=function(){return uh(),S((jn(),fn).b).a>0?true:false};var ff=Ah(180);ih(181,1,cp,jl);_.v=function(){bl(this.a)};var gf=Ah(181);ih(182,1,Wo,kl);_.s=function(){return cl(this.a)};var hf=Ah(182);ih(227,223,{});var Lf=Ah(227);ih(197,227,{});_.c=0;var Pf=Ah(197);ih(198,197,Yo,pl);_.t=Gp;_.o=Dp;_.q=wp;_.u=Hp;_.r=function(){var a;return wh(mf),mf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};var nl=0;var mf=Ah(198);ih(199,1,_o,ql);_.v=Ip;var jf=Ah(199);ih(200,1,cp,rl);_.v=function(){ml(this.a)};var kf=Ah(200);ih(201,1,Wo,sl);_.s=function(){var a,b;return this.a.c=0,$k(),a=S((jn(),fn).e).a,b='item'+(a==1?'':'s'),jk('span',nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,['todo-count'])),[jk('strong',null,[a]),' '+b+' left'])};var lf=Ah(201);ih(169,223,{});_.e='';var Yf=Ah(169);ih(170,169,{});_.d=0;var Sf=Ah(170);ih(171,170,Yo,El);_.t=Ep;_.o=Dp;_.q=wp;_.u=Fp;_.r=function(){var a;return wh(tf),tf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};var yl=0;var tf=Ah(171);ih(172,1,_o,Fl);_.v=function(){zl(this.a)};var of=Ah(172);ih(174,1,Wo,Gl);_.s=function(){return xl(this.a)};var pf=Ah(174);ih(175,1,_o,Hl);_.v=function(){tl(this.a)};var qf=Ah(175);ih(176,1,_o,Il);_.v=function(){Bl(this.a,this.b)};var rf=Ah(176);ih(173,1,cp,Jl);_.v=function(){bl(this.a)};var sf=Ah(173);ih(225,223,{});_.i=false;var $f=Ah(225);ih(184,225,{});_.f=0;var Uf=Ah(184);ih(185,184,Yo,cm);_.t=function(){ic(this.e)};_.o=Dp;_.q=wp;_.u=function(){return this.e.i<0};_.r=function(){var a;return wh(Ef),Ef.k+'@'+(a=Wj(this)>>>0,a.toString(16))};var Tl=0;var Ef=Ah(185);ih(186,1,_o,dm);_.v=function(){Ul(this.a)};var uf=Ah(186);ih(189,1,Wo,em);_.s=function(){return Sl(this.a)};var vf=Ah(189);ih(66,1,_o,fm);_.v=function(){bm(this.a,sn(this.b))};var wf=Ah(66);ih(67,1,_o,gm);_.v=function(){Nl(this.a,this.b)};var xf=Ah(67);ih(190,1,_o,hm);_.v=function(){Wl(this.a,this.b)};var yf=Ah(190);ih(191,1,_o,im);_.v=function(){am(this.a,this.b);zo((jn(),hn),null)};var zf=Ah(191);ih(187,1,Wo,jm);_.s=function(){return Xl(this.a)};var Af=Ah(187);ih(192,1,_o,km);_.v=function(){Kl(this.a,this.b)};var Bf=Ah(192);ih(193,1,_o,lm);_.v=function(){Ol(this.a)};var Cf=Ah(193);ih(188,1,cp,mm);_.v=function(){Rl(this.a)};var Df=Ah(188);ih(224,223,{});var bg=Ah(224);ih(155,224,{});_.c=0;var Wf=Ah(155);ih(156,155,Yo,rm);_.t=Gp;_.o=Dp;_.q=wp;_.u=Hp;_.r=function(){var a;return wh(If),If.k+'@'+(a=Wj(this)>>>0,a.toString(16))};var pm=0;var If=Ah(156);ih(157,1,_o,sm);_.v=Ip;var Ff=Ah(157);ih(158,1,cp,tm);_.v=function(){ml(this.a)};var Gf=Ah(158);ih(159,1,Wo,um);_.s=function(){return this.a.c=0,$k(),jk('div',null,[jk('div',null,[jk(pp,nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,[pp])),[jk('h1',null,['todos']),(new Um).a]),S((jn(),fn).c)?null:jk('section',nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,[pp])),[jk(op,uk(xk(nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,['toggle-all'])),(Wk(),Bk)),kh(cn.prototype.jb,cn,[])),null),jk('ul',nk(new $wnd.Object,bd(Yc(me,1),Xo,2,6,['todo-list'])),Aj(ej(yj(S(hn.c).W(),new dn)),new lk))]),S(fn.c)?null:(new wm).a])])};var Hf=Ah(159);ih(256,$wnd.Function,{},vm);_.lb=function(a){jo((jn(),gn))};ih(162,1,{},wm);var Jf=Ah(162);ih(183,1,{},xm);var Kf=Ah(183);ih(257,$wnd.Function,{},ym);_.mb=function(a){return new Bm(a)};var zm;ih(167,$wnd.React.Component,{},Bm);hh(fh[1],_);_.componentWillUnmount=function(){al(this.a)};_.render=function(){return fl(this.a)};_.shouldComponentUpdate=Jp;var Nf=Ah(167);ih(267,$wnd.Function,{},Cm);_.mb=function(a){return new Fm(a)};var Dm;ih(194,$wnd.React.Component,{},Fm);hh(fh[1],_);_.componentWillUnmount=function(){ll(this.a)};_.render=function(){return ol(this.a)};_.shouldComponentUpdate=Kp;var Of=Ah(194);ih(255,$wnd.Function,{},Gm);_.mb=function(a){return new Jm(a)};var Hm;ih(165,$wnd.React.Component,{},Jm);hh(fh[1],_);_.componentWillUnmount=function(){al(this.a)};_.render=function(){return Cl(this.a)};_.shouldComponentUpdate=Jp;var Rf=Ah(165);ih(266,$wnd.Function,{},Km);_.mb=function(a){return new Nm(a)};var Lm;ih(168,$wnd.React.Component,{},Nm);hh(fh[1],_);_.componentDidUpdate=function(a){$l(this.a)};_.componentWillUnmount=function(){Ql(this.a)};_.render=function(){return _l(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Tf=Ah(168);ih(249,$wnd.Function,{},Om);_.mb=function(a){return new Rm(a)};var Pm;ih(130,$wnd.React.Component,{},Rm);hh(fh[1],_);_.componentWillUnmount=function(){ll(this.a)};_.render=function(){return qm(this.a)};_.shouldComponentUpdate=Kp;var Vf=Ah(130);ih(253,$wnd.Function,{},Sm);_.kb=function(a){ul(this.a,a)};ih(254,$wnd.Function,{},Tm);_.jb=function(a){Al(this.a,a)};ih(161,1,{},Um);var Xf=Ah(161);ih(264,$wnd.Function,{},Vm);_.jb=function(a){Vl(this.a,a)};ih(258,$wnd.Function,{},Wm);_.jb=function(a){Nn(this.a)};ih(260,$wnd.Function,{},Xm);_.lb=function(a){Yl(this.a,this.b)};ih(261,$wnd.Function,{},Ym);_.lb=function(a){Pl(this.a)};ih(262,$wnd.Function,{},Zm);_.w=function(a){Ll(this.a,a)};ih(263,$wnd.Function,{},$m);_.ib=function(a){Zl(this.a,this.b)};ih(265,$wnd.Function,{},_m);_.kb=function(a){Ml(this.a,this.b,a)};ih(166,1,{},bn);var Zf=Ah(166);ih(248,$wnd.Function,{},cn);_.jb=function(a){var b;b=a.target;no((jn(),gn),b.checked)};ih(131,1,{},dn);_.S=function(a){return an(new bn,a)};var _f=Ah(131);ih(69,1,{},en);var ag=Ah(69);var fn,gn,hn;ih(132,1,{});var Ig=Ah(132);ih(133,132,rp,wn);_.t=Ep;_.o=Dp;_.q=wp;_.u=Fp;_.A=Lp;_.r=function(){var a;return wh(jg),jg.k+'@'+(a=Wj(this)>>>0,a.toString(16))};var jg=Ah(133);ih(134,1,_o,xn);_.v=function(){qn(this.a)};var cg=Ah(134);ih(136,1,cp,yn);_.v=function(){ln(this.a)};var dg=Ah(136);ih(137,1,cp,zn);_.v=function(){mn(this.a)};var eg=Ah(137);ih(138,1,_o,An);_.v=function(){kn(this.a,this.b)};var fg=Ah(138);ih(139,1,_o,Bn);_.v=function(){tn(this.a)};var gg=Ah(139);ih(58,1,_o,Cn);_.v=function(){pn(this.a)};var hg=Ah(58);ih(135,1,Wo,Dn);_.s=function(){var a;return a=(qh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var ig=Ah(135);ih(46,1,{46:1});_.d=false;var Qg=Ah(46);ih(47,46,{9:1,51:1,47:1,46:1},On);_.t=Ep;_.o=function(a){return Hn(this,a)};_.q=function(){return this.c.d};_.u=Fp;_.A=Lp;_.r=function(){var a;return wh(zg),zg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var En=0;var zg=Ah(47);ih(195,1,_o,Pn);_.v=function(){Fn(this.a)};var kg=Ah(195);ih(196,1,_o,Qn);_.v=function(){Kn(this.a)};var lg=Ah(196);ih(44,108,{44:1});var Lg=Ah(44);ih(109,44,{9:1,51:1,44:1},Zn);_.t=Mp;_.o=Dp;_.q=wp;_.u=Np;_.A=Op;_.r=function(){var a;return wh(ug),ug.k+'@'+(a=Wj(this)>>>0,a.toString(16))};var ug=Ah(109);ih(111,1,_o,$n);_.v=function(){Sn(this.a)};var mg=Ah(111);ih(110,1,_o,_n);_.v=function(){Wn(this.a)};var ng=Ah(110);ih(116,1,_o,ao);_.v=function(){cc(this.a,this.b,true)};var og=Ah(116);ih(117,1,Wo,bo);_.s=function(){return Rn(this.a,this.c,this.b)};_.b=false;var pg=Ah(117);ih(112,1,Wo,co);_.s=function(){return Xn(this.a)};var qg=Ah(112);ih(113,1,Wo,eo);_.s=function(){return Lh($g(wj(Vn(this.a))))};var rg=Ah(113);ih(114,1,Wo,fo);_.s=function(){return Lh($g(wj(xj(Vn(this.a),new Oo))))};var sg=Ah(114);ih(115,1,Wo,go);_.s=function(){return Yn(this.a)};var tg=Ah(115);ih(92,1,{});var Pg=Ah(92);ih(93,92,rp,oo);_.t=function(){ic(this.a)};_.o=Dp;_.q=wp;_.u=function(){return this.a.i<0};_.A=function(a){mc(this.a,a)};_.r=function(){var a;return wh(yg),yg.k+'@'+(a=Wj(this)>>>0,a.toString(16))};var yg=Ah(93);ih(94,1,_o,po);_.v=function(){ko(this.a,this.b)};_.b=false;var vg=Ah(94);ih(95,1,_o,qo);_.v=function(){vn(this.b,this.a)};var wg=Ah(95);ih(96,1,_o,ro);_.v=function(){lo(this.a)};var xg=Ah(96);ih(97,1,{});var Sg=Ah(97);ih(98,97,rp,Ao);_.t=Mp;_.o=Dp;_.q=wp;_.u=Np;_.A=Op;_.r=function(){var a;return wh(Gg),Gg.k+'@'+(a=Wj(this)>>>0,a.toString(16))};var Gg=Ah(98);ih(99,1,_o,Bo);_.v=function(){vo(this.a)};var Ag=Ah(99);ih(100,1,_o,Co);_.v=function(){uo(this.a)};var Bg=Ah(100);ih(102,1,Wo,Do);_.s=function(){return xo(this.a)};var Cg=Ah(102);ih(103,1,cp,Eo);_.v=function(){yo(this.a)};var Dg=Ah(103);ih(104,1,_o,Fo);_.v=function(){zo(this.a,null)};var Eg=Ah(104);ih(101,1,Wo,Go);_.s=function(){var a;return a=sn(this.a.g),o(tp,a)?(Lo(),Io):o(up,a)?(Lo(),Ko):(Lo(),Jo)};var Fg=Ah(101);ih(129,1,{},Ho);_.handleEvent=function(a){nn(this.a,a)};var Hg=Ah(129);ih(32,31,{3:1,29:1,31:1,32:1},Mo);var Io,Jo,Ko;var Jg=Bh(32,No);ih(88,1,{},Oo);_.gb=function(a){return !Jn(a)};var Kg=Ah(88);ih(90,1,{},Po);_.gb=function(a){return Jn(a)};var Mg=Ah(90);ih(91,1,{},Qo);_.w=function(a){Un(this.a,a)};var Ng=Ah(91);ih(89,1,{},Ro);_.w=function(a){io(this.a,a)};_.a=false;var Og=Ah(89);ih(81,1,{},So);_.gb=function(a){return to(this.a,a)};var Rg=Ah(81);var rd=Ch('D');var To=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=dh;ah(oh);eh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();