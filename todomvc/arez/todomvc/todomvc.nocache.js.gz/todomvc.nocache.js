function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='30F67840A869B1706B26BDDBD75895FB',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '30F67840A869B1706B26BDDBD75895FB';function p(){}
function nh(){}
function jh(){}
function Vh(){}
function Gb(){}
function Sc(){}
function Zc(){}
function oj(){}
function Cj(){}
function Kj(){}
function Lj(){}
function ik(){}
function Yk(){}
function fl(){}
function tm(){}
function wm(){}
function Am(){}
function Em(){}
function Im(){}
function Mm(){}
function an(){}
function bn(){}
function Cn(){}
function Ko(){}
function Lo(){}
function Xc(a){Wc()}
function uh(){uh=jh}
function wi(){ni(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function hc(a){this.a=a}
function qc(a){this.a=a}
function Kh(a){this.a=a}
function Uh(a){this.a=a}
function fi(a){this.a=a}
function ki(a){this.a=a}
function li(a){this.a=a}
function ji(a){this.b=a}
function yi(a){this.c=a}
function pj(a){this.a=a}
function Nj(a){this.a=a}
function el(a){this.a=a}
function gl(a){this.a=a}
function hl(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function pl(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function El(a){this.a=a}
function Fl(a){this.a=a}
function am(a){this.a=a}
function bm(a){this.a=a}
function cm(a){this.a=a}
function dm(a){this.a=a}
function hm(a){this.a=a}
function km(a){this.a=a}
function qm(a){this.a=a}
function rm(a){this.a=a}
function sm(a){this.a=a}
function Qm(a){this.a=a}
function Rm(a){this.a=a}
function Tm(a){this.a=a}
function Um(a){this.a=a}
function Wm(a){this.a=a}
function Xm(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function An(a){this.a=a}
function Bn(a){this.a=a}
function On(a){this.a=a}
function Pn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function co(a){this.a=a}
function eo(a){this.a=a}
function po(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Jj(a,b){a.a=b}
function rb(a,b){a.b=b}
function dk(a,b){a.key=b}
function bk(a,b){ak(a,b)}
function go(a,b){$l(b,a)}
function Z(a){!!a&&ab(a)}
function lc(a){!!a&&a.r()}
function w(a){--a.e;D(a)}
function pp(a){aj(this,a)}
function up(a){dj(this,a)}
function sp(a){Oh(this,a)}
function vp(){kc(this.c)}
function xp(){kc(this.b)}
function Cp(){kc(this.f)}
function Ki(){this.a=Ti()}
function Yi(){this.a=Ti()}
function zp(){lb(this.a.a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function oc(a,b){bi(a.e,b)}
function Mj(a,b){Bj(a.a,b)}
function fo(a,b){Sn(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function L(a,b){P(a);M(a,b)}
function il(a){a.d=2;kc(a.b)}
function Nl(a){a.g=2;kc(a.e)}
function Zk(a){a.e=2;kc(a.c)}
function bl(a){lb(a.b);S(a.a)}
function pn(a){S(a.a);ab(a.b)}
function Vg(a){return a.e}
function tp(){return this.e}
function np(){return this.a}
function rp(){return this.b}
function op(){return Uj(this)}
function Il(a,b){return a.j=b}
function qi(a,b){return a.a[b]}
function tc(a,b){a.e=b;sc(a,b)}
function Rj(a,b){a.splice(b,1)}
function jc(a,b,c){ai(a.e,b,c)}
function ij(a,b,c){b.v(a.a[c])}
function Fn(a,b,c){jc(a.c,b,c)}
function En(a){ab(a.b);ab(a.a)}
function wl(a){lb(a.a);ab(a.b)}
function Ml(a){Tn((hn(),en),a)}
function th(a){wc.call(this,a)}
function Wh(a){wc.call(this,a)}
function qp(){return di(this.a)}
function wp(){return this.c.i<0}
function yp(){return this.b.i<0}
function Dp(){return this.f.i<0}
function $c(a,b){return Dh(a,b)}
function xh(a){wh(a);return a.k}
function Ti(){Pi();return new Oi}
function K(){K=jh;J=new F}
function yc(){yc=jh;xc=new p}
function Pc(){Pc=jh;Oc=new Sc}
function Pi(){Pi=jh;Oi=Ri()}
function Fc(){Fc=jh;!!(Wc(),Vc)}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function bb(a){K();Zb(a);a.e=-2}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function U(a){nb(a.f);return W(a)}
function rn(a){gb(a.b);return a.e}
function In(a){gb(a.a);return a.d}
function to(a){gb(a.d);return a.e}
function Aj(a,b){a.Q(b);return a}
function lk(a,b){a.ref=b;return a}
function ic(a,b){this.a=a;this.b=b}
function Ih(a,b){this.a=a;this.b=b}
function mi(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function Fj(a,b){this.a=a;this.b=b}
function Ij(a,b){this.a=a;this.b=b}
function dj(a,b){while(a.bb(b));}
function Bj(a,b){Jj(a,Aj(a.a,b))}
function Gj(a,b,c){b.v(a.a.P(c))}
function v(a,b,c){t(a,new I(c),b)}
function Pj(a,b,c){a.splice(b,0,c)}
function Uk(a,b){Ih.call(this,a,b)}
function jk(a,b){this.a=a;this.b=b}
function Gl(a,b){this.a=a;this.b=b}
function em(a,b){this.a=a;this.b=b}
function fm(a,b){this.a=a;this.b=b}
function gm(a,b){this.a=a;this.b=b}
function im(a,b){this.a=a;this.b=b}
function jm(a,b){this.a=a;this.b=b}
function Vm(a,b){this.a=a;this.b=b}
function Ym(a,b){this.a=a;this.b=b}
function Zm(a,b){this.a=a;this.b=b}
function Ap(a){return 1==this.a.e}
function Bp(a){return 1==this.a.d}
function di(a){return a.a.b+a.b.b}
function Vi(a,b){return a.a.get(b)}
function zn(a,b){this.a=a;this.b=b}
function $n(a,b){this.a=a;this.b=b}
function no(a,b){this.a=a;this.b=b}
function oo(a,b){this.b=a;this.a=b}
function Io(a,b){Ih.call(this,a,b)}
function mk(a,b){a.href=b;return a}
function Sh(a,b){a.a+=''+b;return a}
function bh(){_g==null&&(_g=[])}
function um(){this.a=fk((ym(),xm))}
function vm(){this.a=fk((Cm(),Bm))}
function Sm(){this.a=fk((Gm(),Fm))}
function _m(){this.a=fk((Km(),Jm))}
function cn(){this.a=fk((Om(),Nm))}
function sn(a){qn(a,(gb(a.b),a.e))}
function Jn(a){$l(a,(gb(a.a),!a.d))}
function Ub(a){return !a.d?a:Ub(a.d)}
function _h(a){return !a?null:a.Z()}
function rd(a){return a==null?null:a}
function cj(a){return a!=null?s(a):0}
function od(a){return typeof a===Ro}
function o(a,b){return rd(a)===rd(b)}
function qk(a,b){a.onBlur=b;return a}
function vk(a,b){a.value=b;return a}
function nk(a,b){a.onClick=b;return a}
function pk(a,b){a.checked=b;return a}
function Mc(a){$wnd.clearTimeout(a)}
function jb(a){this.c=new wi;this.b=a}
function ci(a){a.a=new Ki;a.b=new Yi}
function ni(a){a.a=ad(ke,To,1,0,5,1)}
function qb(a){K();pb(a);tb(a,2,true)}
function Rl(a){lb(a.b);S(a.c);ab(a.a)}
function gc(a,b){cc(a,b,false);fb(a.c)}
function Qj(a,b){Oj(b,0,a,0,b.length)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function ed(a,b,c){return {l:a,m:b,h:c}}
function Ph(a,b){return a.charCodeAt(b)}
function md(a,b){return a!=null&&kd(a,b)}
function $(a){return !(md(a,9)&&a.u())}
function Uj(a){return a.$H||(a.$H=++Tj)}
function ok(a){return a.autoFocus=true,a}
function qd(a){return typeof a==='string'}
function sk(a,b){a.onKeyDown=b;return a}
function rk(a,b){a.onChange=b;return a}
function ck(a,b){a.props['a']=b;return a}
function ak(a,b){for(var c in a){b(c)}}
function io(a,b){pi(ec(a.b),new No(b))}
function fc(a,b){oc(b.c,a);md(b,9)&&b.t()}
function wc(a){this.g=a;rc(this);this.D()}
function zj(a,b){sj.call(this,a);this.a=b}
function aj(a,b){while(a.V()){Mj(b,a.W())}}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function Mi(a,b){var c;c=a[cp];c.call(a,b)}
function Mn(a){A((K(),K(),J),new Pn(a),gp)}
function tn(a){A((K(),K(),J),new An(a),gp)}
function Yl(a){A((K(),K(),J),new km(a),gp)}
function ho(a){A((K(),K(),J),new po(a),gp)}
function wh(a){if(a.k!=null){return}Fh(a)}
function wk(a,b){a.onDoubleClick=b;return a}
function rc(a){a.j&&a.e!==Zo&&a.D();return a}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function so(a){lb(a.a);S(a.b);S(a.c);ab(a.d)}
function Wn(a){return Lh(T(a.e).a-T(a.a).a)}
function nd(a){return typeof a==='boolean'}
function Gc(a,b,c){return a.apply(b,c);var d}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function rh(a,b,c,d){a.addEventListener(b,c,d)}
function _i(a,b,c){this.a=a;this.b=b;this.c=c}
function Ei(){this.a=new Ki;this.b=new Yi}
function Yj(){Yj=jh;Vj=new p;Xj=new p}
function Wc(){Wc=jh;var a;!Yc();a=new Zc;Vc=a}
function Nh(){Nh=jh;Mh=ad(he,To,28,256,0,1)}
function Q(){this.a=ad(ke,To,1,100,5,1)}
function gj(a,b){while(a.c<a.d){ij(a,b,a.c++)}}
function Db(a){while(true){if(!Cb(a)){break}}}
function Ah(a){var b;b=zh(a);Hh(a,b);return b}
function oi(a,b){a.a[a.a.length]=b;return true}
function zl(a,b){var c;c=b.target;Al(a,c.value)}
function yl(a,b){A((K(),K(),J),new Gl(a,b),gp)}
function Tl(a,b){A((K(),K(),J),new jm(a,b),gp)}
function Wl(a,b){A((K(),K(),J),new gm(a,b),gp)}
function Xl(a,b){A((K(),K(),J),new fm(a,b),gp)}
function Zl(a,b){A((K(),K(),J),new em(a,b),gp)}
function Tn(a,b){A((K(),K(),J),new $n(a,b),gp)}
function ko(a,b){A((K(),K(),J),new oo(a,b),gp)}
function lo(a,b){A((K(),K(),J),new no(a,b),gp)}
function Un(a){Oh(new ki(a.g),new hc(a));ci(a.g)}
function qo(a){return o(lp,a)||o(mp,a)||o('',a)}
function cd(a){return Array.isArray(a)&&a.mb===nh}
function kj(a){if(!a.d){a.d=a.b.O();a.c=a.b.R()}}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function _n(a,b){this.a=a;this.c=b;this.b=false}
function Dj(a,b,c){if(a.a.db(c)){a.b=true;b.v(c)}}
function sh(a,b,c,d){a.removeEventListener(b,c,d)}
function tj(a,b){var c;return xj(a,(c=new wi,c))}
function si(a,b){var c;c=a.a[b];Rj(a.a,b);return c}
function hi(a){var b;b=a.a.W();a.b=gi(a);return b}
function Ch(a){var b;b=zh(a);b.j=a;b.e=1;return b}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function zi(a,b){return ej(b,a.length),new jj(a,b)}
function Ui(a,b){return !(a.a.get(b)===undefined)}
function Ai(a){return new zj(null,zi(a,a.length))}
function cl(a){return B((K(),K(),J),a.b,new gl(a))}
function ll(a){return B((K(),K(),J),a.a,new pl(a))}
function xl(a){return B((K(),K(),J),a.a,new Dl(a))}
function Sl(a){return B((K(),K(),J),a.b,new cm(a))}
function om(a){return B((K(),K(),J),a.a,new sm(a))}
function Vn(a){return uh(),0!=T(a.e).a?true:false}
function ei(a,b){if(b){return Zh(a.a,b)}return false}
function ui(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function jl(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Pl(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function _k(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function qj(a){if(!a.b){rj(a);a.c=true}else{qj(a.b)}}
function Rn(a){S(a.d);S(a.e);S(a.a);S(a.b);ab(a.c)}
function un(a,b){var c;c=a.e;if(b!=c){a.e=b;fb(a.b)}}
function Al(a,b){var c;c=a.f;if(b!=c){a.f=b;fb(a.b)}}
function $l(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function vj(a,b){rj(a);return new zj(a,new Ej(b,a.a))}
function wj(a,b){rj(a);return new zj(a,new Hj(b,a.a))}
function qn(a,b){A((K(),K(),J),new zn(a,b),75497472)}
function Di(a,b){return rd(a)===rd(b)||a!=null&&q(a,b)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function ld(a){return !Array.isArray(a)&&a.mb===nh}
function Ul(a){return uh(),to((hn(),gn))==a.i?true:false}
function on(a){var b;V(a.a);b=T(a.a);o(a.f,b)&&un(a,b)}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Bh(a,b){var c;c=zh(a);Hh(a,c);c.e=b?8:0;return c}
function uk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function fj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function lj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function jj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function sj(a){if(!a){this.b=null;new wi}else{this.b=a}}
function Eh(a){if(a.M()){return null}var b=a.j;return fh[b]}
function $g(a){if(od(a)){return a|0}return a.l|a.m<<22}
function _j(){if(Wj==256){Vj=Xj;Xj=new p;Wj=0}++Wj}
function qh(){qh=jh;ph=$wnd.goog.global.document}
function Jo(){Ho();return dd($c(Jg,1),To,30,0,[Eo,Go,Fo])}
function $h(a,b){return b===a?'(this Map)':b==null?_o:mh(b)}
function uc(a,b){var c;c=xh(a.kb);return b==null?c:c+': '+b}
function Hl(a,b){var c;if(T(a.c)){c=b.target;$l(a,c.value)}}
function Oh(a,b){var c,d;for(d=a.O();d.V();){c=d.W();b.v(c)}}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function mb(a){C((K(),K(),J),a);0==(a.f.a&Xo)&&D((null,J))}
function rj(a){if(a.b){rj(a.b)}else if(a.c){throw Vg(new Jh)}}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function lh(a){function b(){}
;b.prototype=a||{};return new b}
function tk(a){a.placeholder='What needs to be done?';return a}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function ym(){ym=jh;var a;xm=(a=kh(wm.prototype.jb,wm,[]),a)}
function Cm(){Cm=jh;var a;Bm=(a=kh(Am.prototype.jb,Am,[]),a)}
function Gm(){Gm=jh;var a;Fm=(a=kh(Em.prototype.jb,Em,[]),a)}
function Km(){Km=jh;var a;Jm=(a=kh(Im.prototype.jb,Im,[]),a)}
function Om(){Om=jh;var a;Nm=(a=kh(Mm.prototype.jb,Mm,[]),a)}
function Dh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function Gi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Hi(a,b){var c;return Fi(b,Gi(a,b==null?0:(c=s(b),c|0)))}
function dc(a){gb(a.c);return new zj(null,new lj(new ki(a.g),0))}
function Vl(a,b){wo((hn(),gn),b);A((K(),K(),J),new em(a,b),gp)}
function mn(a,b){b.preventDefault();A((K(),K(),J),new Bn(a),gp)}
function Hj(a,b){fj.call(this,b.ab(),b._()&-6);this.a=a;this.b=b}
function Li(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function mo(a){this.b=a;K();this.a=new pc(0,null,null,false,false)}
function xi(a){ni(this);Qj(this.a,Yh(a,ad(ke,To,1,di(a.a),5,1)))}
function kn(a){rh((qh(),$wnd.goog.global.window),jp,a.d,false)}
function ln(a){sh((qh(),$wnd.goog.global.window),jp,a.d,false)}
function jo(a){tj(vj(dc(a.b),new Lo),new pj(new oj)).N(new Mo(a.b))}
function nc(a){lc(a.g);!!a.e&&mc(a);Z(a.a);Z(a.c);lc(a.b);lc(a.f)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function hj(a,b){if(a.c<a.d){ij(a,b,a.c++);return true}return false}
function hh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function hk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function cb(a,b){var c,d;oi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Ej(a,b){fj.call(this,b.ab(),b._()&-16449);this.a=a;this.c=b}
function zm(a){$wnd.React.Component.call(this,a);this.a=new dl(this)}
function Dm(a){$wnd.React.Component.call(this,a);this.a=new ml(this)}
function Hm(a){$wnd.React.Component.call(this,a);this.a=new Bl(this)}
function Lm(a){$wnd.React.Component.call(this,a);this.a=new _l(this)}
function Pm(a){$wnd.React.Component.call(this,a);this.a=new pm(this)}
function Zi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function mj(a,b){!a.a?(a.a=new Uh(a.d)):Sh(a.a,a.b);Sh(a.a,b);return a}
function xj(a,b){var c;qj(a);c=new Kj;c.a=b;a.a.U(new Nj(c));return c.a}
function uj(a){var b;qj(a);b=0;while(a.a.bb(new Lj)){b=Wg(b,1)}return b}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function hn(){hn=jh;en=new Xn;fn=new mo(en);dn=new vn;gn=new xo(en,dn)}
function Sn(a,b){var c;return u((K(),K(),J),new _n(a,b),gp,(c=null,c))}
function yj(a,b){var c;c=tj(a,new pj(new oj));return vi(c,b.cb(c.a.length))}
function ro(a,b){return (Ho(),Fo)==a||(Eo==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function bi(a,b){return qd(b)?b==null?Ji(a.a,null):Xi(a.b,b):Ji(a.a,b)}
function Sj(a,b){return _c(b)!=10&&dd(r(b),b.lb,b.__elementTypeId$,_c(b),a),a}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function Jb(b){try{nb(b.b.a)}catch(a){a=Ug(a);if(!md(a,4))throw Vg(a)}}
function jn(a,b){a.f=b;o(b,T(a.a))&&un(a,b);nn(b);A((K(),K(),J),new Bn(a),gp)}
function uo(a){var b;return b=T(a.b),tj(vj(dc(a.i),new Oo(b)),new pj(new oj))}
function ai(a,b,c){return qd(b)?b==null?Ii(a.a,null,c):Wi(a.b,b,c):Ii(a.a,b,c)}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function ti(a,b){var c;c=ri(a,b,0);if(c==-1){return false}Rj(a.a,c);return true}
function Gn(a,b){var c;if(md(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function $i(a){if(a.a.c!=a.c){return Vi(a.a,a.b.value[0])}return a.b.value[1]}
function ri(a,b,c){for(;c<a.a.length;++c){if(Di(b,a.a[c])){return c}}return -1}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function pi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function ql(a){var b;b=Rh((gb(a.b),a.f));if(b.length>0){fo((hn(),fn),b);Al(a,'')}}
function ab(a){if(-2!=a.e){u((K(),K(),J),new H(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function kc(a){if(a.i>=0){a.i=-2;u((K(),K(),J),new H(new qc(a)),67108864,null)}}
function S(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function W(a){if(a.b){if(md(a.b,8)){throw Vg(a.b)}else{throw Vg(a.b)}}return a.k}
function sb(b){if(b){try{b.r()}catch(a){a=Ug(a);if(md(a,4)){K()}else throw Vg(a)}}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function Qc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Uc(b,c)}while(a.a);a.a=c}}
function Rc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function Pb(){var a;this.a=ad(yd,To,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function ii(a){this.d=a;this.c=new Zi(this.d.b);this.a=this.c;this.b=gi(this)}
function nj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Yo:0)|(0!=(b&229376)?0:98304)}
function $m(a,b){dk(a.a,(b?Lh(b.c.d):null)+(''+(wh(_f),_f.k)));ck(a.a,b);return a.a}
function Hh(a,b){var c;if(!a){return}b.j=a;var d=Eh(b);if(!d){fh[a]=[b];return}d.kb=b}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new wi);oi(a.b,b)}}}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new wi);a.c=c.c}b.d=true;oi(a.c,b)}
function zh(a){var b;b=new yh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function kh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ah(){bh();var a=_g;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Jh(){wc.call(this,"Stream already terminated, can't be modified or used")}
function ec(a){return gb(a.c),tj(new zj(null,new lj(new ki(a.g),0)),new pj(new oj))}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function pd(a){return a!=null&&(typeof a===Qo||typeof a==='function')&&!(a.mb===nh)}
function eh(a,b){typeof window===Qo&&typeof window['$gwt']===Qo&&(window['$gwt'][a]=b)}
function rl(a,b){if(13==b.keyCode){b.preventDefault();A((K(),K(),J),new El(a),gp)}}
function oh(){hn();$wnd.ReactDOM.render((new cn).a,(qh(),ph).getElementById('app'),null)}
function fk(a){var b;b=ek($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Bi(a){var b,c,d;d=0;for(c=new ii(a.a);c.b;){b=hi(c);d=d+(b?s(b):0);d=d|0}return d}
function Xh(a,b){var c,d;for(d=new ii(b.a);d.b;){c=hi(d);if(!ei(a,c)){return false}}return true}
function Xi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Mi(a.a,b);--a.b}return c}
function Qn(a,b,c){var d;d=new Nn(b,c);Fn(d,a,new ic(a,d));ai(a.g,Lh(d.c.d),d);fb(a.c);return d}
function cc(a,b,c){var d;d=bi(a.g,b?Lh(b.c.d):null);if(null!=d){oc(b.c,a);c&&!!b&&kc(b.c);fb(a.c)}}
function pb(a){var b,c;for(c=new yi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ug(a){var b;if(md(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function gi(a){if(a.a.V()){return true}if(a.a!=a.c){return false}a.a=new Li(a.d.a);return a.a.V()}
function Xg(a){var b;b=a.h;if(b==0){return a.l+a.m*Yo}if(b==1048575){return a.l+a.m*Yo-ap}return a}
function Zg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=ap;d=1048575}c=sd(e/Yo);b=sd(e-c*Yo);return ed(b,c,d)}
function Fi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Di(a,c.Y())){return c}}return null}
function dd(a,b,c,d,e){e.kb=a;e.lb=b;e.mb=nh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Wi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function wo(a,b){var c;c=a.e;if(!(b==c||!!b&&Gn(b,c))){!!c&&oc(c.c,a);a.e=b;!!b&&Fn(b,a,new zo(a));fb(a.d)}}
function vo(a){var b;b=T(a.g.a);o(lp,b)||o(mp,b)||o('',b)?qn(a.g,b):qo(rn(a.g))?tn(a.g):qn(a.g,'')}
function Ll(a){var b;b=T(a.c);if(!a.k&&b){a.k=true;Zl(a,a.i);a.j.focus();a.j.select()}else a.k&&!b&&(a.k=false)}
function r(a){return qd(a)?ne:od(a)?ce:nd(a)?ae:ld(a)?a.kb:cd(a)?a.kb:a.kb||Array.isArray(a)&&$c(Ud,1)||Ud}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function Jl(a,b,c){27==c.which?A((K(),K(),J),new im(a,b),gp):13==c.which&&A((K(),K(),J),new fm(a,b),gp)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:Vo)|(0==(c&6291456)?!a?Xo:Yo:0)|0|0|0)}
function Ho(){Ho=jh;Eo=new Io('ACTIVE',0);Go=new Io('COMPLETED',1);Fo=new Io('ALL',2)}
function ej(a,b){if(0>a||a>b){throw Vg(new th('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Ac(a){yc();rc(this);this.e=a;sc(this,a);this.g=a==null?_o:mh(a);this.a='';this.b=a;this.a=''}
function yh(){this.g=vh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Xk(){if(!Wk){Wk=(++(K(),K(),J).e,new Gb);$wnd.Promise.resolve(null).then(kh(Yk.prototype.G,Yk,[]))}}
function Vk(){Tk();return dd($c(df,1),To,6,0,[xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk])}
function db(a,b){var c,d;d=a.c;ti(d,b);!!a.b&&Vo!=(a.b.c&Wo)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function fd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ed(c&4194303,d&4194303,e&1048575)}
function Kl(a,b){var c;c=(gb(a.a),a.d);if(null!=c&&c.length!=0){ko((hn(),b),c);wo(gn,null);$l(a,c)}else{Tn((hn(),en),b)}}
function Wg(a,b){var c;if(od(a)&&od(b)){c=a+b;if(-17592186044416<c&&c<ap){return c}}return Xg(fd(od(a)?Zg(a):a,od(b)?Zg(b):b))}
function Lh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Nh(),Mh)[b];!c&&(c=Mh[b]=new Kh(a));return c}return new Kh(a)}
function mh(a){var b;if(Array.isArray(a)&&a.mb===nh){return xh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function $j(a){Yj();var b,c,d;c=':'+a;d=Xj[c];if(d!=null){return sd(d)}d=Vj[c];b=d==null?Zj(a):sd(d);_j();Xj[c]=b;return b}
function Ci(a){var b,c,d;d=1;for(c=new yi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=si(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function mc(a){var b,c,d;for(c=new yi(new xi(new fi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.Y();md(d,9)&&d.u()||b.Z().r()}}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Vo)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(Vo==(b&Wo)?0:524288)|(0==(b&6291456)?Vo==(b&Wo)?Yo:Xo:0)|0|268435456|0)}
function s(a){return qd(a)?$j(a):od(a)?sd(a):nd(a)?a?1231:1237:ld(a)?a.p():cd(a)?Uj(a):!!a&&!!a.hashCode?a.hashCode():Uj(a)}
function q(a,b){return qd(a)?o(a,b):od(a)?rd(a)===rd(b):nd(a)?rd(a)===rd(b):ld(a)?a.n(b):cd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function ml(a){var b;this.c=a;K();b=++kl;this.b=new pc(b,null,new nl(this),false,false);this.a=new wb(null,new ol(this),fp)}
function pm(a){var b;this.c=a;K();b=++nm;this.b=new pc(b,null,new qm(this),false,false);this.a=new wb(null,new rm(this),fp)}
function pc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ei:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new jb((f=null,K(),f)),g):null;this.c=null}
function Gh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function vi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Sj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Yh(a,b){var c,d,e,f;f=di(a.a);b.length<f&&(b=Sj(new Array(f),b));e=b;d=new ii(a.a);for(c=0;c<f;++c){e[c]=hi(d)}b.length>f&&(b[f]=null);return b}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kd(a,b){if(qd(a)){return !!jd[b]}else if(a.lb){return !!a.lb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function kk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function T(a){a.j?hb(a.e):gb(a.e);if(ub(a.f)){if(a.j&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new yi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new yi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new yi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Rh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.r(),null)}finally{bc()}return f}catch(a){a=Ug(a);if(md(a,4)){e=a;throw Vg(e)}else throw Vg(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.s()}else{ac(b,e);try{g=c.s()}finally{bc()}}return g}catch(a){a=Ug(a);if(md(a,4)){f=a;throw Vg(f)}else throw Vg(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.i=c;this.k=null;this.j=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);Vo==(d&Wo)&&mb(this.f)}
function Bl(a){var b,c,d;this.d=a;K();b=++vl;this.c=new pc(b,null,new Cl(this),false,false);this.b=(d=new jb((c=null,c)),d);this.a=new wb(null,new Fl(this),fp)}
function dl(a){var b;this.d=a;K();b=++al;this.c=new pc(b,null,new el(this),false,false);this.a=new X(new fl,null,null,136478720);this.b=new wb(null,new hl(this),fp)}
function Nn(a,b){var c,d,e,f,g;this.e=a;this.d=b;K();c=++Dn;this.c=new pc(c,null,new On(this),true,true);this.b=(g=new jb((e=null,e)),g);this.a=(f=new jb((d=null,d)),f)}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function dh(b,c,d,e){bh();var f=_g;$moduleName=c;$moduleBase=d;Tg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Po(g)()}catch(a){b(c,a)}}else{Po(g)()}}
function ek(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ri(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Si()}}
function gh(){fh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].nb()&&(c=Tc(c,g)):g[0].nb()}catch(a){a=Ug(a);if(md(a,4)){d=a;Fc();Lc(md(d,34)?d.F():d)}else throw Vg(a)}}return c}
function tl(a){var b;a.e=0;Xk();b=gk(hp,ok(rk(sk(vk(tk(kk(new $wnd.Object,dd($c(ne,1),To,2,6,['new-todo']))),(gb(a.b),a.f)),kh(Qm.prototype.hb,Qm,[a])),kh(Rm.prototype.gb,Rm,[a]))),null);return b}
function zc(a){var b;if(a.c==null){b=rd(a.b)===rd(xc)?null:a.b;a.d=b==null?_o:pd(b)?b==null?null:b.name:qd(b)?'String':xh(r(b));a.a=a.a+': '+(pd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.k;try{d=b.c.s();if(!(rd(e)===rd(d)||e!=null&&q(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=Ug(a);if(md(a,10)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw Vg(c)}else throw Vg(a)}}
function Ii(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Fi(b,e);if(f){return f.$(c)}}e[e.length]=new mi(b,c);++a.b;return null}
function Oj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Zj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ph(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{b.e.r()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Ug(a);if(md(a,4)){K()}else throw Vg(a)}}}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=ad(ke,To,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function vb(a,b,c,d){this.b=new wi;this.f=new Kb(new zb(this),d&6520832|262144|Vo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&Xo)&&D((null,J)))}
function Ji(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Di(b,e.Y())){if(d.length==1){d.length=0;Mi(a.a,g)}else{d.splice(h,1)}--a.b;return e.Z()}}return null}
function ih(a,b,c){var d=fh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=fh[b]),lh(h));_.lb=c;!b&&(_.mb=nh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.kb=f)}
function Fh(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Gh('.',[c,Gh('$',d)]);a.b=Gh('.',[c,Gh('.',d)]);a.i=d[d.length-1]}
function Zh(a,b){var c,d,e;c=b.Y();e=b.Z();d=qd(c)?c==null?_h(Hi(a.a,null)):Vi(a.b,c):_h(Hi(a.a,c));if(!(rd(e)===rd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(qd(c)?c==null?!!Hi(a.a,null):Ui(a.b,c):!!Hi(a.a,c))){return false}return true}
function nn(a){var b;if(0==a.length){b=(qh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',ph.title,b)}else{(qh(),$wnd.goog.global.window).location.hash=a}}
function xo(a,b){var c,d;this.i=a;this.g=b;K();this.f=new pc(0,null,new yo(this),false,false);this.d=(d=new jb((c=null,c)),d);this.b=new X(new Ao(this),null,null,kp);this.c=new X(new Bo(this),null,null,kp);this.a=new wb(new Co(this),null,681574400);D((null,J))}
function Xn(){var a;this.g=new Ei;K();this.f=new pc(0,new Zn(this),new Yn(this),false,false);this.c=(a=new jb(null),a);this.d=new X(new ao(this),null,null,kp);this.e=new X(new bo(this),null,null,kp);this.a=new X(new co(this),null,null,kp);this.b=new X(new eo(this),null,null,kp)}
function vn(){var a,b,c;this.d=new Do(this);this.f=this.e=(c=(qh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));K();this.c=new pc(0,null,new wn(this),false,false);this.b=(b=new jb((a=null,a)),b);this.a=new X(new Cn,new xn(this),new yn(this),35651584)}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new yi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Ug(a);if(!md(a,4))throw Vg(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function _l(a){var b,c,d;this.f=a;this.i=a.props['a'];K();b=++Ql;this.e=new pc(b,null,new am(this),false,false);this.a=(d=new jb((c=null,c)),d);this.c=new X(new dm(this),null,null,136478720);this.b=new wb(null,new hm(this),fp);Fn(this.i,this,new bm(this));Zl(this,this.i);D((null,J))}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.B();return a&&a.w()}},suppressed:{get:function(){return c.A()}}})}catch(a){}}}
function gk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;bk(b,kh(jk.prototype.eb,jk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=ek($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function Qi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}pi(a.b,new Bb(a));a.b.a=ad(ke,To,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function Tk(){Tk=jh;xk=new Uk(dp,0);yk=new Uk('checkbox',1);zk=new Uk('color',2);Ak=new Uk('date',3);Bk=new Uk('datetime',4);Ck=new Uk('email',5);Dk=new Uk('file',6);Ek=new Uk('hidden',7);Fk=new Uk('image',8);Gk=new Uk('month',9);Hk=new Uk(Ro,10);Ik=new Uk('password',11);Jk=new Uk('radio',12);Kk=new Uk('range',13);Lk=new Uk('reset',14);Mk=new Uk('search',15);Nk=new Uk('submit',16);Ok=new Uk('tel',17);Pk=new Uk('text',18);Qk=new Uk('time',19);Rk=new Uk('url',20);Sk=new Uk('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=qi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ui(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=qi(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){si(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new wi)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Vo!=(k.b.c&Wo)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function $k(a){var b,c;a.e=0;Xk();c=(b=T((hn(),gn).b),gk('footer',kk(new $wnd.Object,dd($c(ne,1),To,2,6,['footer'])),[(new vm).a,gk('ul',kk(new $wnd.Object,dd($c(ne,1),To,2,6,['filters'])),[gk('li',null,[gk('a',mk(kk(new $wnd.Object,dd($c(ne,1),To,2,6,[(Ho(),Fo)==b?ep:null])),'#'),['All'])]),gk('li',null,[gk('a',mk(kk(new $wnd.Object,dd($c(ne,1),To,2,6,[Eo==b?ep:null])),'#active'),['Active'])]),gk('li',null,[gk('a',mk(kk(new $wnd.Object,dd($c(ne,1),To,2,6,[Go==b?ep:null])),'#completed'),['Completed'])])]),T(a.a)?gk(dp,nk(kk(new $wnd.Object,dd($c(ne,1),To,2,6,['clear-completed'])),kh(tm.prototype.ib,tm,[])),['Clear Completed']):null]));return c}
function Ol(a){var b,c,d;a.g=0;Xk();b=(c=a.i,d=(gb(c.a),c.d),gk('li',kk(new $wnd.Object,dd($c(ne,1),To,2,6,[d?'checked':null,T(a.c)?'editing':null])),[gk('div',kk(new $wnd.Object,dd($c(ne,1),To,2,6,['view'])),[gk(hp,rk(pk(uk(kk(new $wnd.Object,dd($c(ne,1),To,2,6,['toggle'])),(Tk(),yk)),d),kh(Um.prototype.gb,Um,[c])),null),gk('label',wk(new $wnd.Object,kh(Vm.prototype.ib,Vm,[a,c])),[(gb(c.b),c.e)]),gk(dp,nk(kk(new $wnd.Object,dd($c(ne,1),To,2,6,['destroy'])),kh(Wm.prototype.ib,Wm,[c])),null)]),gk(hp,sk(rk(qk(vk(kk(lk(new $wnd.Object,kh(Xm.prototype.v,Xm,[a])),dd($c(ne,1),To,2,6,['edit'])),(gb(a.a),a.d)),kh(Ym.prototype.fb,Ym,[a,c])),kh(Tm.prototype.gb,Tm,[a])),kh(Zm.prototype.hb,Zm,[a,c])),null)]));return b}
function Si(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[cp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Qi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[cp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Qo='object',Ro='number',So={5:1},To={3:1},Uo={9:1},Vo=1048576,Wo=1835008,Xo=2097152,Yo=4194304,Zo='__noinit__',$o={3:1,10:1,8:1,4:1},_o='null',ap=17592186044416,bp={40:1},cp='delete',dp='button',ep='selected',fp=1411518464,gp=142606336,hp='input',ip='header',jp='hashchange',kp=136314880,lp='active',mp='completed';var _,fh,_g,Tg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;gh();ih(1,null,{},p);_.n=function(a){return o(this,a)};_.o=function(){return this.kb};_.p=op;_.q=function(){var a;return xh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.n(a)};_.hashCode=function(){return this.p()};_.toString=function(){return this.q()};var gd,hd,jd;ih(50,1,{},yh);_.H=function(a){var b;b=new yh;b.e=4;a>1?(b.c=Dh(this,a-1)):(b.c=this);return b};_.I=function(){wh(this);return this.b};_.J=function(){return xh(this)};_.K=function(){wh(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.q=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(wh(this),this.k)};_.e=0;_.g=0;var vh=1;var ke=Ah(1);var be=Ah(50);ih(77,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var xd=Ah(77);ih(78,1,So,G);_.r=function(){Db(this.a)};var ud=Ah(78);ih(35,1,{},H);_.s=function(){return this.a.r(),null};var vd=Ah(35);ih(79,1,{},I);var wd=Ah(79);var J;ih(43,1,{43:1},Q);_.b=0;_.c=false;_.d=0;var yd=Ah(43);ih(215,1,Uo);_.q=function(){var a;return xh(this.kb)+'@'+(a=s(this)>>>0,a.toString(16))};var Bd=Ah(215);ih(18,215,Uo,X);_.t=function(){S(this)};_.u=np;_.a=false;_.d=0;_.j=false;var Ad=Ah(18);ih(123,1,{},Y);_.s=function(){return U(this.a)};var zd=Ah(123);ih(15,215,{9:1,15:1},jb);_.t=function(){ab(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Dd=Ah(15);ih(122,1,So,kb);_.r=function(){bb(this.a)};var Cd=Ah(122);ih(16,215,{9:1,16:1},wb,xb);_.t=function(){lb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Id=Ah(16);ih(124,1,{},yb);_.r=function(){R(this.a)};var Ed=Ah(124);ih(125,1,So,zb);_.r=function(){nb(this.a)};var Fd=Ah(125);ih(126,1,So,Ab);_.r=function(){qb(this.a)};var Gd=Ah(126);ih(127,1,{},Bb);_.v=function(a){ob(this.a,a)};var Hd=Ah(127);ih(132,1,{},Eb);_.a=0;_.b=0;_.c=0;var Jd=Ah(132);ih(159,1,Uo,Gb);_.t=function(){Fb(this)};_.u=np;_.a=false;var Kd=Ah(159);ih(58,215,{9:1,58:1},Kb);_.t=function(){Hb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Md=Ah(58);ih(137,1,{},Pb);var Ld=Ah(137);ih(139,1,{},_b);_.q=function(){var a;return wh(Nd),Nd.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.a=0;var Qb;var Nd=Ah(139);ih(110,1,{});var Qd=Ah(110);ih(82,1,{},hc);_.v=function(a){fc(this.a,a)};var Od=Ah(82);ih(83,1,So,ic);_.r=function(){gc(this.a,this.b)};var Pd=Ah(83);ih(14,1,Uo,pc);_.t=function(){kc(this)};_.u=function(){return this.i<0};_.q=function(){var a;return wh(Sd),Sd.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Sd=Ah(14);ih(121,1,So,qc);_.r=function(){nc(this.a)};var Rd=Ah(121);ih(4,1,{3:1,4:1});_.w=tp;_.A=function(){return yj(wj(Ai((this.i==null&&(this.i=ad(pe,To,4,0,0,1)),this.i)),new Vh),new Cj)};_.B=function(){return this.f};_.C=function(){return this.g};_.D=function(){tc(this,vc(new Error(uc(this,this.g))));Xc(this)};_.q=function(){return uc(this,this.C())};_.e=Zo;_.j=true;var pe=Ah(4);ih(10,4,{3:1,10:1,4:1});var ee=Ah(10);ih(8,10,$o);var le=Ah(8);ih(71,8,$o);var ie=Ah(71);ih(72,71,$o);var Wd=Ah(72);ih(34,72,{34:1,3:1,10:1,8:1,4:1},Ac);_.C=function(){zc(this);return this.c};_.F=function(){return rd(this.b)===rd(xc)?null:this.b};var xc;var Td=Ah(34);var Ud=Ah(0);ih(201,1,{});var Vd=Ah(201);var Cc=0,Dc=0,Ec=-1;ih(109,201,{},Sc);var Oc;var Xd=Ah(109);var Vc;ih(212,1,{});var Zd=Ah(212);ih(73,212,{},Zc);var Yd=Ah(73);var ph;ih(69,1,{66:1});_.q=np;var $d=Ah(69);ih(75,8,$o);var ge=Ah(75);ih(155,75,$o,th);var _d=Ah(155);gd={3:1,67:1,27:1};var ae=Ah(67);ih(41,1,{3:1,41:1});var je=Ah(41);hd={3:1,27:1,41:1};var ce=Ah(211);ih(29,1,{3:1,27:1,29:1});_.n=function(a){return this===a};_.p=op;_.q=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=Ah(29);ih(74,8,$o,Jh);var fe=Ah(74);ih(28,41,{3:1,27:1,28:1,41:1},Kh);_.n=function(a){return md(a,28)&&a.a==this.a};_.p=np;_.q=function(){return ''+this.a};_.a=0;var he=Ah(28);var Mh;ih(278,1,{});jd={3:1,66:1,27:1,2:1};var ne=Ah(2);ih(70,69,{66:1},Uh);var me=Ah(70);ih(282,1,{});ih(64,1,{},Vh);_.P=function(a){return a.e};var oe=Ah(64);ih(52,8,$o,Wh);var qe=Ah(52);ih(213,1,{39:1});_.N=sp;_.S=function(){return new lj(this,0)};_.T=function(){return new zj(null,this.S())};_.Q=function(a){throw Vg(new Wh('Add not supported on this collection'))};_.q=function(){var a,b,c;c=new nj('[',']');for(b=this.O();b.V();){a=b.W();mj(c,a===this?'(this Collection)':a==null?_o:mh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var re=Ah(213);ih(216,1,{199:1});_.n=function(a){var b,c,d;if(a===this){return true}if(!md(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ii((new fi(d)).a);c.b;){b=hi(c);if(!Zh(this,b)){return false}}return true};_.p=function(){return Bi(new fi(this))};_.q=function(){var a,b,c;c=new nj('{','}');for(b=new ii((new fi(this)).a);b.b;){a=hi(b);mj(c,$h(this,a.Y())+'='+$h(this,a.Z()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ce=Ah(216);ih(128,216,{199:1});var ue=Ah(128);ih(217,213,{39:1,226:1});_.S=function(){return new lj(this,1)};_.n=function(a){var b;if(a===this){return true}if(!md(a,21)){return false}b=a;if(di(b.a)!=this.R()){return false}return Xh(this,b)};_.p=function(){return Bi(this)};var De=Ah(217);ih(21,217,{21:1,39:1,226:1},fi);_.O=function(){return new ii(this.a)};_.R=qp;var te=Ah(21);ih(22,1,{},ii);_.U=pp;_.W=function(){return hi(this)};_.V=rp;_.b=false;var se=Ah(22);ih(214,213,{39:1,223:1});_.S=function(){return new lj(this,16)};_.X=function(a,b){throw Vg(new Wh('Add not supported on this list'))};_.Q=function(a){this.X(this.R(),a);return true};_.n=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,13)){return false}f=a;if(this.R()!=f.a.length){return false}e=new yi(f);for(c=new yi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(rd(b)===rd(d)||b!=null&&q(b,d))){return false}}return true};_.p=function(){return Ci(this)};_.O=function(){return new ji(this)};var we=Ah(214);ih(108,1,{},ji);_.U=pp;_.V=function(){return this.a<this.b.a.length};_.W=function(){return qi(this.b,this.a++)};_.a=0;var ve=Ah(108);ih(42,213,{39:1},ki);_.O=function(){var a;a=new ii((new fi(this.a)).a);return new li(a)};_.R=qp;var ye=Ah(42);ih(131,1,{},li);_.U=pp;_.V=function(){return this.a.b};_.W=function(){var a;a=hi(this.a);return a.Z()};var xe=Ah(131);ih(129,1,bp);_.n=function(a){var b;if(!md(a,40)){return false}b=a;return Di(this.a,b.Y())&&Di(this.b,b.Z())};_.Y=np;_.Z=rp;_.p=function(){return cj(this.a)^cj(this.b)};_.$=function(a){var b;b=this.b;this.b=a;return b};_.q=function(){return this.a+'='+this.b};var ze=Ah(129);ih(130,129,bp,mi);var Ae=Ah(130);ih(218,1,bp);_.n=function(a){var b;if(!md(a,40)){return false}b=a;return Di(this.b.value[0],b.Y())&&Di($i(this),b.Z())};_.p=function(){return cj(this.b.value[0])^cj($i(this))};_.q=function(){return this.b.value[0]+'='+$i(this)};var Be=Ah(218);ih(13,214,{3:1,13:1,39:1,223:1},wi,xi);_.X=function(a,b){Pj(this.a,a,b)};_.Q=function(a){return oi(this,a)};_.N=function(a){pi(this,a)};_.O=function(){return new yi(this)};_.R=function(){return this.a.length};var Fe=Ah(13);ih(17,1,{},yi);_.U=pp;_.V=function(){return this.a<this.c.a.length};_.W=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ee=Ah(17);ih(36,128,{3:1,36:1,199:1},Ei);var Ge=Ah(36);ih(56,1,{},Ki);_.N=sp;_.O=function(){return new Li(this)};_.b=0;var Ie=Ah(56);ih(57,1,{},Li);_.U=pp;_.W=function(){return this.d=this.a[this.c++],this.d};_.V=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var He=Ah(57);var Oi;ih(54,1,{},Yi);_.N=sp;_.O=function(){return new Zi(this)};_.b=0;_.c=0;var Le=Ah(54);ih(55,1,{},Zi);_.U=pp;_.W=function(){return this.c=this.a,this.a=this.b.next(),new _i(this.d,this.c,this.d.c)};_.V=function(){return !this.a.done};var Je=Ah(55);ih(138,218,bp,_i);_.Y=function(){return this.b.value[0]};_.Z=function(){return $i(this)};_.$=function(a){return Wi(this.a,this.b.value[0],a)};_.c=0;var Ke=Ah(138);ih(141,1,{});_.U=up;_._=function(){return this.d};_.ab=tp;_.d=0;_.e=0;var Pe=Ah(141);ih(59,141,{});var Me=Ah(59);ih(133,1,{});_.U=up;_._=rp;_.ab=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Oe=Ah(133);ih(134,133,{},jj);_.U=function(a){gj(this,a)};_.bb=function(a){return hj(this,a)};var Ne=Ah(134);ih(19,1,{},lj);_._=np;_.ab=function(){kj(this);return this.c};_.U=function(a){kj(this);this.d.U(a)};_.bb=function(a){kj(this);if(this.d.V()){a.v(this.d.W());return true}return false};_.a=0;_.c=0;var Qe=Ah(19);ih(51,1,{},nj);_.q=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Re=Ah(51);ih(33,1,{},oj);_.P=function(a){return a};var Se=Ah(33);ih(37,1,{},pj);var Te=Ah(37);ih(140,1,{});_.c=false;var bf=Ah(140);ih(23,140,{},zj);var af=Ah(23);ih(65,1,{},Cj);_.cb=function(a){return ad(ke,To,1,a,5,1)};var Ue=Ah(65);ih(143,59,{},Ej);_.bb=function(a){this.b=false;while(!this.b&&this.c.bb(new Fj(this,a)));return this.b};_.b=false;var We=Ah(143);ih(146,1,{},Fj);_.v=function(a){Dj(this.a,this.b,a)};var Ve=Ah(146);ih(142,59,{},Hj);_.bb=function(a){return this.b.bb(new Ij(this,a))};var Ye=Ah(142);ih(145,1,{},Ij);_.v=function(a){Gj(this.a,this.b,a)};var Xe=Ah(145);ih(144,1,{},Kj);_.v=function(a){Jj(this,a)};var Ze=Ah(144);ih(147,1,{},Lj);_.v=function(a){};var $e=Ah(147);ih(148,1,{},Nj);_.v=function(a){Mj(this,a)};var _e=Ah(148);ih(280,1,{});ih(277,1,{});var Tj=0;var Vj,Wj=0,Xj;ih(895,1,{});ih(919,1,{});ih(156,1,{},ik);_.cb=function(a){return new Array(a)};var cf=Ah(156);ih(245,$wnd.Function,{},jk);_.eb=function(a){hk(this.a,this.b,a)};ih(6,29,{3:1,27:1,29:1,6:1},Uk);var xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk;var df=Bh(6,Vk);var Wk;ih(246,$wnd.Function,{},Yk);_.G=function(a){return Fb(Wk),Wk=null,null};ih(221,1,{});var Nf=Ah(221);ih(172,221,{});_.e=0;var Rf=Ah(172);ih(173,172,Uo,dl);_.t=vp;_.u=wp;_.q=function(){var a;return wh(nf),nf.k+'@'+(a=Uj(this)>>>0,a.toString(16))};var al=0;var nf=Ah(173);ih(174,1,So,el);_.r=function(){bl(this.a)};var ef=Ah(174);ih(175,1,{},fl);_.s=function(){return uh(),T((hn(),en).b).a>0?true:false};var ff=Ah(175);ih(177,1,{},gl);_.s=function(){return $k(this.a)};var gf=Ah(177);ih(176,1,{},hl);_.r=function(){_k(this.a)};var hf=Ah(176);ih(222,1,{});var Mf=Ah(222);ih(193,222,{});_.d=0;var Qf=Ah(193);ih(194,193,Uo,ml);_.t=xp;_.u=yp;_.q=function(){var a;return wh(mf),mf.k+'@'+(a=Uj(this)>>>0,a.toString(16))};var kl=0;var mf=Ah(194);ih(195,1,So,nl);_.r=zp;var jf=Ah(195);ih(196,1,{},ol);_.r=function(){jl(this.a)};var kf=Ah(196);ih(197,1,{},pl);_.s=function(){var a;return this.a.d=0,Xk(),a=T((hn(),en).e).a,gk('span',kk(new $wnd.Object,dd($c(ne,1),To,2,6,['todo-count'])),[gk('strong',null,[a]),' item'+(a==1?'':'s')+' left'])};var lf=Ah(197);ih(164,1,{});_.f='';var Zf=Ah(164);ih(165,164,{});_.e=0;var Tf=Ah(165);ih(166,165,Uo,Bl);_.t=vp;_.u=wp;_.q=function(){var a;return wh(tf),tf.k+'@'+(a=Uj(this)>>>0,a.toString(16))};var vl=0;var tf=Ah(166);ih(167,1,So,Cl);_.r=function(){wl(this.a)};var of=Ah(167);ih(169,1,{},Dl);_.s=function(){return tl(this.a)};var pf=Ah(169);ih(170,1,So,El);_.r=function(){ql(this.a)};var qf=Ah(170);ih(168,1,{},Fl);_.r=function(){_k(this.a)};var rf=Ah(168);ih(171,1,So,Gl);_.r=function(){zl(this.a,this.b)};var sf=Ah(171);ih(220,1,{});_.k=false;var _f=Ah(220);ih(179,220,{});_.g=0;var Vf=Ah(179);ih(180,179,Uo,_l);_.t=function(){kc(this.e)};_.u=function(){return this.e.i<0};_.q=function(){var a;return wh(Ff),Ff.k+'@'+(a=Uj(this)>>>0,a.toString(16))};var Ql=0;var Ff=Ah(180);ih(181,1,So,am);_.r=function(){Rl(this.a)};var uf=Ah(181);ih(184,1,So,bm);_.r=function(){kc(this.a.e)};var vf=Ah(184);ih(185,1,{},cm);_.s=function(){return Ol(this.a)};var wf=Ah(185);ih(182,1,{},dm);_.s=function(){return Ul(this.a)};var xf=Ah(182);ih(60,1,So,em);_.r=function(){$l(this.a,rn(this.b))};var yf=Ah(60);ih(61,1,So,fm);_.r=function(){Kl(this.a,this.b)};var zf=Ah(61);ih(186,1,So,gm);_.r=function(){Vl(this.a,this.b)};var Af=Ah(186);ih(183,1,{},hm);_.r=function(){Pl(this.a)};var Bf=Ah(183);ih(187,1,So,im);_.r=function(){Zl(this.a,this.b);wo((hn(),gn),null)};var Cf=Ah(187);ih(188,1,So,jm);_.r=function(){Hl(this.a,this.b)};var Df=Ah(188);ih(189,1,So,km);_.r=function(){Ll(this.a)};var Ef=Ah(189);ih(219,1,{});var cg=Ah(219);ih(150,219,{});_.d=0;var Xf=Ah(150);ih(151,150,Uo,pm);_.t=xp;_.u=yp;_.q=function(){var a;return wh(Jf),Jf.k+'@'+(a=Uj(this)>>>0,a.toString(16))};var nm=0;var Jf=Ah(151);ih(152,1,So,qm);_.r=zp;var Gf=Ah(152);ih(153,1,{},rm);_.r=function(){jl(this.a)};var Hf=Ah(153);ih(154,1,{},sm);_.s=function(){return this.a.d=0,Xk(),gk('div',null,[gk('div',null,[gk(ip,kk(new $wnd.Object,dd($c(ne,1),To,2,6,[ip])),[gk('h1',null,['todos']),(new Sm).a]),T((hn(),en).d)?gk('section',kk(new $wnd.Object,dd($c(ne,1),To,2,6,[ip])),[gk(hp,rk(uk(kk(new $wnd.Object,dd($c(ne,1),To,2,6,['toggle-all'])),(Tk(),yk)),kh(an.prototype.gb,an,[])),null),gk('ul',kk(new $wnd.Object,dd($c(ne,1),To,2,6,['todo-list'])),yj(wj(T(gn.c).T(),new bn),new ik))]):null,T(en.d)?(new um).a:null])])};var If=Ah(154);ih(250,$wnd.Function,{},tm);_.ib=function(a){ho((hn(),fn))};ih(158,1,{},um);var Kf=Ah(158);ih(178,1,{},vm);var Lf=Ah(178);ih(251,$wnd.Function,{},wm);_.jb=function(a){return new zm(a)};var xm;ih(162,$wnd.React.Component,{},zm);hh(fh[1],_);_.componentWillUnmount=function(){Zk(this.a)};_.render=function(){return cl(this.a)};_.shouldComponentUpdate=Ap;var Of=Ah(162);ih(261,$wnd.Function,{},Am);_.jb=function(a){return new Dm(a)};var Bm;ih(190,$wnd.React.Component,{},Dm);hh(fh[1],_);_.componentWillUnmount=function(){il(this.a)};_.render=function(){return ll(this.a)};_.shouldComponentUpdate=Bp;var Pf=Ah(190);ih(249,$wnd.Function,{},Em);_.jb=function(a){return new Hm(a)};var Fm;ih(161,$wnd.React.Component,{},Hm);hh(fh[1],_);_.componentWillUnmount=function(){Zk(this.a)};_.render=function(){return xl(this.a)};_.shouldComponentUpdate=Ap;var Sf=Ah(161);ih(252,$wnd.Function,{},Im);_.jb=function(a){return new Lm(a)};var Jm;ih(163,$wnd.React.Component,{},Lm);hh(fh[1],_);_.componentDidUpdate=function(a){$(this.a)&&(Yl(this.a),undefined)};_.componentWillUnmount=function(){$(this.a)&&Nl(this.a)};_.render=function(){return $(this.a)?Sl(this.a):null};_.shouldComponentUpdate=function(a){return $(this.a)&&1==this.a.g};var Uf=Ah(163);ih(243,$wnd.Function,{},Mm);_.jb=function(a){return new Pm(a)};var Nm;ih(135,$wnd.React.Component,{},Pm);hh(fh[1],_);_.componentWillUnmount=function(){il(this.a)};_.render=function(){return om(this.a)};_.shouldComponentUpdate=Bp;var Wf=Ah(135);ih(247,$wnd.Function,{},Qm);_.hb=function(a){rl(this.a,a)};ih(248,$wnd.Function,{},Rm);_.gb=function(a){yl(this.a,a)};ih(157,1,{},Sm);var Yf=Ah(157);ih(259,$wnd.Function,{},Tm);_.gb=function(a){Tl(this.a,a)};ih(253,$wnd.Function,{},Um);_.gb=function(a){Mn(this.a)};ih(255,$wnd.Function,{},Vm);_.ib=function(a){Wl(this.a,this.b)};ih(256,$wnd.Function,{},Wm);_.ib=function(a){Ml(this.a)};ih(257,$wnd.Function,{},Xm);_.v=function(a){Il(this.a,a)};ih(258,$wnd.Function,{},Ym);_.fb=function(a){Xl(this.a,this.b)};ih(260,$wnd.Function,{},Zm);_.hb=function(a){Jl(this.a,this.b,a)};ih(160,1,{},_m);var $f=Ah(160);ih(242,$wnd.Function,{},an);_.gb=function(a){var b;b=a.target;lo((hn(),fn),b.checked)};ih(136,1,{},bn);_.P=function(a){return $m(new _m,a)};var ag=Ah(136);ih(63,1,{},cn);var bg=Ah(63);var dn,en,fn,gn;ih(93,1,{});var Ig=Ah(93);ih(94,93,Uo,vn);_.t=vp;_.u=wp;_.q=function(){var a;return wh(kg),kg.k+'@'+(a=Uj(this)>>>0,a.toString(16))};var kg=Ah(94);ih(95,1,So,wn);_.r=function(){pn(this.a)};var dg=Ah(95);ih(97,1,{},xn);_.r=function(){kn(this.a)};var eg=Ah(97);ih(98,1,{},yn);_.r=function(){ln(this.a)};var fg=Ah(98);ih(99,1,So,zn);_.r=function(){jn(this.a,this.b)};var gg=Ah(99);ih(100,1,So,An);_.r=function(){sn(this.a)};var hg=Ah(100);ih(53,1,So,Bn);_.r=function(){on(this.a)};var ig=Ah(53);ih(96,1,{},Cn);_.s=function(){var a;return a=(qh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var jg=Ah(96);ih(44,1,{44:1});_.d=false;var Qg=Ah(44);ih(45,44,{9:1,244:1,45:1,44:1},Nn);_.t=vp;_.n=function(a){return Gn(this,a)};_.p=function(){return this.c.d};_.u=wp;_.q=function(){var a;return wh(Ag),Ag.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Dn=0;var Ag=Ah(45);ih(191,1,So,On);_.r=function(){En(this.a)};var lg=Ah(191);ih(192,1,So,Pn);_.r=function(){Jn(this.a)};var mg=Ah(192);ih(111,110,{});var Lg=Ah(111);ih(112,111,Uo,Xn);_.t=Cp;_.u=Dp;_.q=function(){var a;return wh(vg),vg.k+'@'+(a=Uj(this)>>>0,a.toString(16))};var vg=Ah(112);ih(114,1,So,Yn);_.r=function(){Rn(this.a)};var ng=Ah(114);ih(113,1,So,Zn);_.r=function(){Un(this.a)};var og=Ah(113);ih(119,1,So,$n);_.r=function(){cc(this.a,this.b,true)};var pg=Ah(119);ih(120,1,{},_n);_.s=function(){return Qn(this.a,this.c,this.b)};_.b=false;var qg=Ah(120);ih(115,1,{},ao);_.s=function(){return Vn(this.a)};var rg=Ah(115);ih(116,1,{},bo);_.s=function(){return Lh($g(uj(dc(this.a))))};var sg=Ah(116);ih(117,1,{},co);_.s=function(){return Lh($g(uj(vj(dc(this.a),new Ko))))};var tg=Ah(117);ih(118,1,{},eo);_.s=function(){return Wn(this.a)};var ug=Ah(118);ih(87,1,{});var Pg=Ah(87);ih(88,87,Uo,mo);_.t=function(){kc(this.a)};_.u=function(){return this.a.i<0};_.q=function(){var a;return wh(zg),zg.k+'@'+(a=Uj(this)>>>0,a.toString(16))};var zg=Ah(88);ih(89,1,So,no);_.r=function(){io(this.a,this.b)};_.b=false;var wg=Ah(89);ih(90,1,So,oo);_.r=function(){un(this.b,this.a)};var xg=Ah(90);ih(91,1,So,po);_.r=function(){jo(this.a)};var yg=Ah(91);ih(101,1,{});var Sg=Ah(101);ih(102,101,Uo,xo);_.t=Cp;_.u=Dp;_.q=function(){var a;return wh(Gg),Gg.k+'@'+(a=Uj(this)>>>0,a.toString(16))};var Gg=Ah(102);ih(103,1,So,yo);_.r=function(){so(this.a)};var Bg=Ah(103);ih(107,1,So,zo);_.r=function(){wo(this.a,null)};var Cg=Ah(107);ih(104,1,{},Ao);_.s=function(){var a;return a=rn(this.a.g),o(lp,a)?(Ho(),Eo):o(mp,a)?(Ho(),Go):(Ho(),Fo)};var Dg=Ah(104);ih(105,1,{},Bo);_.s=function(){return uo(this.a)};var Eg=Ah(105);ih(106,1,{},Co);_.r=function(){vo(this.a)};var Fg=Ah(106);ih(92,1,{},Do);_.handleEvent=function(a){mn(this.a,a)};var Hg=Ah(92);ih(30,29,{3:1,27:1,29:1,30:1},Io);var Eo,Fo,Go;var Jg=Bh(30,Jo);ih(81,1,{},Ko);_.db=function(a){return !In(a)};var Kg=Ah(81);ih(85,1,{},Lo);_.db=function(a){return In(a)};var Mg=Ah(85);ih(86,1,{},Mo);_.v=function(a){Tn(this.a,a)};var Ng=Ah(86);ih(84,1,{},No);_.v=function(a){go(this.a,a)};_.a=false;var Og=Ah(84);ih(76,1,{},Oo);_.db=function(a){return ro(this.a,a)};var Rg=Ah(76);var td=Ch('D');var Po=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=dh;ah(oh);eh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();