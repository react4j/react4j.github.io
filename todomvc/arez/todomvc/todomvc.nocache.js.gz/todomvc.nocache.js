function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='AC2821C500DE5B6E091B239707970078',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'AC2821C500DE5B6E091B239707970078';function p(){}
function kh(){}
function gh(){}
function Sh(){}
function Fb(){}
function Rc(){}
function Yc(){}
function lj(){}
function zj(){}
function Hj(){}
function Ij(){}
function hk(){}
function Xk(){}
function el(){}
function rm(){}
function um(){}
function ym(){}
function Cm(){}
function Gm(){}
function Km(){}
function $m(){}
function _m(){}
function An(){}
function Io(){}
function Jo(){}
function Wc(a){Vc()}
function rh(){rh=gh}
function ti(){ki(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function gc(a){this.a=a}
function pc(a){this.a=a}
function Hh(a){this.a=a}
function Rh(a){this.a=a}
function ci(a){this.a=a}
function hi(a){this.a=a}
function ii(a){this.a=a}
function gi(a){this.b=a}
function vi(a){this.c=a}
function mj(a){this.a=a}
function Kj(a){this.a=a}
function dl(a){this.a=a}
function fl(a){this.a=a}
function gl(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function Bl(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function El(a){this.a=a}
function _l(a){this.a=a}
function am(a){this.a=a}
function bm(a){this.a=a}
function gm(a){this.a=a}
function im(a){this.a=a}
function om(a){this.a=a}
function pm(a){this.a=a}
function qm(a){this.a=a}
function Om(a){this.a=a}
function Pm(a){this.a=a}
function Rm(a){this.a=a}
function Sm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function un(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function Mn(a){this.a=a}
function Nn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function no(a){this.a=a}
function wo(a){this.a=a}
function xo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function Gj(a,b){a.a=b}
function qb(a,b){a.b=b}
function ak(a,b){a.key=b}
function $j(a,b){Zj(a,b)}
function eo(a,b){Zl(b,a)}
function Y(a){!!a&&$(a)}
function kc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function op(a){Zi(this,a)}
function rp(a){Lh(this,a)}
function tp(a){aj(this,a)}
function up(){jc(this.c)}
function wp(){jc(this.b)}
function Bp(){jc(this.f)}
function Hi(){this.a=Qi()}
function Vi(){this.a=Qi()}
function yp(){kb(this.a.a)}
function db(a){Xb((J(),a))}
function eb(a){Yb((J(),a))}
function hb(a){Zb((J(),a))}
function Sg(a){return a.e}
function sp(){return this.e}
function mp(){return this.a}
function qp(){return this.b}
function J(){J=gh;I=new F}
function xc(){xc=gh;wc=new p}
function Mi(){Mi=gh;Li=Oi()}
function Ml(a){a.g=2;jc(a.e)}
function hl(a){a.d=2;jc(a.b)}
function Yk(a){a.e=2;jc(a.c)}
function nn(a){R(a.a);$(a.b)}
function Cn(a){$(a.b);$(a.a)}
function al(a){kb(a.b);R(a.a)}
function vl(a){kb(a.a);$(a.b)}
function K(a,b){O(a);L(a,b)}
function Jj(a,b){yj(a.a,b)}
function nc(a,b){$h(a.e,b)}
function co(a,b){Qn(a.b,b)}
function C(a,b){Nb(a.f,b.f)}
function ic(a,b,c){Zh(a.e,b,c)}
function fj(a,b,c){b.w(a.a[c])}
function Dn(a,b,c){ic(a.c,b,c)}
function Oj(a,b){a.splice(b,1)}
function sc(a,b){a.e=b;rc(a,b)}
function Hl(a,b){return a.i=b}
function ni(a,b){return a.a[b]}
function Zc(a,b){return Ah(a,b)}
function np(){return Rj(this)}
function pp(){return ai(this.a)}
function vp(){return this.c.i<0}
function xp(){return this.b.i<0}
function Cp(){return this.f.i<0}
function Qi(){Mi();return new Li}
function uh(a){th(a);return a.k}
function xj(a,b){a.R(b);return a}
function aj(a,b){while(a.cb(b));}
function yj(a,b){Gj(a,xj(a.a,b))}
function Dj(a,b,c){b.w(a.a.Q(c))}
function v(a,b,c){t(a,new H(c),b)}
function Ll(a){Rn((fn(),cn),a)}
function qh(a){vc.call(this,a)}
function Th(a){vc.call(this,a)}
function Ec(){Ec=gh;!!(Vc(),Uc)}
function Oc(){Oc=gh;Nc=new Rc}
function Mc(){Bc!=0&&(Bc=0);Dc=-1}
function ab(a){J();Yb(a);a.e=-2}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function T(a){mb(a.f);return V(a)}
function pn(a){fb(a.b);return a.e}
function Gn(a){fb(a.a);return a.d}
function ro(a){fb(a.d);return a.e}
function kk(a,b){a.ref=b;return a}
function hc(a,b){this.a=a;this.b=b}
function Fh(a,b){this.a=a;this.b=b}
function Fj(a,b){this.a=a;this.b=b}
function Cj(a,b){this.a=a;this.b=b}
function ji(a,b){this.a=a;this.b=b}
function ik(a,b){this.a=a;this.b=b}
function Fl(a,b){this.a=a;this.b=b}
function cm(a,b){this.a=a;this.b=b}
function dm(a,b){this.a=a;this.b=b}
function em(a,b){this.a=a;this.b=b}
function fm(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function Db(a){this.d=a;this.b=100}
function zp(a){return 1==this.a.e}
function Ap(a){return 1==this.a.d}
function ai(a){return a.a.b+a.b.b}
function Si(a,b){return a.a.get(b)}
function Tk(a,b){Fh.call(this,a,b)}
function Tm(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function xn(a,b){this.a=a;this.b=b}
function Yn(a,b){this.a=a;this.b=b}
function lo(a,b){this.a=a;this.b=b}
function mo(a,b){this.b=a;this.a=b}
function Go(a,b){Fh.call(this,a,b)}
function Mj(a,b,c){a.splice(b,0,c)}
function lk(a,b){a.href=b;return a}
function Ph(a,b){a.a+=''+b;return a}
function $g(){Yg==null&&(Yg=[])}
function sm(){this.a=ek((wm(),vm))}
function tm(){this.a=ek((Am(),zm))}
function Qm(){this.a=ek((Em(),Dm))}
function Zm(){this.a=ek((Im(),Hm))}
function an(){this.a=ek((Mm(),Lm))}
function qn(a){on(a,(fb(a.b),a.e))}
function Hn(a){Zl(a,(fb(a.a),!a.d))}
function Tb(a){return !a.d?a:Tb(a.d)}
function Yh(a){return !a?null:a.$()}
function qd(a){return a==null?null:a}
function _i(a){return a!=null?s(a):0}
function nd(a){return typeof a===Po}
function o(a,b){return qd(a)===qd(b)}
function Nj(a,b){Lj(b,0,a,0,b.length)}
function uk(a,b){a.value=b;return a}
function pk(a,b){a.onBlur=b;return a}
function mk(a,b){a.onClick=b;return a}
function ok(a,b){a.checked=b;return a}
function Lc(a){$wnd.clearTimeout(a)}
function ki(a){a.a=_c(ie,Qo,1,0,5,1)}
function _h(a){a.a=new Hi;a.b=new Vi}
function ib(a){this.c=new ti;this.b=a}
function Vj(){Vj=gh;Sj=new p;Uj=new p}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function Mh(a,b){return a.charCodeAt(b)}
function Rj(a){return a.$H||(a.$H=++Qj)}
function Z(a){return !(!!a&&1==(a.c&7))}
function ld(a,b){return a!=null&&jd(a,b)}
function fc(a,b){bc(a,b,false);eb(a.c)}
function Ql(a){kb(a.b);R(a.c);$(a.a)}
function pb(a){J();ob(a);sb(a,2,true)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function go(a,b){mi(dc(a.b),new Lo(b))}
function Zj(a,b){for(var c in a){b(c)}}
function qk(a,b){a.onChange=b;return a}
function rk(a,b){a.onKeyDown=b;return a}
function _j(a,b){a.props['a']=b;return a}
function nk(a){a.autoFocus=true;return a}
function th(a){if(a.k!=null){return}Ch(a)}
function ec(a,b){nc(b.c,a);ld(b,9)&&b.t()}
function vc(a){this.g=a;qc(this);this.F()}
function wj(a,b){pj.call(this,a);this.a=b}
function Ji(a,b){var c;c=a[ap];c.call(a,b)}
function Zi(a,b){while(a.W()){Jj(b,a.X())}}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function P(){this.a=_c(ie,Qo,1,100,5,1)}
function Kh(){Kh=gh;Jh=_c(fe,Qo,28,256,0,1)}
function Kn(a){A((J(),J(),I),new Nn(a),fp)}
function rn(a){A((J(),J(),I),new yn(a),fp)}
function Xl(a){A((J(),J(),I),new im(a),fp)}
function fo(a){A((J(),J(),I),new no(a),fp)}
function qo(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function Un(a){return Ih(S(a.e).a-S(a.a).a)}
function pd(a){return typeof a==='string'}
function md(a){return typeof a==='boolean'}
function Fc(a,b,c){return a.apply(b,c);var d}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function oh(a,b,c,d){a.addEventListener(b,c,d)}
function Yi(a,b,c){this.a=a;this.b=b;this.c=c}
function Bi(){this.a=new Hi;this.b=new Vi}
function Vc(){Vc=gh;var a;!Xc();a=new Yc;Uc=a}
function qc(a){a.j&&a.e!==Xo&&a.F();return a}
function vk(a,b){a.onDoubleClick=b;return a}
function li(a,b){a.a[a.a.length]=b;return true}
function xh(a){var b;b=wh(a);Eh(a,b);return b}
function Cb(a){while(true){if(!Bb(a)){break}}}
function dj(a,b){while(a.c<a.d){fj(a,b,a.c++)}}
function xl(a,b){A((J(),J(),I),new Fl(a,b),fp)}
function Sl(a,b){A((J(),J(),I),new hm(a,b),fp)}
function Vl(a,b){A((J(),J(),I),new em(a,b),fp)}
function Wl(a,b){A((J(),J(),I),new dm(a,b),fp)}
function Yl(a,b){A((J(),J(),I),new cm(a,b),fp)}
function Rn(a,b){A((J(),J(),I),new Yn(a,b),fp)}
function io(a,b){A((J(),J(),I),new mo(a,b),fp)}
function jo(a,b){A((J(),J(),I),new lo(a,b),fp)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function yl(a,b){var c;c=b.target;zl(a,c.value)}
function qj(a,b){var c;return uj(a,(c=new ti,c))}
function zh(a){var b;b=wh(a);b.j=a;b.e=1;return b}
function ei(a){var b;b=a.a.X();a.b=di(a);return b}
function hj(a){if(!a.d){a.d=a.b.P();a.c=a.b.S()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Aj(a,b,c){if(a.a.eb(c)){a.b=true;b.w(c)}}
function Zn(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function Sn(a){Lh(new hi(a.g),new gc(a));_h(a.g)}
function Pn(a){R(a.d);R(a.e);R(a.a);R(a.b);$(a.c)}
function Tn(a){return rh(),0!=S(a.e).a?true:false}
function oo(a){return o(kp,a)||o(lp,a)||o('',a)}
function wi(a,b){return bj(b,a.length),new gj(a,b)}
function Ri(a,b){return !(a.a.get(b)===undefined)}
function bl(a){return B((J(),J(),I),a.b,new fl(a))}
function xi(a){return new wj(null,wi(a,a.length))}
function kl(a){return B((J(),J(),I),a.a,new ol(a))}
function wl(a){return B((J(),J(),I),a.a,new Cl(a))}
function bd(a){return Array.isArray(a)&&a.nb===kh}
function kd(a){return !Array.isArray(a)&&a.nb===kh}
function Rl(a){return B((J(),J(),I),a.b,new am(a))}
function mm(a){return B((J(),J(),I),a.a,new qm(a))}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Sc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function pi(a,b){var c;c=a.a[b];Oj(a.a,b);return c}
function ri(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function zl(a,b){var c;c=a.f;if(b!=c){a.f=b;eb(a.b)}}
function Zl(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function il(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Ol(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function $k(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function nj(a){if(!a.b){oj(a);a.c=true}else{nj(a.b)}}
function sj(a,b){oj(a);return new wj(a,new Bj(b,a.a))}
function tj(a,b){oj(a);return new wj(a,new Ej(b,a.a))}
function bi(a,b){if(b){return Wh(a.a,b)}return false}
function Xg(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function Yj(){if(Tj==256){Sj=Uj;Uj=new p;Tj=0}++Tj}
function pj(a){if(!a){this.b=null;new ti}else{this.b=a}}
function gj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function cj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function sn(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function yh(a,b){var c;c=wh(a);Eh(a,c);c.e=b?8:0;return c}
function tk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Ai(a,b){return qd(a)===qd(b)||a!=null&&q(a,b)}
function mn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&sn(a,b)}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Vo)&&D((null,I))}
function on(a,b){A((J(),J(),I),new xn(a,b),75497472)}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function ij(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Xh(a,b){return b===a?'(this Map)':b==null?Zo:jh(b)}
function tc(a,b){var c;c=uh(a.lb);return b==null?c:c+': '+b}
function Gl(a,b){var c;if(S(a.c)){c=b.target;Zl(a,c.value)}}
function Lh(a,b){var c,d;for(d=a.P();d.W();){c=d.X();b.w(c)}}
function ph(a,b,c,d){a.removeEventListener(b,c,d)}
function Kc(a){Ec();$wnd.setTimeout(function(){throw a},0)}
function nh(){nh=gh;mh=$wnd.goog.global.document}
function wm(){wm=gh;var a;vm=(a=hh(um.prototype.kb,um,[]),a)}
function Am(){Am=gh;var a;zm=(a=hh(ym.prototype.kb,ym,[]),a)}
function Em(){Em=gh;var a;Dm=(a=hh(Cm.prototype.kb,Cm,[]),a)}
function Im(){Im=gh;var a;Hm=(a=hh(Gm.prototype.kb,Gm,[]),a)}
function Mm(){Mm=gh;var a;Lm=(a=hh(Km.prototype.kb,Km,[]),a)}
function Ho(){Fo();return cd(Zc(Gg,1),Qo,30,0,[Co,Eo,Do])}
function Ul(a,b){uo((fn(),en),b);A((J(),J(),I),new cm(a,b),fp)}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function ih(a){function b(){}
;b.prototype=a||{};return new b}
function Bh(a){if(a.N()){return null}var b=a.j;return bh[b]}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function oj(a){if(a.b){oj(a.b)}else if(a.c){throw Sg(new Gh)}}
function cc(a){fb(a.c);return new wj(null,new ij(new hi(a.g),0))}
function kn(a,b){b.preventDefault();A((J(),J(),I),new zn(a),fp)}
function Di(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ah(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.I(b))}
function eh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Ei(a,b){var c;return Ci(b,Di(a,b==null?0:(c=s(b),c|0)))}
function ui(a){ki(this);Nj(this.a,Vh(a,_c(ie,Qo,1,ai(a.a),5,1)))}
function ko(a){this.b=a;J();this.a=new oc(0,null,null,false,false)}
function Ii(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Ej(a,b){cj.call(this,b.bb(),b.ab()&-6);this.a=a;this.b=b}
function mc(a){kc(a.g);!!a.e&&lc(a);Y(a.a);Y(a.c);kc(a.b);kc(a.f)}
function hn(a){oh((nh(),$wnd.goog.global.window),ip,a.d,false)}
function jn(a){ph((nh(),$wnd.goog.global.window),ip,a.d,false)}
function Tl(a){return rh(),ro((fn(),en))==a.f.props['a']?true:false}
function ej(a,b){if(a.c<a.d){fj(a,b,a.c++);return true}return false}
function sk(a){a.placeholder='What needs to be done?';return a}
function uc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ic(a,b,c){var d;d=Gc();try{return Fc(a,b,c)}finally{Jc(d)}}
function gk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function bb(a,b){var c,d;li(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Bj(a,b){cj.call(this,b.bb(),b.ab()&-16449);this.a=a;this.c=b}
function Bm(a){$wnd.React.Component.call(this,a);this.a=new ll(this)}
function xm(a){$wnd.React.Component.call(this,a);this.a=new cl(this)}
function Fm(a){$wnd.React.Component.call(this,a);this.a=new Al(this)}
function Jm(a){$wnd.React.Component.call(this,a);this.a=new $l(this)}
function Nm(a){$wnd.React.Component.call(this,a);this.a=new nm(this)}
function Wi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function jj(a,b){!a.a?(a.a=new Rh(a.d)):Ph(a.a,a.b);Ph(a.a,b);return a}
function uj(a,b){var c;nj(a);c=new Hj;c.a=b;a.a.V(new Kj(c));return c.a}
function rj(a){var b;nj(a);b=0;while(a.a.cb(new Ij)){b=Tg(b,1)}return b}
function ho(a){qj(sj(cc(a.b),new Jo),new mj(new lj)).O(new Ko(a.b))}
function fn(){fn=gh;cn=new Vn;dn=new ko(cn);bn=new tn;en=new vo(cn,bn)}
function Qn(a,b){var c;return u((J(),J(),I),new Zn(a,b),fp,(c=null,c))}
function vj(a,b){var c;c=qj(a,new mj(new lj));return si(c,b.db(c.a.length))}
function Hc(b){Ec();return function(){return Ic(b,this,arguments);var a}}
function Ac(){if(Date.now){return Date.now()}return (new Date).getTime()}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function $h(a,b){return pd(b)?b==null?Gi(a.a,null):Ui(a.b,b):Gi(a.a,b)}
function po(a,b){return (Fo(),Do)==a||(Co==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function Pj(a,b){return $c(b)!=10&&cd(r(b),b.mb,b.__elementTypeId$,$c(b),a),a}
function gn(a,b){a.f=b;o(b,S(a.a))&&sn(a,b);ln(b);A((J(),J(),I),new zn(a),fp)}
function Ib(b){try{mb(b.b.a)}catch(a){a=Rg(a);if(!ld(a,4))throw Sg(a)}}
function Jc(a){a&&Qc((Oc(),Nc));--Bc;if(a){if(Dc!=-1){Lc(Dc);Dc=-1}}}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function oi(a,b,c){for(;c<a.a.length;++c){if(Ai(b,a.a[c])){return c}}return -1}
function Xi(a){if(a.a.c!=a.c){return Si(a.a,a.b.value[0])}return a.b.value[1]}
function En(a,b){var c;if(ld(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function qi(a,b){var c;c=oi(a,b,0);if(c==-1){return false}Oj(a.a,c);return true}
function _c(a,b,c,d,e,f){var g;g=ad(e,d);e!=10&&cd(Zc(a,f),b,c,e,g);return g}
function mi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Ob(){var a;this.a=_c(wd,Qo,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function fi(a){this.d=a;this.c=new Wi(this.d.b);this.a=this.c;this.b=di(this)}
function kj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Zh(a,b,c){return pd(b)?b==null?Fi(a.a,null,c):Ti(a.b,b,c):Fi(a.a,b,c)}
function dk(a){var b;return bk($wnd.React.StrictMode,null,null,(b={},b[bp]=a,b))}
function so(a){var b;return b=S(a.b),qj(sj(cc(a.i),new Mo(b)),new mj(new lj))}
function pl(a){var b;b=Oh((fb(a.b),a.f));if(b.length>0){co((fn(),dn),b);zl(a,'')}}
function ql(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Dl(a),fp)}}
function jc(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new pc(a)),67108864,null)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function V(a){if(a.b){if(ld(a.b,8)){throw Sg(a.b)}else{throw Sg(a.b)}}return a.n}
function Ym(a,b){ak(a.a,(b?Ih(b.c.d):null)+(''+(th(Yf),Yf.k)));_j(a.a,b);return a.a}
function wh(a){var b;b=new vh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Pc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Tc(b,c)}while(a.a);a.a=c}}
function Qc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Tc(b,c)}while(a.b);a.b=c}}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new ti);li(a.b,b)}}}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new ti);a.c=c.c}b.d=true;li(a.c,b)}
function Eh(a,b){var c;if(!a){return}b.j=a;var d=Bh(b);if(!d){bh[a]=[b];return}d.lb=b}
function rb(b){if(b){try{b.v()}catch(a){a=Rg(a);if(ld(a,4)){J()}else throw Sg(a)}}}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function dc(a){return fb(a.c),qj(new wj(null,new ij(new hi(a.g),0)),new mj(new lj))}
function $c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===Oo||typeof a==='function')&&!(a.nb===kh)}
function ah(a,b){typeof window===Oo&&typeof window['$gwt']===Oo&&(window['$gwt'][a]=b)}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Wo:0)|(0!=(b&229376)?0:98304)}
function Ui(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ji(a.a,b);--a.b}return c}
function hh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function bk(a,b,c,d){var e;e=ck($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function ek(a){var b;b=ck($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function yi(a){var b,c,d;d=0;for(c=new fi(a.a);c.b;){b=ei(c);d=d+(b?s(b):0);d=d|0}return d}
function Uh(a,b){var c,d;for(d=new fi(b.a);d.b;){c=ei(d);if(!bi(a,c)){return false}}return true}
function ob(a){var b,c;for(c=new vi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Zg(){$g();var a=Yg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Gh(){vc.call(this,"Stream already terminated, can't be modified or used")}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:So)|(0==(c&6291456)?!a?Vo:Wo:0)|0|0|0)}
function bc(a,b,c){var d;d=$h(a.g,b?Ih(b.c.d):null);if(null!=d){nc(b.c,a);c&&!!b&&jc(b.c);eb(a.c)}}
function On(a,b,c){var d;d=new Ln(b,c);Dn(d,a,new hc(a,d));Zh(a.g,Ih(d.c.d),d);eb(a.c);return d}
function to(a){var b;b=S(a.g.a);o(kp,b)||o(lp,b)||o('',b)?on(a.g,b):oo(pn(a.g))?rn(a.g):on(a.g,'')}
function Ug(a){var b;b=a.h;if(b==0){return a.l+a.m*Wo}if(b==1048575){return a.l+a.m*Wo-$o}return a}
function Rg(a){var b;if(ld(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new zc(a);Wc(b)}return b}
function di(a){if(a.a.W()){return true}if(a.a!=a.c){return false}a.a=new Ii(a.d.a);return a.a.W()}
function bj(a,b){if(0>a||a>b){throw Sg(new qh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Fo(){Fo=gh;Co=new Go('ACTIVE',0);Eo=new Go('COMPLETED',1);Do=new Go('ALL',2)}
function lh(){fn();$wnd.ReactDOM.render(dk([(new an).a]),(nh(),mh).getElementById('app'),null)}
function zc(a){xc();qc(this);this.e=a;rc(this,a);this.g=a==null?Zo:jh(a);this.a='';this.b=a;this.a=''}
function vh(){this.g=sh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Ti(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function cd(a,b,c,d,e){e.lb=a;e.mb=b;e.nb=kh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ci(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ai(a,c.Z())){return c}}return null}
function Wg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=$o;d=1048575}c=rd(e/Wo);b=rd(e-c*Wo);return dd(b,c,d)}
function Ih(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Kh(),Jh)[b];!c&&(c=Jh[b]=new Hh(a));return c}return new Hh(a)}
function jh(a){var b;if(Array.isArray(a)&&a.nb===kh){return uh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function uo(a,b){var c;c=a.e;if(!(b==c||!!b&&En(b,c))){!!c&&nc(c.c,a);a.e=b;!!b&&Dn(b,a,new xo(a));eb(a.d)}}
function cb(a,b){var c,d;d=a.c;qi(d,b);!!a.b&&So!=(a.b.c&To)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function Jl(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){io((fn(),b),c);uo(en,null);Zl(a,c)}else{Rn((fn(),cn),b)}}
function Kl(a){var b;b=S(a.c);if(!a.j&&b){a.j=true;Yl(a,a.f.props['a']);a.i.focus();a.i.select()}else a.j&&!b&&(a.j=false)}
function ll(a){var b;this.c=a;J();b=++jl;this.b=new oc(b,null,new ml(this),false,false);this.a=new vb(null,new nl(this),ep)}
function nm(a){var b;this.c=a;J();b=++lm;this.b=new oc(b,null,new om(this),false,false);this.a=new vb(null,new pm(this),ep)}
function Il(a,b,c){27==c.which?A((J(),J(),I),new fm(a,b),fp):13==c.which&&A((J(),J(),I),new dm(a,b),fp)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function Wk(){if(!Vk){Vk=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(hh(Xk.prototype.H,Xk,[]))}}
function Uk(){Sk();return cd(Zc(bf,1),Qo,6,0,[wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk])}
function r(a){return pd(a)?le:nd(a)?ae:md(a)?$d:kd(a)?a.lb:bd(a)?a.lb:a.lb||Array.isArray(a)&&Zc(Sd,1)||Sd}
function s(a){return pd(a)?Xj(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.q():bd(a)?Rj(a):!!a&&!!a.hashCode?a.hashCode():Rj(a)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&So)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(So==(b&To)?0:524288)|(0==(b&6291456)?So==(b&To)?Wo:Vo:0)|0|268435456|0)}
function Xj(a){Vj();var b,c,d;c=':'+a;d=Uj[c];if(d!=null){return rd(d)}d=Sj[c];b=d==null?Wj(a):rd(d);Yj();Uj[c]=b;return b}
function zi(a){var b,c,d;d=1;for(c=new vi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function lc(a){var b,c,d;for(c=new vi(new ui(new ci(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.Z();ld(d,9)&&d.u()||b.$().v()}}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=pi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function si(a,b){var c,d;d=a.a.length;b.length<d&&(b=Pj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Dh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Tg(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<$o){return c}}return Ug(ed(nd(a)?Wg(a):a,nd(b)?Wg(b):b))}
function Gc(){var a;if(Bc!=0){a=Ac();if(a-Cc>2000){Cc=a;Dc=$wnd.setTimeout(Mc,10)}}if(Bc++==0){Pc((Oc(),Nc));return true}return false}
function Xc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return pd(a)?o(a,b):nd(a)?qd(a)===qd(b):md(a)?qd(a)===qd(b):kd(a)?a.o(b):bd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.mb){return !!a.mb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function oc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Bi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Al(a){var b,c,d;this.d=a;J();b=++ul;this.c=new oc(b,null,new Bl(this),false,false);this.b=(d=new ib((c=null,c)),d);this.a=new vb(null,new El(this),ep)}
function jk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new vi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new vi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new vi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Oh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Vh(a,b){var c,d,e,f;f=ai(a.a);b.length<f&&(b=Pj(new Array(f),b));e=b;d=new fi(a.a);for(c=0;c<f;++c){e[c]=ei(d)}b.length>f&&(b[f]=null);return b}
function ad(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=Rg(a);if(ld(a,4)){e=a;throw Sg(e)}else throw Sg(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=Rg(a);if(ld(a,4)){f=a;throw Sg(f)}else throw Sg(a)}finally{D(b)}}
function cl(a){var b;this.d=a;J();b=++_k;this.c=new oc(b,null,new dl(this),false,false);this.a=new W(new el,null,null,136478720);this.b=new vb(null,new gl(this),ep)}
function Ln(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++Bn;this.c=new oc(c,null,new Mn(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function _g(b,c,d,e){$g();var f=Yg;$moduleName=c;$moduleBase=d;Qg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{No(g)()}catch(a){b(c,a)}}else{No(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);So==(d&To)&&lb(this.f)}
function ck(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Oi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Pi()}}
function dh(){bh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Tc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].ob()&&(c=Sc(c,g)):g[0].ob()}catch(a){a=Rg(a);if(ld(a,4)){d=a;Ec();Kc(ld(d,34)?d.G():d)}else throw Sg(a)}}return c}
function sl(a){var b;a.e=0;Wk();b=fk(gp,nk(qk(rk(uk(sk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['new-todo']))),(fb(a.b),a.f)),hh(Om.prototype.ib,Om,[a])),hh(Pm.prototype.hb,Pm,[a]))),null);return b}
function yc(a){var b;if(a.c==null){b=qd(a.b)===qd(wc)?null:a.b;a.d=b==null?Zo:od(b)?b==null?null:b.name:pd(b)?'String':uh(r(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(qd(e)===qd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=Rg(a);if(ld(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw Sg(c)}else throw Sg(a)}}
function Fi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ci(b,e);if(f){return f._(c)}}e[e.length]=new ji(b,c);++a.b;return null}
function Lj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Wj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Mh(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Rg(a);if(ld(a,4)){J()}else throw Sg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=_c(ie,Qo,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function ub(a,b,c,d){this.b=new ti;this.f=new Jb(new yb(this),d&6520832|262144|So);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Vo)&&D((null,I)))}
function Gi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ai(b,e.Z())){if(d.length==1){d.length=0;Ji(a.a,g)}else{d.splice(h,1)}--a.b;return e.$()}}return null}
function $l(a){var b,c,d;this.f=a;J();b=++Pl;this.e=new oc(b,null,new _l(this),false,false);this.a=(d=new ib((c=null,c)),d);this.c=new W(new bm(this),null,null,136478720);this.b=new vb(null,new gm(this),ep);Yl(this,this.f.props['a'])}
function fh(a,b,c){var d=bh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=bh[b]),ih(h));_.mb=c;!b&&(_.nb=kh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.lb=f)}
function Ch(a){if(a.M()){var b=a.c;b.N()?(a.k='['+b.j):!b.M()?(a.k='[L'+b.K()+';'):(a.k='['+b.K());a.b=b.J()+'[]';a.i=b.L()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Dh('.',[c,Dh('$',d)]);a.b=Dh('.',[c,Dh('.',d)]);a.i=d[d.length-1]}
function Wh(a,b){var c,d,e;c=b.Z();e=b.$();d=pd(c)?c==null?Yh(Ei(a.a,null)):Si(a.b,c):Yh(Ei(a.a,c));if(!(qd(e)===qd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Ei(a.a,null):Ri(a.b,c):!!Ei(a.a,c))){return false}return true}
function ln(a){var b;if(0==a.length){b=(nh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',mh.title,b)}else{(nh(),$wnd.goog.global.window).location.hash=a}}
function fk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;$j(b,hh(ik.prototype.fb,ik,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[bp]=c[0],undefined):(d[bp]=c,undefined));return bk(a,e,f,d)}
function vo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new oc(0,null,new wo(this),false,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new yo(this),null,null,jp);this.c=new W(new zo(this),null,null,jp);this.a=new vb(new Ao(this),null,681574400);D((null,I))}
function Vn(){var a;this.g=new Bi;J();this.f=new oc(0,new Xn(this),new Wn(this),false,false);this.c=(a=new ib(null),a);this.d=new W(new $n(this),null,null,jp);this.e=new W(new _n(this),null,null,jp);this.a=new W(new ao(this),null,null,jp);this.b=new W(new bo(this),null,null,jp)}
function tn(){var a,b,c;this.d=new Bo(this);this.f=this.e=(c=(nh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new oc(0,null,new un(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new An,new vn(this),new wn(this),35651584)}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new vi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Rg(a);if(!ld(a,4))throw Sg(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function rc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.C();return a&&a.A()}},suppressed:{get:function(){return c.B()}}})}catch(a){}}}
function Ni(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}mi(a.b,new Ab(a));a.b.a=_c(ie,Qo,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Sk(){Sk=gh;wk=new Tk(cp,0);xk=new Tk('checkbox',1);yk=new Tk('color',2);zk=new Tk('date',3);Ak=new Tk('datetime',4);Bk=new Tk('email',5);Ck=new Tk('file',6);Dk=new Tk('hidden',7);Ek=new Tk('image',8);Fk=new Tk('month',9);Gk=new Tk(Po,10);Hk=new Tk('password',11);Ik=new Tk('radio',12);Jk=new Tk('range',13);Kk=new Tk('reset',14);Lk=new Tk('search',15);Mk=new Tk('submit',16);Nk=new Tk('tel',17);Ok=new Tk('text',18);Pk=new Tk('time',19);Qk=new Tk('url',20);Rk=new Tk('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ni(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ri(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ni(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){pi(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new ti)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&So!=(k.b.c&To)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function Zk(a){var b,c;a.e=0;Wk();c=(b=S((fn(),en).b),fk('footer',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['footer'])),[(new tm).a,fk('ul',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['filters'])),[fk('li',null,[fk('a',lk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[(Fo(),Do)==b?dp:null])),'#'),['All'])]),fk('li',null,[fk('a',lk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[Co==b?dp:null])),'#active'),['Active'])]),fk('li',null,[fk('a',lk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[Eo==b?dp:null])),'#completed'),['Completed'])])]),S(a.a)?fk(cp,mk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['clear-completed'])),hh(rm.prototype.jb,rm,[])),['Clear Completed']):null]));return c}
function Nl(a){var b,c,d,e;a.g=0;Wk();b=a.f.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.f.props['a'],e=(fb(d.a),d.d),fk('li',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[e?'checked':null,S(a.c)?'editing':null])),[fk('div',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['view'])),[fk(gp,qk(ok(tk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['toggle'])),(Sk(),xk)),e),hh(Sm.prototype.hb,Sm,[d])),null),fk('label',vk(new $wnd.Object,hh(Tm.prototype.jb,Tm,[a,d])),[(fb(d.b),d.e)]),fk(cp,mk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['destroy'])),hh(Um.prototype.jb,Um,[d])),null)]),fk(gp,rk(qk(pk(uk(jk(kk(new $wnd.Object,hh(Vm.prototype.w,Vm,[a])),cd(Zc(le,1),Qo,2,6,['edit'])),(fb(a.a),a.d)),hh(Wm.prototype.gb,Wm,[a,d])),hh(Rm.prototype.hb,Rm,[a])),hh(Xm.prototype.ib,Xm,[a,d])),null)]));return c}
function Pi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[ap]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ni()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[ap]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Oo='object',Po='number',Qo={3:1},Ro={9:1},So=1048576,To=1835008,Uo={5:1},Vo=2097152,Wo=4194304,Xo='__noinit__',Yo={3:1,10:1,8:1,4:1},Zo='null',$o=17592186044416,_o={40:1},ap='delete',bp='children',cp='button',dp='selected',ep=1411518464,fp=142606336,gp='input',hp='header',ip='hashchange',jp=136314880,kp='active',lp='completed';var _,bh,Yg,Qg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;dh();fh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.lb};_.q=np;_.r=function(){var a;return uh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var fd,gd,hd;fh(50,1,{},vh);_.I=function(a){var b;b=new vh;b.e=4;a>1?(b.c=Ah(this,a-1)):(b.c=this);return b};_.J=function(){th(this);return this.b};_.K=function(){return uh(this)};_.L=function(){th(this);return this.i};_.M=function(){return (this.e&4)!=0};_.N=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(th(this),this.k)};_.e=0;_.g=0;var sh=1;var ie=xh(1);var _d=xh(50);fh(78,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var vd=xh(78);fh(35,1,{},G);_.s=function(){return this.a.v(),null};var td=xh(35);fh(79,1,{},H);var ud=xh(79);var I;fh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var wd=xh(43);fh(213,1,Ro);_.r=function(){var a;return uh(this.lb)+'@'+(a=s(this)>>>0,a.toString(16))};var zd=xh(213);fh(18,213,Ro,W);_.t=function(){R(this)};_.u=mp;_.a=false;_.d=0;_.k=false;var yd=xh(18);fh(122,1,{},X);_.s=function(){return T(this.a)};var xd=xh(122);fh(15,213,{9:1,15:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Bd=xh(15);fh(121,1,Uo,jb);_.v=function(){ab(this.a)};var Ad=xh(121);fh(16,213,{9:1,16:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Gd=xh(16);fh(123,1,{},xb);_.v=function(){Q(this.a)};var Cd=xh(123);fh(124,1,Uo,yb);_.v=function(){mb(this.a)};var Dd=xh(124);fh(125,1,Uo,zb);_.v=function(){pb(this.a)};var Ed=xh(125);fh(126,1,{},Ab);_.w=function(a){nb(this.a,a)};var Fd=xh(126);fh(131,1,{},Db);_.a=0;_.b=0;_.c=0;var Hd=xh(131);fh(158,1,Ro,Fb);_.t=function(){Eb(this)};_.u=mp;_.a=false;var Id=xh(158);fh(58,213,{9:1,58:1},Jb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Kd=xh(58);fh(136,1,{},Ob);var Jd=xh(136);fh(138,1,{},$b);_.r=function(){var a;return th(Ld),Ld.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.a=0;var Pb;var Ld=xh(138);fh(109,1,{});var Od=xh(109);fh(81,1,{},gc);_.w=function(a){ec(this.a,a)};var Md=xh(81);fh(82,1,Uo,hc);_.v=function(){fc(this.a,this.b)};var Nd=xh(82);fh(14,1,Ro,oc);_.t=function(){jc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return th(Qd),Qd.k+'@'+(a=Rj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Qd=xh(14);fh(120,1,Uo,pc);_.v=function(){mc(this.a)};var Pd=xh(120);fh(4,1,{3:1,4:1});_.A=sp;_.B=function(){return vj(tj(xi((this.i==null&&(this.i=_c(ne,Qo,4,0,0,1)),this.i)),new Sh),new zj)};_.C=function(){return this.f};_.D=function(){return this.g};_.F=function(){sc(this,uc(new Error(tc(this,this.g))));Wc(this)};_.r=function(){return tc(this,this.D())};_.e=Xo;_.j=true;var ne=xh(4);fh(10,4,{3:1,10:1,4:1});var ce=xh(10);fh(8,10,Yo);var je=xh(8);fh(71,8,Yo);var ge=xh(71);fh(72,71,Yo);var Ud=xh(72);fh(34,72,{34:1,3:1,10:1,8:1,4:1},zc);_.D=function(){yc(this);return this.c};_.G=function(){return qd(this.b)===qd(wc)?null:this.b};var wc;var Rd=xh(34);var Sd=xh(0);fh(199,1,{});var Td=xh(199);var Bc=0,Cc=0,Dc=-1;fh(108,199,{},Rc);var Nc;var Vd=xh(108);var Uc;fh(210,1,{});var Xd=xh(210);fh(73,210,{},Yc);var Wd=xh(73);var mh;fh(69,1,{66:1});_.r=mp;var Yd=xh(69);fh(75,8,Yo);var ee=xh(75);fh(154,75,Yo,qh);var Zd=xh(154);fd={3:1,67:1,27:1};var $d=xh(67);fh(41,1,{3:1,41:1});var he=xh(41);gd={3:1,27:1,41:1};var ae=xh(209);fh(29,1,{3:1,27:1,29:1});_.o=function(a){return this===a};_.q=np;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=xh(29);fh(74,8,Yo,Gh);var de=xh(74);fh(28,41,{3:1,27:1,28:1,41:1},Hh);_.o=function(a){return ld(a,28)&&a.a==this.a};_.q=mp;_.r=function(){return ''+this.a};_.a=0;var fe=xh(28);var Jh;fh(276,1,{});hd={3:1,66:1,27:1,2:1};var le=xh(2);fh(70,69,{66:1},Rh);var ke=xh(70);fh(280,1,{});fh(64,1,{},Sh);_.Q=function(a){return a.e};var me=xh(64);fh(52,8,Yo,Th);var oe=xh(52);fh(211,1,{39:1});_.O=rp;_.T=function(){return new ij(this,0)};_.U=function(){return new wj(null,this.T())};_.R=function(a){throw Sg(new Th('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new kj('[',']');for(b=this.P();b.W();){a=b.X();jj(c,a===this?'(this Collection)':a==null?Zo:jh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=xh(211);fh(214,1,{197:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ld(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new fi((new ci(d)).a);c.b;){b=ei(c);if(!Wh(this,b)){return false}}return true};_.q=function(){return yi(new ci(this))};_.r=function(){var a,b,c;c=new kj('{','}');for(b=new fi((new ci(this)).a);b.b;){a=ei(b);jj(c,Xh(this,a.Z())+'='+Xh(this,a.$()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=xh(214);fh(127,214,{197:1});var se=xh(127);fh(215,211,{39:1,224:1});_.T=function(){return new ij(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ld(a,21)){return false}b=a;if(ai(b.a)!=this.S()){return false}return Uh(this,b)};_.q=function(){return yi(this)};var Be=xh(215);fh(21,215,{21:1,39:1,224:1},ci);_.P=function(){return new fi(this.a)};_.S=pp;var re=xh(21);fh(22,1,{},fi);_.V=op;_.X=function(){return ei(this)};_.W=qp;_.b=false;var qe=xh(22);fh(212,211,{39:1,221:1});_.T=function(){return new ij(this,16)};_.Y=function(a,b){throw Sg(new Th('Add not supported on this list'))};_.R=function(a){this.Y(this.S(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,13)){return false}f=a;if(this.S()!=f.a.length){return false}e=new vi(f);for(c=new vi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return zi(this)};_.P=function(){return new gi(this)};var ue=xh(212);fh(107,1,{},gi);_.V=op;_.W=function(){return this.a<this.b.a.length};_.X=function(){return ni(this.b,this.a++)};_.a=0;var te=xh(107);fh(42,211,{39:1},hi);_.P=function(){var a;a=new fi((new ci(this.a)).a);return new ii(a)};_.S=pp;var we=xh(42);fh(130,1,{},ii);_.V=op;_.W=function(){return this.a.b};_.X=function(){var a;a=ei(this.a);return a.$()};var ve=xh(130);fh(128,1,_o);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Ai(this.a,b.Z())&&Ai(this.b,b.$())};_.Z=mp;_.$=qp;_.q=function(){return _i(this.a)^_i(this.b)};_._=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var xe=xh(128);fh(129,128,_o,ji);var ye=xh(129);fh(216,1,_o);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Ai(this.b.value[0],b.Z())&&Ai(Xi(this),b.$())};_.q=function(){return _i(this.b.value[0])^_i(Xi(this))};_.r=function(){return this.b.value[0]+'='+Xi(this)};var ze=xh(216);fh(13,212,{3:1,13:1,39:1,221:1},ti,ui);_.Y=function(a,b){Mj(this.a,a,b)};_.R=function(a){return li(this,a)};_.O=function(a){mi(this,a)};_.P=function(){return new vi(this)};_.S=function(){return this.a.length};var De=xh(13);fh(17,1,{},vi);_.V=op;_.W=function(){return this.a<this.c.a.length};_.X=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=xh(17);fh(36,127,{3:1,36:1,197:1},Bi);var Ee=xh(36);fh(56,1,{},Hi);_.O=rp;_.P=function(){return new Ii(this)};_.b=0;var Ge=xh(56);fh(57,1,{},Ii);_.V=op;_.X=function(){return this.d=this.a[this.c++],this.d};_.W=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=xh(57);var Li;fh(54,1,{},Vi);_.O=rp;_.P=function(){return new Wi(this)};_.b=0;_.c=0;var Je=xh(54);fh(55,1,{},Wi);_.V=op;_.X=function(){return this.c=this.a,this.a=this.b.next(),new Yi(this.d,this.c,this.d.c)};_.W=function(){return !this.a.done};var He=xh(55);fh(137,216,_o,Yi);_.Z=function(){return this.b.value[0]};_.$=function(){return Xi(this)};_._=function(a){return Ti(this.a,this.b.value[0],a)};_.c=0;var Ie=xh(137);fh(140,1,{});_.V=tp;_.ab=function(){return this.d};_.bb=sp;_.d=0;_.e=0;var Ne=xh(140);fh(59,140,{});var Ke=xh(59);fh(132,1,{});_.V=tp;_.ab=qp;_.bb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Me=xh(132);fh(133,132,{},gj);_.V=function(a){dj(this,a)};_.cb=function(a){return ej(this,a)};var Le=xh(133);fh(19,1,{},ij);_.ab=mp;_.bb=function(){hj(this);return this.c};_.V=function(a){hj(this);this.d.V(a)};_.cb=function(a){hj(this);if(this.d.W()){a.w(this.d.X());return true}return false};_.a=0;_.c=0;var Oe=xh(19);fh(51,1,{},kj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Pe=xh(51);fh(33,1,{},lj);_.Q=function(a){return a};var Qe=xh(33);fh(37,1,{},mj);var Re=xh(37);fh(139,1,{});_.c=false;var _e=xh(139);fh(23,139,{},wj);var $e=xh(23);fh(65,1,{},zj);_.db=function(a){return _c(ie,Qo,1,a,5,1)};var Se=xh(65);fh(142,59,{},Bj);_.cb=function(a){this.b=false;while(!this.b&&this.c.cb(new Cj(this,a)));return this.b};_.b=false;var Ue=xh(142);fh(145,1,{},Cj);_.w=function(a){Aj(this.a,this.b,a)};var Te=xh(145);fh(141,59,{},Ej);_.cb=function(a){return this.b.cb(new Fj(this,a))};var We=xh(141);fh(144,1,{},Fj);_.w=function(a){Dj(this.a,this.b,a)};var Ve=xh(144);fh(143,1,{},Hj);_.w=function(a){Gj(this,a)};var Xe=xh(143);fh(146,1,{},Ij);_.w=function(a){};var Ye=xh(146);fh(147,1,{},Kj);_.w=function(a){Jj(this,a)};var Ze=xh(147);fh(278,1,{});fh(275,1,{});var Qj=0;var Sj,Tj=0,Uj;fh(894,1,{});fh(916,1,{});fh(155,1,{},hk);_.db=function(a){return new Array(a)};var af=xh(155);fh(243,$wnd.Function,{},ik);_.fb=function(a){gk(this.a,this.b,a)};fh(6,29,{3:1,27:1,29:1,6:1},Tk);var wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk;var bf=yh(6,Uk);var Vk;fh(244,$wnd.Function,{},Xk);_.H=function(a){return Eb(Vk),Vk=null,null};fh(219,1,{});var Kf=xh(219);fh(171,219,{});_.e=0;var Of=xh(171);fh(172,171,Ro,cl);_.t=up;_.u=vp;_.r=function(){var a;return th(lf),lf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var _k=0;var lf=xh(172);fh(173,1,Uo,dl);_.v=function(){al(this.a)};var cf=xh(173);fh(174,1,{},el);_.s=function(){return rh(),S((fn(),cn).b).a>0?true:false};var df=xh(174);fh(176,1,{},fl);_.s=function(){return Zk(this.a)};var ef=xh(176);fh(175,1,{},gl);_.v=function(){$k(this.a)};var ff=xh(175);fh(220,1,{});var Jf=xh(220);fh(191,220,{});_.d=0;var Nf=xh(191);fh(192,191,Ro,ll);_.t=wp;_.u=xp;_.r=function(){var a;return th(kf),kf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var jl=0;var kf=xh(192);fh(193,1,Uo,ml);_.v=yp;var gf=xh(193);fh(194,1,{},nl);_.v=function(){il(this.a)};var hf=xh(194);fh(195,1,{},ol);_.s=function(){var a;return this.a.d=0,Wk(),a=S((fn(),cn).e).a,fk('span',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['todo-count'])),[fk('strong',null,[a]),' item'+(a==1?'':'s')+' left'])};var jf=xh(195);fh(163,1,{});_.f='';var Wf=xh(163);fh(164,163,{});_.e=0;var Qf=xh(164);fh(165,164,Ro,Al);_.t=up;_.u=vp;_.r=function(){var a;return th(rf),rf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var ul=0;var rf=xh(165);fh(166,1,Uo,Bl);_.v=function(){vl(this.a)};var mf=xh(166);fh(168,1,{},Cl);_.s=function(){return sl(this.a)};var nf=xh(168);fh(169,1,Uo,Dl);_.v=function(){pl(this.a)};var of=xh(169);fh(167,1,{},El);_.v=function(){$k(this.a)};var pf=xh(167);fh(170,1,Uo,Fl);_.v=function(){yl(this.a,this.b)};var qf=xh(170);fh(218,1,{});_.j=false;var Yf=xh(218);fh(178,218,{});_.g=0;var Sf=xh(178);fh(179,178,Ro,$l);_.t=function(){jc(this.e)};_.u=function(){return this.e.i<0};_.r=function(){var a;return th(Cf),Cf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var Pl=0;var Cf=xh(179);fh(180,1,Uo,_l);_.v=function(){Ql(this.a)};var sf=xh(180);fh(183,1,{},am);_.s=function(){return Nl(this.a)};var tf=xh(183);fh(181,1,{},bm);_.s=function(){return Tl(this.a)};var uf=xh(181);fh(60,1,Uo,cm);_.v=function(){Zl(this.a,pn(this.b))};var vf=xh(60);fh(61,1,Uo,dm);_.v=function(){Jl(this.a,this.b)};var wf=xh(61);fh(184,1,Uo,em);_.v=function(){Ul(this.a,this.b)};var xf=xh(184);fh(185,1,Uo,fm);_.v=function(){Yl(this.a,this.b);uo((fn(),en),null)};var yf=xh(185);fh(182,1,{},gm);_.v=function(){Ol(this.a)};var zf=xh(182);fh(186,1,Uo,hm);_.v=function(){Gl(this.a,this.b)};var Af=xh(186);fh(187,1,Uo,im);_.v=function(){Kl(this.a)};var Bf=xh(187);fh(217,1,{});var _f=xh(217);fh(149,217,{});_.d=0;var Uf=xh(149);fh(150,149,Ro,nm);_.t=wp;_.u=xp;_.r=function(){var a;return th(Gf),Gf.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var lm=0;var Gf=xh(150);fh(151,1,Uo,om);_.v=yp;var Df=xh(151);fh(152,1,{},pm);_.v=function(){il(this.a)};var Ef=xh(152);fh(153,1,{},qm);_.s=function(){return this.a.d=0,Wk(),fk('div',null,[fk('div',null,[fk(hp,jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[hp])),[fk('h1',null,['todos']),(new Qm).a]),S((fn(),cn).d)?fk('section',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,[hp])),[fk(gp,qk(tk(jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['toggle-all'])),(Sk(),xk)),hh($m.prototype.hb,$m,[])),null),fk('ul',jk(new $wnd.Object,cd(Zc(le,1),Qo,2,6,['todo-list'])),vj(tj(S(en.c).U(),new _m),new hk))]):null,S(cn.d)?(new sm).a:null])])};var Ff=xh(153);fh(248,$wnd.Function,{},rm);_.jb=function(a){fo((fn(),dn))};fh(157,1,{},sm);var Hf=xh(157);fh(177,1,{},tm);var If=xh(177);fh(249,$wnd.Function,{},um);_.kb=function(a){return new xm(a)};var vm;fh(161,$wnd.React.Component,{},xm);eh(bh[1],_);_.componentWillUnmount=function(){Yk(this.a)};_.render=function(){return bl(this.a)};_.shouldComponentUpdate=zp;var Lf=xh(161);fh(259,$wnd.Function,{},ym);_.kb=function(a){return new Bm(a)};var zm;fh(188,$wnd.React.Component,{},Bm);eh(bh[1],_);_.componentWillUnmount=function(){hl(this.a)};_.render=function(){return kl(this.a)};_.shouldComponentUpdate=Ap;var Mf=xh(188);fh(247,$wnd.Function,{},Cm);_.kb=function(a){return new Fm(a)};var Dm;fh(160,$wnd.React.Component,{},Fm);eh(bh[1],_);_.componentWillUnmount=function(){Yk(this.a)};_.render=function(){return wl(this.a)};_.shouldComponentUpdate=zp;var Pf=xh(160);fh(250,$wnd.Function,{},Gm);_.kb=function(a){return new Jm(a)};var Hm;fh(162,$wnd.React.Component,{},Jm);eh(bh[1],_);_.componentDidUpdate=function(a){Xl(this.a)};_.componentWillUnmount=function(){Ml(this.a)};_.render=function(){return Rl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.g};var Rf=xh(162);fh(241,$wnd.Function,{},Km);_.kb=function(a){return new Nm(a)};var Lm;fh(134,$wnd.React.Component,{},Nm);eh(bh[1],_);_.componentWillUnmount=function(){hl(this.a)};_.render=function(){return mm(this.a)};_.shouldComponentUpdate=Ap;var Tf=xh(134);fh(245,$wnd.Function,{},Om);_.ib=function(a){ql(this.a,a)};fh(246,$wnd.Function,{},Pm);_.hb=function(a){xl(this.a,a)};fh(156,1,{},Qm);var Vf=xh(156);fh(257,$wnd.Function,{},Rm);_.hb=function(a){Sl(this.a,a)};fh(251,$wnd.Function,{},Sm);_.hb=function(a){Kn(this.a)};fh(253,$wnd.Function,{},Tm);_.jb=function(a){Vl(this.a,this.b)};fh(254,$wnd.Function,{},Um);_.jb=function(a){Ll(this.a)};fh(255,$wnd.Function,{},Vm);_.w=function(a){Hl(this.a,a)};fh(256,$wnd.Function,{},Wm);_.gb=function(a){Wl(this.a,this.b)};fh(258,$wnd.Function,{},Xm);_.ib=function(a){Il(this.a,this.b,a)};fh(159,1,{},Zm);var Xf=xh(159);fh(240,$wnd.Function,{},$m);_.hb=function(a){var b;b=a.target;jo((fn(),dn),b.checked)};fh(135,1,{},_m);_.Q=function(a){return Ym(new Zm,a)};var Zf=xh(135);fh(63,1,{},an);var $f=xh(63);var bn,cn,dn,en;fh(92,1,{});var Fg=xh(92);fh(93,92,Ro,tn);_.t=up;_.u=vp;_.r=function(){var a;return th(hg),hg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var hg=xh(93);fh(94,1,Uo,un);_.v=function(){nn(this.a)};var ag=xh(94);fh(96,1,{},vn);_.v=function(){hn(this.a)};var bg=xh(96);fh(97,1,{},wn);_.v=function(){jn(this.a)};var cg=xh(97);fh(98,1,Uo,xn);_.v=function(){gn(this.a,this.b)};var dg=xh(98);fh(99,1,Uo,yn);_.v=function(){qn(this.a)};var eg=xh(99);fh(53,1,Uo,zn);_.v=function(){mn(this.a)};var fg=xh(53);fh(95,1,{},An);_.s=function(){var a;return a=(nh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var gg=xh(95);fh(44,1,{44:1});_.d=false;var Ng=xh(44);fh(45,44,{9:1,242:1,45:1,44:1},Ln);_.t=up;_.o=function(a){return En(this,a)};_.q=function(){return this.c.d};_.u=vp;_.r=function(){var a;return th(xg),xg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Bn=0;var xg=xh(45);fh(189,1,Uo,Mn);_.v=function(){Cn(this.a)};var ig=xh(189);fh(190,1,Uo,Nn);_.v=function(){Hn(this.a)};var jg=xh(190);fh(110,109,{});var Ig=xh(110);fh(111,110,Ro,Vn);_.t=Bp;_.u=Cp;_.r=function(){var a;return th(sg),sg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var sg=xh(111);fh(113,1,Uo,Wn);_.v=function(){Pn(this.a)};var kg=xh(113);fh(112,1,Uo,Xn);_.v=function(){Sn(this.a)};var lg=xh(112);fh(118,1,Uo,Yn);_.v=function(){bc(this.a,this.b,true)};var mg=xh(118);fh(119,1,{},Zn);_.s=function(){return On(this.a,this.c,this.b)};_.b=false;var ng=xh(119);fh(114,1,{},$n);_.s=function(){return Tn(this.a)};var og=xh(114);fh(115,1,{},_n);_.s=function(){return Ih(Xg(rj(cc(this.a))))};var pg=xh(115);fh(116,1,{},ao);_.s=function(){return Ih(Xg(rj(sj(cc(this.a),new Io))))};var qg=xh(116);fh(117,1,{},bo);_.s=function(){return Un(this.a)};var rg=xh(117);fh(86,1,{});var Mg=xh(86);fh(87,86,Ro,ko);_.t=function(){jc(this.a)};_.u=function(){return this.a.i<0};_.r=function(){var a;return th(wg),wg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var wg=xh(87);fh(88,1,Uo,lo);_.v=function(){go(this.a,this.b)};_.b=false;var tg=xh(88);fh(89,1,Uo,mo);_.v=function(){sn(this.b,this.a)};var ug=xh(89);fh(90,1,Uo,no);_.v=function(){ho(this.a)};var vg=xh(90);fh(100,1,{});var Pg=xh(100);fh(101,100,Ro,vo);_.t=Bp;_.u=Cp;_.r=function(){var a;return th(Dg),Dg.k+'@'+(a=Rj(this)>>>0,a.toString(16))};var Dg=xh(101);fh(102,1,Uo,wo);_.v=function(){qo(this.a)};var yg=xh(102);fh(106,1,Uo,xo);_.v=function(){uo(this.a,null)};var zg=xh(106);fh(103,1,{},yo);_.s=function(){var a;return a=pn(this.a.g),o(kp,a)?(Fo(),Co):o(lp,a)?(Fo(),Eo):(Fo(),Do)};var Ag=xh(103);fh(104,1,{},zo);_.s=function(){return so(this.a)};var Bg=xh(104);fh(105,1,{},Ao);_.v=function(){to(this.a)};var Cg=xh(105);fh(91,1,{},Bo);_.handleEvent=function(a){kn(this.a,a)};var Eg=xh(91);fh(30,29,{3:1,27:1,29:1,30:1},Go);var Co,Do,Eo;var Gg=yh(30,Ho);fh(80,1,{},Io);_.eb=function(a){return !Gn(a)};var Hg=xh(80);fh(84,1,{},Jo);_.eb=function(a){return Gn(a)};var Jg=xh(84);fh(85,1,{},Ko);_.w=function(a){Rn(this.a,a)};var Kg=xh(85);fh(83,1,{},Lo);_.w=function(a){eo(this.a,a)};_.a=false;var Lg=xh(83);fh(76,1,{},Mo);_.eb=function(a){return po(this.a,a)};var Og=xh(76);var sd=zh('D');var No=(Ec(),Hc);var gwtOnLoad=gwtOnLoad=_g;Zg(lh);ah('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();