function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='C6EC06D0924244D1955FE04FF025F29B',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'C6EC06D0924244D1955FE04FF025F29B';function p(){}
function jh(){}
function fh(){}
function Rh(){}
function Eb(){}
function Oc(){}
function Vc(){}
function Vk(){}
function fk(){}
function kj(){}
function yj(){}
function Gj(){}
function Hj(){}
function cl(){}
function pm(){}
function sm(){}
function wm(){}
function Am(){}
function Em(){}
function Im(){}
function Ym(){}
function Zm(){}
function yn(){}
function Io(){}
function Jo(){}
function Tc(a){Sc()}
function qh(){qh=fh}
function si(){ji(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function ib(a){this.a=a}
function wb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function dc(a){this.a=a}
function mc(a){this.a=a}
function Gh(a){this.a=a}
function Qh(a){this.a=a}
function bi(a){this.a=a}
function gi(a){this.a=a}
function hi(a){this.a=a}
function fi(a){this.b=a}
function ui(a){this.c=a}
function lj(a){this.a=a}
function Jj(a){this.a=a}
function bl(a){this.a=a}
function dl(a){this.a=a}
function el(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function zl(a){this.a=a}
function Al(a){this.a=a}
function Bl(a){this.a=a}
function Dl(a){this.a=a}
function Zl(a){this.a=a}
function $l(a){this.a=a}
function dm(a){this.a=a}
function fm(a){this.a=a}
function gm(a){this.a=a}
function mm(a){this.a=a}
function nm(a){this.a=a}
function om(a){this.a=a}
function Mm(a){this.a=a}
function Nm(a){this.a=a}
function Pm(a){this.a=a}
function Qm(a){this.a=a}
function Sm(a){this.a=a}
function Tm(a){this.a=a}
function sn(a){this.a=a}
function tn(a){this.a=a}
function un(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function Jn(a){this.a=a}
function Kn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function lo(a){this.a=a}
function vo(a){this.a=a}
function wo(a){this.a=a}
function xo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function Fj(a,b){a.a=b}
function pb(a,b){a.b=b}
function $j(a,b){a.key=b}
function Zj(a,b){Yj(a,b)}
function bo(a,b){Xl(b,a)}
function pp(a){Yi(this,a)}
function sp(a){Kh(this,a)}
function up(a){_i(this,a)}
function wp(){gc(this.c)}
function yp(){gc(this.b)}
function Ep(){gc(this.f)}
function Gi(){this.a=Pi()}
function Ui(){this.a=Pi()}
function hc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function cb(a){Wb((J(),a))}
function db(a){Xb((J(),a))}
function gb(a){Yb((J(),a))}
function Ap(){jb(this.a.a)}
function np(){return this.a}
function rp(){return this.b}
function tp(){return this.e}
function Rg(a){return a.e}
function Dp(a){kc(this.c,a)}
function kc(a,b){Zh(a.c,b)}
function Ij(a,b){xj(a.a,b)}
function ao(a,b){Nn(a.b,b)}
function C(a,b){Mb(a.f,b.f)}
function K(a,b){O(a);L(a,b)}
function ln(a){R(a.a);Z(a.b)}
function An(a){Z(a.b);Z(a.a)}
function $k(a){jb(a.b);R(a.a)}
function tl(a){jb(a.a);Z(a.b)}
function fl(a){a.c=2;gc(a.b)}
function Kl(a){a.f=2;gc(a.e)}
function Wk(a){a.d=2;gc(a.c)}
function pc(a,b){a.e=b;oc(a,b)}
function fc(a,b,c){Yh(a.c,b,c)}
function Fl(a,b){return a.g=b}
function mi(a,b){return a.a[b]}
function op(){return Qj(this)}
function ph(a){sc.call(this,a)}
function Sh(a){sc.call(this,a)}
function Jl(a){On((dn(),an),a)}
function $(a){J();Xb(a);a.e=-2}
function J(){J=fh;I=new F}
function uc(){uc=fh;tc=new p}
function Lc(){Lc=fh;Kc=new Oc}
function Li(){Li=fh;Ki=Ni()}
function Bc(){Bc=fh;!!(Sc(),Rc)}
function Bn(a,b,c){fc(a.c,b,c)}
function ej(a,b,c){b.w(a.a[c])}
function Nj(a,b){a.splice(b,1)}
function Wc(a,b){return zh(a,b)}
function vp(a){return this===a}
function xp(){return this.c.f<0}
function zp(){return this.b.f<0}
function Fp(){return this.f.f<0}
function qp(){return _h(this.a)}
function Pi(){Li();return new Ki}
function th(a){sh(a);return a.k}
function wj(a,b){a.S(b);return a}
function ik(a,b){a.ref=b;return a}
function nn(a){eb(a.b);return a.e}
function Dn(a){eb(a.a);return a.d}
function qo(a){eb(a.d);return a.e}
function T(a){lb(a.f);return V(a)}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function xj(a,b){Fj(a,wj(a.a,b))}
function _i(a,b){while(a.db(b));}
function Cj(a,b,c){b.w(a.a.R(c))}
function v(a,b,c){t(a,new H(c),b)}
function Ri(a,b){return a.a.get(b)}
function _h(a){return a.a.b+a.b.b}
function Bp(a){return 1==this.a.d}
function Cp(a){return 1==this.a.c}
function Cb(a){this.d=a;this.b=100}
function ec(a,b){this.a=a;this.b=b}
function Eh(a,b){this.a=a;this.b=b}
function Ej(a,b){this.a=a;this.b=b}
function Bj(a,b){this.a=a;this.b=b}
function ii(a,b){this.a=a;this.b=b}
function gk(a,b){this.a=a;this.b=b}
function Cl(a,b){this.a=a;this.b=b}
function _l(a,b){this.a=a;this.b=b}
function am(a,b){this.a=a;this.b=b}
function bm(a,b){this.a=a;this.b=b}
function cm(a,b){this.a=a;this.b=b}
function em(a,b){this.a=a;this.b=b}
function Rm(a,b){this.a=a;this.b=b}
function Um(a,b){this.a=a;this.b=b}
function Vm(a,b){this.a=a;this.b=b}
function Rk(a,b){Eh.call(this,a,b)}
function Lj(a,b,c){a.splice(b,0,c)}
function jk(a,b){a.href=b;return a}
function vn(a,b){this.a=a;this.b=b}
function Wn(a,b){this.a=a;this.b=b}
function jo(a,b){this.a=a;this.b=b}
function ko(a,b){this.b=a;this.a=b}
function Go(a,b){Eh.call(this,a,b)}
function on(a){mn(a,(eb(a.b),a.e))}
function qm(){this.a=_j((um(),tm))}
function rm(){this.a=_j((ym(),xm))}
function Om(){this.a=_j((Cm(),Bm))}
function Xm(){this.a=_j((Gm(),Fm))}
function $m(){this.a=_j((Km(),Jm))}
function Zg(){Xg==null&&(Xg=[])}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function kd(a){return typeof a===Po}
function Xh(a){return !a?null:a._()}
function Sb(a){return !a.d?a:Sb(a.d)}
function $i(a){return a!=null?s(a):0}
function nd(a){return a==null?null:a}
function o(a,b){return nd(a)===nd(b)}
function Oh(a,b){a.a+=''+b;return a}
function sk(a,b){a.value=b;return a}
function nk(a,b){a.onBlur=b;return a}
function kk(a,b){a.onClick=b;return a}
function mk(a,b){a.checked=b;return a}
function Ic(a){$wnd.clearTimeout(a)}
function ji(a){a.a=Yc(fe,Qo,1,0,5,1)}
function $h(a){a.a=new Gi;a.b=new Ui}
function hb(a){this.c=new si;this.b=a}
function Uj(){Uj=fh;Rj=new p;Tj=new p}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function Y(a){return !(!!a&&1==(a.c&7))}
function En(a){Xl(a,(eb(a.a),!a.d))}
function Ol(a){jb(a.b);R(a.c);Z(a.a)}
function cc(a,b){ac(a,b,false);db(a.c)}
function Mj(a,b){Kj(b,0,a,0,b.length)}
function bc(a,b){b.A(a);hd(b,9)&&b.t()}
function Yj(a,b){for(var c in a){b(c)}}
function ad(a,b,c){return {l:a,m:b,h:c}}
function Lh(a,b){return a.charCodeAt(b)}
function hd(a,b){return a!=null&&fd(a,b)}
function Qj(a){return a.$H||(a.$H=++Pj)}
function md(a){return typeof a==='string'}
function ob(a){J();nb(a);rb(a,2,true)}
function eb(a){var b;Tb((J(),b=Ob,b),a)}
function po(a){var b;b=a.e;!!b&&kc(b.c,a)}
function sh(a){if(a.k!=null){return}Bh(a)}
function ok(a,b){a.onChange=b;return a}
function pk(a,b){a.onKeyDown=b;return a}
function lk(a){a.autoFocus=true;return a}
function sc(a){this.g=a;nc(this);this.G()}
function vj(a,b){oj.call(this,a);this.a=b}
function Ii(a,b){var c;c=a[ap];c.call(a,b)}
function Yi(a,b){while(a.X()){Ij(b,a.Y())}}
function Fb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&rb(a.f,5,true)}
function P(){this.a=Yc(fe,Qo,1,100,5,1)}
function Jh(){Jh=fh;Ih=Yc(ce,Qo,28,256,0,1)}
function Ai(){this.a=new Gi;this.b=new Ui}
function oo(a){jb(a.a);R(a.b);R(a.c);Z(a.d)}
function co(a){A((J(),J(),I),new lo(a),fp)}
function Ul(a){A((J(),J(),I),new fm(a),fp)}
function pn(a){A((J(),J(),I),new wn(a),fp)}
function Hn(a){A((J(),J(),I),new Kn(a),fp)}
function Sn(a){return Hh(S(a.e).a-S(a.a).a)}
function jd(a){return typeof a==='boolean'}
function Cc(a,b,c){return a.apply(b,c);var d}
function Lb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function nh(a,b,c,d){a.addEventListener(b,c,d)}
function Xi(a,b,c){this.a=a;this.b=b;this.c=c}
function tk(a,b){a.onDoubleClick=b;return a}
function ki(a,b){a.a[a.a.length]=b;return true}
function nc(a){a.j&&a.e!==Xo&&a.G();return a}
function wh(a){var b;b=vh(a);Dh(a,b);return b}
function Bb(a){while(true){if(!Ab(a)){break}}}
function cj(a,b){while(a.c<a.d){ej(a,b,a.c++)}}
function ho(a,b){A((J(),J(),I),new jo(a,b),fp)}
function go(a,b){A((J(),J(),I),new ko(a,b),fp)}
function ul(a,b){A((J(),J(),I),new Cl(a,b),fp)}
function Wl(a,b){A((J(),J(),I),new _l(a,b),fp)}
function Pl(a,b){A((J(),J(),I),new em(a,b),fp)}
function Sl(a,b){A((J(),J(),I),new bm(a,b),fp)}
function Tl(a,b){A((J(),J(),I),new am(a,b),fp)}
function On(a,b){A((J(),J(),I),new Wn(a,b),fp)}
function Mb(a,b){Lb(a,((b.a&229376)>>15)-1,b)}
function mb(a,b){bb(b,a);b.c.a.length>0||(b.a=4)}
function vl(a,b){var c;c=b.target;xl(a,c.value)}
function pj(a,b){var c;return tj(a,(c=new si,c))}
function Sc(){Sc=fh;var a;!Uc();a=new Vc;Rc=a}
function F(){this.f=new Nb;this.a=new Cb(this.f)}
function Xn(a,b){this.a=a;this.c=b;this.b=false}
function gj(a){if(!a.d){a.d=a.b.Q();a.c=a.b.T()}}
function Db(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function zj(a,b,c){if(a.a.fb(c)){a.b=true;b.w(c)}}
function oh(a,b,c,d){a.removeEventListener(b,c,d)}
function Qi(a,b){return !(a.a.get(b)===undefined)}
function mo(a){return o(lp,a)||o(mp,a)||o('',a)}
function $c(a){return Array.isArray(a)&&a.ob===jh}
function gd(a){return !Array.isArray(a)&&a.ob===jh}
function wi(a){return new vj(null,vi(a,a.length))}
function Rn(a){return qh(),0!=S(a.e).a?true:false}
function vi(a,b){return aj(b,a.length),new fj(a,b)}
function _k(a){return B((J(),J(),I),a.b,new el(a))}
function Mn(a){R(a.d);R(a.e);R(a.a);R(a.b);Z(a.c)}
function Qn(a){Kh(new gi(a.g),new dc(a));$h(a.g)}
function di(a){var b;b=a.a.Y();a.b=ci(a);return b}
function yh(a){var b;b=vh(a);b.j=a;b.e=1;return b}
function oi(a,b){var c;c=a.a[b];Nj(a.a,b);return c}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Vl(a){return B((J(),J(),I),a.b,new $l(a))}
function il(a){return B((J(),J(),I),a.a,new ml(a))}
function wl(a){return B((J(),J(),I),a.a,new Al(a))}
function km(a){return B((J(),J(),I),a.a,new om(a))}
function jc(a){hc(a.e);!!a.c&&ic(a);hc(a.a);hc(a.d)}
function xl(a,b){var c;c=a.e;if(b!=c){a.e=b;db(a.b)}}
function Xl(a,b){var c;c=a.d;if(b!=c){a.d=b;db(a.a)}}
function qi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ai(a,b){if(b){return Vh(a.a,b)}return false}
function rj(a,b){nj(a);return new vj(a,new Aj(b,a.a))}
function sj(a,b){nj(a);return new vj(a,new Dj(b,a.a))}
function mn(a,b){A((J(),J(),I),new vn(a,b),75497472)}
function Xk(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function gl(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function Ll(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function mj(a){if(!a.b){nj(a);a.c=true}else{mj(a.b)}}
function oj(a){if(!a){this.b=null;new si}else{this.b=a}}
function fj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function bj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function zi(a,b){return nd(a)===nd(b)||a!=null&&q(a,b)}
function kn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&xl(a,b)}
function fb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function kb(a){C((J(),J(),I),a);0==(a.f.a&Vo)&&D((null,I))}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function hj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function rk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function xh(a,b){var c;c=vh(a);Dh(a,c);c.e=b?8:0;return c}
function qc(a,b){var c;c=th(a.mb);return b==null?c:c+': '+b}
function El(a,b){var c;if(S(a.c)){c=b.target;Xl(a,c.value)}}
function Wg(a){if(kd(a)){return a|0}return a.l|a.m<<22}
function Ah(a){if(a.O()){return null}var b=a.j;return ah[b]}
function Pb(a){if(a.e){2==(a.e.c&7)||rb(a.e,4,true);nb(a.e)}}
function Kh(a,b){var c,d;for(d=a.Q();d.X();){c=d.Y();b.w(c)}}
function eo(a,b){pj(Pn(a.b),new lj(new kj)).P(new Lo(b))}
function Wh(a,b){return b===a?'(this Map)':b==null?Zo:ih(b)}
function io(a){this.b=a;J();this.a=new lc(0,null,null,true)}
function mh(){mh=fh;lh=$wnd.goog.global.document}
function Xj(){if(Sj==256){Rj=Tj;Tj=new p;Sj=0}++Sj}
function Ho(){Fo();return _c(Wc(Fg,1),Qo,30,0,[Co,Eo,Do])}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function nj(a){if(a.b){nj(a.b)}else if(a.c){throw Rg(new Fh)}}
function hh(a){function b(){}
;b.prototype=a||{};return new b}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function qk(a){a.placeholder='What needs to be done?';return a}
function Ci(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function zh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function dh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Ql(a,b){to((dn(),cn),b);A((J(),J(),I),new _l(a,b),fp)}
function hn(a,b){b.preventDefault();A((J(),J(),I),new xn(a),fp)}
function Pn(a){eb(a.c);return new vj(null,new hj(new gi(a.g),0))}
function Di(a,b){var c;return Bi(b,Ci(a,b==null?0:(c=s(b),c|0)))}
function ti(a){ji(this);Mj(this.a,Uh(a,Yc(fe,Qo,1,_h(a.a),5,1)))}
function Hi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Dj(a,b){bj.call(this,b.cb(),b.bb()&-6);this.a=a;this.b=b}
function fn(a){nh((mh(),$wnd.goog.global.window),ip,a.d,false)}
function gn(a){oh((mh(),$wnd.goog.global.window),ip,a.d,false)}
function Rl(a){return qh(),qo((dn(),cn))==a.j.props['a']?true:false}
function dj(a,b){if(a.c<a.d){ej(a,b,a.c++);return true}return false}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function ek(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function um(){um=fh;var a;tm=(a=gh(sm.prototype.lb,sm,[]),a)}
function ym(){ym=fh;var a;xm=(a=gh(wm.prototype.lb,wm,[]),a)}
function Cm(){Cm=fh;var a;Bm=(a=gh(Am.prototype.lb,Am,[]),a)}
function Gm(){Gm=fh;var a;Fm=(a=gh(Em.prototype.lb,Em,[]),a)}
function Km(){Km=fh;var a;Jm=(a=gh(Im.prototype.lb,Im,[]),a)}
function vm(a){$wnd.React.Component.call(this,a);this.a=new al(this)}
function zm(a){$wnd.React.Component.call(this,a);this.a=new jl(this)}
function Dm(a){$wnd.React.Component.call(this,a);this.a=new yl(this)}
function Hm(a){$wnd.React.Component.call(this,a);this.a=new Yl(this)}
function Lm(a){$wnd.React.Component.call(this,a);this.a=new lm(this)}
function Vi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Aj(a,b){bj.call(this,b.cb(),b.bb()&-16449);this.a=a;this.c=b}
function ab(a,b){var c,d;ki(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Zh(a,b){return md(b)?b==null?Fi(a.a,null):Ti(a.b,b):Fi(a.a,b)}
function ij(a,b){!a.a?(a.a=new Qh(a.d)):Oh(a.a,a.b);Oh(a.a,b);return a}
function tj(a,b){var c;mj(a);c=new Gj;c.a=b;a.a.W(new Jj(c));return c.a}
function qj(a){var b;mj(a);b=0;while(a.a.db(new Hj)){b=Sg(b,1)}return b}
function fo(a){pj(rj(Pn(a.b),new Jo),new lj(new kj)).P(new Ko(a.b))}
function dn(){dn=fh;an=new Tn;bn=new io(an);_m=new rn;cn=new uo(an,_m)}
function Nn(a,b){var c;return u((J(),J(),I),new Xn(a,b),fp,(c=null,c))}
function uj(a,b){var c;c=pj(a,new lj(new kj));return ri(c,b.eb(c.a.length))}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function od(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Kb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function li(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function jj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function ei(a){this.d=a;this.c=new Vi(this.d.b);this.a=this.c;this.b=ci(this)}
function Wi(a){if(a.a.c!=a.c){return Ri(a.a,a.b.value[0])}return a.b.value[1]}
function ni(a,b,c){for(;c<a.a.length;++c){if(zi(b,a.a[c])){return c}}return -1}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&_c(Wc(a,f),b,c,e,g);return g}
function pi(a,b){var c;c=ni(a,b,0);if(c==-1){return false}Nj(a.a,c);return true}
function Hb(b){try{lb(b.b.a)}catch(a){a=Qg(a);if(!hd(a,4))throw Rg(a)}}
function en(a,b){a.f=b;o(b,S(a.a))&&xl(a,b);jn(b);A((J(),J(),I),new xn(a),fp)}
function no(a,b){return (Fo(),Do)==a||(Co==a?(eb(b.a),!b.d):(eb(b.a),b.d))}
function Yh(a,b,c){return md(b)?b==null?Ei(a.a,null,c):Si(a.b,b,c):Ei(a.a,b,c)}
function Oj(a,b){return Xc(b)!=10&&_c(r(b),b.nb,b.__elementTypeId$,Xc(b),a),a}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ck(a){var b;return ak($wnd.React.StrictMode,null,null,(b={},b[bp]=a,b))}
function ro(a){var b;return b=S(a.b),pj(rj(Pn(a.i),new Mo(b)),new lj(new kj))}
function nl(a){var b;b=Nh((eb(a.b),a.e));if(b.length>0){ao((dn(),bn),b);xl(a,'')}}
function Z(a){if(-2!=a.e){u((J(),J(),I),new G(new ib(a)),0,null);!!a.b&&jb(a.b)}}
function gc(a){if(a.f>=0){a.f=-2;u((J(),J(),I),new G(new mc(a)),67108864,null)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;Z(a.e);2==(a.f.c&7)||jb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Bb(a.a)}finally{a.c=false}}}}
function V(a){if(a.b){if(hd(a.b,8)){throw Rg(a.b)}else{throw Rg(a.b)}}return a.n}
function qb(b){if(b){try{b.v()}catch(a){a=Qg(a);if(hd(a,4)){J()}else throw Rg(a)}}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new si);ki(a.b,b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new si);a.c=c.c}b.d=true;ki(a.c,b)}
function Dh(a,b){var c;if(!a){return}b.j=a;var d=Ah(b);if(!d){ah[a]=[b];return}d.mb=b}
function vh(a){var b;b=new uh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function gh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ak(a,b,c,d){var e;e=bk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function lc(a,b,c,d){this.b=a;this.c=d?new Ai:null;this.e=b;this.a=c;this.d=null}
function Ib(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Wo:0)|(0!=(b&229376)?0:98304)}
function Nb(){var a;this.a=Yc(td,Qo,42,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Yg(){Zg();var a=Xg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function nb(a){var b,c;for(c=new ui(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function xi(a){var b,c,d;d=0;for(c=new ei(a.a);c.b;){b=di(c);d=d+(b?s(b):0);d=d|0}return d}
function _j(a){var b;b=bk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Ti(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ii(a.a,b);--a.b}return c}
function Th(a,b){var c,d;for(d=new ei(b.a);d.b;){c=di(d);if(!ai(a,c)){return false}}return true}
function Ln(a,b,c){var d;d=new In(b,c);Bn(d,a,new ec(a,d));Yh(a.g,Hh(d.c.b),d);db(a.c);return d}
function ol(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Bl(a),fp)}}
function aj(a,b){if(0>a||a>b){throw Rg(new ph('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function _g(a,b){typeof window===Oo&&typeof window['$gwt']===Oo&&(window['$gwt'][a]=b)}
function ld(a){return a!=null&&(typeof a===Oo||typeof a==='function')&&!(a.ob===jh)}
function Fh(){sc.call(this,"Stream already terminated, can't be modified or used")}
function ub(a,b,c){tb.call(this,null,a,b,c|(!a?262144:So)|(0==(c&6291456)?!a?Vo:Wo:0)|0|0|0)}
function ac(a,b,c){var d;d=Zh(a.g,b?Hh(b.c.b):null);if(null!=d){kc(b.c,a);c&&!!b&&gc(b.c);db(a.c)}}
function so(a){var b;b=S(a.g.a);o(lp,b)||o(mp,b)||o('',b)?mn(a.g,b):mo(nn(a.g))?pn(a.g):mn(a.g,'')}
function Fo(){Fo=fh;Co=new Go('ACTIVE',0);Eo=new Go('COMPLETED',1);Do=new Go('ALL',2)}
function kh(){dn();$wnd.ReactDOM.render(ck([(new $m).a]),(mh(),lh).getElementById('app'),null)}
function Wm(a,b){$j(a.a,(sh(Wf),Wf.k+(''+(b?Hh(b.c.b):null))));a.a.props['a']=b;return a.a}
function ci(a){if(a.a.X()){return true}if(a.a!=a.c){return false}a.a=new Hi(a.d.a);return a.a.X()}
function Qg(a){var b;if(hd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new wc(a);Tc(b)}return b}
function Tg(a){var b;b=a.h;if(b==0){return a.l+a.m*Wo}if(b==1048575){return a.l+a.m*Wo-$o}return a}
function Vg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=$o;d=1048575}c=od(e/Wo);b=od(e-c*Wo);return ad(b,c,d)}
function Bi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(zi(a,c.$())){return c}}return null}
function _c(a,b,c,d,e){e.mb=a;e.nb=b;e.ob=jh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Si(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function to(a,b){var c;c=a.e;if(!(b==c||!!b&&b==c)){!!c&&kc(c.c,a);a.e=b;!!b&&Bn(b,a,new zo(a));db(a.d)}}
function bb(a,b){var c,d;d=a.c;pi(d,b);!!a.b&&So!=(a.b.c&To)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function bd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ad(c&4194303,d&4194303,e&1048575)}
function Hh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Jh(),Ih)[b];!c&&(c=Ih[b]=new Gh(a));return c}return new Gh(a)}
function wc(a){uc();nc(this);this.e=a;oc(this,a);this.g=a==null?Zo:ih(a);this.a='';this.b=a;this.a=''}
function uh(){this.g=rh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function jl(a){var b;this.j=a;J();b=++hl;this.b=new lc(b,null,new kl(this),false);this.a=new ub(null,new ll(this),ep)}
function lm(a){var b;this.j=a;J();b=++jm;this.b=new lc(b,null,new mm(this),false);this.a=new ub(null,new nm(this),ep)}
function Gl(a,b,c){27==c.which?A((J(),J(),I),new cm(a,b),fp):13==c.which&&A((J(),J(),I),new am(a,b),fp)}
function jb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new yb(a)),67108864,null);!!a.a&&R(a.a);Fb(a.f);a.c=a.c&-8|1}}
function Uk(){if(!Tk){Tk=(++(J(),J(),I).e,new Eb);$wnd.Promise.resolve(null).then(gh(Vk.prototype.I,Vk,[]))}}
function Sk(){Qk();return _c(Wc(_e,1),Qo,6,0,[uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk])}
function r(a){return md(a)?ie:kd(a)?Zd:jd(a)?Xd:gd(a)?a.mb:$c(a)?a.mb:a.mb||Array.isArray(a)&&Wc(Pd,1)||Pd}
function s(a){return md(a)?Wj(a):kd(a)?od(a):jd(a)?a?1231:1237:gd(a)?a.q():$c(a)?Qj(a):!!a&&!!a.hashCode?a.hashCode():Qj(a)}
function Gb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&So)?Hb(a):lb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Il(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Wl(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Ub(a){var b;if(a.c){while(a.c.a.length!=0){b=oi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&rb(b.b,3,true)}}}
function Jb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function yi(a){var b,c,d;d=1;for(c=new ui(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function ic(a){var b,c,d;for(c=new ui(new ti(new bi(a.c)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.$();hd(d,9)&&d.u()||b._().v()}}
function Hl(a,b){var c;c=(eb(a.a),a.d);if(null!=c&&c.length!=0){go((dn(),b),c);to(cn,null);Xl(a,c)}else{On((dn(),an),b)}}
function Sg(a,b){var c;if(kd(a)&&kd(b)){c=a+b;if(-17592186044416<c&&c<$o){return c}}return Tg(bd(kd(a)?Vg(a):a,kd(b)?Vg(b):b))}
function ih(a){var b;if(Array.isArray(a)&&a.ob===jh){return th(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function Wj(a){Uj();var b,c,d;c=':'+a;d=Tj[c];if(d!=null){return od(d)}d=Rj[c];b=d==null?Vj(a):od(d);Xj();Tj[c]=b;return b}
function ri(a,b){var c,d;d=a.a.length;b.length<d&&(b=Oj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Ch(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function vb(a,b){tb.call(this,a,new wb(a),null,b|(So==(b&To)?0:524288)|(0==(b&6291456)?So==(b&To)?Wo:Vo:0)|0|268435456|0)}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return md(a)?o(a,b):kd(a)?nd(a)===nd(b):jd(a)?nd(a)===nd(b):gd(a)?a.o(b):$c(a)?o(a,b):!!a&&!!a.equals?a.equals(b):nd(a)===nd(b)}
function fd(a,b){if(md(a)){return !!ed[b]}else if(a.nb){return !!a.nb[b]}else if(kd(a)){return !!dd[b]}else if(jd(a)){return !!cd[b]}return false}
function hk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function S(a){a.k?fb(a.e):eb(a.e);if(sb(a.f)){if(a.k&&(J(),!(!!Ob&&!!Ob.e))){return u((J(),J(),I),new X(a),83888128,null)}else{lb(a.f)}}return V(a)}
function Xb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ui(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&rb(b,6,true)}}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ui(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&rb(b,5,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ui(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?rb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Nh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Uh(a,b){var c,d,e,f;f=_h(a.a);b.length<f&&(b=Oj(new Array(f),b));e=b;d=new ei(a.a);for(c=0;c<f;++c){e[c]=di(d)}b.length>f&&(b[f]=null);return b}
function yl(a){var b,c,d;this.j=a;J();b=++sl;this.c=new lc(b,null,new zl(this),false);this.b=(d=new hb((c=null,c)),d);this.a=new ub(null,new Dl(this),ep)}
function al(a){var b;this.j=a;J();b=++Zk;this.c=new lc(b,null,new bl(this),false);this.a=new W(new cl,null,null,136478720);this.b=new ub(null,new dl(this),ep)}
function In(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++zn;this.c=new lc(c,null,new Jn(this),true);this.b=(g=new hb((e=null,e)),g);this.a=(f=new hb((d=null,d)),f)}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{$b(b,d);try{f=(c.a.v(),null)}finally{_b()}return f}catch(a){a=Qg(a);if(hd(a,4)){e=a;throw Rg(e)}else throw Rg(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.s()}else{$b(b,e);try{g=c.s()}finally{_b()}}return g}catch(a){a=Qg(a);if(hd(a,4)){f=a;throw Rg(f)}else throw Rg(a)}finally{D(b)}}
function Ab(a){var b,c;if(0==a.c){b=Kb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Jb(a.d);Gb(c);return true}
function $g(b,c,d,e){Zg();var f=Xg;$moduleName=c;$moduleBase=d;Pg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{No(g)()}catch(a){b(c,a)}}else{No(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new vb(this,d&-16385);this.e=new hb(this.f);So==(d&To)&&kb(this.f)}
function bk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ni(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Oi()}}
function bh(){ah={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].pb()&&(c=Pc(c,g)):g[0].pb()}catch(a){a=Qg(a);if(hd(a,4)){d=a;Bc();Hc(hd(d,34)?d.H():d)}else throw Rg(a)}}return c}
function rl(a){var b;a.d=0;Uk();b=dk(gp,lk(ok(pk(sk(qk(hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,['new-todo']))),(eb(a.b),a.e)),gh(Mm.prototype.jb,Mm,[a])),gh(Nm.prototype.ib,Nm,[a]))),null);return b}
function vc(a){var b;if(a.c==null){b=nd(a.b)===nd(tc)?null:a.b;a.d=b==null?Zo:ld(b)?b==null?null:b.name:md(b)?'String':th(r(b));a.a=a.a+': '+(ld(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(nd(e)===nd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;cb(b.e)}}catch(a){a=Qg(a);if(hd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;cb(b.e)}throw Rg(c)}else throw Rg(a)}}
function Kj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Ei(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Bi(b,e);if(f){return f.ab(c)}}e[e.length]=new ii(b,c);++a.b;return null}
function Vj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Lh(a,c++)}b=b|0;return b}
function lb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Qg(a);if(hd(a,4)){J()}else throw Rg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Yc(fe,Qo,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function tb(a,b,c,d){this.b=new si;this.f=new Ib(new xb(this),d&6520832|262144|So);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Vo)&&D((null,I)))}
function Yl(a){var b,c,d;this.j=a;J();b=++Nl;this.e=new lc(b,null,new Zl(this),false);this.a=(d=new hb((c=null,c)),d);this.c=new W(new dm(this),null,null,136478720);this.b=new ub(null,new gm(this),ep);Wl(this,this.j.props['a'])}
function Fi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(zi(b,e.$())){if(d.length==1){d.length=0;Ii(a.a,g)}else{d.splice(h,1)}--a.b;return e._()}}return null}
function eh(a,b,c){var d=ah,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=ah[b]),hh(h));_.nb=c;!b&&(_.ob=jh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.mb=f)}
function Bh(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Ch('.',[c,Ch('$',d)]);a.b=Ch('.',[c,Ch('.',d)]);a.i=d[d.length-1]}
function Vh(a,b){var c,d,e;c=b.$();e=b._();d=md(c)?c==null?Xh(Di(a.a,null)):Ri(a.b,c):Xh(Di(a.a,c));if(!(nd(e)===nd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(md(c)?c==null?!!Di(a.a,null):Qi(a.b,c):!!Di(a.a,c))){return false}return true}
function jn(a){var b;if(0==a.length){b=(mh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',lh.title,b)}else{(mh(),$wnd.goog.global.window).location.hash=a}}
function dk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Zj(b,gh(gk.prototype.gb,gk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[bp]=c[0],undefined):(d[bp]=c,undefined));return ak(a,e,f,d)}
function rn(){var a,b,c;this.d=new Bo(this);this.f=this.e=(c=(mh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new lc(0,null,new sn(this),true);this.b=(b=new hb((a=null,a)),b);this.a=new W(new yn,new tn(this),new un(this),35651584)}
function uo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new lc(0,new vo(this),new wo(this),true);this.d=(d=new hb((c=null,c)),d);this.b=new W(new Ao(this),null,null,kp);this.c=new W(new xo(this),null,null,kp);this.a=new ub(new yo(this),null,681574400);D((null,I))}
function Tn(){var a;this.g=new Ai;J();this.f=new lc(0,new Vn(this),new Un(this),false);this.c=(a=new hb(null),a);this.d=new W(new Yn(this),null,null,kp);this.e=new W(new Zn(this),null,null,kp);this.a=new W(new $n(this),null,null,kp);this.b=new W(new _n(this),null,null,kp)}
function sb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ui(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Qg(a);if(!hd(a,4))throw Rg(a)}if(6==(b.c&7)){return true}}}}}nb(b);return false}
function oc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function Mi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function rb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){gb(a.a.e);qb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;qb((e=d.i,e));d.n=null}li(a.b,new zb(a));a.b.a=Yc(fe,Qo,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&qb((f=a.a.g,f))}}
function Qk(){Qk=fh;uk=new Rk(cp,0);vk=new Rk('checkbox',1);wk=new Rk('color',2);xk=new Rk('date',3);yk=new Rk('datetime',4);zk=new Rk('email',5);Ak=new Rk('file',6);Bk=new Rk('hidden',7);Ck=new Rk('image',8);Dk=new Rk('month',9);Ek=new Rk(Po,10);Fk=new Rk('password',11);Gk=new Rk('radio',12);Hk=new Rk('range',13);Ik=new Rk('reset',14);Jk=new Rk('search',15);Kk=new Rk('submit',16);Lk=new Rk('tel',17);Mk=new Rk('text',18);Nk=new Rk('time',19);Ok=new Rk('url',20);Pk=new Rk('week',21)}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=mi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&qi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{bb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&rb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=mi(a.b,g);if(-1==k.e){k.e=0;ab(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){oi(a.b,g)}e&&pb(a.e,a.b)}else{e&&pb(a.e,new si)}if(Y(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&So!=(k.b.c&To)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function Yk(a){var b,c;a.d=0;Uk();c=(b=S((dn(),cn).b),dk('footer',hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,['footer'])),[(new rm).a,dk('ul',hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,['filters'])),[dk('li',null,[dk('a',jk(hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,[(Fo(),Do)==b?dp:null])),'#'),['All'])]),dk('li',null,[dk('a',jk(hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,[Co==b?dp:null])),'#active'),['Active'])]),dk('li',null,[dk('a',jk(hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,[Eo==b?dp:null])),'#completed'),['Completed'])])]),S(a.a)?dk(cp,kk(hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,['clear-completed'])),gh(pm.prototype.kb,pm,[])),['Clear Completed']):null]));return c}
function Ml(a){var b,c,d,e;a.f=0;Uk();b=a.j.props['a'];if(!!b&&b.c.f<0){return null}c=(d=a.j.props['a'],e=(eb(d.a),d.d),dk('li',hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,[e?'checked':null,S(a.c)?'editing':null])),[dk('div',hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,['view'])),[dk(gp,ok(mk(rk(hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,['toggle'])),(Qk(),vk)),e),gh(Qm.prototype.ib,Qm,[d])),null),dk('label',tk(new $wnd.Object,gh(Rm.prototype.kb,Rm,[a,d])),[(eb(d.b),d.e)]),dk(cp,kk(hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,['destroy'])),gh(Sm.prototype.kb,Sm,[d])),null)]),dk(gp,pk(ok(nk(sk(hk(ik(new $wnd.Object,gh(Tm.prototype.w,Tm,[a])),_c(Wc(ie,1),Qo,2,6,['edit'])),(eb(a.a),a.d)),gh(Um.prototype.hb,Um,[a,d])),gh(Pm.prototype.ib,Pm,[a])),gh(Vm.prototype.jb,Vm,[a,d])),null)]));return c}
function Oi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[ap]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Mi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[ap]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Oo='object',Po='number',Qo={3:1},Ro={9:1},So=1048576,To=1835008,Uo={5:1},Vo=2097152,Wo=4194304,Xo='__noinit__',Yo={3:1,10:1,8:1,4:1},Zo='null',$o=17592186044416,_o={40:1},ap='delete',bp='children',cp='button',dp='selected',ep=1411518464,fp=142606336,gp='input',hp='header',ip='hashchange',jp={9:1,61:1},kp=136314880,lp='active',mp='completed';var _,ah,Xg,Pg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;bh();eh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.mb};_.q=op;_.r=function(){var a;return th(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var cd,dd,ed;eh(48,1,{},uh);_.J=function(a){var b;b=new uh;b.e=4;a>1?(b.c=zh(this,a-1)):(b.c=this);return b};_.K=function(){sh(this);return this.b};_.L=function(){return th(this)};_.M=function(){sh(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(sh(this),this.k)};_.e=0;_.g=0;var rh=1;var fe=wh(1);var Yd=wh(48);eh(78,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var sd=wh(78);eh(35,1,{},G);_.s=function(){return this.a.v(),null};var qd=wh(35);eh(79,1,{},H);var rd=wh(79);var I;eh(42,1,{42:1},P);_.b=0;_.c=false;_.d=0;var td=wh(42);eh(215,1,Ro);_.r=function(){var a;return th(this.mb)+'@'+(a=s(this)>>>0,a.toString(16))};var wd=wh(215);eh(18,215,Ro,W);_.t=function(){R(this)};_.u=np;_.a=false;_.d=0;_.k=false;var vd=wh(18);eh(123,1,{},X);_.s=function(){return T(this.a)};var ud=wh(123);eh(17,215,{9:1,17:1},hb);_.t=function(){Z(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var yd=wh(17);eh(122,1,Uo,ib);_.v=function(){$(this.a)};var xd=wh(122);eh(15,215,{9:1,15:1},ub,vb);_.t=function(){jb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Dd=wh(15);eh(124,1,{},wb);_.v=function(){Q(this.a)};var zd=wh(124);eh(125,1,Uo,xb);_.v=function(){lb(this.a)};var Ad=wh(125);eh(126,1,Uo,yb);_.v=function(){ob(this.a)};var Bd=wh(126);eh(127,1,{},zb);_.w=function(a){mb(this.a,a)};var Cd=wh(127);eh(132,1,{},Cb);_.a=0;_.b=0;_.c=0;var Ed=wh(132);eh(159,1,Ro,Eb);_.t=function(){Db(this)};_.u=np;_.a=false;var Fd=wh(159);eh(57,215,{9:1,57:1},Ib);_.t=function(){Fb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Hd=wh(57);eh(137,1,{},Nb);var Gd=wh(137);eh(139,1,{},Zb);_.r=function(){var a;return sh(Id),Id.k+'@'+(a=Qj(this)>>>0,a.toString(16))};_.a=0;var Ob;var Id=wh(139);eh(110,1,{});var Ld=wh(110);eh(81,1,{},dc);_.w=function(a){bc(this.a,a)};var Jd=wh(81);eh(82,1,Uo,ec);_.v=function(){cc(this.a,this.b)};var Kd=wh(82);eh(14,1,Ro,lc);_.t=function(){gc(this)};_.u=function(){return this.f<0};_.r=function(){var a;return sh(Nd),Nd.k+'@'+(a=Qj(this)>>>0,a.toString(16))};_.b=0;_.f=0;var Nd=wh(14);eh(121,1,Uo,mc);_.v=function(){jc(this.a)};var Md=wh(121);eh(4,1,{3:1,4:1});_.B=tp;_.C=function(){return uj(sj(wi((this.i==null&&(this.i=Yc(ke,Qo,4,0,0,1)),this.i)),new Rh),new yj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){pc(this,rc(new Error(qc(this,this.g))));Tc(this)};_.r=function(){return qc(this,this.F())};_.e=Xo;_.j=true;var ke=wh(4);eh(10,4,{3:1,10:1,4:1});var _d=wh(10);eh(8,10,Yo);var ge=wh(8);eh(71,8,Yo);var de=wh(71);eh(72,71,Yo);var Rd=wh(72);eh(34,72,{34:1,3:1,10:1,8:1,4:1},wc);_.F=function(){vc(this);return this.c};_.H=function(){return nd(this.b)===nd(tc)?null:this.b};var tc;var Od=wh(34);var Pd=wh(0);eh(201,1,{});var Qd=wh(201);var yc=0,zc=0,Ac=-1;eh(109,201,{},Oc);var Kc;var Sd=wh(109);var Rc;eh(212,1,{});var Ud=wh(212);eh(73,212,{},Vc);var Td=wh(73);var lh;eh(69,1,{66:1});_.r=np;var Vd=wh(69);eh(75,8,Yo);var be=wh(75);eh(155,75,Yo,ph);var Wd=wh(155);cd={3:1,67:1,27:1};var Xd=wh(67);eh(41,1,{3:1,41:1});var ee=wh(41);dd={3:1,27:1,41:1};var Zd=wh(211);eh(29,1,{3:1,27:1,29:1});_.o=vp;_.q=op;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var $d=wh(29);eh(74,8,Yo,Fh);var ae=wh(74);eh(28,41,{3:1,27:1,28:1,41:1},Gh);_.o=function(a){return hd(a,28)&&a.a==this.a};_.q=np;_.r=function(){return ''+this.a};_.a=0;var ce=wh(28);var Ih;eh(278,1,{});ed={3:1,66:1,27:1,2:1};var ie=wh(2);eh(70,69,{66:1},Qh);var he=wh(70);eh(282,1,{});eh(64,1,{},Rh);_.R=function(a){return a.e};var je=wh(64);eh(50,8,Yo,Sh);var le=wh(50);eh(213,1,{39:1});_.P=sp;_.U=function(){return new hj(this,0)};_.V=function(){return new vj(null,this.U())};_.S=function(a){throw Rg(new Sh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new jj('[',']');for(b=this.Q();b.X();){a=b.Y();ij(c,a===this?'(this Collection)':a==null?Zo:ih(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var me=wh(213);eh(216,1,{199:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!hd(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ei((new bi(d)).a);c.b;){b=di(c);if(!Vh(this,b)){return false}}return true};_.q=function(){return xi(new bi(this))};_.r=function(){var a,b,c;c=new jj('{','}');for(b=new ei((new bi(this)).a);b.b;){a=di(b);ij(c,Wh(this,a.$())+'='+Wh(this,a._()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var xe=wh(216);eh(128,216,{199:1});var pe=wh(128);eh(217,213,{39:1,227:1});_.U=function(){return new hj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!hd(a,20)){return false}b=a;if(_h(b.a)!=this.T()){return false}return Th(this,b)};_.q=function(){return xi(this)};var ye=wh(217);eh(20,217,{20:1,39:1,227:1},bi);_.Q=function(){return new ei(this.a)};_.T=qp;var oe=wh(20);eh(21,1,{},ei);_.W=pp;_.Y=function(){return di(this)};_.X=rp;_.b=false;var ne=wh(21);eh(214,213,{39:1,224:1});_.U=function(){return new hj(this,16)};_.Z=function(a,b){throw Rg(new Sh('Add not supported on this list'))};_.S=function(a){this.Z(this.T(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!hd(a,13)){return false}f=a;if(this.T()!=f.a.length){return false}e=new ui(f);for(c=new ui(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(nd(b)===nd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return yi(this)};_.Q=function(){return new fi(this)};var re=wh(214);eh(108,1,{},fi);_.W=pp;_.X=function(){return this.a<this.b.a.length};_.Y=function(){return mi(this.b,this.a++)};_.a=0;var qe=wh(108);eh(52,213,{39:1},gi);_.Q=function(){var a;a=new ei((new bi(this.a)).a);return new hi(a)};_.T=qp;var te=wh(52);eh(131,1,{},hi);_.W=pp;_.X=function(){return this.a.b};_.Y=function(){var a;a=di(this.a);return a._()};var se=wh(131);eh(129,1,_o);_.o=function(a){var b;if(!hd(a,40)){return false}b=a;return zi(this.a,b.$())&&zi(this.b,b._())};_.$=np;_._=rp;_.q=function(){return $i(this.a)^$i(this.b)};_.ab=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ue=wh(129);eh(130,129,_o,ii);var ve=wh(130);eh(218,1,_o);_.o=function(a){var b;if(!hd(a,40)){return false}b=a;return zi(this.b.value[0],b.$())&&zi(Wi(this),b._())};_.q=function(){return $i(this.b.value[0])^$i(Wi(this))};_.r=function(){return this.b.value[0]+'='+Wi(this)};var we=wh(218);eh(13,214,{3:1,13:1,39:1,224:1},si,ti);_.Z=function(a,b){Lj(this.a,a,b)};_.S=function(a){return ki(this,a)};_.P=function(a){li(this,a)};_.Q=function(){return new ui(this)};_.T=function(){return this.a.length};var Ae=wh(13);eh(16,1,{},ui);_.W=pp;_.X=function(){return this.a<this.c.a.length};_.Y=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ze=wh(16);eh(36,128,{3:1,36:1,199:1},Ai);var Be=wh(36);eh(55,1,{},Gi);_.P=sp;_.Q=function(){return new Hi(this)};_.b=0;var De=wh(55);eh(56,1,{},Hi);_.W=pp;_.Y=function(){return this.d=this.a[this.c++],this.d};_.X=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ce=wh(56);var Ki;eh(53,1,{},Ui);_.P=sp;_.Q=function(){return new Vi(this)};_.b=0;_.c=0;var Ge=wh(53);eh(54,1,{},Vi);_.W=pp;_.Y=function(){return this.c=this.a,this.a=this.b.next(),new Xi(this.d,this.c,this.d.c)};_.X=function(){return !this.a.done};var Ee=wh(54);eh(138,218,_o,Xi);_.$=function(){return this.b.value[0]};_._=function(){return Wi(this)};_.ab=function(a){return Si(this.a,this.b.value[0],a)};_.c=0;var Fe=wh(138);eh(141,1,{});_.W=up;_.bb=function(){return this.d};_.cb=tp;_.d=0;_.e=0;var Ke=wh(141);eh(58,141,{});var He=wh(58);eh(133,1,{});_.W=up;_.bb=rp;_.cb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Je=wh(133);eh(134,133,{},fj);_.W=function(a){cj(this,a)};_.db=function(a){return dj(this,a)};var Ie=wh(134);eh(22,1,{},hj);_.bb=np;_.cb=function(){gj(this);return this.c};_.W=function(a){gj(this);this.d.W(a)};_.db=function(a){gj(this);if(this.d.X()){a.w(this.d.Y());return true}return false};_.a=0;_.c=0;var Le=wh(22);eh(49,1,{},jj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Me=wh(49);eh(33,1,{},kj);_.R=function(a){return a};var Ne=wh(33);eh(37,1,{},lj);var Oe=wh(37);eh(140,1,{});_.c=false;var Ye=wh(140);eh(25,140,{},vj);var Xe=wh(25);eh(65,1,{},yj);_.eb=function(a){return Yc(fe,Qo,1,a,5,1)};var Pe=wh(65);eh(143,58,{},Aj);_.db=function(a){this.b=false;while(!this.b&&this.c.db(new Bj(this,a)));return this.b};_.b=false;var Re=wh(143);eh(146,1,{},Bj);_.w=function(a){zj(this.a,this.b,a)};var Qe=wh(146);eh(142,58,{},Dj);_.db=function(a){return this.b.db(new Ej(this,a))};var Te=wh(142);eh(145,1,{},Ej);_.w=function(a){Cj(this.a,this.b,a)};var Se=wh(145);eh(144,1,{},Gj);_.w=function(a){Fj(this,a)};var Ue=wh(144);eh(147,1,{},Hj);_.w=function(a){};var Ve=wh(147);eh(148,1,{},Jj);_.w=function(a){Ij(this,a)};var We=wh(148);eh(280,1,{});eh(277,1,{});var Pj=0;var Rj,Sj=0,Tj;eh(897,1,{});eh(919,1,{});eh(219,1,{});var Ze=wh(219);eh(156,1,{},fk);_.eb=function(a){return new Array(a)};var $e=wh(156);eh(245,$wnd.Function,{},gk);_.gb=function(a){ek(this.a,this.b,a)};eh(6,29,{3:1,27:1,29:1,6:1},Rk);var uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk;var _e=xh(6,Sk);var Tk;eh(246,$wnd.Function,{},Vk);_.I=function(a){return Db(Tk),Tk=null,null};eh(222,219,{});var If=wh(222);eh(172,222,{});_.d=0;var Mf=wh(172);eh(173,172,Ro,al);_.t=wp;_.o=vp;_.q=op;_.u=xp;_.r=function(){var a;return sh(jf),jf.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var Zk=0;var jf=wh(173);eh(174,1,Uo,bl);_.v=function(){$k(this.a)};var af=wh(174);eh(175,1,{},cl);_.s=function(){return qh(),S((dn(),an).b).a>0?true:false};var bf=wh(175);eh(176,1,{},dl);_.v=function(){Xk(this.a)};var cf=wh(176);eh(177,1,{},el);_.s=function(){return Yk(this.a)};var df=wh(177);eh(223,219,{});var Hf=wh(223);eh(193,223,{});_.c=0;var Lf=wh(193);eh(194,193,Ro,jl);_.t=yp;_.o=vp;_.q=op;_.u=zp;_.r=function(){var a;return sh(hf),hf.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var hl=0;var hf=wh(194);eh(195,1,Uo,kl);_.v=Ap;var ef=wh(195);eh(196,1,{},ll);_.v=function(){gl(this.a)};var ff=wh(196);eh(197,1,{},ml);_.s=function(){var a,b;return this.a.c=0,Uk(),a=S((dn(),an).e).a,b='item'+(a==1?'':'s'),dk('span',hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,['todo-count'])),[dk('strong',null,[a]),' '+b+' left'])};var gf=wh(197);eh(164,219,{});_.e='';var Uf=wh(164);eh(165,164,{});_.d=0;var Of=wh(165);eh(166,165,Ro,yl);_.t=wp;_.o=vp;_.q=op;_.u=xp;_.r=function(){var a;return sh(pf),pf.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var sl=0;var pf=wh(166);eh(167,1,Uo,zl);_.v=function(){tl(this.a)};var kf=wh(167);eh(169,1,{},Al);_.s=function(){return rl(this.a)};var lf=wh(169);eh(170,1,Uo,Bl);_.v=function(){nl(this.a)};var mf=wh(170);eh(171,1,Uo,Cl);_.v=function(){vl(this.a,this.b)};var nf=wh(171);eh(168,1,{},Dl);_.v=function(){Xk(this.a)};var of=wh(168);eh(221,219,{});_.i=false;var Wf=wh(221);eh(179,221,{});_.f=0;var Qf=wh(179);eh(180,179,Ro,Yl);_.t=function(){gc(this.e)};_.o=vp;_.q=op;_.u=function(){return this.e.f<0};_.r=function(){var a;return sh(Af),Af.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var Nl=0;var Af=wh(180);eh(181,1,Uo,Zl);_.v=function(){Ol(this.a)};var qf=wh(181);eh(184,1,{},$l);_.s=function(){return Ml(this.a)};var rf=wh(184);eh(59,1,Uo,_l);_.v=function(){Xl(this.a,nn(this.b))};var sf=wh(59);eh(60,1,Uo,am);_.v=function(){Hl(this.a,this.b)};var tf=wh(60);eh(185,1,Uo,bm);_.v=function(){Ql(this.a,this.b)};var uf=wh(185);eh(186,1,Uo,cm);_.v=function(){Wl(this.a,this.b);to((dn(),cn),null)};var vf=wh(186);eh(182,1,{},dm);_.s=function(){return Rl(this.a)};var wf=wh(182);eh(187,1,Uo,em);_.v=function(){El(this.a,this.b)};var xf=wh(187);eh(188,1,Uo,fm);_.v=function(){Il(this.a)};var yf=wh(188);eh(183,1,{},gm);_.v=function(){Ll(this.a)};var zf=wh(183);eh(220,219,{});var Zf=wh(220);eh(150,220,{});_.c=0;var Sf=wh(150);eh(151,150,Ro,lm);_.t=yp;_.o=vp;_.q=op;_.u=zp;_.r=function(){var a;return sh(Ef),Ef.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var jm=0;var Ef=wh(151);eh(152,1,Uo,mm);_.v=Ap;var Bf=wh(152);eh(153,1,{},nm);_.v=function(){gl(this.a)};var Cf=wh(153);eh(154,1,{},om);_.s=function(){return this.a.c=0,Uk(),dk('div',null,[dk('div',null,[dk(hp,hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,[hp])),[dk('h1',null,['todos']),(new Om).a]),S((dn(),an).d)?dk('section',hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,[hp])),[dk(gp,ok(rk(hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,['toggle-all'])),(Qk(),vk)),gh(Ym.prototype.ib,Ym,[])),null),dk('ul',hk(new $wnd.Object,_c(Wc(ie,1),Qo,2,6,['todo-list'])),uj(sj(S(cn.c).V(),new Zm),new fk))]):null,S(an.d)?(new qm).a:null])])};var Df=wh(154);eh(250,$wnd.Function,{},pm);_.kb=function(a){co((dn(),bn))};eh(158,1,{},qm);var Ff=wh(158);eh(178,1,{},rm);var Gf=wh(178);eh(251,$wnd.Function,{},sm);_.lb=function(a){return new vm(a)};var tm;eh(162,$wnd.React.Component,{},vm);dh(ah[1],_);_.componentWillUnmount=function(){Wk(this.a)};_.render=function(){return _k(this.a)};_.shouldComponentUpdate=Bp;var Jf=wh(162);eh(261,$wnd.Function,{},wm);_.lb=function(a){return new zm(a)};var xm;eh(189,$wnd.React.Component,{},zm);dh(ah[1],_);_.componentWillUnmount=function(){fl(this.a)};_.render=function(){return il(this.a)};_.shouldComponentUpdate=Cp;var Kf=wh(189);eh(249,$wnd.Function,{},Am);_.lb=function(a){return new Dm(a)};var Bm;eh(161,$wnd.React.Component,{},Dm);dh(ah[1],_);_.componentWillUnmount=function(){Wk(this.a)};_.render=function(){return wl(this.a)};_.shouldComponentUpdate=Bp;var Nf=wh(161);eh(252,$wnd.Function,{},Em);_.lb=function(a){return new Hm(a)};var Fm;eh(163,$wnd.React.Component,{},Hm);dh(ah[1],_);_.componentDidUpdate=function(a){Ul(this.a)};_.componentWillUnmount=function(){Kl(this.a)};_.render=function(){return Vl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Pf=wh(163);eh(244,$wnd.Function,{},Im);_.lb=function(a){return new Lm(a)};var Jm;eh(135,$wnd.React.Component,{},Lm);dh(ah[1],_);_.componentWillUnmount=function(){fl(this.a)};_.render=function(){return km(this.a)};_.shouldComponentUpdate=Cp;var Rf=wh(135);eh(247,$wnd.Function,{},Mm);_.jb=function(a){ol(this.a,a)};eh(248,$wnd.Function,{},Nm);_.ib=function(a){ul(this.a,a)};eh(157,1,{},Om);var Tf=wh(157);eh(259,$wnd.Function,{},Pm);_.ib=function(a){Pl(this.a,a)};eh(253,$wnd.Function,{},Qm);_.ib=function(a){Hn(this.a)};eh(255,$wnd.Function,{},Rm);_.kb=function(a){Sl(this.a,this.b)};eh(256,$wnd.Function,{},Sm);_.kb=function(a){Jl(this.a)};eh(257,$wnd.Function,{},Tm);_.w=function(a){Fl(this.a,a)};eh(258,$wnd.Function,{},Um);_.hb=function(a){Tl(this.a,this.b)};eh(260,$wnd.Function,{},Vm);_.jb=function(a){Gl(this.a,this.b,a)};eh(160,1,{},Xm);var Vf=wh(160);eh(243,$wnd.Function,{},Ym);_.ib=function(a){var b;b=a.target;ho((dn(),bn),b.checked)};eh(136,1,{},Zm);_.R=function(a){return Wm(new Xm,a)};var Xf=wh(136);eh(63,1,{},$m);var Yf=wh(63);var _m,an,bn,cn;eh(92,1,{});var Eg=wh(92);eh(93,92,jp,rn);_.t=wp;_.o=vp;_.q=op;_.u=xp;_.A=Dp;_.r=function(){var a;return sh(fg),fg.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var fg=wh(93);eh(94,1,Uo,sn);_.v=function(){ln(this.a)};var $f=wh(94);eh(96,1,{},tn);_.v=function(){fn(this.a)};var _f=wh(96);eh(97,1,{},un);_.v=function(){gn(this.a)};var ag=wh(97);eh(98,1,Uo,vn);_.v=function(){en(this.a,this.b)};var bg=wh(98);eh(99,1,Uo,wn);_.v=function(){on(this.a)};var cg=wh(99);eh(51,1,Uo,xn);_.v=function(){kn(this.a)};var dg=wh(51);eh(95,1,{},yn);_.s=function(){var a;return a=(mh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var eg=wh(95);eh(43,1,{43:1});_.d=false;var Mg=wh(43);eh(190,43,{9:1,61:1,43:1},In);_.t=wp;_.o=vp;_.q=op;_.u=xp;_.A=Dp;_.r=function(){var a;return sh(vg),vg.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var zn=0;var vg=wh(190);eh(191,1,Uo,Jn);_.v=function(){An(this.a)};var gg=wh(191);eh(192,1,Uo,Kn);_.v=function(){En(this.a)};var hg=wh(192);eh(111,110,{});var Hg=wh(111);eh(112,111,Ro,Tn);_.t=Ep;_.o=vp;_.q=op;_.u=Fp;_.r=function(){var a;return sh(qg),qg.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var qg=wh(112);eh(114,1,Uo,Un);_.v=function(){Mn(this.a)};var ig=wh(114);eh(113,1,Uo,Vn);_.v=function(){Qn(this.a)};var jg=wh(113);eh(119,1,Uo,Wn);_.v=function(){ac(this.a,this.b,true)};var kg=wh(119);eh(120,1,{},Xn);_.s=function(){return Ln(this.a,this.c,this.b)};_.b=false;var lg=wh(120);eh(115,1,{},Yn);_.s=function(){return Rn(this.a)};var mg=wh(115);eh(116,1,{},Zn);_.s=function(){return Hh(Wg(qj(Pn(this.a))))};var ng=wh(116);eh(117,1,{},$n);_.s=function(){return Hh(Wg(qj(rj(Pn(this.a),new Io))))};var og=wh(117);eh(118,1,{},_n);_.s=function(){return Sn(this.a)};var pg=wh(118);eh(86,1,{});var Lg=wh(86);eh(87,86,jp,io);_.t=function(){gc(this.a)};_.o=vp;_.q=op;_.u=function(){return this.a.f<0};_.A=function(a){kc(this.a,a)};_.r=function(){var a;return sh(ug),ug.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var ug=wh(87);eh(88,1,Uo,jo);_.v=function(){eo(this.a,this.b)};_.b=false;var rg=wh(88);eh(89,1,Uo,ko);_.v=function(){xl(this.b,this.a)};var sg=wh(89);eh(90,1,Uo,lo);_.v=function(){fo(this.a)};var tg=wh(90);eh(100,1,{});var Og=wh(100);eh(101,100,jp,uo);_.t=Ep;_.o=vp;_.q=op;_.u=Fp;_.A=function(a){kc(this.f,a)};_.r=function(){var a;return sh(Cg),Cg.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var Cg=wh(101);eh(102,1,Uo,vo);_.v=function(){po(this.a)};var wg=wh(102);eh(103,1,Uo,wo);_.v=function(){oo(this.a)};var xg=wh(103);eh(105,1,{},xo);_.s=function(){return ro(this.a)};var yg=wh(105);eh(106,1,{},yo);_.v=function(){so(this.a)};var zg=wh(106);eh(107,1,Uo,zo);_.v=function(){to(this.a,null)};var Ag=wh(107);eh(104,1,{},Ao);_.s=function(){var a;return a=nn(this.a.g),o(lp,a)?(Fo(),Co):o(mp,a)?(Fo(),Eo):(Fo(),Do)};var Bg=wh(104);eh(91,1,{},Bo);_.handleEvent=function(a){hn(this.a,a)};var Dg=wh(91);eh(30,29,{3:1,27:1,29:1,30:1},Go);var Co,Do,Eo;var Fg=xh(30,Ho);eh(80,1,{},Io);_.fb=function(a){return !Dn(a)};var Gg=wh(80);eh(84,1,{},Jo);_.fb=function(a){return Dn(a)};var Ig=wh(84);eh(85,1,{},Ko);_.w=function(a){On(this.a,a)};var Jg=wh(85);eh(83,1,{},Lo);_.w=function(a){bo(this.a,a)};_.a=false;var Kg=wh(83);eh(76,1,{},Mo);_.fb=function(a){return no(this.a,a)};var Ng=wh(76);var pd=yh('D');var No=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=$g;Yg(kh);_g('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();