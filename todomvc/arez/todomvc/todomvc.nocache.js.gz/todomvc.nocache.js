function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='5B141E8142915C220EB88448BC35D168',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '5B141E8142915C220EB88448BC35D168';function p(){}
function uh(){}
function qh(){}
function _h(){}
function Gb(){}
function Sc(){}
function Zc(){}
function uj(){}
function Ij(){}
function Qj(){}
function Rj(){}
function ok(){}
function Fk(){}
function Ok(){}
function am(){}
function dm(){}
function hm(){}
function lm(){}
function pm(){}
function tm(){}
function Jm(){}
function Km(){}
function jn(){}
function ro(){}
function so(){}
function Xc(a){Wc()}
function Bh(){Bh=qh}
function Ci(){ti(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function hc(a){this.a=a}
function qc(a){this.a=a}
function qi(a){this.a=a}
function li(a){this.a=a}
function ri(a){this.a=a}
function Qh(a){this.a=a}
function $h(a){this.a=a}
function vj(a){this.a=a}
function Tj(a){this.a=a}
function Nk(a){this.a=a}
function Pk(a){this.a=a}
function Qk(a){this.a=a}
function Wk(a){this.a=a}
function Xk(a){this.a=a}
function Yk(a){this.a=a}
function jl(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function Jl(a){this.a=a}
function Kl(a){this.a=a}
function Ll(a){this.a=a}
function Ml(a){this.a=a}
function Ql(a){this.a=a}
function Tl(a){this.a=a}
function Zl(a){this.a=a}
function $l(a){this.a=a}
function _l(a){this.a=a}
function xm(a){this.a=a}
function ym(a){this.a=a}
function Am(a){this.a=a}
function Bm(a){this.a=a}
function Dm(a){this.a=a}
function Em(a){this.a=a}
function Ei(a){this.c=a}
function pi(a){this.b=a}
function cn(a){this.a=a}
function dn(a){this.a=a}
function en(a){this.a=a}
function gn(a){this.a=a}
function hn(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Jn(a){this.a=a}
function Kn(a){this.a=a}
function Ln(a){this.a=a}
function Mn(a){this.a=a}
function Xn(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function ho(a){this.a=a}
function io(a){this.a=a}
function jo(a){this.a=a}
function ko(a){this.a=a}
function to(a){this.a=a}
function uo(a){this.a=a}
function vo(a){this.a=a}
function Jo(a){this.a=a}
function Ko(a){this.a=a}
function Mo(a){this.a=a}
function Oo(a){this.a=a}
function Pj(a,b){a.a=b}
function rb(a,b){a.b=b}
function jk(a,b){a.key=b}
function hk(a,b){gk(a,b)}
function On(a,b){Hl(b,a)}
function Z(a){!!a&&ab(a)}
function lc(a){!!a&&a.r()}
function w(a){--a.e;D(a)}
function qp(a){gj(this,a)}
function vp(a){jj(this,a)}
function tp(a){Uh(this,a)}
function wp(){kc(this.c)}
function yp(){kc(this.b)}
function Dp(){kc(this.f)}
function Qi(){this.a=Zi()}
function cj(){this.a=Zi()}
function Ap(){lb(this.a.a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function ah(a){return a.e}
function up(){return this.e}
function op(){return this.a}
function sp(){return this.b}
function K(){K=qh;J=new F}
function yc(){yc=qh;xc=new p}
function Pc(){Pc=qh;Oc=new Sc}
function Vi(){Vi=qh;Ui=Xi()}
function Gk(a){a.e=2;kc(a.c)}
function Rk(a){a.d=2;kc(a.b)}
function ul(a){a.g=2;kc(a.e)}
function Xm(a){S(a.a);ab(a.b)}
function Kk(a){lb(a.b);S(a.a)}
function L(a,b){P(a);M(a,b)}
function yo(a,b){Eo(a);M(a,b)}
function Sj(a,b){Hj(a.a,b)}
function oc(a,b){hi(a.e,b)}
function Nn(a,b){zn(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function jc(a,b,c){gi(a.e,b,c)}
function oj(a,b,c){b.v(a.a[c])}
function wi(a,b){return a.a[b]}
function pl(a,b){return a.j=b}
function pp(){return $j(this)}
function Ah(a){wc.call(this,a)}
function ai(a){wc.call(this,a)}
function tl(a){An((Qm(),Nm),a)}
function dl(a){lb(a.a);ab(a.b)}
function ln(a){ab(a.b);ab(a.a)}
function tc(a,b){a.e=b;sc(a,b)}
function Xj(a,b){a.splice(b,1)}
function mn(a,b,c){jc(a.c,b,c)}
function $c(a,b){return Kh(a,b)}
function rp(){return ji(this.a)}
function xp(){return this.c.i<0}
function zp(){return this.b.i<0}
function Ep(){return this.f.i<0}
function Zi(){Vi();return new Ui}
function Eh(a){Dh(a);return a.k}
function Gj(a,b){a.Q(b);return a}
function U(a){nb(a.f);return W(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function bb(a){K();Zb(a);a.e=-2}
function Hj(a,b){Pj(a,Gj(a.a,b))}
function jj(a,b){while(a.bb(b));}
function Mj(a,b,c){b.v(a.a.P(c))}
function v(a,b,c){t(a,new I(c),b)}
function No(a,b){return xo(a.a,b)}
function ji(a){return a.a.b+a.b.b}
function Bp(a){return 1==this.a.e}
function Cp(a){return 1==this.a.d}
function pn(a){gb(a.a);return a.d}
function _n(a){gb(a.d);return a.e}
function Zm(a){gb(a.b);return a.e}
function rk(a,b){a.ref=b;return a}
function ic(a,b){this.a=a;this.b=b}
function si(a,b){this.a=a;this.b=b}
function Lj(a,b){this.a=a;this.b=b}
function Oj(a,b){this.a=a;this.b=b}
function pk(a,b){this.a=a;this.b=b}
function nl(a,b){this.a=a;this.b=b}
function Nl(a,b){this.a=a;this.b=b}
function Ol(a,b){this.a=a;this.b=b}
function Pl(a,b){this.a=a;this.b=b}
function Rl(a,b){this.a=a;this.b=b}
function Sl(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function Cm(a,b){this.a=a;this.b=b}
function Fm(a,b){this.a=a;this.b=b}
function Gm(a,b){this.a=a;this.b=b}
function _i(a,b){return a.a.get(b)}
function sk(a,b){a.href=b;return a}
function Vj(a,b,c){a.splice(b,0,c)}
function Fc(){Fc=qh;!!(Wc(),Vc)}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function jh(){hh==null&&(hh=[])}
function bm(){this.a=lk((fm(),em))}
function cm(){this.a=lk((jm(),im))}
function zm(){this.a=lk((nm(),mm))}
function Im(){this.a=lk((rm(),qm))}
function Lm(){this.a=lk((vm(),um))}
function $m(a){Ym(a,(gb(a.b),a.e))}
function qn(a){Hl(a,(gb(a.a),!a.d))}
function fi(a){return !a?null:a.Z()}
function rd(a){return a==null?null:a}
function Ub(a){return !a.d?a:Ub(a.d)}
function o(a,b){return rd(a)===rd(b)}
function po(a,b){this.a=a;this.b=b}
function fn(a,b){this.a=a;this.b=b}
function Hn(a,b){this.a=a;this.b=b}
function Vn(a,b){this.a=a;this.b=b}
function Wn(a,b){this.b=a;this.a=b}
function jb(a){this.c=new Ci;this.b=a}
function ii(a){a.a=new Qi;a.b=new cj}
function zo(a){a.b=0;a.d=0;a.c=false}
function ti(a){a.a=ad(ke,Vo,1,0,5,1)}
function qb(a){K();pb(a);tb(a,2,true)}
function yl(a){lb(a.b);S(a.c);ab(a.a)}
function Mc(a){$wnd.clearTimeout(a)}
function ij(a){return a!=null?s(a):0}
function Ro(a){return No((Qo(),Po),a)}
function B(a,b,c){return u(a,c,2048,b)}
function A(a,b,c){u(a,new H(b),c,null)}
function Wj(a,b){Uj(b,0,a,0,b.length)}
function gc(a,b){cc(a,b,false);fb(a.c)}
function gk(a,b){for(var c in a){b(c)}}
function Bk(a,b){a.value=b;return a}
function wk(a,b){a.onBlur=b;return a}
function tk(a,b){a.onClick=b;return a}
function xk(a,b){a.onChange=b;return a}
function vk(a,b){a.checked=b;return a}
function Yh(a,b){a.a+=''+b;return a}
function Qn(a,b){vi(ec(a.b),new uo(b))}
function Vh(a,b){return a.charCodeAt(b)}
function md(a,b){return a!=null&&kd(a,b)}
function $(a){return !(md(a,8)&&a.u())}
function $j(a){return a.$H||(a.$H=++Zj)}
function uk(a){return a.autoFocus=true,a}
function od(a){return typeof a==='number'}
function qd(a){return typeof a==='string'}
function ed(a,b,c){return {l:a,m:b,h:c}}
function ik(a,b){a.props['a']=b;return a}
function yk(a,b){a.onKeyDown=b;return a}
function Dh(a){if(a.k!=null){return}Mh(a)}
function Io(){this.d=new Fo;this.b=100}
function Ki(){this.a=new Qi;this.b=new cj}
function ck(){ck=qh;_j=new p;bk=new p}
function Qo(){Qo=qh;Po=new Oo(new Io)}
function Q(){this.a=ad(ke,Vo,1,100,5,1)}
function Fo(){this.a=ad(ke,Vo,1,100,5,1)}
function wc(a){this.g=a;rc(this);this.D()}
function Fj(a,b){yj.call(this,a);this.a=b}
function fc(a,b){oc(b.c,a);md(b,8)&&b.t()}
function gj(a,b){while(a.V()){Sj(b,a.W())}}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function Si(a,b){var c;c=a[ep];c.call(a,b)}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function rc(a){a.j&&a.e!==_o&&a.D();return a}
function Ak(a){a.type='checkbox';return a}
function Ck(a,b){a.onDoubleClick=b;return a}
function Hh(a){var b;b=Gh(a);Oh(a,b);return b}
function $n(a){lb(a.a);S(a.b);S(a.c);ab(a.d)}
function tn(a){A((K(),K(),J),new wn(a),hp)}
function Pn(a){A((K(),K(),J),new Xn(a),hp)}
function _m(a){A((K(),K(),J),new gn(a),hp)}
function Fl(a){A((K(),K(),J),new Tl(a),hp)}
function Dn(a){return Rh(T(a.e).a-T(a.a).a)}
function nd(a){return typeof a==='boolean'}
function Gc(a,b,c){return a.apply(b,c);var d}
function fj(a,b,c){this.a=a;this.b=b;this.c=c}
function yh(a,b,c,d){a.addEventListener(b,c,d)}
function ui(a,b){a.a[a.a.length]=b;return true}
function mj(a,b){while(a.c<a.d){oj(a,b,a.c++)}}
function Db(a){while(true){if(!Cb(a)){break}}}
function Go(a){while(true){if(!Ho(a)){break}}}
function Th(){Th=qh;Sh=ad(he,Vo,26,256,0,1)}
function Wc(){Wc=qh;var a;!Yc();a=new Zc;Vc=a}
function gl(a,b){var c;c=b.target;hl(a,c.value)}
function fl(a,b){A((K(),K(),J),new nl(a,b),hp)}
function Al(a,b){A((K(),K(),J),new Sl(a,b),hp)}
function Dl(a,b){A((K(),K(),J),new Pl(a,b),hp)}
function El(a,b){A((K(),K(),J),new Ol(a,b),hp)}
function Gl(a,b){A((K(),K(),J),new Nl(a,b),hp)}
function An(a,b){A((K(),K(),J),new Hn(a,b),hp)}
function Sn(a,b){A((K(),K(),J),new Wn(a,b),hp)}
function Tn(a,b){A((K(),K(),J),new Vn(a,b),hp)}
function Bn(a){Uh(new qi(a.g),new hc(a));ii(a.g)}
function Yn(a){return o(mp,a)||o(np,a)||o('',a)}
function cd(a){return Array.isArray(a)&&a.mb===uh}
function qj(a){if(!a.d){a.d=a.b.O();a.c=a.b.R()}}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function Lo(a){if(a.a){Fb(Dk);Dk=null;a.a=null}}
function In(a,b){this.a=a;this.c=b;this.b=false}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function $i(a,b){return !(a.a.get(b)===undefined)}
function zj(a,b){var c;return Dj(a,(c=new Ci,c))}
function yi(a,b){var c;c=a.a[b];Xj(a.a,b);return c}
function ni(a){var b;b=a.a.W();a.b=mi(a);return b}
function Jh(a){var b;b=Gh(a);b.j=a;b.e=1;return b}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Fi(a,b){return kj(b,a.length),new pj(a,b)}
function Lk(a){return B((K(),K(),J),a.b,new Pk(a))}
function Uk(a){return B((K(),K(),J),a.a,new Yk(a))}
function el(a){return B((K(),K(),J),a.a,new kl(a))}
function Cn(a){return Bh(),0!=T(a.e).a?true:false}
function zl(a){return B((K(),K(),J),a.b,new Ll(a))}
function Xl(a){return B((K(),K(),J),a.a,new _l(a))}
function Gi(a){return new Fj(null,Fi(a,a.length))}
function ld(a){return !Array.isArray(a)&&a.mb===uh}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function yn(a){S(a.d);S(a.e);S(a.a);S(a.b);ab(a.c)}
function Ik(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function Sk(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function wl(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function wj(a){if(!a.b){xj(a);a.c=true}else{wj(a.b)}}
function Jj(a,b,c){if(a.a.db(c)){a.b=true;b.v(c)}}
function Hl(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function hl(a,b){var c;c=a.f;if(b!=c){a.f=b;fb(a.b)}}
function an(a,b){var c;c=a.e;if(b!=c){a.e=b;fb(a.b)}}
function Ai(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ki(a,b){if(b){return di(a.a,b)}return false}
function Bj(a,b){xj(a);return new Fj(a,new Kj(b,a.a))}
function Cj(a,b){xj(a);return new Fj(a,new Nj(b,a.a))}
function Ym(a,b){A((K(),K(),J),new fn(a,b),75497472)}
function zh(a,b,c,d){a.removeEventListener(b,c,d)}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Wm(a){var b;V(a.a);b=T(a.a);o(a.f,b)&&an(a,b)}
function Ji(a,b){return rd(a)===rd(b)||a!=null&&q(a,b)}
function lj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function rj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function pj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function yj(a){if(!a){this.b=null;new Ci}else{this.b=a}}
function Lh(a){if(a.M()){return null}var b=a.j;return mh[b]}
function gh(a){if(od(a)){return a|0}return a.l|a.m<<22}
function fk(){if(ak==256){_j=bk;bk=new p;ak=0}++ak}
function xh(){xh=qh;wh=$wnd.goog.global.document}
function qo(){oo();return dd($c(Jg,1),Vo,27,0,[lo,no,mo])}
function Bl(a){return Bh(),_n((Qm(),Pm))==a.i?true:false}
function ei(a,b){return b===a?'(this Map)':b==null?bp:th(b)}
function uc(a,b){var c;c=Eh(a.kb);return b==null?c:c+': '+b}
function Ih(a,b){var c;c=Gh(a);Oh(a,c);c.e=b?8:0;return c}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function ol(a,b){var c;if(T(a.c)){c=b.target;Hl(a,c.value)}}
function Uh(a,b){var c,d;for(d=a.O();d.V();){c=d.W();b.v(c)}}
function Kh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function xj(a){if(a.b){xj(a.b)}else if(a.c){throw ah(new Ph)}}
function Ek(){if(!Dk){Dk=(++(K(),K(),J).e,new Gb);Ro(new Fk)}}
function mb(a){C((K(),K(),J),a);0==(a.f.a&Zo)&&D((null,J))}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function Mi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Cl(a,b){co((Qm(),Pm),b);A((K(),K(),J),new Nl(a,b),hp)}
function Sm(a){yh((xh(),$wnd.goog.global.window),kp,a.d,false)}
function Tm(a){zh((xh(),$wnd.goog.global.window),kp,a.d,false)}
function fm(){fm=qh;var a;em=(a=rh(dm.prototype.jb,dm,[]),a)}
function jm(){jm=qh;var a;im=(a=rh(hm.prototype.jb,hm,[]),a)}
function nm(){nm=qh;var a;mm=(a=rh(lm.prototype.jb,lm,[]),a)}
function rm(){rm=qh;var a;qm=(a=rh(pm.prototype.jb,pm,[]),a)}
function vm(){vm=qh;var a;um=(a=rh(tm.prototype.jb,tm,[]),a)}
function sh(a){function b(){}
;b.prototype=a||{};return new b}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function zk(a){a.placeholder='What needs to be done?';return a}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function Ri(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Un(a){this.b=a;K();this.a=new pc(0,null,null,false,false)}
function dc(a){gb(a.c);return new Fj(null,new rj(new qi(a.g),0))}
function Rn(a){zj(Bj(dc(a.b),new so),new vj(new uj)).N(new to(a.b))}
function nc(a){lc(a.g);!!a.e&&mc(a);Z(a.a);Z(a.c);lc(a.b);lc(a.f)}
function Di(a){ti(this);Wj(this.a,ci(a,ad(ke,Vo,1,ji(a.a),5,1)))}
function Ni(a,b){var c;return Li(b,Mi(a,b==null?0:(c=s(b),c|0)))}
function oh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function nk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function Um(a,b){b.preventDefault();A((K(),K(),J),new hn(a),hp)}
function Nj(a,b){lj.call(this,b.ab(),b._()&-6);this.a=a;this.b=b}
function Kj(a,b){lj.call(this,b.ab(),b._()&-16449);this.a=a;this.c=b}
function cb(a,b){var c,d;ui(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function nj(a,b){if(a.c<a.d){oj(a,b,a.c++);return true}return false}
function gm(a){$wnd.React.Component.call(this,a);this.a=new Mk(this)}
function km(a){$wnd.React.Component.call(this,a);this.a=new Vk(this)}
function om(a){$wnd.React.Component.call(this,a);this.a=new il(this)}
function sm(a){$wnd.React.Component.call(this,a);this.a=new Il(this)}
function wm(a){$wnd.React.Component.call(this,a);this.a=new Yl(this)}
function dj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function sj(a,b){!a.a?(a.a=new $h(a.d)):Yh(a.a,a.b);Yh(a.a,b);return a}
function Dj(a,b){var c;wj(a);c=new Qj;c.a=b;a.a.U(new Tj(c));return c.a}
function Aj(a){var b;wj(a);b=0;while(a.a.bb(new Rj)){b=bh(b,1)}return b}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function hi(a,b){return qd(b)?b==null?Pi(a.a,null):bj(a.b,b):Pi(a.a,b)}
function Zn(a,b){return (oo(),mo)==a||(lo==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function zn(a,b){var c;return u((K(),K(),J),new In(a,b),hp,(c=null,c))}
function Ej(a,b){var c;c=zj(a,new vj(new uj));return Bi(c,b.cb(c.a.length))}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function ej(a){if(a.a.c!=a.c){return _i(a.a,a.b.value[0])}return a.b.value[1]}
function Jb(b){try{nb(b.b.a)}catch(a){a=_g(a);if(!md(a,5))throw ah(a)}}
function Rm(a,b){a.f=b;o(b,T(a.a))&&an(a,b);Vm(b);A((K(),K(),J),new hn(a),hp)}
function Qm(){Qm=qh;Nm=new En;Om=new Un(Nm);Mm=new bn;Pm=new eo(Nm,Mm)}
function ao(a){var b;return b=T(a.b),zj(Bj(dc(a.i),new vo(b)),new vj(new uj))}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function nn(a,b){var c;if(md(b,44)){c=b;return a.c.d==c.c.d}else{return false}}
function zi(a,b){var c;c=xi(a,b,0);if(c==-1){return false}Xj(a.a,c);return true}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function xi(a,b,c){for(;c<a.a.length;++c){if(Ji(b,a.a[c])){return c}}return -1}
function W(a){if(a.b){if(md(a.b,7)){throw ah(a.b)}else{throw ah(a.b)}}return a.k}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function S(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function ab(a){if(-2!=a.e){u((K(),K(),J),new H(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function kc(a){if(a.i>=0){a.i=-2;u((K(),K(),J),new H(new qc(a)),67108864,null)}}
function sb(b){if(b){try{b.r()}catch(a){a=_g(a);if(md(a,5)){K()}else throw ah(a)}}}
function Pb(){var a;this.a=ad(yd,Vo,42,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function vi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function Zk(a){var b;b=Xh((gb(a.b),a.f));if(b.length>0){Nn((Qm(),Om),b);hl(a,'')}}
function wo(b){var c;c=Bo(b.d);try{Lo(c)}catch(a){a=_g(a);if(!md(a,5))throw ah(a)}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function $k(a,b){if(13==b.keyCode){b.preventDefault();A((K(),K(),J),new ll(a),hp)}}
function ec(a){return gb(a.c),zj(new Fj(null,new rj(new qi(a.g),0)),new vj(new uj))}
function gi(a,b,c){return qd(b)?b==null?Oi(a.a,null,c):aj(a.b,b,c):Oi(a.a,b,c)}
function Yj(a,b){return _c(b)!=10&&dd(r(b),b.lb,b.__elementTypeId$,_c(b),a),a}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function pd(a){return a!=null&&(typeof a===To||typeof a==='function')&&!(a.mb===uh)}
function oi(a){this.d=a;this.c=new dj(this.d.b);this.a=this.c;this.b=mi(this)}
function tj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?$o:0)|(0!=(b&229376)?0:98304)}
function Hm(a,b){jk(a.a,(b?Rh(b.c.d):null)+(''+(Dh(_f),_f.k)));ik(a.a,b);return a.a}
function Oh(a,b){var c;if(!a){return}b.j=a;var d=Lh(b);if(!d){mh[a]=[b];return}d.kb=b}
function rh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Gh(a){var b;b=new Fh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Ci);a.c=c.c}b.d=true;ui(a.c,b)}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ci);ui(a.b,b)}}}
function Rc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function Qc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Uc(b,c)}while(a.a);a.a=c}}
function pb(a){var b,c;for(c=new Ei(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Hi(a){var b,c,d;d=0;for(c=new oi(a.a);c.b;){b=ni(c);d=d+(b?s(b):0);d=d|0}return d}
function bi(a,b){var c,d;for(d=new oi(b.a);d.b;){c=ni(d);if(!ki(a,c)){return false}}return true}
function bj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Si(a.a,b);--a.b}return c}
function xn(a,b,c){var d;d=new un(b,c);mn(d,a,new ic(a,d));gi(a.g,Rh(d.c.d),d);fb(a.c);return d}
function cc(a,b,c){var d;d=hi(a.g,b?Rh(b.c.d):null);if(null!=d){oc(b.c,a);c&&!!b&&kc(b.c);fb(a.c)}}
function lk(a){var b;b=kk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function dh(a){var b;b=a.h;if(b==0){return a.l+a.m*$o}if(b==1048575){return a.l+a.m*$o-cp}return a}
function _g(a){var b;if(md(a,5)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function mi(a){if(a.a.V()){return true}if(a.a!=a.c){return false}a.a=new Ri(a.d.a);return a.a.V()}
function Ph(){wc.call(this,"Stream already terminated, can't be modified or used")}
function ih(){jh();var a=hh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function vh(){Qm();$wnd.ReactDOM.render((new Lm).a,(xh(),wh).getElementById('app'),null)}
function oo(){oo=qh;lo=new po('ACTIVE',0);no=new po('COMPLETED',1);mo=new po('ALL',2)}
function lh(a,b){typeof window===To&&typeof window['$gwt']===To&&(window['$gwt'][a]=b)}
function kj(a,b){if(0>a||a>b){throw ah(new Ah('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:Xo)|(0==(c&6291456)?!a?Zo:$o:0)|0|0|0)}
function ql(a,b,c){27==c.which?A((K(),K(),J),new Rl(a,b),hp):13==c.which&&A((K(),K(),J),new Ol(a,b),hp)}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function bo(a){var b;b=T(a.g.a);o(mp,b)||o(np,b)||o('',b)?Ym(a.g,b):Yn(Zm(a.g))?_m(a.g):Ym(a.g,'')}
function co(a,b){var c;c=a.e;if(!(b==c||!!b&&nn(b,c))){!!c&&oc(c.c,a);a.e=b;!!b&&mn(b,a,new go(a));fb(a.d)}}
function aj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function dd(a,b,c,d,e){e.kb=a;e.lb=b;e.mb=uh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function fh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=cp;d=1048575}c=sd(e/$o);b=sd(e-c*$o);return ed(b,c,d)}
function Li(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ji(a,c.Y())){return c}}return null}
function Rh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Th(),Sh)[b];!c&&(c=Sh[b]=new Qh(a));return c}return new Qh(a)}
function th(a){var b;if(Array.isArray(a)&&a.mb===uh){return Eh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function sl(a){var b;b=T(a.c);if(!a.k&&b){a.k=true;Gl(a,a.i);a.j.focus();a.j.select()}else a.k&&!b&&(a.k=false)}
function rl(a,b){var c;c=(gb(a.a),a.d);if(null!=c&&c.length!=0){Sn((Qm(),b),c);co(Pm,null);Hl(a,c)}else{An((Qm(),Nm),b)}}
function db(a,b){var c,d;d=a.c;zi(d,b);!!a.b&&Xo!=(a.b.c&Yo)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function Eo(a){var b,c;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){c=$wnd.Math.max(a.a.length-1,1)*2+1;Co(a,c,b)}}
function fd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ed(c&4194303,d&4194303,e&1048575)}
function bh(a,b){var c;if(od(a)&&od(b)){c=a+b;if(-17592186044416<c&&c<cp){return c}}return dh(fd(od(a)?fh(a):a,od(b)?fh(b):b))}
function r(a){return qd(a)?ne:od(a)?ce:nd(a)?ae:ld(a)?a.kb:cd(a)?a.kb:a.kb||Array.isArray(a)&&$c(Ud,1)||Ud}
function s(a){return qd(a)?ek(a):od(a)?sd(a):nd(a)?a?1231:1237:ld(a)?a.p():cd(a)?$j(a):!!a&&!!a.hashCode?a.hashCode():$j(a)}
function Ac(a){yc();rc(this);this.e=a;sc(this,a);this.g=a==null?bp:th(a);this.a='';this.b=a;this.a=''}
function Fh(){this.g=Ch++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Yl(a){var b;this.c=a;K();b=++Wl;this.b=new pc(b,null,new Zl(this),false,false);this.a=new wb(null,new $l(this),gp)}
function Vk(a){var b;this.c=a;K();b=++Tk;this.b=new pc(b,null,new Wk(this),false,false);this.a=new wb(null,new Xk(this),gp)}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=yi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Ii(a){var b,c,d;d=1;for(c=new Ei(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function mc(a){var b,c,d;for(c=new Ei(new Di(new li(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.Y();md(d,8)&&d.u()||b.Z().r()}}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Xo)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(Xo==(b&Yo)?0:524288)|(0==(b&6291456)?Xo==(b&Yo)?$o:Zo:0)|0|268435456|0)}
function ek(a){ck();var b,c,d;c=':'+a;d=bk[c];if(d!=null){return sd(d)}d=_j[c];b=d==null?dk(a):sd(d);fk();bk[c]=b;return b}
function xo(a,b){var c,d;d=0==O(a.d);c=new Mo(b);yo(a.d,c);d&&$wnd.Promise.resolve(null).then(rh(Jo.prototype.G,Jo,[a]));return c}
function Bi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Yj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Nh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return qd(a)?o(a,b):od(a)?rd(a)===rd(b):nd(a)?rd(a)===rd(b):ld(a)?a.n(b):cd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function kd(a,b){if(qd(a)){return !!jd[b]}else if(a.lb){return !!a.lb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function pc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ki:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new jb((f=null,K(),f)),g):null;this.c=null}
function qk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Bo(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}else{b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}}
function T(a){a.j?hb(a.e):gb(a.e);if(ub(a.f)){if(a.j&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Co(a,b,c){var d,e,f,g;d=ad(ke,Vo,1,b,5,1);g=0;for(e=0;e<c;e++){f=(a.b+e)%a.a.length;d[g]=a.a[f];a.a[f]=null;++g}a.a=d;a.b=0;a.d=g;a.c=false}
function Xh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ci(a,b){var c,d,e,f;f=ji(a.a);b.length<f&&(b=Yj(new Array(f),b));e=b;d=new oi(a.a);for(c=0;c<f;++c){e[c]=ni(d)}b.length>f&&(b[f]=null);return b}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.r(),null)}finally{bc()}return f}catch(a){a=_g(a);if(md(a,5)){e=a;throw ah(e)}else throw ah(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.s()}else{ac(b,e);try{g=c.s()}finally{bc()}}return g}catch(a){a=_g(a);if(md(a,5)){f=a;throw ah(f)}else throw ah(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.i=c;this.k=null;this.j=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);Xo==(d&Yo)&&mb(this.f)}
function il(a){var b,c,d;this.d=a;K();b=++cl;this.c=new pc(b,null,new jl(this),false,false);this.b=(d=new jb((c=null,c)),d);this.a=new wb(null,new ml(this),gp)}
function Mk(a){var b;this.d=a;K();b=++Jk;this.c=new pc(b,null,new Nk(this),false,false);this.a=new X(new Ok,null,null,136478720);this.b=new wb(null,new Qk(this),gp)}
function un(a,b){var c,d,e,f,g;this.e=a;this.d=b;K();c=++kn;this.c=new pc(c,null,new vn(this),true,true);this.b=(g=new jb((e=null,e)),g);this.a=(f=new jb((d=null,d)),f)}
function Ho(a){var b;if(0==a.c){b=O(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;zo(a.d);return false}else{a.a=a.a+1;a.c=b}}--a.c;wo(a);return true}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function kh(b,c,d,e){jh();var f=hh;$moduleName=c;$moduleBase=d;$g=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{So(g)()}catch(a){b(c,a)}}else{So(g)()}}
function kk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Xi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Yi()}}
function nh(){mh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].nb()&&(c=Tc(c,g)):g[0].nb()}catch(a){a=_g(a);if(md(a,5)){d=a;Fc();Lc(md(d,32)?d.F():d)}else throw ah(a)}}return c}
function al(a){var b;a.e=0;Ek();b=mk(ip,uk(xk(yk(Bk(zk(qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,['new-todo']))),(gb(a.b),a.f)),rh(xm.prototype.hb,xm,[a])),rh(ym.prototype.gb,ym,[a]))),null);return b}
function zc(a){var b;if(a.c==null){b=rd(a.b)===rd(xc)?null:a.b;a.d=b==null?bp:pd(b)?b==null?null:b.name:qd(b)?'String':Eh(r(b));a.a=a.a+': '+(pd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.k;try{d=b.c.s();if(!(rd(e)===rd(d)||e!=null&&q(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=_g(a);if(md(a,9)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw ah(c)}else throw ah(a)}}
function Oi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Li(b,e);if(f){return f.$(c)}}e[e.length]=new si(b,c);++a.b;return null}
function Uj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function dk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Vh(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{b.e.r()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=_g(a);if(md(a,5)){K()}else throw ah(a)}}}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=ad(ke,Vo,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function vb(a,b,c,d){this.b=new Ci;this.f=new Kb(new zb(this),d&6520832|262144|Xo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&Zo)&&D((null,J)))}
function Pi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ji(b,e.Y())){if(d.length==1){d.length=0;Si(a.a,g)}else{d.splice(h,1)}--a.b;return e.Z()}}return null}
function ph(a,b,c){var d=mh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=mh[b]),sh(h));_.lb=c;!b&&(_.mb=uh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.kb=f)}
function Mh(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Nh('.',[c,Nh('$',d)]);a.b=Nh('.',[c,Nh('.',d)]);a.i=d[d.length-1]}
function di(a,b){var c,d,e;c=b.Y();e=b.Z();d=qd(c)?c==null?fi(Ni(a.a,null)):_i(a.b,c):fi(Ni(a.a,c));if(!(rd(e)===rd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(qd(c)?c==null?!!Ni(a.a,null):$i(a.b,c):!!Ni(a.a,c))){return false}return true}
function Vm(a){var b;if(0==a.length){b=(xh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',wh.title,b)}else{(xh(),$wnd.goog.global.window).location.hash=a}}
function eo(a,b){var c,d;this.i=a;this.g=b;K();this.f=new pc(0,null,new fo(this),false,false);this.d=(d=new jb((c=null,c)),d);this.b=new X(new ho(this),null,null,lp);this.c=new X(new io(this),null,null,lp);this.a=new wb(new jo(this),null,681574400);D((null,J))}
function En(){var a;this.g=new Ki;K();this.f=new pc(0,new Gn(this),new Fn(this),false,false);this.c=(a=new jb(null),a);this.d=new X(new Jn(this),null,null,lp);this.e=new X(new Kn(this),null,null,lp);this.a=new X(new Ln(this),null,null,lp);this.b=new X(new Mn(this),null,null,lp)}
function bn(){var a,b,c;this.d=new ko(this);this.f=this.e=(c=(xh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));K();this.c=new pc(0,null,new cn(this),false,false);this.b=(b=new jb((a=null,a)),b);this.a=new X(new jn,new dn(this),new en(this),35651584)}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ei(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=_g(a);if(!md(a,5))throw ah(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function Il(a){var b,c,d;this.f=a;this.i=a.props['a'];K();b=++xl;this.e=new pc(b,null,new Jl(this),false,false);this.a=(d=new jb((c=null,c)),d);this.c=new X(new Ml(this),null,null,136478720);this.b=new wb(null,new Ql(this),gp);mn(this.i,this,new Kl(this));Gl(this,this.i);D((null,J))}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.B();return a&&a.w()}},suppressed:{get:function(){return c.A()}}})}catch(a){}}}
function mk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;hk(b,rh(pk.prototype.eb,pk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=kk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function Wi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}vi(a.b,new Bb(a));a.b.a=ad(ke,Vo,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=wi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ai(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=wi(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){yi(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Ci)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Xo!=(k.b.c&Yo)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function Hk(a){var b,c;a.e=0;Ek();c=(b=T((Qm(),Pm).b),mk('footer',qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,['footer'])),[(new cm).a,mk('ul',qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,['filters'])),[mk('li',null,[mk('a',sk(qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,[(oo(),mo)==b?fp:null])),'#'),['All'])]),mk('li',null,[mk('a',sk(qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,[lo==b?fp:null])),'#active'),['Active'])]),mk('li',null,[mk('a',sk(qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,[no==b?fp:null])),'#completed'),['Completed'])])]),T(a.a)?mk('button',tk(qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,['clear-completed'])),rh(am.prototype.ib,am,[])),['Clear Completed']):null]));return c}
function vl(a){var b,c,d;a.g=0;Ek();b=(c=a.i,d=(gb(c.a),c.d),mk('li',qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,[d?'checked':null,T(a.c)?'editing':null])),[mk('div',qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,['view'])),[mk(ip,xk(vk(Ak(qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,['toggle']))),d),rh(Bm.prototype.gb,Bm,[c])),null),mk('label',Ck(new $wnd.Object,rh(Cm.prototype.ib,Cm,[a,c])),[(gb(c.b),c.e)]),mk('button',tk(qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,['destroy'])),rh(Dm.prototype.ib,Dm,[c])),null)]),mk(ip,yk(xk(wk(Bk(qk(rk(new $wnd.Object,rh(Em.prototype.v,Em,[a])),dd($c(ne,1),Vo,2,6,['edit'])),(gb(a.a),a.d)),rh(Fm.prototype.fb,Fm,[a,c])),rh(Am.prototype.gb,Am,[a])),rh(Gm.prototype.hb,Gm,[a,c])),null)]));return b}
function Yi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[ep]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Wi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[ep]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var To='object',Uo={6:1},Vo={3:1},Wo={8:1},Xo=1048576,Yo=1835008,Zo=2097152,$o=4194304,_o='__noinit__',ap={3:1,9:1,7:1,5:1},bp='null',cp=17592186044416,dp={38:1},ep='delete',fp='selected',gp=1411518464,hp=142606336,ip='input',jp='header',kp='hashchange',lp=136314880,mp='active',np='completed';var _,mh,hh,$g=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;nh();ph(1,null,{},p);_.n=function(a){return o(this,a)};_.o=function(){return this.kb};_.p=pp;_.q=function(){var a;return Eh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.n(a)};_.hashCode=function(){return this.p()};_.toString=function(){return this.q()};var gd,hd,jd;ph(49,1,{},Fh);_.H=function(a){var b;b=new Fh;b.e=4;a>1?(b.c=Kh(this,a-1)):(b.c=this);return b};_.I=function(){Dh(this);return this.b};_.J=function(){return Eh(this)};_.K=function(){Dh(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.q=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Dh(this),this.k)};_.e=0;_.g=0;var Ch=1;var ke=Hh(1);var be=Hh(49);ph(78,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var xd=Hh(78);ph(79,1,Uo,G);_.r=function(){Db(this.a)};var ud=Hh(79);ph(33,1,{},H);_.s=function(){return this.a.r(),null};var vd=Hh(33);ph(80,1,{},I);var wd=Hh(80);var J;ph(42,1,{42:1},Q);_.b=0;_.c=false;_.d=0;var yd=Hh(42);ph(222,1,Wo);_.q=function(){var a;return Eh(this.kb)+'@'+(a=s(this)>>>0,a.toString(16))};var Bd=Hh(222);ph(17,222,Wo,X);_.t=function(){S(this)};_.u=op;_.a=false;_.d=0;_.j=false;var Ad=Hh(17);ph(124,1,{},Y);_.s=function(){return U(this.a)};var zd=Hh(124);ph(14,222,{8:1,14:1},jb);_.t=function(){ab(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Dd=Hh(14);ph(123,1,Uo,kb);_.r=function(){bb(this.a)};var Cd=Hh(123);ph(15,222,{8:1,15:1},wb,xb);_.t=function(){lb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Id=Hh(15);ph(125,1,{},yb);_.r=function(){R(this.a)};var Ed=Hh(125);ph(126,1,Uo,zb);_.r=function(){nb(this.a)};var Fd=Hh(126);ph(127,1,Uo,Ab);_.r=function(){qb(this.a)};var Gd=Hh(127);ph(128,1,{},Bb);_.v=function(a){ob(this.a,a)};var Hd=Hh(128);ph(133,1,{},Eb);_.a=0;_.b=0;_.c=0;var Jd=Hh(133);ph(161,1,Wo,Gb);_.t=function(){Fb(this)};_.u=op;_.a=false;var Kd=Hh(161);ph(57,222,{8:1,57:1},Kb);_.t=function(){Hb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Md=Hh(57);ph(138,1,{},Pb);var Ld=Hh(138);ph(140,1,{},_b);_.q=function(){var a;return Dh(Nd),Nd.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.a=0;var Qb;var Nd=Hh(140);ph(111,1,{});var Qd=Hh(111);ph(83,1,{},hc);_.v=function(a){fc(this.a,a)};var Od=Hh(83);ph(84,1,Uo,ic);_.r=function(){gc(this.a,this.b)};var Pd=Hh(84);ph(13,1,Wo,pc);_.t=function(){kc(this)};_.u=function(){return this.i<0};_.q=function(){var a;return Dh(Sd),Sd.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Sd=Hh(13);ph(122,1,Uo,qc);_.r=function(){nc(this.a)};var Rd=Hh(122);ph(5,1,{3:1,5:1});_.w=up;_.A=function(){return Ej(Cj(Gi((this.i==null&&(this.i=ad(pe,Vo,5,0,0,1)),this.i)),new _h),new Ij)};_.B=function(){return this.f};_.C=function(){return this.g};_.D=function(){tc(this,vc(new Error(uc(this,this.g))));Xc(this)};_.q=function(){return uc(this,this.C())};_.e=_o;_.j=true;var pe=Hh(5);ph(9,5,{3:1,9:1,5:1});var ee=Hh(9);ph(7,9,ap);var le=Hh(7);ph(72,7,ap);var ie=Hh(72);ph(73,72,ap);var Wd=Hh(73);ph(32,73,{32:1,3:1,9:1,7:1,5:1},Ac);_.C=function(){zc(this);return this.c};_.F=function(){return rd(this.b)===rd(xc)?null:this.b};var xc;var Td=Hh(32);var Ud=Hh(0);ph(208,1,{});var Vd=Hh(208);var Cc=0,Dc=0,Ec=-1;ph(110,208,{},Sc);var Oc;var Xd=Hh(110);var Vc;ph(219,1,{});var Zd=Hh(219);ph(74,219,{},Zc);var Yd=Hh(74);var wh;ph(70,1,{67:1});_.q=op;var $d=Hh(70);ph(76,7,ap);var ge=Hh(76);ph(156,76,ap,Ah);var _d=Hh(156);gd={3:1,68:1,31:1};var ae=Hh(68);ph(39,1,{3:1,39:1});var je=Hh(39);hd={3:1,31:1,39:1};var ce=Hh(218);ph(40,1,{3:1,31:1,40:1});_.n=function(a){return this===a};_.p=pp;_.q=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=Hh(40);ph(75,7,ap,Ph);var fe=Hh(75);ph(26,39,{3:1,31:1,26:1,39:1},Qh);_.n=function(a){return md(a,26)&&a.a==this.a};_.p=op;_.q=function(){return ''+this.a};_.a=0;var he=Hh(26);var Sh;ph(286,1,{});jd={3:1,67:1,31:1,2:1};var ne=Hh(2);ph(71,70,{67:1},$h);var me=Hh(71);ph(290,1,{});ph(65,1,{},_h);_.P=function(a){return a.e};var oe=Hh(65);ph(51,7,ap,ai);var qe=Hh(51);ph(220,1,{37:1});_.N=tp;_.S=function(){return new rj(this,0)};_.T=function(){return new Fj(null,this.S())};_.Q=function(a){throw ah(new ai('Add not supported on this collection'))};_.q=function(){var a,b,c;c=new tj('[',']');for(b=this.O();b.V();){a=b.W();sj(c,a===this?'(this Collection)':a==null?bp:th(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var re=Hh(220);ph(223,1,{206:1});_.n=function(a){var b,c,d;if(a===this){return true}if(!md(a,34)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new oi((new li(d)).a);c.b;){b=ni(c);if(!di(this,b)){return false}}return true};_.p=function(){return Hi(new li(this))};_.q=function(){var a,b,c;c=new tj('{','}');for(b=new oi((new li(this)).a);b.b;){a=ni(b);sj(c,ei(this,a.Y())+'='+ei(this,a.Z()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ce=Hh(223);ph(129,223,{206:1});var ue=Hh(129);ph(224,220,{37:1,233:1});_.S=function(){return new rj(this,1)};_.n=function(a){var b;if(a===this){return true}if(!md(a,20)){return false}b=a;if(ji(b.a)!=this.R()){return false}return bi(this,b)};_.p=function(){return Hi(this)};var De=Hh(224);ph(20,224,{20:1,37:1,233:1},li);_.O=function(){return new oi(this.a)};_.R=rp;var te=Hh(20);ph(21,1,{},oi);_.U=qp;_.W=function(){return ni(this)};_.V=sp;_.b=false;var se=Hh(21);ph(221,220,{37:1,230:1});_.S=function(){return new rj(this,16)};_.X=function(a,b){throw ah(new ai('Add not supported on this list'))};_.Q=function(a){this.X(this.R(),a);return true};_.n=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,12)){return false}f=a;if(this.R()!=f.a.length){return false}e=new Ei(f);for(c=new Ei(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(rd(b)===rd(d)||b!=null&&q(b,d))){return false}}return true};_.p=function(){return Ii(this)};_.O=function(){return new pi(this)};var we=Hh(221);ph(109,1,{},pi);_.U=qp;_.V=function(){return this.a<this.b.a.length};_.W=function(){return wi(this.b,this.a++)};_.a=0;var ve=Hh(109);ph(41,220,{37:1},qi);_.O=function(){var a;a=new oi((new li(this.a)).a);return new ri(a)};_.R=rp;var ye=Hh(41);ph(132,1,{},ri);_.U=qp;_.V=function(){return this.a.b};_.W=function(){var a;a=ni(this.a);return a.Z()};var xe=Hh(132);ph(130,1,dp);_.n=function(a){var b;if(!md(a,38)){return false}b=a;return Ji(this.a,b.Y())&&Ji(this.b,b.Z())};_.Y=op;_.Z=sp;_.p=function(){return ij(this.a)^ij(this.b)};_.$=function(a){var b;b=this.b;this.b=a;return b};_.q=function(){return this.a+'='+this.b};var ze=Hh(130);ph(131,130,dp,si);var Ae=Hh(131);ph(225,1,dp);_.n=function(a){var b;if(!md(a,38)){return false}b=a;return Ji(this.b.value[0],b.Y())&&Ji(ej(this),b.Z())};_.p=function(){return ij(this.b.value[0])^ij(ej(this))};_.q=function(){return this.b.value[0]+'='+ej(this)};var Be=Hh(225);ph(12,221,{3:1,12:1,37:1,230:1},Ci,Di);_.X=function(a,b){Vj(this.a,a,b)};_.Q=function(a){return ui(this,a)};_.N=function(a){vi(this,a)};_.O=function(){return new Ei(this)};_.R=function(){return this.a.length};var Fe=Hh(12);ph(16,1,{},Ei);_.U=qp;_.V=function(){return this.a<this.c.a.length};_.W=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ee=Hh(16);ph(34,129,{3:1,34:1,206:1},Ki);var Ge=Hh(34);ph(55,1,{},Qi);_.N=tp;_.O=function(){return new Ri(this)};_.b=0;var Ie=Hh(55);ph(56,1,{},Ri);_.U=qp;_.W=function(){return this.d=this.a[this.c++],this.d};_.V=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var He=Hh(56);var Ui;ph(53,1,{},cj);_.N=tp;_.O=function(){return new dj(this)};_.b=0;_.c=0;var Le=Hh(53);ph(54,1,{},dj);_.U=qp;_.W=function(){return this.c=this.a,this.a=this.b.next(),new fj(this.d,this.c,this.d.c)};_.V=function(){return !this.a.done};var Je=Hh(54);ph(139,225,dp,fj);_.Y=function(){return this.b.value[0]};_.Z=function(){return ej(this)};_.$=function(a){return aj(this.a,this.b.value[0],a)};_.c=0;var Ke=Hh(139);ph(142,1,{});_.U=vp;_._=function(){return this.d};_.ab=up;_.d=0;_.e=0;var Pe=Hh(142);ph(58,142,{});var Me=Hh(58);ph(134,1,{});_.U=vp;_._=sp;_.ab=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Oe=Hh(134);ph(135,134,{},pj);_.U=function(a){mj(this,a)};_.bb=function(a){return nj(this,a)};var Ne=Hh(135);ph(18,1,{},rj);_._=op;_.ab=function(){qj(this);return this.c};_.U=function(a){qj(this);this.d.U(a)};_.bb=function(a){qj(this);if(this.d.V()){a.v(this.d.W());return true}return false};_.a=0;_.c=0;var Qe=Hh(18);ph(50,1,{},tj);_.q=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Re=Hh(50);ph(30,1,{},uj);_.P=function(a){return a};var Se=Hh(30);ph(35,1,{},vj);var Te=Hh(35);ph(141,1,{});_.c=false;var bf=Hh(141);ph(22,141,{},Fj);var af=Hh(22);ph(66,1,{},Ij);_.cb=function(a){return ad(ke,Vo,1,a,5,1)};var Ue=Hh(66);ph(144,58,{},Kj);_.bb=function(a){this.b=false;while(!this.b&&this.c.bb(new Lj(this,a)));return this.b};_.b=false;var We=Hh(144);ph(147,1,{},Lj);_.v=function(a){Jj(this.a,this.b,a)};var Ve=Hh(147);ph(143,58,{},Nj);_.bb=function(a){return this.b.bb(new Oj(this,a))};var Ye=Hh(143);ph(146,1,{},Oj);_.v=function(a){Mj(this.a,this.b,a)};var Xe=Hh(146);ph(145,1,{},Qj);_.v=function(a){Pj(this,a)};var Ze=Hh(145);ph(148,1,{},Rj);_.v=function(a){};var $e=Hh(148);ph(149,1,{},Tj);_.v=function(a){Sj(this,a)};var _e=Hh(149);ph(288,1,{});ph(285,1,{});var Zj=0;var _j,ak=0,bk;ph(903,1,{});ph(927,1,{});ph(157,1,{},ok);_.cb=function(a){return new Array(a)};var cf=Hh(157);ph(253,$wnd.Function,{},pk);_.eb=function(a){nk(this.a,this.b,a)};var Dk;ph(160,1,{251:1},Fk);var df=Hh(160);ph(228,1,{});var Nf=Hh(228);ph(179,228,{});_.e=0;var Rf=Hh(179);ph(180,179,Wo,Mk);_.t=wp;_.u=xp;_.q=function(){var a;return Dh(nf),nf.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Jk=0;var nf=Hh(180);ph(181,1,Uo,Nk);_.r=function(){Kk(this.a)};var ef=Hh(181);ph(182,1,{},Ok);_.s=function(){return Bh(),T((Qm(),Nm).b).a>0?true:false};var ff=Hh(182);ph(184,1,{},Pk);_.s=function(){return Hk(this.a)};var gf=Hh(184);ph(183,1,{},Qk);_.r=function(){Ik(this.a)};var hf=Hh(183);ph(229,1,{});var Mf=Hh(229);ph(200,229,{});_.d=0;var Qf=Hh(200);ph(201,200,Wo,Vk);_.t=yp;_.u=zp;_.q=function(){var a;return Dh(mf),mf.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Tk=0;var mf=Hh(201);ph(202,1,Uo,Wk);_.r=Ap;var jf=Hh(202);ph(203,1,{},Xk);_.r=function(){Sk(this.a)};var kf=Hh(203);ph(204,1,{},Yk);_.s=function(){var a;return this.a.d=0,Ek(),a=T((Qm(),Nm).e).a,mk('span',qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,['todo-count'])),[mk('strong',null,[a]),' item'+(a==1?'':'s')+' left'])};var lf=Hh(204);ph(171,1,{});_.f='';var Zf=Hh(171);ph(172,171,{});_.e=0;var Tf=Hh(172);ph(173,172,Wo,il);_.t=wp;_.u=xp;_.q=function(){var a;return Dh(tf),tf.k+'@'+(a=$j(this)>>>0,a.toString(16))};var cl=0;var tf=Hh(173);ph(174,1,Uo,jl);_.r=function(){dl(this.a)};var of=Hh(174);ph(176,1,{},kl);_.s=function(){return al(this.a)};var pf=Hh(176);ph(177,1,Uo,ll);_.r=function(){Zk(this.a)};var qf=Hh(177);ph(175,1,{},ml);_.r=function(){Ik(this.a)};var rf=Hh(175);ph(178,1,Uo,nl);_.r=function(){gl(this.a,this.b)};var sf=Hh(178);ph(227,1,{});_.k=false;var _f=Hh(227);ph(186,227,{});_.g=0;var Vf=Hh(186);ph(187,186,Wo,Il);_.t=function(){kc(this.e)};_.u=function(){return this.e.i<0};_.q=function(){var a;return Dh(Ff),Ff.k+'@'+(a=$j(this)>>>0,a.toString(16))};var xl=0;var Ff=Hh(187);ph(188,1,Uo,Jl);_.r=function(){yl(this.a)};var uf=Hh(188);ph(191,1,Uo,Kl);_.r=function(){kc(this.a.e)};var vf=Hh(191);ph(192,1,{},Ll);_.s=function(){return vl(this.a)};var wf=Hh(192);ph(189,1,{},Ml);_.s=function(){return Bl(this.a)};var xf=Hh(189);ph(61,1,Uo,Nl);_.r=function(){Hl(this.a,Zm(this.b))};var yf=Hh(61);ph(62,1,Uo,Ol);_.r=function(){rl(this.a,this.b)};var zf=Hh(62);ph(193,1,Uo,Pl);_.r=function(){Cl(this.a,this.b)};var Af=Hh(193);ph(190,1,{},Ql);_.r=function(){wl(this.a)};var Bf=Hh(190);ph(194,1,Uo,Rl);_.r=function(){Gl(this.a,this.b);co((Qm(),Pm),null)};var Cf=Hh(194);ph(195,1,Uo,Sl);_.r=function(){ol(this.a,this.b)};var Df=Hh(195);ph(196,1,Uo,Tl);_.r=function(){sl(this.a)};var Ef=Hh(196);ph(226,1,{});var cg=Hh(226);ph(151,226,{});_.d=0;var Xf=Hh(151);ph(152,151,Wo,Yl);_.t=yp;_.u=zp;_.q=function(){var a;return Dh(Jf),Jf.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Wl=0;var Jf=Hh(152);ph(153,1,Uo,Zl);_.r=Ap;var Gf=Hh(153);ph(154,1,{},$l);_.r=function(){Sk(this.a)};var Hf=Hh(154);ph(155,1,{},_l);_.s=function(){return this.a.d=0,Ek(),mk('div',null,[mk('div',null,[mk(jp,qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,[jp])),[mk('h1',null,['todos']),(new zm).a]),T((Qm(),Nm).d)?mk('section',qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,[jp])),[mk(ip,xk(Ak(qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,['toggle-all']))),rh(Jm.prototype.gb,Jm,[])),null),mk('ul',qk(new $wnd.Object,dd($c(ne,1),Vo,2,6,['todo-list'])),Ej(Cj(T(Pm.c).T(),new Km),new ok))]):null,T(Nm.d)?(new bm).a:null])])};var If=Hh(155);ph(257,$wnd.Function,{},am);_.ib=function(a){Pn((Qm(),Om))};ph(159,1,{},bm);var Kf=Hh(159);ph(185,1,{},cm);var Lf=Hh(185);ph(258,$wnd.Function,{},dm);_.jb=function(a){return new gm(a)};var em;ph(165,$wnd.React.Component,{},gm);oh(mh[1],_);_.componentWillUnmount=function(){Gk(this.a)};_.render=function(){return Lk(this.a)};_.shouldComponentUpdate=Bp;var Of=Hh(165);ph(269,$wnd.Function,{},hm);_.jb=function(a){return new km(a)};var im;ph(197,$wnd.React.Component,{},km);oh(mh[1],_);_.componentWillUnmount=function(){Rk(this.a)};_.render=function(){return Uk(this.a)};_.shouldComponentUpdate=Cp;var Pf=Hh(197);ph(256,$wnd.Function,{},lm);_.jb=function(a){return new om(a)};var mm;ph(164,$wnd.React.Component,{},om);oh(mh[1],_);_.componentWillUnmount=function(){Gk(this.a)};_.render=function(){return el(this.a)};_.shouldComponentUpdate=Bp;var Sf=Hh(164);ph(260,$wnd.Function,{},pm);_.jb=function(a){return new sm(a)};var qm;ph(169,$wnd.React.Component,{},sm);oh(mh[1],_);_.componentDidUpdate=function(a){$(this.a)&&(Fl(this.a),undefined)};_.componentWillUnmount=function(){$(this.a)&&ul(this.a)};_.render=function(){return $(this.a)?zl(this.a):null};_.shouldComponentUpdate=function(a){return $(this.a)&&1==this.a.g};var Uf=Hh(169);ph(250,$wnd.Function,{},tm);_.jb=function(a){return new wm(a)};var um;ph(136,$wnd.React.Component,{},wm);oh(mh[1],_);_.componentWillUnmount=function(){Rk(this.a)};_.render=function(){return Xl(this.a)};_.shouldComponentUpdate=Cp;var Wf=Hh(136);ph(254,$wnd.Function,{},xm);_.hb=function(a){$k(this.a,a)};ph(255,$wnd.Function,{},ym);_.gb=function(a){fl(this.a,a)};ph(158,1,{},zm);var Yf=Hh(158);ph(267,$wnd.Function,{},Am);_.gb=function(a){Al(this.a,a)};ph(261,$wnd.Function,{},Bm);_.gb=function(a){tn(this.a)};ph(263,$wnd.Function,{},Cm);_.ib=function(a){Dl(this.a,this.b)};ph(264,$wnd.Function,{},Dm);_.ib=function(a){tl(this.a)};ph(265,$wnd.Function,{},Em);_.v=function(a){pl(this.a,a)};ph(266,$wnd.Function,{},Fm);_.fb=function(a){El(this.a,this.b)};ph(268,$wnd.Function,{},Gm);_.hb=function(a){ql(this.a,this.b,a)};ph(162,1,{},Im);var $f=Hh(162);ph(249,$wnd.Function,{},Jm);_.gb=function(a){var b;b=a.target;Tn((Qm(),Om),b.checked)};ph(137,1,{},Km);_.P=function(a){return Hm(new Im,a)};var ag=Hh(137);ph(64,1,{},Lm);var bg=Hh(64);var Mm,Nm,Om,Pm;ph(94,1,{});var Ig=Hh(94);ph(95,94,Wo,bn);_.t=wp;_.u=xp;_.q=function(){var a;return Dh(kg),kg.k+'@'+(a=$j(this)>>>0,a.toString(16))};var kg=Hh(95);ph(96,1,Uo,cn);_.r=function(){Xm(this.a)};var dg=Hh(96);ph(98,1,{},dn);_.r=function(){Sm(this.a)};var eg=Hh(98);ph(99,1,{},en);_.r=function(){Tm(this.a)};var fg=Hh(99);ph(100,1,Uo,fn);_.r=function(){Rm(this.a,this.b)};var gg=Hh(100);ph(101,1,Uo,gn);_.r=function(){$m(this.a)};var hg=Hh(101);ph(52,1,Uo,hn);_.r=function(){Wm(this.a)};var ig=Hh(52);ph(97,1,{},jn);_.s=function(){var a;return a=(xh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var jg=Hh(97);ph(43,1,{43:1});_.d=false;var Qg=Hh(43);ph(44,43,{8:1,252:1,44:1,43:1},un);_.t=wp;_.n=function(a){return nn(this,a)};_.p=function(){return this.c.d};_.u=xp;_.q=function(){var a;return Dh(Ag),Ag.k+'@'+(a=this.c.d>>>0,a.toString(16))};var kn=0;var Ag=Hh(44);ph(198,1,Uo,vn);_.r=function(){ln(this.a)};var lg=Hh(198);ph(199,1,Uo,wn);_.r=function(){qn(this.a)};var mg=Hh(199);ph(112,111,{});var Lg=Hh(112);ph(113,112,Wo,En);_.t=Dp;_.u=Ep;_.q=function(){var a;return Dh(vg),vg.k+'@'+(a=$j(this)>>>0,a.toString(16))};var vg=Hh(113);ph(115,1,Uo,Fn);_.r=function(){yn(this.a)};var ng=Hh(115);ph(114,1,Uo,Gn);_.r=function(){Bn(this.a)};var og=Hh(114);ph(120,1,Uo,Hn);_.r=function(){cc(this.a,this.b,true)};var pg=Hh(120);ph(121,1,{},In);_.s=function(){return xn(this.a,this.c,this.b)};_.b=false;var qg=Hh(121);ph(116,1,{},Jn);_.s=function(){return Cn(this.a)};var rg=Hh(116);ph(117,1,{},Kn);_.s=function(){return Rh(gh(Aj(dc(this.a))))};var sg=Hh(117);ph(118,1,{},Ln);_.s=function(){return Rh(gh(Aj(Bj(dc(this.a),new ro))))};var tg=Hh(118);ph(119,1,{},Mn);_.s=function(){return Dn(this.a)};var ug=Hh(119);ph(88,1,{});var Pg=Hh(88);ph(89,88,Wo,Un);_.t=function(){kc(this.a)};_.u=function(){return this.a.i<0};_.q=function(){var a;return Dh(zg),zg.k+'@'+(a=$j(this)>>>0,a.toString(16))};var zg=Hh(89);ph(90,1,Uo,Vn);_.r=function(){Qn(this.a,this.b)};_.b=false;var wg=Hh(90);ph(91,1,Uo,Wn);_.r=function(){an(this.b,this.a)};var xg=Hh(91);ph(92,1,Uo,Xn);_.r=function(){Rn(this.a)};var yg=Hh(92);ph(102,1,{});var Sg=Hh(102);ph(103,102,Wo,eo);_.t=Dp;_.u=Ep;_.q=function(){var a;return Dh(Gg),Gg.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Gg=Hh(103);ph(104,1,Uo,fo);_.r=function(){$n(this.a)};var Bg=Hh(104);ph(108,1,Uo,go);_.r=function(){co(this.a,null)};var Cg=Hh(108);ph(105,1,{},ho);_.s=function(){var a;return a=Zm(this.a.g),o(mp,a)?(oo(),lo):o(np,a)?(oo(),no):(oo(),mo)};var Dg=Hh(105);ph(106,1,{},io);_.s=function(){return ao(this.a)};var Eg=Hh(106);ph(107,1,{},jo);_.r=function(){bo(this.a)};var Fg=Hh(107);ph(93,1,{},ko);_.handleEvent=function(a){Um(this.a,a)};var Hg=Hh(93);ph(27,40,{3:1,31:1,40:1,27:1},po);var lo,mo,no;var Jg=Ih(27,qo);ph(82,1,{},ro);_.db=function(a){return !pn(a)};var Kg=Hh(82);ph(86,1,{},so);_.db=function(a){return pn(a)};var Mg=Hh(86);ph(87,1,{},to);_.v=function(a){An(this.a,a)};var Ng=Hh(87);ph(85,1,{},uo);_.v=function(a){On(this.a,a)};_.a=false;var Og=Hh(85);ph(77,1,{},vo);_.db=function(a){return Zn(this.a,a)};var Rg=Hh(77);ph(166,1,{});var Tg=Hh(166);ph(170,1,{},Fo);_.b=0;_.c=false;_.d=0;var Ug=Hh(170);ph(59,166,{});_.a=0;_.b=0;_.c=0;var Xg=Hh(59);ph(168,59,{},Io);var Vg=Hh(168);ph(259,$wnd.Function,{},Jo);_.G=function(a){return Go((new Ko(this.a)).a),null};ph(167,1,{},Ko);var Wg=Hh(167);ph(60,1,{60:1},Mo);_.q=function(){var a;return Dh(Yg),Yg.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Yg=Hh(60);ph(163,1,{},Oo);_.q=function(){var a;return Dh(Zg),Zg.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Zg=Hh(163);var Po;var td=Jh('D');var So=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=kh;ih(vh);lh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();