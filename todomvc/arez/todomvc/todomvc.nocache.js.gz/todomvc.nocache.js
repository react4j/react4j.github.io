function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='00CBA61BD6D2C8D41256013A55A06E72',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '00CBA61BD6D2C8D41256013A55A06E72';function o(){}
function bh(){}
function Zg(){}
function Jb(){}
function Oc(){}
function Vc(){}
function mj(){}
function nj(){}
function Bk(){}
function Kk(){}
function Xl(){}
function $l(){}
function cm(){}
function gm(){}
function km(){}
function om(){}
function Em(){}
function bn(){}
function no(){}
function oo(){}
function Tc(a){Sc()}
function ih(){ih=Zg}
function ki(){bi(this)}
function F(a){this.a=a}
function G(a){this.a=a}
function W(a){this.a=a}
function nb(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function Eb(a){this.a=a}
function ec(a){this.a=a}
function nc(a){this.a=a}
function yh(a){this.a=a}
function Jh(a){this.a=a}
function Vh(a){this.a=a}
function $h(a){this.a=a}
function _h(a){this.a=a}
function Zh(a){this.b=a}
function mi(a){this.c=a}
function kj(a){this.a=a}
function pj(a){this.a=a}
function Jk(a){this.a=a}
function Lk(a){this.a=a}
function Mk(a){this.a=a}
function Sk(a){this.a=a}
function Tk(a){this.a=a}
function Uk(a){this.a=a}
function fl(a){this.a=a}
function gl(a){this.a=a}
function hl(a){this.a=a}
function jl(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Il(a){this.a=a}
function Nl(a){this.a=a}
function Ol(a){this.a=a}
function Ul(a){this.a=a}
function Vl(a){this.a=a}
function Wl(a){this.a=a}
function sm(a){this.a=a}
function tm(a){this.a=a}
function vm(a){this.a=a}
function wm(a){this.a=a}
function ym(a){this.a=a}
function zm(a){this.a=a}
function Xm(a){this.a=a}
function Ym(a){this.a=a}
function Zm(a){this.a=a}
function _m(a){this.a=a}
function an(a){this.a=a}
function on(a){this.a=a}
function pn(a){this.a=a}
function zn(a){this.a=a}
function An(a){this.a=a}
function Dn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Rn(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function co(a){this.a=a}
function eo(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function po(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function lj(a,b){a.a=b}
function Hj(a,b){a.key=b}
function Gj(a,b){Fj(a,b)}
function In(a,b){Dl(b,a)}
function X(a){!!a&&db(a)}
function ic(a){!!a&&a.v()}
function v(a){--a.e;C(a)}
function $o(a){Oi(this,a)}
function bp(a){Ch(this,a)}
function cp(){hc(this.c)}
function ep(){hc(this.b)}
function kp(){hc(this.f)}
function wi(){this.a=Fi()}
function Ki(){this.a=Fi()}
function gp(){ob(this.a.a)}
function hb(a){Xb((I(),a))}
function ib(a){Yb((I(),a))}
function lb(a){Zb((I(),a))}
function lc(a,b){Rh(a.e,b)}
function oj(a,b){fj(a.a,b)}
function Hn(a,b){sn(a.b,b)}
function B(a,b){bb(a.f,b.f)}
function ub(a,b){a.b=Ri(b)}
function Mb(a){a.a=-4&a.a|1}
function Ck(a){a.d=2;hc(a.c)}
function Nk(a){a.c=2;hc(a.b)}
function rl(a){a.f=2;hc(a.e)}
function Kg(a){return a.e}
function Xo(){return this.a}
function ap(){return this.b}
function Fh(a,b){return a===b}
function ll(a,b){return a.g=b}
function Zo(){return xj(this)}
function Kh(a){sc.call(this,a)}
function jp(a){lc(this.c,a)}
function mp(a){lc(this.f,a)}
function Gk(a){ob(a.b);Q(a.a)}
function _k(a){ob(a.a);db(a.b)}
function Qm(a){Q(a.a);db(a.b)}
function dn(a){db(a.b);db(a.a)}
function ql(a){tn((Jm(),Gm),a)}
function gc(a,b,c){Qh(a.e,b,c)}
function en(a,b,c){gc(a.c,b,c)}
function tj(a,b){a.splice(b,1)}
function J(a,b){N(a);K(a,Ri(b))}
function ei(a,b){return a.a[b]}
function Wc(a,b){return rh(a,b)}
function Yo(a){return this===a}
function _o(){return Th(this.a)}
function dp(){return this.c.i<0}
function fp(){return this.b.i<0}
function lp(){return this.f.i<0}
function Dh(){oc(this);this.D()}
function Bi(){Bi=Zg;Ai=Di()}
function I(){I=Zg;H=new D}
function uc(){uc=Zg;tc=new o}
function Lc(){Lc=Zg;Kc=new Oc}
function Bc(){Bc=Zg;!!(Sc(),Rc)}
function Sg(){Qg==null&&(Qg=[])}
function eb(a){I();Yb(a);a.e=-2}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function S(a){qb(a.f);return U(a)}
function Sm(a){jb(a.b);return a.e}
function hn(a){jb(a.a);return a.d}
function Wn(a){jb(a.d);return a.e}
function lh(a){kh(a);return a.k}
function ej(a,b){a.P(b);return a}
function Qj(a,b){a.ref=b;return a}
function fj(a,b){lj(a,ej(a.a,b))}
function Si(a,b){while(a.ab(b));}
function ai(a,b){this.a=a;this.b=b}
function fc(a,b){this.a=a;this.b=b}
function wh(a,b){this.a=a;this.b=b}
function ij(a,b){this.a=a;this.b=b}
function Oj(a,b){this.a=a;this.b=b}
function hp(a){return 1==this.a.d}
function ip(a){return 1==this.a.c}
function Th(a){return a.a.b+a.b.b}
function Hi(a,b){return a.a.get(b)}
function _c(a){return new Array(a)}
function Fi(){Bi();return new Ai}
function Rj(a,b){a.href=b;return a}
function il(a,b){this.a=a;this.b=b}
function Hl(a,b){this.a=a;this.b=b}
function Jl(a,b){this.a=a;this.b=b}
function Kl(a,b){this.a=a;this.b=b}
function Ll(a,b){this.a=a;this.b=b}
function Ml(a,b){this.a=a;this.b=b}
function xm(a,b){this.a=a;this.b=b}
function Am(a,b){this.a=a;this.b=b}
function Bm(a,b){this.a=a;this.b=b}
function xk(a,b){wh.call(this,a,b)}
function $m(a,b){this.a=a;this.b=b}
function Bn(a,b){this.a=a;this.b=b}
function Pn(a,b){this.a=a;this.b=b}
function Qn(a,b){this.b=a;this.a=b}
function lo(a,b){wh.call(this,a,b)}
function rj(a,b,c){a.splice(b,0,c)}
function u(a,b,c){s(a,new G(c),b)}
function Tm(a){Rm(a,(jb(a.b),a.e))}
function Yl(){this.a=Ij((am(),_l))}
function Zl(){this.a=Ij((em(),dm))}
function um(){this.a=Ij((im(),hm))}
function Dm(){this.a=Ij((mm(),lm))}
function Fm(){this.a=Ij((qm(),pm))}
function jn(a){Dl(a,(jb(a.a),!a.d))}
function Tb(a){return !a.d?a:Tb(a.d)}
function Ph(a){return !a?null:a.Y()}
function od(a){return a==null?null:a}
function Qi(a){return a!=null?r(a):0}
function ld(a){return typeof a===uo}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function Bj(){Bj=Zg;yj=new o;Aj=new o}
function Sh(a){a.a=new wi;a.b=new Ki}
function mb(a){this.c=new ki;this.b=a}
function Ic(a){$wnd.clearTimeout(a)}
function bi(a){a.a=Yc(ge,wo,1,0,5,1)}
function tb(a){I();sb(a);wb(a,2,true)}
function vl(a){ob(a.b);Q(a.c);db(a.a)}
function cc(a,b){b.A(a);jd(b,9)&&b.t()}
function dc(a,b){bc(a,b,false);ib(a.d)}
function sj(a,b){qj(b,0,a,0,b.length)}
function $j(a,b){a.value=b;return a}
function Vj(a,b){a.onBlur=b;return a}
function Sj(a,b){a.onClick=b;return a}
function Wj(a,b){a.onChange=b;return a}
function Uj(a,b){a.checked=b;return a}
function Hh(a,b){a.a+=''+b;return a}
function w(a,b,c){t(a,new F(b),c,null)}
function A(a,b,c){return t(a,c,2048,b)}
function bd(a,b,c){return {l:a,m:b,h:c}}
function Eh(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function Y(a){return !(!!a&&1==(a.c&7))}
function xj(a){return a.$H||(a.$H=++wj)}
function nd(a){return typeof a==='string'}
function Xj(a,b){a.onKeyDown=b;return a}
function Tj(a){a.autoFocus=true;return a}
function kh(a){if(a.k!=null){return}th(a)}
function Hb(a){this.d=Ri(a);this.b=100}
function sc(a){this.f=a;oc(this);this.D()}
function dj(a,b){$i.call(this,a);this.a=b}
function Fj(a,b){for(var c in a){b(c)}}
function vj(b,c,d){try{b[c]=d}catch(a){}}
function yi(a,b){var c;c=a[Ko];c.call(a,b)}
function Vn(a){var b;b=a.e;!!b&&lc(b.c,a)}
function jb(a){var b;Ub((I(),b=Pb,b),a)}
function pc(a,b){a.e=b;b!=null&&vj(b,Fo,a)}
function Oi(a,b){while(a.U()){oj(b,a.V())}}
function O(){this.a=Yc(ge,wo,1,100,5,1)}
function Bh(){Bh=Zg;Ah=Yc(ce,wo,32,256,0,1)}
function fh(){fh=Zg;eh=$wnd.window.document}
function qi(){this.a=new wi;this.b=new Ki}
function kd(a){return typeof a==='boolean'}
function xn(a){return zh(R(a.e).a-R(a.a).a)}
function Kb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function Un(a){ob(a.a);Q(a.b);Q(a.c);db(a.d)}
function T(a){4==(a.f.c&7)&&wb(a.f,5,true)}
function oc(a){a.g&&a.e!==Eo&&a.D();return a}
function oh(a){var b;b=nh(a);vh(a,b);return b}
function _j(a,b){a.onDoubleClick=b;return a}
function Ni(a,b,c){this.a=a;this.b=b;this.c=c}
function ab(a,b,c){Mb(Ri(c));J(a.a[b],Ri(c))}
function Cc(a,b,c){return a.apply(b,c);var d}
function gh(a,b,c,d){a.addEventListener(b,c,d)}
function ci(a,b){a.a[a.a.length]=b;return true}
function bb(a,b){ab(a,((b.a&229376)>>15)-1,b)}
function al(a,b){w((I(),I(),H),new il(a,b),Po)}
function wl(a,b){w((I(),I(),H),new Ml(a,b),Po)}
function yl(a,b){w((I(),I(),H),new Kl(a,b),Po)}
function zl(a,b){w((I(),I(),H),new Jl(a,b),Po)}
function Cl(a,b){w((I(),I(),H),new Hl(a,b),Po)}
function tn(a,b){w((I(),I(),H),new Bn(a,b),Po)}
function Mn(a,b){w((I(),I(),H),new Qn(a,b),Po)}
function Nn(a,b){w((I(),I(),H),new Pn(a,b),Po)}
function mn(a){w((I(),I(),H),new pn(a),Po)}
function Jn(a){w((I(),I(),H),new Rn(a),Po)}
function Al(a){w((I(),I(),H),new Ol(a),Po)}
function Um(a){w((I(),I(),H),new _m(a),Po)}
function vn(a){Ch(new $h(a.g),new ec(a));Sh(a.g)}
function Gb(a){while(true){if(!Fb(a)){break}}}
function Cn(a,b){this.a=a;this.c=b;this.b=false}
function D(){this.f=new cb;this.a=new Hb(this.f)}
function Sc(){Sc=Zg;var a;!Uc();a=new Vc;Rc=a}
function bj(a){Zi(a);return new dj(a,new jj(a.a))}
function bl(a,b){var c;c=b.target;dl(a,c.value)}
function rb(a,b){gb(b,a);b.c.a.length>0||(b.a=4)}
function gj(a,b,c){if(a.a.bb(c)){a.b=true;b.w(c)}}
function Ib(a){if(!a.a){a.a=true;v((I(),I(),H))}}
function Ui(a){if(!a.d){a.d=a.b.O();a.c=a.b.Q()}}
function Xh(a){var b;b=a.a.V();a.b=Wh(a);return b}
function qh(a){var b;b=nh(a);b.j=a;b.e=1;return b}
function gi(a,b){var c;c=a.a[b];tj(a.a,b);return c}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Gi(a,b){return !(a.a.get(b)===undefined)}
function wn(a){return ih(),0==R(a.e).a?true:false}
function cl(a){return A((I(),I(),H),a.a,new gl(a))}
function Bl(a){return A((I(),I(),H),a.b,new Gl(a))}
function Sl(a){return A((I(),I(),H),a.a,new Wl(a))}
function Qk(a){return A((I(),I(),H),a.a,new Uk(a))}
function Hk(a){return A((I(),I(),H),a.b,new Mk(a))}
function Sn(a){return Fh(Vo,a)||Fh(Wo,a)||Fh('',a)}
function $c(a){return Array.isArray(a)&&a.kb===bh}
function hd(a){return !Array.isArray(a)&&a.kb===bh}
function M(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function rn(a){Q(a.c);Q(a.e);Q(a.a);Q(a.b);db(a.d)}
function Yi(a){if(!a.b){Zi(a);a.c=true}else{Yi(a.b)}}
function Dk(a){if(0==a.d){a.d=1;a.j.forceUpdate()}}
function Ok(a){if(0==a.c){a.c=1;a.j.forceUpdate()}}
function sl(a){if(0==a.f){a.f=1;a.j.forceUpdate()}}
function Ej(){if(zj==256){yj=Aj;Aj=new o;zj=0}++zj}
function Ri(a){if(a==null){throw Kg(new Dh)}return a}
function Uh(a,b){if(b){return Nh(a.a,b)}return false}
function aj(a,b){Zi(a);return new dj(a,new hj(b,a.a))}
function Rm(a,b){w((I(),I(),H),new $m(a,b),75497472)}
function dl(a,b){var c;c=a.e;if(b!=c){a.e=b;ib(a.b)}}
function Dl(a,b){var c;c=a.d;if(b!=c){a.d=b;ib(a.a)}}
function ii(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Zj(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ph(a,b){var c;c=nh(a);vh(a,c);c.e=b?8:0;return c}
function Vm(a,b){var c;c=a.e;if(b!=c){a.e=Ri(b);ib(a.b)}}
function Pm(a){var b;T(a.a);b=R(a.a);Fh(a.f,b)&&Vm(a,b)}
function kb(a){var b;I();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function hh(a,b,c,d){a.removeEventListener(b,c,d)}
function Ti(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Vi(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function $b(a,b){this.a=(I(),I(),H).b++;this.d=a;this.e=b}
function jj(a){Ti.call(this,a._(),a.$()&-6);this.a=a}
function $i(a){if(!a){this.b=null;new ki}else{this.b=a}}
function sh(a){if(a.M()){return null}var b=a.j;return Vg[b]}
function Pg(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function qc(a,b){var c;c=lh(a.ib);return b==null?c:c+': '+b}
function Oh(a,b){return b===a?'(this Map)':b==null?Ho:ah(b)}
function pi(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function sn(a,b){return t((I(),I(),H),new Cn(a,b),Po,null)}
function pb(a){B((I(),I(),H),a);0==(a.f.a&Bo)&&C((null,H))}
function Lm(a){gh((fh(),$wnd.window.window),So,a.d,false)}
function Mm(a){hh((fh(),$wnd.window.window),So,a.d,false)}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function mo(){ko();return ad(Wc(yg,1),wo,34,0,[ho,jo,io])}
function mm(){mm=Zg;var a;lm=(a=$g(km.prototype.hb,km,[]),a)}
function em(){em=Zg;var a;dm=(a=$g(cm.prototype.hb,cm,[]),a)}
function im(){im=Zg;var a;hm=(a=$g(gm.prototype.hb,gm,[]),a)}
function qm(){qm=Zg;var a;pm=(a=$g(om.prototype.hb,om,[]),a)}
function am(){am=Zg;var a;_l=(a=$g($l.prototype.hb,$l,[]),a)}
function Jm(){Jm=Zg;Gm=new yn;Hm=new On(Gm);Im=new $n(Gm)}
function Kn(a,b){var c;cj(un(a.b),(c=new ki,c)).N(new qo(b))}
function kl(a,b){var c;if(R(a.c)){c=b.target;Dl(a,c.value)}}
function Ch(a,b){var c,d;for(d=a.O();d.U();){c=d.V();b.w(c)}}
function rh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function si(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function ti(a,b){var c;return ri(b,si(a,b==null?0:(c=r(b),c|0)))}
function un(a){jb(a.d);return new dj(null,new Vi(new $h(a.g),0))}
function Zi(a){if(a.b){Zi(a.b)}else if(a.c){throw Kg(new xh)}}
function Qb(a){if(a.e){2==(a.e.c&7)||wb(a.e,4,true);sb(a.e)}}
function kc(a){ic(a.g);!!a.e&&jc(a);X(a.a);X(a.c);ic(a.b);ic(a.f)}
function li(a){bi(this);sj(this.a,Mh(a,Yc(ge,wo,1,Th(a.a),5,1)))}
function xi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function hj(a,b){Ti.call(this,b._(),b.$()&-16449);this.a=a;this.c=b}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function _g(a){function b(){}
;b.prototype=a||{};return new b}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Yj(a){a.placeholder='What needs to be done?';return a}
function Nm(a,b){b.preventDefault();w((I(),I(),H),new an(a),Po)}
function nl(a,b){Zn((Jm(),Im),b);w((I(),I(),H),new Hl(a,b),Po)}
function Xg(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Nj(a,b,c){!Fh(c,'key')&&!Fh(c,'ref')&&(a[c]=b[c],undefined)}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function Nb(b){try{b.b.v()}catch(a){a=Jg(a);if(!jd(a,5))throw Kg(a)}}
function On(a){this.b=Ri(a);I();this.a=new mc(0,null,null,true,false)}
function xl(a){return ih(),Wn((Jm(),Im))==a.j.props['a']?true:false}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Rh(a,b){return nd(b)?b==null?vi(a.a,null):Ji(a.b,b):vi(a.a,b)}
function Wi(a,b){!a.a?(a.a=new Jh(a.d)):Hh(a.a,a.b);Hh(a.a,b);return a}
function cj(a,b){var c;Yi(a);c=new mj;c.a=b;a.a.T(new pj(c));return c.a}
function _i(a){var b;Yi(a);b=0;while(a.a.ab(new nj)){b=Lg(b,1)}return b}
function Ln(a){var b;cj(aj(un(a.b),new oo),(b=new ki,b)).N(new po(a.b))}
function bm(a){$wnd.React.Component.call(this,a);this.a=new Ik(this)}
function fm(a){$wnd.React.Component.call(this,a);this.a=new Rk(this)}
function jm(a){$wnd.React.Component.call(this,a);this.a=new el(this)}
function nm(a){$wnd.React.Component.call(this,a);this.a=new El(this)}
function rm(a){$wnd.React.Component.call(this,a);this.a=new Tl(this)}
function Li(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Yh(a){this.d=a;this.c=new Li(this.d.b);this.a=this.c;this.b=Wh(this)}
function Xi(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function K(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function $(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=M(a.a[c])}return b}
function di(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function fb(a,b){var c,d;ci(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Tn(a,b){return (ko(),io)==a||(ho==a?(jb(b.a),!b.d):(jb(b.a),b.d))}
function uj(a,b){return Xc(b)!=10&&ad(q(b),b.jb,b.__elementTypeId$,Xc(b),a),a}
function Qh(a,b,c){return nd(b)?b==null?ui(a.a,null,c):Ii(a.b,b,c):ui(a.a,b,c)}
function Xn(a){var b,c;return b=R(a.b),cj(aj(un(a.i),new ro(b)),(c=new ki,c))}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function hi(a,b){var c;c=fi(a,b,0);if(c==-1){return false}tj(a.a,c);return true}
function fn(a,b){var c;if(jd(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function Mi(a){if(a.a.c!=a.c){return Hi(a.a,a.b.value[0])}return a.b.value[1]}
function fi(a,b,c){for(;c<a.a.length;++c){if(pi(b,a.a[c])){return c}}return -1}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function Km(a,b){a.f=b;Fh(b,R(a.a))&&Vm(a,b);Om(b);w((I(),I(),H),new an(a),Po)}
function Vk(a){var b;b=Gh((jb(a.b),a.e));if(b.length>0){Hn((Jm(),Hm),b);dl(a,'')}}
function Wk(a,b){if(13==b.keyCode){b.preventDefault();w((I(),I(),H),new hl(a),Po)}}
function hc(a){if(a.i>=0){a.i=-2;t((I(),I(),H),new F(new nc(a)),67108864,null)}}
function db(a){if(-2!=a.e){t((I(),I(),H),new F(new nb(a)),0,null);!!a.b&&ob(a.b)}}
function Q(a){if(!a.a){a.a=true;a.n=null;a.b=null;db(a.e);2==(a.f.c&7)||ob(a.f)}}
function C(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Gb(a.a)}finally{a.c=false}}}}
function U(a){if(a.b){if(jd(a.b,8)){throw Kg(a.b)}else{throw Kg(a.b)}}return a.n}
function vb(b){if(b){try{b.v()}catch(a){a=Jg(a);if(jd(a,5)){I()}else throw Kg(a)}}}
function ac(){var a;try{Rb(Pb);I()}finally{a=Pb.d;!a&&((I(),I(),H).d=true);Pb=Pb.d}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function cb(){var a;this.a=Yc(ud,wo,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new O}}
function Rg(){Sg();var a=Qg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function $g(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function vh(a,b){var c;if(!a){return}b.j=a;var d=sh(b);if(!d){Vg[a]=[b];return}d.ib=b}
function Jg(a){var b;if(jd(a,5)){return a}b=a&&a[Fo];if(!b){b=new wc(a);Tc(b)}return b}
function nh(a){var b;b=new mh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Ji(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{yi(a.a,b);--a.b}return c}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;ci((!a.b&&(a.b=new ki),a.b),b)}}}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new ki);a.c=c.c}b.d=true;ci(a.c,Ri(b))}
function sb(a){var b,c;for(c=new mi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function ni(a){var b,c,d;d=0;for(c=new Yh(a.a);c.b;){b=Xh(c);d=d+(b?r(b):0);d=d|0}return d}
function Ij(a){var b;b=Kj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Jj(a,b,c,d){var e;e=Kj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Ri(d);return e}
function Lj(a){var b;return Jj($wnd.React.StrictMode,null,null,(b={},b[Lo]=Ri(a),b))}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function md(a){return a!=null&&(typeof a===to||typeof a==='function')&&!(a.kb===bh)}
function Ug(a,b){typeof window===to&&typeof window['$gwt']===to&&(window['$gwt'][a]=b)}
function Ob(a,b){this.b=Ri(a);this.a=b|0|(0==(b&6291456)?Co:0)|(0!=(b&229376)?0:98304)}
function zb(a,b,c){yb.call(this,null,a,b,c|(!a?262144:yo)|(0==(c&6291456)?!a?Bo:Co:0)|0|0|0)}
function xh(){sc.call(this,"Stream already terminated, can't be modified or used")}
function Wh(a){if(a.a.U()){return true}if(a.a!=a.c){return false}a.a=new xi(a.d.a);return a.a.U()}
function Mg(a){var b;b=a.h;if(b==0){return a.l+a.m*Co}if(b==1048575){return a.l+a.m*Co-Io}return a}
function Lh(a,b){var c,d;for(d=new Yh(b.a);d.b;){c=Xh(d);if(!Uh(a,c)){return false}}return true}
function ri(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(pi(a,c.X())){return c}}return null}
function Og(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Io;d=1048575}c=pd(e/Co);b=pd(e-c*Co);return bd(b,c,d)}
function qn(a,b,c){var d;d=new nn(b,c);en(d,a,new fc(a,d));Qh(a.g,zh(d.c.d),d);ib(a.d);return d}
function Ii(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function bc(a,b,c){var d;d=Rh(a.g,b?zh(b.c.d):null);if(null!=d){lc(b.c,a);c&&!!b&&hc(b.c);ib(a.d)}}
function Zn(a,b){var c;c=a.e;if(!(b==c||!!b&&fn(b,c))){!!c&&lc(c.c,a);a.e=b;!!b&&en(b,a,new bo(a));ib(a.d)}}
function Yn(a){var b;b=R(a.g.a);Fh(Vo,b)||Fh(Wo,b)||Fh('',b)?Rm(a.g,b):Sn(Sm(a.g))?Um(a.g):Rm(a.g,'')}
function ko(){ko=Zg;ho=new lo('ACTIVE',0);jo=new lo('COMPLETED',1);io=new lo('ALL',2)}
function dh(){Jm();$wnd.ReactDOM.render(Lj([(new Fm).a]),(fh(),eh).getElementById('app'),null)}
function Cm(a,b){Hj(a.a,(kh(Qf),Qf.k+(''+(b?zh(b.c.d):null))));Ri(b);a.a.props['a']=b;return a.a}
function ad(a,b,c,d,e){e.ib=a;e.jb=b;e.kb=bh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function ml(a,b,c){27==c.which?w((I(),I(),H),new Ll(a,b),Po):13==c.which&&w((I(),I(),H),new Jl(a,b),Po)}
function ob(a){if(2<(a.c&7)){t((I(),I(),H),new F(new Db(a)),67108864,null);!!a.a&&Q(a.a);Kb(a.f);a.c=a.c&-8|1}}
function Ak(){if(!zk){zk=(++(I(),I(),H).e,new Jb);$wnd.Promise.resolve(null).then($g(Bk.prototype.G,Bk,[]))}}
function yk(){wk();return ad(Wc(Ve,1),wo,7,0,[ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk])}
function q(a){return nd(a)?je:ld(a)?$d:kd(a)?Yd:hd(a)?a.ib:$c(a)?a.ib:a.ib||Array.isArray(a)&&Wc(Rd,1)||Rd}
function Lb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&yo)?Nb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function gb(a,b){var c,d;d=a.c;hi(d,b);!!a.b&&yo!=(a.b.c&zo)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((I(),c=Pb,c),a))}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function Lg(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<Io){return c}}return Mg(cd(ld(a)?Og(a):a,ld(b)?Og(b):b))}
function zh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Bh(),Ah)[b];!c&&(c=Ah[b]=new yh(a));return c}return new yh(a)}
function ah(a){var b;if(Array.isArray(a)&&a.kb===bh){return lh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Dj(a){Bj();var b,c,d;c=':'+a;d=Aj[c];if(d!=null){return pd(d)}d=yj[c];b=d==null?Cj(a):pd(d);Ej();Aj[c]=b;return b}
function wc(a){uc();oc(this);this.e=a;a!=null&&vj(a,Fo,this);this.f=a==null?Ho:ah(a);this.a='';this.b=a;this.a=''}
function mh(){this.g=jh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Tl(a){var b;this.j=Ri(a);I();b=++Rl;this.b=new mc(b,null,new Ul(this),false,false);this.a=new zb(null,Ri(new Vl(this)),Oo)}
function Rk(a){var b;this.j=Ri(a);I();b=++Pk;this.b=new mc(b,null,new Sk(this),false,false);this.a=new zb(null,Ri(new Tk(this)),Oo)}
function pl(a){var b;b=R(a.c);if(!a.i&&b){a.i=true;Cl(a,a.j.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=gi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&wb(b.b,3,true)}}}
function Z(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=L(d);return c}}return null}
function oi(a){var b,c,d;d=1;for(c=new mi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function jc(a){var b,c,d;for(c=new mi(new li(new Vh(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.X();jd(d,9)&&d.u()||b.Y().v()}}
function ol(a,b){var c;c=(jb(a.a),a.d);if(null!=c&&c.length!=0){Mn((Jm(),b),c);Zn(Im,null);Dl(a,c)}else{tn((Jm(),Gm),b)}}
function p(a,b){return nd(a)?Fh(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.o(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function r(a){return nd(a)?Dj(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.q():$c(a)?xj(a):!!a&&!!a.hashCode?a.hashCode():xj(a)}
function Ab(a,b){yb.call(this,a,new Bb(a),null,b|(yo==(b&zo)?0:524288)|(0==(b&6291456)?yo==(b&zo)?Co:Bo:0)|0|268435456|0)}
function uh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function ji(a,b){var c,d;d=a.a.length;b.length<d&&(b=uj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Mh(a,b){var c,d,e;e=Th(a.a);b.length<e&&(b=uj(new Array(e),b));d=new Yh(a.a);for(c=0;c<e;++c){b[c]=Xh(d)}b.length>e&&(b[e]=null);return b}
function Pj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function mc(a,b,c,d,e){var f;this.d=a;this.e=d?new qi:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new mb((I(),null)),f):null;this.c=null}
function nn(a,b){var c,d,e;this.e=Ri(a);this.d=b;I();c=++cn;this.c=new mc(c,null,new on(this),true,true);this.b=(e=new mb(null),e);this.a=(d=new mb(null),d)}
function el(a){var b,c;this.j=Ri(a);I();b=++$k;this.c=new mc(b,null,new fl(this),false,false);this.b=(c=new mb(null),c);this.a=new zb(null,Ri(new jl(this)),Oo)}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.jb){return !!a.jb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function L(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function R(a){a.k?kb(a.e):jb(a.e);if(xb(a.f)){if(a.k&&(I(),!(!!Pb&&!!Pb.e))){return t((I(),I(),H),new W(a),83888128,null)}else{qb(a.f)}}return U(a)}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new mi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&wb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new mi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&wb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new mi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?wb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Gh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=Jg(a);if(jd(a,5)){e=a;throw Kg(e)}else throw Kg(a)}finally{C(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=Jg(a);if(jd(a,5)){f=a;throw Kg(f)}else throw Kg(a)}finally{C(b)}}
function Fb(a){var b,c;if(0==a.c){b=$(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Z(a.d);Lb(c);return true}
function Tg(b,c,d,e){Sg();var f=Qg;$moduleName=c;$moduleBase=d;Ig=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{so(g)()}catch(a){b(c,a)}}else{so(g)()}}
function V(a,b,c,d){this.c=Ri(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new Ab(this,d&-16385);this.e=new mb(this.f);yo==(d&zo)&&pb(this.f)}
function Ik(a){var b;this.j=Ri(a);I();b=++Fk;this.c=new mc(b,null,new Jk(this),false,false);this.a=new V(new Kk,null,null,136478720);this.b=new zb(null,Ri(new Lk(this)),Oo)}
function Kj(a,b){var c;c=new $wnd.Object;c.$$typeof=Ri(a);c.type=Ri(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Di(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ei()}}
function Wg(){Vg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].lb()&&(c=Pc(c,g)):g[0].lb()}catch(a){a=Jg(a);if(jd(a,5)){d=a;Bc();Hc(jd(d,35)?d.F():d)}else throw Kg(a)}}return c}
function Zk(a){var b;a.d=0;Ak();b=Mj(Qo,Tj(Wj(Xj($j(Yj(Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,['new-todo']))),(jb(a.b),a.e)),$g(sm.prototype.fb,sm,[a])),$g(tm.prototype.eb,tm,[a]))),null);return b}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?Ho:md(b)?b==null?null:b.name:nd(b)?'String':lh(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function P(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.n=d;b.b=null;hb(b.e)}}catch(a){a=Jg(a);if(jd(a,12)){c=a;if(!b.b){b.n=null;b.b=c;hb(b.e)}throw Kg(c)}else throw Kg(a)}}
function ui(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=ri(b,e);if(f){return f.Z(c)}}e[e.length]=new ai(b,c);++a.b;return null}
function qj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Cj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Eh(a,c++)}b=b|0;return b}
function qb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;u((I(),I(),H),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Jg(a);if(jd(a,5)){I()}else throw Kg(a)}}}
function N(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Yc(ge,wo,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Om(a){var b;if(0==a.length){b=(fh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',eh.title,b)}else{(fh(),$wnd.window.window).location.hash=a}}
function yb(a,b,c,d){this.b=new ki;this.f=new Ob(new Cb(this),d&6520832|262144|yo);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(B((I(),I(),H),this),0==(this.f.a&Bo)&&C((null,H)))}
function vi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(pi(b,e.X())){if(d.length==1){d.length=0;yi(a.a,g)}else{d.splice(h,1)}--a.b;return e.Y()}}return null}
function El(a){var b,c;this.j=Ri(a);I();b=++ul;this.e=new mc(b,null,new Fl(this),false,false);this.a=(c=new mb(null),c);this.c=new V(new Il(this),null,null,136478720);this.b=new zb(null,Ri(new Nl(this)),Oo);Cl(this,this.j.props['a'])}
function Yg(a,b,c){var d=Vg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Vg[b]),_g(h));_.jb=c;!b&&(_.kb=bh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ib=f)}
function th(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=uh('.',[c,uh('$',d)]);a.b=uh('.',[c,uh('.',d)]);a.i=d[d.length-1]}
function Nh(a,b){var c,d,e;c=b.X();e=b.Y();d=nd(c)?c==null?Ph(ti(a.a,null)):Hi(a.b,c):Ph(ti(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!ti(a.a,null):Gi(a.b,c):!!ti(a.a,c))){return false}return true}
function Mj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Gj(b,$g(Oj.prototype.cb,Oj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Lo]=c[0],undefined):(d[Lo]=c,undefined));return Jj(a,e,f,d)}
function Wm(){var a,b;this.d=new go(this);this.f=this.e=(b=(fh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));I();this.c=new mc(0,null,new Xm(this),true,false);this.b=(a=new mb(null),a);this.a=new V(new bn,new Ym(this),new Zm(this),35651584)}
function $n(a){var b;this.i=Ri(a);this.g=new Wm;I();this.f=new mc(0,new _n(this),new ao(this),true,false);this.d=(b=new mb(null),b);this.b=new V(new co(this),null,null,Uo);this.c=new V(new eo(this),null,null,Uo);this.a=new zb(Ri(new fo(this)),null,681574400);C((null,H))}
function yn(){var a;this.g=new qi;I();this.f=new mc(0,new An(this),new zn(this),true,false);this.d=(a=new mb(null),a);this.c=new V(new Dn(this),null,null,Uo);this.e=new V(new En(this),null,null,Uo);this.a=new V(new Fn(this),null,null,Uo);this.b=new V(new Gn(this),null,null,Uo)}
function xb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new mi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{R(c)}catch(a){a=Jg(a);if(!jd(a,5))throw Kg(a)}if(6==(b.c&7)){return true}}}}}sb(b);return false}
function Ci(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function wb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||B((I(),I(),H),a))}else if(!!a.a&&4==g&&(6==b||5==b)){lb(a.a.e);vb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||B((I(),I(),H),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;vb((e=d.i,e));d.n=null}di(a.b,new Eb(a));a.b.a=Yc(ge,wo,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&vb((f=a.a.g,f))}}
function wk(){wk=Zg;ak=new xk(Mo,0);bk=new xk('checkbox',1);ck=new xk('color',2);dk=new xk('date',3);ek=new xk('datetime',4);fk=new xk('email',5);gk=new xk('file',6);hk=new xk('hidden',7);ik=new xk('image',8);jk=new xk('month',9);kk=new xk(uo,10);lk=new xk('password',11);mk=new xk('radio',12);nk=new xk('range',13);ok=new xk('reset',14);pk=new xk('search',15);qk=new xk('submit',16);rk=new xk('tel',17);sk=new xk('text',18);tk=new xk('time',19);uk=new xk('url',20);vk=new xk('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ei(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ii(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{gb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&wb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ei(a.b,g);if(-1==k.e){k.e=0;fb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){gi(a.b,g)}e&&ub(a.e,a.b)}else{e&&ub(a.e,new ki)}if(Y(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&yo!=(k.b.c&zo)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function Ek(a){var b,c;a.d=0;Ak();c=(b=R((Jm(),Im).b),Mj('footer',Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,['footer'])),[(new Zl).a,Mj('ul',Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,['filters'])),[Mj('li',null,[Mj('a',Rj(Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,[(ko(),io)==b?No:null])),'#'),['All'])]),Mj('li',null,[Mj('a',Rj(Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,[ho==b?No:null])),'#active'),['Active'])]),Mj('li',null,[Mj('a',Rj(Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,[jo==b?No:null])),'#completed'),['Completed'])])]),R(a.a)?Mj(Mo,Sj(Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,['clear-completed'])),$g(Xl.prototype.gb,Xl,[])),['Clear Completed']):null]));return c}
function tl(a){var b,c,d,e;a.f=0;Ak();b=a.j.props['a'];if(b.c.i<0){return null}c=(d=a.j.props['a'],e=(jb(d.a),d.d),Mj('li',Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,[e?'checked':null,R(a.c)?'editing':null])),[Mj('div',Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,['view'])),[Mj(Qo,Wj(Uj(Zj(Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,['toggle'])),(wk(),bk)),e),$g(wm.prototype.eb,wm,[d])),null),Mj('label',_j(new $wnd.Object,$g(xm.prototype.gb,xm,[a,d])),[(jb(d.b),d.e)]),Mj(Mo,Sj(Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,['destroy'])),$g(ym.prototype.gb,ym,[d])),null)]),Mj(Qo,Xj(Wj(Vj($j(Pj(Qj(new $wnd.Object,$g(zm.prototype.w,zm,[a])),ad(Wc(je,1),wo,2,6,['edit'])),(jb(a.a),a.d)),$g(Am.prototype.db,Am,[a,d])),$g(vm.prototype.eb,vm,[a])),$g(Bm.prototype.fb,Bm,[a,d])),null)]));return c}
function Ei(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Ko]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ci()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Ko]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var to='object',uo='number',vo={11:1},wo={3:1,4:1},xo={9:1},yo=1048576,zo=1835008,Ao={6:1},Bo=2097152,Co=4194304,Do={26:1},Eo='__noinit__',Fo='__java$exception',Go={3:1,12:1,8:1,5:1},Ho='null',Io=17592186044416,Jo={40:1},Ko='delete',Lo='children',Mo='button',No='selected',Oo=1411518464,Po=142606336,Qo='input',Ro='header',So='hashchange',To={9:1,49:1},Uo=136314880,Vo='active',Wo='completed';var _,Vg,Qg,Ig=-1;Wg();Yg(1,null,{},o);_.o=Yo;_.p=function(){return this.ib};_.q=Zo;_.r=function(){var a;return lh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var dd,ed,fd;Yg(51,1,{},mh);_.H=function(a){var b;b=new mh;b.e=4;a>1?(b.c=rh(this,a-1)):(b.c=this);return b};_.I=function(){kh(this);return this.b};_.J=function(){return lh(this)};_.K=function(){kh(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(kh(this),this.k)};_.e=0;_.g=0;var jh=1;var ge=oh(1);var Zd=oh(51);Yg(79,1,{},D);_.b=1;_.c=false;_.d=true;_.e=0;var td=oh(79);Yg(36,1,vo,F);_.s=function(){return this.a.v(),null};var rd=oh(36);Yg(80,1,{},G);var sd=oh(80);var H;Yg(43,1,{43:1},O);_.b=0;_.c=false;_.d=0;var ud=oh(43);Yg(210,1,xo);_.r=function(){var a;return lh(this.ib)+'@'+(a=r(this)>>>0,a.toString(16))};var yd=oh(210);Yg(20,210,xo,V);_.t=function(){Q(this)};_.u=Xo;_.a=false;_.d=0;_.k=false;var wd=oh(20);Yg(115,1,vo,W);_.s=function(){return S(this.a)};var vd=oh(115);Yg(135,1,{241:1},cb);var xd=oh(135);Yg(17,210,{9:1,17:1},mb);_.t=function(){db(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Ad=oh(17);Yg(114,1,Ao,nb);_.v=function(){eb(this.a)};var zd=oh(114);Yg(18,210,{9:1,18:1},zb,Ab);_.t=function(){ob(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Fd=oh(18);Yg(116,1,Do,Bb);_.v=function(){P(this.a)};var Bd=oh(116);Yg(117,1,Ao,Cb);_.v=function(){qb(this.a)};var Cd=oh(117);Yg(118,1,Ao,Db);_.v=function(){tb(this.a)};var Dd=oh(118);Yg(119,1,{},Eb);_.w=function(a){rb(this.a,a)};var Ed=oh(119);Yg(134,1,{},Hb);_.a=0;_.b=0;_.c=0;var Gd=oh(134);Yg(155,1,xo,Jb);_.t=function(){Ib(this)};_.u=Xo;_.a=false;var Hd=oh(155);Yg(61,210,{9:1,61:1},Ob);_.t=function(){Kb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Id=oh(61);Yg(137,1,{},$b);_.r=function(){var a;return kh(Jd),Jd.k+'@'+(a=xj(this)>>>0,a.toString(16))};_.a=0;var Pb;var Jd=oh(137);Yg(102,1,{});var Md=oh(102);Yg(81,1,{},ec);_.w=function(a){cc(this.a,a)};var Kd=oh(81);Yg(82,1,Ao,fc);_.v=function(){dc(this.a,this.b)};var Ld=oh(82);Yg(103,102,{});var Nd=oh(103);Yg(16,1,xo,mc);_.t=function(){hc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return kh(Pd),Pd.k+'@'+(a=xj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Pd=oh(16);Yg(113,1,Ao,nc);_.v=function(){kc(this.a)};var Od=oh(113);Yg(5,1,{3:1,5:1});_.B=function(a){return new Error(a)};_.C=function(){return this.f};_.D=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=lh(this.ib),c==null?a:a+': '+c);pc(this,rc(this.B(b)));Tc(this)};_.r=function(){return qc(this,this.C())};_.e=Eo;_.g=true;var ke=oh(5);Yg(12,5,{3:1,12:1,5:1});var ae=oh(12);Yg(8,12,Go);var he=oh(8);Yg(52,8,Go);var de=oh(52);Yg(73,52,Go);var Td=oh(73);Yg(35,73,{35:1,3:1,12:1,8:1,5:1},wc);_.C=function(){vc(this);return this.c};_.F=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Qd=oh(35);var Rd=oh(0);Yg(196,1,{});var Sd=oh(196);var yc=0,zc=0,Ac=-1;Yg(101,196,{},Oc);var Kc;var Ud=oh(101);var Rc;Yg(207,1,{});var Wd=oh(207);Yg(74,207,{},Vc);var Vd=oh(74);var eh;Yg(71,1,{68:1});_.r=Xo;var Xd=oh(71);dd={3:1,69:1,31:1};var Yd=oh(69);Yg(41,1,{3:1,41:1});var fe=oh(41);ed={3:1,31:1,41:1};var $d=oh(206);Yg(33,1,{3:1,31:1,33:1});_.o=Yo;_.q=Zo;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var _d=oh(33);Yg(75,8,Go,xh);var be=oh(75);Yg(32,41,{3:1,31:1,32:1,41:1},yh);_.o=function(a){return jd(a,32)&&a.a==this.a};_.q=Xo;_.r=function(){return ''+this.a};_.a=0;var ce=oh(32);var Ah;Yg(273,1,{});Yg(77,52,Go,Dh);_.B=function(a){return new TypeError(a)};var ee=oh(77);fd={3:1,68:1,31:1,2:1};var je=oh(2);Yg(72,71,{68:1},Jh);var ie=oh(72);Yg(277,1,{});Yg(54,8,Go,Kh);var le=oh(54);Yg(208,1,{39:1});_.N=bp;_.R=function(){return new Vi(this,0)};_.S=function(){return new dj(null,this.R())};_.P=function(a){throw Kg(new Kh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Xi('[',']');for(b=this.O();b.U();){a=b.V();Wi(c,a===this?'(this Collection)':a==null?Ho:ah(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var me=oh(208);Yg(211,1,{194:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!jd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Yh((new Vh(d)).a);c.b;){b=Xh(c);if(!Nh(this,b)){return false}}return true};_.q=function(){return ni(new Vh(this))};_.r=function(){var a,b,c;c=new Xi('{','}');for(b=new Yh((new Vh(this)).a);b.b;){a=Xh(b);Wi(c,Oh(this,a.X())+'='+Oh(this,a.Y()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var xe=oh(211);Yg(120,211,{194:1});var pe=oh(120);Yg(212,208,{39:1,222:1});_.R=function(){return new Vi(this,1)};_.o=function(a){var b;if(a===this){return true}if(!jd(a,22)){return false}b=a;if(Th(b.a)!=this.Q()){return false}return Lh(this,b)};_.q=function(){return ni(this)};var ye=oh(212);Yg(22,212,{22:1,39:1,222:1},Vh);_.O=function(){return new Yh(this.a)};_.Q=_o;var oe=oh(22);Yg(23,1,{},Yh);_.T=$o;_.V=function(){return Xh(this)};_.U=ap;_.b=false;var ne=oh(23);Yg(209,208,{39:1,219:1});_.R=function(){return new Vi(this,16)};_.W=function(a,b){throw Kg(new Kh('Add not supported on this list'))};_.P=function(a){this.W(this.Q(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,14)){return false}f=a;if(this.Q()!=f.a.length){return false}e=new mi(f);for(c=new mi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return oi(this)};_.O=function(){return new Zh(this)};var re=oh(209);Yg(100,1,{},Zh);_.T=$o;_.U=function(){return this.a<this.b.a.length};_.V=function(){return ei(this.b,this.a++)};_.a=0;var qe=oh(100);Yg(55,208,{39:1},$h);_.O=function(){var a;a=new Yh((new Vh(this.a)).a);return new _h(a)};_.Q=_o;var te=oh(55);Yg(123,1,{},_h);_.T=$o;_.U=function(){return this.a.b};_.V=function(){var a;a=Xh(this.a);return a.Y()};var se=oh(123);Yg(121,1,Jo);_.o=function(a){var b;if(!jd(a,40)){return false}b=a;return pi(this.a,b.X())&&pi(this.b,b.Y())};_.X=Xo;_.Y=ap;_.q=function(){return Qi(this.a)^Qi(this.b)};_.Z=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ue=oh(121);Yg(122,121,Jo,ai);var ve=oh(122);Yg(213,1,Jo);_.o=function(a){var b;if(!jd(a,40)){return false}b=a;return pi(this.b.value[0],b.X())&&pi(Mi(this),b.Y())};_.q=function(){return Qi(this.b.value[0])^Qi(Mi(this))};_.r=function(){return this.b.value[0]+'='+Mi(this)};var we=oh(213);Yg(14,209,{3:1,14:1,39:1,219:1},ki,li);_.W=function(a,b){rj(this.a,a,b)};_.P=function(a){return ci(this,a)};_.N=function(a){di(this,a)};_.O=function(){return new mi(this)};_.Q=function(){return this.a.length};var Ae=oh(14);Yg(19,1,{},mi);_.T=$o;_.U=function(){return this.a<this.c.a.length};_.V=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ze=oh(19);Yg(37,120,{3:1,37:1,194:1},qi);var Be=oh(37);Yg(59,1,{},wi);_.N=bp;_.O=function(){return new xi(this)};_.b=0;var De=oh(59);Yg(60,1,{},xi);_.T=$o;_.V=function(){return this.d=this.a[this.c++],this.d};_.U=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ce=oh(60);var Ai;Yg(57,1,{},Ki);_.N=bp;_.O=function(){return new Li(this)};_.b=0;_.c=0;var Ge=oh(57);Yg(58,1,{},Li);_.T=$o;_.V=function(){return this.c=this.a,this.a=this.b.next(),new Ni(this.d,this.c,this.d.c)};_.U=function(){return !this.a.done};var Ee=oh(58);Yg(136,213,Jo,Ni);_.X=function(){return this.b.value[0]};_.Y=function(){return Mi(this)};_.Z=function(a){return Ii(this.a,this.b.value[0],a)};_.c=0;var Fe=oh(136);Yg(139,1,{});_.T=function(a){Si(this,a)};_.$=function(){return this.d};_._=function(){return this.e};_.d=0;_.e=0;var Ie=oh(139);Yg(62,139,{});var He=oh(62);Yg(24,1,{},Vi);_.$=Xo;_._=function(){Ui(this);return this.c};_.T=function(a){Ui(this);this.d.T(a)};_.ab=function(a){Ui(this);if(this.d.U()){a.w(this.d.V());return true}return false};_.a=0;_.c=0;var Je=oh(24);Yg(53,1,{},Xi);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ke=oh(53);Yg(138,1,{});_.c=false;var Te=oh(138);Yg(28,138,{242:1,28:1},dj);var Se=oh(28);Yg(141,62,{},hj);_.ab=function(a){this.b=false;while(!this.b&&this.c.ab(new ij(this,a)));return this.b};_.b=false;var Me=oh(141);Yg(144,1,{},ij);_.w=function(a){gj(this.a,this.b,a)};var Le=oh(144);Yg(140,62,{},jj);_.ab=function(a){return this.a.ab(new kj(a))};var Oe=oh(140);Yg(143,1,{},kj);_.w=function(a){this.a.w(Cm(new Dm,a))};var Ne=oh(143);Yg(142,1,{},mj);_.w=function(a){lj(this,a)};var Pe=oh(142);Yg(145,1,{},nj);_.w=function(a){};var Qe=oh(145);Yg(146,1,{},pj);_.w=function(a){oj(this,a)};var Re=oh(146);Yg(275,1,{});Yg(272,1,{});var wj=0;var yj,zj=0,Aj;Yg(893,1,{});Yg(915,1,{});Yg(214,1,{});var Ue=oh(214);Yg(243,$wnd.Function,{},Oj);_.cb=function(a){Nj(this.a,this.b,a)};Yg(7,33,{3:1,31:1,33:1,7:1},xk);var ak,bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk;var Ve=ph(7,yk);var zk;Yg(244,$wnd.Function,{},Bk);_.G=function(a){return Ib(zk),zk=null,null};Yg(217,214,{});var Cf=oh(217);Yg(168,217,{});_.d=0;var Gf=oh(168);Yg(169,168,xo,Ik);_.t=cp;_.o=Yo;_.q=Zo;_.u=dp;_.r=function(){var a;return kh(cf),cf.k+'@'+(a=xj(this)>>>0,a.toString(16))};var Fk=0;var cf=oh(169);Yg(170,1,Ao,Jk);_.v=function(){Gk(this.a)};var We=oh(170);Yg(171,1,vo,Kk);_.s=function(){return ih(),R((Jm(),Gm).b).a>0?true:false};var Xe=oh(171);Yg(172,1,Do,Lk);_.v=function(){Dk(this.a)};var Ye=oh(172);Yg(173,1,vo,Mk);_.s=function(){return Ek(this.a)};var Ze=oh(173);Yg(218,214,{});var Bf=oh(218);Yg(188,218,{});_.c=0;var Ff=oh(188);Yg(189,188,xo,Rk);_.t=ep;_.o=Yo;_.q=Zo;_.u=fp;_.r=function(){var a;return kh(bf),bf.k+'@'+(a=xj(this)>>>0,a.toString(16))};var Pk=0;var bf=oh(189);Yg(190,1,Ao,Sk);_.v=gp;var $e=oh(190);Yg(191,1,Do,Tk);_.v=function(){Ok(this.a)};var _e=oh(191);Yg(192,1,vo,Uk);_.s=function(){var a,b;return this.a.c=0,Ak(),a=R((Jm(),Gm).e).a,b='item'+(a==1?'':'s'),Mj('span',Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,['todo-count'])),[Mj('strong',null,[a]),' '+b+' left'])};var af=oh(192);Yg(160,214,{});_.e='';var Of=oh(160);Yg(161,160,{});_.d=0;var If=oh(161);Yg(162,161,xo,el);_.t=cp;_.o=Yo;_.q=Zo;_.u=dp;_.r=function(){var a;return kh(jf),jf.k+'@'+(a=xj(this)>>>0,a.toString(16))};var $k=0;var jf=oh(162);Yg(163,1,Ao,fl);_.v=function(){_k(this.a)};var df=oh(163);Yg(165,1,vo,gl);_.s=function(){return Zk(this.a)};var ef=oh(165);Yg(166,1,Ao,hl);_.v=function(){Vk(this.a)};var ff=oh(166);Yg(167,1,Ao,il);_.v=function(){bl(this.a,this.b)};var gf=oh(167);Yg(164,1,Do,jl);_.v=function(){Dk(this.a)};var hf=oh(164);Yg(216,214,{});_.i=false;var Qf=oh(216);Yg(175,216,{});_.f=0;var Kf=oh(175);Yg(176,175,xo,El);_.t=function(){hc(this.e)};_.o=Yo;_.q=Zo;_.u=function(){return this.e.i<0};_.r=function(){var a;return kh(uf),uf.k+'@'+(a=xj(this)>>>0,a.toString(16))};var ul=0;var uf=oh(176);Yg(177,1,Ao,Fl);_.v=function(){vl(this.a)};var kf=oh(177);Yg(180,1,vo,Gl);_.s=function(){return tl(this.a)};var lf=oh(180);Yg(63,1,Ao,Hl);_.v=function(){Dl(this.a,Sm(this.b))};var mf=oh(63);Yg(178,1,vo,Il);_.s=function(){return xl(this.a)};var nf=oh(178);Yg(64,1,Ao,Jl);_.v=function(){ol(this.a,this.b)};var of=oh(64);Yg(181,1,Ao,Kl);_.v=function(){nl(this.a,this.b)};var pf=oh(181);Yg(182,1,Ao,Ll);_.v=function(){Cl(this.a,this.b);Zn((Jm(),Im),null)};var qf=oh(182);Yg(183,1,Ao,Ml);_.v=function(){kl(this.a,this.b)};var rf=oh(183);Yg(179,1,Do,Nl);_.v=function(){sl(this.a)};var sf=oh(179);Yg(184,1,Ao,Ol);_.v=function(){pl(this.a)};var tf=oh(184);Yg(215,214,{});var Sf=oh(215);Yg(148,215,{});_.c=0;var Mf=oh(148);Yg(149,148,xo,Tl);_.t=ep;_.o=Yo;_.q=Zo;_.u=fp;_.r=function(){var a;return kh(yf),yf.k+'@'+(a=xj(this)>>>0,a.toString(16))};var Rl=0;var yf=oh(149);Yg(150,1,Ao,Ul);_.v=gp;var vf=oh(150);Yg(151,1,Do,Vl);_.v=function(){Ok(this.a)};var wf=oh(151);Yg(152,1,vo,Wl);_.s=function(){var a;return this.a.c=0,Ak(),Mj('div',null,[Mj('div',null,[Mj(Ro,Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,[Ro])),[Mj('h1',null,['todos']),(new um).a]),R((Jm(),Gm).c)?null:Mj('section',Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,[Ro])),[Mj(Qo,Wj(Zj(Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,['toggle-all'])),(wk(),bk)),$g(Em.prototype.eb,Em,[])),null),Mj('ul',Pj(new $wnd.Object,ad(Wc(je,1),wo,2,6,['todo-list'])),(a=cj(Ri(bj(R(Im.c).S())),new ki),ji(a,_c(a.a.length))))]),R(Gm.c)?null:(new Yl).a])])};var xf=oh(152);Yg(248,$wnd.Function,{},Xl);_.gb=function(a){Jn((Jm(),Hm))};Yg(154,1,{},Yl);var zf=oh(154);Yg(174,1,{},Zl);var Af=oh(174);Yg(249,$wnd.Function,{},$l);_.hb=function(a){return new bm(a)};var _l;Yg(158,$wnd.React.Component,{},bm);Xg(Vg[1],_);_.componentWillUnmount=function(){Ck(this.a)};_.render=function(){return Hk(this.a)};_.shouldComponentUpdate=hp;var Df=oh(158);Yg(259,$wnd.Function,{},cm);_.hb=function(a){return new fm(a)};var dm;Yg(185,$wnd.React.Component,{},fm);Xg(Vg[1],_);_.componentWillUnmount=function(){Nk(this.a)};_.render=function(){return Qk(this.a)};_.shouldComponentUpdate=ip;var Ef=oh(185);Yg(247,$wnd.Function,{},gm);_.hb=function(a){return new jm(a)};var hm;Yg(156,$wnd.React.Component,{},jm);Xg(Vg[1],_);_.componentWillUnmount=function(){Ck(this.a)};_.render=function(){return cl(this.a)};_.shouldComponentUpdate=hp;var Hf=oh(156);Yg(258,$wnd.Function,{},km);_.hb=function(a){return new nm(a)};var lm;Yg(159,$wnd.React.Component,{},nm);Xg(Vg[1],_);_.componentDidUpdate=function(a){Al(this.a)};_.componentWillUnmount=function(){rl(this.a)};_.render=function(){return Bl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Jf=oh(159);Yg(240,$wnd.Function,{},om);_.hb=function(a){return new rm(a)};var pm;Yg(125,$wnd.React.Component,{},rm);Xg(Vg[1],_);_.componentWillUnmount=function(){Nk(this.a)};_.render=function(){return Sl(this.a)};_.shouldComponentUpdate=ip;var Lf=oh(125);Yg(245,$wnd.Function,{},sm);_.fb=function(a){Wk(this.a,a)};Yg(246,$wnd.Function,{},tm);_.eb=function(a){al(this.a,a)};Yg(153,1,{},um);var Nf=oh(153);Yg(256,$wnd.Function,{},vm);_.eb=function(a){wl(this.a,a)};Yg(250,$wnd.Function,{},wm);_.eb=function(a){mn(this.a)};Yg(252,$wnd.Function,{},xm);_.gb=function(a){yl(this.a,this.b)};Yg(253,$wnd.Function,{},ym);_.gb=function(a){ql(this.a)};Yg(254,$wnd.Function,{},zm);_.w=function(a){ll(this.a,a)};Yg(255,$wnd.Function,{},Am);_.db=function(a){zl(this.a,this.b)};Yg(257,$wnd.Function,{},Bm);_.fb=function(a){ml(this.a,this.b,a)};Yg(157,1,{},Dm);var Pf=oh(157);Yg(239,$wnd.Function,{},Em);_.eb=function(a){var b;b=a.target;Nn((Jm(),Hm),b.checked)};Yg(67,1,{},Fm);var Rf=oh(67);var Gm,Hm,Im;Yg(126,1,{});var xg=oh(126);Yg(127,126,To,Wm);_.t=cp;_.o=Yo;_.q=Zo;_.u=dp;_.A=jp;_.r=function(){var a;return kh($f),$f.k+'@'+(a=xj(this)>>>0,a.toString(16))};var $f=oh(127);Yg(128,1,Ao,Xm);_.v=function(){Qm(this.a)};var Tf=oh(128);Yg(130,1,Do,Ym);_.v=function(){Lm(this.a)};var Uf=oh(130);Yg(131,1,Do,Zm);_.v=function(){Mm(this.a)};var Vf=oh(131);Yg(132,1,Ao,$m);_.v=function(){Km(this.a,this.b)};var Wf=oh(132);Yg(133,1,Ao,_m);_.v=function(){Tm(this.a)};var Xf=oh(133);Yg(56,1,Ao,an);_.v=function(){Pm(this.a)};var Yf=oh(56);Yg(129,1,vo,bn);_.s=function(){var a;return a=(fh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var Zf=oh(129);Yg(44,1,{44:1});_.d=false;var Fg=oh(44);Yg(45,44,{9:1,49:1,45:1,44:1},nn);_.t=cp;_.o=function(a){return fn(this,a)};_.q=function(){return this.c.d};_.u=dp;_.A=jp;_.r=function(){var a;return kh(og),og.k+'@'+(a=this.c.d>>>0,a.toString(16))};var cn=0;var og=oh(45);Yg(186,1,Ao,on);_.v=function(){dn(this.a)};var _f=oh(186);Yg(187,1,Ao,pn);_.v=function(){jn(this.a)};var ag=oh(187);Yg(42,103,{42:1});var Ag=oh(42);Yg(104,42,{9:1,49:1,42:1},yn);_.t=kp;_.o=Yo;_.q=Zo;_.u=lp;_.A=mp;_.r=function(){var a;return kh(jg),jg.k+'@'+(a=xj(this)>>>0,a.toString(16))};var jg=oh(104);Yg(106,1,Ao,zn);_.v=function(){rn(this.a)};var bg=oh(106);Yg(105,1,Ao,An);_.v=function(){vn(this.a)};var cg=oh(105);Yg(111,1,Ao,Bn);_.v=function(){bc(this.a,this.b,true)};var dg=oh(111);Yg(112,1,vo,Cn);_.s=function(){return qn(this.a,this.c,this.b)};_.b=false;var eg=oh(112);Yg(107,1,vo,Dn);_.s=function(){return wn(this.a)};var fg=oh(107);Yg(108,1,vo,En);_.s=function(){return zh(Pg(_i(un(this.a))))};var gg=oh(108);Yg(109,1,vo,Fn);_.s=function(){return zh(Pg(_i(aj(un(this.a),new no))))};var hg=oh(109);Yg(110,1,vo,Gn);_.s=function(){return xn(this.a)};var ig=oh(110);Yg(87,1,{});var Eg=oh(87);Yg(88,87,To,On);_.t=function(){hc(this.a)};_.o=Yo;_.q=Zo;_.u=function(){return this.a.i<0};_.A=function(a){lc(this.a,a)};_.r=function(){var a;return kh(ng),ng.k+'@'+(a=xj(this)>>>0,a.toString(16))};var ng=oh(88);Yg(89,1,Ao,Pn);_.v=function(){Kn(this.a,this.b)};_.b=false;var kg=oh(89);Yg(90,1,Ao,Qn);_.v=function(){Vm(this.b,this.a)};var lg=oh(90);Yg(91,1,Ao,Rn);_.v=function(){Ln(this.a)};var mg=oh(91);Yg(92,1,{});var Hg=oh(92);Yg(93,92,To,$n);_.t=kp;_.o=Yo;_.q=Zo;_.u=lp;_.A=mp;_.r=function(){var a;return kh(vg),vg.k+'@'+(a=xj(this)>>>0,a.toString(16))};var vg=oh(93);Yg(94,1,Ao,_n);_.v=function(){Vn(this.a)};var pg=oh(94);Yg(95,1,Ao,ao);_.v=function(){Un(this.a)};var qg=oh(95);Yg(99,1,Ao,bo);_.v=function(){Zn(this.a,null)};var rg=oh(99);Yg(96,1,vo,co);_.s=function(){var a;return a=Sm(this.a.g),Fh(Vo,a)?(ko(),ho):Fh(Wo,a)?(ko(),jo):(ko(),io)};var sg=oh(96);Yg(97,1,vo,eo);_.s=function(){return Xn(this.a)};var tg=oh(97);Yg(98,1,Do,fo);_.v=function(){Yn(this.a)};var ug=oh(98);Yg(124,1,{},go);_.handleEvent=function(a){Nm(this.a,a)};var wg=oh(124);Yg(34,33,{3:1,31:1,33:1,34:1},lo);var ho,io,jo;var yg=ph(34,mo);Yg(83,1,{},no);_.bb=function(a){return !hn(a)};var zg=oh(83);Yg(85,1,{},oo);_.bb=function(a){return hn(a)};var Bg=oh(85);Yg(86,1,{},po);_.w=function(a){tn(this.a,a)};var Cg=oh(86);Yg(84,1,{},qo);_.w=function(a){In(this.a,a)};_.a=false;var Dg=oh(84);Yg(76,1,{},ro);_.bb=function(a){return Tn(this.a,a)};var Gg=oh(76);var qd=qh('D');var so=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=Tg;Rg(dh);Ug('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();