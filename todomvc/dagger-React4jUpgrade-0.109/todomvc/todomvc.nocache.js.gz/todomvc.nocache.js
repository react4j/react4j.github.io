function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='2E0122155F94FEF7B6860F640C92EDDA',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '2E0122155F94FEF7B6860F640C92EDDA';function o(){}
function Eh(){}
function Ah(){}
function Ib(){}
function Oc(){}
function Vc(){}
function Qj(){}
function Rj(){}
function tk(){}
function tn(){}
function an(){}
function gn(){}
function nn(){}
function Wm(){}
function vo(){}
function ap(){}
function ip(){}
function Jp(){}
function Kp(){}
function Jq(){}
function Tc(a){Sc()}
function $m(a){Zm=a}
function en(a){dn=a}
function ln(a){kn=a}
function rn(a){qn=a}
function xn(a){wn=a}
function Mh(){Mh=Ah}
function Ni(){Ei(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function mb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function hc(a){this.a=a}
function nc(a){this.a=a}
function _h(a){this.a=a}
function ki(a){this.a=a}
function wi(a){this.a=a}
function Bi(a){this.a=a}
function Ci(a){this.a=a}
function Ai(a){this.b=a}
function Pi(a){this.c=a}
function Oj(a){this.a=a}
function Tj(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function xl(a){this.a=a}
function zl(a){this.a=a}
function Ll(a){this.a=a}
function Ml(a){this.a=a}
function Nl(a){this.a=a}
function Ol(a){this.a=a}
function Ql(a){this.a=a}
function Sl(a){this.a=a}
function om(a){this.a=a}
function pm(a){this.a=a}
function qm(a){this.a=a}
function wm(a){this.a=a}
function ym(a){this.a=a}
function zm(a){this.a=a}
function Hm(a){this.a=a}
function Im(a){this.a=a}
function Jm(a){this.a=a}
function Km(a){this.a=a}
function Nm(a){this.a=a}
function Pm(a){this.a=a}
function Rm(a){this.a=a}
function zn(a){this.a=a}
function An(a){this.a=a}
function Cn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function In(a){this.a=a}
function Pn(a){this.a=a}
function Sn(a){this.a=a}
function Un(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function so(a){this.a=a}
function to(a){this.a=a}
function uo(a){this.a=a}
function Ho(a){this.a=a}
function Io(a){this.a=a}
function So(a){this.a=a}
function To(a){this.a=a}
function Wo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function lp(a){this.a=a}
function mp(a){this.a=a}
function wp(a){this.a=a}
function xp(a){this.a=a}
function yp(a){this.a=a}
function zp(a){this.a=a}
function Ap(a){this.a=a}
function Bp(a){this.a=a}
function Cp(a){this.a=a}
function Lp(a){this.a=a}
function Mp(a){this.a=a}
function Np(a){this.a=a}
function Pj(a,b){a.a=b}
function Sm(a,b){a.c=b}
function Tm(a,b){a.d=b}
function Um(a,b){a.e=b}
function Vm(a,b){a.f=b}
function Qn(a,b){a.j=b}
function Rn(a,b){a.k=b}
function nk(a,b){a.key=b}
function ik(a,b){hk(a,b)}
function cp(a,b){Do(b,a)}
function yq(a){pj(this,a)}
function Bq(a){di(this,a)}
function Fq(){jc(this.c)}
function Gq(){jc(this.b)}
function Zi(){this.a=gj()}
function lj(){this.a=gj()}
function kc(a){!!a&&a.w()}
function w(a){--a.e;D(a)}
function gb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function kb(a){Yb((J(),a))}
function lh(a){return a.e}
function Hq(){jc(this.a.c)}
function Iq(){jc(this.a.b)}
function Sj(a,b){Ij(a.a,b)}
function cc(a,b){si(a.b,b)}
function bp(a,b){Lo(a.b,b)}
function Ul(a,b){Mo(a.j,b)}
function C(a,b){ab(a.f,b.f)}
function tb(a,b){a.b=sj(b)}
function Lb(a){a.a=-4&a.a|1}
function V(a){jd(a,8)&&a.v()}
function cj(){cj=Ah;bj=ej()}
function J(){J=Ah;I=new F}
function uc(){uc=Ah;tc=new o}
function Lc(){Lc=Ah;Kc=new Oc}
function _o(){_o=Ah;$o=new ap}
function dc(){this.b=new Ti}
function Dq(){this.a.o=true}
function xq(){return this.a}
function Aq(){return this.b}
function wq(){return _j(this)}
function gi(a,b){return a===b}
function Vl(a,b){return a.f=b}
function Hi(a,b){return a.a[b]}
function ac(a,b,c){ri(a.b,b,c)}
function Xj(a,b){a.splice(b,1)}
function jo(a){R(a.a);cb(a.b)}
function yo(a){cb(a.b);cb(a.a)}
function li(a){sc.call(this,a)}
function _m(a){jk.call(this,a)}
function fn(a){jk.call(this,a)}
function mn(a){jk.call(this,a)}
function sn(a){jk.call(this,a)}
function yn(a){jk.call(this,a)}
function vq(a){return this===a}
function zq(){return ui(this.a)}
function Cq(){return J(),J(),I}
function Wc(a,b){return Uh(a,b)}
function gj(){cj();return new bj}
function Ph(a){Oh(a);return a.k}
function Hj(a,b){a.Q(b);return a}
function tj(a,b){while(a.bb(b));}
function Ij(a,b){Pj(a,Hj(a.a,b))}
function v(a,b,c){s(a,new H(c),b)}
function Bc(){Bc=Ah;!!(Sc(),Rc)}
function ei(){oc(this);this.D()}
function Eq(){rk(this.a,false)}
function th(){rh==null&&(rh=[])}
function sl(a){a.o=true;nb(a.a)}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function db(a){J();Xb(a);a.e=-2}
function lo(a){ib(a.b);return a.e}
function Bo(a){ib(a.a);return a.d}
function qp(a){ib(a.d);return a.f}
function vk(a,b){a.ref=b;return a}
function ic(a,b){this.a=a;this.b=b}
function Zh(a,b){this.a=a;this.b=b}
function Di(a,b){this.a=a;this.b=b}
function Lj(a,b){this.a=a;this.b=b}
function mk(a,b){this.a=a;this.b=b}
function Pl(a,b){this.a=a;this.b=b}
function rm(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function tm(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function xm(a,b){this.a=a;this.b=b}
function dl(a,b){Zh.call(this,a,b)}
function Vj(a,b,c){a.splice(b,0,c)}
function ij(a,b){return a.a.get(b)}
function ui(a){return a.a.b+a.b.b}
function W(a){return !!a&&a.c.i<0}
function _c(a){return new Array(a)}
function Ln(a){return Mn(new On,a)}
function wk(a,b){a.href=b;return a}
function Gn(a,b){this.a=a;this.b=b}
function Hn(a,b){this.a=a;this.b=b}
function Jn(a,b){this.a=a;this.b=b}
function Kn(a,b){this.a=a;this.b=b}
function wo(a,b){this.a=a;this.b=b}
function Uo(a,b){this.a=a;this.b=b}
function jp(a,b){this.a=a;this.b=b}
function kp(a,b){this.b=a;this.a=b}
function Hp(a,b){Zh.call(this,a,b)}
function mo(a){ko(a,(ib(a.b),a.e))}
function Om(){this.a=pk((Ym(),Xm))}
function Qm(){this.a=pk((cn(),bn))}
function Bn(){this.a=pk((jn(),hn))}
function On(){this.a=pk((pn(),on))}
function Tn(){this.a=pk((vn(),un))}
function Co(a){Do(a,(ib(a.a),!a.d))}
function Sb(a){return !a.d?a:Sb(a.d)}
function qi(a){return !a?null:a.Z()}
function od(a){return a==null?null:a}
function rj(a){return a!=null?r(a):0}
function ld(a){return typeof a===Qp}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function Ic(a){$wnd.clearTimeout(a)}
function Ei(a){a.a=Yc(ge,Sp,1,0,5,1)}
function ti(a){a.a=new Zi;a.b=new lj}
function dk(){dk=Ah;ak=new o;ck=new o}
function lb(a){this.c=new Ni;this.b=a}
function zk(a,b){a.checked=b;return a}
function Gk(a,b){a.value=b;return a}
function Bk(a,b){a.onBlur=b;return a}
function xk(a,b){a.onClick=b;return a}
function Ck(a,b){a.onChange=b;return a}
function ii(a,b){a.a+=''+b;return a}
function Mj(a,b){a.A(Nn(Ln(b.c.e),b))}
function Wj(a,b){Uj(b,0,a,0,b.length)}
function gc(a,b){ec(a,b,false);hb(a.d)}
function A(a,b,c){t(a,new G(b),c,null)}
function B(a,b,c){return t(a,c,2048,b)}
function bd(a,b,c){return {l:a,m:b,h:c}}
function fi(a,b){return a.charCodeAt(b)}
function _j(a){return a.$H||(a.$H=++$j)}
function X(a){return !(!!a&&1==(a.c&7))}
function jd(a,b){return a!=null&&gd(a,b)}
function hk(a,b){for(var c in a){b(c)}}
function Dk(a,b){a.onKeyDown=b;return a}
function yk(a){a.autoFocus=true;return a}
function hl(a){a.o=true;nb(a.b);R(a.a)}
function Gl(a){a.o=true;nb(a.a);cb(a.b)}
function sb(a){J();rb(a);vb(a,2,true)}
function ib(a){var b;Tb((J(),b=Ob,b),a)}
function Gb(a){this.d=sj(a);this.b=100}
function Gh(a){this.b=sj(a);this.a=this}
function sc(a){this.f=a;oc(this);this.D()}
function Gj(a,b){Bj.call(this,a);this.a=b}
function pj(a,b){while(a.V()){Sj(b,a.W())}}
function pc(a,b){a.e=b;b!=null&&Zj(b,_p,a)}
function Oh(a){if(a.k!=null){return}Wh(a)}
function Ak(a,b){a.defaultValue=b;return a}
function Mn(a,b){return nk(a.a,sj(''+b)),a}
function nd(a){return typeof a==='string'}
function kd(a){return typeof a==='boolean'}
function Jb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&vb(a.f,5,true)}
function P(){this.a=Yc(ge,Sp,1,100,5,1)}
function Ti(){this.a=new Zi;this.b=new lj}
function u(a,b){return new yb(sj(a),null,b)}
function _i(a,b){var c;c=a[eq];c.call(a,b)}
function fc(a,b){cc(b.c.c,a);jd(b,8)&&b.v()}
function $(a,b,c){Lb(sj(c));K(a.a[b],sj(c))}
function Zj(b,c,d){try{b[c]=d}catch(a){}}
function am(a){A((J(),J(),I),new wm(a),nq)}
function no(a){A((J(),J(),I),new to(a),nq)}
function Fo(a){A((J(),J(),I),new Io(a),nq)}
function dp(a){A((J(),J(),I),new lp(a),nq)}
function sp(a){W((ib(a.d),a.f))&&up(a,null)}
function Qo(a){return ai(S(a.e).a-S(a.a).a)}
function Cc(a,b,c){return a.apply(b,c);var d}
function oj(a,b,c){this.a=a;this.b=b;this.c=c}
function Bl(a,b,c){this.a=a;this.b=b;this.c=c}
function Bm(a,b,c){this.a=a;this.b=b;this.c=c}
function Mm(a,b,c){this.a=a;this.b=b;this.c=c}
function Hk(a,b){a.onDoubleClick=b;return a}
function Nn(a,b){a.a.props['a']=b;return a.a}
function Fi(a,b){a.a[a.a.length]=b;return true}
function oc(a){a.g&&a.e!==$p&&a.D();return a}
function Sh(a){var b;b=Rh(a);Yh(a,b);return b}
function ci(){ci=Ah;bi=Yc(ce,Sp,30,256,0,1)}
function Jh(){Jh=Ah;Ih=$wnd.window.document}
function Sc(){Sc=Ah;var a;!Uc();a=new Vc;Rc=a}
function Fb(a){while(true){if(!Eb(a)){break}}}
function hm(a,b){return Mh(),bm(a,b)?true:false}
function gm(a,b){A((J(),J(),I),new vm(a,b),nq)}
function jm(a,b){A((J(),J(),I),new tm(a,b),nq)}
function km(a,b){A((J(),J(),I),new sm(a,b),nq)}
function lm(a,b){A((J(),J(),I),new rm(a,b),nq)}
function Hl(a,b){A((J(),J(),I),new Pl(a,b),nq)}
function Mo(a,b){A((J(),J(),I),new Uo(a,b),nq)}
function gp(a,b){A((J(),J(),I),new jp(a,b),nq)}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function qb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function Il(a,b){var c;c=b.target;Jl(a,c.value)}
function Vo(a,b){this.a=a;this.c=b;this.b=false}
function $n(a){this.b=a;this.a=new zl(this.b.a)}
function _n(a){this.b=a;this.a=new Sl(this.b.b)}
function F(){this.f=new bb;this.a=new Gb(this.f)}
function Oo(a){di(new Bi(a.g),new hc(a));ti(a.g)}
function Ej(a){Aj(a);return new Gj(a,new Nj(a.a))}
function Hh(a){sj(a);return jd(a,47)?a:new Gh(a)}
function hj(a,b){return !(a.a.get(b)===undefined)}
function Po(a){return Mh(),0==S(a.e).a?true:false}
function il(a){return Mh(),S(a.d.b).a>0?true:false}
function np(a){return gi(uq,a)||gi(pq,a)||gi('',a)}
function $c(a){return Array.isArray(a)&&a.qb===Eh}
function hd(a){return !Array.isArray(a)&&a.qb===Eh}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ji(a,b){var c;c=a.a[b];Xj(a.a,b);return c}
function Li(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function yi(a){var b;b=a.a.W();a.b=xi(a);return b}
function yl(a){var b;b=new tl;Sm(b,a.a.G());return b}
function sj(a){if(a==null){throw lh(new ei)}return a}
function vi(a,b){if(b){return oi(a.a,b)}return false}
function Rl(a){var b;b=new Kl;Tm(b,a.a.G());return b}
function Jl(a,b){var c;c=a.e;if(b!=c){a.e=b;hb(a.b)}}
function mm(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function Do(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function Cm(a,b){var c;c=b.target;gp(a.d,c.checked)}
function pp(a){nb(a.e);nb(a.a);R(a.b);R(a.c);cb(a.d)}
function vj(a){if(!a.d){a.d=a.b.P();a.c=a.b.R()}}
function Hb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function zj(a){if(!a.b){Aj(a);a.c=true}else{zj(a.b)}}
function Jj(a,b,c){if(a.a.cb(c)){a.b=true;b.A(c)}}
function Dj(a,b){Aj(a);return new Gj(a,new Kj(b,a.a))}
function ko(a,b){A((J(),J(),I),new wo(a,b),75497472)}
function Si(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function uj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Fk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ql(a){var b;a.n=false;sk(a);b=pl(a);return b}
function Th(a,b){var c;c=Rh(a);Yh(a,c);c.e=b?8:0;return c}
function oo(a,b){var c;c=a.e;if(b!=c){a.e=sj(b);hb(a.b)}}
function io(a){var b;T(a.a);b=S(a.a);gi(a.f,b)&&oo(a,b)}
function em(a){a.o=true;nb(a.b);R(a.d);cb(a.c);cb(a.a)}
function jb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function Yl(a,b){up(a.k,b);A((J(),J(),I),new rm(a,b),nq)}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Nj(a){uj.call(this,a.ab(),a._()&-6);this.a=a}
function Bj(a){if(!a){this.b=null;new Ni}else{this.b=a}}
function Vh(a){if(a.N()){return null}var b=a.j;return wh[b]}
function qh(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function gk(){if(bk==256){ak=ck;ck=new o;bk=0}++bk}
function Lo(a,b){return t((J(),J(),I),new Vo(a,b),nq,null)}
function ob(a){C((J(),J(),I),a);0==(a.f.a&Xp)&&D((null,I))}
function eo(a){Kh((Jh(),$wnd.window.window),sq,a.d,false)}
function fo(a){Lh((Jh(),$wnd.window.window),sq,a.d,false)}
function Xl(a,b){A((J(),J(),I),new rm(a,b),nq);up(a.k,null)}
function lc(a){kc(a.g);V(a.c);V(a.a);V(a.d);kc(a.b);kc(a.f)}
function Pb(a){if(a.e){2==(a.e.c&7)||vb(a.e,4,true);rb(a.e)}}
function pk(a){var b;b=ok(a);b.props={};b.ref=null;return b}
function qc(a,b){var c;c=Ph(a.ob);return b==null?c:c+': '+b}
function Tl(a,b){var c;if(S(a.d)){c=b.target;mm(a,c.value)}}
function di(a,b){var c,d;for(d=a.P();d.V();){c=d.W();b.A(c)}}
function pi(a,b){return b===a?'(this Map)':b==null?bq:Dh(b)}
function wj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function Ch(a){function b(){}
;b.prototype=a||{};return new b}
function cn(){cn=Ah;var a;bn=(a=Bh(an.prototype.gb,an,[]),a)}
function jn(){jn=Ah;var a;hn=(a=Bh(gn.prototype.gb,gn,[]),a)}
function pn(){pn=Ah;var a;on=(a=Bh(nn.prototype.gb,nn,[]),a)}
function vn(){vn=Ah;var a;un=(a=Bh(tn.prototype.gb,tn,[]),a)}
function Ym(){Ym=Ah;var a;Xm=(a=Bh(Wm.prototype.gb,Wm,[]),a)}
function Ip(){Gp();return ad(Wc($g,1),Sp,34,0,[Dp,Fp,Ep])}
function Oi(a){Ei(this);Wj(this.a,ni(a,Yc(ge,Sp,1,ui(a.a),5,1)))}
function Wi(a,b){var c;return Ui(b,Vi(a,b==null?0:(c=r(b),c|0)))}
function Vi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Uh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.I(b))}
function ep(a,b){var c;Fj(No(a.b),(c=new Ni,c)).O(new Mp(b))}
function go(a,b){b.preventDefault();A((J(),J(),I),new uo(a),nq)}
function fm(a,b){return t((J(),J(),I),new xm(a,b),75497472,null)}
function No(a){ib(a.d);return new Gj(null,new wj(new Bi(a.g),0))}
function Aj(a){if(a.b){Aj(a.b)}else if(a.c){throw lh(new $h)}}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function Kh(a,b,c,d){a.addEventListener(b,c,(Mh(),d?true:false))}
function Lh(a,b,c,d){a.removeEventListener(b,c,(Mh(),d?true:false))}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function yh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ek(a){a.placeholder='What needs to be done?';return a}
function $i(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Zn(a){this.b=a;this.a=new Bl(this.b.a,this.b.b,this.b.c)}
function ao(a){this.b=a;this.a=new Bm(this.b.a,this.b.b,this.b.c)}
function bo(a){this.b=a;this.a=new Mm(this.b.a,this.b.b,this.b.c)}
function mj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Kj(a,b){uj.call(this,b.ab(),b._()&-16449);this.a=a;this.c=b}
function xj(a,b){!a.a?(a.a=new ki(a.d)):ii(a.a,a.b);ii(a.a,b);return a}
function Fj(a,b){var c;zj(a);c=new Qj;c.a=b;a.a.U(new Tj(c));return c.a}
function Cj(a){var b;zj(a);b=0;while(a.a.bb(new Rj)){b=mh(b,1)}return b}
function fp(a){var b;Fj(Dj(No(a.b),new Kp),(b=new Ni,b)).O(new Lp(a.b))}
function up(a,b){var c;c=a.f;if(!(b==c||!!b&&zo(b,c))){a.f=b;hb(a.d)}}
function eb(a,b){var c,d;Fi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function si(a,b){return nd(b)?b==null?Yi(a.a,null):kj(a.b,b):Yi(a.a,b)}
function im(a){return Mh(),qp(a.k)==(jb(a.c),a.p.props['a'])?true:false}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function Mb(b){try{b.b.w()}catch(a){a=kh(a);if(!jd(a,6))throw lh(a)}}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Am(a){var b;b=new nm;Qn(b,a.a.G());a.b.G();Rn(b,a.c.G());return b}
function Cl(a){var b;b=hi((ib(a.b),a.e));if(b.length>0){bp(a.d,b);Jl(a,'')}}
function Gi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.A(c)}}
function yj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function zi(a){this.d=a;this.c=new mj(this.d.b);this.a=this.c;this.b=xi(this)}
function hp(a){this.b=sj(a);J();this.a=new mc(0,null,new ip,false,false)}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function zo(a,b){var c;if(jd(b,53)){c=b;return a.c.e==c.c.e}else{return false}}
function nj(a){if(a.a.c!=a.c){return ij(a.a,a.b.value[0])}return a.b.value[1]}
function Ii(a,b,c){for(;c<a.a.length;++c){if(Si(b,a.a[c])){return c}}return -1}
function lk(a,b,c){!gi(c,'key')&&!gi(c,'ref')&&(a[c]=b[c],undefined)}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function Ki(a,b){var c;c=Ii(a,b,0);if(c==-1){return false}Xj(a.a,c);return true}
function ri(a,b,c){return nd(b)?b==null?Xi(a.a,null,c):jj(a.b,b,c):Xi(a.a,b,c)}
function op(a,b){return (Gp(),Ep)==a||(Dp==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function Yj(a,b){return Xc(b)!=10&&ad(q(b),b.pb,b.__elementTypeId$,Xc(b),a),a}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function rk(a,b){if(!a.n){a.n=true;a.o||(b?a.p.setState({}):a.p.forceUpdate())}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||nb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Fb(a.a)}finally{a.c=false}}}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new mb(a)),0,null);!!a.b&&nb(a.b)}}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new nc(a)),67108864,null)}}
function rp(a){var b,c;return b=S(a.b),Fj(Dj(No(a.j),new Np(b)),(c=new Ni,c))}
function co(a,b){a.f=b;gi(b,S(a.a))&&oo(a,b);ho(b);A((J(),J(),I),new uo(a),nq)}
function Dl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Ol(a),nq)}}
function ub(b){if(b){try{b.w()}catch(a){a=kh(a);if(jd(a,6)){J()}else throw lh(a)}}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function Yh(a,b){var c;if(!a){return}b.j=a;var d=Vh(b);if(!d){wh[a]=[b];return}d.ob=b}
function Al(a){var b;b=new jl;Tm(b,a.a.G());Um(b,a.b.G());Vm(b,a.c.G());return b}
function Lm(a){var b;b=new Gm;Sm(b,a.a.G());Tm(b,a.b.G());Um(b,a.c.G());return b}
function Rh(a){var b;b=new Qh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Bh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function kh(a){var b;if(jd(a,6)){return a}b=a&&a[_p];if(!b){b=new wc(a);Tc(b)}return b}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Fi((!a.b&&(a.b=new Ni),a.b),b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new Ni);a.c=c.c}b.d=true;Fi(a.c,sj(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,sj(b))}
function kj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{_i(a.a,b);--a.b}return c}
function Ko(a){di(new Bi(a.g),new hc(a));ti(a.g);R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function rb(a){var b,c;for(c=new Pi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Qi(a){var b,c,d;d=0;for(c=new zi(a.a);c.b;){b=yi(c);d=d+(b?r(b):0);d=d|0}return d}
function mi(a,b){var c,d;for(d=new zi(b.a);d.b;){c=yi(d);if(!vi(a,c)){return false}}return true}
function sh(){th();var a=rh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function bb(){var a;this.a=Yc(td,Sp,46,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Yn(){this.a=Hh((_o(),_o(),$o));this.b=Hh(new mp(this.a));this.c=Hh(new Bp(this.a))}
function jk(a){$wnd.React.Component.call(this,a);this.a=this.hb();this.a.p=sj(this);this.a.eb()}
function $h(){sc.call(this,"Stream already terminated, can't be modified or used")}
function yb(a,b,c){xb.call(this,null,a,b,c|(!a?262144:Up)|(0==(c&6291456)?!a?Xp:Yp:0)|0|0|0)}
function Nb(a,b){this.b=sj(a);this.a=b|0|(0==(b&6291456)?Yp:0)|(0!=(b&229376)?0:98304)}
function vh(a,b){typeof window===Pp&&typeof window['$gwt']===Pp&&(window['$gwt'][a]=b)}
function md(a){return a!=null&&(typeof a===Pp||typeof a==='function')&&!(a.qb===Eh)}
function Gp(){Gp=Ah;Dp=new Hp('ACTIVE',0);Fp=new Hp('COMPLETED',1);Ep=new Hp('ALL',2)}
function Jo(a,b,c){var d;d=new Go(b,c);ac(d.c.c,a,new ic(a,d));ri(a.g,ai(d.c.e),d);hb(a.d);return d}
function jj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ec(a,b,c){var d;d=si(a.g,b?ai(b.c.e):null);if(null!=d){cc(b.c.c,a);c&&!!b&&jc(b.c);hb(a.d)}}
function bm(a,b){var c,d;d=a.p.props;c=false;if(!(d['a']===b['a'])){hb(a.c);c=true}return c||a.n}
function Ui(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Si(a,c.Y())){return c}}return null}
function ph(a){var b,c,d,e;e=a;d=0;if(e<0){e+=cq;d=1048575}c=pd(e/Yp);b=pd(e-c*Yp);return bd(b,c,d)}
function nh(a){var b;b=a.h;if(b==0){return a.l+a.m*Yp}if(b==1048575){return a.l+a.m*Yp-cq}return a}
function xi(a){if(a.a.V()){return true}if(a.a!=a.c){return false}a.a=new $i(a.d.a);return a.a.V()}
function S(a){ib(a.e);wb(a.f)&&pb(a.f);if(a.b){if(jd(a.b,9)){throw lh(a.b)}else{throw lh(a.b)}}return a.k}
function tp(a){var b;b=S(a.i.a);gi(uq,b)||gi(pq,b)||gi('',b)?ko(a.i,b):np(lo(a.i))?no(a.i):ko(a.i,'')}
function Wl(a,b,c){27==c.which?A((J(),J(),I),new um(a,b),nq):13==c.which&&A((J(),J(),I),new sm(a,b),nq)}
function nb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Cb(a)),67108864,null);!!a.a&&R(a.a);Jb(a.f);a.c=a.c&-8|1}}
function sk(a){if(!qk){qk=(++a.ib().e,new Ib);$wnd.Promise.resolve(null).then(Bh(tk.prototype.H,tk,[]))}}
function ad(a,b,c,d,e){e.ob=a;e.pb=b;e.qb=Eh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function cm(a){var b,c;a.n=false;sk(a);b=(jb(a.c),a.p.props['a']);if(!!b&&b.c.i<0){return null}c=_l(a);return c}
function ai(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ci(),bi)[b];!c&&(c=bi[b]=new _h(a));return c}return new _h(a)}
function Dh(a){var b;if(Array.isArray(a)&&a.qb===Eh){return Ph(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function fk(a){dk();var b,c,d;c=':'+a;d=ck[c];if(d!=null){return pd(d)}d=ak[c];b=d==null?ek(a):pd(d);gk();ck[c]=b;return b}
function wc(a){uc();oc(this);this.e=a;a!=null&&Zj(a,_p,this);this.f=a==null?bq:Dh(a);this.a='';this.b=a;this.a=''}
function Qh(){this.g=Nh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function fb(a,b){var c,d;d=a.c;Ki(d,b);!!a.b&&Up!=(a.b.c&Vp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function bc(a){var b,c;if(!a.a){for(c=new Pi(new Oi(new Bi(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.w()}a.a=true}}
function Ri(a){var b,c,d;d=1;for(c=new Pi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Xh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function q(a){return nd(a)?je:ld(a)?$d:kd(a)?Yd:hd(a)?a.ob:$c(a)?a.ob:a.ob||Array.isArray(a)&&Wc(Qd,1)||Qd}
function r(a){return nd(a)?fk(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.s():$c(a)?_j(a):!!a&&!!a.hashCode?a.hashCode():_j(a)}
function p(a,b){return nd(a)?gi(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.q(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function Kb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Up)?Mb(a):a.b.w();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function zb(a,b){xb.call(this,a,new Ab(a),null,b|(Up==(b&Vp)?0:524288)|(0==(b&6291456)?Up==(b&Vp)?Yp:Xp:0)|0|268435456|0)}
function el(){cl();return ad(Wc(Ye,1),Sp,7,0,[Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl])}
function mh(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<cq){return c}}return nh(cd(ld(a)?ph(a):a,ld(b)?ph(b):b))}
function Zl(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){A((J(),J(),I),new kp(b,c),nq);up(a.k,null);mm(a,c)}else{Mo(a.j,b)}}
function $l(a){var b;b=S(a.d);if(!a.i&&b){a.i=true;lm(a,(jb(a.c),a.p.props['a']));a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Mi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Yj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function uk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function tl(){var a;J();a=++rl;this.b=new mc(a,new vl(this),new ul(this),false,false);this.a=new yb(null,sj(new wl(this)),lq);D((null,I))}
function Gm(){var a;J();a=++Em;this.b=new mc(a,new Im(this),new Hm(this),false,false);this.a=new yb(null,sj(new Jm(this)),lq);D((null,I))}
function mc(a,b,c,d,e){var f;this.e=a;this.c=d?new dc:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new lb((J(),null)),f):null;this.d=null}
function U(a,b,c,d){this.c=sj(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new zb(this,d);this.e=new lb(this.f);Up==(d&Vp)&&ob(this.f)}
function Go(a,b){var c,d,e;this.e=sj(a);this.d=b;J();c=++xo;this.c=new mc(c,null,new Ho(this),true,true);this.b=(e=new lb(null),e);this.a=(d=new lb(null),d)}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.pb){return !!a.pb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&vb(b,5,true)}}}
function Xb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Pi(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&vb(b,6,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?vb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function hi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ub(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=Ji(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&vb(c.b,3,true);++b}}}return b}
function s(b,c,d){var e,f;try{$b(b,d);try{f=(c.a.w(),null)}finally{_b()}return f}catch(a){a=kh(a);if(jd(a,6)){e=a;throw lh(e)}else throw lh(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.u()}else{$b(b,e);try{g=c.u()}finally{_b()}}return g}catch(a){a=kh(a);if(jd(a,6)){f=a;throw lh(f)}else throw lh(a)}finally{D(b)}}
function Eb(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Kb(c);return true}
function Kl(){var a,b;J();a=++Fl;this.c=new mc(a,new Ml(this),new Ll(this),false,false);this.b=(b=new lb(null),b);this.a=new yb(null,sj(new Ql(this)),lq);D((null,I))}
function jl(){var a;J();a=++gl;this.c=new mc(a,new ll(this),new kl(this),false,false);this.a=new U(new nl(this),null,null,136478720);this.b=new yb(null,sj(new ol(this)),lq);D((null,I))}
function uh(b,c,d,e){th();var f=rh;$moduleName=c;$moduleBase=d;jh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Op(g)()}catch(a){b(c,a)}}else{Op(g)()}}
function pl(a){var b,c;c=S(a.c.e).a;b='item'+(c==1?'':'s');return kk('span',uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,['todo-count'])),[kk('strong',null,[c]),' '+b+' left'])}
function Fh(){var a;a=new Yn;$m(new Pm(a));en(new Rm(a));rn(new Pn(a));xn(new Un(a));ln(new Cn(a));$wnd.ReactDOM.render((new Tn).a,(Jh(),Ih).getElementById('todoapp'),null)}
function ej(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return fj()}}
function ok(a){var b;b=new $wnd.Object;b.$$typeof=$wnd.React.Element;b.type=sj(a);b._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return b}
function ni(a,b){var c,d,e,f,g;g=ui(a.a);b.length<g&&(b=Yj(new Array(g),b));e=(f=new zi((new wi(a.a)).a),new Ci(f));for(d=0;d<g;++d){b[d]=(c=yi(e.a),c.Z())}b.length>g&&(b[g]=null);return b}
function xh(){wh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].rb()&&(c=Pc(c,g)):g[0].rb()}catch(a){a=kh(a);if(jd(a,6)){d=a;Bc();Hc(jd(d,36)?d.F():d)}else throw lh(a)}}return c}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?bq:md(b)?b==null?null:b.name:nd(b)?'String':Ph(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function El(a){var b;a.n=false;sk(a);b=kk(oq,yk(Ck(Dk(Gk(Ek(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,['new-todo']))),(ib(a.b),a.e)),Bh(zn.prototype.lb,zn,[a])),Bh(An.prototype.kb,An,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.u();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=kh(a);if(jd(a,12)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw lh(c)}else throw lh(a)}}
function Xi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ui(b,e);if(f){return f.$(c)}}e[e.length]=new Di(b,c);++a.b;return null}
function Uj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function ek(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+fi(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Yc(ge,Sp,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function pb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.w()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=kh(a);if(jd(a,6)){J()}else throw lh(a)}}}
function ho(a){var b;if(0==a.length){b=(Jh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Ih.title,b)}else{(Jh(),$wnd.window.window).location.hash=a}}
function xb(a,b,c,d){this.b=new Ni;this.f=new Nb(new Bb(this),d&6520832|262144|Up);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Xp)&&D((null,I)))}
function Yi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Si(b,e.Y())){if(d.length==1){d.length=0;_i(a.a,g)}else{d.splice(h,1)}--a.b;return e.Z()}}return null}
function zh(a,b,c){var d=wh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=wh[b]),Ch(h));_.pb=c;!b&&(_.qb=Eh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ob=f)}
function Wh(a){if(a.M()){var b=a.c;b.N()?(a.k='['+b.j):!b.M()?(a.k='[L'+b.K()+';'):(a.k='['+b.K());a.b=b.J()+'[]';a.i=b.L()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Xh('.',[c,Xh('$',d)]);a.b=Xh('.',[c,Xh('.',d)]);a.i=d[d.length-1]}
function nm(){var a,b,c;J();a=++dm;this.e=new mc(a,new pm(this),new om(this),false,false);this.c=(c=new lb(null),c);this.a=(b=new lb(null),b);this.d=new U(new ym(this),null,null,136478720);this.b=new yb(null,sj(new zm(this)),lq);D((null,I))}
function oi(a,b){var c,d,e;c=b.Y();e=b.Z();d=nd(c)?c==null?qi(Wi(a.a,null)):ij(a.b,c):qi(Wi(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!Wi(a.a,null):hj(a.b,c):!!Wi(a.a,c))){return false}return true}
function po(){var a,b;this.d=new Cp(this);this.f=this.e=(b=(Jh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new mc(0,null,new qo(this),false,false);this.b=(a=new lb(null),a);this.a=new U(new vo,new ro(this),new so(this),35749888)}
function Ro(){var a;this.g=new Ti;J();this.f=new mc(0,new To(this),new So(this),false,false);this.d=(a=new lb(null),a);this.c=new U(new Wo(this),null,null,tq);this.e=new U(new Xo(this),null,null,tq);this.a=new U(new Yo(this),null,null,tq);this.b=new U(new Zo(this),null,null,tq)}
function vp(a){var b;this.j=sj(a);this.i=new po;J();this.g=new mc(0,null,new wp(this),false,false);this.d=(b=new lb(null),b);this.b=new U(new xp(this),null,null,tq);this.c=new U(new yp(this),null,null,tq);this.e=u(new zp(this),413138944);this.a=u(new Ap(this),681574400);D((null,I))}
function wb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Pi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=kh(a);if(!jd(a,6))throw lh(a)}if(6==(b.c&7)){return true}}}}}rb(b);return false}
function kk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?''+b['key']:null;f='ref' in b?b['ref']:null;ik(b,Bh(mk.prototype.db,mk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=ok(a),g.key=e,g.ref=f,g.props=sj(d),g}
function dj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function vb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){kb(a.a.e);ub((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;ub((e=d.i,e));d.k=null}Gi(a.b,new Db(a));a.b.a=Yc(ge,Sp,1,0,5,1)}else 3==g&&!!a.a&&ub((f=a.a.g,f))}}
function cl(){cl=Ah;Ik=new dl(fq,0);Jk=new dl('checkbox',1);Kk=new dl('color',2);Lk=new dl('date',3);Mk=new dl('datetime',4);Nk=new dl('email',5);Ok=new dl('file',6);Pk=new dl('hidden',7);Qk=new dl('image',8);Rk=new dl('month',9);Sk=new dl(Qp,10);Tk=new dl('password',11);Uk=new dl('radio',12);Vk=new dl('range',13);Wk=new dl('reset',14);Xk=new dl('search',15);Yk=new dl('submit',16);Zk=new dl('tel',17);$k=new dl('text',18);_k=new dl('time',19);al=new dl('url',20);bl=new dl('week',21)}
function Dm(a){var b,c,d;a.n=false;sk(a);d=kk('div',null,[kk('div',null,[kk(qq,uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[qq])),[kk('h1',null,['todos']),(new Bn).a]),S(a.c.c)?null:kk('section',uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[qq])),[kk(oq,Ck(Fk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[rq])),(cl(),Jk)),Bh(Sn.prototype.kb,Sn,[a])),null),kk('ul',uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,['todo-list'])),(b=Fj(Ej(S(a.e.c).T()),(c=new Ni,c)),Mi(b,_c(b.a.length))))]),S(a.c.c)?null:(new Om).a])]);return d}
function fl(a){var b,c;a.n=false;sk(a);c=(b=S(a.f.b),kk(gq,uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[gq])),[(new Qm).a,kk('ul',uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,['filters'])),[kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[(Gp(),Ep)==b?hq:null])),'#'),['All'])]),kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[Dp==b?hq:null])),'#active'),['Active'])]),kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[Fp==b?hq:null])),iq),['Completed'])])]),S(a.a)?kk(fq,xk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[jq])),Bh(Nm.prototype.mb,Nm,[a])),[kq]):null]));return c}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Hi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Li(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&vb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Hi(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ji(a.b,g)}e&&tb(a.e,a.b)}else{e&&tb(a.e,new Ni)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Up!=(k.b.c&Vp)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function _l(a){var b,c;c=(jb(a.c),a.p.props['a']);b=(ib(c.a),c.d);return kk('li',uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[b?pq:null,S(a.d)?'editing':null])),[kk('div',uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,['view'])),[kk(oq,Ck(zk(Fk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,['toggle'])),(cl(),Jk)),b),Bh(Fn.prototype.kb,Fn,[c])),null),kk('label',Hk(new $wnd.Object,Bh(Gn.prototype.mb,Gn,[a,c])),[(ib(c.b),c.e)]),kk(fq,xk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,['destroy'])),Bh(Hn.prototype.mb,Hn,[a,c])),null)]),kk(oq,Dk(Ck(Bk(Ak(uk(vk(new $wnd.Object,Bh(In.prototype.A,In,[a])),ad(Wc(je,1),Sp,2,6,['edit'])),(ib(a.a),a.g)),Bh(Jn.prototype.jb,Jn,[a,c])),Bh(En.prototype.kb,En,[a])),Bh(Kn.prototype.lb,Kn,[a,c])),null)])}
function fj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[eq]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!dj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[eq]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Pp='object',Qp='number',Rp={11:1},Sp={3:1,4:1},Tp={8:1},Up=1048576,Vp=1835008,Wp={5:1},Xp=2097152,Yp=4194304,Zp={23:1},$p='__noinit__',_p='__java$exception',aq={3:1,12:1,9:1,6:1},bq='null',cq=17592186044416,dq={44:1},eq='delete',fq='button',gq='footer',hq='selected',iq='#completed',jq='clear-completed',kq='Clear Completed',lq=1478627328,mq={14:1},nq=142606336,oq='input',pq='completed',qq='header',rq='toggle-all',sq='hashchange',tq=136413184,uq='active';var _,wh,rh,jh=-1;xh();zh(1,null,{},o);_.q=vq;_.r=function(){return this.ob};_.s=wq;_.t=function(){var a;return Ph(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.q(a)};_.hashCode=function(){return this.s()};_.toString=function(){return this.t()};var dd,ed,fd;zh(55,1,{},Qh);_.I=function(a){var b;b=new Qh;b.e=4;a>1?(b.c=Uh(this,a-1)):(b.c=this);return b};_.J=function(){Oh(this);return this.b};_.K=function(){return Ph(this)};_.L=function(){Oh(this);return this.i};_.M=function(){return (this.e&4)!=0};_.N=function(){return (this.e&1)!=0};_.t=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Oh(this),this.k)};_.e=0;_.g=0;var Nh=1;var ge=Sh(1);var Zd=Sh(55);zh(99,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var sd=Sh(99);zh(37,1,Rp,G);_.u=function(){return this.a.w(),null};var qd=Sh(37);zh(100,1,{},H);var rd=Sh(100);var I;zh(46,1,{46:1},P);_.b=0;_.c=false;_.d=0;var td=Sh(46);zh(237,1,Tp);_.t=function(){var a;return Ph(this.ob)+'@'+(a=r(this)>>>0,a.toString(16))};var wd=Sh(237);zh(20,237,Tp,U);_.v=function(){R(this)};_.a=false;_.d=0;var ud=Sh(20);zh(112,1,{281:1},bb);var vd=Sh(112);zh(15,237,{8:1,15:1},lb);_.v=function(){cb(this)};_.a=4;_.d=false;_.e=0;var yd=Sh(15);zh(166,1,Wp,mb);_.w=function(){db(this.a)};var xd=Sh(166);zh(19,237,{8:1,19:1},yb,zb);_.v=function(){nb(this)};_.c=0;var Dd=Sh(19);zh(167,1,Zp,Ab);_.w=function(){Q(this.a)};var zd=Sh(167);zh(168,1,Wp,Bb);_.w=function(){pb(this.a)};var Ad=Sh(168);zh(169,1,Wp,Cb);_.w=function(){sb(this.a)};var Bd=Sh(169);zh(170,1,{},Db);_.A=function(a){qb(this.a,a)};var Cd=Sh(170);zh(113,1,{},Gb);_.a=0;_.b=0;_.c=0;var Ed=Sh(113);zh(209,1,Tp,Ib);_.v=function(){Hb(this)};_.a=false;var Fd=Sh(209);zh(78,237,{8:1,78:1},Nb);_.v=function(){Jb(this)};_.a=0;var Gd=Sh(78);zh(200,1,{},Zb);_.t=function(){var a;return Oh(Hd),Hd.k+'@'+(a=_j(this)>>>0,a.toString(16))};_.a=0;var Ob;var Hd=Sh(200);zh(171,1,Tp,dc);_.v=function(){bc(this)};_.a=false;var Id=Sh(171);zh(128,1,{});var Ld=Sh(128);zh(70,1,{},hc);_.A=function(a){fc(this.a,a)};var Jd=Sh(70);zh(139,1,Wp,ic);_.w=function(){gc(this.a,this.b)};var Kd=Sh(139);zh(129,128,{});var Md=Sh(129);zh(18,1,Tp,mc);_.v=function(){jc(this)};_.t=function(){var a;return Oh(Od),Od.k+'@'+(a=_j(this)>>>0,a.toString(16))};_.e=0;_.i=0;var Od=Sh(18);zh(165,1,Wp,nc);_.w=function(){lc(this.a)};var Nd=Sh(165);zh(6,1,{3:1,6:1});_.B=function(a){return new Error(a)};_.C=function(){return this.f};_.D=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Ph(this.ob),c==null?a:a+': '+c);pc(this,rc(this.B(b)));Tc(this)};_.t=function(){return qc(this,this.C())};_.e=$p;_.g=true;var ke=Sh(6);zh(12,6,{3:1,12:1,6:1});var ae=Sh(12);zh(9,12,aq);var he=Sh(9);zh(56,9,aq);var de=Sh(56);zh(89,56,aq);var Sd=Sh(89);zh(36,89,{36:1,3:1,12:1,9:1,6:1},wc);_.C=function(){vc(this);return this.c};_.F=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Pd=Sh(36);var Qd=Sh(0);zh(216,1,{});var Rd=Sh(216);var yc=0,zc=0,Ac=-1;zh(103,216,{},Oc);var Kc;var Td=Sh(103);var Rc;zh(227,1,{});var Vd=Sh(227);zh(90,227,{},Vc);var Ud=Sh(90);zh(47,1,{47:1,14:1},Gh);_.G=function(){if(this===this.a){this.a=this.b.G();this.b=null}return this.a};var Wd=Sh(47);var Ih;zh(87,1,{84:1});_.t=xq;var Xd=Sh(87);dd={3:1,85:1,29:1};var Yd=Sh(85);zh(45,1,{3:1,45:1});var fe=Sh(45);ed={3:1,29:1,45:1};var $d=Sh(226);zh(33,1,{3:1,29:1,33:1});_.q=vq;_.s=wq;_.t=function(){return this.a!=null?this.a:''+this.b};_.b=0;var _d=Sh(33);zh(91,9,aq,$h);var be=Sh(91);zh(30,45,{3:1,29:1,30:1,45:1},_h);_.q=function(a){return jd(a,30)&&a.a==this.a};_.s=xq;_.t=function(){return ''+this.a};_.a=0;var ce=Sh(30);var bi;zh(296,1,{});zh(97,56,aq,ei);_.B=function(a){return new TypeError(a)};var ee=Sh(97);fd={3:1,84:1,29:1,2:1};var je=Sh(2);zh(88,87,{84:1},ki);var ie=Sh(88);zh(300,1,{});zh(58,9,aq,li);var le=Sh(58);zh(228,1,{41:1});_.O=Bq;_.S=function(){return new wj(this,0)};_.T=function(){return new Gj(null,this.S())};_.Q=function(a){throw lh(new li('Add not supported on this collection'))};_.t=function(){var a,b,c;c=new yj('[',']');for(b=this.P();b.V();){a=b.W();xj(c,a===this?'(this Collection)':a==null?bq:Dh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var me=Sh(228);zh(231,1,{215:1});_.q=function(a){var b,c,d;if(a===this){return true}if(!jd(a,39)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new zi((new wi(d)).a);c.b;){b=yi(c);if(!oi(this,b)){return false}}return true};_.s=function(){return Qi(new wi(this))};_.t=function(){var a,b,c;c=new yj('{','}');for(b=new zi((new wi(this)).a);b.b;){a=yi(b);xj(c,pi(this,a.Y())+'='+pi(this,a.Z()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var xe=Sh(231);zh(111,231,{215:1});var pe=Sh(111);zh(230,228,{41:1,251:1});_.S=function(){return new wj(this,1)};_.q=function(a){var b;if(a===this){return true}if(!jd(a,25)){return false}b=a;if(ui(b.a)!=this.R()){return false}return mi(this,b)};_.s=function(){return Qi(this)};var ye=Sh(230);zh(25,230,{25:1,41:1,251:1},wi);_.P=function(){return new zi(this.a)};_.R=zq;var oe=Sh(25);zh(26,1,{},zi);_.U=yq;_.W=function(){return yi(this)};_.V=Aq;_.b=false;var ne=Sh(26);zh(229,228,{41:1,245:1});_.S=function(){return new wj(this,16)};_.X=function(a,b){throw lh(new li('Add not supported on this list'))};_.Q=function(a){this.X(this.R(),a);return true};_.q=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,10)){return false}f=a;if(this.R()!=f.a.length){return false}e=new Pi(f);for(c=new Pi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.s=function(){return Ri(this)};_.P=function(){return new Ai(this)};var re=Sh(229);zh(102,1,{},Ai);_.U=yq;_.V=function(){return this.a<this.b.a.length};_.W=function(){return Hi(this.b,this.a++)};_.a=0;var qe=Sh(102);zh(38,228,{41:1},Bi);_.P=function(){var a;return a=new zi((new wi(this.a)).a),new Ci(a)};_.R=zq;var te=Sh(38);zh(64,1,{},Ci);_.U=yq;_.V=function(){return this.a.b};_.W=function(){var a;return a=yi(this.a),a.Z()};var se=Sh(64);zh(109,1,dq);_.q=function(a){var b;if(!jd(a,44)){return false}b=a;return Si(this.a,b.Y())&&Si(this.b,b.Z())};_.Y=xq;_.Z=Aq;_.s=function(){return rj(this.a)^rj(this.b)};_.$=function(a){var b;b=this.b;this.b=a;return b};_.t=function(){return this.a+'='+this.b};var ue=Sh(109);zh(110,109,dq,Di);var ve=Sh(110);zh(232,1,dq);_.q=function(a){var b;if(!jd(a,44)){return false}b=a;return Si(this.b.value[0],b.Y())&&Si(nj(this),b.Z())};_.s=function(){return rj(this.b.value[0])^rj(nj(this))};_.t=function(){return this.b.value[0]+'='+nj(this)};var we=Sh(232);zh(10,229,{3:1,10:1,41:1,245:1},Ni,Oi);_.X=function(a,b){Vj(this.a,a,b)};_.Q=function(a){return Fi(this,a)};_.O=function(a){Gi(this,a)};_.P=function(){return new Pi(this)};_.R=function(){return this.a.length};var Ae=Sh(10);zh(17,1,{},Pi);_.U=yq;_.V=function(){return this.a<this.c.a.length};_.W=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ze=Sh(17);zh(39,111,{3:1,39:1,215:1},Ti);var Be=Sh(39);zh(68,1,{},Zi);_.O=Bq;_.P=function(){return new $i(this)};_.b=0;var De=Sh(68);zh(69,1,{},$i);_.U=yq;_.W=function(){return this.d=this.a[this.c++],this.d};_.V=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ce=Sh(69);var bj;zh(66,1,{},lj);_.O=Bq;_.P=function(){return new mj(this)};_.b=0;_.c=0;var Ge=Sh(66);zh(67,1,{},mj);_.U=yq;_.W=function(){return this.c=this.a,this.a=this.b.next(),new oj(this.d,this.c,this.d.c)};_.V=function(){return !this.a.done};var Ee=Sh(67);zh(127,232,dq,oj);_.Y=function(){return this.b.value[0]};_.Z=function(){return nj(this)};_.$=function(a){return jj(this.a,this.b.value[0],a)};_.c=0;var Fe=Sh(127);zh(118,1,{});_.U=function(a){tj(this,a)};_._=function(){return this.d};_.ab=function(){return this.e};_.d=0;_.e=0;var Ie=Sh(118);zh(65,118,{});var He=Sh(65);zh(24,1,{},wj);_._=xq;_.ab=function(){vj(this);return this.c};_.U=function(a){vj(this);this.d.U(a)};_.bb=function(a){vj(this);if(this.d.V()){a.A(this.d.W());return true}return false};_.a=0;_.c=0;var Je=Sh(24);zh(57,1,{},yj);_.t=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ke=Sh(57);zh(117,1,{});_.c=false;var Te=Sh(117);zh(32,117,{},Gj);var Se=Sh(32);zh(120,65,{},Kj);_.bb=function(a){this.b=false;while(!this.b&&this.c.bb(new Lj(this,a)));return this.b};_.b=false;var Me=Sh(120);zh(123,1,{},Lj);_.A=function(a){Jj(this.a,this.b,a)};var Le=Sh(123);zh(119,65,{},Nj);_.bb=function(a){return this.a.bb(new Oj(a))};var Oe=Sh(119);zh(122,1,{},Oj);_.A=function(a){Mj(this.a,a)};var Ne=Sh(122);zh(121,1,{},Qj);_.A=function(a){Pj(this,a)};var Pe=Sh(121);zh(124,1,{},Rj);_.A=function(a){};var Qe=Sh(124);zh(125,1,{},Tj);_.A=function(a){Sj(this,a)};var Re=Sh(125);zh(298,1,{});zh(244,1,{});var Ue=Sh(244);zh(295,1,{});var $j=0;var ak,bk=0,ck;zh(730,1,{});zh(771,1,{});zh(233,1,{});_.eb=Jq;var Ve=Sh(233);zh(31,$wnd.React.Component,{});yh(wh[1],_);_.render=function(){return this.a.fb()};var We=Sh(31);zh(280,$wnd.Function,{},mk);_.db=function(a){lk(this.a,this.b,a)};zh(234,233,{});_.n=false;_.o=false;var qk;var Xe=Sh(234);zh(265,$wnd.Function,{},tk);_.H=function(a){return Hb(qk),qk=null,null};zh(7,33,{3:1,29:1,33:1,7:1},dl);var Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl;var Ye=Th(7,el);zh(238,234,{});_.fb=function(){var a;return a=S(this.f.b),kk(gq,uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[gq])),[(new Qm).a,kk('ul',uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,['filters'])),[kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[(Gp(),Ep)==a?hq:null])),'#'),['All'])]),kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[Dp==a?hq:null])),'#active'),['Active'])]),kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[Fp==a?hq:null])),iq),['Completed'])])]),S(this.a)?kk(fq,xk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[jq])),Bh(Nm.prototype.mb,Nm,[this])),[kq]):null])};var Sf=Sh(238);zh(239,238,{});_.fb=function(){return fl(this)};var Wf=Sh(239);zh(72,239,{8:1,72:1},jl);_.v=Fq;_.q=vq;_.ib=Cq;_.s=wq;_.fb=function(){return B((J(),J(),I),this.b,new ml(this))};_.t=function(){var a;return Oh(kf),kf.k+'@'+(a=_j(this)>>>0,a.toString(16))};var gl=0;var kf=Sh(72);zh(174,1,Wp,kl);_.w=function(){hl(this.a)};var Ze=Sh(174);zh(173,1,Wp,ll);_.w=Dq;var $e=Sh(173);zh(177,1,Rp,ml);_.u=function(){return fl(this.a)};var _e=Sh(177);zh(175,1,Rp,nl);_.u=function(){return il(this.a)};var af=Sh(175);zh(176,1,Zp,ol);_.w=Eq;var bf=Sh(176);zh(240,234,{});_.fb=function(){return pl(this)};var Rf=Sh(240);zh(241,240,{});_.fb=function(){return ql(this)};var Vf=Sh(241);zh(73,241,{8:1,73:1},tl);_.v=Gq;_.q=vq;_.ib=Cq;_.s=wq;_.fb=function(){return B((J(),J(),I),this.a,new xl(this))};_.t=function(){var a;return Oh(hf),hf.k+'@'+(a=_j(this)>>>0,a.toString(16))};var rl=0;var hf=Sh(73);zh(179,1,Wp,ul);_.w=function(){sl(this.a)};var cf=Sh(179);zh(178,1,Wp,vl);_.w=Dq;var df=Sh(178);zh(180,1,Zp,wl);_.w=Eq;var ef=Sh(180);zh(181,1,Rp,xl);_.u=function(){return ql(this.a)};var ff=Sh(181);zh(157,1,mq,zl);_.G=function(){return yl(this)};var gf=Sh(157);zh(156,1,mq,Bl);_.G=function(){return Al(this)};var jf=Sh(156);zh(192,234,{});_.fb=function(){return kk(oq,yk(Ck(Dk(Gk(Ek(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,['new-todo']))),(ib(this.b),this.e)),Bh(zn.prototype.lb,zn,[this])),Bh(An.prototype.kb,An,[this]))),null)};_.e='';var dg=Sh(192);zh(193,192,{});_.fb=function(){return El(this)};var Yf=Sh(193);zh(76,193,{8:1,76:1},Kl);_.v=Fq;_.q=vq;_.ib=Cq;_.s=wq;_.fb=function(){return B((J(),J(),I),this.a,new Nl(this))};_.t=function(){var a;return Oh(sf),sf.k+'@'+(a=_j(this)>>>0,a.toString(16))};var Fl=0;var sf=Sh(76);zh(195,1,Wp,Ll);_.w=function(){Gl(this.a)};var lf=Sh(195);zh(194,1,Wp,Ml);_.w=Dq;var mf=Sh(194);zh(197,1,Rp,Nl);_.u=function(){return El(this.a)};var nf=Sh(197);zh(198,1,Wp,Ol);_.w=function(){Cl(this.a)};var of=Sh(198);zh(199,1,Wp,Pl);_.w=function(){Il(this.a,this.b)};var pf=Sh(199);zh(196,1,Zp,Ql);_.w=Eq;var qf=Sh(196);zh(160,1,mq,Sl);_.G=function(){return Rl(this)};var rf=Sh(160);zh(242,234,{});_.eb=function(){lm(this,this.nb())};_.fb=function(){return _l(this)};_.i=false;var gg=Sh(242);zh(243,242,{});_.nb=function(){return this.p.props['a']};_.fb=function(){return cm(this)};var $f=Sh(243);zh(74,243,{8:1,74:1},nm);_.v=function(){jc(this.e)};_.q=vq;_.ib=Cq;_.nb=function(){return jb(this.c),this.p.props['a']};_.s=wq;_.fb=function(){return B((J(),J(),I),this.b,new qm(this))};_.t=function(){var a;return Oh(Gf),Gf.k+'@'+(a=_j(this)>>>0,a.toString(16))};var dm=0;var Gf=Sh(74);zh(183,1,Wp,om);_.w=function(){em(this.a)};var tf=Sh(183);zh(182,1,Wp,pm);_.w=Dq;var uf=Sh(182);zh(186,1,Rp,qm);_.u=function(){return cm(this.a)};var vf=Sh(186);zh(51,1,Wp,rm);_.w=function(){mm(this.a,lo(this.b))};var wf=Sh(51);zh(75,1,Wp,sm);_.w=function(){Zl(this.a,this.b)};var xf=Sh(75);zh(187,1,Wp,tm);_.w=function(){Yl(this.a,this.b)};var yf=Sh(187);zh(188,1,Wp,um);_.w=function(){Xl(this.a,this.b)};var zf=Sh(188);zh(189,1,Wp,vm);_.w=function(){Tl(this.a,this.b)};var Af=Sh(189);zh(190,1,Wp,wm);_.w=function(){$l(this.a)};var Bf=Sh(190);zh(191,1,Rp,xm);_.u=function(){return hm(this.a,this.b)};var Cf=Sh(191);zh(184,1,Rp,ym);_.u=function(){return im(this.a)};var Df=Sh(184);zh(185,1,Zp,zm);_.w=function(){rk(this.a,true)};var Ef=Sh(185);zh(158,1,mq,Bm);_.G=function(){return Am(this)};var Ff=Sh(158);zh(235,234,{});_.fb=function(){var a;return kk('div',null,[kk('div',null,[kk(qq,uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[qq])),[kk('h1',null,['todos']),(new Bn).a]),S(this.c.c)?null:kk('section',uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[qq])),[kk(oq,Ck(Fk(uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,[rq])),(cl(),Jk)),Bh(Sn.prototype.kb,Sn,[this])),null),kk('ul',uk(new $wnd.Object,ad(Wc(je,1),Sp,2,6,['todo-list'])),(a=Fj(Ej(S(this.e.c).T()),new Ni),Mi(a,_c(a.a.length))))]),S(this.c.c)?null:(new Om).a])])};var jg=Sh(235);zh(236,235,{});_.fb=function(){return Dm(this)};var ag=Sh(236);zh(71,236,{8:1,71:1},Gm);_.v=Gq;_.q=vq;_.ib=Cq;_.s=wq;_.fb=function(){return B((J(),J(),I),this.a,new Km(this))};_.t=function(){var a;return Oh(Mf),Mf.k+'@'+(a=_j(this)>>>0,a.toString(16))};var Em=0;var Mf=Sh(71);zh(162,1,Wp,Hm);_.w=function(){sl(this.a)};var Hf=Sh(162);zh(161,1,Wp,Im);_.w=Dq;var If=Sh(161);zh(163,1,Zp,Jm);_.w=Eq;var Jf=Sh(163);zh(164,1,Rp,Km);_.u=function(){return Dm(this.a)};var Kf=Sh(164);zh(159,1,mq,Mm);_.G=function(){return Lm(this)};var Lf=Sh(159);zh(247,$wnd.Function,{},Nm);_.mb=function(a){dp(this.a.e)};zh(81,1,{},Om);var Nf=Sh(81);zh(92,1,mq,Pm);_.G=function(){return Al((new Zn(this.a)).a)};var Of=Sh(92);zh(79,1,{},Qm);var Pf=Sh(79);zh(96,1,mq,Rm);_.G=function(){return yl((new $n(this.a)).a)};var Qf=Sh(96);zh(264,$wnd.Function,{},Wm);_.gb=function(a){return new _m(a)};var Xm;var Zm;zh(104,31,{},_m);_.hb=function(){return Al((new Zn(Zm.a)).a)};_.componentWillUnmount=Hq;var Tf=Sh(104);zh(267,$wnd.Function,{},an);_.gb=function(a){return new fn(a)};var bn;var dn;zh(105,31,{},fn);_.hb=function(){return yl((new $n(dn.a)).a)};_.componentWillUnmount=Iq;var Uf=Sh(105);zh(278,$wnd.Function,{},gn);_.gb=function(a){return new mn(a)};var hn;var kn;zh(108,31,{},mn);_.hb=function(){return Rl((new _n(kn.a)).a)};_.componentWillUnmount=Hq;var Xf=Sh(108);zh(268,$wnd.Function,{},nn);_.gb=function(a){return new sn(a)};var on;var qn;zh(106,31,{},sn);_.hb=function(){return Am((new ao(qn.a)).a)};_.componentDidUpdate=function(a){am(this.a)};_.componentWillUnmount=function(){jc(this.a.e)};_.shouldComponentUpdate=function(a){return fm(this.a,a)};var Zf=Sh(106);zh(277,$wnd.Function,{},tn);_.gb=function(a){return new yn(a)};var un;var wn;zh(107,31,{},yn);_.hb=function(){return Lm((new bo(wn.a)).a)};_.componentWillUnmount=Iq;var _f=Sh(107);zh(249,$wnd.Function,{},zn);_.lb=function(a){Dl(this.a,a)};zh(250,$wnd.Function,{},An);_.kb=function(a){Hl(this.a,a)};zh(80,1,{},Bn);var bg=Sh(80);zh(95,1,mq,Cn);_.G=function(){return Rl((new _n(this.a)).a)};var cg=Sh(95);zh(275,$wnd.Function,{},En);_.kb=function(a){gm(this.a,a)};zh(269,$wnd.Function,{},Fn);_.kb=function(a){Fo(this.a)};zh(271,$wnd.Function,{},Gn);_.mb=function(a){jm(this.a,this.b)};zh(272,$wnd.Function,{},Hn);_.mb=function(a){Ul(this.a,this.b)};zh(273,$wnd.Function,{},In);_.A=function(a){Vl(this.a,a)};zh(274,$wnd.Function,{},Jn);_.jb=function(a){km(this.a,this.b)};zh(276,$wnd.Function,{},Kn);_.lb=function(a){Wl(this.a,this.b,a)};zh(210,1,{},On);var eg=Sh(210);zh(93,1,mq,Pn);_.G=function(){return Am((new ao(this.a)).a)};var fg=Sh(93);zh(248,$wnd.Function,{},Sn);_.kb=function(a){Cm(this.a,a)};zh(83,1,{},Tn);var hg=Sh(83);zh(94,1,mq,Un);_.G=function(){return Lm((new bo(this.a)).a)};var ig=Sh(94);zh(101,1,{},Yn);var pg=Sh(101);zh(59,1,{},Zn);var kg=Sh(59);zh(63,1,{},$n);var lg=Sh(63);zh(62,1,{},_n);var mg=Sh(62);zh(60,1,{},ao);var ng=Sh(60);zh(61,1,{},bo);var og=Sh(61);zh(201,1,{});var Zg=Sh(201);zh(202,201,Tp,po);_.v=Fq;_.q=vq;_.s=wq;_.t=function(){var a;return Oh(xg),xg.k+'@'+(a=_j(this)>>>0,a.toString(16))};var xg=Sh(202);zh(203,1,Wp,qo);_.w=function(){jo(this.a)};var qg=Sh(203);zh(205,1,Zp,ro);_.w=function(){eo(this.a)};var rg=Sh(205);zh(206,1,Zp,so);_.w=function(){fo(this.a)};var sg=Sh(206);zh(208,1,Wp,to);_.w=function(){mo(this.a)};var tg=Sh(208);zh(77,1,Wp,uo);_.w=function(){io(this.a)};var ug=Sh(77);zh(204,1,Rp,vo);_.u=function(){var a;return a=(Jh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var vg=Sh(204);zh(207,1,Wp,wo);_.w=function(){co(this.a,this.b)};var wg=Sh(207);zh(52,1,{52:1});_.d=false;var gh=Sh(52);zh(53,52,{8:1,282:1,53:1,52:1},Go);_.v=Fq;_.q=function(a){return zo(this,a)};_.s=function(){return this.c.e};_.t=function(){var a;return Oh(Qg),Qg.k+'@'+(a=this.c.e>>>0,a.toString(16))};var xo=0;var Qg=Sh(53);zh(211,1,Wp,Ho);_.w=function(){yo(this.a)};var yg=Sh(211);zh(212,1,Wp,Io);_.w=function(){Co(this.a)};var zg=Sh(212);zh(48,129,{48:1});var ah=Sh(48);zh(130,48,{8:1,48:1},Ro);_.v=function(){jc(this.f)};_.q=vq;_.s=wq;_.t=function(){var a;return Oh(Jg),Jg.k+'@'+(a=_j(this)>>>0,a.toString(16))};var Jg=Sh(130);zh(132,1,Wp,So);_.w=function(){Ko(this.a)};var Ag=Sh(132);zh(131,1,Wp,To);_.w=function(){Oo(this.a)};var Bg=Sh(131);zh(137,1,Wp,Uo);_.w=function(){ec(this.a,this.b,true)};var Cg=Sh(137);zh(138,1,Rp,Vo);_.u=function(){return Jo(this.a,this.c,this.b)};_.b=false;var Dg=Sh(138);zh(133,1,Rp,Wo);_.u=function(){return Po(this.a)};var Eg=Sh(133);zh(134,1,Rp,Xo);_.u=function(){return ai(qh(Cj(No(this.a))))};var Fg=Sh(134);zh(135,1,Rp,Yo);_.u=function(){return ai(qh(Cj(Dj(No(this.a),new Jp))))};var Gg=Sh(135);zh(136,1,Rp,Zo);_.u=function(){return Qo(this.a)};var Hg=Sh(136);zh(114,1,mq,ap);_.G=function(){return new Ro};var $o;var Ig=Sh(114);zh(49,1,{49:1});var fh=Sh(49);zh(141,49,{8:1,49:1},hp);_.v=function(){jc(this.a)};_.q=vq;_.s=wq;_.t=function(){var a;return Oh(Pg),Pg.k+'@'+(a=_j(this)>>>0,a.toString(16))};var Pg=Sh(141);zh(142,1,Wp,ip);_.w=Jq;var Kg=Sh(142);zh(143,1,Wp,jp);_.w=function(){ep(this.a,this.b)};_.b=false;var Lg=Sh(143);zh(144,1,Wp,kp);_.w=function(){oo(this.b,this.a)};var Mg=Sh(144);zh(145,1,Wp,lp);_.w=function(){fp(this.a)};var Ng=Sh(145);zh(115,1,mq,mp);_.G=function(){return new hp(this.a.G())};var Og=Sh(115);zh(50,1,{50:1});var ih=Sh(50);zh(149,50,{8:1,50:1},vp);_.v=function(){jc(this.g)};_.q=vq;_.s=wq;_.t=function(){var a;return Oh(Xg),Xg.k+'@'+(a=_j(this)>>>0,a.toString(16))};var Xg=Sh(149);zh(150,1,Wp,wp);_.w=function(){pp(this.a)};var Rg=Sh(150);zh(151,1,Rp,xp);_.u=function(){var a;return a=lo(this.a.i),gi(uq,a)||gi(pq,a)||gi('',a)?gi(uq,a)?(Gp(),Dp):gi(pq,a)?(Gp(),Fp):(Gp(),Ep):(Gp(),Ep)};var Sg=Sh(151);zh(152,1,Rp,yp);_.u=function(){return rp(this.a)};var Tg=Sh(152);zh(153,1,Zp,zp);_.w=function(){sp(this.a)};var Ug=Sh(153);zh(154,1,Zp,Ap);_.w=function(){tp(this.a)};var Vg=Sh(154);zh(116,1,mq,Bp);_.G=function(){return new vp(this.a.G())};var Wg=Sh(116);zh(172,1,{},Cp);_.handleEvent=function(a){go(this.a,a)};var Yg=Sh(172);zh(34,33,{3:1,29:1,33:1,34:1},Hp);var Dp,Ep,Fp;var $g=Th(34,Ip);zh(140,1,{},Jp);_.cb=function(a){return !Bo(a)};var _g=Sh(140);zh(147,1,{},Kp);_.cb=function(a){return Bo(a)};var bh=Sh(147);zh(148,1,{},Lp);_.A=function(a){Mo(this.a,a)};var dh=Sh(148);zh(146,1,{},Mp);_.A=function(a){cp(this.a,a)};_.a=false;var eh=Sh(146);zh(155,1,{},Np);_.cb=function(a){return op(this.a,a)};var hh=Sh(155);var Op=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=uh;sh(Fh);vh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();