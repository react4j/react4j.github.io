function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='DB5DA37221AA3DCD5CA2B0556EFD9235',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'DB5DA37221AA3DCD5CA2B0556EFD9235';function o(){}
function Eh(){}
function Ah(){}
function Ib(){}
function Oc(){}
function Vc(){}
function Qj(){}
function Rj(){}
function tk(){}
function Zm(){}
function dn(){}
function kn(){}
function qn(){}
function wn(){}
function yo(){}
function dp(){}
function lp(){}
function Mp(){}
function Np(){}
function Mq(){}
function Mh(){Mh=Ah}
function bn(a){an=a}
function hn(a){gn=a}
function on(a){nn=a}
function un(a){tn=a}
function An(a){zn=a}
function Tc(a){Sc()}
function Vm(a,b){a.c=b}
function Wm(a,b){a.d=b}
function Xm(a,b){a.e=b}
function Ym(a,b){a.f=b}
function Pj(a,b){a.a=b}
function Tn(a,b){a.j=b}
function Un(a,b){a.k=b}
function G(a){this.a=a}
function H(a){this.a=a}
function mb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function hc(a){this.a=a}
function nc(a){this.a=a}
function _h(a){this.a=a}
function ki(a){this.a=a}
function wi(a){this.a=a}
function Bi(a){this.a=a}
function Ci(a){this.a=a}
function Ai(a){this.b=a}
function Pi(a){this.c=a}
function Oj(a){this.a=a}
function Tj(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function Ml(a){this.a=a}
function Nl(a){this.a=a}
function Ol(a){this.a=a}
function Pl(a){this.a=a}
function Rl(a){this.a=a}
function Sl(a){this.a=a}
function pm(a){this.a=a}
function qm(a){this.a=a}
function rm(a){this.a=a}
function xm(a){this.a=a}
function zm(a){this.a=a}
function Am(a){this.a=a}
function Jm(a){this.a=a}
function Km(a){this.a=a}
function Lm(a){this.a=a}
function Mm(a){this.a=a}
function Qm(a){this.a=a}
function Sm(a){this.a=a}
function Um(a){this.a=a}
function Cn(a){this.a=a}
function Dn(a){this.a=a}
function Fn(a){this.a=a}
function Hn(a){this.a=a}
function In(a){this.a=a}
function Ln(a){this.a=a}
function Sn(a){this.a=a}
function Vn(a){this.a=a}
function Xn(a){this.a=a}
function to(a){this.a=a}
function uo(a){this.a=a}
function vo(a){this.a=a}
function wo(a){this.a=a}
function xo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Vo(a){this.a=a}
function Wo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function op(a){this.a=a}
function pp(a){this.a=a}
function zp(a){this.a=a}
function Ap(a){this.a=a}
function Bp(a){this.a=a}
function Cp(a){this.a=a}
function Dp(a){this.a=a}
function Ep(a){this.a=a}
function Fp(a){this.a=a}
function Op(a){this.a=a}
function Pp(a){this.a=a}
function Qp(a){this.a=a}
function Iq(){jc(this.c)}
function Jq(){jc(this.b)}
function Ni(){Ei(this)}
function Bq(a){pj(this,a)}
function Eq(a){di(this,a)}
function gb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function kb(a){Yb((J(),a))}
function w(a){--a.e;D(a)}
function kc(a){!!a&&a.w()}
function Zi(){this.a=gj()}
function lj(){this.a=gj()}
function tb(a,b){a.b=sj(b)}
function nk(a,b){a.key=b}
function ik(a,b){hk(a,b)}
function fp(a,b){Go(b,a)}
function ep(a,b){Oo(a.b,b)}
function cc(a,b){si(a.b,b)}
function Sj(a,b){Ij(a.a,b)}
function Vl(a,b){Po(a.j,b)}
function C(a,b){ab(a.f,b.f)}
function lh(a){return a.e}
function Aq(){return this.a}
function Dq(){return this.b}
function Lq(){jc(this.a.b)}
function Kq(){jc(this.a.c)}
function Gq(){this.a.o=true}
function dc(){this.b=new Ti}
function J(){J=Ah;I=new F}
function uc(){uc=Ah;tc=new o}
function Lc(){Lc=Ah;Kc=new Oc}
function cp(){cp=Ah;bp=new dp}
function cj(){cj=Ah;bj=ej()}
function V(a){jd(a,8)&&a.v()}
function Lb(a){a.a=-4&a.a|1}
function mo(a){R(a.a);cb(a.b)}
function Xj(a,b){a.splice(b,1)}
function ac(a,b,c){ri(a.b,b,c)}
function gi(a,b){return a===b}
function Wl(a,b){return a.f=b}
function Hi(a,b){return a.a[b]}
function yq(a){return this===a}
function zq(){return _j(this)}
function Fq(){return J(),J(),I}
function Hq(){rk(this.a,false)}
function cn(a){jk.call(this,a)}
function jn(a){jk.call(this,a)}
function pn(a){jk.call(this,a)}
function vn(a){jk.call(this,a)}
function Bn(a){jk.call(this,a)}
function li(a){sc.call(this,a)}
function ei(){oc(this);this.D()}
function Cq(){return ui(this.a)}
function Wc(a,b){return Uh(a,b)}
function gj(){cj();return new bj}
function Ph(a){Oh(a);return a.k}
function Hj(a,b){a.Q(b);return a}
function tj(a,b){while(a.bb(b));}
function Ij(a,b){Pj(a,Hj(a.a,b))}
function Bo(a){cb(a.b);cb(a.a)}
function sl(a){a.o=true;nb(a.a)}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function db(a){J();Xb(a);a.e=-2}
function oo(a){ib(a.b);return a.e}
function Eo(a){ib(a.a);return a.d}
function tp(a){ib(a.d);return a.f}
function vk(a,b){a.ref=b;return a}
function ic(a,b){this.a=a;this.b=b}
function Zh(a,b){this.a=a;this.b=b}
function Di(a,b){this.a=a;this.b=b}
function Lj(a,b){this.a=a;this.b=b}
function mk(a,b){this.a=a;this.b=b}
function wk(a,b){a.href=b;return a}
function ij(a,b){return a.a.get(b)}
function ui(a){return a.a.b+a.b.b}
function W(a){return !!a&&a.c.i<0}
function _c(a){return new Array(a)}
function th(){rh==null&&(rh=[])}
function Bc(){Bc=Ah;!!(Sc(),Rc)}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function v(a,b,c){s(a,new H(c),b)}
function Vj(a,b,c){a.splice(b,0,c)}
function dl(a,b){Zh.call(this,a,b)}
function Ql(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function tm(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function wm(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function Jn(a,b){this.a=a;this.b=b}
function Kn(a,b){this.a=a;this.b=b}
function Mn(a,b){this.a=a;this.b=b}
function Nn(a,b){this.a=a;this.b=b}
function zo(a,b){this.a=a;this.b=b}
function Xo(a,b){this.a=a;this.b=b}
function mp(a,b){this.a=a;this.b=b}
function np(a,b){this.b=a;this.a=b}
function Kp(a,b){Zh.call(this,a,b)}
function po(a){no(a,(ib(a.b),a.e))}
function Rm(){this.a=pk((_m(),$m))}
function Tm(){this.a=pk((fn(),en))}
function En(){this.a=pk((mn(),ln))}
function Rn(){this.a=pk((sn(),rn))}
function Wn(){this.a=pk((yn(),xn))}
function On(a){return Pn(new Rn,a)}
function qi(a){return !a?null:a.Z()}
function Sb(a){return !a.d?a:Sb(a.d)}
function rj(a){return a!=null?r(a):0}
function od(a){return a==null?null:a}
function ld(a){return typeof a===Tp}
function Ic(a){$wnd.clearTimeout(a)}
function Ei(a){a.a=Yc(ge,Vp,1,0,5,1)}
function ti(a){a.a=new Zi;a.b=new lj}
function dk(){dk=Ah;ak=new o;ck=new o}
function lb(a){this.c=new Ni;this.b=a}
function zk(a,b){a.checked=b;return a}
function Gk(a,b){a.value=b;return a}
function Bk(a,b){a.onBlur=b;return a}
function xk(a,b){a.onClick=b;return a}
function ii(a,b){a.a+=''+b;return a}
function Mj(a,b){a.A(Qn(On(b.c.e),b))}
function Wj(a,b){Uj(b,0,a,0,b.length)}
function gc(a,b){ec(a,b,false);hb(a.d)}
function Fo(a){Go(a,(ib(a.a),!a.d))}
function hl(a){a.o=true;nb(a.b);R(a.a)}
function Al(a){return Cl(a.a,a.b,a.c)}
function Bm(a){return Dm(a.a,a.b,a.c)}
function Nm(a){return Pm(a.a,a.b,a.c)}
function X(a){return !(!!a&&1==(a.c&7))}
function B(a,b,c){return t(a,c,2048,b)}
function bd(a,b,c){return {l:a,m:b,h:c}}
function fi(a,b){return a.charCodeAt(b)}
function _j(a){return a.$H||(a.$H=++$j)}
function sb(a){J();rb(a);vb(a,2,true)}
function ib(a){var b;Tb((J(),b=Ob,b),a)}
function Gb(a){this.d=sj(a);this.b=100}
function Gh(a){this.b=sj(a);this.a=this}
function P(){this.a=Yc(ge,Vp,1,100,5,1)}
function A(a,b,c){t(a,new G(b),c,null)}
function hk(a,b){for(var c in a){b(c)}}
function Ck(a,b){a.onChange=b;return a}
function Dk(a,b){a.onKeyDown=b;return a}
function yk(a){a.autoFocus=true;return a}
function Hl(a){a.o=true;nb(a.a);cb(a.b)}
function Jb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&vb(a.f,5,true)}
function Oh(a){if(a.k!=null){return}Wh(a)}
function pc(a,b){a.e=b;b!=null&&Zj(b,cq,a)}
function jd(a,b){return a!=null&&gd(a,b)}
function _i(a,b){var c;c=a[hq];c.call(a,b)}
function Gj(a,b){Bj.call(this,a);this.a=b}
function sc(a){this.f=a;oc(this);this.D()}
function Ti(){this.a=new Zi;this.b=new lj}
function nd(a){return typeof a==='string'}
function kd(a){return typeof a==='boolean'}
function Pn(a,b){return nk(a.a,sj(''+b)),a}
function u(a,b){return new yb(sj(a),null,b)}
function pj(a,b){while(a.V()){Sj(b,a.W())}}
function fc(a,b){cc(b.c.c,a);jd(b,8)&&b.v()}
function $(a,b,c){Lb(sj(c));K(a.a[b],sj(c))}
function Zj(b,c,d){try{b[c]=d}catch(a){}}
function bm(a){A((J(),J(),I),new xm(a),qq)}
function qo(a){A((J(),J(),I),new wo(a),qq)}
function Io(a){A((J(),J(),I),new Lo(a),qq)}
function gp(a){A((J(),J(),I),new op(a),qq)}
function vp(a){W((ib(a.d),a.f))&&xp(a,null)}
function To(a){return ai(S(a.e).a-S(a.a).a)}
function Cc(a,b,c){return a.apply(b,c);var d}
function Ak(a,b){a.defaultValue=b;return a}
function Hk(a,b){a.onDoubleClick=b;return a}
function Qn(a,b){a.a.props['a']=b;return a.a}
function oc(a){a.g&&a.e!==bq&&a.D();return a}
function Sh(a){var b;b=Rh(a);Yh(a,b);return b}
function Fi(a,b){a.a[a.a.length]=b;return true}
function oj(a,b,c){this.a=a;this.b=b;this.c=c}
function Bl(a,b,c){this.a=a;this.b=b;this.c=c}
function Cm(a,b,c){this.a=a;this.b=b;this.c=c}
function Om(a,b,c){this.a=a;this.b=b;this.c=c}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function Il(a,b){A((J(),J(),I),new Ql(a,b),qq)}
function hm(a,b){A((J(),J(),I),new wm(a,b),qq)}
function km(a,b){A((J(),J(),I),new um(a,b),qq)}
function lm(a,b){A((J(),J(),I),new tm(a,b),qq)}
function mm(a,b){A((J(),J(),I),new sm(a,b),qq)}
function Po(a,b){A((J(),J(),I),new Xo(a,b),qq)}
function jp(a,b){A((J(),J(),I),new mp(a,b),qq)}
function Jl(a,b){var c;c=b.target;Kl(a,c.value)}
function qb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function Yo(a,b){this.a=a;this.c=b;this.b=false}
function bo(a){this.b=a;this.a=new yl(this.b.a)}
function co(a){this.b=a;this.a=new Sl(this.b.b)}
function F(){this.f=new bb;this.a=new Gb(this.f)}
function Ro(a){di(new Bi(a.g),new hc(a));ti(a.g)}
function Fb(a){while(true){if(!Eb(a)){break}}}
function im(a,b){return Mh(),cm(a,b)?true:false}
function hj(a,b){return !(a.a.get(b)===undefined)}
function $c(a){return Array.isArray(a)&&a.qb===Eh}
function So(a){return Mh(),0==S(a.e).a?true:false}
function hd(a){return !Array.isArray(a)&&a.qb===Eh}
function vj(a){if(!a.d){a.d=a.b.P();a.c=a.b.R()}}
function Hb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Jj(a,b,c){if(a.a.cb(c)){a.b=true;b.A(c)}}
function yi(a){var b;b=a.a.W();a.b=xi(a);return b}
function zl(a){var b;b=new tl;Vm(b,a.G());return b}
function Tl(a){var b;b=new Ll;Wm(b,a.G());return b}
function Ji(a,b){var c;c=a.a[b];Xj(a.a,b);return c}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Li(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Em(a,b){var c;c=b.target;jp(a.d,c.checked)}
function Ej(a){Aj(a);return new Gj(a,new Nj(a.a))}
function Hh(a){sj(a);return jd(a,47)?a:new Gh(a)}
function vi(a,b){if(b){return oi(a.a,b)}return false}
function il(a){return Mh(),S(a.d.b).a>0?true:false}
function qp(a){return gi(xq,a)||gi(sq,a)||gi('',a)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Kl(a,b){var c;c=a.e;if(b!=c){a.e=b;hb(a.b)}}
function nm(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function Go(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function sp(a){nb(a.e);nb(a.a);R(a.b);R(a.c);cb(a.d)}
function zj(a){if(!a.b){Aj(a);a.c=true}else{zj(a.b)}}
function Dj(a,b){Aj(a);return new Gj(a,new Kj(b,a.a))}
function no(a,b){A((J(),J(),I),new zo(a,b),75497472)}
function ci(){ci=Ah;bi=Yc(ce,Vp,30,256,0,1)}
function Jh(){Jh=Ah;Ih=$wnd.window.document}
function Sc(){Sc=Ah;var a;!Uc();a=new Vc;Rc=a}
function gk(){if(bk==256){ak=ck;ck=new o;bk=0}++bk}
function sj(a){if(a==null){throw lh(new ei)}return a}
function Bj(a){if(!a){this.b=null;new Ni}else{this.b=a}}
function Nj(a){uj.call(this,a.ab(),a._()&-6);this.a=a}
function fm(a){a.o=true;nb(a.b);R(a.d);cb(a.c);cb(a.a)}
function lo(a){var b;T(a.a);b=S(a.a);gi(a.f,b)&&ro(a,b)}
function ro(a,b){var c;c=a.e;if(b!=c){a.e=sj(b);hb(a.b)}}
function Th(a,b){var c;c=Rh(a);Yh(a,c);c.e=b?8:0;return c}
function ql(a){var b;a.n=false;sk(a);b=pl(a);return b}
function Fk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function uj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function wj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Zl(a,b){xp(a.k,b);A((J(),J(),I),new sm(a,b),qq)}
function Oo(a,b){return t((J(),J(),I),new Yo(a,b),qq,null)}
function Si(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function Lp(){Jp();return ad(Wc($g,1),Vp,34,0,[Gp,Ip,Hp])}
function qh(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function Vh(a){if(a.N()){return null}var b=a.j;return wh[b]}
function pk(a){var b;b=ok(a);b.props={};b.ref=null;return b}
function qc(a,b){var c;c=Ph(a.ob);return b==null?c:c+': '+b}
function Ul(a,b){var c;if(S(a.d)){c=b.target;nm(a,c.value)}}
function jb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function ob(a){C((J(),J(),I),a);0==(a.f.a&$p)&&D((null,I))}
function Yl(a,b){A((J(),J(),I),new sm(a,b),qq);xp(a.k,null)}
function ho(a){Kh((Jh(),$wnd.window.window),vq,a.d,false)}
function io(a){Lh((Jh(),$wnd.window.window),vq,a.d,false)}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function lc(a){kc(a.g);V(a.c);V(a.a);V(a.d);kc(a.b);kc(a.f)}
function Pb(a){if(a.e){2==(a.e.c&7)||vb(a.e,4,true);rb(a.e)}}
function di(a,b){var c,d;for(d=a.P();d.V();){c=d.W();b.A(c)}}
function hp(a,b){var c;Fj(Qo(a.b),(c=new Ni,c)).O(new Pp(b))}
function Uh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.I(b))}
function Vi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function pi(a,b){return b===a?'(this Map)':b==null?eq:Dh(b)}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function Ch(a){function b(){}
;b.prototype=a||{};return new b}
function Ek(a){a.placeholder='What needs to be done?';return a}
function jo(a,b){b.preventDefault();A((J(),J(),I),new xo(a),qq)}
function Kh(a,b,c,d){a.addEventListener(b,c,(Mh(),d?true:false))}
function Aj(a){if(a.b){Aj(a.b)}else if(a.c){throw lh(new $h)}}
function Qo(a){ib(a.d);return new Gj(null,new wj(new Bi(a.g),0))}
function Wi(a,b){var c;return Ui(b,Vi(a,b==null?0:(c=r(b),c|0)))}
function yh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function fn(){fn=Ah;var a;en=(a=Bh(dn.prototype.gb,dn,[]),a)}
function mn(){mn=Ah;var a;ln=(a=Bh(kn.prototype.gb,kn,[]),a)}
function sn(){sn=Ah;var a;rn=(a=Bh(qn.prototype.gb,qn,[]),a)}
function yn(){yn=Ah;var a;xn=(a=Bh(wn.prototype.gb,wn,[]),a)}
function _m(){_m=Ah;var a;$m=(a=Bh(Zm.prototype.gb,Zm,[]),a)}
function ao(a){this.b=a;this.a=new Bl(this.b.a,this.b.b,this.b.c)}
function eo(a){this.b=a;this.a=new Cm(this.b.a,this.b.b,this.b.c)}
function fo(a){this.b=a;this.a=new Om(this.b.a,this.b.b,this.b.c)}
function $i(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Kj(a,b){uj.call(this,b.ab(),b._()&-16449);this.a=a;this.c=b}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function eb(a,b){var c,d;Fi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function xp(a,b){var c;c=a.f;if(!(b==c||!!b&&Co(b,c))){a.f=b;hb(a.d)}}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function gm(a,b){return t((J(),J(),I),new ym(a,b),75497472,null)}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Oi(a){Ei(this);Wj(this.a,ni(a,Yc(ge,Vp,1,ui(a.a),5,1)))}
function mj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function xj(a,b){!a.a?(a.a=new ki(a.d)):ii(a.a,a.b);ii(a.a,b);return a}
function Fj(a,b){var c;zj(a);c=new Qj;c.a=b;a.a.U(new Tj(c));return c.a}
function Cj(a){var b;zj(a);b=0;while(a.a.bb(new Rj)){b=mh(b,1)}return b}
function ip(a){var b;Fj(Dj(Qo(a.b),new Np),(b=new Ni,b)).O(new Op(a.b))}
function Mb(b){try{b.b.w()}catch(a){a=kh(a);if(!jd(a,6))throw lh(a)}}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function kp(a){this.b=sj(a);J();this.a=new mc(0,null,new lp,false,false)}
function yj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function zi(a){this.d=a;this.c=new mj(this.d.b);this.a=this.c;this.b=xi(this)}
function Dm(a,b,c){var d;d=new om;Tn(d,a.G());b.G();Un(d,c.G());return d}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function Lh(a,b,c,d){a.removeEventListener(b,c,(Mh(),d?true:false))}
function lk(a,b,c){!gi(c,'key')&&!gi(c,'ref')&&(a[c]=b[c],undefined)}
function ri(a,b,c){return nd(b)?b==null?Xi(a.a,null,c):jj(a.b,b,c):Xi(a.a,b,c)}
function si(a,b){return nd(b)?b==null?Yi(a.a,null):kj(a.b,b):Yi(a.a,b)}
function rp(a,b){return (Jp(),Hp)==a||(Gp==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function jm(a){return Mh(),tp(a.k)==(jb(a.c),a.p.props['a'])?true:false}
function Yj(a,b){return Xc(b)!=10&&ad(q(b),b.pb,b.__elementTypeId$,Xc(b),a),a}
function go(a,b){a.f=b;gi(b,S(a.a))&&ro(a,b);ko(b);A((J(),J(),I),new xo(a),qq)}
function Dl(a){var b;b=hi((ib(a.b),a.e));if(b.length>0){ep(a.d,b);Kl(a,'')}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Ii(a,b,c){for(;c<a.a.length;++c){if(Si(b,a.a[c])){return c}}return -1}
function Cl(a,b,c){var d;d=new jl;Wm(d,a.G());Xm(d,b.G());Ym(d,c.G());return d}
function Pm(a,b,c){var d;d=new Im;Vm(d,a.G());Wm(d,b.G());Xm(d,c.G());return d}
function Ki(a,b){var c;c=Ii(a,b,0);if(c==-1){return false}Xj(a.a,c);return true}
function Co(a,b){var c;if(jd(b,53)){c=b;return a.c.e==c.c.e}else{return false}}
function nj(a){if(a.a.c!=a.c){return ij(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Fb(a.a)}finally{a.c=false}}}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||nb(a.f)}}
function rk(a,b){if(!a.n){a.n=true;a.o||(b?a.p.setState({}):a.p.forceUpdate())}}
function Gi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.A(c)}}
function up(a){var b,c;return b=S(a.b),Fj(Dj(Qo(a.j),new Qp(b)),(c=new Ni,c))}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new nc(a)),67108864,null)}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new mb(a)),0,null);!!a.b&&nb(a.b)}}
function ub(b){if(b){try{b.w()}catch(a){a=kh(a);if(jd(a,6)){J()}else throw lh(a)}}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function No(a){di(new Bi(a.g),new hc(a));ti(a.g);R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function bb(){var a;this.a=Yc(td,Vp,46,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function sh(){th();var a=rh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Bh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Yh(a,b){var c;if(!a){return}b.j=a;var d=Vh(b);if(!d){wh[a]=[b];return}d.ob=b}
function kh(a){var b;if(jd(a,6)){return a}b=a&&a[cq];if(!b){b=new wc(a);Tc(b)}return b}
function Rh(a){var b;b=new Qh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function kj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{_i(a.a,b);--a.b}return c}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Fi((!a.b&&(a.b=new Ni),a.b),b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new Ni);a.c=c.c}b.d=true;Fi(a.c,sj(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,sj(b))}
function rb(a){var b,c;for(c=new Pi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Qi(a){var b,c,d;d=0;for(c=new zi(a.a);c.b;){b=yi(c);d=d+(b?r(b):0);d=d|0}return d}
function mi(a,b){var c,d;for(d=new zi(b.a);d.b;){c=yi(d);if(!vi(a,c)){return false}}return true}
function El(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Pl(a),qq)}}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function md(a){return a!=null&&(typeof a===Sp||typeof a==='function')&&!(a.qb===Eh)}
function vh(a,b){typeof window===Sp&&typeof window['$gwt']===Sp&&(window['$gwt'][a]=b)}
function Nb(a,b){this.b=sj(a);this.a=b|0|(0==(b&6291456)?_p:0)|(0!=(b&229376)?0:98304)}
function yb(a,b,c){xb.call(this,null,a,b,c|(!a?262144:Xp)|(0==(c&6291456)?!a?$p:_p:0)|0|0|0)}
function $h(){sc.call(this,"Stream already terminated, can't be modified or used")}
function xi(a){if(a.a.V()){return true}if(a.a!=a.c){return false}a.a=new $i(a.d.a);return a.a.V()}
function nh(a){var b;b=a.h;if(b==0){return a.l+a.m*_p}if(b==1048575){return a.l+a.m*_p-fq}return a}
function ph(a){var b,c,d,e;e=a;d=0;if(e<0){e+=fq;d=1048575}c=pd(e/_p);b=pd(e-c*_p);return bd(b,c,d)}
function Ui(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Si(a,c.Y())){return c}}return null}
function cm(a,b){var c,d;d=a.p.props;c=false;if(!(d['a']===b['a'])){hb(a.c);c=true}return c||a.n}
function Mo(a,b,c){var d;d=new Jo(b,c);ac(d.c.c,a,new ic(a,d));ri(a.g,ai(d.c.e),d);hb(a.d);return d}
function jj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ec(a,b,c){var d;d=si(a.g,b?ai(b.c.e):null);if(null!=d){cc(b.c.c,a);c&&!!b&&jc(b.c);hb(a.d)}}
function wp(a){var b;b=S(a.i.a);gi(xq,b)||gi(sq,b)||gi('',b)?no(a.i,b):qp(oo(a.i))?qo(a.i):no(a.i,'')}
function _n(){this.a=Hh((cp(),cp(),bp));this.b=Hh(new pp(this.a));this.c=Hh(new Ep(this.a))}
function jk(a){$wnd.React.Component.call(this,a);this.a=this.hb();this.a.p=sj(this);this.a.eb()}
function Qh(){this.g=Nh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function wc(a){uc();oc(this);this.e=a;a!=null&&Zj(a,cq,this);this.f=a==null?eq:Dh(a);this.a='';this.b=a;this.a=''}
function sk(a){if(!qk){qk=(++a.ib().e,new Ib);$wnd.Promise.resolve(null).then(Bh(tk.prototype.H,tk,[]))}}
function S(a){ib(a.e);wb(a.f)&&pb(a.f);if(a.b){if(jd(a.b,9)){throw lh(a.b)}else{throw lh(a.b)}}return a.k}
function dm(a){var b,c;a.n=false;sk(a);b=(jb(a.c),a.p.props['a']);if(!!b&&b.c.i<0){return null}c=am(a);return c}
function ai(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ci(),bi)[b];!c&&(c=bi[b]=new _h(a));return c}return new _h(a)}
function Dh(a){var b;if(Array.isArray(a)&&a.qb===Eh){return Ph(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function ad(a,b,c,d,e){e.ob=a;e.pb=b;e.qb=Eh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Jp(){Jp=Ah;Gp=new Kp('ACTIVE',0);Ip=new Kp('COMPLETED',1);Hp=new Kp('ALL',2)}
function Xl(a,b,c){27==c.which?A((J(),J(),I),new vm(a,b),qq):13==c.which&&A((J(),J(),I),new tm(a,b),qq)}
function nb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Cb(a)),67108864,null);!!a.a&&R(a.a);Jb(a.f);a.c=a.c&-8|1}}
function Kb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Xp)?Mb(a):a.b.w();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function fb(a,b){var c,d;d=a.c;Ki(d,b);!!a.b&&Xp!=(a.b.c&Yp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function mh(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<fq){return c}}return nh(cd(ld(a)?ph(a):a,ld(b)?ph(b):b))}
function q(a){return nd(a)?je:ld(a)?$d:kd(a)?Yd:hd(a)?a.ob:$c(a)?a.ob:a.ob||Array.isArray(a)&&Wc(Qd,1)||Qd}
function r(a){return nd(a)?fk(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.s():$c(a)?_j(a):!!a&&!!a.hashCode?a.hashCode():_j(a)}
function p(a,b){return nd(a)?gi(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.q(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function zb(a,b){xb.call(this,a,new Ab(a),null,b|(Xp==(b&Yp)?0:524288)|(0==(b&6291456)?Xp==(b&Yp)?_p:$p:0)|0|268435456|0)}
function el(){cl();return ad(Wc(Ye,1),Vp,7,0,[Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl])}
function fk(a){dk();var b,c,d;c=':'+a;d=ck[c];if(d!=null){return pd(d)}d=ak[c];b=d==null?ek(a):pd(d);gk();ck[c]=b;return b}
function Ri(a){var b,c,d;d=1;for(c=new Pi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function bc(a){var b,c;if(!a.a){for(c=new Pi(new Oi(new Bi(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.w()}a.a=true}}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function uk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Mi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Yj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Xh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function $l(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){A((J(),J(),I),new np(b,c),qq);xp(a.k,null);nm(a,c)}else{Po(a.j,b)}}
function _l(a){var b;b=S(a.d);if(!a.i&&b){a.i=true;mm(a,(jb(a.c),a.p.props['a']));a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function tl(){var a;J();a=++rl;this.b=new mc(a,new vl(this),new ul(this),false,false);this.a=new yb(null,sj(new wl(this)),oq);D((null,I))}
function Im(){var a;J();a=++Gm;this.b=new mc(a,new Km(this),new Jm(this),false,false);this.a=new yb(null,sj(new Lm(this)),oq);D((null,I))}
function mc(a,b,c,d,e){var f;this.e=a;this.c=d?new dc:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new lb((J(),null)),f):null;this.d=null}
function U(a,b,c,d){this.c=sj(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new zb(this,d);this.e=new lb(this.f);Xp==(d&Yp)&&ob(this.f)}
function Jo(a,b){var c,d,e;this.e=sj(a);this.d=b;J();c=++Ao;this.c=new mc(c,null,new Ko(this),true,true);this.b=(e=new lb(null),e);this.a=(d=new lb(null),d)}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.pb){return !!a.pb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&vb(b,5,true)}}}
function Xb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Pi(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&vb(b,6,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?vb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function hi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ub(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=Ji(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&vb(c.b,3,true);++b}}}return b}
function s(b,c,d){var e,f;try{$b(b,d);try{f=(c.a.w(),null)}finally{_b()}return f}catch(a){a=kh(a);if(jd(a,6)){e=a;throw lh(e)}else throw lh(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.u()}else{$b(b,e);try{g=c.u()}finally{_b()}}return g}catch(a){a=kh(a);if(jd(a,6)){f=a;throw lh(f)}else throw lh(a)}finally{D(b)}}
function Eb(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Kb(c);return true}
function Ll(){var a,b;J();a=++Gl;this.c=new mc(a,new Nl(this),new Ml(this),false,false);this.b=(b=new lb(null),b);this.a=new yb(null,sj(new Rl(this)),oq);D((null,I))}
function jl(){var a;J();a=++gl;this.c=new mc(a,new ll(this),new kl(this),false,false);this.a=new U(new nl(this),null,null,136478720);this.b=new yb(null,sj(new ol(this)),oq);D((null,I))}
function uh(b,c,d,e){th();var f=rh;$moduleName=c;$moduleBase=d;jh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Rp(g)()}catch(a){b(c,a)}}else{Rp(g)()}}
function pl(a){var b,c;c=S(a.c.e).a;b='item'+(c==1?'':'s');return kk('span',uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,['todo-count'])),[kk('strong',null,[c]),' '+b+' left'])}
function Fh(){var a;a=new _n;bn(new Sm(a));hn(new Um(a));un(new Sn(a));An(new Xn(a));on(new Fn(a));$wnd.ReactDOM.render((new Wn).a,(Jh(),Ih).getElementById('todoapp'),null)}
function ej(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return fj()}}
function ok(a){var b;b=new $wnd.Object;b.$$typeof=$wnd.React.Element;b.type=sj(a);b._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return b}
function ni(a,b){var c,d,e,f,g;g=ui(a.a);b.length<g&&(b=Yj(new Array(g),b));e=(f=new zi((new wi(a.a)).a),new Ci(f));for(d=0;d<g;++d){b[d]=(c=yi(e.a),c.Z())}b.length>g&&(b[g]=null);return b}
function xh(){wh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].rb()&&(c=Pc(c,g)):g[0].rb()}catch(a){a=kh(a);if(jd(a,6)){d=a;Bc();Hc(jd(d,36)?d.F():d)}else throw lh(a)}}return c}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?eq:md(b)?b==null?null:b.name:nd(b)?'String':Ph(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Fl(a){var b;a.n=false;sk(a);b=kk(rq,yk(Ck(Dk(Gk(Ek(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,['new-todo']))),(ib(a.b),a.e)),Bh(Cn.prototype.lb,Cn,[a])),Bh(Dn.prototype.kb,Dn,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.u();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=kh(a);if(jd(a,12)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw lh(c)}else throw lh(a)}}
function Xi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ui(b,e);if(f){return f.$(c)}}e[e.length]=new Di(b,c);++a.b;return null}
function Uj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function ek(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+fi(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Yc(ge,Vp,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function pb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.w()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=kh(a);if(jd(a,6)){J()}else throw lh(a)}}}
function ko(a){var b;if(0==a.length){b=(Jh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Ih.title,b)}else{(Jh(),$wnd.window.window).location.hash=a}}
function xb(a,b,c,d){this.b=new Ni;this.f=new Nb(new Bb(this),d&6520832|262144|Xp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&$p)&&D((null,I)))}
function Yi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Si(b,e.Y())){if(d.length==1){d.length=0;_i(a.a,g)}else{d.splice(h,1)}--a.b;return e.Z()}}return null}
function zh(a,b,c){var d=wh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=wh[b]),Ch(h));_.pb=c;!b&&(_.qb=Eh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ob=f)}
function Wh(a){if(a.M()){var b=a.c;b.N()?(a.k='['+b.j):!b.M()?(a.k='[L'+b.K()+';'):(a.k='['+b.K());a.b=b.J()+'[]';a.i=b.L()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Xh('.',[c,Xh('$',d)]);a.b=Xh('.',[c,Xh('.',d)]);a.i=d[d.length-1]}
function om(){var a,b,c;J();a=++em;this.e=new mc(a,new qm(this),new pm(this),false,false);this.c=(c=new lb(null),c);this.a=(b=new lb(null),b);this.d=new U(new zm(this),null,null,136478720);this.b=new yb(null,sj(new Am(this)),oq);D((null,I))}
function oi(a,b){var c,d,e;c=b.Y();e=b.Z();d=nd(c)?c==null?qi(Wi(a.a,null)):ij(a.b,c):qi(Wi(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!Wi(a.a,null):hj(a.b,c):!!Wi(a.a,c))){return false}return true}
function so(){var a,b;this.d=new Fp(this);this.f=this.e=(b=(Jh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new mc(0,null,new to(this),false,false);this.b=(a=new lb(null),a);this.a=new U(new yo,new uo(this),new vo(this),35749888)}
function Uo(){var a;this.g=new Ti;J();this.f=new mc(0,new Wo(this),new Vo(this),false,false);this.d=(a=new lb(null),a);this.c=new U(new Zo(this),null,null,wq);this.e=new U(new $o(this),null,null,wq);this.a=new U(new _o(this),null,null,wq);this.b=new U(new ap(this),null,null,wq)}
function yp(a){var b;this.j=sj(a);this.i=new so;J();this.g=new mc(0,null,new zp(this),false,false);this.d=(b=new lb(null),b);this.b=new U(new Ap(this),null,null,wq);this.c=new U(new Bp(this),null,null,wq);this.e=u(new Cp(this),413138944);this.a=u(new Dp(this),681574400);D((null,I))}
function wb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Pi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=kh(a);if(!jd(a,6))throw lh(a)}if(6==(b.c&7)){return true}}}}}rb(b);return false}
function kk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?''+b['key']:null;f='ref' in b?b['ref']:null;ik(b,Bh(mk.prototype.db,mk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=ok(a),g.key=e,g.ref=f,g.props=sj(d),g}
function dj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function vb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){kb(a.a.e);ub((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;ub((e=d.i,e));d.k=null}Gi(a.b,new Db(a));a.b.a=Yc(ge,Vp,1,0,5,1)}else 3==g&&!!a.a&&ub((f=a.a.g,f))}}
function cl(){cl=Ah;Ik=new dl(iq,0);Jk=new dl('checkbox',1);Kk=new dl('color',2);Lk=new dl('date',3);Mk=new dl('datetime',4);Nk=new dl('email',5);Ok=new dl('file',6);Pk=new dl('hidden',7);Qk=new dl('image',8);Rk=new dl('month',9);Sk=new dl(Tp,10);Tk=new dl('password',11);Uk=new dl('radio',12);Vk=new dl('range',13);Wk=new dl('reset',14);Xk=new dl('search',15);Yk=new dl('submit',16);Zk=new dl('tel',17);$k=new dl('text',18);_k=new dl('time',19);al=new dl('url',20);bl=new dl('week',21)}
function Fm(a){var b,c,d;a.n=false;sk(a);d=kk('div',null,[kk('div',null,[kk(tq,uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[tq])),[kk('h1',null,['todos']),(new En).a]),S(a.c.c)?null:kk('section',uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[tq])),[kk(rq,Ck(Fk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[uq])),(cl(),Jk)),Bh(Vn.prototype.kb,Vn,[a])),null),kk('ul',uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,['todo-list'])),(b=Fj(Ej(S(a.e.c).T()),(c=new Ni,c)),Mi(b,_c(b.a.length))))]),S(a.c.c)?null:(new Rm).a])]);return d}
function fl(a){var b,c;a.n=false;sk(a);c=(b=S(a.f.b),kk(jq,uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[jq])),[(new Tm).a,kk('ul',uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,['filters'])),[kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[(Jp(),Hp)==b?kq:null])),'#'),['All'])]),kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[Gp==b?kq:null])),'#active'),['Active'])]),kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[Ip==b?kq:null])),lq),['Completed'])])]),S(a.a)?kk(iq,xk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[mq])),Bh(Qm.prototype.mb,Qm,[a])),[nq]):null]));return c}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Hi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Li(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&vb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Hi(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ji(a.b,g)}e&&tb(a.e,a.b)}else{e&&tb(a.e,new Ni)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Xp!=(k.b.c&Yp)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function am(a){var b,c;c=(jb(a.c),a.p.props['a']);b=(ib(c.a),c.d);return kk('li',uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[b?sq:null,S(a.d)?'editing':null])),[kk('div',uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,['view'])),[kk(rq,Ck(zk(Fk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,['toggle'])),(cl(),Jk)),b),Bh(In.prototype.kb,In,[c])),null),kk('label',Hk(new $wnd.Object,Bh(Jn.prototype.mb,Jn,[a,c])),[(ib(c.b),c.e)]),kk(iq,xk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,['destroy'])),Bh(Kn.prototype.mb,Kn,[a,c])),null)]),kk(rq,Dk(Ck(Bk(Ak(uk(vk(new $wnd.Object,Bh(Ln.prototype.A,Ln,[a])),ad(Wc(je,1),Vp,2,6,['edit'])),(ib(a.a),a.g)),Bh(Mn.prototype.jb,Mn,[a,c])),Bh(Hn.prototype.kb,Hn,[a])),Bh(Nn.prototype.lb,Nn,[a,c])),null)])}
function fj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[hq]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!dj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[hq]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Sp='object',Tp='number',Up={11:1},Vp={3:1,4:1},Wp={8:1},Xp=1048576,Yp=1835008,Zp={5:1},$p=2097152,_p=4194304,aq={23:1},bq='__noinit__',cq='__java$exception',dq={3:1,12:1,9:1,6:1},eq='null',fq=17592186044416,gq={44:1},hq='delete',iq='button',jq='footer',kq='selected',lq='#completed',mq='clear-completed',nq='Clear Completed',oq=1478627328,pq={14:1},qq=142606336,rq='input',sq='completed',tq='header',uq='toggle-all',vq='hashchange',wq=136413184,xq='active';var _,wh,rh,jh=-1;xh();zh(1,null,{},o);_.q=yq;_.r=function(){return this.ob};_.s=zq;_.t=function(){var a;return Ph(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.q(a)};_.hashCode=function(){return this.s()};_.toString=function(){return this.t()};var dd,ed,fd;zh(55,1,{},Qh);_.I=function(a){var b;b=new Qh;b.e=4;a>1?(b.c=Uh(this,a-1)):(b.c=this);return b};_.J=function(){Oh(this);return this.b};_.K=function(){return Ph(this)};_.L=function(){Oh(this);return this.i};_.M=function(){return (this.e&4)!=0};_.N=function(){return (this.e&1)!=0};_.t=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Oh(this),this.k)};_.e=0;_.g=0;var Nh=1;var ge=Sh(1);var Zd=Sh(55);zh(99,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var sd=Sh(99);zh(37,1,Up,G);_.u=function(){return this.a.w(),null};var qd=Sh(37);zh(100,1,{},H);var rd=Sh(100);var I;zh(46,1,{46:1},P);_.b=0;_.c=false;_.d=0;var td=Sh(46);zh(237,1,Wp);_.t=function(){var a;return Ph(this.ob)+'@'+(a=r(this)>>>0,a.toString(16))};var wd=Sh(237);zh(20,237,Wp,U);_.v=function(){R(this)};_.a=false;_.d=0;var ud=Sh(20);zh(112,1,{281:1},bb);var vd=Sh(112);zh(15,237,{8:1,15:1},lb);_.v=function(){cb(this)};_.a=4;_.d=false;_.e=0;var yd=Sh(15);zh(166,1,Zp,mb);_.w=function(){db(this.a)};var xd=Sh(166);zh(19,237,{8:1,19:1},yb,zb);_.v=function(){nb(this)};_.c=0;var Dd=Sh(19);zh(167,1,aq,Ab);_.w=function(){Q(this.a)};var zd=Sh(167);zh(168,1,Zp,Bb);_.w=function(){pb(this.a)};var Ad=Sh(168);zh(169,1,Zp,Cb);_.w=function(){sb(this.a)};var Bd=Sh(169);zh(170,1,{},Db);_.A=function(a){qb(this.a,a)};var Cd=Sh(170);zh(113,1,{},Gb);_.a=0;_.b=0;_.c=0;var Ed=Sh(113);zh(209,1,Wp,Ib);_.v=function(){Hb(this)};_.a=false;var Fd=Sh(209);zh(78,237,{8:1,78:1},Nb);_.v=function(){Jb(this)};_.a=0;var Gd=Sh(78);zh(200,1,{},Zb);_.t=function(){var a;return Oh(Hd),Hd.k+'@'+(a=_j(this)>>>0,a.toString(16))};_.a=0;var Ob;var Hd=Sh(200);zh(198,1,Wp,dc);_.v=function(){bc(this)};_.a=false;var Id=Sh(198);zh(128,1,{});var Ld=Sh(128);zh(70,1,{},hc);_.A=function(a){fc(this.a,a)};var Jd=Sh(70);zh(139,1,Zp,ic);_.w=function(){gc(this.a,this.b)};var Kd=Sh(139);zh(129,128,{});var Md=Sh(129);zh(18,1,Wp,mc);_.v=function(){jc(this)};_.t=function(){var a;return Oh(Od),Od.k+'@'+(a=_j(this)>>>0,a.toString(16))};_.e=0;_.i=0;var Od=Sh(18);zh(165,1,Zp,nc);_.w=function(){lc(this.a)};var Nd=Sh(165);zh(6,1,{3:1,6:1});_.B=function(a){return new Error(a)};_.C=function(){return this.f};_.D=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Ph(this.ob),c==null?a:a+': '+c);pc(this,rc(this.B(b)));Tc(this)};_.t=function(){return qc(this,this.C())};_.e=bq;_.g=true;var ke=Sh(6);zh(12,6,{3:1,12:1,6:1});var ae=Sh(12);zh(9,12,dq);var he=Sh(9);zh(56,9,dq);var de=Sh(56);zh(89,56,dq);var Sd=Sh(89);zh(36,89,{36:1,3:1,12:1,9:1,6:1},wc);_.C=function(){vc(this);return this.c};_.F=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Pd=Sh(36);var Qd=Sh(0);zh(216,1,{});var Rd=Sh(216);var yc=0,zc=0,Ac=-1;zh(103,216,{},Oc);var Kc;var Td=Sh(103);var Rc;zh(227,1,{});var Vd=Sh(227);zh(90,227,{},Vc);var Ud=Sh(90);zh(47,1,{47:1,14:1},Gh);_.G=function(){if(this===this.a){this.a=this.b.G();this.b=null}return this.a};var Wd=Sh(47);var Ih;zh(87,1,{84:1});_.t=Aq;var Xd=Sh(87);dd={3:1,85:1,29:1};var Yd=Sh(85);zh(45,1,{3:1,45:1});var fe=Sh(45);ed={3:1,29:1,45:1};var $d=Sh(226);zh(33,1,{3:1,29:1,33:1});_.q=yq;_.s=zq;_.t=function(){return this.a!=null?this.a:''+this.b};_.b=0;var _d=Sh(33);zh(91,9,dq,$h);var be=Sh(91);zh(30,45,{3:1,29:1,30:1,45:1},_h);_.q=function(a){return jd(a,30)&&a.a==this.a};_.s=Aq;_.t=function(){return ''+this.a};_.a=0;var ce=Sh(30);var bi;zh(296,1,{});zh(97,56,dq,ei);_.B=function(a){return new TypeError(a)};var ee=Sh(97);fd={3:1,84:1,29:1,2:1};var je=Sh(2);zh(88,87,{84:1},ki);var ie=Sh(88);zh(300,1,{});zh(58,9,dq,li);var le=Sh(58);zh(228,1,{41:1});_.O=Eq;_.S=function(){return new wj(this,0)};_.T=function(){return new Gj(null,this.S())};_.Q=function(a){throw lh(new li('Add not supported on this collection'))};_.t=function(){var a,b,c;c=new yj('[',']');for(b=this.P();b.V();){a=b.W();xj(c,a===this?'(this Collection)':a==null?eq:Dh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var me=Sh(228);zh(231,1,{215:1});_.q=function(a){var b,c,d;if(a===this){return true}if(!jd(a,39)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new zi((new wi(d)).a);c.b;){b=yi(c);if(!oi(this,b)){return false}}return true};_.s=function(){return Qi(new wi(this))};_.t=function(){var a,b,c;c=new yj('{','}');for(b=new zi((new wi(this)).a);b.b;){a=yi(b);xj(c,pi(this,a.Y())+'='+pi(this,a.Z()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var xe=Sh(231);zh(111,231,{215:1});var pe=Sh(111);zh(230,228,{41:1,251:1});_.S=function(){return new wj(this,1)};_.q=function(a){var b;if(a===this){return true}if(!jd(a,25)){return false}b=a;if(ui(b.a)!=this.R()){return false}return mi(this,b)};_.s=function(){return Qi(this)};var ye=Sh(230);zh(25,230,{25:1,41:1,251:1},wi);_.P=function(){return new zi(this.a)};_.R=Cq;var oe=Sh(25);zh(26,1,{},zi);_.U=Bq;_.W=function(){return yi(this)};_.V=Dq;_.b=false;var ne=Sh(26);zh(229,228,{41:1,245:1});_.S=function(){return new wj(this,16)};_.X=function(a,b){throw lh(new li('Add not supported on this list'))};_.Q=function(a){this.X(this.R(),a);return true};_.q=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,10)){return false}f=a;if(this.R()!=f.a.length){return false}e=new Pi(f);for(c=new Pi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.s=function(){return Ri(this)};_.P=function(){return new Ai(this)};var re=Sh(229);zh(102,1,{},Ai);_.U=Bq;_.V=function(){return this.a<this.b.a.length};_.W=function(){return Hi(this.b,this.a++)};_.a=0;var qe=Sh(102);zh(38,228,{41:1},Bi);_.P=function(){var a;return a=new zi((new wi(this.a)).a),new Ci(a)};_.R=Cq;var te=Sh(38);zh(64,1,{},Ci);_.U=Bq;_.V=function(){return this.a.b};_.W=function(){var a;return a=yi(this.a),a.Z()};var se=Sh(64);zh(109,1,gq);_.q=function(a){var b;if(!jd(a,44)){return false}b=a;return Si(this.a,b.Y())&&Si(this.b,b.Z())};_.Y=Aq;_.Z=Dq;_.s=function(){return rj(this.a)^rj(this.b)};_.$=function(a){var b;b=this.b;this.b=a;return b};_.t=function(){return this.a+'='+this.b};var ue=Sh(109);zh(110,109,gq,Di);var ve=Sh(110);zh(232,1,gq);_.q=function(a){var b;if(!jd(a,44)){return false}b=a;return Si(this.b.value[0],b.Y())&&Si(nj(this),b.Z())};_.s=function(){return rj(this.b.value[0])^rj(nj(this))};_.t=function(){return this.b.value[0]+'='+nj(this)};var we=Sh(232);zh(10,229,{3:1,10:1,41:1,245:1},Ni,Oi);_.X=function(a,b){Vj(this.a,a,b)};_.Q=function(a){return Fi(this,a)};_.O=function(a){Gi(this,a)};_.P=function(){return new Pi(this)};_.R=function(){return this.a.length};var Ae=Sh(10);zh(17,1,{},Pi);_.U=Bq;_.V=function(){return this.a<this.c.a.length};_.W=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ze=Sh(17);zh(39,111,{3:1,39:1,215:1},Ti);var Be=Sh(39);zh(68,1,{},Zi);_.O=Eq;_.P=function(){return new $i(this)};_.b=0;var De=Sh(68);zh(69,1,{},$i);_.U=Bq;_.W=function(){return this.d=this.a[this.c++],this.d};_.V=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ce=Sh(69);var bj;zh(66,1,{},lj);_.O=Eq;_.P=function(){return new mj(this)};_.b=0;_.c=0;var Ge=Sh(66);zh(67,1,{},mj);_.U=Bq;_.W=function(){return this.c=this.a,this.a=this.b.next(),new oj(this.d,this.c,this.d.c)};_.V=function(){return !this.a.done};var Ee=Sh(67);zh(127,232,gq,oj);_.Y=function(){return this.b.value[0]};_.Z=function(){return nj(this)};_.$=function(a){return jj(this.a,this.b.value[0],a)};_.c=0;var Fe=Sh(127);zh(118,1,{});_.U=function(a){tj(this,a)};_._=function(){return this.d};_.ab=function(){return this.e};_.d=0;_.e=0;var Ie=Sh(118);zh(65,118,{});var He=Sh(65);zh(24,1,{},wj);_._=Aq;_.ab=function(){vj(this);return this.c};_.U=function(a){vj(this);this.d.U(a)};_.bb=function(a){vj(this);if(this.d.V()){a.A(this.d.W());return true}return false};_.a=0;_.c=0;var Je=Sh(24);zh(57,1,{},yj);_.t=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ke=Sh(57);zh(117,1,{});_.c=false;var Te=Sh(117);zh(32,117,{},Gj);var Se=Sh(32);zh(120,65,{},Kj);_.bb=function(a){this.b=false;while(!this.b&&this.c.bb(new Lj(this,a)));return this.b};_.b=false;var Me=Sh(120);zh(123,1,{},Lj);_.A=function(a){Jj(this.a,this.b,a)};var Le=Sh(123);zh(119,65,{},Nj);_.bb=function(a){return this.a.bb(new Oj(a))};var Oe=Sh(119);zh(122,1,{},Oj);_.A=function(a){Mj(this.a,a)};var Ne=Sh(122);zh(121,1,{},Qj);_.A=function(a){Pj(this,a)};var Pe=Sh(121);zh(124,1,{},Rj);_.A=function(a){};var Qe=Sh(124);zh(125,1,{},Tj);_.A=function(a){Sj(this,a)};var Re=Sh(125);zh(298,1,{});zh(244,1,{});var Ue=Sh(244);zh(295,1,{});var $j=0;var ak,bk=0,ck;zh(730,1,{});zh(771,1,{});zh(233,1,{});_.eb=Mq;var Ve=Sh(233);zh(31,$wnd.React.Component,{});yh(wh[1],_);_.render=function(){return this.a.fb()};var We=Sh(31);zh(280,$wnd.Function,{},mk);_.db=function(a){lk(this.a,this.b,a)};zh(234,233,{});_.n=false;_.o=false;var qk;var Xe=Sh(234);zh(265,$wnd.Function,{},tk);_.H=function(a){return Hb(qk),qk=null,null};zh(7,33,{3:1,29:1,33:1,7:1},dl);var Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl;var Ye=Th(7,el);zh(238,234,{});_.fb=function(){var a;return a=S(this.f.b),kk(jq,uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[jq])),[(new Tm).a,kk('ul',uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,['filters'])),[kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[(Jp(),Hp)==a?kq:null])),'#'),['All'])]),kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[Gp==a?kq:null])),'#active'),['Active'])]),kk('li',null,[kk('a',wk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[Ip==a?kq:null])),lq),['Completed'])])]),S(this.a)?kk(iq,xk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[mq])),Bh(Qm.prototype.mb,Qm,[this])),[nq]):null])};var Sf=Sh(238);zh(239,238,{});_.fb=function(){return fl(this)};var Wf=Sh(239);zh(72,239,{8:1,72:1},jl);_.v=Iq;_.q=yq;_.ib=Fq;_.s=zq;_.fb=function(){return B((J(),J(),I),this.b,new ml(this))};_.t=function(){var a;return Oh(kf),kf.k+'@'+(a=_j(this)>>>0,a.toString(16))};var gl=0;var kf=Sh(72);zh(172,1,Zp,kl);_.w=function(){hl(this.a)};var Ze=Sh(172);zh(171,1,Zp,ll);_.w=Gq;var $e=Sh(171);zh(175,1,Up,ml);_.u=function(){return fl(this.a)};var _e=Sh(175);zh(173,1,Up,nl);_.u=function(){return il(this.a)};var af=Sh(173);zh(174,1,aq,ol);_.w=Hq;var bf=Sh(174);zh(240,234,{});_.fb=function(){return pl(this)};var Rf=Sh(240);zh(241,240,{});_.fb=function(){return ql(this)};var Vf=Sh(241);zh(73,241,{8:1,73:1},tl);_.v=Jq;_.q=yq;_.ib=Fq;_.s=zq;_.fb=function(){return B((J(),J(),I),this.a,new xl(this))};_.t=function(){var a;return Oh(hf),hf.k+'@'+(a=_j(this)>>>0,a.toString(16))};var rl=0;var hf=Sh(73);zh(177,1,Zp,ul);_.w=function(){sl(this.a)};var cf=Sh(177);zh(176,1,Zp,vl);_.w=Gq;var df=Sh(176);zh(178,1,aq,wl);_.w=Hq;var ef=Sh(178);zh(179,1,Up,xl);_.u=function(){return ql(this.a)};var ff=Sh(179);zh(157,1,pq,yl);_.G=function(){return zl(this.a)};var gf=Sh(157);zh(156,1,pq,Bl);_.G=function(){return Al(this)};var jf=Sh(156);zh(190,234,{});_.fb=function(){return kk(rq,yk(Ck(Dk(Gk(Ek(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,['new-todo']))),(ib(this.b),this.e)),Bh(Cn.prototype.lb,Cn,[this])),Bh(Dn.prototype.kb,Dn,[this]))),null)};_.e='';var dg=Sh(190);zh(191,190,{});_.fb=function(){return Fl(this)};var Yf=Sh(191);zh(76,191,{8:1,76:1},Ll);_.v=Iq;_.q=yq;_.ib=Fq;_.s=zq;_.fb=function(){return B((J(),J(),I),this.a,new Ol(this))};_.t=function(){var a;return Oh(sf),sf.k+'@'+(a=_j(this)>>>0,a.toString(16))};var Gl=0;var sf=Sh(76);zh(193,1,Zp,Ml);_.w=function(){Hl(this.a)};var lf=Sh(193);zh(192,1,Zp,Nl);_.w=Gq;var mf=Sh(192);zh(195,1,Up,Ol);_.u=function(){return Fl(this.a)};var nf=Sh(195);zh(196,1,Zp,Pl);_.w=function(){Dl(this.a)};var of=Sh(196);zh(197,1,Zp,Ql);_.w=function(){Jl(this.a,this.b)};var pf=Sh(197);zh(194,1,aq,Rl);_.w=Hq;var qf=Sh(194);zh(160,1,pq,Sl);_.G=function(){return Tl(this.a)};var rf=Sh(160);zh(242,234,{});_.eb=function(){mm(this,this.nb())};_.fb=function(){return am(this)};_.i=false;var gg=Sh(242);zh(243,242,{});_.nb=function(){return this.p.props['a']};_.fb=function(){return dm(this)};var $f=Sh(243);zh(74,243,{8:1,74:1},om);_.v=function(){jc(this.e)};_.q=yq;_.ib=Fq;_.nb=function(){return jb(this.c),this.p.props['a']};_.s=zq;_.fb=function(){return B((J(),J(),I),this.b,new rm(this))};_.t=function(){var a;return Oh(Gf),Gf.k+'@'+(a=_j(this)>>>0,a.toString(16))};var em=0;var Gf=Sh(74);zh(181,1,Zp,pm);_.w=function(){fm(this.a)};var tf=Sh(181);zh(180,1,Zp,qm);_.w=Gq;var uf=Sh(180);zh(184,1,Up,rm);_.u=function(){return dm(this.a)};var vf=Sh(184);zh(51,1,Zp,sm);_.w=function(){nm(this.a,oo(this.b))};var wf=Sh(51);zh(75,1,Zp,tm);_.w=function(){$l(this.a,this.b)};var xf=Sh(75);zh(185,1,Zp,um);_.w=function(){Zl(this.a,this.b)};var yf=Sh(185);zh(186,1,Zp,vm);_.w=function(){Yl(this.a,this.b)};var zf=Sh(186);zh(187,1,Zp,wm);_.w=function(){Ul(this.a,this.b)};var Af=Sh(187);zh(188,1,Zp,xm);_.w=function(){_l(this.a)};var Bf=Sh(188);zh(189,1,Up,ym);_.u=function(){return im(this.a,this.b)};var Cf=Sh(189);zh(182,1,Up,zm);_.u=function(){return jm(this.a)};var Df=Sh(182);zh(183,1,aq,Am);_.w=function(){rk(this.a,true)};var Ef=Sh(183);zh(158,1,pq,Cm);_.G=function(){return Bm(this)};var Ff=Sh(158);zh(235,234,{});_.fb=function(){var a;return kk('div',null,[kk('div',null,[kk(tq,uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[tq])),[kk('h1',null,['todos']),(new En).a]),S(this.c.c)?null:kk('section',uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[tq])),[kk(rq,Ck(Fk(uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,[uq])),(cl(),Jk)),Bh(Vn.prototype.kb,Vn,[this])),null),kk('ul',uk(new $wnd.Object,ad(Wc(je,1),Vp,2,6,['todo-list'])),(a=Fj(Ej(S(this.e.c).T()),new Ni),Mi(a,_c(a.a.length))))]),S(this.c.c)?null:(new Rm).a])])};var jg=Sh(235);zh(236,235,{});_.fb=function(){return Fm(this)};var ag=Sh(236);zh(71,236,{8:1,71:1},Im);_.v=Jq;_.q=yq;_.ib=Fq;_.s=zq;_.fb=function(){return B((J(),J(),I),this.a,new Mm(this))};_.t=function(){var a;return Oh(Mf),Mf.k+'@'+(a=_j(this)>>>0,a.toString(16))};var Gm=0;var Mf=Sh(71);zh(162,1,Zp,Jm);_.w=function(){sl(this.a)};var Hf=Sh(162);zh(161,1,Zp,Km);_.w=Gq;var If=Sh(161);zh(163,1,aq,Lm);_.w=Hq;var Jf=Sh(163);zh(164,1,Up,Mm);_.u=function(){return Fm(this.a)};var Kf=Sh(164);zh(159,1,pq,Om);_.G=function(){return Nm(this)};var Lf=Sh(159);zh(247,$wnd.Function,{},Qm);_.mb=function(a){gp(this.a.e)};zh(81,1,{},Rm);var Nf=Sh(81);zh(92,1,pq,Sm);_.G=function(){return Al((new ao(this.a)).a)};var Of=Sh(92);zh(79,1,{},Tm);var Pf=Sh(79);zh(96,1,pq,Um);_.G=function(){return zl((new bo(this.a)).a.a)};var Qf=Sh(96);zh(264,$wnd.Function,{},Zm);_.gb=function(a){return new cn(a)};var $m;var an;zh(104,31,{},cn);_.hb=function(){return Al((new ao(an.a)).a)};_.componentWillUnmount=Kq;var Tf=Sh(104);zh(267,$wnd.Function,{},dn);_.gb=function(a){return new jn(a)};var en;var gn;zh(105,31,{},jn);_.hb=function(){return zl((new bo(gn.a)).a.a)};_.componentWillUnmount=Lq;var Uf=Sh(105);zh(278,$wnd.Function,{},kn);_.gb=function(a){return new pn(a)};var ln;var nn;zh(108,31,{},pn);_.hb=function(){return Tl((new co(nn.a)).a.a)};_.componentWillUnmount=Kq;var Xf=Sh(108);zh(268,$wnd.Function,{},qn);_.gb=function(a){return new vn(a)};var rn;var tn;zh(106,31,{},vn);_.hb=function(){return Bm((new eo(tn.a)).a)};_.componentDidUpdate=function(a){bm(this.a)};_.componentWillUnmount=function(){jc(this.a.e)};_.shouldComponentUpdate=function(a){return gm(this.a,a)};var Zf=Sh(106);zh(277,$wnd.Function,{},wn);_.gb=function(a){return new Bn(a)};var xn;var zn;zh(107,31,{},Bn);_.hb=function(){return Nm((new fo(zn.a)).a)};_.componentWillUnmount=Lq;var _f=Sh(107);zh(249,$wnd.Function,{},Cn);_.lb=function(a){El(this.a,a)};zh(250,$wnd.Function,{},Dn);_.kb=function(a){Il(this.a,a)};zh(80,1,{},En);var bg=Sh(80);zh(95,1,pq,Fn);_.G=function(){return Tl((new co(this.a)).a.a)};var cg=Sh(95);zh(275,$wnd.Function,{},Hn);_.kb=function(a){hm(this.a,a)};zh(269,$wnd.Function,{},In);_.kb=function(a){Io(this.a)};zh(271,$wnd.Function,{},Jn);_.mb=function(a){km(this.a,this.b)};zh(272,$wnd.Function,{},Kn);_.mb=function(a){Vl(this.a,this.b)};zh(273,$wnd.Function,{},Ln);_.A=function(a){Wl(this.a,a)};zh(274,$wnd.Function,{},Mn);_.jb=function(a){lm(this.a,this.b)};zh(276,$wnd.Function,{},Nn);_.lb=function(a){Xl(this.a,this.b,a)};zh(210,1,{},Rn);var eg=Sh(210);zh(93,1,pq,Sn);_.G=function(){return Bm((new eo(this.a)).a)};var fg=Sh(93);zh(248,$wnd.Function,{},Vn);_.kb=function(a){Em(this.a,a)};zh(83,1,{},Wn);var hg=Sh(83);zh(94,1,pq,Xn);_.G=function(){return Nm((new fo(this.a)).a)};var ig=Sh(94);zh(101,1,{},_n);var pg=Sh(101);zh(59,1,{},ao);var kg=Sh(59);zh(63,1,{},bo);var lg=Sh(63);zh(62,1,{},co);var mg=Sh(62);zh(60,1,{},eo);var ng=Sh(60);zh(61,1,{},fo);var og=Sh(61);zh(201,1,{});var Zg=Sh(201);zh(202,201,Wp,so);_.v=Iq;_.q=yq;_.s=zq;_.t=function(){var a;return Oh(xg),xg.k+'@'+(a=_j(this)>>>0,a.toString(16))};var xg=Sh(202);zh(203,1,Zp,to);_.w=function(){mo(this.a)};var qg=Sh(203);zh(205,1,aq,uo);_.w=function(){ho(this.a)};var rg=Sh(205);zh(206,1,aq,vo);_.w=function(){io(this.a)};var sg=Sh(206);zh(208,1,Zp,wo);_.w=function(){po(this.a)};var tg=Sh(208);zh(77,1,Zp,xo);_.w=function(){lo(this.a)};var ug=Sh(77);zh(204,1,Up,yo);_.u=function(){var a;return a=(Jh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var vg=Sh(204);zh(207,1,Zp,zo);_.w=function(){go(this.a,this.b)};var wg=Sh(207);zh(52,1,{52:1});_.d=false;var gh=Sh(52);zh(53,52,{8:1,282:1,53:1,52:1},Jo);_.v=Iq;_.q=function(a){return Co(this,a)};_.s=function(){return this.c.e};_.t=function(){var a;return Oh(Qg),Qg.k+'@'+(a=this.c.e>>>0,a.toString(16))};var Ao=0;var Qg=Sh(53);zh(211,1,Zp,Ko);_.w=function(){Bo(this.a)};var yg=Sh(211);zh(212,1,Zp,Lo);_.w=function(){Fo(this.a)};var zg=Sh(212);zh(48,129,{48:1});var ah=Sh(48);zh(130,48,{8:1,48:1},Uo);_.v=function(){jc(this.f)};_.q=yq;_.s=zq;_.t=function(){var a;return Oh(Jg),Jg.k+'@'+(a=_j(this)>>>0,a.toString(16))};var Jg=Sh(130);zh(132,1,Zp,Vo);_.w=function(){No(this.a)};var Ag=Sh(132);zh(131,1,Zp,Wo);_.w=function(){Ro(this.a)};var Bg=Sh(131);zh(137,1,Zp,Xo);_.w=function(){ec(this.a,this.b,true)};var Cg=Sh(137);zh(138,1,Up,Yo);_.u=function(){return Mo(this.a,this.c,this.b)};_.b=false;var Dg=Sh(138);zh(133,1,Up,Zo);_.u=function(){return So(this.a)};var Eg=Sh(133);zh(134,1,Up,$o);_.u=function(){return ai(qh(Cj(Qo(this.a))))};var Fg=Sh(134);zh(135,1,Up,_o);_.u=function(){return ai(qh(Cj(Dj(Qo(this.a),new Mp))))};var Gg=Sh(135);zh(136,1,Up,ap);_.u=function(){return To(this.a)};var Hg=Sh(136);zh(114,1,pq,dp);_.G=function(){return new Uo};var bp;var Ig=Sh(114);zh(49,1,{49:1});var fh=Sh(49);zh(141,49,{8:1,49:1},kp);_.v=function(){jc(this.a)};_.q=yq;_.s=zq;_.t=function(){var a;return Oh(Pg),Pg.k+'@'+(a=_j(this)>>>0,a.toString(16))};var Pg=Sh(141);zh(142,1,Zp,lp);_.w=Mq;var Kg=Sh(142);zh(143,1,Zp,mp);_.w=function(){hp(this.a,this.b)};_.b=false;var Lg=Sh(143);zh(144,1,Zp,np);_.w=function(){ro(this.b,this.a)};var Mg=Sh(144);zh(145,1,Zp,op);_.w=function(){ip(this.a)};var Ng=Sh(145);zh(115,1,pq,pp);_.G=function(){return new kp(this.a.G())};var Og=Sh(115);zh(50,1,{50:1});var ih=Sh(50);zh(149,50,{8:1,50:1},yp);_.v=function(){jc(this.g)};_.q=yq;_.s=zq;_.t=function(){var a;return Oh(Xg),Xg.k+'@'+(a=_j(this)>>>0,a.toString(16))};var Xg=Sh(149);zh(150,1,Zp,zp);_.w=function(){sp(this.a)};var Rg=Sh(150);zh(151,1,Up,Ap);_.u=function(){var a;return a=oo(this.a.i),gi(xq,a)||gi(sq,a)||gi('',a)?gi(xq,a)?(Jp(),Gp):gi(sq,a)?(Jp(),Ip):(Jp(),Hp):(Jp(),Hp)};var Sg=Sh(151);zh(152,1,Up,Bp);_.u=function(){return up(this.a)};var Tg=Sh(152);zh(153,1,aq,Cp);_.w=function(){vp(this.a)};var Ug=Sh(153);zh(154,1,aq,Dp);_.w=function(){wp(this.a)};var Vg=Sh(154);zh(116,1,pq,Ep);_.G=function(){return new yp(this.a.G())};var Wg=Sh(116);zh(199,1,{},Fp);_.handleEvent=function(a){jo(this.a,a)};var Yg=Sh(199);zh(34,33,{3:1,29:1,33:1,34:1},Kp);var Gp,Hp,Ip;var $g=Th(34,Lp);zh(140,1,{},Mp);_.cb=function(a){return !Eo(a)};var _g=Sh(140);zh(147,1,{},Np);_.cb=function(a){return Eo(a)};var bh=Sh(147);zh(148,1,{},Op);_.A=function(a){Po(this.a,a)};var dh=Sh(148);zh(146,1,{},Pp);_.A=function(a){fp(this.a,a)};_.a=false;var eh=Sh(146);zh(155,1,{},Qp);_.cb=function(a){return rp(this.a,a)};var hh=Sh(155);var Rp=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=uh;sh(Fh);vh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();