function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='5E92BCF873DE4C822558C9A402B31DDD',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '5E92BCF873DE4C822558C9A402B31DDD';function o(){}
function on(){}
function hn(){}
function un(){}
function An(){}
function Gn(){}
function Gk(){}
function bk(){}
function ck(){}
function Ph(){}
function Lh(){}
function Ib(){}
function Ip(){}
function bp(){}
function Qp(){}
function Oc(){}
function Vc(){}
function Ao(){}
function Jo(){}
function pq(){}
function qq(){}
function sr(){}
function sn(a){rn=a}
function mn(a){ln=a}
function yn(a){xn=a}
function En(a){Dn=a}
function Kn(a){Jn=a}
function Tc(a){Sc()}
function Xh(){Xh=Lh}
function Zi(){Qi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function mb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function hc(a){this.a=a}
function nc(a){this.a=a}
function ki(a){this.a=a}
function wi(a){this.a=a}
function Ii(a){this.a=a}
function Ni(a){this.a=a}
function Oi(a){this.a=a}
function Mi(a){this.b=a}
function _i(a){this.c=a}
function _j(a){this.a=a}
function ek(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function Al(a){this.a=a}
function Bl(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Jl(a){this.a=a}
function Kl(a){this.a=a}
function Ml(a){this.a=a}
function Yl(a){this.a=a}
function Zl(a){this.a=a}
function $l(a){this.a=a}
function _l(a){this.a=a}
function bm(a){this.a=a}
function dm(a){this.a=a}
function Bm(a){this.a=a}
function Cm(a){this.a=a}
function Dm(a){this.a=a}
function Jm(a){this.a=a}
function Lm(a){this.a=a}
function Mm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function Wm(a){this.a=a}
function Xm(a){this.a=a}
function $m(a){this.a=a}
function an(a){this.a=a}
function cn(a){this.a=a}
function Mn(a){this.a=a}
function Nn(a){this.a=a}
function Pn(a){this.a=a}
function Rn(a){this.a=a}
function Sn(a){this.a=a}
function Vn(a){this.a=a}
function ao(a){this.a=a}
function eo(a){this.a=a}
function go(a){this.a=a}
function Bo(a){this.a=a}
function Ko(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function np(a){this.a=a}
function op(a){this.a=a}
function yp(a){this.a=a}
function zp(a){this.a=a}
function Cp(a){this.a=a}
function Dp(a){this.a=a}
function Ep(a){this.a=a}
function Fp(a){this.a=a}
function Tp(a){this.a=a}
function Up(a){this.a=a}
function cq(a){this.a=a}
function dq(a){this.a=a}
function eq(a){this.a=a}
function fq(a){this.a=a}
function gq(a){this.a=a}
function hq(a){this.a=a}
function iq(a){this.a=a}
function rq(a){this.a=a}
function sq(a){this.a=a}
function tq(a){this.a=a}
function ak(a,b){a.a=b}
function dn(a,b){a.c=b}
function en(a,b){a.d=b}
function fn(a,b){a.e=b}
function gn(a,b){a.f=b}
function bo(a,b){a.j=b}
function co(a,b){a.k=b}
function Co(a,b){a.b=b}
function Ak(a,b){a.key=b}
function vk(a,b){uk(a,b)}
function Kp(a,b){jp(b,a)}
function hr(a){Bj(this,a)}
function kr(a){oi(this,a)}
function or(){jc(this.c)}
function pr(){jc(this.b)}
function jj(){this.a=sj()}
function xj(){this.a=sj()}
function kc(a){!!a&&a.w()}
function w(a){--a.e;D(a)}
function wh(a){return a.e}
function gb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function kb(a){Yb((J(),a))}
function tb(a,b){a.b=Ej(b)}
function fm(a,b){sp(a.j,b)}
function Jp(a,b){rp(a.b,b)}
function cc(a,b){Ei(a.b,b)}
function dk(a,b){Vj(a.a,b)}
function C(a,b){ab(a.f,b.f)}
function V(a){jd(a,9)&&a.v()}
function qr(){jc(this.a.c)}
function rr(){jc(this.a.b)}
function mr(){this.a.o=true}
function dc(){this.b=new dj}
function J(){J=Lh;I=new F}
function uc(){uc=Lh;tc=new o}
function Lc(){Lc=Lh;Kc=new Oc}
function zo(){zo=Lh;xo=new Ao}
function Io(){Io=Lh;Go=new Jo}
function Hp(){Hp=Lh;Gp=new Ip}
function oj(){oj=Lh;nj=qj()}
function gr(){return this.a}
function jr(){return this.b}
function fr(){return mk(this)}
function si(a,b){return a===b}
function gm(a,b){return a.f=b}
function Ti(a,b){return a.a[b]}
function Lb(a){a.a=-4&a.a|1}
function Ro(a){R(a.a);cb(a.b)}
function ep(a){cb(a.b);cb(a.a)}
function xi(a){sc.call(this,a)}
function nn(a){wk.call(this,a)}
function tn(a){wk.call(this,a)}
function zn(a){wk.call(this,a)}
function Fn(a){wk.call(this,a)}
function Ln(a){wk.call(this,a)}
function er(a){return this===a}
function lr(){return J(),J(),I}
function Wc(a,b){return di(a,b)}
function ik(a,b){a.splice(b,1)}
function ac(a,b,c){Di(a.b,b,c)}
function no(a,b){Co(b,a.b.G())}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function $h(a){Zh(a);return a.k}
function Uj(a,b){a.Q(b);return a}
function sj(){oj();return new nj}
function db(a){J();Xb(a);a.e=-2}
function nr(){Ek(this.a,false)}
function pi(){oc(this);this.D()}
function ir(){return Gi(this.a)}
function Gi(a){return a.a.b+a.b.b}
function W(a){return !!a&&a.c.i<0}
function Eh(){Ch==null&&(Ch=[])}
function Bc(){Bc=Lh;!!(Sc(),Rc)}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function Fl(a){a.o=true;nb(a.a)}
function To(a){ib(a.b);return a.e}
function hp(a){ib(a.a);return a.d}
function Yp(a){ib(a.d);return a.f}
function Ik(a,b){a.ref=b;return a}
function Vj(a,b){ak(a,Uj(a.a,b))}
function Gj(a,b){while(a.bb(b));}
function lo(a,b){Co(b,a.b.b.G())}
function uj(a,b){return a.a.get(b)}
function _c(a){return new Array(a)}
function v(a,b,c){s(a,new H(c),b)}
function gk(a,b,c){a.splice(b,0,c)}
function ql(a,b){ii.call(this,a,b)}
function ic(a,b){this.a=a;this.b=b}
function ii(a,b){this.a=a;this.b=b}
function Pi(a,b){this.a=a;this.b=b}
function Yj(a,b){this.a=a;this.b=b}
function zk(a,b){this.a=a;this.b=b}
function am(a,b){this.a=a;this.b=b}
function Em(a,b){this.a=a;this.b=b}
function Fm(a,b){this.a=a;this.b=b}
function Gm(a,b){this.a=a;this.b=b}
function Hm(a,b){this.a=a;this.b=b}
function Im(a,b){this.a=a;this.b=b}
function Km(a,b){this.a=a;this.b=b}
function Tn(a,b){this.a=a;this.b=b}
function Un(a,b){this.a=a;this.b=b}
function Wn(a,b){this.a=a;this.b=b}
function Xn(a,b){this.a=a;this.b=b}
function cp(a,b){this.a=a;this.b=b}
function Ap(a,b){this.a=a;this.b=b}
function Rp(a,b){this.a=a;this.b=b}
function Sp(a,b){this.b=a;this.a=b}
function nq(a,b){ii.call(this,a,b)}
function Jk(a,b){a.href=b;return a}
function ui(a,b){a.a+=''+b;return a}
function Yn(a){return Zn(new _n,a)}
function Ci(a){return !a?null:a.Z()}
function ld(a){return typeof a===wq}
function od(a){return a==null?null:a}
function Sb(a){return !a.d?a:Sb(a.d)}
function ip(a){jp(a,(ib(a.a),!a.d))}
function Uo(a){So(a,(ib(a.b),a.e))}
function fo(){this.a=Ck((In(),Hn))}
function _m(){this.a=Ck((kn(),jn))}
function _n(){this.a=Ck((Cn(),Bn))}
function bn(){this.a=Ck((qn(),pn))}
function On(){this.a=Ck((wn(),vn))}
function lb(a){this.c=new Zi;this.b=a}
function Fi(a){a.a=new jj;a.b=new xj}
function Qi(a){a.a=Yc(ge,yq,1,0,5,1)}
function Ic(a){$wnd.clearTimeout(a)}
function Dj(a){return a!=null?r(a):0}
function B(a,b,c){return t(a,c,2048,b)}
function A(a,b,c){t(a,new G(b),c,null)}
function hk(a,b){fk(b,0,a,0,b.length)}
function gc(a,b){ec(a,b,false);hb(a.d)}
function Tk(a,b){a.value=b;return a}
function Ok(a,b){a.onBlur=b;return a}
function Kk(a,b){a.onClick=b;return a}
function Pk(a,b){a.onChange=b;return a}
function Mk(a,b){a.checked=b;return a}
function Zj(a,b){a.A($n(Yn(b.c.e),b))}
function uk(a,b){for(var c in a){b(c)}}
function bd(a,b,c){return {l:a,m:b,h:c}}
function ri(a,b){return a.charCodeAt(b)}
function mk(a){return a.$H||(a.$H=++lk)}
function X(a){return !(!!a&&1==(a.c&7))}
function jd(a,b){return a!=null&&gd(a,b)}
function Tl(a){a.o=true;nb(a.a);cb(a.b)}
function ul(a){a.o=true;nb(a.b);R(a.a)}
function sb(a){J();rb(a);vb(a,2,true)}
function ib(a){var b;Tb((J(),b=Ob,b),a)}
function Gb(a){this.d=Ej(a);this.b=100}
function Rh(a){this.b=Ej(a);this.a=this}
function sc(a){this.f=a;oc(this);this.D()}
function Tj(a,b){Oj.call(this,a);this.a=b}
function Qk(a,b){a.onKeyDown=b;return a}
function Lk(a){a.autoFocus=true;return a}
function Zh(a){if(a.k!=null){return}fi(a)}
function pc(a,b){a.e=b;b!=null&&kk(b,Iq,a)}
function Bj(a,b){while(a.V()){dk(b,a.W())}}
function lj(a,b){var c;c=a[Nq];c.call(a,b)}
function kk(b,c,d){try{b[c]=d}catch(a){}}
function qk(){qk=Lh;nk=new o;pk=new o}
function dj(){this.a=new jj;this.b=new xj}
function P(){this.a=Yc(ge,yq,1,100,5,1)}
function T(a){4==(a.f.c&7)&&vb(a.f,5,true)}
function Jb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function $(a,b,c){Lb(Ej(c));K(a.a[b],Ej(c))}
function Zn(a,b){return Ak(a.a,Ej(''+b)),a}
function u(a,b){return new yb(Ej(a),null,b)}
function kd(a){return typeof a==='boolean'}
function nd(a){return typeof a==='string'}
function wp(a){return li(S(a.e).a-S(a.a).a)}
function $p(a){W((ib(a.d),a.f))&&aq(a,null)}
function lp(a){A((J(),J(),I),new op(a),Wq)}
function Lp(a){A((J(),J(),I),new Tp(a),Wq)}
function nm(a){A((J(),J(),I),new Jm(a),Wq)}
function Vo(a){A((J(),J(),I),new _o(a),Wq)}
function fc(a,b){cc(b.c.c,a);jd(b,9)&&b.v()}
function Cc(a,b,c){return a.apply(b,c);var d}
function Nk(a,b){a.defaultValue=b;return a}
function Uk(a,b){a.onDoubleClick=b;return a}
function $n(a,b){a.a.props['a']=b;return a.a}
function oc(a){a.g&&a.e!==Hq&&a.D();return a}
function bi(a){var b;b=ai(a);hi(a,b);return b}
function ni(){ni=Lh;mi=Yc(ce,yq,31,256,0,1)}
function Uh(){Uh=Lh;Th=$wnd.window.document}
function Sc(){Sc=Lh;var a;!Uc();a=new Vc;Rc=a}
function Aj(a,b,c){this.a=a;this.b=b;this.c=c}
function Ol(a,b,c){this.a=a;this.b=b;this.c=c}
function Om(a,b,c){this.a=a;this.b=b;this.c=c}
function Zm(a,b,c){this.a=a;this.b=b;this.c=c}
function Ri(a,b){a.a[a.a.length]=b;return true}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function Ul(a,b){A((J(),J(),I),new am(a,b),Wq)}
function tm(a,b){A((J(),J(),I),new Im(a,b),Wq)}
function wm(a,b){A((J(),J(),I),new Gm(a,b),Wq)}
function xm(a,b){A((J(),J(),I),new Fm(a,b),Wq)}
function ym(a,b){A((J(),J(),I),new Em(a,b),Wq)}
function sp(a,b){A((J(),J(),I),new Ap(a,b),Wq)}
function Op(a,b){A((J(),J(),I),new Rp(a,b),Wq)}
function Vl(a,b){var c;c=b.target;Wl(a,c.value)}
function qb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function Bp(a,b){this.a=a;this.c=b;this.b=false}
function mo(a){this.b=a;this.a=new Bo(this.b.a)}
function ro(a){this.b=a;this.a=new Ml(this.b.a)}
function so(a){this.b=a;this.a=new dm(this.b.b)}
function F(){this.f=new bb;this.a=new Gb(this.f)}
function up(a){oi(new Ni(a.g),new hc(a));Fi(a.g)}
function Fb(a){while(true){if(!Eb(a)){break}}}
function Fo(a){return new Do(Fj((Io(),Go)),a)}
function wo(a){return new vo(Fj((zo(),xo)),a)}
function Rj(a){Nj(a);return new Tj(a,new $j(a.a))}
function Sh(a){Ej(a);return jd(a,49)?a:new Rh(a)}
function um(a,b){return Xh(),om(a,b)?true:false}
function vp(a){return Xh(),0==S(a.e).a?true:false}
function tj(a,b){return !(a.a.get(b)===undefined)}
function vl(a){return Xh(),S(a.d.b).a>0?true:false}
function Vp(a){return si(dr,a)||si(Yq,a)||si('',a)}
function $c(a){return Array.isArray(a)&&a.qb===Ph}
function hd(a){return !Array.isArray(a)&&a.qb===Ph}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Vi(a,b){var c;c=a.a[b];ik(a.a,b);return c}
function Xi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Ki(a){var b;b=a.a.W();a.b=Ji(a);return b}
function Ij(a){if(!a.d){a.d=a.b.P();a.c=a.b.R()}}
function Hb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Mj(a){if(!a.b){Nj(a);a.c=true}else{Mj(a.b)}}
function Wj(a,b,c){if(a.a.cb(c)){a.b=true;b.A(c)}}
function Wl(a,b){var c;c=a.e;if(b!=c){a.e=b;hb(a.b)}}
function zm(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function jp(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function Pm(a,b){var c;c=b.target;Op(a.d,c.checked)}
function cm(a){var b;b=new Xl;en(b,a.a.G());return b}
function Ll(a){var b;b=new Gl;dn(b,a.a.G());return b}
function Hi(a,b){if(b){return Ai(a.a,b)}return false}
function Qj(a,b){Nj(a);return new Tj(a,new Xj(b,a.a))}
function So(a,b){A((J(),J(),I),new cp(a,b),75497472)}
function Xp(a){nb(a.e);nb(a.a);R(a.b);R(a.c);cb(a.d)}
function Dl(a){var b;a.n=false;Fk(a);b=Cl(a);return b}
function Ej(a){if(a==null){throw wh(new pi)}return a}
function Fj(a){if(a==null){throw wh(new qi)}return a}
function tk(){if(ok==256){nk=pk;pk=new o;ok=0}++ok}
function Bh(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function Oj(a){if(!a){this.b=null;new Zi}else{this.b=a}}
function $j(a){Hj.call(this,a.ab(),a._()&-6);this.a=a}
function rm(a){a.o=true;nb(a.b);R(a.d);cb(a.c);cb(a.a)}
function Qo(a){var b;T(a.a);b=S(a.a);si(a.f,b)&&Wo(a,b)}
function Wo(a,b){var c;c=a.e;if(b!=c){a.e=Ej(b);hb(a.b)}}
function ci(a,b){var c;c=ai(a);hi(a,c);c.e=b?8:0;return c}
function Sk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Hj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Jj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function rp(a,b){return t((J(),J(),I),new Bp(a,b),Wq,null)}
function jm(a,b){aq(a.k,b);A((J(),J(),I),new Em(a,b),Wq)}
function jb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function ob(a){C((J(),J(),I),a);0==(a.f.a&Dq)&&D((null,I))}
function Mo(a){Vh((Uh(),$wnd.window.window),br,a.d,false)}
function No(a){Wh((Uh(),$wnd.window.window),br,a.d,false)}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function lc(a){kc(a.g);V(a.c);V(a.a);V(a.d);kc(a.b);kc(a.f)}
function Pb(a){if(a.e){2==(a.e.c&7)||vb(a.e,4,true);rb(a.e)}}
function ei(a){if(a.N()){return null}var b=a.j;return Hh[b]}
function Ck(a){var b;b=Bk(a);b.props={};b.ref=null;return b}
function qc(a,b){var c;c=$h(a.ob);return b==null?c:c+': '+b}
function em(a,b){var c;if(S(a.d)){c=b.target;zm(a,c.value)}}
function oi(a,b){var c,d;for(d=a.P();d.V();){c=d.W();b.A(c)}}
function cj(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function Bi(a,b){return b===a?'(this Map)':b==null?Kq:Oh(b)}
function oq(){mq();return ad(Wc(kh,1),yq,35,0,[jq,lq,kq])}
function qn(){qn=Lh;var a;pn=(a=Mh(on.prototype.gb,on,[]),a)}
function kn(){kn=Lh;var a;jn=(a=Mh(hn.prototype.gb,hn,[]),a)}
function wn(){wn=Lh;var a;vn=(a=Mh(un.prototype.gb,un,[]),a)}
function Cn(){Cn=Lh;var a;Bn=(a=Mh(An.prototype.gb,An,[]),a)}
function In(){In=Lh;var a;Hn=(a=Mh(Gn.prototype.gb,Gn,[]),a)}
function Mp(a,b){var c;Sj(tp(a.b),(c=new Zi,c)).O(new sq(b))}
function di(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.I(b))}
function fj(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function gj(a,b){var c;return ej(b,fj(a,b==null?0:(c=r(b),c|0)))}
function Jh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function Nh(a){function b(){}
;b.prototype=a||{};return new b}
function Nj(a){if(a.b){Nj(a.b)}else if(a.c){throw wh(new ji)}}
function tp(a){ib(a.d);return new Tj(null,new Jj(new Ni(a.g),0))}
function Oo(a,b){b.preventDefault();A((J(),J(),I),new ap(a),Wq)}
function sm(a,b){return t((J(),J(),I),new Km(a,b),75497472,null)}
function im(a,b){A((J(),J(),I),new Em(a,b),Wq);aq(a.k,null)}
function $i(a){Qi(this);hk(this.a,zi(a,Yc(ge,yq,1,Gi(a.a),5,1)))}
function qo(a){this.b=a;this.a=new Ol(this.b.a,this.b.b,this.b.c)}
function to(a){this.b=a;this.a=new Om(this.b.a,this.b.b,this.b.c)}
function uo(a){this.b=a;this.a=new Zm(this.b.a,this.b.b,this.b.c)}
function kj(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function ko(){this.a=Sh((Hp(),Hp(),Gp));this.b=Sh(new Up(this.a))}
function Xj(a,b){Hj.call(this,b.ab(),b._()&-16449);this.a=a;this.c=b}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function eb(a,b){var c,d;Ri(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function aq(a,b){var c;c=a.f;if(!(b==c||!!b&&fp(b,c))){a.f=b;hb(a.d)}}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function Vh(a,b,c,d){a.addEventListener(b,c,(Xh(),d?true:false))}
function Wh(a,b,c,d){a.removeEventListener(b,c,(Xh(),d?true:false))}
function yk(a,b,c){!si(c,'key')&&!si(c,'ref')&&(a[c]=b[c],undefined)}
function Rk(a){a.placeholder='What needs to be done?';return a}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Kj(a,b){!a.a?(a.a=new wi(a.d)):ui(a.a,a.b);ui(a.a,b);return a}
function Sj(a,b){var c;Mj(a);c=new bk;c.a=b;a.a.U(new ek(c));return c.a}
function Pj(a){var b;Mj(a);b=0;while(a.a.bb(new ck)){b=xh(b,1)}return b}
function Np(a){var b;Sj(Qj(tp(a.b),new qq),(b=new Zi,b)).O(new rq(a.b))}
function Pp(a){this.b=Ej(a);J();this.a=new mc(0,null,new Qp,false,false)}
function yj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Lj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Mb(b){try{b.b.w()}catch(a){a=vh(a);if(!jd(a,6))throw wh(a)}}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function Pl(a){var b;b=ti((ib(a.b),a.e));if(b.length>0){Jp(a.d,b);Wl(a,'')}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Nm(a){var b;b=new Am;bo(b,a.a.G());a.b.G();co(b,a.c.G());return b}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function Si(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.A(c)}}
function Zp(a){var b,c;return b=S(a.b),Sj(Qj(tp(a.j),new tq(b)),(c=new Zi,c))}
function Ei(a,b){return nd(b)?b==null?ij(a.a,null):wj(a.b,b):ij(a.a,b)}
function Di(a,b,c){return nd(b)?b==null?hj(a.a,null,c):vj(a.b,b,c):hj(a.a,b,c)}
function Wp(a,b){return (mq(),kq)==a||(jq==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function vm(a){return Xh(),Yp(a.k)==(jb(a.c),a.p.props['a'])?true:false}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function zj(a){if(a.a.c!=a.c){return uj(a.a,a.b.value[0])}return a.b.value[1]}
function fp(a,b){var c;if(jd(b,56)){c=b;return a.c.e==c.c.e}else{return false}}
function Wi(a,b){var c;c=Ui(a,b,0);if(c==-1){return false}ik(a.a,c);return true}
function Ui(a,b,c){for(;c<a.a.length;++c){if(cj(b,a.a[c])){return c}}return -1}
function Nl(a){var b;b=new wl;en(b,a.a.G());fn(b,a.b.G());gn(b,a.c.G());return b}
function Ym(a){var b;b=new Tm;dn(b,a.a.G());en(b,a.b.G());fn(b,a.c.G());return b}
function Lo(a,b){a.f=b;si(b,S(a.a))&&Wo(a,b);Po(b);A((J(),J(),I),new ap(a),Wq)}
function jk(a,b){return Xc(b)!=10&&ad(q(b),b.pb,b.__elementTypeId$,Xc(b),a),a}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Ek(a,b){if(!a.n){a.n=true;a.o||(b?a.p.setState({}):a.p.forceUpdate())}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||nb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Fb(a.a)}finally{a.c=false}}}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new mb(a)),0,null);!!a.b&&nb(a.b)}}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new nc(a)),67108864,null)}}
function Ql(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new _l(a),Wq)}}
function ub(b){if(b){try{b.w()}catch(a){a=vh(a);if(jd(a,6)){J()}else throw wh(a)}}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function qp(a){oi(new Ni(a.g),new hc(a));Fi(a.g);R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function Li(a){this.d=a;this.c=new yj(this.d.b);this.a=this.c;this.b=Ji(this)}
function bb(){var a;this.a=Yc(td,yq,48,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Dh(){Eh();var a=Ch;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Mh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function vh(a){var b;if(jd(a,6)){return a}b=a&&a[Iq];if(!b){b=new wc(a);Tc(b)}return b}
function hi(a,b){var c;if(!a){return}b.j=a;var d=ei(b);if(!d){Hh[a]=[b];return}d.ob=b}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Ri((!a.b&&(a.b=new Zi),a.b),b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new Zi);a.c=c.c}b.d=true;Ri(a.c,Ej(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Ej(b))}
function wj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{lj(a.a,b);--a.b}return c}
function ai(a){var b;b=new _h;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function aj(a){var b,c,d;d=0;for(c=new Li(a.a);c.b;){b=Ki(c);d=d+(b?r(b):0);d=d|0}return d}
function rb(a){var b,c;for(c=new _i(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function yi(a,b){var c,d;for(d=new Li(b.a);d.b;){c=Ki(d);if(!Hi(a,c)){return false}}return true}
function yb(a,b,c){xb.call(this,null,a,b,c|(!a?262144:Aq)|(0==(c&6291456)?!a?Dq:Eq:0)|0|0|0)}
function Nb(a,b){this.b=Ej(a);this.a=b|0|(0==(b&6291456)?Eq:0)|(0!=(b&229376)?0:98304)}
function oo(){this.a=Sh((Hp(),Hp(),Gp));this.b=Sh(new Up(this.a));this.c=new Ko(this.a)}
function po(){this.a=Sh((Hp(),Hp(),Gp));this.b=Sh(new Up(this.a));this.c=Sh(new hq(this.a))}
function wk(a){$wnd.React.Component.call(this,a);this.a=this.hb();this.a.p=Ej(this);this.a.eb()}
function ji(){sc.call(this,"Stream already terminated, can't be modified or used")}
function qi(){sc.call(this,'Cannot return null from a non-@Nullable @Provides method')}
function md(a){return a!=null&&(typeof a===vq||typeof a==='function')&&!(a.qb===Ph)}
function Gh(a,b){typeof window===vq&&typeof window['$gwt']===vq&&(window['$gwt'][a]=b)}
function mq(){mq=Lh;jq=new nq('ACTIVE',0);lq=new nq('COMPLETED',1);kq=new nq('ALL',2)}
function pp(a,b,c){var d;d=new mp(b,c);ac(d.c.c,a,new ic(a,d));Di(a.g,li(d.c.e),d);hb(a.d);return d}
function vj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ec(a,b,c){var d;d=Ei(a.g,b?li(b.c.e):null);if(null!=d){cc(b.c.c,a);c&&!!b&&jc(b.c);hb(a.d)}}
function om(a,b){var c,d;d=a.p.props;c=false;if(!(d['a']===b['a'])){hb(a.c);c=true}return c||a.n}
function ej(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(cj(a,c.Y())){return c}}return null}
function Ah(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Lq;d=1048575}c=pd(e/Eq);b=pd(e-c*Eq);return bd(b,c,d)}
function yh(a){var b;b=a.h;if(b==0){return a.l+a.m*Eq}if(b==1048575){return a.l+a.m*Eq-Lq}return a}
function Ji(a){if(a.a.V()){return true}if(a.a!=a.c){return false}a.a=new kj(a.d.a);return a.a.V()}
function S(a){ib(a.e);wb(a.f)&&pb(a.f);if(a.b){if(jd(a.b,8)){throw wh(a.b)}else{throw wh(a.b)}}return a.k}
function _p(a){var b;b=S(a.i.a);si(dr,b)||si(Yq,b)||si('',b)?So(a.i,b):Vp(To(a.i))?Vo(a.i):So(a.i,'')}
function hm(a,b,c){27==c.which?A((J(),J(),I),new Hm(a,b),Wq):13==c.which&&A((J(),J(),I),new Fm(a,b),Wq)}
function nb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Cb(a)),67108864,null);!!a.a&&R(a.a);Jb(a.f);a.c=a.c&-8|1}}
function Fk(a){if(!Dk){Dk=(++a.ib().e,new Ib);$wnd.Promise.resolve(null).then(Mh(Gk.prototype.H,Gk,[]))}}
function ad(a,b,c,d,e){e.ob=a;e.pb=b;e.qb=Ph;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function pm(a){var b,c;a.n=false;Fk(a);b=(jb(a.c),a.p.props['a']);if(!!b&&b.c.i<0){return null}c=mm(a);return c}
function li(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ni(),mi)[b];!c&&(c=mi[b]=new ki(a));return c}return new ki(a)}
function Oh(a){var b;if(Array.isArray(a)&&a.qb===Ph){return $h(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function sk(a){qk();var b,c,d;c=':'+a;d=pk[c];if(d!=null){return pd(d)}d=nk[c];b=d==null?rk(a):pd(d);tk();pk[c]=b;return b}
function wc(a){uc();oc(this);this.e=a;a!=null&&kk(a,Iq,this);this.f=a==null?Kq:Oh(a);this.a='';this.b=a;this.a=''}
function _h(){this.g=Yh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function rl(){pl();return ad(Wc(Ye,1),yq,7,0,[Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il,jl,kl,ll,ml,nl,ol])}
function q(a){return nd(a)?je:ld(a)?$d:kd(a)?Yd:hd(a)?a.ob:$c(a)?a.ob:a.ob||Array.isArray(a)&&Wc(Qd,1)||Qd}
function r(a){return nd(a)?sk(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.s():$c(a)?mk(a):!!a&&!!a.hashCode?a.hashCode():mk(a)}
function p(a,b){return nd(a)?si(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.q(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function fb(a,b){var c,d;d=a.c;Wi(d,b);!!a.b&&Aq!=(a.b.c&Bq)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function xh(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<Lq){return c}}return yh(cd(ld(a)?Ah(a):a,ld(b)?Ah(b):b))}
function km(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){A((J(),J(),I),new Sp(b,c),Wq);aq(a.k,null);zm(a,c)}else{sp(a.j,b)}}
function lm(a){var b;b=S(a.d);if(!a.i&&b){a.i=true;ym(a,(jb(a.c),a.p.props['a']));a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function bc(a){var b,c;if(!a.a){for(c=new _i(new $i(new Ni(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.w()}a.a=true}}
function bj(a){var b,c,d;d=1;for(c=new _i(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Hk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Yi(a,b){var c,d;d=a.a.length;b.length<d&&(b=jk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function gi(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Kb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Aq)?Mb(a):a.b.w();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function zb(a,b){xb.call(this,a,new Ab(a),null,b|(Aq==(b&Bq)?0:524288)|(0==(b&6291456)?Aq==(b&Bq)?Eq:Dq:0)|0|268435456|0)}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Gl(){var a;J();a=++El;this.b=new mc(a,new Il(this),new Hl(this),false,false);this.a=new yb(null,Ej(new Jl(this)),Uq);D((null,I))}
function Tm(){var a;J();a=++Rm;this.b=new mc(a,new Vm(this),new Um(this),false,false);this.a=new yb(null,Ej(new Wm(this)),Uq);D((null,I))}
function mc(a,b,c,d,e){var f;this.e=a;this.c=d?new dc:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new lb((J(),null)),f):null;this.d=null}
function U(a,b,c,d){this.c=Ej(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new zb(this,d);this.e=new lb(this.f);Aq==(d&Bq)&&ob(this.f)}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.pb){return !!a.pb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new _i(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&vb(b,5,true)}}}
function Xb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new _i(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&vb(b,6,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new _i(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?vb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function ti(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function vo(a,b){this.a=Ej(b);a.A(this);(Uh(),$wnd.window.console).log(_q);$wnd.window.console.log('_service=',this.b);$wnd.window.console.log(ar,this.a)}
function Do(a,b){this.a=Ej(b);a.A(this);(Uh(),$wnd.window.console).log(_q);$wnd.window.console.log('_service=',this.b);$wnd.window.console.log(ar,this.a)}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ub(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=Vi(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&vb(c.b,3,true);++b}}}return b}
function s(b,c,d){var e,f;try{$b(b,d);try{f=(c.a.w(),null)}finally{_b()}return f}catch(a){a=vh(a);if(jd(a,6)){e=a;throw wh(e)}else throw wh(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.u()}else{$b(b,e);try{g=c.u()}finally{_b()}}return g}catch(a){a=vh(a);if(jd(a,6)){f=a;throw wh(f)}else throw wh(a)}finally{D(b)}}
function mp(a,b){var c,d,e;this.e=Ej(a);this.d=b;J();c=++dp;this.c=new mc(c,null,new np(this),true,true);this.b=(e=new lb(null),e);this.a=(d=new lb(null),d)}
function Xl(){var a,b;J();a=++Sl;this.c=new mc(a,new Zl(this),new Yl(this),false,false);this.b=(b=new lb(null),b);this.a=new yb(null,Ej(new bm(this)),Uq);D((null,I))}
function wl(){var a;J();a=++tl;this.c=new mc(a,new yl(this),new xl(this),false,false);this.a=new U(new Al(this),null,null,136478720);this.b=new yb(null,Ej(new Bl(this)),Uq);D((null,I))}
function Eb(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Kb(c);return true}
function Fh(b,c,d,e){Eh();var f=Ch;$moduleName=c;$moduleBase=d;uh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{uq(g)()}catch(a){b(c,a)}}else{uq(g)()}}
function Cl(a){var b,c;c=S(a.c.e).a;b='item'+(c==1?'':'s');return xk('span',Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,['todo-count'])),[xk('strong',null,[c]),' '+b+' left'])}
function qj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return rj()}}
function Bk(a){var b;b=new $wnd.Object;b.$$typeof=$wnd.React.Element;b.type=Ej(a);b._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return b}
function zi(a,b){var c,d,e,f,g;g=Gi(a.a);b.length<g&&(b=jk(new Array(g),b));e=(f=new Li((new Ii(a.a)).a),new Oi(f));for(d=0;d<g;++d){b[d]=(c=Ki(e.a),c.Z())}b.length>g&&(b[g]=null);return b}
function Ih(){Hh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].rb()&&(c=Pc(c,g)):g[0].rb()}catch(a){a=vh(a);if(jd(a,6)){d=a;Bc();Hc(jd(d,37)?d.F():d)}else throw wh(a)}}return c}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?Kq:md(b)?b==null?null:b.name:nd(b)?'String':$h(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Rl(a){var b;a.n=false;Fk(a);b=xk(Xq,Lk(Pk(Qk(Tk(Rk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,['new-todo']))),(ib(a.b),a.e)),Mh(Mn.prototype.lb,Mn,[a])),Mh(Nn.prototype.kb,Nn,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.u();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=vh(a);if(jd(a,12)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw wh(c)}else throw wh(a)}}
function hj(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=ej(b,e);if(f){return f.$(c)}}e[e.length]=new Pi(b,c);++a.b;return null}
function fk(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function rk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ri(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Yc(ge,yq,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function pb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.w()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=vh(a);if(jd(a,6)){J()}else throw wh(a)}}}
function Po(a){var b;if(0==a.length){b=(Uh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Th.title,b)}else{(Uh(),$wnd.window.window).location.hash=a}}
function xb(a,b,c,d){this.b=new Zi;this.f=new Nb(new Bb(this),d&6520832|262144|Aq);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Dq)&&D((null,I)))}
function ij(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(cj(b,e.Y())){if(d.length==1){d.length=0;lj(a.a,g)}else{d.splice(h,1)}--a.b;return e.Z()}}return null}
function Kh(a,b,c){var d=Hh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Hh[b]),Nh(h));_.pb=c;!b&&(_.qb=Ph);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ob=f)}
function fi(a){if(a.M()){var b=a.c;b.N()?(a.k='['+b.j):!b.M()?(a.k='[L'+b.K()+';'):(a.k='['+b.K());a.b=b.J()+'[]';a.i=b.L()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=gi('.',[c,gi('$',d)]);a.b=gi('.',[c,gi('.',d)]);a.i=d[d.length-1]}
function Am(){var a,b,c;J();a=++qm;this.e=new mc(a,new Cm(this),new Bm(this),false,false);this.c=(c=new lb(null),c);this.a=(b=new lb(null),b);this.d=new U(new Lm(this),null,null,136478720);this.b=new yb(null,Ej(new Mm(this)),Uq);D((null,I))}
function Ai(a,b){var c,d,e;c=b.Y();e=b.Z();d=nd(c)?c==null?Ci(gj(a.a,null)):uj(a.b,c):Ci(gj(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!gj(a.a,null):tj(a.b,c):!!gj(a.a,c))){return false}return true}
function Xo(){var a,b;this.d=new iq(this);this.f=this.e=(b=(Uh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new mc(0,null,new Yo(this),false,false);this.b=(a=new lb(null),a);this.a=new U(new bp,new Zo(this),new $o(this),35749888)}
function xp(){var a;this.g=new dj;J();this.f=new mc(0,new zp(this),new yp(this),false,false);this.d=(a=new lb(null),a);this.c=new U(new Cp(this),null,null,cr);this.e=new U(new Dp(this),null,null,cr);this.a=new U(new Ep(this),null,null,cr);this.b=new U(new Fp(this),null,null,cr)}
function bq(a){var b;this.j=Ej(a);this.i=new Xo;J();this.g=new mc(0,null,new cq(this),false,false);this.d=(b=new lb(null),b);this.b=new U(new dq(this),null,null,cr);this.c=new U(new eq(this),null,null,cr);this.e=u(new fq(this),413138944);this.a=u(new gq(this),681574400);D((null,I))}
function wb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new _i(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=vh(a);if(!jd(a,6))throw wh(a)}if(6==(b.c&7)){return true}}}}}rb(b);return false}
function Qh(){var a,b,c,d,e;c=new po;mn(new an(c));sn(new cn(c));En(new ao(c));Kn(new go(c));yn(new Pn(c));a=(new mo((d=new ko,zo(),yo=new mo(d),d))).a;Fj(wo(a.a.G()));b=(e=new oo,Io(),Ho=e,e).c;Fj(Fo(b.a.G()));$wnd.ReactDOM.render((new fo).a,(Uh(),Th).getElementById('todoapp'),null)}
function xk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?''+b['key']:null;f='ref' in b?b['ref']:null;vk(b,Mh(zk.prototype.db,zk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=Bk(a),g.key=e,g.ref=f,g.props=Ej(d),g}
function pj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function vb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){kb(a.a.e);ub((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;ub((e=d.i,e));d.k=null}Si(a.b,new Db(a));a.b.a=Yc(ge,yq,1,0,5,1)}else 3==g&&!!a.a&&ub((f=a.a.g,f))}}
function pl(){pl=Lh;Vk=new ql(Oq,0);Wk=new ql('checkbox',1);Xk=new ql('color',2);Yk=new ql('date',3);Zk=new ql('datetime',4);$k=new ql('email',5);_k=new ql('file',6);al=new ql('hidden',7);bl=new ql('image',8);cl=new ql('month',9);dl=new ql(wq,10);el=new ql('password',11);fl=new ql('radio',12);gl=new ql('range',13);hl=new ql('reset',14);il=new ql('search',15);jl=new ql('submit',16);kl=new ql('tel',17);ll=new ql('text',18);ml=new ql('time',19);nl=new ql('url',20);ol=new ql('week',21)}
function Qm(a){var b,c,d;a.n=false;Fk(a);d=xk('div',null,[xk('div',null,[xk(Zq,Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[Zq])),[xk('h1',null,['todos']),(new On).a]),S(a.c.c)?null:xk('section',Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[Zq])),[xk(Xq,Pk(Sk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[$q])),(pl(),Wk)),Mh(eo.prototype.kb,eo,[a])),null),xk('ul',Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,['todo-list'])),(b=Sj(Rj(S(a.e.c).T()),(c=new Zi,c)),Yi(b,_c(b.a.length))))]),S(a.c.c)?null:(new _m).a])]);return d}
function sl(a){var b,c;a.n=false;Fk(a);c=(b=S(a.f.b),xk(Pq,Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[Pq])),[(new bn).a,xk('ul',Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,['filters'])),[xk('li',null,[xk('a',Jk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[(mq(),kq)==b?Qq:null])),'#'),['All'])]),xk('li',null,[xk('a',Jk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[jq==b?Qq:null])),'#active'),['Active'])]),xk('li',null,[xk('a',Jk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[lq==b?Qq:null])),Rq),['Completed'])])]),S(a.a)?xk(Oq,Kk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[Sq])),Mh($m.prototype.mb,$m,[a])),[Tq]):null]));return c}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ti(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Xi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&vb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ti(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Vi(a.b,g)}e&&tb(a.e,a.b)}else{e&&tb(a.e,new Zi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Aq!=(k.b.c&Bq)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function mm(a){var b,c;c=(jb(a.c),a.p.props['a']);b=(ib(c.a),c.d);return xk('li',Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[b?Yq:null,S(a.d)?'editing':null])),[xk('div',Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,['view'])),[xk(Xq,Pk(Mk(Sk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,['toggle'])),(pl(),Wk)),b),Mh(Sn.prototype.kb,Sn,[c])),null),xk('label',Uk(new $wnd.Object,Mh(Tn.prototype.mb,Tn,[a,c])),[(ib(c.b),c.e)]),xk(Oq,Kk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,['destroy'])),Mh(Un.prototype.mb,Un,[a,c])),null)]),xk(Xq,Qk(Pk(Ok(Nk(Hk(Ik(new $wnd.Object,Mh(Vn.prototype.A,Vn,[a])),ad(Wc(je,1),yq,2,6,['edit'])),(ib(a.a),a.g)),Mh(Wn.prototype.jb,Wn,[a,c])),Mh(Rn.prototype.kb,Rn,[a])),Mh(Xn.prototype.lb,Xn,[a,c])),null)])}
function rj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Nq]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!pj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Nq]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var vq='object',wq='number',xq={11:1},yq={3:1,4:1},zq={9:1},Aq=1048576,Bq=1835008,Cq={5:1},Dq=2097152,Eq=4194304,Fq={24:1},Gq={20:1},Hq='__noinit__',Iq='__java$exception',Jq={3:1,12:1,8:1,6:1},Kq='null',Lq=17592186044416,Mq={45:1},Nq='delete',Oq='button',Pq='footer',Qq='selected',Rq='#completed',Sq='clear-completed',Tq='Clear Completed',Uq=1478627328,Vq={14:1},Wq=142606336,Xq='input',Yq='completed',Zq='header',$q='toggle-all',_q='postConstruct',ar='_repository=',br='hashchange',cr=136413184,dr='active';var _,Hh,Ch,uh=-1;Ih();Kh(1,null,{},o);_.q=er;_.r=function(){return this.ob};_.s=fr;_.t=function(){var a;return $h(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.q(a)};_.hashCode=function(){return this.s()};_.toString=function(){return this.t()};var dd,ed,fd;Kh(59,1,{},_h);_.I=function(a){var b;b=new _h;b.e=4;a>1?(b.c=di(this,a-1)):(b.c=this);return b};_.J=function(){Zh(this);return this.b};_.K=function(){return $h(this)};_.L=function(){Zh(this);return this.i};_.M=function(){return (this.e&4)!=0};_.N=function(){return (this.e&1)!=0};_.t=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Zh(this),this.k)};_.e=0;_.g=0;var Yh=1;var ge=bi(1);var Zd=bi(59);Kh(106,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var sd=bi(106);Kh(38,1,xq,G);_.u=function(){return this.a.w(),null};var qd=bi(38);Kh(107,1,{},H);var rd=bi(107);var I;Kh(48,1,{48:1},P);_.b=0;_.c=false;_.d=0;var td=bi(48);Kh(249,1,zq);_.t=function(){var a;return $h(this.ob)+'@'+(a=r(this)>>>0,a.toString(16))};var wd=bi(249);Kh(21,249,zq,U);_.v=function(){R(this)};_.a=false;_.d=0;var ud=bi(21);Kh(121,1,{293:1},bb);var vd=bi(121);Kh(15,249,{9:1,15:1},lb);_.v=function(){cb(this)};_.a=4;_.d=false;_.e=0;var yd=bi(15);Kh(178,1,Cq,mb);_.w=function(){db(this.a)};var xd=bi(178);Kh(19,249,{9:1,19:1},yb,zb);_.v=function(){nb(this)};_.c=0;var Dd=bi(19);Kh(179,1,Fq,Ab);_.w=function(){Q(this.a)};var zd=bi(179);Kh(180,1,Cq,Bb);_.w=function(){pb(this.a)};var Ad=bi(180);Kh(181,1,Cq,Cb);_.w=function(){sb(this.a)};var Bd=bi(181);Kh(182,1,Gq,Db);_.A=function(a){qb(this.a,a)};var Cd=bi(182);Kh(122,1,{},Gb);_.a=0;_.b=0;_.c=0;var Ed=bi(122);Kh(221,1,zq,Ib);_.v=function(){Hb(this)};_.a=false;var Fd=bi(221);Kh(84,249,{9:1,84:1},Nb);_.v=function(){Jb(this)};_.a=0;var Gd=bi(84);Kh(212,1,{},Zb);_.t=function(){var a;return Zh(Hd),Hd.k+'@'+(a=mk(this)>>>0,a.toString(16))};_.a=0;var Ob;var Hd=bi(212);Kh(183,1,zq,dc);_.v=function(){bc(this)};_.a=false;var Id=bi(183);Kh(140,1,{});var Ld=bi(140);Kh(76,1,Gq,hc);_.A=function(a){fc(this.a,a)};var Jd=bi(76);Kh(151,1,Cq,ic);_.w=function(){gc(this.a,this.b)};var Kd=bi(151);Kh(141,140,{});var Md=bi(141);Kh(18,1,zq,mc);_.v=function(){jc(this)};_.t=function(){var a;return Zh(Od),Od.k+'@'+(a=mk(this)>>>0,a.toString(16))};_.e=0;_.i=0;var Od=bi(18);Kh(177,1,Cq,nc);_.w=function(){lc(this.a)};var Nd=bi(177);Kh(6,1,{3:1,6:1});_.B=function(a){return new Error(a)};_.C=function(){return this.f};_.D=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=$h(this.ob),c==null?a:a+': '+c);pc(this,rc(this.B(b)));Tc(this)};_.t=function(){return qc(this,this.C())};_.e=Hq;_.g=true;var ke=bi(6);Kh(12,6,{3:1,12:1,6:1});var ae=bi(12);Kh(8,12,Jq);var he=bi(8);Kh(47,8,Jq);var de=bi(47);Kh(95,47,Jq);var Sd=bi(95);Kh(37,95,{37:1,3:1,12:1,8:1,6:1},wc);_.C=function(){vc(this);return this.c};_.F=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Pd=bi(37);var Qd=bi(0);Kh(228,1,{});var Rd=bi(228);var yc=0,zc=0,Ac=-1;Kh(112,228,{},Oc);var Kc;var Td=bi(112);var Rc;Kh(239,1,{});var Vd=bi(239);Kh(96,239,{},Vc);var Ud=bi(96);Kh(49,1,{49:1,14:1},Rh);_.G=function(){if(this===this.a){this.a=this.b.G();this.b=null}return this.a};var Wd=bi(49);var Th;Kh(93,1,{90:1});_.t=gr;var Xd=bi(93);dd={3:1,91:1,30:1};var Yd=bi(91);Kh(46,1,{3:1,46:1});var fe=bi(46);ed={3:1,30:1,46:1};var $d=bi(238);Kh(34,1,{3:1,30:1,34:1});_.q=er;_.s=fr;_.t=function(){return this.a!=null?this.a:''+this.b};_.b=0;var _d=bi(34);Kh(97,8,Jq,ji);var be=bi(97);Kh(31,46,{3:1,30:1,31:1,46:1},ki);_.q=function(a){return jd(a,31)&&a.a==this.a};_.s=gr;_.t=function(){return ''+this.a};_.a=0;var ce=bi(31);var mi;Kh(308,1,{});Kh(62,47,Jq,pi,qi);_.B=function(a){return new TypeError(a)};var ee=bi(62);fd={3:1,90:1,30:1,2:1};var je=bi(2);Kh(94,93,{90:1},wi);var ie=bi(94);Kh(312,1,{});Kh(61,8,Jq,xi);var le=bi(61);Kh(240,1,{42:1});_.O=kr;_.S=function(){return new Jj(this,0)};_.T=function(){return new Tj(null,this.S())};_.Q=function(a){throw wh(new xi('Add not supported on this collection'))};_.t=function(){var a,b,c;c=new Lj('[',']');for(b=this.P();b.V();){a=b.W();Kj(c,a===this?'(this Collection)':a==null?Kq:Oh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var me=bi(240);Kh(243,1,{227:1});_.q=function(a){var b,c,d;if(a===this){return true}if(!jd(a,40)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Li((new Ii(d)).a);c.b;){b=Ki(c);if(!Ai(this,b)){return false}}return true};_.s=function(){return aj(new Ii(this))};_.t=function(){var a,b,c;c=new Lj('{','}');for(b=new Li((new Ii(this)).a);b.b;){a=Ki(b);Kj(c,Bi(this,a.Y())+'='+Bi(this,a.Z()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var xe=bi(243);Kh(120,243,{227:1});var pe=bi(120);Kh(242,240,{42:1,263:1});_.S=function(){return new Jj(this,1)};_.q=function(a){var b;if(a===this){return true}if(!jd(a,26)){return false}b=a;if(Gi(b.a)!=this.R()){return false}return yi(this,b)};_.s=function(){return aj(this)};var ye=bi(242);Kh(26,242,{26:1,42:1,263:1},Ii);_.P=function(){return new Li(this.a)};_.R=ir;var oe=bi(26);Kh(27,1,{},Li);_.U=hr;_.W=function(){return Ki(this)};_.V=jr;_.b=false;var ne=bi(27);Kh(241,240,{42:1,257:1});_.S=function(){return new Jj(this,16)};_.X=function(a,b){throw wh(new xi('Add not supported on this list'))};_.Q=function(a){this.X(this.R(),a);return true};_.q=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,10)){return false}f=a;if(this.R()!=f.a.length){return false}e=new _i(f);for(c=new _i(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.s=function(){return bj(this)};_.P=function(){return new Mi(this)};var re=bi(241);Kh(111,1,{},Mi);_.U=hr;_.V=function(){return this.a<this.b.a.length};_.W=function(){return Ti(this.b,this.a++)};_.a=0;var qe=bi(111);Kh(39,240,{42:1},Ni);_.P=function(){var a;return a=new Li((new Ii(this.a)).a),new Oi(a)};_.R=ir;var te=bi(39);Kh(68,1,{},Oi);_.U=hr;_.V=function(){return this.a.b};_.W=function(){var a;return a=Ki(this.a),a.Z()};var se=bi(68);Kh(118,1,Mq);_.q=function(a){var b;if(!jd(a,45)){return false}b=a;return cj(this.a,b.Y())&&cj(this.b,b.Z())};_.Y=gr;_.Z=jr;_.s=function(){return Dj(this.a)^Dj(this.b)};_.$=function(a){var b;b=this.b;this.b=a;return b};_.t=function(){return this.a+'='+this.b};var ue=bi(118);Kh(119,118,Mq,Pi);var ve=bi(119);Kh(244,1,Mq);_.q=function(a){var b;if(!jd(a,45)){return false}b=a;return cj(this.b.value[0],b.Y())&&cj(zj(this),b.Z())};_.s=function(){return Dj(this.b.value[0])^Dj(zj(this))};_.t=function(){return this.b.value[0]+'='+zj(this)};var we=bi(244);Kh(10,241,{3:1,10:1,42:1,257:1},Zi,$i);_.X=function(a,b){gk(this.a,a,b)};_.Q=function(a){return Ri(this,a)};_.O=function(a){Si(this,a)};_.P=function(){return new _i(this)};_.R=function(){return this.a.length};var Ae=bi(10);Kh(17,1,{},_i);_.U=hr;_.V=function(){return this.a<this.c.a.length};_.W=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ze=bi(17);Kh(40,120,{3:1,40:1,227:1},dj);var Be=bi(40);Kh(74,1,{},jj);_.O=kr;_.P=function(){return new kj(this)};_.b=0;var De=bi(74);Kh(75,1,{},kj);_.U=hr;_.W=function(){return this.d=this.a[this.c++],this.d};_.V=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ce=bi(75);var nj;Kh(72,1,{},xj);_.O=kr;_.P=function(){return new yj(this)};_.b=0;_.c=0;var Ge=bi(72);Kh(73,1,{},yj);_.U=hr;_.W=function(){return this.c=this.a,this.a=this.b.next(),new Aj(this.d,this.c,this.d.c)};_.V=function(){return !this.a.done};var Ee=bi(73);Kh(138,244,Mq,Aj);_.Y=function(){return this.b.value[0]};_.Z=function(){return zj(this)};_.$=function(a){return vj(this.a,this.b.value[0],a)};_.c=0;var Fe=bi(138);Kh(129,1,{});_.U=function(a){Gj(this,a)};_._=function(){return this.d};_.ab=function(){return this.e};_.d=0;_.e=0;var Ie=bi(129);Kh(71,129,{});var He=bi(71);Kh(25,1,{},Jj);_._=gr;_.ab=function(){Ij(this);return this.c};_.U=function(a){Ij(this);this.d.U(a)};_.bb=function(a){Ij(this);if(this.d.V()){a.A(this.d.W());return true}return false};_.a=0;_.c=0;var Je=bi(25);Kh(60,1,{},Lj);_.t=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ke=bi(60);Kh(128,1,{});_.c=false;var Te=bi(128);Kh(33,128,{},Tj);var Se=bi(33);Kh(131,71,{},Xj);_.bb=function(a){this.b=false;while(!this.b&&this.c.bb(new Yj(this,a)));return this.b};_.b=false;var Me=bi(131);Kh(134,1,Gq,Yj);_.A=function(a){Wj(this.a,this.b,a)};var Le=bi(134);Kh(130,71,{},$j);_.bb=function(a){return this.a.bb(new _j(a))};var Oe=bi(130);Kh(133,1,Gq,_j);_.A=function(a){Zj(this.a,a)};var Ne=bi(133);Kh(132,1,Gq,bk);_.A=function(a){ak(this,a)};var Pe=bi(132);Kh(135,1,Gq,ck);_.A=function(a){};var Qe=bi(135);Kh(136,1,Gq,ek);_.A=function(a){dk(this,a)};var Re=bi(136);Kh(310,1,{});Kh(256,1,{});var Ue=bi(256);Kh(307,1,{});var lk=0;var nk,ok=0,pk;Kh(330,1,{});Kh(787,1,{});Kh(245,1,{});_.eb=sr;var Ve=bi(245);Kh(32,$wnd.React.Component,{});Jh(Hh[1],_);_.render=function(){return this.a.fb()};var We=bi(32);Kh(292,$wnd.Function,{},zk);_.db=function(a){yk(this.a,this.b,a)};Kh(246,245,{});_.n=false;_.o=false;var Dk;var Xe=bi(246);Kh(277,$wnd.Function,{},Gk);_.H=function(a){return Hb(Dk),Dk=null,null};Kh(7,34,{3:1,30:1,34:1,7:1},ql);var Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il,jl,kl,ll,ml,nl,ol;var Ye=ci(7,rl);Kh(250,246,{});_.fb=function(){var a;return a=S(this.f.b),xk(Pq,Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[Pq])),[(new bn).a,xk('ul',Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,['filters'])),[xk('li',null,[xk('a',Jk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[(mq(),kq)==a?Qq:null])),'#'),['All'])]),xk('li',null,[xk('a',Jk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[jq==a?Qq:null])),'#active'),['Active'])]),xk('li',null,[xk('a',Jk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[lq==a?Qq:null])),Rq),['Completed'])])]),S(this.a)?xk(Oq,Kk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[Sq])),Mh($m.prototype.mb,$m,[this])),[Tq]):null])};var Sf=bi(250);Kh(251,250,{});_.fb=function(){return sl(this)};var Wf=bi(251);Kh(78,251,{9:1,78:1},wl);_.v=or;_.q=er;_.ib=lr;_.s=fr;_.fb=function(){return B((J(),J(),I),this.b,new zl(this))};_.t=function(){var a;return Zh(kf),kf.k+'@'+(a=mk(this)>>>0,a.toString(16))};var tl=0;var kf=bi(78);Kh(186,1,Cq,xl);_.w=function(){ul(this.a)};var Ze=bi(186);Kh(185,1,Cq,yl);_.w=mr;var $e=bi(185);Kh(189,1,xq,zl);_.u=function(){return sl(this.a)};var _e=bi(189);Kh(187,1,xq,Al);_.u=function(){return vl(this.a)};var af=bi(187);Kh(188,1,Fq,Bl);_.w=nr;var bf=bi(188);Kh(252,246,{});_.fb=function(){return Cl(this)};var Rf=bi(252);Kh(253,252,{});_.fb=function(){return Dl(this)};var Vf=bi(253);Kh(79,253,{9:1,79:1},Gl);_.v=pr;_.q=er;_.ib=lr;_.s=fr;_.fb=function(){return B((J(),J(),I),this.a,new Kl(this))};_.t=function(){var a;return Zh(hf),hf.k+'@'+(a=mk(this)>>>0,a.toString(16))};var El=0;var hf=bi(79);Kh(191,1,Cq,Hl);_.w=function(){Fl(this.a)};var cf=bi(191);Kh(190,1,Cq,Il);_.w=mr;var df=bi(190);Kh(192,1,Fq,Jl);_.w=nr;var ef=bi(192);Kh(193,1,xq,Kl);_.u=function(){return Dl(this.a)};var ff=bi(193);Kh(169,1,Vq,Ml);_.G=function(){return Ll(this)};var gf=bi(169);Kh(168,1,Vq,Ol);_.G=function(){return Nl(this)};var jf=bi(168);Kh(204,246,{});_.fb=function(){return xk(Xq,Lk(Pk(Qk(Tk(Rk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,['new-todo']))),(ib(this.b),this.e)),Mh(Mn.prototype.lb,Mn,[this])),Mh(Nn.prototype.kb,Nn,[this]))),null)};_.e='';var dg=bi(204);Kh(205,204,{});_.fb=function(){return Rl(this)};var Yf=bi(205);Kh(82,205,{9:1,82:1},Xl);_.v=or;_.q=er;_.ib=lr;_.s=fr;_.fb=function(){return B((J(),J(),I),this.a,new $l(this))};_.t=function(){var a;return Zh(sf),sf.k+'@'+(a=mk(this)>>>0,a.toString(16))};var Sl=0;var sf=bi(82);Kh(207,1,Cq,Yl);_.w=function(){Tl(this.a)};var lf=bi(207);Kh(206,1,Cq,Zl);_.w=mr;var mf=bi(206);Kh(209,1,xq,$l);_.u=function(){return Rl(this.a)};var nf=bi(209);Kh(210,1,Cq,_l);_.w=function(){Pl(this.a)};var of=bi(210);Kh(211,1,Cq,am);_.w=function(){Vl(this.a,this.b)};var pf=bi(211);Kh(208,1,Fq,bm);_.w=nr;var qf=bi(208);Kh(172,1,Vq,dm);_.G=function(){return cm(this)};var rf=bi(172);Kh(254,246,{});_.eb=function(){ym(this,this.nb())};_.fb=function(){return mm(this)};_.i=false;var gg=bi(254);Kh(255,254,{});_.nb=function(){return this.p.props['a']};_.fb=function(){return pm(this)};var $f=bi(255);Kh(80,255,{9:1,80:1},Am);_.v=function(){jc(this.e)};_.q=er;_.ib=lr;_.nb=function(){return jb(this.c),this.p.props['a']};_.s=fr;_.fb=function(){return B((J(),J(),I),this.b,new Dm(this))};_.t=function(){var a;return Zh(Gf),Gf.k+'@'+(a=mk(this)>>>0,a.toString(16))};var qm=0;var Gf=bi(80);Kh(195,1,Cq,Bm);_.w=function(){rm(this.a)};var tf=bi(195);Kh(194,1,Cq,Cm);_.w=mr;var uf=bi(194);Kh(198,1,xq,Dm);_.u=function(){return pm(this.a)};var vf=bi(198);Kh(54,1,Cq,Em);_.w=function(){zm(this.a,To(this.b))};var wf=bi(54);Kh(81,1,Cq,Fm);_.w=function(){km(this.a,this.b)};var xf=bi(81);Kh(199,1,Cq,Gm);_.w=function(){jm(this.a,this.b)};var yf=bi(199);Kh(200,1,Cq,Hm);_.w=function(){im(this.a,this.b)};var zf=bi(200);Kh(201,1,Cq,Im);_.w=function(){em(this.a,this.b)};var Af=bi(201);Kh(202,1,Cq,Jm);_.w=function(){lm(this.a)};var Bf=bi(202);Kh(203,1,xq,Km);_.u=function(){return um(this.a,this.b)};var Cf=bi(203);Kh(196,1,xq,Lm);_.u=function(){return vm(this.a)};var Df=bi(196);Kh(197,1,Fq,Mm);_.w=function(){Ek(this.a,true)};var Ef=bi(197);Kh(170,1,Vq,Om);_.G=function(){return Nm(this)};var Ff=bi(170);Kh(247,246,{});_.fb=function(){var a;return xk('div',null,[xk('div',null,[xk(Zq,Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[Zq])),[xk('h1',null,['todos']),(new On).a]),S(this.c.c)?null:xk('section',Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[Zq])),[xk(Xq,Pk(Sk(Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,[$q])),(pl(),Wk)),Mh(eo.prototype.kb,eo,[this])),null),xk('ul',Hk(new $wnd.Object,ad(Wc(je,1),yq,2,6,['todo-list'])),(a=Sj(Rj(S(this.e.c).T()),new Zi),Yi(a,_c(a.a.length))))]),S(this.c.c)?null:(new _m).a])])};var jg=bi(247);Kh(248,247,{});_.fb=function(){return Qm(this)};var ag=bi(248);Kh(77,248,{9:1,77:1},Tm);_.v=pr;_.q=er;_.ib=lr;_.s=fr;_.fb=function(){return B((J(),J(),I),this.a,new Xm(this))};_.t=function(){var a;return Zh(Mf),Mf.k+'@'+(a=mk(this)>>>0,a.toString(16))};var Rm=0;var Mf=bi(77);Kh(174,1,Cq,Um);_.w=function(){Fl(this.a)};var Hf=bi(174);Kh(173,1,Cq,Vm);_.w=mr;var If=bi(173);Kh(175,1,Fq,Wm);_.w=nr;var Jf=bi(175);Kh(176,1,xq,Xm);_.u=function(){return Qm(this.a)};var Kf=bi(176);Kh(171,1,Vq,Zm);_.G=function(){return Ym(this)};var Lf=bi(171);Kh(259,$wnd.Function,{},$m);_.mb=function(a){Lp(this.a.e)};Kh(87,1,{},_m);var Nf=bi(87);Kh(98,1,Vq,an);_.G=function(){return Nl((new qo(this.a)).a)};var Of=bi(98);Kh(85,1,{},bn);var Pf=bi(85);Kh(102,1,Vq,cn);_.G=function(){return Ll((new ro(this.a)).a)};var Qf=bi(102);Kh(276,$wnd.Function,{},hn);_.gb=function(a){return new nn(a)};var jn;var ln;Kh(113,32,{},nn);_.hb=function(){return Nl((new qo(ln.a)).a)};_.componentWillUnmount=qr;var Tf=bi(113);Kh(279,$wnd.Function,{},on);_.gb=function(a){return new tn(a)};var pn;var rn;Kh(114,32,{},tn);_.hb=function(){return Ll((new ro(rn.a)).a)};_.componentWillUnmount=rr;var Uf=bi(114);Kh(290,$wnd.Function,{},un);_.gb=function(a){return new zn(a)};var vn;var xn;Kh(117,32,{},zn);_.hb=function(){return cm((new so(xn.a)).a)};_.componentWillUnmount=qr;var Xf=bi(117);Kh(280,$wnd.Function,{},An);_.gb=function(a){return new Fn(a)};var Bn;var Dn;Kh(115,32,{},Fn);_.hb=function(){return Nm((new to(Dn.a)).a)};_.componentDidUpdate=function(a){nm(this.a)};_.componentWillUnmount=function(){jc(this.a.e)};_.shouldComponentUpdate=function(a){return sm(this.a,a)};var Zf=bi(115);Kh(289,$wnd.Function,{},Gn);_.gb=function(a){return new Ln(a)};var Hn;var Jn;Kh(116,32,{},Ln);_.hb=function(){return Ym((new uo(Jn.a)).a)};_.componentWillUnmount=rr;var _f=bi(116);Kh(261,$wnd.Function,{},Mn);_.lb=function(a){Ql(this.a,a)};Kh(262,$wnd.Function,{},Nn);_.kb=function(a){Ul(this.a,a)};Kh(86,1,{},On);var bg=bi(86);Kh(101,1,Vq,Pn);_.G=function(){return cm((new so(this.a)).a)};var cg=bi(101);Kh(287,$wnd.Function,{},Rn);_.kb=function(a){tm(this.a,a)};Kh(281,$wnd.Function,{},Sn);_.kb=function(a){lp(this.a)};Kh(283,$wnd.Function,{},Tn);_.mb=function(a){wm(this.a,this.b)};Kh(284,$wnd.Function,{},Un);_.mb=function(a){fm(this.a,this.b)};Kh(285,$wnd.Function,{},Vn);_.A=function(a){gm(this.a,a)};Kh(286,$wnd.Function,{},Wn);_.jb=function(a){xm(this.a,this.b)};Kh(288,$wnd.Function,{},Xn);_.lb=function(a){hm(this.a,this.b,a)};Kh(222,1,{},_n);var eg=bi(222);Kh(99,1,Vq,ao);_.G=function(){return Nm((new to(this.a)).a)};var fg=bi(99);Kh(260,$wnd.Function,{},eo);_.kb=function(a){Pm(this.a,a)};Kh(89,1,{},fo);var hg=bi(89);Kh(100,1,Vq,go);_.G=function(){return Ym((new uo(this.a)).a)};var ig=bi(100);Kh(109,1,{},ko);var mg=bi(109);Kh(58,1,{},mo);var kg=bi(58);Kh(110,1,{},oo);var lg=bi(110);Kh(108,1,{},po);var sg=bi(108);Kh(63,1,{},qo);var ng=bi(63);Kh(67,1,{},ro);var og=bi(67);Kh(66,1,{},so);var pg=bi(66);Kh(64,1,{},to);var qg=bi(64);Kh(65,1,{},uo);var rg=bi(65);Kh(125,1,{});var Ag=bi(125);Kh(69,125,{69:1},vo);var xg=bi(69);var xo,yo;Kh(103,1,Gq,Ao);_.A=function(a){zo();lo(yo,a)};var yg=bi(103);Kh(139,1,Vq,Bo);_.G=function(){return Fj(wo(this.a.G()))};var zg=bi(139);Kh(127,1,{});var ug=bi(127);Kh(70,127,{70:1},Do);var tg=bi(70);var Go,Ho;Kh(104,1,Gq,Jo);_.A=function(a){Io();no(Ho,a)};var vg=bi(104);Kh(126,1,Vq,Ko);_.G=function(){return Fj(Fo(this.a.G()))};var wg=bi(126);Kh(213,1,{});var jh=bi(213);Kh(214,213,zq,Xo);_.v=or;_.q=er;_.s=fr;_.t=function(){var a;return Zh(Ig),Ig.k+'@'+(a=mk(this)>>>0,a.toString(16))};var Ig=bi(214);Kh(215,1,Cq,Yo);_.w=function(){Ro(this.a)};var Bg=bi(215);Kh(217,1,Fq,Zo);_.w=function(){Mo(this.a)};var Cg=bi(217);Kh(218,1,Fq,$o);_.w=function(){No(this.a)};var Dg=bi(218);Kh(220,1,Cq,_o);_.w=function(){Uo(this.a)};var Eg=bi(220);Kh(83,1,Cq,ap);_.w=function(){Qo(this.a)};var Fg=bi(83);Kh(216,1,xq,bp);_.u=function(){var a;return a=(Uh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var Gg=bi(216);Kh(219,1,Cq,cp);_.w=function(){Lo(this.a,this.b)};var Hg=bi(219);Kh(55,1,{55:1});_.d=false;var rh=bi(55);Kh(56,55,{9:1,294:1,56:1,55:1},mp);_.v=or;_.q=function(a){return fp(this,a)};_.s=function(){return this.c.e};_.t=function(){var a;return Zh(_g),_g.k+'@'+(a=this.c.e>>>0,a.toString(16))};var dp=0;var _g=bi(56);Kh(223,1,Cq,np);_.w=function(){ep(this.a)};var Jg=bi(223);Kh(224,1,Cq,op);_.w=function(){ip(this.a)};var Kg=bi(224);Kh(51,141,{51:1});var mh=bi(51);Kh(142,51,{9:1,51:1},xp);_.v=function(){jc(this.f)};_.q=er;_.s=fr;_.t=function(){var a;return Zh(Ug),Ug.k+'@'+(a=mk(this)>>>0,a.toString(16))};var Ug=bi(142);Kh(144,1,Cq,yp);_.w=function(){qp(this.a)};var Lg=bi(144);Kh(143,1,Cq,zp);_.w=function(){up(this.a)};var Mg=bi(143);Kh(149,1,Cq,Ap);_.w=function(){ec(this.a,this.b,true)};var Ng=bi(149);Kh(150,1,xq,Bp);_.u=function(){return pp(this.a,this.c,this.b)};_.b=false;var Og=bi(150);Kh(145,1,xq,Cp);_.u=function(){return vp(this.a)};var Pg=bi(145);Kh(146,1,xq,Dp);_.u=function(){return li(Bh(Pj(tp(this.a))))};var Qg=bi(146);Kh(147,1,xq,Ep);_.u=function(){return li(Bh(Pj(Qj(tp(this.a),new pq))))};var Rg=bi(147);Kh(148,1,xq,Fp);_.u=function(){return wp(this.a)};var Sg=bi(148);Kh(123,1,Vq,Ip);_.G=function(){return new xp};var Gp;var Tg=bi(123);Kh(52,1,{52:1});var qh=bi(52);Kh(153,52,{9:1,52:1},Pp);_.v=function(){jc(this.a)};_.q=er;_.s=fr;_.t=function(){var a;return Zh($g),$g.k+'@'+(a=mk(this)>>>0,a.toString(16))};var $g=bi(153);Kh(154,1,Cq,Qp);_.w=sr;var Vg=bi(154);Kh(155,1,Cq,Rp);_.w=function(){Mp(this.a,this.b)};_.b=false;var Wg=bi(155);Kh(156,1,Cq,Sp);_.w=function(){Wo(this.b,this.a)};var Xg=bi(156);Kh(157,1,Cq,Tp);_.w=function(){Np(this.a)};var Yg=bi(157);Kh(50,1,Vq,Up);_.G=function(){return new Pp(this.a.G())};var Zg=bi(50);Kh(53,1,{53:1});var th=bi(53);Kh(161,53,{9:1,53:1},bq);_.v=function(){jc(this.g)};_.q=er;_.s=fr;_.t=function(){var a;return Zh(hh),hh.k+'@'+(a=mk(this)>>>0,a.toString(16))};var hh=bi(161);Kh(162,1,Cq,cq);_.w=function(){Xp(this.a)};var ah=bi(162);Kh(163,1,xq,dq);_.u=function(){var a;return a=To(this.a.i),si(dr,a)||si(Yq,a)||si('',a)?si(dr,a)?(mq(),jq):si(Yq,a)?(mq(),lq):(mq(),kq):(mq(),kq)};var bh=bi(163);Kh(164,1,xq,eq);_.u=function(){return Zp(this.a)};var dh=bi(164);Kh(165,1,Fq,fq);_.w=function(){$p(this.a)};var eh=bi(165);Kh(166,1,Fq,gq);_.w=function(){_p(this.a)};var fh=bi(166);Kh(124,1,Vq,hq);_.G=function(){return new bq(this.a.G())};var gh=bi(124);Kh(184,1,{},iq);_.handleEvent=function(a){Oo(this.a,a)};var ih=bi(184);Kh(35,34,{3:1,30:1,34:1,35:1},nq);var jq,kq,lq;var kh=ci(35,oq);Kh(152,1,{},pq);_.cb=function(a){return !hp(a)};var lh=bi(152);Kh(159,1,{},qq);_.cb=function(a){return hp(a)};var nh=bi(159);Kh(160,1,Gq,rq);_.A=function(a){sp(this.a,a)};var oh=bi(160);Kh(158,1,Gq,sq);_.A=function(a){Kp(this.a,a)};_.a=false;var ph=bi(158);Kh(167,1,{},tq);_.cb=function(a){return Wp(this.a,a)};var sh=bi(167);var uq=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=Fh;Dh(Qh);Gh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();