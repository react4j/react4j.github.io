function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='3965BDD21FDC83F8EFC587F54BB7BBD0',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '3965BDD21FDC83F8EFC587F54BB7BBD0';function o(){}
function ih(){}
function eh(){}
function Hb(){}
function Hm(){}
function vm(){}
function zm(){}
function Dm(){}
function Lm(){}
function Kc(){}
function Rc(){}
function pj(){}
function qj(){}
function qo(){}
function Yo(){}
function Zo(){}
function Fk(){}
function Jn(){}
function cn(a){bn=a}
function gn(a){fn=a}
function rm(a){qm=a}
function um(a){tm=a}
function Tm(a){Sm=a}
function Pc(a){Oc()}
function qh(){qh=eh}
function pi(){gi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function lb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function cc(a){this.a=a}
function lc(a){this.a=a}
function Gh(a){this.a=a}
function $h(a){this.a=a}
function di(a){this.a=a}
function ei(a){this.a=a}
function ci(a){this.b=a}
function ri(a){this.c=a}
function nj(a){this.a=a}
function sj(a){this.a=a}
function Ok(a){this.a=a}
function Rk(a){this.a=a}
function Sk(a){this.a=a}
function Tk(a){this.a=a}
function $k(a){this.a=a}
function al(a){this.a=a}
function bl(a){this.a=a}
function cl(a){this.a=a}
function pl(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function tl(a){this.a=a}
function vl(a){this.a=a}
function Sl(a){this.a=a}
function Vl(a){this.a=a}
function Xl(a){this.a=a}
function am(a){this.a=a}
function bm(a){this.a=a}
function jm(a){this.a=a}
function mm(a){this.a=a}
function nm(a){this.a=a}
function om(a){this.a=a}
function Pm(a){this.a=a}
function Qm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function Ym(a){this.a=a}
function dn(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function on(a){this.a=a}
function qn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Hn(a){this.a=a}
function In(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function go(a){this.a=a}
function ho(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function Ro(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function Kp(){fc(this.c)}
function Mp(){fc(this.b)}
function Bi(){this.a=Ki()}
function Pi(){this.a=Ki()}
function gc(a){!!a&&a.u()}
function V(a){!!a&&cb(a)}
function w(a){--a.e;D(a)}
function Gp(a){Ti(this,a)}
function Jp(a){Kh(this,a)}
function gb(a){Vb((J(),a))}
function hb(a){Wb((J(),a))}
function jb(a){Xb((J(),a))}
function so(a,b){Sn(b,a)}
function ro(a,b){$n(a.b,b)}
function rj(a,b){ij(a.a,b)}
function Jj(a,b){Ij(a,b)}
function oj(a,b){a.a=b}
function Kj(a,b){a.key=b}
function sb(a,b){a.b=Wi(b)}
function jc(a,b){Wh(a.e,b)}
function xl(a,b){_n(a.j,b)}
function C(a,b){ab(a.f,b.f)}
function Op(){mb(this.a.a)}
function Dp(){return this.a}
function Ip(){return this.b}
function Qg(a){return a.b}
function Nh(a,b){return a===b}
function yl(a,b){return a.f=b}
function Kb(a){a.a=-4&a.a|1}
function Gk(a){a.d=2;fc(a.c)}
function Uk(a){a.c=2;fc(a.b)}
function El(a){a.e=2;fc(a.d)}
function xn(a){R(a.a);cb(a.b)}
function Kk(a){mb(a.b);R(a.a)}
function Qh(a){pc.call(this,a)}
function Fp(){return Aj(this)}
function ji(a,b){return a.a[b]}
function wj(a,b){a.splice(b,1)}
function ec(a,b,c){Vh(a.e,b,c)}
function Nn(a,b,c){ec(a.c,b,c)}
function Mn(a){cb(a.b);cb(a.a)}
function jl(a){mb(a.a);cb(a.b)}
function th(a){sh(a);return a.k}
function Sc(a,b){return zh(a,b)}
function Ep(a){return this===a}
function Lh(){mc(this);this.A()}
function Gi(){Gi=eh;Fi=Ii()}
function J(){J=eh;I=new F}
function rc(){rc=eh;qc=new o}
function Hc(){Hc=eh;Gc=new Kc}
function po(){po=eh;oo=new qo}
function xc(){xc=eh;!!(Oc(),Nc)}
function Yg(){Wg==null&&(Wg=[])}
function Hp(){return Yh(this.a)}
function Lp(){return this.c.i<0}
function Np(){return this.b.i<0}
function W(a){return !!a&&a.c.i<0}
function Yh(a){return a.a.b+a.b.b}
function db(a){J();Wb(a);a.e=-2}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function ij(a,b){oj(a,hj(a.a,b))}
function Xi(a,b){while(a.$(b));}
function hj(a,b){a.N(b);return a}
function Tj(a,b){a.ref=b;return a}
function zn(a){ib(a.b);return a.e}
function Qn(a){ib(a.a);return a.d}
function Fo(a){ib(a.d);return a.f}
function Ki(){Gi();return new Fi}
function Xc(a){return new Array(a)}
function Pp(a){return 1==this.a.d}
function Qp(a){return 1==this.a.c}
function Mi(a,b){return a.a.get(b)}
function fi(a,b){this.a=a;this.b=b}
function dc(a,b){this.a=a;this.b=b}
function Eh(a,b){this.a=a;this.b=b}
function lj(a,b){this.a=a;this.b=b}
function Rj(a,b){this.a=a;this.b=b}
function ul(a,b){this.a=a;this.b=b}
function Wl(a,b){this.a=a;this.b=b}
function Yl(a,b){this.a=a;this.b=b}
function Zl(a,b){this.a=a;this.b=b}
function $l(a,b){this.a=a;this.b=b}
function _l(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function Zm(a,b){this.a=a;this.b=b}
function $m(a,b){this.a=a;this.b=b}
function Bk(a,b){Eh.call(this,a,b)}
function uj(a,b,c){a.splice(b,0,c)}
function v(a,b,c){s(a,new H(c),b)}
function An(a){yn(a,(ib(a.b),a.e))}
function an(){this.a=Lj((Jm(),Im))}
function en(){this.a=Lj((Nm(),Mm))}
function pm(){this.a=Lj((xm(),wm))}
function sm(){this.a=Lj((Bm(),Am))}
function Rm(){this.a=Lj((Fm(),Em))}
function Kn(a,b){this.a=a;this.b=b}
function io(a,b){this.a=a;this.b=b}
function yo(a,b){this.a=a;this.b=b}
function zo(a,b){this.b=a;this.a=b}
function Wo(a,b){Eh.call(this,a,b)}
function ck(a,b){a.value=b;return a}
function Uj(a,b){a.href=b;return a}
function Ec(a){$wnd.clearTimeout(a)}
function Uh(a){return !a?null:a.W()}
function Rb(a){return !a.d?a:Rb(a.d)}
function Vi(a){return a!=null?r(a):0}
function jd(a){return a==null?null:a}
function gd(a){return typeof a===cp}
function gi(a){a.a=Uc(ae,ep,1,0,5,1)}
function Xh(a){a.a=new Bi;a.b=new Pi}
function kb(a){this.c=new pi;this.b=a}
function Ej(){Ej=eh;Bj=new o;Dj=new o}
function Fc(){uc!=0&&(uc=0);wc=-1}
function Rn(a){Sn(a,(ib(a.a),!a.d))}
function Il(a){mb(a.b);R(a.c);cb(a.a)}
function bc(a,b){_b(a,b,false);hb(a.d)}
function vj(a,b){tj(b,0,a,0,b.length)}
function A(a,b,c){t(a,new G(b),c,null)}
function B(a,b,c){return t(a,c,2048,b)}
function X(a){return !(!!a&&1==(a.c&7))}
function Ph(a){return !a?'null':''+a.a}
function Zc(a,b,c){return {l:a,m:b,h:c}}
function Ij(a,b){for(var c in a){b(c)}}
function Zj(a,b){a.onBlur=b;return a}
function Vj(a,b){a.onClick=b;return a}
function $j(a,b){a.onChange=b;return a}
function Xj(a,b){a.checked=b;return a}
function _j(a,b){a.onKeyDown=b;return a}
function Wj(a){a.autoFocus=true;return a}
function rb(a){J();qb(a);ub(a,2,true)}
function ib(a){var b;Sb((J(),b=Nb,b),a)}
function Fb(a){this.d=Wi(a);this.b=100}
function kh(a){this.b=Wi(a);this.a=this}
function pc(a){this.c=a;mc(this);this.A()}
function ac(a,b){jc(b.c,a);ed(b,9)&&b.s()}
function gj(a,b){bj.call(this,a);this.a=b}
function Mh(a,b){return a.charCodeAt(b)}
function ed(a,b){return a!=null&&cd(a,b)}
function ql(a,b){return new ol(Wi(b),a.a)}
function _k(a,b){return new Zk(Wi(b),a.a)}
function Aj(a){return a.$H||(a.$H=++zj)}
function hd(a){return typeof a==='string'}
function fd(a){return typeof a==='boolean'}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function P(){this.a=Uc(ae,ep,1,100,5,1)}
function vi(){this.a=new Bi;this.b=new Pi}
function sh(a){if(a.k!=null){return}Bh(a)}
function nc(a,b){a.b=b;b!=null&&yj(b,np,a)}
function Ti(a,b){while(a.S()){rj(b,a.T())}}
function Di(a,b){var c;c=a[rp];c.call(a,b)}
function u(a,b){return new xb(Wi(a),null,b)}
function Nl(a){A((J(),J(),I),new bm(a),wp)}
function Bn(a){A((J(),J(),I),new Hn(a),wp)}
function Un(a){A((J(),J(),I),new Xn(a),wp)}
function to(a){A((J(),J(),I),new Ao(a),wp)}
function Ho(a){W((ib(a.d),a.f))&&Jo(a,null)}
function eo(a){return Hh(S(a.e).a-S(a.a).a)}
function yc(a,b,c){return a.apply(b,c);var d}
function yj(b,c,d){try{b[c]=d}catch(a){}}
function $(a,b,c){Kb(Wi(c));K(a.a[b],Wi(c))}
function Si(a,b,c){this.a=a;this.b=b;this.c=c}
function Qk(a,b,c){this.a=a;this.b=b;this.c=c}
function Ul(a,b,c){this.a=a;this.b=b;this.c=c}
function lm(a,b,c){this.a=a;this.b=b;this.c=c}
function Yj(a,b){a.defaultValue=b;return a}
function dk(a,b){a.onDoubleClick=b;return a}
function hi(a,b){a.a[a.a.length]=b;return true}
function mc(a){a.d&&a.b!==mp&&a.A();return a}
function wh(a){var b;b=vh(a);Dh(a,b);return b}
function Jh(){Jh=eh;Ih=Uc(Yd,ep,31,256,0,1)}
function nh(){nh=eh;mh=$wnd.window.document}
function Oc(){Oc=eh;var a;!Qc();a=new Rc;Nc=a}
function Eb(a){while(true){if(!Db(a)){break}}}
function jo(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new bb;this.a=new Fb(this.f)}
function kl(a,b){A((J(),J(),I),new ul(a,b),wp)}
function Jl(a,b){A((J(),J(),I),new _l(a,b),wp)}
function Ll(a,b){A((J(),J(),I),new Zl(a,b),wp)}
function Ml(a,b){A((J(),J(),I),new Yl(a,b),wp)}
function Pl(a,b){A((J(),J(),I),new Wl(a,b),wp)}
function _n(a,b){A((J(),J(),I),new io(a,b),wp)}
function wo(a,b){A((J(),J(),I),new yo(a,b),wp)}
function bo(a){Kh(new di(a.g),new cc(a));Xh(a.g)}
function Gb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Zi(a){if(!a.d){a.d=a.b.M();a.c=a.b.O()}}
function jj(a,b,c){if(a.a._(c)){a.b=true;b.v(c)}}
function pb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function ll(a,b){var c;c=b.target;nl(a,c.value)}
function ai(a){var b;b=a.a.T();a.b=_h(a);return b}
function yh(a){var b;b=vh(a);b.j=a;b.e=1;return b}
function Lc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function li(a,b){var c;c=a.a[b];wj(a.a,b);return c}
function Li(a,b){return !(a.a.get(b)===undefined)}
function Pk(a,b){return new Nk(Wi(b),a.a,a.b,a.c)}
function Tl(a,b){return new Rl(Wi(b),a.a,a.b,a.c)}
function km(a,b){return new im(Wi(b),a.a,a.b,a.c)}
function ej(a){aj(a);return new gj(a,new mj(a.a))}
function lh(a){Wi(a);return ed(a,44)?a:new kh(a)}
function Mk(a){return B((J(),J(),I),a.b,new Tk(a))}
function Yk(a){return B((J(),J(),I),a.a,new cl(a))}
function ml(a){return B((J(),J(),I),a.a,new sl(a))}
function Ol(a){return B((J(),J(),I),a.b,new Vl(a))}
function hm(a){return B((J(),J(),I),a.a,new nm(a))}
function Lk(a){return qh(),S(a.e.b).a>0?true:false}
function co(a){return qh(),0==S(a.e).a?true:false}
function Co(a){return Nh(Cp,a)||Nh(yp,a)||Nh('',a)}
function Wc(a){return Array.isArray(a)&&a.ib===ih}
function dd(a){return !Array.isArray(a)&&a.ib===ih}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Zn(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function _i(a){if(!a.b){aj(a);a.c=true}else{_i(a.b)}}
function Hk(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function Vk(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function Fl(a){if(0==a.e){a.e=1;a.n.forceUpdate()}}
function Hj(){if(Cj==256){Bj=Dj;Dj=new o;Cj=0}++Cj}
function Wi(a){if(a==null){throw Qg(new Lh)}return a}
function Zh(a,b){if(b){return Th(a.a,b)}return false}
function dj(a,b){aj(a);return new gj(a,new kj(b,a.a))}
function yn(a,b){A((J(),J(),I),new Kn(a,b),75497472)}
function cm(a,b){var c;c=b.target;wo(a.e,c.checked)}
function nl(a,b){var c;c=a.f;if(b!=c){a.f=b;hb(a.b)}}
function Ql(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function Sn(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function ni(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function bk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function xh(a,b){var c;c=vh(a);Dh(a,c);c.e=b?8:0;return c}
function Cn(a,b){var c;c=a.e;if(b!=c){a.e=Wi(b);hb(a.b)}}
function wn(a){var b;T(a.a);b=S(a.a);Nh(a.f,b)&&Cn(a,b)}
function Eo(a){mb(a.e);mb(a.a);R(a.b);R(a.c);cb(a.d)}
function Bl(a,b){Jo(a.k,b);A((J(),J(),I),new Wl(a,b),wp)}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Yi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function $i(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function mj(a){Yi.call(this,a.Z(),a.Y()&-6);this.a=a}
function bj(a){if(!a){this.b=null;new pi}else{this.b=a}}
function Ah(a){if(a.K()){return null}var b=a.j;return _g[b]}
function Vg(a){if(gd(a)){return a|0}return a.l|a.m<<22}
function ui(a,b){return jd(a)===jd(b)||a!=null&&p(a,b)}
function $n(a,b){return t((J(),J(),I),new jo(a,b),wp,null)}
function Al(a,b){A((J(),J(),I),new Wl(a,b),wp);Jo(a.k,null)}
function nb(a){C((J(),J(),I),a);0==(a.f.a&jp)&&D((null,I))}
function sn(a){oh((nh(),$wnd.window.window),Ap,a.d,false)}
function tn(a){ph((nh(),$wnd.window.window),Ap,a.d,false)}
function Dc(a){xc();$wnd.setTimeout(function(){throw a},0)}
function Xo(){Vo();return Yc(Sc(Eg,1),ep,33,0,[So,Uo,To])}
function jn(a){return new Qk(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function nn(a){return new Ul(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function pn(a){return new lm(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function Kh(a,b){var c,d;for(d=a.M();d.S();){c=d.T();b.v(c)}}
function wl(a,b){var c;if(S(a.c)){c=b.target;Ql(a,c.value)}}
function uo(a,b){var c;fj(ao(a.b),(c=new pi,c)).L(new _o(b))}
function zh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.F(b))}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function gh(a){function b(){}
;b.prototype=a||{};return new b}
function ak(a){a.placeholder='What needs to be done?';return a}
function Ob(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);qb(a.e)}}
function aj(a){if(a.b){aj(a.b)}else if(a.c){throw Qg(new Fh)}}
function oh(a,b,c,d){a.addEventListener(b,c,(qh(),d?true:false))}
function un(a,b){b.preventDefault();A((J(),J(),I),new In(a),wp)}
function xi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function yi(a,b){var c;return wi(b,xi(a,b==null?0:(c=r(b),c|0)))}
function ao(a){ib(a.d);return new gj(null,new $i(new di(a.g),0))}
function qi(a){gi(this);vj(this.a,Sh(a,Uc(ae,ep,1,Yh(a.a),5,1)))}
function Ci(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function ic(a){gc(a.g);!!a.e&&hc(a);V(a.a);V(a.c);gc(a.b);gc(a.f)}
function xm(){xm=eh;var a;wm=(a=fh(vm.prototype.fb,vm,[]),a)}
function Bm(){Bm=eh;var a;Am=(a=fh(zm.prototype.fb,zm,[]),a)}
function Fm(){Fm=eh;var a;Em=(a=fh(Dm.prototype.fb,Dm,[]),a)}
function Jm(){Jm=eh;var a;Im=(a=fh(Hm.prototype.fb,Hm,[]),a)}
function Nm(){Nm=eh;var a;Mm=(a=fh(Lm.prototype.fb,Lm,[]),a)}
function Kl(a){return qh(),Fo(a.k)==a.n.props['a']?true:false}
function ph(a,b,c,d){a.removeEventListener(b,c,(qh(),d?true:false))}
function Bc(a,b,c){var d;d=zc();try{return yc(a,b,c)}finally{Cc(d)}}
function bh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function oc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function kj(a,b){Yi.call(this,b.Z(),b.Y()&-16449);this.a=a;this.c=b}
function ym(a){$wnd.React.Component.call(this,a);this.a=Pk(qm,this)}
function Cm(a){$wnd.React.Component.call(this,a);this.a=_k(tm,this)}
function Gm(a){$wnd.React.Component.call(this,a);this.a=ql(Sm,this)}
function Km(a){$wnd.React.Component.call(this,a);this.a=Tl(bn,this)}
function Om(a){$wnd.React.Component.call(this,a);this.a=km(fn,this)}
function Qi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function xo(a){this.b=Wi(a);J();this.a=new kc(0,null,null,false,false)}
function cj(a){var b;_i(a);b=0;while(a.a.$(new qj)){b=Rg(b,1)}return b}
function fj(a,b){var c;_i(a);c=new pj;c.a=b;a.a.R(new sj(c));return c.a}
function eb(a,b){var c,d;hi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Jo(a,b){var c;c=a.f;if(!(b==c||!!b&&On(b,c))){a.f=b;hb(a.d)}}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function dl(a){var b;b=Oh((ib(a.b),a.f));if(b.length>0){ro(a.e,b);nl(a,'')}}
function vo(a){var b;fj(dj(ao(a.b),new Zo),(b=new pi,b)).L(new $o(a.b))}
function Lb(b){try{b.b.u()}catch(a){a=Pg(a);if(!ed(a,5))throw Qg(a)}}
function Cc(a){a&&Jc((Hc(),Gc));--uc;if(a){if(wc!=-1){Ec(wc);wc=-1}}}
function kd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Wh(a,b){return hd(b)?b==null?Ai(a.a,null):Oi(a.b,b):Ai(a.a,b)}
function Do(a,b){return (Vo(),To)==a||(So==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function Vh(a,b,c){return hd(b)?b==null?zi(a.a,null,c):Ni(a.b,b,c):zi(a.a,b,c)}
function xj(a,b){return Tc(b)!=10&&Yc(q(b),b.hb,b.__elementTypeId$,Tc(b),a),a}
function rn(a,b){a.f=b;Nh(b,S(a.a))&&Cn(a,b);vn(b);A((J(),J(),I),new In(a),wp)}
function Qj(a,b,c){!Nh(c,'key')&&!Nh(c,'ref')&&(a[c]=b[c],undefined)}
function ki(a,b,c){for(;c<a.a.length;++c){if(ui(b,a.a[c])){return c}}return -1}
function Ri(a){if(a.a.c!=a.c){return Mi(a.a,a.b.value[0])}return a.b.value[1]}
function tc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ac(b){xc();return function(){return Bc(b,this,arguments);var a}}
function On(a,b){var c;if(ed(b,49)){c=b;return a.c.d==c.c.d}else{return false}}
function mi(a,b){var c;c=ki(a,b,0);if(c==-1){return false}wj(a.a,c);return true}
function Uc(a,b,c,d,e,f){var g;g=Vc(e,d);e!=10&&Yc(Sc(a,f),b,c,e,g);return g}
function _m(a,b){Kj(a.a,Ph(b?Hh(b.c.d):null));Wi(b);a.a.props['a']=b;return a.a}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||mb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new lb(a)),0,null);!!a.b&&mb(a.b)}}
function fc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new lc(a)),67108864,null)}}
function Go(a){var b,c;return b=S(a.b),fj(dj(ao(a.j),new ap(b)),(c=new pi,c))}
function ii(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function bb(){var a;this.a=Uc(pd,ep,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function bi(a){this.d=a;this.c=new Qi(this.d.b);this.a=this.c;this.b=_h(this)}
function Jc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Mc(b,c)}while(a.b);a.b=c}}
function Ic(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Mc(b,c)}while(a.a);a.a=c}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function tb(b){if(b){try{b.u()}catch(a){a=Pg(a);if(ed(a,5)){J()}else throw Qg(a)}}}
function el(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new tl(a),wp)}}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;hi((!a.b&&(a.b=new pi),a.b),b)}}}
function Dh(a,b){var c;if(!a){return}b.j=a;var d=Ah(b);if(!d){_g[a]=[b];return}d.gb=b}
function Pg(a){var b;if(ed(a,5)){return a}b=a&&a[np];if(!b){b=new sc(a);Pc(b)}return b}
function fh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function vh(a){var b;b=new uh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Lj(a){var b;b=Nj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Oj(a){var b;return Mj($wnd.React.StrictMode,null,null,(b={},b[sp]=Wi(a),b))}
function Tc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Fh(){pc.call(this,"Stream already terminated, can't be modified or used")}
function Xg(){Yg();var a=Wg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function qb(a){var b,c;for(c=new ri(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function si(a){var b,c,d;d=0;for(c=new bi(a.a);c.b;){b=ai(c);d=d+(b?r(b):0);d=d|0}return d}
function Rh(a,b){var c,d;for(d=new bi(b.a);d.b;){c=ai(d);if(!Zh(a,c)){return false}}return true}
function Yn(a,b,c){var d;d=new Vn(b,c);Nn(d,a,new dc(a,d));Vh(a.g,Hh(d.c.d),d);hb(a.d);return d}
function Oi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Di(a.a,b);--a.b}return c}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Wi(b))}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new pi);a.c=c.c}b.d=true;hi(a.c,Wi(b))}
function _b(a,b,c){var d;d=Wh(a.g,b?Hh(b.c.d):null);if(null!=d){jc(b.c,a);c&&!!b&&fc(b.c);hb(a.d)}}
function Mj(a,b,c,d){var e;e=Nj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Wi(d);return e}
function wi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(ui(a,c.V())){return c}}return null}
function Ug(a){var b,c,d,e;e=a;d=0;if(e<0){e+=pp;d=1048575}c=kd(e/kp);b=kd(e-c*kp);return Zc(b,c,d)}
function Sg(a){var b;b=a.h;if(b==0){return a.l+a.m*kp}if(b==1048575){return a.l+a.m*kp-pp}return a}
function _h(a){if(a.a.S()){return true}if(a.a!=a.c){return false}a.a=new Ci(a.d.a);return a.a.S()}
function hn(){this.a=lh((po(),po(),oo));this.b=lh(new Bo(this.a));this.c=lh(new Qo(this.a))}
function Vo(){Vo=eh;So=new Wo('ACTIVE',0);Uo=new Wo('COMPLETED',1);To=new Wo('ALL',2)}
function Mb(a,b){this.b=Wi(a);this.a=b|0|(0==(b&6291456)?kp:0)|(0!=(b&229376)?0:98304)}
function xb(a,b,c){wb.call(this,null,a,b,c|(!a?262144:gp)|(0==(c&6291456)?!a?jp:kp:0)|0|0|0)}
function zl(a,b,c){27==c.which?A((J(),J(),I),new $l(a,b),wp):13==c.which&&A((J(),J(),I),new Yl(a,b),wp)}
function mb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Bb(a)),67108864,null);!!a.a&&R(a.a);Ib(a.f);a.c=a.c&-8|1}}
function Ek(){if(!Dk){Dk=(++(J(),J(),I).e,new Hb);$wnd.Promise.resolve(null).then(fh(Fk.prototype.D,Fk,[]))}}
function Io(a){var b;b=S(a.i.a);Nh(Cp,b)||Nh(yp,b)||Nh('',b)?yn(a.i,b):Co(zn(a.i))?Bn(a.i):yn(a.i,'')}
function sc(a){rc();mc(this);this.b=a;a!=null&&yj(a,np,this);this.c=a==null?'null':hh(a);this.a=a}
function uh(){this.g=rh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Ni(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Yc(a,b,c,d,e){e.gb=a;e.hb=b;e.ib=ih;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function S(a){ib(a.e);vb(a.f)&&ob(a.f);if(a.b){if(ed(a.b,8)){throw Qg(a.b)}else{throw Qg(a.b)}}return a.k}
function q(a){return hd(a)?ce:gd(a)?Ud:fd(a)?Sd:dd(a)?a.gb:Wc(a)?a.gb:a.gb||Array.isArray(a)&&Sc(Ld,1)||Ld}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&gp)?Lb(a):a.b.u();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function fb(a,b){var c,d;d=a.c;mi(d,b);!!a.b&&gp!=(a.b.c&hp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function $c(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return Zc(c&4194303,d&4194303,e&1048575)}
function $g(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Hh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Jh(),Ih)[b];!c&&(c=Ih[b]=new Gh(a));return c}return new Gh(a)}
function hh(a){var b;if(Array.isArray(a)&&a.ib===ih){return th(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Gj(a){Ej();var b,c,d;c=':'+a;d=Dj[c];if(d!=null){return kd(d)}d=Bj[c];b=d==null?Fj(a):kd(d);Hj();Dj[c]=b;return b}
function ti(a){var b,c,d;d=1;for(c=new ri(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=li(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function Dl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Pl(a,a.n.props['a']);a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function Cl(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){A((J(),J(),I),new zo(b,c),wp);Jo(a.k,null);Ql(a,c)}else{_n(a.j,b)}}
function Rg(a,b){var c;if(gd(a)&&gd(b)){c=a+b;if(-17592186044416<c&&c<pp){return c}}return Sg($c(gd(a)?Ug(a):a,gd(b)?Ug(b):b))}
function p(a,b){return hd(a)?Nh(a,b):gd(a)?a===b:fd(a)?a===b:dd(a)?a.o(b):Wc(a)?a===b:!!a&&!!a.equals?a.equals(b):jd(a)===jd(b)}
function r(a){return hd(a)?Gj(a):gd(a)?kd(a):fd(a)?a?1231:1237:dd(a)?a.q():Wc(a)?Aj(a):!!a&&!!a.hashCode?a.hashCode():Aj(a)}
function Ck(){Ak();return Yc(Sc(Oe,1),ep,7,0,[ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk])}
function yb(a,b){wb.call(this,a,new zb(a),null,b|(gp==(b&hp)?0:524288)|(0==(b&6291456)?gp==(b&hp)?kp:jp:0)|0|268435456|0)}
function Ch(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function oi(a,b){var c,d;d=a.a.length;b.length<d&&(b=xj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Sh(a,b){var c,d,e;e=Yh(a.a);b.length<e&&(b=xj(new Array(e),b));d=new bi(a.a);for(c=0;c<e;++c){b[c]=ai(d)}b.length>e&&(b[e]=null);return b}
function Sj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function zc(){var a;if(uc!=0){a=tc();if(a-vc>2000){vc=a;wc=$wnd.setTimeout(Fc,10)}}if(uc++==0){Ic((Hc(),Gc));return true}return false}
function Qc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function hc(a){var b,c,d;for(c=new ri(new qi(new $h(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.V();ed(d,9)&&d.t()||b.W().u()}}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Wb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ri(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&ub(b,6,true)}}}
function kc(a,b,c,d,e){var f;this.d=a;this.e=d?new vi:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new kb((J(),null)),f):null;this.c=null}
function U(a,b,c,d){this.c=Wi(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new yb(this,d);this.e=new kb(this.f);gp==(d&hp)&&nb(this.f)}
function Vn(a,b){var c,d,e;this.e=Wi(a);this.d=b;J();c=++Ln;this.c=new kc(c,null,new Wn(this),true,true);this.b=(e=new kb(null),e);this.a=(d=new kb(null),d)}
function ol(a,b){var c,d;this.e=Wi(b);this.n=Wi(a);J();c=++il;this.c=new kc(c,null,new pl(this),false,false);this.b=(d=new kb(null),d);this.a=new xb(null,Wi(new vl(this)),vp)}
function Zk(a,b){var c;this.d=Wi(b);this.n=Wi(a);J();c=++Xk;this.b=new kc(c,null,new $k(this),false,false);this.a=new xb(null,Wi(new bl(this)),vp)}
function im(a,b,c,d){var e;this.d=Wi(b);this.e=Wi(c);this.f=Wi(d);this.n=Wi(a);J();e=++gm;this.b=new kc(e,null,new jm(this),false,false);this.a=new xb(null,Wi(new mm(this)),vp)}
function cd(a,b){if(hd(a)){return !!bd[b]}else if(a.hb){return !!a.hb[b]}else if(gd(a)){return !!ad[b]}else if(fd(a)){return !!_c[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Oh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Vc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{Zb(b,d);try{f=(c.a.u(),null)}finally{$b()}return f}catch(a){a=Pg(a);if(ed(a,5)){e=a;throw Qg(e)}else throw Qg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.r()}else{Zb(b,e);try{g=c.r()}finally{$b()}}return g}catch(a){a=Pg(a);if(ed(a,5)){f=a;throw Qg(f)}else throw Qg(a)}finally{D(b)}}
function Db(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Jb(c);return true}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Zg(b,c,d,e){Yg();var f=Wg;$moduleName=c;$moduleBase=d;Og=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{bp(g)()}catch(a){b(c,a)}}else{bp(g)()}}
function Nj(a,b){var c;c=new $wnd.Object;c.$$typeof=Wi(a);c.type=Wi(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ii(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ji()}}
function Wk(a){var b,c,d;a.c=0;Ek();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),Pj('span',Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['todo-count'])),[Pj('strong',null,[c]),' '+d+' left']));return b}
function ah(){_g={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Mc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].jb()&&(c=Lc(c,g)):g[0].jb()}catch(a){a=Pg(a);if(ed(a,5)){d=a;xc();Dc(ed(d,35)?d.B():d)}else throw Qg(a)}}return c}
function hl(a){var b;a.d=0;Ek();b=Pj(xp,Wj($j(_j(ck(ak(Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['new-todo']))),(ib(a.b),a.f)),fh(Pm.prototype.db,Pm,[a])),fh(Qm.prototype.cb,Qm,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.r();if(!(jd(e)===jd(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Pg(a);if(ed(a,11)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Qg(c)}else throw Qg(a)}}
function zi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=wi(b,e);if(f){return f.X(c)}}e[e.length]=new fi(b,c);++a.b;return null}
function tj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Fj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Mh(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Uc(ae,ep,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function ob(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.u()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Pg(a);if(ed(a,5)){J()}else throw Qg(a)}}}
function jh(){var a;a=new hn;rm(jn(new kn(a)));um(new al((new ln(a)).a.a.C()));cn(nn(new on(a)));gn(pn(new qn(a)));Tm(new rl((new mn(a)).a.b.C()));$wnd.ReactDOM.render(Oj([(new en).a]),(nh(),mh).getElementById('app'),null)}
function vn(a){var b;if(0==a.length){b=(nh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',mh.title,b)}else{(nh(),$wnd.window.window).location.hash=a}}
function Nk(a,b,c,d){var e;this.e=Wi(b);this.f=Wi(c);this.g=Wi(d);this.n=Wi(a);J();e=++Jk;this.c=new kc(e,null,new Ok(this),false,false);this.a=new U(new Rk(this),null,null,136478720);this.b=new xb(null,Wi(new Sk(this)),vp)}
function Rl(a,b,c,d){var e,f;this.j=Wi(b);Wi(c);this.k=Wi(d);this.n=Wi(a);J();e=++Hl;this.d=new kc(e,null,new Sl(this),false,false);this.a=(f=new kb(null),f);this.c=new U(new Xl(this),null,null,136478720);this.b=new xb(null,Wi(new am(this)),vp);Pl(this,this.n.props['a'])}
function wb(a,b,c,d){this.b=new pi;this.f=new Mb(new Ab(this),d&6520832|262144|gp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&jp)&&D((null,I)))}
function Ai(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(ui(b,e.V())){if(d.length==1){d.length=0;Di(a.a,g)}else{d.splice(h,1)}--a.b;return e.W()}}return null}
function dh(a,b,c){var d=_g,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=_g[b]),gh(h));_.hb=c;!b&&(_.ib=ih);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.gb=f)}
function Bh(a){if(a.J()){var b=a.c;b.K()?(a.k='['+b.j):!b.J()?(a.k='[L'+b.H()+';'):(a.k='['+b.H());a.b=b.G()+'[]';a.i=b.I()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Ch('.',[c,Ch('$',d)]);a.b=Ch('.',[c,Ch('.',d)]);a.i=d[d.length-1]}
function Th(a,b){var c,d,e;c=b.V();e=b.W();d=hd(c)?c==null?Uh(yi(a.a,null)):Mi(a.b,c):Uh(yi(a.a,c));if(!(jd(e)===jd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(hd(c)?c==null?!!yi(a.a,null):Li(a.b,c):!!yi(a.a,c))){return false}return true}
function Pj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Jj(b,fh(Rj.prototype.ab,Rj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[sp]=c[0],undefined):(d[sp]=c,undefined));return Mj(a,e,f,d)}
function Dn(){var a,b;this.d=new Ro(this);this.f=this.e=(b=(nh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new kc(0,null,new En(this),false,false);this.b=(a=new kb(null),a);this.a=new U(new Jn,new Fn(this),new Gn(this),35749888)}
function fo(){var a;this.g=new vi;J();this.f=new kc(0,new ho(this),new go(this),false,false);this.d=(a=new kb(null),a);this.c=new U(new ko(this),null,null,Bp);this.e=new U(new lo(this),null,null,Bp);this.a=new U(new mo(this),null,null,Bp);this.b=new U(new no(this),null,null,Bp)}
function Ko(a){var b;this.j=Wi(a);this.i=new Dn;J();this.g=new kc(0,null,new Lo(this),false,false);this.d=(b=new kb(null),b);this.b=new U(new Mo(this),null,null,Bp);this.c=new U(new No(this),null,null,Bp);this.e=u(new Oo(this),413138944);this.a=u(new Po(this),681574400);D((null,I))}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ri(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Pg(a);if(!ed(a,5))throw Qg(a)}if(6==(b.c&7)){return true}}}}}qb(b);return false}
function Hi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ub(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){jb(a.a.e);tb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;tb((e=d.i,e));d.k=null}ii(a.b,new Cb(a));a.b.a=Uc(ae,ep,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&tb((f=a.a.g,f))}}
function Ak(){Ak=eh;ek=new Bk(tp,0);fk=new Bk('checkbox',1);gk=new Bk('color',2);hk=new Bk('date',3);ik=new Bk('datetime',4);jk=new Bk('email',5);kk=new Bk('file',6);lk=new Bk('hidden',7);mk=new Bk('image',8);nk=new Bk('month',9);ok=new Bk(cp,10);pk=new Bk('password',11);qk=new Bk('radio',12);rk=new Bk('range',13);sk=new Bk('reset',14);tk=new Bk('search',15);uk=new Bk('submit',16);vk=new Bk('tel',17);wk=new Bk('text',18);xk=new Bk('time',19);yk=new Bk('url',20);zk=new Bk('week',21)}
function fm(a){var b,c,d;a.c=0;Ek();d=Pj('div',null,[Pj('div',null,[Pj(zp,Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[zp])),[Pj('h1',null,['todos']),(new Rm).a]),S(a.d.c)?null:Pj('section',Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[zp])),[Pj(xp,$j(bk(Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['toggle-all'])),(Ak(),fk)),fh(dn.prototype.cb,dn,[a])),null),Pj('ul',Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['todo-list'])),(b=fj(Wi(ej(S(a.f.c).Q())),(c=new pi,c)),oi(b,Xc(b.a.length))))]),S(a.d.c)?null:(new pm).a])]);return d}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ji(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ni(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ji(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){li(a.b,g)}e&&sb(a.e,a.b)}else{e&&sb(a.e,new pi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&gp!=(k.b.c&hp)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function Ik(a){var b,c;a.d=0;Ek();c=(b=S(a.g.b),Pj('footer',Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['footer'])),[(new sm).a,Pj('ul',Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['filters'])),[Pj('li',null,[Pj('a',Uj(Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[(Vo(),To)==b?up:null])),'#'),['All'])]),Pj('li',null,[Pj('a',Uj(Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[So==b?up:null])),'#active'),['Active'])]),Pj('li',null,[Pj('a',Uj(Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[Uo==b?up:null])),'#completed'),['Completed'])])]),S(a.a)?Pj(tp,Vj(Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['clear-completed'])),fh(om.prototype.eb,om,[a])),['Clear Completed']):null]));return c}
function Gl(a){var b,c,d,e;a.e=0;Ek();b=a.n.props['a'];if(b.c.i<0){return null}c=(d=a.n.props['a'],e=(ib(d.a),d.d),Pj('li',Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[e?yp:null,S(a.c)?'editing':null])),[Pj('div',Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['view'])),[Pj(xp,$j(Xj(bk(Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['toggle'])),(Ak(),fk)),e),fh(Vm.prototype.cb,Vm,[d])),null),Pj('label',dk(new $wnd.Object,fh(Wm.prototype.eb,Wm,[a,d])),[(ib(d.b),d.e)]),Pj(tp,Vj(Sj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['destroy'])),fh(Xm.prototype.eb,Xm,[a,d])),null)]),Pj(xp,_j($j(Zj(Yj(Sj(Tj(new $wnd.Object,fh(Ym.prototype.v,Ym,[a])),Yc(Sc(ce,1),ep,2,6,['edit'])),(ib(a.a),a.g)),fh(Zm.prototype.bb,Zm,[a,d])),fh(Um.prototype.cb,Um,[a])),fh($m.prototype.db,$m,[a,d])),null)]));return c}
function Ji(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[rp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Hi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[rp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var cp='number',dp={14:1},ep={3:1,4:1},fp={9:1},gp=1048576,hp=1835008,ip={6:1},jp=2097152,kp=4194304,lp={22:1},mp='__noinit__',np='__java$exception',op={3:1,11:1,8:1,5:1},pp=17592186044416,qp={40:1},rp='delete',sp='children',tp='button',up='selected',vp=1411518464,wp=142606336,xp='input',yp='completed',zp='header',Ap='hashchange',Bp=136413184,Cp='active';var _,_g,Wg,Og=-1;ah();dh(1,null,{},o);_.o=Ep;_.p=function(){return this.gb};_.q=Fp;_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};var _c,ad,bd;dh(54,1,{},uh);_.F=function(a){var b;b=new uh;b.e=4;a>1?(b.c=zh(this,a-1)):(b.c=this);return b};_.G=function(){sh(this);return this.b};_.H=function(){return th(this)};_.I=function(){sh(this);return this.i};_.J=function(){return (this.e&4)!=0};_.K=function(){return (this.e&1)!=0};_.e=0;_.g=0;var rh=1;var ae=wh(1);var Td=wh(54);dh(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var od=wh(81);dh(36,1,dp,G);_.r=function(){return this.a.u(),null};var md=wh(36);dh(82,1,{},H);var nd=wh(82);var I;dh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var pd=wh(43);dh(231,1,fp);var sd=wh(231);dh(20,231,fp,U);_.s=function(){R(this)};_.t=Dp;_.a=false;_.d=0;var qd=wh(20);dh(143,1,{269:1},bb);var rd=wh(143);dh(18,231,{9:1,18:1},kb);_.s=function(){cb(this)};_.t=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var ud=wh(18);dh(178,1,ip,lb);_.u=function(){db(this.a)};var td=wh(178);dh(19,231,{9:1,19:1},xb,yb);_.s=function(){mb(this)};_.t=function(){return 1==(this.c&7)};_.c=0;var zd=wh(19);dh(179,1,lp,zb);_.u=function(){Q(this.a)};var vd=wh(179);dh(180,1,ip,Ab);_.u=function(){ob(this.a)};var wd=wh(180);dh(181,1,ip,Bb);_.u=function(){rb(this.a)};var xd=wh(181);dh(182,1,{},Cb);_.v=function(a){pb(this.a,a)};var yd=wh(182);dh(144,1,{},Fb);_.a=0;_.b=0;_.c=0;var Ad=wh(144);dh(183,1,fp,Hb);_.s=function(){Gb(this)};_.t=Dp;_.a=false;var Bd=wh(183);dh(65,231,{9:1,65:1},Mb);_.s=function(){Ib(this)};_.t=function(){return 2==(3&this.a)};_.a=0;var Cd=wh(65);dh(187,1,{},Yb);_.a=0;var Nb;var Dd=wh(187);dh(156,1,{});var Gd=wh(156);dh(149,1,{},cc);_.v=function(a){ac(this.a,a)};var Ed=wh(149);dh(150,1,ip,dc);_.u=function(){bc(this.a,this.b)};var Fd=wh(150);dh(157,156,{});var Hd=wh(157);dh(17,1,fp,kc);_.s=function(){fc(this)};_.t=function(){return this.i<0};_.d=0;_.i=0;var Jd=wh(17);dh(177,1,ip,lc);_.u=function(){ic(this.a)};var Id=wh(177);dh(5,1,{3:1,5:1});_.w=function(a){return new Error(a)};_.A=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=th(this.gb),c==null?a:a+': '+c);nc(this,oc(this.w(b)));Pc(this)};_.b=mp;_.d=true;var de=wh(5);dh(11,5,{3:1,11:1,5:1});var Wd=wh(11);dh(8,11,op);var be=wh(8);dh(55,8,op);var Zd=wh(55);dh(76,55,op);var Nd=wh(76);dh(35,76,{35:1,3:1,11:1,8:1,5:1},sc);_.B=function(){return jd(this.a)===jd(qc)?null:this.a};var qc;var Kd=wh(35);var Ld=wh(0);dh(213,1,{});var Md=wh(213);var uc=0,vc=0,wc=-1;dh(90,213,{},Kc);var Gc;var Od=wh(90);var Nc;dh(224,1,{});var Qd=wh(224);dh(77,224,{},Rc);var Pd=wh(77);dh(44,1,{44:1,69:1},kh);_.C=function(){if(this===this.a){this.a=this.b.C();this.b=null}return this.a};var Rd=wh(44);var mh;_c={3:1,72:1,30:1};var Sd=wh(72);dh(41,1,{3:1,41:1});var _d=wh(41);ad={3:1,30:1,41:1};var Ud=wh(223);dh(32,1,{3:1,30:1,32:1});_.o=Ep;_.q=Fp;_.b=0;var Vd=wh(32);dh(78,8,op,Fh);var Xd=wh(78);dh(31,41,{3:1,30:1,31:1,41:1},Gh);_.o=function(a){return ed(a,31)&&a.a==this.a};_.q=Dp;_.a=0;var Yd=wh(31);var Ih;dh(287,1,{});dh(79,55,op,Lh);_.w=function(a){return new TypeError(a)};var $d=wh(79);bd={3:1,71:1,30:1,2:1};var ce=wh(2);dh(291,1,{});dh(57,8,op,Qh);var ee=wh(57);dh(225,1,{39:1});_.L=Jp;_.P=function(){return new $i(this,0)};_.Q=function(){return new gj(null,this.P())};_.N=function(a){throw Qg(new Qh('Add not supported on this collection'))};var fe=wh(225);dh(229,1,{212:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ed(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new bi((new $h(d)).a);c.b;){b=ai(c);if(!Th(this,b)){return false}}return true};_.q=function(){return si(new $h(this))};var qe=wh(229);dh(142,229,{212:1});var ie=wh(142);dh(228,225,{39:1,236:1});_.P=function(){return new $i(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ed(a,24)){return false}b=a;if(Yh(b.a)!=this.O()){return false}return Rh(this,b)};_.q=function(){return si(this)};var re=wh(228);dh(24,228,{24:1,39:1,236:1},$h);_.M=function(){return new bi(this.a)};_.O=Hp;var he=wh(24);dh(25,1,{},bi);_.R=Gp;_.T=function(){return ai(this)};_.S=Ip;_.b=false;var ge=wh(25);dh(226,225,{39:1,233:1});_.P=function(){return new $i(this,16)};_.U=function(a,b){throw Qg(new Qh('Add not supported on this list'))};_.N=function(a){this.U(this.O(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ed(a,13)){return false}f=a;if(this.O()!=f.a.length){return false}e=new ri(f);for(c=new ri(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(jd(b)===jd(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return ti(this)};_.M=function(){return new ci(this)};var ke=wh(226);dh(89,1,{},ci);_.R=Gp;_.S=function(){return this.a<this.b.a.length};_.T=function(){return ji(this.b,this.a++)};_.a=0;var je=wh(89);dh(59,225,{39:1},di);_.M=function(){var a;a=new bi((new $h(this.a)).a);return new ei(a)};_.O=Hp;var me=wh(59);dh(141,1,{},ei);_.R=Gp;_.S=function(){return this.a.b};_.T=function(){var a;a=ai(this.a);return a.W()};var le=wh(141);dh(139,1,qp);_.o=function(a){var b;if(!ed(a,40)){return false}b=a;return ui(this.a,b.V())&&ui(this.b,b.W())};_.V=Dp;_.W=Ip;_.q=function(){return Vi(this.a)^Vi(this.b)};_.X=function(a){var b;b=this.b;this.b=a;return b};var ne=wh(139);dh(140,139,qp,fi);var oe=wh(140);dh(230,1,qp);_.o=function(a){var b;if(!ed(a,40)){return false}b=a;return ui(this.b.value[0],b.V())&&ui(Ri(this),b.W())};_.q=function(){return Vi(this.b.value[0])^Vi(Ri(this))};var pe=wh(230);dh(13,226,{3:1,13:1,39:1,233:1},pi,qi);_.U=function(a,b){uj(this.a,a,b)};_.N=function(a){return hi(this,a)};_.L=function(a){ii(this,a)};_.M=function(){return new ri(this)};_.O=function(){return this.a.length};var te=wh(13);dh(16,1,{},ri);_.R=Gp;_.S=function(){return this.a<this.c.a.length};_.T=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var se=wh(16);dh(37,142,{3:1,37:1,212:1},vi);var ue=wh(37);dh(62,1,{},Bi);_.L=Jp;_.M=function(){return new Ci(this)};_.b=0;var we=wh(62);dh(63,1,{},Ci);_.R=Gp;_.T=function(){return this.d=this.a[this.c++],this.d};_.S=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ve=wh(63);var Fi;dh(60,1,{},Pi);_.L=Jp;_.M=function(){return new Qi(this)};_.b=0;_.c=0;var ze=wh(60);dh(61,1,{},Qi);_.R=Gp;_.T=function(){return this.c=this.a,this.a=this.b.next(),new Si(this.d,this.c,this.d.c)};_.S=function(){return !this.a.done};var xe=wh(61);dh(148,230,qp,Si);_.V=function(){return this.b.value[0]};_.W=function(){return Ri(this)};_.X=function(a){return Ni(this.a,this.b.value[0],a)};_.c=0;var ye=wh(148);dh(197,1,{});_.R=function(a){Xi(this,a)};_.Y=function(){return this.d};_.Z=function(){return this.e};_.d=0;_.e=0;var Be=wh(197);dh(66,197,{});var Ae=wh(66);dh(23,1,{},$i);_.Y=Dp;_.Z=function(){Zi(this);return this.c};_.R=function(a){Zi(this);this.d.R(a)};_.$=function(a){Zi(this);if(this.d.S()){a.v(this.d.T());return true}return false};_.a=0;_.c=0;var Ce=wh(23);dh(196,1,{});_.c=false;var Le=wh(196);dh(27,196,{272:1,27:1},gj);var Ke=wh(27);dh(199,66,{},kj);_.$=function(a){this.b=false;while(!this.b&&this.c.$(new lj(this,a)));return this.b};_.b=false;var Ee=wh(199);dh(202,1,{},lj);_.v=function(a){jj(this.a,this.b,a)};var De=wh(202);dh(198,66,{},mj);_.$=function(a){return this.a.$(new nj(a))};var Ge=wh(198);dh(201,1,{},nj);_.v=function(a){this.a.v(_m(new an,a))};var Fe=wh(201);dh(200,1,{},pj);_.v=function(a){oj(this,a)};var He=wh(200);dh(203,1,{},qj);_.v=function(a){};var Ie=wh(203);dh(204,1,{},sj);_.v=function(a){rj(this,a)};var Je=wh(204);dh(289,1,{});dh(232,1,{});var Me=wh(232);dh(286,1,{});var zj=0;var Bj,Cj=0,Dj;dh(860,1,{});dh(888,1,{});dh(227,1,{});var Ne=wh(227);dh(271,$wnd.Function,{},Rj);_.ab=function(a){Qj(this.a,this.b,a)};dh(7,32,{3:1,30:1,32:1,7:1},Bk);var ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk;var Oe=xh(7,Ck);var Dk;dh(270,$wnd.Function,{},Fk);_.D=function(a){return Gb(Dk),Dk=null,null};dh(91,227,{});var Af=wh(91);dh(92,91,{});_.d=0;var Ef=wh(92);dh(93,92,fp,Nk);_.s=Kp;_.o=Ep;_.q=Fp;_.t=Lp;var Jk=0;var Ze=wh(93);dh(95,1,ip,Ok);_.u=function(){Kk(this.a)};var Pe=wh(95);dh(94,1,{},Qk);var Qe=wh(94);dh(96,1,dp,Rk);_.r=function(){return Lk(this.a)};var Re=wh(96);dh(97,1,lp,Sk);_.u=function(){Hk(this.a)};var Se=wh(97);dh(98,1,dp,Tk);_.r=function(){return Ik(this.a)};var Te=wh(98);dh(100,227,{});var zf=wh(100);dh(101,100,{});_.c=0;var Df=wh(101);dh(102,101,fp,Zk);_.s=Mp;_.o=Ep;_.q=Fp;_.t=Np;var Xk=0;var Ye=wh(102);dh(104,1,ip,$k);_.u=Op;var Ue=wh(104);dh(103,1,{},al);var Ve=wh(103);dh(105,1,lp,bl);_.u=function(){Vk(this.a)};var We=wh(105);dh(106,1,dp,cl);_.r=function(){return Wk(this.a)};var Xe=wh(106);dh(129,227,{});_.f='';var Mf=wh(129);dh(130,129,{});_.d=0;var Gf=wh(130);dh(131,130,fp,ol);_.s=Kp;_.o=Ep;_.q=Fp;_.t=Lp;var il=0;var ef=wh(131);dh(133,1,ip,pl);_.u=function(){jl(this.a)};var $e=wh(133);dh(132,1,{},rl);var _e=wh(132);dh(135,1,dp,sl);_.r=function(){return hl(this.a)};var af=wh(135);dh(136,1,ip,tl);_.u=function(){dl(this.a)};var bf=wh(136);dh(137,1,ip,ul);_.u=function(){ll(this.a,this.b)};var cf=wh(137);dh(134,1,lp,vl);_.u=function(){Hk(this.a)};var df=wh(134);dh(108,227,{});_.i=false;var Of=wh(108);dh(109,108,{});_.e=0;var If=wh(109);dh(110,109,fp,Rl);_.s=function(){fc(this.d)};_.o=Ep;_.q=Fp;_.t=function(){return this.d.i<0};var Hl=0;var rf=wh(110);dh(112,1,ip,Sl);_.u=function(){Il(this.a)};var ff=wh(112);dh(111,1,{},Ul);var gf=wh(111);dh(115,1,dp,Vl);_.r=function(){return Gl(this.a)};var hf=wh(115);dh(42,1,ip,Wl);_.u=function(){Ql(this.a,zn(this.b))};var jf=wh(42);dh(113,1,dp,Xl);_.r=function(){return Kl(this.a)};var kf=wh(113);dh(58,1,ip,Yl);_.u=function(){Cl(this.a,this.b)};var lf=wh(58);dh(116,1,ip,Zl);_.u=function(){Bl(this.a,this.b)};var mf=wh(116);dh(117,1,ip,$l);_.u=function(){Al(this.a,this.b)};var nf=wh(117);dh(118,1,ip,_l);_.u=function(){wl(this.a,this.b)};var of=wh(118);dh(114,1,lp,am);_.u=function(){Fl(this.a)};var pf=wh(114);dh(119,1,ip,bm);_.u=function(){Dl(this.a)};var qf=wh(119);dh(121,227,{});var Qf=wh(121);dh(122,121,{});_.c=0;var Kf=wh(122);dh(123,122,fp,im);_.s=Mp;_.o=Ep;_.q=Fp;_.t=Np;var gm=0;var wf=wh(123);dh(125,1,ip,jm);_.u=Op;var sf=wh(125);dh(124,1,{},lm);var tf=wh(124);dh(126,1,lp,mm);_.u=function(){Vk(this.a)};var uf=wh(126);dh(127,1,dp,nm);_.r=function(){return fm(this.a)};var vf=wh(127);dh(252,$wnd.Function,{},om);_.eb=function(a){to(this.a.f)};dh(185,1,{},pm);var xf=wh(185);var qm;dh(207,1,{},sm);var yf=wh(207);var tm;dh(253,$wnd.Function,{},vm);_.fb=function(a){return new ym(a)};var wm;dh(99,$wnd.React.Component,{},ym);bh(_g[1],_);_.componentWillUnmount=function(){Gk(this.a)};_.render=function(){return Mk(this.a)};_.shouldComponentUpdate=Pp;var Bf=wh(99);dh(254,$wnd.Function,{},zm);_.fb=function(a){return new Cm(a)};var Am;dh(107,$wnd.React.Component,{},Cm);bh(_g[1],_);_.componentWillUnmount=function(){Uk(this.a)};_.render=function(){return Yk(this.a)};_.shouldComponentUpdate=Qp;var Cf=wh(107);dh(268,$wnd.Function,{},Dm);_.fb=function(a){return new Gm(a)};var Em;dh(138,$wnd.React.Component,{},Gm);bh(_g[1],_);_.componentWillUnmount=function(){Gk(this.a)};_.render=function(){return ml(this.a)};_.shouldComponentUpdate=Pp;var Ff=wh(138);dh(255,$wnd.Function,{},Hm);_.fb=function(a){return new Km(a)};var Im;dh(120,$wnd.React.Component,{},Km);bh(_g[1],_);_.componentDidUpdate=function(a){Nl(this.a)};_.componentWillUnmount=function(){El(this.a)};_.render=function(){return Ol(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.e};var Hf=wh(120);dh(265,$wnd.Function,{},Lm);_.fb=function(a){return new Om(a)};var Mm;dh(128,$wnd.React.Component,{},Om);bh(_g[1],_);_.componentWillUnmount=function(){Uk(this.a)};_.render=function(){return hm(this.a)};_.shouldComponentUpdate=Qp;var Jf=wh(128);dh(266,$wnd.Function,{},Pm);_.db=function(a){el(this.a,a)};dh(267,$wnd.Function,{},Qm);_.cb=function(a){kl(this.a,a)};dh(184,1,{},Rm);var Lf=wh(184);var Sm;dh(262,$wnd.Function,{},Um);_.cb=function(a){Jl(this.a,a)};dh(256,$wnd.Function,{},Vm);_.cb=function(a){Un(this.a)};dh(258,$wnd.Function,{},Wm);_.eb=function(a){Ll(this.a,this.b)};dh(259,$wnd.Function,{},Xm);_.eb=function(a){xl(this.a,this.b)};dh(260,$wnd.Function,{},Ym);_.v=function(a){yl(this.a,a)};dh(261,$wnd.Function,{},Zm);_.bb=function(a){Ml(this.a,this.b)};dh(263,$wnd.Function,{},$m);_.db=function(a){zl(this.a,this.b,a)};dh(206,1,{},an);var Nf=wh(206);var bn;dh(264,$wnd.Function,{},dn);_.cb=function(a){cm(this.a,a)};dh(70,1,{},en);var Pf=wh(70);var fn;dh(83,1,{},hn);var Wf=wh(83);dh(84,1,{},kn);var Rf=wh(84);dh(88,1,{},ln);var Sf=wh(88);dh(87,1,{},mn);var Tf=wh(87);dh(85,1,{},on);var Uf=wh(85);dh(86,1,{},qn);var Vf=wh(86);dh(188,1,{});var Dg=wh(188);dh(189,188,fp,Dn);_.s=Kp;_.o=Ep;_.q=Fp;_.t=Lp;var cg=wh(189);dh(190,1,ip,En);_.u=function(){xn(this.a)};var Xf=wh(190);dh(192,1,lp,Fn);_.u=function(){sn(this.a)};var Yf=wh(192);dh(193,1,lp,Gn);_.u=function(){tn(this.a)};var Zf=wh(193);dh(195,1,ip,Hn);_.u=function(){An(this.a)};var $f=wh(195);dh(64,1,ip,In);_.u=function(){wn(this.a)};var _f=wh(64);dh(191,1,dp,Jn);_.r=function(){var a;return a=(nh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var ag=wh(191);dh(194,1,ip,Kn);_.u=function(){rn(this.a,this.b)};var bg=wh(194);dh(48,1,{48:1});_.d=false;var Lg=wh(48);dh(49,48,{9:1,273:1,49:1,48:1},Vn);_.s=Kp;_.o=function(a){return On(this,a)};_.q=function(){return this.c.d};_.t=Lp;var Ln=0;var ug=wh(49);dh(208,1,ip,Wn);_.u=function(){Mn(this.a)};var dg=wh(208);dh(209,1,ip,Xn);_.u=function(){Rn(this.a)};var eg=wh(209);dh(45,157,{45:1});var Gg=wh(45);dh(158,45,{9:1,45:1},fo);_.s=function(){fc(this.f)};_.o=Ep;_.q=Fp;_.t=function(){return this.f.i<0};var og=wh(158);dh(160,1,ip,go);_.u=function(){Zn(this.a)};var fg=wh(160);dh(159,1,ip,ho);_.u=function(){bo(this.a)};var gg=wh(159);dh(165,1,ip,io);_.u=function(){_b(this.a,this.b,true)};var hg=wh(165);dh(166,1,dp,jo);_.r=function(){return Yn(this.a,this.c,this.b)};_.b=false;var ig=wh(166);dh(161,1,dp,ko);_.r=function(){return co(this.a)};var jg=wh(161);dh(162,1,dp,lo);_.r=function(){return Hh(Vg(cj(ao(this.a))))};var kg=wh(162);dh(163,1,dp,mo);_.r=function(){return Hh(Vg(cj(dj(ao(this.a),new Yo))))};var lg=wh(163);dh(164,1,dp,no);_.r=function(){return eo(this.a)};var mg=wh(164);dh(145,1,{69:1},qo);_.C=function(){return new fo};var oo;var ng=wh(145);dh(46,1,{46:1});var Kg=wh(46);dh(167,46,{9:1,46:1},xo);_.s=function(){fc(this.a)};_.o=Ep;_.q=Fp;_.t=function(){return this.a.i<0};var tg=wh(167);dh(168,1,ip,yo);_.u=function(){uo(this.a,this.b)};_.b=false;var pg=wh(168);dh(169,1,ip,zo);_.u=function(){Cn(this.b,this.a)};var qg=wh(169);dh(170,1,ip,Ao);_.u=function(){vo(this.a)};var rg=wh(170);dh(146,1,{69:1},Bo);_.C=function(){return new xo(this.a.C())};var sg=wh(146);dh(47,1,{47:1});var Ng=wh(47);dh(171,47,{9:1,47:1},Ko);_.s=function(){fc(this.g)};_.o=Ep;_.q=Fp;_.t=function(){return this.g.i<0};var Bg=wh(171);dh(172,1,ip,Lo);_.u=function(){Eo(this.a)};var vg=wh(172);dh(173,1,dp,Mo);_.r=function(){var a;return a=zn(this.a.i),Nh(Cp,a)||Nh(yp,a)||Nh('',a)?Nh(Cp,a)?(Vo(),So):Nh(yp,a)?(Vo(),Uo):(Vo(),To):(Vo(),To)};var wg=wh(173);dh(174,1,dp,No);_.r=function(){return Go(this.a)};var xg=wh(174);dh(175,1,lp,Oo);_.u=function(){Ho(this.a)};var yg=wh(175);dh(176,1,lp,Po);_.u=function(){Io(this.a)};var zg=wh(176);dh(147,1,{69:1},Qo);_.C=function(){return new Ko(this.a.C())};var Ag=wh(147);dh(186,1,{},Ro);_.handleEvent=function(a){un(this.a,a)};var Cg=wh(186);dh(33,32,{3:1,30:1,32:1,33:1},Wo);var So,To,Uo;var Eg=xh(33,Xo);dh(151,1,{},Yo);_._=function(a){return !Qn(a)};var Fg=wh(151);dh(153,1,{},Zo);_._=function(a){return Qn(a)};var Hg=wh(153);dh(154,1,{},$o);_.v=function(a){_n(this.a,a)};var Ig=wh(154);dh(152,1,{},_o);_.v=function(a){so(this.a,a)};_.a=false;var Jg=wh(152);dh(155,1,{},ap);_._=function(a){return Do(this.a,a)};var Mg=wh(155);var ld=yh('D');var bp=(xc(),Ac);var gwtOnLoad=gwtOnLoad=Zg;Xg(jh);$g('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();