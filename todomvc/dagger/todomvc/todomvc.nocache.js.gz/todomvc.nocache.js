function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='22148D30FEFC88D3C7BBB040E7F14370',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '22148D30FEFC88D3C7BBB040E7F14370';function o(){}
function wh(){}
function sh(){}
function zb(){}
function Oc(){}
function Vc(){}
function Pj(){}
function Qj(){}
function qk(){}
function Wm(){}
function Ym(){}
function $m(){}
function an(){}
function cn(){}
function mo(){}
function xo(){}
function Ro(){}
function dp(){}
function ep(){}
function jq(){}
function Tc(a){Sc()}
function Ih(){Ih=sh}
function Mi(){Di(this)}
function db(a){this.a=a}
function qb(a){this.a=a}
function rb(a){this.a=a}
function sb(a){this.a=a}
function ac(a){this.a=a}
function cc(a){this.a=a}
function dc(a){this.a=a}
function ec(a){this.a=a}
function ic(a){this.a=a}
function Zh(a){this.a=a}
function ji(a){this.a=a}
function vi(a){this.a=a}
function Ai(a){this.a=a}
function Bi(a){this.a=a}
function zi(a){this.b=a}
function Oi(a){this.c=a}
function Nj(a){this.a=a}
function Sj(a){this.a=a}
function jl(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function tl(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function xl(a){this.a=a}
function Ml(a){this.a=a}
function Nl(a){this.a=a}
function Pl(a){this.a=a}
function Ql(a){this.a=a}
function Sl(a){this.a=a}
function mm(a){this.a=a}
function nm(a){this.a=a}
function tm(a){this.a=a}
function um(a){this.a=a}
function Em(a){this.a=a}
function Fm(a){this.a=a}
function Gm(a){this.a=a}
function Jm(a){this.a=a}
function Mm(a){this.a=a}
function Nm(a){this.a=a}
function Qm(a){this.a=a}
function Rm(a){this.a=a}
function en(a){this.a=a}
function fn(a){this.a=a}
function hn(){this.a={}}
function Lm(){this.a={}}
function Pm(){this.a={}}
function jn(a){this.a=a}
function kn(a){this.a=a}
function mn(a){this.a=a}
function nn(a){this.a=a}
function qn(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function Bn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function co(a){this.a=a}
function fo(a){this.a=a}
function ho(a){this.a=a}
function io(a){this.a=a}
function jo(a){this.a=a}
function wo(a){this.a=a}
function zo(a){this.a=a}
function Jo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function cp(a){this.a=a}
function fp(a){this.a=a}
function gp(a){this.a=a}
function hp(a){this.a=a}
function ip(a){this.a=a}
function jp(a){this.a=a}
function wn(){this.a={}}
function Dn(){this.a={}}
function Oj(a,b){a.a=b}
function Sm(a,b){a.d=b}
function Tm(a,b){a.e=b}
function Um(a,b){a.f=b}
function Vm(a,b){a.g=b}
function zn(a,b){a.k=b}
function An(a,b){a.n=b}
function oo(a,b){Qn(b,a)}
function C(a,b){wb(a.b,b)}
function Y(a){Ib((H(),a))}
function Z(a){Jb((H(),a))}
function A(a){--a.e;D(a)}
function Fl(a){El();Dl=a}
function fl(a){el();dl=a}
function ql(a){pl();ol=a}
function dm(a){bm();am=a}
function Bm(a){Am();zm=a}
function Vp(a){oj(this,a)}
function Yp(a){bi(this,a)}
function bq(){kk(this.a)}
function gq(){mk(this.a)}
function Yi(){this.a=fj()}
function kj(){this.a=fj()}
function F(){this.b=new xb}
function H(){H=sh;G=new F}
function nc(){this.b=new Si}
function kb(a,b){a.b=rj(b)}
function mc(a,b){ri(a.b,b)}
function no(a,b){Xn(a.b,b)}
function Wl(a,b){Yn(a.k,b)}
function Rj(a,b){Hj(a.a,b)}
function w(a,b,c){s(a,c,b)}
function gk(a,b,c){a[b]=c}
function dh(a){return a.e}
function eq(){return this.e}
function Sp(){return this.a}
function Xp(){return this.b}
function $p(){return this.c}
function fi(a,b){return a===b}
function Xl(a,b){return a.g=b}
function _p(){return this.d<0}
function fq(){return this.c<0}
function iq(){return this.f<0}
function Up(){return $j(this)}
function bj(){bj=sh;aj=dj()}
function uc(){uc=sh;tc=new o}
function Lc(){Lc=sh;Kc=new Oc}
function zh(){zh=sh;yh=new o}
function lo(){lo=sh;ko=new mo}
function Qo(){Qo=sh;Po=new Ro}
function uo(a){this.b=rj(a)}
function rl(a){lc(a.b);eb(a.a)}
function bb(a){Kb((H(),a))}
function bn(a){hk.call(this,a)}
function dn(a){hk.call(this,a)}
function Xm(a){hk.call(this,a)}
function Zm(a){hk.call(this,a)}
function _m(a){hk.call(this,a)}
function Xh(a){sc.call(this,a)}
function ki(a){sc.call(this,a)}
function Tp(a){return this===a}
function Wc(a,b){return Rh(a,b)}
function Gi(a,b){return a.a[b]}
function Lh(a){Kh(a);return a.k}
function Cb(a){Db(a);!a.d&&Gb(a)}
function V(a){H();Jb(a);a.e=-2}
function Tb(a){$(a.a);return a.e}
function Ub(a){$(a.b);return a.g}
function fj(){bj();return new aj}
function Gj(a,b){a.T(b);return a}
function Wj(a,b){a.splice(b,1)}
function sj(a,b){while(a.eb(b));}
function Hj(a,b){Oj(a,Gj(a.a,b))}
function kc(a,b,c){qi(a.b,b,c)}
function Wb(a){Sb(a,($(a.b),a.g))}
function Nn(a){$(a.a);return a.g}
function Mn(a){$(a.b);return a.i}
function Co(a){$(a.d);return a.f}
function sk(a,b){a.ref=b;return a}
function bc(a,b){this.a=a;this.b=b}
function jc(a,b){this.a=a;this.b=b}
function Ah(a){this.a=yh;this.b=a}
function Wh(a,b){this.a=a;this.b=b}
function Ci(a,b){this.a=a;this.b=b}
function ci(){oc(this);this.H()}
function cq(){return pk(this.a)}
function Wp(){return ti(this.a)}
function aq(){return H(),H(),G}
function ti(a){return a.a.b+a.b.b}
function hj(a,b){return a.a.get(b)}
function _c(a){return new Array(a)}
function lh(){jh==null&&(jh=[])}
function Bc(){Bc=sh;!!(Sc(),Rc)}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function Kj(a,b){this.a=a;this.b=b}
function Ol(a,b){this.a=a;this.b=b}
function pm(a,b){this.a=a;this.b=b}
function qm(a,b){this.a=a;this.b=b}
function rm(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function sn(a,b){this.a=a;this.b=b}
function on(a,b){this.a=a;this.b=b}
function pn(a,b){this.a=a;this.b=b}
function rn(a,b){this.a=a;this.b=b}
function eo(a,b){this.a=a;this.b=b}
function yo(a,b){this.a=a;this.b=b}
function vo(a,b){this.b=a;this.a=b}
function Oo(a,b){this.b=a;this.a=b}
function al(a,b){Wh.call(this,a,b)}
function ap(a,b){Wh.call(this,a,b)}
function Vl(a,b){Ho(a.n,b);jm(a,b)}
function Lj(a,b){a.B(vn(tn(b.e),b))}
function Uj(a,b,c){a.splice(b,0,c)}
function Dk(a,b){a.value=b;return a}
function tk(a,b){a.href=b;return a}
function hi(a,b){a.a+=''+b;return a}
function si(a){a.a=new Yi;a.b=new kj}
function J(a){a.b=0;a.d=0;a.c=false}
function Eb(a){return !a.d?a:Eb(a.d)}
function pi(a){return !a?null:a.ab()}
function qj(a){return a!=null?r(a):0}
function od(a){return a==null?null:a}
function tn(a){return un(new wn,a)}
function hq(a,b){return ok(this.a,a)}
function kq(){return Dh(this.a.J())}
function Zp(){return R(this.e.b).a>0}
function ld(a){return typeof a===mp}
function Pn(a){Qn(a,($(a.a),!a.g))}
function hc(a,b){fc(a,b,false);Z(a.d)}
function hl(a){lc(a.c);eb(a.b);Q(a.a)}
function Jl(a){lc(a.c);eb(a.a);U(a.b)}
function Zl(a,b){jm(a,b);Ho(a.n,null)}
function Vj(a,b){Tj(b,0,a,0,b.length)}
function yk(a,b){a.onBlur=b;return a}
function uk(a,b){a.onClick=b;return a}
function zk(a,b){a.onChange=b;return a}
function wk(a,b){a.checked=b;return a}
function Ic(a){$wnd.clearTimeout(a)}
function ei(a,b){return a.charCodeAt(b)}
function B(a,b,c){return t(a,c,2048,b)}
function bd(a,b,c){return {l:a,m:b,h:c}}
function jd(a,b){return a!=null&&gd(a,b)}
function T(a){return !(!!a&&1==(a.c&7))}
function $j(a){return a.$H||(a.$H=++Zj)}
function nd(a){return typeof a==='string'}
function Ak(a,b){a.onKeyDown=b;return a}
function vk(a){a.autoFocus=true;return a}
function Di(a){a.a=Yc(ge,np,1,0,5,1)}
function O(){this.a=Yc(ge,np,1,100,5,1)}
function cb(a){this.c=new Mi;this.b=a}
function Si(){this.a=new Yi;this.b=new kj}
function ck(){ck=sh;_j=new o;bk=new o}
function jb(a){H();ib(a);lb(a,2,true)}
function $(a){var b;Fb((H(),b=Ab,b),a)}
function $i(a,b){var c;c=a[Dp];c.call(a,b)}
function pc(a,b){a.e=b;b!=null&&Yj(b,yp,a)}
function Kh(a){if(a.k!=null){return}Th(a)}
function xk(a,b){a.defaultValue=b;return a}
function Ek(a,b){a.onDoubleClick=b;return a}
function Fj(a,b){Aj.call(this,a);this.a=b}
function sc(a){this.f=a;oc(this);this.H()}
function gc(a,b){mc(b.D(),a);jd(b,12)&&b.v()}
function oj(a,b){while(a.Y()){Rj(b,a.Z())}}
function v(a,b){return new ob(rj(a),null,b)}
function kd(a){return typeof a==='boolean'}
function ao(a){return $h(R(a.e).a-R(a.a).a)}
function On(a){lc(a.c);U(a.d);U(a.b);U(a.a)}
function Oh(a){var b;b=Nh(a);Vh(a,b);return b}
function Qh(){var a;a=Nh(null);a.e=2;return a}
function oc(a){a.g&&a.e!==xp&&a.H();return a}
function Cc(a,b,c){return a.apply(b,c);var d}
function Yj(b,c,d){try{b[c]=d}catch(a){}}
function nj(a,b,c){this.a=a;this.b=b;this.c=c}
function zl(a,b,c){this.a=a;this.b=b;this.c=c}
function om(a,b,c){this.a=a;this.b=b;this.c=c}
function wm(a,b,c){this.a=a;this.b=b;this.c=c}
function Im(a,b,c){this.a=a;this.b=b;this.c=c}
function un(a,b){gk(a.a,'key',rj(b));return a}
function Ei(a,b){a.a[a.a.length]=b;return true}
function ok(a,b){var c;c=a.nb(b);return c||a.o}
function Il(a,b){var c;c=b.target;Kl(a,c.value)}
function hb(a,b){X(b,a);b.c.a.length>0||(b.a=4)}
function Pb(a,b){a.i&&b.preventDefault();$b(a)}
function go(a,b){this.a=a;this.c=b;this.b=false}
function gm(a,b){return Ih(),cm(a,b)?true:false}
function gj(a,b){return !(a.a.get(b)===undefined)}
function $c(a){return Array.isArray(a)&&a.yb===wh}
function _n(a){return Ih(),0==R(a.e).a?true:false}
function hd(a){return !Array.isArray(a)&&a.yb===wh}
function uj(a){if(!a.d){a.d=a.b.S();a.c=a.b.U()}}
function yb(a){if(!a.a){a.a=true;A((H(),H(),G))}}
function Ij(a,b,c){if(a.a.fb(c)){a.b=true;b.B(c)}}
function xi(a){var b;b=a.a.Z();a.b=wi(a);return b}
function Ii(a,b){var c;c=a.a[b];Wj(a.a,b);return c}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ki(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Kl(a,b){var c;c=a.f;if(b!=c){a.f=b;Z(a.b)}}
function fm(a){lc(a.e);eb(a.b);Q(a.d);U(a.c);U(a.a)}
function km(a,b){var c;c=a.i;if(b!=c){a.i=b;Z(a.a)}}
function xm(a,b){var c;c=b.target;to(a.e,c.checked)}
function Qn(a,b){var c;c=a.g;if(b!=c){a.g=b;Z(a.a)}}
function Do(a){eb(a.e);eb(a.a);Q(a.b);Q(a.c);U(a.d)}
function Dj(a){zj(a);return new Fj(a,new Mj(a.a))}
function ui(a,b){if(b){return ni(a.a,b)}return false}
function Ch(a){if(!a){throw dh(new ci)}return a}
function Dh(a){if(a==null){throw dh(new di)}return a}
function rj(a){if(a==null){throw dh(new ci)}return a}
function fk(){if(ak==256){_j=bk;bk=new o;ak=0}++ak}
function Sc(){Sc=sh;var a;!Uc();a=new Vc;Rc=a}
function Fh(){Fh=sh;Eh=$wnd.window.document}
function ai(){ai=sh;_h=Yc(ce,np,32,256,0,1)}
function Ao(a){return fi(Rp,a)||fi(Np,a)||fi('',a)}
function gl(a){return Ih(),R(a.e.b).a>0?true:false}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Ri(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function tj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Ck(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function wl(a){var b;b=new sl;Sm(b,a.a.J());return b}
function Rl(a){var b;b=new Ll;Tm(b,a.a.J());return b}
function Yb(a,b){var c;c=a.e;if(b!=c){a.e=rj(b);Z(a.a)}}
function Zb(a,b){var c;c=a.g;if(b!=c){a.g=rj(b);Z(a.b)}}
function Rn(a,b){var c;c=a.i;if(b!=c){a.i=rj(b);Z(a.b)}}
function Ph(a,b){var c;c=Nh(a);Vh(a,c);c.e=b?8:0;return c}
function ab(a){var b;H();!!Ab&&!!Ab.e&&Fb((b=Ab,b),a)}
function vb(a){while(true){if(!tb(a)&&!ub(a)){break}}}
function yj(a){if(!a.b){zj(a);a.c=true}else{yj(a.b)}}
function Aj(a){if(!a){this.b=null;new Mi}else{this.b=a}}
function Mj(a){tj.call(this,a.db(),a.cb()&-6);this.a=a}
function Lb(a,b){this.a=(H(),H(),G).a++;this.d=a;this.e=b}
function vj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Yh(a){this.f=!a?null:qc(a,a.G());oc(this);this.H()}
function nk(a){lk(a);return jd(a,12)&&a.w()?null:a.ob()}
function Cj(a,b){zj(a);return new Fj(a,new Jj(b,a.a))}
function ih(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function Sh(a){if(a.Q()){return null}var b=a.j;return oh[b]}
function kk(a){if(!a.o){a.o=true;a.p||a.q.forceUpdate()}}
function Bb(a){if(a.e){2==(a.e.c&7)||lb(a.e,4,true);ib(a.e)}}
function Ul(a,b){var c;if(R(a.d)){c=b.target;km(a,c.value)}}
function qc(a,b){var c;c=Lh(a.wb);return b==null?c:c+': '+b}
function oi(a,b){return b===a?'(this Map)':b==null?Ap:vh(b)}
function bi(a,b){var c,d;for(d=a.S();d.Y();){c=d.Z();b.B(c)}}
function Bl(a,b){if(13==b.keyCode){b.preventDefault();Gl(a)}}
function wb(a,b){b.c|=512;I(a.d[((b.c&229376)>>15)-1],rj(b))}
function ro(a,b){var c;Ej(Zn(a.b),(c=new Mi,c)).R(new gp(b))}
function Yl(a,b,c){27==c.which?im(a,b):13==c.which&&$l(a,b)}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function bp(){_o();return ad(Wc(Pg,1),np,37,0,[Yo,$o,Zo])}
function bm(){bm=sh;var a;_l=(a=th(an.prototype.ib,an,[]),a)}
function Am(){Am=sh;var a;ym=(a=th(cn.prototype.ib,cn,[]),a)}
function el(){el=sh;var a;cl=(a=th(Wm.prototype.ib,Wm,[]),a)}
function pl(){pl=sh;var a;nl=(a=th(Ym.prototype.ib,Ym,[]),a)}
function El(){El=sh;var a;Cl=(a=th($m.prototype.ib,$m,[]),a)}
function uh(a){function b(){}
;b.prototype=a||{};return new b}
function Mb(a,b){Ab=new Lb(Ab,b);a.d=false;Bb(Ab);return Ab}
function Ob(a,b){a.j=b;fi(b,($(a.a),a.e))&&Zb(a,b);Qb(b);$b(a)}
function Fo(a){var b;b=($(a.d),a.f);!!b&&!!b&&b.f<0&&Ho(a,null)}
function fb(a){var b;b=(H(),H(),G);wb(b.b,a);0!=(a.c&tp)&&D(b)}
function Rh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.L(b))}
function Ui(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Vi(a,b){var c;return Ti(b,Ui(a,b==null?0:(c=r(b),c|0)))}
function Zn(a){$(a.d);return new Fj(null,new vj(new Ai(a.g),0))}
function Kn(a){if(a.f>=0){a.f=-2;u((H(),H(),G),new Un(a),sp,null)}}
function Ni(a){Di(this);Vj(this.a,mi(a,Yc(ge,np,1,ti(a.a),5,1)))}
function dq(){return Co(this.n)==(ab(this.c),this.q.props['a'])}
function Zi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Bh(a){zh();Ch(a);if(jd(a,53)){return a}return new Ah(a)}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function Ho(a,b){var c;c=a.f;if(!(b==c||!!b&&Ln(b,c))){a.f=b;Z(a.d)}}
function W(a,b){var c,d;Ei(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Jj(a,b){tj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function Uo(a){this.c=a;this.a=new xl(this.c.e);this.b=new Rm(this.a)}
function Vo(a){this.c=a;this.a=new Sl(this.c.f);this.b=new kn(this.a)}
function lj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function wj(a,b){!a.a?(a.a=new ji(a.d)):hi(a.a,a.b);hi(a.a,b);return a}
function Ej(a,b){var c;yj(a);c=new Pj;c.a=b;a.a.X(new Sj(c));return c.a}
function Bj(a){var b;yj(a);b=0;while(a.a.eb(new Qj)){b=eh(b,1)}return b}
function Bk(a){a.placeholder='What needs to be done?';return a}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function qh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Gh(a,b,c,d){a.addEventListener(b,c,(Ih(),d?true:false))}
function Hh(a,b,c,d){a.removeEventListener(b,c,(Ih(),d?true:false))}
function hm(a){return Ih(),Co(a.n)==(ab(a.c),a.q.props['a'])?true:false}
function ri(a,b){return nd(b)?b==null?Xi(a.a,null):jj(a.b,b):Xi(a.a,b)}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Km(a){return $wnd.React.createElement((el(),cl),a.a,undefined)}
function Om(a){return $wnd.React.createElement((pl(),nl),a.a,undefined)}
function gn(a){return $wnd.React.createElement((El(),Cl),a.a,undefined)}
function Cn(a){return $wnd.React.createElement((Am(),ym),a.a,undefined)}
function Bo(a,b){return (_o(),Zo)==a||(Yo==a?($(b.a),!b.g):($(b.a),b.g))}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function Al(a){var b;b=gi(($(a.b),a.f));if(b.length>0){no(a.e,b);Kl(a,'')}}
function qo(a){var b;Ej(Cj(Zn(a.b),new ep),(b=new Mi,b)).R(new fp(a.b))}
function U(a){if(-2!=a.e){u((H(),H(),G),new db(a),0,null);!!a.b&&eb(a.b)}}
function mj(a){if(a.a.c!=a.c){return hj(a.a,a.b.value[0])}return a.b.value[1]}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function pk(a){var b;a.o=false;if(a.kb()){return null}else{b=a.hb();return b}}
function vm(a){var b;b=new lm;zn(b,a.a.J());a.b.J();An(b,a.c.J());return b}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function Ji(a,b){var c;c=Hi(a,b,0);if(c==-1){return false}Wj(a.a,c);return true}
function Fi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.B(c)}}
function Eo(a){var b,c;return b=R(a.b),Ej(Cj(Zn(a.j),new ip(b)),(c=new Mi,c))}
function qi(a,b,c){return nd(b)?b==null?Wi(a.a,null,c):ij(a.b,b,c):Wi(a.a,b,c)}
function Xj(a,b){return Xc(b)!=10&&ad(q(b),b.xb,b.__elementTypeId$,Xc(b),a),a}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function md(a){return a!=null&&(typeof a===lp||typeof a==='function')&&!(a.yb===wh)}
function yi(a){this.d=a;this.c=new lj(this.d.b);this.a=this.c;this.b=wi(this)}
function xj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Q(a){if(!a.a){a.a=true;a.g=null;a.b=null;U(a.d);2==(a.e.c&7)||eb(a.e)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{vb(a.b)}finally{a.c=false}}}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function Vb(a){Hh((Fh(),$wnd.window.window),vp,a.f,false);lc(a.c);U(a.b);U(a.a)}
function $n(a){bi(new Ai(a.g),new ic(a));si(a.g);Q(a.c);Q(a.e);Q(a.a);Q(a.b);U(a.d)}
function yl(a){var b;b=new il;Tm(b,a.a.J());Um(b,a.b.J());Vm(b,a.c.J());return b}
function Hm(a){var b;b=new Dm;Sm(b,a.a.J());Tm(b,a.b.J());Um(b,a.c.J());return b}
function Nh(a){var b;b=new Mh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function bh(a){var b;if(jd(a,4)){return a}b=a&&a[yp];if(!b){b=new wc(a);Tc(b)}return b}
function tb(a){var b;if(0==N(a.c)){return false}else{b=M(a.c);!!b&&b.v();return true}}
function Vh(a,b){var c;if(!a){return}b.j=a;var d=Sh(b);if(!d){oh[a]=[b];return}d.wb=b}
function th(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Hi(a,b,c){for(;c<a.a.length;++c){if(Ri(b,a.a[c])){return c}}return -1}
function Fb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Ei((!a.b&&(a.b=new Mi),a.b),b)}}}
function mk(a){var b;b=(++a.mb().e,new zb);try{a.p=true;jd(a,12)&&a.v()}finally{yb(b)}}
function Nb(){var a;try{Cb(Ab);H()}finally{a=Ab.d;!a&&((H(),H(),G).d=true);Ab=Ab.d}}
function kh(){lh();var a=jh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Wo(a){this.c=a;this.a=new wm(this.c.e,this.c.f,this.c.g);this.b=new yn(this.a)}
function Xo(a){this.c=a;this.a=new Im(this.c.e,this.c.f,this.c.g);this.b=new Fn(this.a)}
function To(a){this.c=a;this.a=new zl(this.c.e,this.c.f,this.c.g);this.b=new Nm(this.a)}
function _o(){_o=sh;Yo=new ap('ACTIVE',0);$o=new ap('COMPLETED',1);Zo=new ap('ALL',2)}
function di(){sc.call(this,'Cannot return null from a non-@Nullable @Provides method')}
function vn(a,b){gk(a.a,(bm(),'a'),b);return $wnd.React.createElement(_l,a.a,undefined)}
function jj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{$i(a.a,b);--a.b}return c}
function Wn(a,b,c){var d;d=new Tn(b,c);kc(d.c,a,new jc(a,d));qi(a.g,$h(d.e),d);Z(a.d);return d}
function li(a,b){var c,d;for(d=new yi(b.a);d.b;){c=xi(d);if(!ui(a,c)){return false}}return true}
function Pi(a){var b,c,d;d=0;for(c=new yi(a.a);c.b;){b=xi(c);d=d+(b?r(b):0);d=d|0}return d}
function ib(a){var b,c;for(c=new Oi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Hb(a,b){var c;if(!a.c){c=Eb(a);!c.c&&(c.c=new Mi);a.c=c.c}b.d=true;Ei(a.c,rj(b))}
function I(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&K(a,c);L(a,rj(b))}
function fc(a,b,c){var d;d=ri(a.g,b?$h(b.e):null);if(null!=d){mc(b.c,a);c&&!!b&&Kn(b);Z(a.d)}}
function cm(a,b){var c;c=false;if(!Ri(a.q.props['a'],null==b?null:b['a'])){Z(a.c);c=true}return c}
function fh(a){var b;b=a.h;if(b==0){return a.l+a.m*tp}if(b==1048575){return a.l+a.m*tp-Bp}return a}
function wi(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new Zi(a.d.a);return a.a.Y()}
function eb(a){if(2<(a.c&7)){u((H(),H(),G),new rb(a),sp,null);!!a.a&&Q(a.a);a.c=a.c&-8|1}}
function hk(a){$wnd.React.Component.call(this,a);this.a=this.jb();this.a.q=rj(this);this.a.gb()}
function sl(){pl();++ik;this.b=new nc;this.a=new ob(null,rj((H(),new tl(this))),Hp);D((null,G))}
function Dm(){Am();++ik;this.b=new nc;this.a=new ob(null,rj((H(),new Em(this))),Hp);D((null,G))}
function Go(a){var b;b=Tb(a.i);fi(Rp,b)||fi(Np,b)||fi('',b)?Sb(a.i,b):Ao(Ub(a.i))?Xb(a.i):Sb(a.i,'')}
function X(a,b){var c,d;d=a.c;Ji(d,b);d.a.length==0&&!!a.b&&pp!=(a.b.c&qp)&&(a.d||Hb((H(),c=Ab,c),a))}
function $l(a,b){var c;c=($(a.a),a.i);if(null!=c&&c.length!=0){so(b,c);Ho(a.n,null);km(a,c)}else{Yn(a.k,b)}}
function Ln(a,b){var c;if(a===b){return true}else if(null==b||!jd(b,60)){return false}else{c=b;return a.e==c.e}}
function Ti(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Ri(a,c._())){return c}}return null}
function hh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Bp;d=1048575}c=pd(e/tp);b=pd(e-c*tp);return bd(b,c,d)}
function ad(a,b,c,d,e){e.wb=a;e.xb=b;e.yb=wh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function ij(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function R(a){$(a.d);mb(a.e)&&gb(a.e);if(a.b){if(jd(a.b,5)){throw dh(a.b)}else{throw dh(a.b)}}return a.g}
function q(a){return nd(a)?je:ld(a)?$d:kd(a)?Yd:hd(a)?a.wb:$c(a)?a.wb:a.wb||Array.isArray(a)&&Wc(Qd,1)||Qd}
function nh(a,b){typeof window===lp&&typeof window['$gwt']===lp&&(window['$gwt'][a]=b)}
function lk(a){if(!jk){jk=(++a.mb().e,new zb);$wnd.Promise.resolve(null).then(th(qk.prototype.K,qk,[]))}}
function zj(a){if(a.b){zj(a.b)}else if(a.c){throw dh(new Xh("Stream already terminated, can't be modified or used"))}}
function wc(a){uc();oc(this);this.e=a;a!=null&&Yj(a,yp,this);this.f=a==null?Ap:vh(a);this.a='';this.b=a;this.a=''}
function Mh(){this.g=Jh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function S(a,b){this.c=rj(a);this.f=null;this.g=null;this.e=new pb(this,b);this.d=new cb(this.e);pp==(b&qp)&&fb(this.e)}
function nb(a,b,c,d){this.b=new Mi;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&fb(this)}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function eh(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<Bp){return c}}return fh(cd(ld(a)?hh(a):a,ld(b)?hh(b):b))}
function $h(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ai(),_h)[b];!c&&(c=_h[b]=new Zh(a));return c}return new Zh(a)}
function vh(a){var b;if(Array.isArray(a)&&a.yb===wh){return Lh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function ek(a){ck();var b,c,d;c=':'+a;d=bk[c];if(d!=null){return pd(d)}d=_j[c];b=d==null?dk(a):pd(d);fk();bk[c]=b;return b}
function Qi(a){var b,c,d;d=1;for(c=new Oi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function lc(a){var b,c;if(!a.a){for(c=new Oi(new Ni(new Ai(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.A()}a.a=true}}
function Rb(a){var b,c;c=(b=(Fh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));Yb(a,c);fi(a.j,c)&&Zb(a,c)}
function Tl(a){var b;b=R(a.d);if(!a.j&&b){a.j=true;jm(a,(ab(a.c),a.q.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function bl(){_k();return ad(Wc(Ze,1),np,9,0,[Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k])}
function ob(a,b,c){nb.call(this,null,a,b,c|(!a?262144:pp)|(0!=(c&6291456)?0:!a?2097152:tp)|(0!=(c&229376)?0:98304)|0|0|0)}
function r(a){return nd(a)?ek(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.t():$c(a)?$j(a):!!a&&!!a.hashCode?a.hashCode():$j(a)}
function p(a,b){return nd(a)?fi(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.r(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function Ll(){El();var a;++ik;this.c=new nc;this.b=(a=new cb((H(),null)),a);this.a=new ob(null,rj(new Pl(this)),Hp);D((null,G))}
function il(){el();++ik;this.c=new nc;this.a=new S((H(),new jl(this)),136478720);this.b=new ob(null,rj(new ll(this)),Hp);D((null,G))}
function xb(){this.c=new O;this.d=Yc(rd,np,20,5,0,1);this.d[0]=new O;this.d[1]=new O;this.d[2]=new O;this.d[3]=new O;this.d[4]=new O}
function Uh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Li(a,b){var c,d;d=a.a.length;b.length<d&&(b=Xj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function rk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function s(b,c,d){var e;try{Mb(b,d);try{c.A()}finally{Nb()}}catch(a){a=bh(a);if(jd(a,4)){e=a;throw dh(e)}else throw dh(a)}finally{D(b)}}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.xb){return !!a.xb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Kb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&lb(b,5,true)}}}
function Jb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Oi(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&lb(b,6,true)}}}
function Ib(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?lb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function pb(a,b){nb.call(this,a,new qb(a),null,b|(pp==(b&qp)?0:524288)|(0!=(b&6291456)?0:pp==(b&qp)?tp:2097152)|0|268435456|0|(0!=(b&229376)?0:98304))}
function gi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Gb(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=Ii(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&lb(c.b,3,true);++b}}}return b}
function Tn(a,b){var c,d,e;this.i=rj(a);this.g=b;this.e=Jn++;this.d=(d=new cb((H(),null)),d);this.c=new nc;this.b=(e=new cb(null),e);this.a=(c=new cb(null),c)}
function mh(b,c,d,e){lh();var f=jh;$moduleName=c;$moduleBase=d;ah=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{kp(g)()}catch(a){b(c,a)}}else{kp(g)()}}
function Xb(b){var c;try{u((H(),H(),G),new cc(b),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){c=a;throw dh(c)}else if(jd(a,4)){c=a;throw dh(new Yh(c))}else throw dh(a)}}
function $b(b){var c;try{u((H(),H(),G),new dc(b),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){c=a;throw dh(c)}else if(jd(a,4)){c=a;throw dh(new Yh(c))}else throw dh(a)}}
function Gl(b){var c;try{u((H(),H(),G),new Nl(b),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){c=a;throw dh(c)}else if(jd(a,4)){c=a;throw dh(new Yh(c))}else throw dh(a)}}
function Sn(b){var c;try{u((H(),H(),G),new Vn(b),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){c=a;throw dh(c)}else if(jd(a,4)){c=a;throw dh(new Yh(c))}else throw dh(a)}}
function po(b){var c;try{u((H(),H(),G),new wo(b),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){c=a;throw dh(c)}else if(jd(a,4)){c=a;throw dh(new Yh(c))}else throw dh(a)}}
function so(b,c){var d;try{u((H(),H(),G),new vo(b,c),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){d=a;throw dh(d)}else if(jd(a,4)){d=a;throw dh(new Yh(d))}else throw dh(a)}}
function to(b,c){var d;try{u((H(),H(),G),new yo(b,c),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){d=a;throw dh(d)}else if(jd(a,4)){d=a;throw dh(new Yh(d))}else throw dh(a)}}
function Yn(b,c){var d;try{u((H(),H(),G),new eo(b,c),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){d=a;throw dh(d)}else if(jd(a,4)){d=a;throw dh(new Yh(d))}else throw dh(a)}}
function Hl(b,c){var d;try{u((H(),H(),G),new Ol(b,c),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){d=a;throw dh(d)}else if(jd(a,4)){d=a;throw dh(new Yh(d))}else throw dh(a)}}
function em(b,c){var d;try{u((H(),H(),G),new sm(b,c),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){d=a;throw dh(d)}else if(jd(a,4)){d=a;throw dh(new Yh(d))}else throw dh(a)}}
function im(b,c){var d;try{u((H(),H(),G),new rm(b,c),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){d=a;throw dh(d)}else if(jd(a,4)){d=a;throw dh(new Yh(d))}else throw dh(a)}}
function jm(b,c){var d;try{u((H(),H(),G),new qm(b,c),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){d=a;throw dh(d)}else if(jd(a,4)){d=a;throw dh(new Yh(d))}else throw dh(a)}}
function Xn(b,c){var d;try{return t((H(),H(),G),new go(b,c),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){d=a;throw dh(d)}else if(jd(a,4)){d=a;throw dh(new Yh(d))}else throw dh(a)}}
function Sb(b,c){var d;try{u((H(),H(),G),new bc(b,c),75497472,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){d=a;throw dh(d)}else if(jd(a,4)){d=a;throw dh(new Yh(d))}else throw dh(a)}}
function u(b,c,d,e){var f;try{if(0==(d&2048)&&!!Ab){c.A()}else{Mb(b,e);try{c.A()}finally{Nb()}}}catch(a){a=bh(a);if(jd(a,4)){f=a;throw dh(f)}else throw dh(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ab){g=c.C()}else{Mb(b,e);try{g=c.C()}finally{Nb()}}return g}catch(a){a=bh(a);if(jd(a,4)){f=a;throw dh(f)}else throw dh(a)}finally{D(b)}}
function xh(){var a;a=new So;fl(new Mm(a));ql(new Qm(a));dm(new xn(a));Bm(new En(a));Fl(new jn(a));$wnd.ReactDOM.render(Cn(new Dn),(Fh(),Eh).getElementById('todoapp'),null)}
function dj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return ej()}}
function bo(){var a;this.g=new Si;this.d=(a=new cb((H(),null)),a);this.c=new S(new fo(this),Qp);this.e=new S(new ho(this),Qp);this.a=new S(new io(this),Qp);this.b=new S(new jo(this),Qp)}
function lm(){bm();var a,b;++ik;this.e=new nc;this.c=(b=new cb((H(),null)),b);this.a=(a=new cb(null),a);this.d=new S(new tm(this),136478720);this.b=new ob(null,rj(new um(this)),Hp);D((null,G))}
function mi(a,b){var c,d,e,f,g;g=ti(a.a);b.length<g&&(b=Xj(new Array(g),b));e=(f=new yi((new vi(a.a)).a),new Bi(f));for(d=0;d<g;++d){b[d]=(c=xi(e.a),c.ab())}b.length>g&&(b[g]=null);return b}
function ph(){oh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].zb()&&(c=Pc(c,g)):g[0].zb()}catch(a){a=bh(a);if(jd(a,4)){d=a;Bc();Hc(jd(d,40)?d.I():d)}else throw dh(a)}}return c}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?Ap:md(b)?b==null?null:b.name:nd(b)?'String':Lh(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function P(b){var c,d,e;e=b.g;try{d=b.c.C();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.g=d;b.b=null;Y(b.d)}}catch(a){a=bh(a);if(jd(a,13)){c=a;if(!b.b){b.g=null;b.b=c;Y(b.d)}throw dh(c)}else throw dh(a)}}
function Tj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Wi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ti(b,e);if(f){return f.bb(c)}}e[e.length]=new Ci(b,c);++a.b;return null}
function So(){this.a=Bh((lo(),lo(),ko));this.e=Bh(new cp(this.a));this.b=Bh(new zo(this.e));this.f=Bh(new hp(this.b));this.d=Bh((Qo(),Qo(),Po));this.c=Bh(new Oo(this.e,this.d));this.g=Bh(new jp(this.c))}
function dk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ei(a,c++)}b=b|0;return b}
function K(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Yc(ge,np,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function Io(a,b){var c;this.j=rj(a);this.i=rj(b);this.d=(c=new cb((H(),null)),c);this.b=new S(new Ko(this),Qp);this.c=new S(new Lo(this),Qp);this.e=v(new Mo(this),413138944);this.a=v(new No(this),681574400);D((null,G))}
function Qb(a){var b;if(0==a.length){b=(Fh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Eh.title,b)}else{(Fh(),$wnd.window.window).location.hash=a}}
function gb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;w((H(),H(),G),b,c)}else{b.e.A()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=bh(a);if(jd(a,4)){H()}else throw dh(a)}}}
function Xi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ri(b,e._())){if(d.length==1){d.length=0;$i(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function rh(a,b,c){var d=oh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=oh[b]),uh(h));_.xb=c;!b&&(_.yb=wh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.wb=f)}
function Th(a){if(a.P()){var b=a.c;b.Q()?(a.k='['+b.j):!b.P()?(a.k='[L'+b.N()+';'):(a.k='['+b.N());a.b=b.M()+'[]';a.i=b.O()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Uh('.',[c,Uh('$',d)]);a.b=Uh('.',[c,Uh('.',d)]);a.i=d[d.length-1]}
function _b(){var a,b,c;this.f=new ec(this);this.c=new nc;this.b=(c=new cb((H(),null)),c);this.a=(b=new cb(null),b);Gh((Fh(),$wnd.window.window),vp,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function ni(a,b){var c,d,e;c=b._();e=b.ab();d=nd(c)?c==null?pi(Vi(a.a,null)):hj(a.b,c):pi(Vi(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!Vi(a.a,null):gj(a.b,c):!!Vi(a.a,c))){return false}return true}
function mb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Oi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{R(c)}catch(a){a=bh(a);if(!jd(a,4))throw dh(a)}if(6==(b.c&7)){return true}}}}}ib(b);return false}
function cj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function lb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((H(),H(),G),a))}else if(!!a.a&&4==f&&(6==b||5==b)){bb(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((H(),H(),G),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}Fi(a.b,new sb(a));a.b.a=Yc(ge,np,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function ub(a){var b,c,d,e,f,g,h,i;d=N(a.d[0]);c=N(a.d[1]);g=N(a.d[2]);e=N(a.d[3]);f=N(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;J(a.d[0]);J(a.d[1]);J(a.d[2]);J(a.d[3]);J(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=M(b);h.c&=-513;gb(h);return true}
function _k(){_k=sh;Fk=new al(Ep,0);Gk=new al('checkbox',1);Hk=new al('color',2);Ik=new al('date',3);Jk=new al('datetime',4);Kk=new al('email',5);Lk=new al('file',6);Mk=new al('hidden',7);Nk=new al('image',8);Ok=new al('month',9);Pk=new al(mp,10);Qk=new al('password',11);Rk=new al('radio',12);Sk=new al('range',13);Tk=new al('reset',14);Uk=new al('search',15);Vk=new al('submit',16);Wk=new al('tel',17);Xk=new al('text',18);Yk=new al('time',19);Zk=new al('url',20);$k=new al('week',21)}
function Db(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Gi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ki(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{X(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&lb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Gi(a.b,g);if(-1==k.e){k.e=0;W(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ii(a.b,g)}e&&kb(a.e,a.b)}else{e&&kb(a.e,new Mi)}if(T(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&pp!=(b.e.c&qp)&&Hb(a,k)}}
function ej(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Dp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!cj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Dp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var lp='object',mp='number',np={3:1,6:1},op={12:1},pp=1048576,qp=1835008,rp={8:1},sp=67108864,tp=4194304,up={30:1},vp='hashchange',wp=142606336,xp='__noinit__',yp='__java$exception',zp={3:1,13:1,5:1,4:1},Ap='null',Bp=17592186044416,Cp={49:1},Dp='delete',Ep='button',Fp={11:1,42:1},Gp='selected',Hp=1478623232,Ip={16:1},Jp={11:1,43:1},Kp={11:1,46:1},Lp='input',Mp={11:1,44:1},Np='completed',Op={11:1,45:1},Pp='header',Qp=136314880,Rp='active';var _,oh,jh,ah=-1;ph();rh(1,null,{},o);_.r=Tp;_.s=function(){return this.wb};_.t=Up;_.u=function(){var a;return Lh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.r(a)};_.hashCode=function(){return this.t()};_.toString=function(){return this.u()};var dd,ed,fd;rh(62,1,{},Mh);_.L=function(a){var b;b=new Mh;b.e=4;a>1?(b.c=Rh(this,a-1)):(b.c=this);return b};_.M=function(){Kh(this);return this.b};_.N=function(){return Lh(this)};_.O=function(){Kh(this);return this.i};_.P=function(){return (this.e&4)!=0};_.Q=function(){return (this.e&1)!=0};_.u=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Kh(this),this.k)};_.e=0;_.g=0;var Jh=1;var ge=Oh(1);var Zd=Oh(62);rh(97,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var qd=Oh(97);var G;rh(20,1,{20:1},O);_.b=0;_.c=false;_.d=0;var rd=Oh(20);rh(233,1,op);_.u=function(){var a;return Lh(this.wb)+'@'+(a=r(this)>>>0,a.toString(16))};var td=Oh(233);rh(21,233,op,S);_.v=function(){Q(this)};_.w=Sp;_.a=false;var sd=Oh(21);rh(17,233,{12:1,17:1},cb);_.v=function(){U(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var vd=Oh(17);rh(163,1,rp,db);_.A=function(){V(this.a)};var ud=Oh(163);rh(19,233,{12:1,19:1},ob,pb);_.v=function(){eb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var zd=Oh(19);rh(164,1,up,qb);_.A=function(){P(this.a)};var wd=Oh(164);rh(165,1,rp,rb);_.A=function(){jb(this.a)};var xd=Oh(165);rh(166,1,{},sb);_.B=function(a){hb(this.a,a)};var yd=Oh(166);rh(125,1,{},xb);_.a=0;_.b=100;_.e=0;var Ad=Oh(125);rh(79,1,op,zb);_.v=function(){yb(this)};_.w=Sp;_.a=false;var Bd=Oh(79);rh(172,1,{},Lb);_.u=function(){var a;return Kh(Cd),Cd.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.a=0;var Ab;var Cd=Oh(172);rh(58,1,{58:1});_.e='';_.g='';_.i=true;_.j='';var Jd=Oh(58);rh(167,58,{12:1,58:1,39:1},_b);_.v=function(){if(this.d>=0){this.d=-2;u((H(),H(),G),new ac(this),sp,null)}};_.r=Tp;_.D=$p;_.t=Up;_.w=_p;_.u=function(){var a;return Kh(Hd),Hd.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.d=0;var Hd=Oh(167);rh(168,1,rp,ac);_.A=function(){Vb(this.a)};var Dd=Oh(168);rh(169,1,rp,bc);_.A=function(){Ob(this.a,this.b)};var Ed=Oh(169);rh(170,1,rp,cc);_.A=function(){Wb(this.a)};var Fd=Oh(170);rh(171,1,rp,dc);_.A=function(){Rb(this.a)};var Gd=Oh(171);rh(146,1,{},ec);_.handleEvent=function(a){Pb(this.a,a)};var Id=Oh(146);rh(127,1,{});var Md=Oh(127);rh(136,1,{},ic);_.B=function(a){gc(this.a,a)};var Kd=Oh(136);rh(137,1,rp,jc);_.A=function(){hc(this.a,this.b)};var Ld=Oh(137);rh(128,127,{});var Nd=Oh(128);rh(27,1,op,nc);_.v=function(){lc(this)};_.w=Sp;_.a=false;var Od=Oh(27);rh(4,1,{3:1,4:1});_.F=function(a){return new Error(a)};_.G=function(){return this.f};_.H=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Lh(this.wb),c==null?a:a+': '+c);pc(this,rc(this.F(b)));Tc(this)};_.u=function(){return qc(this,this.G())};_.e=xp;_.g=true;var ke=Oh(4);rh(13,4,{3:1,13:1,4:1});var ae=Oh(13);rh(5,13,zp);var he=Oh(5);rh(51,5,zp);var de=Oh(51);rh(94,51,zp);var Sd=Oh(94);rh(40,94,{40:1,3:1,13:1,5:1,4:1},wc);_.G=function(){vc(this);return this.c};_.I=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Pd=Oh(40);var Qd=Oh(0);rh(216,1,{});var Rd=Oh(216);var yc=0,zc=0,Ac=-1;rh(105,216,{},Oc);var Kc;var Td=Oh(105);var Rc;rh(227,1,{});var Vd=Oh(227);rh(95,227,{},Vc);var Ud=Oh(95);rh(53,1,{53:1},Ah);_.J=function(){var a,b;b=this.a;if(od(b)===od(yh)){b=this.a;if(od(b)===od(yh)){b=this.b.J();a=this.a;if(od(a)!==od(yh)&&od(a)!==od(b)){throw dh(new Xh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}this.a=b;this.b=null}}return b};var yh;var Wd=Oh(53);var Eh;rh(92,1,{89:1});_.u=Sp;var Xd=Oh(92);dd={3:1,90:1,31:1};var Yd=Oh(90);rh(50,1,{3:1,50:1});var fe=Oh(50);ed={3:1,31:1,50:1};var $d=Oh(226);rh(35,1,{3:1,31:1,35:1});_.r=Tp;_.t=Up;_.u=function(){return this.a!=null?this.a:''+this.b};_.b=0;var _d=Oh(35);rh(10,5,zp,Xh,Yh);var be=Oh(10);rh(32,50,{3:1,31:1,32:1,50:1},Zh);_.r=function(a){return jd(a,32)&&a.a==this.a};_.t=Sp;_.u=function(){return ''+this.a};_.a=0;var ce=Oh(32);var _h;rh(283,1,{});rh(52,51,zp,ci,di);_.F=function(a){return new TypeError(a)};var ee=Oh(52);fd={3:1,89:1,31:1,2:1};var je=Oh(2);rh(93,92,{89:1},ji);var ie=Oh(93);rh(287,1,{});rh(69,5,zp,ki);var le=Oh(69);rh(228,1,{48:1});_.R=Yp;_.V=function(){return new vj(this,0)};_.W=function(){return new Fj(null,this.V())};_.T=function(a){throw dh(new ki('Add not supported on this collection'))};_.u=function(){var a,b,c;c=new xj('[',']');for(b=this.S();b.Y();){a=b.Z();wj(c,a===this?'(this Collection)':a==null?Ap:vh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var me=Oh(228);rh(231,1,{215:1});_.r=function(a){var b,c,d;if(a===this){return true}if(!jd(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new yi((new vi(d)).a);c.b;){b=xi(c);if(!ni(this,b)){return false}}return true};_.t=function(){return Pi(new vi(this))};_.u=function(){var a,b,c;c=new xj('{','}');for(b=new yi((new vi(this)).a);b.b;){a=xi(b);wj(c,oi(this,a._())+'='+oi(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var xe=Oh(231);rh(124,231,{215:1});var pe=Oh(124);rh(230,228,{48:1,238:1});_.V=function(){return new vj(this,1)};_.r=function(a){var b;if(a===this){return true}if(!jd(a,25)){return false}b=a;if(ti(b.a)!=this.U()){return false}return li(this,b)};_.t=function(){return Pi(this)};var ye=Oh(230);rh(25,230,{25:1,48:1,238:1},vi);_.S=function(){return new yi(this.a)};_.U=Wp;var oe=Oh(25);rh(26,1,{},yi);_.X=Vp;_.Z=function(){return xi(this)};_.Y=Xp;_.b=false;var ne=Oh(26);rh(229,228,{48:1,235:1});_.V=function(){return new vj(this,16)};_.$=function(a,b){throw dh(new ki('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.r=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,15)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Oi(f);for(c=new Oi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.t=function(){return Qi(this)};_.S=function(){return new zi(this)};var re=Oh(229);rh(103,1,{},zi);_.X=Vp;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Gi(this.b,this.a++)};_.a=0;var qe=Oh(103);rh(54,228,{48:1},Ai);_.S=function(){var a;return a=new yi((new vi(this.a)).a),new Bi(a)};_.U=Wp;var te=Oh(54);rh(71,1,{},Bi);_.X=Vp;_.Y=function(){return this.a.b};_.Z=function(){var a;return a=xi(this.a),a.ab()};var se=Oh(71);rh(113,1,Cp);_.r=function(a){var b;if(!jd(a,49)){return false}b=a;return Ri(this.a,b._())&&Ri(this.b,b.ab())};_._=Sp;_.ab=Xp;_.t=function(){return qj(this.a)^qj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.u=function(){return this.a+'='+this.b};var ue=Oh(113);rh(114,113,Cp,Ci);var ve=Oh(114);rh(232,1,Cp);_.r=function(a){var b;if(!jd(a,49)){return false}b=a;return Ri(this.b.value[0],b._())&&Ri(mj(this),b.ab())};_.t=function(){return qj(this.b.value[0])^qj(mj(this))};_.u=function(){return this.b.value[0]+'='+mj(this)};var we=Oh(232);rh(15,229,{3:1,15:1,48:1,235:1},Mi,Ni);_.$=function(a,b){Uj(this.a,a,b)};_.T=function(a){return Ei(this,a)};_.R=function(a){Fi(this,a)};_.S=function(){return new Oi(this)};_.U=function(){return this.a.length};var Ae=Oh(15);rh(18,1,{},Oi);_.X=Vp;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ze=Oh(18);rh(41,124,{3:1,41:1,215:1},Si);var Be=Oh(41);rh(74,1,{},Yi);_.R=Yp;_.S=function(){return new Zi(this)};_.b=0;var De=Oh(74);rh(75,1,{},Zi);_.X=Vp;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ce=Oh(75);var aj;rh(72,1,{},kj);_.R=Yp;_.S=function(){return new lj(this)};_.b=0;_.c=0;var Ge=Oh(72);rh(73,1,{},lj);_.X=Vp;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new nj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Ee=Oh(73);rh(126,232,Cp,nj);_._=function(){return this.b.value[0]};_.ab=function(){return mj(this)};_.bb=function(a){return ij(this.a,this.b.value[0],a)};_.c=0;var Fe=Oh(126);rh(104,1,{});_.X=function(a){sj(this,a)};_.cb=function(){return this.d};_.db=eq;_.d=0;_.e=0;var Ie=Oh(104);rh(70,104,{});var He=Oh(70);rh(24,1,{},vj);_.cb=Sp;_.db=function(){uj(this);return this.c};_.X=function(a){uj(this);this.d.X(a)};_.eb=function(a){uj(this);if(this.d.Y()){a.B(this.d.Z());return true}return false};_.a=0;_.c=0;var Je=Oh(24);rh(63,1,{},xj);_.u=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ke=Oh(63);var Te=Qh();rh(115,1,{});_.c=false;var Ue=Oh(115);rh(34,115,{},Fj);var Se=Oh(34);rh(117,70,{},Jj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Kj(this,a)));return this.b};_.b=false;var Me=Oh(117);rh(120,1,{},Kj);_.B=function(a){Ij(this.a,this.b,a)};var Le=Oh(120);rh(116,70,{},Mj);_.eb=function(a){return this.a.eb(new Nj(a))};var Oe=Oh(116);rh(119,1,{},Nj);_.B=function(a){Lj(this.a,a)};var Ne=Oh(119);rh(118,1,{},Pj);_.B=function(a){Oj(this,a)};var Pe=Oh(118);rh(121,1,{},Qj);_.B=function(a){};var Qe=Oh(121);rh(122,1,{},Sj);_.B=function(a){Rj(this,a)};var Re=Oh(122);rh(285,1,{});rh(234,1,{});var Ve=Oh(234);rh(282,1,{});var Zj=0;var _j,ak=0,bk;rh(742,1,{});rh(757,1,{});rh(11,1,{11:1});_.gb=jq;var We=Oh(11);rh(33,$wnd.React.Component,{});qh(oh[1],_);_.render=function(){return nk(this.a)};var Xe=Oh(33);rh(36,11,{11:1});_.kb=function(){return false};_.lb=function(a,b){};_.nb=function(a){return false};_.ob=function(){return pk(this)};_.o=false;_.p=false;var ik=1,jk;var Ye=Oh(36);rh(253,$wnd.Function,{},qk);_.K=function(a){return yb(jk),jk=null,null};rh(9,35,{3:1,31:1,35:1,9:1},al);var Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k;var Ze=Ph(9,bl);rh(42,36,Fp);_.tb=Zp;_.hb=function(){var a;a=R(this.g.b);return $wnd.React.createElement('footer',rk(new $wnd.Object,ad(Wc(je,1),np,2,6,['footer'])),Om(new Pm),$wnd.React.createElement('ul',rk(new $wnd.Object,ad(Wc(je,1),np,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',tk(rk(new $wnd.Object,ad(Wc(je,1),np,2,6,[(_o(),Zo)==a?Gp:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',tk(rk(new $wnd.Object,ad(Wc(je,1),np,2,6,[Yo==a?Gp:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',tk(rk(new $wnd.Object,ad(Wc(je,1),np,2,6,[$o==a?Gp:null])),'#completed'),'Completed'))),this.tb()?$wnd.React.createElement(Ep,uk(rk(new $wnd.Object,ad(Wc(je,1),np,2,6,['clear-completed'])),th(Jm.prototype.sb,Jm,[this])),'Clear Completed'):null)};var Of=Oh(42);rh(173,42,Fp);_.tb=Zp;var cl,dl;var Sf=Oh(173);rh(174,173,{12:1,39:1,11:1,42:1},il);_.v=function(){if(this.d>=0){this.d=-2;u((H(),H(),G),new ml(this),sp,null)}};_.r=Tp;_.mb=aq;_.D=$p;_.tb=function(){return R(this.a)};_.t=Up;_.w=_p;_.u=function(){var a;return Kh(jf),jf.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.ob=function(){var b;try{return B((H(),H(),G),this.b,new kl(this))}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){b=a;throw dh(b)}else if(jd(a,4)){b=a;throw dh(new Yh(b))}else throw dh(a)}};_.d=0;var jf=Oh(174);rh(175,1,Ip,jl);_.C=function(){return gl(this.a)};var $e=Oh(175);rh(178,1,Ip,kl);_.C=cq;var _e=Oh(178);rh(176,1,up,ll);_.A=bq;var af=Oh(176);rh(177,1,rp,ml);_.A=function(){hl(this.a)};var bf=Oh(177);rh(43,36,Jp);_.hb=function(){var a,b;b=R(this.d.e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',rk(new $wnd.Object,ad(Wc(je,1),np,2,6,['todo-count'])),$wnd.React.createElement('strong',null,''+b),' '+a+' left')};var Nf=Oh(43);rh(179,43,Jp);var nl,ol;var Rf=Oh(179);rh(180,179,{12:1,39:1,11:1,43:1},sl);_.v=function(){if(this.c>=0){this.c=-2;u((H(),H(),G),new ul(this),sp,null)}};_.r=Tp;_.mb=aq;_.D=Xp;_.t=Up;_.w=fq;_.u=function(){var a;return Kh(gf),gf.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.ob=function(){var b;try{return B((H(),H(),G),this.a,new vl(this))}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){b=a;throw dh(b)}else if(jd(a,4)){b=a;throw dh(new Yh(b))}else throw dh(a)}};_.c=0;var gf=Oh(180);rh(181,1,up,tl);_.A=bq;var cf=Oh(181);rh(182,1,rp,ul);_.A=function(){rl(this.a)};var df=Oh(182);rh(183,1,Ip,vl);_.C=cq;var ef=Oh(183);rh(155,1,{},xl);_.J=function(){return wl(this)};var ff=Oh(155);rh(153,1,{},zl);_.J=function(){return yl(this)};var hf=Oh(153);rh(46,36,Kp);_.hb=function(){return $wnd.React.createElement(Lp,vk(zk(Ak(Dk(Bk(rk(new $wnd.Object,ad(Wc(je,1),np,2,6,['new-todo']))),($(this.b),this.f)),th(en.prototype.rb,en,[this])),th(fn.prototype.qb,fn,[this]))))};_.f='';var ag=Oh(46);rh(200,46,Kp);var Cl,Dl;var Uf=Oh(200);rh(201,200,{12:1,39:1,11:1,46:1},Ll);_.v=function(){if(this.d>=0){this.d=-2;u((H(),H(),G),new Ql(this),sp,null)}};_.r=Tp;_.mb=aq;_.D=$p;_.t=Up;_.w=_p;_.u=function(){var a;return Kh(qf),qf.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.ob=function(){var b;try{return B((H(),H(),G),this.a,new Ml(this))}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){b=a;throw dh(b)}else if(jd(a,4)){b=a;throw dh(new Yh(b))}else throw dh(a)}};_.d=0;var qf=Oh(201);rh(204,1,Ip,Ml);_.C=cq;var kf=Oh(204);rh(205,1,rp,Nl);_.A=function(){Al(this.a)};var lf=Oh(205);rh(206,1,rp,Ol);_.A=function(){Il(this.a,this.b)};var mf=Oh(206);rh(202,1,up,Pl);_.A=bq;var nf=Oh(202);rh(203,1,rp,Ql);_.A=function(){Jl(this.a)};var of=Oh(203);rh(161,1,{},Sl);_.J=function(){return Rl(this)};var pf=Oh(161);rh(44,36,Mp);_.lb=function(a,b){Tl(this)};_.vb=dq;_.gb=function(){jm(this,this.ub())};_.hb=function(){var a,b;b=this.ub();a=($(b.a),b.g);return $wnd.React.createElement('li',rk(new $wnd.Object,ad(Wc(je,1),np,2,6,[a?Np:null,this.vb()?'editing':null])),$wnd.React.createElement('div',rk(new $wnd.Object,ad(Wc(je,1),np,2,6,['view'])),$wnd.React.createElement(Lp,zk(wk(Ck(rk(new $wnd.Object,ad(Wc(je,1),np,2,6,['toggle'])),(_k(),Gk)),a),th(nn.prototype.qb,nn,[b]))),$wnd.React.createElement('label',Ek(new $wnd.Object,th(on.prototype.sb,on,[this,b])),($(b.b),b.i)),$wnd.React.createElement(Ep,uk(rk(new $wnd.Object,ad(Wc(je,1),np,2,6,['destroy'])),th(pn.prototype.sb,pn,[this,b])))),$wnd.React.createElement(Lp,Ak(zk(yk(xk(rk(sk(new $wnd.Object,th(qn.prototype.B,qn,[this])),ad(Wc(je,1),np,2,6,['edit'])),($(this.a),this.i)),th(rn.prototype.pb,rn,[this,b])),th(mn.prototype.qb,mn,[this])),th(sn.prototype.rb,sn,[this,b]))))};_.j=false;var eg=Oh(44);rh(184,44,Mp);_.kb=function(){var a;a=(ab(this.c),this.q.props['a']);if(!!a&&a.f<0){return true}return false};_.ub=function(){return this.q.props['a']};_.vb=dq;_.nb=function(a){return cm(this,a)};var _l,am;var Wf=Oh(184);rh(185,184,{12:1,39:1,11:1,44:1},lm);_.lb=function(b,c){var d;try{u((H(),H(),G),new om(this,b,c),wp,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){d=a;throw dh(d)}else if(jd(a,4)){d=a;throw dh(new Yh(d))}else throw dh(a)}};_.v=function(){if(this.f>=0){this.f=-2;u((H(),H(),G),new mm(this),sp,null)}};_.r=Tp;_.mb=aq;_.D=eq;_.ub=function(){return ab(this.c),this.q.props['a']};_.t=Up;_.w=iq;_.vb=function(){return R(this.d)};_.nb=function(b){var c;try{return t((H(),H(),G),new pm(this,b),75497472,null)}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){c=a;throw dh(c)}else if(jd(a,4)){c=a;throw dh(new Yh(c))}else throw dh(a)}};_.u=function(){var a;return Kh(Bf),Bf.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.ob=function(){var b;try{return B((H(),H(),G),this.b,new nm(this))}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){b=a;throw dh(b)}else if(jd(a,4)){b=a;throw dh(new Yh(b))}else throw dh(a)}};_.f=0;var Bf=Oh(185);rh(188,1,rp,mm);_.A=function(){fm(this.a)};var rf=Oh(188);rh(189,1,Ip,nm);_.C=cq;var sf=Oh(189);rh(190,1,rp,om);_.A=function(){Tl(this.a)};var tf=Oh(190);rh(191,1,Ip,pm);_.C=function(){return gm(this.a,this.b)};var uf=Oh(191);rh(192,1,rp,qm);_.A=function(){km(this.a,Mn(this.b))};var vf=Oh(192);rh(193,1,rp,rm);_.A=function(){Zl(this.a,this.b)};var wf=Oh(193);rh(194,1,rp,sm);_.A=function(){Ul(this.a,this.b)};var xf=Oh(194);rh(186,1,Ip,tm);_.C=function(){return hm(this.a)};var yf=Oh(186);rh(187,1,up,um);_.A=bq;var zf=Oh(187);rh(157,1,{},wm);_.J=function(){return vm(this)};var Af=Oh(157);rh(45,36,Op);_.hb=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(Pp,rk(new $wnd.Object,ad(Wc(je,1),np,2,6,[Pp])),$wnd.React.createElement('h1',null,'todos'),gn(new hn)),R(this.d.c)?null:$wnd.React.createElement('section',rk(new $wnd.Object,ad(Wc(je,1),np,2,6,[Pp])),$wnd.React.createElement(Lp,zk(Ck(rk(new $wnd.Object,ad(Wc(je,1),np,2,6,['toggle-all'])),(_k(),Gk)),th(Bn.prototype.qb,Bn,[this]))),$wnd.React.createElement.apply(null,['ul',rk(new $wnd.Object,ad(Wc(je,1),np,2,6,['todo-list']))].concat((a=Ej(Dj(R(this.f.c).W()),(b=new Mi,b)),Li(a,_c(a.a.length)))))),R(this.d.c)?null:Km(new Lm)))};var ig=Oh(45);rh(195,45,Op);var ym,zm;var Yf=Oh(195);rh(196,195,{12:1,39:1,11:1,45:1},Dm);_.v=function(){if(this.c>=0){this.c=-2;u((H(),H(),G),new Fm(this),sp,null)}};_.r=Tp;_.mb=aq;_.D=Xp;_.t=Up;_.w=fq;_.u=function(){var a;return Kh(Gf),Gf.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.ob=function(){var b;try{return B((H(),H(),G),this.a,new Gm(this))}catch(a){a=bh(a);if(jd(a,5)||jd(a,7)){b=a;throw dh(b)}else if(jd(a,4)){b=a;throw dh(new Yh(b))}else throw dh(a)}};_.c=0;var Gf=Oh(196);rh(197,1,up,Em);_.A=bq;var Cf=Oh(197);rh(198,1,rp,Fm);_.A=function(){rl(this.a)};var Df=Oh(198);rh(199,1,Ip,Gm);_.C=cq;var Ef=Oh(199);rh(159,1,{},Im);_.J=function(){return Hm(this)};var Ff=Oh(159);rh(252,$wnd.Function,{},Jm);_.sb=function(a){po(this.a.f)};rh(209,1,{},Lm);var Hf=Oh(209);rh(83,1,{},Mm);_.J=function(){return Dh(yl((new To(this.a)).b.a))};var If=Oh(83);rh(154,1,{},Nm);_.J=function(){return Dh(yl(this.a))};var Jf=Oh(154);rh(207,1,{},Pm);var Kf=Oh(207);rh(84,1,{},Qm);_.J=function(){return Dh(wl((new Uo(this.a)).b.a))};var Lf=Oh(84);rh(156,1,{},Rm);_.J=function(){return Dh(wl(this.a))};var Mf=Oh(156);rh(251,$wnd.Function,{},Wm);_.ib=function(a){return new Xm(a)};rh(98,33,{},Xm);_.jb=function(){return el(),Dh(yl((new To(dl.a)).b.a))};_.componentWillUnmount=gq;_.shouldComponentUpdate=hq;var Pf=Oh(98);rh(255,$wnd.Function,{},Ym);_.ib=function(a){return new Zm(a)};rh(99,33,{},Zm);_.jb=function(){return pl(),Dh(wl((new Uo(ol.a)).b.a))};_.componentWillUnmount=gq;_.shouldComponentUpdate=hq;var Qf=Oh(99);rh(267,$wnd.Function,{},$m);_.ib=function(a){return new _m(a)};rh(102,33,{},_m);_.jb=function(){return El(),Dh(Rl((new Vo(Dl.a)).b.a))};_.componentWillUnmount=gq;_.shouldComponentUpdate=hq;var Tf=Oh(102);rh(256,$wnd.Function,{},an);_.ib=function(a){return new bn(a)};rh(100,33,{},bn);_.jb=function(){return bm(),Dh(vm((new Wo(am.a)).b.a))};_.componentDidUpdate=function(a,b){this.a.lb(a,b)};_.componentWillUnmount=gq;_.shouldComponentUpdate=hq;var Vf=Oh(100);rh(265,$wnd.Function,{},cn);_.ib=function(a){return new dn(a)};rh(101,33,{},dn);_.jb=function(){return Am(),Dh(Hm((new Xo(zm.a)).b.a))};_.componentWillUnmount=gq;_.shouldComponentUpdate=hq;var Xf=Oh(101);rh(268,$wnd.Function,{},en);_.rb=function(a){Bl(this.a,a)};rh(269,$wnd.Function,{},fn);_.qb=function(a){Hl(this.a,a)};rh(208,1,{},hn);var Zf=Oh(208);rh(87,1,{},jn);_.J=function(){return Dh(Rl((new Vo(this.a)).b.a))};var $f=Oh(87);rh(162,1,{},kn);_.J=function(){return Dh(Rl(this.a))};var _f=Oh(162);rh(263,$wnd.Function,{},mn);_.qb=function(a){em(this.a,a)};rh(257,$wnd.Function,{},nn);_.qb=function(a){Sn(this.a)};rh(259,$wnd.Function,{},on);_.sb=function(a){Vl(this.a,this.b)};rh(260,$wnd.Function,{},pn);_.sb=function(a){Wl(this.a,this.b)};rh(261,$wnd.Function,{},qn);_.B=function(a){Xl(this.a,a)};rh(262,$wnd.Function,{},rn);_.pb=function(a){$l(this.a,this.b)};rh(264,$wnd.Function,{},sn);_.rb=function(a){Yl(this.a,this.b,a)};rh(210,1,{},wn);var bg=Oh(210);rh(85,1,{},xn);_.J=function(){return Dh(vm((new Wo(this.a)).b.a))};var cg=Oh(85);rh(158,1,{},yn);_.J=function(){return Dh(vm(this.a))};var dg=Oh(158);rh(266,$wnd.Function,{},Bn);_.qb=function(a){xm(this.a,a)};rh(88,1,{},Dn);var fg=Oh(88);rh(86,1,{},En);_.J=function(){return Dh(Hm((new Xo(this.a)).b.a))};var gg=Oh(86);rh(160,1,{},Fn);_.J=function(){return Dh(Hm(this.a))};var hg=Oh(160);rh(59,1,{59:1});_.g=false;var Yg=Oh(59);rh(60,59,{12:1,39:1,60:1,59:1},Tn);_.v=function(){Kn(this)};_.r=function(a){return Ln(this,a)};_.D=$p;_.t=eq;_.w=iq;_.u=function(){var a;return Kh(Ag),Ag.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var Jn=0;var Ag=Oh(60);rh(211,1,rp,Un);_.A=function(){On(this.a)};var jg=Oh(211);rh(212,1,rp,Vn);_.A=function(){Pn(this.a)};var kg=Oh(212);rh(55,128,{55:1});var Sg=Oh(55);rh(76,55,{12:1,76:1,55:1},bo);_.v=function(){if(this.f>=0){this.f=-2;u((H(),H(),G),new co(this),sp,null)}};_.r=Tp;_.t=Up;_.w=iq;_.u=function(){var a;return Kh(tg),tg.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.f=0;var tg=Oh(76);rh(133,1,rp,co);_.A=function(){$n(this.a)};var lg=Oh(133);rh(134,1,rp,eo);_.A=function(){fc(this.a,this.b,true)};var mg=Oh(134);rh(129,1,Ip,fo);_.C=function(){return _n(this.a)};var ng=Oh(129);rh(135,1,Ip,go);_.C=function(){return Wn(this.a,this.c,this.b)};_.b=false;var og=Oh(135);rh(130,1,Ip,ho);_.C=function(){return $h(ih(Bj(Zn(this.a))))};var pg=Oh(130);rh(131,1,Ip,io);_.C=function(){return $h(ih(Bj(Cj(Zn(this.a),new dp))))};var qg=Oh(131);rh(132,1,Ip,jo);_.C=function(){return ao(this.a)};var rg=Oh(132);rh(106,1,{},mo);_.J=function(){return new bo};var ko;var sg=Oh(106);rh(56,1,{56:1});var Xg=Oh(56);rh(77,56,{12:1,77:1,56:1},uo);_.v=function(){if(this.a>=0){this.a=-2;u((H(),H(),G),new xo,sp,null)}};_.r=Tp;_.t=Up;_.w=function(){return this.a<0};_.u=function(){var a;return Kh(zg),zg.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.a=0;var zg=Oh(77);rh(141,1,rp,vo);_.A=function(){Rn(this.b,this.a)};var ug=Oh(141);rh(142,1,rp,wo);_.A=function(){qo(this.a)};var vg=Oh(142);rh(139,1,rp,xo);_.A=jq;var wg=Oh(139);rh(140,1,rp,yo);_.A=function(){ro(this.a,this.b)};_.b=false;var xg=Oh(140);rh(108,1,{},zo);_.J=function(){return new uo(this.a.J())};var yg=Oh(108);rh(57,1,{57:1});var _g=Oh(57);rh(78,57,{12:1,78:1,57:1},Io);_.v=function(){if(this.g>=0){this.g=-2;u((H(),H(),G),new Jo(this),sp,null)}};_.r=Tp;_.t=Up;_.w=function(){return this.g<0};_.u=function(){var a;return Kh(Hg),Hg.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.g=0;var Hg=Oh(78);rh(151,1,rp,Jo);_.A=function(){Do(this.a)};var Bg=Oh(151);rh(147,1,Ip,Ko);_.C=function(){var a;return a=Ub(this.a.i),fi(Rp,a)||fi(Np,a)||fi('',a)?fi(Rp,a)?(_o(),Yo):fi(Np,a)?(_o(),$o):(_o(),Zo):(_o(),Zo)};var Cg=Oh(147);rh(148,1,Ip,Lo);_.C=function(){return Eo(this.a)};var Dg=Oh(148);rh(149,1,up,Mo);_.A=function(){Fo(this.a)};var Eg=Oh(149);rh(150,1,up,No);_.A=function(){Go(this.a)};var Fg=Oh(150);rh(111,1,{},Oo);_.J=function(){return new Io(this.b.J(),this.a.J())};var Gg=Oh(111);rh(110,1,{},Ro);_.J=function(){return Dh(new _b)};var Po;var Ig=Oh(110);rh(82,1,{},So);var Og=Oh(82);rh(64,1,{},To);var Jg=Oh(64);rh(68,1,{},Uo);var Kg=Oh(68);rh(67,1,{},Vo);var Lg=Oh(67);rh(65,1,{},Wo);var Mg=Oh(65);rh(66,1,{},Xo);var Ng=Oh(66);rh(37,35,{3:1,31:1,35:1,37:1},ap);var Yo,Zo,$o;var Pg=Ph(37,bp);rh(107,1,{},cp);_.J=kq;var Qg=Oh(107);rh(138,1,{},dp);_.fb=function(a){return !Nn(a)};var Rg=Oh(138);rh(144,1,{},ep);_.fb=function(a){return Nn(a)};var Tg=Oh(144);rh(145,1,{},fp);_.B=function(a){Yn(this.a,a)};var Ug=Oh(145);rh(143,1,{},gp);_.B=function(a){oo(this.a,a)};_.a=false;var Vg=Oh(143);rh(109,1,{},hp);_.J=kq;var Wg=Oh(109);rh(152,1,{},ip);_.fb=function(a){return Bo(this.a,a)};var Zg=Oh(152);rh(112,1,{},jp);_.J=kq;var $g=Oh(112);var kp=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=mh;kh(xh);nh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();