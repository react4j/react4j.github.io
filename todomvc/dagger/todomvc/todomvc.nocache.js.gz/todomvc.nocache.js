function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='E9D0BAB78EB96D9D69A769CFC98DF626',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'E9D0BAB78EB96D9D69A769CFC98DF626';function o(){}
function oh(){}
function kh(){}
function Hb(){}
function Mc(){}
function Tc(){}
function Tn(){}
function Aj(){}
function Bj(){}
function Pk(){}
function Fm(){}
function Jm(){}
function Nm(){}
function Rm(){}
function Vm(){}
function Ao(){}
function gp(){}
function hp(){}
function Rc(a){Qc()}
function Bm(a){Am=a}
function Em(a){Dm=a}
function bn(a){an=a}
function nn(a){mn=a}
function rn(a){qn=a}
function wh(){wh=kh}
function yi(){pi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function lb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function cc(a){this.a=a}
function lc(a){this.a=a}
function Mh(a){this.a=a}
function Xh(a){this.a=a}
function hi(a){this.a=a}
function mi(a){this.a=a}
function ni(a){this.a=a}
function li(a){this.b=a}
function Ai(a){this.c=a}
function yj(a){this.a=a}
function Dj(a){this.a=a}
function Yk(a){this.a=a}
function _k(a){this.a=a}
function al(a){this.a=a}
function bl(a){this.a=a}
function il(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function zl(a){this.a=a}
function Bl(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function Fl(a){this.a=a}
function am(a){this.a=a}
function dm(a){this.a=a}
function fm(a){this.a=a}
function km(a){this.a=a}
function lm(a){this.a=a}
function tm(a){this.a=a}
function wm(a){this.a=a}
function xm(a){this.a=a}
function ym(a){this.a=a}
function Zm(a){this.a=a}
function $m(a){this.a=a}
function cn(a){this.a=a}
function dn(a){this.a=a}
function gn(a){this.a=a}
function on(a){this.a=a}
function un(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function yn(a){this.a=a}
function An(a){this.a=a}
function On(a){this.a=a}
function Pn(a){this.a=a}
function Qn(a){this.a=a}
function Rn(a){this.a=a}
function Sn(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function uo(a){this.a=a}
function vo(a){this.a=a}
function wo(a){this.a=a}
function xo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Vo(a){this.a=a}
function Wo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ip(a){this.a=a}
function jp(a){this.a=a}
function kp(a){this.a=a}
function Wp(){fc(this.c)}
function Yp(){fc(this.b)}
function Ki(){this.a=Ti()}
function Yi(){this.a=Ti()}
function gc(a){!!a&&a.v()}
function V(a){!!a&&cb(a)}
function w(a){--a.e;D(a)}
function Sp(a){aj(this,a)}
function Vp(a){Qh(this,a)}
function gb(a){Vb((J(),a))}
function hb(a){Wb((J(),a))}
function jb(a){Xb((J(),a))}
function Co(a,b){$l(b,a)}
function Uj(a,b){Tj(a,b)}
function Cj(a,b){tj(a.a,b)}
function jc(a,b){di(a.e,b)}
function Hl(a,b){ko(a.j,b)}
function Bo(a,b){jo(a.b,b)}
function C(a,b){ab(a.f,b.f)}
function zj(a,b){a.a=b}
function Vj(a,b){a.key=b}
function sb(a,b){a.b=dj(b)}
function cl(a){a.c=2;fc(a.b)}
function Ol(a){a.f=2;fc(a.e)}
function Qk(a){a.d=2;fc(a.c)}
function Kb(a){a.a=-4&a.a|1}
function Wg(a){return a.e}
function Il(a,b){return a.g=b}
function Th(a,b){return a===b}
function Up(){return this.b}
function Pp(){return this.a}
function Rp(){return Lj(this)}
function $p(){mb(this.a.a)}
function Uk(a){mb(a.b);R(a.a)}
function Hn(a){R(a.a);cb(a.b)}
function tl(a){mb(a.a);cb(a.b)}
function Wn(a){cb(a.b);cb(a.a)}
function Yh(a){qc.call(this,a)}
function Qp(a){return this===a}
function si(a,b){return a.a[b]}
function zh(a){yh(a);return a.k}
function sc(){sc=kh;rc=new o}
function Jc(){Jc=kh;Ic=new Mc}
function J(){J=kh;I=new F}
function zo(){zo=kh;yo=new Ao}
function Pi(){Pi=kh;Oi=Ri()}
function zc(){zc=kh;!!(Qc(),Pc)}
function Rh(){mc(this);this.C()}
function Tp(){return fi(this.a)}
function Xp(){return this.c.i<0}
function Zp(){return this.b.i<0}
function Uc(a,b){return Fh(a,b)}
function Hj(a,b){a.splice(b,1)}
function ec(a,b,c){ci(a.e,b,c)}
function Xn(a,b,c){ec(a.c,b,c)}
function tj(a,b){zj(a,sj(a.a,b))}
function K(a,b){O(a);L(a,dj(b))}
function ej(a,b){while(a.ab(b));}
function sj(a,b){a.P(b);return a}
function ck(a,b){a.ref=b;return a}
function Jn(a){ib(a.b);return a.e}
function $n(a){ib(a.a);return a.d}
function Po(a){ib(a.d);return a.f}
function Ti(){Pi();return new Oi}
function db(a){J();Wb(a);a.e=-2}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function fi(a){return a.a.b+a.b.b}
function W(a){return !!a&&a.c.i<0}
function _p(a){return 1==this.a.d}
function aq(a){return 1==this.a.c}
function Zc(a){return new Array(a)}
function Vi(a,b){return a.a.get(b)}
function oi(a,b){this.a=a;this.b=b}
function dc(a,b){this.a=a;this.b=b}
function Kh(a,b){this.a=a;this.b=b}
function wj(a,b){this.a=a;this.b=b}
function ak(a,b){this.a=a;this.b=b}
function El(a,b){this.a=a;this.b=b}
function em(a,b){this.a=a;this.b=b}
function gm(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function im(a,b){this.a=a;this.b=b}
function jm(a,b){this.a=a;this.b=b}
function en(a,b){this.a=a;this.b=b}
function fn(a,b){this.a=a;this.b=b}
function hn(a,b){this.a=a;this.b=b}
function jn(a,b){this.a=a;this.b=b}
function Lk(a,b){Kh.call(this,a,b)}
function Fj(a,b,c){a.splice(b,0,c)}
function v(a,b,c){s(a,new H(c),b)}
function Kn(a){In(a,(ib(a.b),a.e))}
function ln(){this.a=Wj((Tm(),Sm))}
function pn(){this.a=Wj((Xm(),Wm))}
function zm(){this.a=Wj((Hm(),Gm))}
function Cm(){this.a=Wj((Lm(),Km))}
function _m(){this.a=Wj((Pm(),Om))}
function dh(){ah==null&&(ah=[])}
function Hc(){wc!=0&&(wc=0);yc=-1}
function Gc(a){$wnd.clearTimeout(a)}
function dk(a,b){a.href=b;return a}
function mk(a,b){a.value=b;return a}
function Vh(a,b){a.a+=''+b;return a}
function Un(a,b){this.a=a;this.b=b}
function so(a,b){this.a=a;this.b=b}
function Io(a,b){this.a=a;this.b=b}
function Jo(a,b){this.b=a;this.a=b}
function ep(a,b){Kh.call(this,a,b)}
function _n(a){$l(a,(ib(a.a),!a.d))}
function Rb(a){return !a.d?a:Rb(a.d)}
function bi(a){return !a?null:a.Y()}
function md(a){return a==null?null:a}
function cj(a){return a!=null?r(a):0}
function jd(a){return typeof a===np}
function ei(a){a.a=new Ki;a.b=new Yi}
function pi(a){a.a=Wc(ee,pp,1,0,5,1)}
function rb(a){J();qb(a);ub(a,2,true)}
function Sl(a){mb(a.b);R(a.c);cb(a.a)}
function bc(a,b){_b(a,b,false);hb(a.d)}
function Gj(a,b){Ej(b,0,a,0,b.length)}
function A(a,b,c){t(a,new G(b),c,null)}
function B(a,b,c){return t(a,c,2048,b)}
function X(a){return !(!!a&&1==(a.c&7))}
function ib(a){var b;Sb((J(),b=Nb,b),a)}
function Fb(a){this.d=dj(a);this.b=100}
function qh(a){this.b=dj(a);this.a=this}
function kb(a){this.c=new yi;this.b=a}
function Pj(){Pj=kh;Mj=new o;Oj=new o}
function gk(a,b){a.checked=b;return a}
function hk(a,b){a.onBlur=b;return a}
function ek(a,b){a.onClick=b;return a}
function ik(a,b){a.onChange=b;return a}
function jk(a,b){a.onKeyDown=b;return a}
function fk(a){a.autoFocus=true;return a}
function yh(a){if(a.k!=null){return}Hh(a)}
function gd(a,b){return a!=null&&ed(a,b)}
function Sh(a,b){return a.charCodeAt(b)}
function _c(a,b,c){return {l:a,m:b,h:c}}
function Tj(a,b){for(var c in a){b(c)}}
function Jj(b,c,d){try{b[c]=d}catch(a){}}
function rj(a,b){mj.call(this,a);this.a=b}
function qc(a){this.f=a;mc(this);this.C()}
function Ei(){this.a=new Ki;this.b=new Yi}
function P(){this.a=Wc(ee,pp,1,100,5,1)}
function T(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function Lj(a){return a.$H||(a.$H=++Kj)}
function jl(a,b){return new hl(dj(b),a.a)}
function Al(a,b){return new yl(dj(b),a.a)}
function hd(a){return typeof a==='boolean'}
function ld(a){return typeof a==='string'}
function u(a,b){return new xb(dj(a),null,b)}
function nc(a,b){a.e=b;b!=null&&Jj(b,yp,a)}
function ac(a,b){jc(b.c,a);gd(b,9)&&b.t()}
function aj(a,b){while(a.U()){Cj(b,a.V())}}
function $(a,b,c){Kb(dj(c));K(a.a[b],dj(c))}
function Mi(a,b){var c;c=a[Dp];c.call(a,b)}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function Ro(a){W((ib(a.d),a.f))&&To(a,null)}
function co(a){A((J(),J(),I),new go(a),Ip)}
function Do(a){A((J(),J(),I),new Ko(a),Ip)}
function Xl(a){A((J(),J(),I),new lm(a),Ip)}
function Ln(a){A((J(),J(),I),new Rn(a),Ip)}
function oo(a){return Nh(S(a.e).a-S(a.a).a)}
function Ac(a,b,c){return a.apply(b,c);var d}
function _i(a,b,c){this.a=a;this.b=b;this.c=c}
function $k(a,b,c){this.a=a;this.b=b;this.c=c}
function cm(a,b,c){this.a=a;this.b=b;this.c=c}
function vm(a,b,c){this.a=a;this.b=b;this.c=c}
function nk(a,b){a.onDoubleClick=b;return a}
function qi(a,b){a.a[a.a.length]=b;return true}
function mc(a){a.g&&a.e!==xp&&a.C();return a}
function Ch(a){var b;b=Bh(a);Jh(a,b);return b}
function Ph(){Ph=kh;Oh=Wc(ae,pp,32,256,0,1)}
function th(){th=kh;sh=$wnd.window.document}
function Qc(){Qc=kh;var a;!Sc();a=new Tc;Pc=a}
function Eb(a){while(true){if(!Db(a)){break}}}
function to(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new bb;this.a=new Fb(this.f)}
function uh(a,b,c,d){a.addEventListener(b,c,d)}
function ul(a,b){A((J(),J(),I),new El(a,b),Ip)}
function Tl(a,b){A((J(),J(),I),new jm(a,b),Ip)}
function Vl(a,b){A((J(),J(),I),new hm(a,b),Ip)}
function Wl(a,b){A((J(),J(),I),new gm(a,b),Ip)}
function Zl(a,b){A((J(),J(),I),new em(a,b),Ip)}
function ko(a,b){A((J(),J(),I),new so(a,b),Ip)}
function Go(a,b){A((J(),J(),I),new Io(a,b),Ip)}
function mo(a){Qh(new mi(a.g),new cc(a));ei(a.g)}
function ji(a){var b;b=a.a.V();a.b=ii(a);return b}
function Eh(a){var b;b=Bh(a);b.j=a;b.e=1;return b}
function vl(a,b){var c;c=b.target;xl(a,c.value)}
function pb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function uj(a,b,c){if(a.a.bb(c)){a.b=true;b.w(c)}}
function gj(a){if(!a.d){a.d=a.b.O();a.c=a.b.Q()}}
function Gb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function pj(a){lj(a);return new rj(a,new xj(a.a))}
function rh(a){dj(a);return gd(a,44)?a:new qh(a)}
function Ui(a,b){return !(a.a.get(b)===undefined)}
function Zk(a,b){return new Xk(dj(b),a.a,a.b,a.c)}
function bm(a,b){return new _l(dj(b),a.a,a.b,a.c)}
function um(a,b){return new sm(dj(b),a.a,a.b,a.c)}
function Wk(a){return B((J(),J(),I),a.b,new bl(a))}
function no(a){return wh(),0==S(a.e).a?true:false}
function Vk(a){return wh(),S(a.e.b).a>0?true:false}
function gl(a){return B((J(),J(),I),a.a,new ml(a))}
function wl(a){return B((J(),J(),I),a.a,new Cl(a))}
function Yl(a){return B((J(),J(),I),a.b,new dm(a))}
function rm(a){return B((J(),J(),I),a.a,new xm(a))}
function Yc(a){return Array.isArray(a)&&a.kb===oh}
function fd(a){return !Array.isArray(a)&&a.kb===oh}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Nc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ui(a,b){var c;c=a.a[b];Hj(a.a,b);return c}
function wi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function mm(a,b){var c;c=b.target;Go(a.e,c.checked)}
function io(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function kj(a){if(!a.b){lj(a);a.c=true}else{kj(a.b)}}
function Rk(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function dl(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function Pl(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Sj(){if(Nj==256){Mj=Oj;Oj=new o;Nj=0}++Nj}
function dj(a){if(a==null){throw Wg(new Rh)}return a}
function gi(a,b){if(b){return _h(a.a,b)}return false}
function oj(a,b){lj(a);return new rj(a,new vj(b,a.a))}
function In(a,b){A((J(),J(),I),new Un(a,b),75497472)}
function Mo(a){return Th(Np,a)||Th(Op,a)||Th('',a)}
function Di(a,b){return md(a)===md(b)||a!=null&&p(a,b)}
function xl(a,b){var c;c=a.f;if(b!=c){a.f=b;hb(a.b)}}
function $l(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function Mn(a,b){var c;c=a.e;if(b!=c){a.e=dj(b);hb(a.b)}}
function Dh(a,b){var c;c=Bh(a);Jh(a,c);c.e=b?8:0;return c}
function lk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function fj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function hj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function xj(a){fj.call(this,a._(),a.$()&-6);this.a=a}
function mj(a){if(!a){this.b=null;new yi}else{this.b=a}}
function vh(a,b,c,d){a.removeEventListener(b,c,d)}
function Oo(a){mb(a.e);mb(a.a);R(a.b);R(a.c);cb(a.d)}
function Gn(a){var b;T(a.a);b=S(a.a);Th(a.f,b)&&Mn(a,b)}
function nb(a){C((J(),J(),I),a);0==(a.f.a&up)&&D((null,I))}
function jo(a,b){return t((J(),J(),I),new to(a,b),Ip,null)}
function Ll(a,b){To(a.k,b);A((J(),J(),I),new em(a,b),Ip)}
function Gl(a,b){var c;if(S(a.c)){c=b.target;$l(a,c.value)}}
function oc(a,b){var c;c=zh(a.ib);return b==null?c:c+': '+b}
function ai(a,b){return b===a?'(this Map)':b==null?Ap:nh(b)}
function tn(a){return new $k(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function xn(a){return new cm(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function zn(a){return new vm(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function Qh(a,b){var c,d;for(d=a.O();d.U();){c=d.V();b.w(c)}}
function Ob(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);qb(a.e)}}
function Gh(a){if(a.M()){return null}var b=a.j;return gh[b]}
function _g(a){if(jd(a)){return a|0}return a.l|a.m<<22}
function Cn(a){uh((th(),$wnd.window.window),Lp,a.d,false)}
function Dn(a){vh((th(),$wnd.window.window),Lp,a.d,false)}
function Kl(a,b){A((J(),J(),I),new em(a,b),Ip);To(a.k,null)}
function Eo(a,b){var c;qj(lo(a.b),(c=new yi,c)).N(new jp(b))}
function Fh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function Fc(a){zc();$wnd.setTimeout(function(){throw a},0)}
function lj(a){if(a.b){lj(a.b)}else if(a.c){throw Wg(new Lh)}}
function mh(a){function b(){}
;b.prototype=a||{};return new b}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function kk(a){a.placeholder='What needs to be done?';return a}
function En(a,b){b.preventDefault();A((J(),J(),I),new Sn(a),Ip)}
function Gi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Hi(a,b){var c;return Fi(b,Gi(a,b==null?0:(c=r(b),c|0)))}
function fp(){dp();return $c(Uc(Kg,1),pp,34,0,[ap,cp,bp])}
function lo(a){ib(a.d);return new rj(null,new hj(new mi(a.g),0))}
function zi(a){pi(this);Gj(this.a,$h(a,Wc(ee,pp,1,fi(a.a),5,1)))}
function Li(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function ic(a){gc(a.g);!!a.e&&hc(a);V(a.a);V(a.c);gc(a.b);gc(a.f)}
function Hm(){Hm=kh;var a;Gm=(a=lh(Fm.prototype.hb,Fm,[]),a)}
function Lm(){Lm=kh;var a;Km=(a=lh(Jm.prototype.hb,Jm,[]),a)}
function Pm(){Pm=kh;var a;Om=(a=lh(Nm.prototype.hb,Nm,[]),a)}
function Tm(){Tm=kh;var a;Sm=(a=lh(Rm.prototype.hb,Rm,[]),a)}
function Xm(){Xm=kh;var a;Wm=(a=lh(Vm.prototype.hb,Vm,[]),a)}
function Ul(a){return wh(),Po(a.k)==a.n.props['a']?true:false}
function nd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Im(a){$wnd.React.Component.call(this,a);this.a=Zk(Am,this)}
function Mm(a){$wnd.React.Component.call(this,a);this.a=jl(Dm,this)}
function Qm(a){$wnd.React.Component.call(this,a);this.a=Al(an,this)}
function Um(a){$wnd.React.Component.call(this,a);this.a=bm(mn,this)}
function Ym(a){$wnd.React.Component.call(this,a);this.a=um(qn,this)}
function vj(a,b){fj.call(this,b._(),b.$()&-16449);this.a=a;this.c=b}
function eb(a,b){var c,d;qi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function To(a,b){var c;c=a.f;if(!(b==c||!!b&&Yn(b,c))){a.f=b;hb(a.d)}}
function Dc(a,b,c){var d;d=Bc();try{return Ac(a,b,c)}finally{Ec(d)}}
function ih(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function _j(a,b,c){!Th(c,'key')&&!Th(c,'ref')&&(a[c]=b[c],undefined)}
function ij(a,b){!a.a?(a.a=new Xh(a.d)):Vh(a.a,a.b);Vh(a.a,b);return a}
function qj(a,b){var c;kj(a);c=new Aj;c.a=b;a.a.T(new Dj(c));return c.a}
function nj(a){var b;kj(a);b=0;while(a.a.ab(new Bj)){b=Xg(b,1)}return b}
function Fo(a){var b;qj(oj(lo(a.b),new hp),(b=new yi,b)).N(new ip(a.b))}
function Lb(b){try{b.b.v()}catch(a){a=Vg(a);if(!gd(a,5))throw Wg(a)}}
function Ec(a){a&&Lc((Jc(),Ic));--wc;if(a){if(yc!=-1){Gc(yc);yc=-1}}}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function nl(a){var b;b=Uh((ib(a.b),a.f));if(b.length>0){Bo(a.e,b);xl(a,'')}}
function di(a,b){return ld(b)?b==null?Ji(a.a,null):Xi(a.b,b):Ji(a.a,b)}
function No(a,b){return (dp(),bp)==a||(ap==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function Ho(a){this.b=dj(a);J();this.a=new kc(0,null,null,false,false)}
function Zi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function ki(a){this.d=a;this.c=new Zi(this.d.b);this.a=this.c;this.b=ii(this)}
function jj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function pc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Cc(b){zc();return function(){return Dc(b,this,arguments);var a}}
function vc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function $i(a){if(a.a.c!=a.c){return Vi(a.a,a.b.value[0])}return a.b.value[1]}
function Yn(a,b){var c;if(gd(b,49)){c=b;return a.c.d==c.c.d}else{return false}}
function vi(a,b){var c;c=ti(a,b,0);if(c==-1){return false}Hj(a.a,c);return true}
function Wc(a,b,c,d,e,f){var g;g=Xc(e,d);e!=10&&$c(Uc(a,f),b,c,e,g);return g}
function ti(a,b,c){for(;c<a.a.length;++c){if(Di(b,a.a[c])){return c}}return -1}
function ci(a,b,c){return ld(b)?b==null?Ii(a.a,null,c):Wi(a.b,b,c):Ii(a.a,b,c)}
function Ij(a,b){return Vc(b)!=10&&$c(q(b),b.jb,b.__elementTypeId$,Vc(b),a),a}
function Vc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ri(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Qo(a){var b,c;return b=S(a.b),qj(oj(lo(a.j),new kp(b)),(c=new yi,c))}
function Bn(a,b){a.f=b;Th(b,S(a.a))&&Mn(a,b);Fn(b);A((J(),J(),I),new Sn(a),Ip)}
function ol(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Dl(a),Ip)}}
function fc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new lc(a)),67108864,null)}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new lb(a)),0,null);!!a.b&&mb(a.b)}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||mb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function Kc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Oc(b,c)}while(a.a);a.a=c}}
function Lc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Oc(b,c)}while(a.b);a.b=c}}
function Jh(a,b){var c;if(!a){return}b.j=a;var d=Gh(b);if(!d){gh[a]=[b];return}d.ib=b}
function tb(b){if(b){try{b.v()}catch(a){a=Vg(a);if(gd(a,5)){J()}else throw Wg(a)}}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function bb(){var a;this.a=Wc(sd,pp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function bh(){dh();var a=ah;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function lh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Vg(a){var b;if(gd(a,5)){return a}b=a&&a[yp];if(!b){b=new uc(a);Rc(b)}return b}
function Bh(a){var b;b=new Ah;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Wj(a){var b;b=Yj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Zj(a){var b;return Xj($wnd.React.StrictMode,null,null,(b={},b[Ep]=dj(a),b))}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new yi);a.c=c.c}b.d=true;qi(a.c,dj(b))}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;qi((!a.b&&(a.b=new yi),a.b),b)}}}
function Xi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Mi(a.a,b);--a.b}return c}
function Bi(a){var b,c,d;d=0;for(c=new ki(a.a);c.b;){b=ji(c);d=d+(b?r(b):0);d=d|0}return d}
function Zh(a,b){var c,d;for(d=new ki(b.a);d.b;){c=ji(d);if(!gi(a,c)){return false}}return true}
function ho(a,b,c){var d;d=new eo(b,c);Xn(d,a,new dc(a,d));ci(a.g,Nh(d.c.d),d);hb(a.d);return d}
function Xj(a,b,c,d){var e;e=Yj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=dj(d);return e}
function kn(a,b){Vj(a.a,(yh(Uf),Uf.k+(''+(b?Nh(b.c.d):null))));dj(b);a.a.props['a']=b;return a.a}
function ii(a){if(a.a.U()){return true}if(a.a!=a.c){return false}a.a=new Li(a.d.a);return a.a.U()}
function Yg(a){var b;b=a.h;if(b==0){return a.l+a.m*vp}if(b==1048575){return a.l+a.m*vp-Bp}return a}
function $g(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Bp;d=1048575}c=nd(e/vp);b=nd(e-c*vp);return _c(b,c,d)}
function Fi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Di(a,c.X())){return c}}return null}
function qb(a){var b,c;for(c=new Ai(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function _b(a,b,c){var d;d=di(a.g,b?Nh(b.c.d):null);if(null!=d){jc(b.c,a);c&&!!b&&fc(b.c);hb(a.d)}}
function Mb(a,b){this.b=dj(a);this.a=b|0|(0==(b&6291456)?vp:0)|(0!=(b&229376)?0:98304)}
function xb(a,b,c){wb.call(this,null,a,b,c|(!a?262144:rp)|(0==(c&6291456)?!a?up:vp:0)|0|0|0)}
function Lh(){qc.call(this,"Stream already terminated, can't be modified or used")}
function kd(a){return a!=null&&(typeof a===mp||typeof a==='function')&&!(a.kb===oh)}
function fh(a,b){typeof window===mp&&typeof window['$gwt']===mp&&(window['$gwt'][a]=b)}
function dp(){dp=kh;ap=new ep('ACTIVE',0);cp=new ep('COMPLETED',1);bp=new ep('ALL',2)}
function sn(){this.a=rh((zo(),zo(),yo));this.b=rh(new Lo(this.a));this.c=rh(new $o(this.a))}
function Ah(){this.g=xh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function uc(a){sc();mc(this);this.e=a;a!=null&&Jj(a,yp,this);this.f=a==null?Ap:nh(a);this.a='';this.b=a;this.a=''}
function So(a){var b;b=S(a.i.a);Th(Np,b)||Th(Op,b)||Th('',b)?In(a.i,b):Mo(Jn(a.i))?Ln(a.i):In(a.i,'')}
function S(a){ib(a.e);vb(a.f)&&ob(a.f);if(a.b){if(gd(a.b,8)){throw Wg(a.b)}else{throw Wg(a.b)}}return a.k}
function $c(a,b,c,d,e){e.ib=a;e.jb=b;e.kb=oh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Wi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function fb(a,b){var c,d;d=a.c;vi(d,b);!!a.b&&rp!=(a.b.c&sp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function Jl(a,b,c){27==c.which?A((J(),J(),I),new im(a,b),Ip):13==c.which&&A((J(),J(),I),new gm(a,b),Ip)}
function mb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Bb(a)),67108864,null);!!a.a&&R(a.a);Ib(a.f);a.c=a.c&-8|1}}
function Ok(){if(!Nk){Nk=(++(J(),J(),I).e,new Hb);$wnd.Promise.resolve(null).then(lh(Pk.prototype.G,Pk,[]))}}
function Mk(){Kk();return $c(Uc(Ue,1),pp,7,0,[ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk])}
function q(a){return ld(a)?he:jd(a)?Yd:hd(a)?Wd:fd(a)?a.ib:Yc(a)?a.ib:a.ib||Array.isArray(a)&&Uc(Od,1)||Od}
function p(a,b){return ld(a)?Th(a,b):jd(a)?a===b:hd(a)?a===b:fd(a)?a.o(b):Yc(a)?a===b:!!a&&!!a.equals?a.equals(b):md(a)===md(b)}
function r(a){return ld(a)?Rj(a):jd(a)?nd(a):hd(a)?a?1231:1237:fd(a)?a.q():Yc(a)?Lj(a):!!a&&!!a.hashCode?a.hashCode():Lj(a)}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&rp)?Lb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Nl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Zl(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=ui(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Nh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Ph(),Oh)[b];!c&&(c=Oh[b]=new Mh(a));return c}return new Mh(a)}
function nh(a){var b;if(Array.isArray(a)&&a.kb===oh){return zh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Rj(a){Pj();var b,c,d;c=':'+a;d=Oj[c];if(d!=null){return nd(d)}d=Mj[c];b=d==null?Qj(a):nd(d);Sj();Oj[c]=b;return b}
function Ci(a){var b,c,d;d=1;for(c=new Ai(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function hc(a){var b,c,d;for(c=new Ai(new zi(new hi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.X();gd(d,9)&&d.u()||b.Y().v()}}
function ad(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return _c(c&4194303,d&4194303,e&1048575)}
function Xg(a,b){var c;if(jd(a)&&jd(b)){c=a+b;if(-17592186044416<c&&c<Bp){return c}}return Yg(ad(jd(a)?$g(a):a,jd(b)?$g(b):b))}
function Ml(a,b){var c;c=(ib(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Jo(b,c),Ip);To(a.k,null);$l(a,c)}else{ko(a.j,b)}}
function yb(a,b){wb.call(this,a,new zb(a),null,b|(rp==(b&sp)?0:524288)|(0==(b&6291456)?rp==(b&sp)?vp:up:0)|0|268435456|0)}
function Ih(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function xi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Ij(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function $h(a,b){var c,d,e;e=fi(a.a);b.length<e&&(b=Ij(new Array(e),b));d=new ki(a.a);for(c=0;c<e;++c){b[c]=ji(d)}b.length>e&&(b[e]=null);return b}
function bk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Bc(){var a;if(wc!=0){a=vc();if(a-xc>2000){xc=a;yc=$wnd.setTimeout(Hc,10)}}if(wc++==0){Kc((Jc(),Ic));return true}return false}
function Sc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a,b,c,d,e){var f;this.d=a;this.e=d?new Ei:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new kb((J(),null)),f):null;this.c=null}
function U(a,b,c,d){this.c=dj(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new yb(this,d);this.e=new kb(this.f);rp==(d&sp)&&nb(this.f)}
function eo(a,b){var c,d,e;this.e=dj(a);this.d=b;J();c=++Vn;this.c=new kc(c,null,new fo(this),true,true);this.b=(e=new kb(null),e);this.a=(d=new kb(null),d)}
function hl(a,b){var c;this.d=dj(b);this.n=dj(a);J();c=++fl;this.b=new kc(c,null,new il(this),false,false);this.a=new xb(null,dj(new ll(this)),Hp)}
function ed(a,b){if(ld(a)){return !!dd[b]}else if(a.jb){return !!a.jb[b]}else if(jd(a)){return !!cd[b]}else if(hd(a)){return !!bd[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ai(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Wb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Ai(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&ub(b,6,true)}}}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ai(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Uh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Xc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{Zb(b,d);try{f=(c.a.v(),null)}finally{$b()}return f}catch(a){a=Vg(a);if(gd(a,5)){e=a;throw Wg(e)}else throw Wg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.s()}else{Zb(b,e);try{g=c.s()}finally{$b()}}return g}catch(a){a=Vg(a);if(gd(a,5)){f=a;throw Wg(f)}else throw Wg(a)}finally{D(b)}}
function Db(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Jb(c);return true}
function eh(b,c,d,e){dh();var f=ah;$moduleName=c;$moduleBase=d;Ug=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{lp(g)()}catch(a){b(c,a)}}else{lp(g)()}}
function yl(a,b){var c,d;this.e=dj(b);this.n=dj(a);J();c=++sl;this.c=new kc(c,null,new zl(this),false,false);this.b=(d=new kb(null),d);this.a=new xb(null,dj(new Fl(this)),Hp)}
function sm(a,b,c,d){var e;this.d=dj(b);this.e=dj(c);this.f=dj(d);this.n=dj(a);J();e=++qm;this.b=new kc(e,null,new tm(this),false,false);this.a=new xb(null,dj(new wm(this)),Hp)}
function Yj(a,b){var c;c=new $wnd.Object;c.$$typeof=dj(a);c.type=dj(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ri(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Si()}}
function el(a){var b,c,d;a.c=0;Ok();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),$j('span',bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,['todo-count'])),[$j('strong',null,[c]),' '+d+' left']));return b}
function hh(){gh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Oc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].lb()&&(c=Nc(c,g)):g[0].lb()}catch(a){a=Vg(a);if(gd(a,5)){d=a;zc();Fc(gd(d,35)?d.D():d)}else throw Wg(a)}}return c}
function rl(a){var b;a.d=0;Ok();b=$j(Jp,fk(ik(jk(mk(kk(bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,['new-todo']))),(ib(a.b),a.f)),lh(Zm.prototype.fb,Zm,[a])),lh($m.prototype.eb,$m,[a]))),null);return b}
function tc(a){var b;if(a.c==null){b=md(a.b)===md(rc)?null:a.b;a.d=b==null?Ap:kd(b)?b==null?null:b.name:ld(b)?'String':zh(q(b));a.a=a.a+': '+(kd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.k;try{d=b.c.s();if(!(md(e)===md(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Vg(a);if(gd(a,11)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Wg(c)}else throw Wg(a)}}
function Ii(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Fi(b,e);if(f){return f.Z(c)}}e[e.length]=new oi(b,c);++a.b;return null}
function Ej(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Qj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Sh(a,c++)}b=b|0;return b}
function ob(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Vg(a);if(gd(a,5)){J()}else throw Wg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Wc(ee,pp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function ph(){var a;a=new sn;Bm(tn(new un(a)));Em(new kl((new vn(a)).a.a.F()));nn(xn(new yn(a)));rn(zn(new An(a)));bn(new Bl((new wn(a)).a.b.F()));$wnd.ReactDOM.render(Zj([(new pn).a]),(th(),sh).getElementById('app'),null)}
function Fn(a){var b;if(0==a.length){b=(th(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',sh.title,b)}else{(th(),$wnd.window.window).location.hash=a}}
function Xk(a,b,c,d){var e;this.e=dj(b);this.f=dj(c);this.g=dj(d);this.n=dj(a);J();e=++Tk;this.c=new kc(e,null,new Yk(this),false,false);this.a=new U(new _k(this),null,null,136478720);this.b=new xb(null,dj(new al(this)),Hp)}
function _l(a,b,c,d){var e,f;this.j=dj(b);dj(c);this.k=dj(d);this.n=dj(a);J();e=++Rl;this.e=new kc(e,null,new am(this),false,false);this.a=(f=new kb(null),f);this.c=new U(new fm(this),null,null,136478720);this.b=new xb(null,dj(new km(this)),Hp);Zl(this,this.n.props['a'])}
function wb(a,b,c,d){this.b=new yi;this.f=new Mb(new Ab(this),d&6520832|262144|rp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&up)&&D((null,I)))}
function Ji(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Di(b,e.X())){if(d.length==1){d.length=0;Mi(a.a,g)}else{d.splice(h,1)}--a.b;return e.Y()}}return null}
function jh(a,b,c){var d=gh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=gh[b]),mh(h));_.jb=c;!b&&(_.kb=oh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ib=f)}
function Hh(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Ih('.',[c,Ih('$',d)]);a.b=Ih('.',[c,Ih('.',d)]);a.i=d[d.length-1]}
function _h(a,b){var c,d,e;c=b.X();e=b.Y();d=ld(c)?c==null?bi(Hi(a.a,null)):Vi(a.b,c):bi(Hi(a.a,c));if(!(md(e)===md(d)||e!=null&&p(e,d))){return false}if(d==null&&!(ld(c)?c==null?!!Hi(a.a,null):Ui(a.b,c):!!Hi(a.a,c))){return false}return true}
function $j(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Uj(b,lh(ak.prototype.cb,ak,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ep]=c[0],undefined):(d[Ep]=c,undefined));return Xj(a,e,f,d)}
function Nn(){var a,b;this.d=new _o(this);this.f=this.e=(b=(th(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new kc(0,null,new On(this),false,false);this.b=(a=new kb(null),a);this.a=new U(new Tn,new Pn(this),new Qn(this),35749888)}
function po(){var a;this.g=new Ei;J();this.f=new kc(0,new ro(this),new qo(this),false,false);this.d=(a=new kb(null),a);this.c=new U(new uo(this),null,null,Mp);this.e=new U(new vo(this),null,null,Mp);this.a=new U(new wo(this),null,null,Mp);this.b=new U(new xo(this),null,null,Mp)}
function Uo(a){var b;this.j=dj(a);this.i=new Nn;J();this.g=new kc(0,null,new Vo(this),false,false);this.d=(b=new kb(null),b);this.b=new U(new Wo(this),null,null,Mp);this.c=new U(new Xo(this),null,null,Mp);this.e=u(new Yo(this),413138944);this.a=u(new Zo(this),681574400);D((null,I))}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ai(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Vg(a);if(!gd(a,5))throw Wg(a)}if(6==(b.c&7)){return true}}}}}qb(b);return false}
function Qi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ub(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){jb(a.a.e);tb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;tb((e=d.i,e));d.k=null}ri(a.b,new Cb(a));a.b.a=Wc(ee,pp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&tb((f=a.a.g,f))}}
function Kk(){Kk=kh;ok=new Lk(Fp,0);pk=new Lk('checkbox',1);qk=new Lk('color',2);rk=new Lk('date',3);sk=new Lk('datetime',4);tk=new Lk('email',5);uk=new Lk('file',6);vk=new Lk('hidden',7);wk=new Lk('image',8);xk=new Lk('month',9);yk=new Lk(np,10);zk=new Lk('password',11);Ak=new Lk('radio',12);Bk=new Lk('range',13);Ck=new Lk('reset',14);Dk=new Lk('search',15);Ek=new Lk('submit',16);Fk=new Lk('tel',17);Gk=new Lk('text',18);Hk=new Lk('time',19);Ik=new Lk('url',20);Jk=new Lk('week',21)}
function pm(a){var b,c,d;a.c=0;Ok();d=$j('div',null,[$j('div',null,[$j(Kp,bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,[Kp])),[$j('h1',null,['todos']),(new _m).a]),S(a.d.c)?null:$j('section',bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,[Kp])),[$j(Jp,ik(lk(bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,['toggle-all'])),(Kk(),pk)),lh(on.prototype.eb,on,[a])),null),$j('ul',bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,['todo-list'])),(b=qj(dj(pj(S(a.f.c).S())),(c=new yi,c)),xi(b,Zc(b.a.length))))]),S(a.d.c)?null:(new zm).a])]);return d}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=si(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&wi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=si(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ui(a.b,g)}e&&sb(a.e,a.b)}else{e&&sb(a.e,new yi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&rp!=(k.b.c&sp)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function Sk(a){var b,c;a.d=0;Ok();c=(b=S(a.g.b),$j('footer',bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,['footer'])),[(new Cm).a,$j('ul',bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,['filters'])),[$j('li',null,[$j('a',dk(bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,[(dp(),bp)==b?Gp:null])),'#'),['All'])]),$j('li',null,[$j('a',dk(bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,[ap==b?Gp:null])),'#active'),['Active'])]),$j('li',null,[$j('a',dk(bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,[cp==b?Gp:null])),'#completed'),['Completed'])])]),S(a.a)?$j(Fp,ek(bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,['clear-completed'])),lh(ym.prototype.gb,ym,[a])),['Clear Completed']):null]));return c}
function Ql(a){var b,c,d,e;a.f=0;Ok();b=a.n.props['a'];if(b.c.i<0){return null}c=(d=a.n.props['a'],e=(ib(d.a),d.d),$j('li',bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[$j('div',bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,['view'])),[$j(Jp,ik(gk(lk(bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,['toggle'])),(Kk(),pk)),e),lh(dn.prototype.eb,dn,[d])),null),$j('label',nk(new $wnd.Object,lh(en.prototype.gb,en,[a,d])),[(ib(d.b),d.e)]),$j(Fp,ek(bk(new $wnd.Object,$c(Uc(he,1),pp,2,6,['destroy'])),lh(fn.prototype.gb,fn,[a,d])),null)]),$j(Jp,jk(ik(hk(mk(bk(ck(new $wnd.Object,lh(gn.prototype.w,gn,[a])),$c(Uc(he,1),pp,2,6,['edit'])),(ib(a.a),a.d)),lh(hn.prototype.db,hn,[a,d])),lh(cn.prototype.eb,cn,[a])),lh(jn.prototype.fb,jn,[a,d])),null)]));return c}
function Si(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Dp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Qi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Dp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var mp='object',np='number',op={14:1},pp={3:1,4:1},qp={9:1},rp=1048576,sp=1835008,tp={6:1},up=2097152,vp=4194304,wp={22:1},xp='__noinit__',yp='__java$exception',zp={3:1,11:1,8:1,5:1},Ap='null',Bp=17592186044416,Cp={40:1},Dp='delete',Ep='children',Fp='button',Gp='selected',Hp=1411518464,Ip=142606336,Jp='input',Kp='header',Lp='hashchange',Mp=136413184,Np='active',Op='completed';var _,gh,ah,Ug=-1;hh();jh(1,null,{},o);_.o=Qp;_.p=function(){return this.ib};_.q=Rp;_.r=function(){var a;return zh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var bd,cd,dd;jh(54,1,{},Ah);_.H=function(a){var b;b=new Ah;b.e=4;a>1?(b.c=Fh(this,a-1)):(b.c=this);return b};_.I=function(){yh(this);return this.b};_.J=function(){return zh(this)};_.K=function(){yh(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(yh(this),this.k)};_.e=0;_.g=0;var xh=1;var ee=Ch(1);var Xd=Ch(54);jh(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var rd=Ch(81);jh(36,1,op,G);_.s=function(){return this.a.v(),null};var pd=Ch(36);jh(82,1,{},H);var qd=Ch(82);var I;jh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var sd=Ch(43);jh(231,1,qp);_.r=function(){var a;return zh(this.ib)+'@'+(a=r(this)>>>0,a.toString(16))};var vd=Ch(231);jh(20,231,qp,U);_.t=function(){R(this)};_.u=Pp;_.a=false;_.d=0;var td=Ch(20);jh(956,1,{});jh(143,1,{270:1},bb);var ud=Ch(143);jh(18,231,{9:1,18:1},kb);_.t=function(){cb(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var xd=Ch(18);jh(178,1,tp,lb);_.v=function(){db(this.a)};var wd=Ch(178);jh(19,231,{9:1,19:1},xb,yb);_.t=function(){mb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Cd=Ch(19);jh(179,1,wp,zb);_.v=function(){Q(this.a)};var yd=Ch(179);jh(180,1,tp,Ab);_.v=function(){ob(this.a)};var zd=Ch(180);jh(181,1,tp,Bb);_.v=function(){rb(this.a)};var Ad=Ch(181);jh(182,1,{},Cb);_.w=function(a){pb(this.a,a)};var Bd=Ch(182);jh(144,1,{},Fb);_.a=0;_.b=0;_.c=0;var Dd=Ch(144);jh(183,1,qp,Hb);_.t=function(){Gb(this)};_.u=Pp;_.a=false;var Ed=Ch(183);jh(65,231,{9:1,65:1},Mb);_.t=function(){Ib(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Fd=Ch(65);jh(187,1,{},Yb);_.r=function(){var a;return yh(Gd),Gd.k+'@'+(a=Lj(this)>>>0,a.toString(16))};_.a=0;var Nb;var Gd=Ch(187);jh(156,1,{});var Jd=Ch(156);jh(149,1,{},cc);_.w=function(a){ac(this.a,a)};var Hd=Ch(149);jh(150,1,tp,dc);_.v=function(){bc(this.a,this.b)};var Id=Ch(150);jh(157,156,{});var Kd=Ch(157);jh(17,1,qp,kc);_.t=function(){fc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return yh(Md),Md.k+'@'+(a=Lj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Md=Ch(17);jh(177,1,tp,lc);_.v=function(){ic(this.a)};var Ld=Ch(177);jh(5,1,{3:1,5:1});_.A=function(a){return new Error(a)};_.B=function(){return this.f};_.C=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=zh(this.ib),c==null?a:a+': '+c);nc(this,pc(this.A(b)));Rc(this)};_.r=function(){return oc(this,this.B())};_.e=xp;_.g=true;var ie=Ch(5);jh(11,5,{3:1,11:1,5:1});var $d=Ch(11);jh(8,11,zp);var fe=Ch(8);jh(55,8,zp);var be=Ch(55);jh(76,55,zp);var Qd=Ch(76);jh(35,76,{35:1,3:1,11:1,8:1,5:1},uc);_.B=function(){tc(this);return this.c};_.D=function(){return md(this.b)===md(rc)?null:this.b};var rc;var Nd=Ch(35);var Od=Ch(0);jh(213,1,{});var Pd=Ch(213);var wc=0,xc=0,yc=-1;jh(90,213,{},Mc);var Ic;var Rd=Ch(90);var Pc;jh(224,1,{});var Td=Ch(224);jh(77,224,{},Tc);var Sd=Ch(77);jh(44,1,{44:1,69:1},qh);_.F=function(){if(this===this.a){this.a=this.b.F();this.b=null}return this.a};var Ud=Ch(44);var sh;jh(74,1,{71:1});_.r=Pp;var Vd=Ch(74);bd={3:1,72:1,31:1};var Wd=Ch(72);jh(41,1,{3:1,41:1});var de=Ch(41);cd={3:1,31:1,41:1};var Yd=Ch(223);jh(33,1,{3:1,31:1,33:1});_.o=Qp;_.q=Rp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var Zd=Ch(33);jh(78,8,zp,Lh);var _d=Ch(78);jh(32,41,{3:1,31:1,32:1,41:1},Mh);_.o=function(a){return gd(a,32)&&a.a==this.a};_.q=Pp;_.r=function(){return ''+this.a};_.a=0;var ae=Ch(32);var Oh;jh(288,1,{});jh(79,55,zp,Rh);_.A=function(a){return new TypeError(a)};var ce=Ch(79);dd={3:1,71:1,31:1,2:1};var he=Ch(2);jh(75,74,{71:1},Xh);var ge=Ch(75);jh(292,1,{});jh(57,8,zp,Yh);var je=Ch(57);jh(225,1,{39:1});_.N=Vp;_.R=function(){return new hj(this,0)};_.S=function(){return new rj(null,this.R())};_.P=function(a){throw Wg(new Yh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new jj('[',']');for(b=this.O();b.U();){a=b.V();ij(c,a===this?'(this Collection)':a==null?Ap:nh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ke=Ch(225);jh(229,1,{212:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!gd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ki((new hi(d)).a);c.b;){b=ji(c);if(!_h(this,b)){return false}}return true};_.q=function(){return Bi(new hi(this))};_.r=function(){var a,b,c;c=new jj('{','}');for(b=new ki((new hi(this)).a);b.b;){a=ji(b);ij(c,ai(this,a.X())+'='+ai(this,a.Y()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ve=Ch(229);jh(142,229,{212:1});var ne=Ch(142);jh(228,225,{39:1,237:1});_.R=function(){return new hj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!gd(a,24)){return false}b=a;if(fi(b.a)!=this.Q()){return false}return Zh(this,b)};_.q=function(){return Bi(this)};var we=Ch(228);jh(24,228,{24:1,39:1,237:1},hi);_.O=function(){return new ki(this.a)};_.Q=Tp;var me=Ch(24);jh(25,1,{},ki);_.T=Sp;_.V=function(){return ji(this)};_.U=Up;_.b=false;var le=Ch(25);jh(226,225,{39:1,233:1});_.R=function(){return new hj(this,16)};_.W=function(a,b){throw Wg(new Yh('Add not supported on this list'))};_.P=function(a){this.W(this.Q(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!gd(a,13)){return false}f=a;if(this.Q()!=f.a.length){return false}e=new Ai(f);for(c=new Ai(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(md(b)===md(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return Ci(this)};_.O=function(){return new li(this)};var pe=Ch(226);jh(89,1,{},li);_.T=Sp;_.U=function(){return this.a<this.b.a.length};_.V=function(){return si(this.b,this.a++)};_.a=0;var oe=Ch(89);jh(59,225,{39:1},mi);_.O=function(){var a;a=new ki((new hi(this.a)).a);return new ni(a)};_.Q=Tp;var re=Ch(59);jh(141,1,{},ni);_.T=Sp;_.U=function(){return this.a.b};_.V=function(){var a;a=ji(this.a);return a.Y()};var qe=Ch(141);jh(139,1,Cp);_.o=function(a){var b;if(!gd(a,40)){return false}b=a;return Di(this.a,b.X())&&Di(this.b,b.Y())};_.X=Pp;_.Y=Up;_.q=function(){return cj(this.a)^cj(this.b)};_.Z=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var se=Ch(139);jh(140,139,Cp,oi);var te=Ch(140);jh(230,1,Cp);_.o=function(a){var b;if(!gd(a,40)){return false}b=a;return Di(this.b.value[0],b.X())&&Di($i(this),b.Y())};_.q=function(){return cj(this.b.value[0])^cj($i(this))};_.r=function(){return this.b.value[0]+'='+$i(this)};var ue=Ch(230);jh(13,226,{3:1,13:1,39:1,233:1},yi,zi);_.W=function(a,b){Fj(this.a,a,b)};_.P=function(a){return qi(this,a)};_.N=function(a){ri(this,a)};_.O=function(){return new Ai(this)};_.Q=function(){return this.a.length};var ye=Ch(13);jh(16,1,{},Ai);_.T=Sp;_.U=function(){return this.a<this.c.a.length};_.V=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var xe=Ch(16);jh(37,142,{3:1,37:1,212:1},Ei);var ze=Ch(37);jh(62,1,{},Ki);_.N=Vp;_.O=function(){return new Li(this)};_.b=0;var Be=Ch(62);jh(63,1,{},Li);_.T=Sp;_.V=function(){return this.d=this.a[this.c++],this.d};_.U=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ae=Ch(63);var Oi;jh(60,1,{},Yi);_.N=Vp;_.O=function(){return new Zi(this)};_.b=0;_.c=0;var Ee=Ch(60);jh(61,1,{},Zi);_.T=Sp;_.V=function(){return this.c=this.a,this.a=this.b.next(),new _i(this.d,this.c,this.d.c)};_.U=function(){return !this.a.done};var Ce=Ch(61);jh(148,230,Cp,_i);_.X=function(){return this.b.value[0]};_.Y=function(){return $i(this)};_.Z=function(a){return Wi(this.a,this.b.value[0],a)};_.c=0;var De=Ch(148);jh(197,1,{});_.T=function(a){ej(this,a)};_.$=function(){return this.d};_._=function(){return this.e};_.d=0;_.e=0;var Ge=Ch(197);jh(66,197,{});var Fe=Ch(66);jh(23,1,{},hj);_.$=Pp;_._=function(){gj(this);return this.c};_.T=function(a){gj(this);this.d.T(a)};_.ab=function(a){gj(this);if(this.d.U()){a.w(this.d.V());return true}return false};_.a=0;_.c=0;var He=Ch(23);jh(56,1,{},jj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ie=Ch(56);jh(196,1,{});_.c=false;var Re=Ch(196);jh(28,196,{273:1,28:1},rj);var Qe=Ch(28);jh(199,66,{},vj);_.ab=function(a){this.b=false;while(!this.b&&this.c.ab(new wj(this,a)));return this.b};_.b=false;var Ke=Ch(199);jh(202,1,{},wj);_.w=function(a){uj(this.a,this.b,a)};var Je=Ch(202);jh(198,66,{},xj);_.ab=function(a){return this.a.ab(new yj(a))};var Me=Ch(198);jh(201,1,{},yj);_.w=function(a){this.a.w(kn(new ln,a))};var Le=Ch(201);jh(200,1,{},Aj);_.w=function(a){zj(this,a)};var Ne=Ch(200);jh(203,1,{},Bj);_.w=function(a){};var Oe=Ch(203);jh(204,1,{},Dj);_.w=function(a){Cj(this,a)};var Pe=Ch(204);jh(290,1,{});jh(232,1,{});var Se=Ch(232);jh(287,1,{});var Kj=0;var Mj,Nj=0,Oj;jh(919,1,{});jh(954,1,{});jh(227,1,{});var Te=Ch(227);jh(272,$wnd.Function,{},ak);_.cb=function(a){_j(this.a,this.b,a)};jh(7,33,{3:1,31:1,33:1,7:1},Lk);var ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk;var Ue=Dh(7,Mk);var Nk;jh(271,$wnd.Function,{},Pk);_.G=function(a){return Gb(Nk),Nk=null,null};jh(91,227,{});var Gf=Ch(91);jh(92,91,{});_.d=0;var Kf=Ch(92);jh(93,92,qp,Xk);_.t=Wp;_.o=Qp;_.q=Rp;_.u=Xp;_.r=function(){var a;return yh(df),df.k+'@'+(a=Lj(this)>>>0,a.toString(16))};var Tk=0;var df=Ch(93);jh(95,1,tp,Yk);_.v=function(){Uk(this.a)};var Ve=Ch(95);jh(94,1,{},$k);var We=Ch(94);jh(96,1,op,_k);_.s=function(){return Vk(this.a)};var Xe=Ch(96);jh(97,1,wp,al);_.v=function(){Rk(this.a)};var Ye=Ch(97);jh(98,1,op,bl);_.s=function(){return Sk(this.a)};var Ze=Ch(98);jh(100,227,{});var Ff=Ch(100);jh(101,100,{});_.c=0;var Jf=Ch(101);jh(102,101,qp,hl);_.t=Yp;_.o=Qp;_.q=Rp;_.u=Zp;_.r=function(){var a;return yh(cf),cf.k+'@'+(a=Lj(this)>>>0,a.toString(16))};var fl=0;var cf=Ch(102);jh(104,1,tp,il);_.v=$p;var $e=Ch(104);jh(103,1,{},kl);var _e=Ch(103);jh(105,1,wp,ll);_.v=function(){dl(this.a)};var af=Ch(105);jh(106,1,op,ml);_.s=function(){return el(this.a)};var bf=Ch(106);jh(129,227,{});_.f='';var Sf=Ch(129);jh(130,129,{});_.d=0;var Mf=Ch(130);jh(131,130,qp,yl);_.t=Wp;_.o=Qp;_.q=Rp;_.u=Xp;_.r=function(){var a;return yh(lf),lf.k+'@'+(a=Lj(this)>>>0,a.toString(16))};var sl=0;var lf=Ch(131);jh(133,1,tp,zl);_.v=function(){tl(this.a)};var ef=Ch(133);jh(132,1,{},Bl);var ff=Ch(132);jh(135,1,op,Cl);_.s=function(){return rl(this.a)};var gf=Ch(135);jh(136,1,tp,Dl);_.v=function(){nl(this.a)};var hf=Ch(136);jh(137,1,tp,El);_.v=function(){vl(this.a,this.b)};var jf=Ch(137);jh(134,1,wp,Fl);_.v=function(){Rk(this.a)};var kf=Ch(134);jh(108,227,{});_.i=false;var Uf=Ch(108);jh(109,108,{});_.f=0;var Of=Ch(109);jh(110,109,qp,_l);_.t=function(){fc(this.e)};_.o=Qp;_.q=Rp;_.u=function(){return this.e.i<0};_.r=function(){var a;return yh(xf),xf.k+'@'+(a=Lj(this)>>>0,a.toString(16))};var Rl=0;var xf=Ch(110);jh(112,1,tp,am);_.v=function(){Sl(this.a)};var mf=Ch(112);jh(111,1,{},cm);var nf=Ch(111);jh(115,1,op,dm);_.s=function(){return Ql(this.a)};var of=Ch(115);jh(42,1,tp,em);_.v=function(){$l(this.a,Jn(this.b))};var pf=Ch(42);jh(113,1,op,fm);_.s=function(){return Ul(this.a)};var qf=Ch(113);jh(58,1,tp,gm);_.v=function(){Ml(this.a,this.b)};var rf=Ch(58);jh(116,1,tp,hm);_.v=function(){Ll(this.a,this.b)};var sf=Ch(116);jh(117,1,tp,im);_.v=function(){Kl(this.a,this.b)};var tf=Ch(117);jh(118,1,tp,jm);_.v=function(){Gl(this.a,this.b)};var uf=Ch(118);jh(114,1,wp,km);_.v=function(){Pl(this.a)};var vf=Ch(114);jh(119,1,tp,lm);_.v=function(){Nl(this.a)};var wf=Ch(119);jh(121,227,{});var Wf=Ch(121);jh(122,121,{});_.c=0;var Qf=Ch(122);jh(123,122,qp,sm);_.t=Yp;_.o=Qp;_.q=Rp;_.u=Zp;_.r=function(){var a;return yh(Cf),Cf.k+'@'+(a=Lj(this)>>>0,a.toString(16))};var qm=0;var Cf=Ch(123);jh(125,1,tp,tm);_.v=$p;var yf=Ch(125);jh(124,1,{},vm);var zf=Ch(124);jh(126,1,wp,wm);_.v=function(){dl(this.a)};var Af=Ch(126);jh(127,1,op,xm);_.s=function(){return pm(this.a)};var Bf=Ch(127);jh(253,$wnd.Function,{},ym);_.gb=function(a){Do(this.a.f)};jh(185,1,{},zm);var Df=Ch(185);var Am;jh(207,1,{},Cm);var Ef=Ch(207);var Dm;jh(254,$wnd.Function,{},Fm);_.hb=function(a){return new Im(a)};var Gm;jh(99,$wnd.React.Component,{},Im);ih(gh[1],_);_.componentWillUnmount=function(){Qk(this.a)};_.render=function(){return Wk(this.a)};_.shouldComponentUpdate=_p;var Hf=Ch(99);jh(255,$wnd.Function,{},Jm);_.hb=function(a){return new Mm(a)};var Km;jh(107,$wnd.React.Component,{},Mm);ih(gh[1],_);_.componentWillUnmount=function(){cl(this.a)};_.render=function(){return gl(this.a)};_.shouldComponentUpdate=aq;var If=Ch(107);jh(269,$wnd.Function,{},Nm);_.hb=function(a){return new Qm(a)};var Om;jh(138,$wnd.React.Component,{},Qm);ih(gh[1],_);_.componentWillUnmount=function(){Qk(this.a)};_.render=function(){return wl(this.a)};_.shouldComponentUpdate=_p;var Lf=Ch(138);jh(256,$wnd.Function,{},Rm);_.hb=function(a){return new Um(a)};var Sm;jh(120,$wnd.React.Component,{},Um);ih(gh[1],_);_.componentDidUpdate=function(a){Xl(this.a)};_.componentWillUnmount=function(){Ol(this.a)};_.render=function(){return Yl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Nf=Ch(120);jh(266,$wnd.Function,{},Vm);_.hb=function(a){return new Ym(a)};var Wm;jh(128,$wnd.React.Component,{},Ym);ih(gh[1],_);_.componentWillUnmount=function(){cl(this.a)};_.render=function(){return rm(this.a)};_.shouldComponentUpdate=aq;var Pf=Ch(128);jh(267,$wnd.Function,{},Zm);_.fb=function(a){ol(this.a,a)};jh(268,$wnd.Function,{},$m);_.eb=function(a){ul(this.a,a)};jh(184,1,{},_m);var Rf=Ch(184);var an;jh(263,$wnd.Function,{},cn);_.eb=function(a){Tl(this.a,a)};jh(257,$wnd.Function,{},dn);_.eb=function(a){co(this.a)};jh(259,$wnd.Function,{},en);_.gb=function(a){Vl(this.a,this.b)};jh(260,$wnd.Function,{},fn);_.gb=function(a){Hl(this.a,this.b)};jh(261,$wnd.Function,{},gn);_.w=function(a){Il(this.a,a)};jh(262,$wnd.Function,{},hn);_.db=function(a){Wl(this.a,this.b)};jh(264,$wnd.Function,{},jn);_.fb=function(a){Jl(this.a,this.b,a)};jh(206,1,{},ln);var Tf=Ch(206);var mn;jh(265,$wnd.Function,{},on);_.eb=function(a){mm(this.a,a)};jh(70,1,{},pn);var Vf=Ch(70);var qn;jh(83,1,{},sn);var ag=Ch(83);jh(84,1,{},un);var Xf=Ch(84);jh(88,1,{},vn);var Yf=Ch(88);jh(87,1,{},wn);var Zf=Ch(87);jh(85,1,{},yn);var $f=Ch(85);jh(86,1,{},An);var _f=Ch(86);jh(188,1,{});var Jg=Ch(188);jh(189,188,qp,Nn);_.t=Wp;_.o=Qp;_.q=Rp;_.u=Xp;_.r=function(){var a;return yh(ig),ig.k+'@'+(a=Lj(this)>>>0,a.toString(16))};var ig=Ch(189);jh(190,1,tp,On);_.v=function(){Hn(this.a)};var bg=Ch(190);jh(192,1,wp,Pn);_.v=function(){Cn(this.a)};var cg=Ch(192);jh(193,1,wp,Qn);_.v=function(){Dn(this.a)};var dg=Ch(193);jh(195,1,tp,Rn);_.v=function(){Kn(this.a)};var eg=Ch(195);jh(64,1,tp,Sn);_.v=function(){Gn(this.a)};var fg=Ch(64);jh(191,1,op,Tn);_.s=function(){var a;return a=(th(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var gg=Ch(191);jh(194,1,tp,Un);_.v=function(){Bn(this.a,this.b)};var hg=Ch(194);jh(48,1,{48:1});_.d=false;var Rg=Ch(48);jh(49,48,{9:1,274:1,49:1,48:1},eo);_.t=Wp;_.o=function(a){return Yn(this,a)};_.q=function(){return this.c.d};_.u=Xp;_.r=function(){var a;return yh(Ag),Ag.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Vn=0;var Ag=Ch(49);jh(208,1,tp,fo);_.v=function(){Wn(this.a)};var jg=Ch(208);jh(209,1,tp,go);_.v=function(){_n(this.a)};var kg=Ch(209);jh(45,157,{45:1});var Mg=Ch(45);jh(158,45,{9:1,45:1},po);_.t=function(){fc(this.f)};_.o=Qp;_.q=Rp;_.u=function(){return this.f.i<0};_.r=function(){var a;return yh(ug),ug.k+'@'+(a=Lj(this)>>>0,a.toString(16))};var ug=Ch(158);jh(160,1,tp,qo);_.v=function(){io(this.a)};var lg=Ch(160);jh(159,1,tp,ro);_.v=function(){mo(this.a)};var mg=Ch(159);jh(165,1,tp,so);_.v=function(){_b(this.a,this.b,true)};var ng=Ch(165);jh(166,1,op,to);_.s=function(){return ho(this.a,this.c,this.b)};_.b=false;var og=Ch(166);jh(161,1,op,uo);_.s=function(){return no(this.a)};var pg=Ch(161);jh(162,1,op,vo);_.s=function(){return Nh(_g(nj(lo(this.a))))};var qg=Ch(162);jh(163,1,op,wo);_.s=function(){return Nh(_g(nj(oj(lo(this.a),new gp))))};var rg=Ch(163);jh(164,1,op,xo);_.s=function(){return oo(this.a)};var sg=Ch(164);jh(145,1,{69:1},Ao);_.F=function(){return new po};var yo;var tg=Ch(145);jh(46,1,{46:1});var Qg=Ch(46);jh(167,46,{9:1,46:1},Ho);_.t=function(){fc(this.a)};_.o=Qp;_.q=Rp;_.u=function(){return this.a.i<0};_.r=function(){var a;return yh(zg),zg.k+'@'+(a=Lj(this)>>>0,a.toString(16))};var zg=Ch(167);jh(168,1,tp,Io);_.v=function(){Eo(this.a,this.b)};_.b=false;var vg=Ch(168);jh(169,1,tp,Jo);_.v=function(){Mn(this.b,this.a)};var wg=Ch(169);jh(170,1,tp,Ko);_.v=function(){Fo(this.a)};var xg=Ch(170);jh(146,1,{69:1},Lo);_.F=function(){return new Ho(this.a.F())};var yg=Ch(146);jh(47,1,{47:1});var Tg=Ch(47);jh(171,47,{9:1,47:1},Uo);_.t=function(){fc(this.g)};_.o=Qp;_.q=Rp;_.u=function(){return this.g.i<0};_.r=function(){var a;return yh(Hg),Hg.k+'@'+(a=Lj(this)>>>0,a.toString(16))};var Hg=Ch(171);jh(172,1,tp,Vo);_.v=function(){Oo(this.a)};var Bg=Ch(172);jh(173,1,op,Wo);_.s=function(){var a;return a=Jn(this.a.i),Th(Np,a)?(dp(),ap):Th(Op,a)?(dp(),cp):(dp(),bp)};var Cg=Ch(173);jh(174,1,op,Xo);_.s=function(){return Qo(this.a)};var Dg=Ch(174);jh(175,1,wp,Yo);_.v=function(){Ro(this.a)};var Eg=Ch(175);jh(176,1,wp,Zo);_.v=function(){So(this.a)};var Fg=Ch(176);jh(147,1,{69:1},$o);_.F=function(){return new Uo(this.a.F())};var Gg=Ch(147);jh(186,1,{},_o);_.handleEvent=function(a){En(this.a,a)};var Ig=Ch(186);jh(34,33,{3:1,31:1,33:1,34:1},ep);var ap,bp,cp;var Kg=Dh(34,fp);jh(151,1,{},gp);_.bb=function(a){return !$n(a)};var Lg=Ch(151);jh(153,1,{},hp);_.bb=function(a){return $n(a)};var Ng=Ch(153);jh(154,1,{},ip);_.w=function(a){ko(this.a,a)};var Og=Ch(154);jh(152,1,{},jp);_.w=function(a){Co(this.a,a)};_.a=false;var Pg=Ch(152);jh(155,1,{},kp);_.bb=function(a){return No(this.a,a)};var Sg=Ch(155);var od=Eh('D');var lp=(zc(),Cc);var gwtOnLoad=gwtOnLoad=eh;bh(ph);fh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();