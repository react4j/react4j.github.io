function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='179A57A608C60A18B5F6564CADDA84E2',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '179A57A608C60A18B5F6564CADDA84E2';function o(){}
function Ah(){}
function wh(){}
function Bb(){}
function Qc(){}
function Xc(){}
function Tj(){}
function Uj(){}
function uk(){}
function $m(){}
function an(){}
function cn(){}
function en(){}
function gn(){}
function qo(){}
function Bo(){}
function Vo(){}
function hp(){}
function ip(){}
function oq(){}
function Vc(a){Uc()}
function Mh(){Mh=wh}
function Qi(){Hi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function fb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function ub(a){this.a=a}
function cc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function gc(a){this.a=a}
function kc(a){this.a=a}
function bi(a){this.a=a}
function ni(a){this.a=a}
function zi(a){this.a=a}
function Ei(a){this.a=a}
function Fi(a){this.a=a}
function Di(a){this.b=a}
function Si(a){this.c=a}
function Rj(a){this.a=a}
function Wj(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function Bl(a){this.a=a}
function Ql(a){this.a=a}
function Rl(a){this.a=a}
function Tl(a){this.a=a}
function Ul(a){this.a=a}
function Wl(a){this.a=a}
function qm(a){this.a=a}
function rm(a){this.a=a}
function xm(a){this.a=a}
function ym(a){this.a=a}
function Im(a){this.a=a}
function Jm(a){this.a=a}
function Km(a){this.a=a}
function Nm(a){this.a=a}
function Qm(a){this.a=a}
function Rm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function jn(a){this.a=a}
function kn(a){this.a=a}
function mn(){this.a={}}
function Pm(){this.a={}}
function Tm(){this.a={}}
function nn(a){this.a=a}
function on(a){this.a=a}
function qn(a){this.a=a}
function rn(a){this.a=a}
function un(a){this.a=a}
function Bn(a){this.a=a}
function Cn(a){this.a=a}
function Fn(a){this.a=a}
function In(a){this.a=a}
function Jn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function ho(a){this.a=a}
function jo(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function Ao(a){this.a=a}
function Do(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function Ro(a){this.a=a}
function gp(a){this.a=a}
function jp(a){this.a=a}
function kp(a){this.a=a}
function lp(a){this.a=a}
function mp(a){this.a=a}
function np(a){this.a=a}
function An(){this.a={}}
function Hn(){this.a={}}
function Sj(a,b){a.a=b}
function Wm(a,b){a.d=b}
function Xm(a,b){a.e=b}
function Ym(a,b){a.f=b}
function Zm(a,b){a.g=b}
function Dn(a,b){a.k=b}
function En(a,b){a.n=b}
function so(a,b){Un(b,a)}
function C(a,b){yb(a.b,b)}
function $(a){Kb((J(),a))}
function w(a){--a.e;D(a)}
function Fm(a){Em();Dm=a}
function hm(a){fm();em=a}
function jl(a){il();hl=a}
function ul(a){tl();sl=a}
function Jl(a){Il();Hl=a}
function $p(a){sj(this,a)}
function bq(a){fi(this,a)}
function gq(){ok(this.a)}
function lq(){qk(this.a)}
function aj(){this.a=jj()}
function oj(){this.a=jj()}
function F(){this.b=new zb}
function J(){J=wh;I=new F}
function pc(){this.b=new Wi}
function mb(a,b){a.b=vj(b)}
function $l(a,b){ao(a.k,b)}
function oc(a,b){vi(a.b,b)}
function ro(a,b){_n(a.b,b)}
function Vj(a,b){Lj(a.a,b)}
function ab(a){Lb((J(),a))}
function db(a){Mb((J(),a))}
function hh(a){return a.e}
function jq(){return this.e}
function aq(){return this.b}
function dq(){return this.c}
function Xp(){return this.a}
function ji(a,b){return a===b}
function _l(a,b){return a.g=b}
function eq(){return this.d<0}
function kq(){return this.c<0}
function nq(){return this.f<0}
function Zp(){return ck(this)}
function fj(){fj=wh;ej=hj()}
function wc(){wc=wh;vc=new o}
function Nc(){Nc=wh;Mc=new Qc}
function Dh(){Dh=wh;Ch=new o}
function po(){po=wh;oo=new qo}
function Uo(){Uo=wh;To=new Vo}
function yo(a){this.b=vj(a)}
function vl(a){nc(a.b);gb(a.a)}
function _h(a){uc.call(this,a)}
function oi(a){uc.call(this,a)}
function _m(a){lk.call(this,a)}
function bn(a){lk.call(this,a)}
function dn(a){lk.call(this,a)}
function fn(a){lk.call(this,a)}
function hn(a){lk.call(this,a)}
function Yp(a){return this===a}
function Yc(a,b){return Vh(a,b)}
function Ki(a,b){return a.a[b]}
function Ph(a){Oh(a);return a.k}
function X(a){J();Lb(a);a.e=-2}
function Eb(a){Fb(a);!a.d&&Ib(a)}
function kk(a,b,c){a[b]=c}
function mc(a,b,c){ui(a.b,b,c)}
function wj(a,b){while(a.eb(b));}
function Lj(a,b){Sj(a,Kj(a.a,b))}
function $j(a,b){a.splice(b,1)}
function Kj(a,b){a.T(b);return a}
function Wb(a){bb(a.b);return a.g}
function Vb(a){bb(a.a);return a.e}
function jj(){fj();return new ej}
function fq(){return J(),J(),I}
function hq(){return tk(this.a)}
function _p(){return xi(this.a)}
function xi(a){return a.a.b+a.b.b}
function Yb(a){Ub(a,(bb(a.b),a.g))}
function Rn(a){bb(a.a);return a.g}
function Qn(a){bb(a.b);return a.i}
function Go(a){bb(a.d);return a.f}
function wk(a,b){a.ref=b;return a}
function dc(a,b){this.a=a;this.b=b}
function lc(a,b){this.a=a;this.b=b}
function $h(a,b){this.a=a;this.b=b}
function Gi(a,b){this.a=a;this.b=b}
function Oj(a,b){this.a=a;this.b=b}
function Eh(a){this.a=Ch;this.b=a}
function Sl(a,b){this.a=a;this.b=b}
function el(a,b){$h.call(this,a,b)}
function tm(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function wm(a,b){this.a=a;this.b=b}
function sn(a,b){this.a=a;this.b=b}
function tn(a,b){this.a=a;this.b=b}
function vn(a,b){this.a=a;this.b=b}
function wn(a,b){this.a=a;this.b=b}
function gi(){qc(this);this.H()}
function io(a,b){this.a=a;this.b=b}
function zo(a,b){this.b=a;this.a=b}
function Co(a,b){this.a=a;this.b=b}
function So(a,b){this.b=a;this.a=b}
function ep(a,b){$h.call(this,a,b)}
function Zl(a,b){Lo(a.n,b);nm(a,b)}
function lj(a,b){return a.a.get(b)}
function bd(a){return new Array(a)}
function xn(a){return yn(new An,a)}
function nd(a){return typeof a===qp}
function ph(){nh==null&&(nh=[])}
function Dc(){Dc=wh;!!(Uc(),Tc)}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function L(a){a.b=0;a.d=0;a.c=false}
function Gb(a){return !a.d?a:Gb(a.d)}
function ti(a){return !a?null:a.ab()}
function qd(a){return a==null?null:a}
function pq(){return Hh(this.a.J())}
function uj(a){return a!=null?r(a):0}
function Kc(a){$wnd.clearTimeout(a)}
function xk(a,b){a.href=b;return a}
function Hk(a,b){a.value=b;return a}
function Ck(a,b){a.onBlur=b;return a}
function li(a,b){a.a+=''+b;return a}
function Pj(a,b){a.C(zn(xn(b.e),b))}
function Yj(a,b,c){a.splice(b,0,c)}
function yk(a,b){a.onClick=b;return a}
function Ak(a,b){a.checked=b;return a}
function Hi(a){a.a=$c(ke,tp,1,0,5,1)}
function wi(a){a.a=new aj;a.b=new oj}
function gk(){gk=wh;dk=new o;fk=new o}
function eb(a){this.c=new Qi;this.b=a}
function mq(a,b){return sk(this.a,a)}
function cq(){return T(this.e.b).a>0}
function Tn(a){Un(a,(bb(a.a),!a.g))}
function Nl(a){nc(a.c);gb(a.a);W(a.b)}
function ll(a){nc(a.c);gb(a.b);S(a.a)}
function bm(a,b){nm(a,b);Lo(a.n,null)}
function A(a,b,c){t(a,new G(b),c,null)}
function Zj(a,b){Xj(b,0,a,0,b.length)}
function jc(a,b){hc(a,b,false);ab(a.d)}
function lb(a){J();kb(a);nb(a,2,true)}
function bb(a){var b;Hb((J(),b=Cb,b),a)}
function ck(a){return a.$H||(a.$H=++bk)}
function ii(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function V(a){return !(!!a&&1==(a.c&7))}
function pd(a){return typeof a==='string'}
function dd(a,b,c){return {l:a,m:b,h:c}}
function md(a){return typeof a==='boolean'}
function zk(a){a.autoFocus=true;return a}
function Dk(a,b){a.onChange=b;return a}
function Ek(a,b){a.onKeyDown=b;return a}
function Bk(a,b){a.defaultValue=b;return a}
function Oh(a){if(a.k!=null){return}Xh(a)}
function rc(a,b){a.e=b;b!=null&&ak(b,Ep,a)}
function cj(a,b){var c;c=a[Jp];c.call(a,b)}
function Jj(a,b){Ej.call(this,a);this.a=b}
function uc(a){this.f=a;qc(this);this.H()}
function Wi(){this.a=new aj;this.b=new oj}
function Q(){this.a=$c(ke,tp,1,100,5,1)}
function ei(){ei=wh;di=$c(ge,tp,33,256,0,1)}
function Jh(){Jh=wh;Ih=$wnd.window.document}
function Sh(a){var b;b=Rh(a);Zh(a,b);return b}
function Uh(){var a;a=Rh(null);a.e=2;return a}
function qc(a){a.g&&a.e!==Dp&&a.H();return a}
function Ik(a,b){a.onDoubleClick=b;return a}
function sj(a,b){while(a.Y()){Vj(b,a.Z())}}
function ic(a,b){oc(b.D(),a);ld(b,12)&&b.w()}
function Ec(a,b,c){return a.apply(b,c);var d}
function u(a,b){return new qb(vj(a),null,b)}
function fo(a){return ci(T(a.e).a-T(a.a).a)}
function Sn(a){nc(a.c);W(a.d);W(a.b);W(a.a)}
function yn(a,b){kk(a.a,'key',vj(b));return a}
function Ii(a,b){a.a[a.a.length]=b;return true}
function sk(a,b){var c;c=a.nb(b);return c||a.o}
function sm(a,b,c){this.a=a;this.b=b;this.c=c}
function Am(a,b,c){this.a=a;this.b=b;this.c=c}
function Mm(a,b,c){this.a=a;this.b=b;this.c=c}
function rj(a,b,c){this.a=a;this.b=b;this.c=c}
function Dl(a,b,c){this.a=a;this.b=b;this.c=c}
function ko(a,b){this.a=a;this.c=b;this.b=false}
function km(a,b){return Mh(),gm(a,b)?true:false}
function ad(a){return Array.isArray(a)&&a.yb===Ah}
function kj(a,b){return !(a.a.get(b)===undefined)}
function Ml(a,b){var c;c=b.target;Ol(a,c.value)}
function Rb(a,b){a.i&&b.preventDefault();ac(a)}
function jb(a,b){Z(b,a);b.c.a.length>0||(b.a=4)}
function Mj(a,b,c){if(a.a.fb(c)){a.b=true;b.C(c)}}
function yj(a){if(!a.d){a.d=a.b.S();a.c=a.b.U()}}
function Ab(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Gh(a){if(!a){throw hh(new gi)}return a}
function Bi(a){var b;b=a.a.Z();a.b=Ai(a);return b}
function Mi(a,b){var c;c=a.a[b];$j(a.a,b);return c}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function P(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function kd(a){return !Array.isArray(a)&&a.yb===Ah}
function eo(a){return Mh(),0==T(a.e).a?true:false}
function kl(a){return Mh(),T(a.e.b).a>0?true:false}
function Eo(a){return ji(Wp,a)||ji(Sp,a)||ji('',a)}
function Hj(a){Dj(a);return new Jj(a,new Qj(a.a))}
function yi(a,b){if(b){return ri(a.a,b)}return false}
function Hh(a){if(a==null){throw hh(new hi)}return a}
function vj(a){if(a==null){throw hh(new gi)}return a}
function jk(){if(ek==256){dk=fk;fk=new o;ek=0}++ek}
function Uc(){Uc=wh;var a;!Wc();a=new Xc;Tc=a}
function ak(b,c,d){try{b[c]=d}catch(a){}}
function Oi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Al(a){var b;b=new wl;Wm(b,a.a.J());return b}
function Vl(a){var b;b=new Pl;Xm(b,a.a.J());return b}
function Ol(a,b){var c;c=a.f;if(b!=c){a.f=b;ab(a.b)}}
function om(a,b){var c;c=a.i;if(b!=c){a.i=b;ab(a.a)}}
function Un(a,b){var c;c=a.g;if(b!=c){a.g=b;ab(a.a)}}
function Bm(a,b){var c;c=b.target;xo(a.e,c.checked)}
function jm(a){nc(a.e);gb(a.b);S(a.d);W(a.c);W(a.a)}
function Ho(a){gb(a.e);gb(a.a);S(a.b);S(a.c);W(a.d)}
function Cj(a){if(!a.b){Dj(a);a.c=true}else{Cj(a.b)}}
function Ej(a){if(!a){this.b=null;new Qi}else{this.b=a}}
function Qj(a){xj.call(this,a.db(),a.cb()&-6);this.a=a}
function xj(a,b){this.e=a;this.d=(b&64)!=0?b|rp:b}
function zj(a,b){this.b=a;this.a=(b&4096)==0?b|64|rp:b}
function Gk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Vi(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function rk(a){pk(a);return ld(a,12)&&a.A()?null:a.ob()}
function Gj(a,b){Dj(a);return new Jj(a,new Nj(b,a.a))}
function mh(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function ok(a){if(!a.o){a.o=true;a.p||a.q.forceUpdate()}}
function Wh(a){if(a.Q()){return null}var b=a.j;return sh[b]}
function Th(a,b){var c;c=Rh(a);Zh(a,c);c.e=b?8:0;return c}
function $b(a,b){var c;c=a.e;if(b!=c){a.e=vj(b);ab(a.a)}}
function _b(a,b){var c;c=a.g;if(b!=c){a.g=vj(b);ab(a.b)}}
function Vn(a,b){var c;c=a.i;if(b!=c){a.i=vj(b);ab(a.b)}}
function Yl(a,b){var c;if(T(a.d)){c=b.target;om(a,c.value)}}
function sc(a,b){var c;c=Ph(a.wb);return b==null?c:c+': '+b}
function si(a,b){return b===a?'(this Map)':b==null?Gp:zh(b)}
function fp(){dp();return cd(Yc(Tg,1),tp,38,0,[ap,cp,bp])}
function cb(a){var b;J();!!Cb&&!!Cb.e&&Hb((b=Cb,b),a)}
function xb(a){while(true){if(!vb(a)&&!wb(a)){break}}}
function Db(a){if(a.e){2==(a.e.c&7)||nb(a.e,4,true);kb(a.e)}}
function Fl(a,b){if(13==b.keyCode){b.preventDefault();Kl(a)}}
function yb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],vj(b))}
function Ob(a,b){Cb=new Nb(Cb,b);a.d=false;Db(Cb);return Cb}
function Nb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function ai(a){this.f=!a?null:sc(a,a.G());qc(this);this.H()}
function fi(a,b){var c,d;for(d=a.S();d.Y();){c=d.Z();b.C(c)}}
function vo(a,b){var c;Ij(bo(a.b),(c=new Qi,c)).R(new kp(b))}
function Vh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.L(b))}
function am(a,b,c){27==c.which?mm(a,b):13==c.which&&cm(a,b)}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&rp)?rp:8192)|0,b)}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&rp)?rp:8192)|0,b)}
function hb(a){var b;b=(J(),J(),I);yb(b.b,a);0!=(a.c&zp)&&D(b)}
function Yi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function yh(a){function b(){}
;b.prototype=a||{};return new b}
function Fh(a){Dh();Gh(a);if(ld(a,54)){return a}return new Eh(a)}
function tl(){tl=wh;var a;rl=(a=xh(an.prototype.ib,an,[]),a)}
function Il(){Il=wh;var a;Gl=(a=xh(cn.prototype.ib,cn,[]),a)}
function il(){il=wh;var a;gl=(a=xh($m.prototype.ib,$m,[]),a)}
function fm(){fm=wh;var a;dm=(a=xh(en.prototype.ib,en,[]),a)}
function Em(){Em=wh;var a;Cm=(a=xh(gn.prototype.ib,gn,[]),a)}
function iq(){return Go(this.n)==(cb(this.c),this.q.props['a'])}
function Ri(a){Hi(this);Zj(this.a,qi(a,$c(ke,tp,1,xi(a.a),5,1)))}
function Zi(a,b){var c;return Xi(b,Yi(a,b==null?0:(c=r(b),c|0)))}
function bo(a){bb(a.d);return new Jj(null,new zj(new Ei(a.g),0))}
function Fk(a){a.placeholder='What needs to be done?';return a}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function uh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Qb(a,b){a.j=b;ji(b,(bb(a.a),a.e))&&_b(a,b);Sb(b);ac(a)}
function Jo(a){var b;b=(bb(a.d),a.f);!!b&&!!b&&b.f<0&&Lo(a,null)}
function Lo(a,b){var c;c=a.f;if(!(b==c||!!b&&Pn(b,c))){a.f=b;ab(a.d)}}
function Y(a,b){var c,d;Ii(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Nj(a,b){xj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function bj(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function pj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Yo(a){this.c=a;this.a=new Bl(this.c.e);this.b=new Vm(this.a)}
function Zo(a){this.c=a;this.a=new Wl(this.c.f);this.b=new on(this.a)}
function Aj(a,b){!a.a?(a.a=new ni(a.d)):li(a.a,a.b);li(a.a,b);return a}
function Ij(a,b){var c;Cj(a);c=new Tj;c.a=b;a.a.X(new Wj(c));return c.a}
function Fj(a){var b;Cj(a);b=0;while(a.a.eb(new Uj)){b=ih(b,1)}return b}
function vi(a,b){return pd(b)?b==null?_i(a.a,null):nj(a.b,b):_i(a.a,b)}
function lm(a){return Mh(),Go(a.n)==(cb(a.c),a.q.props['a'])?true:false}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Om(a){return $wnd.React.createElement((il(),gl),a.a,undefined)}
function Sm(a){return $wnd.React.createElement((tl(),rl),a.a,undefined)}
function ln(a){return $wnd.React.createElement((Il(),Gl),a.a,undefined)}
function Gn(a){return $wnd.React.createElement((Em(),Cm),a.a,undefined)}
function Kh(a,b,c,d){a.addEventListener(b,c,(Mh(),d?true:false))}
function Lh(a,b,c,d){a.removeEventListener(b,c,(Mh(),d?true:false))}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function On(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Yn(a)),yp,null)}}
function uo(a){var b;Ij(Gj(bo(a.b),new ip),(b=new Qi,b)).R(new jp(a.b))}
function El(a){var b;b=ki((bb(a.b),a.f));if(b.length>0){ro(a.e,b);Ol(a,'')}}
function zm(a){var b;b=new pm;Dn(b,a.a.J());a.b.J();En(b,a.c.J());return b}
function tk(a){var b;a.o=false;if(a.kb()){return null}else{b=a.hb();return b}}
function qj(a){if(a.a.c!=a.c){return lj(a.a,a.b.value[0])}return a.b.value[1]}
function N(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Bj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Ci(a){this.d=a;this.c=new pj(this.d.b);this.a=this.c;this.b=Ai(this)}
function Xb(a){Lh((Jh(),$wnd.window.window),Bp,a.f,false);nc(a.c);W(a.b);W(a.a)}
function S(a){if(!a.a){a.a=true;a.g=null;a.b=null;W(a.d);2==(a.e.c&7)||gb(a.e)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{xb(a.b)}finally{a.c=false}}}}
function W(a){if(-2!=a.e){t((J(),J(),I),new G(new fb(a)),0,null);!!a.b&&gb(a.b)}}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Fo(a,b){return (dp(),bp)==a||(ap==a?(bb(b.a),!b.g):(bb(b.a),b.g))}
function ui(a,b,c){return pd(b)?b==null?$i(a.a,null,c):mj(a.b,b,c):$i(a.a,b,c)}
function _j(a,b){return Zc(b)!=10&&cd(q(b),b.xb,b.__elementTypeId$,Zc(b),a),a}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===pp||typeof a==='function')&&!(a.yb===Ah)}
function Io(a){var b,c;return b=T(a.b),Ij(Gj(bo(a.j),new mp(b)),(c=new Qi,c))}
function Ji(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.C(c)}}
function Ni(a,b){var c;c=Li(a,b,0);if(c==-1){return false}$j(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function Li(a,b,c){for(;c<a.a.length;++c){if(Vi(b,a.a[c])){return c}}return -1}
function Cl(a){var b;b=new ml;Xm(b,a.a.J());Ym(b,a.b.J());Zm(b,a.c.J());return b}
function Lm(a){var b;b=new Hm;Wm(b,a.a.J());Xm(b,a.b.J());Ym(b,a.c.J());return b}
function Rh(a){var b;b=new Qh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function vb(a){var b;if(0==P(a.c)){return false}else{b=O(a.c);!!b&&b.w();return true}}
function Zh(a,b){var c;if(!a){return}b.j=a;var d=Wh(b);if(!d){sh[a]=[b];return}d.wb=b}
function gh(a){var b;if(ld(a,4)){return a}b=a&&a[Ep];if(!b){b=new yc(a);Vc(b)}return b}
function xh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function oh(){ph();var a=nh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Pb(){var a;try{Eb(Cb);J()}finally{a=Cb.d;!a&&((J(),J(),I).d=true);Cb=Cb.d}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Hb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Ii((!a.b&&(a.b=new Qi),a.b),b)}}}
function Jb(a,b){var c;if(!a.c){c=Gb(a);!c.c&&(c.c=new Qi);a.c=c.c}b.d=true;Ii(a.c,vj(b))}
function nj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{cj(a.a,b);--a.b}return c}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);N(a,vj(b))}
function co(a){fi(new Ei(a.g),new kc(a));wi(a.g);S(a.c);S(a.e);S(a.a);S(a.b);W(a.d)}
function qk(a){var b;b=(++a.mb().e,new Bb);try{a.p=true;ld(a,12)&&a.w()}finally{Ab(b)}}
function hc(a,b,c){var d;d=vi(a.g,b?ci(b.e):null);if(null!=d){oc(b.c,a);c&&!!b&&On(b);ab(a.d)}}
function kb(a){var b,c;for(c=new Si(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ti(a){var b,c,d;d=0;for(c=new Ci(a.a);c.b;){b=Bi(c);d=d+(b?r(b):0);d=d|0}return d}
function pi(a,b){var c,d;for(d=new Ci(b.a);d.b;){c=Bi(d);if(!yi(a,c)){return false}}return true}
function Xo(a){this.c=a;this.a=new Dl(this.c.e,this.c.f,this.c.g);this.b=new Rm(this.a)}
function $o(a){this.c=a;this.a=new Am(this.c.e,this.c.f,this.c.g);this.b=new Cn(this.a)}
function _o(a){this.c=a;this.a=new Mm(this.c.e,this.c.f,this.c.g);this.b=new Jn(this.a)}
function lk(a){$wnd.React.Component.call(this,a);this.a=this.jb();this.a.q=vj(this);this.a.gb()}
function wl(){tl();++mk;this.b=new pc;this.a=new qb(null,vj((J(),new xl(this))),Np);D((null,I))}
function Hm(){Em();++mk;this.b=new pc;this.a=new qb(null,vj((J(),new Im(this))),Np);D((null,I))}
function hi(){uc.call(this,'Cannot return null from a non-@Nullable @Provides method')}
function zn(a,b){kk(a.a,(fm(),'a'),b);return $wnd.React.createElement(dm,a.a,undefined)}
function rh(a,b){typeof window===pp&&typeof window['$gwt']===pp&&(window['$gwt'][a]=b)}
function dp(){dp=wh;ap=new ep('ACTIVE',0);cp=new ep('COMPLETED',1);bp=new ep('ALL',2)}
function $n(a,b,c){var d;d=new Xn(b,c);mc(d.c,a,new lc(a,d));ui(a.g,ci(d.e),d);ab(a.d);return d}
function mj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function gm(a,b){var c;c=false;if(!Vi(a.q.props['a'],null==b?null:b['a'])){ab(a.c);c=true}return c}
function jh(a){var b;b=a.h;if(b==0){return a.l+a.m*zp}if(b==1048575){return a.l+a.m*zp-Hp}return a}
function Ai(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new bj(a.d.a);return a.a.Y()}
function T(a){bb(a.d);ob(a.e)&&ib(a.e);if(a.b){if(ld(a.b,5)){throw hh(a.b)}else{throw hh(a.b)}}return a.g}
function Ko(a){var b;b=Vb(a.i);ji(Wp,b)||ji(Sp,b)||ji('',b)?Ub(a.i,b):Eo(Wb(a.i))?Zb(a.i):Ub(a.i,'')}
function Z(a,b){var c,d;d=a.c;Ni(d,b);d.a.length==0&&!!a.b&&vp!=(a.b.c&wp)&&(a.d||Jb((J(),c=Cb,c),a))}
function Xi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Vi(a,c._())){return c}}return null}
function lh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Hp;d=1048575}c=rd(e/zp);b=rd(e-c*zp);return dd(b,c,d)}
function cd(a,b,c,d,e){e.wb=a;e.xb=b;e.yb=Ah;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Pn(a,b){var c;if(a===b){return true}else if(null==b||!ld(b,61)){return false}else{c=b;return a.e==c.e}}
function cm(a,b){var c;c=(bb(a.a),a.i);if(null!=c&&c.length!=0){wo(b,c);Lo(a.n,null);om(a,c)}else{ao(a.k,b)}}
function gb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new tb(a)),yp,null);!!a.a&&S(a.a);a.c=a.c&-8|1}}
function pk(a){if(!nk){nk=(++a.mb().e,new Bb);$wnd.Promise.resolve(null).then(xh(uk.prototype.K,uk,[]))}}
function Dj(a){if(a.b){Dj(a.b)}else if(a.c){throw hh(new _h("Stream already terminated, can't be modified or used"))}}
function q(a){return pd(a)?ne:nd(a)?ce:md(a)?ae:kd(a)?a.wb:ad(a)?a.wb:a.wb||Array.isArray(a)&&Yc(Ud,1)||Ud}
function r(a){return pd(a)?ik(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.t():ad(a)?ck(a):!!a&&!!a.hashCode?a.hashCode():ck(a)}
function ci(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ei(),di)[b];!c&&(c=di[b]=new bi(a));return c}return new bi(a)}
function zh(a){var b;if(Array.isArray(a)&&a.yb===Ah){return Ph(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function ik(a){gk();var b,c,d;c=':'+a;d=fk[c];if(d!=null){return rd(d)}d=dk[c];b=d==null?hk(a):rd(d);jk();fk[c]=b;return b}
function yc(a){wc();qc(this);this.e=a;a!=null&&ak(a,Ep,this);this.f=a==null?Gp:zh(a);this.a='';this.b=a;this.a=''}
function Qh(){this.g=Nh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function U(a,b){this.c=vj(a);this.f=null;this.g=null;this.e=new rb(this,b);this.d=new eb(this.e);vp==(b&wp)&&hb(this.e)}
function pb(a,b,c,d){this.b=new Qi;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&hb(this)}
function zb(){this.c=new Q;this.d=$c(vd,tp,21,5,0,1);this.d[0]=new Q;this.d[1]=new Q;this.d[2]=new Q;this.d[3]=new Q;this.d[4]=new Q}
function ml(){il();++mk;this.c=new pc;this.a=new U((J(),new nl(this)),136486912);this.b=new qb(null,vj(new pl(this)),Np);D((null,I))}
function Pl(){Il();var a;++mk;this.c=new pc;this.b=(a=new eb((J(),null)),a);this.a=new qb(null,vj(new Tl(this)),Np);D((null,I))}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function ih(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<Hp){return c}}return jh(ed(nd(a)?lh(a):a,nd(b)?lh(b):b))}
function Tb(a){var b,c;c=(b=(Jh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));$b(a,c);ji(a.j,c)&&_b(a,c)}
function nc(a){var b,c;if(!a.a){for(c=new Si(new Ri(new Ei(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.B()}a.a=true}}
function Ui(a){var b,c,d;d=1;for(c=new Si(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Pi(a,b){var c,d;d=a.a.length;b.length<d&&(b=_j(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Yh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function fl(){dl();return cd(Yc(bf,1),tp,9,0,[Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl])}
function p(a,b){return pd(a)?ji(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.r(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function Xl(a){var b;b=T(a.d);if(!a.j&&b){a.j=true;nm(a,(cb(a.c),a.q.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function vk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.xb){return !!a.xb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function O(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function qb(a,b,c){pb.call(this,null,a,b,c|(!a?262144:vp)|(a?rp:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:zp)|(0!=(c&229376)?0:98304)|0|0|0)}
function Mb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Si(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&nb(b,5,true)}}}
function Lb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Si(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&nb(b,6,true)}}}
function Kb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Si(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?nb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function ki(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ib(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=Mi(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&nb(c.b,3,true);++b}}}return b}
function Xn(a,b){var c,d,e;this.i=vj(a);this.g=b;this.e=Nn++;this.d=(d=new eb((J(),null)),d);this.c=new pc;this.b=(e=new eb(null),e);this.a=(c=new eb(null),c)}
function Zb(b){var c;try{A((J(),J(),I),new ec(b),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){c=a;throw hh(c)}else if(ld(a,4)){c=a;throw hh(new ai(c))}else throw hh(a)}}
function ac(b){var c;try{A((J(),J(),I),new fc(b),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){c=a;throw hh(c)}else if(ld(a,4)){c=a;throw hh(new ai(c))}else throw hh(a)}}
function Kl(b){var c;try{A((J(),J(),I),new Rl(b),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){c=a;throw hh(c)}else if(ld(a,4)){c=a;throw hh(new ai(c))}else throw hh(a)}}
function Wn(b){var c;try{A((J(),J(),I),new Zn(b),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){c=a;throw hh(c)}else if(ld(a,4)){c=a;throw hh(new ai(c))}else throw hh(a)}}
function to(b){var c;try{A((J(),J(),I),new Ao(b),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){c=a;throw hh(c)}else if(ld(a,4)){c=a;throw hh(new ai(c))}else throw hh(a)}}
function ao(b,c){var d;try{A((J(),J(),I),new io(b,c),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){d=a;throw hh(d)}else if(ld(a,4)){d=a;throw hh(new ai(d))}else throw hh(a)}}
function wo(b,c){var d;try{A((J(),J(),I),new zo(b,c),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){d=a;throw hh(d)}else if(ld(a,4)){d=a;throw hh(new ai(d))}else throw hh(a)}}
function xo(b,c){var d;try{A((J(),J(),I),new Co(b,c),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){d=a;throw hh(d)}else if(ld(a,4)){d=a;throw hh(new ai(d))}else throw hh(a)}}
function Ll(b,c){var d;try{A((J(),J(),I),new Sl(b,c),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){d=a;throw hh(d)}else if(ld(a,4)){d=a;throw hh(new ai(d))}else throw hh(a)}}
function im(b,c){var d;try{A((J(),J(),I),new wm(b,c),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){d=a;throw hh(d)}else if(ld(a,4)){d=a;throw hh(new ai(d))}else throw hh(a)}}
function mm(b,c){var d;try{A((J(),J(),I),new vm(b,c),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){d=a;throw hh(d)}else if(ld(a,4)){d=a;throw hh(new ai(d))}else throw hh(a)}}
function nm(b,c){var d;try{A((J(),J(),I),new um(b,c),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){d=a;throw hh(d)}else if(ld(a,4)){d=a;throw hh(new ai(d))}else throw hh(a)}}
function Ub(b,c){var d;try{A((J(),J(),I),new dc(b,c),75505664)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){d=a;throw hh(d)}else if(ld(a,4)){d=a;throw hh(new ai(d))}else throw hh(a)}}
function _n(b,c){var d;try{return t((J(),J(),I),new ko(b,c),Cp,null)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){d=a;throw hh(d)}else if(ld(a,4)){d=a;throw hh(new ai(d))}else throw hh(a)}}
function qh(b,c,d,e){ph();var f=nh;$moduleName=c;$moduleBase=d;fh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{op(g)()}catch(a){b(c,a)}}else{op(g)()}}
function rb(a,b){pb.call(this,a,new sb(a),null,b|(vp==(b&wp)?0:524288)|(0!=(b&6291456)?0:vp==(b&wp)?zp:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function Bh(){var a;a=new Wo;jl(new Qm(a));ul(new Um(a));hm(new Bn(a));Fm(new In(a));Jl(new nn(a));$wnd.ReactDOM.render(Gn(new Hn),(Jh(),Ih).getElementById('todoapp'),null)}
function hj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return ij()}}
function go(){var a;this.g=new Wi;this.d=(a=new eb((J(),null)),a);this.c=new U(new jo(this),Vp);this.e=new U(new lo(this),Vp);this.a=new U(new mo(this),Vp);this.b=new U(new no(this),Vp)}
function pm(){fm();var a,b;++mk;this.e=new pc;this.c=(b=new eb((J(),null)),b);this.a=(a=new eb(null),a);this.d=new U(new xm(this),136486912);this.b=new qb(null,vj(new ym(this)),Np);D((null,I))}
function qi(a,b){var c,d,e,f,g;g=xi(a.a);b.length<g&&(b=_j(new Array(g),b));e=(f=new Ci((new zi(a.a)).a),new Fi(f));for(d=0;d<g;++d){b[d]=(c=Bi(e.a),c.ab())}b.length>g&&(b[g]=null);return b}
function th(){sh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].zb()&&(c=Rc(c,g)):g[0].zb()}catch(a){a=gh(a);if(ld(a,4)){d=a;Dc();Jc(ld(d,41)?d.I():d)}else throw hh(a)}}return c}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?Gp:od(b)?b==null?null:b.name:pd(b)?'String':Ph(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.g;try{d=b.c.v();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;$(b.d)}}catch(a){a=gh(a);if(ld(a,13)){c=a;if(!b.b){b.g=null;b.b=c;$(b.d)}throw hh(c)}else throw hh(a)}}
function Xj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function $i(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Xi(b,e);if(f){return f.bb(c)}}e[e.length]=new Gi(b,c);++a.b;return null}
function Wo(){this.a=Fh((po(),po(),oo));this.e=Fh(new gp(this.a));this.b=Fh(new Do(this.e));this.f=Fh(new lp(this.b));this.d=Fh((Uo(),Uo(),To));this.c=Fh(new So(this.e,this.d));this.g=Fh(new np(this.c))}
function hk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ii(a,c++)}b=b|0;return b}
function M(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=$c(ke,tp,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function Mo(a,b){var c;this.j=vj(a);this.i=vj(b);this.d=(c=new eb((J(),null)),c);this.b=new U(new Oo(this),Vp);this.c=new U(new Po(this),Vp);this.e=u(new Qo(this),413155328);this.a=u(new Ro(this),681590784);D((null,I))}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=rp==(d&rp)?c.v():c.v()}else{Ob(b,e);try{g=rp==(d&rp)?c.v():c.v()}finally{Pb()}}return g}catch(a){a=gh(a);if(ld(a,4)){f=a;throw hh(f)}else throw hh(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=rp==(d&rp)?(c.a.B(),null):(c.a.B(),null)}else{Ob(b,e);try{g=rp==(d&rp)?(c.a.B(),null):(c.a.B(),null)}finally{Pb()}}return g}catch(a){a=gh(a);if(ld(a,4)){f=a;throw hh(f)}else throw hh(a)}finally{D(b)}}
function Sb(a){var b;if(0==a.length){b=(Jh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Ih.title,b)}else{(Jh(),$wnd.window.window).location.hash=a}}
function ib(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.B()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=gh(a);if(ld(a,4)){J()}else throw hh(a)}}}
function _i(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Vi(b,e._())){if(d.length==1){d.length=0;cj(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function vh(a,b,c){var d=sh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=sh[b]),yh(h));_.xb=c;!b&&(_.yb=Ah);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.wb=f)}
function Xh(a){if(a.P()){var b=a.c;b.Q()?(a.k='['+b.j):!b.P()?(a.k='[L'+b.N()+';'):(a.k='['+b.N());a.b=b.M()+'[]';a.i=b.O()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Yh('.',[c,Yh('$',d)]);a.b=Yh('.',[c,Yh('.',d)]);a.i=d[d.length-1]}
function bc(){var a,b,c;this.f=new gc(this);this.c=new pc;this.b=(c=new eb((J(),null)),c);this.a=(b=new eb(null),b);Kh((Jh(),$wnd.window.window),Bp,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function ri(a,b){var c,d,e;c=b._();e=b.ab();d=pd(c)?c==null?ti(Zi(a.a,null)):lj(a.b,c):ti(Zi(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Zi(a.a,null):kj(a.b,c):!!Zi(a.a,c))){return false}return true}
function ob(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Si(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=gh(a);if(!ld(a,4))throw hh(a)}if(6==(b.c&7)){return true}}}}}kb(b);return false}
function gj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function nb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){db(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}Ji(a.b,new ub(a));a.b.a=$c(ke,tp,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function wb(a){var b,c,d,e,f,g,h,i;d=P(a.d[0]);c=P(a.d[1]);g=P(a.d[2]);e=P(a.d[3]);f=P(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;L(a.d[0]);L(a.d[1]);L(a.d[2]);L(a.d[3]);L(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=O(b);h.c&=-513;ib(h);return true}
function dl(){dl=wh;Jk=new el(Kp,0);Kk=new el('checkbox',1);Lk=new el('color',2);Mk=new el('date',3);Nk=new el('datetime',4);Ok=new el('email',5);Pk=new el('file',6);Qk=new el('hidden',7);Rk=new el('image',8);Sk=new el('month',9);Tk=new el(qp,10);Uk=new el('password',11);Vk=new el('radio',12);Wk=new el('range',13);Xk=new el('reset',14);Yk=new el('search',15);Zk=new el('submit',16);$k=new el('tel',17);_k=new el('text',18);al=new el('time',19);bl=new el('url',20);cl=new el('week',21)}
function Fb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ki(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Oi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Z(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&nb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ki(a.b,g);if(-1==k.e){k.e=0;Y(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Mi(a.b,g)}e&&mb(a.e,a.b)}else{e&&mb(a.e,new Qi)}if(V(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&vp!=(b.e.c&wp)&&Jb(a,k)}}
function ij(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Jp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!gj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Jp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var pp='object',qp='number',rp=16384,sp={16:1},tp={3:1,6:1},up={12:1},vp=1048576,wp=1835008,xp={8:1},yp=67108864,zp=4194304,Ap={31:1},Bp='hashchange',Cp=142614528,Dp='__noinit__',Ep='__java$exception',Fp={3:1,13:1,5:1,4:1},Gp='null',Hp=17592186044416,Ip={50:1},Jp='delete',Kp='button',Lp={11:1,43:1},Mp='selected',Np=1478631424,Op={11:1,44:1},Pp={11:1,47:1},Qp='input',Rp={11:1,45:1},Sp='completed',Tp={11:1,46:1},Up='header',Vp=136323072,Wp='active';var _,sh,nh,fh=-1;th();vh(1,null,{},o);_.r=Yp;_.s=function(){return this.wb};_.t=Zp;_.u=function(){var a;return Ph(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.r(a)};_.hashCode=function(){return this.t()};_.toString=function(){return this.u()};var fd,gd,hd;vh(63,1,{},Qh);_.L=function(a){var b;b=new Qh;b.e=4;a>1?(b.c=Vh(this,a-1)):(b.c=this);return b};_.M=function(){Oh(this);return this.b};_.N=function(){return Ph(this)};_.O=function(){Oh(this);return this.i};_.P=function(){return (this.e&4)!=0};_.Q=function(){return (this.e&1)!=0};_.u=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Oh(this),this.k)};_.e=0;_.g=0;var Nh=1;var ke=Sh(1);var be=Sh(63);vh(98,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var ud=Sh(98);vh(17,1,sp,G);_.v=function(){return this.a.B(),null};var sd=Sh(17);vh(99,1,{},H);var td=Sh(99);var I;vh(21,1,{21:1},Q);_.b=0;_.c=false;_.d=0;var vd=Sh(21);vh(235,1,up);_.u=function(){var a;return Ph(this.wb)+'@'+(a=r(this)>>>0,a.toString(16))};var xd=Sh(235);vh(22,235,up,U);_.w=function(){S(this)};_.A=Xp;_.a=false;var wd=Sh(22);vh(18,235,{12:1,18:1},eb);_.w=function(){W(this)};_.A=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=Sh(18);vh(165,1,xp,fb);_.B=function(){X(this.a)};var yd=Sh(165);vh(20,235,{12:1,20:1},qb,rb);_.w=function(){gb(this)};_.A=function(){return 1==(this.c&7)};_.c=0;var Dd=Sh(20);vh(166,1,Ap,sb);_.B=function(){R(this.a)};var Ad=Sh(166);vh(167,1,xp,tb);_.B=function(){lb(this.a)};var Bd=Sh(167);vh(168,1,{},ub);_.C=function(a){jb(this.a,a)};var Cd=Sh(168);vh(127,1,{},zb);_.a=0;_.b=100;_.e=0;var Ed=Sh(127);vh(80,1,up,Bb);_.w=function(){Ab(this)};_.A=Xp;_.a=false;var Fd=Sh(80);vh(174,1,{},Nb);_.u=function(){var a;return Oh(Gd),Gd.k+'@'+(a=ck(this)>>>0,a.toString(16))};_.a=0;var Cb;var Gd=Sh(174);vh(59,1,{59:1});_.e='';_.g='';_.i=true;_.j='';var Nd=Sh(59);vh(169,59,{12:1,59:1,40:1},bc);_.w=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new cc(this)),yp,null)}};_.r=Yp;_.D=dq;_.t=Zp;_.A=eq;_.u=function(){var a;return Oh(Ld),Ld.k+'@'+(a=ck(this)>>>0,a.toString(16))};_.d=0;var Ld=Sh(169);vh(170,1,xp,cc);_.B=function(){Xb(this.a)};var Hd=Sh(170);vh(171,1,xp,dc);_.B=function(){Qb(this.a,this.b)};var Id=Sh(171);vh(172,1,xp,ec);_.B=function(){Yb(this.a)};var Jd=Sh(172);vh(173,1,xp,fc);_.B=function(){Tb(this.a)};var Kd=Sh(173);vh(148,1,{},gc);_.handleEvent=function(a){Rb(this.a,a)};var Md=Sh(148);vh(129,1,{});var Qd=Sh(129);vh(138,1,{},kc);_.C=function(a){ic(this.a,a)};var Od=Sh(138);vh(139,1,xp,lc);_.B=function(){jc(this.a,this.b)};var Pd=Sh(139);vh(130,129,{});var Rd=Sh(130);vh(28,1,up,pc);_.w=function(){nc(this)};_.A=Xp;_.a=false;var Sd=Sh(28);vh(4,1,{3:1,4:1});_.F=function(a){return new Error(a)};_.G=function(){return this.f};_.H=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Ph(this.wb),c==null?a:a+': '+c);rc(this,tc(this.F(b)));Vc(this)};_.u=function(){return sc(this,this.G())};_.e=Dp;_.g=true;var oe=Sh(4);vh(13,4,{3:1,13:1,4:1});var ee=Sh(13);vh(5,13,Fp);var le=Sh(5);vh(52,5,Fp);var he=Sh(52);vh(95,52,Fp);var Wd=Sh(95);vh(41,95,{41:1,3:1,13:1,5:1,4:1},yc);_.G=function(){xc(this);return this.c};_.I=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Td=Sh(41);var Ud=Sh(0);vh(218,1,{});var Vd=Sh(218);var Ac=0,Bc=0,Cc=-1;vh(107,218,{},Qc);var Mc;var Xd=Sh(107);var Tc;vh(229,1,{});var Zd=Sh(229);vh(96,229,{},Xc);var Yd=Sh(96);vh(54,1,{54:1},Eh);_.J=function(){var a,b;b=this.a;if(qd(b)===qd(Ch)){b=this.a;if(qd(b)===qd(Ch)){b=this.b.J();a=this.a;if(qd(a)!==qd(Ch)&&qd(a)!==qd(b)){throw hh(new _h('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}this.a=b;this.b=null}}return b};var Ch;var $d=Sh(54);var Ih;vh(93,1,{90:1});_.u=Xp;var _d=Sh(93);fd={3:1,91:1,32:1};var ae=Sh(91);vh(51,1,{3:1,51:1});var je=Sh(51);gd={3:1,32:1,51:1};var ce=Sh(228);vh(36,1,{3:1,32:1,36:1});_.r=Yp;_.t=Zp;_.u=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=Sh(36);vh(10,5,Fp,_h,ai);var fe=Sh(10);vh(33,51,{3:1,32:1,33:1,51:1},bi);_.r=function(a){return ld(a,33)&&a.a==this.a};_.t=Xp;_.u=function(){return ''+this.a};_.a=0;var ge=Sh(33);var di;vh(285,1,{});vh(53,52,Fp,gi,hi);_.F=function(a){return new TypeError(a)};var ie=Sh(53);hd={3:1,90:1,32:1,2:1};var ne=Sh(2);vh(94,93,{90:1},ni);var me=Sh(94);vh(289,1,{});vh(70,5,Fp,oi);var pe=Sh(70);vh(230,1,{49:1});_.R=bq;_.V=function(){return new zj(this,0)};_.W=function(){return new Jj(null,this.V())};_.T=function(a){throw hh(new oi('Add not supported on this collection'))};_.u=function(){var a,b,c;c=new Bj('[',']');for(b=this.S();b.Y();){a=b.Z();Aj(c,a===this?'(this Collection)':a==null?Gp:zh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var qe=Sh(230);vh(233,1,{217:1});_.r=function(a){var b,c,d;if(a===this){return true}if(!ld(a,42)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Ci((new zi(d)).a);c.b;){b=Bi(c);if(!ri(this,b)){return false}}return true};_.t=function(){return Ti(new zi(this))};_.u=function(){var a,b,c;c=new Bj('{','}');for(b=new Ci((new zi(this)).a);b.b;){a=Bi(b);Aj(c,si(this,a._())+'='+si(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Be=Sh(233);vh(126,233,{217:1});var te=Sh(126);vh(232,230,{49:1,240:1});_.V=function(){return new zj(this,1)};_.r=function(a){var b;if(a===this){return true}if(!ld(a,26)){return false}b=a;if(xi(b.a)!=this.U()){return false}return pi(this,b)};_.t=function(){return Ti(this)};var Ce=Sh(232);vh(26,232,{26:1,49:1,240:1},zi);_.S=function(){return new Ci(this.a)};_.U=_p;var se=Sh(26);vh(27,1,{},Ci);_.X=$p;_.Z=function(){return Bi(this)};_.Y=aq;_.b=false;var re=Sh(27);vh(231,230,{49:1,237:1});_.V=function(){return new zj(this,16)};_.$=function(a,b){throw hh(new oi('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.r=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,15)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Si(f);for(c=new Si(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.t=function(){return Ui(this)};_.S=function(){return new Di(this)};var ve=Sh(231);vh(105,1,{},Di);_.X=$p;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Ki(this.b,this.a++)};_.a=0;var ue=Sh(105);vh(55,230,{49:1},Ei);_.S=function(){var a;return a=new Ci((new zi(this.a)).a),new Fi(a)};_.U=_p;var xe=Sh(55);vh(72,1,{},Fi);_.X=$p;_.Y=function(){return this.a.b};_.Z=function(){var a;return a=Bi(this.a),a.ab()};var we=Sh(72);vh(115,1,Ip);_.r=function(a){var b;if(!ld(a,50)){return false}b=a;return Vi(this.a,b._())&&Vi(this.b,b.ab())};_._=Xp;_.ab=aq;_.t=function(){return uj(this.a)^uj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.u=function(){return this.a+'='+this.b};var ye=Sh(115);vh(116,115,Ip,Gi);var ze=Sh(116);vh(234,1,Ip);_.r=function(a){var b;if(!ld(a,50)){return false}b=a;return Vi(this.b.value[0],b._())&&Vi(qj(this),b.ab())};_.t=function(){return uj(this.b.value[0])^uj(qj(this))};_.u=function(){return this.b.value[0]+'='+qj(this)};var Ae=Sh(234);vh(15,231,{3:1,15:1,49:1,237:1},Qi,Ri);_.$=function(a,b){Yj(this.a,a,b)};_.T=function(a){return Ii(this,a)};_.R=function(a){Ji(this,a)};_.S=function(){return new Si(this)};_.U=function(){return this.a.length};var Ee=Sh(15);vh(19,1,{},Si);_.X=$p;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var De=Sh(19);vh(42,126,{3:1,42:1,217:1},Wi);var Fe=Sh(42);vh(75,1,{},aj);_.R=bq;_.S=function(){return new bj(this)};_.b=0;var He=Sh(75);vh(76,1,{},bj);_.X=$p;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ge=Sh(76);var ej;vh(73,1,{},oj);_.R=bq;_.S=function(){return new pj(this)};_.b=0;_.c=0;var Ke=Sh(73);vh(74,1,{},pj);_.X=$p;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new rj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Ie=Sh(74);vh(128,234,Ip,rj);_._=function(){return this.b.value[0]};_.ab=function(){return qj(this)};_.bb=function(a){return mj(this.a,this.b.value[0],a)};_.c=0;var Je=Sh(128);vh(106,1,{});_.X=function(a){wj(this,a)};_.cb=function(){return this.d};_.db=jq;_.d=0;_.e=0;var Me=Sh(106);vh(71,106,{});var Le=Sh(71);vh(25,1,{},zj);_.cb=Xp;_.db=function(){yj(this);return this.c};_.X=function(a){yj(this);this.d.X(a)};_.eb=function(a){yj(this);if(this.d.Y()){a.C(this.d.Z());return true}return false};_.a=0;_.c=0;var Ne=Sh(25);vh(64,1,{},Bj);_.u=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Oe=Sh(64);var Xe=Uh();vh(117,1,{});_.c=false;var Ye=Sh(117);vh(35,117,{},Jj);var We=Sh(35);vh(119,71,{},Nj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Oj(this,a)));return this.b};_.b=false;var Qe=Sh(119);vh(122,1,{},Oj);_.C=function(a){Mj(this.a,this.b,a)};var Pe=Sh(122);vh(118,71,{},Qj);_.eb=function(a){return this.a.eb(new Rj(a))};var Se=Sh(118);vh(121,1,{},Rj);_.C=function(a){Pj(this.a,a)};var Re=Sh(121);vh(120,1,{},Tj);_.C=function(a){Sj(this,a)};var Te=Sh(120);vh(123,1,{},Uj);_.C=function(a){};var Ue=Sh(123);vh(124,1,{},Wj);_.C=function(a){Vj(this,a)};var Ve=Sh(124);vh(287,1,{});vh(236,1,{});var Ze=Sh(236);vh(284,1,{});var bk=0;var dk,ek=0,fk;vh(747,1,{});vh(762,1,{});vh(11,1,{11:1});_.gb=oq;var $e=Sh(11);vh(34,$wnd.React.Component,{});uh(sh[1],_);_.render=function(){return rk(this.a)};var _e=Sh(34);vh(37,11,{11:1});_.kb=function(){return false};_.lb=function(a,b){};_.nb=function(a){return false};_.ob=function(){return tk(this)};_.o=false;_.p=false;var mk=1,nk;var af=Sh(37);vh(255,$wnd.Function,{},uk);_.K=function(a){return Ab(nk),nk=null,null};vh(9,36,{3:1,32:1,36:1,9:1},el);var Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl;var bf=Th(9,fl);vh(43,37,Lp);_.tb=cq;_.hb=function(){var a;a=T(this.g.b);return $wnd.React.createElement('footer',vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,['footer'])),Sm(new Tm),$wnd.React.createElement('ul',vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',xk(vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,[(dp(),bp)==a?Mp:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',xk(vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,[ap==a?Mp:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',xk(vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,[cp==a?Mp:null])),'#completed'),'Completed'))),this.tb()?$wnd.React.createElement(Kp,yk(vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,['clear-completed'])),xh(Nm.prototype.sb,Nm,[this])),'Clear Completed'):null)};var Sf=Sh(43);vh(175,43,Lp);_.tb=cq;var gl,hl;var Wf=Sh(175);vh(176,175,{12:1,40:1,11:1,43:1},ml);_.w=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new ql(this)),yp,null)}};_.r=Yp;_.mb=fq;_.D=dq;_.tb=function(){return T(this.a)};_.t=Zp;_.A=eq;_.u=function(){var a;return Oh(nf),nf.k+'@'+(a=ck(this)>>>0,a.toString(16))};_.ob=function(){var b;try{return B((J(),J(),I),this.b,new ol(this))}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){b=a;throw hh(b)}else if(ld(a,4)){b=a;throw hh(new ai(b))}else throw hh(a)}};_.d=0;var nf=Sh(176);vh(177,1,sp,nl);_.v=function(){return kl(this.a)};var cf=Sh(177);vh(180,1,sp,ol);_.v=hq;var df=Sh(180);vh(178,1,Ap,pl);_.B=gq;var ef=Sh(178);vh(179,1,xp,ql);_.B=function(){ll(this.a)};var ff=Sh(179);vh(44,37,Op);_.hb=function(){var a,b;b=T(this.d.e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,['todo-count'])),$wnd.React.createElement('strong',null,b),' '+a+' left')};var Rf=Sh(44);vh(181,44,Op);var rl,sl;var Vf=Sh(181);vh(182,181,{12:1,40:1,11:1,44:1},wl);_.w=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new yl(this)),yp,null)}};_.r=Yp;_.mb=fq;_.D=aq;_.t=Zp;_.A=kq;_.u=function(){var a;return Oh(lf),lf.k+'@'+(a=ck(this)>>>0,a.toString(16))};_.ob=function(){var b;try{return B((J(),J(),I),this.a,new zl(this))}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){b=a;throw hh(b)}else if(ld(a,4)){b=a;throw hh(new ai(b))}else throw hh(a)}};_.c=0;var lf=Sh(182);vh(183,1,Ap,xl);_.B=gq;var gf=Sh(183);vh(184,1,xp,yl);_.B=function(){vl(this.a)};var hf=Sh(184);vh(185,1,sp,zl);_.v=hq;var jf=Sh(185);vh(157,1,{},Bl);_.J=function(){return Al(this)};var kf=Sh(157);vh(155,1,{},Dl);_.J=function(){return Cl(this)};var mf=Sh(155);vh(47,37,Pp);_.hb=function(){return $wnd.React.createElement(Qp,zk(Dk(Ek(Hk(Fk(vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,['new-todo']))),(bb(this.b),this.f)),xh(jn.prototype.rb,jn,[this])),xh(kn.prototype.qb,kn,[this]))))};_.f='';var eg=Sh(47);vh(202,47,Pp);var Gl,Hl;var Yf=Sh(202);vh(203,202,{12:1,40:1,11:1,47:1},Pl);_.w=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Ul(this)),yp,null)}};_.r=Yp;_.mb=fq;_.D=dq;_.t=Zp;_.A=eq;_.u=function(){var a;return Oh(uf),uf.k+'@'+(a=ck(this)>>>0,a.toString(16))};_.ob=function(){var b;try{return B((J(),J(),I),this.a,new Ql(this))}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){b=a;throw hh(b)}else if(ld(a,4)){b=a;throw hh(new ai(b))}else throw hh(a)}};_.d=0;var uf=Sh(203);vh(206,1,sp,Ql);_.v=hq;var of=Sh(206);vh(207,1,xp,Rl);_.B=function(){El(this.a)};var pf=Sh(207);vh(208,1,xp,Sl);_.B=function(){Ml(this.a,this.b)};var qf=Sh(208);vh(204,1,Ap,Tl);_.B=gq;var rf=Sh(204);vh(205,1,xp,Ul);_.B=function(){Nl(this.a)};var sf=Sh(205);vh(163,1,{},Wl);_.J=function(){return Vl(this)};var tf=Sh(163);vh(45,37,Rp);_.lb=function(a,b){Xl(this)};_.vb=iq;_.gb=function(){nm(this,this.ub())};_.hb=function(){var a,b;b=this.ub();a=(bb(b.a),b.g);return $wnd.React.createElement('li',vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,[a?Sp:null,this.vb()?'editing':null])),$wnd.React.createElement('div',vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,['view'])),$wnd.React.createElement(Qp,Dk(Ak(Gk(vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,['toggle'])),(dl(),Kk)),a),xh(rn.prototype.qb,rn,[b]))),$wnd.React.createElement('label',Ik(new $wnd.Object,xh(sn.prototype.sb,sn,[this,b])),(bb(b.b),b.i)),$wnd.React.createElement(Kp,yk(vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,['destroy'])),xh(tn.prototype.sb,tn,[this,b])))),$wnd.React.createElement(Qp,Ek(Dk(Ck(Bk(vk(wk(new $wnd.Object,xh(un.prototype.C,un,[this])),cd(Yc(ne,1),tp,2,6,['edit'])),(bb(this.a),this.i)),xh(vn.prototype.pb,vn,[this,b])),xh(qn.prototype.qb,qn,[this])),xh(wn.prototype.rb,wn,[this,b]))))};_.j=false;var ig=Sh(45);vh(186,45,Rp);_.kb=function(){var a;a=(cb(this.c),this.q.props['a']);if(!!a&&a.f<0){return true}return false};_.ub=function(){return this.q.props['a']};_.vb=iq;_.nb=function(a){return gm(this,a)};var dm,em;var $f=Sh(186);vh(187,186,{12:1,40:1,11:1,45:1},pm);_.lb=function(b,c){var d;try{A((J(),J(),I),new sm(this,b,c),Cp)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){d=a;throw hh(d)}else if(ld(a,4)){d=a;throw hh(new ai(d))}else throw hh(a)}};_.w=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new qm(this)),yp,null)}};_.r=Yp;_.mb=fq;_.D=jq;_.ub=function(){return cb(this.c),this.q.props['a']};_.t=Zp;_.A=nq;_.vb=function(){return T(this.d)};_.nb=function(b){var c;try{return t((J(),J(),I),new tm(this,b),75505664,null)}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){c=a;throw hh(c)}else if(ld(a,4)){c=a;throw hh(new ai(c))}else throw hh(a)}};_.u=function(){var a;return Oh(Ff),Ff.k+'@'+(a=ck(this)>>>0,a.toString(16))};_.ob=function(){var b;try{return B((J(),J(),I),this.b,new rm(this))}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){b=a;throw hh(b)}else if(ld(a,4)){b=a;throw hh(new ai(b))}else throw hh(a)}};_.f=0;var Ff=Sh(187);vh(190,1,xp,qm);_.B=function(){jm(this.a)};var vf=Sh(190);vh(191,1,sp,rm);_.v=hq;var wf=Sh(191);vh(192,1,xp,sm);_.B=function(){Xl(this.a)};var xf=Sh(192);vh(193,1,sp,tm);_.v=function(){return km(this.a,this.b)};var yf=Sh(193);vh(194,1,xp,um);_.B=function(){om(this.a,Qn(this.b))};var zf=Sh(194);vh(195,1,xp,vm);_.B=function(){bm(this.a,this.b)};var Af=Sh(195);vh(196,1,xp,wm);_.B=function(){Yl(this.a,this.b)};var Bf=Sh(196);vh(188,1,sp,xm);_.v=function(){return lm(this.a)};var Cf=Sh(188);vh(189,1,Ap,ym);_.B=gq;var Df=Sh(189);vh(159,1,{},Am);_.J=function(){return zm(this)};var Ef=Sh(159);vh(46,37,Tp);_.hb=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(Up,vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,[Up])),$wnd.React.createElement('h1',null,'todos'),ln(new mn)),T(this.d.c)?null:$wnd.React.createElement('section',vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,[Up])),$wnd.React.createElement(Qp,Dk(Gk(vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,['toggle-all'])),(dl(),Kk)),xh(Fn.prototype.qb,Fn,[this]))),$wnd.React.createElement.apply(null,['ul',vk(new $wnd.Object,cd(Yc(ne,1),tp,2,6,['todo-list']))].concat((a=Ij(Hj(T(this.f.c).W()),(b=new Qi,b)),Pi(a,bd(a.a.length)))))),T(this.d.c)?null:Om(new Pm)))};var mg=Sh(46);vh(197,46,Tp);var Cm,Dm;var ag=Sh(197);vh(198,197,{12:1,40:1,11:1,46:1},Hm);_.w=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Jm(this)),yp,null)}};_.r=Yp;_.mb=fq;_.D=aq;_.t=Zp;_.A=kq;_.u=function(){var a;return Oh(Kf),Kf.k+'@'+(a=ck(this)>>>0,a.toString(16))};_.ob=function(){var b;try{return B((J(),J(),I),this.a,new Km(this))}catch(a){a=gh(a);if(ld(a,5)||ld(a,7)){b=a;throw hh(b)}else if(ld(a,4)){b=a;throw hh(new ai(b))}else throw hh(a)}};_.c=0;var Kf=Sh(198);vh(199,1,Ap,Im);_.B=gq;var Gf=Sh(199);vh(200,1,xp,Jm);_.B=function(){vl(this.a)};var Hf=Sh(200);vh(201,1,sp,Km);_.v=hq;var If=Sh(201);vh(161,1,{},Mm);_.J=function(){return Lm(this)};var Jf=Sh(161);vh(254,$wnd.Function,{},Nm);_.sb=function(a){to(this.a.f)};vh(211,1,{},Pm);var Lf=Sh(211);vh(84,1,{},Qm);_.J=function(){return Hh(Cl((new Xo(this.a)).b.a))};var Mf=Sh(84);vh(156,1,{},Rm);_.J=function(){return Hh(Cl(this.a))};var Nf=Sh(156);vh(209,1,{},Tm);var Of=Sh(209);vh(85,1,{},Um);_.J=function(){return Hh(Al((new Yo(this.a)).b.a))};var Pf=Sh(85);vh(158,1,{},Vm);_.J=function(){return Hh(Al(this.a))};var Qf=Sh(158);vh(253,$wnd.Function,{},$m);_.ib=function(a){return new _m(a)};vh(100,34,{},_m);_.jb=function(){return il(),Hh(Cl((new Xo(hl.a)).b.a))};_.componentWillUnmount=lq;_.shouldComponentUpdate=mq;var Tf=Sh(100);vh(257,$wnd.Function,{},an);_.ib=function(a){return new bn(a)};vh(101,34,{},bn);_.jb=function(){return tl(),Hh(Al((new Yo(sl.a)).b.a))};_.componentWillUnmount=lq;_.shouldComponentUpdate=mq;var Uf=Sh(101);vh(269,$wnd.Function,{},cn);_.ib=function(a){return new dn(a)};vh(104,34,{},dn);_.jb=function(){return Il(),Hh(Vl((new Zo(Hl.a)).b.a))};_.componentWillUnmount=lq;_.shouldComponentUpdate=mq;var Xf=Sh(104);vh(258,$wnd.Function,{},en);_.ib=function(a){return new fn(a)};vh(102,34,{},fn);_.jb=function(){return fm(),Hh(zm((new $o(em.a)).b.a))};_.componentDidUpdate=function(a,b){this.a.lb(a,b)};_.componentWillUnmount=lq;_.shouldComponentUpdate=mq;var Zf=Sh(102);vh(267,$wnd.Function,{},gn);_.ib=function(a){return new hn(a)};vh(103,34,{},hn);_.jb=function(){return Em(),Hh(Lm((new _o(Dm.a)).b.a))};_.componentWillUnmount=lq;_.shouldComponentUpdate=mq;var _f=Sh(103);vh(270,$wnd.Function,{},jn);_.rb=function(a){Fl(this.a,a)};vh(271,$wnd.Function,{},kn);_.qb=function(a){Ll(this.a,a)};vh(210,1,{},mn);var bg=Sh(210);vh(88,1,{},nn);_.J=function(){return Hh(Vl((new Zo(this.a)).b.a))};var cg=Sh(88);vh(164,1,{},on);_.J=function(){return Hh(Vl(this.a))};var dg=Sh(164);vh(265,$wnd.Function,{},qn);_.qb=function(a){im(this.a,a)};vh(259,$wnd.Function,{},rn);_.qb=function(a){Wn(this.a)};vh(261,$wnd.Function,{},sn);_.sb=function(a){Zl(this.a,this.b)};vh(262,$wnd.Function,{},tn);_.sb=function(a){$l(this.a,this.b)};vh(263,$wnd.Function,{},un);_.C=function(a){_l(this.a,a)};vh(264,$wnd.Function,{},vn);_.pb=function(a){cm(this.a,this.b)};vh(266,$wnd.Function,{},wn);_.rb=function(a){am(this.a,this.b,a)};vh(212,1,{},An);var fg=Sh(212);vh(86,1,{},Bn);_.J=function(){return Hh(zm((new $o(this.a)).b.a))};var gg=Sh(86);vh(160,1,{},Cn);_.J=function(){return Hh(zm(this.a))};var hg=Sh(160);vh(268,$wnd.Function,{},Fn);_.qb=function(a){Bm(this.a,a)};vh(89,1,{},Hn);var jg=Sh(89);vh(87,1,{},In);_.J=function(){return Hh(Lm((new _o(this.a)).b.a))};var kg=Sh(87);vh(162,1,{},Jn);_.J=function(){return Hh(Lm(this.a))};var lg=Sh(162);vh(60,1,{60:1});_.g=false;var ah=Sh(60);vh(61,60,{12:1,40:1,61:1,60:1},Xn);_.w=function(){On(this)};_.r=function(a){return Pn(this,a)};_.D=dq;_.t=jq;_.A=nq;_.u=function(){var a;return Oh(Eg),Eg.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var Nn=0;var Eg=Sh(61);vh(213,1,xp,Yn);_.B=function(){Sn(this.a)};var ng=Sh(213);vh(214,1,xp,Zn);_.B=function(){Tn(this.a)};var og=Sh(214);vh(56,130,{56:1});var Wg=Sh(56);vh(77,56,{12:1,77:1,56:1},go);_.w=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new ho(this)),yp,null)}};_.r=Yp;_.t=Zp;_.A=nq;_.u=function(){var a;return Oh(xg),xg.k+'@'+(a=ck(this)>>>0,a.toString(16))};_.f=0;var xg=Sh(77);vh(135,1,xp,ho);_.B=function(){co(this.a)};var pg=Sh(135);vh(136,1,xp,io);_.B=function(){hc(this.a,this.b,true)};var qg=Sh(136);vh(131,1,sp,jo);_.v=function(){return eo(this.a)};var rg=Sh(131);vh(137,1,sp,ko);_.v=function(){return $n(this.a,this.c,this.b)};_.b=false;var sg=Sh(137);vh(132,1,sp,lo);_.v=function(){return ci(mh(Fj(bo(this.a))))};var tg=Sh(132);vh(133,1,sp,mo);_.v=function(){return ci(mh(Fj(Gj(bo(this.a),new hp))))};var ug=Sh(133);vh(134,1,sp,no);_.v=function(){return fo(this.a)};var vg=Sh(134);vh(108,1,{},qo);_.J=function(){return new go};var oo;var wg=Sh(108);vh(57,1,{57:1});var _g=Sh(57);vh(78,57,{12:1,78:1,57:1},yo);_.w=function(){if(this.a>=0){this.a=-2;t((J(),J(),I),new G(new Bo),yp,null)}};_.r=Yp;_.t=Zp;_.A=function(){return this.a<0};_.u=function(){var a;return Oh(Dg),Dg.k+'@'+(a=ck(this)>>>0,a.toString(16))};_.a=0;var Dg=Sh(78);vh(143,1,xp,zo);_.B=function(){Vn(this.b,this.a)};var yg=Sh(143);vh(144,1,xp,Ao);_.B=function(){uo(this.a)};var zg=Sh(144);vh(141,1,xp,Bo);_.B=oq;var Ag=Sh(141);vh(142,1,xp,Co);_.B=function(){vo(this.a,this.b)};_.b=false;var Bg=Sh(142);vh(110,1,{},Do);_.J=function(){return new yo(this.a.J())};var Cg=Sh(110);vh(58,1,{58:1});var eh=Sh(58);vh(79,58,{12:1,79:1,58:1},Mo);_.w=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new No(this)),yp,null)}};_.r=Yp;_.t=Zp;_.A=function(){return this.g<0};_.u=function(){var a;return Oh(Lg),Lg.k+'@'+(a=ck(this)>>>0,a.toString(16))};_.g=0;var Lg=Sh(79);vh(153,1,xp,No);_.B=function(){Ho(this.a)};var Fg=Sh(153);vh(149,1,sp,Oo);_.v=function(){var a;return a=Wb(this.a.i),ji(Wp,a)||ji(Sp,a)||ji('',a)?ji(Wp,a)?(dp(),ap):ji(Sp,a)?(dp(),cp):(dp(),bp):(dp(),bp)};var Gg=Sh(149);vh(150,1,sp,Po);_.v=function(){return Io(this.a)};var Hg=Sh(150);vh(151,1,Ap,Qo);_.B=function(){Jo(this.a)};var Ig=Sh(151);vh(152,1,Ap,Ro);_.B=function(){Ko(this.a)};var Jg=Sh(152);vh(113,1,{},So);_.J=function(){return new Mo(this.b.J(),this.a.J())};var Kg=Sh(113);vh(112,1,{},Vo);_.J=function(){return Hh(new bc)};var To;var Mg=Sh(112);vh(83,1,{},Wo);var Sg=Sh(83);vh(65,1,{},Xo);var Ng=Sh(65);vh(69,1,{},Yo);var Og=Sh(69);vh(68,1,{},Zo);var Pg=Sh(68);vh(66,1,{},$o);var Qg=Sh(66);vh(67,1,{},_o);var Rg=Sh(67);vh(38,36,{3:1,32:1,36:1,38:1},ep);var ap,bp,cp;var Tg=Th(38,fp);vh(109,1,{},gp);_.J=pq;var Ug=Sh(109);vh(140,1,{},hp);_.fb=function(a){return !Rn(a)};var Vg=Sh(140);vh(146,1,{},ip);_.fb=function(a){return Rn(a)};var Xg=Sh(146);vh(147,1,{},jp);_.C=function(a){ao(this.a,a)};var Yg=Sh(147);vh(145,1,{},kp);_.C=function(a){so(this.a,a)};_.a=false;var Zg=Sh(145);vh(111,1,{},lp);_.J=pq;var $g=Sh(111);vh(154,1,{},mp);_.fb=function(a){return Fo(this.a,a)};var bh=Sh(154);vh(114,1,{},np);_.J=pq;var dh=Sh(114);var op=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=qh;oh(Bh);rh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();