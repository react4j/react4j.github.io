function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='DB1AF66DE3EF45F90CA37032A6330406',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'DB1AF66DE3EF45F90CA37032A6330406';function o(){}
function jh(){}
function fh(){}
function Hb(){}
function Hm(){}
function vm(){}
function zm(){}
function Dm(){}
function Lm(){}
function Lc(){}
function Sc(){}
function pj(){}
function qj(){}
function Fk(){}
function Jn(){}
function po(){}
function Xo(){}
function Yo(){}
function Qc(a){Pc()}
function rm(a){qm=a}
function um(a){tm=a}
function Tm(a){Sm=a}
function cn(a){bn=a}
function gn(a){fn=a}
function rh(){rh=fh}
function pi(){gi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function lb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function gc(a){this.a=a}
function mc(a){this.a=a}
function Gh(a){this.a=a}
function $h(a){this.a=a}
function di(a){this.a=a}
function ei(a){this.a=a}
function ci(a){this.b=a}
function ri(a){this.c=a}
function nj(a){this.a=a}
function sj(a){this.a=a}
function Ok(a){this.a=a}
function Rk(a){this.a=a}
function Sk(a){this.a=a}
function Tk(a){this.a=a}
function $k(a){this.a=a}
function al(a){this.a=a}
function bl(a){this.a=a}
function cl(a){this.a=a}
function pl(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function tl(a){this.a=a}
function vl(a){this.a=a}
function Sl(a){this.a=a}
function Vl(a){this.a=a}
function Xl(a){this.a=a}
function am(a){this.a=a}
function bm(a){this.a=a}
function jm(a){this.a=a}
function mm(a){this.a=a}
function nm(a){this.a=a}
function om(a){this.a=a}
function Pm(a){this.a=a}
function Qm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function Ym(a){this.a=a}
function dn(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function on(a){this.a=a}
function qn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Hn(a){this.a=a}
function In(a){this.a=a}
function Vn(a){this.a=a}
function Wn(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function jo(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function oj(a,b){a.a=b}
function Kj(a,b){a.key=b}
function Jj(a,b){Ij(a,b)}
function ro(a,b){Rn(b,a)}
function Ep(a){Ti(this,a)}
function Ip(a){Kh(this,a)}
function Jp(){ic(this.c)}
function Kp(){ic(this.b)}
function Bi(){this.a=Ki()}
function Pi(){this.a=Ki()}
function jc(a){!!a&&a.t()}
function w(a){--a.e;D(a)}
function gb(a){Vb((J(),a))}
function hb(a){Wb((J(),a))}
function jb(a){Xb((J(),a))}
function Lp(){mb(this.a.a)}
function Rg(a){return a.b}
function Kb(a){a.a=-4&a.a|1}
function sb(a,b){a.b=Wi(b)}
function bc(a,b){Wh(a.b,b)}
function qo(a,b){Zn(a.b,b)}
function xl(a,b){$n(a.j,b)}
function rj(a,b){ij(a.a,b)}
function C(a,b){ab(a.f,b.f)}
function V(a){fd(a,8)&&a.s()}
function Gk(a){a.d=2;ic(a.c)}
function Uk(a){a.c=2;ic(a.b)}
function El(a){a.e=2;ic(a.d)}
function Kk(a){mb(a.b);R(a.a)}
function xn(a){R(a.a);cb(a.b)}
function Gi(){Gi=fh;Fi=Ii()}
function J(){J=fh;I=new F}
function sc(){sc=fh;rc=new o}
function Ic(){Ic=fh;Hc=new Lc}
function oo(){oo=fh;no=new po}
function cc(){this.b=new vi}
function Gp(){return this.a}
function Hp(){return this.b}
function Dp(){return Aj(this)}
function Cp(a){return this===a}
function Nh(a,b){return a===b}
function yl(a,b){return a.f=b}
function ji(a,b){return a.a[b]}
function Tc(a,b){return zh(a,b)}
function wj(a,b){a.splice(b,1)}
function _b(a,b,c){Vh(a.b,b,c)}
function Xi(a,b){while(a.Z(b));}
function Qh(a){qc.call(this,a)}
function Lh(){nc(this);this.w()}
function Fp(){return Yh(this.a)}
function Ki(){Gi();return new Fi}
function uh(a){th(a);return a.k}
function hj(a,b){a.M(b);return a}
function ij(a,b){oj(a,hj(a.a,b))}
function jl(a){mb(a.a);cb(a.b)}
function Mn(a){cb(a.b);cb(a.a)}
function zn(a){ib(a.b);return a.e}
function Pn(a){ib(a.a);return a.d}
function Eo(a){ib(a.d);return a.f}
function Tj(a,b){a.ref=b;return a}
function db(a){J();Wb(a);a.e=-2}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function yc(){yc=fh;!!(Pc(),Oc)}
function Gc(){vc!=0&&(vc=0);xc=-1}
function Zg(){Xg==null&&(Xg=[])}
function W(a){return !!a&&a.c.i<0}
function Yh(a){return a.a.b+a.b.b}
function Mi(a,b){return a.a.get(b)}
function Mp(a){return 1==this.a.d}
function Np(a){return 1==this.a.c}
function Yc(a){return new Array(a)}
function v(a,b,c){s(a,new H(c),b)}
function uj(a,b,c){a.splice(b,0,c)}
function Bk(a,b){Eh.call(this,a,b)}
function hc(a,b){this.a=a;this.b=b}
function Eh(a,b){this.a=a;this.b=b}
function fi(a,b){this.a=a;this.b=b}
function lj(a,b){this.a=a;this.b=b}
function Rj(a,b){this.a=a;this.b=b}
function ul(a,b){this.a=a;this.b=b}
function Wl(a,b){this.a=a;this.b=b}
function Yl(a,b){this.a=a;this.b=b}
function Zl(a,b){this.a=a;this.b=b}
function $l(a,b){this.a=a;this.b=b}
function _l(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function Zm(a,b){this.a=a;this.b=b}
function $m(a,b){this.a=a;this.b=b}
function Kn(a,b){this.a=a;this.b=b}
function ho(a,b){this.a=a;this.b=b}
function xo(a,b){this.a=a;this.b=b}
function yo(a,b){this.b=a;this.a=b}
function Vo(a,b){Eh.call(this,a,b)}
function Uj(a,b){a.href=b;return a}
function ck(a,b){a.value=b;return a}
function Fc(a){$wnd.clearTimeout(a)}
function pm(){this.a=Lj((xm(),wm))}
function sm(){this.a=Lj((Bm(),Am))}
function Rm(){this.a=Lj((Fm(),Em))}
function an(){this.a=Lj((Jm(),Im))}
function en(){this.a=Lj((Nm(),Mm))}
function An(a){yn(a,(ib(a.b),a.e))}
function Qn(a){Rn(a,(ib(a.a),!a.d))}
function Rb(a){return !a.d?a:Rb(a.d)}
function Uh(a){return !a?null:a.V()}
function kd(a){return a==null?null:a}
function Vi(a){return a!=null?r(a):0}
function hd(a){return typeof a===bp}
function Xh(a){a.a=new Bi;a.b=new Pi}
function kb(a){this.c=new pi;this.b=a}
function gi(a){a.a=Vc(be,dp,1,0,5,1)}
function rb(a){J();qb(a);ub(a,2,true)}
function Il(a){mb(a.b);R(a.c);cb(a.a)}
function fc(a,b){dc(a,b,false);hb(a.d)}
function vj(a,b){tj(b,0,a,0,b.length)}
function A(a,b,c){t(a,new G(b),c,null)}
function B(a,b,c){return t(a,c,2048,b)}
function X(a){return !(!!a&&1==(a.c&7))}
function Ph(a){return !a?'null':''+a.a}
function $c(a,b,c){return {l:a,m:b,h:c}}
function Ij(a,b){for(var c in a){b(c)}}
function Zj(a,b){a.onBlur=b;return a}
function Vj(a,b){a.onClick=b;return a}
function $j(a,b){a.onChange=b;return a}
function Xj(a,b){a.checked=b;return a}
function _j(a,b){a.onKeyDown=b;return a}
function Wj(a){a.autoFocus=true;return a}
function Ej(){Ej=fh;Bj=new o;Dj=new o}
function Aj(a){return a.$H||(a.$H=++zj)}
function Mh(a,b){return a.charCodeAt(b)}
function fd(a,b){return a!=null&&dd(a,b)}
function jd(a){return typeof a==='string'}
function Fb(a){this.d=Wi(a);this.b=100}
function lh(a){this.b=Wi(a);this.a=this}
function qc(a){this.c=a;nc(this);this.w()}
function gj(a,b){bj.call(this,a);this.a=b}
function _k(a,b){return new Zk(Wi(b),a.a)}
function ql(a,b){return new ol(Wi(b),a.a)}
function gd(a){return typeof a==='boolean'}
function ib(a){var b;Sb((J(),b=Nb,b),a)}
function oc(a,b){a.b=b;b!=null&&yj(b,mp,a)}
function th(a){if(a.k!=null){return}Bh(a)}
function Yj(a,b){a.defaultValue=b;return a}
function Ti(a,b){while(a.R()){rj(b,a.S())}}
function Di(a,b){var c;c=a[qp];c.call(a,b)}
function u(a,b){return new xb(Wi(a),null,b)}
function P(){this.a=Vc(be,dp,1,100,5,1)}
function vi(){this.a=new Bi;this.b=new Pi}
function oh(){oh=fh;nh=$wnd.window.document}
function Jh(){Jh=fh;Ih=Vc(Zd,dp,30,256,0,1)}
function T(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function co(a){return Hh(S(a.e).a-S(a.a).a)}
function Go(a){W((ib(a.d),a.f))&&Io(a,null)}
function so(a){A((J(),J(),I),new zo(a),vp)}
function Nl(a){A((J(),J(),I),new bm(a),vp)}
function Bn(a){A((J(),J(),I),new Hn(a),vp)}
function Tn(a){A((J(),J(),I),new Wn(a),vp)}
function $(a,b,c){Kb(Wi(c));K(a.a[b],Wi(c))}
function Si(a,b,c){this.a=a;this.b=b;this.c=c}
function Qk(a,b,c){this.a=a;this.b=b;this.c=c}
function Ul(a,b,c){this.a=a;this.b=b;this.c=c}
function lm(a,b,c){this.a=a;this.b=b;this.c=c}
function zc(a,b,c){return a.apply(b,c);var d}
function ec(a,b){bc(b.c.c,a);fd(b,8)&&b.s()}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function kl(a,b){A((J(),J(),I),new ul(a,b),vp)}
function Jl(a,b){A((J(),J(),I),new _l(a,b),vp)}
function Ll(a,b){A((J(),J(),I),new Zl(a,b),vp)}
function Ml(a,b){A((J(),J(),I),new Yl(a,b),vp)}
function Pl(a,b){A((J(),J(),I),new Wl(a,b),vp)}
function $n(a,b){A((J(),J(),I),new ho(a,b),vp)}
function vo(a,b){A((J(),J(),I),new xo(a,b),vp)}
function ll(a,b){var c;c=b.target;nl(a,c.value)}
function xh(a){var b;b=wh(a);Dh(a,b);return b}
function nc(a){a.d&&a.b!==lp&&a.w();return a}
function dk(a,b){a.onDoubleClick=b;return a}
function hi(a,b){a.a[a.a.length]=b;return true}
function io(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new bb;this.a=new Fb(this.f)}
function ao(a){Kh(new di(a.g),new gc(a));Xh(a.g)}
function Eb(a){while(true){if(!Db(a)){break}}}
function yj(b,c,d){try{b[c]=d}catch(a){}}
function jj(a,b,c){if(a.a.$(c)){a.b=true;b.u(c)}}
function Gb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Zi(a){if(!a.d){a.d=a.b.L();a.c=a.b.N()}}
function ai(a){var b;b=a.a.S();a.b=_h(a);return b}
function bo(a){return rh(),0==S(a.e).a?true:false}
function Pk(a,b){return new Nk(Wi(b),a.a,a.b,a.c)}
function Tl(a,b){return new Rl(Wi(b),a.a,a.b,a.c)}
function km(a,b){return new im(Wi(b),a.a,a.b,a.c)}
function Li(a,b){return !(a.a.get(b)===undefined)}
function Xc(a){return Array.isArray(a)&&a.hb===jh}
function ed(a){return !Array.isArray(a)&&a.hb===jh}
function Lk(a){return rh(),S(a.e.b).a>0?true:false}
function Mk(a){return B((J(),J(),I),a.b,new Tk(a))}
function Yk(a){return B((J(),J(),I),a.a,new cl(a))}
function ml(a){return B((J(),J(),I),a.a,new sl(a))}
function mh(a){Wi(a);return fd(a,44)?a:new lh(a)}
function ej(a){aj(a);return new gj(a,new mj(a.a))}
function Ol(a){return B((J(),J(),I),a.b,new Vl(a))}
function hm(a){return B((J(),J(),I),a.a,new nm(a))}
function Bo(a){return Nh(Bp,a)||Nh(xp,a)||Nh('',a)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function pb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function Mc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function li(a,b){var c;c=a.a[b];wj(a.a,b);return c}
function ni(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function cm(a,b){var c;c=b.target;vo(a.e,c.checked)}
function Yn(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function _i(a){if(!a.b){aj(a);a.c=true}else{_i(a.b)}}
function Hk(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function Vk(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function Fl(a){if(0==a.e){a.e=1;a.n.forceUpdate()}}
function Hj(){if(Cj==256){Bj=Dj;Dj=new o;Cj=0}++Cj}
function Wi(a){if(a==null){throw Rg(new Lh)}return a}
function Zh(a,b){if(b){return Th(a.a,b)}return false}
function dj(a,b){aj(a);return new gj(a,new kj(b,a.a))}
function yn(a,b){A((J(),J(),I),new Kn(a,b),75497472)}
function Rn(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function Ql(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function nl(a,b){var c;c=a.f;if(b!=c){a.f=b;hb(a.b)}}
function wn(a){var b;T(a.a);b=S(a.a);Nh(a.f,b)&&Cn(a,b)}
function Do(a){mb(a.e);mb(a.a);R(a.b);R(a.c);cb(a.d)}
function Cn(a,b){var c;c=a.e;if(b!=c){a.e=Wi(b);hb(a.b)}}
function yh(a,b){var c;c=wh(a);Dh(a,c);c.e=b?8:0;return c}
function bk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Yi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function $i(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function mj(a){Yi.call(this,a.Y(),a.X()&-6);this.a=a}
function bj(a){if(!a){this.b=null;new pi}else{this.b=a}}
function Pc(){Pc=fh;var a;!Rc();a=new Sc;Oc=a}
function ui(a,b){return kd(a)===kd(b)||a!=null&&p(a,b)}
function Zn(a,b){return t((J(),J(),I),new io(a,b),vp,null)}
function Bl(a,b){Io(a.k,b);A((J(),J(),I),new Wl(a,b),vp)}
function kc(a){jc(a.g);V(a.c);V(a.a);V(a.d);jc(a.b);jc(a.f)}
function nb(a){C((J(),J(),I),a);0==(a.f.a&ip)&&D((null,I))}
function Al(a,b){A((J(),J(),I),new Wl(a,b),vp);Io(a.k,null)}
function sn(a){ph((oh(),$wnd.window.window),zp,a.d,false)}
function tn(a){qh((oh(),$wnd.window.window),zp,a.d,false)}
function Ec(a){yc();$wnd.setTimeout(function(){throw a},0)}
function Ah(a){if(a.J()){return null}var b=a.j;return ah[b]}
function Wg(a){if(hd(a)){return a|0}return a.l|a.m<<22}
function wl(a,b){var c;if(S(a.c)){c=b.target;Ql(a,c.value)}}
function Kh(a,b){var c,d;for(d=a.L();d.R();){c=d.S();b.u(c)}}
function jn(a){return new Qk(a.a.a.B(),a.a.b.B(),a.a.c.B())}
function nn(a){return new Ul(a.a.a.B(),a.a.b.B(),a.a.c.B())}
function pn(a){return new lm(a.a.a.B(),a.a.b.B(),a.a.c.B())}
function Wo(){Uo();return Zc(Tc(Fg,1),dp,32,0,[Ro,To,So])}
function xm(){xm=fh;var a;wm=(a=gh(vm.prototype.eb,vm,[]),a)}
function Bm(){Bm=fh;var a;Am=(a=gh(zm.prototype.eb,zm,[]),a)}
function Fm(){Fm=fh;var a;Em=(a=gh(Dm.prototype.eb,Dm,[]),a)}
function Jm(){Jm=fh;var a;Im=(a=gh(Hm.prototype.eb,Hm,[]),a)}
function Nm(){Nm=fh;var a;Mm=(a=gh(Lm.prototype.eb,Lm,[]),a)}
function to(a,b){var c;fj(_n(a.b),(c=new pi,c)).K(new $o(b))}
function zh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.D(b))}
function xi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function un(a,b){b.preventDefault();A((J(),J(),I),new In(a),vp)}
function ph(a,b,c,d){a.addEventListener(b,c,(rh(),d?true:false))}
function Kl(a){return rh(),Eo(a.k)==a.n.props['a']?true:false}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function hh(a){function b(){}
;b.prototype=a||{};return new b}
function pc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function ak(a){a.placeholder='What needs to be done?';return a}
function Ob(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);qb(a.e)}}
function aj(a){if(a.b){aj(a.b)}else if(a.c){throw Rg(new Fh)}}
function _n(a){ib(a.d);return new gj(null,new $i(new di(a.g),0))}
function yi(a,b){var c;return wi(b,xi(a,b==null?0:(c=r(b),c|0)))}
function dh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Cc(a,b,c){var d;d=Ac();try{return zc(a,b,c)}finally{Dc(d)}}
function qh(a,b,c,d){a.removeEventListener(b,c,(rh(),d?true:false))}
function qi(a){gi(this);vj(this.a,Sh(a,Vc(be,dp,1,Yh(a.a),5,1)))}
function Ci(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Cm(a){$wnd.React.Component.call(this,a);this.a=_k(tm,this)}
function ym(a){$wnd.React.Component.call(this,a);this.a=Pk(qm,this)}
function Gm(a){$wnd.React.Component.call(this,a);this.a=ql(Sm,this)}
function Km(a){$wnd.React.Component.call(this,a);this.a=Tl(bn,this)}
function Om(a){$wnd.React.Component.call(this,a);this.a=km(fn,this)}
function Qi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function kj(a,b){Yi.call(this,b.Y(),b.X()&-16449);this.a=a;this.c=b}
function eb(a,b){var c,d;hi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Io(a,b){var c;c=a.f;if(!(b==c||!!b&&Nn(b,c))){a.f=b;hb(a.d)}}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function fj(a,b){var c;_i(a);c=new pj;c.a=b;a.a.Q(new sj(c));return c.a}
function cj(a){var b;_i(a);b=0;while(a.a.Z(new qj)){b=Sg(b,1)}return b}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function uo(a){var b;fj(dj(_n(a.b),new Yo),(b=new pi,b)).K(new Zo(a.b))}
function dl(a){var b;b=Oh((ib(a.b),a.f));if(b.length>0){qo(a.e,b);nl(a,'')}}
function Wh(a,b){return jd(b)?b==null?Ai(a.a,null):Oi(a.b,b):Ai(a.a,b)}
function Co(a,b){return (Uo(),So)==a||(Ro==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function ld(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Dc(a){a&&Kc((Ic(),Hc));--vc;if(a){if(xc!=-1){Fc(xc);xc=-1}}}
function Lb(b){try{b.b.t()}catch(a){a=Qg(a);if(!fd(a,5))throw Rg(a)}}
function wo(a){this.b=Wi(a);J();this.a=new lc(0,null,null,false,false)}
function bi(a){this.d=a;this.c=new Qi(this.d.b);this.a=this.c;this.b=_h(this)}
function Ri(a){if(a.a.c!=a.c){return Mi(a.a,a.b.value[0])}return a.b.value[1]}
function uc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Bc(b){yc();return function(){return Cc(b,this,arguments);var a}}
function Nn(a,b){var c;if(fd(b,49)){c=b;return a.c.e==c.c.e}else{return false}}
function Vc(a,b,c,d,e,f){var g;g=Wc(e,d);e!=10&&Zc(Tc(a,f),b,c,e,g);return g}
function mi(a,b){var c;c=ki(a,b,0);if(c==-1){return false}wj(a.a,c);return true}
function ii(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.u(c)}}
function Fo(a){var b,c;return b=S(a.b),fj(dj(_n(a.j),new _o(b)),(c=new pi,c))}
function rn(a,b){a.f=b;Nh(b,S(a.a))&&Cn(a,b);vn(b);A((J(),J(),I),new In(a),vp)}
function Qj(a,b,c){!Nh(c,'key')&&!Nh(c,'ref')&&(a[c]=b[c],undefined)}
function ki(a,b,c){for(;c<a.a.length;++c){if(ui(b,a.a[c])){return c}}return -1}
function _m(a,b){Kj(a.a,Ph(b?Hh(b.c.e):null));Wi(b);a.a.props['a']=b;return a.a}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||mb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new lb(a)),0,null);!!a.b&&mb(a.b)}}
function ic(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new mc(a)),67108864,null)}}
function el(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new tl(a),vp)}}
function tb(b){if(b){try{b.t()}catch(a){a=Qg(a);if(fd(a,5)){J()}else throw Rg(a)}}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function Jc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Nc(b,c)}while(a.a);a.a=c}}
function Kc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Nc(b,c)}while(a.b);a.b=c}}
function Vh(a,b,c){return jd(b)?b==null?zi(a.a,null,c):Ni(a.b,b,c):zi(a.a,b,c)}
function xj(a,b){return Uc(b)!=10&&Zc(q(b),b.gb,b.__elementTypeId$,Uc(b),a),a}
function Uc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Oj(a){var b;return Mj($wnd.React.StrictMode,null,null,(b={},b[rp]=Wi(a),b))}
function bb(){var a;this.a=Vc(pd,dp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Yg(){Zg();var a=Xg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function gh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Dh(a,b){var c;if(!a){return}b.j=a;var d=Ah(b);if(!d){ah[a]=[b];return}d.fb=b}
function Qg(a){var b;if(fd(a,5)){return a}b=a&&a[mp];if(!b){b=new tc(a);Qc(b)}return b}
function wh(a){var b;b=new vh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Lj(a){var b;b=Nj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function si(a){var b,c,d;d=0;for(c=new bi(a.a);c.b;){b=ai(c);d=d+(b?r(b):0);d=d|0}return d}
function qb(a){var b,c;for(c=new ri(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;hi((!a.b&&(a.b=new pi),a.b),b)}}}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new pi);a.c=c.c}b.d=true;hi(a.c,Wi(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Wi(b))}
function Oi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Di(a.a,b);--a.b}return c}
function Rh(a,b){var c,d;for(d=new bi(b.a);d.b;){c=ai(d);if(!Zh(a,c)){return false}}return true}
function Tg(a){var b;b=a.h;if(b==0){return a.l+a.m*jp}if(b==1048575){return a.l+a.m*jp-op}return a}
function _h(a){if(a.a.R()){return true}if(a.a!=a.c){return false}a.a=new Ci(a.d.a);return a.a.R()}
function Fh(){qc.call(this,"Stream already terminated, can't be modified or used")}
function xb(a,b,c){wb.call(this,null,a,b,c|(!a?262144:fp)|(0==(c&6291456)?!a?ip:jp:0)|0|0|0)}
function Mb(a,b){this.b=Wi(a);this.a=b|0|(0==(b&6291456)?jp:0)|(0!=(b&229376)?0:98304)}
function hn(){this.a=mh((oo(),oo(),no));this.b=mh(new Ao(this.a));this.c=mh(new Po(this.a))}
function Uo(){Uo=fh;Ro=new Vo('ACTIVE',0);To=new Vo('COMPLETED',1);So=new Vo('ALL',2)}
function Xn(a,b,c){var d;d=new Un(b,c);_b(d.c.c,a,new hc(a,d));Vh(a.g,Hh(d.c.e),d);hb(a.d);return d}
function Mj(a,b,c,d){var e;e=Nj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Wi(d);return e}
function Zc(a,b,c,d,e){e.fb=a;e.gb=b;e.hb=jh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ni(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function dc(a,b,c){var d;d=Wh(a.g,b?Hh(b.c.e):null);if(null!=d){bc(b.c.c,a);c&&!!b&&ic(b.c);hb(a.d)}}
function Ho(a){var b;b=S(a.i.a);Nh(Bp,b)||Nh(xp,b)||Nh('',b)?yn(a.i,b):Bo(zn(a.i))?Bn(a.i):yn(a.i,'')}
function Vg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=op;d=1048575}c=ld(e/jp);b=ld(e-c*jp);return $c(b,c,d)}
function wi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(ui(a,c.U())){return c}}return null}
function Hh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Jh(),Ih)[b];!c&&(c=Ih[b]=new Gh(a));return c}return new Gh(a)}
function S(a){ib(a.e);vb(a.f)&&ob(a.f);if(a.b){if(fd(a.b,9)){throw Rg(a.b)}else{throw Rg(a.b)}}return a.k}
function tc(a){sc();nc(this);this.b=a;a!=null&&yj(a,mp,this);this.c=a==null?'null':ih(a);this.a=a}
function vh(){this.g=sh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Ek(){if(!Dk){Dk=(++(J(),J(),I).e,new Hb);$wnd.Promise.resolve(null).then(gh(Fk.prototype.C,Fk,[]))}}
function mb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Bb(a)),67108864,null);!!a.a&&R(a.a);Ib(a.f);a.c=a.c&-8|1}}
function zl(a,b,c){27==c.which?A((J(),J(),I),new $l(a,b),vp):13==c.which&&A((J(),J(),I),new Yl(a,b),vp)}
function _g(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function _c(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return $c(c&4194303,d&4194303,e&1048575)}
function fb(a,b){var c,d;d=a.c;mi(d,b);!!a.b&&fp!=(a.b.c&gp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function ac(a){var b,c;if(!a.a){for(c=new ri(new qi(new di(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.t()}a.a=true}}
function Dl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Pl(a,a.n.props['a']);a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&fp)?Lb(a):a.b.t();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function q(a){return jd(a)?de:hd(a)?Vd:gd(a)?Td:ed(a)?a.fb:Xc(a)?a.fb:a.fb||Array.isArray(a)&&Tc(Md,1)||Md}
function r(a){return jd(a)?Gj(a):hd(a)?ld(a):gd(a)?a?1231:1237:ed(a)?a.q():Xc(a)?Aj(a):!!a&&!!a.hashCode?a.hashCode():Aj(a)}
function p(a,b){return jd(a)?Nh(a,b):hd(a)?a===b:gd(a)?a===b:ed(a)?a.o(b):Xc(a)?a===b:!!a&&!!a.equals?a.equals(b):kd(a)===kd(b)}
function yb(a,b){wb.call(this,a,new zb(a),null,b|(fp==(b&gp)?0:524288)|(0==(b&6291456)?fp==(b&gp)?jp:ip:0)|0|268435456|0)}
function Ck(){Ak();return Zc(Tc(Pe,1),dp,7,0,[ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk])}
function ih(a){var b;if(Array.isArray(a)&&a.hb===jh){return uh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Gj(a){Ej();var b,c,d;c=':'+a;d=Dj[c];if(d!=null){return ld(d)}d=Bj[c];b=d==null?Fj(a):ld(d);Hj();Dj[c]=b;return b}
function ti(a){var b,c,d;d=1;for(c=new ri(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Sj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function oi(a,b){var c,d;d=a.a.length;b.length<d&&(b=xj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Ch(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Sg(a,b){var c;if(hd(a)&&hd(b)){c=a+b;if(-17592186044416<c&&c<op){return c}}return Tg(_c(hd(a)?Vg(a):a,hd(b)?Vg(b):b))}
function Cl(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){A((J(),J(),I),new yo(b,c),vp);Io(a.k,null);Ql(a,c)}else{$n(a.j,b)}}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=li(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Wb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ri(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&ub(b,6,true)}}}
function Ac(){var a;if(vc!=0){a=uc();if(a-wc>2000){wc=a;xc=$wnd.setTimeout(Gc,10)}}if(vc++==0){Jc((Ic(),Hc));return true}return false}
function Rc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function lc(a,b,c,d,e){var f;this.e=a;this.c=d?new cc:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new kb((J(),null)),f):null;this.d=null}
function U(a,b,c,d){this.c=Wi(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new yb(this,d);this.e=new kb(this.f);fp==(d&gp)&&nb(this.f)}
function Un(a,b){var c,d,e;this.e=Wi(a);this.d=b;J();c=++Ln;this.c=new lc(c,null,new Vn(this),true,true);this.b=(e=new kb(null),e);this.a=(d=new kb(null),d)}
function ol(a,b){var c,d;this.e=Wi(b);this.n=Wi(a);J();c=++il;this.c=new lc(c,null,new pl(this),false,false);this.b=(d=new kb(null),d);this.a=new xb(null,Wi(new vl(this)),up)}
function Zk(a,b){var c;this.d=Wi(b);this.n=Wi(a);J();c=++Xk;this.b=new lc(c,null,new $k(this),false,false);this.a=new xb(null,Wi(new bl(this)),up)}
function im(a,b,c,d){var e;this.d=Wi(b);this.e=Wi(c);this.f=Wi(d);this.n=Wi(a);J();e=++gm;this.b=new lc(e,null,new jm(this),false,false);this.a=new xb(null,Wi(new mm(this)),up)}
function dd(a,b){if(jd(a)){return !!cd[b]}else if(a.gb){return !!a.gb[b]}else if(hd(a)){return !!bd[b]}else if(gd(a)){return !!ad[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Oh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Wc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{Zb(b,d);try{f=(c.a.t(),null)}finally{$b()}return f}catch(a){a=Qg(a);if(fd(a,5)){e=a;throw Rg(e)}else throw Rg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.r()}else{Zb(b,e);try{g=c.r()}finally{$b()}}return g}catch(a){a=Qg(a);if(fd(a,5)){f=a;throw Rg(f)}else throw Rg(a)}finally{D(b)}}
function Db(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Jb(c);return true}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function $g(b,c,d,e){Zg();var f=Xg;$moduleName=c;$moduleBase=d;Pg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ap(g)()}catch(a){b(c,a)}}else{ap(g)()}}
function Nj(a,b){var c;c=new $wnd.Object;c.$$typeof=Wi(a);c.type=Wi(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ii(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ji()}}
function Sh(a,b){var c,d,e,f,g;g=Yh(a.a);b.length<g&&(b=xj(new Array(g),b));e=(f=new bi((new $h(a.a)).a),new ei(f));for(d=0;d<g;++d){b[d]=(c=ai(e.a),c.V())}b.length>g&&(b[g]=null);return b}
function Wk(a){var b,c,d;a.c=0;Ek();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),Pj('span',Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,['todo-count'])),[Pj('strong',null,[c]),' '+d+' left']));return b}
function bh(){ah={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Nc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].ib()&&(c=Mc(c,g)):g[0].ib()}catch(a){a=Qg(a);if(fd(a,5)){d=a;yc();Ec(fd(d,34)?d.A():d)}else throw Rg(a)}}return c}
function hl(a){var b;a.d=0;Ek();b=Pj(wp,Wj($j(_j(ck(ak(Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,['new-todo']))),(ib(a.b),a.f)),gh(Pm.prototype.cb,Pm,[a])),gh(Qm.prototype.bb,Qm,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.r();if(!(kd(e)===kd(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Qg(a);if(fd(a,10)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Rg(c)}else throw Rg(a)}}
function zi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=wi(b,e);if(f){return f.W(c)}}e[e.length]=new fi(b,c);++a.b;return null}
function tj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Fj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Mh(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Vc(be,dp,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function ob(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.t()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Qg(a);if(fd(a,5)){J()}else throw Rg(a)}}}
function kh(){var a;a=new hn;rm(jn(new kn(a)));um(new al((new ln(a)).a.a.B()));cn(nn(new on(a)));gn(pn(new qn(a)));Tm(new rl((new mn(a)).a.b.B()));$wnd.ReactDOM.render(Oj([(new en).a]),(oh(),nh).getElementById('app'),null)}
function vn(a){var b;if(0==a.length){b=(oh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',nh.title,b)}else{(oh(),$wnd.window.window).location.hash=a}}
function Nk(a,b,c,d){var e;this.e=Wi(b);this.f=Wi(c);this.g=Wi(d);this.n=Wi(a);J();e=++Jk;this.c=new lc(e,null,new Ok(this),false,false);this.a=new U(new Rk(this),null,null,136478720);this.b=new xb(null,Wi(new Sk(this)),up)}
function Rl(a,b,c,d){var e,f;this.j=Wi(b);Wi(c);this.k=Wi(d);this.n=Wi(a);J();e=++Hl;this.d=new lc(e,null,new Sl(this),false,false);this.a=(f=new kb(null),f);this.c=new U(new Xl(this),null,null,136478720);this.b=new xb(null,Wi(new am(this)),up);Pl(this,this.n.props['a'])}
function wb(a,b,c,d){this.b=new pi;this.f=new Mb(new Ab(this),d&6520832|262144|fp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&ip)&&D((null,I)))}
function Ai(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(ui(b,e.U())){if(d.length==1){d.length=0;Di(a.a,g)}else{d.splice(h,1)}--a.b;return e.V()}}return null}
function eh(a,b,c){var d=ah,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=ah[b]),hh(h));_.gb=c;!b&&(_.hb=jh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.fb=f)}
function Bh(a){if(a.I()){var b=a.c;b.J()?(a.k='['+b.j):!b.I()?(a.k='[L'+b.G()+';'):(a.k='['+b.G());a.b=b.F()+'[]';a.i=b.H()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Ch('.',[c,Ch('$',d)]);a.b=Ch('.',[c,Ch('.',d)]);a.i=d[d.length-1]}
function Th(a,b){var c,d,e;c=b.U();e=b.V();d=jd(c)?c==null?Uh(yi(a.a,null)):Mi(a.b,c):Uh(yi(a.a,c));if(!(kd(e)===kd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(jd(c)?c==null?!!yi(a.a,null):Li(a.b,c):!!yi(a.a,c))){return false}return true}
function Pj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Jj(b,gh(Rj.prototype._,Rj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[rp]=c[0],undefined):(d[rp]=c,undefined));return Mj(a,e,f,d)}
function Dn(){var a,b;this.d=new Qo(this);this.f=this.e=(b=(oh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new lc(0,null,new En(this),false,false);this.b=(a=new kb(null),a);this.a=new U(new Jn,new Fn(this),new Gn(this),35749888)}
function eo(){var a;this.g=new vi;J();this.f=new lc(0,new go(this),new fo(this),false,false);this.d=(a=new kb(null),a);this.c=new U(new jo(this),null,null,Ap);this.e=new U(new ko(this),null,null,Ap);this.a=new U(new lo(this),null,null,Ap);this.b=new U(new mo(this),null,null,Ap)}
function Jo(a){var b;this.j=Wi(a);this.i=new Dn;J();this.g=new lc(0,null,new Ko(this),false,false);this.d=(b=new kb(null),b);this.b=new U(new Lo(this),null,null,Ap);this.c=new U(new Mo(this),null,null,Ap);this.e=u(new No(this),413138944);this.a=u(new Oo(this),681574400);D((null,I))}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ri(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Qg(a);if(!fd(a,5))throw Rg(a)}if(6==(b.c&7)){return true}}}}}qb(b);return false}
function Hi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ub(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){jb(a.a.e);tb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;tb((e=d.i,e));d.k=null}ii(a.b,new Cb(a));a.b.a=Vc(be,dp,1,0,5,1)}else 3==g&&!!a.a&&tb((f=a.a.g,f))}}
function Ak(){Ak=fh;ek=new Bk(sp,0);fk=new Bk('checkbox',1);gk=new Bk('color',2);hk=new Bk('date',3);ik=new Bk('datetime',4);jk=new Bk('email',5);kk=new Bk('file',6);lk=new Bk('hidden',7);mk=new Bk('image',8);nk=new Bk('month',9);ok=new Bk(bp,10);pk=new Bk('password',11);qk=new Bk('radio',12);rk=new Bk('range',13);sk=new Bk('reset',14);tk=new Bk('search',15);uk=new Bk('submit',16);vk=new Bk('tel',17);wk=new Bk('text',18);xk=new Bk('time',19);yk=new Bk('url',20);zk=new Bk('week',21)}
function fm(a){var b,c,d;a.c=0;Ek();d=Pj('div',null,[Pj('div',null,[Pj(yp,Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,[yp])),[Pj('h1',null,['todos']),(new Rm).a]),S(a.d.c)?null:Pj('section',Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,[yp])),[Pj(wp,$j(bk(Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,['toggle-all'])),(Ak(),fk)),gh(dn.prototype.bb,dn,[a])),null),Pj('ul',Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,['todo-list'])),(b=fj(Wi(ej(S(a.f.c).P())),(c=new pi,c)),oi(b,Yc(b.a.length))))]),S(a.d.c)?null:(new pm).a])]);return d}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ji(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ni(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ji(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){li(a.b,g)}e&&sb(a.e,a.b)}else{e&&sb(a.e,new pi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&fp!=(k.b.c&gp)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function Ik(a){var b,c;a.d=0;Ek();c=(b=S(a.g.b),Pj('footer',Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,['footer'])),[(new sm).a,Pj('ul',Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,['filters'])),[Pj('li',null,[Pj('a',Uj(Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,[(Uo(),So)==b?tp:null])),'#'),['All'])]),Pj('li',null,[Pj('a',Uj(Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,[Ro==b?tp:null])),'#active'),['Active'])]),Pj('li',null,[Pj('a',Uj(Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,[To==b?tp:null])),'#completed'),['Completed'])])]),S(a.a)?Pj(sp,Vj(Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,['clear-completed'])),gh(om.prototype.db,om,[a])),['Clear Completed']):null]));return c}
function Gl(a){var b,c,d,e;a.e=0;Ek();b=a.n.props['a'];if(b.c.i<0){return null}c=(d=a.n.props['a'],e=(ib(d.a),d.d),Pj('li',Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,[e?xp:null,S(a.c)?'editing':null])),[Pj('div',Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,['view'])),[Pj(wp,$j(Xj(bk(Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,['toggle'])),(Ak(),fk)),e),gh(Vm.prototype.bb,Vm,[d])),null),Pj('label',dk(new $wnd.Object,gh(Wm.prototype.db,Wm,[a,d])),[(ib(d.b),d.e)]),Pj(sp,Vj(Sj(new $wnd.Object,Zc(Tc(de,1),dp,2,6,['destroy'])),gh(Xm.prototype.db,Xm,[a,d])),null)]),Pj(wp,_j($j(Zj(Yj(Sj(Tj(new $wnd.Object,gh(Ym.prototype.u,Ym,[a])),Zc(Tc(de,1),dp,2,6,['edit'])),(ib(a.a),a.g)),gh(Zm.prototype.ab,Zm,[a,d])),gh(Um.prototype.bb,Um,[a])),gh($m.prototype.cb,$m,[a,d])),null)]));return c}
function Ji(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[qp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Hi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[qp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var bp='number',cp={13:1},dp={3:1,4:1},ep={8:1},fp=1048576,gp=1835008,hp={6:1},ip=2097152,jp=4194304,kp={21:1},lp='__noinit__',mp='__java$exception',np={3:1,10:1,9:1,5:1},op=17592186044416,pp={39:1},qp='delete',rp='children',sp='button',tp='selected',up=1411518464,vp=142606336,wp='input',xp='completed',yp='header',zp='hashchange',Ap=136413184,Bp='active';var _,ah,Xg,Pg=-1;bh();eh(1,null,{},o);_.o=Cp;_.p=function(){return this.fb};_.q=Dp;_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};var ad,bd,cd;eh(52,1,{},vh);_.D=function(a){var b;b=new vh;b.e=4;a>1?(b.c=zh(this,a-1)):(b.c=this);return b};_.F=function(){th(this);return this.b};_.G=function(){return uh(this)};_.H=function(){th(this);return this.i};_.I=function(){return (this.e&4)!=0};_.J=function(){return (this.e&1)!=0};_.e=0;_.g=0;var sh=1;var be=xh(1);var Ud=xh(52);eh(79,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var od=xh(79);eh(35,1,cp,G);_.r=function(){return this.a.t(),null};var md=xh(35);eh(80,1,{},H);var nd=xh(80);var I;eh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var pd=xh(43);eh(229,1,ep);var sd=xh(229);eh(18,229,ep,U);_.s=function(){R(this)};_.a=false;_.d=0;var qd=xh(18);eh(140,1,{265:1},bb);var rd=xh(140);eh(16,229,{8:1,16:1},kb);_.s=function(){cb(this)};_.a=4;_.d=false;_.e=0;var ud=xh(16);eh(175,1,hp,lb);_.t=function(){db(this.a)};var td=xh(175);eh(17,229,{8:1,17:1},xb,yb);_.s=function(){mb(this)};_.c=0;var zd=xh(17);eh(176,1,kp,zb);_.t=function(){Q(this.a)};var vd=xh(176);eh(177,1,hp,Ab);_.t=function(){ob(this.a)};var wd=xh(177);eh(178,1,hp,Bb);_.t=function(){rb(this.a)};var xd=xh(178);eh(179,1,{},Cb);_.u=function(a){pb(this.a,a)};var yd=xh(179);eh(141,1,{},Fb);_.a=0;_.b=0;_.c=0;var Ad=xh(141);eh(180,1,ep,Hb);_.s=function(){Gb(this)};_.a=false;var Bd=xh(180);eh(63,229,{8:1,63:1},Mb);_.s=function(){Ib(this)};_.a=0;var Cd=xh(63);eh(185,1,{},Yb);_.a=0;var Nb;var Dd=xh(185);eh(183,1,ep,cc);_.s=function(){ac(this)};_.a=false;var Ed=xh(183);eh(153,1,{});var Hd=xh(153);eh(146,1,{},gc);_.u=function(a){ec(this.a,a)};var Fd=xh(146);eh(147,1,hp,hc);_.t=function(){fc(this.a,this.b)};var Gd=xh(147);eh(154,153,{});var Id=xh(154);eh(15,1,ep,lc);_.s=function(){ic(this)};_.e=0;_.i=0;var Kd=xh(15);eh(174,1,hp,mc);_.t=function(){kc(this.a)};var Jd=xh(174);eh(5,1,{3:1,5:1});_.v=function(a){return new Error(a)};_.w=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=uh(this.fb),c==null?a:a+': '+c);oc(this,pc(this.v(b)));Qc(this)};_.b=lp;_.d=true;var ee=xh(5);eh(10,5,{3:1,10:1,5:1});var Xd=xh(10);eh(9,10,np);var ce=xh(9);eh(53,9,np);var $d=xh(53);eh(74,53,np);var Od=xh(74);eh(34,74,{34:1,3:1,10:1,9:1,5:1},tc);_.A=function(){return kd(this.a)===kd(rc)?null:this.a};var rc;var Ld=xh(34);var Md=xh(0);eh(211,1,{});var Nd=xh(211);var vc=0,wc=0,xc=-1;eh(88,211,{},Lc);var Hc;var Pd=xh(88);var Oc;eh(222,1,{});var Rd=xh(222);eh(75,222,{},Sc);var Qd=xh(75);eh(44,1,{44:1,67:1},lh);_.B=function(){if(this===this.a){this.a=this.b.B();this.b=null}return this.a};var Sd=xh(44);var nh;ad={3:1,70:1,29:1};var Td=xh(70);eh(40,1,{3:1,40:1});var ae=xh(40);bd={3:1,29:1,40:1};var Vd=xh(221);eh(31,1,{3:1,29:1,31:1});_.o=Cp;_.q=Dp;_.b=0;var Wd=xh(31);eh(76,9,np,Fh);var Yd=xh(76);eh(30,40,{3:1,29:1,30:1,40:1},Gh);_.o=function(a){return fd(a,30)&&a.a==this.a};_.q=Gp;_.a=0;var Zd=xh(30);var Ih;eh(283,1,{});eh(77,53,np,Lh);_.v=function(a){return new TypeError(a)};var _d=xh(77);cd={3:1,69:1,29:1,2:1};var de=xh(2);eh(287,1,{});eh(55,9,np,Qh);var fe=xh(55);eh(223,1,{38:1});_.K=Ip;_.O=function(){return new $i(this,0)};_.P=function(){return new gj(null,this.O())};_.M=function(a){throw Rg(new Qh('Add not supported on this collection'))};var ge=xh(223);eh(227,1,{210:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!fd(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new bi((new $h(d)).a);c.b;){b=ai(c);if(!Th(this,b)){return false}}return true};_.q=function(){return si(new $h(this))};var re=xh(227);eh(139,227,{210:1});var je=xh(139);eh(226,223,{38:1,234:1});_.O=function(){return new $i(this,1)};_.o=function(a){var b;if(a===this){return true}if(!fd(a,23)){return false}b=a;if(Yh(b.a)!=this.N()){return false}return Rh(this,b)};_.q=function(){return si(this)};var se=xh(226);eh(23,226,{23:1,38:1,234:1},$h);_.L=function(){return new bi(this.a)};_.N=Fp;var ie=xh(23);eh(24,1,{},bi);_.Q=Ep;_.S=function(){return ai(this)};_.R=Hp;_.b=false;var he=xh(24);eh(224,223,{38:1,231:1});_.O=function(){return new $i(this,16)};_.T=function(a,b){throw Rg(new Qh('Add not supported on this list'))};_.M=function(a){this.T(this.N(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!fd(a,12)){return false}f=a;if(this.N()!=f.a.length){return false}e=new ri(f);for(c=new ri(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(kd(b)===kd(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return ti(this)};_.L=function(){return new ci(this)};var le=xh(224);eh(87,1,{},ci);_.Q=Ep;_.R=function(){return this.a<this.b.a.length};_.S=function(){return ji(this.b,this.a++)};_.a=0;var ke=xh(87);eh(42,223,{38:1},di);_.L=function(){var a;return a=new bi((new $h(this.a)).a),new ei(a)};_.N=Fp;var ne=xh(42);eh(57,1,{},ei);_.Q=Ep;_.R=function(){return this.a.b};_.S=function(){var a;return a=ai(this.a),a.V()};var me=xh(57);eh(137,1,pp);_.o=function(a){var b;if(!fd(a,39)){return false}b=a;return ui(this.a,b.U())&&ui(this.b,b.V())};_.U=Gp;_.V=Hp;_.q=function(){return Vi(this.a)^Vi(this.b)};_.W=function(a){var b;b=this.b;this.b=a;return b};var oe=xh(137);eh(138,137,pp,fi);var pe=xh(138);eh(228,1,pp);_.o=function(a){var b;if(!fd(a,39)){return false}b=a;return ui(this.b.value[0],b.U())&&ui(Ri(this),b.V())};_.q=function(){return Vi(this.b.value[0])^Vi(Ri(this))};var qe=xh(228);eh(12,224,{3:1,12:1,38:1,231:1},pi,qi);_.T=function(a,b){uj(this.a,a,b)};_.M=function(a){return hi(this,a)};_.K=function(a){ii(this,a)};_.L=function(){return new ri(this)};_.N=function(){return this.a.length};var ue=xh(12);eh(14,1,{},ri);_.Q=Ep;_.R=function(){return this.a<this.c.a.length};_.S=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var te=xh(14);eh(36,139,{3:1,36:1,210:1},vi);var ve=xh(36);eh(60,1,{},Bi);_.K=Ip;_.L=function(){return new Ci(this)};_.b=0;var xe=xh(60);eh(61,1,{},Ci);_.Q=Ep;_.S=function(){return this.d=this.a[this.c++],this.d};_.R=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var we=xh(61);var Fi;eh(58,1,{},Pi);_.K=Ip;_.L=function(){return new Qi(this)};_.b=0;_.c=0;var Ae=xh(58);eh(59,1,{},Qi);_.Q=Ep;_.S=function(){return this.c=this.a,this.a=this.b.next(),new Si(this.d,this.c,this.d.c)};_.R=function(){return !this.a.done};var ye=xh(59);eh(145,228,pp,Si);_.U=function(){return this.b.value[0]};_.V=function(){return Ri(this)};_.W=function(a){return Ni(this.a,this.b.value[0],a)};_.c=0;var ze=xh(145);eh(195,1,{});_.Q=function(a){Xi(this,a)};_.X=function(){return this.d};_.Y=function(){return this.e};_.d=0;_.e=0;var Ce=xh(195);eh(64,195,{});var Be=xh(64);eh(22,1,{},$i);_.X=Gp;_.Y=function(){Zi(this);return this.c};_.Q=function(a){Zi(this);this.d.Q(a)};_.Z=function(a){Zi(this);if(this.d.R()){a.u(this.d.S());return true}return false};_.a=0;_.c=0;var De=xh(22);eh(194,1,{});_.c=false;var Me=xh(194);eh(26,194,{268:1,26:1},gj);var Le=xh(26);eh(197,64,{},kj);_.Z=function(a){this.b=false;while(!this.b&&this.c.Z(new lj(this,a)));return this.b};_.b=false;var Fe=xh(197);eh(200,1,{},lj);_.u=function(a){jj(this.a,this.b,a)};var Ee=xh(200);eh(196,64,{},mj);_.Z=function(a){return this.a.Z(new nj(a))};var He=xh(196);eh(199,1,{},nj);_.u=function(a){this.a.u(_m(new an,a))};var Ge=xh(199);eh(198,1,{},pj);_.u=function(a){oj(this,a)};var Ie=xh(198);eh(201,1,{},qj);_.u=function(a){};var Je=xh(201);eh(202,1,{},sj);_.u=function(a){rj(this,a)};var Ke=xh(202);eh(285,1,{});eh(230,1,{});var Ne=xh(230);eh(282,1,{});var zj=0;var Bj,Cj=0,Dj;eh(726,1,{});eh(756,1,{});eh(225,1,{});var Oe=xh(225);eh(267,$wnd.Function,{},Rj);_._=function(a){Qj(this.a,this.b,a)};eh(7,31,{3:1,29:1,31:1,7:1},Bk);var ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk;var Pe=yh(7,Ck);var Dk;eh(266,$wnd.Function,{},Fk);_.C=function(a){return Gb(Dk),Dk=null,null};eh(89,225,{});var Bf=xh(89);eh(90,89,{});_.d=0;var Ff=xh(90);eh(91,90,ep,Nk);_.s=Jp;_.o=Cp;_.q=Dp;var Jk=0;var $e=xh(91);eh(93,1,hp,Ok);_.t=function(){Kk(this.a)};var Qe=xh(93);eh(92,1,{},Qk);var Re=xh(92);eh(94,1,cp,Rk);_.r=function(){return Lk(this.a)};var Se=xh(94);eh(95,1,kp,Sk);_.t=function(){Hk(this.a)};var Te=xh(95);eh(96,1,cp,Tk);_.r=function(){return Ik(this.a)};var Ue=xh(96);eh(98,225,{});var Af=xh(98);eh(99,98,{});_.c=0;var Ef=xh(99);eh(100,99,ep,Zk);_.s=Kp;_.o=Cp;_.q=Dp;var Xk=0;var Ze=xh(100);eh(102,1,hp,$k);_.t=Lp;var Ve=xh(102);eh(101,1,{},al);var We=xh(101);eh(103,1,kp,bl);_.t=function(){Vk(this.a)};var Xe=xh(103);eh(104,1,cp,cl);_.r=function(){return Wk(this.a)};var Ye=xh(104);eh(127,225,{});_.f='';var Nf=xh(127);eh(128,127,{});_.d=0;var Hf=xh(128);eh(129,128,ep,ol);_.s=Jp;_.o=Cp;_.q=Dp;var il=0;var ff=xh(129);eh(131,1,hp,pl);_.t=function(){jl(this.a)};var _e=xh(131);eh(130,1,{},rl);var af=xh(130);eh(133,1,cp,sl);_.r=function(){return hl(this.a)};var bf=xh(133);eh(134,1,hp,tl);_.t=function(){dl(this.a)};var cf=xh(134);eh(135,1,hp,ul);_.t=function(){ll(this.a,this.b)};var df=xh(135);eh(132,1,kp,vl);_.t=function(){Hk(this.a)};var ef=xh(132);eh(106,225,{});_.i=false;var Pf=xh(106);eh(107,106,{});_.e=0;var Jf=xh(107);eh(108,107,ep,Rl);_.s=function(){ic(this.d)};_.o=Cp;_.q=Dp;var Hl=0;var sf=xh(108);eh(110,1,hp,Sl);_.t=function(){Il(this.a)};var gf=xh(110);eh(109,1,{},Ul);var hf=xh(109);eh(113,1,cp,Vl);_.r=function(){return Gl(this.a)};var jf=xh(113);eh(41,1,hp,Wl);_.t=function(){Ql(this.a,zn(this.b))};var kf=xh(41);eh(111,1,cp,Xl);_.r=function(){return Kl(this.a)};var lf=xh(111);eh(56,1,hp,Yl);_.t=function(){Cl(this.a,this.b)};var mf=xh(56);eh(114,1,hp,Zl);_.t=function(){Bl(this.a,this.b)};var nf=xh(114);eh(115,1,hp,$l);_.t=function(){Al(this.a,this.b)};var of=xh(115);eh(116,1,hp,_l);_.t=function(){wl(this.a,this.b)};var pf=xh(116);eh(112,1,kp,am);_.t=function(){Fl(this.a)};var qf=xh(112);eh(117,1,hp,bm);_.t=function(){Dl(this.a)};var rf=xh(117);eh(119,225,{});var Rf=xh(119);eh(120,119,{});_.c=0;var Lf=xh(120);eh(121,120,ep,im);_.s=Kp;_.o=Cp;_.q=Dp;var gm=0;var xf=xh(121);eh(123,1,hp,jm);_.t=Lp;var tf=xh(123);eh(122,1,{},lm);var uf=xh(122);eh(124,1,kp,mm);_.t=function(){Vk(this.a)};var vf=xh(124);eh(125,1,cp,nm);_.r=function(){return fm(this.a)};var wf=xh(125);eh(248,$wnd.Function,{},om);_.db=function(a){so(this.a.f)};eh(182,1,{},pm);var yf=xh(182);var qm;eh(205,1,{},sm);var zf=xh(205);var tm;eh(249,$wnd.Function,{},vm);_.eb=function(a){return new ym(a)};var wm;eh(97,$wnd.React.Component,{},ym);dh(ah[1],_);_.componentWillUnmount=function(){Gk(this.a)};_.render=function(){return Mk(this.a)};_.shouldComponentUpdate=Mp;var Cf=xh(97);eh(250,$wnd.Function,{},zm);_.eb=function(a){return new Cm(a)};var Am;eh(105,$wnd.React.Component,{},Cm);dh(ah[1],_);_.componentWillUnmount=function(){Uk(this.a)};_.render=function(){return Yk(this.a)};_.shouldComponentUpdate=Np;var Df=xh(105);eh(264,$wnd.Function,{},Dm);_.eb=function(a){return new Gm(a)};var Em;eh(136,$wnd.React.Component,{},Gm);dh(ah[1],_);_.componentWillUnmount=function(){Gk(this.a)};_.render=function(){return ml(this.a)};_.shouldComponentUpdate=Mp;var Gf=xh(136);eh(251,$wnd.Function,{},Hm);_.eb=function(a){return new Km(a)};var Im;eh(118,$wnd.React.Component,{},Km);dh(ah[1],_);_.componentDidUpdate=function(a){Nl(this.a)};_.componentWillUnmount=function(){El(this.a)};_.render=function(){return Ol(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.e};var If=xh(118);eh(261,$wnd.Function,{},Lm);_.eb=function(a){return new Om(a)};var Mm;eh(126,$wnd.React.Component,{},Om);dh(ah[1],_);_.componentWillUnmount=function(){Uk(this.a)};_.render=function(){return hm(this.a)};_.shouldComponentUpdate=Np;var Kf=xh(126);eh(262,$wnd.Function,{},Pm);_.cb=function(a){el(this.a,a)};eh(263,$wnd.Function,{},Qm);_.bb=function(a){kl(this.a,a)};eh(181,1,{},Rm);var Mf=xh(181);var Sm;eh(258,$wnd.Function,{},Um);_.bb=function(a){Jl(this.a,a)};eh(252,$wnd.Function,{},Vm);_.bb=function(a){Tn(this.a)};eh(254,$wnd.Function,{},Wm);_.db=function(a){Ll(this.a,this.b)};eh(255,$wnd.Function,{},Xm);_.db=function(a){xl(this.a,this.b)};eh(256,$wnd.Function,{},Ym);_.u=function(a){yl(this.a,a)};eh(257,$wnd.Function,{},Zm);_.ab=function(a){Ml(this.a,this.b)};eh(259,$wnd.Function,{},$m);_.cb=function(a){zl(this.a,this.b,a)};eh(204,1,{},an);var Of=xh(204);var bn;eh(260,$wnd.Function,{},dn);_.bb=function(a){cm(this.a,a)};eh(68,1,{},en);var Qf=xh(68);var fn;eh(81,1,{},hn);var Xf=xh(81);eh(82,1,{},kn);var Sf=xh(82);eh(86,1,{},ln);var Tf=xh(86);eh(85,1,{},mn);var Uf=xh(85);eh(83,1,{},on);var Vf=xh(83);eh(84,1,{},qn);var Wf=xh(84);eh(186,1,{});var Eg=xh(186);eh(187,186,ep,Dn);_.s=Jp;_.o=Cp;_.q=Dp;var dg=xh(187);eh(188,1,hp,En);_.t=function(){xn(this.a)};var Yf=xh(188);eh(190,1,kp,Fn);_.t=function(){sn(this.a)};var Zf=xh(190);eh(191,1,kp,Gn);_.t=function(){tn(this.a)};var $f=xh(191);eh(193,1,hp,Hn);_.t=function(){An(this.a)};var _f=xh(193);eh(62,1,hp,In);_.t=function(){wn(this.a)};var ag=xh(62);eh(189,1,cp,Jn);_.r=function(){var a;return a=(oh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var bg=xh(189);eh(192,1,hp,Kn);_.t=function(){rn(this.a,this.b)};var cg=xh(192);eh(48,1,{48:1});_.d=false;var Mg=xh(48);eh(49,48,{8:1,269:1,49:1,48:1},Un);_.s=Jp;_.o=function(a){return Nn(this,a)};_.q=function(){return this.c.e};var Ln=0;var vg=xh(49);eh(206,1,hp,Vn);_.t=function(){Mn(this.a)};var eg=xh(206);eh(207,1,hp,Wn);_.t=function(){Qn(this.a)};var fg=xh(207);eh(45,154,{45:1});var Hg=xh(45);eh(155,45,{8:1,45:1},eo);_.s=function(){ic(this.f)};_.o=Cp;_.q=Dp;var pg=xh(155);eh(157,1,hp,fo);_.t=function(){Yn(this.a)};var gg=xh(157);eh(156,1,hp,go);_.t=function(){ao(this.a)};var hg=xh(156);eh(162,1,hp,ho);_.t=function(){dc(this.a,this.b,true)};var ig=xh(162);eh(163,1,cp,io);_.r=function(){return Xn(this.a,this.c,this.b)};_.b=false;var jg=xh(163);eh(158,1,cp,jo);_.r=function(){return bo(this.a)};var kg=xh(158);eh(159,1,cp,ko);_.r=function(){return Hh(Wg(cj(_n(this.a))))};var lg=xh(159);eh(160,1,cp,lo);_.r=function(){return Hh(Wg(cj(dj(_n(this.a),new Xo))))};var mg=xh(160);eh(161,1,cp,mo);_.r=function(){return co(this.a)};var ng=xh(161);eh(142,1,{67:1},po);_.B=function(){return new eo};var no;var og=xh(142);eh(46,1,{46:1});var Lg=xh(46);eh(164,46,{8:1,46:1},wo);_.s=function(){ic(this.a)};_.o=Cp;_.q=Dp;var ug=xh(164);eh(165,1,hp,xo);_.t=function(){to(this.a,this.b)};_.b=false;var qg=xh(165);eh(166,1,hp,yo);_.t=function(){Cn(this.b,this.a)};var rg=xh(166);eh(167,1,hp,zo);_.t=function(){uo(this.a)};var sg=xh(167);eh(143,1,{67:1},Ao);_.B=function(){return new wo(this.a.B())};var tg=xh(143);eh(47,1,{47:1});var Og=xh(47);eh(168,47,{8:1,47:1},Jo);_.s=function(){ic(this.g)};_.o=Cp;_.q=Dp;var Cg=xh(168);eh(169,1,hp,Ko);_.t=function(){Do(this.a)};var wg=xh(169);eh(170,1,cp,Lo);_.r=function(){var a;return a=zn(this.a.i),Nh(Bp,a)||Nh(xp,a)||Nh('',a)?Nh(Bp,a)?(Uo(),Ro):Nh(xp,a)?(Uo(),To):(Uo(),So):(Uo(),So)};var xg=xh(170);eh(171,1,cp,Mo);_.r=function(){return Fo(this.a)};var yg=xh(171);eh(172,1,kp,No);_.t=function(){Go(this.a)};var zg=xh(172);eh(173,1,kp,Oo);_.t=function(){Ho(this.a)};var Ag=xh(173);eh(144,1,{67:1},Po);_.B=function(){return new Jo(this.a.B())};var Bg=xh(144);eh(184,1,{},Qo);_.handleEvent=function(a){un(this.a,a)};var Dg=xh(184);eh(32,31,{3:1,29:1,31:1,32:1},Vo);var Ro,So,To;var Fg=yh(32,Wo);eh(148,1,{},Xo);_.$=function(a){return !Pn(a)};var Gg=xh(148);eh(150,1,{},Yo);_.$=function(a){return Pn(a)};var Ig=xh(150);eh(151,1,{},Zo);_.u=function(a){$n(this.a,a)};var Jg=xh(151);eh(149,1,{},$o);_.u=function(a){ro(this.a,a)};_.a=false;var Kg=xh(149);eh(152,1,{},_o);_.$=function(a){return Co(this.a,a)};var Ng=xh(152);var ap=(yc(),Bc);var gwtOnLoad=gwtOnLoad=$g;Yg(kh);_g('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();