function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='F0208296CD4E006D0796CF6C0D01F829',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'F0208296CD4E006D0796CF6C0D01F829';function o(){}
function vh(){}
function rh(){}
function rk(){}
function Bb(){}
function Qc(){}
function Xc(){}
function Xm(){}
function Vm(){}
function Zm(){}
function _m(){}
function _o(){}
function io(){}
function to(){}
function No(){}
function Oj(){}
function Pj(){}
function bn(){}
function ap(){}
function Sp(){}
function Vc(a){Uc()}
function Hh(){Hh=rh}
function H(a){this.a=a}
function G(a){this.a=a}
function fb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function ub(a){this.a=a}
function cc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function gc(a){this.a=a}
function kc(a){this.a=a}
function Yh(a){this.a=a}
function ii(a){this.a=a}
function ui(a){this.a=a}
function zi(a){this.a=a}
function Ai(a){this.a=a}
function yi(a){this.b=a}
function Ni(a){this.c=a}
function Mj(a){this.a=a}
function Rj(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function yl(a){this.a=a}
function Nl(a){this.a=a}
function Ol(a){this.a=a}
function Ql(a){this.a=a}
function Rl(a){this.a=a}
function Tl(a){this.a=a}
function nm(a){this.a=a}
function om(a){this.a=a}
function pm(a){this.a=a}
function um(a){this.a=a}
function vm(a){this.a=a}
function Fm(a){this.a=a}
function Gm(a){this.a=a}
function Hm(a){this.a=a}
function Km(a){this.a=a}
function Nm(a){this.a=a}
function Mm(){this.a={}}
function Pm(){this.a={}}
function Qm(a){this.a=a}
function dn(a){this.a=a}
function en(a){this.a=a}
function hn(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function on(a){this.a=a}
function gn(){this.a={}}
function un(){this.a={}}
function vn(a){this.a=a}
function yn(a){this.a=a}
function Bn(a){this.a=a}
function Qn(a){this.a=a}
function Rn(a){this.a=a}
function $n(a){this.a=a}
function ao(a){this.a=a}
function co(a){this.a=a}
function eo(a){this.a=a}
function fo(a){this.a=a}
function so(a){this.a=a}
function vo(a){this.a=a}
function Fo(a){this.a=a}
function Go(a){this.a=a}
function Ho(a){this.a=a}
function Io(a){this.a=a}
function Jo(a){this.a=a}
function $o(a){this.a=a}
function bp(a){this.a=a}
function cp(a){this.a=a}
function dp(a){this.a=a}
function ep(a){this.a=a}
function fp(a){this.a=a}
function An(){this.a={}}
function Li(){Ci(this)}
function gl(a){fl();el=a}
function rl(a){ql();pl=a}
function Gl(a){Fl();El=a}
function em(a){cm();bm=a}
function Cm(a){Bm();Am=a}
function Rm(a,b){a.d=b}
function Sm(a,b){a.e=b}
function Tm(a,b){a.f=b}
function Um(a,b){a.g=b}
function Nj(a,b){a.a=b}
function wn(a,b){a.k=b}
function xn(a,b){a.n=b}
function ko(a,b){Mn(b,a)}
function C(a,b){yb(a.b,b)}
function $(a){Kb((J(),a))}
function Op(a){nj(this,a)}
function Rp(a){ai(this,a)}
function Xp(){mk(this.a)}
function aq(){ok(this.a)}
function Xi(){this.a=ej()}
function jj(){this.a=ej()}
function F(){this.b=new zb}
function J(){J=rh;I=new F}
function bh(a){return a.e}
function w(a){--a.e;D(a)}
function ab(a){Lb((J(),a))}
function db(a){Mb((J(),a))}
function mb(a,b){a.b=qj(b)}
function oc(a,b){qi(a.b,b)}
function jo(a,b){Tn(a.b,b)}
function Xl(a,b){Un(a.k,b)}
function Qj(a,b){Gj(a.a,b)}
function fk(a,b,c){a[b]=c}
function aj(){aj=rh;_i=cj()}
function wc(){wc=rh;vc=new o}
function Nc(){Nc=rh;Mc=new Qc}
function yh(){yh=rh;xh=new o}
function ho(){ho=rh;go=new io}
function Mo(){Mo=rh;Lo=new No}
function pc(){this.b=new Ri}
function qo(a){this.b=qj(a)}
function Lp(){return this.a}
function Qp(){return this.b}
function Up(){return this.c}
function $p(){return this.e}
function Vp(){return this.d<0}
function _p(){return this.c<0}
function bq(){return this.f<0}
function Np(){return Zj(this)}
function ei(a,b){return a===b}
function Yl(a,b){return a.g=b}
function Fi(a,b){return a.a[b]}
function Vj(a,b){a.splice(b,1)}
function mc(a,b,c){pi(a.b,b,c)}
function sl(a){nc(a.b);gb(a.a)}
function Wh(a){uc.call(this,a)}
function ji(a){uc.call(this,a)}
function Wm(a){jk.call(this,a)}
function Ym(a){jk.call(this,a)}
function $m(a){jk.call(this,a)}
function an(a){jk.call(this,a)}
function cn(a){jk.call(this,a)}
function Pp(){return si(this.a)}
function Yp(){return qk(this.a)}
function Mp(a){return this===a}
function Wp(){return J(),J(),I}
function Yc(a,b){return Qh(a,b)}
function Gj(a,b){Nj(a,Fj(a.a,b))}
function rj(a,b){while(a.fb(b));}
function Fj(a,b){a.U(b);return a}
function Kh(a){Jh(a);return a.k}
function Vb(a){bb(a.a);return a.e}
function Wb(a){bb(a.b);return a.g}
function tk(a,b){a.ref=b;return a}
function In(a){bb(a.b);return a.i}
function Jn(a){bb(a.a);return a.g}
function yo(a){bb(a.d);return a.f}
function ej(){aj();return new _i}
function X(a){J();Lb(a);a.e=-2}
function Yb(a){Ub(a,(bb(a.b),a.g))}
function Eb(a){Fb(a);!a.d&&Ib(a)}
function Dc(){Dc=rh;!!(Uc(),Tc)}
function bi(){qc(this);this.I()}
function Bi(a,b){this.a=a;this.b=b}
function dc(a,b){this.a=a;this.b=b}
function lc(a,b){this.a=a;this.b=b}
function Vh(a,b){this.a=a;this.b=b}
function Jj(a,b){this.a=a;this.b=b}
function Pl(a,b){this.a=a;this.b=b}
function zh(a){this.a=xh;this.b=a}
function rm(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function tm(a,b){this.a=a;this.b=b}
function mn(a,b){this.a=a;this.b=b}
function nn(a,b){this.a=a;this.b=b}
function pn(a,b){this.a=a;this.b=b}
function qn(a,b){this.a=a;this.b=b}
function bl(a,b){Vh.call(this,a,b)}
function _n(a,b){this.a=a;this.b=b}
function ro(a,b){this.b=a;this.a=b}
function uo(a,b){this.a=a;this.b=b}
function Ko(a,b){this.b=a;this.a=b}
function Yo(a,b){Vh.call(this,a,b)}
function Wl(a,b){Do(a.n,b);km(a,b)}
function gj(a,b){return a.a.get(b)}
function si(a){return a.a.b+a.b.b}
function bd(a){return new Array(a)}
function rn(a){return sn(new un,a)}
function nd(a){return typeof a===ip}
function kh(){ih==null&&(ih=[])}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function L(a){a.b=0;a.d=0;a.c=false}
function Ln(a){Mn(a,(bb(a.a),!a.g))}
function Kj(a,b){a.D(tn(rn(b.e),b))}
function Tj(a,b,c){a.splice(b,0,c)}
function Ek(a,b){a.value=b;return a}
function uk(a,b){a.href=b;return a}
function zk(a,b){a.onBlur=b;return a}
function gi(a,b){a.a+=''+b;return a}
function ri(a){a.a=new Xi;a.b=new jj}
function Ci(a){a.a=$c(ke,lp,1,0,5,1)}
function Kc(a){$wnd.clearTimeout(a)}
function Gb(a){return !a.d?a:Gb(a.d)}
function oi(a){return !a?null:a.bb()}
function qd(a){return a==null?null:a}
function pj(a){return a!=null?r(a):0}
function cq(){return Ch(this.a.K())}
function Tp(){return T(this.e.b).a>0}
function eb(a){this.c=new Li;this.b=a}
function bk(){bk=rh;$j=new o;ak=new o}
function xk(a,b){a.checked=b;return a}
function vk(a,b){a.onClick=b;return a}
function Ak(a,b){a.onChange=b;return a}
function Uj(a,b){Sj(b,0,a,0,b.length)}
function $l(a,b){km(a,b);Do(a.n,null)}
function A(a,b,c){t(a,new G(b),c,null)}
function jc(a,b){hc(a,b,false);ab(a.d)}
function il(a){nc(a.c);gb(a.b);S(a.a)}
function Kl(a){nc(a.c);gb(a.a);W(a.b)}
function lb(a){J();kb(a);nb(a,2,true)}
function bb(a){var b;Hb((J(),b=Cb,b),a)}
function V(a){return !(!!a&&1==(a.c&7))}
function Zj(a){return a.$H||(a.$H=++Yj)}
function di(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function pd(a){return typeof a==='string'}
function md(a){return typeof a==='boolean'}
function wk(a){a.autoFocus=true;return a}
function Bk(a,b){a.onKeyDown=b;return a}
function yk(a,b){a.defaultValue=b;return a}
function Jh(a){if(a.k!=null){return}Sh(a)}
function rc(a,b){a.e=b;b!=null&&Xj(b,wp,a)}
function nj(a,b){while(a.Z()){Qj(b,a.$())}}
function uc(a){this.f=a;qc(this);this.I()}
function Ej(a,b){zj.call(this,a);this.a=b}
function Zi(a,b){var c;c=a[Bp];c.call(a,b)}
function u(a,b){return new qb(qj(a),null,b)}
function Yn(a){return Zh(T(a.e).a-T(a.a).a)}
function Kn(a){nc(a.c);W(a.d);W(a.b);W(a.a)}
function ic(a,b){oc(b.F(),a);ld(b,11)&&b.A()}
function Ec(a,b,c){return a.apply(b,c);var d}
function Xj(b,c,d){try{b[c]=d}catch(a){}}
function mj(a,b,c){this.a=a;this.b=b;this.c=c}
function Al(a,b,c){this.a=a;this.b=b;this.c=c}
function xm(a,b,c){this.a=a;this.b=b;this.c=c}
function Jm(a,b,c){this.a=a;this.b=b;this.c=c}
function Ri(){this.a=new Xi;this.b=new jj}
function Q(){this.a=$c(ke,lp,1,100,5,1)}
function _h(){_h=rh;$h=$c(ge,lp,32,256,0,1)}
function Eh(){Eh=rh;Dh=$wnd.window.document}
function Uc(){Uc=rh;var a;!Wc();a=new Xc;Tc=a}
function Ph(){var a;a=Mh(null);a.e=2;return a}
function Nh(a){var b;b=Mh(a);Uh(a,b);return b}
function sn(a,b){qj(b);fk(a.a,'key',b);return a}
function Fk(a,b){a.onDoubleClick=b;return a}
function Di(a,b){a.a[a.a.length]=b;return true}
function qc(a){a.g&&a.e!==vp&&a.I();return a}
function Bh(a){if(!a){throw bh(new bi)}return a}
function wi(a){var b;b=a.a.$();a.b=vi(a);return b}
function Jl(a,b){var c;c=b.target;Ll(a,c.value)}
function Rb(a,b){a.i&&b.preventDefault();ac(a)}
function jb(a,b){Z(b,a);b.c.a.length>0||(b.a=4)}
function bo(a,b){this.a=a;this.c=b;this.b=false}
function Ro(a){this.b=a;this.a=new Tl(this.b.f)}
function Qo(a){this.b=a;this.a=new yl(this.b.e)}
function sj(a,b){this.e=a;this.d=(b&64)!=0?b|jp:b}
function tj(a){if(!a.d){a.d=a.b.T();a.c=a.b.V()}}
function Ab(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Hj(a,b,c){if(a.a.gb(c)){a.b=true;b.D(c)}}
function fj(a,b){return !(a.a.get(b)===undefined)}
function hl(a){return Hh(),T(a.e.b).a>0?true:false}
function Xn(a){return Hh(),0==T(a.e).a?true:false}
function wo(a){return ei(Kp,a)||ei(Hp,a)||ei('',a)}
function ad(a){return Array.isArray(a)&&a.zb===vh}
function kd(a){return !Array.isArray(a)&&a.zb===vh}
function P(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Hi(a,b){var c;c=a.a[b];Vj(a.a,b);return c}
function Ji(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function xl(a){var b;b=new tl;Rm(b,a.a.K());return b}
function Ch(a){if(a==null){throw bh(new ci)}return a}
function qj(a){if(a==null){throw bh(new bi)}return a}
function ti(a,b){if(b){return mi(a.a,b)}return false}
function Cj(a){yj(a);return new Ej(a,new Lj(a.a))}
function gm(a){nc(a.e);gb(a.b);S(a.d);W(a.c);W(a.a)}
function zo(a){gb(a.e);gb(a.a);S(a.b);S(a.c);W(a.d)}
function xj(a){if(!a.b){yj(a);a.c=true}else{xj(a.b)}}
function ek(){if(_j==256){$j=ak;ak=new o;_j=0}++_j}
function hh(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function Bj(a,b){yj(a);return new Ej(a,new Ij(b,a.a))}
function ym(a,b){var c;c=b.target;po(a.e,c.checked)}
function lm(a,b){var c;c=a.i;if(b!=c){a.i=b;ab(a.a)}}
function Mn(a,b){var c;c=a.g;if(b!=c){a.g=b;ab(a.a)}}
function Ll(a,b){var c;c=a.f;if(b!=c){a.f=b;ab(a.b)}}
function Sl(a){var b;b=new Ml;Sm(b,a.a.K());return b}
function Dk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Qi(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function pk(a){nk(a);return ld(a,11)&&a.B()?null:a.pb()}
function hm(a,b,c,d){return Hh(),dm(a,b,c,d)?true:false}
function qm(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function uj(a,b){this.b=a;this.a=(b&4096)==0?b|64|jp:b}
function Lj(a){sj.call(this,a.eb(),a.db()&-6);this.a=a}
function zj(a){if(!a){this.b=null;new Li}else{this.b=a}}
function mk(a){if(!a.o){a.o=true;a.p||a.q.forceUpdate()}}
function gk(a,b){null!=b&&a.kb(b,a.q.props,true);a.hb()}
function $b(a,b){var c;c=a.e;if(b!=c){a.e=qj(b);ab(a.a)}}
function _b(a,b){var c;c=a.g;if(b!=c){a.g=qj(b);ab(a.b)}}
function Nn(a,b){var c;c=a.i;if(b!=c){a.i=qj(b);ab(a.b)}}
function Oh(a,b){var c;c=Mh(a);Uh(a,c);c.e=b?8:0;return c}
function sc(a,b){var c;c=Kh(a.xb);return b==null?c:c+': '+b}
function Vl(a,b){var c;if(T(a.d)){c=b.target;lm(a,c.value)}}
function cb(a){var b;J();!!Cb&&!!Cb.e&&Hb((b=Cb,b),a)}
function xb(a){while(true){if(!vb(a)&&!wb(a)){break}}}
function Db(a){if(a.e){2==(a.e.c&7)||nb(a.e,4,true);kb(a.e)}}
function Rh(a){if(a.R()){return null}var b=a.j;return nh[b]}
function Ob(a,b){Cb=new Nb(Cb,b);a.d=false;Db(Cb);return Cb}
function Nb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function Xh(a){this.f=!a?null:sc(a,a.H());qc(this);this.I()}
function ai(a,b){var c,d;for(d=a.T();d.Z();){c=d.$();b.D(c)}}
function ni(a,b){return b===a?'(this Map)':b==null?yp:uh(b)}
function Zo(){Xo();return cd(Yc(Og,1),lp,37,0,[Uo,Wo,Vo])}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Zl(a,b,c){27==c.which?jm(a,b):13==c.which&&_l(a,b)}
function no(a,b){var c;Dj(Vn(a.b),(c=new Li,c)).S(new cp(b))}
function Qh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.M(b))}
function yb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],qj(b))}
function Cl(a,b){if(13==b.keyCode){b.preventDefault();Hl(a)}}
function Lm(a){return $wnd.React.createElement((fl(),dl),a.a)}
function Om(a){return $wnd.React.createElement((ql(),ol),a.a)}
function fn(a){return $wnd.React.createElement((Fl(),Dl),a.a)}
function zn(a){return $wnd.React.createElement((Bm(),zm),a.a)}
function fl(){fl=rh;var a;dl=(a=sh(Vm.prototype.lb,Vm,[]),a)}
function ql(){ql=rh;var a;ol=(a=sh(Xm.prototype.lb,Xm,[]),a)}
function Fl(){Fl=rh;var a;Dl=(a=sh(Zm.prototype.lb,Zm,[]),a)}
function cm(){cm=rh;var a;am=(a=sh(_m.prototype.lb,_m,[]),a)}
function Bm(){Bm=rh;var a;zm=(a=sh(bn.prototype.lb,bn,[]),a)}
function th(a){function b(){}
;b.prototype=a||{};return new b}
function Ah(a){yh();Bh(a);if(ld(a,48)){return a}return new zh(a)}
function Ti(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ui(a,b){var c;return Si(b,Ti(a,b==null?0:(c=r(b),c|0)))}
function Mi(a){Ci(this);Uj(this.a,li(a,$c(ke,lp,1,si(a.a),5,1)))}
function Vn(a){bb(a.d);return new Ej(null,new uj(new zi(a.g),0))}
function Po(a){this.b=a;this.a=new Al(this.b.e,this.b.f,this.b.g)}
function So(a){this.b=a;this.a=new xm(this.b.e,this.b.f,this.b.g)}
function To(a){this.b=a;this.a=new Jm(this.b.e,this.b.f,this.b.g)}
function Zp(){return yo(this.n)==(cb(this.c),this.q.props['a'])}
function Yi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Qb(a,b){a.j=b;ei(b,(bb(a.a),a.e))&&_b(a,b);Sb(b);ac(a)}
function Bo(a){var b;b=(bb(a.d),a.f);!!b&&!!b&&b.f<0&&Do(a,null)}
function hb(a){var b;b=(J(),J(),I);yb(b.b,a);0!=(a.c&rp)&&D(b)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function Fh(a,b,c,d){a.addEventListener(b,c,(Hh(),d?true:false))}
function Gh(a,b,c,d){a.removeEventListener(b,c,(Hh(),d?true:false))}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&jp)?jp:8192)|0|0,b)}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&jp)?jp:8192)|0|0,b)}
function qi(a,b){return pd(b)?b==null?Wi(a.a,null):ij(a.b,b):Wi(a.a,b)}
function Y(a,b){var c,d;Di(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Do(a,b){var c;c=a.f;if(!(b==c||!!b&&Hn(b,c))){a.f=b;ab(a.d)}}
function N(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function vj(a,b){!a.a?(a.a=new ii(a.d)):gi(a.a,a.b);gi(a.a,b);return a}
function Dj(a,b){var c;xj(a);c=new Oj;c.a=b;a.a.Y(new Rj(c));return c.a}
function Aj(a){var b;xj(a);b=0;while(a.a.fb(new Pj)){b=dh(b,1)}return b}
function Ck(a){a.placeholder='What needs to be done?';return a}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function ph(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function im(a){return Hh(),yo(a.n)==(cb(a.c),a.q.props['a'])?true:false}
function xo(a,b){return (Xo(),Vo)==a||(Uo==a?(bb(b.a),!b.g):(bb(b.a),b.g))}
function mo(a){var b;Dj(Bj(Vn(a.b),new ap),(b=new Li,b)).S(new bp(a.b))}
function Bl(a){var b;b=fi((bb(a.b),a.f));if(b.length>0){jo(a.e,b);Ll(a,'')}}
function wm(a){var b;b=new mm;wn(b,a.a.K());a.b.K();xn(b,a.c.K());return b}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function Ei(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.D(c)}}
function Ij(a,b){sj.call(this,b.eb(),b.db()&-16449);this.a=a;this.c=b}
function kj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function xi(a){this.d=a;this.c=new kj(this.d.b);this.a=this.c;this.b=vi(this)}
function wj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Wj(a,b){return Zc(b)!=10&&cd(q(b),b.yb,b.__elementTypeId$,Zc(b),a),a}
function pi(a,b,c){return pd(b)?b==null?Vi(a.a,null,c):hj(a.b,b,c):Vi(a.a,b,c)}
function Ao(a){var b,c;return b=T(a.b),Dj(Bj(Vn(a.j),new ep(b)),(c=new Li,c))}
function Gn(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Qn(a)),qp,null)}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function qk(a){var b;a.o=false;if(a.nb()){return null}else{b=a.jb();return b}}
function Ii(a,b){var c;c=Gi(a,b,0);if(c==-1){return false}Vj(a.a,c);return true}
function Im(a){var b;b=new Em;Rm(b,a.a.K());Sm(b,a.b.K());Tm(b,a.c.K());return b}
function zl(a){var b;b=new jl;Sm(b,a.a.K());Tm(b,a.b.K());Um(b,a.c.K());return b}
function hk(a,b){var c;c=null!=b&&a.kb(a.q.props,b,false);c||(a.r=false);return c}
function ik(a,b){var c;if(b){c=a.r;a.r=false;return !c}else{a.r=true;return true}}
function lj(a){if(a.a.c!=a.c){return gj(a.a,a.b.value[0])}return a.b.value[1]}
function tn(a,b){fk(a.a,(cm(),'a'),b);return $wnd.React.createElement(am,a.a)}
function W(a){if(-2!=a.e){t((J(),J(),I),new G(new fb(a)),0,null);!!a.b&&gb(a.b)}}
function S(a){if(!a.a){a.a=true;a.g=null;a.b=null;W(a.d);2==(a.e.c&7)||gb(a.e)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{xb(a.b)}finally{a.c=false}}}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Xb(a){Gh((Eh(),$wnd.window.window),tp,a.f,false);nc(a.c);W(a.b);W(a.a)}
function Wn(a){ai(new zi(a.g),new kc(a));ri(a.g);S(a.c);S(a.e);S(a.a);S(a.b);W(a.d)}
function vb(a){var b;if(0==P(a.c)){return false}else{b=O(a.c);!!b&&b.A();return true}}
function Uh(a,b){var c;if(!a){return}b.j=a;var d=Rh(b);if(!d){nh[a]=[b];return}d.xb=b}
function sh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ah(a){var b;if(ld(a,4)){return a}b=a&&a[wp];if(!b){b=new yc(a);Vc(b)}return b}
function Mh(a){var b;b=new Lh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Gi(a,b,c){for(;c<a.a.length;++c){if(Qi(b,a.a[c])){return c}}return -1}
function Hb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Di((!a.b&&(a.b=new Li),a.b),b)}}}
function Jb(a,b){var c;if(!a.c){c=Gb(a);!c.c&&(c.c=new Li);a.c=c.c}b.d=true;Di(a.c,qj(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);N(a,qj(b))}
function ij(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Zi(a.a,b);--a.b}return c}
function Oi(a){var b,c,d;d=0;for(c=new xi(a.a);c.b;){b=wi(c);d=d+(b?r(b):0);d=d|0}return d}
function kb(a){var b,c;for(c=new Ni(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function ki(a,b){var c,d;for(d=new xi(b.a);d.b;){c=wi(d);if(!ti(a,c)){return false}}return true}
function jh(){kh();var a=ih;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Pb(){var a;try{Eb(Cb);J()}finally{a=Cb.d;!a&&((J(),J(),I).d=true);Cb=Cb.d}}
function ok(a){var b;b=(++a.ob().e,new Bb);try{a.p=true;ld(a,11)&&a.A()}finally{Ab(b)}}
function hc(a,b,c){var d;d=qi(a.g,b?Zh(b.e):null);if(null!=d){oc(b.c,a);c&&!!b&&Gn(b);ab(a.d)}}
function Sn(a,b,c){var d;d=new Pn(b,c);mc(d.c,a,new lc(a,d));pi(a.g,Zh(d.e),d);ab(a.d);return d}
function vi(a){if(a.a.Z()){return true}if(a.a!=a.c){return false}a.a=new Yi(a.d.a);return a.a.Z()}
function eh(a){var b;b=a.h;if(b==0){return a.l+a.m*rp}if(b==1048575){return a.l+a.m*rp-zp}return a}
function gh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=zp;d=1048575}c=rd(e/rp);b=rd(e-c*rp);return dd(b,c,d)}
function Si(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Qi(a,c.ab())){return c}}return null}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===hp||typeof a==='function')&&!(a.zb===vh)}
function mh(a,b){typeof window===hp&&typeof window['$gwt']===hp&&(window['$gwt'][a]=b)}
function Xo(){Xo=rh;Uo=new Yo('ACTIVE',0);Wo=new Yo('COMPLETED',1);Vo=new Yo('ALL',2)}
function ci(){uc.call(this,'Cannot return null from a non-@Nullable @Provides method')}
function tl(){ql();++kk;this.b=new pc;this.a=new qb(null,qj((J(),new ul(this))),Ep);D((null,I))}
function Em(){Bm();++kk;this.b=new pc;this.a=new qb(null,qj((J(),new Fm(this))),Ep);D((null,I))}
function jk(a){$wnd.React.Component.call(this,a);this.a=this.mb();this.a.q=qj(this);this.a.ib()}
function Co(a){var b;b=Vb(a.i);ei(Kp,b)||ei(Hp,b)||ei('',b)?Ub(a.i,b):wo(Wb(a.i))?Zb(a.i):Ub(a.i,'')}
function Z(a,b){var c,d;d=a.c;Ii(d,b);d.a.length==0&&!!a.b&&np!=(a.b.c&op)&&(a.d||Jb((J(),c=Cb,c),a))}
function hj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function cd(a,b,c,d,e){e.xb=a;e.yb=b;e.zb=vh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function dm(a,b,c,d){var e,f;e=false;f=ik(a,d);if(!(b['a']===c['a'])){f&&ab(a.c);e=true}return e||a.o}
function T(a){bb(a.d);ob(a.e)&&ib(a.e);if(a.b){if(ld(a.b,5)){throw bh(a.b)}else{throw bh(a.b)}}return a.g}
function Hn(a,b){var c;if(a===b){return true}else if(null==b||!ld(b,55)){return false}else{c=b;return a.e==c.e}}
function _l(a,b){var c;c=(bb(a.a),a.i);if(null!=c&&c.length!=0){oo(b,c);Do(a.n,null);lm(a,c)}else{Un(a.k,b)}}
function gb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new tb(a)),qp,null);!!a.a&&S(a.a);a.c=a.c&-8|1}}
function nk(a){if(!lk){lk=(++a.ob().e,new Bb);$wnd.Promise.resolve(null).then(sh(rk.prototype.L,rk,[]))}}
function yj(a){if(a.b){yj(a.b)}else if(a.c){throw bh(new Wh("Stream already terminated, can't be modified or used"))}}
function q(a){return pd(a)?ne:nd(a)?ce:md(a)?ae:kd(a)?a.xb:ad(a)?a.xb:a.xb||Array.isArray(a)&&Yc(Ud,1)||Ud}
function r(a){return pd(a)?dk(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.u():ad(a)?Zj(a):!!a&&!!a.hashCode?a.hashCode():Zj(a)}
function Zh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(_h(),$h)[b];!c&&(c=$h[b]=new Yh(a));return c}return new Yh(a)}
function uh(a){var b;if(Array.isArray(a)&&a.zb===vh){return Kh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function dk(a){bk();var b,c,d;c=':'+a;d=ak[c];if(d!=null){return rd(d)}d=$j[c];b=d==null?ck(a):rd(d);ek();ak[c]=b;return b}
function yc(a){wc();qc(this);this.e=a;a!=null&&Xj(a,wp,this);this.f=a==null?yp:uh(a);this.a='';this.b=a;this.a=''}
function Lh(){this.g=Ih++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function U(a,b){this.c=qj(a);this.f=null;this.g=null;this.e=new rb(this,b);this.d=new eb(this.e);np==(b&op)&&hb(this.e)}
function pb(a,b,c,d){this.b=new Li;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&hb(this)}
function zb(){this.c=new Q;this.d=$c(vd,lp,20,5,0,1);this.d[0]=new Q;this.d[1]=new Q;this.d[2]=new Q;this.d[3]=new Q;this.d[4]=new Q}
function Ml(){Fl();var a;++kk;this.c=new pc;this.b=(a=new eb((J(),null)),a);this.a=new qb(null,qj(new Ql(this)),Ep);D((null,I))}
function jl(){fl();++kk;this.c=new pc;this.a=new U((J(),new kl(this)),136486912);this.b=new qb(null,qj(new ml(this)),Ep);D((null,I))}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function dh(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<zp){return c}}return eh(ed(nd(a)?gh(a):a,nd(b)?gh(b):b))}
function Tb(a){var b,c;c=(b=(Eh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));$b(a,c);ei(a.j,c)&&_b(a,c)}
function nc(a){var b,c;if(!a.a){for(c=new Ni(new Mi(new zi(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.C()}a.a=true}}
function Pi(a){var b,c,d;d=1;for(c=new Ni(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Ki(a,b){var c,d;d=a.a.length;b.length<d&&(b=Wj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Th(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function cl(){al();return cd(Yc(bf,1),lp,9,0,[Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k])}
function p(a,b){return pd(a)?ei(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.s(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function Ul(a){var b;b=T(a.d);if(!a.j&&b){a.j=true;km(a,(cb(a.c),a.q.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function sk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.yb){return !!a.yb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function O(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function qb(a,b,c){pb.call(this,null,a,b,c|(!a?262144:np)|(a?jp:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:rp)|(0!=(c&229376)?0:98304)|0|0|0)}
function Mb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ni(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&nb(b,5,true)}}}
function Lb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Ni(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&nb(b,6,true)}}}
function Kb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ni(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?nb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function fi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ib(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=Hi(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&nb(c.b,3,true);++b}}}return b}
function Pn(a,b){var c,d,e;this.i=qj(a);this.g=b;this.e=Fn++;this.d=(d=new eb((J(),null)),d);this.c=new pc;this.b=(e=new eb(null),e);this.a=(c=new eb(null),c)}
function Zb(b){var c;try{A((J(),J(),I),new ec(b),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){c=a;throw bh(c)}else if(ld(a,4)){c=a;throw bh(new Xh(c))}else throw bh(a)}}
function ac(b){var c;try{A((J(),J(),I),new fc(b),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){c=a;throw bh(c)}else if(ld(a,4)){c=a;throw bh(new Xh(c))}else throw bh(a)}}
function Hl(b){var c;try{A((J(),J(),I),new Ol(b),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){c=a;throw bh(c)}else if(ld(a,4)){c=a;throw bh(new Xh(c))}else throw bh(a)}}
function On(b){var c;try{A((J(),J(),I),new Rn(b),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){c=a;throw bh(c)}else if(ld(a,4)){c=a;throw bh(new Xh(c))}else throw bh(a)}}
function lo(b){var c;try{A((J(),J(),I),new so(b),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){c=a;throw bh(c)}else if(ld(a,4)){c=a;throw bh(new Xh(c))}else throw bh(a)}}
function oo(b,c){var d;try{A((J(),J(),I),new ro(b,c),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){d=a;throw bh(d)}else if(ld(a,4)){d=a;throw bh(new Xh(d))}else throw bh(a)}}
function po(b,c){var d;try{A((J(),J(),I),new uo(b,c),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){d=a;throw bh(d)}else if(ld(a,4)){d=a;throw bh(new Xh(d))}else throw bh(a)}}
function Il(b,c){var d;try{A((J(),J(),I),new Pl(b,c),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){d=a;throw bh(d)}else if(ld(a,4)){d=a;throw bh(new Xh(d))}else throw bh(a)}}
function fm(b,c){var d;try{A((J(),J(),I),new tm(b,c),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){d=a;throw bh(d)}else if(ld(a,4)){d=a;throw bh(new Xh(d))}else throw bh(a)}}
function jm(b,c){var d;try{A((J(),J(),I),new sm(b,c),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){d=a;throw bh(d)}else if(ld(a,4)){d=a;throw bh(new Xh(d))}else throw bh(a)}}
function km(b,c){var d;try{A((J(),J(),I),new rm(b,c),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){d=a;throw bh(d)}else if(ld(a,4)){d=a;throw bh(new Xh(d))}else throw bh(a)}}
function Un(b,c){var d;try{A((J(),J(),I),new _n(b,c),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){d=a;throw bh(d)}else if(ld(a,4)){d=a;throw bh(new Xh(d))}else throw bh(a)}}
function Ub(b,c){var d;try{A((J(),J(),I),new dc(b,c),75505664)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){d=a;throw bh(d)}else if(ld(a,4)){d=a;throw bh(new Xh(d))}else throw bh(a)}}
function Tn(b,c){var d;try{return t((J(),J(),I),new bo(b,c),up,null)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){d=a;throw bh(d)}else if(ld(a,4)){d=a;throw bh(new Xh(d))}else throw bh(a)}}
function lh(b,c,d,e){kh();var f=ih;$moduleName=c;$moduleBase=d;_g=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{gp(g)()}catch(a){b(c,a)}}else{gp(g)()}}
function rb(a,b){pb.call(this,a,new sb(a),null,b|(np==(b&op)?0:524288)|(0!=(b&6291456)?0:np==(b&op)?rp:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function wh(){var a;a=new Oo;gl(new Nm(a));rl(new Qm(a));em(new vn(a));Cm(new Bn(a));Gl(new hn(a));$wnd.ReactDOM.render(zn(new An),(Eh(),Dh).getElementById('todoapp'),null)}
function cj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return dj()}}
function Zn(){var a;this.g=new Ri;this.d=(a=new eb((J(),null)),a);this.c=new U(new ao(this),Jp);this.e=new U(new co(this),Jp);this.a=new U(new eo(this),Jp);this.b=new U(new fo(this),Jp)}
function mm(){cm();var a,b;++kk;this.e=new pc;this.c=(b=new eb((J(),null)),b);this.a=(a=new eb(null),a);this.d=new U(new um(this),136486912);this.b=new qb(null,qj(new vm(this)),Ep);D((null,I))}
function li(a,b){var c,d,e,f,g;g=si(a.a);b.length<g&&(b=Wj(new Array(g),b));e=(f=new xi((new ui(a.a)).a),new Ai(f));for(d=0;d<g;++d){b[d]=(c=wi(e.a),c.bb())}b.length>g&&(b[g]=null);return b}
function oh(){nh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Ab()&&(c=Rc(c,g)):g[0].Ab()}catch(a){a=ah(a);if(ld(a,4)){d=a;Dc();Jc(ld(d,40)?d.J():d)}else throw bh(a)}}return c}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?yp:od(b)?b==null?null:b.name:pd(b)?'String':Kh(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.g;try{d=b.c.w();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;$(b.d)}}catch(a){a=ah(a);if(ld(a,12)){c=a;if(!b.b){b.g=null;b.b=c;$(b.d)}throw bh(c)}else throw bh(a)}}
function Sj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Vi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Si(b,e);if(f){return f.cb(c)}}e[e.length]=new Bi(b,c);++a.b;return null}
function Oo(){this.a=Ah((ho(),ho(),go));this.e=Ah(new $o(this.a));this.b=Ah(new vo(this.e));this.f=Ah(new dp(this.b));this.d=Ah((Mo(),Mo(),Lo));this.c=Ah(new Ko(this.e,this.d));this.g=Ah(new fp(this.c))}
function ck(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+di(a,c++)}b=b|0;return b}
function M(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=$c(ke,lp,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function Eo(a,b){var c;this.j=qj(a);this.i=qj(b);this.d=(c=new eb((J(),null)),c);this.b=new U(new Go(this),Jp);this.c=new U(new Ho(this),Jp);this.e=u(new Io(this),413155328);this.a=u(new Jo(this),681590784);D((null,I))}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=jp==(d&jp)?c.w():c.w()}else{Ob(b,e);try{g=jp==(d&jp)?c.w():c.w()}finally{Pb()}}return g}catch(a){a=ah(a);if(ld(a,4)){f=a;throw bh(f)}else throw bh(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=jp==(d&jp)?(c.a.C(),null):(c.a.C(),null)}else{Ob(b,e);try{g=jp==(d&jp)?(c.a.C(),null):(c.a.C(),null)}finally{Pb()}}return g}catch(a){a=ah(a);if(ld(a,4)){f=a;throw bh(f)}else throw bh(a)}finally{D(b)}}
function Sb(a){var b;if(0==a.length){b=(Eh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Dh.title,b)}else{(Eh(),$wnd.window.window).location.hash=a}}
function ib(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.C()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=ah(a);if(ld(a,4)){J()}else throw bh(a)}}}
function Wi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Qi(b,e.ab())){if(d.length==1){d.length=0;Zi(a.a,g)}else{d.splice(h,1)}--a.b;return e.bb()}}return null}
function qh(a,b,c){var d=nh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=nh[b]),th(h));_.yb=c;!b&&(_.zb=vh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.xb=f)}
function Sh(a){if(a.Q()){var b=a.c;b.R()?(a.k='['+b.j):!b.Q()?(a.k='[L'+b.O()+';'):(a.k='['+b.O());a.b=b.N()+'[]';a.i=b.P()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Th('.',[c,Th('$',d)]);a.b=Th('.',[c,Th('.',d)]);a.i=d[d.length-1]}
function bc(){var a,b,c;this.f=new gc(this);this.c=new pc;this.b=(c=new eb((J(),null)),c);this.a=(b=new eb(null),b);Fh((Eh(),$wnd.window.window),tp,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function mi(a,b){var c,d,e;c=b.ab();e=b.bb();d=pd(c)?c==null?oi(Ui(a.a,null)):gj(a.b,c):oi(Ui(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Ui(a.a,null):fj(a.b,c):!!Ui(a.a,c))){return false}return true}
function ob(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ni(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=ah(a);if(!ld(a,4))throw bh(a)}if(6==(b.c&7)){return true}}}}}kb(b);return false}
function bj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function nb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){db(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}Ei(a.b,new ub(a));a.b.a=$c(ke,lp,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function wb(a){var b,c,d,e,f,g,h,i;d=P(a.d[0]);c=P(a.d[1]);g=P(a.d[2]);e=P(a.d[3]);f=P(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;L(a.d[0]);L(a.d[1]);L(a.d[2]);L(a.d[3]);L(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=O(b);h.c&=-513;ib(h);return true}
function al(){al=rh;Gk=new bl(Cp,0);Hk=new bl('checkbox',1);Ik=new bl('color',2);Jk=new bl('date',3);Kk=new bl('datetime',4);Lk=new bl('email',5);Mk=new bl('file',6);Nk=new bl('hidden',7);Ok=new bl('image',8);Pk=new bl('month',9);Qk=new bl(ip,10);Rk=new bl('password',11);Sk=new bl('radio',12);Tk=new bl('range',13);Uk=new bl('reset',14);Vk=new bl('search',15);Wk=new bl('submit',16);Xk=new bl('tel',17);Yk=new bl('text',18);Zk=new bl('time',19);$k=new bl('url',20);_k=new bl('week',21)}
function Fb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Fi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ji(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Z(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&nb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Fi(a.b,g);if(-1==k.e){k.e=0;Y(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Hi(a.b,g)}e&&mb(a.e,a.b)}else{e&&mb(a.e,new Li)}if(V(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&np!=(b.e.c&op)&&Jb(a,k)}}
function dj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Bp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!bj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Bp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var hp='object',ip='number',jp=16384,kp={15:1},lp={3:1,6:1},mp={11:1},np=1048576,op=1835008,pp={8:1},qp=67108864,rp=4194304,sp={30:1},tp='hashchange',up=142614528,vp='__noinit__',wp='__java$exception',xp={3:1,12:1,5:1,4:1},yp='null',zp=17592186044416,Ap={44:1},Bp='delete',Cp='button',Dp='selected',Ep=1478635520,Fp={11:1,39:1},Gp='input',Hp='completed',Ip='header',Jp=136421376,Kp='active';var _,nh,ih,_g=-1;oh();qh(1,null,{},o);_.s=Mp;_.t=function(){return this.xb};_.u=Np;_.v=function(){var a;return Kh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.s(a)};_.hashCode=function(){return this.u()};_.toString=function(){return this.v()};var fd,gd,hd;qh(57,1,{},Lh);_.M=function(a){var b;b=new Lh;b.e=4;a>1?(b.c=Qh(this,a-1)):(b.c=this);return b};_.N=function(){Jh(this);return this.b};_.O=function(){return Kh(this)};_.P=function(){Jh(this);return this.i};_.Q=function(){return (this.e&4)!=0};_.R=function(){return (this.e&1)!=0};_.v=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Jh(this),this.k)};_.e=0;_.g=0;var Ih=1;var ke=Nh(1);var be=Nh(57);qh(92,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var ud=Nh(92);qh(16,1,kp,G);_.w=function(){return this.a.C(),null};var sd=Nh(16);qh(93,1,{},H);var td=Nh(93);var I;qh(20,1,{20:1},Q);_.b=0;_.c=false;_.d=0;var vd=Nh(20);qh(229,1,mp);_.v=function(){var a;return Kh(this.xb)+'@'+(a=r(this)>>>0,a.toString(16))};var xd=Nh(229);qh(21,229,mp,U);_.A=function(){S(this)};_.B=Lp;_.a=false;var wd=Nh(21);qh(17,229,{11:1,17:1},eb);_.A=function(){W(this)};_.B=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=Nh(17);qh(154,1,pp,fb);_.C=function(){X(this.a)};var yd=Nh(154);qh(19,229,{11:1,19:1},qb,rb);_.A=function(){gb(this)};_.B=function(){return 1==(this.c&7)};_.c=0;var Dd=Nh(19);qh(155,1,sp,sb);_.C=function(){R(this.a)};var Ad=Nh(155);qh(156,1,pp,tb);_.C=function(){lb(this.a)};var Bd=Nh(156);qh(157,1,{},ub);_.D=function(a){jb(this.a,a)};var Cd=Nh(157);qh(121,1,{},zb);_.a=0;_.b=100;_.e=0;var Ed=Nh(121);qh(74,1,mp,Bb);_.A=function(){Ab(this)};_.B=Lp;_.a=false;var Fd=Nh(74);qh(163,1,{},Nb);_.v=function(){var a;return Jh(Gd),Gd.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.a=0;var Cb;var Gd=Nh(163);qh(53,1,{53:1});_.e='';_.g='';_.i=true;_.j='';var Nd=Nh(53);qh(158,53,{11:1,53:1,39:1},bc);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new cc(this)),qp,null)}};_.s=Mp;_.F=Up;_.u=Np;_.B=Vp;_.v=function(){var a;return Jh(Ld),Ld.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.d=0;var Ld=Nh(158);qh(159,1,pp,cc);_.C=function(){Xb(this.a)};var Hd=Nh(159);qh(160,1,pp,dc);_.C=function(){Qb(this.a,this.b)};var Id=Nh(160);qh(161,1,pp,ec);_.C=function(){Yb(this.a)};var Jd=Nh(161);qh(162,1,pp,fc);_.C=function(){Tb(this.a)};var Kd=Nh(162);qh(142,1,{},gc);_.handleEvent=function(a){Rb(this.a,a)};var Md=Nh(142);qh(123,1,{});var Qd=Nh(123);qh(132,1,{},kc);_.D=function(a){ic(this.a,a)};var Od=Nh(132);qh(133,1,pp,lc);_.C=function(){jc(this.a,this.b)};var Pd=Nh(133);qh(124,123,{});var Rd=Nh(124);qh(27,1,mp,pc);_.A=function(){nc(this)};_.B=Lp;_.a=false;var Sd=Nh(27);qh(4,1,{3:1,4:1});_.G=function(a){return new Error(a)};_.H=function(){return this.f};_.I=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Kh(this.xb),c==null?a:a+': '+c);rc(this,tc(this.G(b)));Vc(this)};_.v=function(){return sc(this,this.H())};_.e=vp;_.g=true;var oe=Nh(4);qh(12,4,{3:1,12:1,4:1});var ee=Nh(12);qh(5,12,xp);var le=Nh(5);qh(46,5,xp);var he=Nh(46);qh(89,46,xp);var Wd=Nh(89);qh(40,89,{40:1,3:1,12:1,5:1,4:1},yc);_.H=function(){xc(this);return this.c};_.J=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Td=Nh(40);var Ud=Nh(0);qh(212,1,{});var Vd=Nh(212);var Ac=0,Bc=0,Cc=-1;qh(101,212,{},Qc);var Mc;var Xd=Nh(101);var Tc;qh(223,1,{});var Zd=Nh(223);qh(90,223,{},Xc);var Yd=Nh(90);qh(48,1,{48:1},zh);_.K=function(){var a,b;b=this.a;if(qd(b)===qd(xh)){b=this.a;if(qd(b)===qd(xh)){b=this.b.K();a=this.a;if(qd(a)!==qd(xh)&&qd(a)!==qd(b)){throw bh(new Wh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}this.a=b;this.b=null}}return b};var xh;var $d=Nh(48);var Dh;qh(87,1,{84:1});_.v=Lp;var _d=Nh(87);fd={3:1,85:1,31:1};var ae=Nh(85);qh(45,1,{3:1,45:1});var je=Nh(45);gd={3:1,31:1,45:1};var ce=Nh(222);qh(35,1,{3:1,31:1,35:1});_.s=Mp;_.u=Np;_.v=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=Nh(35);qh(10,5,xp,Wh,Xh);var fe=Nh(10);qh(32,45,{3:1,31:1,32:1,45:1},Yh);_.s=function(a){return ld(a,32)&&a.a==this.a};_.u=Lp;_.v=function(){return ''+this.a};_.a=0;var ge=Nh(32);var $h;qh(280,1,{});qh(47,46,xp,bi,ci);_.G=function(a){return new TypeError(a)};var ie=Nh(47);hd={3:1,84:1,31:1,2:1};var ne=Nh(2);qh(88,87,{84:1},ii);var me=Nh(88);qh(284,1,{});qh(64,5,xp,ji);var pe=Nh(64);qh(224,1,{43:1});_.S=Rp;_.W=function(){return new uj(this,0)};_.X=function(){return new Ej(null,this.W())};_.U=function(a){throw bh(new ji('Add not supported on this collection'))};_.v=function(){var a,b,c;c=new wj('[',']');for(b=this.T();b.Z();){a=b.$();vj(c,a===this?'(this Collection)':a==null?yp:uh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var qe=Nh(224);qh(227,1,{211:1});_.s=function(a){var b,c,d;if(a===this){return true}if(!ld(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new xi((new ui(d)).a);c.b;){b=wi(c);if(!mi(this,b)){return false}}return true};_.u=function(){return Oi(new ui(this))};_.v=function(){var a,b,c;c=new wj('{','}');for(b=new xi((new ui(this)).a);b.b;){a=wi(b);vj(c,ni(this,a.ab())+'='+ni(this,a.bb()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Be=Nh(227);qh(120,227,{211:1});var te=Nh(120);qh(226,224,{43:1,235:1});_.W=function(){return new uj(this,1)};_.s=function(a){var b;if(a===this){return true}if(!ld(a,25)){return false}b=a;if(si(b.a)!=this.V()){return false}return ki(this,b)};_.u=function(){return Oi(this)};var Ce=Nh(226);qh(25,226,{25:1,43:1,235:1},ui);_.T=function(){return new xi(this.a)};_.V=Pp;var se=Nh(25);qh(26,1,{},xi);_.Y=Op;_.$=function(){return wi(this)};_.Z=Qp;_.b=false;var re=Nh(26);qh(225,224,{43:1,232:1});_.W=function(){return new uj(this,16)};_._=function(a,b){throw bh(new ji('Add not supported on this list'))};_.U=function(a){this._(this.V(),a);return true};_.s=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.V()!=f.a.length){return false}e=new Ni(f);for(c=new Ni(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.u=function(){return Pi(this)};_.T=function(){return new yi(this)};var ve=Nh(225);qh(99,1,{},yi);_.Y=Op;_.Z=function(){return this.a<this.b.a.length};_.$=function(){return Fi(this.b,this.a++)};_.a=0;var ue=Nh(99);qh(49,224,{43:1},zi);_.T=function(){var a;return a=new xi((new ui(this.a)).a),new Ai(a)};_.V=Pp;var xe=Nh(49);qh(66,1,{},Ai);_.Y=Op;_.Z=function(){return this.a.b};_.$=function(){var a;return a=wi(this.a),a.bb()};var we=Nh(66);qh(109,1,Ap);_.s=function(a){var b;if(!ld(a,44)){return false}b=a;return Qi(this.a,b.ab())&&Qi(this.b,b.bb())};_.ab=Lp;_.bb=Qp;_.u=function(){return pj(this.a)^pj(this.b)};_.cb=function(a){var b;b=this.b;this.b=a;return b};_.v=function(){return this.a+'='+this.b};var ye=Nh(109);qh(110,109,Ap,Bi);var ze=Nh(110);qh(228,1,Ap);_.s=function(a){var b;if(!ld(a,44)){return false}b=a;return Qi(this.b.value[0],b.ab())&&Qi(lj(this),b.bb())};_.u=function(){return pj(this.b.value[0])^pj(lj(this))};_.v=function(){return this.b.value[0]+'='+lj(this)};var Ae=Nh(228);qh(14,225,{3:1,14:1,43:1,232:1},Li,Mi);_._=function(a,b){Tj(this.a,a,b)};_.U=function(a){return Di(this,a)};_.S=function(a){Ei(this,a)};_.T=function(){return new Ni(this)};_.V=function(){return this.a.length};var Ee=Nh(14);qh(18,1,{},Ni);_.Y=Op;_.Z=function(){return this.a<this.c.a.length};_.$=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var De=Nh(18);qh(41,120,{3:1,41:1,211:1},Ri);var Fe=Nh(41);qh(69,1,{},Xi);_.S=Rp;_.T=function(){return new Yi(this)};_.b=0;var He=Nh(69);qh(70,1,{},Yi);_.Y=Op;_.$=function(){return this.d=this.a[this.c++],this.d};_.Z=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ge=Nh(70);var _i;qh(67,1,{},jj);_.S=Rp;_.T=function(){return new kj(this)};_.b=0;_.c=0;var Ke=Nh(67);qh(68,1,{},kj);_.Y=Op;_.$=function(){return this.c=this.a,this.a=this.b.next(),new mj(this.d,this.c,this.d.c)};_.Z=function(){return !this.a.done};var Ie=Nh(68);qh(122,228,Ap,mj);_.ab=function(){return this.b.value[0]};_.bb=function(){return lj(this)};_.cb=function(a){return hj(this.a,this.b.value[0],a)};_.c=0;var Je=Nh(122);qh(100,1,{});_.Y=function(a){rj(this,a)};_.db=function(){return this.d};_.eb=$p;_.d=0;_.e=0;var Me=Nh(100);qh(65,100,{});var Le=Nh(65);qh(24,1,{},uj);_.db=Lp;_.eb=function(){tj(this);return this.c};_.Y=function(a){tj(this);this.d.Y(a)};_.fb=function(a){tj(this);if(this.d.Z()){a.D(this.d.$());return true}return false};_.a=0;_.c=0;var Ne=Nh(24);qh(58,1,{},wj);_.v=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Oe=Nh(58);var Xe=Ph();qh(111,1,{});_.c=false;var Ye=Nh(111);qh(34,111,{},Ej);var We=Nh(34);qh(113,65,{},Ij);_.fb=function(a){this.b=false;while(!this.b&&this.c.fb(new Jj(this,a)));return this.b};_.b=false;var Qe=Nh(113);qh(116,1,{},Jj);_.D=function(a){Hj(this.a,this.b,a)};var Pe=Nh(116);qh(112,65,{},Lj);_.fb=function(a){return this.a.fb(new Mj(a))};var Se=Nh(112);qh(115,1,{},Mj);_.D=function(a){Kj(this.a,a)};var Re=Nh(115);qh(114,1,{},Oj);_.D=function(a){Nj(this,a)};var Te=Nh(114);qh(117,1,{},Pj);_.D=function(a){};var Ue=Nh(117);qh(118,1,{},Rj);_.D=function(a){Qj(this,a)};var Ve=Nh(118);qh(282,1,{});qh(231,1,{});var Ze=Nh(231);qh(279,1,{});var Yj=0;var $j,_j=0,ak;qh(740,1,{});qh(755,1,{});qh(230,1,{});_.hb=Sp;_.ib=Sp;_.kb=function(a,b,c){return false};_.r=false;var $e=Nh(230);qh(33,$wnd.React.Component,{});ph(nh[1],_);_.render=function(){return pk(this.a)};var _e=Nh(33);qh(36,230,{});_.nb=function(){return false};_.pb=function(){return qk(this)};_.o=false;_.p=false;var kk=1,lk;var af=Nh(36);qh(250,$wnd.Function,{},rk);_.L=function(a){return Ab(lk),lk=null,null};qh(9,35,{3:1,31:1,35:1,9:1},bl);var Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k;var bf=Oh(9,cl);qh(164,36,{});_.ub=Tp;_.jb=function(){var a;a=T(this.g.b);return $wnd.React.createElement('footer',sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,['footer'])),Om(new Pm),$wnd.React.createElement('ul',sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',uk(sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,[(Xo(),Vo)==a?Dp:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',uk(sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,[Uo==a?Dp:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',uk(sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,[Wo==a?Dp:null])),'#completed'),'Completed'))),this.ub()?$wnd.React.createElement(Cp,vk(sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,['clear-completed'])),sh(Km.prototype.tb,Km,[this])),'Clear Completed'):null)};var Qf=Nh(164);qh(165,164,{});_.ub=Tp;var dl,el;var Uf=Nh(165);qh(166,165,Fp,jl);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new nl(this)),qp,null)}};_.s=Mp;_.ob=Wp;_.F=Up;_.ub=function(){return T(this.a)};_.u=Np;_.B=Vp;_.v=function(){var a;return Jh(nf),nf.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.b,new ll(this))}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){b=a;throw bh(b)}else if(ld(a,4)){b=a;throw bh(new Xh(b))}else throw bh(a)}};_.d=0;var nf=Nh(166);qh(167,1,kp,kl);_.w=function(){return hl(this.a)};var cf=Nh(167);qh(170,1,kp,ll);_.w=Yp;var df=Nh(170);qh(168,1,sp,ml);_.C=Xp;var ef=Nh(168);qh(169,1,pp,nl);_.C=function(){il(this.a)};var ff=Nh(169);qh(171,36,{});_.jb=function(){var a,b;b=T(this.d.e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,['todo-count'])),$wnd.React.createElement('strong',null,b),' '+a+' left')};var Pf=Nh(171);qh(172,171,{});var ol,pl;var Tf=Nh(172);qh(173,172,Fp,tl);_.A=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new vl(this)),qp,null)}};_.s=Mp;_.ob=Wp;_.F=Qp;_.u=Np;_.B=_p;_.v=function(){var a;return Jh(lf),lf.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.a,new wl(this))}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){b=a;throw bh(b)}else if(ld(a,4)){b=a;throw bh(new Xh(b))}else throw bh(a)}};_.c=0;var lf=Nh(173);qh(174,1,sp,ul);_.C=Xp;var gf=Nh(174);qh(175,1,pp,vl);_.C=function(){sl(this.a)};var hf=Nh(175);qh(176,1,kp,wl);_.w=Yp;var jf=Nh(176);qh(150,1,{},yl);_.K=function(){return xl(this)};var kf=Nh(150);qh(149,1,{},Al);_.K=function(){return zl(this)};var mf=Nh(149);qh(195,36,{});_.jb=function(){return $wnd.React.createElement(Gp,wk(Ak(Bk(Ek(Ck(sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,['new-todo']))),(bb(this.b),this.f)),sh(dn.prototype.sb,dn,[this])),sh(en.prototype.rb,en,[this]))))};_.f='';var bg=Nh(195);qh(196,195,{});var Dl,El;var Wf=Nh(196);qh(197,196,Fp,Ml);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Rl(this)),qp,null)}};_.s=Mp;_.ob=Wp;_.F=Up;_.u=Np;_.B=Vp;_.v=function(){var a;return Jh(uf),uf.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.a,new Nl(this))}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){b=a;throw bh(b)}else if(ld(a,4)){b=a;throw bh(new Xh(b))}else throw bh(a)}};_.d=0;var uf=Nh(197);qh(200,1,kp,Nl);_.w=Yp;var of=Nh(200);qh(201,1,pp,Ol);_.C=function(){Bl(this.a)};var pf=Nh(201);qh(202,1,pp,Pl);_.C=function(){Jl(this.a,this.b)};var qf=Nh(202);qh(198,1,sp,Ql);_.C=Xp;var rf=Nh(198);qh(199,1,pp,Rl);_.C=function(){Kl(this.a)};var sf=Nh(199);qh(153,1,{},Tl);_.K=function(){return Sl(this)};var tf=Nh(153);qh(177,36,{});_.hb=function(){Ul(this)};_.wb=Zp;_.ib=function(){km(this,this.vb())};_.jb=function(){var a,b;b=this.vb();a=(bb(b.a),b.g);return $wnd.React.createElement('li',sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,[a?Hp:null,this.wb()?'editing':null])),$wnd.React.createElement('div',sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,['view'])),$wnd.React.createElement(Gp,Ak(xk(Dk(sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,['toggle'])),(al(),Hk)),a),sh(ln.prototype.rb,ln,[b]))),$wnd.React.createElement('label',Fk(new $wnd.Object,sh(mn.prototype.tb,mn,[this,b])),(bb(b.b),b.i)),$wnd.React.createElement(Cp,vk(sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,['destroy'])),sh(nn.prototype.tb,nn,[this,b])))),$wnd.React.createElement(Gp,Bk(Ak(zk(yk(sk(tk(new $wnd.Object,sh(on.prototype.D,on,[this])),cd(Yc(ne,1),lp,2,6,['edit'])),(bb(this.a),this.i)),sh(pn.prototype.qb,pn,[this,b])),sh(kn.prototype.rb,kn,[this])),sh(qn.prototype.sb,qn,[this,b]))))};_.j=false;var eg=Nh(177);qh(178,177,{});_.nb=function(){var a;a=(cb(this.c),this.q.props['a']);if(!!a&&a.f<0){return true}return false};_.vb=function(){return this.q.props['a']};_.wb=Zp;_.kb=function(a,b,c){return dm(this,a,b,c)};var am,bm;var Yf=Nh(178);qh(179,178,Fp,mm);_.hb=function(){var b;try{A((J(),J(),I),new pm(this),up)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){b=a;throw bh(b)}else if(ld(a,4)){b=a;throw bh(new Xh(b))}else throw bh(a)}};_.A=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new nm(this)),qp,null)}};_.s=Mp;_.ob=Wp;_.F=$p;_.vb=function(){return cb(this.c),this.q.props['a']};_.u=Np;_.B=bq;_.wb=function(){return T(this.d)};_.kb=function(b,c,d){var e;try{return t((J(),J(),I),new qm(this,b,c,d),75505664,null)}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){e=a;throw bh(e)}else if(ld(a,4)){e=a;throw bh(new Xh(e))}else throw bh(a)}};_.v=function(){var a;return Jh(Ff),Ff.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.b,new om(this))}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){b=a;throw bh(b)}else if(ld(a,4)){b=a;throw bh(new Xh(b))}else throw bh(a)}};_.f=0;var Ff=Nh(179);qh(182,1,pp,nm);_.C=function(){gm(this.a)};var vf=Nh(182);qh(183,1,kp,om);_.w=Yp;var wf=Nh(183);qh(184,1,pp,pm);_.C=function(){Ul(this.a)};var xf=Nh(184);qh(185,1,kp,qm);_.w=function(){return hm(this.a,this.d,this.c,this.b)};_.b=false;var yf=Nh(185);qh(186,1,pp,rm);_.C=function(){lm(this.a,In(this.b))};var zf=Nh(186);qh(187,1,pp,sm);_.C=function(){$l(this.a,this.b)};var Af=Nh(187);qh(188,1,pp,tm);_.C=function(){Vl(this.a,this.b)};var Bf=Nh(188);qh(180,1,kp,um);_.w=function(){return im(this.a)};var Cf=Nh(180);qh(181,1,sp,vm);_.C=Xp;var Df=Nh(181);qh(151,1,{},xm);_.K=function(){return wm(this)};var Ef=Nh(151);qh(189,36,{});_.jb=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(Ip,sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,[Ip])),$wnd.React.createElement('h1',null,'todos'),fn(new gn)),T(this.d.c)?null:$wnd.React.createElement('section',sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,[Ip])),$wnd.React.createElement(Gp,Ak(Dk(sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,['toggle-all'])),(al(),Hk)),sh(yn.prototype.rb,yn,[this]))),$wnd.React.createElement.apply(null,['ul',sk(new $wnd.Object,cd(Yc(ne,1),lp,2,6,['todo-list']))].concat((a=Dj(Cj(T(this.f.c).X()),(b=new Li,b)),Ki(a,bd(a.a.length)))))),T(this.d.c)?null:Lm(new Mm)))};var hg=Nh(189);qh(190,189,{});var zm,Am;var $f=Nh(190);qh(191,190,Fp,Em);_.A=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Gm(this)),qp,null)}};_.s=Mp;_.ob=Wp;_.F=Qp;_.u=Np;_.B=_p;_.v=function(){var a;return Jh(Kf),Kf.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.a,new Hm(this))}catch(a){a=ah(a);if(ld(a,5)||ld(a,7)){b=a;throw bh(b)}else if(ld(a,4)){b=a;throw bh(new Xh(b))}else throw bh(a)}};_.c=0;var Kf=Nh(191);qh(192,1,sp,Fm);_.C=Xp;var Gf=Nh(192);qh(193,1,pp,Gm);_.C=function(){sl(this.a)};var Hf=Nh(193);qh(194,1,kp,Hm);_.w=Yp;var If=Nh(194);qh(152,1,{},Jm);_.K=function(){return Im(this)};var Jf=Nh(152);qh(249,$wnd.Function,{},Km);_.tb=function(a){lo(this.a.f)};qh(205,1,{},Mm);var Lf=Nh(205);qh(78,1,{},Nm);_.K=function(){return zl((new Po(this.a)).a)};var Mf=Nh(78);qh(203,1,{},Pm);var Nf=Nh(203);qh(79,1,{},Qm);_.K=function(){return xl((new Qo(this.a)).a)};var Of=Nh(79);qh(248,$wnd.Function,{},Vm);_.lb=function(a){return new Wm(a)};qh(94,33,{},Wm);_.mb=function(){return fl(),zl((new Po(el.a)).a)};_.componentWillUnmount=aq;var Rf=Nh(94);qh(252,$wnd.Function,{},Xm);_.lb=function(a){return new Ym(a)};qh(95,33,{},Ym);_.mb=function(){return ql(),xl((new Qo(pl.a)).a)};_.componentWillUnmount=aq;var Sf=Nh(95);qh(264,$wnd.Function,{},Zm);_.lb=function(a){return new $m(a)};qh(98,33,{},$m);_.mb=function(){return Fl(),Sl((new Ro(El.a)).a)};_.componentWillUnmount=aq;var Vf=Nh(98);qh(253,$wnd.Function,{},_m);_.lb=function(a){return new an(a)};qh(96,33,{},an);_.mb=function(){return cm(),wm((new So(bm.a)).a)};_.componentDidUpdate=function(a){gk(this.a,a)};_.componentWillUnmount=aq;_.shouldComponentUpdate=function(a){return hk(this.a,a)};var Xf=Nh(96);qh(262,$wnd.Function,{},bn);_.lb=function(a){return new cn(a)};qh(97,33,{},cn);_.mb=function(){return Bm(),Im((new To(Am.a)).a)};_.componentWillUnmount=aq;var Zf=Nh(97);qh(265,$wnd.Function,{},dn);_.sb=function(a){Cl(this.a,a)};qh(266,$wnd.Function,{},en);_.rb=function(a){Il(this.a,a)};qh(204,1,{},gn);var _f=Nh(204);qh(82,1,{},hn);_.K=function(){return Sl((new Ro(this.a)).a)};var ag=Nh(82);qh(260,$wnd.Function,{},kn);_.rb=function(a){fm(this.a,a)};qh(254,$wnd.Function,{},ln);_.rb=function(a){On(this.a)};qh(256,$wnd.Function,{},mn);_.tb=function(a){Wl(this.a,this.b)};qh(257,$wnd.Function,{},nn);_.tb=function(a){Xl(this.a,this.b)};qh(258,$wnd.Function,{},on);_.D=function(a){Yl(this.a,a)};qh(259,$wnd.Function,{},pn);_.qb=function(a){_l(this.a,this.b)};qh(261,$wnd.Function,{},qn);_.sb=function(a){Zl(this.a,this.b,a)};qh(206,1,{},un);var cg=Nh(206);qh(80,1,{},vn);_.K=function(){return wm((new So(this.a)).a)};var dg=Nh(80);qh(263,$wnd.Function,{},yn);_.rb=function(a){ym(this.a,a)};qh(83,1,{},An);var fg=Nh(83);qh(81,1,{},Bn);_.K=function(){return Im((new To(this.a)).a)};var gg=Nh(81);qh(54,1,{54:1});_.g=false;var Xg=Nh(54);qh(55,54,{11:1,39:1,55:1,54:1},Pn);_.A=function(){Gn(this)};_.s=function(a){return Hn(this,a)};_.F=Up;_.u=$p;_.B=bq;_.v=function(){var a;return Jh(zg),zg.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var Fn=0;var zg=Nh(55);qh(207,1,pp,Qn);_.C=function(){Kn(this.a)};var ig=Nh(207);qh(208,1,pp,Rn);_.C=function(){Ln(this.a)};var jg=Nh(208);qh(50,124,{50:1});var Rg=Nh(50);qh(71,50,{11:1,71:1,50:1},Zn);_.A=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new $n(this)),qp,null)}};_.s=Mp;_.u=Np;_.B=bq;_.v=function(){var a;return Jh(sg),sg.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.f=0;var sg=Nh(71);qh(129,1,pp,$n);_.C=function(){Wn(this.a)};var kg=Nh(129);qh(130,1,pp,_n);_.C=function(){hc(this.a,this.b,true)};var lg=Nh(130);qh(125,1,kp,ao);_.w=function(){return Xn(this.a)};var mg=Nh(125);qh(131,1,kp,bo);_.w=function(){return Sn(this.a,this.c,this.b)};_.b=false;var ng=Nh(131);qh(126,1,kp,co);_.w=function(){return Zh(hh(Aj(Vn(this.a))))};var og=Nh(126);qh(127,1,kp,eo);_.w=function(){return Zh(hh(Aj(Bj(Vn(this.a),new _o))))};var pg=Nh(127);qh(128,1,kp,fo);_.w=function(){return Yn(this.a)};var qg=Nh(128);qh(102,1,{},io);_.K=function(){return new Zn};var go;var rg=Nh(102);qh(51,1,{51:1});var Wg=Nh(51);qh(72,51,{11:1,72:1,51:1},qo);_.A=function(){if(this.a>=0){this.a=-2;t((J(),J(),I),new G(new to),qp,null)}};_.s=Mp;_.u=Np;_.B=function(){return this.a<0};_.v=function(){var a;return Jh(yg),yg.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.a=0;var yg=Nh(72);qh(137,1,pp,ro);_.C=function(){Nn(this.b,this.a)};var tg=Nh(137);qh(138,1,pp,so);_.C=function(){mo(this.a)};var ug=Nh(138);qh(135,1,pp,to);_.C=Sp;var vg=Nh(135);qh(136,1,pp,uo);_.C=function(){no(this.a,this.b)};_.b=false;var wg=Nh(136);qh(104,1,{},vo);_.K=function(){return new qo(this.a.K())};var xg=Nh(104);qh(52,1,{52:1});var $g=Nh(52);qh(73,52,{11:1,73:1,52:1},Eo);_.A=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new Fo(this)),qp,null)}};_.s=Mp;_.u=Np;_.B=function(){return this.g<0};_.v=function(){var a;return Jh(Gg),Gg.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.g=0;var Gg=Nh(73);qh(147,1,pp,Fo);_.C=function(){zo(this.a)};var Ag=Nh(147);qh(143,1,kp,Go);_.w=function(){var a;return a=Wb(this.a.i),ei(Kp,a)||ei(Hp,a)||ei('',a)?ei(Kp,a)?(Xo(),Uo):ei(Hp,a)?(Xo(),Wo):(Xo(),Vo):(Xo(),Vo)};var Bg=Nh(143);qh(144,1,kp,Ho);_.w=function(){return Ao(this.a)};var Cg=Nh(144);qh(145,1,sp,Io);_.C=function(){Bo(this.a)};var Dg=Nh(145);qh(146,1,sp,Jo);_.C=function(){Co(this.a)};var Eg=Nh(146);qh(107,1,{},Ko);_.K=function(){return new Eo(this.b.K(),this.a.K())};var Fg=Nh(107);qh(106,1,{},No);_.K=function(){return Ch(new bc)};var Lo;var Hg=Nh(106);qh(77,1,{},Oo);var Ng=Nh(77);qh(59,1,{},Po);var Ig=Nh(59);qh(63,1,{},Qo);var Jg=Nh(63);qh(62,1,{},Ro);var Kg=Nh(62);qh(60,1,{},So);var Lg=Nh(60);qh(61,1,{},To);var Mg=Nh(61);qh(37,35,{3:1,31:1,35:1,37:1},Yo);var Uo,Vo,Wo;var Og=Oh(37,Zo);qh(103,1,{},$o);_.K=cq;var Pg=Nh(103);qh(134,1,{},_o);_.gb=function(a){return !Jn(a)};var Qg=Nh(134);qh(140,1,{},ap);_.gb=function(a){return Jn(a)};var Sg=Nh(140);qh(141,1,{},bp);_.D=function(a){Un(this.a,a)};var Tg=Nh(141);qh(139,1,{},cp);_.D=function(a){ko(this.a,a)};_.a=false;var Ug=Nh(139);qh(105,1,{},dp);_.K=cq;var Vg=Nh(105);qh(148,1,{},ep);_.gb=function(a){return xo(this.a,a)};var Yg=Nh(148);qh(108,1,{},fp);_.K=cq;var Zg=Nh(108);var gp=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=lh;jh(wh);mh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();