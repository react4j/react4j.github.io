function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='A740AF660DB1053047058C622BED50E4',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'A740AF660DB1053047058C622BED50E4';function o(){}
function ih(){}
function eh(){}
function Hb(){}
function Hm(){}
function vm(){}
function zm(){}
function Dm(){}
function Lm(){}
function Kc(){}
function Rc(){}
function qj(){}
function rj(){}
function Fk(){}
function Jn(){}
function qo(){}
function Yo(){}
function Zo(){}
function Pc(a){Oc()}
function rm(a){qm=a}
function um(a){tm=a}
function Tm(a){Sm=a}
function cn(a){bn=a}
function gn(a){fn=a}
function rh(){rh=eh}
function qi(){hi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function Hh(a){this.a=a}
function _h(a){this.a=a}
function lb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function cc(a){this.a=a}
function lc(a){this.a=a}
function ei(a){this.a=a}
function fi(a){this.a=a}
function di(a){this.b=a}
function si(a){this.c=a}
function oj(a){this.a=a}
function tj(a){this.a=a}
function Ok(a){this.a=a}
function Rk(a){this.a=a}
function Sk(a){this.a=a}
function Tk(a){this.a=a}
function $k(a){this.a=a}
function al(a){this.a=a}
function bl(a){this.a=a}
function cl(a){this.a=a}
function pl(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function tl(a){this.a=a}
function vl(a){this.a=a}
function Sl(a){this.a=a}
function Vl(a){this.a=a}
function Xl(a){this.a=a}
function am(a){this.a=a}
function bm(a){this.a=a}
function jm(a){this.a=a}
function mm(a){this.a=a}
function nm(a){this.a=a}
function om(a){this.a=a}
function Pm(a){this.a=a}
function Qm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function Ym(a){this.a=a}
function dn(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function on(a){this.a=a}
function qn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Hn(a){this.a=a}
function In(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function go(a){this.a=a}
function ho(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function Ro(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function Kp(){fc(this.c)}
function Mp(){fc(this.b)}
function Ci(){this.a=Li()}
function Qi(){this.a=Li()}
function gc(a){!!a&&a.u()}
function V(a){!!a&&cb(a)}
function w(a){--a.e;D(a)}
function Gp(a){Ui(this,a)}
function Jp(a){Lh(this,a)}
function gb(a){Vb((J(),a))}
function hb(a){Wb((J(),a))}
function jb(a){Xb((J(),a))}
function jc(a,b){Xh(a.e,b)}
function sj(a,b){jj(a.a,b)}
function Kj(a,b){Jj(a,b)}
function pj(a,b){a.a=b}
function Lj(a,b){a.key=b}
function sb(a,b){a.b=Xi(b)}
function so(a,b){Ql(b,a)}
function ro(a,b){$n(a.b,b)}
function xl(a,b){_n(a.j,b)}
function C(a,b){ab(a.f,b.f)}
function Op(){mb(this.a.a)}
function Dp(){return this.a}
function Ip(){return this.b}
function Qg(a){return a.b}
function Oh(a,b){return a===b}
function yl(a,b){return a.g=b}
function Kb(a){a.a=-4&a.a|1}
function Gk(a){a.d=2;fc(a.c)}
function Uk(a){a.c=2;fc(a.b)}
function El(a){a.f=2;fc(a.e)}
function xn(a){R(a.a);cb(a.b)}
function Kk(a){mb(a.b);R(a.a)}
function Rh(a){pc.call(this,a)}
function Fp(){return Bj(this)}
function ki(a,b){return a.a[b]}
function xj(a,b){a.splice(b,1)}
function ec(a,b,c){Wh(a.e,b,c)}
function Nn(a,b,c){ec(a.c,b,c)}
function Mn(a){cb(a.b);cb(a.a)}
function jl(a){mb(a.a);cb(a.b)}
function uh(a){th(a);return a.k}
function Ep(a){return this===a}
function Sc(a,b){return Ah(a,b)}
function K(a,b){O(a);L(a,Xi(b))}
function Yi(a,b){while(a.$(b));}
function Hi(){Hi=eh;Gi=Ji()}
function Hc(){Hc=eh;Gc=new Kc}
function rc(){rc=eh;qc=new o}
function J(){J=eh;I=new F}
function po(){po=eh;oo=new qo}
function xc(){xc=eh;!!(Oc(),Nc)}
function Mh(){mc(this);this.A()}
function Hp(){return Zh(this.a)}
function Lp(){return this.c.i<0}
function Np(){return this.b.i<0}
function W(a){return !!a&&a.c.i<0}
function Zh(a){return a.a.b+a.b.b}
function db(a){J();Wb(a);a.e=-2}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function jj(a,b){pj(a,ij(a.a,b))}
function v(a,b,c){s(a,new H(c),b)}
function ij(a,b){a.N(b);return a}
function Uj(a,b){a.ref=b;return a}
function zn(a){ib(a.b);return a.e}
function Qn(a){ib(a.a);return a.d}
function Fo(a){ib(a.d);return a.f}
function Li(){Hi();return new Gi}
function Xc(a){return new Array(a)}
function Pp(a){return 1==this.a.d}
function Qp(a){return 1==this.a.c}
function Ni(a,b){return a.a.get(b)}
function gi(a,b){this.a=a;this.b=b}
function dc(a,b){this.a=a;this.b=b}
function Fh(a,b){this.a=a;this.b=b}
function mj(a,b){this.a=a;this.b=b}
function Sj(a,b){this.a=a;this.b=b}
function ul(a,b){this.a=a;this.b=b}
function Wl(a,b){this.a=a;this.b=b}
function Yl(a,b){this.a=a;this.b=b}
function Zl(a,b){this.a=a;this.b=b}
function $l(a,b){this.a=a;this.b=b}
function _l(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function Zm(a,b){this.a=a;this.b=b}
function $m(a,b){this.a=a;this.b=b}
function Bk(a,b){Fh.call(this,a,b)}
function vj(a,b,c){a.splice(b,0,c)}
function Vj(a,b){a.href=b;return a}
function Kn(a,b){this.a=a;this.b=b}
function io(a,b){this.a=a;this.b=b}
function yo(a,b){this.a=a;this.b=b}
function zo(a,b){this.b=a;this.a=b}
function Wo(a,b){Fh.call(this,a,b)}
function An(a){yn(a,(ib(a.b),a.e))}
function an(){this.a=Mj((Jm(),Im))}
function en(){this.a=Mj((Nm(),Mm))}
function pm(){this.a=Mj((xm(),wm))}
function sm(){this.a=Mj((Bm(),Am))}
function Rm(){this.a=Mj((Fm(),Em))}
function Rn(a){Ql(a,(ib(a.a),!a.d))}
function Rb(a){return !a.d?a:Rb(a.d)}
function Vh(a){return !a?null:a.W()}
function jd(a){return a==null?null:a}
function Wi(a){return a!=null?r(a):0}
function gd(a){return typeof a===cp}
function Yg(){Wg==null&&(Wg=[])}
function Fc(){uc!=0&&(uc=0);wc=-1}
function Ec(a){$wnd.clearTimeout(a)}
function hi(a){a.a=Uc(ae,ep,1,0,5,1)}
function Yh(a){a.a=new Ci;a.b=new Qi}
function kb(a){this.c=new qi;this.b=a}
function Fj(){Fj=eh;Cj=new o;Ej=new o}
function Yj(a,b){a.checked=b;return a}
function ck(a,b){a.value=b;return a}
function Zj(a,b){a.onBlur=b;return a}
function Wj(a,b){a.onClick=b;return a}
function $j(a,b){a.onChange=b;return a}
function wj(a,b){uj(b,0,a,0,b.length)}
function bc(a,b){_b(a,b,false);hb(a.d)}
function Il(a){mb(a.b);R(a.c);cb(a.a)}
function rb(a){J();qb(a);ub(a,2,true)}
function ib(a){var b;Sb((J(),b=Nb,b),a)}
function Fb(a){this.d=Xi(a);this.b=100}
function kh(a){this.b=Xi(a);this.a=this}
function P(){this.a=Uc(ae,ep,1,100,5,1)}
function B(a,b,c){return t(a,c,2048,b)}
function Zc(a,b,c){return {l:a,m:b,h:c}}
function Nh(a,b){return a.charCodeAt(b)}
function ed(a,b){return a!=null&&cd(a,b)}
function Qh(a){return !a?'null':''+a.a}
function Bj(a){return a.$H||(a.$H=++Aj)}
function X(a){return !(!!a&&1==(a.c&7))}
function hd(a){return typeof a==='string'}
function _j(a,b){a.onKeyDown=b;return a}
function Xj(a){a.autoFocus=true;return a}
function th(a){if(a.k!=null){return}Ch(a)}
function ac(a,b){jc(b.c,a);ed(b,9)&&b.s()}
function pc(a){this.c=a;mc(this);this.A()}
function hj(a,b){cj.call(this,a);this.a=b}
function Jj(a,b){for(var c in a){b(c)}}
function zj(b,c,d){try{b[c]=d}catch(a){}}
function A(a,b,c){t(a,new G(b),c,null)}
function _k(a,b){return new Zk(Xi(b),a.a)}
function ql(a,b){return new ol(Xi(b),a.a)}
function fd(a){return typeof a==='boolean'}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function sn(a){ph((oh(),nh),zp,a.d,false)}
function tn(a){qh((oh(),nh),zp,a.d,false)}
function Bn(a){A((J(),J(),I),new Hn(a),wp)}
function Un(a){A((J(),J(),I),new Xn(a),wp)}
function Nl(a){A((J(),J(),I),new bm(a),wp)}
function to(a){A((J(),J(),I),new Ao(a),wp)}
function Ho(a){W((ib(a.d),a.f))&&Jo(a,null)}
function eo(a){return Ih(S(a.e).a-S(a.a).a)}
function u(a,b){return new xb(Xi(a),null,b)}
function yc(a,b,c){return a.apply(b,c);var d}
function nc(a,b){a.b=b;b!=null&&zj(b,np,a)}
function Ui(a,b){while(a.S()){sj(b,a.T())}}
function Eb(a){while(true){if(!Db(a)){break}}}
function wi(){this.a=new Ci;this.b=new Qi}
function Ti(a,b,c){this.a=a;this.b=b;this.c=c}
function Qk(a,b,c){this.a=a;this.b=b;this.c=c}
function Ul(a,b,c){this.a=a;this.b=b;this.c=c}
function lm(a,b,c){this.a=a;this.b=b;this.c=c}
function $(a,b,c){Kb(Xi(c));K(a.a[b],Xi(c))}
function Ei(a,b){var c;c=a[rp];c.call(a,b)}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function kl(a,b){A((J(),J(),I),new ul(a,b),wp)}
function Jl(a,b){A((J(),J(),I),new _l(a,b),wp)}
function Ll(a,b){A((J(),J(),I),new Zl(a,b),wp)}
function Ml(a,b){A((J(),J(),I),new Yl(a,b),wp)}
function Pl(a,b){A((J(),J(),I),new Wl(a,b),wp)}
function _n(a,b){A((J(),J(),I),new io(a,b),wp)}
function wo(a,b){A((J(),J(),I),new yo(a,b),wp)}
function ll(a,b){var c;c=b.target;nl(a,c.value)}
function xh(a){var b;b=wh(a);Eh(a,b);return b}
function mc(a){a.d&&a.b!==mp&&a.A();return a}
function dk(a,b){a.onDoubleClick=b;return a}
function ii(a,b){a.a[a.a.length]=b;return true}
function jo(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new bb;this.a=new Fb(this.f)}
function bo(a){Lh(new ei(a.g),new cc(a));Yh(a.g)}
function lh(a){Xi(a);return ed(a,44)?a:new kh(a)}
function Oc(){Oc=eh;var a;!Qc();a=new Rc;Nc=a}
function Kh(){Kh=eh;Jh=Uc(Yd,ep,32,256,0,1)}
function ph(a,b,c,d){a.addEventListener(b,c,d)}
function qh(a,b,c,d){a.removeEventListener(b,c,d)}
function kj(a,b,c){if(a.a._(c)){a.b=true;b.v(c)}}
function Gb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function $i(a){if(!a.d){a.d=a.b.M();a.c=a.b.O()}}
function bi(a){var b;b=a.a.T();a.b=ai(a);return b}
function zh(a){var b;b=wh(a);b.j=a;b.e=1;return b}
function Lc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function mi(a,b){var c;c=a.a[b];xj(a.a,b);return c}
function Mi(a,b){return !(a.a.get(b)===undefined)}
function Pk(a,b){return new Nk(Xi(b),a.a,a.b,a.c)}
function Tl(a,b){return new Rl(Xi(b),a.a,a.b,a.c)}
function km(a,b){return new im(Xi(b),a.a,a.b,a.c)}
function fj(a){bj(a);return new hj(a,new nj(a.a))}
function Mk(a){return B((J(),J(),I),a.b,new Tk(a))}
function Yk(a){return B((J(),J(),I),a.a,new cl(a))}
function ml(a){return B((J(),J(),I),a.a,new sl(a))}
function Ol(a){return B((J(),J(),I),a.b,new Vl(a))}
function hm(a){return B((J(),J(),I),a.a,new nm(a))}
function Lk(a){return rh(),S(a.e.b).a>0?true:false}
function co(a){return rh(),0==S(a.e).a?true:false}
function Co(a){return Oh(Bp,a)||Oh(Cp,a)||Oh('',a)}
function Wc(a){return Array.isArray(a)&&a.ib===ih}
function dd(a){return !Array.isArray(a)&&a.ib===ih}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function pb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function Zn(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function aj(a){if(!a.b){bj(a);a.c=true}else{aj(a.b)}}
function Hk(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function Vk(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function Fl(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Ij(){if(Dj==256){Cj=Ej;Ej=new o;Dj=0}++Dj}
function Xi(a){if(a==null){throw Qg(new Mh)}return a}
function $h(a,b){if(b){return Uh(a.a,b)}return false}
function ej(a,b){bj(a);return new hj(a,new lj(b,a.a))}
function yn(a,b){A((J(),J(),I),new Kn(a,b),75497472)}
function cm(a,b){var c;c=b.target;wo(a.e,c.checked)}
function nl(a,b){var c;c=a.f;if(b!=c){a.f=b;hb(a.b)}}
function Ql(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function oi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function bk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function yh(a,b){var c;c=wh(a);Eh(a,c);c.e=b?8:0;return c}
function Cn(a,b){var c;c=a.e;if(b!=c){a.e=Xi(b);hb(a.b)}}
function wn(a){var b;T(a.a);b=S(a.a);Oh(a.f,b)&&Cn(a,b)}
function Eo(a){mb(a.e);mb(a.a);R(a.b);R(a.c);cb(a.d)}
function Bl(a,b){Jo(a.k,b);A((J(),J(),I),new Wl(a,b),wp)}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function $n(a,b){return t((J(),J(),I),new jo(a,b),wp,null)}
function vi(a,b){return jd(a)===jd(b)||a!=null&&p(a,b)}
function Zi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function _i(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function nj(a){Zi.call(this,a.Z(),a.Y()&-6);this.a=a}
function cj(a){if(!a){this.b=null;new qi}else{this.b=a}}
function Bh(a){if(a.K()){return null}var b=a.j;return _g[b]}
function Vg(a){if(gd(a)){return a|0}return a.l|a.m<<22}
function wl(a,b){var c;if(S(a.c)){c=b.target;Ql(a,c.value)}}
function Lh(a,b){var c,d;for(d=a.M();d.S();){c=d.T();b.v(c)}}
function jn(a){return new Qk(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function nn(a){return new Ul(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function pn(a){return new lm(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function nb(a){C((J(),J(),I),a);0==(a.f.a&jp)&&D((null,I))}
function Al(a,b){A((J(),J(),I),new Wl(a,b),wp);Jo(a.k,null)}
function uo(a,b){var c;gj(ao(a.b),(c=new qi,c)).L(new _o(b))}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function gh(a){function b(){}
;b.prototype=a||{};return new b}
function bj(a){if(a.b){bj(a.b)}else if(a.c){throw Qg(new Gh)}}
function Ob(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);qb(a.e)}}
function Xo(){Vo();return Yc(Sc(Eg,1),ep,34,0,[So,Uo,To])}
function Dc(a){xc();$wnd.setTimeout(function(){throw a},0)}
function yi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ah(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.F(b))}
function bh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function zi(a,b){var c;return xi(b,yi(a,b==null?0:(c=r(b),c|0)))}
function ao(a){ib(a.d);return new hj(null,new _i(new ei(a.g),0))}
function un(a,b){b.preventDefault();A((J(),J(),I),new In(a),wp)}
function ak(a){a.placeholder='What needs to be done?';return a}
function oc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Kl(a){return rh(),Fo(a.k)==a.n.props['a']?true:false}
function xm(){xm=eh;var a;wm=(a=fh(vm.prototype.fb,vm,[]),a)}
function Bm(){Bm=eh;var a;Am=(a=fh(zm.prototype.fb,zm,[]),a)}
function Fm(){Fm=eh;var a;Em=(a=fh(Dm.prototype.fb,Dm,[]),a)}
function Jm(){Jm=eh;var a;Im=(a=fh(Hm.prototype.fb,Hm,[]),a)}
function Nm(){Nm=eh;var a;Mm=(a=fh(Lm.prototype.fb,Lm,[]),a)}
function ri(a){hi(this);wj(this.a,Th(a,Uc(ae,ep,1,Zh(a.a),5,1)))}
function Di(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function ym(a){$wnd.React.Component.call(this,a);this.a=Pk(qm,this)}
function Cm(a){$wnd.React.Component.call(this,a);this.a=_k(tm,this)}
function Gm(a){$wnd.React.Component.call(this,a);this.a=ql(Sm,this)}
function Km(a){$wnd.React.Component.call(this,a);this.a=Tl(bn,this)}
function Om(a){$wnd.React.Component.call(this,a);this.a=km(fn,this)}
function lj(a,b){Zi.call(this,b.Z(),b.Y()&-16449);this.a=a;this.c=b}
function eb(a,b){var c,d;ii(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Jo(a,b){var c;c=a.f;if(!(b==c||!!b&&On(b,c))){a.f=b;hb(a.d)}}
function Bc(a,b,c){var d;d=zc();try{return yc(a,b,c)}finally{Cc(d)}}
function Rj(a,b,c){!Oh(c,'key')&&!Oh(c,'ref')&&(a[c]=b[c],undefined)}
function ic(a){gc(a.g);!!a.e&&hc(a);V(a.a);V(a.c);gc(a.b);gc(a.f)}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Ri(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function xo(a){this.b=Xi(a);J();this.a=new kc(0,null,null,false,false)}
function dj(a){var b;aj(a);b=0;while(a.a.$(new rj)){b=Rg(b,1)}return b}
function gj(a,b){var c;aj(a);c=new qj;c.a=b;a.a.R(new tj(c));return c.a}
function vo(a){var b;gj(ej(ao(a.b),new Zo),(b=new qi,b)).L(new $o(a.b))}
function dl(a){var b;b=Ph((ib(a.b),a.f));if(b.length>0){ro(a.e,b);nl(a,'')}}
function Xh(a,b){return hd(b)?b==null?Bi(a.a,null):Pi(a.b,b):Bi(a.a,b)}
function Do(a,b){return (Vo(),To)==a||(So==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function kd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Cc(a){a&&Jc((Hc(),Gc));--uc;if(a){if(wc!=-1){Ec(wc);wc=-1}}}
function Lb(b){try{b.b.u()}catch(a){a=Pg(a);if(!ed(a,5))throw Qg(a)}}
function Ac(b){xc();return function(){return Bc(b,this,arguments);var a}}
function tc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Si(a){if(a.a.c!=a.c){return Ni(a.a,a.b.value[0])}return a.b.value[1]}
function li(a,b,c){for(;c<a.a.length;++c){if(vi(b,a.a[c])){return c}}return -1}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function ji(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function Go(a){var b,c;return b=S(a.b),gj(ej(ao(a.j),new ap(b)),(c=new qi,c))}
function Wh(a,b,c){return hd(b)?b==null?Ai(a.a,null,c):Oi(a.b,b,c):Ai(a.a,b,c)}
function yj(a,b){return Tc(b)!=10&&Yc(q(b),b.hb,b.__elementTypeId$,Tc(b),a),a}
function rn(a,b){a.f=b;Oh(b,S(a.a))&&Cn(a,b);vn(b);A((J(),J(),I),new In(a),wp)}
function _m(a,b){Lj(a.a,Qh(b?Ih(b.c.d):null));Xi(b);a.a.props['a']=b;return a.a}
function On(a,b){var c;if(ed(b,49)){c=b;return a.c.d==c.c.d}else{return false}}
function ni(a,b){var c;c=li(a,b,0);if(c==-1){return false}xj(a.a,c);return true}
function Uc(a,b,c,d,e,f){var g;g=Vc(e,d);e!=10&&Yc(Sc(a,f),b,c,e,g);return g}
function fc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new lc(a)),67108864,null)}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new lb(a)),0,null);!!a.b&&mb(a.b)}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||mb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function Ic(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Mc(b,c)}while(a.a);a.a=c}}
function Jc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Mc(b,c)}while(a.b);a.b=c}}
function bb(){var a;this.a=Uc(pd,ep,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function ci(a){this.d=a;this.c=new Ri(this.d.b);this.a=this.c;this.b=ai(this)}
function oh(){oh=eh;mh=$wnd.window.document;nh=$wnd.window.window}
function Gh(){pc.call(this,"Stream already terminated, can't be modified or used")}
function Xg(){Yg();var a=Wg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function fh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Eh(a,b){var c;if(!a){return}b.j=a;var d=Bh(b);if(!d){_g[a]=[b];return}d.gb=b}
function Pg(a){var b;if(ed(a,5)){return a}b=a&&a[np];if(!b){b=new sc(a);Pc(b)}return b}
function wh(a){var b;b=new vh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Pi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ei(a.a,b);--a.b}return c}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;ii((!a.b&&(a.b=new qi),a.b),b)}}}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new qi);a.c=c.c}b.d=true;ii(a.c,Xi(b))}
function qb(a){var b,c;for(c=new si(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function ti(a){var b,c,d;d=0;for(c=new ci(a.a);c.b;){b=bi(c);d=d+(b?r(b):0);d=d|0}return d}
function Mj(a){var b;b=Oj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Nj(a,b,c,d){var e;e=Oj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Xi(d);return e}
function Pj(a){var b;return Nj($wnd.React.StrictMode,null,null,(b={},b[sp]=Xi(a),b))}
function Tc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function el(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new tl(a),wp)}}
function tb(b){if(b){try{b.u()}catch(a){a=Pg(a);if(ed(a,5)){J()}else throw Qg(a)}}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function Yn(a,b,c){var d;d=new Vn(b,c);Nn(d,a,new dc(a,d));Wh(a.g,Ih(d.c.d),d);hb(a.d);return d}
function Sh(a,b){var c,d;for(d=new ci(b.a);d.b;){c=bi(d);if(!$h(a,c)){return false}}return true}
function Sg(a){var b;b=a.h;if(b==0){return a.l+a.m*kp}if(b==1048575){return a.l+a.m*kp-pp}return a}
function ai(a){if(a.a.S()){return true}if(a.a!=a.c){return false}a.a=new Di(a.d.a);return a.a.S()}
function Ug(a){var b,c,d,e;e=a;d=0;if(e<0){e+=pp;d=1048575}c=kd(e/kp);b=kd(e-c*kp);return Zc(b,c,d)}
function xi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(vi(a,c.V())){return c}}return null}
function Yc(a,b,c,d,e){e.gb=a;e.hb=b;e.ib=ih;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Oi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function _b(a,b,c){var d;d=Xh(a.g,b?Ih(b.c.d):null);if(null!=d){jc(b.c,a);c&&!!b&&fc(b.c);hb(a.d)}}
function Mb(a,b){this.b=Xi(a);this.a=b|0|(0==(b&6291456)?kp:0)|(0!=(b&229376)?0:98304)}
function xb(a,b,c){wb.call(this,null,a,b,c|(!a?262144:gp)|(0==(c&6291456)?!a?jp:kp:0)|0|0|0)}
function zl(a,b,c){27==c.which?A((J(),J(),I),new $l(a,b),wp):13==c.which&&A((J(),J(),I),new Yl(a,b),wp)}
function hn(){this.a=lh((po(),po(),oo));this.b=lh(new Bo(this.a));this.c=lh(new Qo(this.a))}
function Vo(){Vo=eh;So=new Wo('ACTIVE',0);Uo=new Wo('COMPLETED',1);To=new Wo('ALL',2)}
function $g(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function sc(a){rc();mc(this);this.b=a;a!=null&&zj(a,np,this);this.c=a==null?'null':hh(a);this.a=a}
function vh(){this.g=sh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function S(a){ib(a.e);vb(a.f)&&ob(a.f);if(a.b){if(ed(a.b,8)){throw Qg(a.b)}else{throw Qg(a.b)}}return a.k}
function Io(a){var b;b=S(a.i.a);Oh(Bp,b)||Oh(Cp,b)||Oh('',b)?yn(a.i,b):Co(zn(a.i))?Bn(a.i):yn(a.i,'')}
function mb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Bb(a)),67108864,null);!!a.a&&R(a.a);Ib(a.f);a.c=a.c&-8|1}}
function Ek(){if(!Dk){Dk=(++(J(),J(),I).e,new Hb);$wnd.Promise.resolve(null).then(fh(Fk.prototype.D,Fk,[]))}}
function Ck(){Ak();return Yc(Sc(Oe,1),ep,7,0,[ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk])}
function q(a){return hd(a)?ce:gd(a)?Ud:fd(a)?Sd:dd(a)?a.gb:Wc(a)?a.gb:a.gb||Array.isArray(a)&&Sc(Ld,1)||Ld}
function r(a){return hd(a)?Hj(a):gd(a)?kd(a):fd(a)?a?1231:1237:dd(a)?a.q():Wc(a)?Bj(a):!!a&&!!a.hashCode?a.hashCode():Bj(a)}
function p(a,b){return hd(a)?Oh(a,b):gd(a)?a===b:fd(a)?a===b:dd(a)?a.o(b):Wc(a)?a===b:!!a&&!!a.equals?a.equals(b):jd(a)===jd(b)}
function fb(a,b){var c,d;d=a.c;ni(d,b);!!a.b&&gp!=(a.b.c&hp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function $c(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return Zc(c&4194303,d&4194303,e&1048575)}
function Rg(a,b){var c;if(gd(a)&&gd(b)){c=a+b;if(-17592186044416<c&&c<pp){return c}}return Sg($c(gd(a)?Ug(a):a,gd(b)?Ug(b):b))}
function Ih(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Kh(),Jh)[b];!c&&(c=Jh[b]=new Hh(a));return c}return new Hh(a)}
function hh(a){var b;if(Array.isArray(a)&&a.ib===ih){return uh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Hj(a){Fj();var b,c,d;c=':'+a;d=Ej[c];if(d!=null){return kd(d)}d=Cj[c];b=d==null?Gj(a):kd(d);Ij();Ej[c]=b;return b}
function ui(a){var b,c,d;d=1;for(c=new si(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function hc(a){var b,c,d;for(c=new si(new ri(new _h(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.V();ed(d,9)&&d.t()||b.W().u()}}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=mi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function Dl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Pl(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&gp)?Lb(a):a.b.u();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function yb(a,b){wb.call(this,a,new zb(a),null,b|(gp==(b&hp)?0:524288)|(0==(b&6291456)?gp==(b&hp)?kp:jp:0)|0|268435456|0)}
function Cl(a,b){var c;c=(ib(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new zo(b,c),wp);Jo(a.k,null);Ql(a,c)}else{_n(a.j,b)}}
function Dh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function pi(a,b){var c,d;d=a.a.length;b.length<d&&(b=yj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Th(a,b){var c,d,e;e=Zh(a.a);b.length<e&&(b=yj(new Array(e),b));d=new ci(a.a);for(c=0;c<e;++c){b[c]=bi(d)}b.length>e&&(b[e]=null);return b}
function Tj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function zc(){var a;if(uc!=0){a=tc();if(a-vc>2000){vc=a;wc=$wnd.setTimeout(Fc,10)}}if(uc++==0){Ic((Hc(),Gc));return true}return false}
function Qc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a,b,c,d,e){var f;this.d=a;this.e=d?new wi:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new kb((J(),null)),f):null;this.c=null}
function U(a,b,c,d){this.c=Xi(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new yb(this,d);this.e=new kb(this.f);gp==(d&hp)&&nb(this.f)}
function Vn(a,b){var c,d,e;this.e=Xi(a);this.d=b;J();c=++Ln;this.c=new kc(c,null,new Wn(this),true,true);this.b=(e=new kb(null),e);this.a=(d=new kb(null),d)}
function Zk(a,b){var c;this.d=Xi(b);this.n=Xi(a);J();c=++Xk;this.b=new kc(c,null,new $k(this),false,false);this.a=new xb(null,Xi(new bl(this)),vp)}
function cd(a,b){if(hd(a)){return !!bd[b]}else if(a.hb){return !!a.hb[b]}else if(gd(a)){return !!ad[b]}else if(fd(a)){return !!_c[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new si(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Wb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new si(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&ub(b,6,true)}}}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new si(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Ph(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Vc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{Zb(b,d);try{f=(c.a.u(),null)}finally{$b()}return f}catch(a){a=Pg(a);if(ed(a,5)){e=a;throw Qg(e)}else throw Qg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.r()}else{Zb(b,e);try{g=c.r()}finally{$b()}}return g}catch(a){a=Pg(a);if(ed(a,5)){f=a;throw Qg(f)}else throw Qg(a)}finally{D(b)}}
function vn(a){var b;if(0==a.length){b=(oh(),nh).location.pathname+(''+nh.location.search);nh.history.pushState('',mh.title,b)}else{(oh(),nh).location.hash=a}}
function Db(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Jb(c);return true}
function Zg(b,c,d,e){Yg();var f=Wg;$moduleName=c;$moduleBase=d;Og=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{bp(g)()}catch(a){b(c,a)}}else{bp(g)()}}
function ol(a,b){var c,d;this.e=Xi(b);this.n=Xi(a);J();c=++il;this.c=new kc(c,null,new pl(this),false,false);this.b=(d=new kb(null),d);this.a=new xb(null,Xi(new vl(this)),vp)}
function im(a,b,c,d){var e;this.d=Xi(b);this.e=Xi(c);this.f=Xi(d);this.n=Xi(a);J();e=++gm;this.b=new kc(e,null,new jm(this),false,false);this.a=new xb(null,Xi(new mm(this)),vp)}
function Oj(a,b){var c;c=new $wnd.Object;c.$$typeof=Xi(a);c.type=Xi(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ji(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ki()}}
function Wk(a){var b,c,d;a.c=0;Ek();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),Qj('span',Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['todo-count'])),[Qj('strong',null,[c]),' '+d+' left']));return b}
function ah(){_g={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Mc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].jb()&&(c=Lc(c,g)):g[0].jb()}catch(a){a=Pg(a);if(ed(a,5)){d=a;xc();Dc(ed(d,35)?d.B():d)}else throw Qg(a)}}return c}
function hl(a){var b;a.d=0;Ek();b=Qj(xp,Xj($j(_j(ck(ak(Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['new-todo']))),(ib(a.b),a.f)),fh(Pm.prototype.db,Pm,[a])),fh(Qm.prototype.cb,Qm,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.r();if(!(jd(e)===jd(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Pg(a);if(ed(a,11)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Qg(c)}else throw Qg(a)}}
function Ai(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=xi(b,e);if(f){return f.X(c)}}e[e.length]=new gi(b,c);++a.b;return null}
function uj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Gj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Nh(a,c++)}b=b|0;return b}
function ob(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.u()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Pg(a);if(ed(a,5)){J()}else throw Qg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Uc(ae,ep,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function jh(){var a;a=new hn;rm(jn(new kn(a)));um(new al((new ln(a)).a.a.C()));cn(nn(new on(a)));gn(pn(new qn(a)));Tm(new rl((new mn(a)).a.b.C()));$wnd.ReactDOM.render(Pj([(new en).a]),(oh(),mh).getElementById('app'),null)}
function Nk(a,b,c,d){var e;this.e=Xi(b);this.f=Xi(c);this.g=Xi(d);this.n=Xi(a);J();e=++Jk;this.c=new kc(e,null,new Ok(this),false,false);this.a=new U(new Rk(this),null,null,136478720);this.b=new xb(null,Xi(new Sk(this)),vp)}
function Rl(a,b,c,d){var e,f;this.j=Xi(b);Xi(c);this.k=Xi(d);this.n=Xi(a);J();e=++Hl;this.e=new kc(e,null,new Sl(this),false,false);this.a=(f=new kb(null),f);this.c=new U(new Xl(this),null,null,136478720);this.b=new xb(null,Xi(new am(this)),vp);Pl(this,this.n.props['a'])}
function wb(a,b,c,d){this.b=new qi;this.f=new Mb(new Ab(this),d&6520832|262144|gp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&jp)&&D((null,I)))}
function Bi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(vi(b,e.V())){if(d.length==1){d.length=0;Ei(a.a,g)}else{d.splice(h,1)}--a.b;return e.W()}}return null}
function dh(a,b,c){var d=_g,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=_g[b]),gh(h));_.hb=c;!b&&(_.ib=ih);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.gb=f)}
function Dn(){var a,b;this.d=new Ro(this);this.f=this.e=(b=(oh(),nh).location.hash,null==b?'':b.substr(1));J();this.c=new kc(0,null,new En(this),false,false);this.b=(a=new kb(null),a);this.a=new U(new Jn,new Fn(this),new Gn(this),35749888)}
function Ch(a){if(a.J()){var b=a.c;b.K()?(a.k='['+b.j):!b.J()?(a.k='[L'+b.H()+';'):(a.k='['+b.H());a.b=b.G()+'[]';a.i=b.I()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Dh('.',[c,Dh('$',d)]);a.b=Dh('.',[c,Dh('.',d)]);a.i=d[d.length-1]}
function Uh(a,b){var c,d,e;c=b.V();e=b.W();d=hd(c)?c==null?Vh(zi(a.a,null)):Ni(a.b,c):Vh(zi(a.a,c));if(!(jd(e)===jd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(hd(c)?c==null?!!zi(a.a,null):Mi(a.b,c):!!zi(a.a,c))){return false}return true}
function Qj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Kj(b,fh(Sj.prototype.ab,Sj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[sp]=c[0],undefined):(d[sp]=c,undefined));return Nj(a,e,f,d)}
function fo(){var a;this.g=new wi;J();this.f=new kc(0,new ho(this),new go(this),false,false);this.d=(a=new kb(null),a);this.c=new U(new ko(this),null,null,Ap);this.e=new U(new lo(this),null,null,Ap);this.a=new U(new mo(this),null,null,Ap);this.b=new U(new no(this),null,null,Ap)}
function Ko(a){var b;this.j=Xi(a);this.i=new Dn;J();this.g=new kc(0,null,new Lo(this),false,false);this.d=(b=new kb(null),b);this.b=new U(new Mo(this),null,null,Ap);this.c=new U(new No(this),null,null,Ap);this.e=u(new Oo(this),413138944);this.a=u(new Po(this),681574400);D((null,I))}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new si(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Pg(a);if(!ed(a,5))throw Qg(a)}if(6==(b.c&7)){return true}}}}}qb(b);return false}
function Ii(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ub(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){jb(a.a.e);tb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;tb((e=d.i,e));d.k=null}ji(a.b,new Cb(a));a.b.a=Uc(ae,ep,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&tb((f=a.a.g,f))}}
function Ak(){Ak=eh;ek=new Bk(tp,0);fk=new Bk('checkbox',1);gk=new Bk('color',2);hk=new Bk('date',3);ik=new Bk('datetime',4);jk=new Bk('email',5);kk=new Bk('file',6);lk=new Bk('hidden',7);mk=new Bk('image',8);nk=new Bk('month',9);ok=new Bk(cp,10);pk=new Bk('password',11);qk=new Bk('radio',12);rk=new Bk('range',13);sk=new Bk('reset',14);tk=new Bk('search',15);uk=new Bk('submit',16);vk=new Bk('tel',17);wk=new Bk('text',18);xk=new Bk('time',19);yk=new Bk('url',20);zk=new Bk('week',21)}
function fm(a){var b,c,d;a.c=0;Ek();d=Qj('div',null,[Qj('div',null,[Qj(yp,Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[yp])),[Qj('h1',null,['todos']),(new Rm).a]),S(a.d.c)?null:Qj('section',Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[yp])),[Qj(xp,$j(bk(Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['toggle-all'])),(Ak(),fk)),fh(dn.prototype.cb,dn,[a])),null),Qj('ul',Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['todo-list'])),(b=gj(Xi(fj(S(a.f.c).Q())),(c=new qi,c)),pi(b,Xc(b.a.length))))]),S(a.d.c)?null:(new pm).a])]);return d}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ki(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&oi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ki(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){mi(a.b,g)}e&&sb(a.e,a.b)}else{e&&sb(a.e,new qi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&gp!=(k.b.c&hp)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function Ik(a){var b,c;a.d=0;Ek();c=(b=S(a.g.b),Qj('footer',Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['footer'])),[(new sm).a,Qj('ul',Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['filters'])),[Qj('li',null,[Qj('a',Vj(Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[(Vo(),To)==b?up:null])),'#'),['All'])]),Qj('li',null,[Qj('a',Vj(Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[So==b?up:null])),'#active'),['Active'])]),Qj('li',null,[Qj('a',Vj(Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[Uo==b?up:null])),'#completed'),['Completed'])])]),S(a.a)?Qj(tp,Wj(Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['clear-completed'])),fh(om.prototype.eb,om,[a])),['Clear Completed']):null]));return c}
function Gl(a){var b,c,d,e;a.f=0;Ek();b=a.n.props['a'];if(b.c.i<0){return null}c=(d=a.n.props['a'],e=(ib(d.a),d.d),Qj('li',Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,[e?'checked':null,S(a.c)?'editing':null])),[Qj('div',Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['view'])),[Qj(xp,$j(Yj(bk(Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['toggle'])),(Ak(),fk)),e),fh(Vm.prototype.cb,Vm,[d])),null),Qj('label',dk(new $wnd.Object,fh(Wm.prototype.eb,Wm,[a,d])),[(ib(d.b),d.e)]),Qj(tp,Wj(Tj(new $wnd.Object,Yc(Sc(ce,1),ep,2,6,['destroy'])),fh(Xm.prototype.eb,Xm,[a,d])),null)]),Qj(xp,_j($j(Zj(ck(Tj(Uj(new $wnd.Object,fh(Ym.prototype.v,Ym,[a])),Yc(Sc(ce,1),ep,2,6,['edit'])),(ib(a.a),a.d)),fh(Zm.prototype.bb,Zm,[a,d])),fh(Um.prototype.cb,Um,[a])),fh($m.prototype.db,$m,[a,d])),null)]));return c}
function Ki(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[rp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ii()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[rp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var cp='number',dp={14:1},ep={3:1,4:1},fp={9:1},gp=1048576,hp=1835008,ip={6:1},jp=2097152,kp=4194304,lp={22:1},mp='__noinit__',np='__java$exception',op={3:1,11:1,8:1,5:1},pp=17592186044416,qp={40:1},rp='delete',sp='children',tp='button',up='selected',vp=1411518464,wp=142606336,xp='input',yp='header',zp='hashchange',Ap=136413184,Bp='active',Cp='completed';var _,_g,Wg,Og=-1;ah();dh(1,null,{},o);_.o=Ep;_.p=function(){return this.gb};_.q=Fp;_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};var _c,ad,bd;dh(54,1,{},vh);_.F=function(a){var b;b=new vh;b.e=4;a>1?(b.c=Ah(this,a-1)):(b.c=this);return b};_.G=function(){th(this);return this.b};_.H=function(){return uh(this)};_.I=function(){th(this);return this.i};_.J=function(){return (this.e&4)!=0};_.K=function(){return (this.e&1)!=0};_.e=0;_.g=0;var sh=1;var ae=xh(1);var Td=xh(54);dh(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var od=xh(81);dh(36,1,dp,G);_.r=function(){return this.a.u(),null};var md=xh(36);dh(82,1,{},H);var nd=xh(82);var I;dh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var pd=xh(43);dh(231,1,fp);var sd=xh(231);dh(20,231,fp,U);_.s=function(){R(this)};_.t=Dp;_.a=false;_.d=0;var qd=xh(20);dh(143,1,{270:1},bb);var rd=xh(143);dh(18,231,{9:1,18:1},kb);_.s=function(){cb(this)};_.t=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var ud=xh(18);dh(178,1,ip,lb);_.u=function(){db(this.a)};var td=xh(178);dh(19,231,{9:1,19:1},xb,yb);_.s=function(){mb(this)};_.t=function(){return 1==(this.c&7)};_.c=0;var zd=xh(19);dh(179,1,lp,zb);_.u=function(){Q(this.a)};var vd=xh(179);dh(180,1,ip,Ab);_.u=function(){ob(this.a)};var wd=xh(180);dh(181,1,ip,Bb);_.u=function(){rb(this.a)};var xd=xh(181);dh(182,1,{},Cb);_.v=function(a){pb(this.a,a)};var yd=xh(182);dh(144,1,{},Fb);_.a=0;_.b=0;_.c=0;var Ad=xh(144);dh(183,1,fp,Hb);_.s=function(){Gb(this)};_.t=Dp;_.a=false;var Bd=xh(183);dh(65,231,{9:1,65:1},Mb);_.s=function(){Ib(this)};_.t=function(){return 2==(3&this.a)};_.a=0;var Cd=xh(65);dh(187,1,{},Yb);_.a=0;var Nb;var Dd=xh(187);dh(156,1,{});var Gd=xh(156);dh(149,1,{},cc);_.v=function(a){ac(this.a,a)};var Ed=xh(149);dh(150,1,ip,dc);_.u=function(){bc(this.a,this.b)};var Fd=xh(150);dh(157,156,{});var Hd=xh(157);dh(17,1,fp,kc);_.s=function(){fc(this)};_.t=function(){return this.i<0};_.d=0;_.i=0;var Jd=xh(17);dh(177,1,ip,lc);_.u=function(){ic(this.a)};var Id=xh(177);dh(5,1,{3:1,5:1});_.w=function(a){return new Error(a)};_.A=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=uh(this.gb),c==null?a:a+': '+c);nc(this,oc(this.w(b)));Pc(this)};_.b=mp;_.d=true;var de=xh(5);dh(11,5,{3:1,11:1,5:1});var Wd=xh(11);dh(8,11,op);var be=xh(8);dh(55,8,op);var Zd=xh(55);dh(76,55,op);var Nd=xh(76);dh(35,76,{35:1,3:1,11:1,8:1,5:1},sc);_.B=function(){return jd(this.a)===jd(qc)?null:this.a};var qc;var Kd=xh(35);var Ld=xh(0);dh(213,1,{});var Md=xh(213);var uc=0,vc=0,wc=-1;dh(90,213,{},Kc);var Gc;var Od=xh(90);var Nc;dh(224,1,{});var Qd=xh(224);dh(77,224,{},Rc);var Pd=xh(77);dh(44,1,{44:1,69:1},kh);_.C=function(){if(this===this.a){this.a=this.b.C();this.b=null}return this.a};var Rd=xh(44);var mh,nh;_c={3:1,72:1,31:1};var Sd=xh(72);dh(41,1,{3:1,41:1});var _d=xh(41);ad={3:1,31:1,41:1};var Ud=xh(223);dh(33,1,{3:1,31:1,33:1});_.o=Ep;_.q=Fp;_.b=0;var Vd=xh(33);dh(78,8,op,Gh);var Xd=xh(78);dh(32,41,{3:1,31:1,32:1,41:1},Hh);_.o=function(a){return ed(a,32)&&a.a==this.a};_.q=Dp;_.a=0;var Yd=xh(32);var Jh;dh(288,1,{});dh(79,55,op,Mh);_.w=function(a){return new TypeError(a)};var $d=xh(79);bd={3:1,71:1,31:1,2:1};var ce=xh(2);dh(292,1,{});dh(57,8,op,Rh);var ee=xh(57);dh(225,1,{39:1});_.L=Jp;_.P=function(){return new _i(this,0)};_.Q=function(){return new hj(null,this.P())};_.N=function(a){throw Qg(new Rh('Add not supported on this collection'))};var fe=xh(225);dh(229,1,{212:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ed(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ci((new _h(d)).a);c.b;){b=bi(c);if(!Uh(this,b)){return false}}return true};_.q=function(){return ti(new _h(this))};var qe=xh(229);dh(142,229,{212:1});var ie=xh(142);dh(228,225,{39:1,237:1});_.P=function(){return new _i(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ed(a,24)){return false}b=a;if(Zh(b.a)!=this.O()){return false}return Sh(this,b)};_.q=function(){return ti(this)};var re=xh(228);dh(24,228,{24:1,39:1,237:1},_h);_.M=function(){return new ci(this.a)};_.O=Hp;var he=xh(24);dh(25,1,{},ci);_.R=Gp;_.T=function(){return bi(this)};_.S=Ip;_.b=false;var ge=xh(25);dh(226,225,{39:1,233:1});_.P=function(){return new _i(this,16)};_.U=function(a,b){throw Qg(new Rh('Add not supported on this list'))};_.N=function(a){this.U(this.O(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ed(a,13)){return false}f=a;if(this.O()!=f.a.length){return false}e=new si(f);for(c=new si(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(jd(b)===jd(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return ui(this)};_.M=function(){return new di(this)};var ke=xh(226);dh(89,1,{},di);_.R=Gp;_.S=function(){return this.a<this.b.a.length};_.T=function(){return ki(this.b,this.a++)};_.a=0;var je=xh(89);dh(59,225,{39:1},ei);_.M=function(){var a;a=new ci((new _h(this.a)).a);return new fi(a)};_.O=Hp;var me=xh(59);dh(141,1,{},fi);_.R=Gp;_.S=function(){return this.a.b};_.T=function(){var a;a=bi(this.a);return a.W()};var le=xh(141);dh(139,1,qp);_.o=function(a){var b;if(!ed(a,40)){return false}b=a;return vi(this.a,b.V())&&vi(this.b,b.W())};_.V=Dp;_.W=Ip;_.q=function(){return Wi(this.a)^Wi(this.b)};_.X=function(a){var b;b=this.b;this.b=a;return b};var ne=xh(139);dh(140,139,qp,gi);var oe=xh(140);dh(230,1,qp);_.o=function(a){var b;if(!ed(a,40)){return false}b=a;return vi(this.b.value[0],b.V())&&vi(Si(this),b.W())};_.q=function(){return Wi(this.b.value[0])^Wi(Si(this))};var pe=xh(230);dh(13,226,{3:1,13:1,39:1,233:1},qi,ri);_.U=function(a,b){vj(this.a,a,b)};_.N=function(a){return ii(this,a)};_.L=function(a){ji(this,a)};_.M=function(){return new si(this)};_.O=function(){return this.a.length};var te=xh(13);dh(16,1,{},si);_.R=Gp;_.S=function(){return this.a<this.c.a.length};_.T=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var se=xh(16);dh(37,142,{3:1,37:1,212:1},wi);var ue=xh(37);dh(62,1,{},Ci);_.L=Jp;_.M=function(){return new Di(this)};_.b=0;var we=xh(62);dh(63,1,{},Di);_.R=Gp;_.T=function(){return this.d=this.a[this.c++],this.d};_.S=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ve=xh(63);var Gi;dh(60,1,{},Qi);_.L=Jp;_.M=function(){return new Ri(this)};_.b=0;_.c=0;var ze=xh(60);dh(61,1,{},Ri);_.R=Gp;_.T=function(){return this.c=this.a,this.a=this.b.next(),new Ti(this.d,this.c,this.d.c)};_.S=function(){return !this.a.done};var xe=xh(61);dh(148,230,qp,Ti);_.V=function(){return this.b.value[0]};_.W=function(){return Si(this)};_.X=function(a){return Oi(this.a,this.b.value[0],a)};_.c=0;var ye=xh(148);dh(197,1,{});_.R=function(a){Yi(this,a)};_.Y=function(){return this.d};_.Z=function(){return this.e};_.d=0;_.e=0;var Be=xh(197);dh(66,197,{});var Ae=xh(66);dh(23,1,{},_i);_.Y=Dp;_.Z=function(){$i(this);return this.c};_.R=function(a){$i(this);this.d.R(a)};_.$=function(a){$i(this);if(this.d.S()){a.v(this.d.T());return true}return false};_.a=0;_.c=0;var Ce=xh(23);dh(196,1,{});_.c=false;var Le=xh(196);dh(28,196,{273:1,28:1},hj);var Ke=xh(28);dh(199,66,{},lj);_.$=function(a){this.b=false;while(!this.b&&this.c.$(new mj(this,a)));return this.b};_.b=false;var Ee=xh(199);dh(202,1,{},mj);_.v=function(a){kj(this.a,this.b,a)};var De=xh(202);dh(198,66,{},nj);_.$=function(a){return this.a.$(new oj(a))};var Ge=xh(198);dh(201,1,{},oj);_.v=function(a){this.a.v(_m(new an,a))};var Fe=xh(201);dh(200,1,{},qj);_.v=function(a){pj(this,a)};var He=xh(200);dh(203,1,{},rj);_.v=function(a){};var Ie=xh(203);dh(204,1,{},tj);_.v=function(a){sj(this,a)};var Je=xh(204);dh(290,1,{});dh(232,1,{});var Me=xh(232);dh(287,1,{});var Aj=0;var Cj,Dj=0,Ej;dh(915,1,{});dh(227,1,{});var Ne=xh(227);dh(272,$wnd.Function,{},Sj);_.ab=function(a){Rj(this.a,this.b,a)};dh(7,33,{3:1,31:1,33:1,7:1},Bk);var ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk;var Oe=yh(7,Ck);var Dk;dh(271,$wnd.Function,{},Fk);_.D=function(a){return Gb(Dk),Dk=null,null};dh(91,227,{});var Af=xh(91);dh(92,91,{});_.d=0;var Ef=xh(92);dh(93,92,fp,Nk);_.s=Kp;_.o=Ep;_.q=Fp;_.t=Lp;var Jk=0;var Ze=xh(93);dh(95,1,ip,Ok);_.u=function(){Kk(this.a)};var Pe=xh(95);dh(94,1,{},Qk);var Qe=xh(94);dh(96,1,dp,Rk);_.r=function(){return Lk(this.a)};var Re=xh(96);dh(97,1,lp,Sk);_.u=function(){Hk(this.a)};var Se=xh(97);dh(98,1,dp,Tk);_.r=function(){return Ik(this.a)};var Te=xh(98);dh(100,227,{});var zf=xh(100);dh(101,100,{});_.c=0;var Df=xh(101);dh(102,101,fp,Zk);_.s=Mp;_.o=Ep;_.q=Fp;_.t=Np;var Xk=0;var Ye=xh(102);dh(104,1,ip,$k);_.u=Op;var Ue=xh(104);dh(103,1,{},al);var Ve=xh(103);dh(105,1,lp,bl);_.u=function(){Vk(this.a)};var We=xh(105);dh(106,1,dp,cl);_.r=function(){return Wk(this.a)};var Xe=xh(106);dh(129,227,{});_.f='';var Mf=xh(129);dh(130,129,{});_.d=0;var Gf=xh(130);dh(131,130,fp,ol);_.s=Kp;_.o=Ep;_.q=Fp;_.t=Lp;var il=0;var ef=xh(131);dh(133,1,ip,pl);_.u=function(){jl(this.a)};var $e=xh(133);dh(132,1,{},rl);var _e=xh(132);dh(135,1,dp,sl);_.r=function(){return hl(this.a)};var af=xh(135);dh(136,1,ip,tl);_.u=function(){dl(this.a)};var bf=xh(136);dh(137,1,ip,ul);_.u=function(){ll(this.a,this.b)};var cf=xh(137);dh(134,1,lp,vl);_.u=function(){Hk(this.a)};var df=xh(134);dh(108,227,{});_.i=false;var Of=xh(108);dh(109,108,{});_.f=0;var If=xh(109);dh(110,109,fp,Rl);_.s=function(){fc(this.e)};_.o=Ep;_.q=Fp;_.t=function(){return this.e.i<0};var Hl=0;var rf=xh(110);dh(112,1,ip,Sl);_.u=function(){Il(this.a)};var ff=xh(112);dh(111,1,{},Ul);var gf=xh(111);dh(115,1,dp,Vl);_.r=function(){return Gl(this.a)};var hf=xh(115);dh(42,1,ip,Wl);_.u=function(){Ql(this.a,zn(this.b))};var jf=xh(42);dh(113,1,dp,Xl);_.r=function(){return Kl(this.a)};var kf=xh(113);dh(58,1,ip,Yl);_.u=function(){Cl(this.a,this.b)};var lf=xh(58);dh(116,1,ip,Zl);_.u=function(){Bl(this.a,this.b)};var mf=xh(116);dh(117,1,ip,$l);_.u=function(){Al(this.a,this.b)};var nf=xh(117);dh(118,1,ip,_l);_.u=function(){wl(this.a,this.b)};var of=xh(118);dh(114,1,lp,am);_.u=function(){Fl(this.a)};var pf=xh(114);dh(119,1,ip,bm);_.u=function(){Dl(this.a)};var qf=xh(119);dh(121,227,{});var Qf=xh(121);dh(122,121,{});_.c=0;var Kf=xh(122);dh(123,122,fp,im);_.s=Mp;_.o=Ep;_.q=Fp;_.t=Np;var gm=0;var wf=xh(123);dh(125,1,ip,jm);_.u=Op;var sf=xh(125);dh(124,1,{},lm);var tf=xh(124);dh(126,1,lp,mm);_.u=function(){Vk(this.a)};var uf=xh(126);dh(127,1,dp,nm);_.r=function(){return fm(this.a)};var vf=xh(127);dh(253,$wnd.Function,{},om);_.eb=function(a){to(this.a.f)};dh(185,1,{},pm);var xf=xh(185);var qm;dh(207,1,{},sm);var yf=xh(207);var tm;dh(254,$wnd.Function,{},vm);_.fb=function(a){return new ym(a)};var wm;dh(99,$wnd.React.Component,{},ym);bh(_g[1],_);_.componentWillUnmount=function(){Gk(this.a)};_.render=function(){return Mk(this.a)};_.shouldComponentUpdate=Pp;var Bf=xh(99);dh(255,$wnd.Function,{},zm);_.fb=function(a){return new Cm(a)};var Am;dh(107,$wnd.React.Component,{},Cm);bh(_g[1],_);_.componentWillUnmount=function(){Uk(this.a)};_.render=function(){return Yk(this.a)};_.shouldComponentUpdate=Qp;var Cf=xh(107);dh(269,$wnd.Function,{},Dm);_.fb=function(a){return new Gm(a)};var Em;dh(138,$wnd.React.Component,{},Gm);bh(_g[1],_);_.componentWillUnmount=function(){Gk(this.a)};_.render=function(){return ml(this.a)};_.shouldComponentUpdate=Pp;var Ff=xh(138);dh(256,$wnd.Function,{},Hm);_.fb=function(a){return new Km(a)};var Im;dh(120,$wnd.React.Component,{},Km);bh(_g[1],_);_.componentDidUpdate=function(a){Nl(this.a)};_.componentWillUnmount=function(){El(this.a)};_.render=function(){return Ol(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Hf=xh(120);dh(266,$wnd.Function,{},Lm);_.fb=function(a){return new Om(a)};var Mm;dh(128,$wnd.React.Component,{},Om);bh(_g[1],_);_.componentWillUnmount=function(){Uk(this.a)};_.render=function(){return hm(this.a)};_.shouldComponentUpdate=Qp;var Jf=xh(128);dh(267,$wnd.Function,{},Pm);_.db=function(a){el(this.a,a)};dh(268,$wnd.Function,{},Qm);_.cb=function(a){kl(this.a,a)};dh(184,1,{},Rm);var Lf=xh(184);var Sm;dh(263,$wnd.Function,{},Um);_.cb=function(a){Jl(this.a,a)};dh(257,$wnd.Function,{},Vm);_.cb=function(a){Un(this.a)};dh(259,$wnd.Function,{},Wm);_.eb=function(a){Ll(this.a,this.b)};dh(260,$wnd.Function,{},Xm);_.eb=function(a){xl(this.a,this.b)};dh(261,$wnd.Function,{},Ym);_.v=function(a){yl(this.a,a)};dh(262,$wnd.Function,{},Zm);_.bb=function(a){Ml(this.a,this.b)};dh(264,$wnd.Function,{},$m);_.db=function(a){zl(this.a,this.b,a)};dh(206,1,{},an);var Nf=xh(206);var bn;dh(265,$wnd.Function,{},dn);_.cb=function(a){cm(this.a,a)};dh(70,1,{},en);var Pf=xh(70);var fn;dh(83,1,{},hn);var Wf=xh(83);dh(84,1,{},kn);var Rf=xh(84);dh(88,1,{},ln);var Sf=xh(88);dh(87,1,{},mn);var Tf=xh(87);dh(85,1,{},on);var Uf=xh(85);dh(86,1,{},qn);var Vf=xh(86);dh(188,1,{});var Dg=xh(188);dh(189,188,fp,Dn);_.s=Kp;_.o=Ep;_.q=Fp;_.t=Lp;var cg=xh(189);dh(190,1,ip,En);_.u=function(){xn(this.a)};var Xf=xh(190);dh(192,1,lp,Fn);_.u=function(){sn(this.a)};var Yf=xh(192);dh(193,1,lp,Gn);_.u=function(){tn(this.a)};var Zf=xh(193);dh(195,1,ip,Hn);_.u=function(){An(this.a)};var $f=xh(195);dh(64,1,ip,In);_.u=function(){wn(this.a)};var _f=xh(64);dh(191,1,dp,Jn);_.r=function(){var a;return a=(oh(),nh).location.hash,null==a?'':a.substr(1)};var ag=xh(191);dh(194,1,ip,Kn);_.u=function(){rn(this.a,this.b)};var bg=xh(194);dh(48,1,{48:1});_.d=false;var Lg=xh(48);dh(49,48,{9:1,274:1,49:1,48:1},Vn);_.s=Kp;_.o=function(a){return On(this,a)};_.q=function(){return this.c.d};_.t=Lp;var Ln=0;var ug=xh(49);dh(208,1,ip,Wn);_.u=function(){Mn(this.a)};var dg=xh(208);dh(209,1,ip,Xn);_.u=function(){Rn(this.a)};var eg=xh(209);dh(45,157,{45:1});var Gg=xh(45);dh(158,45,{9:1,45:1},fo);_.s=function(){fc(this.f)};_.o=Ep;_.q=Fp;_.t=function(){return this.f.i<0};var og=xh(158);dh(160,1,ip,go);_.u=function(){Zn(this.a)};var fg=xh(160);dh(159,1,ip,ho);_.u=function(){bo(this.a)};var gg=xh(159);dh(165,1,ip,io);_.u=function(){_b(this.a,this.b,true)};var hg=xh(165);dh(166,1,dp,jo);_.r=function(){return Yn(this.a,this.c,this.b)};_.b=false;var ig=xh(166);dh(161,1,dp,ko);_.r=function(){return co(this.a)};var jg=xh(161);dh(162,1,dp,lo);_.r=function(){return Ih(Vg(dj(ao(this.a))))};var kg=xh(162);dh(163,1,dp,mo);_.r=function(){return Ih(Vg(dj(ej(ao(this.a),new Yo))))};var lg=xh(163);dh(164,1,dp,no);_.r=function(){return eo(this.a)};var mg=xh(164);dh(145,1,{69:1},qo);_.C=function(){return new fo};var oo;var ng=xh(145);dh(46,1,{46:1});var Kg=xh(46);dh(167,46,{9:1,46:1},xo);_.s=function(){fc(this.a)};_.o=Ep;_.q=Fp;_.t=function(){return this.a.i<0};var tg=xh(167);dh(168,1,ip,yo);_.u=function(){uo(this.a,this.b)};_.b=false;var pg=xh(168);dh(169,1,ip,zo);_.u=function(){Cn(this.b,this.a)};var qg=xh(169);dh(170,1,ip,Ao);_.u=function(){vo(this.a)};var rg=xh(170);dh(146,1,{69:1},Bo);_.C=function(){return new xo(this.a.C())};var sg=xh(146);dh(47,1,{47:1});var Ng=xh(47);dh(171,47,{9:1,47:1},Ko);_.s=function(){fc(this.g)};_.o=Ep;_.q=Fp;_.t=function(){return this.g.i<0};var Bg=xh(171);dh(172,1,ip,Lo);_.u=function(){Eo(this.a)};var vg=xh(172);dh(173,1,dp,Mo);_.r=function(){var a;return a=zn(this.a.i),Oh(Bp,a)?(Vo(),So):Oh(Cp,a)?(Vo(),Uo):(Vo(),To)};var wg=xh(173);dh(174,1,dp,No);_.r=function(){return Go(this.a)};var xg=xh(174);dh(175,1,lp,Oo);_.u=function(){Ho(this.a)};var yg=xh(175);dh(176,1,lp,Po);_.u=function(){Io(this.a)};var zg=xh(176);dh(147,1,{69:1},Qo);_.C=function(){return new Ko(this.a.C())};var Ag=xh(147);dh(186,1,{},Ro);_.handleEvent=function(a){un(this.a,a)};var Cg=xh(186);dh(34,33,{3:1,31:1,33:1,34:1},Wo);var So,To,Uo;var Eg=yh(34,Xo);dh(151,1,{},Yo);_._=function(a){return !Qn(a)};var Fg=xh(151);dh(153,1,{},Zo);_._=function(a){return Qn(a)};var Hg=xh(153);dh(154,1,{},$o);_.v=function(a){_n(this.a,a)};var Ig=xh(154);dh(152,1,{},_o);_.v=function(a){so(this.a,a)};_.a=false;var Jg=xh(152);dh(155,1,{},ap);_._=function(a){return Do(this.a,a)};var Mg=xh(155);var ld=zh('D');var bp=(xc(),Ac);var gwtOnLoad=gwtOnLoad=Zg;Xg(jh);$g('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();