function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='3030D884A3631298205D0E41A39CB8C9',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '3030D884A3631298205D0E41A39CB8C9';function o(){}
function ok(){}
function uh(){}
function qh(){}
function Bb(){}
function Qc(){}
function Xc(){}
function Lj(){}
function Mj(){}
function Wm(){}
function Ym(){}
function $m(){}
function an(){}
function cn(){}
function jo(){}
function uo(){}
function Oo(){}
function _o(){}
function ap(){}
function Qp(){}
function Vc(a){Uc()}
function Fh(){Fh=qh}
function Ii(){zi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function fb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function ub(a){this.a=a}
function cc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function gc(a){this.a=a}
function kc(a){this.a=a}
function Wh(a){this.a=a}
function fi(a){this.a=a}
function ri(a){this.a=a}
function wi(a){this.a=a}
function xi(a){this.a=a}
function vi(a){this.b=a}
function Ki(a){this.c=a}
function Jj(a){this.a=a}
function Oj(a){this.a=a}
function hl(a){this.a=a}
function il(a){this.a=a}
function jl(a){this.a=a}
function kl(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function tl(a){this.a=a}
function vl(a){this.a=a}
function Kl(a){this.a=a}
function Ll(a){this.a=a}
function Nl(a){this.a=a}
function Ol(a){this.a=a}
function Ql(a){this.a=a}
function mm(a){this.a=a}
function nm(a){this.a=a}
function om(a){this.a=a}
function tm(a){this.a=a}
function wm(a){this.a=a}
function Gm(a){this.a=a}
function Hm(a){this.a=a}
function Im(a){this.a=a}
function Lm(a){this.a=a}
function Om(a){this.a=a}
function Rm(a){this.a=a}
function en(a){this.a=a}
function fn(a){this.a=a}
function hn(){this.a={}}
function Nm(){this.a={}}
function Qm(){this.a={}}
function jn(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function pn(a){this.a=a}
function wn(a){this.a=a}
function zn(a){this.a=a}
function Cn(a){this.a=a}
function Rn(a){this.a=a}
function Sn(a){this.a=a}
function _n(a){this.a=a}
function bo(a){this.a=a}
function eo(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function to(a){this.a=a}
function wo(a){this.a=a}
function Go(a){this.a=a}
function Ho(a){this.a=a}
function Io(a){this.a=a}
function Jo(a){this.a=a}
function Ko(a){this.a=a}
function bp(a){this.a=a}
function cp(a){this.a=a}
function dp(a){this.a=a}
function vn(){this.a={}}
function Bn(){this.a={}}
function Kj(a,b){a.a=b}
function Sm(a,b){a.d=b}
function Tm(a,b){a.e=b}
function Um(a,b){a.f=b}
function Vm(a,b){a.g=b}
function xn(a,b){a.k=b}
function yn(a,b){a.n=b}
function lo(a,b){Nn(b,a)}
function C(a,b){yb(a.b,b)}
function $(a){Kb((J(),a))}
function w(a){--a.e;D(a)}
function dl(a){cl();bl=a}
function ol(a){nl();ml=a}
function Dl(a){Cl();Bl=a}
function Dm(a){Cm();Bm=a}
function bm(a){_l();$l=a}
function Mp(a){kj(this,a)}
function Pp(a){$h(this,a)}
function Vp(){jk(this.a)}
function $p(){lk(this.a)}
function Ui(){this.a=bj()}
function gj(){this.a=bj()}
function F(){this.b=new zb}
function J(){J=qh;I=new F}
function pc(){this.b=new Oi}
function mb(a,b){a.b=nj(b)}
function oc(a,b){ni(a.b,b)}
function ko(a,b){Un(a.b,b)}
function Tl(a,b){Vn(a.k,b)}
function Nj(a,b){Dj(a.a,b)}
function ck(a,b,c){a[b]=c}
function ah(a){return a.e}
function Yp(){return this.e}
function Jp(){return this.a}
function Op(){return this.b}
function Sp(){return this.c}
function bi(a,b){return a===b}
function Ul(a,b){return a.g=b}
function Lp(){return Wj(this)}
function Tp(){return this.d<0}
function Zp(){return this.c<0}
function _p(){return this.f<0}
function Zi(){Zi=qh;Yi=_i()}
function wc(){wc=qh;vc=new o}
function Nc(){Nc=qh;Mc=new Qc}
function No(){No=qh;Mo=new Oo}
function io(){io=qh;ho=new jo}
function xh(){xh=qh;wh=new o}
function ro(a){this.b=nj(a)}
function pl(a){nc(a.b);gb(a.a)}
function ab(a){Lb((J(),a))}
function db(a){Mb((J(),a))}
function Uh(a){uc.call(this,a)}
function gi(a){uc.call(this,a)}
function Xm(a){gk.call(this,a)}
function Zm(a){gk.call(this,a)}
function _m(a){gk.call(this,a)}
function bn(a){gk.call(this,a)}
function dn(a){gk.call(this,a)}
function Kp(a){return this===a}
function Up(){return J(),J(),I}
function Np(){return pi(this.a)}
function Wp(){return nk(this.a)}
function Yc(a,b){return Oh(a,b)}
function Ci(a,b){return a.a[b]}
function Ih(a){Hh(a);return a.k}
function Cj(a,b){a.U(b);return a}
function Sj(a,b){a.splice(b,1)}
function mc(a,b,c){mi(a.b,b,c)}
function oj(a,b){while(a.fb(b));}
function Dj(a,b){Kj(a,Cj(a.a,b))}
function Eb(a){Fb(a);!a.d&&Ib(a)}
function Vb(a){bb(a.a);return a.e}
function Wb(a){bb(a.b);return a.g}
function Jn(a){bb(a.b);return a.i}
function Kn(a){bb(a.a);return a.g}
function zo(a){bb(a.d);return a.f}
function qk(a,b){a.ref=b;return a}
function dc(a,b){this.a=a;this.b=b}
function lc(a,b){this.a=a;this.b=b}
function yh(a){this.a=wh;this.b=a}
function Th(a,b){this.a=a;this.b=b}
function yi(a,b){this.a=a;this.b=b}
function _h(){qc(this);this.I()}
function Gj(a,b){this.a=a;this.b=b}
function dj(a,b){return a.a.get(b)}
function pi(a){return a.a.b+a.b.b}
function bd(a){return new Array(a)}
function bj(){Zi();return new Yi}
function X(a){J();Lb(a);a.e=-2}
function Yb(a){Ub(a,(bb(a.b),a.g))}
function Dc(){Dc=qh;!!(Uc(),Tc)}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function jh(){hh==null&&(hh=[])}
function $k(a,b){Th.call(this,a,b)}
function Ml(a,b){this.a=a;this.b=b}
function qm(a,b){this.a=a;this.b=b}
function rm(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function nn(a,b){this.a=a;this.b=b}
function on(a,b){this.a=a;this.b=b}
function qn(a,b){this.a=a;this.b=b}
function rn(a,b){this.a=a;this.b=b}
function ao(a,b){this.a=a;this.b=b}
function vo(a,b){this.a=a;this.b=b}
function so(a,b){this.b=a;this.a=b}
function Lo(a,b){this.b=a;this.a=b}
function Zo(a,b){Th.call(this,a,b)}
function Xl(a,b){Eo(a.n,b);jm(a,b)}
function Hj(a,b){a.D(un(sn(b.e),b))}
function Qj(a,b,c){a.splice(b,0,c)}
function Bk(a,b){a.value=b;return a}
function rk(a,b){a.href=b;return a}
function di(a,b){a.a+=''+b;return a}
function oi(a){a.a=new Ui;a.b=new gj}
function L(a){a.b=0;a.d=0;a.c=false}
function Gb(a){return !a.d?a:Gb(a.d)}
function li(a){return !a?null:a.bb()}
function qd(a){return a==null?null:a}
function mj(a){return a!=null?r(a):0}
function sn(a){return tn(new vn,a)}
function nd(a){return typeof a===gp}
function Rp(){return T(this.e.b).a>0}
function eb(a){this.c=new Ii;this.b=a}
function Kc(a){$wnd.clearTimeout(a)}
function fl(a){nc(a.c);gb(a.b);S(a.a)}
function Hl(a){nc(a.c);gb(a.a);W(a.b)}
function Mn(a){Nn(a,(bb(a.a),!a.g))}
function Wl(a,b){jm(a,b);Eo(a.n,null)}
function A(a,b,c){t(a,new G(b),c,null)}
function Rj(a,b){Pj(b,0,a,0,b.length)}
function jc(a,b){hc(a,b,false);ab(a.d)}
function wk(a,b){a.onBlur=b;return a}
function sk(a,b){a.onClick=b;return a}
function xk(a,b){a.onChange=b;return a}
function uk(a,b){a.checked=b;return a}
function yk(a,b){a.onKeyDown=b;return a}
function zi(a){a.a=$c(ke,jp,1,0,5,1)}
function Q(){this.a=$c(ke,jp,1,100,5,1)}
function bb(a){var b;Hb((J(),b=Cb,b),a)}
function lb(a){J();kb(a);nb(a,2,true)}
function Wj(a){return a.$H||(a.$H=++Vj)}
function V(a){return !(!!a&&1==(a.c&7))}
function ld(a,b){return a!=null&&jd(a,b)}
function ai(a,b){return a.charCodeAt(b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function pd(a){return typeof a==='string'}
function md(a){return typeof a==='boolean'}
function tk(a){a.autoFocus=true;return a}
function vk(a,b){a.defaultValue=b;return a}
function rc(a,b){a.e=b;b!=null&&Uj(b,up,a)}
function Hh(a){if(a.k!=null){return}Qh(a)}
function uc(a){this.f=a;qc(this);this.I()}
function Bj(a,b){wj.call(this,a);this.a=b}
function kj(a,b){while(a.Z()){Nj(b,a.$())}}
function Wi(a,b){var c;c=a[zp];c.call(a,b)}
function u(a,b){return new qb(nj(a),null,b)}
function Zn(a){return Xh(T(a.e).a-T(a.a).a)}
function Ln(a){nc(a.c);W(a.d);W(a.b);W(a.a)}
function Lh(a){var b;b=Kh(a);Sh(a,b);return b}
function Nh(){var a;a=Kh(null);a.e=2;return a}
function qc(a){a.g&&a.e!==tp&&a.I();return a}
function Ck(a,b){a.onDoubleClick=b;return a}
function jj(a,b,c){this.a=a;this.b=b;this.c=c}
function xl(a,b,c){this.a=a;this.b=b;this.c=c}
function ym(a,b,c){this.a=a;this.b=b;this.c=c}
function Km(a,b,c){this.a=a;this.b=b;this.c=c}
function Oi(){this.a=new Ui;this.b=new gj}
function $j(){$j=qh;Xj=new o;Zj=new o}
function Ch(){Ch=qh;Bh=$wnd.window.document}
function Zh(){Zh=qh;Yh=$c(ge,jp,32,256,0,1)}
function Uc(){Uc=qh;var a;!Wc();a=new Xc;Tc=a}
function Uj(b,c,d){try{b[c]=d}catch(a){}}
function Ec(a,b,c){return a.apply(b,c);var d}
function ic(a,b){oc(b.F(),a);ld(b,11)&&b.A()}
function jb(a,b){Z(b,a);b.c.a.length>0||(b.a=4)}
function Rb(a,b){a.i&&b.preventDefault();ac(a)}
function Ai(a,b){a.a[a.a.length]=b;return true}
function tn(a,b){nj(b);ck(a.a,'key',b);return a}
function Ah(a){if(!a){throw ah(new _h)}return a}
function Ab(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function qj(a){if(!a.d){a.d=a.b.T();a.c=a.b.V()}}
function Ej(a,b,c){if(a.a.gb(c)){a.b=true;b.D(c)}}
function co(a,b){this.a=a;this.c=b;this.b=false}
function Ro(a){this.b=a;this.a=new vl(this.b.a)}
function So(a){this.b=a;this.a=new Ql(this.b.b)}
function pj(a,b){this.e=a;this.d=(b&64)!=0?b|hp:b}
function cj(a,b){return !(a.a.get(b)===undefined)}
function el(a){return Fh(),T(a.e.b).a>0?true:false}
function Yn(a){return Fh(),0==T(a.e).a?true:false}
function xo(a){return bi(Ip,a)||bi(Fp,a)||bi('',a)}
function ad(a){return Array.isArray(a)&&a.zb===uh}
function kd(a){return !Array.isArray(a)&&a.zb===uh}
function P(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ei(a,b){var c;c=a.a[b];Sj(a.a,b);return c}
function Gi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ti(a){var b;b=a.a.$();a.b=si(a);return b}
function ul(a){var b;b=new ql;Sm(b,a.a.K());return b}
function nj(a){if(a==null){throw ah(new _h)}return a}
function qi(a,b){if(b){return ji(a.a,b)}return false}
function zj(a){vj(a);return new Bj(a,new Ij(a.a))}
function Gl(a,b){var c;c=b.target;Il(a,c.value)}
function zm(a,b){var c;c=b.target;qo(a.e,c.checked)}
function km(a,b){var c;c=a.i;if(b!=c){a.i=b;ab(a.a)}}
function Nn(a,b){var c;c=a.g;if(b!=c){a.g=b;ab(a.a)}}
function Il(a,b){var c;c=a.f;if(b!=c){a.f=b;ab(a.b)}}
function Pl(a){var b;b=new Jl;Tm(b,a.a.K());return b}
function Ak(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Ni(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function yj(a,b){vj(a);return new Bj(a,new Fj(b,a.a))}
function uj(a){if(!a.b){vj(a);a.c=true}else{uj(a.b)}}
function wj(a){if(!a){this.b=null;new Ii}else{this.b=a}}
function Ij(a){pj.call(this,a.eb(),a.db()&-6);this.a=a}
function dm(a){nc(a.e);gb(a.b);S(a.d);W(a.c);W(a.a)}
function Ao(a){gb(a.e);gb(a.a);S(a.b);S(a.c);W(a.d)}
function mk(a){kk(a);return ld(a,11)&&a.B()?null:a.pb()}
function em(a,b,c,d){return Fh(),am(a,b,c,d)?true:false}
function dk(a,b){null!=b&&a.kb(b,a.q.props,true);a.hb()}
function $b(a,b){var c;c=a.e;if(b!=c){a.e=nj(b);ab(a.a)}}
function _b(a,b){var c;c=a.g;if(b!=c){a.g=nj(b);ab(a.b)}}
function On(a,b){var c;c=a.i;if(b!=c){a.i=nj(b);ab(a.b)}}
function Mh(a,b){var c;c=Kh(a);Sh(a,c);c.e=b?8:0;return c}
function cb(a){var b;J();!!Cb&&!!Cb.e&&Hb((b=Cb,b),a)}
function xb(a){while(true){if(!vb(a)&&!wb(a)){break}}}
function bk(){if(Yj==256){Xj=Zj;Zj=new o;Yj=0}++Yj}
function gh(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function Ph(a){if(a.R()){return null}var b=a.j;return mh[b]}
function jk(a){if(!a.o){a.o=true;a.p||a.q.forceUpdate()}}
function Sl(a,b){var c;if(T(a.d)){c=b.target;km(a,c.value)}}
function sc(a,b){var c;c=Ih(a.xb);return b==null?c:c+': '+b}
function ki(a,b){return b===a?'(this Map)':b==null?wp:th(b)}
function rj(a,b){this.b=a;this.a=(b&4096)==0?b|64|hp:b}
function pm(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function Nb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function Vh(a){this.f=!a?null:sc(a,a.H());qc(this);this.I()}
function $h(a,b){var c,d;for(d=a.T();d.Z();){c=d.$();b.D(c)}}
function Db(a){if(a.e){2==(a.e.c&7)||nb(a.e,4,true);kb(a.e)}}
function zl(a,b){if(13==b.keyCode){b.preventDefault();El(a)}}
function yb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],nj(b))}
function oo(a,b){var c;Aj(Wn(a.b),(c=new Ii,c)).S(new cp(b))}
function Vl(a,b,c){27==c.which?gm(a,b):13==c.which&&im(a,b)}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Mm(a){return $wnd.React.createElement((cl(),al),a.a)}
function Pm(a){return $wnd.React.createElement((nl(),ll),a.a)}
function gn(a){return $wnd.React.createElement((Cl(),Al),a.a)}
function An(a){return $wnd.React.createElement((Cm(),Am),a.a)}
function $o(){Yo();return cd(Yc(Qg,1),jp,37,0,[Vo,Xo,Wo])}
function cl(){cl=qh;var a;al=(a=rh(Wm.prototype.lb,Wm,[]),a)}
function nl(){nl=qh;var a;ll=(a=rh(Ym.prototype.lb,Ym,[]),a)}
function Cl(){Cl=qh;var a;Al=(a=rh($m.prototype.lb,$m,[]),a)}
function _l(){_l=qh;var a;Zl=(a=rh(an.prototype.lb,an,[]),a)}
function Cm(){Cm=qh;var a;Am=(a=rh(cn.prototype.lb,cn,[]),a)}
function sh(a){function b(){}
;b.prototype=a||{};return new b}
function Ob(a,b){Cb=new Nb(Cb,b);a.d=false;Db(Cb);return Cb}
function Qb(a,b){a.j=b;bi(b,(bb(a.a),a.e))&&_b(a,b);Sb(b);ac(a)}
function hb(a){var b;b=(J(),J(),I);yb(b.b,a);0!=(a.c&pp)&&D(b)}
function Oh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.M(b))}
function Qi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ri(a,b){var c;return Pi(b,Qi(a,b==null?0:(c=r(b),c|0)))}
function Wn(a){bb(a.d);return new Bj(null,new rj(new wi(a.g),0))}
function Ji(a){zi(this);Rj(this.a,ii(a,$c(ke,jp,1,pi(a.a),5,1)))}
function Qo(a){this.b=a;this.a=new xl(this.b.a,this.b.b,this.b.c)}
function To(a){this.b=a;this.a=new ym(this.b.a,this.b.b,this.b.c)}
function Uo(a){this.b=a;this.a=new Km(this.b.a,this.b.b,this.b.c)}
function Vi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Xp(){return zo(this.n)==(cb(this.c),this.q.props['a'])}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&hp)?hp:8192)|0|0,b)}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&hp)?hp:8192)|0|0,b)}
function Dh(a,b,c,d){a.addEventListener(b,c,(Fh(),d?true:false))}
function Eh(a,b,c,d){a.removeEventListener(b,c,(Fh(),d?true:false))}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function zh(a){xh();Ah(a);if(ld(a,46)){return a}return new yh(a)}
function zk(a){a.placeholder='What needs to be done?';return a}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function oh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Eo(a,b){var c;c=a.f;if(!(b==c||!!b&&In(b,c))){a.f=b;ab(a.d)}}
function Y(a,b){var c,d;Ai(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Co(a){var b;b=(bb(a.d),a.f);!!b&&!!b&&b.f<0&&Eo(a,null)}
function xj(a){var b;uj(a);b=0;while(a.a.fb(new Mj)){b=bh(b,1)}return b}
function Aj(a,b){var c;uj(a);c=new Lj;c.a=b;a.a.Y(new Oj(c));return c.a}
function sj(a,b){!a.a?(a.a=new fi(a.d)):di(a.a,a.b);di(a.a,b);return a}
function N(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Fj(a,b){pj.call(this,b.eb(),b.db()&-16449);this.a=a;this.c=b}
function hj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function tj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function ni(a,b){return pd(b)?b==null?Ti(a.a,null):fj(a.b,b):Ti(a.a,b)}
function yo(a,b){return (Yo(),Wo)==a||(Vo==a?(bb(b.a),!b.g):(bb(b.a),b.g))}
function fm(a){return Fh(),zo(a.n)==(cb(a.c),a.q.props['a'])?true:false}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function yl(a){var b;b=ci((bb(a.b),a.f));if(b.length>0){ko(a.e,b);Il(a,'')}}
function no(a){var b;Aj(yj(Wn(a.b),new ap),(b=new Ii,b)).S(new bp(a.b))}
function nk(a){var b;a.o=false;if(a.nb()){return null}else{b=a.jb();return b}}
function xm(a){var b;b=new lm;xn(b,a.a.K());a.b.K();yn(b,a.c.K());return b}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function Bi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.D(c)}}
function Bo(a){var b,c;return b=T(a.b),Aj(yj(Wn(a.j),new dp(b)),(c=new Ii,c))}
function Hn(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Rn(a)),op,null)}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function un(a,b){ck(a.a,(_l(),'a'),b);return $wnd.React.createElement(Zl,a.a)}
function ij(a){if(a.a.c!=a.c){return dj(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{xb(a.b)}finally{a.c=false}}}}
function W(a){if(-2!=a.e){t((J(),J(),I),new G(new fb(a)),0,null);!!a.b&&gb(a.b)}}
function S(a){if(!a.a){a.a=true;a.g=null;a.b=null;W(a.d);2==(a.e.c&7)||gb(a.e)}}
function Xb(a){Eh((Ch(),$wnd.window.window),rp,a.f,false);nc(a.c);W(a.b);W(a.a)}
function ui(a){this.d=a;this.c=new hj(this.d.b);this.a=this.c;this.b=si(this)}
function Di(a,b,c){for(;c<a.a.length;++c){if(Ni(b,a.a[c])){return c}}return -1}
function Fi(a,b){var c;c=Di(a,b,0);if(c==-1){return false}Sj(a.a,c);return true}
function fk(a,b){var c;if(b){c=a.r;a.r=false;return !c}else{a.r=true;return true}}
function ek(a,b){var c;c=null!=b&&a.kb(a.q.props,b,false);c||(a.r=false);return c}
function wl(a){var b;b=new gl;Tm(b,a.a.K());Um(b,a.b.K());Vm(b,a.c.K());return b}
function Jm(a){var b;b=new Fm;Sm(b,a.a.K());Tm(b,a.b.K());Um(b,a.c.K());return b}
function Kh(a){var b;b=new Jh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Sh(a,b){var c;if(!a){return}b.j=a;var d=Ph(b);if(!d){mh[a]=[b];return}d.xb=b}
function vb(a){var b;if(0==P(a.c)){return false}else{b=O(a.c);!!b&&b.A();return true}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function mi(a,b,c){return pd(b)?b==null?Si(a.a,null,c):ej(a.b,b,c):Si(a.a,b,c)}
function Tj(a,b){return Zc(b)!=10&&cd(q(b),b.yb,b.__elementTypeId$,Zc(b),a),a}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===fp||typeof a==='function')&&!(a.zb===uh)}
function lh(a,b){typeof window===fp&&typeof window['$gwt']===fp&&(window['$gwt'][a]=b)}
function Hb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Ai((!a.b&&(a.b=new Ii),a.b),b)}}}
function Jb(a,b){var c;if(!a.c){c=Gb(a);!c.c&&(c.c=new Ii);a.c=c.c}b.d=true;Ai(a.c,nj(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);N(a,nj(b))}
function fj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Wi(a.a,b);--a.b}return c}
function rh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function _g(a){var b;if(ld(a,4)){return a}b=a&&a[up];if(!b){b=new yc(a);Vc(b)}return b}
function Li(a){var b,c,d;d=0;for(c=new ui(a.a);c.b;){b=ti(c);d=d+(b?r(b):0);d=d|0}return d}
function hi(a,b){var c,d;for(d=new ui(b.a);d.b;){c=ti(d);if(!qi(a,c)){return false}}return true}
function kb(a){var b,c;for(c=new Ki(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function ih(){jh();var a=hh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Pb(){var a;try{Eb(Cb);J()}finally{a=Cb.d;!a&&((J(),J(),I).d=true);Cb=Cb.d}}
function lk(a){var b;b=(++a.ob().e,new Bb);try{a.p=true;ld(a,11)&&a.A()}finally{Ab(b)}}
function Xn(a){$h(new wi(a.g),new kc(a));oi(a.g);S(a.c);S(a.e);S(a.a);S(a.b);W(a.d)}
function Tn(a,b,c){var d;d=new Qn(b,c);mc(d.c,a,new lc(a,d));mi(a.g,Xh(d.e),d);ab(a.d);return d}
function hc(a,b,c){var d;d=ni(a.g,b?Xh(b.e):null);if(null!=d){oc(b.c,a);c&&!!b&&Hn(b);ab(a.d)}}
function Do(a){var b;b=Vb(a.i);bi(Ip,b)||bi(Fp,b)||bi('',b)?Ub(a.i,b):xo(Wb(a.i))?Zb(a.i):Ub(a.i,'')}
function Z(a,b){var c,d;d=a.c;Fi(d,b);d.a.length==0&&!!a.b&&lp!=(a.b.c&mp)&&(a.d||Jb((J(),c=Cb,c),a))}
function Pi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Ni(a,c.ab())){return c}}return null}
function fh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=xp;d=1048575}c=rd(e/pp);b=rd(e-c*pp);return dd(b,c,d)}
function dh(a){var b;b=a.h;if(b==0){return a.l+a.m*pp}if(b==1048575){return a.l+a.m*pp-xp}return a}
function si(a){if(a.a.Z()){return true}if(a.a!=a.c){return false}a.a=new Vi(a.d.a);return a.a.Z()}
function T(a){bb(a.d);ob(a.e)&&ib(a.e);if(a.b){if(ld(a.b,5)){throw ah(a.b)}else{throw ah(a.b)}}return a.g}
function am(a,b,c,d){var e,f;e=false;f=fk(a,d);if(!(b['a']===c['a'])){f&&ab(a.c);e=true}return e||a.o}
function cd(a,b,c,d,e){e.xb=a;e.yb=b;e.zb=uh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function ej(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Yl(a,b){var c;c=(bb(a.a),a.i);if(null!=c&&c.length!=0){po(b,c);Eo(a.n,null);km(a,c)}else{Vn(a.k,b)}}
function In(a,b){var c;if(a===b){return true}else if(null==b||!ld(b,53)){return false}else{c=b;return a.e==c.e}}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function gk(a){$wnd.React.Component.call(this,a);this.a=this.mb();this.a.q=nj(this);this.a.ib()}
function Jh(){this.g=Gh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function yc(a){wc();qc(this);this.e=a;a!=null&&Uj(a,up,this);this.f=a==null?wp:th(a);this.a='';this.b=a;this.a=''}
function ql(){nl();++hk;this.b=new pc;this.a=new qb(null,nj((J(),new rl(this))),Cp);D((null,I))}
function Fm(){Cm();++hk;this.b=new pc;this.a=new qb(null,nj((J(),new Gm(this))),Cp);D((null,I))}
function Yo(){Yo=qh;Vo=new Zo('ACTIVE',0);Xo=new Zo('COMPLETED',1);Wo=new Zo('ALL',2)}
function gb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new tb(a)),op,null);!!a.a&&S(a.a);a.c=a.c&-8|1}}
function kk(a){if(!ik){ik=(++a.ob().e,new Bb);$wnd.Promise.resolve(null).then(rh(ok.prototype.L,ok,[]))}}
function vj(a){if(a.b){vj(a.b)}else if(a.c){throw ah(new Uh("Stream already terminated, can't be modified or used"))}}
function q(a){return pd(a)?ne:nd(a)?ce:md(a)?ae:kd(a)?a.xb:ad(a)?a.xb:a.xb||Array.isArray(a)&&Yc(Ud,1)||Ud}
function r(a){return pd(a)?ak(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.u():ad(a)?Wj(a):!!a&&!!a.hashCode?a.hashCode():Wj(a)}
function Xh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Zh(),Yh)[b];!c&&(c=Yh[b]=new Wh(a));return c}return new Wh(a)}
function th(a){var b;if(Array.isArray(a)&&a.zb===uh){return Ih(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function ak(a){$j();var b,c,d;c=':'+a;d=Zj[c];if(d!=null){return rd(d)}d=Xj[c];b=d==null?_j(a):rd(d);bk();Zj[c]=b;return b}
function Mi(a){var b,c,d;d=1;for(c=new Ki(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function nc(a){var b,c;if(!a.a){for(c=new Ki(new Ji(new wi(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.C()}a.a=true}}
function Tb(a){var b,c;c=(b=(Ch(),$wnd.window.window).location.hash,null==b?'':b.substr(1));$b(a,c);bi(a.j,c)&&_b(a,c)}
function U(a,b){this.c=nj(a);this.f=null;this.g=null;this.e=new rb(this,b);this.d=new eb(this.e);lp==(b&mp)&&hb(this.e)}
function pb(a,b,c,d){this.b=new Ii;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&hb(this)}
function Po(){this.a=zh((io(),io(),ho));this.b=zh(new wo(this.a));this.d=zh((No(),No(),Mo));this.c=zh(new Lo(this.a,this.d))}
function zb(){this.c=new Q;this.d=$c(vd,jp,20,5,0,1);this.d[0]=new Q;this.d[1]=new Q;this.d[2]=new Q;this.d[3]=new Q;this.d[4]=new Q}
function gl(){cl();++hk;this.c=new pc;this.a=new U((J(),new hl(this)),136486912);this.b=new qb(null,nj(new jl(this)),Cp);D((null,I))}
function Jl(){Cl();var a;++hk;this.c=new pc;this.b=(a=new eb((J(),null)),a);this.a=new qb(null,nj(new Nl(this)),Cp);D((null,I))}
function _k(){Zk();return cd(Yc(bf,1),jp,10,0,[Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk])}
function bh(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<xp){return c}}return dh(ed(nd(a)?fh(a):a,nd(b)?fh(b):b))}
function p(a,b){return pd(a)?bi(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.s(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function Rl(a){var b;b=T(a.d);if(!a.j&&b){a.j=true;jm(a,(cb(a.c),a.q.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function Rh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Hi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Tj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function pk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.yb){return !!a.yb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function O(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function qb(a,b,c){pb.call(this,null,a,b,c|(!a?262144:lp)|(a?hp:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:pp)|(0!=(c&229376)?0:98304)|0|0|0)}
function Mb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&nb(b,5,true)}}}
function Lb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Ki(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&nb(b,6,true)}}}
function Kb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?nb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function ci(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ib(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=Ei(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&nb(c.b,3,true);++b}}}return b}
function Qn(a,b){var c,d,e;this.i=nj(a);this.g=b;this.e=Gn++;this.d=(d=new eb((J(),null)),d);this.c=new pc;this.b=(e=new eb(null),e);this.a=(c=new eb(null),c)}
function Zb(b){var c;try{A((J(),J(),I),new ec(b),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){c=a;throw ah(c)}else if(ld(a,4)){c=a;throw ah(new Vh(c))}else throw ah(a)}}
function ac(b){var c;try{A((J(),J(),I),new fc(b),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){c=a;throw ah(c)}else if(ld(a,4)){c=a;throw ah(new Vh(c))}else throw ah(a)}}
function El(b){var c;try{A((J(),J(),I),new Ll(b),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){c=a;throw ah(c)}else if(ld(a,4)){c=a;throw ah(new Vh(c))}else throw ah(a)}}
function Pn(b){var c;try{A((J(),J(),I),new Sn(b),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){c=a;throw ah(c)}else if(ld(a,4)){c=a;throw ah(new Vh(c))}else throw ah(a)}}
function mo(b){var c;try{A((J(),J(),I),new to(b),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){c=a;throw ah(c)}else if(ld(a,4)){c=a;throw ah(new Vh(c))}else throw ah(a)}}
function po(b,c){var d;try{A((J(),J(),I),new so(b,c),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function qo(b,c){var d;try{A((J(),J(),I),new vo(b,c),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function cm(b,c){var d;try{A((J(),J(),I),new vm(b,c),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function gm(b,c){var d;try{A((J(),J(),I),new um(b,c),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function hm(b,c){var d;try{A((J(),J(),I),new sm(b,c),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function im(b,c){var d;try{A((J(),J(),I),new rm(b,c),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function jm(b,c){var d;try{A((J(),J(),I),new qm(b,c),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function Fl(b,c){var d;try{A((J(),J(),I),new Ml(b,c),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function Vn(b,c){var d;try{A((J(),J(),I),new ao(b,c),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function Ub(b,c){var d;try{A((J(),J(),I),new dc(b,c),75505664)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function Un(b,c){var d;try{return t((J(),J(),I),new co(b,c),sp,null)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function kh(b,c,d,e){jh();var f=hh;$moduleName=c;$moduleBase=d;$g=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ep(g)()}catch(a){b(c,a)}}else{ep(g)()}}
function rb(a,b){pb.call(this,a,new sb(a),null,b|(lp==(b&mp)?0:524288)|(0!=(b&6291456)?0:lp==(b&mp)?pp:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function vh(){var a;a=new Po;dl(new Om(a));ol(new Rm(a));bm(new wn(a));Dm(new Cn(a));Dl(new jn(a));$wnd.ReactDOM.render(An(new Bn),(Ch(),Bh).getElementById('todoapp'),null)}
function _i(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return aj()}}
function $n(){var a;this.g=new Oi;this.d=(a=new eb((J(),null)),a);this.c=new U(new bo(this),Hp);this.e=new U(new eo(this),Hp);this.a=new U(new fo(this),Hp);this.b=new U(new go(this),Hp)}
function lm(){_l();var a,b;++hk;this.e=new pc;this.c=(b=new eb((J(),null)),b);this.a=(a=new eb(null),a);this.d=new U(new tm(this),136486912);this.b=new qb(null,nj(new wm(this)),Cp);D((null,I))}
function Fo(a,b){var c;this.j=nj(a);this.i=nj(b);this.d=(c=new eb((J(),null)),c);this.b=new U(new Ho(this),Hp);this.c=new U(new Io(this),Hp);this.e=u(new Jo(this),413155328);this.a=u(new Ko(this),681590784);D((null,I))}
function ii(a,b){var c,d,e,f,g;g=pi(a.a);b.length<g&&(b=Tj(new Array(g),b));e=(f=new ui((new ri(a.a)).a),new xi(f));for(d=0;d<g;++d){b[d]=(c=ti(e.a),c.bb())}b.length>g&&(b[g]=null);return b}
function nh(){mh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Ab()&&(c=Rc(c,g)):g[0].Ab()}catch(a){a=_g(a);if(ld(a,4)){d=a;Dc();Jc(ld(d,40)?d.J():d)}else throw ah(a)}}return c}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?wp:od(b)?b==null?null:b.name:pd(b)?'String':Ih(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.g;try{d=b.c.w();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;$(b.d)}}catch(a){a=_g(a);if(ld(a,12)){c=a;if(!b.b){b.g=null;b.b=c;$(b.d)}throw ah(c)}else throw ah(a)}}
function Pj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Si(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Pi(b,e);if(f){return f.cb(c)}}e[e.length]=new yi(b,c);++a.b;return null}
function _j(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ai(a,c++)}b=b|0;return b}
function M(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=$c(ke,jp,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=hp==(d&hp)?c.w():c.w()}else{Ob(b,e);try{g=hp==(d&hp)?c.w():c.w()}finally{Pb()}}return g}catch(a){a=_g(a);if(ld(a,4)){f=a;throw ah(f)}else throw ah(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=hp==(d&hp)?(c.a.C(),null):(c.a.C(),null)}else{Ob(b,e);try{g=hp==(d&hp)?(c.a.C(),null):(c.a.C(),null)}finally{Pb()}}return g}catch(a){a=_g(a);if(ld(a,4)){f=a;throw ah(f)}else throw ah(a)}finally{D(b)}}
function Sb(a){var b;if(0==a.length){b=(Ch(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Bh.title,b)}else{(Ch(),$wnd.window.window).location.hash=a}}
function ib(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.C()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=_g(a);if(ld(a,4)){J()}else throw ah(a)}}}
function Ti(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ni(b,e.ab())){if(d.length==1){d.length=0;Wi(a.a,g)}else{d.splice(h,1)}--a.b;return e.bb()}}return null}
function ph(a,b,c){var d=mh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=mh[b]),sh(h));_.yb=c;!b&&(_.zb=uh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.xb=f)}
function Qh(a){if(a.Q()){var b=a.c;b.R()?(a.k='['+b.j):!b.Q()?(a.k='[L'+b.O()+';'):(a.k='['+b.O());a.b=b.N()+'[]';a.i=b.P()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Rh('.',[c,Rh('$',d)]);a.b=Rh('.',[c,Rh('.',d)]);a.i=d[d.length-1]}
function bc(){var a,b,c;this.f=new gc(this);this.c=new pc;this.b=(c=new eb((J(),null)),c);this.a=(b=new eb(null),b);Dh((Ch(),$wnd.window.window),rp,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function ji(a,b){var c,d,e;c=b.ab();e=b.bb();d=pd(c)?c==null?li(Ri(a.a,null)):dj(a.b,c):li(Ri(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Ri(a.a,null):cj(a.b,c):!!Ri(a.a,c))){return false}return true}
function ob(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ki(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=_g(a);if(!ld(a,4))throw ah(a)}if(6==(b.c&7)){return true}}}}}kb(b);return false}
function $i(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function nb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){db(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}Bi(a.b,new ub(a));a.b.a=$c(ke,jp,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function wb(a){var b,c,d,e,f,g,h,i;d=P(a.d[0]);c=P(a.d[1]);g=P(a.d[2]);e=P(a.d[3]);f=P(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;L(a.d[0]);L(a.d[1]);L(a.d[2]);L(a.d[3]);L(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=O(b);h.c&=-513;ib(h);return true}
function Zk(){Zk=qh;Dk=new $k(Ap,0);Ek=new $k('checkbox',1);Fk=new $k('color',2);Gk=new $k('date',3);Hk=new $k('datetime',4);Ik=new $k('email',5);Jk=new $k('file',6);Kk=new $k('hidden',7);Lk=new $k('image',8);Mk=new $k('month',9);Nk=new $k(gp,10);Ok=new $k('password',11);Pk=new $k('radio',12);Qk=new $k('range',13);Rk=new $k('reset',14);Sk=new $k('search',15);Tk=new $k('submit',16);Uk=new $k('tel',17);Vk=new $k('text',18);Wk=new $k('time',19);Xk=new $k('url',20);Yk=new $k('week',21)}
function Fb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ci(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Gi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Z(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&nb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ci(a.b,g);if(-1==k.e){k.e=0;Y(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ei(a.b,g)}e&&mb(a.e,a.b)}else{e&&mb(a.e,new Ii)}if(V(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&lp!=(b.e.c&mp)&&Jb(a,k)}}
function aj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[zp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!$i()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[zp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var fp='object',gp='number',hp=16384,ip={15:1},jp={3:1,6:1},kp={11:1},lp=1048576,mp=1835008,np={8:1},op=67108864,pp=4194304,qp={30:1},rp='hashchange',sp=142614528,tp='__noinit__',up='__java$exception',vp={3:1,12:1,5:1,4:1},wp='null',xp=17592186044416,yp={44:1},zp='delete',Ap='button',Bp='selected',Cp=1478635520,Dp={11:1,39:1},Ep='input',Fp='completed',Gp='header',Hp=136421376,Ip='active';var _,mh,hh,$g=-1;nh();ph(1,null,{},o);_.s=Kp;_.t=function(){return this.xb};_.u=Lp;_.v=function(){var a;return Ih(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.s(a)};_.hashCode=function(){return this.u()};_.toString=function(){return this.v()};var fd,gd,hd;ph(55,1,{},Jh);_.M=function(a){var b;b=new Jh;b.e=4;a>1?(b.c=Oh(this,a-1)):(b.c=this);return b};_.N=function(){Hh(this);return this.b};_.O=function(){return Ih(this)};_.P=function(){Hh(this);return this.i};_.Q=function(){return (this.e&4)!=0};_.R=function(){return (this.e&1)!=0};_.v=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Hh(this),this.k)};_.e=0;_.g=0;var Gh=1;var ke=Lh(1);var be=Lh(55);ph(89,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var ud=Lh(89);ph(16,1,ip,G);_.w=function(){return this.a.C(),null};var sd=Lh(16);ph(90,1,{},H);var td=Lh(90);var I;ph(20,1,{20:1},Q);_.b=0;_.c=false;_.d=0;var vd=Lh(20);ph(228,1,kp);_.v=function(){var a;return Ih(this.xb)+'@'+(a=r(this)>>>0,a.toString(16))};var xd=Lh(228);ph(21,228,kp,U);_.A=function(){S(this)};_.B=Jp;_.a=false;var wd=Lh(21);ph(17,228,{11:1,17:1},eb);_.A=function(){W(this)};_.B=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=Lh(17);ph(151,1,np,fb);_.C=function(){X(this.a)};var yd=Lh(151);ph(19,228,{11:1,19:1},qb,rb);_.A=function(){gb(this)};_.B=function(){return 1==(this.c&7)};_.c=0;var Dd=Lh(19);ph(152,1,qp,sb);_.C=function(){R(this.a)};var Ad=Lh(152);ph(153,1,np,tb);_.C=function(){lb(this.a)};var Bd=Lh(153);ph(154,1,{},ub);_.D=function(a){jb(this.a,a)};var Cd=Lh(154);ph(115,1,{},zb);_.a=0;_.b=100;_.e=0;var Ed=Lh(115);ph(71,1,kp,Bb);_.A=function(){Ab(this)};_.B=Jp;_.a=false;var Fd=Lh(71);ph(160,1,{},Nb);_.v=function(){var a;return Hh(Gd),Gd.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.a=0;var Cb;var Gd=Lh(160);ph(51,1,{51:1});_.e='';_.g='';_.i=true;_.j='';var Nd=Lh(51);ph(155,51,{11:1,51:1,39:1},bc);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new cc(this)),op,null)}};_.s=Kp;_.F=Sp;_.u=Lp;_.B=Tp;_.v=function(){var a;return Hh(Ld),Ld.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.d=0;var Ld=Lh(155);ph(156,1,np,cc);_.C=function(){Xb(this.a)};var Hd=Lh(156);ph(157,1,np,dc);_.C=function(){Qb(this.a,this.b)};var Id=Lh(157);ph(158,1,np,ec);_.C=function(){Yb(this.a)};var Jd=Lh(158);ph(159,1,np,fc);_.C=function(){Tb(this.a)};var Kd=Lh(159);ph(138,1,{},gc);_.handleEvent=function(a){Rb(this.a,a)};var Md=Lh(138);ph(117,1,{});var Qd=Lh(117);ph(127,1,{},kc);_.D=function(a){ic(this.a,a)};var Od=Lh(127);ph(128,1,np,lc);_.C=function(){jc(this.a,this.b)};var Pd=Lh(128);ph(118,117,{});var Rd=Lh(118);ph(27,1,kp,pc);_.A=function(){nc(this)};_.B=Jp;_.a=false;var Sd=Lh(27);ph(4,1,{3:1,4:1});_.G=function(a){return new Error(a)};_.H=function(){return this.f};_.I=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Ih(this.xb),c==null?a:a+': '+c);rc(this,tc(this.G(b)));Vc(this)};_.v=function(){return sc(this,this.H())};_.e=tp;_.g=true;var oe=Lh(4);ph(12,4,{3:1,12:1,4:1});var ee=Lh(12);ph(5,12,vp);var le=Lh(5);ph(56,5,vp);var he=Lh(56);ph(86,56,vp);var Wd=Lh(86);ph(40,86,{40:1,3:1,12:1,5:1,4:1},yc);_.H=function(){xc(this);return this.c};_.J=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Td=Lh(40);var Ud=Lh(0);ph(211,1,{});var Vd=Lh(211);var Ac=0,Bc=0,Cc=-1;ph(98,211,{},Qc);var Mc;var Xd=Lh(98);var Tc;ph(222,1,{});var Zd=Lh(222);ph(87,222,{},Xc);var Yd=Lh(87);ph(46,1,{46:1},yh);_.K=function(){var a,b;b=this.a;if(qd(b)===qd(wh)){b=this.a;if(qd(b)===qd(wh)){b=this.b.K();a=this.a;if(qd(a)!==qd(wh)&&qd(a)!==qd(b)){throw ah(new Uh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}this.a=b;this.b=null}}return b};var wh;var $d=Lh(46);var Bh;ph(84,1,{81:1});_.v=Jp;var _d=Lh(84);fd={3:1,82:1,31:1};var ae=Lh(82);ph(45,1,{3:1,45:1});var je=Lh(45);gd={3:1,31:1,45:1};var ce=Lh(221);ph(35,1,{3:1,31:1,35:1});_.s=Kp;_.u=Lp;_.v=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=Lh(35);ph(9,5,vp,Uh,Vh);var fe=Lh(9);ph(32,45,{3:1,31:1,32:1,45:1},Wh);_.s=function(a){return ld(a,32)&&a.a==this.a};_.u=Jp;_.v=function(){return ''+this.a};_.a=0;var ge=Lh(32);var Yh;ph(279,1,{});ph(64,56,vp,_h);_.G=function(a){return new TypeError(a)};var ie=Lh(64);hd={3:1,81:1,31:1,2:1};var ne=Lh(2);ph(85,84,{81:1},fi);var me=Lh(85);ph(283,1,{});ph(63,5,vp,gi);var pe=Lh(63);ph(223,1,{43:1});_.S=Pp;_.W=function(){return new rj(this,0)};_.X=function(){return new Bj(null,this.W())};_.U=function(a){throw ah(new gi('Add not supported on this collection'))};_.v=function(){var a,b,c;c=new tj('[',']');for(b=this.T();b.Z();){a=b.$();sj(c,a===this?'(this Collection)':a==null?wp:th(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var qe=Lh(223);ph(226,1,{210:1});_.s=function(a){var b,c,d;if(a===this){return true}if(!ld(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ui((new ri(d)).a);c.b;){b=ti(c);if(!ji(this,b)){return false}}return true};_.u=function(){return Li(new ri(this))};_.v=function(){var a,b,c;c=new tj('{','}');for(b=new ui((new ri(this)).a);b.b;){a=ti(b);sj(c,ki(this,a.ab())+'='+ki(this,a.bb()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Be=Lh(226);ph(114,226,{210:1});var te=Lh(114);ph(225,223,{43:1,234:1});_.W=function(){return new rj(this,1)};_.s=function(a){var b;if(a===this){return true}if(!ld(a,25)){return false}b=a;if(pi(b.a)!=this.V()){return false}return hi(this,b)};_.u=function(){return Li(this)};var Ce=Lh(225);ph(25,225,{25:1,43:1,234:1},ri);_.T=function(){return new ui(this.a)};_.V=Np;var se=Lh(25);ph(26,1,{},ui);_.Y=Mp;_.$=function(){return ti(this)};_.Z=Op;_.b=false;var re=Lh(26);ph(224,223,{43:1,231:1});_.W=function(){return new rj(this,16)};_._=function(a,b){throw ah(new gi('Add not supported on this list'))};_.U=function(a){this._(this.V(),a);return true};_.s=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.V()!=f.a.length){return false}e=new Ki(f);for(c=new Ki(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.u=function(){return Mi(this)};_.T=function(){return new vi(this)};var ve=Lh(224);ph(96,1,{},vi);_.Y=Mp;_.Z=function(){return this.a<this.b.a.length};_.$=function(){return Ci(this.b,this.a++)};_.a=0;var ue=Lh(96);ph(47,223,{43:1},wi);_.T=function(){var a;return a=new ui((new ri(this.a)).a),new xi(a)};_.V=Np;var xe=Lh(47);ph(66,1,{},xi);_.Y=Mp;_.Z=function(){return this.a.b};_.$=function(){var a;return a=ti(this.a),a.bb()};var we=Lh(66);ph(103,1,yp);_.s=function(a){var b;if(!ld(a,44)){return false}b=a;return Ni(this.a,b.ab())&&Ni(this.b,b.bb())};_.ab=Jp;_.bb=Op;_.u=function(){return mj(this.a)^mj(this.b)};_.cb=function(a){var b;b=this.b;this.b=a;return b};_.v=function(){return this.a+'='+this.b};var ye=Lh(103);ph(104,103,yp,yi);var ze=Lh(104);ph(227,1,yp);_.s=function(a){var b;if(!ld(a,44)){return false}b=a;return Ni(this.b.value[0],b.ab())&&Ni(ij(this),b.bb())};_.u=function(){return mj(this.b.value[0])^mj(ij(this))};_.v=function(){return this.b.value[0]+'='+ij(this)};var Ae=Lh(227);ph(14,224,{3:1,14:1,43:1,231:1},Ii,Ji);_._=function(a,b){Qj(this.a,a,b)};_.U=function(a){return Ai(this,a)};_.S=function(a){Bi(this,a)};_.T=function(){return new Ki(this)};_.V=function(){return this.a.length};var Ee=Lh(14);ph(18,1,{},Ki);_.Y=Mp;_.Z=function(){return this.a<this.c.a.length};_.$=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var De=Lh(18);ph(41,114,{3:1,41:1,210:1},Oi);var Fe=Lh(41);ph(69,1,{},Ui);_.S=Pp;_.T=function(){return new Vi(this)};_.b=0;var He=Lh(69);ph(70,1,{},Vi);_.Y=Mp;_.$=function(){return this.d=this.a[this.c++],this.d};_.Z=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ge=Lh(70);var Yi;ph(67,1,{},gj);_.S=Pp;_.T=function(){return new hj(this)};_.b=0;_.c=0;var Ke=Lh(67);ph(68,1,{},hj);_.Y=Mp;_.$=function(){return this.c=this.a,this.a=this.b.next(),new jj(this.d,this.c,this.d.c)};_.Z=function(){return !this.a.done};var Ie=Lh(68);ph(116,227,yp,jj);_.ab=function(){return this.b.value[0]};_.bb=function(){return ij(this)};_.cb=function(a){return ej(this.a,this.b.value[0],a)};_.c=0;var Je=Lh(116);ph(97,1,{});_.Y=function(a){oj(this,a)};_.db=function(){return this.d};_.eb=Yp;_.d=0;_.e=0;var Me=Lh(97);ph(65,97,{});var Le=Lh(65);ph(24,1,{},rj);_.db=Jp;_.eb=function(){qj(this);return this.c};_.Y=function(a){qj(this);this.d.Y(a)};_.fb=function(a){qj(this);if(this.d.Z()){a.D(this.d.$());return true}return false};_.a=0;_.c=0;var Ne=Lh(24);ph(57,1,{},tj);_.v=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Oe=Lh(57);var Xe=Nh();ph(105,1,{});_.c=false;var Ye=Lh(105);ph(34,105,{},Bj);var We=Lh(34);ph(107,65,{},Fj);_.fb=function(a){this.b=false;while(!this.b&&this.c.fb(new Gj(this,a)));return this.b};_.b=false;var Qe=Lh(107);ph(110,1,{},Gj);_.D=function(a){Ej(this.a,this.b,a)};var Pe=Lh(110);ph(106,65,{},Ij);_.fb=function(a){return this.a.fb(new Jj(a))};var Se=Lh(106);ph(109,1,{},Jj);_.D=function(a){Hj(this.a,a)};var Re=Lh(109);ph(108,1,{},Lj);_.D=function(a){Kj(this,a)};var Te=Lh(108);ph(111,1,{},Mj);_.D=function(a){};var Ue=Lh(111);ph(112,1,{},Oj);_.D=function(a){Nj(this,a)};var Ve=Lh(112);ph(281,1,{});ph(230,1,{});var Ze=Lh(230);ph(278,1,{});var Vj=0;var Xj,Yj=0,Zj;ph(739,1,{});ph(754,1,{});ph(229,1,{});_.hb=Qp;_.ib=Qp;_.kb=function(a,b,c){return false};_.r=false;var $e=Lh(229);ph(33,$wnd.React.Component,{});oh(mh[1],_);_.render=function(){return mk(this.a)};var _e=Lh(33);ph(36,229,{});_.nb=function(){return false};_.pb=function(){return nk(this)};_.o=false;_.p=false;var hk=1,ik;var af=Lh(36);ph(249,$wnd.Function,{},ok);_.L=function(a){return Ab(ik),ik=null,null};ph(10,35,{3:1,31:1,35:1,10:1},$k);var Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk;var bf=Mh(10,_k);ph(161,36,{});_.ub=Rp;_.jb=function(){var a;a=T(this.g.b);return $wnd.React.createElement('footer',pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,['footer'])),Pm(new Qm),$wnd.React.createElement('ul',pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',rk(pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,[(Yo(),Wo)==a?Bp:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',rk(pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,[Vo==a?Bp:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',rk(pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,[Xo==a?Bp:null])),'#completed'),'Completed'))),this.ub()?$wnd.React.createElement(Ap,sk(pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,['clear-completed'])),rh(Lm.prototype.tb,Lm,[this])),'Clear Completed'):null)};var Sf=Lh(161);ph(162,161,{});_.ub=Rp;var al,bl;var Wf=Lh(162);ph(163,162,Dp,gl);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new kl(this)),op,null)}};_.s=Kp;_.ob=Up;_.F=Sp;_.ub=function(){return T(this.a)};_.u=Lp;_.B=Tp;_.v=function(){var a;return Hh(nf),nf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.b,new il(this))}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.d=0;var nf=Lh(163);ph(164,1,ip,hl);_.w=function(){return el(this.a)};var cf=Lh(164);ph(167,1,ip,il);_.w=Wp;var df=Lh(167);ph(165,1,qp,jl);_.C=Vp;var ef=Lh(165);ph(166,1,np,kl);_.C=function(){fl(this.a)};var ff=Lh(166);ph(168,36,{});_.jb=function(){var a,b;b=T(this.d.e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,['todo-count'])),$wnd.React.createElement('strong',null,b),' '+a+' left')};var Rf=Lh(168);ph(169,168,{});var ll,ml;var Vf=Lh(169);ph(170,169,Dp,ql);_.A=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new sl(this)),op,null)}};_.s=Kp;_.ob=Up;_.F=Op;_.u=Lp;_.B=Zp;_.v=function(){var a;return Hh(lf),lf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.a,new tl(this))}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.c=0;var lf=Lh(170);ph(171,1,qp,rl);_.C=Vp;var gf=Lh(171);ph(172,1,np,sl);_.C=function(){pl(this.a)};var hf=Lh(172);ph(173,1,ip,tl);_.w=Wp;var jf=Lh(173);ph(147,1,{},vl);_.K=function(){return ul(this)};var kf=Lh(147);ph(146,1,{},xl);_.K=function(){return wl(this)};var mf=Lh(146);ph(194,36,{});_.jb=function(){return $wnd.React.createElement(Ep,tk(xk(yk(Bk(zk(pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,['new-todo']))),(bb(this.b),this.f)),rh(en.prototype.sb,en,[this])),rh(fn.prototype.rb,fn,[this]))))};_.f='';var dg=Lh(194);ph(195,194,{});var Al,Bl;var Yf=Lh(195);ph(196,195,Dp,Jl);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Ol(this)),op,null)}};_.s=Kp;_.ob=Up;_.F=Sp;_.u=Lp;_.B=Tp;_.v=function(){var a;return Hh(uf),uf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.a,new Kl(this))}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.d=0;var uf=Lh(196);ph(199,1,ip,Kl);_.w=Wp;var of=Lh(199);ph(200,1,np,Ll);_.C=function(){yl(this.a)};var pf=Lh(200);ph(201,1,np,Ml);_.C=function(){Gl(this.a,this.b)};var qf=Lh(201);ph(197,1,qp,Nl);_.C=Vp;var rf=Lh(197);ph(198,1,np,Ol);_.C=function(){Hl(this.a)};var sf=Lh(198);ph(150,1,{},Ql);_.K=function(){return Pl(this)};var tf=Lh(150);ph(174,36,{});_.hb=function(){Rl(this)};_.wb=Xp;_.ib=function(){jm(this,this.vb())};_.jb=function(){var a,b;b=this.vb();a=(bb(b.a),b.g);return $wnd.React.createElement('li',pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,[a?Fp:null,this.wb()?'editing':null])),$wnd.React.createElement('div',pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,['view'])),$wnd.React.createElement(Ep,xk(uk(Ak(pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,['toggle'])),(Zk(),Ek)),a),rh(mn.prototype.rb,mn,[b]))),$wnd.React.createElement('label',Ck(new $wnd.Object,rh(nn.prototype.tb,nn,[this,b])),(bb(b.b),b.i)),$wnd.React.createElement(Ap,sk(pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,['destroy'])),rh(on.prototype.tb,on,[this,b])))),$wnd.React.createElement(Ep,yk(xk(wk(vk(pk(qk(new $wnd.Object,rh(pn.prototype.D,pn,[this])),cd(Yc(ne,1),jp,2,6,['edit'])),(bb(this.a),this.i)),rh(qn.prototype.qb,qn,[this,b])),rh(ln.prototype.rb,ln,[this])),rh(rn.prototype.sb,rn,[this,b]))))};_.j=false;var gg=Lh(174);ph(175,174,{});_.nb=function(){var a;a=(cb(this.c),this.q.props['a']);if(!!a&&a.f<0){return true}return false};_.vb=function(){return this.q.props['a']};_.wb=Xp;_.kb=function(a,b,c){return am(this,a,b,c)};var Zl,$l;var $f=Lh(175);ph(176,175,Dp,lm);_.hb=function(){var b;try{A((J(),J(),I),new om(this),sp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.A=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new mm(this)),op,null)}};_.s=Kp;_.ob=Up;_.F=Yp;_.vb=function(){return cb(this.c),this.q.props['a']};_.u=Lp;_.B=_p;_.wb=function(){return T(this.d)};_.kb=function(b,c,d){var e;try{return t((J(),J(),I),new pm(this,b,c,d),75505664,null)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){e=a;throw ah(e)}else if(ld(a,4)){e=a;throw ah(new Vh(e))}else throw ah(a)}};_.v=function(){var a;return Hh(Hf),Hf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.b,new nm(this))}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.f=0;var Hf=Lh(176);ph(179,1,np,mm);_.C=function(){dm(this.a)};var vf=Lh(179);ph(180,1,ip,nm);_.w=Wp;var wf=Lh(180);ph(181,1,np,om);_.C=function(){Rl(this.a)};var xf=Lh(181);ph(182,1,ip,pm);_.w=function(){return em(this.a,this.d,this.c,this.b)};_.b=false;var yf=Lh(182);ph(183,1,np,qm);_.C=function(){km(this.a,Jn(this.b))};var zf=Lh(183);ph(184,1,np,rm);_.C=function(){Yl(this.a,this.b)};var Af=Lh(184);ph(185,1,np,sm);_.C=function(){Xl(this.a,this.b)};var Bf=Lh(185);ph(177,1,ip,tm);_.w=function(){return fm(this.a)};var Cf=Lh(177);ph(186,1,np,um);_.C=function(){Wl(this.a,this.b)};var Df=Lh(186);ph(187,1,np,vm);_.C=function(){Sl(this.a,this.b)};var Ef=Lh(187);ph(178,1,qp,wm);_.C=Vp;var Ff=Lh(178);ph(148,1,{},ym);_.K=function(){return xm(this)};var Gf=Lh(148);ph(188,36,{});_.jb=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(Gp,pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,[Gp])),$wnd.React.createElement('h1',null,'todos'),gn(new hn)),T(this.d.c)?null:$wnd.React.createElement('section',pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,[Gp])),$wnd.React.createElement(Ep,xk(Ak(pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,['toggle-all'])),(Zk(),Ek)),rh(zn.prototype.rb,zn,[this]))),$wnd.React.createElement.apply(null,['ul',pk(new $wnd.Object,cd(Yc(ne,1),jp,2,6,['todo-list']))].concat((a=Aj(zj(T(this.f.c).X()),(b=new Ii,b)),Hi(a,bd(a.a.length)))))),T(this.d.c)?null:Mm(new Nm)))};var jg=Lh(188);ph(189,188,{});var Am,Bm;var ag=Lh(189);ph(190,189,Dp,Fm);_.A=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Hm(this)),op,null)}};_.s=Kp;_.ob=Up;_.F=Op;_.u=Lp;_.B=Zp;_.v=function(){var a;return Hh(Mf),Mf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.a,new Im(this))}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.c=0;var Mf=Lh(190);ph(191,1,qp,Gm);_.C=Vp;var If=Lh(191);ph(192,1,np,Hm);_.C=function(){pl(this.a)};var Jf=Lh(192);ph(193,1,ip,Im);_.w=Wp;var Kf=Lh(193);ph(149,1,{},Km);_.K=function(){return Jm(this)};var Lf=Lh(149);ph(248,$wnd.Function,{},Lm);_.tb=function(a){mo(this.a.f)};ph(204,1,{},Nm);var Nf=Lh(204);ph(75,1,{},Om);_.K=function(){return wl((new Qo(this.a)).a)};var Of=Lh(75);ph(202,1,{},Qm);var Pf=Lh(202);ph(76,1,{},Rm);_.K=function(){return ul((new Ro(this.a)).a)};var Qf=Lh(76);ph(247,$wnd.Function,{},Wm);_.lb=function(a){return new Xm(a)};ph(91,33,{},Xm);_.mb=function(){return cl(),wl((new Qo(bl.a)).a)};_.componentWillUnmount=$p;var Tf=Lh(91);ph(251,$wnd.Function,{},Ym);_.lb=function(a){return new Zm(a)};ph(92,33,{},Zm);_.mb=function(){return nl(),ul((new Ro(ml.a)).a)};_.componentWillUnmount=$p;var Uf=Lh(92);ph(263,$wnd.Function,{},$m);_.lb=function(a){return new _m(a)};ph(95,33,{},_m);_.mb=function(){return Cl(),Pl((new So(Bl.a)).a)};_.componentWillUnmount=$p;var Xf=Lh(95);ph(252,$wnd.Function,{},an);_.lb=function(a){return new bn(a)};ph(93,33,{},bn);_.mb=function(){return _l(),xm((new To($l.a)).a)};_.componentDidUpdate=function(a){dk(this.a,a)};_.componentWillUnmount=$p;_.shouldComponentUpdate=function(a){return ek(this.a,a)};var Zf=Lh(93);ph(261,$wnd.Function,{},cn);_.lb=function(a){return new dn(a)};ph(94,33,{},dn);_.mb=function(){return Cm(),Jm((new Uo(Bm.a)).a)};_.componentWillUnmount=$p;var _f=Lh(94);ph(264,$wnd.Function,{},en);_.sb=function(a){zl(this.a,a)};ph(265,$wnd.Function,{},fn);_.rb=function(a){Fl(this.a,a)};ph(203,1,{},hn);var bg=Lh(203);ph(79,1,{},jn);_.K=function(){return Pl((new So(this.a)).a)};var cg=Lh(79);ph(259,$wnd.Function,{},ln);_.rb=function(a){cm(this.a,a)};ph(253,$wnd.Function,{},mn);_.rb=function(a){Pn(this.a)};ph(255,$wnd.Function,{},nn);_.tb=function(a){hm(this.a,this.b)};ph(256,$wnd.Function,{},on);_.tb=function(a){Tl(this.a,this.b)};ph(257,$wnd.Function,{},pn);_.D=function(a){Ul(this.a,a)};ph(258,$wnd.Function,{},qn);_.qb=function(a){im(this.a,this.b)};ph(260,$wnd.Function,{},rn);_.sb=function(a){Vl(this.a,this.b,a)};ph(205,1,{},vn);var eg=Lh(205);ph(77,1,{},wn);_.K=function(){return xm((new To(this.a)).a)};var fg=Lh(77);ph(262,$wnd.Function,{},zn);_.rb=function(a){zm(this.a,a)};ph(80,1,{},Bn);var hg=Lh(80);ph(78,1,{},Cn);_.K=function(){return Jm((new Uo(this.a)).a)};var ig=Lh(78);ph(52,1,{52:1});_.g=false;var Xg=Lh(52);ph(53,52,{11:1,39:1,53:1,52:1},Qn);_.A=function(){Hn(this)};_.s=function(a){return In(this,a)};_.F=Sp;_.u=Yp;_.B=_p;_.v=function(){var a;return Hh(Bg),Bg.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var Gn=0;var Bg=Lh(53);ph(206,1,np,Rn);_.C=function(){Ln(this.a)};var kg=Lh(206);ph(207,1,np,Sn);_.C=function(){Mn(this.a)};var lg=Lh(207);ph(48,118,{48:1});var Sg=Lh(48);ph(119,48,{11:1,48:1},$n);_.A=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new _n(this)),op,null)}};_.s=Kp;_.u=Lp;_.B=_p;_.v=function(){var a;return Hh(ug),ug.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.f=0;var ug=Lh(119);ph(124,1,np,_n);_.C=function(){Xn(this.a)};var mg=Lh(124);ph(125,1,np,ao);_.C=function(){hc(this.a,this.b,true)};var ng=Lh(125);ph(120,1,ip,bo);_.w=function(){return Yn(this.a)};var og=Lh(120);ph(126,1,ip,co);_.w=function(){return Tn(this.a,this.c,this.b)};_.b=false;var pg=Lh(126);ph(121,1,ip,eo);_.w=function(){return Xh(gh(xj(Wn(this.a))))};var qg=Lh(121);ph(122,1,ip,fo);_.w=function(){return Xh(gh(xj(yj(Wn(this.a),new _o))))};var rg=Lh(122);ph(123,1,ip,go);_.w=function(){return Zn(this.a)};var sg=Lh(123);ph(99,1,{},jo);_.K=function(){return new $n};var ho;var tg=Lh(99);ph(49,1,{49:1});var Wg=Lh(49);ph(130,49,{11:1,49:1},ro);_.A=function(){if(this.a>=0){this.a=-2;t((J(),J(),I),new G(new uo),op,null)}};_.s=Kp;_.u=Lp;_.B=function(){return this.a<0};_.v=function(){var a;return Hh(Ag),Ag.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.a=0;var Ag=Lh(130);ph(133,1,np,so);_.C=function(){On(this.b,this.a)};var vg=Lh(133);ph(134,1,np,to);_.C=function(){no(this.a)};var wg=Lh(134);ph(131,1,np,uo);_.C=Qp;var xg=Lh(131);ph(132,1,np,vo);_.C=function(){oo(this.a,this.b)};_.b=false;var yg=Lh(132);ph(100,1,{},wo);_.K=function(){return new ro(this.a.K())};var zg=Lh(100);ph(50,1,{50:1});var Zg=Lh(50);ph(139,50,{11:1,50:1},Fo);_.A=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new Go(this)),op,null)}};_.s=Kp;_.u=Lp;_.B=function(){return this.g<0};_.v=function(){var a;return Hh(Ig),Ig.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.g=0;var Ig=Lh(139);ph(144,1,np,Go);_.C=function(){Ao(this.a)};var Cg=Lh(144);ph(140,1,ip,Ho);_.w=function(){var a;return a=Wb(this.a.i),bi(Ip,a)||bi(Fp,a)||bi('',a)?bi(Ip,a)?(Yo(),Vo):bi(Fp,a)?(Yo(),Xo):(Yo(),Wo):(Yo(),Wo)};var Dg=Lh(140);ph(141,1,ip,Io);_.w=function(){return Bo(this.a)};var Eg=Lh(141);ph(142,1,qp,Jo);_.C=function(){Co(this.a)};var Fg=Lh(142);ph(143,1,qp,Ko);_.C=function(){Do(this.a)};var Gg=Lh(143);ph(102,1,{},Lo);_.K=function(){return new Fo(this.b.K(),this.a.K())};var Hg=Lh(102);ph(101,1,{},Oo);_.K=function(){return new bc};var Mo;var Jg=Lh(101);ph(74,1,{},Po);var Pg=Lh(74);ph(58,1,{},Qo);var Kg=Lh(58);ph(62,1,{},Ro);var Lg=Lh(62);ph(61,1,{},So);var Mg=Lh(61);ph(59,1,{},To);var Ng=Lh(59);ph(60,1,{},Uo);var Og=Lh(60);ph(37,35,{3:1,31:1,35:1,37:1},Zo);var Vo,Wo,Xo;var Qg=Mh(37,$o);ph(129,1,{},_o);_.gb=function(a){return !Kn(a)};var Rg=Lh(129);ph(136,1,{},ap);_.gb=function(a){return Kn(a)};var Tg=Lh(136);ph(137,1,{},bp);_.D=function(a){Vn(this.a,a)};var Ug=Lh(137);ph(135,1,{},cp);_.D=function(a){lo(this.a,a)};_.a=false;var Vg=Lh(135);ph(145,1,{},dp);_.gb=function(a){return yo(this.a,a)};var Yg=Lh(145);var ep=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=kh;ih(vh);lh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();