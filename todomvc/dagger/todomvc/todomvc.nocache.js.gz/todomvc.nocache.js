function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='AABE374348ACC618305E7D31E3763CAE',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'AABE374348ACC618305E7D31E3763CAE';function p(){}
function yh(){}
function uh(){}
function Gb(){}
function Gj(){}
function Uj(){}
function Sc(){}
function Zc(){}
function li(){}
function ak(){}
function bk(){}
function Ak(){}
function ol(){}
function op(){}
function ep(){}
function eo(){}
function Xm(){}
function _m(){}
function dn(){}
function hn(){}
function mn(){}
function Hn(){}
function np(){}
function rp(){}
function Xc(a){Wc()}
function Lh(){Lh=uh}
function Oi(){Fi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function hc(a){this.a=a}
function qc(a){this.a=a}
function _h(a){this.a=a}
function ki(a){this.a=a}
function xi(a){this.a=a}
function Ci(a){this.a=a}
function Di(a){this.a=a}
function Bi(a){this.b=a}
function Qi(a){this.c=a}
function Hj(a){this.a=a}
function Hl(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function Al(a){this.a=a}
function Il(a){this.a=a}
function Jl(a){this.a=a}
function Wl(a){this.a=a}
function Xl(a){this.a=a}
function Yl(a){this.a=a}
function Zl(a){this.a=a}
function dk(a){this.a=a}
function vm(a){this.a=a}
function wm(a){this.a=a}
function xm(a){this.a=a}
function ym(a){this.a=a}
function Cm(a){this.a=a}
function Fm(a){this.a=a}
function Nm(a){this.a=a}
function Om(a){this.a=a}
function Pm(a){this.a=a}
function Qm(a){this.a=a}
function qn(a){this.a=a}
function rn(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function zn(a){this.a=a}
function Gn(a){this.a=a}
function Zn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function bo(a){this.a=a}
function co(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Eo(a){this.a=a}
function Fo(a){this.a=a}
function Go(a){this.a=a}
function Ho(a){this.a=a}
function Ro(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function cp(a){this.a=a}
function dp(a){this.a=a}
function pp(a){this.a=a}
function qp(a){this.a=a}
function sp(a){this.a=a}
function tp(a){this.a=a}
function _j(a,b){a.a=b}
function rb(a,b){a.b=b}
function vk(a,b){a.key=b}
function tk(a,b){sk(a,b)}
function Jo(a,b){tm(b,a)}
function Z(a){!!a&&ab(a)}
function lc(a){!!a&&a.t()}
function w(a){--a.e;D(a)}
function Wp(a){sj(this,a)}
function _p(a){vj(this,a)}
function Zp(a){di(this,a)}
function aq(){kc(this.c)}
function cq(){kc(this.b)}
function hq(){kc(this.f)}
function aj(){this.a=jj()}
function oj(){this.a=jj()}
function eq(){lb(this.a.a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function fh(a){return a.e}
function Up(){return this.a}
function Yp(){return this.b}
function $p(){return this.e}
function K(){K=uh;J=new F}
function yc(){yc=uh;xc=new p}
function Bh(){Bh=uh;Ah=new p}
function fj(){fj=uh;ej=hj()}
function Pc(){Pc=uh;Oc=new Sc}
function pl(a){a.e=2;kc(a.c)}
function Bl(a){a.d=2;kc(a.b)}
function fm(a){a.g=2;kc(a.e)}
function Sn(a){S(a.a);ab(a.b)}
function tl(a){lb(a.b);S(a.a)}
function L(a,b){P(a);M(a,b)}
function ck(a,b){Tj(a.a,b)}
function oc(a,b){ti(a.e,b)}
function am(a,b){vo(a.n,b)}
function Io(a,b){uo(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function jc(a,b,c){si(a.e,b,c)}
function Aj(a,b,c){b.A(a.a[c])}
function Ii(a,b){return a.a[b]}
function bm(a,b){return a.j=b}
function Vp(){return kk(this)}
function Kh(a){wc.call(this,a)}
function $h(a){wc.call(this,a)}
function mi(a){wc.call(this,a)}
function hk(a,b){a.splice(b,1)}
function tc(a,b){a.e=b;sc(a,b)}
function $c(a,b){return Uh(a,b)}
function Ql(a){lb(a.a);ab(a.b)}
function go(a){ab(a.b);ab(a.a)}
function ho(a,b,c){jc(a.c,b,c)}
function bb(a){K();Zb(a);a.e=-2}
function Oh(a){Nh(a);return a.k}
function tn(a){this.a=a;un=this}
function Vm(a){this.a=a;Wm=this}
function ei(){rc(this);this.H()}
function Xp(){return vi(this.a)}
function bq(){return this.c.i<0}
function dq(){return this.b.i<0}
function iq(){return this.f.i<0}
function jj(){fj();return new ej}
function Sj(a,b){a.U(b);return a}
function U(a){nb(a.f);return W(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function Tj(a,b){_j(a,Sj(a.a,b))}
function vj(a,b){while(a.fb(b));}
function Yj(a,b,c){b.A(a.a.T(c))}
function v(a,b,c){t(a,new I(c),b)}
function gp(){gp=uh;fp=new ep}
function Fc(){Fc=uh;!!(Wc(),Vc)}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function nh(){lh==null&&(lh=[])}
function Ch(a){this.a=Ah;this.b=a}
function Zh(a,b){this.a=a;this.b=b}
function ic(a,b){this.a=a;this.b=b}
function Ei(a,b){this.a=a;this.b=b}
function Xj(a,b){this.a=a;this.b=b}
function $j(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function Bk(a,b){this.a=a;this.b=b}
function Dk(a,b){a.ref=b;return a}
function Ek(a,b){a.href=b;return a}
function Un(a){gb(a.b);return a.e}
function Vo(a){gb(a.d);return a.e}
function ko(a){gb(a.a);return a.d}
function gq(a){return 1==this.a.d}
function fq(a){return 1==this.a.e}
function vi(a){return a.a.b+a.b.b}
function lj(a,b){return a.a.get(b)}
function kl(a,b){Zh.call(this,a,b)}
function $l(a,b){this.a=a;this.b=b}
function zm(a,b){this.a=a;this.b=b}
function Am(a,b){this.a=a;this.b=b}
function Bm(a,b){this.a=a;this.b=b}
function Dm(a,b){this.a=a;this.b=b}
function Em(a,b){this.a=a;this.b=b}
function xn(a,b){this.a=a;this.b=b}
function yn(a,b){this.a=a;this.b=b}
function An(a,b){this.a=a;this.b=b}
function Bn(a,b){this.a=a;this.b=b}
function ao(a,b){this.a=a;this.b=b}
function Co(a,b){this.a=a;this.b=b}
function Po(a,b){this.a=a;this.b=b}
function Qo(a,b){this.b=a;this.a=b}
function lp(a,b){Zh.call(this,a,b)}
function fk(a,b,c){a.splice(b,0,c)}
function Nk(a,b){a.value=b;return a}
function ii(a,b){a.a+=''+b;return a}
function Um(){this.a=xk((bn(),an))}
function sn(){this.a=xk((fn(),en))}
function Dn(){this.a=xk((kn(),jn))}
function In(){this.a=xk((on(),nn))}
function Rm(){this.a=xk((Zm(),Ym))}
function Vn(a){Tn(a,(gb(a.b),a.e))}
function lo(a){tm(a,(gb(a.a),!a.d))}
function Ub(a){return !a.d?a:Ub(a.d)}
function ri(a){return !a?null:a.bb()}
function rd(a){return a==null?null:a}
function uj(a){return a!=null?s(a):0}
function od(a){return typeof a===wp}
function o(a,b){return rd(a)===rd(b)}
function Ik(a,b){a.onBlur=b;return a}
function Fk(a,b){a.onClick=b;return a}
function Hk(a,b){a.checked=b;return a}
function Mc(a){$wnd.clearTimeout(a)}
function jb(a){this.c=new Oi;this.b=a}
function ui(a){a.a=new aj;a.b=new oj}
function Fi(a){a.a=ad(me,yp,1,0,5,1)}
function qb(a){K();pb(a);tb(a,2,true)}
function jm(a){lb(a.b);S(a.c);ab(a.a)}
function gc(a,b){cc(a,b,false);fb(a.c)}
function gk(a,b){ek(b,0,a,0,b.length)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function ed(a,b,c){return {l:a,m:b,h:c}}
function fi(a,b){return a.charCodeAt(b)}
function md(a,b){return a!=null&&kd(a,b)}
function $(a){return !(md(a,9)&&a.w())}
function kk(a){return a.$H||(a.$H=++jk)}
function qd(a){return typeof a==='string'}
function Kk(a,b){a.onKeyDown=b;return a}
function Jk(a,b){a.onChange=b;return a}
function uk(a,b){a.props['a']=b;return a}
function Gk(a){a.autoFocus=true;return a}
function Nh(a){if(a.k!=null){return}Wh(a)}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function Lo(a,b){Hi(ec(a.b),new qp(b))}
function sk(a,b){for(var c in a){b(c)}}
function sj(a,b){while(a.Z()){ck(b,a.$())}}
function fc(a,b){oc(b.c,a);md(b,9)&&b.v()}
function wc(a){this.g=a;rc(this);this.H()}
function Rj(a,b){Kj.call(this,a);this.a=b}
function En(a,b){this.a=a;this.b=b;Fn=this}
function Wi(){this.a=new aj;this.b=new oj}
function ok(){ok=uh;lk=new p;nk=new p}
function Q(){this.a=ad(me,yp,1,100,5,1)}
function ci(){ci=uh;bi=ad(ie,yp,29,256,0,1)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function yo(a){return ai(T(a.e).a-T(a.a).a)}
function nd(a){return typeof a==='boolean'}
function Gc(a,b,c){return a.apply(b,c);var d}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function cj(a,b){var c;c=a[Jp];c.call(a,b)}
function Uo(a){lb(a.a);S(a.b);S(a.c);ab(a.d)}
function oo(a){A((K(),K(),J),new ro(a),Np)}
function Ko(a){A((K(),K(),J),new Ro(a),Np)}
function Wn(a){A((K(),K(),J),new bo(a),Np)}
function rm(a){A((K(),K(),J),new Fm(a),Np)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Sl(a,b){A((K(),K(),J),new $l(a,b),Np)}
function lm(a,b){A((K(),K(),J),new Em(a,b),Np)}
function pm(a,b){A((K(),K(),J),new Bm(a,b),Np)}
function qm(a,b){A((K(),K(),J),new Am(a,b),Np)}
function sm(a,b){A((K(),K(),J),new zm(a,b),Np)}
function vo(a,b){A((K(),K(),J),new Co(a,b),Np)}
function No(a,b){A((K(),K(),J),new Po(a,b),Np)}
function yj(a,b){while(a.c<a.d){Aj(a,b,a.c++)}}
function Db(a){while(true){if(!Cb(a)){break}}}
function Do(a,b){this.a=a;this.c=b;this.b=false}
function rj(a,b,c){this.a=a;this.b=b;this.c=c}
function Ok(a,b){a.onDoubleClick=b;return a}
function Gi(a,b){a.a[a.a.length]=b;return true}
function rc(a){a.j&&a.e!==Ep&&a.H();return a}
function Rh(a){var b;b=Qh(a);Yh(a,b);return b}
function Fh(a){if(!a){throw fh(new ei)}return a}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function Cj(a){if(!a.d){a.d=a.b.S();a.c=a.b.V()}}
function Wc(){Wc=uh;var a;!Yc();a=new Zc;Vc=a}
function Lj(a,b){var c;return Pj(a,(c=new Oi,c))}
function Tl(a,b){var c;c=b.target;Ul(a,c.value)}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Ih(a,b,c,d){a.addEventListener(b,c,d)}
function Jh(a,b,c,d){a.removeEventListener(b,c,d)}
function Vj(a,b,c){if(a.a.hb(c)){a.b=true;b.A(c)}}
function zi(a){var b;b=a.a.$();a.b=yi(a);return b}
function Th(a){var b;b=Qh(a);b.j=a;b.e=1;return b}
function Ki(a,b){var c;c=a.a[b];hk(a.a,b);return c}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ri(a,b){return wj(b,a.length),new Bj(a,b)}
function kj(a,b){return !(a.a.get(b)===undefined)}
function So(a){return o(Sp,a)||o(Tp,a)||o('',a)}
function ul(a){return B((K(),K(),J),a.b,new zl(a))}
function xo(a){return Lh(),0!=T(a.e).a?true:false}
function vl(a){return Lh(),T(a.f.b).a>0?true:false}
function Fl(a){return B((K(),K(),J),a.a,new Jl(a))}
function Rl(a){return B((K(),K(),J),a.a,new Xl(a))}
function km(a){return B((K(),K(),J),a.b,new xm(a))}
function mm(a){return Lh(),Vo(a.o)==a.i?true:false}
function Lm(a){return B((K(),K(),J),a.a,new Pm(a))}
function Si(a){return new Rj(null,Ri(a,a.length))}
function cd(a){return Array.isArray(a)&&a.qb===yh}
function ld(a){return !Array.isArray(a)&&a.qb===yh}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function wo(a){di(new Ci(a.g),new hc(a));ui(a.g)}
function to(a){S(a.d);S(a.e);S(a.a);S(a.b);ab(a.c)}
function Ij(a){if(!a.b){Jj(a);a.c=true}else{Ij(a.b)}}
function Dl(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function rl(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function hm(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function rk(){if(mk==256){lk=nk;nk=new p;mk=0}++mk}
function Hh(){Hh=uh;Gh=$wnd.goog.global.document}
function Gm(a,b){var c;c=b.target;No(a.f,c.checked)}
function tm(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function Ul(a,b){var c;c=a.g;if(b!=c){a.g=b;fb(a.b)}}
function Xn(a,b){var c;c=a.e;if(b!=c){a.e=b;fb(a.b)}}
function Mi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Mk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function wi(a,b){if(b){return pi(a.a,b)}return false}
function Nj(a,b){Jj(a);return new Rj(a,new Wj(b,a.a))}
function Oj(a,b){Jj(a);return new Rj(a,new Zj(b,a.a))}
function Tn(a,b){A((K(),K(),J),new ao(a,b),75497472)}
function nm(a,b){Yo(a.o,b);A((K(),K(),J),new zm(a,b),Np)}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Rn(a){var b;V(a.a);b=T(a.a);o(a.f,b)&&Xn(a,b)}
function Vi(a,b){return rd(a)===rd(b)||a!=null&&q(a,b)}
function xj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Dj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Bj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Sm(a,b,c){this.a=a;this.b=b;this.c=c;Tm=this}
function Jn(a,b,c){this.a=a;this.b=b;this.c=c;Kn=this}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function Kj(a){if(!a){this.b=null;new Oi}else{this.b=a}}
function Vh(a){if(a.Q()){return null}var b=a.j;return qh[b]}
function kh(a){if(od(a)){return a|0}return a.l|a.m<<22}
function uc(a,b){var c;c=Oh(a.ob);return b==null?c:c+': '+b}
function Sh(a,b){var c;c=Qh(a);Yh(a,c);c.e=b?8:0;return c}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function _l(a,b){var c;if(T(a.c)){c=b.target;tm(a,c.value)}}
function di(a,b){var c,d;for(d=a.S();d.Z();){c=d.$();b.A(c)}}
function qi(a,b){return b===a?'(this Map)':b==null?Gp:xh(b)}
function mp(){kp();return dd($c(Sg,1),yp,31,0,[hp,jp,ip])}
function kn(){kn=uh;var a;jn=(a=vh(hn.prototype.nb,hn,[]),a)}
function fn(){fn=uh;var a;en=(a=vh(dn.prototype.nb,dn,[]),a)}
function on(){on=uh;var a;nn=(a=vh(mn.prototype.nb,mn,[]),a)}
function bn(){bn=uh;var a;an=(a=vh(_m.prototype.nb,_m,[]),a)}
function Zm(){Zm=uh;var a;Ym=(a=vh(Xm.prototype.nb,Xm,[]),a)}
function wh(a){function b(){}
;b.prototype=a||{};return new b}
function Lk(a){a.placeholder='What needs to be done?';return a}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function Nn(a){Ih((Hh(),$wnd.goog.global.window),Qp,a.d,false)}
function On(a){Jh((Hh(),$wnd.goog.global.window),Qp,a.d,false)}
function om(a,b){A((K(),K(),J),new zm(a,b),Np);Yo(a.o,null)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&Cp)&&D((null,J))}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function nc(a){lc(a.g);!!a.e&&mc(a);Z(a.a);Z(a.c);lc(a.b);lc(a.f)}
function dc(a){gb(a.c);return new Rj(null,new Dj(new Ci(a.g),0))}
function Pn(a,b){b.preventDefault();A((K(),K(),J),new co(a),Np)}
function Yi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Uh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.L(b))}
function sh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Zi(a,b){var c;return Xi(b,Yi(a,b==null?0:(c=s(b),c|0)))}
function Pi(a){Fi(this);gk(this.a,oi(a,ad(me,yp,1,vi(a.a),5,1)))}
function Oo(a){this.b=a;K();this.a=new pc(0,null,null,false,false)}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function bj(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Zj(a,b){xj.call(this,b.eb(),b.db()&-6);this.a=a;this.b=b}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function zj(a,b){if(a.c<a.d){Aj(a,b,a.c++);return true}return false}
function Dh(a){Bh();Fh(a);if(md(a,45)){return a}return new Ch(a)}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function cb(a,b){var c,d;Gi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Wj(a,b){xj.call(this,b.eb(),b.db()&-16449);this.a=a;this.c=b}
function pj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Ej(a,b){!a.a?(a.a=new ki(a.d)):ii(a.a,a.b);ii(a.a,b);return a}
function Pj(a,b){var c;Ij(a);c=new ak;c.a=b;a.a.Y(new dk(c));return c.a}
function Mj(a){var b;Ij(a);b=0;while(a.a.fb(new bk)){b=gh(b,1)}return b}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Mo(a){Lj(Nj(dc(a.b),new op),new Hj(new Gj)).R(new pp(a.b))}
function uo(a,b){var c;return u((K(),K(),J),new Do(a,b),Np,(c=null,c))}
function To(a,b){return (kp(),ip)==a||(hp==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function ti(a,b){return qd(b)?b==null?_i(a.a,null):nj(a.b,b):_i(a.a,b)}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function Kl(a){var b;b=hi((gb(a.b),a.g));if(b.length>0){Io(a.f,b);Ul(a,'')}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Hi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.A(c)}}
function Qj(a,b){var c;c=Lj(a,new Hj(new Gj));return Ni(c,b.gb(c.a.length))}
function zk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function Mn(a,b){a.f=b;o(b,T(a.a))&&Xn(a,b);Qn(b);A((K(),K(),J),new co(a),Np)}
function Jb(b){try{nb(b.b.a)}catch(a){a=eh(a);if(!md(a,4))throw fh(a)}}
function cn(a){$wnd.React.Component.call(this,a);this.a=new Gl(this,Wm.a)}
function gn(a){$wnd.React.Component.call(this,a);this.a=new Vl(this,un.a)}
function ln(a){$wnd.React.Component.call(this,a);this.a=new um(this,Fn.a,Fn.b)}
function Ai(a){this.d=a;this.c=new pj(this.d.b);this.a=this.c;this.b=yi(this)}
function Fj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Ln(){this.a=Dh(new rp);this.b=Dh((gp(),fp));this.c=Dh(new tp(this.b))}
function Wo(a){var b;return b=T(a.b),Lj(Nj(dc(a.i),new sp(b)),new Hj(new Gj))}
function kc(a){if(a.i>=0){a.i=-2;u((K(),K(),J),new H(new qc(a)),67108864,null)}}
function S(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function qj(a){if(a.a.c!=a.c){return lj(a.a,a.b.value[0])}return a.b.value[1]}
function io(a,b){var c;if(md(b,51)){c=b;return a.c.d==c.c.d}else{return false}}
function Li(a,b){var c;c=Ji(a,b,0);if(c==-1){return false}hk(a.a,c);return true}
function Ji(a,b,c){for(;c<a.a.length;++c){if(Vi(b,a.a[c])){return c}}return -1}
function W(a){if(a.b){if(md(a.b,7)){throw fh(a.b)}else{throw fh(a.b)}}return a.k}
function sb(b){if(b){try{b.t()}catch(a){a=eh(a);if(md(a,4)){K()}else throw fh(a)}}}
function ab(a){if(-2!=a.e){u((K(),K(),J),new H(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function ec(a){return gb(a.c),Lj(new Rj(null,new Dj(new Ci(a.g),0)),new Hj(new Gj))}
function si(a,b,c){return qd(b)?b==null?$i(a.a,null,c):mj(a.b,b,c):$i(a.a,b,c)}
function ik(a,b){return _c(b)!=10&&dd(r(b),b.pb,b.__elementTypeId$,_c(b),a),a}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function pd(a){return a!=null&&(typeof a===vp||typeof a==='function')&&!(a.qb===yh)}
function pn(a){$wnd.React.Component.call(this,a);this.a=new Mm(this,Kn.a,Kn.b,Kn.c)}
function $m(a){$wnd.React.Component.call(this,a);this.a=new wl(this,Tm.a,Tm.b,Tm.c)}
function Pb(){var a;this.a=ad(yd,yp,44,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function Qc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Uc(b,c)}while(a.a);a.a=c}}
function Rc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Oi);Gi(a.b,b)}}}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Oi);a.c=c.c}b.d=true;Gi(a.c,b)}
function Yh(a,b){var c;if(!a){return}b.j=a;var d=Vh(b);if(!d){qh[a]=[b];return}d.ob=b}
function vh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Cn(a,b){vk(a.a,(b?ai(b.c.d):null)+(''+(Nh(fg),fg.k)));uk(a.a,b);return a.a}
function Qh(a){var b;b=new Ph;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function xk(a){var b;b=wk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Ti(a){var b,c,d;d=0;for(c=new Ai(a.a);c.b;){b=zi(c);d=d+(b?s(b):0);d=d|0}return d}
function pb(a){var b,c;for(c=new Qi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function ni(a,b){var c,d;for(d=new Ai(b.a);d.b;){c=zi(d);if(!wi(a,c)){return false}}return true}
function so(a,b,c){var d;d=new po(b,c);ho(d,a,new ic(a,d));si(a.g,ai(d.c.d),d);fb(a.c);return d}
function nj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{cj(a.a,b);--a.b}return c}
function Ll(a,b){if(13==b.keyCode){b.preventDefault();A((K(),K(),J),new Yl(a),Np)}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function mh(){nh();var a=lh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function wj(a,b){if(0>a||a>b){throw fh(new Kh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function ph(a,b){typeof window===vp&&typeof window['$gwt']===vp&&(window['$gwt'][a]=b)}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Dp:0)|(0!=(b&229376)?0:98304)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:Ap)|(0==(c&6291456)?!a?Cp:Dp:0)|0|0|0)}
function cc(a,b,c){var d;d=ti(a.g,b?ai(b.c.d):null);if(null!=d){oc(b.c,a);c&&!!b&&kc(b.c);fb(a.c)}}
function mj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function hh(a){var b;b=a.h;if(b==0){return a.l+a.m*Dp}if(b==1048575){return a.l+a.m*Dp-Hp}return a}
function eh(a){var b;if(md(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function yi(a){if(a.a.Z()){return true}if(a.a!=a.c){return false}a.a=new bj(a.d.a);return a.a.Z()}
function jh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Hp;d=1048575}c=sd(e/Dp);b=sd(e-c*Dp);return ed(b,c,d)}
function Xi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Vi(a,c.ab())){return c}}return null}
function dd(a,b,c,d,e){e.ob=a;e.pb=b;e.qb=yh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function kp(){kp=uh;hp=new lp('ACTIVE',0);jp=new lp('COMPLETED',1);ip=new lp('ALL',2)}
function cm(a,b,c){27==c.which?A((K(),K(),J),new Dm(a,b),Np):13==c.which&&A((K(),K(),J),new Am(a,b),Np)}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function nl(){if(!ml){ml=(++(K(),K(),J).e,new Gb);$wnd.Promise.resolve(null).then(vh(ol.prototype.K,ol,[]))}}
function Xo(a){var b;b=T(a.g.a);o(Sp,b)||o(Tp,b)||o('',b)?Tn(a.g,b):So(Un(a.g))?Wn(a.g):Tn(a.g,'')}
function Yo(a,b){var c;c=a.e;if(!(b==c||!!b&&io(b,c))){!!c&&oc(c.c,a);a.e=b;!!b&&ho(b,a,new _o(a));fb(a.d)}}
function db(a,b){var c,d;d=a.c;Li(d,b);!!a.b&&Ap!=(a.b.c&Bp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function em(a){var b;b=T(a.c);if(!a.k&&b){a.k=true;sm(a,a.i);a.j.focus();a.j.select()}else a.k&&!b&&(a.k=false)}
function ai(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ci(),bi)[b];!c&&(c=bi[b]=new _h(a));return c}return new _h(a)}
function xh(a){var b;if(Array.isArray(a)&&a.qb===yh){return Oh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function qk(a){ok();var b,c,d;c=':'+a;d=nk[c];if(d!=null){return sd(d)}d=lk[c];b=d==null?pk(a):sd(d);rk();nk[c]=b;return b}
function Ac(a){yc();rc(this);this.e=a;sc(this,a);this.g=a==null?Gp:xh(a);this.a='';this.b=a;this.a=''}
function Ph(){this.g=Mh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function r(a){return qd(a)?pe:od(a)?de:nd(a)?be:ld(a)?a.ob:cd(a)?a.ob:a.ob||Array.isArray(a)&&$c(Ud,1)||Ud}
function s(a){return qd(a)?qk(a):od(a)?sd(a):nd(a)?a?1231:1237:ld(a)?a.r():cd(a)?kk(a):!!a&&!!a.hashCode?a.hashCode():kk(a)}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Ap)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Jj(a){if(a.b){Jj(a.b)}else if(a.c){throw fh(new $h("Stream already terminated, can't be modified or used"))}}
function fd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ed(c&4194303,d&4194303,e&1048575)}
function gh(a,b){var c;if(od(a)&&od(b)){c=a+b;if(-17592186044416<c&&c<Hp){return c}}return hh(fd(od(a)?jh(a):a,od(b)?jh(b):b))}
function dm(a,b){var c;c=(gb(a.a),a.d);if(null!=c&&c.length!=0){A((K(),K(),J),new Qo(b,c),Np);Yo(a.o,null);tm(a,c)}else{vo(a.n,b)}}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=Ki(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Ui(a){var b,c,d;d=1;for(c=new Qi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function mc(a){var b,c,d;for(c=new Qi(new Pi(new xi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.ab();md(d,9)&&d.w()||b.bb().t()}}
function ll(){jl();return dd($c(ff,1),yp,6,0,[Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il])}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(Ap==(b&Bp)?0:524288)|(0==(b&6291456)?Ap==(b&Bp)?Dp:Cp:0)|0|268435456|0)}
function Xh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ni(a,b){var c,d;d=a.a.length;b.length<d&&(b=ik(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Gl(a,b){var c;this.e=b;this.c=a;K();c=++El;this.b=new pc(c,null,new Hl(this),false,false);this.a=new wb(null,new Il(this),Mp)}
function pc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Wi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new jb((f=null,K(),f)),g):null;this.c=null}
function q(a,b){return qd(a)?o(a,b):od(a)?rd(a)===rd(b):nd(a)?rd(a)===rd(b):ld(a)?a.p(b):cd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function kd(a,b){if(qd(a)){return !!jd[b]}else if(a.pb){return !!a.pb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function Ck(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function T(a){a.j?hb(a.e):gb(a.e);if(ub(a.f)){if(a.j&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Qi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Qi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Qi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function hi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function oi(a,b){var c,d,e,f;f=vi(a.a);b.length<f&&(b=ik(new Array(f),b));e=b;d=new Ai(a.a);for(c=0;c<f;++c){e[c]=zi(d)}b.length>f&&(b[f]=null);return b}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.t(),null)}finally{bc()}return f}catch(a){a=eh(a);if(md(a,4)){e=a;throw fh(e)}else throw fh(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.u()}else{ac(b,e);try{g=c.u()}finally{bc()}}return g}catch(a){a=eh(a);if(md(a,4)){f=a;throw fh(f)}else throw fh(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.i=c;this.k=null;this.j=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);Ap==(d&Bp)&&mb(this.f)}
function Mm(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.c=a;K();e=++Km;this.b=new pc(e,null,new Nm(this),false,false);this.a=new wb(null,new Om(this),Mp)}
function Vl(a,b){var c,d,e;this.f=b;this.d=a;K();c=++Pl;this.c=new pc(c,null,new Wl(this),false,false);this.b=(e=new jb((d=null,d)),e);this.a=new wb(null,new Zl(this),Mp)}
function po(a,b){var c,d,e,f,g;this.e=a;this.d=b;K();c=++fo;this.c=new pc(c,null,new qo(this),true,true);this.b=(g=new jb((e=null,e)),g);this.a=(f=new jb((d=null,d)),f)}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function oh(b,c,d,e){nh();var f=lh;$moduleName=c;$moduleBase=d;dh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{up(g)()}catch(a){b(c,a)}}else{up(g)()}}
function wk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function hj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return ij()}}
function Cl(a){var b,c;a.d=0;nl();c=(b=T(a.e.e).a,yk('span',Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,['todo-count'])),[yk('strong',null,[b]),' item'+(b==1?'':'s')+' left']));return c}
function rh(){qh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].rb()&&(c=Tc(c,g)):g[0].rb()}catch(a){a=eh(a);if(md(a,4)){d=a;Fc();Lc(md(d,35)?d.I():d)}else throw fh(a)}}return c}
function Nl(a){var b;a.e=0;nl();b=yk(Op,Gk(Jk(Kk(Nk(Lk(Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,['new-todo']))),(gb(a.b),a.g)),vh(qn.prototype.lb,qn,[a])),vh(rn.prototype.kb,rn,[a]))),null);return b}
function zc(a){var b;if(a.c==null){b=rd(a.b)===rd(xc)?null:a.b;a.d=b==null?Gp:pd(b)?b==null?null:b.name:qd(b)?'String':Oh(r(b));a.a=a.a+': '+(pd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.k;try{d=b.c.u();if(!(rd(e)===rd(d)||e!=null&&q(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=eh(a);if(md(a,10)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw fh(c)}else throw fh(a)}}
function ek(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function $i(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Xi(b,e);if(f){return f.cb(c)}}e[e.length]=new Ei(b,c);++a.b;return null}
function wl(a,b,c,d){var e;this.f=b;this.g=c;this.i=d;this.d=a;K();e=++sl;this.c=new pc(e,null,new xl(this),false,false);this.a=new X(new yl(this),null,null,136478720);this.b=new wb(null,new Al(this),Mp)}
function pk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+fi(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{b.e.t()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=eh(a);if(md(a,4)){K()}else throw fh(a)}}}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=ad(me,yp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Eh(a,b){var c;c=rd(a)!==rd(Ah);if(c&&rd(a)!==rd(b)){throw fh(new $h('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}return b}
function vb(a,b,c,d){this.b=new Oi;this.f=new Kb(new zb(this),d&6520832|262144|Ap);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&Cp)&&D((null,J)))}
function zh(){var a;a=new Ln;new Sm(new zo,a.a.J(),a.c.J());new En(new zo,(a.a.J(),a.c.J()));new Jn(new zo,a.a.J(),a.c.J());new tn(a.a.J());new Vm(new zo);$wnd.ReactDOM.render((new In).a,(Hh(),Gh).getElementById('app'),null)}
function _i(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Vi(b,e.ab())){if(d.length==1){d.length=0;cj(a.a,g)}else{d.splice(h,1)}--a.b;return e.bb()}}return null}
function th(a,b,c){var d=qh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=qh[b]),wh(h));_.pb=c;!b&&(_.qb=yh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ob=f)}
function Wh(a){if(a.P()){var b=a.c;b.Q()?(a.k='['+b.j):!b.P()?(a.k='[L'+b.N()+';'):(a.k='['+b.N());a.b=b.M()+'[]';a.i=b.O()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Xh('.',[c,Xh('$',d)]);a.b=Xh('.',[c,Xh('.',d)]);a.i=d[d.length-1]}
function Qn(a){var b;if(0==a.length){b=(Hh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Gh.title,b)}else{(Hh(),$wnd.goog.global.window).location.hash=a}}
function pi(a,b){var c,d,e;c=b.ab();e=b.bb();d=qd(c)?c==null?ri(Zi(a.a,null)):lj(a.b,c):ri(Zi(a.a,c));if(!(rd(e)===rd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(qd(c)?c==null?!!Zi(a.a,null):kj(a.b,c):!!Zi(a.a,c))){return false}return true}
function Zo(a,b){var c,d;this.i=a;this.g=b;K();this.f=new pc(0,null,new $o(this),false,false);this.d=(d=new jb((c=null,c)),d);this.b=new X(new ap(this),null,null,Rp);this.c=new X(new bp(this),null,null,Rp);this.a=new wb(new cp(this),null,681574400);D((null,J))}
function zo(){var a;this.g=new Wi;K();this.f=new pc(0,new Bo(this),new Ao(this),false,false);this.c=(a=new jb(null),a);this.d=new X(new Eo(this),null,null,Rp);this.e=new X(new Fo(this),null,null,Rp);this.a=new X(new Go(this),null,null,Rp);this.b=new X(new Ho(this),null,null,Rp)}
function Yn(){var a,b,c;this.d=new dp(this);this.f=this.e=(c=(Hh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));K();this.c=new pc(0,null,new Zn(this),false,false);this.b=(b=new jb((a=null,a)),b);this.a=new X(new eo,new $n(this),new _n(this),35651584)}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Qi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=eh(a);if(!md(a,4))throw fh(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.F();return a&&a.C()}},suppressed:{get:function(){return c.D()}}})}catch(a){}}}
function um(a,b,c){var d,e,f;this.n=b;this.o=c;this.f=a;this.i=a.props['a'];K();d=++im;this.e=new pc(d,null,new vm(this),false,false);this.a=(f=new jb((e=null,e)),f);this.c=new X(new ym(this),null,null,136478720);this.b=new wb(null,new Cm(this),Mp);ho(this.i,this,new wm(this));sm(this,this.i);D((null,J))}
function yk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;tk(b,vh(Bk.prototype.ib,Bk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=wk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function gj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}Hi(a.b,new Bb(a));a.b.a=ad(me,yp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function Im(a){var b;a.d=0;nl();b=yk('div',null,[yk('div',null,[yk(Pp,Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,[Pp])),[yk('h1',null,['todos']),(new sn).a]),T(a.e.d)?yk('section',Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,[Pp])),[yk(Op,Jk(Mk(Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,['toggle-all'])),(jl(),Qk)),vh(Gn.prototype.kb,Gn,[a])),null),yk('ul',Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,['todo-list'])),Qj(Oj(T(a.g.c).X(),new Hn),new Ak))]):null,T(a.e.d)?(new Rm).a:null])]);return b}
function jl(){jl=uh;Pk=new kl(Kp,0);Qk=new kl('checkbox',1);Rk=new kl('color',2);Sk=new kl('date',3);Tk=new kl('datetime',4);Uk=new kl('email',5);Vk=new kl('file',6);Wk=new kl('hidden',7);Xk=new kl('image',8);Yk=new kl('month',9);Zk=new kl(wp,10);$k=new kl('password',11);_k=new kl('radio',12);al=new kl('range',13);bl=new kl('reset',14);cl=new kl('search',15);dl=new kl('submit',16);el=new kl('tel',17);fl=new kl('text',18);gl=new kl('time',19);hl=new kl('url',20);il=new kl('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ii(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Mi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ii(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ki(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Oi)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Ap!=(k.b.c&Bp)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function ql(a){var b,c;a.e=0;nl();c=(b=T(a.i.b),yk('footer',Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,['footer'])),[(new Um).a,yk('ul',Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,['filters'])),[yk('li',null,[yk('a',Ek(Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,[(kp(),ip)==b?Lp:null])),'#'),['All'])]),yk('li',null,[yk('a',Ek(Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,[hp==b?Lp:null])),'#active'),['Active'])]),yk('li',null,[yk('a',Ek(Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,[jp==b?Lp:null])),'#completed'),['Completed'])])]),T(a.a)?yk(Kp,Fk(Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,['clear-completed'])),vh(Qm.prototype.mb,Qm,[a])),['Clear Completed']):null]));return c}
function gm(a){var b,c,d;a.g=0;nl();b=(c=a.i,d=(gb(c.a),c.d),yk('li',Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,[d?'checked':null,T(a.c)?'editing':null])),[yk('div',Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,['view'])),[yk(Op,Jk(Hk(Mk(Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,['toggle'])),(jl(),Qk)),d),vh(wn.prototype.kb,wn,[c])),null),yk('label',Ok(new $wnd.Object,vh(xn.prototype.mb,xn,[a,c])),[(gb(c.b),c.e)]),yk(Kp,Fk(Ck(new $wnd.Object,dd($c(pe,1),yp,2,6,['destroy'])),vh(yn.prototype.mb,yn,[a,c])),null)]),yk(Op,Kk(Jk(Ik(Nk(Ck(Dk(new $wnd.Object,vh(zn.prototype.A,zn,[a])),dd($c(pe,1),yp,2,6,['edit'])),(gb(a.a),a.d)),vh(An.prototype.jb,An,[a,c])),vh(vn.prototype.kb,vn,[a])),vh(Bn.prototype.lb,Bn,[a,c])),null)]));return b}
function ij(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Jp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!gj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Jp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var vp='object',wp='number',xp={5:1},yp={3:1},zp={9:1},Ap=1048576,Bp=1835008,Cp=2097152,Dp=4194304,Ep='__noinit__',Fp={3:1,10:1,7:1,4:1},Gp='null',Hp=17592186044416,Ip={41:1},Jp='delete',Kp='button',Lp='selected',Mp=1411518464,Np=142606336,Op='input',Pp='header',Qp='hashchange',Rp=136314880,Sp='active',Tp='completed';var _,qh,lh,dh=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;rh();th(1,null,{},p);_.p=function(a){return o(this,a)};_.q=function(){return this.ob};_.r=Vp;_.s=function(){var a;return Oh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.p(a)};_.hashCode=function(){return this.r()};_.toString=function(){return this.s()};var gd,hd,jd;th(56,1,{},Ph);_.L=function(a){var b;b=new Ph;b.e=4;a>1?(b.c=Uh(this,a-1)):(b.c=this);return b};_.M=function(){Nh(this);return this.b};_.N=function(){return Oh(this)};_.O=function(){Nh(this);return this.i};_.P=function(){return (this.e&4)!=0};_.Q=function(){return (this.e&1)!=0};_.s=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Nh(this),this.k)};_.e=0;_.g=0;var Mh=1;var me=Rh(1);var ce=Rh(56);th(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var xd=Rh(81);th(82,1,xp,G);_.t=function(){Db(this.a)};var ud=Rh(82);th(36,1,{},H);_.u=function(){return this.a.t(),null};var vd=Rh(36);th(83,1,{},I);var wd=Rh(83);var J;th(44,1,{44:1},Q);_.b=0;_.c=false;_.d=0;var yd=Rh(44);th(233,1,zp);_.s=function(){var a;return Oh(this.ob)+'@'+(a=s(this)>>>0,a.toString(16))};var Bd=Rh(233);th(18,233,zp,X);_.v=function(){S(this)};_.w=Up;_.a=false;_.d=0;_.j=false;var Ad=Rh(18);th(127,1,{},Y);_.u=function(){return U(this.a)};var zd=Rh(127);th(16,233,{9:1,16:1},jb);_.v=function(){ab(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Dd=Rh(16);th(126,1,xp,kb);_.t=function(){bb(this.a)};var Cd=Rh(126);th(17,233,{9:1,17:1},wb,xb);_.v=function(){lb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Id=Rh(17);th(139,1,{},yb);_.t=function(){R(this.a)};var Ed=Rh(139);th(140,1,xp,zb);_.t=function(){nb(this.a)};var Fd=Rh(140);th(141,1,xp,Ab);_.t=function(){qb(this.a)};var Gd=Rh(141);th(142,1,{},Bb);_.A=function(a){ob(this.a,a)};var Hd=Rh(142);th(103,1,{},Eb);_.a=0;_.b=0;_.c=0;var Jd=Rh(103);th(168,1,zp,Gb);_.v=function(){Fb(this)};_.w=Up;_.a=false;var Kd=Rh(168);th(66,233,{9:1,66:1},Kb);_.v=function(){Hb(this)};_.w=function(){return 2==(3&this.a)};_.a=0;var Md=Rh(66);th(102,1,{},Pb);var Ld=Rh(102);th(143,1,{},_b);_.s=function(){var a;return Nh(Nd),Nd.k+'@'+(a=kk(this)>>>0,a.toString(16))};_.a=0;var Qb;var Nd=Rh(143);th(115,1,{});var Qd=Rh(115);th(108,1,{},hc);_.A=function(a){fc(this.a,a)};var Od=Rh(108);th(109,1,xp,ic);_.t=function(){gc(this.a,this.b)};var Pd=Rh(109);th(15,1,zp,pc);_.v=function(){kc(this)};_.w=function(){return this.i<0};_.s=function(){var a;return Nh(Sd),Sd.k+'@'+(a=kk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Sd=Rh(15);th(125,1,xp,qc);_.t=function(){nc(this.a)};var Rd=Rh(125);th(4,1,{3:1,4:1});_.B=function(a){return new Error(a)};_.C=$p;_.D=function(){return Qj(Oj(Si((this.i==null&&(this.i=ad(re,yp,4,0,0,1)),this.i)),new li),new Uj)};_.F=function(){return this.f};_.G=function(){return this.g};_.H=function(){tc(this,vc(this.B(uc(this,this.g))));Xc(this)};_.s=function(){return uc(this,this.G())};_.e=Ep;_.j=true;var re=Rh(4);th(10,4,{3:1,10:1,4:1});var fe=Rh(10);th(7,10,Fp);var ne=Rh(7);th(57,7,Fp);var je=Rh(57);th(78,57,Fp);var Wd=Rh(78);th(35,78,{35:1,3:1,10:1,7:1,4:1},Ac);_.G=function(){zc(this);return this.c};_.I=function(){return rd(this.b)===rd(xc)?null:this.b};var xc;var Td=Rh(35);var Ud=Rh(0);th(216,1,{});var Vd=Rh(216);var Cc=0,Dc=0,Ec=-1;th(93,216,{},Sc);var Oc;var Xd=Rh(93);var Vc;th(227,1,{});var Zd=Rh(227);th(79,227,{},Zc);var Yd=Rh(79);th(45,1,{45:1},Ch);_.J=function(){var a;a=this.a;if(rd(a)===rd(Ah)){a=this.a;if(rd(a)===rd(Ah)){a=this.b.J();this.a=Eh(this.a,a);this.b=null}}return a};var Ah;var $d=Rh(45);var Gh;th(76,1,{73:1});_.s=Up;var _d=Rh(76);th(80,7,Fp);var he=Rh(80);th(144,80,Fp,Kh);var ae=Rh(144);gd={3:1,74:1,28:1};var be=Rh(74);th(42,1,{3:1,42:1});var le=Rh(42);hd={3:1,28:1,42:1};var de=Rh(226);th(30,1,{3:1,28:1,30:1});_.p=function(a){return this===a};_.r=Vp;_.s=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ee=Rh(30);th(59,7,Fp,$h);var ge=Rh(59);th(29,42,{3:1,28:1,29:1,42:1},_h);_.p=function(a){return md(a,29)&&a.a==this.a};_.r=Up;_.s=function(){return ''+this.a};_.a=0;var ie=Rh(29);var bi;th(290,1,{});th(84,57,Fp,ei);_.B=function(a){return new TypeError(a)};var ke=Rh(84);jd={3:1,73:1,28:1,2:1};var pe=Rh(2);th(77,76,{73:1},ki);var oe=Rh(77);th(294,1,{});th(71,1,{},li);_.T=function(a){return a.e};var qe=Rh(71);th(60,7,Fp,mi);var se=Rh(60);th(228,1,{40:1});_.R=Zp;_.W=function(){return new Dj(this,0)};_.X=function(){return new Rj(null,this.W())};_.U=function(a){throw fh(new mi('Add not supported on this collection'))};_.s=function(){var a,b,c;c=new Fj('[',']');for(b=this.S();b.Z();){a=b.$();Ej(c,a===this?'(this Collection)':a==null?Gp:xh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var te=Rh(228);th(231,1,{214:1});_.p=function(a){var b,c,d;if(a===this){return true}if(!md(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Ai((new xi(d)).a);c.b;){b=zi(c);if(!pi(this,b)){return false}}return true};_.r=function(){return Ti(new xi(this))};_.s=function(){var a,b,c;c=new Fj('{','}');for(b=new Ai((new xi(this)).a);b.b;){a=zi(b);Ej(c,qi(this,a.ab())+'='+qi(this,a.bb()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ee=Rh(231);th(101,231,{214:1});var we=Rh(101);th(230,228,{40:1,237:1});_.W=function(){return new Dj(this,1)};_.p=function(a){var b;if(a===this){return true}if(!md(a,21)){return false}b=a;if(vi(b.a)!=this.V()){return false}return ni(this,b)};_.r=function(){return Ti(this)};var Fe=Rh(230);th(21,230,{21:1,40:1,237:1},xi);_.S=function(){return new Ai(this.a)};_.V=Xp;var ve=Rh(21);th(22,1,{},Ai);_.Y=Wp;_.$=function(){return zi(this)};_.Z=Yp;_.b=false;var ue=Rh(22);th(229,228,{40:1,234:1});_.W=function(){return new Dj(this,16)};_._=function(a,b){throw fh(new mi('Add not supported on this list'))};_.U=function(a){this._(this.V(),a);return true};_.p=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,13)){return false}f=a;if(this.V()!=f.a.length){return false}e=new Qi(f);for(c=new Qi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(rd(b)===rd(d)||b!=null&&q(b,d))){return false}}return true};_.r=function(){return Ui(this)};_.S=function(){return new Bi(this)};var ye=Rh(229);th(92,1,{},Bi);_.Y=Wp;_.Z=function(){return this.a<this.b.a.length};_.$=function(){return Ii(this.b,this.a++)};_.a=0;var xe=Rh(92);th(43,228,{40:1},Ci);_.S=function(){var a;a=new Ai((new xi(this.a)).a);return new Di(a)};_.V=Xp;var Ae=Rh(43);th(96,1,{},Di);_.Y=Wp;_.Z=function(){return this.a.b};_.$=function(){var a;a=zi(this.a);return a.bb()};var ze=Rh(96);th(94,1,Ip);_.p=function(a){var b;if(!md(a,41)){return false}b=a;return Vi(this.a,b.ab())&&Vi(this.b,b.bb())};_.ab=Up;_.bb=Yp;_.r=function(){return uj(this.a)^uj(this.b)};_.cb=function(a){var b;b=this.b;this.b=a;return b};_.s=function(){return this.a+'='+this.b};var Be=Rh(94);th(95,94,Ip,Ei);var Ce=Rh(95);th(232,1,Ip);_.p=function(a){var b;if(!md(a,41)){return false}b=a;return Vi(this.b.value[0],b.ab())&&Vi(qj(this),b.bb())};_.r=function(){return uj(this.b.value[0])^uj(qj(this))};_.s=function(){return this.b.value[0]+'='+qj(this)};var De=Rh(232);th(13,229,{3:1,13:1,40:1,234:1},Oi,Pi);_._=function(a,b){fk(this.a,a,b)};_.U=function(a){return Gi(this,a)};_.R=function(a){Hi(this,a)};_.S=function(){return new Qi(this)};_.V=function(){return this.a.length};var He=Rh(13);th(14,1,{},Qi);_.Y=Wp;_.Z=function(){return this.a<this.c.a.length};_.$=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ge=Rh(14);th(37,101,{3:1,37:1,214:1},Wi);var Ie=Rh(37);th(63,1,{},aj);_.R=Zp;_.S=function(){return new bj(this)};_.b=0;var Ke=Rh(63);th(64,1,{},bj);_.Y=Wp;_.$=function(){return this.d=this.a[this.c++],this.d};_.Z=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Je=Rh(64);var ej;th(61,1,{},oj);_.R=Zp;_.S=function(){return new pj(this)};_.b=0;_.c=0;var Ne=Rh(61);th(62,1,{},pj);_.Y=Wp;_.$=function(){return this.c=this.a,this.a=this.b.next(),new rj(this.d,this.c,this.d.c)};_.Z=function(){return !this.a.done};var Le=Rh(62);th(114,232,Ip,rj);_.ab=function(){return this.b.value[0]};_.bb=function(){return qj(this)};_.cb=function(a){return mj(this.a,this.b.value[0],a)};_.c=0;var Me=Rh(114);th(129,1,{});_.Y=_p;_.db=function(){return this.d};_.eb=$p;_.d=0;_.e=0;var Re=Rh(129);th(65,129,{});var Oe=Rh(65);th(97,1,{});_.Y=_p;_.db=Yp;_.eb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Qe=Rh(97);th(98,97,{},Bj);_.Y=function(a){yj(this,a)};_.fb=function(a){return zj(this,a)};var Pe=Rh(98);th(19,1,{},Dj);_.db=Up;_.eb=function(){Cj(this);return this.c};_.Y=function(a){Cj(this);this.d.Y(a)};_.fb=function(a){Cj(this);if(this.d.Z()){a.A(this.d.$());return true}return false};_.a=0;_.c=0;var Se=Rh(19);th(58,1,{},Fj);_.s=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Te=Rh(58);th(34,1,{},Gj);_.T=function(a){return a};var Ue=Rh(34);th(38,1,{},Hj);var Ve=Rh(38);th(128,1,{});_.c=false;var df=Rh(128);th(23,128,{},Rj);var cf=Rh(23);th(72,1,{},Uj);_.gb=function(a){return ad(me,yp,1,a,5,1)};var We=Rh(72);th(131,65,{},Wj);_.fb=function(a){this.b=false;while(!this.b&&this.c.fb(new Xj(this,a)));return this.b};_.b=false;var Ye=Rh(131);th(134,1,{},Xj);_.A=function(a){Vj(this.a,this.b,a)};var Xe=Rh(134);th(130,65,{},Zj);_.fb=function(a){return this.b.fb(new $j(this,a))};var $e=Rh(130);th(133,1,{},$j);_.A=function(a){Yj(this.a,this.b,a)};var Ze=Rh(133);th(132,1,{},ak);_.A=function(a){_j(this,a)};var _e=Rh(132);th(135,1,{},bk);_.A=function(a){};var af=Rh(135);th(136,1,{},dk);_.A=function(a){ck(this,a)};var bf=Rh(136);th(292,1,{});th(289,1,{});var jk=0;var lk,mk=0,nk;th(905,1,{});th(928,1,{});th(169,1,{},Ak);_.gb=function(a){return new Array(a)};var ef=Rh(169);th(257,$wnd.Function,{},Bk);_.ib=function(a){zk(this.a,this.b,a)};th(6,30,{3:1,28:1,30:1,6:1},kl);var Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il;var ff=Sh(6,ll);var ml;th(256,$wnd.Function,{},ol);_.K=function(a){return Fb(ml),ml=null,null};th(185,1,{});var Rf=Rh(185);th(186,185,{});_.e=0;var Vf=Rh(186);th(187,186,zp,wl);_.v=aq;_.w=bq;_.s=function(){var a;return Nh(pf),pf.k+'@'+(a=kk(this)>>>0,a.toString(16))};var sl=0;var pf=Rh(187);th(188,1,xp,xl);_.t=function(){tl(this.a)};var gf=Rh(188);th(189,1,{},yl);_.u=function(){return vl(this.a)};var hf=Rh(189);th(191,1,{},zl);_.u=function(){return ql(this.a)};var jf=Rh(191);th(190,1,{},Al);_.t=function(){rl(this.a)};var kf=Rh(190);th(207,1,{});var Qf=Rh(207);th(208,207,{});_.d=0;var Uf=Rh(208);th(209,208,zp,Gl);_.v=cq;_.w=dq;_.s=function(){var a;return Nh(of),of.k+'@'+(a=kk(this)>>>0,a.toString(16))};var El=0;var of=Rh(209);th(210,1,xp,Hl);_.t=eq;var lf=Rh(210);th(211,1,{},Il);_.t=function(){Dl(this.a)};var mf=Rh(211);th(212,1,{},Jl);_.u=function(){return Cl(this.a)};var nf=Rh(212);th(177,1,{});_.g='';var cg=Rh(177);th(178,177,{});_.e=0;var Xf=Rh(178);th(179,178,zp,Vl);_.v=aq;_.w=bq;_.s=function(){var a;return Nh(vf),vf.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Pl=0;var vf=Rh(179);th(180,1,xp,Wl);_.t=function(){Ql(this.a)};var qf=Rh(180);th(182,1,{},Xl);_.u=function(){return Nl(this.a)};var rf=Rh(182);th(183,1,xp,Yl);_.t=function(){Kl(this.a)};var sf=Rh(183);th(181,1,{},Zl);_.t=function(){rl(this.a)};var tf=Rh(181);th(184,1,xp,$l);_.t=function(){Tl(this.a,this.b)};var uf=Rh(184);th(173,1,{});_.k=false;var fg=Rh(173);th(193,173,{});_.g=0;var Zf=Rh(193);th(194,193,zp,um);_.v=function(){kc(this.e)};_.w=function(){return this.e.i<0};_.s=function(){var a;return Nh(Hf),Hf.k+'@'+(a=kk(this)>>>0,a.toString(16))};var im=0;var Hf=Rh(194);th(195,1,xp,vm);_.t=function(){jm(this.a)};var wf=Rh(195);th(198,1,xp,wm);_.t=function(){kc(this.a.e)};var xf=Rh(198);th(199,1,{},xm);_.u=function(){return gm(this.a)};var yf=Rh(199);th(196,1,{},ym);_.u=function(){return mm(this.a)};var zf=Rh(196);th(49,1,xp,zm);_.t=function(){tm(this.a,Un(this.b))};var Af=Rh(49);th(68,1,xp,Am);_.t=function(){dm(this.a,this.b)};var Bf=Rh(68);th(200,1,xp,Bm);_.t=function(){nm(this.a,this.b)};var Cf=Rh(200);th(197,1,{},Cm);_.t=function(){hm(this.a)};var Df=Rh(197);th(201,1,xp,Dm);_.t=function(){om(this.a,this.b)};var Ef=Rh(201);th(202,1,xp,Em);_.t=function(){_l(this.a,this.b)};var Ff=Rh(202);th(203,1,xp,Fm);_.t=function(){em(this.a)};var Gf=Rh(203);th(155,1,{});var jg=Rh(155);th(156,155,{});_.d=0;var _f=Rh(156);th(157,156,zp,Mm);_.v=cq;_.w=dq;_.s=function(){var a;return Nh(Lf),Lf.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Km=0;var Lf=Rh(157);th(158,1,xp,Nm);_.t=eq;var If=Rh(158);th(159,1,{},Om);_.t=function(){Dl(this.a)};var Jf=Rh(159);th(160,1,{},Pm);_.u=function(){return Im(this.a)};var Kf=Rh(160);th(262,$wnd.Function,{},Qm);_.mb=function(a){Ko(this.a.g)};th(171,1,{},Rm);var Mf=Rh(171);th(87,1,{},Sm);var Nf=Rh(87);var Tm;th(192,1,{},Um);var Of=Rh(192);th(91,1,{},Vm);var Pf=Rh(91);var Wm;th(263,$wnd.Function,{},Xm);_.nb=function(a){return new $m(a)};var Ym;th(175,$wnd.React.Component,{},$m);sh(qh[1],_);_.componentWillUnmount=function(){pl(this.a)};_.render=function(){return ul(this.a)};_.shouldComponentUpdate=fq;var Sf=Rh(175);th(273,$wnd.Function,{},_m);_.nb=function(a){return new cn(a)};var an;th(204,$wnd.React.Component,{},cn);sh(qh[1],_);_.componentWillUnmount=function(){Bl(this.a)};_.render=function(){return Fl(this.a)};_.shouldComponentUpdate=gq;var Tf=Rh(204);th(261,$wnd.Function,{},dn);_.nb=function(a){return new gn(a)};var en;th(174,$wnd.React.Component,{},gn);sh(qh[1],_);_.componentWillUnmount=function(){pl(this.a)};_.render=function(){return Rl(this.a)};_.shouldComponentUpdate=fq;var Wf=Rh(174);th(264,$wnd.Function,{},hn);_.nb=function(a){return new ln(a)};var jn;th(176,$wnd.React.Component,{},ln);sh(qh[1],_);_.componentDidUpdate=function(a){$(this.a)&&(rm(this.a),undefined)};_.componentWillUnmount=function(){$(this.a)&&fm(this.a)};_.render=function(){return $(this.a)?km(this.a):null};_.shouldComponentUpdate=function(a){return $(this.a)&&1==this.a.g};var Yf=Rh(176);th(255,$wnd.Function,{},mn);_.nb=function(a){return new pn(a)};var nn;th(99,$wnd.React.Component,{},pn);sh(qh[1],_);_.componentWillUnmount=function(){Bl(this.a)};_.render=function(){return Lm(this.a)};_.shouldComponentUpdate=gq;var $f=Rh(99);th(259,$wnd.Function,{},qn);_.lb=function(a){Ll(this.a,a)};th(260,$wnd.Function,{},rn);_.kb=function(a){Sl(this.a,a)};th(170,1,{},sn);var ag=Rh(170);th(90,1,{},tn);var bg=Rh(90);var un;th(271,$wnd.Function,{},vn);_.kb=function(a){lm(this.a,a)};th(265,$wnd.Function,{},wn);_.kb=function(a){oo(this.a)};th(267,$wnd.Function,{},xn);_.mb=function(a){pm(this.a,this.b)};th(268,$wnd.Function,{},yn);_.mb=function(a){am(this.a,this.b)};th(269,$wnd.Function,{},zn);_.A=function(a){bm(this.a,a)};th(270,$wnd.Function,{},An);_.jb=function(a){qm(this.a,this.b)};th(272,$wnd.Function,{},Bn);_.lb=function(a){cm(this.a,this.b,a)};th(172,1,{},Dn);var dg=Rh(172);th(88,1,{},En);var eg=Rh(88);var Fn;th(254,$wnd.Function,{},Gn);_.kb=function(a){Gm(this.a,a)};th(100,1,{},Hn);_.T=function(a){return Cn(new Dn,a)};var gg=Rh(100);th(70,1,{},In);var hg=Rh(70);th(89,1,{},Jn);var ig=Rh(89);var Kn;th(86,1,{},Ln);var kg=Rh(86);th(48,1,{48:1});var Rg=Rh(48);th(161,48,{9:1,48:1},Yn);_.v=aq;_.w=bq;_.s=function(){var a;return Nh(sg),sg.k+'@'+(a=kk(this)>>>0,a.toString(16))};var sg=Rh(161);th(162,1,xp,Zn);_.t=function(){Sn(this.a)};var lg=Rh(162);th(164,1,{},$n);_.t=function(){Nn(this.a)};var mg=Rh(164);th(165,1,{},_n);_.t=function(){On(this.a)};var ng=Rh(165);th(166,1,xp,ao);_.t=function(){Mn(this.a,this.b)};var og=Rh(166);th(167,1,xp,bo);_.t=function(){Vn(this.a)};var pg=Rh(167);th(67,1,xp,co);_.t=function(){Rn(this.a)};var qg=Rh(67);th(163,1,{},eo);_.u=function(){var a;return a=(Hh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var rg=Rh(163);th(50,1,{50:1});_.d=false;var $g=Rh(50);th(51,50,{9:1,258:1,51:1,50:1},po);_.v=aq;_.p=function(a){return io(this,a)};_.r=function(){return this.c.d};_.w=bq;_.s=function(){var a;return Nh(Ig),Ig.k+'@'+(a=this.c.d>>>0,a.toString(16))};var fo=0;var Ig=Rh(51);th(205,1,xp,qo);_.t=function(){go(this.a)};var tg=Rh(205);th(206,1,xp,ro);_.t=function(){lo(this.a)};var ug=Rh(206);th(116,115,{});var Ug=Rh(116);th(26,116,zp,zo);_.v=hq;_.w=iq;_.s=function(){var a;return Nh(Dg),Dg.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Dg=Rh(26);th(118,1,xp,Ao);_.t=function(){to(this.a)};var vg=Rh(118);th(117,1,xp,Bo);_.t=function(){wo(this.a)};var wg=Rh(117);th(123,1,xp,Co);_.t=function(){cc(this.a,this.b,true)};var xg=Rh(123);th(124,1,{},Do);_.u=function(){return so(this.a,this.c,this.b)};_.b=false;var yg=Rh(124);th(119,1,{},Eo);_.u=function(){return xo(this.a)};var zg=Rh(119);th(120,1,{},Fo);_.u=function(){return ai(kh(Mj(dc(this.a))))};var Ag=Rh(120);th(121,1,{},Go);_.u=function(){return ai(kh(Mj(Nj(dc(this.a),new np))))};var Bg=Rh(121);th(122,1,{},Ho);_.u=function(){return yo(this.a)};var Cg=Rh(122);th(46,1,{46:1});var Zg=Rh(46);th(145,46,{9:1,46:1},Oo);_.v=function(){kc(this.a)};_.w=function(){return this.a.i<0};_.s=function(){var a;return Nh(Hg),Hg.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Hg=Rh(145);th(146,1,xp,Po);_.t=function(){Lo(this.a,this.b)};_.b=false;var Eg=Rh(146);th(147,1,xp,Qo);_.t=function(){Xn(this.b,this.a)};var Fg=Rh(147);th(148,1,xp,Ro);_.t=function(){Mo(this.a)};var Gg=Rh(148);th(47,1,{47:1});var bh=Rh(47);th(149,47,{9:1,47:1},Zo);_.v=hq;_.w=iq;_.s=function(){var a;return Nh(Og),Og.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Og=Rh(149);th(150,1,xp,$o);_.t=function(){Uo(this.a)};var Jg=Rh(150);th(154,1,xp,_o);_.t=function(){Yo(this.a,null)};var Kg=Rh(154);th(151,1,{},ap);_.u=function(){var a;return a=Un(this.a.g),o(Sp,a)?(kp(),hp):o(Tp,a)?(kp(),jp):(kp(),ip)};var Lg=Rh(151);th(152,1,{},bp);_.u=function(){return Wo(this.a)};var Mg=Rh(152);th(153,1,{},cp);_.t=function(){Xo(this.a)};var Ng=Rh(153);th(138,1,{},dp);_.handleEvent=function(a){Pn(this.a,a)};var Pg=Rh(138);th(105,1,{},ep);_.J=function(){return new Yn};var Qg=Rh(105);var fp;th(31,30,{3:1,28:1,30:1,31:1},lp);var hp,ip,jp;var Sg=Sh(31,mp);th(107,1,{},np);_.hb=function(a){return !ko(a)};var Tg=Rh(107);th(111,1,{},op);_.hb=function(a){return ko(a)};var Vg=Rh(111);th(112,1,{},pp);_.A=function(a){vo(this.a,a)};var Wg=Rh(112);th(110,1,{},qp);_.A=function(a){Jo(this.a,a)};_.a=false;var Xg=Rh(110);th(104,1,{},rp);_.J=function(){return new Oo(new zo)};var Yg=Rh(104);th(113,1,{},sp);_.hb=function(a){return To(this.a,a)};var _g=Rh(113);th(106,1,{},tp);_.J=function(){return new Zo(new zo,this.a.J())};var ah=Rh(106);var td=Th('D');var up=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=oh;mh(zh);ph('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();