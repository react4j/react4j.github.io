function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='FC6274E612FD81870F7B3AB148A06F85',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'FC6274E612FD81870F7B3AB148A06F85';function p(){}
function wh(){}
function sh(){}
function Fb(){}
function Qc(){}
function Xc(){}
function Xj(){}
function Bj(){}
function Pj(){}
function Yj(){}
function fi(){}
function wk(){}
function kl(){}
function Sm(){}
function Wm(){}
function $m(){}
function $n(){}
function cn(){}
function gn(){}
function Cn(){}
function ap(){}
function jp(){}
function mp(){}
function np(){}
function Vc(a){Uc()}
function Fh(){Fh=sh}
function Ii(){zi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function fc(a){this.a=a}
function oc(a){this.a=a}
function Vh(a){this.a=a}
function ei(a){this.a=a}
function ri(a){this.a=a}
function wi(a){this.a=a}
function xi(a){this.a=a}
function vi(a){this.b=a}
function Ki(a){this.c=a}
function Cj(a){this.a=a}
function $j(a){this.a=a}
function tl(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function Dl(a){this.a=a}
function El(a){this.a=a}
function Fl(a){this.a=a}
function Sl(a){this.a=a}
function Tl(a){this.a=a}
function Ul(a){this.a=a}
function Wl(a){this.a=a}
function rm(a){this.a=a}
function sm(a){this.a=a}
function xm(a){this.a=a}
function zm(a){this.a=a}
function Am(a){this.a=a}
function Im(a){this.a=a}
function Jm(a){this.a=a}
function Km(a){this.a=a}
function Lm(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function qn(a){this.a=a}
function rn(a){this.a=a}
function un(a){this.a=a}
function Bn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function Wn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function wo(a){this.a=a}
function xo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function No(a){this.a=a}
function Wo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function op(a){this.a=a}
function pp(a){this.a=a}
function qp(a){this.a=a}
function rp(a){this.a=a}
function Wj(a,b){a.a=b}
function pk(a,b){a.key=b}
function ok(a,b){nk(a,b)}
function Fo(a,b){pm(b,a)}
function Y(a){!!a&&$(a)}
function jc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function Zp(a){mj(this,a)}
function cq(a){qj(this,a)}
function aq(a){Zh(this,a)}
function eq(){ic(this.c)}
function gq(){ic(this.b)}
function lq(){ic(this.f)}
function Wi(){this.a=dj()}
function ij(){this.a=dj()}
function qb(a,b){a.b=pj(b)}
function Yl(a,b){qo(a.j,b)}
function Eo(a,b){po(a.b,b)}
function mc(a,b){ni(a.e,b)}
function Zj(a,b){Oj(a.a,b)}
function C(a,b){Ob(a.f,b.f)}
function db(a){Yb((J(),a))}
function eb(a){Zb((J(),a))}
function hb(a){$b((J(),a))}
function iq(){kb(this.a.a)}
function dh(a){return a.e}
function bq(){return this.e}
function Xp(){return this.a}
function _p(){return this.b}
function _i(){_i=sh;$i=bj()}
function J(){J=sh;I=new F}
function wc(){wc=sh;vc=new p}
function Nc(){Nc=sh;Mc=new Qc}
function cp(){cp=sh;bp=new ap}
function lp(){lp=sh;kp=new jp}
function ll(a){a.d=2;ic(a.c)}
function xl(a){a.c=2;ic(a.b)}
function bm(a){a.f=2;ic(a.e)}
function rc(a,b){a.e=b;qc(a,b)}
function Nn(a){R(a.a);$(a.b)}
function Ml(a){kb(a.a);$(a.b)}
function pl(a){kb(a.b);R(a.a)}
function ao(a){$(a.b);$(a.a)}
function Ib(a){a.a=-4&a.a|1}
function Zl(a,b){return a.g=b}
function Ci(a,b){return a.a[b]}
function dq(a){return this===a}
function Yp(){return fk(this)}
function Eh(a){uc.call(this,a)}
function gi(a){uc.call(this,a)}
function ck(a,b){a.splice(b,1)}
function hc(a,b,c){mi(a.e,b,c)}
function bo(a,b,c){hc(a.c,b,c)}
function vj(a,b,c){b.w(a.a[c])}
function K(a,b){O(a);L(a,pj(b))}
function Yc(a,b){return Oh(a,b)}
function $p(){return pi(this.a)}
function fq(){return this.c.i<0}
function hq(){return this.b.i<0}
function mq(){return this.f.i<0}
function $h(){pc(this);this.G()}
function Dc(){Dc=sh;!!(Uc(),Tc)}
function lh(){jh==null&&(jh=[])}
function Ih(a){Hh(a);return a.k}
function Nj(a,b){a.T(b);return a}
function T(a){mb(a.f);return V(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function ab(a){J();Zb(a);a.e=-2}
function dj(){_i();return new $i}
function Pn(a){fb(a.b);return a.e}
function Ro(a){fb(a.d);return a.e}
function fo(a){fb(a.a);return a.d}
function zk(a,b){a.ref=b;return a}
function qj(a,b){while(a.eb(b));}
function Oj(a,b){Wj(a,Nj(a.a,b))}
function Tj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function fj(a,b){return a.a.get(b)}
function pi(a){return a.a.b+a.b.b}
function jq(a){return 1==this.a.d}
function kq(a){return 1==this.a.c}
function gc(a,b){this.a=a;this.b=b}
function Th(a,b){this.a=a;this.b=b}
function yi(a,b){this.a=a;this.b=b}
function Sj(a,b){this.a=a;this.b=b}
function Vj(a,b){this.a=a;this.b=b}
function Vl(a,b){this.a=a;this.b=b}
function xk(a,b){this.a=a;this.b=b}
function tm(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function wm(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function sn(a,b){this.a=a;this.b=b}
function tn(a,b){this.a=a;this.b=b}
function vn(a,b){this.a=a;this.b=b}
function wn(a,b){this.a=a;this.b=b}
function gl(a,b){Th.call(this,a,b)}
function Xn(a,b){this.a=a;this.b=b}
function yo(a,b){this.a=a;this.b=b}
function Lo(a,b){this.a=a;this.b=b}
function Mo(a,b){this.b=a;this.a=b}
function hp(a,b){Th.call(this,a,b)}
function sp(a,b){this.b=a;this.a=b}
function Ak(a,b){a.href=b;return a}
function ak(a,b,c){a.splice(b,0,c)}
function Mm(){this.a=qk((Um(),Tm))}
function Pm(){this.a=qk((Ym(),Xm))}
function nn(){this.a=qk((an(),_m))}
function yn(){this.a=qk((en(),dn))}
function Dn(){this.a=qk((jn(),hn))}
function on(a){this.a=pj(a);pn=this}
function Qm(a){this.a=pj(a);Rm=this}
function Qn(a){On(a,(fb(a.b),a.e))}
function go(a){pm(a,(fb(a.a),!a.d))}
function Ub(a){return !a.d?a:Ub(a.d)}
function li(a){return !a?null:a.ab()}
function oj(a){return a!=null?s(a):0}
function pd(a){return a==null?null:a}
function md(a){return typeof a===vp}
function o(a,b){return pd(a)===pd(b)}
function oi(a){a.a=new Wi;a.b=new ij}
function zi(a){a.a=$c(je,xp,1,0,5,1)}
function Kc(a){$wnd.clearTimeout(a)}
function fm(a){kb(a.b);R(a.c);$(a.a)}
function pb(a){J();ob(a);sb(a,2,true)}
function bk(a,b){_j(b,0,a,0,b.length)}
function Jk(a,b){a.value=b;return a}
function Ek(a,b){a.onBlur=b;return a}
function Bk(a,b){a.onClick=b;return a}
function Dk(a,b){a.checked=b;return a}
function Fk(a,b){a.onChange=b;return a}
function ci(a,b){a.a+=''+b;return a}
function ec(a,b){cc(a,b,false);eb(a.d)}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function cd(a,b,c){return {l:a,m:b,h:c}}
function _h(a,b){return a.charCodeAt(b)}
function fk(a){return a.$H||(a.$H=++ek)}
function Z(a){return !(!!a&&1==(a.c&7))}
function kd(a,b){return a!=null&&hd(a,b)}
function nk(a,b){for(var c in a){b(c)}}
function Gk(a,b){a.onKeyDown=b;return a}
function Ck(a){a.autoFocus=true;return a}
function Hh(a){if(a.k!=null){return}Qh(a)}
function ib(a){this.c=new Ii;this.b=a}
function Db(a){this.d=pj(a);this.b=100}
function yh(a){this.b=pj(a);this.a=this}
function uc(a){this.g=a;pc(this);this.G()}
function Mj(a,b){Fj.call(this,a);this.a=b}
function dc(a,b){mc(b.c,a);kd(b,9)&&b.t()}
function mj(a,b){while(a.Y()){Zj(b,a.Z())}}
function fb(a){var b;Vb((J(),b=Qb,b),a)}
function Yi(a,b){var c;c=a[Kp];c.call(a,b)}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function jk(){jk=sh;gk=new p;ik=new p}
function Qi(){this.a=new Wi;this.b=new ij}
function P(){this.a=$c(je,xp,1,100,5,1)}
function Yh(){Yh=sh;Xh=$c(fe,xp,30,256,0,1)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function Qo(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function uo(a){return Wh(S(a.e).a-S(a.a).a)}
function od(a){return typeof a==='string'}
function ld(a){return typeof a==='boolean'}
function Ec(a,b,c){return a.apply(b,c);var d}
function Nb(a,b,c){Ib(pj(c));K(a.a[b],pj(c))}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function mm(a){A((J(),J(),I),new zm(a),Pp)}
function Rn(a){A((J(),J(),I),new Yn(a),Pp)}
function jo(a){A((J(),J(),I),new mo(a),Pp)}
function Go(a){A((J(),J(),I),new No(a),Pp)}
function Nl(a,b){A((J(),J(),I),new Vl(a,b),Pp)}
function gm(a,b){A((J(),J(),I),new ym(a,b),Pp)}
function km(a,b){A((J(),J(),I),new vm(a,b),Pp)}
function lm(a,b){A((J(),J(),I),new um(a,b),Pp)}
function om(a,b){A((J(),J(),I),new tm(a,b),Pp)}
function qo(a,b){A((J(),J(),I),new yo(a,b),Pp)}
function Jo(a,b){A((J(),J(),I),new Lo(a,b),Pp)}
function tj(a,b){while(a.c<a.d){vj(a,b,a.c++)}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function zo(a,b){this.a=a;this.c=b;this.b=false}
function lj(a,b,c){this.a=a;this.b=b;this.c=c}
function F(){this.f=new Pb;this.a=new Db(this.f)}
function Uc(){Uc=sh;var a;!Wc();a=new Xc;Tc=a}
function zh(a){pj(a);return kd(a,45)?a:new yh(a)}
function Lh(a){var b;b=Kh(a);Sh(a,b);return b}
function pc(a){a.j&&a.e!==Fp&&a.G();return a}
function Kk(a,b){a.onDoubleClick=b;return a}
function Ai(a,b){a.a[a.a.length]=b;return true}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Ol(a,b){var c;c=b.target;Ql(a,c.value)}
function Gj(a,b){var c;return Kj(a,(c=new Ii,c))}
function Nh(a){var b;b=Kh(a);b.j=a;b.e=1;return b}
function ti(a){var b;b=a.a.Z();a.b=si(a);return b}
function xj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Qj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function Ch(a,b,c,d){a.addEventListener(b,c,d)}
function Dh(a,b,c,d){a.removeEventListener(b,c,d)}
function ej(a,b){return !(a.a.get(b)===undefined)}
function Oo(a){return o(Up,a)||o(Vp,a)||o('',a)}
function Li(a,b){return rj(b,a.length),new wj(a,b)}
function to(a){return Fh(),0==S(a.e).a?true:false}
function Mi(a){return new Mj(null,Li(a,a.length))}
function ad(a){return Array.isArray(a)&&a.pb===wh}
function jd(a){return !Array.isArray(a)&&a.pb===wh}
function ql(a){return Fh(),S(a.e.b).a>0?true:false}
function Bl(a){return B((J(),J(),I),a.a,new Fl(a))}
function Pl(a){return B((J(),J(),I),a.a,new Tl(a))}
function rl(a){return B((J(),J(),I),a.b,new wl(a))}
function nm(a){return B((J(),J(),I),a.b,new sm(a))}
function Gm(a){return B((J(),J(),I),a.a,new Km(a))}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ei(a,b){var c;c=a.a[b];ck(a.a,b);return c}
function Gi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Bm(a,b){var c;c=b.target;Jo(a.e,c.checked)}
function oo(a){R(a.c);R(a.e);R(a.a);R(a.b);$(a.d)}
function so(a){Zh(new wi(a.g),new fc(a));oi(a.g)}
function Dj(a){if(!a.b){Ej(a);a.c=true}else{Dj(a.b)}}
function ml(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function yl(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function cm(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function mk(){if(hk==256){gk=ik;ik=new p;hk=0}++hk}
function pj(a){if(a==null){throw dh(new $h)}return a}
function qi(a,b){if(b){return ji(a.a,b)}return false}
function Ij(a,b){Ej(a);return new Mj(a,new Rj(b,a.a))}
function Jj(a,b){Ej(a);return new Mj(a,new Uj(b,a.a))}
function On(a,b){A((J(),J(),I),new Xn(a,b),75497472)}
function Ql(a,b){var c;c=a.f;if(b!=c){a.f=b;eb(a.b)}}
function pm(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function Mn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&Sn(a,b)}
function Sn(a,b){var c;c=a.e;if(b!=c){a.e=pj(b);eb(a.b)}}
function gb(a){var b;J();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function hm(a,b){Uo(a.k,b);A((J(),J(),I),new tm(a,b),Pp)}
function Ho(a,b){Gj(ro(a.b),new Cj(new Bj)).Q(new pp(b))}
function Ik(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Mh(a,b){var c;c=Kh(a);Sh(a,c);c.e=b?8:0;return c}
function Pi(a,b){return pd(a)===pd(b)||a!=null&&q(a,b)}
function sj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function yj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function wj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Fj(a){if(!a){this.b=null;new Ii}else{this.b=a}}
function Ph(a){if(a.P()){return null}var b=a.j;return oh[b]}
function ih(a){if(md(a)){return a|0}return a.l|a.m<<22}
function Bh(){Bh=sh;Ah=$wnd.goog.global.document}
function ip(){gp();return bd(Yc(Pg,1),xp,32,0,[dp,fp,ep])}
function ki(a,b){return b===a?'(this Map)':b==null?Hp:vh(b)}
function sc(a,b){var c;c=Ih(a.nb);return b==null?c:c+': '+b}
function Xl(a,b){var c;if(S(a.c)){c=b.target;pm(a,c.value)}}
function Zh(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function Rb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Cp)&&D((null,I))}
function im(a,b){A((J(),J(),I),new tm(a,b),Pp);Uo(a.k,null)}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function uh(a){function b(){}
;b.prototype=a||{};return new b}
function Ej(a){if(a.b){Ej(a.b)}else if(a.c){throw dh(new Uh)}}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function In(a){Ch((Bh(),$wnd.goog.global.window),Sp,a.d,false)}
function Jn(a){Dh((Bh(),$wnd.goog.global.window),Sp,a.d,false)}
function jm(a){return Fh(),Ro(a.k)==a.n.props['a']?true:false}
function en(){en=sh;var a;dn=(a=th(cn.prototype.mb,cn,[]),a)}
function jn(){jn=sh;var a;hn=(a=th(gn.prototype.mb,gn,[]),a)}
function an(){an=sh;var a;_m=(a=th($m.prototype.mb,$m,[]),a)}
function Um(){Um=sh;var a;Tm=(a=th(Sm.prototype.mb,Sm,[]),a)}
function Ym(){Ym=sh;var a;Xm=(a=th(Wm.prototype.mb,Wm,[]),a)}
function Oh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function Si(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ti(a,b){var c;return Ri(b,Si(a,b==null?0:(c=s(b),c|0)))}
function ro(a){fb(a.d);return new Mj(null,new yj(new wi(a.g),0))}
function Kn(a,b){b.preventDefault();A((J(),J(),I),new Zn(a),Pp)}
function Uj(a,b){sj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function Nm(a,b,c){this.a=pj(a);this.b=pj(b);this.c=pj(c);Om=this}
function zn(a,b,c){this.a=pj(a);this.b=pj(b);this.c=pj(c);An=this}
function En(a,b,c){this.a=pj(a);this.b=pj(b);this.c=pj(c);Fn=this}
function Xi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Ji(a){zi(this);bk(this.a,ii(a,$c(je,xp,1,pi(a.a),5,1)))}
function lc(a){jc(a.g);!!a.e&&kc(a);Y(a.a);Y(a.c);jc(a.b);jc(a.f)}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function uj(a,b){if(a.c<a.d){vj(a,b,a.c++);return true}return false}
function Hk(a){a.placeholder='What needs to be done?';return a}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function qh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function vk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function po(a,b){var c;return u((J(),J(),I),new zo(a,b),Pp,(c=null,c))}
function Io(a){Gj(Ij(ro(a.b),new np),new Cj(new Bj)).Q(new op(a.b))}
function Hj(a){var b;Dj(a);b=0;while(a.a.eb(new Yj)){b=eh(b,1)}return b}
function Kj(a,b){var c;Dj(a);c=new Xj;c.a=b;a.a.X(new $j(c));return c.a}
function zj(a,b){!a.a?(a.a=new ei(a.d)):ci(a.a,a.b);ci(a.a,b);return a}
function ni(a,b){return od(b)?b==null?Vi(a.a,null):hj(a.b,b):Vi(a.a,b)}
function bb(a,b){var c,d;Ai(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Rj(a,b){sj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function jj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Aj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Ko(a){this.b=pj(a);J();this.a=new nc(0,null,null,false,false)}
function Jb(b){try{b.b.v()}catch(a){a=bh(a);if(!kd(a,4))throw dh(a)}}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Gl(a){var b;b=bi((fb(a.b),a.f));if(b.length>0){Eo(a.e,b);Ql(a,'')}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Bi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Lj(a,b){var c;c=Gj(a,new Cj(new Bj));return Hi(c,b.fb(c.a.length))}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function kj(a){if(a.a.c!=a.c){return fj(a.a,a.b.value[0])}return a.b.value[1]}
function ui(a){this.d=a;this.c=new jj(this.d.b);this.a=this.c;this.b=si(this)}
function Zm(a){$wnd.React.Component.call(this,a);this.a=new Cl(this,Rm.a)}
function bn(a){$wnd.React.Component.call(this,a);this.a=new Rl(this,pn.a)}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Po(a,b){return (gp(),ep)==a||(dp==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function mi(a,b,c){return od(b)?b==null?Ui(a.a,null,c):gj(a.b,b,c):Ui(a.a,b,c)}
function dk(a,b){return Zc(b)!=10&&bd(r(b),b.ob,b.__elementTypeId$,Zc(b),a),a}
function Hn(a,b){a.f=b;o(b,S(a.a))&&Sn(a,b);Ln(b);A((J(),J(),I),new Zn(a),Pp)}
function So(a){var b;return b=S(a.b),Gj(Ij(ro(a.i),new rp(b)),new Cj(new Bj))}
function ic(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new oc(a)),67108864,null)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function V(a){if(a.b){if(kd(a.b,7)){throw dh(a.b)}else{throw dh(a.b)}}return a.n}
function co(a,b){var c;if(kd(b,52)){c=b;return a.c.d==c.c.d}else{return false}}
function Fi(a,b){var c;c=Di(a,b,0);if(c==-1){return false}ck(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&bd(Yc(a,f),b,c,e,g);return g}
function Di(a,b,c){for(;c<a.a.length;++c){if(Pi(b,a.a[c])){return c}}return -1}
function rb(b){if(b){try{b.v()}catch(a){a=bh(a);if(kd(a,4)){J()}else throw dh(a)}}}
function bc(){var a;try{Sb(Qb);J()}finally{a=Qb.d;!a&&((J(),J(),I).d=true);Qb=Qb.d}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ii);Ai(a.b,b)}}}
function Pb(){var a;this.a=$c(vd,xp,44,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function kh(){lh();var a=jh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Uh(){uc.call(this,"Stream already terminated, can't be modified or used")}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nd(a){return a!=null&&(typeof a===up||typeof a==='function')&&!(a.pb===wh)}
function nh(a,b){typeof window===up&&typeof window['$gwt']===up&&(window['$gwt'][a]=b)}
function Sh(a,b){var c;if(!a){return}b.j=a;var d=Ph(b);if(!d){oh[a]=[b];return}d.nb=b}
function th(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Kh(a){var b;b=new Jh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function qk(a){var b;b=sk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function tk(a){var b;return rk($wnd.React.StrictMode,null,null,(b={},b[Lp]=pj(a),b))}
function Hl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Ul(a),Pp)}}
function Vm(a){$wnd.React.Component.call(this,a);this.a=new sl(this,Om.a,Om.b,Om.c)}
function fn(a){$wnd.React.Component.call(this,a);this.a=new qm(this,An.a,An.b,An.c)}
function kn(a){$wnd.React.Component.call(this,a);this.a=new Hm(this,Fn.a,Fn.b,Fn.c)}
function ob(a){var b,c;for(c=new Ki(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ni(a){var b,c,d;d=0;for(c=new ui(a.a);c.b;){b=ti(c);d=d+(b?s(b):0);d=d|0}return d}
function hi(a,b){var c,d;for(d=new ui(b.a);d.b;){c=ti(d);if(!qi(a,c)){return false}}return true}
function hj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Yi(a.a,b);--a.b}return c}
function no(a,b,c){var d;d=new ko(b,c);bo(d,a,new gc(a,d));mi(a.g,Wh(d.c.d),d);eb(a.d);return d}
function rk(a,b,c,d){var e;e=sk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=pj(d);return e}
function xn(a,b){pk(a.a,(Hh(cg),cg.k+(''+(b?Wh(b.c.d):null))));pj(b);a.a.props['a']=b;return a.a}
function si(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new Xi(a.d.a);return a.a.Y()}
function bh(a){var b;if(kd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new yc(a);Vc(b)}return b}
function fh(a){var b;b=a.h;if(b==0){return a.l+a.m*Dp}if(b==1048575){return a.l+a.m*Dp-Ip}return a}
function hh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Ip;d=1048575}c=qd(e/Dp);b=qd(e-c*Dp);return cd(b,c,d)}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Ii);a.c=c.c}b.d=true;Ai(a.c,pj(b))}
function cc(a,b,c){var d;d=ni(a.g,b?Wh(b.c.d):null);if(null!=d){mc(b.c,a);c&&!!b&&ic(b.c);eb(a.d)}}
function gj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function bd(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=wh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ri(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Pi(a,c._())){return c}}return null}
function Uo(a,b){var c;c=a.e;if(!(b==c||!!b&&co(b,c))){!!c&&mc(c.c,a);a.e=b;!!b&&bo(b,a,new Xo(a));eb(a.d)}}
function To(a){var b;b=S(a.g.a);o(Up,b)||o(Vp,b)||o('',b)?On(a.g,b):Oo(Pn(a.g))?Rn(a.g):On(a.g,'')}
function Kb(a,b){this.b=pj(a);this.a=b|0|(0==(b&6291456)?Dp:0)|(0!=(b&229376)?0:98304)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:zp)|(0==(c&6291456)?!a?Cp:Dp:0)|0|0|0)}
function $l(a,b,c){27==c.which?A((J(),J(),I),new wm(a,b),Pp):13==c.which&&A((J(),J(),I),new um(a,b),Pp)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function jl(){if(!il){il=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(th(kl.prototype.J,kl,[]))}}
function rj(a,b){if(0>a||a>b){throw dh(new Eh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function gp(){gp=sh;dp=new hp('ACTIVE',0);fp=new hp('COMPLETED',1);ep=new hp('ALL',2)}
function yc(a){wc();pc(this);this.e=a;qc(this,a);this.g=a==null?Hp:vh(a);this.a='';this.b=a;this.a=''}
function Jh(){this.g=Gh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Gn(){this.a=zh((lp(),kp));this.b=zh(new qp(this.a));this.c=zh((cp(),bp));this.d=zh(new sp(this.a,this.c))}
function Wh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Yh(),Xh)[b];!c&&(c=Xh[b]=new Vh(a));return c}return new Vh(a)}
function vh(a){var b;if(Array.isArray(a)&&a.pb===wh){return Ih(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function lk(a){jk();var b,c,d;c=':'+a;d=ik[c];if(d!=null){return qd(d)}d=gk[c];b=d==null?kk(a):qd(d);mk();ik[c]=b;return b}
function Oi(a){var b,c,d;d=1;for(c=new Ki(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function cb(a,b){var c,d;d=a.c;Fi(d,b);!!a.b&&zp!=(a.b.c&Ap)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((J(),c=Qb,c),a))}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=Ei(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function am(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;om(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&zp)?Jb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function r(a){return od(a)?me:md(a)?ae:ld(a)?$d:jd(a)?a.nb:ad(a)?a.nb:a.nb||Array.isArray(a)&&Yc(Rd,1)||Rd}
function s(a){return od(a)?lk(a):md(a)?qd(a):ld(a)?a?1231:1237:jd(a)?a.q():ad(a)?fk(a):!!a&&!!a.hashCode?a.hashCode():fk(a)}
function dd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return cd(c&4194303,d&4194303,e&1048575)}
function eh(a,b){var c;if(md(a)&&md(b)){c=a+b;if(-17592186044416<c&&c<Ip){return c}}return fh(dd(md(a)?hh(a):a,md(b)?hh(b):b))}
function _l(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Mo(b,c),Pp);Uo(a.k,null);pm(a,c)}else{qo(a.j,b)}}
function hl(){fl();return bd(Yc(df,1),xp,6,0,[Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el])}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(zp==(b&Ap)?0:524288)|(0==(b&6291456)?zp==(b&Ap)?Dp:Cp:0)|0|268435456|0)}
function Rh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Hi(a,b){var c,d;d=a.a.length;b.length<d&&(b=dk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a){var b,c,d;for(c=new Ki(new Ji(new ri(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();kd(d,9)&&d.u()||b.ab().v()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function q(a,b){return od(a)?o(a,b):md(a)?pd(a)===pd(b):ld(a)?pd(a)===pd(b):jd(a)?a.o(b):ad(a)?o(a,b):!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function hd(a,b){if(od(a)){return !!gd[b]}else if(a.ob){return !!a.ob[b]}else if(md(a)){return !!fd[b]}else if(ld(a)){return !!ed[b]}return false}
function nc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Qi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Cl(a,b){var c;this.d=pj(b);this.n=pj(a);J();c=++Al;this.b=new nc(c,null,new Dl(this),false,false);this.a=new vb(null,pj(new El(this)),Op)}
function yk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Qb&&!!Qb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function bi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ii(a,b){var c,d,e,f;f=pi(a.a);b.length<f&&(b=dk(new Array(f),b));e=b;d=new ui(a.a);for(c=0;c<f;++c){e[c]=ti(d)}b.length>f&&(b[f]=null);return b}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.v(),null)}finally{bc()}return f}catch(a){a=bh(a);if(kd(a,4)){e=a;throw dh(e)}else throw dh(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.s()}else{ac(b,e);try{g=c.s()}finally{bc()}}return g}catch(a){a=bh(a);if(kd(a,4)){f=a;throw dh(f)}else throw dh(a)}finally{D(b)}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Bb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Hb(c);return true}
function mh(b,c,d,e){lh();var f=jh;$moduleName=c;$moduleBase=d;ah=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{tp(g)()}catch(a){b(c,a)}}else{tp(g)()}}
function W(a,b,c,d){this.c=pj(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);zp==(d&Ap)&&lb(this.f)}
function ko(a,b){var c,d,e,f,g;this.e=pj(a);this.d=b;J();c=++_n;this.c=new nc(c,null,new lo(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Rl(a,b){var c,d,e;this.e=pj(b);this.n=pj(a);J();c=++Ll;this.c=new nc(c,null,new Sl(this),false,false);this.b=(e=new ib((d=null,d)),e);this.a=new vb(null,pj(new Wl(this)),Op)}
function Hm(a,b,c,d){var e;this.d=pj(b);this.e=pj(c);this.f=pj(d);this.n=pj(a);J();e=++Fm;this.b=new nc(e,null,new Im(this),false,false);this.a=new vb(null,pj(new Jm(this)),Op)}
function sk(a,b){var c;c=new $wnd.Object;c.$$typeof=pj(a);c.type=pj(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function bj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return cj()}}
function zl(a){var b,c,d;a.c=0;jl();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),uk('span',yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,['todo-count'])),[uk('strong',null,[c]),' '+d+' left']));return b}
function ph(){oh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Rc(c,g)):g[0].qb()}catch(a){a=bh(a);if(kd(a,4)){d=a;Dc();Jc(kd(d,36)?d.H():d)}else throw dh(a)}}return c}
function Kl(a){var b;a.d=0;jl();b=uk(Qp,Ck(Fk(Gk(Jk(Hk(yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,['new-todo']))),(fb(a.b),a.f)),th(ln.prototype.kb,ln,[a])),th(mn.prototype.jb,mn,[a]))),null);return b}
function xc(a){var b;if(a.c==null){b=pd(a.b)===pd(vc)?null:a.b;a.d=b==null?Hp:nd(b)?b==null?null:b.name:od(b)?'String':Ih(r(b));a.a=a.a+': '+(nd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(pd(e)===pd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=bh(a);if(kd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw dh(c)}else throw dh(a)}}
function _j(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Ui(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ri(b,e);if(f){return f.bb(c)}}e[e.length]=new yi(b,c);++a.b;return null}
function kk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+_h(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=bh(a);if(kd(a,4)){J()}else throw dh(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=$c(je,xp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function sl(a,b,c,d){var e;this.e=pj(b);this.f=pj(c);this.g=pj(d);this.n=pj(a);J();e=++ol;this.c=new nc(e,null,new tl(this),false,false);this.a=new W(new ul(this),null,null,136478720);this.b=new vb(null,pj(new vl(this)),Op)}
function ub(a,b,c,d){this.b=new Ii;this.f=new Kb(new yb(this),d&6520832|262144|zp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Cp)&&D((null,I)))}
function Vi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Pi(b,e._())){if(d.length==1){d.length=0;Yi(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function xh(){var a;a=new Gn;new Nm(a.a.I(),a.b.I(),a.d.I());new zn(a.a.I(),a.b.I(),a.d.I());new En(a.a.I(),a.b.I(),a.d.I());new on(a.b.I());new Qm(a.a.I());$wnd.ReactDOM.render(tk([(new Dn).a]),(Bh(),Ah).getElementById('app'),null)}
function rh(a,b,c){var d=oh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=oh[b]),uh(h));_.ob=c;!b&&(_.pb=wh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Qh(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Rh('.',[c,Rh('$',d)]);a.b=Rh('.',[c,Rh('.',d)]);a.i=d[d.length-1]}
function Ln(a){var b;if(0==a.length){b=(Bh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Ah.title,b)}else{(Bh(),$wnd.goog.global.window).location.hash=a}}
function ji(a,b){var c,d,e;c=b._();e=b.ab();d=od(c)?c==null?li(Ti(a.a,null)):fj(a.b,c):li(Ti(a.a,c));if(!(pd(e)===pd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(od(c)?c==null?!!Ti(a.a,null):ej(a.b,c):!!Ti(a.a,c))){return false}return true}
function uk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ok(b,th(xk.prototype.hb,xk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Lp]=c[0],undefined):(d[Lp]=c,undefined));return rk(a,e,f,d)}
function Tn(){var a,b,c;this.d=new _o(this);this.f=this.e=(c=(Bh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new nc(0,null,new Un(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new $n,new Vn(this),new Wn(this),35651584)}
function Vo(a,b){var c,d;this.i=pj(a);this.g=pj(b);J();this.f=new nc(0,null,new Wo(this),false,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new Yo(this),null,null,Tp);this.c=new W(new Zo(this),null,null,Tp);this.a=new vb(pj(new $o(this)),null,681574400);D((null,I))}
function vo(){var a;this.g=new Qi;J();this.f=new nc(0,new xo(this),new wo(this),false,false);this.d=(a=new ib(null),a);this.c=new W(new Ao(this),null,null,Tp);this.e=new W(new Bo(this),null,null,Tp);this.a=new W(new Co(this),null,null,Tp);this.b=new W(new Do(this),null,null,Tp)}
function qm(a,b,c,d){var e,f,g;this.j=pj(b);pj(c);this.k=pj(d);this.n=pj(a);J();e=++em;this.e=new nc(e,null,new rm(this),false,false);this.a=(g=new ib((f=null,f)),g);this.c=new W(new xm(this),null,null,136478720);this.b=new vb(null,pj(new Am(this)),Op);om(this,this.n.props['a'])}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ki(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=bh(a);if(!kd(a,4))throw dh(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function qc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function aj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}Bi(a.b,new Ab(a));a.b.a=$c(je,xp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Em(a){var b;a.c=0;jl();b=uk('div',null,[uk('div',null,[uk(Rp,yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,[Rp])),[uk('h1',null,['todos']),(new nn).a]),S(a.d.c)?null:uk('section',yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,[Rp])),[uk(Qp,Fk(Ik(yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,['toggle-all'])),(fl(),Mk)),th(Bn.prototype.jb,Bn,[a])),null),uk('ul',yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,['todo-list'])),Lj(pj(Jj(S(a.f.c).W(),new Cn)),new wk))]),S(a.d.c)?null:(new Mm).a])]);return b}
function fl(){fl=sh;Lk=new gl(Mp,0);Mk=new gl('checkbox',1);Nk=new gl('color',2);Ok=new gl('date',3);Pk=new gl('datetime',4);Qk=new gl('email',5);Rk=new gl('file',6);Sk=new gl('hidden',7);Tk=new gl('image',8);Uk=new gl('month',9);Vk=new gl(vp,10);Wk=new gl('password',11);Xk=new gl('radio',12);Yk=new gl('range',13);Zk=new gl('reset',14);$k=new gl('search',15);_k=new gl('submit',16);al=new gl('tel',17);bl=new gl('text',18);cl=new gl('time',19);dl=new gl('url',20);el=new gl('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ci(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Gi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ci(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ei(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Ii)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&zp!=(k.b.c&Ap)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function nl(a){var b,c;a.d=0;jl();c=(b=S(a.g.b),uk('footer',yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,['footer'])),[(new Pm).a,uk('ul',yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,['filters'])),[uk('li',null,[uk('a',Ak(yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,[(gp(),ep)==b?Np:null])),'#'),['All'])]),uk('li',null,[uk('a',Ak(yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,[dp==b?Np:null])),'#active'),['Active'])]),uk('li',null,[uk('a',Ak(yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,[fp==b?Np:null])),'#completed'),['Completed'])])]),S(a.a)?uk(Mp,Bk(yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,['clear-completed'])),th(Lm.prototype.lb,Lm,[a])),['Clear Completed']):null]));return c}
function dm(a){var b,c,d,e;a.f=0;jl();b=a.n.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.n.props['a'],e=(fb(d.a),d.d),uk('li',yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[uk('div',yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,['view'])),[uk(Qp,Fk(Dk(Ik(yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,['toggle'])),(fl(),Mk)),e),th(rn.prototype.jb,rn,[d])),null),uk('label',Kk(new $wnd.Object,th(sn.prototype.lb,sn,[a,d])),[(fb(d.b),d.e)]),uk(Mp,Bk(yk(new $wnd.Object,bd(Yc(me,1),xp,2,6,['destroy'])),th(tn.prototype.lb,tn,[a,d])),null)]),uk(Qp,Gk(Fk(Ek(Jk(yk(zk(new $wnd.Object,th(un.prototype.w,un,[a])),bd(Yc(me,1),xp,2,6,['edit'])),(fb(a.a),a.d)),th(vn.prototype.ib,vn,[a,d])),th(qn.prototype.jb,qn,[a])),th(wn.prototype.kb,wn,[a,d])),null)]));return c}
function cj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Kp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!aj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Kp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var up='object',vp='number',wp={11:1},xp={3:1},yp={9:1},zp=1048576,Ap=1835008,Bp={5:1},Cp=2097152,Dp=4194304,Ep={25:1},Fp='__noinit__',Gp={3:1,10:1,7:1,4:1},Hp='null',Ip=17592186044416,Jp={42:1},Kp='delete',Lp='children',Mp='button',Np='selected',Op=1411518464,Pp=142606336,Qp='input',Rp='header',Sp='hashchange',Tp=136314880,Up='active',Vp='completed',Wp={56:1};var _,oh,jh,ah=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;ph();rh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=Yp;_.r=function(){var a;return Ih(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var ed,fd,gd;rh(58,1,{},Jh);_.K=function(a){var b;b=new Jh;b.e=4;a>1?(b.c=Oh(this,a-1)):(b.c=this);return b};_.L=function(){Hh(this);return this.b};_.M=function(){return Ih(this)};_.N=function(){Hh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Hh(this),this.k)};_.e=0;_.g=0;var Gh=1;var je=Lh(1);var _d=Lh(58);rh(87,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var ud=Lh(87);rh(37,1,wp,G);_.s=function(){return this.a.v(),null};var sd=Lh(37);rh(88,1,{},H);var td=Lh(88);var I;rh(44,1,{44:1},P);_.b=0;_.c=false;_.d=0;var vd=Lh(44);rh(236,1,yp);_.r=function(){var a;return Ih(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var yd=Lh(236);rh(19,236,yp,W);_.t=function(){R(this)};_.u=Xp;_.a=false;_.d=0;_.k=false;var xd=Lh(19);rh(165,1,wp,X);_.s=function(){return T(this.a)};var wd=Lh(165);rh(17,236,{9:1,17:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Ad=Lh(17);rh(164,1,Bp,jb);_.v=function(){ab(this.a)};var zd=Lh(164);rh(18,236,{9:1,18:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Fd=Lh(18);rh(166,1,Ep,xb);_.v=function(){Q(this.a)};var Bd=Lh(166);rh(167,1,Bp,yb);_.v=function(){mb(this.a)};var Cd=Lh(167);rh(168,1,Bp,zb);_.v=function(){pb(this.a)};var Dd=Lh(168);rh(169,1,{},Ab);_.w=function(a){nb(this.a,a)};var Ed=Lh(169);rh(105,1,{},Db);_.a=0;_.b=0;_.c=0;var Gd=Lh(105);rh(170,1,yp,Fb);_.t=function(){Eb(this)};_.u=Xp;_.a=false;var Hd=Lh(170);rh(70,236,{9:1,70:1},Kb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Jd=Lh(70);rh(63,1,{63:1},Pb);var Id=Lh(63);rh(174,1,{},_b);_.r=function(){var a;return Hh(Kd),Kd.k+'@'+(a=fk(this)>>>0,a.toString(16))};_.a=0;var Qb;var Kd=Lh(174);rh(146,1,{});var Nd=Lh(146);rh(110,1,{},fc);_.w=function(a){dc(this.a,a)};var Ld=Lh(110);rh(111,1,Bp,gc);_.v=function(){ec(this.a,this.b)};var Md=Lh(111);rh(16,1,yp,nc);_.t=function(){ic(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Hh(Pd),Pd.k+'@'+(a=fk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Pd=Lh(16);rh(156,1,Bp,oc);_.v=function(){lc(this.a)};var Od=Lh(156);rh(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=bq;_.C=function(){return Lj(Jj(Mi((this.i==null&&(this.i=$c(oe,xp,4,0,0,1)),this.i)),new fi),new Pj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){rc(this,tc(this.A(sc(this,this.g))));Vc(this)};_.r=function(){return sc(this,this.F())};_.e=Fp;_.j=true;var oe=Lh(4);rh(10,4,{3:1,10:1,4:1});var ce=Lh(10);rh(7,10,Gp);var ke=Lh(7);rh(59,7,Gp);var ge=Lh(59);rh(81,59,Gp);var Td=Lh(81);rh(36,81,{36:1,3:1,10:1,7:1,4:1},yc);_.F=function(){xc(this);return this.c};_.H=function(){return pd(this.b)===pd(vc)?null:this.b};var vc;var Qd=Lh(36);var Rd=Lh(0);rh(218,1,{});var Sd=Lh(218);var Ac=0,Bc=0,Cc=-1;rh(96,218,{},Qc);var Mc;var Ud=Lh(96);var Tc;rh(229,1,{});var Wd=Lh(229);rh(82,229,{},Xc);var Vd=Lh(82);rh(45,1,{45:1,56:1},yh);_.I=function(){if(this===this.a){this.a=this.b.I();this.b=null}return this.a};var Xd=Lh(45);var Ah;rh(79,1,{76:1});_.r=Xp;var Yd=Lh(79);rh(84,7,Gp);var ee=Lh(84);rh(129,84,Gp,Eh);var Zd=Lh(129);ed={3:1,77:1,29:1};var $d=Lh(77);rh(43,1,{3:1,43:1});var ie=Lh(43);fd={3:1,29:1,43:1};var ae=Lh(228);rh(31,1,{3:1,29:1,31:1});_.o=dq;_.q=Yp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=Lh(31);rh(83,7,Gp,Uh);var de=Lh(83);rh(30,43,{3:1,29:1,30:1,43:1},Vh);_.o=function(a){return kd(a,30)&&a.a==this.a};_.q=Xp;_.r=function(){return ''+this.a};_.a=0;var fe=Lh(30);var Xh;rh(294,1,{});rh(85,59,Gp,$h);_.A=function(a){return new TypeError(a)};var he=Lh(85);gd={3:1,76:1,29:1,2:1};var me=Lh(2);rh(80,79,{76:1},ei);var le=Lh(80);rh(298,1,{});rh(74,1,{},fi);_.S=function(a){return a.e};var ne=Lh(74);rh(61,7,Gp,gi);var pe=Lh(61);rh(230,1,{41:1});_.Q=aq;_.V=function(){return new yj(this,0)};_.W=function(){return new Mj(null,this.V())};_.T=function(a){throw dh(new gi('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Aj('[',']');for(b=this.R();b.Y();){a=b.Z();zj(c,a===this?'(this Collection)':a==null?Hp:vh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var qe=Lh(230);rh(233,1,{216:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!kd(a,38)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ui((new ri(d)).a);c.b;){b=ti(c);if(!ji(this,b)){return false}}return true};_.q=function(){return Ni(new ri(this))};_.r=function(){var a,b,c;c=new Aj('{','}');for(b=new ui((new ri(this)).a);b.b;){a=ti(b);zj(c,ki(this,a._())+'='+ki(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Be=Lh(233);rh(104,233,{216:1});var te=Lh(104);rh(232,230,{41:1,240:1});_.V=function(){return new yj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!kd(a,22)){return false}b=a;if(pi(b.a)!=this.U()){return false}return hi(this,b)};_.q=function(){return Ni(this)};var Ce=Lh(232);rh(22,232,{22:1,41:1,240:1},ri);_.R=function(){return new ui(this.a)};_.U=$p;var se=Lh(22);rh(23,1,{},ui);_.X=Zp;_.Z=function(){return ti(this)};_.Y=_p;_.b=false;var re=Lh(23);rh(231,230,{41:1,237:1});_.V=function(){return new yj(this,16)};_.$=function(a,b){throw dh(new gi('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!kd(a,14)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Ki(f);for(c=new Ki(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(pd(b)===pd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Oi(this)};_.R=function(){return new vi(this)};var ve=Lh(231);rh(95,1,{},vi);_.X=Zp;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Ci(this.b,this.a++)};_.a=0;var ue=Lh(95);rh(62,230,{41:1},wi);_.R=function(){var a;a=new ui((new ri(this.a)).a);return new xi(a)};_.U=$p;var xe=Lh(62);rh(99,1,{},xi);_.X=Zp;_.Y=function(){return this.a.b};_.Z=function(){var a;a=ti(this.a);return a.ab()};var we=Lh(99);rh(97,1,Jp);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Pi(this.a,b._())&&Pi(this.b,b.ab())};_._=Xp;_.ab=_p;_.q=function(){return oj(this.a)^oj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ye=Lh(97);rh(98,97,Jp,yi);var ze=Lh(98);rh(234,1,Jp);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Pi(this.b.value[0],b._())&&Pi(kj(this),b.ab())};_.q=function(){return oj(this.b.value[0])^oj(kj(this))};_.r=function(){return this.b.value[0]+'='+kj(this)};var Ae=Lh(234);rh(14,231,{3:1,14:1,41:1,237:1},Ii,Ji);_.$=function(a,b){ak(this.a,a,b)};_.T=function(a){return Ai(this,a)};_.Q=function(a){Bi(this,a)};_.R=function(){return new Ki(this)};_.U=function(){return this.a.length};var Ee=Lh(14);rh(15,1,{},Ki);_.X=Zp;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var De=Lh(15);rh(38,104,{3:1,38:1,216:1},Qi);var Fe=Lh(38);rh(66,1,{},Wi);_.Q=aq;_.R=function(){return new Xi(this)};_.b=0;var He=Lh(66);rh(67,1,{},Xi);_.X=Zp;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ge=Lh(67);var $i;rh(64,1,{},ij);_.Q=aq;_.R=function(){return new jj(this)};_.b=0;_.c=0;var Ke=Lh(64);rh(65,1,{},jj);_.X=Zp;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new lj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Ie=Lh(65);rh(117,234,Jp,lj);_._=function(){return this.b.value[0]};_.ab=function(){return kj(this)};_.bb=function(a){return gj(this.a,this.b.value[0],a)};_.c=0;var Je=Lh(117);rh(119,1,{});_.X=cq;_.cb=function(){return this.d};_.db=bq;_.d=0;_.e=0;var Oe=Lh(119);rh(68,119,{});var Le=Lh(68);rh(100,1,{});_.X=cq;_.cb=_p;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Ne=Lh(100);rh(101,100,{},wj);_.X=function(a){tj(this,a)};_.eb=function(a){return uj(this,a)};var Me=Lh(101);rh(21,1,{},yj);_.cb=Xp;_.db=function(){xj(this);return this.c};_.X=function(a){xj(this);this.d.X(a)};_.eb=function(a){xj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Pe=Lh(21);rh(60,1,{},Aj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Qe=Lh(60);rh(35,1,{},Bj);_.S=function(a){return a};var Re=Lh(35);rh(39,1,{},Cj);var Se=Lh(39);rh(118,1,{});_.c=false;var af=Lh(118);rh(27,118,{259:1},Mj);var _e=Lh(27);rh(75,1,{},Pj);_.fb=function(a){return $c(je,xp,1,a,5,1)};var Te=Lh(75);rh(121,68,{},Rj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Sj(this,a)));return this.b};_.b=false;var Ve=Lh(121);rh(124,1,{},Sj);_.w=function(a){Qj(this.a,this.b,a)};var Ue=Lh(124);rh(120,68,{},Uj);_.eb=function(a){return this.b.eb(new Vj(this,a))};var Xe=Lh(120);rh(123,1,{},Vj);_.w=function(a){Tj(this.a,this.b,a)};var We=Lh(123);rh(122,1,{},Xj);_.w=function(a){Wj(this,a)};var Ye=Lh(122);rh(125,1,{},Yj);_.w=function(a){};var Ze=Lh(125);rh(126,1,{},$j);_.w=function(a){Zj(this,a)};var $e=Lh(126);rh(296,1,{});rh(293,1,{});var ek=0;var gk,hk=0,ik;rh(909,1,{});rh(930,1,{});rh(235,1,{});var bf=Lh(235);rh(171,1,{},wk);_.fb=function(a){return new Array(a)};var cf=Lh(171);rh(261,$wnd.Function,{},xk);_.hb=function(a){vk(this.a,this.b,a)};rh(6,31,{3:1,29:1,31:1,6:1},gl);var Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el;var df=Mh(6,hl);var il;rh(260,$wnd.Function,{},kl);_.J=function(a){return Eb(il),il=null,null};rh(188,235,{});var Of=Lh(188);rh(189,188,{});_.d=0;var Sf=Lh(189);rh(190,189,yp,sl);_.t=eq;_.o=dq;_.q=Yp;_.u=fq;_.r=function(){var a;return Hh(nf),nf.k+'@'+(a=fk(this)>>>0,a.toString(16))};var ol=0;var nf=Lh(190);rh(191,1,Bp,tl);_.v=function(){pl(this.a)};var ef=Lh(191);rh(192,1,wp,ul);_.s=function(){return ql(this.a)};var ff=Lh(192);rh(193,1,Ep,vl);_.v=function(){ml(this.a)};var gf=Lh(193);rh(194,1,wp,wl);_.s=function(){return nl(this.a)};var hf=Lh(194);rh(209,235,{});var Nf=Lh(209);rh(210,209,{});_.c=0;var Rf=Lh(210);rh(211,210,yp,Cl);_.t=gq;_.o=dq;_.q=Yp;_.u=hq;_.r=function(){var a;return Hh(mf),mf.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Al=0;var mf=Lh(211);rh(212,1,Bp,Dl);_.v=iq;var jf=Lh(212);rh(213,1,Ep,El);_.v=function(){yl(this.a)};var kf=Lh(213);rh(214,1,wp,Fl);_.s=function(){return zl(this.a)};var lf=Lh(214);rh(180,235,{});_.f='';var _f=Lh(180);rh(181,180,{});_.d=0;var Uf=Lh(181);rh(182,181,yp,Rl);_.t=eq;_.o=dq;_.q=Yp;_.u=fq;_.r=function(){var a;return Hh(tf),tf.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Ll=0;var tf=Lh(182);rh(183,1,Bp,Sl);_.v=function(){Ml(this.a)};var of=Lh(183);rh(185,1,wp,Tl);_.s=function(){return Kl(this.a)};var pf=Lh(185);rh(186,1,Bp,Ul);_.v=function(){Gl(this.a)};var qf=Lh(186);rh(187,1,Bp,Vl);_.v=function(){Ol(this.a,this.b)};var rf=Lh(187);rh(184,1,Ep,Wl);_.v=function(){ml(this.a)};var sf=Lh(184);rh(176,235,{});_.i=false;var cg=Lh(176);rh(196,176,{});_.f=0;var Wf=Lh(196);rh(197,196,yp,qm);_.t=function(){ic(this.e)};_.o=dq;_.q=Yp;_.u=function(){return this.e.i<0};_.r=function(){var a;return Hh(Ef),Ef.k+'@'+(a=fk(this)>>>0,a.toString(16))};var em=0;var Ef=Lh(197);rh(198,1,Bp,rm);_.v=function(){fm(this.a)};var uf=Lh(198);rh(201,1,wp,sm);_.s=function(){return dm(this.a)};var vf=Lh(201);rh(50,1,Bp,tm);_.v=function(){pm(this.a,Pn(this.b))};var wf=Lh(50);rh(71,1,Bp,um);_.v=function(){_l(this.a,this.b)};var xf=Lh(71);rh(202,1,Bp,vm);_.v=function(){hm(this.a,this.b)};var yf=Lh(202);rh(203,1,Bp,wm);_.v=function(){im(this.a,this.b)};var zf=Lh(203);rh(199,1,wp,xm);_.s=function(){return jm(this.a)};var Af=Lh(199);rh(204,1,Bp,ym);_.v=function(){Xl(this.a,this.b)};var Bf=Lh(204);rh(205,1,Bp,zm);_.v=function(){am(this.a)};var Cf=Lh(205);rh(200,1,Ep,Am);_.v=function(){cm(this.a)};var Df=Lh(200);rh(140,235,{});var gg=Lh(140);rh(141,140,{});_.c=0;var Yf=Lh(141);rh(142,141,yp,Hm);_.t=gq;_.o=dq;_.q=Yp;_.u=hq;_.r=function(){var a;return Hh(If),If.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Fm=0;var If=Lh(142);rh(143,1,Bp,Im);_.v=iq;var Ff=Lh(143);rh(144,1,Ep,Jm);_.v=function(){yl(this.a)};var Gf=Lh(144);rh(145,1,wp,Km);_.s=function(){return Em(this.a)};var Hf=Lh(145);rh(265,$wnd.Function,{},Lm);_.lb=function(a){Go(this.a.f)};rh(173,1,{},Mm);var Jf=Lh(173);rh(90,1,{},Nm);var Kf=Lh(90);var Om;rh(195,1,{},Pm);var Lf=Lh(195);rh(94,1,{},Qm);var Mf=Lh(94);var Rm;rh(266,$wnd.Function,{},Sm);_.mb=function(a){return new Vm(a)};var Tm;rh(178,$wnd.React.Component,{},Vm);qh(oh[1],_);_.componentWillUnmount=function(){ll(this.a)};_.render=function(){return rl(this.a)};_.shouldComponentUpdate=jq;var Pf=Lh(178);rh(277,$wnd.Function,{},Wm);_.mb=function(a){return new Zm(a)};var Xm;rh(206,$wnd.React.Component,{},Zm);qh(oh[1],_);_.componentWillUnmount=function(){xl(this.a)};_.render=function(){return Bl(this.a)};_.shouldComponentUpdate=kq;var Qf=Lh(206);rh(264,$wnd.Function,{},$m);_.mb=function(a){return new bn(a)};var _m;rh(177,$wnd.React.Component,{},bn);qh(oh[1],_);_.componentWillUnmount=function(){ll(this.a)};_.render=function(){return Pl(this.a)};_.shouldComponentUpdate=jq;var Tf=Lh(177);rh(267,$wnd.Function,{},cn);_.mb=function(a){return new fn(a)};var dn;rh(179,$wnd.React.Component,{},fn);qh(oh[1],_);_.componentDidUpdate=function(a){mm(this.a)};_.componentWillUnmount=function(){bm(this.a)};_.render=function(){return nm(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Vf=Lh(179);rh(258,$wnd.Function,{},gn);_.mb=function(a){return new kn(a)};var hn;rh(102,$wnd.React.Component,{},kn);qh(oh[1],_);_.componentWillUnmount=function(){xl(this.a)};_.render=function(){return Gm(this.a)};_.shouldComponentUpdate=kq;var Xf=Lh(102);rh(262,$wnd.Function,{},ln);_.kb=function(a){Hl(this.a,a)};rh(263,$wnd.Function,{},mn);_.jb=function(a){Nl(this.a,a)};rh(172,1,{},nn);var Zf=Lh(172);rh(93,1,{},on);var $f=Lh(93);var pn;rh(274,$wnd.Function,{},qn);_.jb=function(a){gm(this.a,a)};rh(268,$wnd.Function,{},rn);_.jb=function(a){jo(this.a)};rh(270,$wnd.Function,{},sn);_.lb=function(a){km(this.a,this.b)};rh(271,$wnd.Function,{},tn);_.lb=function(a){Yl(this.a,this.b)};rh(272,$wnd.Function,{},un);_.w=function(a){Zl(this.a,a)};rh(273,$wnd.Function,{},vn);_.ib=function(a){lm(this.a,this.b)};rh(275,$wnd.Function,{},wn);_.kb=function(a){$l(this.a,this.b,a)};rh(175,1,{},yn);var ag=Lh(175);rh(91,1,{},zn);var bg=Lh(91);var An;rh(257,$wnd.Function,{},Bn);_.jb=function(a){Bm(this.a,a)};rh(103,1,{},Cn);_.S=function(a){return xn(new yn,a)};var dg=Lh(103);rh(73,1,{},Dn);var eg=Lh(73);rh(92,1,{},En);var fg=Lh(92);var Fn;rh(89,1,{},Gn);var hg=Lh(89);rh(49,1,{49:1});var Og=Lh(49);rh(157,49,{9:1,49:1},Tn);_.t=eq;_.o=dq;_.q=Yp;_.u=fq;_.r=function(){var a;return Hh(pg),pg.k+'@'+(a=fk(this)>>>0,a.toString(16))};var pg=Lh(157);rh(158,1,Bp,Un);_.v=function(){Nn(this.a)};var ig=Lh(158);rh(160,1,Ep,Vn);_.v=function(){In(this.a)};var jg=Lh(160);rh(161,1,Ep,Wn);_.v=function(){Jn(this.a)};var kg=Lh(161);rh(162,1,Bp,Xn);_.v=function(){Hn(this.a,this.b)};var lg=Lh(162);rh(163,1,Bp,Yn);_.v=function(){Qn(this.a)};var mg=Lh(163);rh(69,1,Bp,Zn);_.v=function(){Mn(this.a)};var ng=Lh(69);rh(159,1,wp,$n);_.s=function(){var a;return a=(Bh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var og=Lh(159);rh(51,1,{51:1});_.d=false;var Yg=Lh(51);rh(52,51,{9:1,276:1,52:1,51:1},ko);_.t=eq;_.o=function(a){return co(this,a)};_.q=function(){return this.c.d};_.u=fq;_.r=function(){var a;return Hh(Fg),Fg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var _n=0;var Fg=Lh(52);rh(207,1,Bp,lo);_.v=function(){ao(this.a)};var qg=Lh(207);rh(208,1,Bp,mo);_.v=function(){go(this.a)};var rg=Lh(208);rh(48,146,{48:1});var Sg=Lh(48);rh(147,48,{9:1,48:1},vo);_.t=lq;_.o=dq;_.q=Yp;_.u=mq;_.r=function(){var a;return Hh(Ag),Ag.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Ag=Lh(147);rh(149,1,Bp,wo);_.v=function(){oo(this.a)};var sg=Lh(149);rh(148,1,Bp,xo);_.v=function(){so(this.a)};var tg=Lh(148);rh(154,1,Bp,yo);_.v=function(){cc(this.a,this.b,true)};var ug=Lh(154);rh(155,1,wp,zo);_.s=function(){return no(this.a,this.c,this.b)};_.b=false;var vg=Lh(155);rh(150,1,wp,Ao);_.s=function(){return to(this.a)};var wg=Lh(150);rh(151,1,wp,Bo);_.s=function(){return Wh(ih(Hj(ro(this.a))))};var xg=Lh(151);rh(152,1,wp,Co);_.s=function(){return Wh(ih(Hj(Ij(ro(this.a),new mp))))};var yg=Lh(152);rh(153,1,wp,Do);_.s=function(){return uo(this.a)};var zg=Lh(153);rh(46,1,{46:1});var Xg=Lh(46);rh(130,46,{9:1,46:1},Ko);_.t=function(){ic(this.a)};_.o=dq;_.q=Yp;_.u=function(){return this.a.i<0};_.r=function(){var a;return Hh(Eg),Eg.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Eg=Lh(130);rh(131,1,Bp,Lo);_.v=function(){Ho(this.a,this.b)};_.b=false;var Bg=Lh(131);rh(132,1,Bp,Mo);_.v=function(){Sn(this.b,this.a)};var Cg=Lh(132);rh(133,1,Bp,No);_.v=function(){Io(this.a)};var Dg=Lh(133);rh(47,1,{47:1});var _g=Lh(47);rh(134,47,{9:1,47:1},Vo);_.t=lq;_.o=dq;_.q=Yp;_.u=mq;_.r=function(){var a;return Hh(Lg),Lg.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Lg=Lh(134);rh(135,1,Bp,Wo);_.v=function(){Qo(this.a)};var Gg=Lh(135);rh(139,1,Bp,Xo);_.v=function(){Uo(this.a,null)};var Hg=Lh(139);rh(136,1,wp,Yo);_.s=function(){var a;return a=Pn(this.a.g),o(Up,a)?(gp(),dp):o(Vp,a)?(gp(),fp):(gp(),ep)};var Ig=Lh(136);rh(137,1,wp,Zo);_.s=function(){return So(this.a)};var Jg=Lh(137);rh(138,1,Ep,$o);_.v=function(){To(this.a)};var Kg=Lh(138);rh(128,1,{},_o);_.handleEvent=function(a){Kn(this.a,a)};var Mg=Lh(128);rh(108,1,Wp,ap);_.I=function(){return new Tn};var Ng=Lh(108);var bp;rh(32,31,{3:1,29:1,31:1,32:1},hp);var dp,ep,fp;var Pg=Mh(32,ip);rh(106,1,Wp,jp);_.I=function(){return new vo};var Qg=Lh(106);var kp;rh(112,1,{},mp);_.gb=function(a){return !fo(a)};var Rg=Lh(112);rh(114,1,{},np);_.gb=function(a){return fo(a)};var Tg=Lh(114);rh(115,1,{},op);_.w=function(a){qo(this.a,a)};var Ug=Lh(115);rh(113,1,{},pp);_.w=function(a){Fo(this.a,a)};_.a=false;var Vg=Lh(113);rh(107,1,Wp,qp);_.I=function(){return new Ko(this.a.I())};var Wg=Lh(107);rh(116,1,{},rp);_.gb=function(a){return Po(this.a,a)};var Zg=Lh(116);rh(109,1,Wp,sp);_.I=function(){return new Vo(this.b.I(),this.a.I())};var $g=Lh(109);var rd=Nh('D');var tp=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=mh;kh(xh);nh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();