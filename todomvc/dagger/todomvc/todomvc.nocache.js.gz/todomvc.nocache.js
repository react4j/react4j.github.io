function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='D6B9C617C437367040D1F2ED4693DD1C',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'D6B9C617C437367040D1F2ED4693DD1C';function o(){}
function oh(){}
function sh(){}
function Bb(){}
function Qc(){}
function Xc(){}
function Jj(){}
function Kj(){}
function mk(){}
function Qm(){}
function Sm(){}
function Um(){}
function Wm(){}
function Ym(){}
function co(){}
function oo(){}
function Io(){}
function Vo(){}
function Wo(){}
function Kp(){}
function Vc(a){Uc()}
function Dh(){Dh=oh}
function Gi(){xi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function fb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function ub(a){this.a=a}
function cc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function gc(a){this.a=a}
function kc(a){this.a=a}
function Uh(a){this.a=a}
function di(a){this.a=a}
function pi(a){this.a=a}
function ui(a){this.a=a}
function vi(a){this.a=a}
function ti(a){this.b=a}
function Ii(a){this.c=a}
function Hj(a){this.a=a}
function Mj(a){this.a=a}
function fl(a){this.a=a}
function gl(a){this.a=a}
function hl(a){this.a=a}
function il(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function tl(a){this.a=a}
function Il(a){this.a=a}
function Jl(a){this.a=a}
function Ll(a){this.a=a}
function Ml(a){this.a=a}
function Ol(a){this.a=a}
function im(a){this.a=a}
function jm(a){this.a=a}
function km(a){this.a=a}
function pm(a){this.a=a}
function qm(a){this.a=a}
function Am(a){this.a=a}
function Bm(a){this.a=a}
function Cm(a){this.a=a}
function Fm(a){this.a=a}
function Im(a){this.a=a}
function Lm(a){this.a=a}
function $m(a){this.a=a}
function _m(a){this.a=a}
function Hm(){this.a={}}
function Km(){this.a={}}
function bn(){this.a={}}
function cn(a){this.a=a}
function en(a){this.a=a}
function fn(a){this.a=a}
function jn(a){this.a=a}
function qn(a){this.a=a}
function tn(a){this.a=a}
function wn(a){this.a=a}
function Ln(a){this.a=a}
function Mn(a){this.a=a}
function Vn(a){this.a=a}
function Xn(a){this.a=a}
function Zn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function no(a){this.a=a}
function qo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Eo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function pn(){this.a={}}
function vn(){this.a={}}
function Ij(a,b){a.a=b}
function Mm(a,b){a.d=b}
function Nm(a,b){a.e=b}
function Om(a,b){a.f=b}
function Pm(a,b){a.g=b}
function rn(a,b){a.k=b}
function sn(a,b){a.n=b}
function fo(a,b){Hn(b,a)}
function C(a,b){yb(a.b,b)}
function $(a){Kb((J(),a))}
function w(a){--a.e;D(a)}
function bl(a){al();_k=a}
function ml(a){ll();kl=a}
function Bl(a){Al();zl=a}
function _l(a){Zl();Yl=a}
function xm(a){wm();vm=a}
function Gp(a){ij(this,a)}
function Jp(a){Yh(this,a)}
function Pp(){hk(this.a)}
function Up(){jk(this.a)}
function Si(){this.a=_i()}
function ej(){this.a=_i()}
function F(){this.b=new zb}
function J(){J=oh;I=new F}
function pc(){this.b=new Mi}
function mb(a,b){a.b=lj(b)}
function oc(a,b){li(a.b,b)}
function eo(a,b){On(a.b,b)}
function Sl(a,b){Pn(a.k,b)}
function Lj(a,b){Bj(a.a,b)}
function ak(a,b,c){a[b]=c}
function $g(a){return a.e}
function Sp(){return this.e}
function Dp(){return this.a}
function Ip(){return this.b}
function Mp(){return this.c}
function _h(a,b){return a===b}
function Tl(a,b){return a.g=b}
function Fp(){return Uj(this)}
function Np(){return this.d<0}
function Tp(){return this.c<0}
function Vp(){return this.f<0}
function Xi(){Xi=oh;Wi=Zi()}
function wc(){wc=oh;vc=new o}
function Nc(){Nc=oh;Mc=new Qc}
function vh(){vh=oh;uh=new o}
function bo(){bo=oh;ao=new co}
function Ho(){Ho=oh;Go=new Io}
function lo(a){this.b=lj(a)}
function nl(a){nc(a.b);gb(a.a)}
function ab(a){Lb((J(),a))}
function db(a){Mb((J(),a))}
function Sh(a){uc.call(this,a)}
function ei(a){uc.call(this,a)}
function Rm(a){ek.call(this,a)}
function Tm(a){ek.call(this,a)}
function Vm(a){ek.call(this,a)}
function Xm(a){ek.call(this,a)}
function Zm(a){ek.call(this,a)}
function Ep(a){return this===a}
function Op(){return J(),J(),I}
function Hp(){return ni(this.a)}
function Qp(){return lk(this.a)}
function Yc(a,b){return Mh(a,b)}
function Ai(a,b){return a.a[b]}
function Gh(a){Fh(a);return a.k}
function Aj(a,b){a.U(b);return a}
function Qj(a,b){a.splice(b,1)}
function mc(a,b,c){ki(a.b,b,c)}
function mj(a,b){while(a.fb(b));}
function Bj(a,b){Ij(a,Aj(a.a,b))}
function Eb(a){Fb(a);!a.d&&Ib(a)}
function Vb(a){bb(a.a);return a.e}
function Wb(a){bb(a.b);return a.g}
function Dn(a){bb(a.b);return a.i}
function En(a){bb(a.a);return a.g}
function to(a){bb(a.d);return a.f}
function ok(a,b){a.ref=b;return a}
function dc(a,b){this.a=a;this.b=b}
function lc(a,b){this.a=a;this.b=b}
function wh(a){this.a=uh;this.b=a}
function Rh(a,b){this.a=a;this.b=b}
function wi(a,b){this.a=a;this.b=b}
function Zh(){qc(this);this.I()}
function Ej(a,b){this.a=a;this.b=b}
function bj(a,b){return a.a.get(b)}
function ni(a){return a.a.b+a.b.b}
function bd(a){return new Array(a)}
function _i(){Xi();return new Wi}
function X(a){J();Lb(a);a.e=-2}
function Yb(a){Ub(a,(bb(a.b),a.g))}
function Dc(){Dc=oh;!!(Uc(),Tc)}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function hh(){fh==null&&(fh=[])}
function Yk(a,b){Rh.call(this,a,b)}
function Kl(a,b){this.a=a;this.b=b}
function mm(a,b){this.a=a;this.b=b}
function nm(a,b){this.a=a;this.b=b}
function om(a,b){this.a=a;this.b=b}
function gn(a,b){this.a=a;this.b=b}
function hn(a,b){this.a=a;this.b=b}
function kn(a,b){this.a=a;this.b=b}
function ln(a,b){this.a=a;this.b=b}
function Wn(a,b){this.a=a;this.b=b}
function po(a,b){this.a=a;this.b=b}
function mo(a,b){this.b=a;this.a=b}
function Fo(a,b){this.b=a;this.a=b}
function To(a,b){Rh.call(this,a,b)}
function Rl(a,b){yo(a.n,b);fm(a,b)}
function Fj(a,b){a.D(on(mn(b.e),b))}
function Oj(a,b,c){a.splice(b,0,c)}
function zk(a,b){a.value=b;return a}
function pk(a,b){a.href=b;return a}
function bi(a,b){a.a+=''+b;return a}
function mi(a){a.a=new Si;a.b=new ej}
function L(a){a.b=0;a.d=0;a.c=false}
function Gb(a){return !a.d?a:Gb(a.d)}
function ji(a){return !a?null:a.bb()}
function qd(a){return a==null?null:a}
function kj(a){return a!=null?r(a):0}
function mn(a){return nn(new pn,a)}
function nd(a){return typeof a===ap}
function Lp(){return T(this.e.b).a>0}
function eb(a){this.c=new Gi;this.b=a}
function Kc(a){$wnd.clearTimeout(a)}
function dl(a){nc(a.c);gb(a.b);S(a.a)}
function Fl(a){nc(a.c);gb(a.a);W(a.b)}
function Gn(a){Hn(a,(bb(a.a),!a.g))}
function Vl(a,b){fm(a,b);yo(a.n,null)}
function A(a,b,c){t(a,new G(b),c,null)}
function Pj(a,b){Nj(b,0,a,0,b.length)}
function jc(a,b){hc(a,b,false);ab(a.d)}
function uk(a,b){a.onBlur=b;return a}
function qk(a,b){a.onClick=b;return a}
function vk(a,b){a.onChange=b;return a}
function sk(a,b){a.checked=b;return a}
function wk(a,b){a.onKeyDown=b;return a}
function xi(a){a.a=$c(ke,dp,1,0,5,1)}
function Q(){this.a=$c(ke,dp,1,100,5,1)}
function bb(a){var b;Hb((J(),b=Cb,b),a)}
function lb(a){J();kb(a);nb(a,2,true)}
function Uj(a){return a.$H||(a.$H=++Tj)}
function V(a){return !(!!a&&1==(a.c&7))}
function ld(a,b){return a!=null&&jd(a,b)}
function $h(a,b){return a.charCodeAt(b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function pd(a){return typeof a==='string'}
function md(a){return typeof a==='boolean'}
function rk(a){a.autoFocus=true;return a}
function tk(a,b){a.defaultValue=b;return a}
function Fh(a){if(a.k!=null){return}Oh(a)}
function rc(a,b){a.e=b;b!=null&&Sj(b,op,a)}
function ij(a,b){while(a.Z()){Lj(b,a.$())}}
function uc(a){this.f=a;qc(this);this.I()}
function zj(a,b){uj.call(this,a);this.a=b}
function Ui(a,b){var c;c=a[tp];c.call(a,b)}
function u(a,b){return new qb(lj(a),null,b)}
function Tn(a){return Vh(T(a.e).a-T(a.a).a)}
function Fn(a){nc(a.c);W(a.d);W(a.b);W(a.a)}
function ic(a,b){oc(b.F(),a);ld(b,11)&&b.A()}
function Ec(a,b,c){return a.apply(b,c);var d}
function Sj(b,c,d){try{b[c]=d}catch(a){}}
function Yj(){Yj=oh;Vj=new o;Xj=new o}
function Mi(){this.a=new Si;this.b=new ej}
function hj(a,b,c){this.a=a;this.b=b;this.c=c}
function vl(a,b,c){this.a=a;this.b=b;this.c=c}
function sm(a,b,c){this.a=a;this.b=b;this.c=c}
function Em(a,b,c){this.a=a;this.b=b;this.c=c}
function Ak(a,b){a.onDoubleClick=b;return a}
function yi(a,b){a.a[a.a.length]=b;return true}
function qc(a){a.g&&a.e!==np&&a.I();return a}
function Lh(){var a;a=Ih(null);a.e=2;return a}
function Jh(a){var b;b=Ih(a);Qh(a,b);return b}
function nn(a,b){lj(b);ak(a.a,'key',b);return a}
function yh(a){if(!a){throw $g(new Zh)}return a}
function Ab(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function oj(a){if(!a.d){a.d=a.b.T();a.c=a.b.V()}}
function jb(a,b){Z(b,a);b.c.a.length>0||(b.a=4)}
function Rb(a,b){a.i&&b.preventDefault();ac(a)}
function El(a,b){var c;c=b.target;Gl(a,c.value)}
function Yn(a,b){this.a=a;this.c=b;this.b=false}
function Lo(a){this.b=a;this.a=new tl(this.b.a)}
function Mo(a){this.b=a;this.a=new Ol(this.b.b)}
function nj(a,b){this.e=a;this.d=(b&64)!=0?b|bp:b}
function aj(a,b){return !(a.a.get(b)===undefined)}
function ad(a){return Array.isArray(a)&&a.zb===sh}
function kd(a){return !Array.isArray(a)&&a.zb===sh}
function Sn(a){return Dh(),0==T(a.e).a?true:false}
function cl(a){return Dh(),T(a.e.b).a>0?true:false}
function ro(a){return _h(Cp,a)||_h(zp,a)||_h('',a)}
function P(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ci(a,b){var c;c=a.a[b];Qj(a.a,b);return c}
function Ei(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ri(a){var b;b=a.a.$();a.b=qi(a);return b}
function uo(a){gb(a.e);gb(a.a);S(a.b);S(a.c);W(a.d)}
function bm(a){nc(a.e);gb(a.b);S(a.d);W(a.c);W(a.a)}
function sj(a){if(!a.b){tj(a);a.c=true}else{sj(a.b)}}
function Cj(a,b,c){if(a.a.gb(c)){a.b=true;b.D(c)}}
function Gl(a,b){var c;c=a.f;if(b!=c){a.f=b;ab(a.b)}}
function tm(a,b){var c;c=b.target;ko(a.e,c.checked)}
function gm(a,b){var c;c=a.i;if(b!=c){a.i=b;ab(a.a)}}
function Hn(a,b){var c;c=a.g;if(b!=c){a.g=b;ab(a.a)}}
function sl(a){var b;b=new ol;Mm(b,a.a.K());return b}
function Nl(a){var b;b=new Hl;Nm(b,a.a.K());return b}
function oi(a,b){if(b){return hi(a.a,b)}return false}
function wj(a,b){tj(a);return new zj(a,new Dj(b,a.a))}
function xj(a){tj(a);return new zj(a,new Gj(a.a))}
function eh(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function lj(a){if(a==null){throw $g(new Zh)}return a}
function _j(){if(Wj==256){Vj=Xj;Xj=new o;Wj=0}++Wj}
function Uc(){Uc=oh;var a;!Wc();a=new Xc;Tc=a}
function Ah(){Ah=oh;zh=$wnd.window.document}
function Xh(){Xh=oh;Wh=$c(ge,dp,32,256,0,1)}
function cb(a){var b;J();!!Cb&&!!Cb.e&&Hb((b=Cb,b),a)}
function $b(a,b){var c;c=a.e;if(b!=c){a.e=lj(b);ab(a.a)}}
function _b(a,b){var c;c=a.g;if(b!=c){a.g=lj(b);ab(a.b)}}
function xb(a){while(true){if(!vb(a)&&!wb(a)){break}}}
function Gj(a){nj.call(this,a.eb(),a.db()&-6);this.a=a}
function uj(a){if(!a){this.b=null;new Gi}else{this.b=a}}
function lm(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function Nb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function pj(a,b){this.b=a;this.a=(b&4096)==0?b|64|bp:b}
function In(a,b){var c;c=a.i;if(b!=c){a.i=lj(b);ab(a.b)}}
function Kh(a,b){var c;c=Ih(a);Qh(a,c);c.e=b?8:0;return c}
function yk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Ob(a,b){Cb=new Nb(Cb,b);a.d=false;Db(Cb);return Cb}
function bk(a,b){null!=b&&a.kb(b,a.q.props,true);a.hb()}
function kk(a){ik(a);return ld(a,11)&&a.B()?null:a.pb()}
function Li(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function ii(a,b){return b===a?'(this Map)':b==null?qp:rh(b)}
function sc(a,b){var c;c=Gh(a.xb);return b==null?c:c+': '+b}
function Ql(a,b){var c;if(T(a.d)){c=b.target;gm(a,c.value)}}
function Yh(a,b){var c,d;for(d=a.T();d.Z();){c=d.$();b.D(c)}}
function Th(a){this.f=!a?null:sc(a,a.H());qc(this);this.I()}
function hk(a){if(!a.o){a.o=true;a.p||a.q.forceUpdate()}}
function Db(a){if(a.e){2==(a.e.c&7)||nb(a.e,4,true);kb(a.e)}}
function Nh(a){if(a.R()){return null}var b=a.j;return kh[b]}
function cm(a,b,c,d){return Dh(),$l(a,b,c,d)?true:false}
function Uo(){So();return cd(Yc(Og,1),dp,37,0,[Po,Ro,Qo])}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Ul(a,b,c){27==c.which?em(a,b):13==c.which&&Wl(a,b)}
function xl(a,b){if(13==b.keyCode){b.preventDefault();Cl(a)}}
function yb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],lj(b))}
function io(a,b){var c;yj(Qn(a.b),(c=new Gi,c)).S(new Yo(b))}
function Mh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.M(b))}
function al(){al=oh;var a;$k=(a=ph(Qm.prototype.lb,Qm,[]),a)}
function ll(){ll=oh;var a;jl=(a=ph(Sm.prototype.lb,Sm,[]),a)}
function Al(){Al=oh;var a;yl=(a=ph(Um.prototype.lb,Um,[]),a)}
function Zl(){Zl=oh;var a;Xl=(a=ph(Wm.prototype.lb,Wm,[]),a)}
function wm(){wm=oh;var a;um=(a=ph(Ym.prototype.lb,Ym,[]),a)}
function qh(a){function b(){}
;b.prototype=a||{};return new b}
function xk(a){a.placeholder='What needs to be done?';return a}
function Gm(a){return $wnd.React.createElement((al(),$k),a.a)}
function Jm(a){return $wnd.React.createElement((ll(),jl),a.a)}
function an(a){return $wnd.React.createElement((Al(),yl),a.a)}
function un(a){return $wnd.React.createElement((wm(),um),a.a)}
function Rp(){return to(this.n)==(cb(this.c),this.q.props['a'])}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&bp)?bp:8192)|0|0,b)}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&bp)?bp:8192)|0|0,b)}
function hb(a){var b;b=(J(),J(),I);yb(b.b,a);0!=(a.c&jp)&&D(b)}
function wo(a){var b;b=(bb(a.d),a.f);!!b&&!!b&&b.f<0&&yo(a,null)}
function Qb(a,b){a.j=b;_h(b,(bb(a.a),a.e))&&_b(a,b);Sb(b);ac(a)}
function xh(a){vh();yh(a);if(ld(a,46)){return a}return new wh(a)}
function Oi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Pi(a,b){var c;return Ni(b,Oi(a,b==null?0:(c=r(b),c|0)))}
function Qn(a){bb(a.d);return new zj(null,new pj(new ui(a.g),0))}
function Hi(a){xi(this);Pj(this.a,gi(a,$c(ke,dp,1,ni(a.a),5,1)))}
function Ko(a){this.b=a;this.a=new vl(this.b.a,this.b.b,this.b.c)}
function No(a){this.b=a;this.a=new sm(this.b.a,this.b.b,this.b.c)}
function Oo(a){this.b=a;this.a=new Em(this.b.a,this.b.b,this.b.c)}
function Ti(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Dj(a,b){nj.call(this,b.eb(),b.db()&-16449);this.a=a;this.c=b}
function Y(a,b){var c,d;yi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function yo(a,b){var c;c=a.f;if(!(b==c||!!b&&Cn(b,c))){a.f=b;ab(a.d)}}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function Bh(a,b,c,d){a.addEventListener(b,c,(Dh(),d?true:false))}
function Ch(a,b,c,d){a.removeEventListener(b,c,(Dh(),d?true:false))}
function mh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function qj(a,b){!a.a?(a.a=new di(a.d)):bi(a.a,a.b);bi(a.a,b);return a}
function yj(a,b){var c;sj(a);c=new Jj;c.a=b;a.a.Y(new Mj(c));return c.a}
function vj(a){var b;sj(a);b=0;while(a.a.fb(new Kj)){b=_g(b,1)}return b}
function ho(a){var b;yj(wj(Qn(a.b),new Wo),(b=new Gi,b)).S(new Xo(a.b))}
function Bn(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Ln(a)),ip,null)}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function fj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function rj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function si(a){this.d=a;this.c=new fj(this.d.b);this.a=this.c;this.b=qi(this)}
function N(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function wl(a){var b;b=ai((bb(a.b),a.f));if(b.length>0){eo(a.e,b);Gl(a,'')}}
function rm(a){var b;b=new hm;rn(b,a.a.K());a.b.K();sn(b,a.c.K());return b}
function lk(a){var b;a.o=false;if(a.nb()){return null}else{b=a.jb();return b}}
function gj(a){if(a.a.c!=a.c){return bj(a.a,a.b.value[0])}return a.b.value[1]}
function dm(a){return Dh(),to(a.n)==(cb(a.c),a.q.props['a'])?true:false}
function li(a,b){return pd(b)?b==null?Ri(a.a,null):dj(a.b,b):Ri(a.a,b)}
function ki(a,b,c){return pd(b)?b==null?Qi(a.a,null,c):cj(a.b,b,c):Qi(a.a,b,c)}
function so(a,b){return (So(),Qo)==a||(Po==a?(bb(b.a),!b.g):(bb(b.a),b.g))}
function Rj(a,b){return Zc(b)!=10&&cd(q(b),b.yb,b.__elementTypeId$,Zc(b),a),a}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function on(a,b){ak(a.a,(Zl(),'a'),b);return $wnd.React.createElement(Xl,a.a)}
function Di(a,b){var c;c=Bi(a,b,0);if(c==-1){return false}Qj(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function Bi(a,b,c){for(;c<a.a.length;++c){if(Li(b,a.a[c])){return c}}return -1}
function ul(a){var b;b=new el;Nm(b,a.a.K());Om(b,a.b.K());Pm(b,a.c.K());return b}
function Dm(a){var b;b=new zm;Mm(b,a.a.K());Nm(b,a.b.K());Om(b,a.c.K());return b}
function ck(a,b){var c;c=null!=b&&a.kb(a.q.props,b,false);c||(a.r=false);return c}
function dk(a,b){var c;if(b){c=a.r;a.r=false;return !c}else{a.r=true;return true}}
function zi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.D(c)}}
function vo(a){var b,c;return b=T(a.b),yj(wj(Qn(a.j),new Zo(b)),(c=new Gi,c))}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function S(a){if(!a.a){a.a=true;a.g=null;a.b=null;W(a.d);2==(a.e.c&7)||gb(a.e)}}
function W(a){if(-2!=a.e){t((J(),J(),I),new G(new fb(a)),0,null);!!a.b&&gb(a.b)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{xb(a.b)}finally{a.c=false}}}}
function Rn(a){Yh(new ui(a.g),new kc(a));mi(a.g);S(a.c);S(a.e);S(a.a);S(a.b);W(a.d)}
function Xb(a){Ch((Ah(),$wnd.window.window),lp,a.f,false);nc(a.c);W(a.b);W(a.a)}
function od(a){return a!=null&&(typeof a===_o||typeof a==='function')&&!(a.zb===sh)}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Ih(a){var b;b=new Hh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function vb(a){var b;if(0==P(a.c)){return false}else{b=O(a.c);!!b&&b.A();return true}}
function Zg(a){var b;if(ld(a,4)){return a}b=a&&a[op];if(!b){b=new yc(a);Vc(b)}return b}
function Qh(a,b){var c;if(!a){return}b.j=a;var d=Nh(b);if(!d){kh[a]=[b];return}d.xb=b}
function ph(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function gh(){hh();var a=fh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function kb(a){var b,c;for(c=new Ii(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ji(a){var b,c,d;d=0;for(c=new si(a.a);c.b;){b=ri(c);d=d+(b?r(b):0);d=d|0}return d}
function fi(a,b){var c,d;for(d=new si(b.a);d.b;){c=ri(d);if(!oi(a,c)){return false}}return true}
function dj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ui(a.a,b);--a.b}return c}
function Hb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;yi((!a.b&&(a.b=new Gi),a.b),b)}}}
function Jb(a,b){var c;if(!a.c){c=Gb(a);!c.c&&(c.c=new Gi);a.c=c.c}b.d=true;yi(a.c,lj(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);N(a,lj(b))}
function jk(a){var b;b=(++a.ob().e,new Bb);try{a.p=true;ld(a,11)&&a.A()}finally{Ab(b)}}
function Pb(){var a;try{Eb(Cb);J()}finally{a=Cb.d;!a&&((J(),J(),I).d=true);Cb=Cb.d}}
function hc(a,b,c){var d;d=li(a.g,b?Vh(b.e):null);if(null!=d){oc(b.c,a);c&&!!b&&Bn(b);ab(a.d)}}
function Nn(a,b,c){var d;d=new Kn(b,c);mc(d.c,a,new lc(a,d));ki(a.g,Vh(d.e),d);ab(a.d);return d}
function Ni(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Li(a,c.ab())){return c}}return null}
function dh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=rp;d=1048575}c=rd(e/jp);b=rd(e-c*jp);return dd(b,c,d)}
function ah(a){var b;b=a.h;if(b==0){return a.l+a.m*jp}if(b==1048575){return a.l+a.m*jp-rp}return a}
function qi(a){if(a.a.Z()){return true}if(a.a!=a.c){return false}a.a=new Ti(a.d.a);return a.a.Z()}
function gb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new tb(a)),ip,null);!!a.a&&S(a.a);a.c=a.c&-8|1}}
function xo(a){var b;b=Vb(a.i);_h(Cp,b)||_h(zp,b)||_h('',b)?Ub(a.i,b):ro(Wb(a.i))?Zb(a.i):Ub(a.i,'')}
function Z(a,b){var c,d;d=a.c;Di(d,b);d.a.length==0&&!!a.b&&fp!=(a.b.c&gp)&&(a.d||Jb((J(),c=Cb,c),a))}
function cj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function cd(a,b,c,d,e){e.xb=a;e.yb=b;e.zb=sh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function $l(a,b,c,d){var e,f;e=false;f=dk(a,d);if(!(b['a']===c['a'])){f&&ab(a.c);e=true}return e||a.o}
function T(a){bb(a.d);ob(a.e)&&ib(a.e);if(a.b){if(ld(a.b,6)){throw $g(a.b)}else{throw $g(a.b)}}return a.g}
function Wl(a,b){var c;c=(bb(a.a),a.i);if(null!=c&&c.length!=0){jo(b,c);yo(a.n,null);gm(a,c)}else{Pn(a.k,b)}}
function Cn(a,b){var c;if(a===b){return true}else if(null==b||!ld(b,53)){return false}else{c=b;return a.e==c.e}}
function ol(){ll();++fk;this.b=new pc;this.a=new qb(null,lj((J(),new pl(this))),wp);D((null,I))}
function zm(){wm();++fk;this.b=new pc;this.a=new qb(null,lj((J(),new Am(this))),wp);D((null,I))}
function So(){So=oh;Po=new To('ACTIVE',0);Ro=new To('COMPLETED',1);Qo=new To('ALL',2)}
function jh(a,b){typeof window===_o&&typeof window['$gwt']===_o&&(window['$gwt'][a]=b)}
function ek(a){$wnd.React.Component.call(this,a);this.a=this.mb();this.a.q=lj(this);this.a.ib()}
function Hh(){this.g=Eh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function U(a,b){this.c=lj(a);this.f=null;this.g=null;this.e=new rb(this,b);this.d=new eb(this.e);fp==(b&gp)&&hb(this.e)}
function yc(a){wc();qc(this);this.e=a;a!=null&&Sj(a,op,this);this.f=a==null?qp:rh(a);this.a='';this.b=a;this.a=''}
function ik(a){if(!gk){gk=(++a.ob().e,new Bb);$wnd.Promise.resolve(null).then(ph(mk.prototype.L,mk,[]))}}
function tj(a){if(a.b){tj(a.b)}else if(a.c){throw $g(new Sh("Stream already terminated, can't be modified or used"))}}
function q(a){return pd(a)?ne:nd(a)?ce:md(a)?ae:kd(a)?a.xb:ad(a)?a.xb:a.xb||Array.isArray(a)&&Yc(Ud,1)||Ud}
function r(a){return pd(a)?$j(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.u():ad(a)?Uj(a):!!a&&!!a.hashCode?a.hashCode():Uj(a)}
function Vh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Xh(),Wh)[b];!c&&(c=Wh[b]=new Uh(a));return c}return new Uh(a)}
function rh(a){var b;if(Array.isArray(a)&&a.zb===sh){return Gh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function $j(a){Yj();var b,c,d;c=':'+a;d=Xj[c];if(d!=null){return rd(d)}d=Vj[c];b=d==null?Zj(a):rd(d);_j();Xj[c]=b;return b}
function Ki(a){var b,c,d;d=1;for(c=new Ii(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function nc(a){var b,c;if(!a.a){for(c=new Ii(new Hi(new ui(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.C()}a.a=true}}
function Tb(a){var b,c;c=(b=(Ah(),$wnd.window.window).location.hash,null==b?'':b.substr(1));$b(a,c);_h(a.j,c)&&_b(a,c)}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function _g(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<rp){return c}}return ah(ed(nd(a)?dh(a):a,nd(b)?dh(b):b))}
function p(a,b){return pd(a)?_h(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.s(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function Zk(){Xk();return cd(Yc(bf,1),dp,9,0,[Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk])}
function Jo(){this.a=xh((bo(),bo(),ao));this.b=xh(new qo(this.a));this.d=xh((Ho(),Ho(),Go));this.c=xh(new Fo(this.a,this.d))}
function zb(){this.c=new Q;this.d=$c(vd,dp,20,5,0,1);this.d[0]=new Q;this.d[1]=new Q;this.d[2]=new Q;this.d[3]=new Q;this.d[4]=new Q}
function pb(a,b,c,d){this.b=new Gi;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&hb(this)}
function el(){al();++fk;this.c=new pc;this.a=new U((J(),new fl(this)),136486912);this.b=new qb(null,lj(new hl(this)),wp);D((null,I))}
function Hl(){Al();var a;++fk;this.c=new pc;this.b=(a=new eb((J(),null)),a);this.a=new qb(null,lj(new Ll(this)),wp);D((null,I))}
function Pl(a){var b;b=T(a.d);if(!a.j&&b){a.j=true;fm(a,(cb(a.c),a.q.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function Ph(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Fi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Rj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function nk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.yb){return !!a.yb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function O(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function qb(a,b,c){pb.call(this,null,a,b,c|(!a?262144:fp)|(a?bp:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:jp)|(0!=(c&229376)?0:98304)|0|0|0)}
function Mb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ii(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&nb(b,5,true)}}}
function Lb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Ii(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&nb(b,6,true)}}}
function Kb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ii(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?nb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function ai(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ib(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=Ci(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&nb(c.b,3,true);++b}}}return b}
function Kn(a,b){var c,d,e;this.i=lj(a);this.g=b;this.e=An++;this.d=(d=new eb((J(),null)),d);this.c=new pc;this.b=(e=new eb(null),e);this.a=(c=new eb(null),c)}
function Zb(b){var c;try{A((J(),J(),I),new ec(b),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){c=a;throw $g(c)}else if(ld(a,4)){c=a;throw $g(new Th(c))}else throw $g(a)}}
function ac(b){var c;try{A((J(),J(),I),new fc(b),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){c=a;throw $g(c)}else if(ld(a,4)){c=a;throw $g(new Th(c))}else throw $g(a)}}
function Cl(b){var c;try{A((J(),J(),I),new Jl(b),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){c=a;throw $g(c)}else if(ld(a,4)){c=a;throw $g(new Th(c))}else throw $g(a)}}
function Jn(b){var c;try{A((J(),J(),I),new Mn(b),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){c=a;throw $g(c)}else if(ld(a,4)){c=a;throw $g(new Th(c))}else throw $g(a)}}
function go(b){var c;try{A((J(),J(),I),new no(b),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){c=a;throw $g(c)}else if(ld(a,4)){c=a;throw $g(new Th(c))}else throw $g(a)}}
function jo(b,c){var d;try{A((J(),J(),I),new mo(b,c),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){d=a;throw $g(d)}else if(ld(a,4)){d=a;throw $g(new Th(d))}else throw $g(a)}}
function ko(b,c){var d;try{A((J(),J(),I),new po(b,c),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){d=a;throw $g(d)}else if(ld(a,4)){d=a;throw $g(new Th(d))}else throw $g(a)}}
function Dl(b,c){var d;try{A((J(),J(),I),new Kl(b,c),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){d=a;throw $g(d)}else if(ld(a,4)){d=a;throw $g(new Th(d))}else throw $g(a)}}
function am(b,c){var d;try{A((J(),J(),I),new om(b,c),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){d=a;throw $g(d)}else if(ld(a,4)){d=a;throw $g(new Th(d))}else throw $g(a)}}
function em(b,c){var d;try{A((J(),J(),I),new nm(b,c),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){d=a;throw $g(d)}else if(ld(a,4)){d=a;throw $g(new Th(d))}else throw $g(a)}}
function fm(b,c){var d;try{A((J(),J(),I),new mm(b,c),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){d=a;throw $g(d)}else if(ld(a,4)){d=a;throw $g(new Th(d))}else throw $g(a)}}
function Pn(b,c){var d;try{A((J(),J(),I),new Wn(b,c),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){d=a;throw $g(d)}else if(ld(a,4)){d=a;throw $g(new Th(d))}else throw $g(a)}}
function Ub(b,c){var d;try{A((J(),J(),I),new dc(b,c),75505664)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){d=a;throw $g(d)}else if(ld(a,4)){d=a;throw $g(new Th(d))}else throw $g(a)}}
function On(b,c){var d;try{return t((J(),J(),I),new Yn(b,c),mp,null)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){d=a;throw $g(d)}else if(ld(a,4)){d=a;throw $g(new Th(d))}else throw $g(a)}}
function ih(b,c,d,e){hh();var f=fh;$moduleName=c;$moduleBase=d;Yg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{$o(g)()}catch(a){b(c,a)}}else{$o(g)()}}
function rb(a,b){pb.call(this,a,new sb(a),null,b|(fp==(b&gp)?0:524288)|(0!=(b&6291456)?0:fp==(b&gp)?jp:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function th(){var a;a=new Jo;bl(new Im(a));ml(new Lm(a));_l(new qn(a));xm(new wn(a));Bl(new cn(a));$wnd.ReactDOM.render(un(new vn),(Ah(),zh).getElementById('todoapp'),null)}
function Zi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return $i()}}
function Un(){var a;this.g=new Mi;this.d=(a=new eb((J(),null)),a);this.c=new U(new Xn(this),Bp);this.e=new U(new Zn(this),Bp);this.a=new U(new $n(this),Bp);this.b=new U(new _n(this),Bp)}
function hm(){Zl();var a,b;++fk;this.e=new pc;this.c=(b=new eb((J(),null)),b);this.a=(a=new eb(null),a);this.d=new U(new pm(this),136486912);this.b=new qb(null,lj(new qm(this)),wp);D((null,I))}
function gi(a,b){var c,d,e,f,g;g=ni(a.a);b.length<g&&(b=Rj(new Array(g),b));e=(f=new si((new pi(a.a)).a),new vi(f));for(d=0;d<g;++d){b[d]=(c=ri(e.a),c.bb())}b.length>g&&(b[g]=null);return b}
function lh(){kh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Ab()&&(c=Rc(c,g)):g[0].Ab()}catch(a){a=Zg(a);if(ld(a,4)){d=a;Dc();Jc(ld(d,40)?d.J():d)}else throw $g(a)}}return c}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?qp:od(b)?b==null?null:b.name:pd(b)?'String':Gh(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.g;try{d=b.c.w();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;$(b.d)}}catch(a){a=Zg(a);if(ld(a,12)){c=a;if(!b.b){b.g=null;b.b=c;$(b.d)}throw $g(c)}else throw $g(a)}}
function Nj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Qi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ni(b,e);if(f){return f.cb(c)}}e[e.length]=new wi(b,c);++a.b;return null}
function Zj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+$h(a,c++)}b=b|0;return b}
function M(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=$c(ke,dp,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function zo(a,b){var c;this.j=lj(a);this.i=lj(b);this.d=(c=new eb((J(),null)),c);this.b=new U(new Bo(this),Bp);this.c=new U(new Co(this),Bp);this.e=u(new Do(this),413155328);this.a=u(new Eo(this),681590784);D((null,I))}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=bp==(d&bp)?c.w():c.w()}else{Ob(b,e);try{g=bp==(d&bp)?c.w():c.w()}finally{Pb()}}return g}catch(a){a=Zg(a);if(ld(a,4)){f=a;throw $g(f)}else throw $g(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=bp==(d&bp)?(c.a.C(),null):(c.a.C(),null)}else{Ob(b,e);try{g=bp==(d&bp)?(c.a.C(),null):(c.a.C(),null)}finally{Pb()}}return g}catch(a){a=Zg(a);if(ld(a,4)){f=a;throw $g(f)}else throw $g(a)}finally{D(b)}}
function Sb(a){var b;if(0==a.length){b=(Ah(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',zh.title,b)}else{(Ah(),$wnd.window.window).location.hash=a}}
function ib(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.C()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=Zg(a);if(ld(a,4)){J()}else throw $g(a)}}}
function Ri(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Li(b,e.ab())){if(d.length==1){d.length=0;Ui(a.a,g)}else{d.splice(h,1)}--a.b;return e.bb()}}return null}
function nh(a,b,c){var d=kh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=kh[b]),qh(h));_.yb=c;!b&&(_.zb=sh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.xb=f)}
function Oh(a){if(a.Q()){var b=a.c;b.R()?(a.k='['+b.j):!b.Q()?(a.k='[L'+b.O()+';'):(a.k='['+b.O());a.b=b.N()+'[]';a.i=b.P()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Ph('.',[c,Ph('$',d)]);a.b=Ph('.',[c,Ph('.',d)]);a.i=d[d.length-1]}
function bc(){var a,b,c;this.f=new gc(this);this.c=new pc;this.b=(c=new eb((J(),null)),c);this.a=(b=new eb(null),b);Bh((Ah(),$wnd.window.window),lp,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function hi(a,b){var c,d,e;c=b.ab();e=b.bb();d=pd(c)?c==null?ji(Pi(a.a,null)):bj(a.b,c):ji(Pi(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Pi(a.a,null):aj(a.b,c):!!Pi(a.a,c))){return false}return true}
function ob(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ii(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Zg(a);if(!ld(a,4))throw $g(a)}if(6==(b.c&7)){return true}}}}}kb(b);return false}
function Yi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function nb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){db(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}zi(a.b,new ub(a));a.b.a=$c(ke,dp,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function wb(a){var b,c,d,e,f,g,h,i;d=P(a.d[0]);c=P(a.d[1]);g=P(a.d[2]);e=P(a.d[3]);f=P(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;L(a.d[0]);L(a.d[1]);L(a.d[2]);L(a.d[3]);L(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=O(b);h.c&=-513;ib(h);return true}
function Xk(){Xk=oh;Bk=new Yk(up,0);Ck=new Yk('checkbox',1);Dk=new Yk('color',2);Ek=new Yk('date',3);Fk=new Yk('datetime',4);Gk=new Yk('email',5);Hk=new Yk('file',6);Ik=new Yk('hidden',7);Jk=new Yk('image',8);Kk=new Yk('month',9);Lk=new Yk(ap,10);Mk=new Yk('password',11);Nk=new Yk('radio',12);Ok=new Yk('range',13);Pk=new Yk('reset',14);Qk=new Yk('search',15);Rk=new Yk('submit',16);Sk=new Yk('tel',17);Tk=new Yk('text',18);Uk=new Yk('time',19);Vk=new Yk('url',20);Wk=new Yk('week',21)}
function Fb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ai(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ei(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Z(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&nb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ai(a.b,g);if(-1==k.e){k.e=0;Y(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ci(a.b,g)}e&&mb(a.e,a.b)}else{e&&mb(a.e,new Gi)}if(V(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&fp!=(b.e.c&gp)&&Jb(a,k)}}
function $i(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[tp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Yi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[tp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var _o='object',ap='number',bp=16384,cp={15:1},dp={3:1,5:1},ep={11:1},fp=1048576,gp=1835008,hp={8:1},ip=67108864,jp=4194304,kp={30:1},lp='hashchange',mp=142614528,np='__noinit__',op='__java$exception',pp={3:1,12:1,6:1,4:1},qp='null',rp=17592186044416,sp={44:1},tp='delete',up='button',vp='selected',wp=1478635520,xp={11:1,39:1},yp='input',zp='completed',Ap='header',Bp=136421376,Cp='active';var _,kh,fh,Yg=-1;lh();nh(1,null,{},o);_.s=Ep;_.t=function(){return this.xb};_.u=Fp;_.v=function(){var a;return Gh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.s(a)};_.hashCode=function(){return this.u()};_.toString=function(){return this.v()};var fd,gd,hd;nh(55,1,{},Hh);_.M=function(a){var b;b=new Hh;b.e=4;a>1?(b.c=Mh(this,a-1)):(b.c=this);return b};_.N=function(){Fh(this);return this.b};_.O=function(){return Gh(this)};_.P=function(){Fh(this);return this.i};_.Q=function(){return (this.e&4)!=0};_.R=function(){return (this.e&1)!=0};_.v=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Fh(this),this.k)};_.e=0;_.g=0;var Eh=1;var ke=Jh(1);var be=Jh(55);nh(89,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var ud=Jh(89);nh(16,1,cp,G);_.w=function(){return this.a.C(),null};var sd=Jh(16);nh(90,1,{},H);var td=Jh(90);var I;nh(20,1,{20:1},Q);_.b=0;_.c=false;_.d=0;var vd=Jh(20);nh(226,1,ep);_.v=function(){var a;return Gh(this.xb)+'@'+(a=r(this)>>>0,a.toString(16))};var xd=Jh(226);nh(21,226,ep,U);_.A=function(){S(this)};_.B=Dp;_.a=false;var wd=Jh(21);nh(17,226,{11:1,17:1},eb);_.A=function(){W(this)};_.B=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=Jh(17);nh(151,1,hp,fb);_.C=function(){X(this.a)};var yd=Jh(151);nh(19,226,{11:1,19:1},qb,rb);_.A=function(){gb(this)};_.B=function(){return 1==(this.c&7)};_.c=0;var Dd=Jh(19);nh(152,1,kp,sb);_.C=function(){R(this.a)};var Ad=Jh(152);nh(153,1,hp,tb);_.C=function(){lb(this.a)};var Bd=Jh(153);nh(154,1,{},ub);_.D=function(a){jb(this.a,a)};var Cd=Jh(154);nh(115,1,{},zb);_.a=0;_.b=100;_.e=0;var Ed=Jh(115);nh(71,1,ep,Bb);_.A=function(){Ab(this)};_.B=Dp;_.a=false;var Fd=Jh(71);nh(160,1,{},Nb);_.v=function(){var a;return Fh(Gd),Gd.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.a=0;var Cb;var Gd=Jh(160);nh(51,1,{51:1});_.e='';_.g='';_.i=true;_.j='';var Nd=Jh(51);nh(155,51,{11:1,51:1,39:1},bc);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new cc(this)),ip,null)}};_.s=Ep;_.F=Mp;_.u=Fp;_.B=Np;_.v=function(){var a;return Fh(Ld),Ld.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.d=0;var Ld=Jh(155);nh(156,1,hp,cc);_.C=function(){Xb(this.a)};var Hd=Jh(156);nh(157,1,hp,dc);_.C=function(){Qb(this.a,this.b)};var Id=Jh(157);nh(158,1,hp,ec);_.C=function(){Yb(this.a)};var Jd=Jh(158);nh(159,1,hp,fc);_.C=function(){Tb(this.a)};var Kd=Jh(159);nh(138,1,{},gc);_.handleEvent=function(a){Rb(this.a,a)};var Md=Jh(138);nh(117,1,{});var Qd=Jh(117);nh(127,1,{},kc);_.D=function(a){ic(this.a,a)};var Od=Jh(127);nh(128,1,hp,lc);_.C=function(){jc(this.a,this.b)};var Pd=Jh(128);nh(118,117,{});var Rd=Jh(118);nh(27,1,ep,pc);_.A=function(){nc(this)};_.B=Dp;_.a=false;var Sd=Jh(27);nh(4,1,{3:1,4:1});_.G=function(a){return new Error(a)};_.H=function(){return this.f};_.I=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Gh(this.xb),c==null?a:a+': '+c);rc(this,tc(this.G(b)));Vc(this)};_.v=function(){return sc(this,this.H())};_.e=np;_.g=true;var oe=Jh(4);nh(12,4,{3:1,12:1,4:1});var ee=Jh(12);nh(6,12,pp);var le=Jh(6);nh(56,6,pp);var he=Jh(56);nh(86,56,pp);var Wd=Jh(86);nh(40,86,{40:1,3:1,12:1,6:1,4:1},yc);_.H=function(){xc(this);return this.c};_.J=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Td=Jh(40);var Ud=Jh(0);nh(209,1,{});var Vd=Jh(209);var Ac=0,Bc=0,Cc=-1;nh(98,209,{},Qc);var Mc;var Xd=Jh(98);var Tc;nh(220,1,{});var Zd=Jh(220);nh(87,220,{},Xc);var Yd=Jh(87);nh(46,1,{46:1},wh);_.K=function(){var a,b;b=this.a;if(qd(b)===qd(uh)){b=this.a;if(qd(b)===qd(uh)){b=this.b.K();a=this.a;if(qd(a)!==qd(uh)&&qd(a)!==qd(b)){throw $g(new Sh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}this.a=b;this.b=null}}return b};var uh;var $d=Jh(46);var zh;nh(84,1,{81:1});_.v=Dp;var _d=Jh(84);fd={3:1,82:1,31:1};var ae=Jh(82);nh(45,1,{3:1,45:1});var je=Jh(45);gd={3:1,31:1,45:1};var ce=Jh(219);nh(35,1,{3:1,31:1,35:1});_.s=Ep;_.u=Fp;_.v=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=Jh(35);nh(10,6,pp,Sh,Th);var fe=Jh(10);nh(32,45,{3:1,31:1,32:1,45:1},Uh);_.s=function(a){return ld(a,32)&&a.a==this.a};_.u=Dp;_.v=function(){return ''+this.a};_.a=0;var ge=Jh(32);var Wh;nh(277,1,{});nh(64,56,pp,Zh);_.G=function(a){return new TypeError(a)};var ie=Jh(64);hd={3:1,81:1,31:1,2:1};var ne=Jh(2);nh(85,84,{81:1},di);var me=Jh(85);nh(281,1,{});nh(63,6,pp,ei);var pe=Jh(63);nh(221,1,{43:1});_.S=Jp;_.W=function(){return new pj(this,0)};_.X=function(){return new zj(null,this.W())};_.U=function(a){throw $g(new ei('Add not supported on this collection'))};_.v=function(){var a,b,c;c=new rj('[',']');for(b=this.T();b.Z();){a=b.$();qj(c,a===this?'(this Collection)':a==null?qp:rh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var qe=Jh(221);nh(224,1,{208:1});_.s=function(a){var b,c,d;if(a===this){return true}if(!ld(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new si((new pi(d)).a);c.b;){b=ri(c);if(!hi(this,b)){return false}}return true};_.u=function(){return Ji(new pi(this))};_.v=function(){var a,b,c;c=new rj('{','}');for(b=new si((new pi(this)).a);b.b;){a=ri(b);qj(c,ii(this,a.ab())+'='+ii(this,a.bb()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Be=Jh(224);nh(114,224,{208:1});var te=Jh(114);nh(223,221,{43:1,232:1});_.W=function(){return new pj(this,1)};_.s=function(a){var b;if(a===this){return true}if(!ld(a,25)){return false}b=a;if(ni(b.a)!=this.V()){return false}return fi(this,b)};_.u=function(){return Ji(this)};var Ce=Jh(223);nh(25,223,{25:1,43:1,232:1},pi);_.T=function(){return new si(this.a)};_.V=Hp;var se=Jh(25);nh(26,1,{},si);_.Y=Gp;_.$=function(){return ri(this)};_.Z=Ip;_.b=false;var re=Jh(26);nh(222,221,{43:1,229:1});_.W=function(){return new pj(this,16)};_._=function(a,b){throw $g(new ei('Add not supported on this list'))};_.U=function(a){this._(this.V(),a);return true};_.s=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.V()!=f.a.length){return false}e=new Ii(f);for(c=new Ii(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.u=function(){return Ki(this)};_.T=function(){return new ti(this)};var ve=Jh(222);nh(96,1,{},ti);_.Y=Gp;_.Z=function(){return this.a<this.b.a.length};_.$=function(){return Ai(this.b,this.a++)};_.a=0;var ue=Jh(96);nh(47,221,{43:1},ui);_.T=function(){var a;return a=new si((new pi(this.a)).a),new vi(a)};_.V=Hp;var xe=Jh(47);nh(66,1,{},vi);_.Y=Gp;_.Z=function(){return this.a.b};_.$=function(){var a;return a=ri(this.a),a.bb()};var we=Jh(66);nh(103,1,sp);_.s=function(a){var b;if(!ld(a,44)){return false}b=a;return Li(this.a,b.ab())&&Li(this.b,b.bb())};_.ab=Dp;_.bb=Ip;_.u=function(){return kj(this.a)^kj(this.b)};_.cb=function(a){var b;b=this.b;this.b=a;return b};_.v=function(){return this.a+'='+this.b};var ye=Jh(103);nh(104,103,sp,wi);var ze=Jh(104);nh(225,1,sp);_.s=function(a){var b;if(!ld(a,44)){return false}b=a;return Li(this.b.value[0],b.ab())&&Li(gj(this),b.bb())};_.u=function(){return kj(this.b.value[0])^kj(gj(this))};_.v=function(){return this.b.value[0]+'='+gj(this)};var Ae=Jh(225);nh(14,222,{3:1,14:1,43:1,229:1},Gi,Hi);_._=function(a,b){Oj(this.a,a,b)};_.U=function(a){return yi(this,a)};_.S=function(a){zi(this,a)};_.T=function(){return new Ii(this)};_.V=function(){return this.a.length};var Ee=Jh(14);nh(18,1,{},Ii);_.Y=Gp;_.Z=function(){return this.a<this.c.a.length};_.$=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var De=Jh(18);nh(41,114,{3:1,41:1,208:1},Mi);var Fe=Jh(41);nh(69,1,{},Si);_.S=Jp;_.T=function(){return new Ti(this)};_.b=0;var He=Jh(69);nh(70,1,{},Ti);_.Y=Gp;_.$=function(){return this.d=this.a[this.c++],this.d};_.Z=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ge=Jh(70);var Wi;nh(67,1,{},ej);_.S=Jp;_.T=function(){return new fj(this)};_.b=0;_.c=0;var Ke=Jh(67);nh(68,1,{},fj);_.Y=Gp;_.$=function(){return this.c=this.a,this.a=this.b.next(),new hj(this.d,this.c,this.d.c)};_.Z=function(){return !this.a.done};var Ie=Jh(68);nh(116,225,sp,hj);_.ab=function(){return this.b.value[0]};_.bb=function(){return gj(this)};_.cb=function(a){return cj(this.a,this.b.value[0],a)};_.c=0;var Je=Jh(116);nh(97,1,{});_.Y=function(a){mj(this,a)};_.db=function(){return this.d};_.eb=Sp;_.d=0;_.e=0;var Me=Jh(97);nh(65,97,{});var Le=Jh(65);nh(24,1,{},pj);_.db=Dp;_.eb=function(){oj(this);return this.c};_.Y=function(a){oj(this);this.d.Y(a)};_.fb=function(a){oj(this);if(this.d.Z()){a.D(this.d.$());return true}return false};_.a=0;_.c=0;var Ne=Jh(24);nh(57,1,{},rj);_.v=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Oe=Jh(57);var Xe=Lh();nh(105,1,{});_.c=false;var Ye=Jh(105);nh(34,105,{},zj);var We=Jh(34);nh(107,65,{},Dj);_.fb=function(a){this.b=false;while(!this.b&&this.c.fb(new Ej(this,a)));return this.b};_.b=false;var Qe=Jh(107);nh(110,1,{},Ej);_.D=function(a){Cj(this.a,this.b,a)};var Pe=Jh(110);nh(106,65,{},Gj);_.fb=function(a){return this.a.fb(new Hj(a))};var Se=Jh(106);nh(109,1,{},Hj);_.D=function(a){Fj(this.a,a)};var Re=Jh(109);nh(108,1,{},Jj);_.D=function(a){Ij(this,a)};var Te=Jh(108);nh(111,1,{},Kj);_.D=function(a){};var Ue=Jh(111);nh(112,1,{},Mj);_.D=function(a){Lj(this,a)};var Ve=Jh(112);nh(279,1,{});nh(228,1,{});var Ze=Jh(228);nh(276,1,{});var Tj=0;var Vj,Wj=0,Xj;nh(737,1,{});nh(752,1,{});nh(227,1,{});_.hb=Kp;_.ib=Kp;_.kb=function(a,b,c){return false};_.r=false;var $e=Jh(227);nh(33,$wnd.React.Component,{});mh(kh[1],_);_.render=function(){return kk(this.a)};var _e=Jh(33);nh(36,227,{});_.nb=function(){return false};_.pb=function(){return lk(this)};_.o=false;_.p=false;var fk=1,gk;var af=Jh(36);nh(247,$wnd.Function,{},mk);_.L=function(a){return Ab(gk),gk=null,null};nh(9,35,{3:1,31:1,35:1,9:1},Yk);var Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk;var bf=Kh(9,Zk);nh(161,36,{});_.ub=Lp;_.jb=function(){var a;a=T(this.g.b);return $wnd.React.createElement('footer',nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,['footer'])),Jm(new Km),$wnd.React.createElement('ul',nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',pk(nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,[(So(),Qo)==a?vp:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',pk(nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,[Po==a?vp:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',pk(nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,[Ro==a?vp:null])),'#completed'),'Completed'))),this.ub()?$wnd.React.createElement(up,qk(nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,['clear-completed'])),ph(Fm.prototype.tb,Fm,[this])),'Clear Completed'):null)};var Qf=Jh(161);nh(162,161,{});_.ub=Lp;var $k,_k;var Uf=Jh(162);nh(163,162,xp,el);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new il(this)),ip,null)}};_.s=Ep;_.ob=Op;_.F=Mp;_.ub=function(){return T(this.a)};_.u=Fp;_.B=Np;_.v=function(){var a;return Fh(nf),nf.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.b,new gl(this))}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){b=a;throw $g(b)}else if(ld(a,4)){b=a;throw $g(new Th(b))}else throw $g(a)}};_.d=0;var nf=Jh(163);nh(164,1,cp,fl);_.w=function(){return cl(this.a)};var cf=Jh(164);nh(167,1,cp,gl);_.w=Qp;var df=Jh(167);nh(165,1,kp,hl);_.C=Pp;var ef=Jh(165);nh(166,1,hp,il);_.C=function(){dl(this.a)};var ff=Jh(166);nh(168,36,{});_.jb=function(){var a,b;b=T(this.d.e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,['todo-count'])),$wnd.React.createElement('strong',null,b),' '+a+' left')};var Pf=Jh(168);nh(169,168,{});var jl,kl;var Tf=Jh(169);nh(170,169,xp,ol);_.A=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new ql(this)),ip,null)}};_.s=Ep;_.ob=Op;_.F=Ip;_.u=Fp;_.B=Tp;_.v=function(){var a;return Fh(lf),lf.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.a,new rl(this))}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){b=a;throw $g(b)}else if(ld(a,4)){b=a;throw $g(new Th(b))}else throw $g(a)}};_.c=0;var lf=Jh(170);nh(171,1,kp,pl);_.C=Pp;var gf=Jh(171);nh(172,1,hp,ql);_.C=function(){nl(this.a)};var hf=Jh(172);nh(173,1,cp,rl);_.w=Qp;var jf=Jh(173);nh(147,1,{},tl);_.K=function(){return sl(this)};var kf=Jh(147);nh(146,1,{},vl);_.K=function(){return ul(this)};var mf=Jh(146);nh(192,36,{});_.jb=function(){return $wnd.React.createElement(yp,rk(vk(wk(zk(xk(nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,['new-todo']))),(bb(this.b),this.f)),ph($m.prototype.sb,$m,[this])),ph(_m.prototype.rb,_m,[this]))))};_.f='';var bg=Jh(192);nh(193,192,{});var yl,zl;var Wf=Jh(193);nh(194,193,xp,Hl);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Ml(this)),ip,null)}};_.s=Ep;_.ob=Op;_.F=Mp;_.u=Fp;_.B=Np;_.v=function(){var a;return Fh(uf),uf.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.a,new Il(this))}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){b=a;throw $g(b)}else if(ld(a,4)){b=a;throw $g(new Th(b))}else throw $g(a)}};_.d=0;var uf=Jh(194);nh(197,1,cp,Il);_.w=Qp;var of=Jh(197);nh(198,1,hp,Jl);_.C=function(){wl(this.a)};var pf=Jh(198);nh(199,1,hp,Kl);_.C=function(){El(this.a,this.b)};var qf=Jh(199);nh(195,1,kp,Ll);_.C=Pp;var rf=Jh(195);nh(196,1,hp,Ml);_.C=function(){Fl(this.a)};var sf=Jh(196);nh(150,1,{},Ol);_.K=function(){return Nl(this)};var tf=Jh(150);nh(174,36,{});_.hb=function(){Pl(this)};_.wb=Rp;_.ib=function(){fm(this,this.vb())};_.jb=function(){var a,b;b=this.vb();a=(bb(b.a),b.g);return $wnd.React.createElement('li',nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,[a?zp:null,this.wb()?'editing':null])),$wnd.React.createElement('div',nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,['view'])),$wnd.React.createElement(yp,vk(sk(yk(nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,['toggle'])),(Xk(),Ck)),a),ph(fn.prototype.rb,fn,[b]))),$wnd.React.createElement('label',Ak(new $wnd.Object,ph(gn.prototype.tb,gn,[this,b])),(bb(b.b),b.i)),$wnd.React.createElement(up,qk(nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,['destroy'])),ph(hn.prototype.tb,hn,[this,b])))),$wnd.React.createElement(yp,wk(vk(uk(tk(nk(ok(new $wnd.Object,ph(jn.prototype.D,jn,[this])),cd(Yc(ne,1),dp,2,6,['edit'])),(bb(this.a),this.i)),ph(kn.prototype.qb,kn,[this,b])),ph(en.prototype.rb,en,[this])),ph(ln.prototype.sb,ln,[this,b]))))};_.j=false;var eg=Jh(174);nh(175,174,{});_.nb=function(){var a;a=(cb(this.c),this.q.props['a']);if(!!a&&a.f<0){return true}return false};_.vb=function(){return this.q.props['a']};_.wb=Rp;_.kb=function(a,b,c){return $l(this,a,b,c)};var Xl,Yl;var Yf=Jh(175);nh(176,175,xp,hm);_.hb=function(){var b;try{A((J(),J(),I),new km(this),mp)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){b=a;throw $g(b)}else if(ld(a,4)){b=a;throw $g(new Th(b))}else throw $g(a)}};_.A=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new im(this)),ip,null)}};_.s=Ep;_.ob=Op;_.F=Sp;_.vb=function(){return cb(this.c),this.q.props['a']};_.u=Fp;_.B=Vp;_.wb=function(){return T(this.d)};_.kb=function(b,c,d){var e;try{return t((J(),J(),I),new lm(this,b,c,d),75505664,null)}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){e=a;throw $g(e)}else if(ld(a,4)){e=a;throw $g(new Th(e))}else throw $g(a)}};_.v=function(){var a;return Fh(Ff),Ff.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.b,new jm(this))}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){b=a;throw $g(b)}else if(ld(a,4)){b=a;throw $g(new Th(b))}else throw $g(a)}};_.f=0;var Ff=Jh(176);nh(179,1,hp,im);_.C=function(){bm(this.a)};var vf=Jh(179);nh(180,1,cp,jm);_.w=Qp;var wf=Jh(180);nh(181,1,hp,km);_.C=function(){Pl(this.a)};var xf=Jh(181);nh(182,1,cp,lm);_.w=function(){return cm(this.a,this.d,this.c,this.b)};_.b=false;var yf=Jh(182);nh(183,1,hp,mm);_.C=function(){gm(this.a,Dn(this.b))};var zf=Jh(183);nh(184,1,hp,nm);_.C=function(){Vl(this.a,this.b)};var Af=Jh(184);nh(185,1,hp,om);_.C=function(){Ql(this.a,this.b)};var Bf=Jh(185);nh(177,1,cp,pm);_.w=function(){return dm(this.a)};var Cf=Jh(177);nh(178,1,kp,qm);_.C=Pp;var Df=Jh(178);nh(148,1,{},sm);_.K=function(){return rm(this)};var Ef=Jh(148);nh(186,36,{});_.jb=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(Ap,nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,[Ap])),$wnd.React.createElement('h1',null,'todos'),an(new bn)),T(this.d.c)?null:$wnd.React.createElement('section',nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,[Ap])),$wnd.React.createElement(yp,vk(yk(nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,['toggle-all'])),(Xk(),Ck)),ph(tn.prototype.rb,tn,[this]))),$wnd.React.createElement.apply(null,['ul',nk(new $wnd.Object,cd(Yc(ne,1),dp,2,6,['todo-list']))].concat((a=yj(xj(T(this.f.c).X()),(b=new Gi,b)),Fi(a,bd(a.a.length)))))),T(this.d.c)?null:Gm(new Hm)))};var hg=Jh(186);nh(187,186,{});var um,vm;var $f=Jh(187);nh(188,187,xp,zm);_.A=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Bm(this)),ip,null)}};_.s=Ep;_.ob=Op;_.F=Ip;_.u=Fp;_.B=Tp;_.v=function(){var a;return Fh(Kf),Kf.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.pb=function(){var b;try{return B((J(),J(),I),this.a,new Cm(this))}catch(a){a=Zg(a);if(ld(a,6)||ld(a,7)){b=a;throw $g(b)}else if(ld(a,4)){b=a;throw $g(new Th(b))}else throw $g(a)}};_.c=0;var Kf=Jh(188);nh(189,1,kp,Am);_.C=Pp;var Gf=Jh(189);nh(190,1,hp,Bm);_.C=function(){nl(this.a)};var Hf=Jh(190);nh(191,1,cp,Cm);_.w=Qp;var If=Jh(191);nh(149,1,{},Em);_.K=function(){return Dm(this)};var Jf=Jh(149);nh(246,$wnd.Function,{},Fm);_.tb=function(a){go(this.a.f)};nh(202,1,{},Hm);var Lf=Jh(202);nh(75,1,{},Im);_.K=function(){return ul((new Ko(this.a)).a)};var Mf=Jh(75);nh(200,1,{},Km);var Nf=Jh(200);nh(76,1,{},Lm);_.K=function(){return sl((new Lo(this.a)).a)};var Of=Jh(76);nh(245,$wnd.Function,{},Qm);_.lb=function(a){return new Rm(a)};nh(91,33,{},Rm);_.mb=function(){return al(),ul((new Ko(_k.a)).a)};_.componentWillUnmount=Up;var Rf=Jh(91);nh(249,$wnd.Function,{},Sm);_.lb=function(a){return new Tm(a)};nh(92,33,{},Tm);_.mb=function(){return ll(),sl((new Lo(kl.a)).a)};_.componentWillUnmount=Up;var Sf=Jh(92);nh(261,$wnd.Function,{},Um);_.lb=function(a){return new Vm(a)};nh(95,33,{},Vm);_.mb=function(){return Al(),Nl((new Mo(zl.a)).a)};_.componentWillUnmount=Up;var Vf=Jh(95);nh(250,$wnd.Function,{},Wm);_.lb=function(a){return new Xm(a)};nh(93,33,{},Xm);_.mb=function(){return Zl(),rm((new No(Yl.a)).a)};_.componentDidUpdate=function(a){bk(this.a,a)};_.componentWillUnmount=Up;_.shouldComponentUpdate=function(a){return ck(this.a,a)};var Xf=Jh(93);nh(259,$wnd.Function,{},Ym);_.lb=function(a){return new Zm(a)};nh(94,33,{},Zm);_.mb=function(){return wm(),Dm((new Oo(vm.a)).a)};_.componentWillUnmount=Up;var Zf=Jh(94);nh(262,$wnd.Function,{},$m);_.sb=function(a){xl(this.a,a)};nh(263,$wnd.Function,{},_m);_.rb=function(a){Dl(this.a,a)};nh(201,1,{},bn);var _f=Jh(201);nh(79,1,{},cn);_.K=function(){return Nl((new Mo(this.a)).a)};var ag=Jh(79);nh(257,$wnd.Function,{},en);_.rb=function(a){am(this.a,a)};nh(251,$wnd.Function,{},fn);_.rb=function(a){Jn(this.a)};nh(253,$wnd.Function,{},gn);_.tb=function(a){Rl(this.a,this.b)};nh(254,$wnd.Function,{},hn);_.tb=function(a){Sl(this.a,this.b)};nh(255,$wnd.Function,{},jn);_.D=function(a){Tl(this.a,a)};nh(256,$wnd.Function,{},kn);_.qb=function(a){Wl(this.a,this.b)};nh(258,$wnd.Function,{},ln);_.sb=function(a){Ul(this.a,this.b,a)};nh(203,1,{},pn);var cg=Jh(203);nh(77,1,{},qn);_.K=function(){return rm((new No(this.a)).a)};var dg=Jh(77);nh(260,$wnd.Function,{},tn);_.rb=function(a){tm(this.a,a)};nh(80,1,{},vn);var fg=Jh(80);nh(78,1,{},wn);_.K=function(){return Dm((new Oo(this.a)).a)};var gg=Jh(78);nh(52,1,{52:1});_.g=false;var Vg=Jh(52);nh(53,52,{11:1,39:1,53:1,52:1},Kn);_.A=function(){Bn(this)};_.s=function(a){return Cn(this,a)};_.F=Mp;_.u=Sp;_.B=Vp;_.v=function(){var a;return Fh(zg),zg.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var An=0;var zg=Jh(53);nh(204,1,hp,Ln);_.C=function(){Fn(this.a)};var ig=Jh(204);nh(205,1,hp,Mn);_.C=function(){Gn(this.a)};var jg=Jh(205);nh(48,118,{48:1});var Qg=Jh(48);nh(119,48,{11:1,48:1},Un);_.A=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new Vn(this)),ip,null)}};_.s=Ep;_.u=Fp;_.B=Vp;_.v=function(){var a;return Fh(sg),sg.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.f=0;var sg=Jh(119);nh(124,1,hp,Vn);_.C=function(){Rn(this.a)};var kg=Jh(124);nh(125,1,hp,Wn);_.C=function(){hc(this.a,this.b,true)};var lg=Jh(125);nh(120,1,cp,Xn);_.w=function(){return Sn(this.a)};var mg=Jh(120);nh(126,1,cp,Yn);_.w=function(){return Nn(this.a,this.c,this.b)};_.b=false;var ng=Jh(126);nh(121,1,cp,Zn);_.w=function(){return Vh(eh(vj(Qn(this.a))))};var og=Jh(121);nh(122,1,cp,$n);_.w=function(){return Vh(eh(vj(wj(Qn(this.a),new Vo))))};var pg=Jh(122);nh(123,1,cp,_n);_.w=function(){return Tn(this.a)};var qg=Jh(123);nh(99,1,{},co);_.K=function(){return new Un};var ao;var rg=Jh(99);nh(49,1,{49:1});var Ug=Jh(49);nh(130,49,{11:1,49:1},lo);_.A=function(){if(this.a>=0){this.a=-2;t((J(),J(),I),new G(new oo),ip,null)}};_.s=Ep;_.u=Fp;_.B=function(){return this.a<0};_.v=function(){var a;return Fh(yg),yg.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.a=0;var yg=Jh(130);nh(133,1,hp,mo);_.C=function(){In(this.b,this.a)};var tg=Jh(133);nh(134,1,hp,no);_.C=function(){ho(this.a)};var ug=Jh(134);nh(131,1,hp,oo);_.C=Kp;var vg=Jh(131);nh(132,1,hp,po);_.C=function(){io(this.a,this.b)};_.b=false;var wg=Jh(132);nh(100,1,{},qo);_.K=function(){return new lo(this.a.K())};var xg=Jh(100);nh(50,1,{50:1});var Xg=Jh(50);nh(139,50,{11:1,50:1},zo);_.A=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new Ao(this)),ip,null)}};_.s=Ep;_.u=Fp;_.B=function(){return this.g<0};_.v=function(){var a;return Fh(Gg),Gg.k+'@'+(a=Uj(this)>>>0,a.toString(16))};_.g=0;var Gg=Jh(139);nh(144,1,hp,Ao);_.C=function(){uo(this.a)};var Ag=Jh(144);nh(140,1,cp,Bo);_.w=function(){var a;return a=Wb(this.a.i),_h(Cp,a)||_h(zp,a)||_h('',a)?_h(Cp,a)?(So(),Po):_h(zp,a)?(So(),Ro):(So(),Qo):(So(),Qo)};var Bg=Jh(140);nh(141,1,cp,Co);_.w=function(){return vo(this.a)};var Cg=Jh(141);nh(142,1,kp,Do);_.C=function(){wo(this.a)};var Dg=Jh(142);nh(143,1,kp,Eo);_.C=function(){xo(this.a)};var Eg=Jh(143);nh(102,1,{},Fo);_.K=function(){return new zo(this.b.K(),this.a.K())};var Fg=Jh(102);nh(101,1,{},Io);_.K=function(){return new bc};var Go;var Hg=Jh(101);nh(74,1,{},Jo);var Ng=Jh(74);nh(58,1,{},Ko);var Ig=Jh(58);nh(62,1,{},Lo);var Jg=Jh(62);nh(61,1,{},Mo);var Kg=Jh(61);nh(59,1,{},No);var Lg=Jh(59);nh(60,1,{},Oo);var Mg=Jh(60);nh(37,35,{3:1,31:1,35:1,37:1},To);var Po,Qo,Ro;var Og=Kh(37,Uo);nh(129,1,{},Vo);_.gb=function(a){return !En(a)};var Pg=Jh(129);nh(136,1,{},Wo);_.gb=function(a){return En(a)};var Rg=Jh(136);nh(137,1,{},Xo);_.D=function(a){Pn(this.a,a)};var Sg=Jh(137);nh(135,1,{},Yo);_.D=function(a){fo(this.a,a)};_.a=false;var Tg=Jh(135);nh(145,1,{},Zo);_.gb=function(a){return so(this.a,a)};var Wg=Jh(145);var $o=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=ih;gh(th);jh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();