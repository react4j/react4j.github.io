function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='BFFCDDC4B2F65DF3B40EF3436DABD53B',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'BFFCDDC4B2F65DF3B40EF3436DABD53B';function p(){}
function vh(){}
function rh(){}
function Fb(){}
function Rc(){}
function Yc(){}
function ii(){}
function Dj(){}
function Rj(){}
function Zj(){}
function $j(){}
function zk(){}
function nl(){}
function Vm(){}
function Zm(){}
function bn(){}
function fn(){}
function kn(){}
function Fn(){}
function bo(){}
function cp(){}
function lp(){}
function mp(){}
function pp(){}
function Wc(a){Vc()}
function Ih(){Ih=rh}
function Li(){Ci(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function gc(a){this.a=a}
function pc(a){this.a=a}
function Yh(a){this.a=a}
function hi(a){this.a=a}
function ui(a){this.a=a}
function zi(a){this.a=a}
function Ai(a){this.a=a}
function yi(a){this.b=a}
function Ni(a){this.c=a}
function Ej(a){this.a=a}
function ak(a){this.a=a}
function wl(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Vl(a){this.a=a}
function Wl(a){this.a=a}
function Xl(a){this.a=a}
function Zl(a){this.a=a}
function um(a){this.a=a}
function vm(a){this.a=a}
function Am(a){this.a=a}
function Cm(a){this.a=a}
function Dm(a){this.a=a}
function Lm(a){this.a=a}
function Mm(a){this.a=a}
function Nm(a){this.a=a}
function Om(a){this.a=a}
function on(a){this.a=a}
function pn(a){this.a=a}
function tn(a){this.a=a}
function un(a){this.a=a}
function xn(a){this.a=a}
function En(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function oo(a){this.a=a}
function po(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Eo(a){this.a=a}
function Fo(a){this.a=a}
function Po(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function np(a){this.a=a}
function op(a){this.a=a}
function qp(a){this.a=a}
function rp(a){this.a=a}
function _p(){jc(this.c)}
function bq(){jc(this.b)}
function gq(){jc(this.f)}
function Y(a){!!a&&$(a)}
function kc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function Vp(a){pj(this,a)}
function Yp(a){ai(this,a)}
function $p(a){sj(this,a)}
function Ho(a,b){sm(b,a)}
function qk(a,b){pk(a,b)}
function qb(a,b){a.b=b}
function Yj(a,b){a.a=b}
function sk(a,b){a.key=b}
function nc(a,b){qi(a.e,b)}
function _j(a,b){Qj(a.a,b)}
function _l(a,b){to(a.k,b)}
function Go(a,b){so(a.b,b)}
function C(a,b){Nb(a.f,b.f)}
function K(a,b){O(a);L(a,b)}
function db(a){Xb((J(),a))}
function eb(a){Yb((J(),a))}
function hb(a){Zb((J(),a))}
function dq(){kb(this.a.a)}
function Zi(){this.a=gj()}
function lj(){this.a=gj()}
function cj(){cj=rh;bj=ej()}
function J(){J=rh;I=new F}
function xc(){xc=rh;wc=new p}
function yh(){yh=rh;xh=new p}
function Oc(){Oc=rh;Nc=new Rc}
function bh(a){return a.e}
function Zp(){return this.e}
function Tp(){return this.a}
function Xp(){return this.b}
function Up(){return hk(this)}
function am(a,b){return a.i=b}
function sc(a,b){a.e=b;rc(a,b)}
function ol(a){a.e=2;jc(a.c)}
function Al(a){a.d=2;jc(a.b)}
function em(a){a.g=2;jc(a.e)}
function eo(a){$(a.b);$(a.a)}
function Qn(a){R(a.a);$(a.b)}
function Pl(a){kb(a.a);$(a.b)}
function sl(a){kb(a.b);R(a.a)}
function Hh(a){vc.call(this,a)}
function Xh(a){vc.call(this,a)}
function ji(a){vc.call(this,a)}
function ek(a,b){a.splice(b,1)}
function ic(a,b,c){pi(a.e,b,c)}
function fo(a,b,c){ic(a.c,b,c)}
function xj(a,b,c){b.w(a.a[c])}
function Fi(a,b){return a.a[b]}
function Zc(a,b){return Rh(a,b)}
function Wp(){return si(this.a)}
function aq(){return this.c.i<0}
function cq(){return this.b.i<0}
function hq(){return this.f.i<0}
function bi(){qc(this);this.G()}
function Ec(){Ec=rh;!!(Vc(),Uc)}
function ep(){ep=rh;dp=new cp}
function gj(){cj();return new bj}
function Lh(a){Kh(a);return a.k}
function Pj(a,b){a.T(b);return a}
function T(a){mb(a.f);return V(a)}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function ab(a){J();Yb(a);a.e=-2}
function Tm(a){this.a=a;Um=this}
function rn(a){this.a=a;sn=this}
function zh(a){this.a=xh;this.b=a}
function io(a){fb(a.a);return a.d}
function To(a){fb(a.d);return a.e}
function Sn(a){fb(a.b);return a.e}
function Ck(a,b){a.ref=b;return a}
function sj(a,b){while(a.eb(b));}
function Qj(a,b){Yj(a,Pj(a.a,b))}
function Vj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function ij(a,b){return a.a.get(b)}
function si(a){return a.a.b+a.b.b}
function eq(a){return 1==this.a.e}
function fq(a){return 1==this.a.d}
function Db(a){this.d=a;this.b=100}
function hc(a,b){this.a=a;this.b=b}
function Wh(a,b){this.a=a;this.b=b}
function Bi(a,b){this.a=a;this.b=b}
function Uj(a,b){this.a=a;this.b=b}
function Xj(a,b){this.a=a;this.b=b}
function Ak(a,b){this.a=a;this.b=b}
function Yl(a,b){this.a=a;this.b=b}
function wm(a,b){this.a=a;this.b=b}
function xm(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function zm(a,b){this.a=a;this.b=b}
function Bm(a,b){this.a=a;this.b=b}
function vn(a,b){this.a=a;this.b=b}
function wn(a,b){this.a=a;this.b=b}
function yn(a,b){this.a=a;this.b=b}
function zn(a,b){this.a=a;this.b=b}
function jl(a,b){Wh.call(this,a,b)}
function ck(a,b,c){a.splice(b,0,c)}
function Dk(a,b){a.href=b;return a}
function $n(a,b){this.a=a;this.b=b}
function Ao(a,b){this.a=a;this.b=b}
function No(a,b){this.a=a;this.b=b}
function Oo(a,b){this.b=a;this.a=b}
function jp(a,b){Wh.call(this,a,b)}
function kh(){ih==null&&(ih=[])}
function Pm(){this.a=wk((Xm(),Wm))}
function Sm(){this.a=wk((_m(),$m))}
function qn(){this.a=wk((dn(),cn))}
function Bn(){this.a=wk((hn(),gn))}
function Gn(){this.a=wk((mn(),ln))}
function Tn(a){Rn(a,(fb(a.b),a.e))}
function jo(a){sm(a,(fb(a.a),!a.d))}
function Tb(a){return !a.d?a:Tb(a.d)}
function oi(a){return !a?null:a.ab()}
function rj(a){return a!=null?s(a):0}
function qd(a){return a==null?null:a}
function nd(a){return typeof a===up}
function o(a,b){return qd(a)===qd(b)}
function Lc(a){$wnd.clearTimeout(a)}
function Ci(a){a.a=_c(ke,vp,1,0,5,1)}
function ri(a){a.a=new Zi;a.b=new lj}
function ib(a){this.c=new Li;this.b=a}
function im(a){kb(a.b);R(a.c);$(a.a)}
function pb(a){J();ob(a);sb(a,2,true)}
function dk(a,b){bk(b,0,a,0,b.length)}
function fc(a,b){bc(a,b,false);eb(a.c)}
function Mk(a,b){a.value=b;return a}
function Hk(a,b){a.onBlur=b;return a}
function Ek(a,b){a.onClick=b;return a}
function Ik(a,b){a.onChange=b;return a}
function Gk(a,b){a.checked=b;return a}
function fi(a,b){a.a+=''+b;return a}
function Jo(a,b){Ei(dc(a.b),new op(b))}
function pk(a,b){for(var c in a){b(c)}}
function dd(a,b,c){return {l:a,m:b,h:c}}
function B(a,b,c){return u(a,c,2048,b)}
function ci(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function hk(a){return a.$H||(a.$H=++gk)}
function pd(a){return typeof a==='string'}
function Jk(a,b){a.onKeyDown=b;return a}
function rk(a,b){a.props['a']=b;return a}
function Fk(a){a.autoFocus=true;return a}
function Kh(a){if(a.k!=null){return}Th(a)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function P(){this.a=_c(ke,vp,1,100,5,1)}
function vc(a){this.g=a;qc(this);this.G()}
function Oj(a,b){Hj.call(this,a);this.a=b}
function Cn(a,b){this.a=a;this.b=b;Dn=this}
function Ti(){this.a=new Zi;this.b=new lj}
function lk(){lk=rh;ik=new p;kk=new p}
function Mc(){Bc!=0&&(Bc=0);Dc=-1}
function ec(a,b){nc(b.c,a);ld(b,9)&&b.t()}
function pj(a,b){while(a.Y()){_j(b,a.Z())}}
function A(a,b,c){u(a,new G(b),c,null)}
function qm(a){A((J(),J(),I),new Cm(a),Mp)}
function Un(a){A((J(),J(),I),new _n(a),Mp)}
function mo(a){A((J(),J(),I),new po(a),Mp)}
function Io(a){A((J(),J(),I),new Po(a),Mp)}
function So(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function wo(a){return Zh(S(a.e).a-S(a.a).a)}
function md(a){return typeof a==='boolean'}
function Fc(a,b,c){return a.apply(b,c);var d}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function _i(a,b){var c;c=a[Hp];c.call(a,b)}
function Oh(a){var b;b=Nh(a);Vh(a,b);return b}
function qc(a){a.j&&a.e!==Cp&&a.G();return a}
function Nk(a,b){a.onDoubleClick=b;return a}
function Di(a,b){a.a[a.a.length]=b;return true}
function oj(a,b,c){this.a=a;this.b=b;this.c=c}
function Fh(a,b,c,d){a.addEventListener(b,c,d)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function Rl(a,b){A((J(),J(),I),new Yl(a,b),Mp)}
function km(a,b){A((J(),J(),I),new Bm(a,b),Mp)}
function om(a,b){A((J(),J(),I),new ym(a,b),Mp)}
function pm(a,b){A((J(),J(),I),new xm(a,b),Mp)}
function rm(a,b){A((J(),J(),I),new wm(a,b),Mp)}
function to(a,b){A((J(),J(),I),new Ao(a,b),Mp)}
function Lo(a,b){A((J(),J(),I),new No(a,b),Mp)}
function vj(a,b){while(a.c<a.d){xj(a,b,a.c++)}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function Ch(a){if(!a){throw bh(new bi)}return a}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function zj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function Vc(){Vc=rh;var a;!Xc();a=new Yc;Uc=a}
function _h(){_h=rh;$h=_c(ge,vp,29,256,0,1)}
function Eh(){Eh=rh;Dh=$wnd.goog.global.document}
function Sl(a,b){var c;c=b.target;Tl(a,c.value)}
function Ij(a,b){var c;return Mj(a,(c=new Li,c))}
function Qh(a){var b;b=Nh(a);b.j=a;b.e=1;return b}
function wi(a){var b;b=a.a.Z();a.b=vi(a);return b}
function uo(a){ai(new zi(a.g),new gc(a));ri(a.g)}
function ro(a){R(a.d);R(a.e);R(a.a);R(a.b);$(a.c)}
function vo(a){return Ih(),0!=S(a.e).a?true:false}
function Qo(a){return o(Rp,a)||o(Sp,a)||o('',a)}
function hj(a,b){return !(a.a.get(b)===undefined)}
function bd(a){return Array.isArray(a)&&a.pb===vh}
function kd(a){return !Array.isArray(a)&&a.pb===vh}
function Pi(a){return new Oj(null,Oi(a,a.length))}
function Oi(a,b){return tj(b,a.length),new yj(a,b)}
function tl(a){return B((J(),J(),I),a.b,new zl(a))}
function ul(a){return Ih(),S(a.f.b).a>0?true:false}
function Bo(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function ok(){if(jk==256){ik=kk;kk=new p;jk=0}++jk}
function ql(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function Cl(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function gm(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function Sj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Sc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Hi(a,b){var c;c=a.a[b];ek(a.a,b);return c}
function Ji(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Em(a,b){var c;c=b.target;Lo(a.f,c.checked)}
function Tl(a,b){var c;c=a.g;if(b!=c){a.g=b;eb(a.b)}}
function sm(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function jm(a){return B((J(),J(),I),a.b,new vm(a))}
function Jm(a){return B((J(),J(),I),a.a,new Nm(a))}
function El(a){return B((J(),J(),I),a.a,new Il(a))}
function Ql(a){return B((J(),J(),I),a.a,new Wl(a))}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Vn(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function Gh(a,b,c,d){a.removeEventListener(b,c,d)}
function Kj(a,b){Gj(a);return new Oj(a,new Tj(b,a.a))}
function Lj(a,b){Gj(a);return new Oj(a,new Wj(b,a.a))}
function ti(a,b){if(b){return mi(a.a,b)}return false}
function hh(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function Fj(a){if(!a.b){Gj(a);a.c=true}else{Fj(a.b)}}
function Hj(a){if(!a){this.b=null;new Li}else{this.b=a}}
function yj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Qm(a,b,c){this.a=a;this.b=b;this.c=c;Rm=this}
function Hn(a,b,c){this.a=a;this.b=b;this.c=c;In=this}
function uj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Aj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Rn(a,b){A((J(),J(),I),new $n(a,b),75497472)}
function lm(a,b){Wo(a.n,b);A((J(),J(),I),new wm(a,b),Mp)}
function Si(a,b){return qd(a)===qd(b)||a!=null&&q(a,b)}
function ni(a,b){return b===a?'(this Map)':b==null?Ep:uh(b)}
function tc(a,b){var c;c=Lh(a.nb);return b==null?c:c+': '+b}
function Ph(a,b){var c;c=Nh(a);Vh(a,c);c.e=b?8:0;return c}
function Lk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function Sh(a){if(a.P()){return null}var b=a.j;return nh[b]}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function Pn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&Vn(a,b)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Ap)&&D((null,I))}
function mm(a,b){A((J(),J(),I),new wm(a,b),Mp);Wo(a.n,null)}
function $l(a,b){var c;if(S(a.c)){c=b.target;sm(a,c.value)}}
function ai(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function Rh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function Vi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Kc(a){Ec();$wnd.setTimeout(function(){throw a},0)}
function Ln(a){Fh((Eh(),$wnd.goog.global.window),Pp,a.d,false)}
function Mn(a){Gh((Eh(),$wnd.goog.global.window),Pp,a.d,false)}
function nm(a){return Ih(),To(a.n)==a.f.props['a']?true:false}
function th(a){function b(){}
;b.prototype=a||{};return new b}
function Kk(a){a.placeholder='What needs to be done?';return a}
function Nn(a,b){b.preventDefault();A((J(),J(),I),new ao(a),Mp)}
function cc(a){fb(a.c);return new Oj(null,new Aj(new zi(a.g),0))}
function kp(){ip();return cd(Zc(Pg,1),vp,31,0,[fp,hp,gp])}
function Wi(a,b){var c;return Ui(b,Vi(a,b==null?0:(c=s(b),c|0)))}
function ph(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function dn(){dn=rh;var a;cn=(a=sh(bn.prototype.mb,bn,[]),a)}
function hn(){hn=rh;var a;gn=(a=sh(fn.prototype.mb,fn,[]),a)}
function mn(){mn=rh;var a;ln=(a=sh(kn.prototype.mb,kn,[]),a)}
function Xm(){Xm=rh;var a;Wm=(a=sh(Vm.prototype.mb,Vm,[]),a)}
function _m(){_m=rh;var a;$m=(a=sh(Zm.prototype.mb,Zm,[]),a)}
function Mi(a){Ci(this);dk(this.a,li(a,_c(ke,vp,1,si(a.a),5,1)))}
function Mo(a){this.b=a;J();this.a=new oc(0,null,null,false,false)}
function $i(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Wj(a,b){uj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function mc(a){kc(a.g);!!a.e&&lc(a);Y(a.a);Y(a.c);kc(a.b);kc(a.f)}
function Ah(a){yh();Ch(a);if(ld(a,45)){return a}return new zh(a)}
function wj(a,b){if(a.c<a.d){xj(a,b,a.c++);return true}return false}
function uc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ic(a,b,c){var d;d=Gc();try{return Fc(a,b,c)}finally{Jc(d)}}
function bb(a,b){var c,d;Di(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Tj(a,b){uj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function mj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Jj(a){var b;Fj(a);b=0;while(a.a.eb(new $j)){b=dh(b,1)}return b}
function Mj(a,b){var c;Fj(a);c=new Zj;c.a=b;a.a.X(new ak(c));return c.a}
function Bj(a,b){!a.a?(a.a=new hi(a.d)):fi(a.a,a.b);fi(a.a,b);return a}
function qi(a,b){return pd(b)?b==null?Yi(a.a,null):kj(a.b,b):Yi(a.a,b)}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Jc(a){a&&Qc((Oc(),Nc));--Bc;if(a){if(Dc!=-1){Lc(Dc);Dc=-1}}}
function Ko(a){Ij(Kj(cc(a.b),new mp),new Ej(new Dj)).Q(new np(a.b))}
function so(a,b){var c;return u((J(),J(),I),new Bo(a,b),Mp,(c=null,c))}
function Nj(a,b){var c;c=Ij(a,new Ej(new Dj));return Ki(c,b.fb(c.a.length))}
function Hc(b){Ec();return function(){return Ic(b,this,arguments);var a}}
function Ac(){if(Date.now){return Date.now()}return (new Date).getTime()}
function an(a){$wnd.React.Component.call(this,a);this.a=new Fl(this,Um.a)}
function en(a){$wnd.React.Component.call(this,a);this.a=new Ul(this,sn.a)}
function xi(a){this.d=a;this.c=new mj(this.d.b);this.a=this.c;this.b=vi(this)}
function Cj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function yk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function _c(a,b,c,d,e,f){var g;g=ad(e,d);e!=10&&cd(Zc(a,f),b,c,e,g);return g}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Gi(a,b,c){for(;c<a.a.length;++c){if(Si(b,a.a[c])){return c}}return -1}
function nj(a){if(a.a.c!=a.c){return ij(a.a,a.b.value[0])}return a.b.value[1]}
function Ib(b){try{mb(b.b.a)}catch(a){a=ah(a);if(!ld(a,4))throw bh(a)}}
function Kn(a,b){a.f=b;o(b,S(a.a))&&Vn(a,b);On(b);A((J(),J(),I),new ao(a),Mp)}
function Ro(a,b){return (ip(),gp)==a||(fp==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function pi(a,b,c){return pd(b)?b==null?Xi(a.a,null,c):jj(a.b,b,c):Xi(a.a,b,c)}
function fk(a,b){return $c(b)!=10&&cd(r(b),b.ob,b.__elementTypeId$,$c(b),a),a}
function Jl(a){var b;b=ei((fb(a.b),a.g));if(b.length>0){Go(a.f,b);Tl(a,'')}}
function Ei(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Ob(){var a;this.a=_c(wd,vp,44,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Jn(){this.a=Ah(new pp);this.b=Ah((ep(),dp));this.c=Ah(new rp(this.b))}
function jn(a){$wnd.React.Component.call(this,a);this.a=new tm(this,Dn.a,Dn.b)}
function jc(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new pc(a)),67108864,null)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function V(a){if(a.b){if(ld(a.b,7)){throw bh(a.b)}else{throw bh(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=ah(a);if(ld(a,4)){J()}else throw bh(a)}}}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function Pc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Tc(b,c)}while(a.a);a.a=c}}
function Qc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Tc(b,c)}while(a.b);a.b=c}}
function go(a,b){var c;if(ld(b,51)){c=b;return a.c.d==c.c.d}else{return false}}
function Ii(a,b){var c;c=Gi(a,b,0);if(c==-1){return false}ek(a.a,c);return true}
function An(a,b){sk(a.a,(b?Zh(b.c.d):null)+(''+(Kh(cg),cg.k)));rk(a.a,b);return a.a}
function Nh(a){var b;b=new Mh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Uo(a){var b;return b=S(a.b),Ij(Kj(cc(a.i),new qp(b)),new Ej(new Dj))}
function dc(a){return fb(a.c),Ij(new Oj(null,new Aj(new zi(a.g),0)),new Ej(new Dj))}
function $c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===tp||typeof a==='function')&&!(a.pb===vh)}
function vk(a){var b;return tk($wnd.React.StrictMode,null,null,(b={},b[Ip]=a,b))}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Li);Di(a.b,b)}}}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new Li);a.c=c.c}b.d=true;Di(a.c,b)}
function Vh(a,b){var c;if(!a){return}b.j=a;var d=Sh(b);if(!d){nh[a]=[b];return}d.nb=b}
function sh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function tk(a,b,c,d){var e;e=uk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function wk(a){var b;b=uk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Qi(a){var b,c,d;d=0;for(c=new xi(a.a);c.b;){b=wi(c);d=d+(b?s(b):0);d=d|0}return d}
function ob(a){var b,c;for(c=new Ni(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function jh(){kh();var a=ih;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Kl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Xl(a),Mp)}}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Bp:0)|(0!=(b&229376)?0:98304)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:xp)|(0==(c&6291456)?!a?Ap:Bp:0)|0|0|0)}
function mh(a,b){typeof window===tp&&typeof window['$gwt']===tp&&(window['$gwt'][a]=b)}
function Ym(a){$wnd.React.Component.call(this,a);this.a=new vl(this,Rm.a,Rm.b,Rm.c)}
function nn(a){$wnd.React.Component.call(this,a);this.a=new Km(this,In.a,In.b,In.c)}
function vi(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new $i(a.d.a);return a.a.Y()}
function ah(a){var b;if(ld(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new zc(a);Wc(b)}return b}
function eh(a){var b;b=a.h;if(b==0){return a.l+a.m*Bp}if(b==1048575){return a.l+a.m*Bp-Fp}return a}
function kj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{_i(a.a,b);--a.b}return c}
function qo(a,b,c){var d;d=new no(b,c);fo(d,a,new hc(a,d));pi(a.g,Zh(d.c.d),d);eb(a.c);return d}
function ki(a,b){var c,d;for(d=new xi(b.a);d.b;){c=wi(d);if(!ti(a,c)){return false}}return true}
function Ui(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Si(a,c._())){return c}}return null}
function gh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Fp;d=1048575}c=rd(e/Bp);b=rd(e-c*Bp);return dd(b,c,d)}
function Vo(a){var b;b=S(a.g.a);o(Rp,b)||o(Sp,b)||o('',b)?Rn(a.g,b):Qo(Sn(a.g))?Un(a.g):Rn(a.g,'')}
function bc(a,b,c){var d;d=qi(a.g,b?Zh(b.c.d):null);if(null!=d){nc(b.c,a);c&&!!b&&jc(b.c);eb(a.c)}}
function Wo(a,b){var c;c=a.e;if(!(b==c||!!b&&go(b,c))){!!c&&nc(c.c,a);a.e=b;!!b&&fo(b,a,new Zo(a));eb(a.d)}}
function jj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function cd(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=vh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function tj(a,b){if(0>a||a>b){throw bh(new Hh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function ip(){ip=rh;fp=new jp('ACTIVE',0);hp=new jp('COMPLETED',1);gp=new jp('ALL',2)}
function bm(a,b,c){27==c.which?A((J(),J(),I),new zm(a,b),Mp):13==c.which&&A((J(),J(),I),new xm(a,b),Mp)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function ml(){if(!ll){ll=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(sh(nl.prototype.J,nl,[]))}}
function zc(a){xc();qc(this);this.e=a;rc(this,a);this.g=a==null?Ep:uh(a);this.a='';this.b=a;this.a=''}
function Mh(){this.g=Jh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Zh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(_h(),$h)[b];!c&&(c=$h[b]=new Yh(a));return c}return new Yh(a)}
function uh(a){var b;if(Array.isArray(a)&&a.pb===vh){return Lh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function nk(a){lk();var b,c,d;c=':'+a;d=kk[c];if(d!=null){return rd(d)}d=ik[c];b=d==null?mk(a):rd(d);ok();kk[c]=b;return b}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function cb(a,b){var c,d;d=a.c;Ii(d,b);!!a.b&&xp!=(a.b.c&yp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function r(a){return pd(a)?ne:nd(a)?be:md(a)?_d:kd(a)?a.nb:bd(a)?a.nb:a.nb||Array.isArray(a)&&Zc(Sd,1)||Sd}
function s(a){return pd(a)?nk(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.q():bd(a)?hk(a):!!a&&!!a.hashCode?a.hashCode():hk(a)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&xp)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function dm(a){var b;b=S(a.c);if(!a.j&&b){a.j=true;rm(a,a.f.props['a']);a.i.focus();a.i.select()}else a.j&&!b&&(a.j=false)}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=Hi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Ri(a){var b,c,d;d=1;for(c=new Ni(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Ki(a,b){var c,d;d=a.a.length;b.length<d&&(b=fk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Uh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function kl(){il();return cd(Zc(df,1),vp,6,0,[Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl])}
function Gj(a){if(a.b){Gj(a.b)}else if(a.c){throw bh(new Xh("Stream already terminated, can't be modified or used"))}}
function dh(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<Fp){return c}}return eh(ed(nd(a)?gh(a):a,nd(b)?gh(b):b))}
function cm(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Oo(b,c),Mp);Wo(a.n,null);sm(a,c)}else{to(a.k,b)}}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(xp==(b&yp)?0:524288)|(0==(b&6291456)?xp==(b&yp)?Bp:Ap:0)|0|268435456|0)}
function Gc(){var a;if(Bc!=0){a=Ac();if(a-Cc>2000){Cc=a;Dc=$wnd.setTimeout(Mc,10)}}if(Bc++==0){Pc((Oc(),Nc));return true}return false}
function Xc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Fl(a,b){var c;this.e=b;this.c=a;J();c=++Dl;this.b=new oc(c,null,new Gl(this),false,false);this.a=new vb(null,new Hl(this),Lp)}
function oc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ti:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function lc(a){var b,c,d;for(c=new Ni(new Mi(new ui(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();ld(d,9)&&d.u()||b.ab().v()}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ni(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ni(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function q(a,b){return pd(a)?o(a,b):nd(a)?qd(a)===qd(b):md(a)?qd(a)===qd(b):kd(a)?a.o(b):bd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.ob){return !!a.ob[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function Bk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function ei(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function li(a,b){var c,d,e,f;f=si(a.a);b.length<f&&(b=fk(new Array(f),b));e=b;d=new xi(a.a);for(c=0;c<f;++c){e[c]=wi(d)}b.length>f&&(b[f]=null);return b}
function ad(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=ah(a);if(ld(a,4)){e=a;throw bh(e)}else throw bh(a)}finally{D(b)}}
function Km(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.c=a;J();e=++Im;this.b=new oc(e,null,new Lm(this),false,false);this.a=new vb(null,new Mm(this),Lp)}
function Ul(a,b){var c,d,e;this.f=b;this.d=a;J();c=++Ol;this.c=new oc(c,null,new Vl(this),false,false);this.b=(e=new ib((d=null,d)),e);this.a=new vb(null,new Zl(this),Lp)}
function no(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++co;this.c=new oc(c,null,new oo(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ni(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function lh(b,c,d,e){kh();var f=ih;$moduleName=c;$moduleBase=d;_g=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{sp(g)()}catch(a){b(c,a)}}else{sp(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);xp==(d&yp)&&lb(this.f)}
function uk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function ej(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return fj()}}
function Bl(a){var b,c;a.d=0;ml();c=(b=S(a.e.e).a,xk('span',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['todo-count'])),[xk('strong',null,[b]),' item'+(b==1?'':'s')+' left']));return c}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=ah(a);if(ld(a,4)){f=a;throw bh(f)}else throw bh(a)}finally{D(b)}}
function oh(){nh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Tc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Sc(c,g)):g[0].qb()}catch(a){a=ah(a);if(ld(a,4)){d=a;Ec();Kc(ld(d,35)?d.H():d)}else throw bh(a)}}return c}
function Ml(a){var b;a.e=0;ml();b=xk(Np,Fk(Ik(Jk(Mk(Kk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['new-todo']))),(fb(a.b),a.g)),sh(on.prototype.kb,on,[a])),sh(pn.prototype.jb,pn,[a]))),null);return b}
function yc(a){var b;if(a.c==null){b=qd(a.b)===qd(wc)?null:a.b;a.d=b==null?Ep:od(b)?b==null?null:b.name:pd(b)?'String':Lh(r(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(qd(e)===qd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=ah(a);if(ld(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw bh(c)}else throw bh(a)}}
function bk(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Xi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ui(b,e);if(f){return f.bb(c)}}e[e.length]=new Bi(b,c);++a.b;return null}
function vl(a,b,c,d){var e;this.f=b;this.g=c;this.i=d;this.d=a;J();e=++rl;this.c=new oc(e,null,new wl(this),false,false);this.a=new W(new xl(this),null,null,136478720);this.b=new vb(null,new yl(this),Lp)}
function mk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ci(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=ah(a);if(ld(a,4)){J()}else throw bh(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=_c(ke,vp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Bh(a,b){var c;c=qd(a)!==qd(xh);if(c&&qd(a)!==qd(b)){throw bh(new Xh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}return b}
function ub(a,b,c,d){this.b=new Li;this.f=new Jb(new yb(this),d&6520832|262144|xp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Ap)&&D((null,I)))}
function wh(){var a;a=new Jn;new Qm(new xo,a.a.I(),a.c.I());new Cn(new xo,(a.a.I(),a.c.I()));new Hn(new xo,a.a.I(),a.c.I());new rn(a.a.I());new Tm(new xo);$wnd.ReactDOM.render(vk([(new Gn).a]),(Eh(),Dh).getElementById('app'),null)}
function Yi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Si(b,e._())){if(d.length==1){d.length=0;_i(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function qh(a,b,c){var d=nh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=nh[b]),th(h));_.ob=c;!b&&(_.pb=vh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Th(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Uh('.',[c,Uh('$',d)]);a.b=Uh('.',[c,Uh('.',d)]);a.i=d[d.length-1]}
function On(a){var b;if(0==a.length){b=(Eh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Dh.title,b)}else{(Eh(),$wnd.goog.global.window).location.hash=a}}
function mi(a,b){var c,d,e;c=b._();e=b.ab();d=pd(c)?c==null?oi(Wi(a.a,null)):ij(a.b,c):oi(Wi(a.a,c));if(!(qd(e)===qd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Wi(a.a,null):hj(a.b,c):!!Wi(a.a,c))){return false}return true}
function xk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;qk(b,sh(Ak.prototype.hb,Ak,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ip]=c[0],undefined):(d[Ip]=c,undefined));return tk(a,e,f,d)}
function tm(a,b,c){var d,e,f;this.k=b;this.n=c;this.f=a;J();d=++hm;this.e=new oc(d,null,new um(this),false,false);this.a=(f=new ib((e=null,e)),f);this.c=new W(new Am(this),null,null,136478720);this.b=new vb(null,new Dm(this),Lp);rm(this,this.f.props['a'])}
function Xo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new oc(0,null,new Yo(this),false,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new $o(this),null,null,Qp);this.c=new W(new _o(this),null,null,Qp);this.a=new vb(new ap(this),null,681574400);D((null,I))}
function xo(){var a;this.g=new Ti;J();this.f=new oc(0,new zo(this),new yo(this),false,false);this.c=(a=new ib(null),a);this.d=new W(new Co(this),null,null,Qp);this.e=new W(new Do(this),null,null,Qp);this.a=new W(new Eo(this),null,null,Qp);this.b=new W(new Fo(this),null,null,Qp)}
function Wn(){var a,b,c;this.d=new bp(this);this.f=this.e=(c=(Eh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new oc(0,null,new Xn(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new bo,new Yn(this),new Zn(this),35651584)}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ni(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=ah(a);if(!ld(a,4))throw bh(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function rc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function dj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}Ei(a.b,new Ab(a));a.b.a=_c(ke,vp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Gm(a){var b;a.d=0;ml();b=xk('div',null,[xk('div',null,[xk(Op,Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[Op])),[xk('h1',null,['todos']),(new qn).a]),S(a.e.d)?xk('section',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[Op])),[xk(Np,Ik(Lk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['toggle-all'])),(il(),Pk)),sh(En.prototype.jb,En,[a])),null),xk('ul',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['todo-list'])),Nj(Lj(S(a.g.c).W(),new Fn),new zk))]):null,S(a.e.d)?(new Pm).a:null])]);return b}
function il(){il=rh;Ok=new jl(Jp,0);Pk=new jl('checkbox',1);Qk=new jl('color',2);Rk=new jl('date',3);Sk=new jl('datetime',4);Tk=new jl('email',5);Uk=new jl('file',6);Vk=new jl('hidden',7);Wk=new jl('image',8);Xk=new jl('month',9);Yk=new jl(up,10);Zk=new jl('password',11);$k=new jl('radio',12);_k=new jl('range',13);al=new jl('reset',14);bl=new jl('search',15);cl=new jl('submit',16);dl=new jl('tel',17);el=new jl('text',18);fl=new jl('time',19);gl=new jl('url',20);hl=new jl('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Fi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ji(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Fi(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Hi(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Li)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&xp!=(k.b.c&yp)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function pl(a){var b,c;a.e=0;ml();c=(b=S(a.i.b),xk('footer',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['footer'])),[(new Sm).a,xk('ul',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['filters'])),[xk('li',null,[xk('a',Dk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[(ip(),gp)==b?Kp:null])),'#'),['All'])]),xk('li',null,[xk('a',Dk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[fp==b?Kp:null])),'#active'),['Active'])]),xk('li',null,[xk('a',Dk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[hp==b?Kp:null])),'#completed'),['Completed'])])]),S(a.a)?xk(Jp,Ek(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['clear-completed'])),sh(Om.prototype.lb,Om,[a])),['Clear Completed']):null]));return c}
function fm(a){var b,c,d,e;a.g=0;ml();b=a.f.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.f.props['a'],e=(fb(d.a),d.d),xk('li',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[xk('div',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['view'])),[xk(Np,Ik(Gk(Lk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['toggle'])),(il(),Pk)),e),sh(un.prototype.jb,un,[d])),null),xk('label',Nk(new $wnd.Object,sh(vn.prototype.lb,vn,[a,d])),[(fb(d.b),d.e)]),xk(Jp,Ek(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['destroy'])),sh(wn.prototype.lb,wn,[a,d])),null)]),xk(Np,Jk(Ik(Hk(Mk(Bk(Ck(new $wnd.Object,sh(xn.prototype.w,xn,[a])),cd(Zc(ne,1),vp,2,6,['edit'])),(fb(a.a),a.d)),sh(yn.prototype.ib,yn,[a,d])),sh(tn.prototype.jb,tn,[a])),sh(zn.prototype.kb,zn,[a,d])),null)]));return c}
function fj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Hp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!dj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Hp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var tp='object',up='number',vp={3:1},wp={9:1},xp=1048576,yp=1835008,zp={5:1},Ap=2097152,Bp=4194304,Cp='__noinit__',Dp={3:1,10:1,7:1,4:1},Ep='null',Fp=17592186044416,Gp={41:1},Hp='delete',Ip='children',Jp='button',Kp='selected',Lp=1411518464,Mp=142606336,Np='input',Op='header',Pp='hashchange',Qp=136314880,Rp='active',Sp='completed';var _,nh,ih,_g=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;oh();qh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=Up;_.r=function(){var a;return Lh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var fd,gd,hd;qh(56,1,{},Mh);_.K=function(a){var b;b=new Mh;b.e=4;a>1?(b.c=Rh(this,a-1)):(b.c=this);return b};_.L=function(){Kh(this);return this.b};_.M=function(){return Lh(this)};_.N=function(){Kh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Kh(this),this.k)};_.e=0;_.g=0;var Jh=1;var ke=Oh(1);var ae=Oh(56);qh(83,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var vd=Oh(83);qh(36,1,{},G);_.s=function(){return this.a.v(),null};var td=Oh(36);qh(84,1,{},H);var ud=Oh(84);var I;qh(44,1,{44:1},P);_.b=0;_.c=false;_.d=0;var wd=Oh(44);qh(231,1,wp);_.r=function(){var a;return Lh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var zd=Oh(231);qh(18,231,wp,W);_.t=function(){R(this)};_.u=Tp;_.a=false;_.d=0;_.k=false;var yd=Oh(18);qh(126,1,{},X);_.s=function(){return T(this.a)};var xd=Oh(126);qh(16,231,{9:1,16:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Bd=Oh(16);qh(125,1,zp,jb);_.v=function(){ab(this.a)};var Ad=Oh(125);qh(17,231,{9:1,17:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Gd=Oh(17);qh(138,1,{},xb);_.v=function(){Q(this.a)};var Cd=Oh(138);qh(139,1,zp,yb);_.v=function(){mb(this.a)};var Dd=Oh(139);qh(140,1,zp,zb);_.v=function(){pb(this.a)};var Ed=Oh(140);qh(141,1,{},Ab);_.w=function(a){nb(this.a,a)};var Fd=Oh(141);qh(102,1,{},Db);_.a=0;_.b=0;_.c=0;var Hd=Oh(102);qh(167,1,wp,Fb);_.t=function(){Eb(this)};_.u=Tp;_.a=false;var Id=Oh(167);qh(67,231,{9:1,67:1},Jb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Kd=Oh(67);qh(101,1,{},Ob);var Jd=Oh(101);qh(142,1,{},$b);_.r=function(){var a;return Kh(Ld),Ld.k+'@'+(a=hk(this)>>>0,a.toString(16))};_.a=0;var Pb;var Ld=Oh(142);qh(114,1,{});var Od=Oh(114);qh(107,1,{},gc);_.w=function(a){ec(this.a,a)};var Md=Oh(107);qh(108,1,zp,hc);_.v=function(){fc(this.a,this.b)};var Nd=Oh(108);qh(15,1,wp,oc);_.t=function(){jc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Kh(Qd),Qd.k+'@'+(a=hk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Qd=Oh(15);qh(124,1,zp,pc);_.v=function(){mc(this.a)};var Pd=Oh(124);qh(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=Zp;_.C=function(){return Nj(Lj(Pi((this.i==null&&(this.i=_c(pe,vp,4,0,0,1)),this.i)),new ii),new Rj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){sc(this,uc(this.A(tc(this,this.g))));Wc(this)};_.r=function(){return tc(this,this.F())};_.e=Cp;_.j=true;var pe=Oh(4);qh(10,4,{3:1,10:1,4:1});var de=Oh(10);qh(7,10,Dp);var le=Oh(7);qh(57,7,Dp);var he=Oh(57);qh(78,57,Dp);var Ud=Oh(78);qh(35,78,{35:1,3:1,10:1,7:1,4:1},zc);_.F=function(){yc(this);return this.c};_.H=function(){return qd(this.b)===qd(wc)?null:this.b};var wc;var Rd=Oh(35);var Sd=Oh(0);qh(214,1,{});var Td=Oh(214);var Bc=0,Cc=0,Dc=-1;qh(92,214,{},Rc);var Nc;var Vd=Oh(92);var Uc;qh(225,1,{});var Xd=Oh(225);qh(79,225,{},Yc);var Wd=Oh(79);qh(45,1,{45:1},zh);_.I=function(){var a;a=this.a;if(qd(a)===qd(xh)){a=this.a;if(qd(a)===qd(xh)){a=this.b.I();this.a=Bh(this.a,a);this.b=null}}return a};var xh;var Yd=Oh(45);var Dh;qh(76,1,{73:1});_.r=Tp;var Zd=Oh(76);qh(80,7,Dp);var fe=Oh(80);qh(143,80,Dp,Hh);var $d=Oh(143);fd={3:1,74:1,28:1};var _d=Oh(74);qh(42,1,{3:1,42:1});var je=Oh(42);gd={3:1,28:1,42:1};var be=Oh(224);qh(30,1,{3:1,28:1,30:1});_.o=function(a){return this===a};_.q=Up;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ce=Oh(30);qh(59,7,Dp,Xh);var ee=Oh(59);qh(29,42,{3:1,28:1,29:1,42:1},Yh);_.o=function(a){return ld(a,29)&&a.a==this.a};_.q=Tp;_.r=function(){return ''+this.a};_.a=0;var ge=Oh(29);var $h;qh(288,1,{});qh(81,57,Dp,bi);_.A=function(a){return new TypeError(a)};var ie=Oh(81);hd={3:1,73:1,28:1,2:1};var ne=Oh(2);qh(77,76,{73:1},hi);var me=Oh(77);qh(292,1,{});qh(71,1,{},ii);_.S=function(a){return a.e};var oe=Oh(71);qh(60,7,Dp,ji);var qe=Oh(60);qh(226,1,{40:1});_.Q=Yp;_.V=function(){return new Aj(this,0)};_.W=function(){return new Oj(null,this.V())};_.T=function(a){throw bh(new ji('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Cj('[',']');for(b=this.R();b.Y();){a=b.Z();Bj(c,a===this?'(this Collection)':a==null?Ep:uh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var re=Oh(226);qh(229,1,{212:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ld(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new xi((new ui(d)).a);c.b;){b=wi(c);if(!mi(this,b)){return false}}return true};_.q=function(){return Qi(new ui(this))};_.r=function(){var a,b,c;c=new Cj('{','}');for(b=new xi((new ui(this)).a);b.b;){a=wi(b);Bj(c,ni(this,a._())+'='+ni(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ce=Oh(229);qh(100,229,{212:1});var ue=Oh(100);qh(228,226,{40:1,235:1});_.V=function(){return new Aj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ld(a,21)){return false}b=a;if(si(b.a)!=this.U()){return false}return ki(this,b)};_.q=function(){return Qi(this)};var De=Oh(228);qh(21,228,{21:1,40:1,235:1},ui);_.R=function(){return new xi(this.a)};_.U=Wp;var te=Oh(21);qh(22,1,{},xi);_.X=Vp;_.Z=function(){return wi(this)};_.Y=Xp;_.b=false;var se=Oh(22);qh(227,226,{40:1,232:1});_.V=function(){return new Aj(this,16)};_.$=function(a,b){throw bh(new ji('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,13)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Ni(f);for(c=new Ni(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Ri(this)};_.R=function(){return new yi(this)};var we=Oh(227);qh(91,1,{},yi);_.X=Vp;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Fi(this.b,this.a++)};_.a=0;var ve=Oh(91);qh(43,226,{40:1},zi);_.R=function(){var a;a=new xi((new ui(this.a)).a);return new Ai(a)};_.U=Wp;var ye=Oh(43);qh(95,1,{},Ai);_.X=Vp;_.Y=function(){return this.a.b};_.Z=function(){var a;a=wi(this.a);return a.ab()};var xe=Oh(95);qh(93,1,Gp);_.o=function(a){var b;if(!ld(a,41)){return false}b=a;return Si(this.a,b._())&&Si(this.b,b.ab())};_._=Tp;_.ab=Xp;_.q=function(){return rj(this.a)^rj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ze=Oh(93);qh(94,93,Gp,Bi);var Ae=Oh(94);qh(230,1,Gp);_.o=function(a){var b;if(!ld(a,41)){return false}b=a;return Si(this.b.value[0],b._())&&Si(nj(this),b.ab())};_.q=function(){return rj(this.b.value[0])^rj(nj(this))};_.r=function(){return this.b.value[0]+'='+nj(this)};var Be=Oh(230);qh(13,227,{3:1,13:1,40:1,232:1},Li,Mi);_.$=function(a,b){ck(this.a,a,b)};_.T=function(a){return Di(this,a)};_.Q=function(a){Ei(this,a)};_.R=function(){return new Ni(this)};_.U=function(){return this.a.length};var Fe=Oh(13);qh(14,1,{},Ni);_.X=Vp;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ee=Oh(14);qh(37,100,{3:1,37:1,212:1},Ti);var Ge=Oh(37);qh(63,1,{},Zi);_.Q=Yp;_.R=function(){return new $i(this)};_.b=0;var Ie=Oh(63);qh(64,1,{},$i);_.X=Vp;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var He=Oh(64);var bj;qh(61,1,{},lj);_.Q=Yp;_.R=function(){return new mj(this)};_.b=0;_.c=0;var Le=Oh(61);qh(62,1,{},mj);_.X=Vp;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new oj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Je=Oh(62);qh(113,230,Gp,oj);_._=function(){return this.b.value[0]};_.ab=function(){return nj(this)};_.bb=function(a){return jj(this.a,this.b.value[0],a)};_.c=0;var Ke=Oh(113);qh(128,1,{});_.X=$p;_.cb=function(){return this.d};_.db=Zp;_.d=0;_.e=0;var Pe=Oh(128);qh(65,128,{});var Me=Oh(65);qh(96,1,{});_.X=$p;_.cb=Xp;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Oe=Oh(96);qh(97,96,{},yj);_.X=function(a){vj(this,a)};_.eb=function(a){return wj(this,a)};var Ne=Oh(97);qh(19,1,{},Aj);_.cb=Tp;_.db=function(){zj(this);return this.c};_.X=function(a){zj(this);this.d.X(a)};_.eb=function(a){zj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Qe=Oh(19);qh(58,1,{},Cj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Re=Oh(58);qh(34,1,{},Dj);_.S=function(a){return a};var Se=Oh(34);qh(38,1,{},Ej);var Te=Oh(38);qh(127,1,{});_.c=false;var bf=Oh(127);qh(23,127,{},Oj);var af=Oh(23);qh(72,1,{},Rj);_.fb=function(a){return _c(ke,vp,1,a,5,1)};var Ue=Oh(72);qh(130,65,{},Tj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Uj(this,a)));return this.b};_.b=false;var We=Oh(130);qh(133,1,{},Uj);_.w=function(a){Sj(this.a,this.b,a)};var Ve=Oh(133);qh(129,65,{},Wj);_.eb=function(a){return this.b.eb(new Xj(this,a))};var Ye=Oh(129);qh(132,1,{},Xj);_.w=function(a){Vj(this.a,this.b,a)};var Xe=Oh(132);qh(131,1,{},Zj);_.w=function(a){Yj(this,a)};var Ze=Oh(131);qh(134,1,{},$j);_.w=function(a){};var $e=Oh(134);qh(135,1,{},ak);_.w=function(a){_j(this,a)};var _e=Oh(135);qh(290,1,{});qh(287,1,{});var gk=0;var ik,jk=0,kk;qh(904,1,{});qh(925,1,{});qh(168,1,{},zk);_.fb=function(a){return new Array(a)};var cf=Oh(168);qh(255,$wnd.Function,{},Ak);_.hb=function(a){yk(this.a,this.b,a)};qh(6,30,{3:1,28:1,30:1,6:1},jl);var Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl;var df=Ph(6,kl);var ll;qh(254,$wnd.Function,{},nl);_.J=function(a){return Eb(ll),ll=null,null};qh(184,1,{});var Of=Oh(184);qh(185,184,{});_.e=0;var Sf=Oh(185);qh(186,185,wp,vl);_.t=_p;_.u=aq;_.r=function(){var a;return Kh(nf),nf.k+'@'+(a=hk(this)>>>0,a.toString(16))};var rl=0;var nf=Oh(186);qh(187,1,zp,wl);_.v=function(){sl(this.a)};var ef=Oh(187);qh(188,1,{},xl);_.s=function(){return ul(this.a)};var ff=Oh(188);qh(189,1,{},yl);_.v=function(){ql(this.a)};var gf=Oh(189);qh(190,1,{},zl);_.s=function(){return pl(this.a)};var hf=Oh(190);qh(205,1,{});var Nf=Oh(205);qh(206,205,{});_.d=0;var Rf=Oh(206);qh(207,206,wp,Fl);_.t=bq;_.u=cq;_.r=function(){var a;return Kh(mf),mf.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Dl=0;var mf=Oh(207);qh(208,1,zp,Gl);_.v=dq;var jf=Oh(208);qh(209,1,{},Hl);_.v=function(){Cl(this.a)};var kf=Oh(209);qh(210,1,{},Il);_.s=function(){return Bl(this.a)};var lf=Oh(210);qh(176,1,{});_.g='';var _f=Oh(176);qh(177,176,{});_.e=0;var Uf=Oh(177);qh(178,177,wp,Ul);_.t=_p;_.u=aq;_.r=function(){var a;return Kh(tf),tf.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Ol=0;var tf=Oh(178);qh(179,1,zp,Vl);_.v=function(){Pl(this.a)};var of=Oh(179);qh(181,1,{},Wl);_.s=function(){return Ml(this.a)};var pf=Oh(181);qh(182,1,zp,Xl);_.v=function(){Jl(this.a)};var qf=Oh(182);qh(183,1,zp,Yl);_.v=function(){Sl(this.a,this.b)};var rf=Oh(183);qh(180,1,{},Zl);_.v=function(){ql(this.a)};var sf=Oh(180);qh(172,1,{});_.j=false;var cg=Oh(172);qh(192,172,{});_.g=0;var Wf=Oh(192);qh(193,192,wp,tm);_.t=function(){jc(this.e)};_.u=function(){return this.e.i<0};_.r=function(){var a;return Kh(Ef),Ef.k+'@'+(a=hk(this)>>>0,a.toString(16))};var hm=0;var Ef=Oh(193);qh(194,1,zp,um);_.v=function(){im(this.a)};var uf=Oh(194);qh(197,1,{},vm);_.s=function(){return fm(this.a)};var vf=Oh(197);qh(49,1,zp,wm);_.v=function(){sm(this.a,Sn(this.b))};var wf=Oh(49);qh(68,1,zp,xm);_.v=function(){cm(this.a,this.b)};var xf=Oh(68);qh(198,1,zp,ym);_.v=function(){lm(this.a,this.b)};var yf=Oh(198);qh(199,1,zp,zm);_.v=function(){mm(this.a,this.b)};var zf=Oh(199);qh(195,1,{},Am);_.s=function(){return nm(this.a)};var Af=Oh(195);qh(200,1,zp,Bm);_.v=function(){$l(this.a,this.b)};var Bf=Oh(200);qh(201,1,zp,Cm);_.v=function(){dm(this.a)};var Cf=Oh(201);qh(196,1,{},Dm);_.v=function(){gm(this.a)};var Df=Oh(196);qh(154,1,{});var gg=Oh(154);qh(155,154,{});_.d=0;var Yf=Oh(155);qh(156,155,wp,Km);_.t=bq;_.u=cq;_.r=function(){var a;return Kh(If),If.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Im=0;var If=Oh(156);qh(157,1,zp,Lm);_.v=dq;var Ff=Oh(157);qh(158,1,{},Mm);_.v=function(){Cl(this.a)};var Gf=Oh(158);qh(159,1,{},Nm);_.s=function(){return Gm(this.a)};var Hf=Oh(159);qh(260,$wnd.Function,{},Om);_.lb=function(a){Io(this.a.g)};qh(170,1,{},Pm);var Jf=Oh(170);qh(86,1,{},Qm);var Kf=Oh(86);var Rm;qh(191,1,{},Sm);var Lf=Oh(191);qh(90,1,{},Tm);var Mf=Oh(90);var Um;qh(261,$wnd.Function,{},Vm);_.mb=function(a){return new Ym(a)};var Wm;qh(174,$wnd.React.Component,{},Ym);ph(nh[1],_);_.componentWillUnmount=function(){ol(this.a)};_.render=function(){return tl(this.a)};_.shouldComponentUpdate=eq;var Pf=Oh(174);qh(271,$wnd.Function,{},Zm);_.mb=function(a){return new an(a)};var $m;qh(202,$wnd.React.Component,{},an);ph(nh[1],_);_.componentWillUnmount=function(){Al(this.a)};_.render=function(){return El(this.a)};_.shouldComponentUpdate=fq;var Qf=Oh(202);qh(259,$wnd.Function,{},bn);_.mb=function(a){return new en(a)};var cn;qh(173,$wnd.React.Component,{},en);ph(nh[1],_);_.componentWillUnmount=function(){ol(this.a)};_.render=function(){return Ql(this.a)};_.shouldComponentUpdate=eq;var Tf=Oh(173);qh(262,$wnd.Function,{},fn);_.mb=function(a){return new jn(a)};var gn;qh(175,$wnd.React.Component,{},jn);ph(nh[1],_);_.componentDidUpdate=function(a){qm(this.a)};_.componentWillUnmount=function(){em(this.a)};_.render=function(){return jm(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.g};var Vf=Oh(175);qh(253,$wnd.Function,{},kn);_.mb=function(a){return new nn(a)};var ln;qh(98,$wnd.React.Component,{},nn);ph(nh[1],_);_.componentWillUnmount=function(){Al(this.a)};_.render=function(){return Jm(this.a)};_.shouldComponentUpdate=fq;var Xf=Oh(98);qh(257,$wnd.Function,{},on);_.kb=function(a){Kl(this.a,a)};qh(258,$wnd.Function,{},pn);_.jb=function(a){Rl(this.a,a)};qh(169,1,{},qn);var Zf=Oh(169);qh(89,1,{},rn);var $f=Oh(89);var sn;qh(269,$wnd.Function,{},tn);_.jb=function(a){km(this.a,a)};qh(263,$wnd.Function,{},un);_.jb=function(a){mo(this.a)};qh(265,$wnd.Function,{},vn);_.lb=function(a){om(this.a,this.b)};qh(266,$wnd.Function,{},wn);_.lb=function(a){_l(this.a,this.b)};qh(267,$wnd.Function,{},xn);_.w=function(a){am(this.a,a)};qh(268,$wnd.Function,{},yn);_.ib=function(a){pm(this.a,this.b)};qh(270,$wnd.Function,{},zn);_.kb=function(a){bm(this.a,this.b,a)};qh(171,1,{},Bn);var ag=Oh(171);qh(87,1,{},Cn);var bg=Oh(87);var Dn;qh(252,$wnd.Function,{},En);_.jb=function(a){Em(this.a,a)};qh(99,1,{},Fn);_.S=function(a){return An(new Bn,a)};var dg=Oh(99);qh(70,1,{},Gn);var eg=Oh(70);qh(88,1,{},Hn);var fg=Oh(88);var In;qh(85,1,{},Jn);var hg=Oh(85);qh(48,1,{48:1});var Og=Oh(48);qh(160,48,{9:1,48:1},Wn);_.t=_p;_.u=aq;_.r=function(){var a;return Kh(pg),pg.k+'@'+(a=hk(this)>>>0,a.toString(16))};var pg=Oh(160);qh(161,1,zp,Xn);_.v=function(){Qn(this.a)};var ig=Oh(161);qh(163,1,{},Yn);_.v=function(){Ln(this.a)};var jg=Oh(163);qh(164,1,{},Zn);_.v=function(){Mn(this.a)};var kg=Oh(164);qh(165,1,zp,$n);_.v=function(){Kn(this.a,this.b)};var lg=Oh(165);qh(166,1,zp,_n);_.v=function(){Tn(this.a)};var mg=Oh(166);qh(66,1,zp,ao);_.v=function(){Pn(this.a)};var ng=Oh(66);qh(162,1,{},bo);_.s=function(){var a;return a=(Eh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var og=Oh(162);qh(50,1,{50:1});_.d=false;var Xg=Oh(50);qh(51,50,{9:1,256:1,51:1,50:1},no);_.t=_p;_.o=function(a){return go(this,a)};_.q=function(){return this.c.d};_.u=aq;_.r=function(){var a;return Kh(Fg),Fg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var co=0;var Fg=Oh(51);qh(203,1,zp,oo);_.v=function(){eo(this.a)};var qg=Oh(203);qh(204,1,zp,po);_.v=function(){jo(this.a)};var rg=Oh(204);qh(115,114,{});var Rg=Oh(115);qh(26,115,wp,xo);_.t=gq;_.u=hq;_.r=function(){var a;return Kh(Ag),Ag.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Ag=Oh(26);qh(117,1,zp,yo);_.v=function(){ro(this.a)};var sg=Oh(117);qh(116,1,zp,zo);_.v=function(){uo(this.a)};var tg=Oh(116);qh(122,1,zp,Ao);_.v=function(){bc(this.a,this.b,true)};var ug=Oh(122);qh(123,1,{},Bo);_.s=function(){return qo(this.a,this.c,this.b)};_.b=false;var vg=Oh(123);qh(118,1,{},Co);_.s=function(){return vo(this.a)};var wg=Oh(118);qh(119,1,{},Do);_.s=function(){return Zh(hh(Jj(cc(this.a))))};var xg=Oh(119);qh(120,1,{},Eo);_.s=function(){return Zh(hh(Jj(Kj(cc(this.a),new lp))))};var yg=Oh(120);qh(121,1,{},Fo);_.s=function(){return wo(this.a)};var zg=Oh(121);qh(46,1,{46:1});var Wg=Oh(46);qh(144,46,{9:1,46:1},Mo);_.t=function(){jc(this.a)};_.u=function(){return this.a.i<0};_.r=function(){var a;return Kh(Eg),Eg.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Eg=Oh(144);qh(145,1,zp,No);_.v=function(){Jo(this.a,this.b)};_.b=false;var Bg=Oh(145);qh(146,1,zp,Oo);_.v=function(){Vn(this.b,this.a)};var Cg=Oh(146);qh(147,1,zp,Po);_.v=function(){Ko(this.a)};var Dg=Oh(147);qh(47,1,{47:1});var $g=Oh(47);qh(148,47,{9:1,47:1},Xo);_.t=gq;_.u=hq;_.r=function(){var a;return Kh(Lg),Lg.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Lg=Oh(148);qh(149,1,zp,Yo);_.v=function(){So(this.a)};var Gg=Oh(149);qh(153,1,zp,Zo);_.v=function(){Wo(this.a,null)};var Hg=Oh(153);qh(150,1,{},$o);_.s=function(){var a;return a=Sn(this.a.g),o(Rp,a)?(ip(),fp):o(Sp,a)?(ip(),hp):(ip(),gp)};var Ig=Oh(150);qh(151,1,{},_o);_.s=function(){return Uo(this.a)};var Jg=Oh(151);qh(152,1,{},ap);_.v=function(){Vo(this.a)};var Kg=Oh(152);qh(137,1,{},bp);_.handleEvent=function(a){Nn(this.a,a)};var Mg=Oh(137);qh(104,1,{},cp);_.I=function(){return new Wn};var Ng=Oh(104);var dp;qh(31,30,{3:1,28:1,30:1,31:1},jp);var fp,gp,hp;var Pg=Ph(31,kp);qh(106,1,{},lp);_.gb=function(a){return !io(a)};var Qg=Oh(106);qh(110,1,{},mp);_.gb=function(a){return io(a)};var Sg=Oh(110);qh(111,1,{},np);_.w=function(a){to(this.a,a)};var Tg=Oh(111);qh(109,1,{},op);_.w=function(a){Ho(this.a,a)};_.a=false;var Ug=Oh(109);qh(103,1,{},pp);_.I=function(){return new Mo(new xo)};var Vg=Oh(103);qh(112,1,{},qp);_.gb=function(a){return Ro(this.a,a)};var Yg=Oh(112);qh(105,1,{},rp);_.I=function(){return new Xo(new xo,this.a.I())};var Zg=Oh(105);var sd=Qh('D');var sp=(Ec(),Hc);var gwtOnLoad=gwtOnLoad=lh;jh(wh);mh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();