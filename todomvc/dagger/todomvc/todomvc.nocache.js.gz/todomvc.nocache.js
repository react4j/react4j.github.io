function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='722F5C7518F53769FE695C9678410C65',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '722F5C7518F53769FE695C9678410C65';function o(){}
function th(){}
function ph(){}
function Lb(){}
function Qc(){}
function Xc(){}
function Fj(){}
function Gj(){}
function Uk(){}
function Km(){}
function Om(){}
function Sm(){}
function Wm(){}
function $m(){}
function Yn(){}
function Fo(){}
function lp(){}
function mp(){}
function Vc(a){Uc()}
function Gm(a){Fm=a}
function Jm(a){Im=a}
function gn(a){fn=a}
function sn(a){rn=a}
function wn(a){vn=a}
function Bh(){Bh=ph}
function Di(){ui(this)}
function Db(a){this.a=a}
function pb(a){this.a=a}
function Eb(a){this.a=a}
function Fb(a){this.a=a}
function Gb(a){this.a=a}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function gc(a){this.a=a}
function pc(a){this.a=a}
function Rh(a){this.a=a}
function ai(a){this.a=a}
function mi(a){this.a=a}
function ri(a){this.a=a}
function si(a){this.a=a}
function qi(a){this.b=a}
function Fi(a){this.c=a}
function Dj(a){this.a=a}
function Ij(a){this.a=a}
function bl(a){this.a=a}
function el(a){this.a=a}
function fl(a){this.a=a}
function gl(a){this.a=a}
function nl(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function El(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Kl(a){this.a=a}
function fm(a){this.a=a}
function im(a){this.a=a}
function km(a){this.a=a}
function pm(a){this.a=a}
function qm(a){this.a=a}
function ym(a){this.a=a}
function Bm(a){this.a=a}
function Cm(a){this.a=a}
function Dm(a){this.a=a}
function cn(a){this.a=a}
function dn(a){this.a=a}
function hn(a){this.a=a}
function jn(a){this.a=a}
function mn(a){this.a=a}
function tn(a){this.a=a}
function zn(a){this.a=a}
function An(a){this.a=a}
function Bn(a){this.a=a}
function Dn(a){this.a=a}
function Fn(a){this.a=a}
function Tn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function vo(a){this.a=a}
function wo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function cp(a){this.a=a}
function dp(a){this.a=a}
function ep(a){this.a=a}
function np(a){this.a=a}
function op(a){this.a=a}
function pp(a){this.a=a}
function _p(){jc(this.c)}
function bq(){jc(this.b)}
function Pi(){this.a=Yi()}
function bj(){this.a=Yi()}
function Ej(a,b){a.a=b}
function $j(a,b){a.key=b}
function Zj(a,b){Yj(a,b)}
function Ho(a,b){dm(b,a)}
function Xp(a){fj(this,a)}
function $p(a){Vh(this,a)}
function jb(a){Zb((J(),a))}
function kb(a){$b((J(),a))}
function nb(a){_b((J(),a))}
function w(a){--a.e;D(a)}
function Y(a){!!a&&fb(a)}
function kc(a){!!a&&a.v()}
function Ob(a){a.a=-4&a.a|1}
function _g(a){return a.e}
function Up(){return this.a}
function Zp(){return this.b}
function dq(){qb(this.a.a)}
function nc(a,b){ii(a.e,b)}
function Hj(a,b){yj(a.a,b)}
function Ml(a,b){po(a.j,b)}
function Go(a,b){oo(a.b,b)}
function C(a,b){db(a.f,b.f)}
function wb(a,b){a.b=ij(b)}
function hl(a){a.c=2;jc(a.b)}
function Tl(a){a.f=2;jc(a.e)}
function Vk(a){a.d=2;jc(a.c)}
function Zk(a){qb(a.b);R(a.a)}
function Mn(a){R(a.a);fb(a.b)}
function Ui(){Ui=ph;Ti=Wi()}
function J(){J=ph;I=new F}
function wc(){wc=ph;vc=new o}
function Nc(){Nc=ph;Mc=new Qc}
function Eo(){Eo=ph;Do=new Fo}
function Wp(){return Qj(this)}
function Vp(a){return this===a}
function Yh(a,b){return a===b}
function Nl(a,b){return a.g=b}
function xi(a,b){return a.a[b]}
function Eh(a){Dh(a);return a.k}
function yl(a){qb(a.a);fb(a.b)}
function _n(a){fb(a.b);fb(a.a)}
function bi(a){uc.call(this,a)}
function Yp(){return ki(this.a)}
function aq(){return this.c.i<0}
function cq(){return this.b.i<0}
function Yc(a,b){return Kh(a,b)}
function Mj(a,b){a.splice(b,1)}
function ic(a,b,c){hi(a.e,b,c)}
function ao(a,b,c){ic(a.c,b,c)}
function jj(a,b){while(a.ab(b));}
function yj(a,b){Ej(a,xj(a.a,b))}
function K(a,b){O(a);L(a,ij(b))}
function Tb(a){Ub(a);!a.d&&Xb(a)}
function T(a){sb(a.f);return V(a)}
function xj(a,b){a.P(b);return a}
function hk(a,b){a.ref=b;return a}
function On(a){lb(a.b);return a.e}
function eo(a){lb(a.a);return a.d}
function Uo(a){lb(a.d);return a.f}
function Yi(){Ui();return new Ti}
function gb(a){J();$b(a);a.e=-2}
function Z(a){return !!a&&a.c.i<0}
function ki(a){return a.a.b+a.b.b}
function eq(a){return 1==this.a.d}
function fq(a){return 1==this.a.c}
function bd(a){return new Array(a)}
function $i(a,b){return a.a.get(b)}
function ti(a,b){this.a=a;this.b=b}
function hc(a,b){this.a=a;this.b=b}
function Ph(a,b){this.a=a;this.b=b}
function Bj(a,b){this.a=a;this.b=b}
function fk(a,b){this.a=a;this.b=b}
function Jl(a,b){this.a=a;this.b=b}
function jm(a,b){this.a=a;this.b=b}
function lm(a,b){this.a=a;this.b=b}
function mm(a,b){this.a=a;this.b=b}
function nm(a,b){this.a=a;this.b=b}
function om(a,b){this.a=a;this.b=b}
function Qk(a,b){Ph.call(this,a,b)}
function Kj(a,b,c){a.splice(b,0,c)}
function v(a,b,c){s(a,new H(c),b)}
function kn(a,b){this.a=a;this.b=b}
function ln(a,b){this.a=a;this.b=b}
function nn(a,b){this.a=a;this.b=b}
function on(a,b){this.a=a;this.b=b}
function Wh(){qc(this);this.C()}
function Dc(){Dc=ph;!!(Uc(),Tc)}
function en(){this.a=_j((Um(),Tm))}
function qn(){this.a=_j((Ym(),Xm))}
function Em(){this.a=_j((Mm(),Lm))}
function Hm(){this.a=_j((Qm(),Pm))}
function un(){this.a=_j((an(),_m))}
function Pn(a){Nn(a,(lb(a.b),a.e))}
function jp(a,b){Ph.call(this,a,b)}
function Zn(a,b){this.a=a;this.b=b}
function xo(a,b){this.a=a;this.b=b}
function No(a,b){this.a=a;this.b=b}
function Oo(a,b){this.b=a;this.a=b}
function ik(a,b){a.href=b;return a}
function rk(a,b){a.value=b;return a}
function $h(a,b){a.a+=''+b;return a}
function ji(a){a.a=new Pi;a.b=new bj}
function ui(a){a.a=$c(je,up,1,0,5,1)}
function Kc(a){$wnd.clearTimeout(a)}
function gi(a){return !a?null:a.Y()}
function Vb(a){return !a.d?a:Vb(a.d)}
function hj(a){return a!=null?r(a):0}
function qd(a){return a==null?null:a}
function nd(a){return typeof a===sp}
function ih(){gh==null&&(gh=[])}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function fo(a){dm(a,(lb(a.a),!a.d))}
function Xl(a){qb(a.b);R(a.c);fb(a.a)}
function vb(a){J();ub(a);yb(a,2,true)}
function Lj(a,b){Jj(b,0,a,0,b.length)}
function fc(a,b){dc(a,b,false);kb(a.d)}
function A(a,b,c){t(a,new G(b),c,null)}
function B(a,b,c){return t(a,c,2048,b)}
function $(a){return !(!!a&&1==(a.c&7))}
function lb(a){var b;Wb((J(),b=Rb,b),a)}
function Jb(a){this.d=ij(a);this.b=100}
function vh(a){this.b=ij(a);this.a=this}
function ob(a){this.c=new Di;this.b=a}
function Uj(){Uj=ph;Rj=new o;Tj=new o}
function lk(a,b){a.checked=b;return a}
function mk(a,b){a.onBlur=b;return a}
function jk(a,b){a.onClick=b;return a}
function nk(a,b){a.onChange=b;return a}
function ok(a,b){a.onKeyDown=b;return a}
function kk(a){a.autoFocus=true;return a}
function Dh(a){if(a.k!=null){return}Mh(a)}
function ld(a,b){return a!=null&&jd(a,b)}
function Xh(a,b){return a.charCodeAt(b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function Yj(a,b){for(var c in a){b(c)}}
function Oj(b,c,d){try{b[c]=d}catch(a){}}
function wj(a,b){rj.call(this,a);this.a=b}
function uc(a){this.f=a;qc(this);this.C()}
function Ji(){this.a=new Pi;this.b=new bj}
function P(){this.a=$c(je,up,1,100,5,1)}
function U(a){4==(a.f.c&7)&&yb(a.f,5,true)}
function Mb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function Qj(a){return a.$H||(a.$H=++Pj)}
function ol(a,b){return new ml(ij(b),a.a)}
function Fl(a,b){return new Dl(ij(b),a.a)}
function md(a){return typeof a==='boolean'}
function pd(a){return typeof a==='string'}
function u(a,b){return new Bb(ij(a),null,b)}
function rc(a,b){a.e=b;b!=null&&Oj(b,Dp,a)}
function ec(a,b){nc(b.c,a);ld(b,9)&&b.t()}
function fj(a,b){while(a.U()){Hj(b,a.V())}}
function Wo(a){Z((lb(a.d),a.f))&&Yo(a,null)}
function io(a){A((J(),J(),I),new lo(a),Np)}
function Io(a){A((J(),J(),I),new Po(a),Np)}
function am(a){A((J(),J(),I),new qm(a),Np)}
function Qn(a){A((J(),J(),I),new Wn(a),Np)}
function Ri(a,b){var c;c=a[Ip];c.call(a,b)}
function Hh(a){var b;b=Gh(a);Oh(a,b);return b}
function qc(a){a.g&&a.e!==Cp&&a.C();return a}
function sk(a,b){a.onDoubleClick=b;return a}
function ej(a,b,c){this.a=a;this.b=b;this.c=c}
function dl(a,b,c){this.a=a;this.b=b;this.c=c}
function hm(a,b,c){this.a=a;this.b=b;this.c=c}
function Am(a,b,c){this.a=a;this.b=b;this.c=c}
function cb(a,b,c){Ob(ij(c));K(a.a[b],ij(c))}
function Ec(a,b,c){return a.apply(b,c);var d}
function to(a){return Sh(S(a.e).a-S(a.a).a)}
function Ib(a){while(true){if(!Hb(a)){break}}}
function Uh(){Uh=ph;Th=$c(fe,up,32,256,0,1)}
function yh(){yh=ph;xh=$wnd.window.document}
function Uc(){Uc=ph;var a;!Wc();a=new Xc;Tc=a}
function zh(a,b,c,d){a.addEventListener(b,c,d)}
function vi(a,b){a.a[a.a.length]=b;return true}
function yo(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new eb;this.a=new Jb(this.f)}
function zl(a,b){A((J(),J(),I),new Jl(a,b),Np)}
function Yl(a,b){A((J(),J(),I),new om(a,b),Np)}
function $l(a,b){A((J(),J(),I),new mm(a,b),Np)}
function _l(a,b){A((J(),J(),I),new lm(a,b),Np)}
function cm(a,b){A((J(),J(),I),new jm(a,b),Np)}
function po(a,b){A((J(),J(),I),new xo(a,b),Np)}
function Lo(a,b){A((J(),J(),I),new No(a,b),Np)}
function ro(a){Vh(new ri(a.g),new gc(a));ji(a.g)}
function Kb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function lj(a){if(!a.d){a.d=a.b.O();a.c=a.b.Q()}}
function tb(a,b){ib(b,a);b.c.a.length>0||(b.a=4)}
function db(a,b){cb(a,((b.a&229376)>>15)-1,b)}
function Al(a,b){var c;c=b.target;Cl(a,c.value)}
function oi(a){var b;b=a.a.V();a.b=ni(a);return b}
function Jh(a){var b;b=Gh(a);b.j=a;b.e=1;return b}
function so(a){return Bh(),0==S(a.e).a?true:false}
function cl(a,b){return new al(ij(b),a.a,a.b,a.c)}
function gm(a,b){return new em(ij(b),a.a,a.b,a.c)}
function zm(a,b){return new xm(ij(b),a.a,a.b,a.c)}
function Zi(a,b){return !(a.a.get(b)===undefined)}
function ad(a){return Array.isArray(a)&&a.kb===th}
function kd(a){return !Array.isArray(a)&&a.kb===th}
function $k(a){return Bh(),S(a.e.b).a>0?true:false}
function _k(a){return B((J(),J(),I),a.b,new gl(a))}
function ll(a){return B((J(),J(),I),a.a,new rl(a))}
function Bl(a){return B((J(),J(),I),a.a,new Hl(a))}
function wh(a){ij(a);return ld(a,44)?a:new vh(a)}
function uj(a){qj(a);return new wj(a,new Cj(a.a))}
function wm(a){return B((J(),J(),I),a.a,new Cm(a))}
function bm(a){return B((J(),J(),I),a.b,new im(a))}
function Ro(a){return Yh(Sp,a)||Yh(Tp,a)||Yh('',a)}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function zi(a,b){var c;c=a.a[b];Mj(a.a,b);return c}
function Bi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function rm(a,b){var c;c=b.target;Lo(a.e,c.checked)}
function Ah(a,b,c,d){a.removeEventListener(b,c,d)}
function zj(a,b,c){if(a.a.bb(c)){a.b=true;b.w(c)}}
function pj(a){if(!a.b){qj(a);a.c=true}else{pj(a.b)}}
function Wk(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function il(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function Ul(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Xj(){if(Sj==256){Rj=Tj;Tj=new o;Sj=0}++Sj}
function ij(a){if(a==null){throw _g(new Wh)}return a}
function li(a,b){if(b){return ei(a.a,b)}return false}
function tj(a,b){qj(a);return new wj(a,new Aj(b,a.a))}
function Nn(a,b){A((J(),J(),I),new Zn(a,b),75497472)}
function no(a){R(a.c);R(a.e);R(a.a);R(a.b);fb(a.d)}
function To(a){qb(a.e);qb(a.a);R(a.b);R(a.c);fb(a.d)}
function Ln(a){var b;U(a.a);b=S(a.a);Yh(a.f,b)&&Rn(a,b)}
function Cl(a,b){var c;c=a.f;if(b!=c){a.f=b;kb(a.b)}}
function dm(a,b){var c;c=a.d;if(b!=c){a.d=b;kb(a.a)}}
function Rn(a,b){var c;c=a.e;if(b!=c){a.e=ij(b);kb(a.b)}}
function Ih(a,b){var c;c=Gh(a);Oh(a,c);c.e=b?8:0;return c}
function qk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function kj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function mj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function ac(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Cj(a){kj.call(this,a._(),a.$()&-6);this.a=a}
function rj(a){if(!a){this.b=null;new Di}else{this.b=a}}
function fh(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function Lh(a){if(a.M()){return null}var b=a.j;return lh[b]}
function Ii(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function oo(a,b){return t((J(),J(),I),new yo(a,b),Np,null)}
function Ql(a,b){Yo(a.k,b);A((J(),J(),I),new jm(a,b),Np)}
function mb(a){var b;J();!!Rb&&!!Rb.e&&Wb((b=Rb,b),a)}
function rb(a){C((J(),J(),I),a);0==(a.f.a&zp)&&D((null,I))}
function Pl(a,b){A((J(),J(),I),new jm(a,b),Np);Yo(a.k,null)}
function In(a){Ah((yh(),$wnd.window.window),Qp,a.d,false)}
function Hn(a){zh((yh(),$wnd.window.window),Qp,a.d,false)}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function kp(){ip();return cd(Yc(Pg,1),up,34,0,[fp,hp,gp])}
function fi(a,b){return b===a?'(this Map)':b==null?Fp:sh(b)}
function sc(a,b){var c;c=Eh(a.ib);return b==null?c:c+': '+b}
function Ll(a,b){var c;if(S(a.c)){c=b.target;dm(a,c.value)}}
function Vh(a,b){var c,d;for(d=a.O();d.U();){c=d.V();b.w(c)}}
function yn(a){return new dl(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function Cn(a){return new hm(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function En(a){return new Am(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function Sb(a){if(a.e){2==(a.e.c&7)||yb(a.e,4,true);ub(a.e)}}
function qj(a){if(a.b){qj(a.b)}else if(a.c){throw _g(new Qh)}}
function Jo(a,b){var c;vj(qo(a.b),(c=new Di,c)).N(new op(b))}
function Kh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function Li(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function bc(a,b){Rb=new ac(Rb,b);a.d=false;Sb(Rb);return Rb}
function rh(a){function b(){}
;b.prototype=a||{};return new b}
function pk(a){a.placeholder='What needs to be done?';return a}
function Jn(a,b){b.preventDefault();A((J(),J(),I),new Xn(a),Np)}
function qo(a){lb(a.d);return new wj(null,new mj(new ri(a.g),0))}
function Mi(a,b){var c;return Ki(b,Li(a,b==null?0:(c=r(b),c|0)))}
function nh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Mm(){Mm=ph;var a;Lm=(a=qh(Km.prototype.hb,Km,[]),a)}
function Qm(){Qm=ph;var a;Pm=(a=qh(Om.prototype.hb,Om,[]),a)}
function Um(){Um=ph;var a;Tm=(a=qh(Sm.prototype.hb,Sm,[]),a)}
function Ym(){Ym=ph;var a;Xm=(a=qh(Wm.prototype.hb,Wm,[]),a)}
function an(){an=ph;var a;_m=(a=qh($m.prototype.hb,$m,[]),a)}
function Zl(a){return Bh(),Uo(a.k)==a.n.props['a']?true:false}
function Ei(a){ui(this);Lj(this.a,di(a,$c(je,up,1,ki(a.a),5,1)))}
function mc(a){kc(a.g);!!a.e&&lc(a);Y(a.a);Y(a.c);kc(a.b);kc(a.f)}
function Qi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Nm(a){$wnd.React.Component.call(this,a);this.a=cl(Fm,this)}
function Rm(a){$wnd.React.Component.call(this,a);this.a=ol(Im,this)}
function Vm(a){$wnd.React.Component.call(this,a);this.a=Fl(fn,this)}
function Zm(a){$wnd.React.Component.call(this,a);this.a=gm(rn,this)}
function bn(a){$wnd.React.Component.call(this,a);this.a=zm(vn,this)}
function Aj(a,b){kj.call(this,b._(),b.$()&-16449);this.a=a;this.c=b}
function hb(a,b){var c,d;vi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Yo(a,b){var c;c=a.f;if(!(b==c||!!b&&bo(b,c))){a.f=b;kb(a.d)}}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function ek(a,b,c){!Yh(c,'key')&&!Yh(c,'ref')&&(a[c]=b[c],undefined)}
function nj(a,b){!a.a?(a.a=new ai(a.d)):$h(a.a,a.b);$h(a.a,b);return a}
function vj(a,b){var c;pj(a);c=new Fj;c.a=b;a.a.T(new Ij(c));return c.a}
function sj(a){var b;pj(a);b=0;while(a.a.ab(new Gj)){b=ah(b,1)}return b}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function ii(a,b){return pd(b)?b==null?Oi(a.a,null):aj(a.b,b):Oi(a.a,b)}
function So(a,b){return (ip(),gp)==a||(fp==a?(lb(b.a),!b.d):(lb(b.a),b.d))}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Pb(b){try{b.b.v()}catch(a){a=$g(a);if(!ld(a,5))throw _g(a)}}
function Ko(a){var b;vj(tj(qo(a.b),new mp),(b=new Di,b)).N(new np(a.b))}
function sl(a){var b;b=Zh((lb(a.b),a.f));if(b.length>0){Go(a.e,b);Cl(a,'')}}
function bb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function wi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function cj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function pi(a){this.d=a;this.c=new cj(this.d.b);this.a=this.c;this.b=ni(this)}
function oj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Mo(a){this.b=ij(a);J();this.a=new oc(0,null,null,false,false)}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new pc(a)),67108864,null)}}
function Vo(a){var b,c;return b=S(a.b),vj(tj(qo(a.j),new pp(b)),(c=new Di,c))}
function hi(a,b,c){return pd(b)?b==null?Ni(a.a,null,c):_i(a.b,b,c):Ni(a.a,b,c)}
function Nj(a,b){return Zc(b)!=10&&cd(q(b),b.jb,b.__elementTypeId$,Zc(b),a),a}
function Gn(a,b){a.f=b;Yh(b,S(a.a))&&Rn(a,b);Kn(b);A((J(),J(),I),new Xn(a),Np)}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function Ai(a,b){var c;c=yi(a,b,0);if(c==-1){return false}Mj(a.a,c);return true}
function bo(a,b){var c;if(ld(b,49)){c=b;return a.c.d==c.c.d}else{return false}}
function dj(a){if(a.a.c!=a.c){return $i(a.a,a.b.value[0])}return a.b.value[1]}
function yi(a,b,c){for(;c<a.a.length;++c){if(Ii(b,a.a[c])){return c}}return -1}
function V(a){if(a.b){if(ld(a.b,8)){throw _g(a.b)}else{throw _g(a.b)}}return a.n}
function xb(b){if(b){try{b.v()}catch(a){a=$g(a);if(ld(a,5)){J()}else throw _g(a)}}}
function cc(){var a;try{Tb(Rb);J()}finally{a=Rb.d;!a&&((J(),J(),I).d=true);Rb=Rb.d}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;fb(a.e);2==(a.f.c&7)||qb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Ib(a.a)}finally{a.c=false}}}}
function fb(a){if(-2!=a.e){t((J(),J(),I),new G(new pb(a)),0,null);!!a.b&&qb(a.b)}}
function tl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Il(a),Np)}}
function ck(a){var b;return ak($wnd.React.StrictMode,null,null,(b={},b[Jp]=ij(a),b))}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===rp||typeof a==='function')&&!(a.kb===th)}
function kh(a,b){typeof window===rp&&typeof window['$gwt']===rp&&(window['$gwt'][a]=b)}
function Oh(a,b){var c;if(!a){return}b.j=a;var d=Lh(b);if(!d){lh[a]=[b];return}d.ib=b}
function $g(a){var b;if(ld(a,5)){return a}b=a&&a[Dp];if(!b){b=new yc(a);Vc(b)}return b}
function qh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Gh(a){var b;b=new Fh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function _j(a){var b;b=bk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Gi(a){var b,c,d;d=0;for(c=new pi(a.a);c.b;){b=oi(c);d=d+(b?r(b):0);d=d|0}return d}
function ub(a){var b,c;for(c=new Fi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function hh(){ih();var a=gh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function eb(){var a;this.a=$c(wd,up,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Wb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;vi((!a.b&&(a.b=new Di),a.b),b)}}}
function Yb(a,b){var c;if(!a.c){c=Vb(a);!c.c&&(c.c=new Di);a.c=c.c}b.d=true;vi(a.c,ij(b))}
function aj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ri(a.a,b);--a.b}return c}
function mo(a,b,c){var d;d=new jo(b,c);ao(d,a,new hc(a,d));hi(a.g,Sh(d.c.d),d);kb(a.d);return d}
function ak(a,b,c,d){var e;e=bk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=ij(d);return e}
function pn(a,b){$j(a.a,(Dh(Zf),Zf.k+(''+(b?Sh(b.c.d):null))));ij(b);a.a.props['a']=b;return a.a}
function ci(a,b){var c,d;for(d=new pi(b.a);d.b;){c=oi(d);if(!li(a,c)){return false}}return true}
function Ki(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Ii(a,c.X())){return c}}return null}
function eh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Gp;d=1048575}c=rd(e/Ap);b=rd(e-c*Ap);return dd(b,c,d)}
function bh(a){var b;b=a.h;if(b==0){return a.l+a.m*Ap}if(b==1048575){return a.l+a.m*Ap-Gp}return a}
function ni(a){if(a.a.U()){return true}if(a.a!=a.c){return false}a.a=new Qi(a.d.a);return a.a.U()}
function Qh(){uc.call(this,"Stream already terminated, can't be modified or used")}
function Bb(a,b,c){Ab.call(this,null,a,b,c|(!a?262144:wp)|(0==(c&6291456)?!a?zp:Ap:0)|0|0|0)}
function Qb(a,b){this.b=ij(a);this.a=b|0|(0==(b&6291456)?Ap:0)|(0!=(b&229376)?0:98304)}
function xn(){this.a=wh((Eo(),Eo(),Do));this.b=wh(new Qo(this.a));this.c=wh(new dp(this.a))}
function ip(){ip=ph;fp=new jp('ACTIVE',0);hp=new jp('COMPLETED',1);gp=new jp('ALL',2)}
function Ol(a,b,c){27==c.which?A((J(),J(),I),new nm(a,b),Np):13==c.which&&A((J(),J(),I),new lm(a,b),Np)}
function qb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Fb(a)),67108864,null);!!a.a&&R(a.a);Mb(a.f);a.c=a.c&-8|1}}
function Tk(){if(!Sk){Sk=(++(J(),J(),I).e,new Lb);$wnd.Promise.resolve(null).then(qh(Uk.prototype.G,Uk,[]))}}
function Xo(a){var b;b=S(a.i.a);Yh(Sp,b)||Yh(Tp,b)||Yh('',b)?Nn(a.i,b):Ro(On(a.i))?Qn(a.i):Nn(a.i,'')}
function dc(a,b,c){var d;d=ii(a.g,b?Sh(b.c.d):null);if(null!=d){nc(b.c,a);c&&!!b&&jc(b.c);kb(a.d)}}
function _i(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function cd(a,b,c,d,e){e.ib=a;e.jb=b;e.kb=th;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function ib(a,b){var c,d;d=a.c;Ai(d,b);!!a.b&&wp!=(a.b.c&xp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Yb((J(),c=Rb,c),a))}
function Nb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&wp)?Pb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function q(a){return pd(a)?me:nd(a)?be:md(a)?_d:kd(a)?a.ib:ad(a)?a.ib:a.ib||Array.isArray(a)&&Yc(Td,1)||Td}
function r(a){return pd(a)?Wj(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.q():ad(a)?Qj(a):!!a&&!!a.hashCode?a.hashCode():Qj(a)}
function p(a,b){return pd(a)?Yh(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.o(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function Sl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;cm(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Sh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Uh(),Th)[b];!c&&(c=Th[b]=new Rh(a));return c}return new Rh(a)}
function sh(a){var b;if(Array.isArray(a)&&a.kb===th){return Eh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Wj(a){Uj();var b,c,d;c=':'+a;d=Tj[c];if(d!=null){return rd(d)}d=Rj[c];b=d==null?Vj(a):rd(d);Xj();Tj[c]=b;return b}
function yc(a){wc();qc(this);this.e=a;a!=null&&Oj(a,Dp,this);this.f=a==null?Fp:sh(a);this.a='';this.b=a;this.a=''}
function Fh(){this.g=Ch++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Hi(a){var b,c,d;d=1;for(c=new Fi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function ab(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Xb(a){var b;if(a.c){while(a.c.a.length!=0){b=zi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&yb(b.b,3,true)}}}
function lc(a){var b,c,d;for(c=new Fi(new Ei(new mi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.X();ld(d,9)&&d.u()||b.Y().v()}}
function Rk(){Pk();return cd(Yc(Ze,1),up,7,0,[tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok])}
function Cb(a,b){Ab.call(this,a,new Db(a),null,b|(wp==(b&xp)?0:524288)|(0==(b&6291456)?wp==(b&xp)?Ap:zp:0)|0|268435456|0)}
function ah(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<Gp){return c}}return bh(ed(nd(a)?eh(a):a,nd(b)?eh(b):b))}
function Rl(a,b){var c;c=(lb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Oo(b,c),Np);Yo(a.k,null);dm(a,c)}else{po(a.j,b)}}
function Nh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ci(a,b){var c,d;d=a.a.length;b.length<d&&(b=Nj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function di(a,b){var c,d,e;e=ki(a.a);b.length<e&&(b=Nj(new Array(e),b));d=new pi(a.a);for(c=0;c<e;++c){b[c]=oi(d)}b.length>e&&(b[e]=null);return b}
function gk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function oc(a,b,c,d,e){var f;this.d=a;this.e=d?new Ji:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new ob((J(),null)),f):null;this.c=null}
function ml(a,b){var c;this.d=ij(b);this.n=ij(a);J();c=++kl;this.b=new oc(c,null,new nl(this),false,false);this.a=new Bb(null,ij(new ql(this)),Mp)}
function jo(a,b){var c,d,e;this.e=ij(a);this.d=b;J();c=++$n;this.c=new oc(c,null,new ko(this),true,true);this.b=(e=new ob(null),e);this.a=(d=new ob(null),d)}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.jb){return !!a.jb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function S(a){a.k?mb(a.e):lb(a.e);if(zb(a.f)){if(a.k&&(J(),!(!!Rb&&!!Rb.e))){return t((J(),J(),I),new X(a),83888128,null)}else{sb(a.f)}}return V(a)}
function _b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Fi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&yb(b,5,true)}}}
function $b(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Fi(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&yb(b,6,true)}}}
function Zb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Fi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?yb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Zh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{bc(b,d);try{f=(c.a.v(),null)}finally{cc()}return f}catch(a){a=$g(a);if(ld(a,5)){e=a;throw _g(e)}else throw _g(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Rb){g=c.s()}else{bc(b,e);try{g=c.s()}finally{cc()}}return g}catch(a){a=$g(a);if(ld(a,5)){f=a;throw _g(f)}else throw _g(a)}finally{D(b)}}
function Hb(a){var b,c;if(0==a.c){b=bb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=ab(a.d);Nb(c);return true}
function jh(b,c,d,e){ih();var f=gh;$moduleName=c;$moduleBase=d;Zg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{qp(g)()}catch(a){b(c,a)}}else{qp(g)()}}
function W(a,b,c,d){this.c=ij(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new Cb(this,d&-16385);this.e=new ob(this.f);wp==(d&xp)&&rb(this.f)}
function Dl(a,b){var c,d;this.e=ij(b);this.n=ij(a);J();c=++xl;this.c=new oc(c,null,new El(this),false,false);this.b=(d=new ob(null),d);this.a=new Bb(null,ij(new Kl(this)),Mp)}
function xm(a,b,c,d){var e;this.d=ij(b);this.e=ij(c);this.f=ij(d);this.n=ij(a);J();e=++vm;this.b=new oc(e,null,new ym(this),false,false);this.a=new Bb(null,ij(new Bm(this)),Mp)}
function bk(a,b){var c;c=new $wnd.Object;c.$$typeof=ij(a);c.type=ij(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Wi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Xi()}}
function jl(a){var b,c,d;a.c=0;Tk();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),dk('span',gk(new $wnd.Object,cd(Yc(me,1),up,2,6,['todo-count'])),[dk('strong',null,[c]),' '+d+' left']));return b}
function mh(){lh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].lb()&&(c=Rc(c,g)):g[0].lb()}catch(a){a=$g(a);if(ld(a,5)){d=a;Dc();Jc(ld(d,35)?d.D():d)}else throw _g(a)}}return c}
function wl(a){var b;a.d=0;Tk();b=dk(Op,kk(nk(ok(rk(pk(gk(new $wnd.Object,cd(Yc(me,1),up,2,6,['new-todo']))),(lb(a.b),a.f)),qh(cn.prototype.fb,cn,[a])),qh(dn.prototype.eb,dn,[a]))),null);return b}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?Fp:od(b)?b==null?null:b.name:pd(b)?'String':Eh(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.n=d;b.b=null;jb(b.e)}}catch(a){a=$g(a);if(ld(a,12)){c=a;if(!b.b){b.n=null;b.b=c;jb(b.e)}throw _g(c)}else throw _g(a)}}
function Ni(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ki(b,e);if(f){return f.Z(c)}}e[e.length]=new ti(b,c);++a.b;return null}
function Jj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Vj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Xh(a,c++)}b=b|0;return b}
function sb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=$g(a);if(ld(a,5)){J()}else throw _g(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=$c(je,up,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function uh(){var a;a=new xn;Gm(yn(new zn(a)));Jm(new pl((new An(a)).a.a.F()));sn(Cn(new Dn(a)));wn(En(new Fn(a)));gn(new Gl((new Bn(a)).a.b.F()));$wnd.ReactDOM.render(ck([(new un).a]),(yh(),xh).getElementById('app'),null)}
function Kn(a){var b;if(0==a.length){b=(yh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',xh.title,b)}else{(yh(),$wnd.window.window).location.hash=a}}
function al(a,b,c,d){var e;this.e=ij(b);this.f=ij(c);this.g=ij(d);this.n=ij(a);J();e=++Yk;this.c=new oc(e,null,new bl(this),false,false);this.a=new W(new el(this),null,null,136478720);this.b=new Bb(null,ij(new fl(this)),Mp)}
function em(a,b,c,d){var e,f;this.j=ij(b);ij(c);this.k=ij(d);this.n=ij(a);J();e=++Wl;this.e=new oc(e,null,new fm(this),false,false);this.a=(f=new ob(null),f);this.c=new W(new km(this),null,null,136478720);this.b=new Bb(null,ij(new pm(this)),Mp);cm(this,this.n.props['a'])}
function Ab(a,b,c,d){this.b=new Di;this.f=new Qb(new Eb(this),d&6520832|262144|wp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&zp)&&D((null,I)))}
function Oi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ii(b,e.X())){if(d.length==1){d.length=0;Ri(a.a,g)}else{d.splice(h,1)}--a.b;return e.Y()}}return null}
function oh(a,b,c){var d=lh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=lh[b]),rh(h));_.jb=c;!b&&(_.kb=th);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ib=f)}
function Mh(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Nh('.',[c,Nh('$',d)]);a.b=Nh('.',[c,Nh('.',d)]);a.i=d[d.length-1]}
function ei(a,b){var c,d,e;c=b.X();e=b.Y();d=pd(c)?c==null?gi(Mi(a.a,null)):$i(a.b,c):gi(Mi(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Mi(a.a,null):Zi(a.b,c):!!Mi(a.a,c))){return false}return true}
function dk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Zj(b,qh(fk.prototype.cb,fk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Jp]=c[0],undefined):(d[Jp]=c,undefined));return ak(a,e,f,d)}
function Sn(){var a,b;this.d=new ep(this);this.f=this.e=(b=(yh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new oc(0,null,new Tn(this),false,false);this.b=(a=new ob(null),a);this.a=new W(new Yn,new Un(this),new Vn(this),35651584)}
function uo(){var a;this.g=new Ji;J();this.f=new oc(0,new wo(this),new vo(this),false,false);this.d=(a=new ob(null),a);this.c=new W(new zo(this),null,null,Rp);this.e=new W(new Ao(this),null,null,Rp);this.a=new W(new Bo(this),null,null,Rp);this.b=new W(new Co(this),null,null,Rp)}
function Zo(a){var b;this.j=ij(a);this.i=new Sn;J();this.g=new oc(0,null,new $o(this),false,false);this.d=(b=new ob(null),b);this.b=new W(new _o(this),null,null,Rp);this.c=new W(new ap(this),null,null,Rp);this.e=u(new bp(this),413138944);this.a=u(new cp(this),681574400);D((null,I))}
function zb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Fi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=$g(a);if(!ld(a,5))throw _g(a)}if(6==(b.c&7)){return true}}}}}ub(b);return false}
function Vi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function yb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){nb(a.a.e);xb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;xb((e=d.i,e));d.n=null}wi(a.b,new Gb(a));a.b.a=$c(je,up,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&xb((f=a.a.g,f))}}
function Pk(){Pk=ph;tk=new Qk(Kp,0);uk=new Qk('checkbox',1);vk=new Qk('color',2);wk=new Qk('date',3);xk=new Qk('datetime',4);yk=new Qk('email',5);zk=new Qk('file',6);Ak=new Qk('hidden',7);Bk=new Qk('image',8);Ck=new Qk('month',9);Dk=new Qk(sp,10);Ek=new Qk('password',11);Fk=new Qk('radio',12);Gk=new Qk('range',13);Hk=new Qk('reset',14);Ik=new Qk('search',15);Jk=new Qk('submit',16);Kk=new Qk('tel',17);Lk=new Qk('text',18);Mk=new Qk('time',19);Nk=new Qk('url',20);Ok=new Qk('week',21)}
function um(a){var b,c,d;a.c=0;Tk();d=dk('div',null,[dk('div',null,[dk(Pp,gk(new $wnd.Object,cd(Yc(me,1),up,2,6,[Pp])),[dk('h1',null,['todos']),(new en).a]),S(a.d.c)?null:dk('section',gk(new $wnd.Object,cd(Yc(me,1),up,2,6,[Pp])),[dk(Op,nk(qk(gk(new $wnd.Object,cd(Yc(me,1),up,2,6,['toggle-all'])),(Pk(),uk)),qh(tn.prototype.eb,tn,[a])),null),dk('ul',gk(new $wnd.Object,cd(Yc(me,1),up,2,6,['todo-list'])),(b=vj(ij(uj(S(a.f.c).S())),(c=new Di,c)),Ci(b,bd(b.a.length))))]),S(a.d.c)?null:(new Em).a])]);return d}
function Ub(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=xi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Bi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{ib(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&yb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=xi(a.b,g);if(-1==k.e){k.e=0;hb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){zi(a.b,g)}e&&wb(a.e,a.b)}else{e&&wb(a.e,new Di)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&wp!=(k.b.c&xp)&&k.c.a.length<=0&&0==k.b.a.d&&Yb(a,k)}}
function Xk(a){var b,c;a.d=0;Tk();c=(b=S(a.g.b),dk('footer',gk(new $wnd.Object,cd(Yc(me,1),up,2,6,['footer'])),[(new Hm).a,dk('ul',gk(new $wnd.Object,cd(Yc(me,1),up,2,6,['filters'])),[dk('li',null,[dk('a',ik(gk(new $wnd.Object,cd(Yc(me,1),up,2,6,[(ip(),gp)==b?Lp:null])),'#'),['All'])]),dk('li',null,[dk('a',ik(gk(new $wnd.Object,cd(Yc(me,1),up,2,6,[fp==b?Lp:null])),'#active'),['Active'])]),dk('li',null,[dk('a',ik(gk(new $wnd.Object,cd(Yc(me,1),up,2,6,[hp==b?Lp:null])),'#completed'),['Completed'])])]),S(a.a)?dk(Kp,jk(gk(new $wnd.Object,cd(Yc(me,1),up,2,6,['clear-completed'])),qh(Dm.prototype.gb,Dm,[a])),['Clear Completed']):null]));return c}
function Vl(a){var b,c,d,e;a.f=0;Tk();b=a.n.props['a'];if(b.c.i<0){return null}c=(d=a.n.props['a'],e=(lb(d.a),d.d),dk('li',gk(new $wnd.Object,cd(Yc(me,1),up,2,6,[e?'checked':null,S(a.c)?'editing':null])),[dk('div',gk(new $wnd.Object,cd(Yc(me,1),up,2,6,['view'])),[dk(Op,nk(lk(qk(gk(new $wnd.Object,cd(Yc(me,1),up,2,6,['toggle'])),(Pk(),uk)),e),qh(jn.prototype.eb,jn,[d])),null),dk('label',sk(new $wnd.Object,qh(kn.prototype.gb,kn,[a,d])),[(lb(d.b),d.e)]),dk(Kp,jk(gk(new $wnd.Object,cd(Yc(me,1),up,2,6,['destroy'])),qh(ln.prototype.gb,ln,[a,d])),null)]),dk(Op,ok(nk(mk(rk(gk(hk(new $wnd.Object,qh(mn.prototype.w,mn,[a])),cd(Yc(me,1),up,2,6,['edit'])),(lb(a.a),a.d)),qh(nn.prototype.db,nn,[a,d])),qh(hn.prototype.eb,hn,[a])),qh(on.prototype.fb,on,[a,d])),null)]));return c}
function Xi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Ip]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Vi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Ip]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var rp='object',sp='number',tp={11:1},up={3:1,4:1},vp={9:1},wp=1048576,xp=1835008,yp={6:1},zp=2097152,Ap=4194304,Bp={22:1},Cp='__noinit__',Dp='__java$exception',Ep={3:1,12:1,8:1,5:1},Fp='null',Gp=17592186044416,Hp={40:1},Ip='delete',Jp='children',Kp='button',Lp='selected',Mp=1411518464,Np=142606336,Op='input',Pp='header',Qp='hashchange',Rp=136314880,Sp='active',Tp='completed';var _,lh,gh,Zg=-1;mh();oh(1,null,{},o);_.o=Vp;_.p=function(){return this.ib};_.q=Wp;_.r=function(){var a;return Eh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var fd,gd,hd;oh(54,1,{},Fh);_.H=function(a){var b;b=new Fh;b.e=4;a>1?(b.c=Kh(this,a-1)):(b.c=this);return b};_.I=function(){Dh(this);return this.b};_.J=function(){return Eh(this)};_.K=function(){Dh(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Dh(this),this.k)};_.e=0;_.g=0;var Ch=1;var je=Hh(1);var ae=Hh(54);oh(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var vd=Hh(81);oh(36,1,tp,G);_.s=function(){return this.a.v(),null};var td=Hh(36);oh(82,1,{},H);var ud=Hh(82);var I;oh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var wd=Hh(43);oh(232,1,vp);_.r=function(){var a;return Eh(this.ib)+'@'+(a=r(this)>>>0,a.toString(16))};var Ad=Hh(232);oh(20,232,vp,W);_.t=function(){R(this)};_.u=Up;_.a=false;_.d=0;_.k=false;var yd=Hh(20);oh(179,1,tp,X);_.s=function(){return T(this.a)};var xd=Hh(179);oh(143,1,{271:1},eb);var zd=Hh(143);oh(18,232,{9:1,18:1},ob);_.t=function(){fb(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Cd=Hh(18);oh(178,1,yp,pb);_.v=function(){gb(this.a)};var Bd=Hh(178);oh(19,232,{9:1,19:1},Bb,Cb);_.t=function(){qb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Hd=Hh(19);oh(180,1,Bp,Db);_.v=function(){Q(this.a)};var Dd=Hh(180);oh(181,1,yp,Eb);_.v=function(){sb(this.a)};var Ed=Hh(181);oh(182,1,yp,Fb);_.v=function(){vb(this.a)};var Fd=Hh(182);oh(183,1,{},Gb);_.w=function(a){tb(this.a,a)};var Gd=Hh(183);oh(144,1,{},Jb);_.a=0;_.b=0;_.c=0;var Id=Hh(144);oh(184,1,vp,Lb);_.t=function(){Kb(this)};_.u=Up;_.a=false;var Jd=Hh(184);oh(65,232,{9:1,65:1},Qb);_.t=function(){Mb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Kd=Hh(65);oh(188,1,{},ac);_.r=function(){var a;return Dh(Ld),Ld.k+'@'+(a=Qj(this)>>>0,a.toString(16))};_.a=0;var Rb;var Ld=Hh(188);oh(156,1,{});var Od=Hh(156);oh(149,1,{},gc);_.w=function(a){ec(this.a,a)};var Md=Hh(149);oh(150,1,yp,hc);_.v=function(){fc(this.a,this.b)};var Nd=Hh(150);oh(157,156,{});var Pd=Hh(157);oh(17,1,vp,oc);_.t=function(){jc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Dh(Rd),Rd.k+'@'+(a=Qj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Rd=Hh(17);oh(177,1,yp,pc);_.v=function(){mc(this.a)};var Qd=Hh(177);oh(5,1,{3:1,5:1});_.A=function(a){return new Error(a)};_.B=function(){return this.f};_.C=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Eh(this.ib),c==null?a:a+': '+c);rc(this,tc(this.A(b)));Vc(this)};_.r=function(){return sc(this,this.B())};_.e=Cp;_.g=true;var ne=Hh(5);oh(12,5,{3:1,12:1,5:1});var de=Hh(12);oh(8,12,Ep);var ke=Hh(8);oh(55,8,Ep);var ge=Hh(55);oh(76,55,Ep);var Vd=Hh(76);oh(35,76,{35:1,3:1,12:1,8:1,5:1},yc);_.B=function(){xc(this);return this.c};_.D=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Sd=Hh(35);var Td=Hh(0);oh(214,1,{});var Ud=Hh(214);var Ac=0,Bc=0,Cc=-1;oh(90,214,{},Qc);var Mc;var Wd=Hh(90);var Tc;oh(225,1,{});var Yd=Hh(225);oh(77,225,{},Xc);var Xd=Hh(77);oh(44,1,{44:1,69:1},vh);_.F=function(){if(this===this.a){this.a=this.b.F();this.b=null}return this.a};var Zd=Hh(44);var xh;oh(74,1,{71:1});_.r=Up;var $d=Hh(74);fd={3:1,72:1,31:1};var _d=Hh(72);oh(41,1,{3:1,41:1});var ie=Hh(41);gd={3:1,31:1,41:1};var be=Hh(224);oh(33,1,{3:1,31:1,33:1});_.o=Vp;_.q=Wp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ce=Hh(33);oh(78,8,Ep,Qh);var ee=Hh(78);oh(32,41,{3:1,31:1,32:1,41:1},Rh);_.o=function(a){return ld(a,32)&&a.a==this.a};_.q=Up;_.r=function(){return ''+this.a};_.a=0;var fe=Hh(32);var Th;oh(289,1,{});oh(79,55,Ep,Wh);_.A=function(a){return new TypeError(a)};var he=Hh(79);hd={3:1,71:1,31:1,2:1};var me=Hh(2);oh(75,74,{71:1},ai);var le=Hh(75);oh(293,1,{});oh(57,8,Ep,bi);var oe=Hh(57);oh(226,1,{39:1});_.N=$p;_.R=function(){return new mj(this,0)};_.S=function(){return new wj(null,this.R())};_.P=function(a){throw _g(new bi('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new oj('[',']');for(b=this.O();b.U();){a=b.V();nj(c,a===this?'(this Collection)':a==null?Fp:sh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=Hh(226);oh(230,1,{213:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ld(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new pi((new mi(d)).a);c.b;){b=oi(c);if(!ei(this,b)){return false}}return true};_.q=function(){return Gi(new mi(this))};_.r=function(){var a,b,c;c=new oj('{','}');for(b=new pi((new mi(this)).a);b.b;){a=oi(b);nj(c,fi(this,a.X())+'='+fi(this,a.Y()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=Hh(230);oh(142,230,{213:1});var se=Hh(142);oh(229,226,{39:1,238:1});_.R=function(){return new mj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ld(a,24)){return false}b=a;if(ki(b.a)!=this.Q()){return false}return ci(this,b)};_.q=function(){return Gi(this)};var Be=Hh(229);oh(24,229,{24:1,39:1,238:1},mi);_.O=function(){return new pi(this.a)};_.Q=Yp;var re=Hh(24);oh(25,1,{},pi);_.T=Xp;_.V=function(){return oi(this)};_.U=Zp;_.b=false;var qe=Hh(25);oh(227,226,{39:1,234:1});_.R=function(){return new mj(this,16)};_.W=function(a,b){throw _g(new bi('Add not supported on this list'))};_.P=function(a){this.W(this.Q(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.Q()!=f.a.length){return false}e=new Fi(f);for(c=new Fi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return Hi(this)};_.O=function(){return new qi(this)};var ue=Hh(227);oh(89,1,{},qi);_.T=Xp;_.U=function(){return this.a<this.b.a.length};_.V=function(){return xi(this.b,this.a++)};_.a=0;var te=Hh(89);oh(59,226,{39:1},ri);_.O=function(){var a;a=new pi((new mi(this.a)).a);return new si(a)};_.Q=Yp;var we=Hh(59);oh(141,1,{},si);_.T=Xp;_.U=function(){return this.a.b};_.V=function(){var a;a=oi(this.a);return a.Y()};var ve=Hh(141);oh(139,1,Hp);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Ii(this.a,b.X())&&Ii(this.b,b.Y())};_.X=Up;_.Y=Zp;_.q=function(){return hj(this.a)^hj(this.b)};_.Z=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var xe=Hh(139);oh(140,139,Hp,ti);var ye=Hh(140);oh(231,1,Hp);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Ii(this.b.value[0],b.X())&&Ii(dj(this),b.Y())};_.q=function(){return hj(this.b.value[0])^hj(dj(this))};_.r=function(){return this.b.value[0]+'='+dj(this)};var ze=Hh(231);oh(14,227,{3:1,14:1,39:1,234:1},Di,Ei);_.W=function(a,b){Kj(this.a,a,b)};_.P=function(a){return vi(this,a)};_.N=function(a){wi(this,a)};_.O=function(){return new Fi(this)};_.Q=function(){return this.a.length};var De=Hh(14);oh(16,1,{},Fi);_.T=Xp;_.U=function(){return this.a<this.c.a.length};_.V=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=Hh(16);oh(37,142,{3:1,37:1,213:1},Ji);var Ee=Hh(37);oh(62,1,{},Pi);_.N=$p;_.O=function(){return new Qi(this)};_.b=0;var Ge=Hh(62);oh(63,1,{},Qi);_.T=Xp;_.V=function(){return this.d=this.a[this.c++],this.d};_.U=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=Hh(63);var Ti;oh(60,1,{},bj);_.N=$p;_.O=function(){return new cj(this)};_.b=0;_.c=0;var Je=Hh(60);oh(61,1,{},cj);_.T=Xp;_.V=function(){return this.c=this.a,this.a=this.b.next(),new ej(this.d,this.c,this.d.c)};_.U=function(){return !this.a.done};var He=Hh(61);oh(148,231,Hp,ej);_.X=function(){return this.b.value[0]};_.Y=function(){return dj(this)};_.Z=function(a){return _i(this.a,this.b.value[0],a)};_.c=0;var Ie=Hh(148);oh(198,1,{});_.T=function(a){jj(this,a)};_.$=function(){return this.d};_._=function(){return this.e};_.d=0;_.e=0;var Le=Hh(198);oh(66,198,{});var Ke=Hh(66);oh(23,1,{},mj);_.$=Up;_._=function(){lj(this);return this.c};_.T=function(a){lj(this);this.d.T(a)};_.ab=function(a){lj(this);if(this.d.U()){a.w(this.d.V());return true}return false};_.a=0;_.c=0;var Me=Hh(23);oh(56,1,{},oj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ne=Hh(56);oh(197,1,{});_.c=false;var We=Hh(197);oh(28,197,{274:1,28:1},wj);var Ve=Hh(28);oh(200,66,{},Aj);_.ab=function(a){this.b=false;while(!this.b&&this.c.ab(new Bj(this,a)));return this.b};_.b=false;var Pe=Hh(200);oh(203,1,{},Bj);_.w=function(a){zj(this.a,this.b,a)};var Oe=Hh(203);oh(199,66,{},Cj);_.ab=function(a){return this.a.ab(new Dj(a))};var Re=Hh(199);oh(202,1,{},Dj);_.w=function(a){this.a.w(pn(new qn,a))};var Qe=Hh(202);oh(201,1,{},Fj);_.w=function(a){Ej(this,a)};var Se=Hh(201);oh(204,1,{},Gj);_.w=function(a){};var Te=Hh(204);oh(205,1,{},Ij);_.w=function(a){Hj(this,a)};var Ue=Hh(205);oh(291,1,{});oh(233,1,{});var Xe=Hh(233);oh(288,1,{});var Pj=0;var Rj,Sj=0,Tj;oh(920,1,{});oh(955,1,{});oh(228,1,{});var Ye=Hh(228);oh(273,$wnd.Function,{},fk);_.cb=function(a){ek(this.a,this.b,a)};oh(7,33,{3:1,31:1,33:1,7:1},Qk);var tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok;var Ze=Ih(7,Rk);var Sk;oh(272,$wnd.Function,{},Uk);_.G=function(a){return Kb(Sk),Sk=null,null};oh(91,228,{});var Lf=Hh(91);oh(92,91,{});_.d=0;var Pf=Hh(92);oh(93,92,vp,al);_.t=_p;_.o=Vp;_.q=Wp;_.u=aq;_.r=function(){var a;return Dh(jf),jf.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var Yk=0;var jf=Hh(93);oh(95,1,yp,bl);_.v=function(){Zk(this.a)};var $e=Hh(95);oh(94,1,{},dl);var _e=Hh(94);oh(96,1,tp,el);_.s=function(){return $k(this.a)};var af=Hh(96);oh(97,1,Bp,fl);_.v=function(){Wk(this.a)};var bf=Hh(97);oh(98,1,tp,gl);_.s=function(){return Xk(this.a)};var cf=Hh(98);oh(100,228,{});var Kf=Hh(100);oh(101,100,{});_.c=0;var Of=Hh(101);oh(102,101,vp,ml);_.t=bq;_.o=Vp;_.q=Wp;_.u=cq;_.r=function(){var a;return Dh(hf),hf.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var kl=0;var hf=Hh(102);oh(104,1,yp,nl);_.v=dq;var df=Hh(104);oh(103,1,{},pl);var ef=Hh(103);oh(105,1,Bp,ql);_.v=function(){il(this.a)};var ff=Hh(105);oh(106,1,tp,rl);_.s=function(){return jl(this.a)};var gf=Hh(106);oh(129,228,{});_.f='';var Xf=Hh(129);oh(130,129,{});_.d=0;var Rf=Hh(130);oh(131,130,vp,Dl);_.t=_p;_.o=Vp;_.q=Wp;_.u=aq;_.r=function(){var a;return Dh(qf),qf.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var xl=0;var qf=Hh(131);oh(133,1,yp,El);_.v=function(){yl(this.a)};var kf=Hh(133);oh(132,1,{},Gl);var lf=Hh(132);oh(135,1,tp,Hl);_.s=function(){return wl(this.a)};var mf=Hh(135);oh(136,1,yp,Il);_.v=function(){sl(this.a)};var nf=Hh(136);oh(137,1,yp,Jl);_.v=function(){Al(this.a,this.b)};var of=Hh(137);oh(134,1,Bp,Kl);_.v=function(){Wk(this.a)};var pf=Hh(134);oh(108,228,{});_.i=false;var Zf=Hh(108);oh(109,108,{});_.f=0;var Tf=Hh(109);oh(110,109,vp,em);_.t=function(){jc(this.e)};_.o=Vp;_.q=Wp;_.u=function(){return this.e.i<0};_.r=function(){var a;return Dh(Cf),Cf.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var Wl=0;var Cf=Hh(110);oh(112,1,yp,fm);_.v=function(){Xl(this.a)};var rf=Hh(112);oh(111,1,{},hm);var sf=Hh(111);oh(115,1,tp,im);_.s=function(){return Vl(this.a)};var tf=Hh(115);oh(42,1,yp,jm);_.v=function(){dm(this.a,On(this.b))};var uf=Hh(42);oh(113,1,tp,km);_.s=function(){return Zl(this.a)};var vf=Hh(113);oh(58,1,yp,lm);_.v=function(){Rl(this.a,this.b)};var wf=Hh(58);oh(116,1,yp,mm);_.v=function(){Ql(this.a,this.b)};var xf=Hh(116);oh(117,1,yp,nm);_.v=function(){Pl(this.a,this.b)};var yf=Hh(117);oh(118,1,yp,om);_.v=function(){Ll(this.a,this.b)};var zf=Hh(118);oh(114,1,Bp,pm);_.v=function(){Ul(this.a)};var Af=Hh(114);oh(119,1,yp,qm);_.v=function(){Sl(this.a)};var Bf=Hh(119);oh(121,228,{});var _f=Hh(121);oh(122,121,{});_.c=0;var Vf=Hh(122);oh(123,122,vp,xm);_.t=bq;_.o=Vp;_.q=Wp;_.u=cq;_.r=function(){var a;return Dh(Hf),Hf.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var vm=0;var Hf=Hh(123);oh(125,1,yp,ym);_.v=dq;var Df=Hh(125);oh(124,1,{},Am);var Ef=Hh(124);oh(126,1,Bp,Bm);_.v=function(){il(this.a)};var Ff=Hh(126);oh(127,1,tp,Cm);_.s=function(){return um(this.a)};var Gf=Hh(127);oh(254,$wnd.Function,{},Dm);_.gb=function(a){Io(this.a.f)};oh(186,1,{},Em);var If=Hh(186);var Fm;oh(208,1,{},Hm);var Jf=Hh(208);var Im;oh(255,$wnd.Function,{},Km);_.hb=function(a){return new Nm(a)};var Lm;oh(99,$wnd.React.Component,{},Nm);nh(lh[1],_);_.componentWillUnmount=function(){Vk(this.a)};_.render=function(){return _k(this.a)};_.shouldComponentUpdate=eq;var Mf=Hh(99);oh(256,$wnd.Function,{},Om);_.hb=function(a){return new Rm(a)};var Pm;oh(107,$wnd.React.Component,{},Rm);nh(lh[1],_);_.componentWillUnmount=function(){hl(this.a)};_.render=function(){return ll(this.a)};_.shouldComponentUpdate=fq;var Nf=Hh(107);oh(270,$wnd.Function,{},Sm);_.hb=function(a){return new Vm(a)};var Tm;oh(138,$wnd.React.Component,{},Vm);nh(lh[1],_);_.componentWillUnmount=function(){Vk(this.a)};_.render=function(){return Bl(this.a)};_.shouldComponentUpdate=eq;var Qf=Hh(138);oh(257,$wnd.Function,{},Wm);_.hb=function(a){return new Zm(a)};var Xm;oh(120,$wnd.React.Component,{},Zm);nh(lh[1],_);_.componentDidUpdate=function(a){am(this.a)};_.componentWillUnmount=function(){Tl(this.a)};_.render=function(){return bm(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Sf=Hh(120);oh(267,$wnd.Function,{},$m);_.hb=function(a){return new bn(a)};var _m;oh(128,$wnd.React.Component,{},bn);nh(lh[1],_);_.componentWillUnmount=function(){hl(this.a)};_.render=function(){return wm(this.a)};_.shouldComponentUpdate=fq;var Uf=Hh(128);oh(268,$wnd.Function,{},cn);_.fb=function(a){tl(this.a,a)};oh(269,$wnd.Function,{},dn);_.eb=function(a){zl(this.a,a)};oh(185,1,{},en);var Wf=Hh(185);var fn;oh(264,$wnd.Function,{},hn);_.eb=function(a){Yl(this.a,a)};oh(258,$wnd.Function,{},jn);_.eb=function(a){io(this.a)};oh(260,$wnd.Function,{},kn);_.gb=function(a){$l(this.a,this.b)};oh(261,$wnd.Function,{},ln);_.gb=function(a){Ml(this.a,this.b)};oh(262,$wnd.Function,{},mn);_.w=function(a){Nl(this.a,a)};oh(263,$wnd.Function,{},nn);_.db=function(a){_l(this.a,this.b)};oh(265,$wnd.Function,{},on);_.fb=function(a){Ol(this.a,this.b,a)};oh(207,1,{},qn);var Yf=Hh(207);var rn;oh(266,$wnd.Function,{},tn);_.eb=function(a){rm(this.a,a)};oh(70,1,{},un);var $f=Hh(70);var vn;oh(83,1,{},xn);var fg=Hh(83);oh(84,1,{},zn);var ag=Hh(84);oh(88,1,{},An);var bg=Hh(88);oh(87,1,{},Bn);var cg=Hh(87);oh(85,1,{},Dn);var dg=Hh(85);oh(86,1,{},Fn);var eg=Hh(86);oh(189,1,{});var Og=Hh(189);oh(190,189,vp,Sn);_.t=_p;_.o=Vp;_.q=Wp;_.u=aq;_.r=function(){var a;return Dh(ng),ng.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var ng=Hh(190);oh(191,1,yp,Tn);_.v=function(){Mn(this.a)};var gg=Hh(191);oh(193,1,Bp,Un);_.v=function(){Hn(this.a)};var hg=Hh(193);oh(194,1,Bp,Vn);_.v=function(){In(this.a)};var ig=Hh(194);oh(196,1,yp,Wn);_.v=function(){Pn(this.a)};var jg=Hh(196);oh(64,1,yp,Xn);_.v=function(){Ln(this.a)};var kg=Hh(64);oh(192,1,tp,Yn);_.s=function(){var a;return a=(yh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var lg=Hh(192);oh(195,1,yp,Zn);_.v=function(){Gn(this.a,this.b)};var mg=Hh(195);oh(48,1,{48:1});_.d=false;var Wg=Hh(48);oh(49,48,{9:1,275:1,49:1,48:1},jo);_.t=_p;_.o=function(a){return bo(this,a)};_.q=function(){return this.c.d};_.u=aq;_.r=function(){var a;return Dh(Fg),Fg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var $n=0;var Fg=Hh(49);oh(209,1,yp,ko);_.v=function(){_n(this.a)};var og=Hh(209);oh(210,1,yp,lo);_.v=function(){fo(this.a)};var pg=Hh(210);oh(45,157,{45:1});var Rg=Hh(45);oh(158,45,{9:1,45:1},uo);_.t=function(){jc(this.f)};_.o=Vp;_.q=Wp;_.u=function(){return this.f.i<0};_.r=function(){var a;return Dh(zg),zg.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var zg=Hh(158);oh(160,1,yp,vo);_.v=function(){no(this.a)};var qg=Hh(160);oh(159,1,yp,wo);_.v=function(){ro(this.a)};var rg=Hh(159);oh(165,1,yp,xo);_.v=function(){dc(this.a,this.b,true)};var sg=Hh(165);oh(166,1,tp,yo);_.s=function(){return mo(this.a,this.c,this.b)};_.b=false;var tg=Hh(166);oh(161,1,tp,zo);_.s=function(){return so(this.a)};var ug=Hh(161);oh(162,1,tp,Ao);_.s=function(){return Sh(fh(sj(qo(this.a))))};var vg=Hh(162);oh(163,1,tp,Bo);_.s=function(){return Sh(fh(sj(tj(qo(this.a),new lp))))};var wg=Hh(163);oh(164,1,tp,Co);_.s=function(){return to(this.a)};var xg=Hh(164);oh(145,1,{69:1},Fo);_.F=function(){return new uo};var Do;var yg=Hh(145);oh(46,1,{46:1});var Vg=Hh(46);oh(167,46,{9:1,46:1},Mo);_.t=function(){jc(this.a)};_.o=Vp;_.q=Wp;_.u=function(){return this.a.i<0};_.r=function(){var a;return Dh(Eg),Eg.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var Eg=Hh(167);oh(168,1,yp,No);_.v=function(){Jo(this.a,this.b)};_.b=false;var Ag=Hh(168);oh(169,1,yp,Oo);_.v=function(){Rn(this.b,this.a)};var Bg=Hh(169);oh(170,1,yp,Po);_.v=function(){Ko(this.a)};var Cg=Hh(170);oh(146,1,{69:1},Qo);_.F=function(){return new Mo(this.a.F())};var Dg=Hh(146);oh(47,1,{47:1});var Yg=Hh(47);oh(171,47,{9:1,47:1},Zo);_.t=function(){jc(this.g)};_.o=Vp;_.q=Wp;_.u=function(){return this.g.i<0};_.r=function(){var a;return Dh(Mg),Mg.k+'@'+(a=Qj(this)>>>0,a.toString(16))};var Mg=Hh(171);oh(172,1,yp,$o);_.v=function(){To(this.a)};var Gg=Hh(172);oh(173,1,tp,_o);_.s=function(){var a;return a=On(this.a.i),Yh(Sp,a)?(ip(),fp):Yh(Tp,a)?(ip(),hp):(ip(),gp)};var Hg=Hh(173);oh(174,1,tp,ap);_.s=function(){return Vo(this.a)};var Ig=Hh(174);oh(175,1,Bp,bp);_.v=function(){Wo(this.a)};var Jg=Hh(175);oh(176,1,Bp,cp);_.v=function(){Xo(this.a)};var Kg=Hh(176);oh(147,1,{69:1},dp);_.F=function(){return new Zo(this.a.F())};var Lg=Hh(147);oh(187,1,{},ep);_.handleEvent=function(a){Jn(this.a,a)};var Ng=Hh(187);oh(34,33,{3:1,31:1,33:1,34:1},jp);var fp,gp,hp;var Pg=Ih(34,kp);oh(151,1,{},lp);_.bb=function(a){return !eo(a)};var Qg=Hh(151);oh(153,1,{},mp);_.bb=function(a){return eo(a)};var Sg=Hh(153);oh(154,1,{},np);_.w=function(a){po(this.a,a)};var Tg=Hh(154);oh(152,1,{},op);_.w=function(a){Ho(this.a,a)};_.a=false;var Ug=Hh(152);oh(155,1,{},pp);_.bb=function(a){return So(this.a,a)};var Xg=Hh(155);var sd=Jh('D');var qp=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=jh;hh(uh);kh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();