function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='98F3D9CA6CC25250138659BEA682857D',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '98F3D9CA6CC25250138659BEA682857D';function p(){}
function xh(){}
function th(){}
function Gb(){}
function Sc(){}
function Zc(){}
function Zm(){}
function Vm(){}
function ki(){}
function kn(){}
function bn(){}
function fn(){}
function Fn(){}
function Fj(){}
function Tj(){}
function _j(){}
function ak(){}
function zk(){}
function nl(){}
function bo(){}
function cp(){}
function lp(){}
function mp(){}
function pp(){}
function Xc(a){Wc()}
function Kh(){Kh=th}
function Ni(){Ei(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Bi(a){this.a=a}
function ji(a){this.a=a}
function wi(a){this.a=a}
function Ci(a){this.a=a}
function hc(a){this.a=a}
function qc(a){this.a=a}
function $h(a){this.a=a}
function Gj(a){this.a=a}
function Gl(a){this.a=a}
function wl(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Vl(a){this.a=a}
function Wl(a){this.a=a}
function Xl(a){this.a=a}
function Yl(a){this.a=a}
function ck(a){this.a=a}
function um(a){this.a=a}
function vm(a){this.a=a}
function wm(a){this.a=a}
function Bm(a){this.a=a}
function Dm(a){this.a=a}
function Lm(a){this.a=a}
function Mm(a){this.a=a}
function Nm(a){this.a=a}
function Om(a){this.a=a}
function on(a){this.a=a}
function pn(a){this.a=a}
function tn(a){this.a=a}
function un(a){this.a=a}
function xn(a){this.a=a}
function En(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function oo(a){this.a=a}
function po(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Eo(a){this.a=a}
function Fo(a){this.a=a}
function Po(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function np(a){this.a=a}
function op(a){this.a=a}
function qp(a){this.a=a}
function rp(a){this.a=a}
function Ai(a){this.b=a}
function Pi(a){this.c=a}
function $p(){kc(this.c)}
function aq(){kc(this.b)}
function fq(){kc(this.f)}
function w(a){--a.e;D(a)}
function Z(a){!!a&&ab(a)}
function lc(a){!!a&&a.s()}
function _i(){this.a=ij()}
function nj(){this.a=ij()}
function $j(a,b){a.a=b}
function rb(a,b){a.b=b}
function uk(a,b){a.key=b}
function sk(a,b){rk(a,b)}
function Ho(a,b){sm(b,a)}
function oc(a,b){si(a.e,b)}
function bk(a,b){Sj(a.a,b)}
function _l(a,b){to(a.k,b)}
function Go(a,b){so(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function L(a,b){P(a);M(a,b)}
function Up(a){rj(this,a)}
function Zp(a){uj(this,a)}
function Xp(a){ci(this,a)}
function cq(){lb(this.a.a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function eh(a){return a.e}
function Yp(){return this.e}
function Sp(){return this.a}
function Wp(){return this.b}
function am(a,b){return a.i=b}
function ol(a){a.e=2;kc(a.c)}
function Al(a){a.d=2;kc(a.b)}
function em(a){a.g=2;kc(a.e)}
function Qn(a){S(a.a);ab(a.b)}
function sl(a){lb(a.b);S(a.a)}
function tc(a,b){a.e=b;sc(a,b)}
function jc(a,b,c){ri(a.e,b,c)}
function Jh(a){wc.call(this,a)}
function Zh(a){wc.call(this,a)}
function li(a){wc.call(this,a)}
function Tp(){return jk(this)}
function Hi(a,b){return a.a[b]}
function zj(a,b,c){b.w(a.a[c])}
function fo(a,b,c){jc(a.c,b,c)}
function gk(a,b){a.splice(b,1)}
function Pl(a){lb(a.a);ab(a.b)}
function eo(a){ab(a.b);ab(a.a)}
function ej(){ej=th;dj=gj()}
function ep(){ep=th;dp=new cp}
function yc(){yc=th;xc=new p}
function Pc(){Pc=th;Oc=new Sc}
function K(){K=th;J=new F}
function Ah(){Ah=th;zh=new p}
function Nh(a){Mh(a);return a.k}
function $c(a,b){return Th(a,b)}
function Vp(){return ui(this.a)}
function _p(){return this.c.i<0}
function bq(){return this.b.i<0}
function gq(){return this.f.i<0}
function di(){rc(this);this.G()}
function Fc(){Fc=th;!!(Wc(),Vc)}
function mh(){kh==null&&(kh=[])}
function bb(a){K();Zb(a);a.e=-2}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function U(a){nb(a.f);return W(a)}
function Rj(a,b){a.T(b);return a}
function ij(){ej();return new dj}
function Ck(a,b){a.ref=b;return a}
function Sn(a){gb(a.b);return a.e}
function io(a){gb(a.a);return a.d}
function To(a){gb(a.d);return a.e}
function dq(a){return 1==this.a.e}
function eq(a){return 1==this.a.d}
function ui(a){return a.a.b+a.b.b}
function Tm(a){this.a=a;Um=this}
function rn(a){this.a=a;sn=this}
function Bh(a){this.a=zh;this.b=a}
function Yh(a,b){this.a=a;this.b=b}
function ic(a,b){this.a=a;this.b=b}
function Di(a,b){this.a=a;this.b=b}
function Wj(a,b){this.a=a;this.b=b}
function Zj(a,b){this.a=a;this.b=b}
function Ak(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function Zl(a,b){this.a=a;this.b=b}
function xm(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function zm(a,b){this.a=a;this.b=b}
function Am(a,b){this.a=a;this.b=b}
function Cm(a,b){this.a=a;this.b=b}
function jl(a,b){Yh.call(this,a,b)}
function Sj(a,b){$j(a,Rj(a.a,b))}
function uj(a,b){while(a.eb(b));}
function Xj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new I(c),b)}
function ek(a,b,c){a.splice(b,0,c)}
function Dk(a,b){a.href=b;return a}
function vn(a,b){this.a=a;this.b=b}
function wn(a,b){this.a=a;this.b=b}
function yn(a,b){this.a=a;this.b=b}
function zn(a,b){this.a=a;this.b=b}
function $n(a,b){this.a=a;this.b=b}
function Ao(a,b){this.a=a;this.b=b}
function No(a,b){this.a=a;this.b=b}
function Oo(a,b){this.b=a;this.a=b}
function jp(a,b){Yh.call(this,a,b)}
function kj(a,b){return a.a.get(b)}
function od(a){return typeof a===up}
function Tn(a){Rn(a,(gb(a.b),a.e))}
function jo(a){sm(a,(gb(a.a),!a.d))}
function Pm(){this.a=wk((Xm(),Wm))}
function Sm(){this.a=wk((_m(),$m))}
function qn(){this.a=wk((dn(),cn))}
function Bn(){this.a=wk((hn(),gn))}
function Gn(){this.a=wk((mn(),ln))}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function Mc(a){$wnd.clearTimeout(a)}
function Mk(a,b){a.value=b;return a}
function Hk(a,b){a.onBlur=b;return a}
function hi(a,b){a.a+=''+b;return a}
function ti(a){a.a=new _i;a.b=new nj}
function Ei(a){a.a=ad(me,wp,1,0,5,1)}
function qb(a){K();pb(a);tb(a,2,true)}
function Ub(a){return !a.d?a:Ub(a.d)}
function qi(a){return !a?null:a.ab()}
function tj(a){return a!=null?s(a):0}
function rd(a){return a==null?null:a}
function o(a,b){return rd(a)===rd(b)}
function B(a,b,c){return u(a,c,2048,b)}
function A(a,b,c){u(a,new H(b),c,null)}
function fk(a,b){dk(b,0,a,0,b.length)}
function gc(a,b){cc(a,b,false);fb(a.c)}
function im(a){lb(a.b);S(a.c);ab(a.a)}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function jb(a){this.c=new Ni;this.b=a}
function nk(){nk=th;kk=new p;mk=new p}
function Gk(a,b){a.checked=b;return a}
function Ek(a,b){a.onClick=b;return a}
function Ik(a,b){a.onChange=b;return a}
function Jk(a,b){a.onKeyDown=b;return a}
function tk(a,b){a.props['a']=b;return a}
function Fk(a){a.autoFocus=true;return a}
function Mh(a){if(a.k!=null){return}Vh(a)}
function md(a,b){return a!=null&&kd(a,b)}
function ei(a,b){return a.charCodeAt(b)}
function ed(a,b,c){return {l:a,m:b,h:c}}
function rk(a,b){for(var c in a){b(c)}}
function Jo(a,b){Gi(ec(a.b),new op(b))}
function fc(a,b){oc(b.c,a);md(b,9)&&b.u()}
function wc(a){this.g=a;rc(this);this.G()}
function Qj(a,b){Jj.call(this,a);this.a=b}
function bj(a,b){var c;c=a[Hp];c.call(a,b)}
function rj(a,b){while(a.Y()){bk(b,a.Z())}}
function Cn(a,b){this.a=a;this.b=b;Dn=this}
function Vi(){this.a=new _i;this.b=new nj}
function Q(){this.a=ad(me,wp,1,100,5,1)}
function $(a){return !(!!a&&1==(a.c&7))}
function jk(a){return a.$H||(a.$H=++ik)}
function qd(a){return typeof a==='string'}
function nd(a){return typeof a==='boolean'}
function wo(a){return _h(T(a.e).a-T(a.a).a)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function So(a){lb(a.a);S(a.b);S(a.c);ab(a.d)}
function mo(a){A((K(),K(),J),new po(a),Lp)}
function Io(a){A((K(),K(),J),new Po(a),Lp)}
function qm(a){A((K(),K(),J),new Dm(a),Lp)}
function Un(a){A((K(),K(),J),new _n(a),Lp)}
function bi(){bi=th;ai=ad(ie,wp,29,256,0,1)}
function Wc(){Wc=th;var a;!Yc();a=new Zc;Vc=a}
function qj(a,b,c){this.a=a;this.b=b;this.c=c}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function Gc(a,b,c){return a.apply(b,c);var d}
function Nk(a,b){a.onDoubleClick=b;return a}
function Fi(a,b){a.a[a.a.length]=b;return true}
function rc(a){a.j&&a.e!==Cp&&a.G();return a}
function Qh(a){var b;b=Ph(a);Xh(a,b);return b}
function Db(a){while(true){if(!Cb(a)){break}}}
function xj(a,b){while(a.c<a.d){zj(a,b,a.c++)}}
function om(a,b){A((K(),K(),J),new zm(a,b),Lp)}
function km(a,b){A((K(),K(),J),new Cm(a,b),Lp)}
function pm(a,b){A((K(),K(),J),new ym(a,b),Lp)}
function rm(a,b){A((K(),K(),J),new xm(a,b),Lp)}
function Rl(a,b){A((K(),K(),J),new Zl(a,b),Lp)}
function to(a,b){A((K(),K(),J),new Ao(a,b),Lp)}
function Lo(a,b){A((K(),K(),J),new No(a,b),Lp)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Sl(a,b){var c;c=b.target;Tl(a,c.value)}
function Kj(a,b){var c;return Oj(a,(c=new Ni,c))}
function Sh(a){var b;b=Ph(a);b.j=a;b.e=1;return b}
function Eh(a){if(!a){throw eh(new di)}return a}
function yi(a){var b;b=a.a.Z();a.b=xi(a);return b}
function Bj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function Uj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function Hh(a,b,c,d){a.addEventListener(b,c,d)}
function Ih(a,b,c,d){a.removeEventListener(b,c,d)}
function jj(a,b){return !(a.a.get(b)===undefined)}
function Qo(a){return o(Qp,a)||o(Rp,a)||o('',a)}
function Qi(a,b){return vj(b,a.length),new Aj(a,b)}
function vo(a){return Kh(),0!=T(a.e).a?true:false}
function Ri(a){return new Qj(null,Qi(a,a.length))}
function tl(a){return B((K(),K(),J),a.b,new yl(a))}
function ul(a){return Kh(),T(a.f.b).a>0?true:false}
function cd(a){return Array.isArray(a)&&a.pb===xh}
function ld(a){return !Array.isArray(a)&&a.pb===xh}
function El(a){return B((K(),K(),J),a.a,new Il(a))}
function Ql(a){return B((K(),K(),J),a.a,new Wl(a))}
function jm(a){return B((K(),K(),J),a.b,new vm(a))}
function Jm(a){return B((K(),K(),J),a.a,new Nm(a))}
function uo(a){ci(new Bi(a.g),new hc(a));ti(a.g)}
function ro(a){S(a.d);S(a.e);S(a.a);S(a.b);ab(a.c)}
function Ji(a,b){var c;c=a.a[b];gk(a.a,b);return c}
function Li(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Bo(a,b){this.a=a;this.c=b;this.b=false}
function wj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Tl(a,b){var c;c=a.g;if(b!=c){a.g=b;fb(a.b)}}
function sm(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function Em(a,b){var c;c=b.target;Lo(a.f,c.checked)}
function Vn(a,b){var c;c=a.e;if(b!=c){a.e=b;fb(a.b)}}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Mj(a,b){Ij(a);return new Qj(a,new Vj(b,a.a))}
function Nj(a,b){Ij(a);return new Qj(a,new Yj(b,a.a))}
function vi(a,b){if(b){return oi(a.a,b)}return false}
function Lk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ql(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function Cl(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function gm(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function Hj(a){if(!a.b){Ij(a);a.c=true}else{Hj(a.b)}}
function Jj(a){if(!a){this.b=null;new Ni}else{this.b=a}}
function Aj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Qm(a,b,c){this.a=a;this.b=b;this.c=c;Rm=this}
function Hn(a,b,c){this.a=a;this.b=b;this.c=c;In=this}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function Rn(a,b){A((K(),K(),J),new $n(a,b),75497472)}
function mm(a,b){Wo(a.n,b);A((K(),K(),J),new xm(a,b),Lp)}
function Ui(a,b){return rd(a)===rd(b)||a!=null&&q(a,b)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Pn(a){var b;V(a.a);b=T(a.a);o(a.f,b)&&Vn(a,b)}
function Rh(a,b){var c;c=Ph(a);Xh(a,c);c.e=b?8:0;return c}
function uc(a,b){var c;c=Nh(a.nb);return b==null?c:c+': '+b}
function pi(a,b){return b===a?'(this Map)':b==null?Ep:wh(b)}
function Cj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Gh(){Gh=th;Fh=$wnd.goog.global.document}
function qk(){if(lk==256){kk=mk;mk=new p;lk=0}++lk}
function jh(a){if(od(a)){return a|0}return a.l|a.m<<22}
function Uh(a){if(a.P()){return null}var b=a.j;return ph[b]}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function $l(a,b){var c;if(T(a.c)){c=b.target;sm(a,c.value)}}
function ci(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function vh(a){function b(){}
;b.prototype=a||{};return new b}
function dn(){dn=th;var a;cn=(a=uh(bn.prototype.mb,bn,[]),a)}
function hn(){hn=th;var a;gn=(a=uh(fn.prototype.mb,fn,[]),a)}
function mn(){mn=th;var a;ln=(a=uh(kn.prototype.mb,kn,[]),a)}
function Xm(){Xm=th;var a;Wm=(a=uh(Vm.prototype.mb,Vm,[]),a)}
function _m(){_m=th;var a;$m=(a=uh(Zm.prototype.mb,Zm,[]),a)}
function kp(){ip();return dd($c(Rg,1),wp,31,0,[fp,hp,gp])}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function Ln(a){Hh((Gh(),$wnd.goog.global.window),Op,a.d,false)}
function Mn(a){Ih((Gh(),$wnd.goog.global.window),Op,a.d,false)}
function nm(a,b){A((K(),K(),J),new xm(a,b),Lp);Wo(a.n,null)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&Ap)&&D((null,J))}
function lm(a){return Kh(),To(a.n)==a.f.props['a']?true:false}
function Yi(a,b){var c;return Wi(b,Xi(a,b==null?0:(c=s(b),c|0)))}
function Xi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Th(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function rh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Nn(a,b){b.preventDefault();A((K(),K(),J),new ao(a),Lp)}
function dc(a){gb(a.c);return new Qj(null,new Cj(new Bi(a.g),0))}
function Mo(a){this.b=a;K();this.a=new pc(0,null,null,false,false)}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function aj(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Yj(a,b){wj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function Oi(a){Ei(this);fk(this.a,ni(a,ad(me,wp,1,ui(a.a),5,1)))}
function nc(a){lc(a.g);!!a.e&&mc(a);Z(a.a);Z(a.c);lc(a.b);lc(a.f)}
function Ch(a){Ah();Eh(a);if(md(a,45)){return a}return new Bh(a)}
function yj(a,b){if(a.c<a.d){zj(a,b,a.c++);return true}return false}
function Kk(a){a.placeholder='What needs to be done?';return a}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function cb(a,b){var c,d;Fi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Vj(a,b){wj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function oj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Dj(a,b){!a.a?(a.a=new ji(a.d)):hi(a.a,a.b);hi(a.a,b);return a}
function Oj(a,b){var c;Hj(a);c=new _j;c.a=b;a.a.X(new ck(c));return c.a}
function Lj(a){var b;Hj(a);b=0;while(a.a.eb(new ak)){b=fh(b,1)}return b}
function Ko(a){Kj(Mj(dc(a.b),new mp),new Gj(new Fj)).Q(new np(a.b))}
function so(a,b){var c;return u((K(),K(),J),new Bo(a,b),Lp,(c=null,c))}
function si(a,b){return qd(b)?b==null?$i(a.a,null):mj(a.b,b):$i(a.a,b)}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function Jb(b){try{nb(b.b.a)}catch(a){a=dh(a);if(!md(a,4))throw eh(a)}}
function Jl(a){var b;b=gi((gb(a.b),a.g));if(b.length>0){Go(a.f,b);Tl(a,'')}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function yk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function Pj(a,b){var c;c=Kj(a,new Gj(new Fj));return Mi(c,b.fb(c.a.length))}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function pj(a){if(a.a.c!=a.c){return kj(a.a,a.b.value[0])}return a.b.value[1]}
function zi(a){this.d=a;this.c=new oj(this.d.b);this.a=this.c;this.b=xi(this)}
function Ej(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function an(a){$wnd.React.Component.call(this,a);this.a=new Fl(this,Um.a)}
function en(a){$wnd.React.Component.call(this,a);this.a=new Ul(this,sn.a)}
function jn(a){$wnd.React.Component.call(this,a);this.a=new tm(this,Dn.a,Dn.b)}
function Jn(){this.a=Ch(new pp);this.b=Ch((ep(),dp));this.c=Ch(new rp(this.b))}
function Uo(a){var b;return b=T(a.b),Kj(Mj(dc(a.i),new qp(b)),new Gj(new Fj))}
function kc(a){if(a.i>=0){a.i=-2;u((K(),K(),J),new H(new qc(a)),67108864,null)}}
function Kn(a,b){a.f=b;o(b,T(a.a))&&Vn(a,b);On(b);A((K(),K(),J),new ao(a),Lp)}
function Ro(a,b){return (ip(),gp)==a||(fp==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function ri(a,b,c){return qd(b)?b==null?Zi(a.a,null,c):lj(a.b,b,c):Zi(a.a,b,c)}
function hk(a,b){return _c(b)!=10&&dd(r(b),b.ob,b.__elementTypeId$,_c(b),a),a}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Gi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Pb(){var a;this.a=ad(yd,wp,44,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function go(a,b){var c;if(md(b,51)){c=b;return a.c.d==c.c.d}else{return false}}
function Ki(a,b){var c;c=Ii(a,b,0);if(c==-1){return false}gk(a.a,c);return true}
function Ii(a,b,c){for(;c<a.a.length;++c){if(Ui(b,a.a[c])){return c}}return -1}
function W(a){if(a.b){if(md(a.b,7)){throw eh(a.b)}else{throw eh(a.b)}}return a.k}
function sb(b){if(b){try{b.s()}catch(a){a=dh(a);if(md(a,4)){K()}else throw eh(a)}}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function Qc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Uc(b,c)}while(a.a);a.a=c}}
function Rc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function S(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function ab(a){if(-2!=a.e){u((K(),K(),J),new H(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function ec(a){return gb(a.c),Kj(new Qj(null,new Cj(new Bi(a.g),0)),new Gj(new Fj))}
function Kl(a,b){if(13==b.keyCode){b.preventDefault();A((K(),K(),J),new Xl(a),Lp)}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ni);Fi(a.b,b)}}}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Ni);a.c=c.c}b.d=true;Fi(a.c,b)}
function Xh(a,b){var c;if(!a){return}b.j=a;var d=Uh(b);if(!d){ph[a]=[b];return}d.nb=b}
function uh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function An(a,b){uk(a.a,(b?_h(b.c.d):null)+(''+(Mh(eg),eg.k)));tk(a.a,b);return a.a}
function Ph(a){var b;b=new Oh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function wk(a){var b;b=vk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Si(a){var b,c,d;d=0;for(c=new zi(a.a);c.b;){b=yi(c);d=d+(b?s(b):0);d=d|0}return d}
function pb(a){var b,c;for(c=new Pi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function lh(){mh();var a=kh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function pd(a){return a!=null&&(typeof a===tp||typeof a==='function')&&!(a.pb===xh)}
function oh(a,b){typeof window===tp&&typeof window['$gwt']===tp&&(window['$gwt'][a]=b)}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Bp:0)|(0!=(b&229376)?0:98304)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:yp)|(0==(c&6291456)?!a?Ap:Bp:0)|0|0|0)}
function mi(a,b){var c,d;for(d=new zi(b.a);d.b;){c=yi(d);if(!vi(a,c)){return false}}return true}
function mj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{bj(a.a,b);--a.b}return c}
function qo(a,b,c){var d;d=new no(b,c);fo(d,a,new ic(a,d));ri(a.g,_h(d.c.d),d);fb(a.c);return d}
function cc(a,b,c){var d;d=si(a.g,b?_h(b.c.d):null);if(null!=d){oc(b.c,a);c&&!!b&&kc(b.c);fb(a.c)}}
function Vo(a){var b;b=T(a.g.a);o(Qp,b)||o(Rp,b)||o('',b)?Rn(a.g,b):Qo(Sn(a.g))?Un(a.g):Rn(a.g,'')}
function nn(a){$wnd.React.Component.call(this,a);this.a=new Km(this,In.a,In.b,In.c)}
function Ym(a){$wnd.React.Component.call(this,a);this.a=new vl(this,Rm.a,Rm.b,Rm.c)}
function Ac(a){yc();rc(this);this.e=a;sc(this,a);this.g=a==null?Ep:wh(a);this.a='';this.b=a;this.a=''}
function ip(){ip=th;fp=new jp('ACTIVE',0);hp=new jp('COMPLETED',1);gp=new jp('ALL',2)}
function vj(a,b){if(0>a||a>b){throw eh(new Jh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function xi(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new aj(a.d.a);return a.a.Y()}
function dh(a){var b;if(md(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function gh(a){var b;b=a.h;if(b==0){return a.l+a.m*Bp}if(b==1048575){return a.l+a.m*Bp-Fp}return a}
function ih(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Fp;d=1048575}c=sd(e/Bp);b=sd(e-c*Bp);return ed(b,c,d)}
function Wi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ui(a,c._())){return c}}return null}
function _h(a){var b,c;if(a>-129&&a<128){b=a+128;c=(bi(),ai)[b];!c&&(c=ai[b]=new $h(a));return c}return new $h(a)}
function Wo(a,b){var c;c=a.e;if(!(b==c||!!b&&go(b,c))){!!c&&oc(c.c,a);a.e=b;!!b&&fo(b,a,new Zo(a));fb(a.d)}}
function lj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function dd(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=xh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function bm(a,b,c){27==c.which?A((K(),K(),J),new Am(a,b),Lp):13==c.which&&A((K(),K(),J),new ym(a,b),Lp)}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function ml(){if(!ll){ll=(++(K(),K(),J).e,new Gb);$wnd.Promise.resolve(null).then(uh(nl.prototype.J,nl,[]))}}
function Ij(a){if(a.b){Ij(a.b)}else if(a.c){throw eh(new Zh("Stream already terminated, can't be modified or used"))}}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&yp)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function db(a,b){var c,d;d=a.c;Ki(d,b);!!a.b&&yp!=(a.b.c&zp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function fd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ed(c&4194303,d&4194303,e&1048575)}
function fh(a,b){var c;if(od(a)&&od(b)){c=a+b;if(-17592186044416<c&&c<Fp){return c}}return gh(fd(od(a)?ih(a):a,od(b)?ih(b):b))}
function r(a){return qd(a)?pe:od(a)?de:nd(a)?be:ld(a)?a.nb:cd(a)?a.nb:a.nb||Array.isArray(a)&&$c(Ud,1)||Ud}
function s(a){return qd(a)?pk(a):od(a)?sd(a):nd(a)?a?1231:1237:ld(a)?a.q():cd(a)?jk(a):!!a&&!!a.hashCode?a.hashCode():jk(a)}
function dm(a){var b;b=T(a.c);if(!a.j&&b){a.j=true;rm(a,a.f.props['a']);a.i.focus();a.i.select()}else a.j&&!b&&(a.j=false)}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=Ji(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Ti(a){var b,c,d;d=1;for(c=new Pi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function pk(a){nk();var b,c,d;c=':'+a;d=mk[c];if(d!=null){return sd(d)}d=kk[c];b=d==null?ok(a):sd(d);qk();mk[c]=b;return b}
function wh(a){var b;if(Array.isArray(a)&&a.pb===xh){return Nh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function cm(a,b){var c;c=(gb(a.a),a.d);if(null!=c&&c.length!=0){A((K(),K(),J),new Oo(b,c),Lp);Wo(a.n,null);sm(a,c)}else{to(a.k,b)}}
function Oh(){this.g=Lh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Fl(a,b){var c;this.e=b;this.c=a;K();c=++Dl;this.b=new pc(c,null,new Gl(this),false,false);this.a=new wb(null,new Hl(this),Kp)}
function pc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Vi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new jb((f=null,K(),f)),g):null;this.c=null}
function kl(){il();return dd($c(ff,1),wp,6,0,[Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl])}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(yp==(b&zp)?0:524288)|(0==(b&6291456)?yp==(b&zp)?Bp:Ap:0)|0|268435456|0)}
function Wh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Mi(a,b){var c,d;d=a.a.length;b.length<d&&(b=hk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function mc(a){var b,c,d;for(c=new Pi(new Oi(new wi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();md(d,9)&&d.v()||b.ab().s()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function q(a,b){return qd(a)?o(a,b):od(a)?rd(a)===rd(b):nd(a)?rd(a)===rd(b):ld(a)?a.o(b):cd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function kd(a,b){if(qd(a)){return !!jd[b]}else if(a.ob){return !!a.ob[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function Bk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function T(a){a.j?hb(a.e):gb(a.e);if(ub(a.f)){if(a.j&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function gi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ni(a,b){var c,d,e,f;f=ui(a.a);b.length<f&&(b=hk(new Array(f),b));e=b;d=new zi(a.a);for(c=0;c<f;++c){e[c]=yi(d)}b.length>f&&(b[f]=null);return b}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.s(),null)}finally{bc()}return f}catch(a){a=dh(a);if(md(a,4)){e=a;throw eh(e)}else throw eh(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.i=c;this.k=null;this.j=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);yp==(d&zp)&&mb(this.f)}
function Km(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.c=a;K();e=++Im;this.b=new pc(e,null,new Lm(this),false,false);this.a=new wb(null,new Mm(this),Kp)}
function Ul(a,b){var c,d,e;this.f=b;this.d=a;K();c=++Ol;this.c=new pc(c,null,new Vl(this),false,false);this.b=(e=new jb((d=null,d)),e);this.a=new wb(null,new Yl(this),Kp)}
function no(a,b){var c,d,e,f,g;this.e=a;this.d=b;K();c=++co;this.c=new pc(c,null,new oo(this),true,true);this.b=(g=new jb((e=null,e)),g);this.a=(f=new jb((d=null,d)),f)}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function nh(b,c,d,e){mh();var f=kh;$moduleName=c;$moduleBase=d;bh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{sp(g)()}catch(a){b(c,a)}}else{sp(g)()}}
function vk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function gj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return hj()}}
function Bl(a){var b,c;a.d=0;ml();c=(b=T(a.e.e).a,xk('span',Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,['todo-count'])),[xk('strong',null,[b]),' item'+(b==1?'':'s')+' left']));return c}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.t()}else{ac(b,e);try{g=c.t()}finally{bc()}}return g}catch(a){a=dh(a);if(md(a,4)){f=a;throw eh(f)}else throw eh(a)}finally{D(b)}}
function qh(){ph={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Tc(c,g)):g[0].qb()}catch(a){a=dh(a);if(md(a,4)){d=a;Fc();Lc(md(d,35)?d.H():d)}else throw eh(a)}}return c}
function Ml(a){var b;a.e=0;ml();b=xk(Mp,Fk(Ik(Jk(Mk(Kk(Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,['new-todo']))),(gb(a.b),a.g)),uh(on.prototype.kb,on,[a])),uh(pn.prototype.jb,pn,[a]))),null);return b}
function zc(a){var b;if(a.c==null){b=rd(a.b)===rd(xc)?null:a.b;a.d=b==null?Ep:pd(b)?b==null?null:b.name:qd(b)?'String':Nh(r(b));a.a=a.a+': '+(pd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.k;try{d=b.c.t();if(!(rd(e)===rd(d)||e!=null&&q(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=dh(a);if(md(a,10)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw eh(c)}else throw eh(a)}}
function dk(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Zi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Wi(b,e);if(f){return f.bb(c)}}e[e.length]=new Di(b,c);++a.b;return null}
function vl(a,b,c,d){var e;this.f=b;this.g=c;this.i=d;this.d=a;K();e=++rl;this.c=new pc(e,null,new wl(this),false,false);this.a=new X(new xl(this),null,null,136478720);this.b=new wb(null,new zl(this),Kp)}
function ok(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ei(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{b.e.s()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=dh(a);if(md(a,4)){K()}else throw eh(a)}}}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=ad(me,wp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Dh(a,b){var c;c=rd(a)!==rd(zh);if(c&&rd(a)!==rd(b)){throw eh(new Zh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}return b}
function vb(a,b,c,d){this.b=new Ni;this.f=new Kb(new zb(this),d&6520832|262144|yp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&Ap)&&D((null,J)))}
function yh(){var a;a=new Jn;new Qm(new xo,a.a.I(),a.c.I());new Cn(new xo,(a.a.I(),a.c.I()));new Hn(new xo,a.a.I(),a.c.I());new rn(a.a.I());new Tm(new xo);$wnd.ReactDOM.render((new Gn).a,(Gh(),Fh).getElementById('app'),null)}
function $i(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ui(b,e._())){if(d.length==1){d.length=0;bj(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function sh(a,b,c){var d=ph,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=ph[b]),vh(h));_.ob=c;!b&&(_.pb=xh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Vh(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Wh('.',[c,Wh('$',d)]);a.b=Wh('.',[c,Wh('.',d)]);a.i=d[d.length-1]}
function On(a){var b;if(0==a.length){b=(Gh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Fh.title,b)}else{(Gh(),$wnd.goog.global.window).location.hash=a}}
function oi(a,b){var c,d,e;c=b._();e=b.ab();d=qd(c)?c==null?qi(Yi(a.a,null)):kj(a.b,c):qi(Yi(a.a,c));if(!(rd(e)===rd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(qd(c)?c==null?!!Yi(a.a,null):jj(a.b,c):!!Yi(a.a,c))){return false}return true}
function tm(a,b,c){var d,e,f;this.k=b;this.n=c;this.f=a;K();d=++hm;this.e=new pc(d,null,new um(this),false,false);this.a=(f=new jb((e=null,e)),f);this.c=new X(new wm(this),null,null,136478720);this.b=new wb(null,new Bm(this),Kp);rm(this,this.f.props['a'])}
function Xo(a,b){var c,d;this.i=a;this.g=b;K();this.f=new pc(0,null,new Yo(this),false,false);this.d=(d=new jb((c=null,c)),d);this.b=new X(new $o(this),null,null,Pp);this.c=new X(new _o(this),null,null,Pp);this.a=new wb(new ap(this),null,681574400);D((null,J))}
function xo(){var a;this.g=new Vi;K();this.f=new pc(0,new zo(this),new yo(this),false,false);this.c=(a=new jb(null),a);this.d=new X(new Co(this),null,null,Pp);this.e=new X(new Do(this),null,null,Pp);this.a=new X(new Eo(this),null,null,Pp);this.b=new X(new Fo(this),null,null,Pp)}
function Wn(){var a,b,c;this.d=new bp(this);this.f=this.e=(c=(Gh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));K();this.c=new pc(0,null,new Xn(this),false,false);this.b=(b=new jb((a=null,a)),b);this.a=new X(new bo,new Yn(this),new Zn(this),35651584)}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Pi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=dh(a);if(!md(a,4))throw eh(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function xk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;sk(b,uh(Ak.prototype.hb,Ak,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=vk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function fj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}Gi(a.b,new Bb(a));a.b.a=ad(me,wp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function Gm(a){var b;a.d=0;ml();b=xk('div',null,[xk('div',null,[xk(Np,Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,[Np])),[xk('h1',null,['todos']),(new qn).a]),T(a.e.d)?xk('section',Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,[Np])),[xk(Mp,Ik(Lk(Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,['toggle-all'])),(il(),Pk)),uh(En.prototype.jb,En,[a])),null),xk('ul',Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,['todo-list'])),Pj(Nj(T(a.g.c).W(),new Fn),new zk))]):null,T(a.e.d)?(new Pm).a:null])]);return b}
function il(){il=th;Ok=new jl(Ip,0);Pk=new jl('checkbox',1);Qk=new jl('color',2);Rk=new jl('date',3);Sk=new jl('datetime',4);Tk=new jl('email',5);Uk=new jl('file',6);Vk=new jl('hidden',7);Wk=new jl('image',8);Xk=new jl('month',9);Yk=new jl(up,10);Zk=new jl('password',11);$k=new jl('radio',12);_k=new jl('range',13);al=new jl('reset',14);bl=new jl('search',15);cl=new jl('submit',16);dl=new jl('tel',17);el=new jl('text',18);fl=new jl('time',19);gl=new jl('url',20);hl=new jl('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Hi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Li(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Hi(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ji(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Ni)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&yp!=(k.b.c&zp)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function pl(a){var b,c;a.e=0;ml();c=(b=T(a.i.b),xk('footer',Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,['footer'])),[(new Sm).a,xk('ul',Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,['filters'])),[xk('li',null,[xk('a',Dk(Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,[(ip(),gp)==b?Jp:null])),'#'),['All'])]),xk('li',null,[xk('a',Dk(Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,[fp==b?Jp:null])),'#active'),['Active'])]),xk('li',null,[xk('a',Dk(Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,[hp==b?Jp:null])),'#completed'),['Completed'])])]),T(a.a)?xk(Ip,Ek(Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,['clear-completed'])),uh(Om.prototype.lb,Om,[a])),['Clear Completed']):null]));return c}
function fm(a){var b,c,d,e;a.g=0;ml();b=a.f.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.f.props['a'],e=(gb(d.a),d.d),xk('li',Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,[e?'checked':null,T(a.c)?'editing':null])),[xk('div',Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,['view'])),[xk(Mp,Ik(Gk(Lk(Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,['toggle'])),(il(),Pk)),e),uh(un.prototype.jb,un,[d])),null),xk('label',Nk(new $wnd.Object,uh(vn.prototype.lb,vn,[a,d])),[(gb(d.b),d.e)]),xk(Ip,Ek(Bk(new $wnd.Object,dd($c(pe,1),wp,2,6,['destroy'])),uh(wn.prototype.lb,wn,[a,d])),null)]),xk(Mp,Jk(Ik(Hk(Mk(Bk(Ck(new $wnd.Object,uh(xn.prototype.w,xn,[a])),dd($c(pe,1),wp,2,6,['edit'])),(gb(a.a),a.d)),uh(yn.prototype.ib,yn,[a,d])),uh(tn.prototype.jb,tn,[a])),uh(zn.prototype.kb,zn,[a,d])),null)]));return c}
function hj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Hp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!fj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Hp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var tp='object',up='number',vp={5:1},wp={3:1},xp={9:1},yp=1048576,zp=1835008,Ap=2097152,Bp=4194304,Cp='__noinit__',Dp={3:1,10:1,7:1,4:1},Ep='null',Fp=17592186044416,Gp={41:1},Hp='delete',Ip='button',Jp='selected',Kp=1411518464,Lp=142606336,Mp='input',Np='header',Op='hashchange',Pp=136314880,Qp='active',Rp='completed';var _,ph,kh,bh=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;qh();sh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=Tp;_.r=function(){var a;return Nh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var gd,hd,jd;sh(56,1,{},Oh);_.K=function(a){var b;b=new Oh;b.e=4;a>1?(b.c=Th(this,a-1)):(b.c=this);return b};_.L=function(){Mh(this);return this.b};_.M=function(){return Nh(this)};_.N=function(){Mh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Mh(this),this.k)};_.e=0;_.g=0;var Lh=1;var me=Qh(1);var ce=Qh(56);sh(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var xd=Qh(81);sh(82,1,vp,G);_.s=function(){Db(this.a)};var ud=Qh(82);sh(36,1,{},H);_.t=function(){return this.a.s(),null};var vd=Qh(36);sh(83,1,{},I);var wd=Qh(83);var J;sh(44,1,{44:1},Q);_.b=0;_.c=false;_.d=0;var yd=Qh(44);sh(232,1,xp);_.r=function(){var a;return Nh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var Bd=Qh(232);sh(18,232,xp,X);_.u=function(){S(this)};_.v=Sp;_.a=false;_.d=0;_.j=false;var Ad=Qh(18);sh(127,1,{},Y);_.t=function(){return U(this.a)};var zd=Qh(127);sh(16,232,{9:1,16:1},jb);_.u=function(){ab(this)};_.v=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Dd=Qh(16);sh(126,1,vp,kb);_.s=function(){bb(this.a)};var Cd=Qh(126);sh(17,232,{9:1,17:1},wb,xb);_.u=function(){lb(this)};_.v=function(){return 1==(this.c&7)};_.c=0;var Id=Qh(17);sh(139,1,{},yb);_.s=function(){R(this.a)};var Ed=Qh(139);sh(140,1,vp,zb);_.s=function(){nb(this.a)};var Fd=Qh(140);sh(141,1,vp,Ab);_.s=function(){qb(this.a)};var Gd=Qh(141);sh(142,1,{},Bb);_.w=function(a){ob(this.a,a)};var Hd=Qh(142);sh(103,1,{},Eb);_.a=0;_.b=0;_.c=0;var Jd=Qh(103);sh(168,1,xp,Gb);_.u=function(){Fb(this)};_.v=Sp;_.a=false;var Kd=Qh(168);sh(66,232,{9:1,66:1},Kb);_.u=function(){Hb(this)};_.v=function(){return 2==(3&this.a)};_.a=0;var Md=Qh(66);sh(102,1,{},Pb);var Ld=Qh(102);sh(143,1,{},_b);_.r=function(){var a;return Mh(Nd),Nd.k+'@'+(a=jk(this)>>>0,a.toString(16))};_.a=0;var Qb;var Nd=Qh(143);sh(115,1,{});var Qd=Qh(115);sh(108,1,{},hc);_.w=function(a){fc(this.a,a)};var Od=Qh(108);sh(109,1,vp,ic);_.s=function(){gc(this.a,this.b)};var Pd=Qh(109);sh(15,1,xp,pc);_.u=function(){kc(this)};_.v=function(){return this.i<0};_.r=function(){var a;return Mh(Sd),Sd.k+'@'+(a=jk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Sd=Qh(15);sh(125,1,vp,qc);_.s=function(){nc(this.a)};var Rd=Qh(125);sh(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=Yp;_.C=function(){return Pj(Nj(Ri((this.i==null&&(this.i=ad(re,wp,4,0,0,1)),this.i)),new ki),new Tj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){tc(this,vc(this.A(uc(this,this.g))));Xc(this)};_.r=function(){return uc(this,this.F())};_.e=Cp;_.j=true;var re=Qh(4);sh(10,4,{3:1,10:1,4:1});var fe=Qh(10);sh(7,10,Dp);var ne=Qh(7);sh(57,7,Dp);var je=Qh(57);sh(78,57,Dp);var Wd=Qh(78);sh(35,78,{35:1,3:1,10:1,7:1,4:1},Ac);_.F=function(){zc(this);return this.c};_.H=function(){return rd(this.b)===rd(xc)?null:this.b};var xc;var Td=Qh(35);var Ud=Qh(0);sh(215,1,{});var Vd=Qh(215);var Cc=0,Dc=0,Ec=-1;sh(93,215,{},Sc);var Oc;var Xd=Qh(93);var Vc;sh(226,1,{});var Zd=Qh(226);sh(79,226,{},Zc);var Yd=Qh(79);sh(45,1,{45:1},Bh);_.I=function(){var a;a=this.a;if(rd(a)===rd(zh)){a=this.a;if(rd(a)===rd(zh)){a=this.b.I();this.a=Dh(this.a,a);this.b=null}}return a};var zh;var $d=Qh(45);var Fh;sh(76,1,{73:1});_.r=Sp;var _d=Qh(76);sh(80,7,Dp);var he=Qh(80);sh(144,80,Dp,Jh);var ae=Qh(144);gd={3:1,74:1,28:1};var be=Qh(74);sh(42,1,{3:1,42:1});var le=Qh(42);hd={3:1,28:1,42:1};var de=Qh(225);sh(30,1,{3:1,28:1,30:1});_.o=function(a){return this===a};_.q=Tp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ee=Qh(30);sh(59,7,Dp,Zh);var ge=Qh(59);sh(29,42,{3:1,28:1,29:1,42:1},$h);_.o=function(a){return md(a,29)&&a.a==this.a};_.q=Sp;_.r=function(){return ''+this.a};_.a=0;var ie=Qh(29);var ai;sh(289,1,{});sh(84,57,Dp,di);_.A=function(a){return new TypeError(a)};var ke=Qh(84);jd={3:1,73:1,28:1,2:1};var pe=Qh(2);sh(77,76,{73:1},ji);var oe=Qh(77);sh(293,1,{});sh(71,1,{},ki);_.S=function(a){return a.e};var qe=Qh(71);sh(60,7,Dp,li);var se=Qh(60);sh(227,1,{40:1});_.Q=Xp;_.V=function(){return new Cj(this,0)};_.W=function(){return new Qj(null,this.V())};_.T=function(a){throw eh(new li('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Ej('[',']');for(b=this.R();b.Y();){a=b.Z();Dj(c,a===this?'(this Collection)':a==null?Ep:wh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var te=Qh(227);sh(230,1,{213:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!md(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new zi((new wi(d)).a);c.b;){b=yi(c);if(!oi(this,b)){return false}}return true};_.q=function(){return Si(new wi(this))};_.r=function(){var a,b,c;c=new Ej('{','}');for(b=new zi((new wi(this)).a);b.b;){a=yi(b);Dj(c,pi(this,a._())+'='+pi(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ee=Qh(230);sh(101,230,{213:1});var we=Qh(101);sh(229,227,{40:1,236:1});_.V=function(){return new Cj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!md(a,21)){return false}b=a;if(ui(b.a)!=this.U()){return false}return mi(this,b)};_.q=function(){return Si(this)};var Fe=Qh(229);sh(21,229,{21:1,40:1,236:1},wi);_.R=function(){return new zi(this.a)};_.U=Vp;var ve=Qh(21);sh(22,1,{},zi);_.X=Up;_.Z=function(){return yi(this)};_.Y=Wp;_.b=false;var ue=Qh(22);sh(228,227,{40:1,233:1});_.V=function(){return new Cj(this,16)};_.$=function(a,b){throw eh(new li('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,13)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Pi(f);for(c=new Pi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(rd(b)===rd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Ti(this)};_.R=function(){return new Ai(this)};var ye=Qh(228);sh(92,1,{},Ai);_.X=Up;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Hi(this.b,this.a++)};_.a=0;var xe=Qh(92);sh(43,227,{40:1},Bi);_.R=function(){var a;a=new zi((new wi(this.a)).a);return new Ci(a)};_.U=Vp;var Ae=Qh(43);sh(96,1,{},Ci);_.X=Up;_.Y=function(){return this.a.b};_.Z=function(){var a;a=yi(this.a);return a.ab()};var ze=Qh(96);sh(94,1,Gp);_.o=function(a){var b;if(!md(a,41)){return false}b=a;return Ui(this.a,b._())&&Ui(this.b,b.ab())};_._=Sp;_.ab=Wp;_.q=function(){return tj(this.a)^tj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var Be=Qh(94);sh(95,94,Gp,Di);var Ce=Qh(95);sh(231,1,Gp);_.o=function(a){var b;if(!md(a,41)){return false}b=a;return Ui(this.b.value[0],b._())&&Ui(pj(this),b.ab())};_.q=function(){return tj(this.b.value[0])^tj(pj(this))};_.r=function(){return this.b.value[0]+'='+pj(this)};var De=Qh(231);sh(13,228,{3:1,13:1,40:1,233:1},Ni,Oi);_.$=function(a,b){ek(this.a,a,b)};_.T=function(a){return Fi(this,a)};_.Q=function(a){Gi(this,a)};_.R=function(){return new Pi(this)};_.U=function(){return this.a.length};var He=Qh(13);sh(14,1,{},Pi);_.X=Up;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ge=Qh(14);sh(37,101,{3:1,37:1,213:1},Vi);var Ie=Qh(37);sh(63,1,{},_i);_.Q=Xp;_.R=function(){return new aj(this)};_.b=0;var Ke=Qh(63);sh(64,1,{},aj);_.X=Up;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Je=Qh(64);var dj;sh(61,1,{},nj);_.Q=Xp;_.R=function(){return new oj(this)};_.b=0;_.c=0;var Ne=Qh(61);sh(62,1,{},oj);_.X=Up;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new qj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Le=Qh(62);sh(114,231,Gp,qj);_._=function(){return this.b.value[0]};_.ab=function(){return pj(this)};_.bb=function(a){return lj(this.a,this.b.value[0],a)};_.c=0;var Me=Qh(114);sh(129,1,{});_.X=Zp;_.cb=function(){return this.d};_.db=Yp;_.d=0;_.e=0;var Re=Qh(129);sh(65,129,{});var Oe=Qh(65);sh(97,1,{});_.X=Zp;_.cb=Wp;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Qe=Qh(97);sh(98,97,{},Aj);_.X=function(a){xj(this,a)};_.eb=function(a){return yj(this,a)};var Pe=Qh(98);sh(19,1,{},Cj);_.cb=Sp;_.db=function(){Bj(this);return this.c};_.X=function(a){Bj(this);this.d.X(a)};_.eb=function(a){Bj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Se=Qh(19);sh(58,1,{},Ej);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Te=Qh(58);sh(34,1,{},Fj);_.S=function(a){return a};var Ue=Qh(34);sh(38,1,{},Gj);var Ve=Qh(38);sh(128,1,{});_.c=false;var df=Qh(128);sh(23,128,{},Qj);var cf=Qh(23);sh(72,1,{},Tj);_.fb=function(a){return ad(me,wp,1,a,5,1)};var We=Qh(72);sh(131,65,{},Vj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Wj(this,a)));return this.b};_.b=false;var Ye=Qh(131);sh(134,1,{},Wj);_.w=function(a){Uj(this.a,this.b,a)};var Xe=Qh(134);sh(130,65,{},Yj);_.eb=function(a){return this.b.eb(new Zj(this,a))};var $e=Qh(130);sh(133,1,{},Zj);_.w=function(a){Xj(this.a,this.b,a)};var Ze=Qh(133);sh(132,1,{},_j);_.w=function(a){$j(this,a)};var _e=Qh(132);sh(135,1,{},ak);_.w=function(a){};var af=Qh(135);sh(136,1,{},ck);_.w=function(a){bk(this,a)};var bf=Qh(136);sh(291,1,{});sh(288,1,{});var ik=0;var kk,lk=0,mk;sh(904,1,{});sh(927,1,{});sh(169,1,{},zk);_.fb=function(a){return new Array(a)};var ef=Qh(169);sh(256,$wnd.Function,{},Ak);_.hb=function(a){yk(this.a,this.b,a)};sh(6,30,{3:1,28:1,30:1,6:1},jl);var Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl;var ff=Rh(6,kl);var ll;sh(255,$wnd.Function,{},nl);_.J=function(a){return Fb(ll),ll=null,null};sh(185,1,{});var Qf=Qh(185);sh(186,185,{});_.e=0;var Uf=Qh(186);sh(187,186,xp,vl);_.u=$p;_.v=_p;_.r=function(){var a;return Mh(pf),pf.k+'@'+(a=jk(this)>>>0,a.toString(16))};var rl=0;var pf=Qh(187);sh(188,1,vp,wl);_.s=function(){sl(this.a)};var gf=Qh(188);sh(189,1,{},xl);_.t=function(){return ul(this.a)};var hf=Qh(189);sh(191,1,{},yl);_.t=function(){return pl(this.a)};var jf=Qh(191);sh(190,1,{},zl);_.s=function(){ql(this.a)};var kf=Qh(190);sh(206,1,{});var Pf=Qh(206);sh(207,206,{});_.d=0;var Tf=Qh(207);sh(208,207,xp,Fl);_.u=aq;_.v=bq;_.r=function(){var a;return Mh(of),of.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Dl=0;var of=Qh(208);sh(209,1,vp,Gl);_.s=cq;var lf=Qh(209);sh(210,1,{},Hl);_.s=function(){Cl(this.a)};var mf=Qh(210);sh(211,1,{},Il);_.t=function(){return Bl(this.a)};var nf=Qh(211);sh(177,1,{});_.g='';var bg=Qh(177);sh(178,177,{});_.e=0;var Wf=Qh(178);sh(179,178,xp,Ul);_.u=$p;_.v=_p;_.r=function(){var a;return Mh(vf),vf.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Ol=0;var vf=Qh(179);sh(180,1,vp,Vl);_.s=function(){Pl(this.a)};var qf=Qh(180);sh(182,1,{},Wl);_.t=function(){return Ml(this.a)};var rf=Qh(182);sh(183,1,vp,Xl);_.s=function(){Jl(this.a)};var sf=Qh(183);sh(181,1,{},Yl);_.s=function(){ql(this.a)};var tf=Qh(181);sh(184,1,vp,Zl);_.s=function(){Sl(this.a,this.b)};var uf=Qh(184);sh(173,1,{});_.j=false;var eg=Qh(173);sh(193,173,{});_.g=0;var Yf=Qh(193);sh(194,193,xp,tm);_.u=function(){kc(this.e)};_.v=function(){return this.e.i<0};_.r=function(){var a;return Mh(Gf),Gf.k+'@'+(a=jk(this)>>>0,a.toString(16))};var hm=0;var Gf=Qh(194);sh(195,1,vp,um);_.s=function(){im(this.a)};var wf=Qh(195);sh(198,1,{},vm);_.t=function(){return fm(this.a)};var xf=Qh(198);sh(196,1,{},wm);_.t=function(){return lm(this.a)};var yf=Qh(196);sh(49,1,vp,xm);_.s=function(){sm(this.a,Sn(this.b))};var zf=Qh(49);sh(68,1,vp,ym);_.s=function(){cm(this.a,this.b)};var Af=Qh(68);sh(199,1,vp,zm);_.s=function(){mm(this.a,this.b)};var Bf=Qh(199);sh(200,1,vp,Am);_.s=function(){nm(this.a,this.b)};var Cf=Qh(200);sh(197,1,{},Bm);_.s=function(){gm(this.a)};var Df=Qh(197);sh(201,1,vp,Cm);_.s=function(){$l(this.a,this.b)};var Ef=Qh(201);sh(202,1,vp,Dm);_.s=function(){dm(this.a)};var Ff=Qh(202);sh(155,1,{});var ig=Qh(155);sh(156,155,{});_.d=0;var $f=Qh(156);sh(157,156,xp,Km);_.u=aq;_.v=bq;_.r=function(){var a;return Mh(Kf),Kf.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Im=0;var Kf=Qh(157);sh(158,1,vp,Lm);_.s=cq;var Hf=Qh(158);sh(159,1,{},Mm);_.s=function(){Cl(this.a)};var If=Qh(159);sh(160,1,{},Nm);_.t=function(){return Gm(this.a)};var Jf=Qh(160);sh(261,$wnd.Function,{},Om);_.lb=function(a){Io(this.a.g)};sh(171,1,{},Pm);var Lf=Qh(171);sh(87,1,{},Qm);var Mf=Qh(87);var Rm;sh(192,1,{},Sm);var Nf=Qh(192);sh(91,1,{},Tm);var Of=Qh(91);var Um;sh(262,$wnd.Function,{},Vm);_.mb=function(a){return new Ym(a)};var Wm;sh(175,$wnd.React.Component,{},Ym);rh(ph[1],_);_.componentWillUnmount=function(){ol(this.a)};_.render=function(){return tl(this.a)};_.shouldComponentUpdate=dq;var Rf=Qh(175);sh(272,$wnd.Function,{},Zm);_.mb=function(a){return new an(a)};var $m;sh(203,$wnd.React.Component,{},an);rh(ph[1],_);_.componentWillUnmount=function(){Al(this.a)};_.render=function(){return El(this.a)};_.shouldComponentUpdate=eq;var Sf=Qh(203);sh(260,$wnd.Function,{},bn);_.mb=function(a){return new en(a)};var cn;sh(174,$wnd.React.Component,{},en);rh(ph[1],_);_.componentWillUnmount=function(){ol(this.a)};_.render=function(){return Ql(this.a)};_.shouldComponentUpdate=dq;var Vf=Qh(174);sh(263,$wnd.Function,{},fn);_.mb=function(a){return new jn(a)};var gn;sh(176,$wnd.React.Component,{},jn);rh(ph[1],_);_.componentDidUpdate=function(a){qm(this.a)};_.componentWillUnmount=function(){em(this.a)};_.render=function(){return jm(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.g};var Xf=Qh(176);sh(254,$wnd.Function,{},kn);_.mb=function(a){return new nn(a)};var ln;sh(99,$wnd.React.Component,{},nn);rh(ph[1],_);_.componentWillUnmount=function(){Al(this.a)};_.render=function(){return Jm(this.a)};_.shouldComponentUpdate=eq;var Zf=Qh(99);sh(258,$wnd.Function,{},on);_.kb=function(a){Kl(this.a,a)};sh(259,$wnd.Function,{},pn);_.jb=function(a){Rl(this.a,a)};sh(170,1,{},qn);var _f=Qh(170);sh(90,1,{},rn);var ag=Qh(90);var sn;sh(270,$wnd.Function,{},tn);_.jb=function(a){km(this.a,a)};sh(264,$wnd.Function,{},un);_.jb=function(a){mo(this.a)};sh(266,$wnd.Function,{},vn);_.lb=function(a){om(this.a,this.b)};sh(267,$wnd.Function,{},wn);_.lb=function(a){_l(this.a,this.b)};sh(268,$wnd.Function,{},xn);_.w=function(a){am(this.a,a)};sh(269,$wnd.Function,{},yn);_.ib=function(a){pm(this.a,this.b)};sh(271,$wnd.Function,{},zn);_.kb=function(a){bm(this.a,this.b,a)};sh(172,1,{},Bn);var cg=Qh(172);sh(88,1,{},Cn);var dg=Qh(88);var Dn;sh(253,$wnd.Function,{},En);_.jb=function(a){Em(this.a,a)};sh(100,1,{},Fn);_.S=function(a){return An(new Bn,a)};var fg=Qh(100);sh(70,1,{},Gn);var gg=Qh(70);sh(89,1,{},Hn);var hg=Qh(89);var In;sh(86,1,{},Jn);var jg=Qh(86);sh(48,1,{48:1});var Qg=Qh(48);sh(161,48,{9:1,48:1},Wn);_.u=$p;_.v=_p;_.r=function(){var a;return Mh(rg),rg.k+'@'+(a=jk(this)>>>0,a.toString(16))};var rg=Qh(161);sh(162,1,vp,Xn);_.s=function(){Qn(this.a)};var kg=Qh(162);sh(164,1,{},Yn);_.s=function(){Ln(this.a)};var lg=Qh(164);sh(165,1,{},Zn);_.s=function(){Mn(this.a)};var mg=Qh(165);sh(166,1,vp,$n);_.s=function(){Kn(this.a,this.b)};var ng=Qh(166);sh(167,1,vp,_n);_.s=function(){Tn(this.a)};var og=Qh(167);sh(67,1,vp,ao);_.s=function(){Pn(this.a)};var pg=Qh(67);sh(163,1,{},bo);_.t=function(){var a;return a=(Gh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var qg=Qh(163);sh(50,1,{50:1});_.d=false;var Zg=Qh(50);sh(51,50,{9:1,257:1,51:1,50:1},no);_.u=$p;_.o=function(a){return go(this,a)};_.q=function(){return this.c.d};_.v=_p;_.r=function(){var a;return Mh(Hg),Hg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var co=0;var Hg=Qh(51);sh(204,1,vp,oo);_.s=function(){eo(this.a)};var sg=Qh(204);sh(205,1,vp,po);_.s=function(){jo(this.a)};var tg=Qh(205);sh(116,115,{});var Tg=Qh(116);sh(26,116,xp,xo);_.u=fq;_.v=gq;_.r=function(){var a;return Mh(Cg),Cg.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Cg=Qh(26);sh(118,1,vp,yo);_.s=function(){ro(this.a)};var ug=Qh(118);sh(117,1,vp,zo);_.s=function(){uo(this.a)};var vg=Qh(117);sh(123,1,vp,Ao);_.s=function(){cc(this.a,this.b,true)};var wg=Qh(123);sh(124,1,{},Bo);_.t=function(){return qo(this.a,this.c,this.b)};_.b=false;var xg=Qh(124);sh(119,1,{},Co);_.t=function(){return vo(this.a)};var yg=Qh(119);sh(120,1,{},Do);_.t=function(){return _h(jh(Lj(dc(this.a))))};var zg=Qh(120);sh(121,1,{},Eo);_.t=function(){return _h(jh(Lj(Mj(dc(this.a),new lp))))};var Ag=Qh(121);sh(122,1,{},Fo);_.t=function(){return wo(this.a)};var Bg=Qh(122);sh(46,1,{46:1});var Yg=Qh(46);sh(145,46,{9:1,46:1},Mo);_.u=function(){kc(this.a)};_.v=function(){return this.a.i<0};_.r=function(){var a;return Mh(Gg),Gg.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Gg=Qh(145);sh(146,1,vp,No);_.s=function(){Jo(this.a,this.b)};_.b=false;var Dg=Qh(146);sh(147,1,vp,Oo);_.s=function(){Vn(this.b,this.a)};var Eg=Qh(147);sh(148,1,vp,Po);_.s=function(){Ko(this.a)};var Fg=Qh(148);sh(47,1,{47:1});var ah=Qh(47);sh(149,47,{9:1,47:1},Xo);_.u=fq;_.v=gq;_.r=function(){var a;return Mh(Ng),Ng.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Ng=Qh(149);sh(150,1,vp,Yo);_.s=function(){So(this.a)};var Ig=Qh(150);sh(154,1,vp,Zo);_.s=function(){Wo(this.a,null)};var Jg=Qh(154);sh(151,1,{},$o);_.t=function(){var a;return a=Sn(this.a.g),o(Qp,a)?(ip(),fp):o(Rp,a)?(ip(),hp):(ip(),gp)};var Kg=Qh(151);sh(152,1,{},_o);_.t=function(){return Uo(this.a)};var Lg=Qh(152);sh(153,1,{},ap);_.s=function(){Vo(this.a)};var Mg=Qh(153);sh(138,1,{},bp);_.handleEvent=function(a){Nn(this.a,a)};var Og=Qh(138);sh(105,1,{},cp);_.I=function(){return new Wn};var Pg=Qh(105);var dp;sh(31,30,{3:1,28:1,30:1,31:1},jp);var fp,gp,hp;var Rg=Rh(31,kp);sh(107,1,{},lp);_.gb=function(a){return !io(a)};var Sg=Qh(107);sh(111,1,{},mp);_.gb=function(a){return io(a)};var Ug=Qh(111);sh(112,1,{},np);_.w=function(a){to(this.a,a)};var Vg=Qh(112);sh(110,1,{},op);_.w=function(a){Ho(this.a,a)};_.a=false;var Wg=Qh(110);sh(104,1,{},pp);_.I=function(){return new Mo(new xo)};var Xg=Qh(104);sh(113,1,{},qp);_.gb=function(a){return Ro(this.a,a)};var $g=Qh(113);sh(106,1,{},rp);_.I=function(){return new Xo(new xo,this.a.I())};var _g=Qh(106);var td=Sh('D');var sp=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=nh;lh(yh);oh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();