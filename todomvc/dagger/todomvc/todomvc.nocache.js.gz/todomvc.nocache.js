function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='A55DDD9057679B2C2AC0847F581BF32A',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'A55DDD9057679B2C2AC0847F581BF32A';function o(){}
function ok(){}
function Dh(){}
function zh(){}
function Ib(){}
function Mc(){}
function Tc(){}
function Lj(){}
function Mj(){}
function Sm(){}
function _m(){}
function jn(){}
function sn(){}
function Bn(){}
function Lo(){}
function qp(){}
function yp(){}
function Zp(){}
function $p(){}
function Yq(){}
function Rc(a){Qc()}
function Wm(a){Vm=a}
function dn(a){cn=a}
function nn(a){mn=a}
function wn(a){vn=a}
function Fn(a){En=a}
function Lh(){Lh=zh}
function Ji(){Ai(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function mb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function hc(a){this.a=a}
function nc(a){this.a=a}
function $h(a){this.a=a}
function si(a){this.a=a}
function xi(a){this.a=a}
function yi(a){this.a=a}
function wi(a){this.b=a}
function Li(a){this.c=a}
function Jj(a){this.a=a}
function Oj(a){this.a=a}
function fl(a){this.a=a}
function gl(a){this.a=a}
function hl(a){this.a=a}
function il(a){this.a=a}
function jl(a){this.a=a}
function ol(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Jl(a){this.a=a}
function Ll(a){this.a=a}
function Ml(a){this.a=a}
function jm(a){this.a=a}
function km(a){this.a=a}
function lm(a){this.a=a}
function rm(a){this.a=a}
function tm(a){this.a=a}
function um(a){this.a=a}
function Cm(a){this.a=a}
function Dm(a){this.a=a}
function Em(a){this.a=a}
function Fm(a){this.a=a}
function Jm(a){this.a=a}
function Lm(a){this.a=a}
function Nm(a){this.a=a}
function $m(a){this.a=a}
function hn(a){this.a=a}
function rn(a){this.a=a}
function An(a){this.a=a}
function Jn(a){this.a=a}
function Kn(a){this.a=a}
function Ln(a){this.a=a}
function Nn(a){this.a=a}
function Pn(a){this.a=a}
function Qn(a){this.a=a}
function Tn(a){this.a=a}
function $n(a){this.a=a}
function bo(a){this.a=a}
function eo(a){this.a=a}
function Go(a){this.a=a}
function Ho(a){this.a=a}
function Io(a){this.a=a}
function Jo(a){this.a=a}
function Ko(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function gp(a){this.a=a}
function hp(a){this.a=a}
function kp(a){this.a=a}
function lp(a){this.a=a}
function mp(a){this.a=a}
function np(a){this.a=a}
function Bp(a){this.a=a}
function Cp(a){this.a=a}
function Mp(a){this.a=a}
function Np(a){this.a=a}
function Op(a){this.a=a}
function Pp(a){this.a=a}
function Qp(a){this.a=a}
function Rp(a){this.a=a}
function Sp(a){this.a=a}
function _p(a){this.a=a}
function aq(a){this.a=a}
function bq(a){this.a=a}
function Kj(a,b){a.a=b}
function Om(a,b){a.c=b}
function Pm(a,b){a.d=b}
function Qm(a,b){a.e=b}
function Rm(a,b){a.f=b}
function _n(a,b){a.j=b}
function ao(a,b){a.k=b}
function ik(a,b){a.key=b}
function dk(a,b){ck(a,b)}
function sp(a,b){To(b,a)}
function Lq(a){lj(this,a)}
function Pq(a){ci(this,a)}
function Tq(){jc(this.c)}
function Uq(){jc(this.b)}
function Vi(){this.a=cj()}
function hj(){this.a=cj()}
function kc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function gb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function kb(a){Yb((J(),a))}
function kh(a){return a.b}
function Xq(){jc(this.a.b)}
function Wq(){jc(this.a.c)}
function Vq(){nb(this.a.a)}
function $i(){$i=zh;Zi=aj()}
function J(){J=zh;I=new F}
function dc(){this.b=new Pi}
function Rq(){this.a.o=true}
function Nq(){return this.a}
function Oq(){return this.b}
function Lb(a){a.a=-4&a.a|1}
function tb(a,b){a.b=oj(b)}
function Pl(a,b){ap(a.j,b)}
function cc(a,b){oi(a.b,b)}
function rp(a,b){_o(a.b,b)}
function Nj(a,b){Dj(a.a,b)}
function C(a,b){ab(a.f,b.f)}
function ac(a,b,c){ni(a.b,b,c)}
function cl(a){nb(a.b);R(a.a)}
function zo(a){R(a.a);cb(a.b)}
function V(a){gd(a,9)&&a.u()}
function Bl(a){nb(a.a);cb(a.b)}
function Sj(a,b){a.splice(b,1)}
function gi(a,b){return a===b}
function Ql(a,b){return a.f=b}
function Di(a,b){return a.a[b]}
function Kq(){return Wj(this)}
function ii(a){rc.call(this,a)}
function Xm(a){ek.call(this,a)}
function en(a){ek.call(this,a)}
function on(a){ek.call(this,a)}
function xn(a){ek.call(this,a)}
function Gn(a){ek.call(this,a)}
function Jq(a){return this===a}
function Qq(){return J(),J(),I}
function Uc(a,b){return Th(a,b)}
function Oh(a){Nh(a);return a.k}
function Oo(a){cb(a.b);cb(a.a)}
function db(a){J();Xb(a);a.e=-2}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function Sq(){mk(this.a,false)}
function di(){oc(this);this.B()}
function Mq(){return qi(this.a)}
function cj(){$i();return new Zi}
function Cj(a,b){a.O(b);return a}
function qj(a,b){while(a._(b));}
function Dj(a,b){Kj(a,Cj(a.a,b))}
function Ym(a,b){jo(new ko(a),b)}
function fn(a,b){lo(new mo(a),b)}
function pn(a,b){no(new oo(a),b)}
function yn(a,b){po(new qo(a),b)}
function Hn(a,b){ro(new so(a),b)}
function v(a,b,c){s(a,new H(c),b)}
function lo(a,b){Om(b,a.b.a.D())}
function no(a,b){Pm(b,a.b.b.D())}
function qi(a){return a.a.b+a.b.b}
function W(a){return !!a&&a.c.i<0}
function sh(){qh==null&&(qh=[])}
function zc(){zc=zh;!!(Qc(),Pc)}
function tc(){tc=zh;sc=new o}
function Jc(){Jc=zh;Ic=new Mc}
function pp(){pp=zh;op=new qp}
function Gp(a){ib(a.d);return a.f}
function Bo(a){ib(a.b);return a.e}
function Ro(a){ib(a.a);return a.d}
function qk(a,b){a.ref=b;return a}
function rk(a,b){a.href=b;return a}
function hk(a,b){this.a=a;this.b=b}
function ic(a,b){this.a=a;this.b=b}
function Yh(a,b){this.a=a;this.b=b}
function zi(a,b){this.a=a;this.b=b}
function Gj(a,b){this.a=a;this.b=b}
function Kl(a,b){this.a=a;this.b=b}
function mm(a,b){this.a=a;this.b=b}
function nm(a,b){this.a=a;this.b=b}
function om(a,b){this.a=a;this.b=b}
function pm(a,b){this.a=a;this.b=b}
function qm(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function Rn(a,b){this.a=a;this.b=b}
function Sn(a,b){this.a=a;this.b=b}
function Un(a,b){this.a=a;this.b=b}
function Vn(a,b){this.a=a;this.b=b}
function $k(a,b){Yh.call(this,a,b)}
function Qj(a,b,c){a.splice(b,0,c)}
function ej(a,b){return a.a.get(b)}
function Zc(a){return new Array(a)}
function Wn(a){return Xn(new Zn,a)}
function Mn(){this.a=jk((ln(),kn))}
function Mm(){this.a=jk((bn(),an))}
function Zn(){this.a=jk((un(),tn))}
function co(){this.a=jk((Dn(),Cn))}
function Km(){this.a=jk((Um(),Tm))}
function Co(a){Ao(a,(ib(a.b),a.e))}
function Xp(a,b){Yh.call(this,a,b)}
function ip(a,b){this.a=a;this.b=b}
function zp(a,b){this.a=a;this.b=b}
function Mo(a,b){this.a=a;this.b=b}
function Ap(a,b){this.b=a;this.a=b}
function Bk(a,b){a.value=b;return a}
function pi(a){a.a=new Vi;a.b=new hj}
function Ai(a){a.a=Wc(ce,fq,1,0,5,1)}
function Gc(a){$wnd.clearTimeout(a)}
function mi(a){return !a?null:a.X()}
function Sb(a){return !a.d?a:Sb(a.d)}
function nj(a){return a!=null?r(a):0}
function ld(a){return a==null?null:a}
function jd(a){return typeof a===dq}
function Hc(){wc!=0&&(wc=0);yc=-1}
function So(a){To(a,(ib(a.a),!a.d))}
function ul(a){return wl(a.a,a.b,a.c)}
function vm(a){return xm(a.a,a.b,a.c)}
function Gm(a){return Im(a.a,a.b,a.c)}
function B(a,b,c){return t(a,c,2048,b)}
function A(a,b,c){t(a,new G(b),c,null)}
function Rj(a,b){Pj(b,0,a,0,b.length)}
function Hj(a,b){a.w(Yn(Wn(b.c.e),b))}
function wk(a,b){a.onBlur=b;return a}
function sk(a,b){a.onClick=b;return a}
function xk(a,b){a.onChange=b;return a}
function uk(a,b){a.checked=b;return a}
function lb(a){this.c=new Ji;this.b=a}
function Gb(a){this.d=oj(a);this.b=100}
function Fh(a){this.b=oj(a);this.a=this}
function sb(a){J();rb(a);vb(a,2,true)}
function ib(a){var b;Tb((J(),b=Ob,b),a)}
function X(a){return !(!!a&&1==(a.c&7))}
function Wj(a){return a.$H||(a.$H=++Vj)}
function fi(a,b){return a.charCodeAt(b)}
function gd(a,b){return a!=null&&ed(a,b)}
function gc(a,b){ec(a,b,false);hb(a.d)}
function ck(a,b){for(var c in a){b(c)}}
function _c(a,b,c){return {l:a,m:b,h:c}}
function Uj(b,c,d){try{b[c]=d}catch(a){}}
function Bj(a,b){wj.call(this,a);this.a=b}
function rc(a){this.c=a;oc(this);this.B()}
function P(){this.a=Wc(ce,fq,1,100,5,1)}
function Pi(){this.a=new Vi;this.b=new hj}
function $j(){$j=zh;Xj=new o;Zj=new o}
function yk(a,b){a.onKeyDown=b;return a}
function vk(a,b){a.defaultValue=b;return a}
function tk(a){a.autoFocus=true;return a}
function Nh(a){if(a.k!=null){return}Vh(a)}
function pc(a,b){a.b=b;b!=null&&Uj(b,oq,a)}
function lj(a,b){while(a.T()){Nj(b,a.U())}}
function Xn(a,b){return ik(a.a,oj(''+b)),a}
function u(a,b){return new yb(oj(a),null,b)}
function kd(a){return typeof a==='string'}
function hd(a){return typeof a==='boolean'}
function Jb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&vb(a.f,5,true)}
function fc(a,b){cc(b.c.c,a);gd(b,9)&&b.u()}
function Xi(a,b){var c;c=a[sq];c.call(a,b)}
function fm(a){A((J(),J(),I),new rm(a),Bq)}
function Do(a){A((J(),J(),I),new Jo(a),Bq)}
function Vo(a){A((J(),J(),I),new Yo(a),Bq)}
function tp(a){A((J(),J(),I),new Bp(a),Bq)}
function Ip(a){W((ib(a.d),a.f))&&Kp(a,null)}
function ep(a){return _h(S(a.e).a-S(a.a).a)}
function Ac(a,b,c){return a.apply(b,c);var d}
function $(a,b,c){Lb(oj(c));K(a.a[b],oj(c))}
function kj(a,b,c){this.a=a;this.b=b;this.c=c}
function vl(a,b,c){this.a=a;this.b=b;this.c=c}
function Ck(a,b){a.onDoubleClick=b;return a}
function Yn(a,b){a.a.props['a']=b;return a.a}
function oc(a){a.d&&a.b!==nq&&a.B();return a}
function Rh(a){var b;b=Qh(a);Xh(a,b);return b}
function $l(a){nb(a.b);R(a.d);cb(a.c);cb(a.a)}
function Cl(a,b){A((J(),J(),I),new Kl(a,b),Bq)}
function am(a,b){A((J(),J(),I),new qm(a,b),Bq)}
function dm(a,b){A((J(),J(),I),new om(a,b),Bq)}
function em(a,b){A((J(),J(),I),new nm(a,b),Bq)}
function gm(a,b){A((J(),J(),I),new mm(a,b),Bq)}
function ap(a,b){A((J(),J(),I),new ip(a,b),Bq)}
function wp(a,b){A((J(),J(),I),new zp(a,b),Bq)}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function Dl(a,b){var c;c=b.target;El(a,c.value)}
function Bi(a,b){a.a[a.a.length]=b;return true}
function jp(a,b){this.a=a;this.c=b;this.b=false}
function wm(a,b,c){this.a=a;this.b=b;this.c=c}
function Hm(a,b,c){this.a=a;this.b=b;this.c=c}
function mo(a){this.b=a;this.a=new sl(this.b.a)}
function oo(a){this.b=a;this.a=new Ml(this.b.b)}
function F(){this.f=new bb;this.a=new Gb(this.f)}
function cp(a){ci(new xi(a.g),new hc(a));pi(a.g)}
function Fb(a){while(true){if(!Eb(a)){break}}}
function bm(a,b){return Lh(),Xl(a,b)?true:false}
function dj(a,b){return !(a.a.get(b)===undefined)}
function Yc(a){return Array.isArray(a)&&a.ob===Dh}
function sj(a){if(!a.d){a.d=a.b.N();a.c=a.b.P()}}
function Hb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Ej(a,b,c){if(a.a.ab(c)){a.b=true;b.w(c)}}
function qb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function Nc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Fi(a,b){var c;c=a.a[b];Sj(a.a,b);return c}
function ui(a){var b;b=a.a.U();a.b=ti(a);return b}
function $o(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function Gh(a){oj(a);return gd(a,55)?a:new Fh(a)}
function zj(a){vj(a);return new Bj(a,new Ij(a.a))}
function Qc(){Qc=zh;var a;!Sc();a=new Tc;Pc=a}
function Ih(){Ih=zh;Hh=$wnd.window.document}
function bi(){bi=zh;ai=Wc($d,fq,30,256,0,1)}
function Dp(a){return gi(Iq,a)||gi(Dq,a)||gi('',a)}
function dp(a){return Lh(),0==S(a.e).a?true:false}
function dl(a){return Lh(),S(a.d.b).a>0?true:false}
function ri(a,b){if(b){return li(a.a,b)}return false}
function oj(a){if(a==null){throw kh(new di)}return a}
function pj(a){if(a==null){throw kh(new ei)}return a}
function bk(){if(Yj==256){Xj=Zj;Zj=new o;Yj=0}++Yj}
function uj(a){if(!a.b){vj(a);a.c=true}else{uj(a.b)}}
function El(a,b){var c;c=a.e;if(b!=c){a.e=b;hb(a.b)}}
function hm(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function To(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function ym(a,b){var c;c=b.target;wp(a.d,c.checked)}
function Hi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Ak(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ll(a){var b;a.n=false;nk(a);b=kl(a);return b}
function Fp(a){nb(a.e);nb(a.a);R(a.b);R(a.c);cb(a.d)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function fd(a){return !Array.isArray(a)&&a.ob===Dh}
function Oi(a,b){return ld(a)===ld(b)||a!=null&&p(a,b)}
function rj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Ij(a){rj.call(this,a.$(),a.Z()&-6);this.a=a}
function wj(a){if(!a){this.b=null;new Ji}else{this.b=a}}
function yj(a,b){vj(a);return new Bj(a,new Fj(b,a.a))}
function Ao(a,b){A((J(),J(),I),new Mo(a,b),75497472)}
function Tl(a,b){Kp(a.k,b);A((J(),J(),I),new mm(a,b),Bq)}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function tj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Eo(a,b){var c;c=a.e;if(b!=c){a.e=oj(b);hb(a.b)}}
function Sh(a,b){var c;c=Qh(a);Xh(a,c);c.e=b?8:0;return c}
function tl(a){var b;b=new nl(pj(gn));Om(b,a.D());return b}
function Nl(a){var b;b=new Fl(pj(qn));Pm(b,a.D());return b}
function yo(a){var b;T(a.a);b=S(a.a);gi(a.f,b)&&Eo(a,b)}
function jb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function ob(a){C((J(),J(),I),a);0==(a.f.a&kq)&&D((null,I))}
function _o(a,b){return t((J(),J(),I),new jp(a,b),Bq,null)}
function Sl(a,b){A((J(),J(),I),new mm(a,b),Bq);Kp(a.k,null)}
function uo(a){Jh((Ih(),$wnd.window.window),Gq,a.d,false)}
function vo(a){Kh((Ih(),$wnd.window.window),Gq,a.d,false)}
function Fc(a){zc();$wnd.setTimeout(function(){throw a},0)}
function lc(a){kc(a.g);V(a.c);V(a.a);V(a.d);kc(a.b);kc(a.f)}
function Pb(a){if(a.e){2==(a.e.c&7)||vb(a.e,4,true);rb(a.e)}}
function Uh(a){if(a.L()){return null}var b=a.j;return vh[b]}
function ph(a){if(jd(a)){return a|0}return a.l|a.m<<22}
function Ol(a,b){var c;if(S(a.d)){c=b.target;hm(a,c.value)}}
function up(a,b){var c;Aj(bp(a.b),(c=new Ji,c)).M(new aq(b))}
function Th(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.G(b))}
function ci(a,b){var c,d;for(d=a.N();d.T();){c=d.U();b.w(c)}}
function Ri(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function Bh(a){function b(){}
;b.prototype=a||{};return new b}
function un(){un=zh;var a;tn=(a=Ah(sn.prototype.eb,sn,[]),a)}
function ln(){ln=zh;var a;kn=(a=Ah(jn.prototype.eb,jn,[]),a)}
function Dn(){Dn=zh;var a;Cn=(a=Ah(Bn.prototype.eb,Bn,[]),a)}
function bn(){bn=zh;var a;an=(a=Ah(_m.prototype.eb,_m,[]),a)}
function Um(){Um=zh;var a;Tm=(a=Ah(Sm.prototype.eb,Sm,[]),a)}
function Yp(){Wp();return $c(Uc(Zg,1),fq,34,0,[Tp,Vp,Up])}
function bp(a){ib(a.d);return new Bj(null,new tj(new xi(a.g),0))}
function vj(a){if(a.b){vj(a.b)}else if(a.c){throw kh(new Zh)}}
function Ki(a){Ai(this);Rj(this.a,ki(a,Wc(ce,fq,1,qi(a.a),5,1)))}
function Si(a,b){var c;return Qi(b,Ri(a,b==null?0:(c=r(b),c|0)))}
function xh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function wo(a,b){b.preventDefault();A((J(),J(),I),new Ko(a),Bq)}
function _l(a,b){return t((J(),J(),I),new sm(a,b),75497472,null)}
function Dc(a,b,c){var d;d=Bc();try{return Ac(a,b,c)}finally{Ec(d)}}
function Jh(a,b,c,d){a.addEventListener(b,c,(Lh(),d?true:false))}
function Kh(a,b,c,d){a.removeEventListener(b,c,(Lh(),d?true:false))}
function zk(a){a.placeholder='What needs to be done?';return a}
function qc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function po(a,b){_n(b,a.b.a.D());a.b.b.D();ao(b,a.b.c.D());return b}
function Fj(a,b){rj.call(this,b.$(),b.Z()&-16449);this.a=a;this.c=b}
function ko(a){this.b=a;this.a=new vl(this.b.a,this.b.b,this.b.c)}
function qo(a){this.b=a;this.a=new wm(this.b.a,this.b.b,this.b.c)}
function so(a){this.b=a;this.a=new Hm(this.b.a,this.b.b,this.b.c)}
function ij(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Wi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Kp(a,b){var c;c=a.f;if(!(b==c||!!b&&Po(b,c))){a.f=b;hb(a.d)}}
function eb(a,b){var c,d;Bi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Aj(a,b){var c;uj(a);c=new Lj;c.a=b;a.a.S(new Oj(c));return c.a}
function xj(a){var b;uj(a);b=0;while(a.a._(new Mj)){b=lh(b,1)}return b}
function vp(a){var b;Aj(yj(bp(a.b),new $p),(b=new Ji,b)).M(new _p(a.b))}
function xp(a){this.b=oj(a);J();this.a=new mc(0,null,new yp,false,false)}
function cm(a){return Lh(),Gp(a.k)==(jb(a.c),a.p.props['a'])?true:false}
function oi(a,b){return kd(b)?b==null?Ui(a.a,null):gj(a.b,b):Ui(a.a,b)}
function Ep(a,b){return (Wp(),Up)==a||(Tp==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function Ec(a){a&&Lc((Jc(),Ic));--wc;if(a){if(yc!=-1){Gc(yc);yc=-1}}}
function Mb(b){try{b.b.v()}catch(a){a=jh(a);if(!gd(a,6))throw kh(a)}}
function jo(a,b){Pm(b,a.b.a.D());Qm(b,a.b.b.D());Rm(b,a.b.c.D());return b}
function ro(a,b){Om(b,a.b.a.D());Pm(b,a.b.b.D());Qm(b,a.b.c.D());return b}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Ci(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function xl(a){var b;b=hi((ib(a.b),a.e));if(b.length>0){rp(a.d,b);El(a,'')}}
function Hp(a){var b,c;return b=S(a.b),Aj(yj(bp(a.j),new bq(b)),(c=new Ji,c))}
function vc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Cc(b){zc();return function(){return Dc(b,this,arguments);var a}}
function md(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Tj(a,b){return Vc(b)!=10&&$c(q(b),b.nb,b.__elementTypeId$,Vc(b),a),a}
function ni(a,b,c){return kd(b)?b==null?Ti(a.a,null,c):fj(a.b,b,c):Ti(a.a,b,c)}
function gk(a,b,c){!gi(c,'key')&&!gi(c,'ref')&&(a[c]=b[c],undefined)}
function Ei(a,b,c){for(;c<a.a.length;++c){if(Oi(b,a.a[c])){return c}}return -1}
function jj(a){if(a.a.c!=a.c){return ej(a.a,a.b.value[0])}return a.b.value[1]}
function Po(a,b){var c;if(gd(b,60)){c=b;return a.c.e==c.c.e}else{return false}}
function Gi(a,b){var c;c=Ei(a,b,0);if(c==-1){return false}Sj(a.a,c);return true}
function Wc(a,b,c,d,e,f){var g;g=Xc(e,d);e!=10&&$c(Uc(a,f),b,c,e,g);return g}
function xm(a,b,c){var d;d=new im(pj(zn));_n(d,a.D());b.D();ao(d,c.D());return d}
function to(a,b){a.f=b;gi(b,S(a.a))&&Eo(a,b);xo(b);A((J(),J(),I),new Ko(a),Bq)}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new nc(a)),67108864,null)}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new mb(a)),0,null);!!a.b&&nb(a.b)}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||nb(a.f)}}
function mk(a,b){if(!a.n){a.n=true;a.o||(b?a.p.setState({}):a.p.forceUpdate())}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Fb(a.a)}finally{a.c=false}}}}
function Kc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Oc(b,c)}while(a.a);a.a=c}}
function Lc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Oc(b,c)}while(a.b);a.b=c}}
function Xh(a,b){var c;if(!a){return}b.j=a;var d=Uh(b);if(!d){vh[a]=[b];return}d.mb=b}
function ub(b){if(b){try{b.v()}catch(a){a=jh(a);if(gd(a,6)){J()}else throw kh(a)}}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function bb(){var a;this.a=Wc(qd,fq,54,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function vi(a){this.d=a;this.c=new ij(this.d.b);this.a=this.c;this.b=ti(this)}
function Nb(a,b){this.b=oj(a);this.a=b|0|(0==(b&6291456)?lq:0)|(0!=(b&229376)?0:98304)}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Bi((!a.b&&(a.b=new Ji),a.b),b)}}}
function jh(a){var b;if(gd(a,6)){return a}b=a&&a[oq];if(!b){b=new uc(a);Rc(b)}return b}
function Ah(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Im(a,b,c){var d;d=new Bm(pj(In));Om(d,a.D());Pm(d,b.D());Qm(d,c.D());return d}
function wl(a,b,c){var d;d=new el(pj(Zm));Pm(d,a.D());Qm(d,b.D());Rm(d,c.D());return d}
function Qh(a){var b;b=new Ph;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function jk(a){var b;b=kk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Mi(a){var b,c,d;d=0;for(c=new vi(a.a);c.b;){b=ui(c);d=d+(b?r(b):0);d=d|0}return d}
function rb(a){var b,c;for(c=new Li(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function rh(){sh();var a=qh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Zh(){rc.call(this,"Stream already terminated, can't be modified or used")}
function ei(){rc.call(this,'Cannot return null from a non-@Nullable @Provides method')}
function Vc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function yl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Jl(a),Bq)}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new Ji);a.c=c.c}b.d=true;Bi(a.c,oj(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,oj(b))}
function gj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Xi(a.a,b);--a.b}return c}
function Xl(a,b){var c,d;d=a.p.props;c=false;if(!(d['a']===b['a'])){hb(a.c);c=true}return c||a.n}
function ji(a,b){var c,d;for(d=new vi(b.a);d.b;){c=ui(d);if(!ri(a,c)){return false}}return true}
function Qi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Oi(a,c.W())){return c}}return null}
function oh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=qq;d=1048575}c=md(e/lq);b=md(e-c*lq);return _c(b,c,d)}
function mh(a){var b;b=a.h;if(b==0){return a.l+a.m*lq}if(b==1048575){return a.l+a.m*lq-qq}return a}
function ti(a){if(a.a.T()){return true}if(a.a!=a.c){return false}a.a=new Wi(a.d.a);return a.a.T()}
function ek(a){$wnd.React.Component.call(this,a);this.a=this.fb();this.a.p=oj(this);this.a.cb()}
function io(){this.a=Gh((pp(),pp(),op));this.b=Gh(new Cp(this.a));this.c=Gh(new Rp(this.a))}
function Wp(){Wp=zh;Tp=new Xp('ACTIVE',0);Vp=new Xp('COMPLETED',1);Up=new Xp('ALL',2)}
function Zo(a,b,c){var d;d=new Wo(b,c);ac(d.c.c,a,new ic(a,d));ni(a.g,_h(d.c.e),d);hb(a.d);return d}
function fj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ec(a,b,c){var d;d=oi(a.g,b?_h(b.c.e):null);if(null!=d){cc(b.c.c,a);c&&!!b&&jc(b.c);hb(a.d)}}
function uc(a){tc();oc(this);this.b=a;a!=null&&Uj(a,oq,this);this.c=a==null?'null':Ch(a);this.a=a}
function Ph(){this.g=Mh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function yb(a,b,c){xb.call(this,null,a,b,c|(!a?262144:hq)|(0==(c&6291456)?!a?kq:lq:0)|0|0|0)}
function Rl(a,b,c){27==c.which?A((J(),J(),I),new pm(a,b),Bq):13==c.which&&A((J(),J(),I),new nm(a,b),Bq)}
function nb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Cb(a)),67108864,null);!!a.a&&R(a.a);Jb(a.f);a.c=a.c&-8|1}}
function nk(a){if(!lk){lk=(++a.gb().e,new Ib);$wnd.Promise.resolve(null).then(Ah(ok.prototype.F,ok,[]))}}
function S(a){ib(a.e);wb(a.f)&&pb(a.f);if(a.b){if(gd(a.b,8)){throw kh(a.b)}else{throw kh(a.b)}}return a.k}
function Jp(a){var b;b=S(a.i.a);gi(Iq,b)||gi(Dq,b)||gi('',b)?Ao(a.i,b):Dp(Bo(a.i))?Do(a.i):Ao(a.i,'')}
function Yl(a){var b,c;a.n=false;nk(a);b=(jb(a.c),a.p.props['a']);if(!!b&&b.c.i<0){return null}c=Wl(a);return c}
function _h(a){var b,c;if(a>-129&&a<128){b=a+128;c=(bi(),ai)[b];!c&&(c=ai[b]=new $h(a));return c}return new $h(a)}
function Ch(a){var b;if(Array.isArray(a)&&a.ob===Dh){return Oh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function ak(a){$j();var b,c,d;c=':'+a;d=Zj[c];if(d!=null){return md(d)}d=Xj[c];b=d==null?_j(a):md(d);bk();Zj[c]=b;return b}
function $c(a,b,c,d,e){e.mb=a;e.nb=b;e.ob=Dh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function uh(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function fb(a,b){var c,d;d=a.c;Gi(d,b);!!a.b&&hq!=(a.b.c&iq)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function ad(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return _c(c&4194303,d&4194303,e&1048575)}
function lh(a,b){var c;if(jd(a)&&jd(b)){c=a+b;if(-17592186044416<c&&c<qq){return c}}return mh(ad(jd(a)?oh(a):a,jd(b)?oh(b):b))}
function q(a){return kd(a)?ee:jd(a)?Wd:hd(a)?Ud:fd(a)?a.mb:Yc(a)?a.mb:a.mb||Array.isArray(a)&&Uc(Nd,1)||Nd}
function r(a){return kd(a)?ak(a):jd(a)?md(a):hd(a)?a?1231:1237:fd(a)?a.s():Yc(a)?Wj(a):!!a&&!!a.hashCode?a.hashCode():Wj(a)}
function p(a,b){return kd(a)?gi(a,b):jd(a)?a===b:hd(a)?a===b:fd(a)?a.q(b):Yc(a)?a===b:!!a&&!!a.equals?a.equals(b):ld(a)===ld(b)}
function Kb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&hq)?Mb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function zb(a,b){xb.call(this,a,new Ab(a),null,b|(hq==(b&iq)?0:524288)|(0==(b&6291456)?hq==(b&iq)?lq:kq:0)|0|268435456|0)}
function _k(){Zk();return $c(Uc(Se,1),fq,7,0,[Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk])}
function bc(a){var b,c;if(!a.a){for(c=new Li(new Ki(new xi(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.v()}a.a=true}}
function Ni(a){var b,c,d;d=1;for(c=new Li(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function pk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Ii(a,b){var c,d;d=a.a.length;b.length<d&&(b=Tj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Wh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ul(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){A((J(),J(),I),new Ap(b,c),Bq);Kp(a.k,null);hm(a,c)}else{ap(a.j,b)}}
function Ub(a){var b;if(a.c){while(a.c.a.length!=0){b=Fi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&vb(b.b,3,true)}}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Li(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&vb(b,5,true)}}}
function Vl(a){var b;b=S(a.d);if(!a.i&&b){a.i=true;gm(a,(jb(a.c),a.p.props['a']));a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function Bc(){var a;if(wc!=0){a=vc();if(a-xc>2000){xc=a;yc=$wnd.setTimeout(Hc,10)}}if(wc++==0){Kc((Jc(),Ic));return true}return false}
function Sc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function mc(a,b,c,d,e){var f;this.e=a;this.c=d?new dc:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new lb((J(),null)),f):null;this.d=null}
function U(a,b,c,d){this.c=oj(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new zb(this,d);this.e=new lb(this.f);hq==(d&iq)&&ob(this.f)}
function Wo(a,b){var c,d,e;this.e=oj(a);this.d=b;J();c=++No;this.c=new mc(c,null,new Xo(this),true,true);this.b=(e=new lb(null),e);this.a=(d=new lb(null),d)}
function nl(a){var b;J();b=++ml;this.b=new mc(b,new pl(this),new ol(this),false,false);this.a=new yb(null,oj(new ql(this)),zq);fn(a.a,this);D((null,I))}
function Bm(a){var b;J();b=++Am;this.b=new mc(b,new Dm(this),new Cm(this),false,false);this.a=new yb(null,oj(new Em(this)),zq);Hn(a.a,this);D((null,I))}
function ed(a,b){if(kd(a)){return !!dd[b]}else if(a.nb){return !!a.nb[b]}else if(jd(a)){return !!cd[b]}else if(hd(a)){return !!bd[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function hi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Xb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Li(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&vb(b,6,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Li(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?vb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Xc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{$b(b,d);try{f=(c.a.v(),null)}finally{_b()}return f}catch(a){a=jh(a);if(gd(a,6)){e=a;throw kh(e)}else throw kh(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.t()}else{$b(b,e);try{g=c.t()}finally{_b()}}return g}catch(a){a=jh(a);if(gd(a,6)){f=a;throw kh(f)}else throw kh(a)}finally{D(b)}}
function Eb(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Kb(c);return true}
function th(b,c,d,e){sh();var f=qh;$moduleName=c;$moduleBase=d;ih=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{cq(g)()}catch(a){b(c,a)}}else{cq(g)()}}
function kl(a){var b,c;c=S(a.c.e).a;b='item'+(c==1?'':'s');return fk('span',pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,['todo-count'])),[fk('strong',null,[c]),' '+b+' left'])}
function kk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=oj(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function aj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return bj()}}
function Fl(a){var b,c;J();b=++Al;this.c=new mc(b,new Hl(this),new Gl(this),false,false);this.b=(c=new lb(null),c);this.a=new yb(null,oj(new Ll(this)),zq);pn(a.a,this);D((null,I))}
function el(a){var b;J();b=++bl;this.c=new mc(b,new gl(this),new fl(this),false,false);this.a=new U(new il(this),null,null,136478720);this.b=new yb(null,oj(new jl(this)),zq);Ym(a.a,this);D((null,I))}
function ki(a,b){var c,d,e,f,g;g=qi(a.a);b.length<g&&(b=Tj(new Array(g),b));e=(f=new vi((new si(a.a)).a),new yi(f));for(d=0;d<g;++d){b[d]=(c=ui(e.a),c.X())}b.length>g&&(b[g]=null);return b}
function wh(){vh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Oc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].pb()&&(c=Nc(c,g)):g[0].pb()}catch(a){a=jh(a);if(gd(a,6)){d=a;zc();Fc(gd(d,36)?d.C():d)}else throw kh(a)}}return c}
function zl(a){var b;a.n=false;nk(a);b=fk(Cq,tk(xk(yk(Bk(zk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,['new-todo']))),(ib(a.b),a.e)),Ah(Kn.prototype.jb,Kn,[a])),Ah(Ln.prototype.ib,Ln,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.t();if(!(ld(e)===ld(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=jh(a);if(gd(a,12)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw kh(c)}else throw kh(a)}}
function Ti(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Qi(b,e);if(f){return f.Y(c)}}e[e.length]=new zi(b,c);++a.b;return null}
function Pj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function _j(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+fi(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Wc(ce,fq,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function pb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=jh(a);if(gd(a,6)){J()}else throw kh(a)}}}
function xo(a){var b;if(0==a.length){b=(Ih(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Hh.title,b)}else{(Ih(),$wnd.window.window).location.hash=a}}
function xb(a,b,c,d){this.b=new Ji;this.f=new Nb(new Bb(this),d&6520832|262144|hq);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&kq)&&D((null,I)))}
function Ui(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Oi(b,e.W())){if(d.length==1){d.length=0;Xi(a.a,g)}else{d.splice(h,1)}--a.b;return e.X()}}return null}
function Eh(){var a;a=new io;Zm=new $m(a);Wm(new Lm(a));gn=new hn(a);dn(new Nm(a));zn=new An(a);wn(new $n(a));In=new Jn(a);Fn(new eo(a));qn=new rn(a);nn(new Nn(a));$wnd.ReactDOM.render((new co).a,(Ih(),Hh).getElementById('app'),null)}
function yh(a,b,c){var d=vh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=vh[b]),Bh(h));_.nb=c;!b&&(_.ob=Dh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.mb=f)}
function Vh(a){if(a.K()){var b=a.c;b.L()?(a.k='['+b.j):!b.K()?(a.k='[L'+b.I()+';'):(a.k='['+b.I());a.b=b.H()+'[]';a.i=b.J()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Wh('.',[c,Wh('$',d)]);a.b=Wh('.',[c,Wh('.',d)]);a.i=d[d.length-1]}
function li(a,b){var c,d,e;c=b.W();e=b.X();d=kd(c)?c==null?mi(Si(a.a,null)):ej(a.b,c):mi(Si(a.a,c));if(!(ld(e)===ld(d)||e!=null&&p(e,d))){return false}if(d==null&&!(kd(c)?c==null?!!Si(a.a,null):dj(a.b,c):!!Si(a.a,c))){return false}return true}
function im(a){var b,c,d;J();b=++Zl;this.e=new mc(b,new km(this),new jm(this),false,false);this.c=(d=new lb(null),d);this.a=(c=new lb(null),c);this.d=new U(new tm(this),null,null,136478720);this.b=new yb(null,oj(new um(this)),zq);yn(a.a,this);D((null,I))}
function Fo(){var a,b;this.d=new Sp(this);this.f=this.e=(b=(Ih(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new mc(0,null,new Go(this),false,false);this.b=(a=new lb(null),a);this.a=new U(new Lo,new Ho(this),new Io(this),35749888)}
function fp(){var a;this.g=new Pi;J();this.f=new mc(0,new hp(this),new gp(this),false,false);this.d=(a=new lb(null),a);this.c=new U(new kp(this),null,null,Hq);this.e=new U(new lp(this),null,null,Hq);this.a=new U(new mp(this),null,null,Hq);this.b=new U(new np(this),null,null,Hq)}
function Lp(a){var b;this.j=oj(a);this.i=new Fo;J();this.g=new mc(0,null,new Mp(this),false,false);this.d=(b=new lb(null),b);this.b=new U(new Np(this),null,null,Hq);this.c=new U(new Op(this),null,null,Hq);this.e=u(new Pp(this),413138944);this.a=u(new Qp(this),681574400);D((null,I))}
function wb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Li(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=jh(a);if(!gd(a,6))throw kh(a)}if(6==(b.c&7)){return true}}}}}rb(b);return false}
function fk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;dk(b,Ah(hk.prototype.bb,hk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=kk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=oj(d),g}
function _i(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function vb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){kb(a.a.e);ub((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;ub((e=d.i,e));d.k=null}Ci(a.b,new Db(a));a.b.a=Wc(ce,fq,1,0,5,1)}else 3==g&&!!a.a&&ub((f=a.a.g,f))}}
function Zk(){Zk=zh;Dk=new $k(tq,0);Ek=new $k('checkbox',1);Fk=new $k('color',2);Gk=new $k('date',3);Hk=new $k('datetime',4);Ik=new $k('email',5);Jk=new $k('file',6);Kk=new $k('hidden',7);Lk=new $k('image',8);Mk=new $k('month',9);Nk=new $k(dq,10);Ok=new $k('password',11);Pk=new $k('radio',12);Qk=new $k('range',13);Rk=new $k('reset',14);Sk=new $k('search',15);Tk=new $k('submit',16);Uk=new $k('tel',17);Vk=new $k('text',18);Wk=new $k('time',19);Xk=new $k('url',20);Yk=new $k('week',21)}
function zm(a){var b,c,d;a.n=false;nk(a);d=fk('div',null,[fk('div',null,[fk(Eq,pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[Eq])),[fk('h1',null,['todos']),(new Mn).a]),S(a.c.c)?null:fk('section',pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[Eq])),[fk(Cq,xk(Ak(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[Fq])),(Zk(),Ek)),Ah(bo.prototype.ib,bo,[a])),null),fk('ul',pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,['todo-list'])),(b=Aj(zj(S(a.e.c).R()),(c=new Ji,c)),Ii(b,Zc(b.a.length))))]),S(a.c.c)?null:(new Km).a])]);return d}
function al(a){var b,c;a.n=false;nk(a);c=(b=S(a.f.b),fk(uq,pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[uq])),[(new Mm).a,fk('ul',pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,['filters'])),[fk('li',null,[fk('a',rk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[(Wp(),Up)==b?vq:null])),'#'),['All'])]),fk('li',null,[fk('a',rk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[Tp==b?vq:null])),'#active'),['Active'])]),fk('li',null,[fk('a',rk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[Vp==b?vq:null])),wq),['Completed'])])]),S(a.a)?fk(tq,sk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[xq])),Ah(Jm.prototype.kb,Jm,[a])),[yq]):null]));return c}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Di(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Hi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&vb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Di(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Fi(a.b,g)}e&&tb(a.e,a.b)}else{e&&tb(a.e,new Ji)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&hq!=(k.b.c&iq)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function Wl(a){var b,c;c=(jb(a.c),a.p.props['a']);b=(ib(c.a),c.d);return fk('li',pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[b?Dq:null,S(a.d)?'editing':null])),[fk('div',pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,['view'])),[fk(Cq,xk(uk(Ak(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,['toggle'])),(Zk(),Ek)),b),Ah(Qn.prototype.ib,Qn,[c])),null),fk('label',Ck(new $wnd.Object,Ah(Rn.prototype.kb,Rn,[a,c])),[(ib(c.b),c.e)]),fk(tq,sk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,['destroy'])),Ah(Sn.prototype.kb,Sn,[a,c])),null)]),fk(Cq,yk(xk(wk(vk(pk(qk(new $wnd.Object,Ah(Tn.prototype.w,Tn,[a])),$c(Uc(ee,1),fq,2,6,['edit'])),(ib(a.a),a.g)),Ah(Un.prototype.hb,Un,[a,c])),Ah(Pn.prototype.ib,Pn,[a])),Ah(Vn.prototype.jb,Vn,[a,c])),null)])}
function bj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[sq]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!_i()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[sq]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var dq='number',eq={11:1},fq={3:1,4:1},gq={9:1},hq=1048576,iq=1835008,jq={5:1},kq=2097152,lq=4194304,mq={23:1},nq='__noinit__',oq='__java$exception',pq={3:1,12:1,8:1,6:1},qq=17592186044416,rq={43:1},sq='delete',tq='button',uq='footer',vq='selected',wq='#completed',xq='clear-completed',yq='Clear Completed',zq=1478627328,Aq={14:1},Bq=142606336,Cq='input',Dq='completed',Eq='header',Fq='toggle-all',Gq='hashchange',Hq=136413184,Iq='active';var _,vh,qh,ih=-1;wh();yh(1,null,{},o);_.q=Jq;_.r=function(){return this.mb};_.s=Kq;_.equals=function(a){return this.q(a)};_.hashCode=function(){return this.s()};var bd,cd,dd;yh(62,1,{},Ph);_.G=function(a){var b;b=new Ph;b.e=4;a>1?(b.c=Th(this,a-1)):(b.c=this);return b};_.H=function(){Nh(this);return this.b};_.I=function(){return Oh(this)};_.J=function(){Nh(this);return this.i};_.K=function(){return (this.e&4)!=0};_.L=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Mh=1;var ce=Rh(1);var Vd=Rh(62);yh(143,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var pd=Rh(143);yh(37,1,eq,G);_.t=function(){return this.a.v(),null};var nd=Rh(37);yh(144,1,{},H);var od=Rh(144);var I;yh(54,1,{54:1},P);_.b=0;_.c=false;_.d=0;var qd=Rh(54);yh(248,1,gq);var td=Rh(248);yh(20,248,gq,U);_.u=function(){R(this)};_.a=false;_.d=0;var rd=Rh(20);yh(151,1,{291:1},bb);var sd=Rh(151);yh(15,248,{9:1,15:1},lb);_.u=function(){cb(this)};_.a=4;_.d=false;_.e=0;var vd=Rh(15);yh(202,1,jq,mb);_.v=function(){db(this.a)};var ud=Rh(202);yh(19,248,{9:1,19:1},yb,zb);_.u=function(){nb(this)};_.c=0;var Ad=Rh(19);yh(203,1,mq,Ab);_.v=function(){Q(this.a)};var wd=Rh(203);yh(204,1,jq,Bb);_.v=function(){pb(this.a)};var xd=Rh(204);yh(205,1,jq,Cb);_.v=function(){sb(this.a)};var yd=Rh(205);yh(206,1,{},Db);_.w=function(a){qb(this.a,a)};var zd=Rh(206);yh(152,1,{},Gb);_.a=0;_.b=0;_.c=0;var Bd=Rh(152);yh(218,1,gq,Ib);_.u=function(){Hb(this)};_.a=false;var Cd=Rh(218);yh(83,248,{9:1,83:1},Nb);_.u=function(){Jb(this)};_.a=0;var Dd=Rh(83);yh(209,1,{},Zb);_.a=0;var Ob;var Ed=Rh(209);yh(207,1,gq,dc);_.u=function(){bc(this)};_.a=false;var Fd=Rh(207);yh(167,1,{});var Id=Rh(167);yh(178,1,{},hc);_.w=function(a){fc(this.a,a)};var Gd=Rh(178);yh(179,1,jq,ic);_.v=function(){gc(this.a,this.b)};var Hd=Rh(179);yh(168,167,{});var Jd=Rh(168);yh(18,1,gq,mc);_.u=function(){jc(this)};_.e=0;_.i=0;var Ld=Rh(18);yh(201,1,jq,nc);_.v=function(){lc(this.a)};var Kd=Rh(201);yh(6,1,{3:1,6:1});_.A=function(a){return new Error(a)};_.B=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=Oh(this.mb),c==null?a:a+': '+c);pc(this,qc(this.A(b)));Rc(this)};_.b=nq;_.d=true;var fe=Rh(6);yh(12,6,{3:1,12:1,6:1});var Yd=Rh(12);yh(8,12,pq);var de=Rh(8);yh(45,8,pq);var _d=Rh(45);yh(94,45,pq);var Pd=Rh(94);yh(36,94,{36:1,3:1,12:1,8:1,6:1},uc);_.C=function(){return ld(this.a)===ld(sc)?null:this.a};var sc;var Md=Rh(36);var Nd=Rh(0);yh(225,1,{});var Od=Rh(225);var wc=0,xc=0,yc=-1;yh(147,225,{},Mc);var Ic;var Qd=Rh(147);var Pc;yh(236,1,{});var Sd=Rh(236);yh(95,236,{},Tc);var Rd=Rh(95);yh(55,1,{55:1,14:1},Fh);_.D=function(){if(this===this.a){this.a=this.b.D();this.b=null}return this.a};var Td=Rh(55);var Hh;bd={3:1,90:1,29:1};var Ud=Rh(90);yh(44,1,{3:1,44:1});var be=Rh(44);cd={3:1,29:1,44:1};var Wd=Rh(235);yh(33,1,{3:1,29:1,33:1});_.q=Jq;_.s=Kq;_.b=0;var Xd=Rh(33);yh(96,8,pq,Zh);var Zd=Rh(96);yh(30,44,{3:1,29:1,30:1,44:1},$h);_.q=function(a){return gd(a,30)&&a.a==this.a};_.s=Nq;_.a=0;var $d=Rh(30);var ai;yh(306,1,{});yh(75,45,pq,di,ei);_.A=function(a){return new TypeError(a)};var ae=Rh(75);dd={3:1,89:1,29:1,2:1};var ee=Rh(2);yh(310,1,{});yh(74,8,pq,ii);var ge=Rh(74);yh(243,1,{41:1});_.M=Pq;_.Q=function(){return new tj(this,0)};_.R=function(){return new Bj(null,this.Q())};_.O=function(a){throw kh(new ii('Add not supported on this collection'))};var he=Rh(243);yh(246,1,{224:1});_.q=function(a){var b,c,d;if(a===this){return true}if(!gd(a,38)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new vi((new si(d)).a);c.b;){b=ui(c);if(!li(this,b)){return false}}return true};_.s=function(){return Mi(new si(this))};var se=Rh(246);yh(150,246,{224:1});var ke=Rh(150);yh(245,243,{41:1,256:1});_.Q=function(){return new tj(this,1)};_.q=function(a){var b;if(a===this){return true}if(!gd(a,25)){return false}b=a;if(qi(b.a)!=this.P()){return false}return ji(this,b)};_.s=function(){return Mi(this)};var te=Rh(245);yh(25,245,{25:1,41:1,256:1},si);_.N=function(){return new vi(this.a)};_.P=Mq;var je=Rh(25);yh(26,1,{},vi);_.S=Lq;_.U=function(){return ui(this)};_.T=Oq;_.b=false;var ie=Rh(26);yh(244,243,{41:1,251:1});_.Q=function(){return new tj(this,16)};_.V=function(a,b){throw kh(new ii('Add not supported on this list'))};_.O=function(a){this.V(this.P(),a);return true};_.q=function(a){var b,c,d,e,f;if(a===this){return true}if(!gd(a,10)){return false}f=a;if(this.P()!=f.a.length){return false}e=new Li(f);for(c=new Li(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(ld(b)===ld(d)||b!=null&&p(b,d))){return false}}return true};_.s=function(){return Ni(this)};_.N=function(){return new wi(this)};var me=Rh(244);yh(145,1,{},wi);_.S=Lq;_.T=function(){return this.a<this.b.a.length};_.U=function(){return Di(this.b,this.a++)};_.a=0;var le=Rh(145);yh(53,243,{41:1},xi);_.N=function(){var a;return a=new vi((new si(this.a)).a),new yi(a)};_.P=Mq;var oe=Rh(53);yh(76,1,{},yi);_.S=Lq;_.T=function(){return this.a.b};_.U=function(){var a;return a=ui(this.a),a.X()};var ne=Rh(76);yh(148,1,rq);_.q=function(a){var b;if(!gd(a,43)){return false}b=a;return Oi(this.a,b.W())&&Oi(this.b,b.X())};_.W=Nq;_.X=Oq;_.s=function(){return nj(this.a)^nj(this.b)};_.Y=function(a){var b;b=this.b;this.b=a;return b};var pe=Rh(148);yh(149,148,rq,zi);var qe=Rh(149);yh(247,1,rq);_.q=function(a){var b;if(!gd(a,43)){return false}b=a;return Oi(this.b.value[0],b.W())&&Oi(jj(this),b.X())};_.s=function(){return nj(this.b.value[0])^nj(jj(this))};var re=Rh(247);yh(10,244,{3:1,10:1,41:1,251:1},Ji,Ki);_.V=function(a,b){Qj(this.a,a,b)};_.O=function(a){return Bi(this,a)};_.M=function(a){Ci(this,a)};_.N=function(){return new Li(this)};_.P=function(){return this.a.length};var ve=Rh(10);yh(17,1,{},Li);_.S=Lq;_.T=function(){return this.a<this.c.a.length};_.U=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ue=Rh(17);yh(38,150,{3:1,38:1,224:1},Pi);var we=Rh(38);yh(80,1,{},Vi);_.M=Pq;_.N=function(){return new Wi(this)};_.b=0;var ye=Rh(80);yh(81,1,{},Wi);_.S=Lq;_.U=function(){return this.d=this.a[this.c++],this.d};_.T=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var xe=Rh(81);var Zi;yh(78,1,{},hj);_.M=Pq;_.N=function(){return new ij(this)};_.b=0;_.c=0;var Be=Rh(78);yh(79,1,{},ij);_.S=Lq;_.U=function(){return this.c=this.a,this.a=this.b.next(),new kj(this.d,this.c,this.d.c)};_.T=function(){return !this.a.done};var ze=Rh(79);yh(166,247,rq,kj);_.W=function(){return this.b.value[0]};_.X=function(){return jj(this)};_.Y=function(a){return fj(this.a,this.b.value[0],a)};_.c=0;var Ae=Rh(166);yh(157,1,{});_.S=function(a){qj(this,a)};_.Z=function(){return this.d};_.$=function(){return this.e};_.d=0;_.e=0;var De=Rh(157);yh(77,157,{});var Ce=Rh(77);yh(24,1,{},tj);_.Z=Nq;_.$=function(){sj(this);return this.c};_.S=function(a){sj(this);this.d.S(a)};_._=function(a){sj(this);if(this.d.T()){a.w(this.d.U());return true}return false};_.a=0;_.c=0;var Ee=Rh(24);yh(156,1,{});_.c=false;var Ne=Rh(156);yh(32,156,{},Bj);var Me=Rh(32);yh(159,77,{},Fj);_._=function(a){this.b=false;while(!this.b&&this.c._(new Gj(this,a)));return this.b};_.b=false;var Ge=Rh(159);yh(162,1,{},Gj);_.w=function(a){Ej(this.a,this.b,a)};var Fe=Rh(162);yh(158,77,{},Ij);_._=function(a){return this.a._(new Jj(a))};var Ie=Rh(158);yh(161,1,{},Jj);_.w=function(a){Hj(this.a,a)};var He=Rh(161);yh(160,1,{},Lj);_.w=function(a){Kj(this,a)};var Je=Rh(160);yh(163,1,{},Mj);_.w=function(a){};var Ke=Rh(163);yh(164,1,{},Oj);_.w=function(a){Nj(this,a)};var Le=Rh(164);yh(308,1,{});yh(249,1,{});var Oe=Rh(249);yh(305,1,{});var Vj=0;var Xj,Yj=0,Zj;yh(772,1,{});yh(787,1,{});yh(237,1,{});_.cb=Yq;var Pe=Rh(237);yh(31,$wnd.React.Component,{});xh(vh[1],_);_.render=function(){return this.a.db()};var Qe=Rh(31);yh(290,$wnd.Function,{},hk);_.bb=function(a){gk(this.a,this.b,a)};yh(238,237,{});_.n=false;_.o=false;var lk;var Re=Rh(238);yh(262,$wnd.Function,{},ok);_.F=function(a){return Hb(lk),lk=null,null};yh(7,33,{3:1,29:1,33:1,7:1},$k);var Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk;var Se=Sh(7,_k);yh(239,238,{});_.db=function(){var a;return a=S(this.f.b),fk(uq,pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[uq])),[(new Mm).a,fk('ul',pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,['filters'])),[fk('li',null,[fk('a',rk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[(Wp(),Up)==a?vq:null])),'#'),['All'])]),fk('li',null,[fk('a',rk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[Tp==a?vq:null])),'#active'),['Active'])]),fk('li',null,[fk('a',rk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[Vp==a?vq:null])),wq),['Completed'])])]),S(this.a)?fk(tq,sk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[xq])),Ah(Jm.prototype.kb,Jm,[this])),[yq]):null])};var Mf=Rh(239);yh(64,239,{64:1});_.db=function(){return al(this)};var Sf=Rh(64);yh(65,64,{9:1,65:1,64:1},el);_.u=Tq;_.q=Jq;_.gb=Qq;_.s=Kq;_.db=function(){return B((J(),J(),I),this.b,new hl(this))};var bl=0;var df=Rh(65);yh(100,1,jq,fl);_.v=function(){cl(this.a)};var Te=Rh(100);yh(99,1,jq,gl);_.v=Rq;var Ue=Rh(99);yh(103,1,eq,hl);_.t=function(){return al(this.a)};var Ve=Rh(103);yh(101,1,eq,il);_.t=function(){return dl(this.a)};var We=Rh(101);yh(102,1,mq,jl);_.v=Sq;var Xe=Rh(102);yh(242,238,{});_.db=function(){return kl(this)};var Lf=Rh(242);yh(72,242,{72:1});_.db=function(){return ll(this)};var Rf=Rh(72);yh(73,72,{9:1,73:1,72:1},nl);_.u=Uq;_.q=Jq;_.gb=Qq;_.s=Kq;_.db=function(){return B((J(),J(),I),this.a,new rl(this))};var ml=0;var bf=Rh(73);yh(138,1,jq,ol);_.v=Vq;var Ye=Rh(138);yh(137,1,jq,pl);_.v=Rq;var Ze=Rh(137);yh(139,1,mq,ql);_.v=Sq;var $e=Rh(139);yh(140,1,eq,rl);_.t=function(){return ll(this.a)};var _e=Rh(140);yh(197,1,Aq,sl);_.D=function(){return tl(this.a)};var af=Rh(197);yh(196,1,Aq,vl);_.D=function(){return ul(this)};var cf=Rh(196);yh(127,238,{});_.db=function(){return fk(Cq,tk(xk(yk(Bk(zk(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,['new-todo']))),(ib(this.b),this.e)),Ah(Kn.prototype.jb,Kn,[this])),Ah(Ln.prototype.ib,Ln,[this]))),null)};_.e='';var cg=Rh(127);yh(47,127,{47:1});_.db=function(){return zl(this)};var Vf=Rh(47);yh(71,47,{9:1,71:1,47:1},Fl);_.u=Tq;_.q=Jq;_.gb=Qq;_.s=Kq;_.db=function(){return B((J(),J(),I),this.a,new Il(this))};var Al=0;var mf=Rh(71);yh(129,1,jq,Gl);_.v=function(){Bl(this.a)};var ef=Rh(129);yh(128,1,jq,Hl);_.v=Rq;var ff=Rh(128);yh(131,1,eq,Il);_.t=function(){return zl(this.a)};var gf=Rh(131);yh(132,1,jq,Jl);_.v=function(){xl(this.a)};var hf=Rh(132);yh(133,1,jq,Kl);_.v=function(){Dl(this.a,this.b)};var jf=Rh(133);yh(130,1,mq,Ll);_.v=Sq;var kf=Rh(130);yh(200,1,Aq,Ml);_.D=function(){return Nl(this.a)};var lf=Rh(200);yh(240,238,{});_.cb=function(){gm(this,this.lb())};_.db=function(){return Wl(this)};_.i=false;var fg=Rh(240);yh(66,240,{66:1});_.lb=function(){return this.p.props['a']};_.db=function(){return Yl(this)};var Yf=Rh(66);yh(67,66,{9:1,67:1,66:1},im);_.u=function(){jc(this.e)};_.q=Jq;_.gb=Qq;_.lb=function(){return jb(this.c),this.p.props['a']};_.s=Kq;_.db=function(){return B((J(),J(),I),this.b,new lm(this))};var Zl=0;var Af=Rh(67);yh(108,1,jq,jm);_.v=function(){$l(this.a)};var nf=Rh(108);yh(107,1,jq,km);_.v=Rq;var of=Rh(107);yh(111,1,eq,lm);_.t=function(){return Yl(this.a)};var pf=Rh(111);yh(46,1,jq,mm);_.v=function(){hm(this.a,Bo(this.b))};var qf=Rh(46);yh(68,1,jq,nm);_.v=function(){Ul(this.a,this.b)};var rf=Rh(68);yh(112,1,jq,om);_.v=function(){Tl(this.a,this.b)};var sf=Rh(112);yh(113,1,jq,pm);_.v=function(){Sl(this.a,this.b)};var tf=Rh(113);yh(114,1,jq,qm);_.v=function(){Ol(this.a,this.b)};var uf=Rh(114);yh(115,1,jq,rm);_.v=function(){Vl(this.a)};var vf=Rh(115);yh(116,1,eq,sm);_.t=function(){return bm(this.a,this.b)};var wf=Rh(116);yh(109,1,eq,tm);_.t=function(){return cm(this.a)};var xf=Rh(109);yh(110,1,mq,um);_.v=function(){mk(this.a,true)};var yf=Rh(110);yh(198,1,Aq,wm);_.D=function(){return vm(this)};var zf=Rh(198);yh(241,238,{});_.db=function(){var a;return fk('div',null,[fk('div',null,[fk(Eq,pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[Eq])),[fk('h1',null,['todos']),(new Mn).a]),S(this.c.c)?null:fk('section',pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[Eq])),[fk(Cq,xk(Ak(pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,[Fq])),(Zk(),Ek)),Ah(bo.prototype.ib,bo,[this])),null),fk('ul',pk(new $wnd.Object,$c(Uc(ee,1),fq,2,6,['todo-list'])),(a=Aj(zj(S(this.e.c).R()),new Ji),Ii(a,Zc(a.a.length))))]),S(this.c.c)?null:(new Km).a])])};var ig=Rh(241);yh(69,241,{69:1});_.db=function(){return zm(this)};var _f=Rh(69);yh(70,69,{9:1,70:1,69:1},Bm);_.u=Uq;_.q=Jq;_.gb=Qq;_.s=Kq;_.db=function(){return B((J(),J(),I),this.a,new Fm(this))};var Am=0;var Gf=Rh(70);yh(121,1,jq,Cm);_.v=Vq;var Bf=Rh(121);yh(120,1,jq,Dm);_.v=Rq;var Cf=Rh(120);yh(122,1,mq,Em);_.v=Sq;var Df=Rh(122);yh(123,1,eq,Fm);_.t=function(){return zm(this.a)};var Ef=Rh(123);yh(199,1,Aq,Hm);_.D=function(){return Gm(this)};var Ff=Rh(199);yh(250,$wnd.Function,{},Jm);_.kb=function(a){tp(this.a.e)};yh(86,1,{},Km);var Hf=Rh(86);yh(97,1,Aq,Lm);_.D=function(){return ul((new ko(this.a)).a)};var If=Rh(97);yh(84,1,{},Mm);var Jf=Rh(84);yh(135,1,Aq,Nm);_.D=function(){return tl((new mo(this.a)).a.a)};var Kf=Rh(135);yh(261,$wnd.Function,{},Sm);_.eb=function(a){return new Xm(a)};var Tm;var Vm;yh(104,31,{},Xm);_.fb=function(){return ul((new ko(Vm.a)).a)};_.componentWillUnmount=Wq;var Nf=Rh(104);var Zm;yh(98,1,{260:1},$m);var Of=Rh(98);yh(287,$wnd.Function,{},_m);_.eb=function(a){return new en(a)};var an;var cn;yh(141,31,{},en);_.fb=function(){return tl((new mo(cn.a)).a.a)};_.componentWillUnmount=Xq;var Pf=Rh(141);var gn;yh(136,1,{286:1},hn);var Qf=Rh(136);yh(285,$wnd.Function,{},jn);_.eb=function(a){return new on(a)};var kn;var mn;yh(134,31,{},on);_.fb=function(){return Nl((new oo(mn.a)).a.a)};_.componentWillUnmount=Wq;var Tf=Rh(134);var qn;yh(126,1,{284:1},rn);var Uf=Rh(126);yh(273,$wnd.Function,{},sn);_.eb=function(a){return new xn(a)};var tn;var vn;yh(117,31,{},xn);_.fb=function(){return vm((new qo(vn.a)).a)};_.componentDidUpdate=function(a){fm(this.a)};_.componentWillUnmount=function(){jc(this.a.e)};_.shouldComponentUpdate=function(a){return _l(this.a,a)};var Wf=Rh(117);var zn;yh(106,1,{272:1},An);var Xf=Rh(106);yh(283,$wnd.Function,{},Bn);_.eb=function(a){return new Gn(a)};var Cn;var En;yh(124,31,{},Gn);_.fb=function(){return Gm((new so(En.a)).a)};_.componentWillUnmount=Xq;var Zf=Rh(124);var In;yh(119,1,{282:1},Jn);var $f=Rh(119);yh(254,$wnd.Function,{},Kn);_.jb=function(a){yl(this.a,a)};yh(255,$wnd.Function,{},Ln);_.ib=function(a){Cl(this.a,a)};yh(85,1,{},Mn);var ag=Rh(85);yh(125,1,Aq,Nn);_.D=function(){return Nl((new oo(this.a)).a.a)};var bg=Rh(125);yh(280,$wnd.Function,{},Pn);_.ib=function(a){am(this.a,a)};yh(274,$wnd.Function,{},Qn);_.ib=function(a){Vo(this.a)};yh(276,$wnd.Function,{},Rn);_.kb=function(a){dm(this.a,this.b)};yh(277,$wnd.Function,{},Sn);_.kb=function(a){Pl(this.a,this.b)};yh(278,$wnd.Function,{},Tn);_.w=function(a){Ql(this.a,a)};yh(279,$wnd.Function,{},Un);_.hb=function(a){em(this.a,this.b)};yh(281,$wnd.Function,{},Vn);_.jb=function(a){Rl(this.a,this.b,a)};yh(219,1,{},Zn);var dg=Rh(219);yh(105,1,Aq,$n);_.D=function(){return vm((new qo(this.a)).a)};var eg=Rh(105);yh(253,$wnd.Function,{},bo);_.ib=function(a){ym(this.a,a)};yh(88,1,{},co);var gg=Rh(88);yh(118,1,Aq,eo);_.D=function(){return Gm((new so(this.a)).a)};var hg=Rh(118);yh(146,1,{},io);var og=Rh(146);yh(48,1,{},ko);var jg=Rh(48);yh(52,1,{},mo);var kg=Rh(52);yh(51,1,{},oo);var lg=Rh(51);yh(49,1,{},qo);var mg=Rh(49);yh(50,1,{},so);var ng=Rh(50);yh(210,1,{});var Yg=Rh(210);yh(211,210,gq,Fo);_.u=Tq;_.q=Jq;_.s=Kq;var wg=Rh(211);yh(212,1,jq,Go);_.v=function(){zo(this.a)};var pg=Rh(212);yh(214,1,mq,Ho);_.v=function(){uo(this.a)};var qg=Rh(214);yh(215,1,mq,Io);_.v=function(){vo(this.a)};var rg=Rh(215);yh(217,1,jq,Jo);_.v=function(){Co(this.a)};var sg=Rh(217);yh(82,1,jq,Ko);_.v=function(){yo(this.a)};var tg=Rh(82);yh(213,1,eq,Lo);_.t=function(){var a;return a=(Ih(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var ug=Rh(213);yh(216,1,jq,Mo);_.v=function(){to(this.a,this.b)};var vg=Rh(216);yh(59,1,{59:1});_.d=false;var fh=Rh(59);yh(60,59,{9:1,292:1,60:1,59:1},Wo);_.u=Tq;_.q=function(a){return Po(this,a)};_.s=function(){return this.c.e};var No=0;var Pg=Rh(60);yh(220,1,jq,Xo);_.v=function(){Oo(this.a)};var xg=Rh(220);yh(221,1,jq,Yo);_.v=function(){So(this.a)};var yg=Rh(221);yh(56,168,{56:1});var _g=Rh(56);yh(169,56,{9:1,56:1},fp);_.u=function(){jc(this.f)};_.q=Jq;_.s=Kq;var Ig=Rh(169);yh(171,1,jq,gp);_.v=function(){$o(this.a)};var zg=Rh(171);yh(170,1,jq,hp);_.v=function(){cp(this.a)};var Ag=Rh(170);yh(176,1,jq,ip);_.v=function(){ec(this.a,this.b,true)};var Bg=Rh(176);yh(177,1,eq,jp);_.t=function(){return Zo(this.a,this.c,this.b)};_.b=false;var Cg=Rh(177);yh(172,1,eq,kp);_.t=function(){return dp(this.a)};var Dg=Rh(172);yh(173,1,eq,lp);_.t=function(){return _h(ph(xj(bp(this.a))))};var Eg=Rh(173);yh(174,1,eq,mp);_.t=function(){return _h(ph(xj(yj(bp(this.a),new Zp))))};var Fg=Rh(174);yh(175,1,eq,np);_.t=function(){return ep(this.a)};var Gg=Rh(175);yh(153,1,Aq,qp);_.D=function(){return new fp};var op;var Hg=Rh(153);yh(57,1,{57:1});var eh=Rh(57);yh(181,57,{9:1,57:1},xp);_.u=function(){jc(this.a)};_.q=Jq;_.s=Kq;var Og=Rh(181);yh(182,1,jq,yp);_.v=Yq;var Jg=Rh(182);yh(183,1,jq,zp);_.v=function(){up(this.a,this.b)};_.b=false;var Kg=Rh(183);yh(184,1,jq,Ap);_.v=function(){Eo(this.b,this.a)};var Lg=Rh(184);yh(185,1,jq,Bp);_.v=function(){vp(this.a)};var Mg=Rh(185);yh(154,1,Aq,Cp);_.D=function(){return new xp(this.a.D())};var Ng=Rh(154);yh(58,1,{58:1});var hh=Rh(58);yh(189,58,{9:1,58:1},Lp);_.u=function(){jc(this.g)};_.q=Jq;_.s=Kq;var Wg=Rh(189);yh(190,1,jq,Mp);_.v=function(){Fp(this.a)};var Qg=Rh(190);yh(191,1,eq,Np);_.t=function(){var a;return a=Bo(this.a.i),gi(Iq,a)||gi(Dq,a)||gi('',a)?gi(Iq,a)?(Wp(),Tp):gi(Dq,a)?(Wp(),Vp):(Wp(),Up):(Wp(),Up)};var Rg=Rh(191);yh(192,1,eq,Op);_.t=function(){return Hp(this.a)};var Sg=Rh(192);yh(193,1,mq,Pp);_.v=function(){Ip(this.a)};var Tg=Rh(193);yh(194,1,mq,Qp);_.v=function(){Jp(this.a)};var Ug=Rh(194);yh(155,1,Aq,Rp);_.D=function(){return new Lp(this.a.D())};var Vg=Rh(155);yh(208,1,{},Sp);_.handleEvent=function(a){wo(this.a,a)};var Xg=Rh(208);yh(34,33,{3:1,29:1,33:1,34:1},Xp);var Tp,Up,Vp;var Zg=Sh(34,Yp);yh(180,1,{},Zp);_.ab=function(a){return !Ro(a)};var $g=Rh(180);yh(187,1,{},$p);_.ab=function(a){return Ro(a)};var ah=Rh(187);yh(188,1,{},_p);_.w=function(a){ap(this.a,a)};var bh=Rh(188);yh(186,1,{},aq);_.w=function(a){sp(this.a,a)};_.a=false;var dh=Rh(186);yh(195,1,{},bq);_.ab=function(a){return Ep(this.a,a)};var gh=Rh(195);var cq=(zc(),Cc);var gwtOnLoad=gwtOnLoad=th;rh(Eh);uh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();