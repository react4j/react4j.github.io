function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='0BFC5360015C1543413A330B963265BE',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '0BFC5360015C1543413A330B963265BE';function o(){}
function th(){}
function ph(){}
function Ab(){}
function Pc(){}
function Wc(){}
function Kj(){}
function Lj(){}
function uk(){}
function Im(){}
function Om(){}
function Um(){}
function $m(){}
function en(){}
function po(){}
function Ao(){}
function Uo(){}
function fp(){}
function gp(){}
function Wp(){}
function Uc(a){Tc()}
function Mm(a){Lm=a}
function Sm(a){Rm=a}
function Ym(a){Xm=a}
function cn(a){bn=a}
function jn(a){hn=a}
function Eh(){Eh=ph}
function Hi(){yi(this)}
function H(a){this.a=a}
function G(a){this.a=a}
function eb(a){this.a=a}
function rb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function bc(a){this.a=a}
function dc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function jc(a){this.a=a}
function Vh(a){this.a=a}
function ei(a){this.a=a}
function qi(a){this.a=a}
function vi(a){this.a=a}
function wi(a){this.a=a}
function ui(a){this.b=a}
function Ji(a){this.c=a}
function Ij(a){this.a=a}
function Nj(a){this.a=a}
function jl(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function tl(a){this.a=a}
function El(a){this.a=a}
function Fl(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Kl(a){this.a=a}
function cm(a){this.a=a}
function dm(a){this.a=a}
function em(a){this.a=a}
function jm(a){this.a=a}
function mm(a){this.a=a}
function sm(a){this.a=a}
function tm(a){this.a=a}
function um(a){this.a=a}
function xm(a){this.a=a}
function Am(a){this.a=a}
function Dm(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function on(){this.a={}}
function zm(){this.a={}}
function Cm(){this.a={}}
function pn(a){this.a=a}
function rn(a){this.a=a}
function sn(a){this.a=a}
function vn(a){this.a=a}
function Cn(a){this.a=a}
function Fn(a){this.a=a}
function In(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function go(a){this.a=a}
function io(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function zo(a){this.a=a}
function Co(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function hp(a){this.a=a}
function ip(a){this.a=a}
function jp(a){this.a=a}
function Bn(){this.a={}}
function Hn(){this.a={}}
function Jj(a,b){a.a=b}
function Em(a,b){a.d=b}
function Fm(a,b){a.e=b}
function Gm(a,b){a.f=b}
function Hm(a,b){a.g=b}
function Dn(a,b){a.k=b}
function En(a,b){a.n=b}
function ck(a,b){bk(a,b)}
function ro(a,b){Tn(b,a)}
function C(a,b){xb(a.b,b)}
function Z(a){Jb((J(),a))}
function $(a){Kb((J(),a))}
function Sp(a){jj(this,a)}
function Vp(a){Zh(this,a)}
function _p(){pk(this.a)}
function eq(){rk(this.a)}
function Ti(){this.a=aj()}
function fj(){this.a=aj()}
function F(){this.b=new yb}
function oc(){this.b=new Ni}
function J(){J=ph;I=new F}
function Yi(){Yi=ph;Xi=$i()}
function w(a){--a.e;D(a)}
function xo(a){this.b=mj(a)}
function lb(a,b){a.b=mj(b)}
function nc(a,b){mi(a.b,b)}
function qo(a,b){$n(a.b,b)}
function Nl(a,b){_n(a.k,b)}
function Mj(a,b){Cj(a.a,b)}
function cb(a){Lb((J(),a))}
function _g(a){return a.e}
function cq(){return this.e}
function Pp(){return this.a}
function Up(){return this.b}
function Yp(){return this.c}
function Zp(){return this.d<0}
function dq(){return this.c<0}
function fq(){return this.f<0}
function Rp(){return Vj(this)}
function ai(a,b){return a===b}
function Ol(a,b){return a.g=b}
function Bi(a,b){return a.a[b]}
function Rj(a,b){a.splice(b,1)}
function lc(a,b,c){li(a.b,b,c)}
function Th(a){tc.call(this,a)}
function fi(a){tc.call(this,a)}
function Nm(a){gk.call(this,a)}
function Tm(a){gk.call(this,a)}
function Zm(a){gk.call(this,a)}
function dn(a){gk.call(this,a)}
function kn(a){gk.call(this,a)}
function Qp(a){return this===a}
function $p(){return J(),J(),I}
function Cc(){Cc=ph;!!(Tc(),Sc)}
function vc(){vc=ph;uc=new o}
function Mc(){Mc=ph;Lc=new Pc}
function wh(){wh=ph;vh=new o}
function oo(){oo=ph;no=new po}
function To(){To=ph;So=new Uo}
function aj(){Yi();return new Xi}
function Hh(a){Gh(a);return a.k}
function Bj(a,b){a.U(b);return a}
function Xc(a,b){return Nh(a,b)}
function Tp(){return oi(this.a)}
function aq(){return tk(this.a)}
function $h(){pc(this);this.I()}
function xh(a){this.a=vh;this.b=a}
function nl(a){mc(a.b);fb(a.a)}
function Vb(a){ab(a.b);return a.g}
function Ub(a){ab(a.a);return a.e}
function Qn(a){ab(a.a);return a.g}
function Pn(a){ab(a.b);return a.i}
function Fo(a){ab(a.d);return a.f}
function wk(a,b){a.ref=b;return a}
function cc(a,b){this.a=a;this.b=b}
function kc(a,b){this.a=a;this.b=b}
function Sh(a,b){this.a=a;this.b=b}
function xi(a,b){this.a=a;this.b=b}
function nj(a,b){while(a.fb(b));}
function Cj(a,b){Jj(a,Bj(a.a,b))}
function Xb(a){Tb(a,(ab(a.b),a.g))}
function Db(a){Eb(a);!a.d&&Hb(a)}
function W(a){J();Kb(a);a.e=-2}
function Kc(){zc!=0&&(zc=0);Bc=-1}
function ih(){gh==null&&(gh=[])}
function el(a,b){Sh.call(this,a,b)}
function Gl(a,b){this.a=a;this.b=b}
function Fj(a,b){this.a=a;this.b=b}
function kk(a,b){this.a=a;this.b=b}
function lk(a,b){this.a=a;this.b=b}
function gm(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function im(a,b){this.a=a;this.b=b}
function km(a,b){this.a=a;this.b=b}
function lm(a,b){this.a=a;this.b=b}
function tn(a,b){this.a=a;this.b=b}
function un(a,b){this.a=a;this.b=b}
function wn(a,b){this.a=a;this.b=b}
function xn(a,b){this.a=a;this.b=b}
function ho(a,b){this.a=a;this.b=b}
function Bo(a,b){this.a=a;this.b=b}
function yo(a,b){this.b=a;this.a=b}
function Ro(a,b){this.b=a;this.a=b}
function dp(a,b){Sh.call(this,a,b)}
function Rl(a,b){Ko(a.n,b);_l(a,b)}
function cj(a,b){return a.a.get(b)}
function oi(a){return a.a.b+a.b.b}
function ad(a){return new Array(a)}
function yn(a){return zn(new Bn,a)}
function md(a){return typeof a===mp}
function pd(a){return a==null?null:a}
function ki(a){return !a?null:a.bb()}
function Fb(a){return !a.d?a:Fb(a.d)}
function lj(a){return a!=null?r(a):0}
function Jc(a){$wnd.clearTimeout(a)}
function xk(a,b){a.href=b;return a}
function Hk(a,b){a.value=b;return a}
function Ck(a,b){a.onBlur=b;return a}
function ci(a,b){a.a+=''+b;return a}
function Gj(a,b){a.D(An(yn(b.e),b))}
function Pj(a,b,c){a.splice(b,0,c)}
function yk(a,b){a.onClick=b;return a}
function Ak(a,b){a.checked=b;return a}
function yi(a){a.a=Zc(je,pp,1,0,5,1)}
function ni(a){a.a=new Ti;a.b=new fj}
function db(a){this.c=new Hi;this.b=a}
function Xp(){return S(this.e.b).a>0}
function Sn(a){Tn(a,(ab(a.a),!a.g))}
function Bl(a){mc(a.c);fb(a.a);V(a.b)}
function hl(a){mc(a.c);fb(a.b);R(a.a)}
function ic(a,b){gc(a,b,false);$(a.d)}
function Ql(a,b){_l(a,b);Ko(a.n,null)}
function A(a,b,c){t(a,new G(b),c,null)}
function Qj(a,b){Oj(b,0,a,0,b.length)}
function Dk(a,b){a.onChange=b;return a}
function Ek(a,b){a.onKeyDown=b;return a}
function bk(a,b){for(var c in a){b(c)}}
function cd(a,b,c){return {l:a,m:b,h:c}}
function _h(a,b){return a.charCodeAt(b)}
function kd(a,b){return a!=null&&hd(a,b)}
function U(a){return !(!!a&&1==(a.c&7))}
function Vj(a){return a.$H||(a.$H=++Uj)}
function od(a){return typeof a==='string'}
function kb(a){J();jb(a);mb(a,2,true)}
function ab(a){var b;Gb((J(),b=Bb,b),a)}
function qc(a,b){a.e=b;b!=null&&Tj(b,Ap,a)}
function Gh(a){if(a.k!=null){return}Ph(a)}
function zk(a){a.autoFocus=true;return a}
function Bk(a,b){a.defaultValue=b;return a}
function Aj(a,b){vj.call(this,a);this.a=b}
function tc(a){this.f=a;pc(this);this.I()}
function Ni(){this.a=new Ti;this.b=new fj}
function Zj(){Zj=ph;Wj=new o;Yj=new o}
function Bh(){Bh=ph;Ah=$wnd.window.document}
function Yh(){Yh=ph;Xh=Zc(fe,pp,32,256,0,1)}
function P(){this.a=Zc(je,pp,1,100,5,1)}
function jj(a,b){while(a.Z()){Mj(b,a.$())}}
function hc(a,b){nc(b.F(),a);kd(b,11)&&b.A()}
function Rn(a){mc(a.c);V(a.d);V(a.b);V(a.a)}
function eo(a){return Wh(S(a.e).a-S(a.a).a)}
function ym(a){return hk((Km(),Jm),a.a,null)}
function Bm(a){return hk((Qm(),Pm),a.a,null)}
function nn(a){return hk((Wm(),Vm),a.a,null)}
function Gn(a){return hk((gn(),fn),a.a,null)}
function u(a,b){return new pb(mj(a),null,b)}
function Dc(a,b,c){return a.apply(b,c);var d}
function Tj(b,c,d){try{b[c]=d}catch(a){}}
function Vi(a,b){var c;c=a[Fp];c.call(a,b)}
function zn(a,b){mj(b);a.a['key']=b;return a}
function Ik(a,b){a.onDoubleClick=b;return a}
function pc(a){a.g&&a.e!==zp&&a.I();return a}
function Mh(){var a;a=Jh(null);a.e=2;return a}
function Kh(a){var b;b=Jh(a);Rh(a,b);return b}
function zh(a){if(!a){throw _g(new $h)}return a}
function zi(a,b){a.a[a.a.length]=b;return true}
function Qb(a,b){a.i&&b.preventDefault();_b(a)}
function ib(a,b){Y(b,a);b.c.a.length>0||(b.a=4)}
function Al(a,b){var c;c=b.target;Cl(a,c.value)}
function jo(a,b){this.a=a;this.c=b;this.b=false}
function ij(a,b,c){this.a=a;this.b=b;this.c=c}
function vl(a,b,c){this.a=a;this.b=b;this.c=c}
function om(a,b,c){this.a=a;this.b=b;this.c=c}
function wm(a,b,c){this.a=a;this.b=b;this.c=c}
function Xo(a){this.b=a;this.a=new tl(this.b.a)}
function Yo(a){this.b=a;this.a=new Kl(this.b.b)}
function oj(a,b){this.e=a;this.d=(b&64)!=0?b|np:b}
function pj(a){if(!a.d){a.d=a.b.T();a.c=a.b.V()}}
function zb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Dj(a,b,c){if(a.a.gb(c)){a.b=true;b.D(c)}}
function bj(a,b){return !(a.a.get(b)===undefined)}
function ld(a){return typeof a==='boolean'}
function co(a){return Eh(),0==S(a.e).a?true:false}
function gl(a){return Eh(),S(a.e.b).a>0?true:false}
function Do(a){return ai(Op,a)||ai(Lp,a)||ai('',a)}
function _c(a){return Array.isArray(a)&&a.Ab===th}
function jd(a){return !Array.isArray(a)&&a.Ab===th}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Qc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Di(a,b){var c;c=a.a[b];Rj(a.a,b);return c}
function Fi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function si(a){var b;b=a.a.$();a.b=ri(a);return b}
function Go(a){fb(a.e);fb(a.a);R(a.b);R(a.c);V(a.d)}
function Vl(a){mc(a.e);fb(a.b);R(a.d);V(a.c);V(a.a)}
function Cl(a,b){var c;c=a.f;if(b!=c){a.f=b;$(a.b)}}
function am(a,b){var c;c=a.i;if(b!=c){a.i=b;$(a.a)}}
function Tn(a,b){var c;c=a.g;if(b!=c){a.g=b;$(a.a)}}
function pm(a,b){var c;c=b.target;wo(a.e,c.checked)}
function sl(a){var b;b=new ol;Em(b,a.a.K());return b}
function Jl(a){var b;b=new Dl;Fm(b,a.a.K());return b}
function Gk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function pi(a,b){if(b){return ii(a.a,b)}return false}
function xj(a,b){uj(a);return new Aj(a,new Ej(b,a.a))}
function yj(a){uj(a);return new Aj(a,new Hj(a.a))}
function fh(a){if(md(a)){return a|0}return a.l|a.m<<22}
function mj(a){if(a==null){throw _g(new $h)}return a}
function ak(){if(Xj==256){Wj=Yj;Yj=new o;Xj=0}++Xj}
function Tc(){Tc=ph;var a;!Vc();a=new Wc;Sc=a}
function Hj(a){oj.call(this,a.eb(),a.db()&-6);this.a=a}
function vj(a){if(!a){this.b=null;new Hi}else{this.b=a}}
function tj(a){if(!a.b){uj(a);a.c=true}else{tj(a.b)}}
function wb(a){while(true){if(!ub(a)&&!vb(a)){break}}}
function bb(a){var b;J();!!Bb&&!!Bb.e&&Gb((b=Bb,b),a)}
function Zb(a,b){var c;c=a.e;if(b!=c){a.e=mj(b);$(a.a)}}
function $b(a,b){var c;c=a.g;if(b!=c){a.g=mj(b);$(a.b)}}
function Un(a,b){var c;c=a.i;if(b!=c){a.i=mj(b);$(a.b)}}
function Lh(a,b){var c;c=Jh(a);Rh(a,c);c.e=b?8:0;return c}
function Mi(a,b){return pd(a)===pd(b)||a!=null&&p(a,b)}
function sk(a){qk(a);return kd(a,11)&&a.B()?null:a.qb()}
function Wl(a,b,c,d){return Eh(),Tl(a,b,c,d)?true:false}
function ep(){cp();return bd(Xc(Pg,1),pp,37,0,[_o,bp,ap])}
function An(a,b){a.a['a']=b;return hk((an(),_m),a.a,null)}
function jk(a,b,c){a[c]===undefined&&(a[c]=b[c],undefined)}
function fm(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function Mb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function Uh(a){this.f=!a?null:rc(a,a.H());pc(this);this.I()}
function dk(a,b){null!=b&&a.lb(b,a.q.props,true);a.ib()}
function pk(a){if(!a.o){a.o=true;a.p||a.q.forceUpdate()}}
function Cb(a){if(a.e){2==(a.e.c&7)||mb(a.e,4,true);jb(a.e)}}
function Oh(a){if(a.R()){return null}var b=a.j;return lh[b]}
function Nb(a,b){Bb=new Mb(Bb,b);a.d=false;Cb(Bb);return Bb}
function qj(a,b){this.b=a;this.a=(b&4096)==0?b|64|np:b}
function ji(a,b){return b===a?'(this Map)':b==null?Cp:sh(b)}
function rc(a,b){var c;c=Hh(a.yb);return b==null?c:c+': '+b}
function Ml(a,b){var c;if(S(a.d)){c=b.target;am(a,c.value)}}
function Zh(a,b){var c,d;for(d=a.T();d.Z();){c=d.$();b.D(c)}}
function uo(a,b){var c;zj(ao(a.b),(c=new Hi,c)).S(new ip(b))}
function xb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],mj(b))}
function xl(a,b){if(13==b.keyCode){b.preventDefault();yl(a)}}
function Pl(a,b,c){27==c.which?Yl(a,b):13==c.which&&$l(a,b)}
function Ic(a){Cc();$wnd.setTimeout(function(){throw a},0)}
function Pi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Nh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.M(b))}
function nh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function gn(){gn=ph;var a;fn=(a=qh(en.prototype.mb,en,[]),a)}
function an(){an=ph;var a;_m=(a=qh($m.prototype.mb,$m,[]),a)}
function Km(){Km=ph;var a;Jm=(a=qh(Im.prototype.mb,Im,[]),a)}
function Qm(){Qm=ph;var a;Pm=(a=qh(Om.prototype.mb,Om,[]),a)}
function Wm(){Wm=ph;var a;Vm=(a=qh(Um.prototype.mb,Um,[]),a)}
function rh(a){function b(){}
;b.prototype=a||{};return new b}
function yh(a){wh();zh(a);if(kd(a,46)){return a}return new xh(a)}
function Pb(a,b){a.j=b;ai(b,(ab(a.a),a.e))&&$b(a,b);Rb(b);_b(a)}
function Io(a){var b;b=(ab(a.d),a.f);!!b&&!!b&&b.f<0&&Ko(a,null)}
function gb(a){var b;b=(J(),J(),I);xb(b.b,a);0!=(a.c&vp)&&D(b)}
function Qi(a,b){var c;return Oi(b,Pi(a,b==null?0:(c=r(b),c|0)))}
function ao(a){ab(a.d);return new Aj(null,new qj(new vi(a.g),0))}
function Ii(a){yi(this);Qj(this.a,hi(a,Zc(je,pp,1,oi(a.a),5,1)))}
function Wo(a){this.b=a;this.a=new vl(this.b.a,this.b.b,this.b.c)}
function Zo(a){this.b=a;this.a=new om(this.b.a,this.b.b,this.b.c)}
function $o(a){this.b=a;this.a=new wm(this.b.a,this.b.b,this.b.c)}
function Ui(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function bq(){return Fo(this.n)==(bb(this.c),this.q.props['a'])}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&np)?np:8192)|0|0,b)}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&np)?np:8192)|0|0,b)}
function Ch(a,b,c,d){a.addEventListener(b,c,(Eh(),d?true:false))}
function Dh(a,b,c,d){a.removeEventListener(b,c,(Eh(),d?true:false))}
function Gc(a,b,c){var d;d=Ec();try{return Dc(a,b,c)}finally{Hc(d)}}
function Ko(a,b){var c;c=a.f;if(!(b==c||!!b&&On(b,c))){a.f=b;$(a.d)}}
function X(a,b){var c,d;zi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function rj(a,b){!a.a?(a.a=new ei(a.d)):ci(a.a,a.b);ci(a.a,b);return a}
function zj(a,b){var c;tj(a);c=new Kj;c.a=b;a.a.Y(new Nj(c));return c.a}
function wj(a){var b;tj(a);b=0;while(a.a.fb(new Lj)){b=ah(b,1)}return b}
function Fk(a){a.placeholder='What needs to be done?';return a}
function sc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Fc(b){Cc();return function(){return Gc(b,this,arguments);var a}}
function yc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Nn(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Xn(a)),up,null)}}
function to(a){var b;zj(xj(ao(a.b),new gp),(b=new Hi,b)).S(new hp(a.b))}
function nm(a){var b;b=new bm;Dn(b,a.a.K());a.b.K();En(b,a.c.K());return b}
function On(a,b){var c;if(kd(b,53)){c=b;return a.e==c.e}else{return false}}
function mi(a,b){return od(b)?b==null?Si(a.a,null):ej(a.b,b):Si(a.a,b)}
function Eo(a,b){return (cp(),ap)==a||(_o==a?(ab(b.a),!b.g):(ab(b.a),b.g))}
function Xl(a){return Eh(),Fo(a.n)==(bb(a.c),a.q.props['a'])?true:false}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Hc(a){a&&Oc((Mc(),Lc));--zc;if(a){if(Bc!=-1){Jc(Bc);Bc=-1}}}
function wl(a){var b;b=bi((ab(a.b),a.f));if(b.length>0){qo(a.e,b);Cl(a,'')}}
function tk(a){var b;a.o=false;if(a.ob()){return null}else{b=a.kb();return b}}
function hj(a){if(a.a.c!=a.c){return cj(a.a,a.b.value[0])}return a.b.value[1]}
function gj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function ti(a){this.d=a;this.c=new gj(this.d.b);this.a=this.c;this.b=ri(this)}
function sj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Ej(a,b){oj.call(this,b.eb(),b.db()&-16449);this.a=a;this.c=b}
function ik(a,b,c){!ai(c,'key')&&!ai(c,'ref')&&(a[c]=b[c],undefined)}
function Ci(a,b,c){for(;c<a.a.length;++c){if(Mi(b,a.a[c])){return c}}return -1}
function Zc(a,b,c,d,e,f){var g;g=$c(e,d);e!=10&&bd(Xc(a,f),b,c,e,g);return g}
function Ei(a,b){var c;c=Ci(a,b,0);if(c==-1){return false}Rj(a.a,c);return true}
function ul(a){var b;b=new il;Fm(b,a.a.K());Gm(b,a.b.K());Hm(b,a.c.K());return b}
function vm(a){var b;b=new rm;Em(b,a.a.K());Fm(b,a.b.K());Gm(b,a.c.K());return b}
function ek(a,b){var c;c=null!=b&&a.lb(a.q.props,b,false);c||(a.r=false);return c}
function fk(a,b){var c;if(b){c=a.r;a.r=false;return !c}else{a.r=true;return true}}
function Ai(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.D(c)}}
function Ho(a){var b,c;return b=S(a.b),zj(xj(ao(a.j),new jp(b)),(c=new Hi,c))}
function li(a,b,c){return od(b)?b==null?Ri(a.a,null,c):dj(a.b,b,c):Ri(a.a,b,c)}
function Sj(a,b){return Yc(b)!=10&&bd(q(b),b.zb,b.__elementTypeId$,Yc(b),a),a}
function Yc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nd(a){return a!=null&&(typeof a===lp||typeof a==='function')&&!(a.Ab===th)}
function Wb(a){Dh((Bh(),$wnd.window.window),xp,a.f,false);mc(a.c);V(a.b);V(a.a)}
function bo(a){Zh(new vi(a.g),new jc(a));ni(a.g);R(a.c);R(a.e);R(a.a);R(a.b);V(a.d)}
function R(a){if(!a.a){a.a=true;a.g=null;a.b=null;V(a.d);2==(a.e.c&7)||fb(a.e)}}
function V(a){if(-2!=a.e){t((J(),J(),I),new G(new eb(a)),0,null);!!a.b&&fb(a.b)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{wb(a.b)}finally{a.c=false}}}}
function Nc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Rc(b,c)}while(a.a);a.a=c}}
function Oc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Rc(b,c)}while(a.b);a.b=c}}
function Gb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;zi((!a.b&&(a.b=new Hi),a.b),b)}}}
function Rh(a,b){var c;if(!a){return}b.j=a;var d=Oh(b);if(!d){lh[a]=[b];return}d.yb=b}
function $g(a){var b;if(kd(a,4)){return a}b=a&&a[Ap];if(!b){b=new xc(a);Uc(b)}return b}
function ub(a){var b;if(0==O(a.c)){return false}else{b=N(a.c);!!b&&b.A();return true}}
function qh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Jh(a){var b;b=new Ih;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function ej(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Vi(a.a,b);--a.b}return c}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,mj(b))}
function Ib(a,b){var c;if(!a.c){c=Fb(a);!c.c&&(c.c=new Hi);a.c=c.c}b.d=true;zi(a.c,mj(b))}
function jb(a){var b,c;for(c=new Ji(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ki(a){var b,c,d;d=0;for(c=new ti(a.a);c.b;){b=si(c);d=d+(b?r(b):0);d=d|0}return d}
function gi(a,b){var c,d;for(d=new ti(b.a);d.b;){c=si(d);if(!pi(a,c)){return false}}return true}
function Zn(a,b,c){var d;d=new Wn(b,c);lc(d.c,a,new kc(a,d));li(a.g,Wh(d.e),d);$(a.d);return d}
function gc(a,b,c){var d;d=mi(a.g,b?Wh(b.e):null);if(null!=d){nc(b.c,a);c&&!!b&&Nn(b);$(a.d)}}
function rk(a){var b;b=(++a.pb().e,new Ab);try{a.p=true;kd(a,11)&&a.A()}finally{zb(b)}}
function Ob(){var a;try{Db(Bb);J()}finally{a=Bb.d;!a&&((J(),J(),I).d=true);Bb=Bb.d}}
function hh(){ih();var a=gh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function cp(){cp=ph;_o=new dp('ACTIVE',0);bp=new dp('COMPLETED',1);ap=new dp('ALL',2)}
function ol(){++nk;this.b=new oc;this.a=new pb(null,mj((J(),new pl(this))),Ip);D((null,I))}
function rm(){++nk;this.b=new oc;this.a=new pb(null,mj((J(),new sm(this))),Ip);D((null,I))}
function gk(a){$wnd.React.Component.call(this,a);this.a=this.nb();this.a.q=mj(this);this.a.jb()}
function ri(a){if(a.a.Z()){return true}if(a.a!=a.c){return false}a.a=new Ui(a.d.a);return a.a.Z()}
function bh(a){var b;b=a.h;if(b==0){return a.l+a.m*vp}if(b==1048575){return a.l+a.m*vp-Dp}return a}
function eh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Dp;d=1048575}c=qd(e/vp);b=qd(e-c*vp);return cd(b,c,d)}
function Oi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Mi(a,c.ab())){return c}}return null}
function Tl(a,b,c,d){var e,f;e=false;f=fk(a,d);if(!(b['a']===c['a'])){f&&$(a.c);e=true}return e||a.o}
function bd(a,b,c,d,e){e.yb=a;e.zb=b;e.Ab=th;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function dj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Y(a,b){var c,d;d=a.c;Ei(d,b);d.a.length==0&&!!a.b&&rp!=(a.b.c&sp)&&(a.d||Ib((J(),c=Bb,c),a))}
function Jo(a){var b;b=Ub(a.i);ai(Op,b)||ai(Lp,b)||ai('',b)?Tb(a.i,b):Do(Vb(a.i))?Yb(a.i):Tb(a.i,'')}
function Sl(a,b){var c;c=(ab(a.a),a.i);if(null!=c&&c.length!=0){vo(b,c);Ko(a.n,null);am(a,c)}else{_n(a.k,b)}}
function S(a){ab(a.d);nb(a.e)&&hb(a.e);if(a.b){if(kd(a.b,5)){throw _g(a.b)}else{throw _g(a.b)}}return a.g}
function fb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new sb(a)),up,null);!!a.a&&R(a.a);a.c=a.c&-8|1}}
function qk(a){if(!ok){ok=(++a.pb().e,new Ab);$wnd.Promise.resolve(null).then(qh(uk.prototype.L,uk,[]))}}
function uj(a){if(a.b){uj(a.b)}else if(a.c){throw _g(new Th("Stream already terminated, can't be modified or used"))}}
function kh(a,b){typeof window===lp&&typeof window['$gwt']===lp&&(window['$gwt'][a]=b)}
function xc(a){vc();pc(this);this.e=a;a!=null&&Tj(a,Ap,this);this.f=a==null?Cp:sh(a);this.a='';this.b=a;this.a=''}
function Ih(){this.g=Fh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function T(a,b){this.c=mj(a);this.f=null;this.g=null;this.e=new qb(this,b);this.d=new db(this.e);rp==(b&sp)&&gb(this.e)}
function Vo(){this.a=yh((oo(),oo(),no));this.b=yh(new Co(this.a));this.d=yh((To(),To(),So));this.c=yh(new Ro(this.a,this.d))}
function ob(a,b,c,d){this.b=new Hi;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&gb(this)}
function Dl(){var a;++nk;this.c=new oc;this.b=(a=new db((J(),null)),a);this.a=new pb(null,mj(new Hl(this)),Ip);D((null,I))}
function Wh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Yh(),Xh)[b];!c&&(c=Xh[b]=new Vh(a));return c}return new Vh(a)}
function sh(a){var b;if(Array.isArray(a)&&a.Ab===th){return Hh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function _j(a){Zj();var b,c,d;c=':'+a;d=Yj[c];if(d!=null){return qd(d)}d=Wj[c];b=d==null?$j(a):qd(d);ak();Yj[c]=b;return b}
function Li(a){var b,c,d;d=1;for(c=new Ji(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function mc(a){var b,c;if(!a.a){for(c=new Ji(new Ii(new vi(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.C()}a.a=true}}
function Sb(a){var b,c;c=(b=(Bh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));Zb(a,c);ai(a.j,c)&&$b(a,c)}
function dd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return cd(c&4194303,d&4194303,e&1048575)}
function ah(a,b){var c;if(md(a)&&md(b)){c=a+b;if(-17592186044416<c&&c<Dp){return c}}return bh(dd(md(a)?eh(a):a,md(b)?eh(b):b))}
function q(a){return od(a)?me:md(a)?be:ld(a)?_d:jd(a)?a.yb:_c(a)?a.yb:a.yb||Array.isArray(a)&&Xc(Td,1)||Td}
function p(a,b){return od(a)?ai(a,b):md(a)?a===b:ld(a)?a===b:jd(a)?a.s(b):_c(a)?a===b:!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function r(a){return od(a)?_j(a):md(a)?qd(a):ld(a)?a?1231:1237:jd(a)?a.u():_c(a)?Vj(a):!!a&&!!a.hashCode?a.hashCode():Vj(a)}
function fl(){dl();return bd(Xc(af,1),pp,10,0,[Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl])}
function il(){++nk;this.c=new oc;this.a=new T((J(),new jl(this)),136486912);this.b=new pb(null,mj(new ll(this)),Ip);D((null,I))}
function yb(){this.c=new P;this.d=Zc(ud,pp,20,5,0,1);this.d[0]=new P;this.d[1]=new P;this.d[2]=new P;this.d[3]=new P;this.d[4]=new P}
function Ll(a){var b;b=S(a.d);if(!a.j&&b){a.j=true;_l(a,(bb(a.c),a.q.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function Qh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Gi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Sj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function vk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Ec(){var a;if(zc!=0){a=yc();if(a-Ac>2000){Ac=a;Bc=$wnd.setTimeout(Kc,10)}}if(zc++==0){Nc((Mc(),Lc));return true}return false}
function Vc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function mk(a,b,c,d,e){var f;f=new $wnd.Object;f.$$typeof=$wnd.React.Element;f.type=mj(a);f.key=b;f.ref=c;f.props=mj(d);f._owner=e;return f}
function hd(a,b){if(od(a)){return !!gd[b]}else if(a.zb){return !!a.zb[b]}else if(md(a)){return !!fd[b]}else if(ld(a)){return !!ed[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function pb(a,b,c){ob.call(this,null,a,b,c|(!a?262144:rp)|(a?np:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:vp)|(0!=(c&229376)?0:98304)|0|0|0)}
function Lb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&mb(b,5,true)}}}
function Kb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Ji(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&mb(b,6,true)}}}
function Jb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?mb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function bi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function $c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Hb(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=Di(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&mb(c.b,3,true);++b}}}return b}
function Wn(a,b){var c,d,e;this.i=mj(a);this.g=b;this.e=Mn++;this.d=(d=new db((J(),null)),d);this.c=new oc;this.b=(e=new db(null),e);this.a=(c=new db(null),c)}
function Yb(b){var c;try{A((J(),J(),I),new dc(b),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){c=a;throw _g(c)}else if(kd(a,4)){c=a;throw _g(new Uh(c))}else throw _g(a)}}
function _b(b){var c;try{A((J(),J(),I),new ec(b),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){c=a;throw _g(c)}else if(kd(a,4)){c=a;throw _g(new Uh(c))}else throw _g(a)}}
function yl(b){var c;try{A((J(),J(),I),new Fl(b),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){c=a;throw _g(c)}else if(kd(a,4)){c=a;throw _g(new Uh(c))}else throw _g(a)}}
function Vn(b){var c;try{A((J(),J(),I),new Yn(b),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){c=a;throw _g(c)}else if(kd(a,4)){c=a;throw _g(new Uh(c))}else throw _g(a)}}
function so(b){var c;try{A((J(),J(),I),new zo(b),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){c=a;throw _g(c)}else if(kd(a,4)){c=a;throw _g(new Uh(c))}else throw _g(a)}}
function vo(b,c){var d;try{A((J(),J(),I),new yo(b,c),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function wo(b,c){var d;try{A((J(),J(),I),new Bo(b,c),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function _n(b,c){var d;try{A((J(),J(),I),new ho(b,c),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function $l(b,c){var d;try{A((J(),J(),I),new hm(b,c),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function Ul(b,c){var d;try{A((J(),J(),I),new lm(b,c),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function Yl(b,c){var d;try{A((J(),J(),I),new km(b,c),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function Zl(b,c){var d;try{A((J(),J(),I),new im(b,c),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function _l(b,c){var d;try{A((J(),J(),I),new gm(b,c),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function zl(b,c){var d;try{A((J(),J(),I),new Gl(b,c),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function Tb(b,c){var d;try{A((J(),J(),I),new cc(b,c),75505664)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function $n(b,c){var d;try{return t((J(),J(),I),new jo(b,c),yp,null)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){d=a;throw _g(d)}else if(kd(a,4)){d=a;throw _g(new Uh(d))}else throw _g(a)}}
function jh(b,c,d,e){ih();var f=gh;$moduleName=c;$moduleBase=d;Zg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{kp(g)()}catch(a){b(c,a)}}else{kp(g)()}}
function qb(a,b){ob.call(this,a,new rb(a),null,b|(rp==(b&sp)?0:524288)|(0!=(b&6291456)?0:rp==(b&sp)?vp:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function uh(){var a;a=new Vo;Mm(new Am(a));Sm(new Dm(a));cn(new Cn(a));jn(new In(a));Ym(new pn(a));$wnd.ReactDOM.render(Gn(new Hn),(Bh(),Ah).getElementById('todoapp'),null)}
function $i(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return _i()}}
function fo(){var a;this.g=new Ni;this.d=(a=new db((J(),null)),a);this.c=new T(new io(this),Np);this.e=new T(new ko(this),Np);this.a=new T(new lo(this),Np);this.b=new T(new mo(this),Np)}
function bm(){var a,b;++nk;this.e=new oc;this.c=(b=new db((J(),null)),b);this.a=(a=new db(null),a);this.d=new T(new jm(this),136486912);this.b=new pb(null,mj(new mm(this)),Ip);D((null,I))}
function Lo(a,b){var c;this.j=mj(a);this.i=mj(b);this.d=(c=new db((J(),null)),c);this.b=new T(new No(this),Np);this.c=new T(new Oo(this),Np);this.e=u(new Po(this),413155328);this.a=u(new Qo(this),681590784);D((null,I))}
function hi(a,b){var c,d,e,f,g;g=oi(a.a);b.length<g&&(b=Sj(new Array(g),b));e=(f=new ti((new qi(a.a)).a),new wi(f));for(d=0;d<g;++d){b[d]=(c=si(e.a),c.bb())}b.length>g&&(b[g]=null);return b}
function mh(){lh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Rc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Bb()&&(c=Qc(c,g)):g[0].Bb()}catch(a){a=$g(a);if(kd(a,4)){d=a;Cc();Ic(kd(d,40)?d.J():d)}else throw _g(a)}}return c}
function wc(a){var b;if(a.c==null){b=pd(a.b)===pd(uc)?null:a.b;a.d=b==null?Cp:nd(b)?b==null?null:b.name:od(b)?'String':Hh(q(b));a.a=a.a+': '+(nd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.g;try{d=b.c.w();if(!(pd(e)===pd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;Z(b.d)}}catch(a){a=$g(a);if(kd(a,12)){c=a;if(!b.b){b.g=null;b.b=c;Z(b.d)}throw _g(c)}else throw _g(a)}}
function Oj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Ri(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Oi(b,e);if(f){return f.cb(c)}}e[e.length]=new xi(b,c);++a.b;return null}
function $j(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+_h(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Zc(je,pp,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Bb){g=np==(d&np)?c.w():c.w()}else{Nb(b,e);try{g=np==(d&np)?c.w():c.w()}finally{Ob()}}return g}catch(a){a=$g(a);if(kd(a,4)){f=a;throw _g(f)}else throw _g(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Bb){g=np==(d&np)?(c.a.C(),null):(c.a.C(),null)}else{Nb(b,e);try{g=np==(d&np)?(c.a.C(),null):(c.a.C(),null)}finally{Ob()}}return g}catch(a){a=$g(a);if(kd(a,4)){f=a;throw _g(f)}else throw _g(a)}finally{D(b)}}
function Rb(a){var b;if(0==a.length){b=(Bh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Ah.title,b)}else{(Bh(),$wnd.window.window).location.hash=a}}
function hb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.C()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=$g(a);if(kd(a,4)){J()}else throw _g(a)}}}
function Si(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Mi(b,e.ab())){if(d.length==1){d.length=0;Vi(a.a,g)}else{d.splice(h,1)}--a.b;return e.bb()}}return null}
function oh(a,b,c){var d=lh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=lh[b]),rh(h));_.zb=c;!b&&(_.Ab=th);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.yb=f)}
function Ph(a){if(a.Q()){var b=a.c;b.R()?(a.k='['+b.j):!b.Q()?(a.k='[L'+b.O()+';'):(a.k='['+b.O());a.b=b.N()+'[]';a.i=b.P()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Qh('.',[c,Qh('$',d)]);a.b=Qh('.',[c,Qh('.',d)]);a.i=d[d.length-1]}
function ac(){var a,b,c;this.f=new fc(this);this.c=new oc;this.b=(c=new db((J(),null)),c);this.a=(b=new db(null),b);Ch((Bh(),$wnd.window.window),xp,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function ii(a,b){var c,d,e;c=b.ab();e=b.bb();d=od(c)?c==null?ki(Qi(a.a,null)):cj(a.b,c):ki(Qi(a.a,c));if(!(pd(e)===pd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(od(c)?c==null?!!Qi(a.a,null):bj(a.b,c):!!Qi(a.a,c))){return false}return true}
function nb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ji(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=$g(a);if(!kd(a,4))throw _g(a)}if(6==(b.c&7)){return true}}}}}jb(b);return false}
function vb(a){var b,c,d,e,f,g,h,i;d=O(a.d[0]);c=O(a.d[1]);g=O(a.d[2]);e=O(a.d[3]);f=O(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=N(b);h.c&=-513;hb(h);return true}
function Zi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function mb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){cb(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}Ai(a.b,new tb(a));a.b.a=Zc(je,pp,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function hk(a,b,c){var d,e,f,g,h;d={};f=null;g=null;if(null!=b){f='key' in b?''+b['key']:null;g='ref' in b?b['ref']:null;ck(b,qh(kk.prototype.hb,kk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));h=a;e=h['defaultProps'];null!=e&&ck(e,qh(lk.prototype.hb,lk,[d,e]));return mk(a,f,g,d,$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current)}
function dl(){dl=ph;Jk=new el(Gp,0);Kk=new el('checkbox',1);Lk=new el('color',2);Mk=new el('date',3);Nk=new el('datetime',4);Ok=new el('email',5);Pk=new el('file',6);Qk=new el('hidden',7);Rk=new el('image',8);Sk=new el('month',9);Tk=new el(mp,10);Uk=new el('password',11);Vk=new el('radio',12);Wk=new el('range',13);Xk=new el('reset',14);Yk=new el('search',15);Zk=new el('submit',16);$k=new el('tel',17);_k=new el('text',18);al=new el('time',19);bl=new el('url',20);cl=new el('week',21)}
function Eb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Bi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Fi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Y(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&mb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Bi(a.b,g);if(-1==k.e){k.e=0;X(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Di(a.b,g)}e&&lb(a.e,a.b)}else{e&&lb(a.e,new Hi)}if(U(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&rp!=(b.e.c&sp)&&Ib(a,k)}}
function _i(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Fp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Zi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Fp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var lp='object',mp='number',np=16384,op={15:1},pp={3:1,6:1},qp={11:1},rp=1048576,sp=1835008,tp={8:1},up=67108864,vp=4194304,wp={30:1},xp='hashchange',yp=142614528,zp='__noinit__',Ap='__java$exception',Bp={3:1,12:1,5:1,4:1},Cp='null',Dp=17592186044416,Ep={44:1},Fp='delete',Gp='button',Hp='selected',Ip=1478635520,Jp={11:1,39:1},Kp='input',Lp='completed',Mp='header',Np=136421376,Op='active';var _,lh,gh,Zg=-1;mh();oh(1,null,{},o);_.s=Qp;_.t=function(){return this.yb};_.u=Rp;_.v=function(){var a;return Hh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.s(a)};_.hashCode=function(){return this.u()};_.toString=function(){return this.v()};var ed,fd,gd;oh(55,1,{},Ih);_.M=function(a){var b;b=new Ih;b.e=4;a>1?(b.c=Nh(this,a-1)):(b.c=this);return b};_.N=function(){Gh(this);return this.b};_.O=function(){return Hh(this)};_.P=function(){Gh(this);return this.i};_.Q=function(){return (this.e&4)!=0};_.R=function(){return (this.e&1)!=0};_.v=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Gh(this),this.k)};_.e=0;_.g=0;var Fh=1;var je=Kh(1);var ae=Kh(55);oh(89,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var td=Kh(89);oh(16,1,op,G);_.w=function(){return this.a.C(),null};var rd=Kh(16);oh(90,1,{},H);var sd=Kh(90);var I;oh(20,1,{20:1},P);_.b=0;_.c=false;_.d=0;var ud=Kh(20);oh(228,1,qp);_.v=function(){var a;return Hh(this.yb)+'@'+(a=r(this)>>>0,a.toString(16))};var wd=Kh(228);oh(21,228,qp,T);_.A=function(){R(this)};_.B=Pp;_.a=false;var vd=Kh(21);oh(17,228,{11:1,17:1},db);_.A=function(){V(this)};_.B=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var yd=Kh(17);oh(151,1,tp,eb);_.C=function(){W(this.a)};var xd=Kh(151);oh(19,228,{11:1,19:1},pb,qb);_.A=function(){fb(this)};_.B=function(){return 1==(this.c&7)};_.c=0;var Cd=Kh(19);oh(152,1,wp,rb);_.C=function(){Q(this.a)};var zd=Kh(152);oh(153,1,tp,sb);_.C=function(){kb(this.a)};var Ad=Kh(153);oh(154,1,{},tb);_.D=function(a){ib(this.a,a)};var Bd=Kh(154);oh(115,1,{},yb);_.a=0;_.b=100;_.e=0;var Dd=Kh(115);oh(71,1,qp,Ab);_.A=function(){zb(this)};_.B=Pp;_.a=false;var Ed=Kh(71);oh(160,1,{},Mb);_.v=function(){var a;return Gh(Fd),Fd.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.a=0;var Bb;var Fd=Kh(160);oh(51,1,{51:1});_.e='';_.g='';_.i=true;_.j='';var Md=Kh(51);oh(155,51,{11:1,51:1,39:1},ac);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new bc(this)),up,null)}};_.s=Qp;_.F=Yp;_.u=Rp;_.B=Zp;_.v=function(){var a;return Gh(Kd),Kd.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.d=0;var Kd=Kh(155);oh(156,1,tp,bc);_.C=function(){Wb(this.a)};var Gd=Kh(156);oh(157,1,tp,cc);_.C=function(){Pb(this.a,this.b)};var Hd=Kh(157);oh(158,1,tp,dc);_.C=function(){Xb(this.a)};var Id=Kh(158);oh(159,1,tp,ec);_.C=function(){Sb(this.a)};var Jd=Kh(159);oh(138,1,{},fc);_.handleEvent=function(a){Qb(this.a,a)};var Ld=Kh(138);oh(117,1,{});var Pd=Kh(117);oh(127,1,{},jc);_.D=function(a){hc(this.a,a)};var Nd=Kh(127);oh(128,1,tp,kc);_.C=function(){ic(this.a,this.b)};var Od=Kh(128);oh(118,117,{});var Qd=Kh(118);oh(27,1,qp,oc);_.A=function(){mc(this)};_.B=Pp;_.a=false;var Rd=Kh(27);oh(4,1,{3:1,4:1});_.G=function(a){return new Error(a)};_.H=function(){return this.f};_.I=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Hh(this.yb),c==null?a:a+': '+c);qc(this,sc(this.G(b)));Uc(this)};_.v=function(){return rc(this,this.H())};_.e=zp;_.g=true;var ne=Kh(4);oh(12,4,{3:1,12:1,4:1});var de=Kh(12);oh(5,12,Bp);var ke=Kh(5);oh(56,5,Bp);var ge=Kh(56);oh(86,56,Bp);var Vd=Kh(86);oh(40,86,{40:1,3:1,12:1,5:1,4:1},xc);_.H=function(){wc(this);return this.c};_.J=function(){return pd(this.b)===pd(uc)?null:this.b};var uc;var Sd=Kh(40);var Td=Kh(0);oh(211,1,{});var Ud=Kh(211);var zc=0,Ac=0,Bc=-1;oh(98,211,{},Pc);var Lc;var Wd=Kh(98);var Sc;oh(222,1,{});var Yd=Kh(222);oh(87,222,{},Wc);var Xd=Kh(87);oh(46,1,{46:1},xh);_.K=function(){var a,b;b=this.a;if(pd(b)===pd(vh)){b=this.a;if(pd(b)===pd(vh)){b=this.b.K();a=this.a;if(pd(a)!==pd(vh)&&pd(a)!==pd(b)){throw _g(new Th('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}this.a=b;this.b=null}}return b};var vh;var Zd=Kh(46);var Ah;oh(84,1,{81:1});_.v=Pp;var $d=Kh(84);ed={3:1,82:1,31:1};var _d=Kh(82);oh(45,1,{3:1,45:1});var ie=Kh(45);fd={3:1,31:1,45:1};var be=Kh(221);oh(35,1,{3:1,31:1,35:1});_.s=Qp;_.u=Rp;_.v=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ce=Kh(35);oh(9,5,Bp,Th,Uh);var ee=Kh(9);oh(32,45,{3:1,31:1,32:1,45:1},Vh);_.s=function(a){return kd(a,32)&&a.a==this.a};_.u=Pp;_.v=function(){return ''+this.a};_.a=0;var fe=Kh(32);var Xh;oh(282,1,{});oh(64,56,Bp,$h);_.G=function(a){return new TypeError(a)};var he=Kh(64);gd={3:1,81:1,31:1,2:1};var me=Kh(2);oh(85,84,{81:1},ei);var le=Kh(85);oh(286,1,{});oh(63,5,Bp,fi);var oe=Kh(63);oh(223,1,{43:1});_.S=Vp;_.W=function(){return new qj(this,0)};_.X=function(){return new Aj(null,this.W())};_.U=function(a){throw _g(new fi('Add not supported on this collection'))};_.v=function(){var a,b,c;c=new sj('[',']');for(b=this.T();b.Z();){a=b.$();rj(c,a===this?'(this Collection)':a==null?Cp:sh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=Kh(223);oh(226,1,{210:1});_.s=function(a){var b,c,d;if(a===this){return true}if(!kd(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ti((new qi(d)).a);c.b;){b=si(c);if(!ii(this,b)){return false}}return true};_.u=function(){return Ki(new qi(this))};_.v=function(){var a,b,c;c=new sj('{','}');for(b=new ti((new qi(this)).a);b.b;){a=si(b);rj(c,ji(this,a.ab())+'='+ji(this,a.bb()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=Kh(226);oh(114,226,{210:1});var se=Kh(114);oh(225,223,{43:1,234:1});_.W=function(){return new qj(this,1)};_.s=function(a){var b;if(a===this){return true}if(!kd(a,25)){return false}b=a;if(oi(b.a)!=this.V()){return false}return gi(this,b)};_.u=function(){return Ki(this)};var Be=Kh(225);oh(25,225,{25:1,43:1,234:1},qi);_.T=function(){return new ti(this.a)};_.V=Tp;var re=Kh(25);oh(26,1,{},ti);_.Y=Sp;_.$=function(){return si(this)};_.Z=Up;_.b=false;var qe=Kh(26);oh(224,223,{43:1,231:1});_.W=function(){return new qj(this,16)};_._=function(a,b){throw _g(new fi('Add not supported on this list'))};_.U=function(a){this._(this.V(),a);return true};_.s=function(a){var b,c,d,e,f;if(a===this){return true}if(!kd(a,14)){return false}f=a;if(this.V()!=f.a.length){return false}e=new Ji(f);for(c=new Ji(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(pd(b)===pd(d)||b!=null&&p(b,d))){return false}}return true};_.u=function(){return Li(this)};_.T=function(){return new ui(this)};var ue=Kh(224);oh(96,1,{},ui);_.Y=Sp;_.Z=function(){return this.a<this.b.a.length};_.$=function(){return Bi(this.b,this.a++)};_.a=0;var te=Kh(96);oh(47,223,{43:1},vi);_.T=function(){var a;return a=new ti((new qi(this.a)).a),new wi(a)};_.V=Tp;var we=Kh(47);oh(66,1,{},wi);_.Y=Sp;_.Z=function(){return this.a.b};_.$=function(){var a;return a=si(this.a),a.bb()};var ve=Kh(66);oh(103,1,Ep);_.s=function(a){var b;if(!kd(a,44)){return false}b=a;return Mi(this.a,b.ab())&&Mi(this.b,b.bb())};_.ab=Pp;_.bb=Up;_.u=function(){return lj(this.a)^lj(this.b)};_.cb=function(a){var b;b=this.b;this.b=a;return b};_.v=function(){return this.a+'='+this.b};var xe=Kh(103);oh(104,103,Ep,xi);var ye=Kh(104);oh(227,1,Ep);_.s=function(a){var b;if(!kd(a,44)){return false}b=a;return Mi(this.b.value[0],b.ab())&&Mi(hj(this),b.bb())};_.u=function(){return lj(this.b.value[0])^lj(hj(this))};_.v=function(){return this.b.value[0]+'='+hj(this)};var ze=Kh(227);oh(14,224,{3:1,14:1,43:1,231:1},Hi,Ii);_._=function(a,b){Pj(this.a,a,b)};_.U=function(a){return zi(this,a)};_.S=function(a){Ai(this,a)};_.T=function(){return new Ji(this)};_.V=function(){return this.a.length};var De=Kh(14);oh(18,1,{},Ji);_.Y=Sp;_.Z=function(){return this.a<this.c.a.length};_.$=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=Kh(18);oh(41,114,{3:1,41:1,210:1},Ni);var Ee=Kh(41);oh(69,1,{},Ti);_.S=Vp;_.T=function(){return new Ui(this)};_.b=0;var Ge=Kh(69);oh(70,1,{},Ui);_.Y=Sp;_.$=function(){return this.d=this.a[this.c++],this.d};_.Z=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=Kh(70);var Xi;oh(67,1,{},fj);_.S=Vp;_.T=function(){return new gj(this)};_.b=0;_.c=0;var Je=Kh(67);oh(68,1,{},gj);_.Y=Sp;_.$=function(){return this.c=this.a,this.a=this.b.next(),new ij(this.d,this.c,this.d.c)};_.Z=function(){return !this.a.done};var He=Kh(68);oh(116,227,Ep,ij);_.ab=function(){return this.b.value[0]};_.bb=function(){return hj(this)};_.cb=function(a){return dj(this.a,this.b.value[0],a)};_.c=0;var Ie=Kh(116);oh(97,1,{});_.Y=function(a){nj(this,a)};_.db=function(){return this.d};_.eb=cq;_.d=0;_.e=0;var Le=Kh(97);oh(65,97,{});var Ke=Kh(65);oh(24,1,{},qj);_.db=Pp;_.eb=function(){pj(this);return this.c};_.Y=function(a){pj(this);this.d.Y(a)};_.fb=function(a){pj(this);if(this.d.Z()){a.D(this.d.$());return true}return false};_.a=0;_.c=0;var Me=Kh(24);oh(57,1,{},sj);_.v=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ne=Kh(57);var We=Mh();oh(105,1,{});_.c=false;var Xe=Kh(105);oh(34,105,{},Aj);var Ve=Kh(34);oh(107,65,{},Ej);_.fb=function(a){this.b=false;while(!this.b&&this.c.fb(new Fj(this,a)));return this.b};_.b=false;var Pe=Kh(107);oh(110,1,{},Fj);_.D=function(a){Dj(this.a,this.b,a)};var Oe=Kh(110);oh(106,65,{},Hj);_.fb=function(a){return this.a.fb(new Ij(a))};var Re=Kh(106);oh(109,1,{},Ij);_.D=function(a){Gj(this.a,a)};var Qe=Kh(109);oh(108,1,{},Kj);_.D=function(a){Jj(this,a)};var Se=Kh(108);oh(111,1,{},Lj);_.D=function(a){};var Te=Kh(111);oh(112,1,{},Nj);_.D=function(a){Mj(this,a)};var Ue=Kh(112);oh(284,1,{});oh(230,1,{});var Ye=Kh(230);oh(281,1,{});var Uj=0;var Wj,Xj=0,Yj;oh(742,1,{});oh(757,1,{});oh(229,1,{});_.ib=Wp;_.jb=Wp;_.lb=function(a,b,c){return false};_.r=false;var Ze=Kh(229);oh(33,$wnd.React.Component,{});nh(lh[1],_);_.render=function(){return sk(this.a)};var $e=Kh(33);oh(266,$wnd.Function,{},kk);_.hb=function(a){ik(this.a,this.b,a)};oh(267,$wnd.Function,{},lk);_.hb=function(a){jk(this.a,this.b,a)};oh(36,229,{});_.ob=function(){return false};_.qb=function(){return tk(this)};_.o=false;_.p=false;var nk=1,ok;var _e=Kh(36);oh(249,$wnd.Function,{},uk);_.L=function(a){return zb(ok),ok=null,null};oh(10,35,{3:1,31:1,35:1,10:1},el);var Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl;var af=Lh(10,fl);oh(161,36,{});_.vb=Xp;_.kb=function(){var a;a=S(this.g.b);return hk('footer',vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,['footer'])),[Bm(new Cm),hk('ul',vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,['filters'])),[hk('li',null,[hk('a',xk(vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,[(cp(),ap)==a?Hp:null])),'#'),['All'])]),hk('li',null,[hk('a',xk(vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,[_o==a?Hp:null])),'#active'),['Active'])]),hk('li',null,[hk('a',xk(vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,[bp==a?Hp:null])),'#completed'),['Completed'])])]),this.vb()?hk(Gp,yk(vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,['clear-completed'])),qh(xm.prototype.ub,xm,[this])),['Clear Completed']):null])};var Rf=Kh(161);oh(162,161,{});_.vb=Xp;var Vf=Kh(162);oh(163,162,Jp,il);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new ml(this)),up,null)}};_.s=Qp;_.pb=$p;_.F=Yp;_.vb=function(){return S(this.a)};_.u=Rp;_.B=Zp;_.v=function(){var a;return Gh(mf),mf.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((J(),J(),I),this.b,new kl(this))}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){b=a;throw _g(b)}else if(kd(a,4)){b=a;throw _g(new Uh(b))}else throw _g(a)}};_.d=0;var mf=Kh(163);oh(164,1,op,jl);_.w=function(){return gl(this.a)};var bf=Kh(164);oh(167,1,op,kl);_.w=aq;var cf=Kh(167);oh(165,1,wp,ll);_.C=_p;var df=Kh(165);oh(166,1,tp,ml);_.C=function(){hl(this.a)};var ef=Kh(166);oh(168,36,{});_.kb=function(){var a,b;b=S(this.d.e).a;a='item'+(b==1?'':'s');return hk('span',vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,['todo-count'])),[hk('strong',null,[b]),' '+a+' left'])};var Qf=Kh(168);oh(169,168,{});var Uf=Kh(169);oh(170,169,Jp,ol);_.A=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new ql(this)),up,null)}};_.s=Qp;_.pb=$p;_.F=Up;_.u=Rp;_.B=dq;_.v=function(){var a;return Gh(kf),kf.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((J(),J(),I),this.a,new rl(this))}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){b=a;throw _g(b)}else if(kd(a,4)){b=a;throw _g(new Uh(b))}else throw _g(a)}};_.c=0;var kf=Kh(170);oh(171,1,wp,pl);_.C=_p;var ff=Kh(171);oh(172,1,tp,ql);_.C=function(){nl(this.a)};var gf=Kh(172);oh(173,1,op,rl);_.w=aq;var hf=Kh(173);oh(147,1,{},tl);_.K=function(){return sl(this)};var jf=Kh(147);oh(146,1,{},vl);_.K=function(){return ul(this)};var lf=Kh(146);oh(194,36,{});_.kb=function(){return hk(Kp,zk(Dk(Ek(Hk(Fk(vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,['new-todo']))),(ab(this.b),this.f)),qh(ln.prototype.tb,ln,[this])),qh(mn.prototype.sb,mn,[this]))),null)};_.f='';var cg=Kh(194);oh(195,194,{});var Xf=Kh(195);oh(196,195,Jp,Dl);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Il(this)),up,null)}};_.s=Qp;_.pb=$p;_.F=Yp;_.u=Rp;_.B=Zp;_.v=function(){var a;return Gh(tf),tf.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((J(),J(),I),this.a,new El(this))}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){b=a;throw _g(b)}else if(kd(a,4)){b=a;throw _g(new Uh(b))}else throw _g(a)}};_.d=0;var tf=Kh(196);oh(199,1,op,El);_.w=aq;var nf=Kh(199);oh(200,1,tp,Fl);_.C=function(){wl(this.a)};var of=Kh(200);oh(201,1,tp,Gl);_.C=function(){Al(this.a,this.b)};var pf=Kh(201);oh(197,1,wp,Hl);_.C=_p;var qf=Kh(197);oh(198,1,tp,Il);_.C=function(){Bl(this.a)};var rf=Kh(198);oh(150,1,{},Kl);_.K=function(){return Jl(this)};var sf=Kh(150);oh(174,36,{});_.ib=function(){Ll(this)};_.xb=bq;_.jb=function(){_l(this,this.wb())};_.kb=function(){var a,b;b=this.wb();a=(ab(b.a),b.g);return hk('li',vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,[a?Lp:null,this.xb()?'editing':null])),[hk('div',vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,['view'])),[hk(Kp,Dk(Ak(Gk(vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,['toggle'])),(dl(),Kk)),a),qh(sn.prototype.sb,sn,[b])),null),hk('label',Ik(new $wnd.Object,qh(tn.prototype.ub,tn,[this,b])),[(ab(b.b),b.i)]),hk(Gp,yk(vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,['destroy'])),qh(un.prototype.ub,un,[this,b])),null)]),hk(Kp,Ek(Dk(Ck(Bk(vk(wk(new $wnd.Object,qh(vn.prototype.D,vn,[this])),bd(Xc(me,1),pp,2,6,['edit'])),(ab(this.a),this.i)),qh(wn.prototype.rb,wn,[this,b])),qh(rn.prototype.sb,rn,[this])),qh(xn.prototype.tb,xn,[this,b])),null)])};_.j=false;var fg=Kh(174);oh(175,174,{});_.ob=function(){var a;a=(bb(this.c),this.q.props['a']);if(!!a&&a.f<0){return true}return false};_.wb=function(){return this.q.props['a']};_.xb=bq;_.lb=function(a,b,c){return Tl(this,a,b,c)};var Zf=Kh(175);oh(176,175,Jp,bm);_.ib=function(){var b;try{A((J(),J(),I),new em(this),yp)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){b=a;throw _g(b)}else if(kd(a,4)){b=a;throw _g(new Uh(b))}else throw _g(a)}};_.A=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new cm(this)),up,null)}};_.s=Qp;_.pb=$p;_.F=cq;_.wb=function(){return bb(this.c),this.q.props['a']};_.u=Rp;_.B=fq;_.xb=function(){return S(this.d)};_.lb=function(b,c,d){var e;try{return t((J(),J(),I),new fm(this,b,c,d),75505664,null)}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){e=a;throw _g(e)}else if(kd(a,4)){e=a;throw _g(new Uh(e))}else throw _g(a)}};_.v=function(){var a;return Gh(Gf),Gf.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((J(),J(),I),this.b,new dm(this))}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){b=a;throw _g(b)}else if(kd(a,4)){b=a;throw _g(new Uh(b))}else throw _g(a)}};_.f=0;var Gf=Kh(176);oh(179,1,tp,cm);_.C=function(){Vl(this.a)};var uf=Kh(179);oh(180,1,op,dm);_.w=aq;var vf=Kh(180);oh(181,1,tp,em);_.C=function(){Ll(this.a)};var wf=Kh(181);oh(182,1,op,fm);_.w=function(){return Wl(this.a,this.d,this.c,this.b)};_.b=false;var xf=Kh(182);oh(183,1,tp,gm);_.C=function(){am(this.a,Pn(this.b))};var yf=Kh(183);oh(184,1,tp,hm);_.C=function(){Sl(this.a,this.b)};var zf=Kh(184);oh(185,1,tp,im);_.C=function(){Rl(this.a,this.b)};var Af=Kh(185);oh(177,1,op,jm);_.w=function(){return Xl(this.a)};var Bf=Kh(177);oh(186,1,tp,km);_.C=function(){Ql(this.a,this.b)};var Cf=Kh(186);oh(187,1,tp,lm);_.C=function(){Ml(this.a,this.b)};var Df=Kh(187);oh(178,1,wp,mm);_.C=_p;var Ef=Kh(178);oh(148,1,{},om);_.K=function(){return nm(this)};var Ff=Kh(148);oh(188,36,{});_.kb=function(){var a,b;return hk('div',null,[hk('div',null,[hk(Mp,vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,[Mp])),[hk('h1',null,['todos']),nn(new on)]),S(this.d.c)?null:hk('section',vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,[Mp])),[hk(Kp,Dk(Gk(vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,['toggle-all'])),(dl(),Kk)),qh(Fn.prototype.sb,Fn,[this])),null),hk('ul',vk(new $wnd.Object,bd(Xc(me,1),pp,2,6,['todo-list'])),(a=zj(yj(S(this.f.c).X()),(b=new Hi,b)),Gi(a,ad(a.a.length))))]),S(this.d.c)?null:ym(new zm)])])};var ig=Kh(188);oh(189,188,{});var _f=Kh(189);oh(190,189,Jp,rm);_.A=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new tm(this)),up,null)}};_.s=Qp;_.pb=$p;_.F=Up;_.u=Rp;_.B=dq;_.v=function(){var a;return Gh(Lf),Lf.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((J(),J(),I),this.a,new um(this))}catch(a){a=$g(a);if(kd(a,5)||kd(a,7)){b=a;throw _g(b)}else if(kd(a,4)){b=a;throw _g(new Uh(b))}else throw _g(a)}};_.c=0;var Lf=Kh(190);oh(191,1,wp,sm);_.C=_p;var Hf=Kh(191);oh(192,1,tp,tm);_.C=function(){nl(this.a)};var If=Kh(192);oh(193,1,op,um);_.w=aq;var Jf=Kh(193);oh(149,1,{},wm);_.K=function(){return vm(this)};var Kf=Kh(149);oh(248,$wnd.Function,{},xm);_.ub=function(a){so(this.a.f)};oh(204,1,{},zm);var Mf=Kh(204);oh(75,1,{},Am);_.K=function(){return ul((new Wo(this.a)).a)};var Nf=Kh(75);oh(202,1,{},Cm);var Of=Kh(202);oh(76,1,{},Dm);_.K=function(){return sl((new Xo(this.a)).a)};var Pf=Kh(76);oh(247,$wnd.Function,{},Im);_.mb=function(a){return new Nm(a)};var Jm;var Lm;oh(91,33,{},Nm);_.nb=function(){return ul((new Wo(Lm.a)).a)};_.componentWillUnmount=eq;var Sf=Kh(91);oh(251,$wnd.Function,{},Om);_.mb=function(a){return new Tm(a)};var Pm;var Rm;oh(92,33,{},Tm);_.nb=function(){return sl((new Xo(Rm.a)).a)};_.componentWillUnmount=eq;var Tf=Kh(92);oh(263,$wnd.Function,{},Um);_.mb=function(a){return new Zm(a)};var Vm;var Xm;oh(95,33,{},Zm);_.nb=function(){return Jl((new Yo(Xm.a)).a)};_.componentWillUnmount=eq;var Wf=Kh(95);oh(252,$wnd.Function,{},$m);_.mb=function(a){return new dn(a)};var _m;var bn;oh(93,33,{},dn);_.nb=function(){return nm((new Zo(bn.a)).a)};_.componentDidUpdate=function(a){dk(this.a,a)};_.componentWillUnmount=eq;_.shouldComponentUpdate=function(a){return ek(this.a,a)};var Yf=Kh(93);oh(261,$wnd.Function,{},en);_.mb=function(a){return new kn(a)};var fn;var hn;oh(94,33,{},kn);_.nb=function(){return vm((new $o(hn.a)).a)};_.componentWillUnmount=eq;var $f=Kh(94);oh(264,$wnd.Function,{},ln);_.tb=function(a){xl(this.a,a)};oh(265,$wnd.Function,{},mn);_.sb=function(a){zl(this.a,a)};oh(203,1,{},on);var ag=Kh(203);oh(79,1,{},pn);_.K=function(){return Jl((new Yo(this.a)).a)};var bg=Kh(79);oh(259,$wnd.Function,{},rn);_.sb=function(a){Ul(this.a,a)};oh(253,$wnd.Function,{},sn);_.sb=function(a){Vn(this.a)};oh(255,$wnd.Function,{},tn);_.ub=function(a){Zl(this.a,this.b)};oh(256,$wnd.Function,{},un);_.ub=function(a){Nl(this.a,this.b)};oh(257,$wnd.Function,{},vn);_.D=function(a){Ol(this.a,a)};oh(258,$wnd.Function,{},wn);_.rb=function(a){$l(this.a,this.b)};oh(260,$wnd.Function,{},xn);_.tb=function(a){Pl(this.a,this.b,a)};oh(205,1,{},Bn);var dg=Kh(205);oh(77,1,{},Cn);_.K=function(){return nm((new Zo(this.a)).a)};var eg=Kh(77);oh(262,$wnd.Function,{},Fn);_.sb=function(a){pm(this.a,a)};oh(80,1,{},Hn);var gg=Kh(80);oh(78,1,{},In);_.K=function(){return vm((new $o(this.a)).a)};var hg=Kh(78);oh(52,1,{52:1});_.g=false;var Wg=Kh(52);oh(53,52,{11:1,39:1,53:1,52:1},Wn);_.A=function(){Nn(this)};_.s=function(a){return On(this,a)};_.F=Yp;_.u=cq;_.B=fq;_.v=function(){var a;return Gh(Ag),Ag.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var Mn=0;var Ag=Kh(53);oh(206,1,tp,Xn);_.C=function(){Rn(this.a)};var jg=Kh(206);oh(207,1,tp,Yn);_.C=function(){Sn(this.a)};var kg=Kh(207);oh(48,118,{48:1});var Rg=Kh(48);oh(119,48,{11:1,48:1},fo);_.A=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new go(this)),up,null)}};_.s=Qp;_.u=Rp;_.B=fq;_.v=function(){var a;return Gh(tg),tg.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.f=0;var tg=Kh(119);oh(124,1,tp,go);_.C=function(){bo(this.a)};var lg=Kh(124);oh(125,1,tp,ho);_.C=function(){gc(this.a,this.b,true)};var mg=Kh(125);oh(120,1,op,io);_.w=function(){return co(this.a)};var ng=Kh(120);oh(126,1,op,jo);_.w=function(){return Zn(this.a,this.c,this.b)};_.b=false;var og=Kh(126);oh(121,1,op,ko);_.w=function(){return Wh(fh(wj(ao(this.a))))};var pg=Kh(121);oh(122,1,op,lo);_.w=function(){return Wh(fh(wj(xj(ao(this.a),new fp))))};var qg=Kh(122);oh(123,1,op,mo);_.w=function(){return eo(this.a)};var rg=Kh(123);oh(99,1,{},po);_.K=function(){return new fo};var no;var sg=Kh(99);oh(49,1,{49:1});var Vg=Kh(49);oh(130,49,{11:1,49:1},xo);_.A=function(){if(this.a>=0){this.a=-2;t((J(),J(),I),new G(new Ao),up,null)}};_.s=Qp;_.u=Rp;_.B=function(){return this.a<0};_.v=function(){var a;return Gh(zg),zg.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.a=0;var zg=Kh(130);oh(133,1,tp,yo);_.C=function(){Un(this.b,this.a)};var ug=Kh(133);oh(134,1,tp,zo);_.C=function(){to(this.a)};var vg=Kh(134);oh(131,1,tp,Ao);_.C=Wp;var wg=Kh(131);oh(132,1,tp,Bo);_.C=function(){uo(this.a,this.b)};_.b=false;var xg=Kh(132);oh(100,1,{},Co);_.K=function(){return new xo(this.a.K())};var yg=Kh(100);oh(50,1,{50:1});var Yg=Kh(50);oh(139,50,{11:1,50:1},Lo);_.A=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new Mo(this)),up,null)}};_.s=Qp;_.u=Rp;_.B=function(){return this.g<0};_.v=function(){var a;return Gh(Hg),Hg.k+'@'+(a=Vj(this)>>>0,a.toString(16))};_.g=0;var Hg=Kh(139);oh(144,1,tp,Mo);_.C=function(){Go(this.a)};var Bg=Kh(144);oh(140,1,op,No);_.w=function(){var a;return a=Vb(this.a.i),ai(Op,a)||ai(Lp,a)||ai('',a)?ai(Op,a)?(cp(),_o):ai(Lp,a)?(cp(),bp):(cp(),ap):(cp(),ap)};var Cg=Kh(140);oh(141,1,op,Oo);_.w=function(){return Ho(this.a)};var Dg=Kh(141);oh(142,1,wp,Po);_.C=function(){Io(this.a)};var Eg=Kh(142);oh(143,1,wp,Qo);_.C=function(){Jo(this.a)};var Fg=Kh(143);oh(102,1,{},Ro);_.K=function(){return new Lo(this.b.K(),this.a.K())};var Gg=Kh(102);oh(101,1,{},Uo);_.K=function(){return new ac};var So;var Ig=Kh(101);oh(74,1,{},Vo);var Og=Kh(74);oh(58,1,{},Wo);var Jg=Kh(58);oh(62,1,{},Xo);var Kg=Kh(62);oh(61,1,{},Yo);var Lg=Kh(61);oh(59,1,{},Zo);var Mg=Kh(59);oh(60,1,{},$o);var Ng=Kh(60);oh(37,35,{3:1,31:1,35:1,37:1},dp);var _o,ap,bp;var Pg=Lh(37,ep);oh(129,1,{},fp);_.gb=function(a){return !Qn(a)};var Qg=Kh(129);oh(136,1,{},gp);_.gb=function(a){return Qn(a)};var Sg=Kh(136);oh(137,1,{},hp);_.D=function(a){_n(this.a,a)};var Tg=Kh(137);oh(135,1,{},ip);_.D=function(a){ro(this.a,a)};_.a=false;var Ug=Kh(135);oh(145,1,{},jp);_.gb=function(a){return Eo(this.a,a)};var Xg=Kh(145);var kp=(Cc(),Fc);var gwtOnLoad=gwtOnLoad=jh;hh(uh);kh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();