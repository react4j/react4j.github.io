function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='C517C3317C9E033D9C959C7247AE38F3',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'C517C3317C9E033D9C959C7247AE38F3';function o(){}
function ih(){}
function eh(){}
function Ib(){}
function Mc(){}
function Tc(){}
function qj(){}
function rj(){}
function rm(){}
function wm(){}
function Bm(){}
function Gm(){}
function Gk(){}
function Mm(){}
function Nm(){}
function On(){}
function uo(){}
function ap(){}
function bp(){}
function Rc(a){Qc()}
function Rl(a){Wi(a)}
function qh(){qh=eh}
function pi(){gi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function mb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function Db(a){this.a=a}
function hc(a){this.a=a}
function nc(a){this.a=a}
function Fh(a){this.a=a}
function $h(a){this.a=a}
function di(a){this.a=a}
function ei(a){this.a=a}
function ci(a){this.b=a}
function ri(a){this.c=a}
function oj(a){this.a=a}
function tj(a){this.a=a}
function Pk(a){this.a=a}
function Qk(a){this.a=a}
function Rk(a){this.a=a}
function Sk(a){this.a=a}
function Zk(a){this.a=a}
function $k(a){this.a=a}
function _k(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function ql(a){this.a=a}
function Ql(a){this.a=a}
function Sl(a){this.a=a}
function Wl(a){this.a=a}
function Zl(a){this.a=a}
function $l(a){this.a=a}
function hm(a){this.a=a}
function im(a){this.a=a}
function jm(a){this.a=a}
function km(a){this.a=a}
function Sm(a){this.a=a}
function Tm(a){this.a=a}
function Wm(a){this.a=a}
function Xm(a){this.a=a}
function $m(a){this.a=a}
function fn(a){this.a=a}
function nn(a){this.a=a}
function pn(a){this.a=a}
function rn(a){this.a=a}
function tn(a){this.a=a}
function vn(a){this.a=a}
function Jn(a){this.a=a}
function Kn(a){this.a=a}
function Ln(a){this.a=a}
function Mn(a){this.a=a}
function Nn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function oo(a){this.a=a}
function po(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function Eo(a){this.a=a}
function Fo(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function Ro(a){this.a=a}
function So(a){this.a=a}
function To(a){this.a=a}
function Uo(a){this.a=a}
function Vo(a){this.a=a}
function cp(a){this.a=a}
function dp(a){this.a=a}
function ep(a){this.a=a}
function pj(a,b){a.a=b}
function pm(a,b){a.f=b}
function nm(a,b){a.d=b}
function om(a,b){a.e=b}
function qm(a,b){a.g=b}
function dn(a,b){a.k=b}
function en(a,b){a.n=b}
function Lj(a,b){a.key=b}
function Kj(a,b){Jj(a,b)}
function wo(a,b){Wn(b,a)}
function Jp(a){Ti(this,a)}
function Np(a){Jh(this,a)}
function Op(){jc(this.c)}
function Pp(){jc(this.b)}
function Pi(){this.a=Ki()}
function Bi(){this.a=Ki()}
function kc(a){!!a&&a.u()}
function w(a){--a.e;D(a)}
function gb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function kb(a){Yb((J(),a))}
function Qp(){nb(this.a.a)}
function Qg(a){return a.b}
function Lb(a){a.a=-4&a.a|1}
function tb(a,b){a.b=Wi(b)}
function cc(a,b){Wh(a.b,b)}
function vo(a,b){co(a.b,b)}
function sl(a,b){eo(a.k,b)}
function sj(a,b){jj(a.a,b)}
function C(a,b){ab(a.f,b.f)}
function V(a){gd(a,9)&&a.t()}
function Hk(a){a.d=2;jc(a.c)}
function Tk(a){a.c=2;jc(a.b)}
function zl(a){a.f=2;jc(a.e)}
function Lk(a){nb(a.b);R(a.a)}
function Cn(a){R(a.a);cb(a.b)}
function Gi(){Gi=eh;Fi=Ii()}
function J(){J=eh;I=new F}
function Jc(){Jc=eh;Ic=new Mc}
function tc(){tc=eh;sc=new o}
function to(){to=eh;so=new uo}
function dc(){this.b=new vi}
function Lp(){return this.a}
function Mp(){return this.b}
function Ip(){return Bj(this)}
function Hp(a){return this===a}
function Nh(a,b){return a===b}
function tl(a,b){return a.g=b}
function ji(a,b){return a.a[b]}
function Uc(a,b){return yh(a,b)}
function xj(a,b){a.splice(b,1)}
function ac(a,b,c){Vh(a.b,b,c)}
function Yi(a,b){while(a.$(b));}
function Qh(a){rc.call(this,a)}
function Kp(){return Yh(this.a)}
function Kh(){oc(this);this.A()}
function gl(a){nb(a.a);cb(a.b)}
function Rn(a){cb(a.b);cb(a.a)}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function th(a){sh(a);return a.k}
function ij(a,b){a.N(b);return a}
function Ki(){Gi();return new Fi}
function db(a){J();Xb(a);a.e=-2}
function jj(a,b){pj(a,ij(a.a,b))}
function on(a,b){nm(b,a.a.a.C())}
function qn(a,b){om(b,a.a.b.C())}
function v(a,b,c){s(a,new H(c),b)}
function ic(a,b){this.a=a;this.b=b}
function Yh(a){return a.a.b+a.b.b}
function W(a){return !!a&&a.c.i<0}
function Zc(a){return new Array(a)}
function Mi(a,b){return a.a.get(b)}
function En(a){ib(a.b);return a.e}
function Un(a){ib(a.a);return a.d}
function Jo(a){ib(a.d);return a.f}
function Uj(a,b){a.ref=b;return a}
function Vj(a,b){a.href=b;return a}
function mj(a,b){this.a=a;this.b=b}
function Sj(a,b){this.a=a;this.b=b}
function Dh(a,b){this.a=a;this.b=b}
function fi(a,b){this.a=a;this.b=b}
function pl(a,b){this.a=a;this.b=b}
function Tl(a,b){this.a=a;this.b=b}
function Ul(a,b){this.a=a;this.b=b}
function Vl(a,b){this.a=a;this.b=b}
function Xl(a,b){this.a=a;this.b=b}
function Yl(a,b){this.a=a;this.b=b}
function _l(a,b){this.a=a;this.b=b}
function Ym(a,b){this.a=a;this.b=b}
function Zm(a,b){this.a=a;this.b=b}
function _m(a,b){this.a=a;this.b=b}
function an(a,b){this.a=a;this.b=b}
function Ck(a,b){Dh.call(this,a,b)}
function vj(a,b,c){a.splice(b,0,c)}
function zc(){zc=eh;!!(Qc(),Pc)}
function Hc(){wc!=0&&(wc=0);yc=-1}
function Yg(){Wg==null&&(Wg=[])}
function lm(){this.a=Mj((tm(),sm))}
function mm(){this.a=Mj((ym(),xm))}
function Um(){this.a=Mj((Dm(),Cm))}
function cn(){this.a=Mj((Im(),Hm))}
function gn(){this.a=Mj((Pm(),Om))}
function Fn(a){Dn(a,(ib(a.b),a.e))}
function Vn(a){Wn(a,(ib(a.a),!a.d))}
function Uh(a){return !a?null:a.W()}
function Sb(a){return !a.d?a:Sb(a.d)}
function jd(a){return typeof a===gp}
function ld(a){return a==null?null:a}
function Vi(a){return a!=null?r(a):0}
function Gc(a){$wnd.clearTimeout(a)}
function $o(a,b){Dh.call(this,a,b)}
function mo(a,b){this.a=a;this.b=b}
function Co(a,b){this.a=a;this.b=b}
function Pn(a,b){this.a=a;this.b=b}
function Do(a,b){this.b=a;this.a=b}
function lb(a){this.c=new pi;this.b=a}
function Xh(a){a.a=new Bi;a.b=new Pi}
function Fj(){Fj=eh;Cj=new o;Ej=new o}
function Yj(a,b){a.checked=b;return a}
function dk(a,b){a.value=b;return a}
function $j(a,b){a.onBlur=b;return a}
function Wj(a,b){a.onClick=b;return a}
function _j(a,b){a.onChange=b;return a}
function wj(a,b){uj(b,0,a,0,b.length)}
function gc(a,b){ec(a,b,false);hb(a.d)}
function A(a,b,c){t(a,new G(b),c,null)}
function B(a,b,c){return t(a,c,2048,b)}
function _c(a,b,c){return {l:a,m:b,h:c}}
function Mh(a,b){return a.charCodeAt(b)}
function Ph(a){return !a?'null':''+a.a}
function Bj(a){return a.$H||(a.$H=++Aj)}
function X(a){return !(!!a&&1==(a.c&7))}
function gd(a,b){return a!=null&&ed(a,b)}
function Jj(a,b){for(var c in a){b(c)}}
function zj(b,c,d){try{b[c]=d}catch(a){}}
function sb(a){J();rb(a);vb(a,2,true)}
function gi(a){a.a=Wc(ce,ip,1,0,5,1)}
function P(){this.a=Wc(ce,ip,1,100,5,1)}
function Gb(a){this.d=Wi(a);this.b=100}
function kh(a){this.b=Wi(a);this.a=this}
function rc(a){this.c=a;oc(this);this.A()}
function hj(a,b){cj.call(this,a);this.a=b}
function ak(a,b){a.onKeyDown=b;return a}
function Xj(a){a.autoFocus=true;return a}
function sh(a){if(a.k!=null){return}Ah(a)}
function pc(a,b){a.b=b;b!=null&&zj(b,rp,a)}
function ib(a){var b;Tb((J(),b=Ob,b),a)}
function Di(a,b){var c;c=a[vp];c.call(a,b)}
function Ti(a,b){while(a.S()){sj(b,a.T())}}
function Zj(a,b){a.defaultValue=b;return a}
function kd(a){return typeof a==='string'}
function hd(a){return typeof a==='boolean'}
function u(a,b){return new yb(Wi(a),null,b)}
function vi(){this.a=new Bi;this.b=new Pi}
function nh(){nh=eh;mh=$wnd.window.document}
function Ih(){Ih=eh;Hh=Wc($d,ip,30,256,0,1)}
function T(a){4==(a.f.c&7)&&vb(a.f,5,true)}
function Jb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function io(a){return Gh(S(a.e).a-S(a.a).a)}
function Lo(a){W((ib(a.d),a.f))&&No(a,null)}
function xo(a){A((J(),J(),I),new Eo(a),Ap)}
function Ll(a){A((J(),J(),I),new Zl(a),Ap)}
function Gn(a){A((J(),J(),I),new Mn(a),Ap)}
function Yn(a){A((J(),J(),I),new _n(a),Ap)}
function fc(a,b){cc(b.c.c,a);gd(b,9)&&b.t()}
function Ac(a,b,c){return a.apply(b,c);var d}
function Si(a,b,c){this.a=a;this.b=b;this.c=c}
function $(a,b,c){Lb(Wi(c));K(a.a[b],Wi(c))}
function El(a){nb(a.b);R(a.d);cb(a.c);cb(a.a)}
function wh(a){var b;b=vh(a);Ch(a,b);return b}
function oc(a){a.d&&a.b!==qp&&a.A();return a}
function ek(a,b){a.onDoubleClick=b;return a}
function hi(a,b){a.a[a.a.length]=b;return true}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function hl(a,b){A((J(),J(),I),new pl(a,b),Ap)}
function Gl(a,b){A((J(),J(),I),new Yl(a,b),Ap)}
function Jl(a,b){A((J(),J(),I),new Vl(a,b),Ap)}
function Kl(a,b){A((J(),J(),I),new Ul(a,b),Ap)}
function Nl(a,b){A((J(),J(),I),new Tl(a,b),Ap)}
function eo(a,b){A((J(),J(),I),new mo(a,b),Ap)}
function Ao(a,b){A((J(),J(),I),new Co(a,b),Ap)}
function il(a,b){var c;c=b.target;kl(a,c.value)}
function qb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function no(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new bb;this.a=new Gb(this.f)}
function go(a){Jh(new di(a.g),new hc(a));Xh(a.g)}
function Fb(a){while(true){if(!Eb(a)){break}}}
function Il(a,b){return qh(),Al(a,b)?true:false}
function Li(a,b){return !(a.a.get(b)===undefined)}
function Yc(a){return Array.isArray(a)&&a.ib===ih}
function ho(a){return qh(),0==S(a.e).a?true:false}
function fd(a){return !Array.isArray(a)&&a.ib===ih}
function $i(a){if(!a.d){a.d=a.b.M();a.c=a.b.O()}}
function Hb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function kj(a,b,c){if(a.a._(c)){a.b=true;b.v(c)}}
function ai(a){var b;b=a.a.T();a.b=_h(a);return b}
function li(a,b){var c;c=a.a[b];xj(a.a,b);return c}
function Nc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Xi(a){if(!a){throw Qg(new Lh)}return a}
function lh(a){Wi(a);return gd(a,45)?a:new kh(a)}
function fj(a){bj(a);return new hj(a,new nj(a.a))}
function jl(a){return B((J(),J(),I),a.a,new nl(a))}
function Ml(a){return B((J(),J(),I),a.b,new Sl(a))}
function Nk(a){return B((J(),J(),I),a.b,new Sk(a))}
function Xk(a){return B((J(),J(),I),a.a,new _k(a))}
function fm(a){return B((J(),J(),I),a.a,new jm(a))}
function Mk(a){return qh(),S(a.e.b).a>0?true:false}
function Go(a){return Nh(Gp,a)||Nh(Cp,a)||Nh('',a)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function bo(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function Qc(){Qc=eh;var a;!Sc();a=new Tc;Pc=a}
function Ij(){if(Dj==256){Cj=Ej;Ej=new o;Dj=0}++Dj}
function Bl(a){if(0==a.f){a.f=1;a.o.setState({})}}
function Ik(a){if(0==a.d){a.d=1;a.o.forceUpdate()}}
function Uk(a){if(0==a.c){a.c=1;a.o.forceUpdate()}}
function aj(a){if(!a.b){bj(a);a.c=true}else{aj(a.b)}}
function kl(a,b){var c;c=a.f;if(b!=c){a.f=b;hb(a.b)}}
function Ol(a,b){var c;c=a.i;if(b!=c){a.i=b;hb(a.a)}}
function Wn(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function am(a,b){var c;c=b.target;Ao(a.e,c.checked)}
function ni(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ck(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Zh(a,b){if(b){return Th(a.a,b)}return false}
function ej(a,b){bj(a);return new hj(a,new lj(b,a.a))}
function Dn(a,b){A((J(),J(),I),new Pn(a,b),75497472)}
function wl(a,b){No(a.n,b);A((J(),J(),I),new Tl(a,b),Ap)}
function Io(a){nb(a.e);nb(a.a);R(a.b);R(a.c);cb(a.d)}
function Bn(a){var b;T(a.a);b=S(a.a);Nh(a.f,b)&&Hn(a,b)}
function Hn(a,b){var c;c=a.e;if(b!=c){a.e=Wi(b);hb(a.b)}}
function xh(a,b){var c;c=vh(a);Ch(a,c);c.e=b?8:0;return c}
function Wi(a){if(a==null){throw Qg(new Kh)}return a}
function Vg(a){if(jd(a)){return a|0}return a.l|a.m<<22}
function cj(a){if(!a){this.b=null;new pi}else{this.b=a}}
function nj(a){Zi.call(this,a.Z(),a.Y()&-6);this.a=a}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function co(a,b){return t((J(),J(),I),new no(a,b),Ap,null)}
function ui(a,b){return ld(a)===ld(b)||a!=null&&p(a,b)}
function Zi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function _i(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function jb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function ob(a){C((J(),J(),I),a);0==(a.f.a&np)&&D((null,I))}
function vl(a,b){A((J(),J(),I),new Tl(a,b),Ap);No(a.n,null)}
function xn(a){oh((nh(),$wnd.window.window),Ep,a.d,false)}
function yn(a){ph((nh(),$wnd.window.window),Ep,a.d,false)}
function Fc(a){zc();$wnd.setTimeout(function(){throw a},0)}
function lc(a){kc(a.g);V(a.c);V(a.a);V(a.d);kc(a.b);kc(a.f)}
function Pb(a){if(a.e){2==(a.e.c&7)||vb(a.e,4,true);rb(a.e)}}
function zh(a){if(a.K()){return null}var b=a.j;return _g[b]}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function gh(a){function b(){}
;b.prototype=a||{};return new b}
function tm(){tm=eh;var a;sm=(a=fh(rm.prototype.fb,rm,[]),a)}
function ym(){ym=eh;var a;xm=(a=fh(wm.prototype.fb,wm,[]),a)}
function Dm(){Dm=eh;var a;Cm=(a=fh(Bm.prototype.fb,Bm,[]),a)}
function Im(){Im=eh;var a;Hm=(a=fh(Gm.prototype.fb,Gm,[]),a)}
function Pm(){Pm=eh;var a;Om=(a=fh(Nm.prototype.fb,Nm,[]),a)}
function _o(){Zo();return $c(Uc(Eg,1),ip,32,0,[Wo,Yo,Xo])}
function bh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function rl(a,b){var c;if(S(a.d)){c=b.target;Ol(a,c.value)}}
function yo(a,b){var c;gj(fo(a.b),(c=new pi,c)).L(new dp(b))}
function Jh(a,b){var c,d;for(d=a.M();d.S();){c=d.T();b.v(c)}}
function yh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.F(b))}
function xi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function yi(a,b){var c;return wi(b,xi(a,b==null?0:(c=r(b),c|0)))}
function fo(a){ib(a.d);return new hj(null,new _i(new di(a.g),0))}
function bj(a){if(a.b){bj(a.b)}else if(a.c){throw Qg(new Eh)}}
function Ci(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function qi(a){gi(this);wj(this.a,Sh(a,Wc(ce,ip,1,Yh(a.a),5,1)))}
function zn(a,b){b.preventDefault();A((J(),J(),I),new Nn(a),Ap)}
function Fl(a,b){return t((J(),J(),I),new _l(a,b),75497472,null)}
function md(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ec(a){a&&Lc((Jc(),Ic));--wc;if(a){if(yc!=-1){Gc(yc);yc=-1}}}
function Mb(b){try{b.b.u()}catch(a){a=Pg(a);if(!gd(a,5))throw Qg(a)}}
function sn(a,b){dn(b,a.a.a.C());a.a.b.C();en(b,a.a.c.C());return b}
function qc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function bk(a){a.placeholder='What needs to be done?';return a}
function oh(a,b,c,d){a.addEventListener(b,c,(qh(),d?true:false))}
function ph(a,b,c,d){a.removeEventListener(b,c,(qh(),d?true:false))}
function Dc(a,b,c){var d;d=Bc();try{return Ac(a,b,c)}finally{Ec(d)}}
function No(a,b){var c;c=a.f;if(!(b==c||!!b&&Sn(b,c))){a.f=b;hb(a.d)}}
function eb(a,b){var c,d;hi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function gj(a,b){var c;aj(a);c=new qj;c.a=b;a.a.R(new tj(c));return c.a}
function dj(a){var b;aj(a);b=0;while(a.a.$(new rj)){b=Rg(b,1)}return b}
function zo(a){var b;gj(ej(fo(a.b),new bp),(b=new pi,b)).L(new cp(a.b))}
function Bo(a){this.b=Wi(a);J();this.a=new mc(0,null,null,false,false)}
function Qi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function lj(a,b){Zi.call(this,b.Z(),b.Y()&-16449);this.a=a;this.c=b}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function mn(a,b){om(b,a.a.a.C());pm(b,a.a.b.C());qm(b,a.a.c.C());return b}
function un(a,b){nm(b,a.a.a.C());om(b,a.a.b.C());pm(b,a.a.c.C());return b}
function Wc(a,b,c,d,e,f){var g;g=Xc(e,d);e!=10&&$c(Uc(a,f),b,c,e,g);return g}
function Rj(a,b,c){!Nh(c,'key')&&!Nh(c,'ref')&&(a[c]=b[c],undefined)}
function Wh(a,b){return kd(b)?b==null?Ai(a.a,null):Oi(a.b,b):Ai(a.a,b)}
function Ho(a,b){return (Zo(),Xo)==a||(Wo==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function Hl(a){return qh(),Jo(a.n)==(jb(a.c),a.o.props['a'])?true:false}
function yj(a,b){return Vc(b)!=10&&$c(q(b),b.hb,b.__elementTypeId$,Vc(b),a),a}
function Vh(a,b,c){return kd(b)?b==null?zi(a.a,null,c):Ni(a.b,b,c):zi(a.a,b,c)}
function al(a){var b;b=Oh((ib(a.b),a.f));if(b.length>0){vo(a.e,b);kl(a,'')}}
function Ko(a){var b,c;return b=S(a.b),gj(ej(fo(a.j),new ep(b)),(c=new pi,c))}
function vc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Cc(b){zc();return function(){return Dc(b,this,arguments);var a}}
function Sn(a,b){var c;if(gd(b,50)){c=b;return a.c.e==c.c.e}else{return false}}
function mi(a,b){var c;c=ki(a,b,0);if(c==-1){return false}xj(a.a,c);return true}
function ii(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function bb(){var a;this.a=Wc(qd,ip,44,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function bi(a){this.d=a;this.c=new Qi(this.d.b);this.a=this.c;this.b=_h(this)}
function Jm(a){$wnd.React.Component.call(this,a);this.a=new Pl(Wi(this))}
function Ri(a){if(a.a.c!=a.c){return Mi(a.a,a.b.value[0])}return a.b.value[1]}
function ki(a,b,c){for(;c<a.a.length;++c){if(ui(b,a.a[c])){return c}}return -1}
function bn(a,b){Lj(a.a,Ph(b?Gh(b.c.e):null));Wi(b);a.a.props['a']=b;return a.a}
function wn(a,b){a.f=b;Nh(b,S(a.a))&&Hn(a,b);An(b);A((J(),J(),I),new Nn(a),Ap)}
function bl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new ol(a),Ap)}}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new nc(a)),67108864,null)}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new mb(a)),0,null);!!a.b&&nb(a.b)}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||nb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Fb(a.a)}finally{a.c=false}}}}
function Kc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Oc(b,c)}while(a.a);a.a=c}}
function Lc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Oc(b,c)}while(a.b);a.b=c}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function ub(b){if(b){try{b.u()}catch(a){a=Pg(a);if(gd(a,5)){J()}else throw Qg(a)}}}
function Ch(a,b){var c;if(!a){return}b.j=a;var d=zh(b);if(!d){_g[a]=[b];return}d.gb=b}
function Pg(a){var b;if(gd(a,5)){return a}b=a&&a[rp];if(!b){b=new uc(a);Rc(b)}return b}
function fh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function vh(a){var b;b=new uh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Oi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Di(a.a,b);--a.b}return c}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;hi((!a.b&&(a.b=new pi),a.b),b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new pi);a.c=c.c}b.d=true;hi(a.c,Wi(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Wi(b))}
function Pj(a){var b;return Nj($wnd.React.StrictMode,null,null,(b={},b[wp]=Wi(a),b))}
function Mj(a){var b;b=Oj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function si(a){var b,c,d;d=0;for(c=new bi(a.a);c.b;){b=ai(c);d=d+(b?r(b):0);d=d|0}return d}
function rb(a){var b,c;for(c=new ri(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Xg(){Yg();var a=Wg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Eh(){rc.call(this,"Stream already terminated, can't be modified or used")}
function Lh(){rc.call(this,'Cannot return null from a non-@Nullable @Provides method')}
function Vc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Zo(){Zo=eh;Wo=new $o('ACTIVE',0);Yo=new $o('COMPLETED',1);Xo=new $o('ALL',2)}
function ln(){this.a=lh((to(),to(),so));this.b=lh(new Fo(this.a));this.c=lh(new Uo(this.a))}
function uc(a){tc();oc(this);this.b=a;a!=null&&zj(a,rp,this);this.c=a==null?'null':hh(a);this.a=a}
function um(a){var b;$wnd.React.Component.call(this,a);this.a=(b=new Ok(Wi(this)),mn(vm,b),b)}
function zm(a){var b;$wnd.React.Component.call(this,a);this.a=(b=new Yk(Wi(this)),on(Am,b),b)}
function Em(a){var b;$wnd.React.Component.call(this,a);this.a=(b=new ll(Wi(this)),qn(Fm,b),b)}
function Qm(a){var b;$wnd.React.Component.call(this,a);this.a=(b=new gm(Wi(this)),un(Rm,b),b)}
function Nj(a,b,c,d){var e;e=Oj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Wi(d);return e}
function ao(a,b,c){var d;d=new Zn(b,c);ac(d.c.c,a,new ic(a,d));Vh(a.g,Gh(d.c.e),d);hb(a.d);return d}
function Rh(a,b){var c,d;for(d=new bi(b.a);d.b;){c=ai(d);if(!Zh(a,c)){return false}}return true}
function wi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(ui(a,c.V())){return c}}return null}
function Ug(a){var b,c,d,e;e=a;d=0;if(e<0){e+=tp;d=1048575}c=md(e/op);b=md(e-c*op);return _c(b,c,d)}
function Sg(a){var b;b=a.h;if(b==0){return a.l+a.m*op}if(b==1048575){return a.l+a.m*op-tp}return a}
function _h(a){if(a.a.S()){return true}if(a.a!=a.c){return false}a.a=new Ci(a.d.a);return a.a.S()}
function S(a){ib(a.e);wb(a.f)&&pb(a.f);if(a.b){if(gd(a.b,8)){throw Qg(a.b)}else{throw Qg(a.b)}}return a.k}
function Al(a,b){var c,d;d=a.o.props;c=false;if(!(d['a']===b['a'])){hb(a.c);c=true}return c||1==a.f}
function ec(a,b,c){var d;d=Wh(a.g,b?Gh(b.c.e):null);if(null!=d){cc(b.c.c,a);c&&!!b&&jc(b.c);hb(a.d)}}
function Ni(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function $c(a,b,c,d,e){e.gb=a;e.hb=b;e.ib=ih;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function $g(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Nb(a,b){this.b=Wi(a);this.a=b|0|(0==(b&6291456)?op:0)|(0!=(b&229376)?0:98304)}
function yb(a,b,c){xb.call(this,null,a,b,c|(!a?262144:kp)|(0==(c&6291456)?!a?np:op:0)|0|0|0)}
function ul(a,b,c){27==c.which?A((J(),J(),I),new Xl(a,b),Ap):13==c.which&&A((J(),J(),I),new Ul(a,b),Ap)}
function nb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Cb(a)),67108864,null);!!a.a&&R(a.a);Jb(a.f);a.c=a.c&-8|1}}
function Fk(){if(!Ek){Ek=(++(J(),J(),I).e,new Ib);$wnd.Promise.resolve(null).then(fh(Gk.prototype.D,Gk,[]))}}
function Mo(a){var b;b=S(a.i.a);Nh(Gp,b)||Nh(Cp,b)||Nh('',b)?Dn(a.i,b):Go(En(a.i))?Gn(a.i):Dn(a.i,'')}
function q(a){return kd(a)?ee:jd(a)?Wd:hd(a)?Ud:fd(a)?a.gb:Yc(a)?a.gb:a.gb||Array.isArray(a)&&Uc(Nd,1)||Nd}
function r(a){return kd(a)?Hj(a):jd(a)?md(a):hd(a)?a?1231:1237:fd(a)?a.r():Yc(a)?Bj(a):!!a&&!!a.hashCode?a.hashCode():Bj(a)}
function Kb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&kp)?Mb(a):a.b.u();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function fb(a,b){var c,d;d=a.c;mi(d,b);!!a.b&&kp!=(a.b.c&lp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function ad(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return _c(c&4194303,d&4194303,e&1048575)}
function Rg(a,b){var c;if(jd(a)&&jd(b)){c=a+b;if(-17592186044416<c&&c<tp){return c}}return Sg(ad(jd(a)?Ug(a):a,jd(b)?Ug(b):b))}
function Gh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Ih(),Hh)[b];!c&&(c=Hh[b]=new Fh(a));return c}return new Fh(a)}
function hh(a){var b;if(Array.isArray(a)&&a.ib===ih){return th(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Hj(a){Fj();var b,c,d;c=':'+a;d=Ej[c];if(d!=null){return md(d)}d=Cj[c];b=d==null?Gj(a):md(d);Ij();Ej[c]=b;return b}
function ti(a){var b,c,d;d=1;for(c=new ri(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function bc(a){var b,c;if(!a.a){for(c=new ri(new qi(new di(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.u()}a.a=true}}
function Ub(a){var b;if(a.c){while(a.c.a.length!=0){b=li(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&vb(b.b,3,true)}}}
function yl(a){var b;b=S(a.d);if(!a.j&&b){a.j=true;Nl(a,(jb(a.c),a.o.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function xl(a,b){var c;c=(ib(a.a),a.i);if(null!=c&&c.length!=0){A((J(),J(),I),new Do(b,c),Ap);No(a.n,null);Ol(a,c)}else{eo(a.k,b)}}
function uh(){this.g=rh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Yk(a){var b;this.o=Wi(a);J();b=++Wk;this.b=new mc(b,null,new Zk(this),false,false);this.a=new yb(null,Wi(new $k(this)),zp)}
function gm(a){var b;this.o=Wi(a);J();b=++em;this.b=new mc(b,null,new hm(this),false,false);this.a=new yb(null,Wi(new im(this)),zp)}
function mc(a,b,c,d,e){var f;this.e=a;this.c=d?new dc:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new lb((J(),null)),f):null;this.d=null}
function U(a,b,c,d){this.c=Wi(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new zb(this,d);this.e=new lb(this.f);kp==(d&lp)&&ob(this.f)}
function Dk(){Bk();return $c(Uc(Qe,1),ip,7,0,[fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak])}
function zb(a,b){xb.call(this,a,new Ab(a),null,b|(kp==(b&lp)?0:524288)|(0==(b&6291456)?kp==(b&lp)?op:np:0)|0|268435456|0)}
function p(a,b){return kd(a)?Nh(a,b):jd(a)?a===b:hd(a)?a===b:fd(a)?a.p(b):Yc(a)?a===b:!!a&&!!a.equals?a.equals(b):ld(a)===ld(b)}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Tj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function oi(a,b){var c,d;d=a.a.length;b.length<d&&(b=yj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Bh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Bc(){var a;if(wc!=0){a=vc();if(a-xc>2000){xc=a;yc=$wnd.setTimeout(Hc,10)}}if(wc++==0){Kc((Jc(),Ic));return true}return false}
function Sc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function ed(a,b){if(kd(a)){return !!dd[b]}else if(a.hb){return !!a.hb[b]}else if(jd(a)){return !!cd[b]}else if(hd(a)){return !!bd[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&vb(b,5,true)}}}
function Xb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ri(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&vb(b,6,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?vb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Oh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Xc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{$b(b,d);try{f=(c.a.u(),null)}finally{_b()}return f}catch(a){a=Pg(a);if(gd(a,5)){e=a;throw Qg(e)}else throw Qg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.s()}else{$b(b,e);try{g=c.s()}finally{_b()}}return g}catch(a){a=Pg(a);if(gd(a,5)){f=a;throw Qg(f)}else throw Qg(a)}finally{D(b)}}
function Zn(a,b){var c,d,e;this.e=Wi(a);this.d=b;J();c=++Qn;this.c=new mc(c,null,new $n(this),true,true);this.b=(e=new lb(null),e);this.a=(d=new lb(null),d)}
function ll(a){var b,c;this.o=Wi(a);J();b=++fl;this.c=new mc(b,null,new ml(this),false,false);this.b=(c=new lb(null),c);this.a=new yb(null,Wi(new ql(this)),zp)}
function Ok(a){var b;this.o=Wi(a);J();b=++Kk;this.c=new mc(b,null,new Pk(this),false,false);this.a=new U(new Qk(this),null,null,136478720);this.b=new yb(null,Wi(new Rk(this)),zp)}
function Eb(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Kb(c);return true}
function Zg(b,c,d,e){Yg();var f=Wg;$moduleName=c;$moduleBase=d;Og=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{fp(g)()}catch(a){b(c,a)}}else{fp(g)()}}
function Oj(a,b){var c;c=new $wnd.Object;c.$$typeof=Wi(a);c.type=Wi(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ii(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ji()}}
function Sh(a,b){var c,d,e,f,g;g=Yh(a.a);b.length<g&&(b=yj(new Array(g),b));e=(f=new bi((new $h(a.a)).a),new ei(f));for(d=0;d<g;++d){b[d]=(c=ai(e.a),c.W())}b.length>g&&(b[g]=null);return b}
function Vk(a){var b,c,d;a.c=0;Fk();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),Qj('span',Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,['todo-count'])),[Qj('strong',null,[c]),' '+d+' left']));return b}
function ah(){_g={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Oc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].jb()&&(c=Nc(c,g)):g[0].jb()}catch(a){a=Pg(a);if(gd(a,5)){d=a;zc();Fc(gd(d,34)?d.B():d)}else throw Qg(a)}}return c}
function el(a){var b;a.d=0;Fk();b=Qj(Bp,Xj(_j(ak(dk(bk(Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,['new-todo']))),(ib(a.b),a.f)),fh(Sm.prototype.db,Sm,[a])),fh(Tm.prototype.cb,Tm,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.s();if(!(ld(e)===ld(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Pg(a);if(gd(a,11)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Qg(c)}else throw Qg(a)}}
function zi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=wi(b,e);if(f){return f.X(c)}}e[e.length]=new fi(b,c);++a.b;return null}
function uj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Gj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Mh(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Wc(ce,ip,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function pb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.u()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Pg(a);if(gd(a,5)){J()}else throw Qg(a)}}}
function An(a){var b;if(0==a.length){b=(nh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',mh.title,b)}else{(nh(),$wnd.window.window).location.hash=a}}
function xb(a,b,c,d){this.b=new pi;this.f=new Nb(new Bb(this),d&6520832|262144|kp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&np)&&D((null,I)))}
function Ai(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(ui(b,e.V())){if(d.length==1){d.length=0;Di(a.a,g)}else{d.splice(h,1)}--a.b;return e.W()}}return null}
function dh(a,b,c){var d=_g,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=_g[b]),gh(h));_.hb=c;!b&&(_.ib=ih);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.gb=f)}
function Ah(a){if(a.J()){var b=a.c;b.K()?(a.k='['+b.j):!b.J()?(a.k='[L'+b.H()+';'):(a.k='['+b.H());a.b=b.G()+'[]';a.i=b.I()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Bh('.',[c,Bh('$',d)]);a.b=Bh('.',[c,Bh('.',d)]);a.i=d[d.length-1]}
function Th(a,b){var c,d,e;c=b.V();e=b.W();d=kd(c)?c==null?Uh(yi(a.a,null)):Mi(a.b,c):Uh(yi(a.a,c));if(!(ld(e)===ld(d)||e!=null&&p(e,d))){return false}if(d==null&&!(kd(c)?c==null?!!yi(a.a,null):Li(a.b,c):!!yi(a.a,c))){return false}return true}
function jh(){var a;a=new ln;vm=new nn(a);new nn(a);Am=new pn(a);new pn(a);Lm=new tn(a);Km=new Mm;new tn(a);new Rl(Xi(Km));Rm=new vn(a);new vn(a);Fm=new rn(a);new rn(a);$wnd.ReactDOM.render(Pj([(new gn).a]),(nh(),mh).getElementById('app'),null)}
function Qj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Kj(b,fh(Sj.prototype.ab,Sj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[wp]=c[0],undefined):(d[wp]=c,undefined));return Nj(a,e,f,d)}
function In(){var a,b;this.d=new Vo(this);this.f=this.e=(b=(nh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new mc(0,null,new Jn(this),false,false);this.b=(a=new lb(null),a);this.a=new U(new On,new Kn(this),new Ln(this),35749888)}
function jo(){var a;this.g=new vi;J();this.f=new mc(0,new lo(this),new ko(this),false,false);this.d=(a=new lb(null),a);this.c=new U(new oo(this),null,null,Fp);this.e=new U(new po(this),null,null,Fp);this.a=new U(new qo(this),null,null,Fp);this.b=new U(new ro(this),null,null,Fp)}
function Oo(a){var b;this.j=Wi(a);this.i=new In;J();this.g=new mc(0,null,new Po(this),false,false);this.d=(b=new lb(null),b);this.b=new U(new Qo(this),null,null,Fp);this.c=new U(new Ro(this),null,null,Fp);this.e=u(new So(this),413138944);this.a=u(new To(this),681574400);D((null,I))}
function wb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ri(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Pg(a);if(!gd(a,5))throw Qg(a)}if(6==(b.c&7)){return true}}}}}rb(b);return false}
function Pl(a){var b,c,d;this.o=Wi(a);J();b=++Dl;this.e=new mc(b,null,new Ql(this),false,false);this.c=(d=new lb(null),d);this.a=(c=new lb(null),c);this.d=new U(new Wl(this),null,null,136478720);this.b=new yb(null,Wi(new $l(this)),zp);sn(Lm,this);Nl(this,(jb(this.c),this.o.props['a']))}
function Hi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function vb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){kb(a.a.e);ub((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;ub((e=d.i,e));d.k=null}ii(a.b,new Db(a));a.b.a=Wc(ce,ip,1,0,5,1)}else 3==g&&!!a.a&&ub((f=a.a.g,f))}}
function Bk(){Bk=eh;fk=new Ck(xp,0);gk=new Ck('checkbox',1);hk=new Ck('color',2);ik=new Ck('date',3);jk=new Ck('datetime',4);kk=new Ck('email',5);lk=new Ck('file',6);mk=new Ck('hidden',7);nk=new Ck('image',8);ok=new Ck('month',9);pk=new Ck(gp,10);qk=new Ck('password',11);rk=new Ck('radio',12);sk=new Ck('range',13);tk=new Ck('reset',14);uk=new Ck('search',15);vk=new Ck('submit',16);wk=new Ck('tel',17);xk=new Ck('text',18);yk=new Ck('time',19);zk=new Ck('url',20);Ak=new Ck('week',21)}
function dm(a){var b,c,d;a.c=0;Fk();d=Qj('div',null,[Qj('div',null,[Qj(Dp,Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,[Dp])),[Qj('h1',null,['todos']),(new Um).a]),S(a.d.c)?null:Qj('section',Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,[Dp])),[Qj(Bp,_j(ck(Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,['toggle-all'])),(Bk(),gk)),fh(fn.prototype.cb,fn,[a])),null),Qj('ul',Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,['todo-list'])),(b=gj(Wi(fj(S(a.f.c).Q())),(c=new pi,c)),oi(b,Zc(b.a.length))))]),S(a.d.c)?null:(new lm).a])]);return d}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ji(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ni(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&vb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ji(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){li(a.b,g)}e&&tb(a.e,a.b)}else{e&&tb(a.e,new pi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&kp!=(k.b.c&lp)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function Jk(a){var b,c;a.d=0;Fk();c=(b=S(a.g.b),Qj('footer',Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,['footer'])),[(new mm).a,Qj('ul',Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,['filters'])),[Qj('li',null,[Qj('a',Vj(Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,[(Zo(),Xo)==b?yp:null])),'#'),['All'])]),Qj('li',null,[Qj('a',Vj(Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,[Wo==b?yp:null])),'#active'),['Active'])]),Qj('li',null,[Qj('a',Vj(Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,[Yo==b?yp:null])),'#completed'),['Completed'])])]),S(a.a)?Qj(xp,Wj(Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,['clear-completed'])),fh(km.prototype.eb,km,[a])),['Clear Completed']):null]));return c}
function Cl(a){var b,c,d,e;a.f=0;Fk();b=(jb(a.c),a.o.props['a']);if(b.c.i<0){return null}c=(d=(jb(a.c),a.o.props['a']),e=(ib(d.a),d.d),Qj('li',Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,[e?Cp:null,S(a.d)?'editing':null])),[Qj('div',Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,['view'])),[Qj(Bp,_j(Yj(ck(Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,['toggle'])),(Bk(),gk)),e),fh(Xm.prototype.cb,Xm,[d])),null),Qj('label',ek(new $wnd.Object,fh(Ym.prototype.eb,Ym,[a,d])),[(ib(d.b),d.e)]),Qj(xp,Wj(Tj(new $wnd.Object,$c(Uc(ee,1),ip,2,6,['destroy'])),fh(Zm.prototype.eb,Zm,[a,d])),null)]),Qj(Bp,ak(_j($j(Zj(Tj(Uj(new $wnd.Object,fh($m.prototype.v,$m,[a])),$c(Uc(ee,1),ip,2,6,['edit'])),(ib(a.a),a.i)),fh(_m.prototype.bb,_m,[a,d])),fh(Wm.prototype.cb,Wm,[a])),fh(an.prototype.db,an,[a,d])),null)]));return c}
function Ji(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[vp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Hi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[vp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var gp='number',hp={10:1},ip={3:1,4:1},jp={9:1},kp=1048576,lp=1835008,mp={6:1},np=2097152,op=4194304,pp={21:1},qp='__noinit__',rp='__java$exception',sp={3:1,11:1,8:1,5:1},tp=17592186044416,up={39:1},vp='delete',wp='children',xp='button',yp='selected',zp=1478627328,Ap=142606336,Bp='input',Cp='completed',Dp='header',Ep='hashchange',Fp=136413184,Gp='active';var _,_g,Wg,Og=-1;ah();dh(1,null,{},o);_.p=Hp;_.q=function(){return this.gb};_.r=Ip;_.equals=function(a){return this.p(a)};_.hashCode=function(){return this.r()};var bd,cd,dd;dh(53,1,{},uh);_.F=function(a){var b;b=new uh;b.e=4;a>1?(b.c=yh(this,a-1)):(b.c=this);return b};_.G=function(){sh(this);return this.b};_.H=function(){return th(this)};_.I=function(){sh(this);return this.i};_.J=function(){return (this.e&4)!=0};_.K=function(){return (this.e&1)!=0};_.e=0;_.g=0;var rh=1;var ce=wh(1);var Vd=wh(53);dh(98,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var pd=wh(98);dh(35,1,hp,G);_.s=function(){return this.a.u(),null};var nd=wh(35);dh(99,1,{},H);var od=wh(99);var I;dh(44,1,{44:1},P);_.b=0;_.c=false;_.d=0;var qd=wh(44);dh(227,1,jp);var td=wh(227);dh(18,227,jp,U);_.t=function(){R(this)};_.a=false;_.d=0;var rd=wh(18);dh(134,1,{264:1},bb);var sd=wh(134);dh(14,227,{9:1,14:1},lb);_.t=function(){cb(this)};_.a=4;_.d=false;_.e=0;var vd=wh(14);dh(169,1,mp,mb);_.u=function(){db(this.a)};var ud=wh(169);dh(17,227,{9:1,17:1},yb,zb);_.t=function(){nb(this)};_.c=0;var Ad=wh(17);dh(170,1,pp,Ab);_.u=function(){Q(this.a)};var wd=wh(170);dh(171,1,mp,Bb);_.u=function(){pb(this.a)};var xd=wh(171);dh(172,1,mp,Cb);_.u=function(){sb(this.a)};var yd=wh(172);dh(173,1,{},Db);_.v=function(a){qb(this.a,a)};var zd=wh(173);dh(135,1,{},Gb);_.a=0;_.b=0;_.c=0;var Bd=wh(135);dh(174,1,jp,Ib);_.t=function(){Hb(this)};_.a=false;var Cd=wh(174);dh(69,227,{9:1,69:1},Nb);_.t=function(){Jb(this)};_.a=0;var Dd=wh(69);dh(179,1,{},Zb);_.a=0;var Ob;var Ed=wh(179);dh(177,1,jp,dc);_.t=function(){bc(this)};_.a=false;var Fd=wh(177);dh(140,1,{});var Id=wh(140);dh(151,1,{},hc);_.v=function(a){fc(this.a,a)};var Gd=wh(151);dh(152,1,mp,ic);_.u=function(){gc(this.a,this.b)};var Hd=wh(152);dh(141,140,{});var Jd=wh(141);dh(16,1,jp,mc);_.t=function(){jc(this)};_.e=0;_.i=0;var Ld=wh(16);dh(168,1,mp,nc);_.u=function(){lc(this.a)};var Kd=wh(168);dh(5,1,{3:1,5:1});_.w=function(a){return new Error(a)};_.A=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=th(this.gb),c==null?a:a+': '+c);pc(this,qc(this.w(b)));Rc(this)};_.b=qp;_.d=true;var fe=wh(5);dh(11,5,{3:1,11:1,5:1});var Yd=wh(11);dh(8,11,sp);var de=wh(8);dh(41,8,sp);var _d=wh(41);dh(80,41,sp);var Pd=wh(80);dh(34,80,{34:1,3:1,11:1,8:1,5:1},uc);_.B=function(){return ld(this.a)===ld(sc)?null:this.a};var sc;var Md=wh(34);var Nd=wh(0);dh(205,1,{});var Od=wh(205);var wc=0,xc=0,yc=-1;dh(102,205,{},Mc);var Ic;var Qd=wh(102);var Pc;dh(216,1,{});var Sd=wh(216);dh(81,216,{},Tc);var Rd=wh(81);dh(45,1,{45:1,73:1},kh);_.C=function(){if(this===this.a){this.a=this.b.C();this.b=null}return this.a};var Td=wh(45);var mh;bd={3:1,76:1,29:1};var Ud=wh(76);dh(40,1,{3:1,40:1});var be=wh(40);cd={3:1,29:1,40:1};var Wd=wh(215);dh(31,1,{3:1,29:1,31:1});_.p=Hp;_.r=Ip;_.b=0;var Xd=wh(31);dh(82,8,sp,Eh);var Zd=wh(82);dh(30,40,{3:1,29:1,30:1,40:1},Fh);_.p=function(a){return gd(a,30)&&a.a==this.a};_.r=Lp;_.a=0;var $d=wh(30);var Hh;dh(282,1,{});dh(57,41,sp,Kh,Lh);_.w=function(a){return new TypeError(a)};var ae=wh(57);dd={3:1,75:1,29:1,2:1};var ee=wh(2);dh(286,1,{});dh(56,8,sp,Qh);var ge=wh(56);dh(219,1,{38:1});_.L=Np;_.P=function(){return new _i(this,0)};_.Q=function(){return new hj(null,this.P())};_.N=function(a){throw Qg(new Qh('Add not supported on this collection'))};var he=wh(219);dh(225,1,{204:1});_.p=function(a){var b,c,d;if(a===this){return true}if(!gd(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new bi((new $h(d)).a);c.b;){b=ai(c);if(!Th(this,b)){return false}}return true};_.r=function(){return si(new $h(this))};var se=wh(225);dh(133,225,{204:1});var ke=wh(133);dh(224,219,{38:1,232:1});_.P=function(){return new _i(this,1)};_.p=function(a){var b;if(a===this){return true}if(!gd(a,23)){return false}b=a;if(Yh(b.a)!=this.O()){return false}return Rh(this,b)};_.r=function(){return si(this)};var te=wh(224);dh(23,224,{23:1,38:1,232:1},$h);_.M=function(){return new bi(this.a)};_.O=Kp;var je=wh(23);dh(24,1,{},bi);_.R=Jp;_.T=function(){return ai(this)};_.S=Mp;_.b=false;var ie=wh(24);dh(220,219,{38:1,230:1});_.P=function(){return new _i(this,16)};_.U=function(a,b){throw Qg(new Qh('Add not supported on this list'))};_.N=function(a){this.U(this.O(),a);return true};_.p=function(a){var b,c,d,e,f;if(a===this){return true}if(!gd(a,13)){return false}f=a;if(this.O()!=f.a.length){return false}e=new ri(f);for(c=new ri(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(ld(b)===ld(d)||b!=null&&p(b,d))){return false}}return true};_.r=function(){return ti(this)};_.M=function(){return new ci(this)};var me=wh(220);dh(100,1,{},ci);_.R=Jp;_.S=function(){return this.a<this.b.a.length};_.T=function(){return ji(this.b,this.a++)};_.a=0;var le=wh(100);dh(43,219,{38:1},di);_.M=function(){var a;return a=new bi((new $h(this.a)).a),new ei(a)};_.O=Kp;var oe=wh(43);dh(63,1,{},ei);_.R=Jp;_.S=function(){return this.a.b};_.T=function(){var a;return a=ai(this.a),a.W()};var ne=wh(63);dh(131,1,up);_.p=function(a){var b;if(!gd(a,39)){return false}b=a;return ui(this.a,b.V())&&ui(this.b,b.W())};_.V=Lp;_.W=Mp;_.r=function(){return Vi(this.a)^Vi(this.b)};_.X=function(a){var b;b=this.b;this.b=a;return b};var pe=wh(131);dh(132,131,up,fi);var qe=wh(132);dh(226,1,up);_.p=function(a){var b;if(!gd(a,39)){return false}b=a;return ui(this.b.value[0],b.V())&&ui(Ri(this),b.W())};_.r=function(){return Vi(this.b.value[0])^Vi(Ri(this))};var re=wh(226);dh(13,220,{3:1,13:1,38:1,230:1},pi,qi);_.U=function(a,b){vj(this.a,a,b)};_.N=function(a){return hi(this,a)};_.L=function(a){ii(this,a)};_.M=function(){return new ri(this)};_.O=function(){return this.a.length};var ve=wh(13);dh(15,1,{},ri);_.R=Jp;_.S=function(){return this.a<this.c.a.length};_.T=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ue=wh(15);dh(36,133,{3:1,36:1,204:1},vi);var we=wh(36);dh(66,1,{},Bi);_.L=Np;_.M=function(){return new Ci(this)};_.b=0;var ye=wh(66);dh(67,1,{},Ci);_.R=Jp;_.T=function(){return this.d=this.a[this.c++],this.d};_.S=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var xe=wh(67);var Fi;dh(64,1,{},Pi);_.L=Np;_.M=function(){return new Qi(this)};_.b=0;_.c=0;var Be=wh(64);dh(65,1,{},Qi);_.R=Jp;_.T=function(){return this.c=this.a,this.a=this.b.next(),new Si(this.d,this.c,this.d.c)};_.S=function(){return !this.a.done};var ze=wh(65);dh(139,226,up,Si);_.V=function(){return this.b.value[0]};_.W=function(){return Ri(this)};_.X=function(a){return Ni(this.a,this.b.value[0],a)};_.c=0;var Ae=wh(139);dh(189,1,{});_.R=function(a){Yi(this,a)};_.Y=function(){return this.d};_.Z=function(){return this.e};_.d=0;_.e=0;var De=wh(189);dh(70,189,{});var Ce=wh(70);dh(22,1,{},_i);_.Y=Lp;_.Z=function(){$i(this);return this.c};_.R=function(a){$i(this);this.d.R(a)};_.$=function(a){$i(this);if(this.d.S()){a.v(this.d.T());return true}return false};_.a=0;_.c=0;var Ee=wh(22);dh(188,1,{});_.c=false;var Ne=wh(188);dh(26,188,{267:1,26:1},hj);var Me=wh(26);dh(191,70,{},lj);_.$=function(a){this.b=false;while(!this.b&&this.c.$(new mj(this,a)));return this.b};_.b=false;var Ge=wh(191);dh(194,1,{},mj);_.v=function(a){kj(this.a,this.b,a)};var Fe=wh(194);dh(190,70,{},nj);_.$=function(a){return this.a.$(new oj(a))};var Ie=wh(190);dh(193,1,{},oj);_.v=function(a){this.a.v(bn(new cn,a))};var He=wh(193);dh(192,1,{},qj);_.v=function(a){pj(this,a)};var Je=wh(192);dh(195,1,{},rj);_.v=function(a){};var Ke=wh(195);dh(196,1,{},tj);_.v=function(a){sj(this,a)};var Le=wh(196);dh(284,1,{});dh(228,1,{});var Oe=wh(228);dh(281,1,{});var Aj=0;var Cj,Dj=0,Ej;dh(744,1,{});dh(755,1,{});dh(217,1,{});var Pe=wh(217);dh(266,$wnd.Function,{},Sj);_.ab=function(a){Rj(this.a,this.b,a)};dh(7,31,{3:1,29:1,31:1,7:1},Ck);var fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak;var Qe=xh(7,Dk);var Ek;dh(265,$wnd.Function,{},Gk);_.D=function(a){return Hb(Ek),Ek=null,null};dh(221,217,{});var zf=wh(221);dh(103,221,{});_.d=0;var Df=wh(103);dh(104,103,jp,Ok);_.t=Op;_.p=Hp;_.r=Ip;var Kk=0;var Ze=wh(104);dh(105,1,mp,Pk);_.u=function(){Lk(this.a)};var Re=wh(105);dh(106,1,hp,Qk);_.s=function(){return Mk(this.a)};var Se=wh(106);dh(107,1,pp,Rk);_.u=function(){Ik(this.a)};var Te=wh(107);dh(108,1,hp,Sk);_.s=function(){return Jk(this.a)};var Ue=wh(108);dh(222,217,{});var yf=wh(222);dh(110,222,{});_.c=0;var Cf=wh(110);dh(111,110,jp,Yk);_.t=Pp;_.p=Hp;_.r=Ip;var Wk=0;var Ye=wh(111);dh(112,1,mp,Zk);_.u=Qp;var Ve=wh(112);dh(113,1,pp,$k);_.u=function(){Uk(this.a)};var We=wh(113);dh(114,1,hp,_k);_.s=function(){return Vk(this.a)};var Xe=wh(114);dh(122,217,{});_.f='';var Mf=wh(122);dh(123,122,{});_.d=0;var Ff=wh(123);dh(124,123,jp,ll);_.t=Op;_.p=Hp;_.r=Ip;var fl=0;var df=wh(124);dh(125,1,mp,ml);_.u=function(){gl(this.a)};var $e=wh(125);dh(127,1,hp,nl);_.s=function(){return el(this.a)};var _e=wh(127);dh(128,1,mp,ol);_.u=function(){al(this.a)};var af=wh(128);dh(129,1,mp,pl);_.u=function(){il(this.a,this.b)};var bf=wh(129);dh(126,1,pp,ql);_.u=function(){Ik(this.a)};var cf=wh(126);dh(218,217,{});_.j=false;var Of=wh(218);dh(84,218,{});_.f=0;var If=wh(84);dh(85,84,jp,Pl);_.t=function(){jc(this.e)};_.p=Hp;_.r=Ip;var Dl=0;var rf=wh(85);dh(87,1,mp,Ql);_.u=function(){El(this.a)};var ef=wh(87);dh(86,1,{},Rl);var ff=wh(86);dh(90,1,hp,Sl);_.s=function(){return Cl(this.a)};var gf=wh(90);dh(42,1,mp,Tl);_.u=function(){Ol(this.a,En(this.b))};var hf=wh(42);dh(55,1,mp,Ul);_.u=function(){xl(this.a,this.b)};var jf=wh(55);dh(91,1,mp,Vl);_.u=function(){wl(this.a,this.b)};var kf=wh(91);dh(88,1,hp,Wl);_.s=function(){return Hl(this.a)};var lf=wh(88);dh(92,1,mp,Xl);_.u=function(){vl(this.a,this.b)};var mf=wh(92);dh(93,1,mp,Yl);_.u=function(){rl(this.a,this.b)};var nf=wh(93);dh(94,1,mp,Zl);_.u=function(){yl(this.a)};var of=wh(94);dh(89,1,pp,$l);_.u=function(){Bl(this.a)};var pf=wh(89);dh(95,1,hp,_l);_.s=function(){return Il(this.a,this.b)};var qf=wh(95);dh(223,217,{});var Qf=wh(223);dh(116,223,{});_.c=0;var Kf=wh(116);dh(117,116,jp,gm);_.t=Pp;_.p=Hp;_.r=Ip;var em=0;var vf=wh(117);dh(118,1,mp,hm);_.u=Qp;var sf=wh(118);dh(119,1,pp,im);_.u=function(){Uk(this.a)};var tf=wh(119);dh(120,1,hp,jm);_.s=function(){return dm(this.a)};var uf=wh(120);dh(256,$wnd.Function,{},km);_.eb=function(a){xo(this.a.f)};dh(176,1,{},lm);var wf=wh(176);dh(199,1,{},mm);var xf=wh(199);dh(257,$wnd.Function,{},rm);_.fb=function(a){return new um(a)};var sm;dh(109,$wnd.React.Component,{},um);bh(_g[1],_);_.componentWillUnmount=function(){Hk(this.a)};_.render=function(){return Nk(this.a)};var Af=wh(109);var vm;dh(258,$wnd.Function,{},wm);_.fb=function(a){return new zm(a)};var xm;dh(115,$wnd.React.Component,{},zm);bh(_g[1],_);_.componentWillUnmount=function(){Tk(this.a)};_.render=function(){return Xk(this.a)};var Bf=wh(115);var Am;dh(263,$wnd.Function,{},Bm);_.fb=function(a){return new Em(a)};var Cm;dh(130,$wnd.React.Component,{},Em);bh(_g[1],_);_.componentWillUnmount=function(){Hk(this.a)};_.render=function(){return jl(this.a)};var Ef=wh(130);var Fm;dh(237,$wnd.Function,{},Gm);_.fb=function(a){return new Jm(a)};var Hm;dh(96,$wnd.React.Component,{},Jm);bh(_g[1],_);_.componentDidUpdate=function(a){Ll(this.a)};_.componentWillUnmount=function(){zl(this.a)};_.render=function(){return Ml(this.a)};_.shouldComponentUpdate=function(a){return Fl(this.a,a)};var Gf=wh(96);var Km,Lm;dh(83,1,{236:1},Mm);var Hf=wh(83);dh(260,$wnd.Function,{},Nm);_.fb=function(a){return new Qm(a)};var Om;dh(121,$wnd.React.Component,{},Qm);bh(_g[1],_);_.componentWillUnmount=function(){Tk(this.a)};_.render=function(){return fm(this.a)};var Jf=wh(121);var Rm;dh(261,$wnd.Function,{},Sm);_.db=function(a){bl(this.a,a)};dh(262,$wnd.Function,{},Tm);_.cb=function(a){hl(this.a,a)};dh(175,1,{},Um);var Lf=wh(175);dh(244,$wnd.Function,{},Wm);_.cb=function(a){Gl(this.a,a)};dh(238,$wnd.Function,{},Xm);_.cb=function(a){Yn(this.a)};dh(240,$wnd.Function,{},Ym);_.eb=function(a){Jl(this.a,this.b)};dh(241,$wnd.Function,{},Zm);_.eb=function(a){sl(this.a,this.b)};dh(242,$wnd.Function,{},$m);_.v=function(a){tl(this.a,a)};dh(243,$wnd.Function,{},_m);_.bb=function(a){Kl(this.a,this.b)};dh(245,$wnd.Function,{},an);_.db=function(a){ul(this.a,this.b,a)};dh(198,1,{},cn);var Nf=wh(198);dh(259,$wnd.Function,{},fn);_.cb=function(a){am(this.a,a)};dh(74,1,{},gn);var Pf=wh(74);dh(101,1,{},ln);var Wf=wh(101);dh(58,1,{},nn);var Rf=wh(58);dh(62,1,{},pn);var Sf=wh(62);dh(61,1,{},rn);var Tf=wh(61);dh(59,1,{},tn);var Uf=wh(59);dh(60,1,{},vn);var Vf=wh(60);dh(180,1,{});var Dg=wh(180);dh(181,180,jp,In);_.t=Op;_.p=Hp;_.r=Ip;var cg=wh(181);dh(182,1,mp,Jn);_.u=function(){Cn(this.a)};var Xf=wh(182);dh(184,1,pp,Kn);_.u=function(){xn(this.a)};var Yf=wh(184);dh(185,1,pp,Ln);_.u=function(){yn(this.a)};var Zf=wh(185);dh(187,1,mp,Mn);_.u=function(){Fn(this.a)};var $f=wh(187);dh(68,1,mp,Nn);_.u=function(){Bn(this.a)};var _f=wh(68);dh(183,1,hp,On);_.s=function(){var a;return a=(nh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var ag=wh(183);dh(186,1,mp,Pn);_.u=function(){wn(this.a,this.b)};var bg=wh(186);dh(49,1,{49:1});_.d=false;var Lg=wh(49);dh(50,49,{9:1,268:1,50:1,49:1},Zn);_.t=Op;_.p=function(a){return Sn(this,a)};_.r=function(){return this.c.e};var Qn=0;var ug=wh(50);dh(200,1,mp,$n);_.u=function(){Rn(this.a)};var dg=wh(200);dh(201,1,mp,_n);_.u=function(){Vn(this.a)};var eg=wh(201);dh(46,141,{46:1});var Gg=wh(46);dh(142,46,{9:1,46:1},jo);_.t=function(){jc(this.f)};_.p=Hp;_.r=Ip;var og=wh(142);dh(144,1,mp,ko);_.u=function(){bo(this.a)};var fg=wh(144);dh(143,1,mp,lo);_.u=function(){go(this.a)};var gg=wh(143);dh(149,1,mp,mo);_.u=function(){ec(this.a,this.b,true)};var hg=wh(149);dh(150,1,hp,no);_.s=function(){return ao(this.a,this.c,this.b)};_.b=false;var ig=wh(150);dh(145,1,hp,oo);_.s=function(){return ho(this.a)};var jg=wh(145);dh(146,1,hp,po);_.s=function(){return Gh(Vg(dj(fo(this.a))))};var kg=wh(146);dh(147,1,hp,qo);_.s=function(){return Gh(Vg(dj(ej(fo(this.a),new ap))))};var lg=wh(147);dh(148,1,hp,ro);_.s=function(){return io(this.a)};var mg=wh(148);dh(136,1,{73:1},uo);_.C=function(){return new jo};var so;var ng=wh(136);dh(47,1,{47:1});var Kg=wh(47);dh(154,47,{9:1,47:1},Bo);_.t=function(){jc(this.a)};_.p=Hp;_.r=Ip;var tg=wh(154);dh(155,1,mp,Co);_.u=function(){yo(this.a,this.b)};_.b=false;var pg=wh(155);dh(156,1,mp,Do);_.u=function(){Hn(this.b,this.a)};var qg=wh(156);dh(157,1,mp,Eo);_.u=function(){zo(this.a)};var rg=wh(157);dh(137,1,{73:1},Fo);_.C=function(){return new Bo(this.a.C())};var sg=wh(137);dh(48,1,{48:1});var Ng=wh(48);dh(161,48,{9:1,48:1},Oo);_.t=function(){jc(this.g)};_.p=Hp;_.r=Ip;var Bg=wh(161);dh(162,1,mp,Po);_.u=function(){Io(this.a)};var vg=wh(162);dh(163,1,hp,Qo);_.s=function(){var a;return a=En(this.a.i),Nh(Gp,a)||Nh(Cp,a)||Nh('',a)?Nh(Gp,a)?(Zo(),Wo):Nh(Cp,a)?(Zo(),Yo):(Zo(),Xo):(Zo(),Xo)};var wg=wh(163);dh(164,1,hp,Ro);_.s=function(){return Ko(this.a)};var xg=wh(164);dh(165,1,pp,So);_.u=function(){Lo(this.a)};var yg=wh(165);dh(166,1,pp,To);_.u=function(){Mo(this.a)};var zg=wh(166);dh(138,1,{73:1},Uo);_.C=function(){return new Oo(this.a.C())};var Ag=wh(138);dh(178,1,{},Vo);_.handleEvent=function(a){zn(this.a,a)};var Cg=wh(178);dh(32,31,{3:1,29:1,31:1,32:1},$o);var Wo,Xo,Yo;var Eg=xh(32,_o);dh(153,1,{},ap);_._=function(a){return !Un(a)};var Fg=wh(153);dh(159,1,{},bp);_._=function(a){return Un(a)};var Hg=wh(159);dh(160,1,{},cp);_.v=function(a){eo(this.a,a)};var Ig=wh(160);dh(158,1,{},dp);_.v=function(a){wo(this.a,a)};_.a=false;var Jg=wh(158);dh(167,1,{},ep);_._=function(a){return Ho(this.a,a)};var Mg=wh(167);var fp=(zc(),Cc);var gwtOnLoad=gwtOnLoad=Zg;Xg(jh);$g('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();