function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='51ECDDE21F0FFF0F2378E7C7D3E7AE84',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '51ECDDE21F0FFF0F2378E7C7D3E7AE84';function p(){}
function Bh(){}
function xh(){}
function Fb(){}
function Qc(){}
function Xc(){}
function ki(){}
function kn(){}
function fn(){}
function on(){}
function sn(){}
function wn(){}
function Rn(){}
function Gj(){}
function Uj(){}
function ak(){}
function bk(){}
function Bk(){}
function pl(){}
function wo(){}
function _o(){}
function Ip(){}
function Jp(){}
function Vc(a){Uc()}
function bn(a){an=a}
function en(a){dn=a}
function En(a){Dn=a}
function Pn(a){On=a}
function Un(a){Tn=a}
function Kh(){Kh=xh}
function Ni(){Ei(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function fc(a){this.a=a}
function oc(a){this.a=a}
function $h(a){this.a=a}
function ji(a){this.a=a}
function wi(a){this.a=a}
function Bi(a){this.a=a}
function Ci(a){this.a=a}
function Cl(a){this.a=a}
function yl(a){this.a=a}
function Bl(a){this.a=a}
function Dl(a){this.a=a}
function Kl(a){this.a=a}
function Nl(a){this.a=a}
function Ol(a){this.a=a}
function _l(a){this.a=a}
function Hj(a){this.a=a}
function dk(a){this.a=a}
function dm(a){this.a=a}
function cm(a){this.a=a}
function fm(a){this.a=a}
function Cm(a){this.a=a}
function Fm(a){this.a=a}
function Km(a){this.a=a}
function Mm(a){this.a=a}
function Nm(a){this.a=a}
function Vm(a){this.a=a}
function Ym(a){this.a=a}
function Zm(a){this.a=a}
function $m(a){this.a=a}
function An(a){this.a=a}
function Bn(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Jn(a){this.a=a}
function Qn(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function _n(a){this.a=a}
function bo(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function so(a){this.a=a}
function uo(a){this.a=a}
function vo(a){this.a=a}
function Io(a){this.a=a}
function Jo(a){this.a=a}
function To(a){this.a=a}
function Uo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function lp(a){this.a=a}
function mp(a){this.a=a}
function vp(a){this.a=a}
function wp(a){this.a=a}
function xp(a){this.a=a}
function yp(a){this.a=a}
function zp(a){this.a=a}
function Ap(a){this.a=a}
function Bp(a){this.a=a}
function Kp(a){this.a=a}
function Lp(a){this.a=a}
function Mp(a){this.a=a}
function Ai(a){this.b=a}
function Pi(a){this.c=a}
function xq(){ic(this.c)}
function zq(){ic(this.b)}
function Eq(){ic(this.f)}
function _i(){this.a=ij()}
function nj(){this.a=ij()}
function _j(a,b){a.a=b}
function uk(a,b){a.key=b}
function tk(a,b){sk(a,b)}
function dp(a,b){Am(b,a)}
function qq(a){rj(this,a)}
function vq(a){vj(this,a)}
function tq(a){ci(this,a)}
function db(a){Yb((J(),a))}
function eb(a){Zb((J(),a))}
function hb(a){$b((J(),a))}
function Y(a){!!a&&$(a)}
function jc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function qb(a,b){a.b=uj(b)}
function hm(a,b){No(a.j,b)}
function cp(a,b){Mo(a.b,b)}
function ck(a,b){Tj(a.a,b)}
function mc(a,b){si(a.e,b)}
function C(a,b){Ob(a.f,b.f)}
function Bq(){kb(this.a.a)}
function Ml(a){this.a=uj(a)}
function bm(a){this.a=uj(a)}
function Ib(a){a.a=-4&a.a|1}
function ql(a){a.d=2;ic(a.c)}
function El(a){a.c=2;ic(a.b)}
function mm(a){a.f=2;ic(a.e)}
function jo(a){R(a.a);$(a.b)}
function yo(a){$(a.b);$(a.a)}
function ul(a){kb(a.b);R(a.a)}
function Vl(a){kb(a.a);$(a.b)}
function ih(a){return a.e}
function im(a,b){return a.g=b}
function sq(){return this.b}
function oq(){return this.a}
function uq(){return this.e}
function pq(){return kk(this)}
function Hi(a,b){return a.a[b]}
function rc(a,b){a.e=b;qc(a,b)}
function hk(a,b){a.splice(b,1)}
function hc(a,b,c){ri(a.e,b,c)}
function zo(a,b,c){hc(a.c,b,c)}
function Aj(a,b,c){b.w(a.a[c])}
function Jh(a){uc.call(this,a)}
function li(a){uc.call(this,a)}
function wq(a){return this===a}
function Nh(a){Mh(a);return a.k}
function Yc(a,b){return Th(a,b)}
function K(a,b){O(a);L(a,uj(b))}
function ab(a){J();Zb(a);a.e=-2}
function J(){J=xh;I=new F}
function wc(){wc=xh;vc=new p}
function Nc(){Nc=xh;Mc=new Qc}
function bp(){bp=xh;ap=new _o}
function ej(){ej=xh;dj=gj()}
function Dc(){Dc=xh;!!(Uc(),Tc)}
function di(){pc(this);this.G()}
function rq(){return ui(this.a)}
function yq(){return this.c.i<0}
function Aq(){return this.b.i<0}
function Fq(){return this.f.i<0}
function ij(){ej();return new dj}
function Sj(a,b){a.T(b);return a}
function Ek(a,b){a.ref=b;return a}
function lo(a){fb(a.b);return a.e}
function Co(a){fb(a.a);return a.d}
function qp(a){fb(a.d);return a.e}
function T(a){mb(a.f);return V(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function Tj(a,b){_j(a,Sj(a.a,b))}
function vj(a,b){while(a.eb(b));}
function Yj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function kj(a,b){return a.a.get(b)}
function ui(a){return a.a.b+a.b.b}
function Cq(a){return 1==this.a.d}
function Dq(a){return 1==this.a.c}
function Di(a,b){this.a=a;this.b=b}
function gc(a,b){this.a=a;this.b=b}
function Yh(a,b){this.a=a;this.b=b}
function Xj(a,b){this.a=a;this.b=b}
function $j(a,b){this.a=a;this.b=b}
function Ck(a,b){this.a=a;this.b=b}
function em(a,b){this.a=a;this.b=b}
function Gm(a,b){this.a=a;this.b=b}
function Hm(a,b){this.a=a;this.b=b}
function Im(a,b){this.a=a;this.b=b}
function Jm(a,b){this.a=a;this.b=b}
function Lm(a,b){this.a=a;this.b=b}
function Hn(a,b){this.a=a;this.b=b}
function In(a,b){this.a=a;this.b=b}
function Kn(a,b){this.a=a;this.b=b}
function Ln(a,b){this.a=a;this.b=b}
function ll(a,b){Yh.call(this,a,b)}
function fk(a,b,c){a.splice(b,0,c)}
function Fk(a,b){a.href=b;return a}
function to(a,b){this.a=a;this.b=b}
function Vo(a,b){this.a=a;this.b=b}
function jp(a,b){this.a=a;this.b=b}
function kp(a,b){this.b=a;this.a=b}
function Gp(a,b){Yh.call(this,a,b)}
function qh(){oh==null&&(oh=[])}
function _m(){this.a=vk((hn(),gn))}
function cn(){this.a=vk((mn(),ln))}
function Cn(){this.a=vk((qn(),pn))}
function Nn(){this.a=vk((un(),tn))}
function Sn(){this.a=vk((yn(),xn))}
function mo(a){ko(a,(fb(a.b),a.e))}
function Do(a){Am(a,(fb(a.a),!a.d))}
function Ub(a){return !a.d?a:Ub(a.d)}
function qi(a){return !a?null:a.ab()}
function tj(a){return a!=null?s(a):0}
function pd(a){return a==null?null:a}
function md(a){return typeof a===Pp}
function o(a,b){return pd(a)===pd(b)}
function Kc(a){$wnd.clearTimeout(a)}
function Ei(a){a.a=$c(ke,Rp,1,0,5,1)}
function ti(a){a.a=new _i;a.b=new nj}
function ib(a){this.c=new Ni;this.b=a}
function ok(){ok=xh;lk=new p;nk=new p}
function Ik(a,b){a.checked=b;return a}
function Ok(a,b){a.value=b;return a}
function Jk(a,b){a.onBlur=b;return a}
function Gk(a,b){a.onClick=b;return a}
function hi(a,b){a.a+=''+b;return a}
function Kk(a,b){a.onChange=b;return a}
function gk(a,b){ek(b,0,a,0,b.length)}
function ec(a,b){cc(a,b,false);eb(a.d)}
function qm(a){kb(a.b);R(a.c);$(a.a)}
function pb(a){J();ob(a);sb(a,2,true)}
function fb(a){var b;Vb((J(),b=Qb,b),a)}
function Db(a){this.d=uj(a);this.b=100}
function Dh(a){this.b=uj(a);this.a=this}
function P(){this.a=$c(ke,Rp,1,100,5,1)}
function B(a,b,c){return u(a,c,2048,b)}
function cd(a,b,c){return {l:a,m:b,h:c}}
function ei(a,b){return a.charCodeAt(b)}
function kd(a,b){return a!=null&&hd(a,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function kk(a){return a.$H||(a.$H=++jk)}
function od(a){return typeof a==='string'}
function Lk(a,b){a.onKeyDown=b;return a}
function Hk(a){a.autoFocus=true;return a}
function Mh(a){if(a.k!=null){return}Vh(a)}
function dc(a,b){mc(b.c,a);kd(b,9)&&b.t()}
function uc(a){this.g=a;pc(this);this.G()}
function Rj(a,b){Kj.call(this,a);this.a=b}
function sk(a,b){for(var c in a){b(c)}}
function rj(a,b){while(a.Y()){ck(b,a.Z())}}
function Ll(a,b){return new Jl(uj(b),a.a)}
function am(a,b){return new $l(uj(b),a.a)}
function A(a,b,c){u(a,new G(b),c,null)}
function xm(a){A((J(),J(),I),new Mm(a),hq)}
function no(a){A((J(),J(),I),new uo(a),hq)}
function Go(a){A((J(),J(),I),new Jo(a),hq)}
function ep(a){A((J(),J(),I),new lp(a),hq)}
function pp(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function pc(a){a.j&&a.e!==Zp&&a.G();return a}
function Pk(a,b){a.onDoubleClick=b;return a}
function Qh(a){var b;b=Ph(a);Xh(a,b);return b}
function bj(a,b){var c;c=a[cq];c.call(a,b)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Nb(a,b,c){Ib(uj(c));K(a.a[b],uj(c))}
function qj(a,b,c){this.a=a;this.b=b;this.c=c}
function Vi(){this.a=new _i;this.b=new nj}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function Uc(){Uc=xh;var a;!Wc();a=new Xc;Tc=a}
function bi(){bi=xh;ai=$c(ge,Rp,30,256,0,1)}
function Ro(a){return _h(S(a.e).a-S(a.a).a)}
function ld(a){return typeof a==='boolean'}
function Ec(a,b,c){return a.apply(b,c);var d}
function Hh(a,b,c,d){a.addEventListener(b,c,d)}
function Fi(a,b){a.a[a.a.length]=b;return true}
function yj(a,b){while(a.c<a.d){Aj(a,b,a.c++)}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function Wo(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new Pb;this.a=new Db(this.f)}
function Wl(a,b){A((J(),J(),I),new em(a,b),hq)}
function rm(a,b){A((J(),J(),I),new Lm(a,b),hq)}
function vm(a,b){A((J(),J(),I),new Im(a,b),hq)}
function wm(a,b){A((J(),J(),I),new Hm(a,b),hq)}
function zm(a,b){A((J(),J(),I),new Gm(a,b),hq)}
function No(a,b){A((J(),J(),I),new Vo(a,b),hq)}
function hp(a,b){A((J(),J(),I),new jp(a,b),hq)}
function Po(a){ci(new Bi(a.g),new fc(a));ti(a.g)}
function np(a){return o(mq,a)||o(nq,a)||o('',a)}
function ad(a){return Array.isArray(a)&&a.pb===Bh}
function Cj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Xl(a,b){var c;c=b.target;Zl(a,c.value)}
function Lj(a,b){var c;return Pj(a,(c=new Ni,c))}
function Eh(a){uj(a);return kd(a,46)?a:new Dh(a)}
function Ri(a){return new Rj(null,Qi(a,a.length))}
function zl(a,b){return new xl(uj(b),a.a,a.b,a.c)}
function Dm(a,b){return new Bm(uj(b),a.a,a.b,a.c)}
function Wm(a,b){return new Um(uj(b),a.a,a.b,a.c)}
function jj(a,b){return !(a.a.get(b)===undefined)}
function Qo(a){return Kh(),0==S(a.e).a?true:false}
function Qi(a,b){return wj(b,a.length),new Bj(a,b)}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ji(a,b){var c;c=a.a[b];hk(a.a,b);return c}
function yi(a){var b;b=a.a.Z();a.b=xi(a);return b}
function Sh(a){var b;b=Ph(a);b.j=a;b.e=1;return b}
function Lo(a){R(a.c);R(a.e);R(a.a);R(a.b);$(a.d)}
function wl(a){return B((J(),J(),I),a.b,new Dl(a))}
function Il(a){return B((J(),J(),I),a.a,new Ol(a))}
function Yl(a){return B((J(),J(),I),a.a,new cm(a))}
function ym(a){return B((J(),J(),I),a.b,new Fm(a))}
function Tm(a){return B((J(),J(),I),a.a,new Zm(a))}
function vl(a){return Kh(),S(a.e.b).a>0?true:false}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function jd(a){return !Array.isArray(a)&&a.pb===Bh}
function rl(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function Fl(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function nm(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Ij(a){if(!a.b){Jj(a);a.c=true}else{Ij(a.b)}}
function Vj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function Zl(a,b){var c;c=a.f;if(b!=c){a.f=b;eb(a.b)}}
function Am(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function Om(a,b){var c;c=b.target;hp(a.e,c.checked)}
function Li(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function vi(a,b){if(b){return oi(a.a,b)}return false}
function Nj(a,b){Jj(a);return new Rj(a,new Wj(b,a.a))}
function Oj(a,b){Jj(a);return new Rj(a,new Zj(b,a.a))}
function ko(a,b){A((J(),J(),I),new to(a,b),75497472)}
function io(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&oo(a,b)}
function gb(a){var b;J();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Ih(a,b,c,d){a.removeEventListener(b,c,d)}
function sm(a,b){tp(a.k,b);A((J(),J(),I),new Gm(a,b),hq)}
function Ui(a,b){return pd(a)===pd(b)||a!=null&&q(a,b)}
function xj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Bj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Dj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Al(a,b,c){this.a=uj(a);this.b=uj(b);this.c=uj(c)}
function Em(a,b,c){this.a=uj(a);this.b=uj(b);this.c=uj(c)}
function Xm(a,b,c){this.a=uj(a);this.b=uj(b);this.c=uj(c)}
function Kj(a){if(!a){this.b=null;new Ni}else{this.b=a}}
function uj(a){if(a==null){throw ih(new di)}return a}
function rk(){if(mk==256){lk=nk;nk=new p;mk=0}++mk}
function nh(a){if(md(a)){return a|0}return a.l|a.m<<22}
function Uh(a){if(a.P()){return null}var b=a.j;return th[b]}
function Nk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Rh(a,b){var c;c=Ph(a);Xh(a,c);c.e=b?8:0;return c}
function oo(a,b){var c;c=a.e;if(b!=c){a.e=uj(b);eb(a.b)}}
function gm(a,b){var c;if(S(a.c)){c=b.target;Am(a,c.value)}}
function sc(a,b){var c;c=Nh(a.nb);return b==null?c:c+': '+b}
function pi(a,b){return b===a?'(this Map)':b==null?_p:Ah(b)}
function Wn(a){return new Al(a.a.a.I(),a.a.b.I(),a.a.c.I())}
function $n(a){return new Em(a.a.a.I(),a.a.b.I(),a.a.c.I())}
function ao(a){return new Xm(a.a.a.I(),a.a.b.I(),a.a.c.I())}
function ci(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function fp(a,b){Lj(Oo(a.b),new Hj(new Gj)).Q(new Lp(b))}
function tm(a,b){A((J(),J(),I),new Gm(a,b),hq);tp(a.k,null)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Wp)&&D((null,I))}
function Rb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function Gh(){Gh=xh;Fh=$wnd.goog.global.document}
function qn(){qn=xh;var a;pn=(a=yh(on.prototype.mb,on,[]),a)}
function hn(){hn=xh;var a;gn=(a=yh(fn.prototype.mb,fn,[]),a)}
function mn(){mn=xh;var a;ln=(a=yh(kn.prototype.mb,kn,[]),a)}
function un(){un=xh;var a;tn=(a=yh(sn.prototype.mb,sn,[]),a)}
function yn(){yn=xh;var a;xn=(a=yh(wn.prototype.mb,wn,[]),a)}
function Hp(){Fp();return bd(Yc(Xg,1),Rp,32,0,[Cp,Ep,Dp])}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Jj(a){if(a.b){Jj(a.b)}else if(a.c){throw ih(new Zh)}}
function zh(a){function b(){}
;b.prototype=a||{};return new b}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function Mk(a){a.placeholder='What needs to be done?';return a}
function go(a,b){b.preventDefault();A((J(),J(),I),new vo(a),hq)}
function Oo(a){fb(a.d);return new Rj(null,new Dj(new Bi(a.g),0))}
function Yi(a,b){var c;return Wi(b,Xi(a,b==null?0:(c=s(b),c|0)))}
function Xi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Th(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function vh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Ak(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function lc(a){jc(a.g);!!a.e&&kc(a);Y(a.a);Y(a.c);jc(a.b);jc(a.f)}
function Oi(a){Ei(this);gk(this.a,ni(a,$c(ke,Rp,1,ui(a.a),5,1)))}
function aj(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function jn(a){$wnd.React.Component.call(this,a);this.a=zl(an,this)}
function nn(a){$wnd.React.Component.call(this,a);this.a=Ll(dn,this)}
function rn(a){$wnd.React.Component.call(this,a);this.a=am(Dn,this)}
function vn(a){$wnd.React.Component.call(this,a);this.a=Dm(On,this)}
function zn(a){$wnd.React.Component.call(this,a);this.a=Wm(Tn,this)}
function Zj(a,b){xj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function zj(a,b){if(a.c<a.d){Aj(a,b,a.c++);return true}return false}
function um(a){return Kh(),qp(a.k)==a.n.props['a']?true:false}
function eo(a){Hh((Gh(),$wnd.goog.global.window),kq,a.d,false)}
function fo(a){Ih((Gh(),$wnd.goog.global.window),kq,a.d,false)}
function gp(a){Lj(Nj(Oo(a.b),new Jp),new Hj(new Gj)).Q(new Kp(a.b))}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ej(a,b){!a.a?(a.a=new ji(a.d)):hi(a.a,a.b);hi(a.a,b);return a}
function Mj(a){var b;Ij(a);b=0;while(a.a.eb(new bk)){b=jh(b,1)}return b}
function Pj(a,b){var c;Ij(a);c=new ak;c.a=b;a.a.X(new dk(c));return c.a}
function bb(a,b){var c,d;Fi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Wj(a,b){xj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function oj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Fj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function ip(a){this.b=uj(a);J();this.a=new nc(0,null,null,false,false)}
function Mo(a,b){var c;return u((J(),J(),I),new Wo(a,b),hq,(c=null,c))}
function Qj(a,b){var c;c=Lj(a,new Hj(new Gj));return Mi(c,b.fb(c.a.length))}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function si(a,b){return od(b)?b==null?$i(a.a,null):mj(a.b,b):$i(a.a,b)}
function op(a,b){return (Fp(),Dp)==a||(Cp==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function ik(a,b){return Zc(b)!=10&&bd(r(b),b.ob,b.__elementTypeId$,Zc(b),a),a}
function co(a,b){a.f=b;o(b,S(a.a))&&oo(a,b);ho(b);A((J(),J(),I),new vo(a),hq)}
function Jb(b){try{b.b.v()}catch(a){a=hh(a);if(!kd(a,4))throw ih(a)}}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Pl(a){var b;b=gi((fb(a.b),a.f));if(b.length>0){cp(a.e,b);Zl(a,'')}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Ii(a,b,c){for(;c<a.a.length;++c){if(Ui(b,a.a[c])){return c}}return -1}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&bd(Yc(a,f),b,c,e,g);return g}
function Ki(a,b){var c;c=Ii(a,b,0);if(c==-1){return false}hk(a.a,c);return true}
function Ao(a,b){var c;if(kd(b,51)){c=b;return a.c.d==c.c.d}else{return false}}
function pj(a){if(a.a.c!=a.c){return kj(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function ic(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new oc(a)),67108864,null)}}
function rp(a){var b;return b=S(a.b),Lj(Nj(Oo(a.i),new Mp(b)),new Hj(new Gj))}
function ri(a,b,c){return od(b)?b==null?Zi(a.a,null,c):lj(a.b,b,c):Zi(a.a,b,c)}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function V(a){if(a.b){if(kd(a.b,7)){throw ih(a.b)}else{throw ih(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=hh(a);if(kd(a,4)){J()}else throw ih(a)}}}
function bc(){var a;try{Sb(Qb);J()}finally{a=Qb.d;!a&&((J(),J(),I).d=true);Qb=Qb.d}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ni);Fi(a.b,b)}}}
function Gi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Pb(){var a;this.a=$c(vd,Rp,45,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function zi(a){this.d=a;this.c=new oj(this.d.b);this.a=this.c;this.b=xi(this)}
function Zh(){uc.call(this,"Stream already terminated, can't be modified or used")}
function ph(){qh();var a=oh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function yh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Xh(a,b){var c;if(!a){return}b.j=a;var d=Uh(b);if(!d){th[a]=[b];return}d.nb=b}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Ni);a.c=c.c}b.d=true;Fi(a.c,uj(b))}
function mj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{bj(a.a,b);--a.b}return c}
function Ph(a){var b;b=new Oh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function vk(a){var b;b=xk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function yk(a){var b;return wk($wnd.React.StrictMode,null,null,(b={},b[dq]=uj(a),b))}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nd(a){return a!=null&&(typeof a===Op||typeof a==='function')&&!(a.pb===Bh)}
function sh(a,b){typeof window===Op&&typeof window['$gwt']===Op&&(window['$gwt'][a]=b)}
function Ql(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new dm(a),hq)}}
function wj(a,b){if(0>a||a>b){throw ih(new Jh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Kb(a,b){this.b=uj(a);this.a=b|0|(0==(b&6291456)?Xp:0)|(0!=(b&229376)?0:98304)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:Tp)|(0==(c&6291456)?!a?Wp:Xp:0)|0|0|0)}
function ob(a){var b,c;for(c=new Pi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Si(a){var b,c,d;d=0;for(c=new zi(a.a);c.b;){b=yi(c);d=d+(b?s(b):0);d=d|0}return d}
function mi(a,b){var c,d;for(d=new zi(b.a);d.b;){c=yi(d);if(!vi(a,c)){return false}}return true}
function Ko(a,b,c){var d;d=new Ho(b,c);zo(d,a,new gc(a,d));ri(a.g,_h(d.c.d),d);eb(a.d);return d}
function wk(a,b,c,d){var e;e=xk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=uj(d);return e}
function Mn(a,b){uk(a.a,(Mh(eg),eg.k+(''+(b?_h(b.c.d):null))));uj(b);a.a.props['a']=b;return a.a}
function xi(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new aj(a.d.a);return a.a.Y()}
function hh(a){var b;if(kd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new yc(a);Vc(b)}return b}
function kh(a){var b;b=a.h;if(b==0){return a.l+a.m*Xp}if(b==1048575){return a.l+a.m*Xp-aq}return a}
function mh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=aq;d=1048575}c=qd(e/Xp);b=qd(e-c*Xp);return cd(b,c,d)}
function Wi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ui(a,c._())){return c}}return null}
function bd(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=Bh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function lj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function cc(a,b,c){var d;d=si(a.g,b?_h(b.c.d):null);if(null!=d){mc(b.c,a);c&&!!b&&ic(b.c);eb(a.d)}}
function tp(a,b){var c;c=a.e;if(!(b==c||!!b&&Ao(b,c))){!!c&&mc(c.c,a);a.e=b;!!b&&zo(b,a,new wp(a));eb(a.d)}}
function sp(a){var b;b=S(a.g.a);o(mq,b)||o(nq,b)||o('',b)?ko(a.g,b):np(lo(a.g))?no(a.g):ko(a.g,'')}
function Fp(){Fp=xh;Cp=new Gp('ACTIVE',0);Ep=new Gp('COMPLETED',1);Dp=new Gp('ALL',2)}
function Vn(){this.a=Eh((bp(),ap));this.b=Eh(new mp(this.a));this.c=Eh(new Ap(this.a))}
function yc(a){wc();pc(this);this.e=a;qc(this,a);this.g=a==null?_p:Ah(a);this.a='';this.b=a;this.a=''}
function Oh(){this.g=Lh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function ol(){if(!nl){nl=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(yh(pl.prototype.J,pl,[]))}}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function jm(a,b,c){27==c.which?A((J(),J(),I),new Jm(a,b),hq):13==c.which&&A((J(),J(),I),new Hm(a,b),hq)}
function cb(a,b){var c,d;d=a.c;Ki(d,b);!!a.b&&Tp!=(a.b.c&Up)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((J(),c=Qb,c),a))}
function dd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return cd(c&4194303,d&4194303,e&1048575)}
function jh(a,b){var c;if(md(a)&&md(b)){c=a+b;if(-17592186044416<c&&c<aq){return c}}return kh(dd(md(a)?mh(a):a,md(b)?mh(b):b))}
function _h(a){var b,c;if(a>-129&&a<128){b=a+128;c=(bi(),ai)[b];!c&&(c=ai[b]=new $h(a));return c}return new $h(a)}
function Ah(a){var b;if(Array.isArray(a)&&a.pb===Bh){return Nh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function qk(a){ok();var b,c,d;c=':'+a;d=nk[c];if(d!=null){return qd(d)}d=lk[c];b=d==null?pk(a):qd(d);rk();nk[c]=b;return b}
function Ti(a){var b,c,d;d=1;for(c=new Pi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=Ji(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function lm(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;zm(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Tp)?Jb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function r(a){return od(a)?ne:md(a)?be:ld(a)?_d:jd(a)?a.nb:ad(a)?a.nb:a.nb||Array.isArray(a)&&Yc(Sd,1)||Sd}
function s(a){return od(a)?qk(a):md(a)?qd(a):ld(a)?a?1231:1237:jd(a)?a.q():ad(a)?kk(a):!!a&&!!a.hashCode?a.hashCode():kk(a)}
function q(a,b){return od(a)?o(a,b):md(a)?pd(a)===pd(b):ld(a)?pd(a)===pd(b):jd(a)?a.o(b):ad(a)?o(a,b):!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function ml(){kl();return bd(Yc(ef,1),Rp,6,0,[Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il,jl])}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(Tp==(b&Up)?0:524288)|(0==(b&6291456)?Tp==(b&Up)?Xp:Wp:0)|0|268435456|0)}
function km(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new kp(b,c),hq);tp(a.k,null);Am(a,c)}else{No(a.j,b)}}
function Wh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Mi(a,b){var c,d;d=a.a.length;b.length<d&&(b=ik(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a){var b,c,d;for(c=new Pi(new Oi(new wi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();kd(d,9)&&d.u()||b.ab().v()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function hd(a,b){if(od(a)){return !!gd[b]}else if(a.ob){return !!a.ob[b]}else if(md(a)){return !!fd[b]}else if(ld(a)){return !!ed[b]}return false}
function nc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Vi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Jl(a,b){var c;this.d=uj(b);this.n=uj(a);J();c=++Hl;this.b=new nc(c,null,new Kl(this),false,false);this.a=new vb(null,uj(new Nl(this)),gq)}
function Ho(a,b){var c,d,e,f,g;this.e=uj(a);this.d=b;J();c=++xo;this.c=new nc(c,null,new Io(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Dk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Qb&&!!Qb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function gi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ni(a,b){var c,d,e,f;f=ui(a.a);b.length<f&&(b=ik(new Array(f),b));e=b;d=new zi(a.a);for(c=0;c<f;++c){e[c]=yi(d)}b.length>f&&(b[f]=null);return b}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.v(),null)}finally{bc()}return f}catch(a){a=hh(a);if(kd(a,4)){e=a;throw ih(e)}else throw ih(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.s()}else{ac(b,e);try{g=c.s()}finally{bc()}}return g}catch(a){a=hh(a);if(kd(a,4)){f=a;throw ih(f)}else throw ih(a)}finally{D(b)}}
function Bb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Hb(c);return true}
function rh(b,c,d,e){qh();var f=oh;$moduleName=c;$moduleBase=d;gh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Np(g)()}catch(a){b(c,a)}}else{Np(g)()}}
function W(a,b,c,d){this.c=uj(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);Tp==(d&Up)&&lb(this.f)}
function xk(a,b){var c;c=new $wnd.Object;c.$$typeof=uj(a);c.type=uj(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Um(a,b,c,d){var e;this.d=uj(b);this.e=uj(c);this.f=uj(d);this.n=uj(a);J();e=++Sm;this.b=new nc(e,null,new Vm(this),false,false);this.a=new vb(null,uj(new Ym(this)),gq)}
function $l(a,b){var c,d,e;this.e=uj(b);this.n=uj(a);J();c=++Ul;this.c=new nc(c,null,new _l(this),false,false);this.b=(e=new ib((d=null,d)),e);this.a=new vb(null,uj(new fm(this)),gq)}
function gj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return hj()}}
function Gl(a){var b,c,d;a.c=0;ol();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),zk('span',Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,['todo-count'])),[zk('strong',null,[c]),' '+d+' left']));return b}
function uh(){th={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Rc(c,g)):g[0].qb()}catch(a){a=hh(a);if(kd(a,4)){d=a;Dc();Jc(kd(d,36)?d.H():d)}else throw ih(a)}}return c}
function Tl(a){var b;a.d=0;ol();b=zk(iq,Hk(Kk(Lk(Ok(Mk(Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,['new-todo']))),(fb(a.b),a.f)),yh(An.prototype.kb,An,[a])),yh(Bn.prototype.jb,Bn,[a]))),null);return b}
function xc(a){var b;if(a.c==null){b=pd(a.b)===pd(vc)?null:a.b;a.d=b==null?_p:nd(b)?b==null?null:b.name:od(b)?'String':Nh(r(b));a.a=a.a+': '+(nd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(pd(e)===pd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=hh(a);if(kd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw ih(c)}else throw ih(a)}}
function ek(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Zi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Wi(b,e);if(f){return f.bb(c)}}e[e.length]=new Di(b,c);++a.b;return null}
function pk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ei(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=hh(a);if(kd(a,4)){J()}else throw ih(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=$c(ke,Rp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Ch(){var a;a=new Vn;bn(Wn(new Xn(a)));en(new Ml((new Yn(a)).a.a.I()));Pn($n(new _n(a)));Un(ao(new bo(a)));En(new bm((new Zn(a)).a.b.I()));$wnd.ReactDOM.render(yk([(new Sn).a]),(Gh(),Fh).getElementById('app'),null)}
function xl(a,b,c,d){var e;this.e=uj(b);this.f=uj(c);this.g=uj(d);this.n=uj(a);J();e=++tl;this.c=new nc(e,null,new yl(this),false,false);this.a=new W(new Bl(this),null,null,136478720);this.b=new vb(null,uj(new Cl(this)),gq)}
function ub(a,b,c,d){this.b=new Ni;this.f=new Kb(new yb(this),d&6520832|262144|Tp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Wp)&&D((null,I)))}
function $i(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ui(b,e._())){if(d.length==1){d.length=0;bj(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function wh(a,b,c){var d=th,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=th[b]),zh(h));_.ob=c;!b&&(_.pb=Bh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Vh(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Wh('.',[c,Wh('$',d)]);a.b=Wh('.',[c,Wh('.',d)]);a.i=d[d.length-1]}
function ho(a){var b;if(0==a.length){b=(Gh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Fh.title,b)}else{(Gh(),$wnd.goog.global.window).location.hash=a}}
function oi(a,b){var c,d,e;c=b._();e=b.ab();d=od(c)?c==null?qi(Yi(a.a,null)):kj(a.b,c):qi(Yi(a.a,c));if(!(pd(e)===pd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(od(c)?c==null?!!Yi(a.a,null):jj(a.b,c):!!Yi(a.a,c))){return false}return true}
function zk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;tk(b,yh(Ck.prototype.hb,Ck,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[dq]=c[0],undefined):(d[dq]=c,undefined));return wk(a,e,f,d)}
function po(){var a,b,c;this.d=new Bp(this);this.f=this.e=(c=(Gh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new nc(0,null,new qo(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new wo,new ro(this),new so(this),35651584)}
function up(a){var b,c;this.i=uj(a);this.g=new po;J();this.f=new nc(0,null,new vp(this),false,false);this.d=(c=new ib((b=null,b)),c);this.b=new W(new xp(this),null,null,lq);this.c=new W(new yp(this),null,null,lq);this.a=new vb(uj(new zp(this)),null,681574400);D((null,I))}
function So(){var a;this.g=new Vi;J();this.f=new nc(0,new Uo(this),new To(this),false,false);this.d=(a=new ib(null),a);this.c=new W(new Xo(this),null,null,lq);this.e=new W(new Yo(this),null,null,lq);this.a=new W(new Zo(this),null,null,lq);this.b=new W(new $o(this),null,null,lq)}
function Bm(a,b,c,d){var e,f,g;this.j=uj(b);uj(c);this.k=uj(d);this.n=uj(a);J();e=++pm;this.e=new nc(e,null,new Cm(this),false,false);this.a=(g=new ib((f=null,f)),g);this.c=new W(new Km(this),null,null,136478720);this.b=new vb(null,uj(new Nm(this)),gq);zm(this,this.n.props['a'])}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Pi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=hh(a);if(!kd(a,4))throw ih(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function qc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function fj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}Gi(a.b,new Ab(a));a.b.a=$c(ke,Rp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Rm(a){var b;a.c=0;ol();b=zk('div',null,[zk('div',null,[zk(jq,Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,[jq])),[zk('h1',null,['todos']),(new Cn).a]),S(a.d.c)?null:zk('section',Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,[jq])),[zk(iq,Kk(Nk(Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,['toggle-all'])),(kl(),Rk)),yh(Qn.prototype.jb,Qn,[a])),null),zk('ul',Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,['todo-list'])),Qj(uj(Oj(S(a.f.c).W(),new Rn)),new Bk))]),S(a.d.c)?null:(new _m).a])]);return b}
function kl(){kl=xh;Qk=new ll(eq,0);Rk=new ll('checkbox',1);Sk=new ll('color',2);Tk=new ll('date',3);Uk=new ll('datetime',4);Vk=new ll('email',5);Wk=new ll('file',6);Xk=new ll('hidden',7);Yk=new ll('image',8);Zk=new ll('month',9);$k=new ll(Pp,10);_k=new ll('password',11);al=new ll('radio',12);bl=new ll('range',13);cl=new ll('reset',14);dl=new ll('search',15);el=new ll('submit',16);fl=new ll('tel',17);gl=new ll('text',18);hl=new ll('time',19);il=new ll('url',20);jl=new ll('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Hi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Li(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Hi(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ji(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Ni)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Tp!=(k.b.c&Up)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function sl(a){var b,c;a.d=0;ol();c=(b=S(a.g.b),zk('footer',Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,['footer'])),[(new cn).a,zk('ul',Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,['filters'])),[zk('li',null,[zk('a',Fk(Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,[(Fp(),Dp)==b?fq:null])),'#'),['All'])]),zk('li',null,[zk('a',Fk(Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,[Cp==b?fq:null])),'#active'),['Active'])]),zk('li',null,[zk('a',Fk(Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,[Ep==b?fq:null])),'#completed'),['Completed'])])]),S(a.a)?zk(eq,Gk(Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,['clear-completed'])),yh($m.prototype.lb,$m,[a])),['Clear Completed']):null]));return c}
function om(a){var b,c,d,e;a.f=0;ol();b=a.n.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.n.props['a'],e=(fb(d.a),d.d),zk('li',Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[zk('div',Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,['view'])),[zk(iq,Kk(Ik(Nk(Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,['toggle'])),(kl(),Rk)),e),yh(Gn.prototype.jb,Gn,[d])),null),zk('label',Pk(new $wnd.Object,yh(Hn.prototype.lb,Hn,[a,d])),[(fb(d.b),d.e)]),zk(eq,Gk(Dk(new $wnd.Object,bd(Yc(ne,1),Rp,2,6,['destroy'])),yh(In.prototype.lb,In,[a,d])),null)]),zk(iq,Lk(Kk(Jk(Ok(Dk(Ek(new $wnd.Object,yh(Jn.prototype.w,Jn,[a])),bd(Yc(ne,1),Rp,2,6,['edit'])),(fb(a.a),a.d)),yh(Kn.prototype.ib,Kn,[a,d])),yh(Fn.prototype.jb,Fn,[a])),yh(Ln.prototype.kb,Ln,[a,d])),null)]));return c}
function hj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[cq]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!fj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[cq]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Op='object',Pp='number',Qp={11:1},Rp={3:1},Sp={9:1},Tp=1048576,Up=1835008,Vp={5:1},Wp=2097152,Xp=4194304,Yp={25:1},Zp='__noinit__',$p={3:1,10:1,7:1,4:1},_p='null',aq=17592186044416,bq={42:1},cq='delete',dq='children',eq='button',fq='selected',gq=1411518464,hq=142606336,iq='input',jq='header',kq='hashchange',lq=136314880,mq='active',nq='completed';var _,th,oh,gh=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;uh();wh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=pq;_.r=function(){var a;return Nh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var ed,fd,gd;wh(56,1,{},Oh);_.K=function(a){var b;b=new Oh;b.e=4;a>1?(b.c=Th(this,a-1)):(b.c=this);return b};_.L=function(){Mh(this);return this.b};_.M=function(){return Nh(this)};_.N=function(){Mh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Mh(this),this.k)};_.e=0;_.g=0;var Lh=1;var ke=Qh(1);var ae=Qh(56);wh(86,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var ud=Qh(86);wh(37,1,Qp,G);_.s=function(){return this.a.v(),null};var sd=Qh(37);wh(87,1,{},H);var td=Qh(87);var I;wh(45,1,{45:1},P);_.b=0;_.c=false;_.d=0;var vd=Qh(45);wh(241,1,Sp);_.r=function(){var a;return Nh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var yd=Qh(241);wh(19,241,Sp,W);_.t=function(){R(this)};_.u=oq;_.a=false;_.d=0;_.k=false;var xd=Qh(19);wh(197,1,Qp,X);_.s=function(){return T(this.a)};var wd=Qh(197);wh(17,241,{9:1,17:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Ad=Qh(17);wh(196,1,Vp,jb);_.v=function(){ab(this.a)};var zd=Qh(196);wh(18,241,{9:1,18:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Fd=Qh(18);wh(198,1,Yp,xb);_.v=function(){Q(this.a)};var Bd=Qh(198);wh(199,1,Vp,yb);_.v=function(){mb(this.a)};var Cd=Qh(199);wh(200,1,Vp,zb);_.v=function(){pb(this.a)};var Dd=Qh(200);wh(201,1,{},Ab);_.w=function(a){nb(this.a,a)};var Ed=Qh(201);wh(151,1,{},Db);_.a=0;_.b=0;_.c=0;var Gd=Qh(151);wh(202,1,Sp,Fb);_.t=function(){Eb(this)};_.u=oq;_.a=false;var Hd=Qh(202);wh(69,241,{9:1,69:1},Kb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Jd=Qh(69);wh(62,1,{62:1},Pb);var Id=Qh(62);wh(215,1,{},_b);_.r=function(){var a;return Mh(Kd),Kd.k+'@'+(a=kk(this)>>>0,a.toString(16))};_.a=0;var Qb;var Kd=Qh(215);wh(183,1,{});var Nd=Qh(183);wh(156,1,{},fc);_.w=function(a){dc(this.a,a)};var Ld=Qh(156);wh(157,1,Vp,gc);_.v=function(){ec(this.a,this.b)};var Md=Qh(157);wh(184,183,{});var Od=Qh(184);wh(16,1,Sp,nc);_.t=function(){ic(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Mh(Qd),Qd.k+'@'+(a=kk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Qd=Qh(16);wh(195,1,Vp,oc);_.v=function(){lc(this.a)};var Pd=Qh(195);wh(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=uq;_.C=function(){return Qj(Oj(Ri((this.i==null&&(this.i=$c(pe,Rp,4,0,0,1)),this.i)),new ki),new Uj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){rc(this,tc(this.A(sc(this,this.g))));Vc(this)};_.r=function(){return sc(this,this.F())};_.e=Zp;_.j=true;var pe=Qh(4);wh(10,4,{3:1,10:1,4:1});var de=Qh(10);wh(7,10,$p);var le=Qh(7);wh(57,7,$p);var he=Qh(57);wh(80,57,$p);var Ud=Qh(80);wh(36,80,{36:1,3:1,10:1,7:1,4:1},yc);_.F=function(){xc(this);return this.c};_.H=function(){return pd(this.b)===pd(vc)?null:this.b};var vc;var Rd=Qh(36);var Sd=Qh(0);wh(223,1,{});var Td=Qh(223);var Ac=0,Bc=0,Cc=-1;wh(95,223,{},Qc);var Mc;var Vd=Qh(95);var Tc;wh(234,1,{});var Xd=Qh(234);wh(81,234,{},Xc);var Wd=Qh(81);wh(46,1,{46:1,71:1},Dh);_.I=function(){if(this===this.a){this.a=this.b.I();this.b=null}return this.a};var Yd=Qh(46);var Fh;wh(78,1,{75:1});_.r=oq;var Zd=Qh(78);wh(83,7,$p);var fe=Qh(83);wh(194,83,$p,Jh);var $d=Qh(194);ed={3:1,76:1,29:1};var _d=Qh(76);wh(43,1,{3:1,43:1});var je=Qh(43);fd={3:1,29:1,43:1};var be=Qh(233);wh(31,1,{3:1,29:1,31:1});_.o=wq;_.q=pq;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ce=Qh(31);wh(82,7,$p,Zh);var ee=Qh(82);wh(30,43,{3:1,29:1,30:1,43:1},$h);_.o=function(a){return kd(a,30)&&a.a==this.a};_.q=oq;_.r=function(){return ''+this.a};_.a=0;var ge=Qh(30);var ai;wh(299,1,{});wh(84,57,$p,di);_.A=function(a){return new TypeError(a)};var ie=Qh(84);gd={3:1,75:1,29:1,2:1};var ne=Qh(2);wh(79,78,{75:1},ji);var me=Qh(79);wh(303,1,{});wh(73,1,{},ki);_.S=function(a){return a.e};var oe=Qh(73);wh(59,7,$p,li);var qe=Qh(59);wh(235,1,{41:1});_.Q=tq;_.V=function(){return new Dj(this,0)};_.W=function(){return new Rj(null,this.V())};_.T=function(a){throw ih(new li('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Fj('[',']');for(b=this.R();b.Y();){a=b.Z();Ej(c,a===this?'(this Collection)':a==null?_p:Ah(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var re=Qh(235);wh(239,1,{222:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!kd(a,38)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new zi((new wi(d)).a);c.b;){b=yi(c);if(!oi(this,b)){return false}}return true};_.q=function(){return Si(new wi(this))};_.r=function(){var a,b,c;c=new Fj('{','}');for(b=new zi((new wi(this)).a);b.b;){a=yi(b);Ej(c,pi(this,a._())+'='+pi(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ce=Qh(239);wh(150,239,{222:1});var ue=Qh(150);wh(238,235,{41:1,246:1});_.V=function(){return new Dj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!kd(a,22)){return false}b=a;if(ui(b.a)!=this.U()){return false}return mi(this,b)};_.q=function(){return Si(this)};var De=Qh(238);wh(22,238,{22:1,41:1,246:1},wi);_.R=function(){return new zi(this.a)};_.U=rq;var te=Qh(22);wh(23,1,{},zi);_.X=qq;_.Z=function(){return yi(this)};_.Y=sq;_.b=false;var se=Qh(23);wh(236,235,{41:1,242:1});_.V=function(){return new Dj(this,16)};_.$=function(a,b){throw ih(new li('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!kd(a,14)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Pi(f);for(c=new Pi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(pd(b)===pd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Ti(this)};_.R=function(){return new Ai(this)};var we=Qh(236);wh(94,1,{},Ai);_.X=qq;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Hi(this.b,this.a++)};_.a=0;var ve=Qh(94);wh(61,235,{41:1},Bi);_.R=function(){var a;a=new zi((new wi(this.a)).a);return new Ci(a)};_.U=rq;var ye=Qh(61);wh(147,1,{},Ci);_.X=qq;_.Y=function(){return this.a.b};_.Z=function(){var a;a=yi(this.a);return a.ab()};var xe=Qh(147);wh(145,1,bq);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Ui(this.a,b._())&&Ui(this.b,b.ab())};_._=oq;_.ab=sq;_.q=function(){return tj(this.a)^tj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ze=Qh(145);wh(146,145,bq,Di);var Ae=Qh(146);wh(240,1,bq);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Ui(this.b.value[0],b._())&&Ui(pj(this),b.ab())};_.q=function(){return tj(this.b.value[0])^tj(pj(this))};_.r=function(){return this.b.value[0]+'='+pj(this)};var Be=Qh(240);wh(14,236,{3:1,14:1,41:1,242:1},Ni,Oi);_.$=function(a,b){fk(this.a,a,b)};_.T=function(a){return Fi(this,a)};_.Q=function(a){Gi(this,a)};_.R=function(){return new Pi(this)};_.U=function(){return this.a.length};var Fe=Qh(14);wh(15,1,{},Pi);_.X=qq;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ee=Qh(15);wh(38,150,{3:1,38:1,222:1},Vi);var Ge=Qh(38);wh(65,1,{},_i);_.Q=tq;_.R=function(){return new aj(this)};_.b=0;var Ie=Qh(65);wh(66,1,{},aj);_.X=qq;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var He=Qh(66);var dj;wh(63,1,{},nj);_.Q=tq;_.R=function(){return new oj(this)};_.b=0;_.c=0;var Le=Qh(63);wh(64,1,{},oj);_.X=qq;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new qj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Je=Qh(64);wh(155,240,bq,qj);_._=function(){return this.b.value[0]};_.ab=function(){return pj(this)};_.bb=function(a){return lj(this.a,this.b.value[0],a)};_.c=0;var Ke=Qh(155);wh(174,1,{});_.X=vq;_.cb=function(){return this.d};_.db=uq;_.d=0;_.e=0;var Pe=Qh(174);wh(67,174,{});var Me=Qh(67);wh(148,1,{});_.X=vq;_.cb=sq;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Oe=Qh(148);wh(149,148,{},Bj);_.X=function(a){yj(this,a)};_.eb=function(a){return zj(this,a)};var Ne=Qh(149);wh(21,1,{},Dj);_.cb=oq;_.db=function(){Cj(this);return this.c};_.X=function(a){Cj(this);this.d.X(a)};_.eb=function(a){Cj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Qe=Qh(21);wh(58,1,{},Fj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Re=Qh(58);wh(35,1,{},Gj);_.S=function(a){return a};var Se=Qh(35);wh(39,1,{},Hj);var Te=Qh(39);wh(173,1,{});_.c=false;var bf=Qh(173);wh(27,173,{279:1},Rj);var af=Qh(27);wh(74,1,{},Uj);_.fb=function(a){return $c(ke,Rp,1,a,5,1)};var Ue=Qh(74);wh(176,67,{},Wj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Xj(this,a)));return this.b};_.b=false;var We=Qh(176);wh(179,1,{},Xj);_.w=function(a){Vj(this.a,this.b,a)};var Ve=Qh(179);wh(175,67,{},Zj);_.eb=function(a){return this.b.eb(new $j(this,a))};var Ye=Qh(175);wh(178,1,{},$j);_.w=function(a){Yj(this.a,this.b,a)};var Xe=Qh(178);wh(177,1,{},ak);_.w=function(a){_j(this,a)};var Ze=Qh(177);wh(180,1,{},bk);_.w=function(a){};var $e=Qh(180);wh(181,1,{},dk);_.w=function(a){ck(this,a)};var _e=Qh(181);wh(301,1,{});wh(298,1,{});var jk=0;var lk,mk=0,nk;wh(929,1,{});wh(964,1,{});wh(237,1,{});var cf=Qh(237);wh(203,1,{},Bk);_.fb=function(a){return new Array(a)};var df=Qh(203);wh(281,$wnd.Function,{},Ck);_.hb=function(a){Ak(this.a,this.b,a)};wh(6,31,{3:1,29:1,31:1,6:1},ll);var Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il,jl;var ef=Rh(6,ml);var nl;wh(280,$wnd.Function,{},pl);_.J=function(a){return Eb(nl),nl=null,null};wh(96,237,{});var Sf=Qh(96);wh(97,96,{});_.d=0;var Wf=Qh(97);wh(98,97,Sp,xl);_.t=xq;_.o=wq;_.q=pq;_.u=yq;_.r=function(){var a;return Mh(qf),qf.k+'@'+(a=kk(this)>>>0,a.toString(16))};var tl=0;var qf=Qh(98);wh(100,1,Vp,yl);_.v=function(){ul(this.a)};var ff=Qh(100);wh(99,1,{},Al);var gf=Qh(99);wh(101,1,Qp,Bl);_.s=function(){return vl(this.a)};var hf=Qh(101);wh(102,1,Yp,Cl);_.v=function(){rl(this.a)};var jf=Qh(102);wh(103,1,Qp,Dl);_.s=function(){return sl(this.a)};var kf=Qh(103);wh(105,237,{});var Rf=Qh(105);wh(106,105,{});_.c=0;var Vf=Qh(106);wh(107,106,Sp,Jl);_.t=zq;_.o=wq;_.q=pq;_.u=Aq;_.r=function(){var a;return Mh(pf),pf.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Hl=0;var pf=Qh(107);wh(109,1,Vp,Kl);_.v=Bq;var lf=Qh(109);wh(108,1,{},Ml);var mf=Qh(108);wh(110,1,Yp,Nl);_.v=function(){Fl(this.a)};var nf=Qh(110);wh(111,1,Qp,Ol);_.s=function(){return Gl(this.a)};var of=Qh(111);wh(135,237,{});_.f='';var cg=Qh(135);wh(136,135,{});_.d=0;var Yf=Qh(136);wh(137,136,Sp,$l);_.t=xq;_.o=wq;_.q=pq;_.u=yq;_.r=function(){var a;return Mh(xf),xf.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Ul=0;var xf=Qh(137);wh(139,1,Vp,_l);_.v=function(){Vl(this.a)};var rf=Qh(139);wh(138,1,{},bm);var sf=Qh(138);wh(141,1,Qp,cm);_.s=function(){return Tl(this.a)};var tf=Qh(141);wh(142,1,Vp,dm);_.v=function(){Pl(this.a)};var uf=Qh(142);wh(143,1,Vp,em);_.v=function(){Xl(this.a,this.b)};var vf=Qh(143);wh(140,1,Yp,fm);_.v=function(){rl(this.a)};var wf=Qh(140);wh(113,237,{});_.i=false;var eg=Qh(113);wh(114,113,{});_.f=0;var $f=Qh(114);wh(115,114,Sp,Bm);_.t=function(){ic(this.e)};_.o=wq;_.q=pq;_.u=function(){return this.e.i<0};_.r=function(){var a;return Mh(Jf),Jf.k+'@'+(a=kk(this)>>>0,a.toString(16))};var pm=0;var Jf=Qh(115);wh(117,1,Vp,Cm);_.v=function(){qm(this.a)};var yf=Qh(117);wh(116,1,{},Em);var zf=Qh(116);wh(120,1,Qp,Fm);_.s=function(){return om(this.a)};var Af=Qh(120);wh(44,1,Vp,Gm);_.v=function(){Am(this.a,lo(this.b))};var Bf=Qh(44);wh(60,1,Vp,Hm);_.v=function(){km(this.a,this.b)};var Cf=Qh(60);wh(121,1,Vp,Im);_.v=function(){sm(this.a,this.b)};var Df=Qh(121);wh(122,1,Vp,Jm);_.v=function(){tm(this.a,this.b)};var Ef=Qh(122);wh(118,1,Qp,Km);_.s=function(){return um(this.a)};var Ff=Qh(118);wh(123,1,Vp,Lm);_.v=function(){gm(this.a,this.b)};var Gf=Qh(123);wh(124,1,Vp,Mm);_.v=function(){lm(this.a)};var Hf=Qh(124);wh(119,1,Yp,Nm);_.v=function(){nm(this.a)};var If=Qh(119);wh(126,237,{});var hg=Qh(126);wh(127,126,{});_.c=0;var ag=Qh(127);wh(128,127,Sp,Um);_.t=zq;_.o=wq;_.q=pq;_.u=Aq;_.r=function(){var a;return Mh(Of),Of.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Sm=0;var Of=Qh(128);wh(130,1,Vp,Vm);_.v=Bq;var Kf=Qh(130);wh(129,1,{},Xm);var Lf=Qh(129);wh(131,1,Yp,Ym);_.v=function(){Fl(this.a)};var Mf=Qh(131);wh(132,1,Qp,Zm);_.s=function(){return Rm(this.a)};var Nf=Qh(132);wh(262,$wnd.Function,{},$m);_.lb=function(a){ep(this.a.f)};wh(205,1,{},_m);var Pf=Qh(205);var an;wh(217,1,{},cn);var Qf=Qh(217);var dn;wh(263,$wnd.Function,{},fn);_.mb=function(a){return new jn(a)};var gn;wh(104,$wnd.React.Component,{},jn);vh(th[1],_);_.componentWillUnmount=function(){ql(this.a)};_.render=function(){return wl(this.a)};_.shouldComponentUpdate=Cq;var Tf=Qh(104);wh(264,$wnd.Function,{},kn);_.mb=function(a){return new nn(a)};var ln;wh(112,$wnd.React.Component,{},nn);vh(th[1],_);_.componentWillUnmount=function(){El(this.a)};_.render=function(){return Il(this.a)};_.shouldComponentUpdate=Dq;var Uf=Qh(112);wh(278,$wnd.Function,{},on);_.mb=function(a){return new rn(a)};var pn;wh(144,$wnd.React.Component,{},rn);vh(th[1],_);_.componentWillUnmount=function(){ql(this.a)};_.render=function(){return Yl(this.a)};_.shouldComponentUpdate=Cq;var Xf=Qh(144);wh(265,$wnd.Function,{},sn);_.mb=function(a){return new vn(a)};var tn;wh(125,$wnd.React.Component,{},vn);vh(th[1],_);_.componentDidUpdate=function(a){xm(this.a)};_.componentWillUnmount=function(){mm(this.a)};_.render=function(){return ym(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Zf=Qh(125);wh(275,$wnd.Function,{},wn);_.mb=function(a){return new zn(a)};var xn;wh(133,$wnd.React.Component,{},zn);vh(th[1],_);_.componentWillUnmount=function(){El(this.a)};_.render=function(){return Tm(this.a)};_.shouldComponentUpdate=Dq;var _f=Qh(133);wh(276,$wnd.Function,{},An);_.kb=function(a){Ql(this.a,a)};wh(277,$wnd.Function,{},Bn);_.jb=function(a){Wl(this.a,a)};wh(204,1,{},Cn);var bg=Qh(204);var Dn;wh(272,$wnd.Function,{},Fn);_.jb=function(a){rm(this.a,a)};wh(266,$wnd.Function,{},Gn);_.jb=function(a){Go(this.a)};wh(268,$wnd.Function,{},Hn);_.lb=function(a){vm(this.a,this.b)};wh(269,$wnd.Function,{},In);_.lb=function(a){hm(this.a,this.b)};wh(270,$wnd.Function,{},Jn);_.w=function(a){im(this.a,a)};wh(271,$wnd.Function,{},Kn);_.ib=function(a){wm(this.a,this.b)};wh(273,$wnd.Function,{},Ln);_.kb=function(a){jm(this.a,this.b,a)};wh(216,1,{},Nn);var dg=Qh(216);var On;wh(274,$wnd.Function,{},Qn);_.jb=function(a){Om(this.a,a)};wh(134,1,{},Rn);_.S=function(a){return Mn(new Nn,a)};var fg=Qh(134);wh(72,1,{},Sn);var gg=Qh(72);var Tn;wh(88,1,{},Vn);var ng=Qh(88);wh(89,1,{},Xn);var ig=Qh(89);wh(93,1,{},Yn);var jg=Qh(93);wh(92,1,{},Zn);var kg=Qh(92);wh(90,1,{},_n);var lg=Qh(90);wh(91,1,{},bo);var mg=Qh(91);wh(207,1,{});var Wg=Qh(207);wh(208,207,Sp,po);_.t=xq;_.o=wq;_.q=pq;_.u=yq;_.r=function(){var a;return Mh(vg),vg.k+'@'+(a=kk(this)>>>0,a.toString(16))};var vg=Qh(208);wh(209,1,Vp,qo);_.v=function(){jo(this.a)};var og=Qh(209);wh(211,1,Yp,ro);_.v=function(){eo(this.a)};var pg=Qh(211);wh(212,1,Yp,so);_.v=function(){fo(this.a)};var qg=Qh(212);wh(213,1,Vp,to);_.v=function(){co(this.a,this.b)};var rg=Qh(213);wh(214,1,Vp,uo);_.v=function(){mo(this.a)};var sg=Qh(214);wh(68,1,Vp,vo);_.v=function(){io(this.a)};var tg=Qh(68);wh(210,1,Qp,wo);_.s=function(){var a;return a=(Gh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var ug=Qh(210);wh(50,1,{50:1});_.d=false;var dh=Qh(50);wh(51,50,{9:1,282:1,51:1,50:1},Ho);_.t=xq;_.o=function(a){return Ao(this,a)};_.q=function(){return this.c.d};_.u=yq;_.r=function(){var a;return Mh(Ng),Ng.k+'@'+(a=this.c.d>>>0,a.toString(16))};var xo=0;var Ng=Qh(51);wh(218,1,Vp,Io);_.v=function(){yo(this.a)};var wg=Qh(218);wh(219,1,Vp,Jo);_.v=function(){Do(this.a)};var xg=Qh(219);wh(49,184,{49:1});var Zg=Qh(49);wh(185,49,{9:1,49:1},So);_.t=Eq;_.o=wq;_.q=pq;_.u=Fq;_.r=function(){var a;return Mh(Hg),Hg.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Hg=Qh(185);wh(187,1,Vp,To);_.v=function(){Lo(this.a)};var yg=Qh(187);wh(186,1,Vp,Uo);_.v=function(){Po(this.a)};var zg=Qh(186);wh(192,1,Vp,Vo);_.v=function(){cc(this.a,this.b,true)};var Ag=Qh(192);wh(193,1,Qp,Wo);_.s=function(){return Ko(this.a,this.c,this.b)};_.b=false;var Bg=Qh(193);wh(188,1,Qp,Xo);_.s=function(){return Qo(this.a)};var Cg=Qh(188);wh(189,1,Qp,Yo);_.s=function(){return _h(nh(Mj(Oo(this.a))))};var Dg=Qh(189);wh(190,1,Qp,Zo);_.s=function(){return _h(nh(Mj(Nj(Oo(this.a),new Ip))))};var Eg=Qh(190);wh(191,1,Qp,$o);_.s=function(){return Ro(this.a)};var Fg=Qh(191);wh(152,1,{71:1},_o);_.I=function(){return new So};var Gg=Qh(152);var ap;wh(47,1,{47:1});var bh=Qh(47);wh(163,47,{9:1,47:1},ip);_.t=function(){ic(this.a)};_.o=wq;_.q=pq;_.u=function(){return this.a.i<0};_.r=function(){var a;return Mh(Mg),Mg.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Mg=Qh(163);wh(164,1,Vp,jp);_.v=function(){fp(this.a,this.b)};_.b=false;var Ig=Qh(164);wh(165,1,Vp,kp);_.v=function(){oo(this.b,this.a)};var Jg=Qh(165);wh(166,1,Vp,lp);_.v=function(){gp(this.a)};var Kg=Qh(166);wh(153,1,{71:1},mp);_.I=function(){return new ip(this.a.I())};var Lg=Qh(153);wh(48,1,{48:1});var fh=Qh(48);wh(167,48,{9:1,48:1},up);_.t=Eq;_.o=wq;_.q=pq;_.u=Fq;_.r=function(){var a;return Mh(Ug),Ug.k+'@'+(a=kk(this)>>>0,a.toString(16))};var Ug=Qh(167);wh(168,1,Vp,vp);_.v=function(){pp(this.a)};var Og=Qh(168);wh(172,1,Vp,wp);_.v=function(){tp(this.a,null)};var Pg=Qh(172);wh(169,1,Qp,xp);_.s=function(){var a;return a=lo(this.a.g),o(mq,a)?(Fp(),Cp):o(nq,a)?(Fp(),Ep):(Fp(),Dp)};var Qg=Qh(169);wh(170,1,Qp,yp);_.s=function(){return rp(this.a)};var Rg=Qh(170);wh(171,1,Yp,zp);_.v=function(){sp(this.a)};var Sg=Qh(171);wh(154,1,{71:1},Ap);_.I=function(){return new up(this.a.I())};var Tg=Qh(154);wh(206,1,{},Bp);_.handleEvent=function(a){go(this.a,a)};var Vg=Qh(206);wh(32,31,{3:1,29:1,31:1,32:1},Gp);var Cp,Dp,Ep;var Xg=Rh(32,Hp);wh(158,1,{},Ip);_.gb=function(a){return !Co(a)};var Yg=Qh(158);wh(160,1,{},Jp);_.gb=function(a){return Co(a)};var $g=Qh(160);wh(161,1,{},Kp);_.w=function(a){No(this.a,a)};var _g=Qh(161);wh(159,1,{},Lp);_.w=function(a){dp(this.a,a)};_.a=false;var ah=Qh(159);wh(162,1,{},Mp);_.gb=function(a){return op(this.a,a)};var eh=Qh(162);var rd=Sh('D');var Np=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=rh;ph(Ch);sh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();