function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='07D354EF770A1A172D7D343B6E3C3DBA',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '07D354EF770A1A172D7D343B6E3C3DBA';function o(){}
function uh(){}
function qh(){}
function Bb(){}
function Qc(){}
function Xc(){}
function Lj(){}
function Mj(){}
function vk(){}
function Jm(){}
function Pm(){}
function Vm(){}
function _m(){}
function fn(){}
function qo(){}
function Bo(){}
function Vo(){}
function gp(){}
function hp(){}
function Xp(){}
function Vc(a){Uc()}
function Nm(a){Mm=a}
function Tm(a){Sm=a}
function Zm(a){Ym=a}
function dn(a){cn=a}
function kn(a){jn=a}
function Fh(){Fh=qh}
function Ii(){zi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function fb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function ub(a){this.a=a}
function cc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function gc(a){this.a=a}
function kc(a){this.a=a}
function Wh(a){this.a=a}
function fi(a){this.a=a}
function ri(a){this.a=a}
function wi(a){this.a=a}
function xi(a){this.a=a}
function vi(a){this.b=a}
function Ki(a){this.c=a}
function Jj(a){this.a=a}
function Oj(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function ul(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Il(a){this.a=a}
function Jl(a){this.a=a}
function Ll(a){this.a=a}
function dm(a){this.a=a}
function em(a){this.a=a}
function fm(a){this.a=a}
function km(a){this.a=a}
function nm(a){this.a=a}
function tm(a){this.a=a}
function um(a){this.a=a}
function vm(a){this.a=a}
function ym(a){this.a=a}
function Bm(a){this.a=a}
function Em(a){this.a=a}
function mn(a){this.a=a}
function nn(a){this.a=a}
function pn(){this.a={}}
function Am(){this.a={}}
function Dm(){this.a={}}
function qn(a){this.a=a}
function sn(a){this.a=a}
function tn(a){this.a=a}
function wn(a){this.a=a}
function Dn(a){this.a=a}
function Gn(a){this.a=a}
function Jn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function ho(a){this.a=a}
function jo(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function Ao(a){this.a=a}
function Do(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function Ro(a){this.a=a}
function ip(a){this.a=a}
function jp(a){this.a=a}
function kp(a){this.a=a}
function Cn(){this.a={}}
function In(){this.a={}}
function Kj(a,b){a.a=b}
function Fm(a,b){a.d=b}
function Gm(a,b){a.e=b}
function Hm(a,b){a.f=b}
function Im(a,b){a.g=b}
function En(a,b){a.k=b}
function Fn(a,b){a.n=b}
function dk(a,b){ck(a,b)}
function so(a,b){Un(b,a)}
function C(a,b){yb(a.b,b)}
function $(a){Kb((J(),a))}
function Tp(a){kj(this,a)}
function Wp(a){$h(this,a)}
function aq(){qk(this.a)}
function fq(){sk(this.a)}
function Ui(){this.a=bj()}
function gj(){this.a=bj()}
function F(){this.b=new zb}
function J(){J=qh;I=new F}
function pc(){this.b=new Oi}
function mb(a,b){a.b=nj(b)}
function Ol(a,b){ao(a.k,b)}
function oc(a,b){ni(a.b,b)}
function ro(a,b){_n(a.b,b)}
function Nj(a,b){Dj(a.a,b)}
function w(a){--a.e;D(a)}
function yo(a){this.b=nj(a)}
function ah(a){return a.e}
function dq(){return this.e}
function Qp(){return this.a}
function Vp(){return this.b}
function Zp(){return this.c}
function bi(a,b){return a===b}
function Pl(a,b){return a.g=b}
function $p(){return this.d<0}
function eq(){return this.c<0}
function gq(){return this.f<0}
function Sp(){return Wj(this)}
function Zi(){Zi=qh;Yi=_i()}
function wc(){wc=qh;vc=new o}
function Nc(){Nc=qh;Mc=new Qc}
function xh(){xh=qh;wh=new o}
function po(){po=qh;oo=new qo}
function Uo(){Uo=qh;To=new Vo}
function Uh(a){uc.call(this,a)}
function gi(a){uc.call(this,a)}
function Om(a){hk.call(this,a)}
function Um(a){hk.call(this,a)}
function $m(a){hk.call(this,a)}
function en(a){hk.call(this,a)}
function ln(a){hk.call(this,a)}
function ab(a){Lb((J(),a))}
function db(a){Mb((J(),a))}
function ol(a){nc(a.b);gb(a.a)}
function X(a){J();Lb(a);a.e=-2}
function Ih(a){Hh(a);return a.k}
function Ci(a,b){return a.a[b]}
function Yc(a,b){return Oh(a,b)}
function Rp(a){return this===a}
function Up(){return pi(this.a)}
function bq(){return uk(this.a)}
function _p(){return J(),J(),I}
function Dc(){Dc=qh;!!(Uc(),Tc)}
function _h(){qc(this);this.I()}
function jh(){hh==null&&(hh=[])}
function Sj(a,b){a.splice(b,1)}
function Cj(a,b){a.U(b);return a}
function Wb(a){bb(a.b);return a.g}
function Vb(a){bb(a.a);return a.e}
function Qn(a){bb(a.b);return a.i}
function Rn(a){bb(a.a);return a.g}
function Go(a){bb(a.d);return a.f}
function xk(a,b){a.ref=b;return a}
function dc(a,b){this.a=a;this.b=b}
function lc(a,b){this.a=a;this.b=b}
function yh(a){this.a=wh;this.b=a}
function Th(a,b){this.a=a;this.b=b}
function yi(a,b){this.a=a;this.b=b}
function oj(a,b){while(a.fb(b));}
function Dj(a,b){Kj(a,Cj(a.a,b))}
function mc(a,b,c){mi(a.b,b,c)}
function Qj(a,b,c){a.splice(b,0,c)}
function dj(a,b){return a.a.get(b)}
function pi(a){return a.a.b+a.b.b}
function bd(a){return new Array(a)}
function bj(){Zi();return new Yi}
function Eb(a){Fb(a);!a.d&&Ib(a)}
function Yb(a){Ub(a,(bb(a.b),a.g))}
function Sl(a,b){Lo(a.n,b);am(a,b)}
function fl(a,b){Th.call(this,a,b)}
function Hl(a,b){this.a=a;this.b=b}
function Gj(a,b){this.a=a;this.b=b}
function lk(a,b){this.a=a;this.b=b}
function mk(a,b){this.a=a;this.b=b}
function mm(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function im(a,b){this.a=a;this.b=b}
function jm(a,b){this.a=a;this.b=b}
function lm(a,b){this.a=a;this.b=b}
function un(a,b){this.a=a;this.b=b}
function vn(a,b){this.a=a;this.b=b}
function xn(a,b){this.a=a;this.b=b}
function yn(a,b){this.a=a;this.b=b}
function io(a,b){this.a=a;this.b=b}
function Co(a,b){this.a=a;this.b=b}
function zo(a,b){this.b=a;this.a=b}
function So(a,b){this.b=a;this.a=b}
function ep(a,b){Th.call(this,a,b)}
function Hj(a,b){a.D(Bn(zn(b.e),b))}
function Tn(a){Un(a,(bb(a.a),!a.g))}
function Gb(a){return !a.d?a:Gb(a.d)}
function li(a){return !a?null:a.bb()}
function qd(a){return a==null?null:a}
function zn(a){return An(new Cn,a)}
function mj(a){return a!=null?r(a):0}
function nd(a){return typeof a===np}
function Yp(){return T(this.e.b).a>0}
function eb(a){this.c=new Ii;this.b=a}
function oi(a){a.a=new Ui;a.b=new gj}
function L(a){a.b=0;a.d=0;a.c=false}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function Kc(a){$wnd.clearTimeout(a)}
function yk(a,b){a.href=b;return a}
function Ik(a,b){a.value=b;return a}
function Dk(a,b){a.onBlur=b;return a}
function zk(a,b){a.onClick=b;return a}
function Bk(a,b){a.checked=b;return a}
function di(a,b){a.a+=''+b;return a}
function Rl(a,b){am(a,b);Lo(a.n,null)}
function A(a,b,c){t(a,new G(b),c,null)}
function Rj(a,b){Pj(b,0,a,0,b.length)}
function jc(a,b){hc(a,b,false);ab(a.d)}
function il(a){nc(a.c);gb(a.b);S(a.a)}
function Cl(a){nc(a.c);gb(a.a);W(a.b)}
function lb(a){J();kb(a);nb(a,2,true)}
function zi(a){a.a=$c(ke,qp,1,0,5,1)}
function Q(){this.a=$c(ke,qp,1,100,5,1)}
function bb(a){var b;Hb((J(),b=Cb,b),a)}
function V(a){return !(!!a&&1==(a.c&7))}
function Wj(a){return a.$H||(a.$H=++Vj)}
function ai(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function ck(a,b){for(var c in a){b(c)}}
function Ek(a,b){a.onChange=b;return a}
function Fk(a,b){a.onKeyDown=b;return a}
function Ak(a){a.autoFocus=true;return a}
function Hh(a){if(a.k!=null){return}Qh(a)}
function rc(a,b){a.e=b;b!=null&&Uj(b,Bp,a)}
function kj(a,b){while(a.Z()){Nj(b,a.$())}}
function Bj(a,b){wj.call(this,a);this.a=b}
function uc(a){this.f=a;qc(this);this.I()}
function Oi(){this.a=new Ui;this.b=new gj}
function $j(){$j=qh;Xj=new o;Zj=new o}
function Ch(){Ch=qh;Bh=$wnd.window.document}
function Zh(){Zh=qh;Yh=$c(ge,qp,32,256,0,1)}
function Wi(a,b){var c;c=a[Gp];c.call(a,b)}
function u(a,b){return new qb(nj(a),null,b)}
function md(a){return typeof a==='boolean'}
function pd(a){return typeof a==='string'}
function fo(a){return Xh(T(a.e).a-T(a.a).a)}
function zm(a){return ik((Lm(),Km),a.a,null)}
function Cm(a){return ik((Rm(),Qm),a.a,null)}
function on(a){return ik((Xm(),Wm),a.a,null)}
function Hn(a){return ik((hn(),gn),a.a,null)}
function Ec(a,b,c){return a.apply(b,c);var d}
function ic(a,b){oc(b.F(),a);ld(b,11)&&b.A()}
function Sn(a){nc(a.c);W(a.d);W(a.b);W(a.a)}
function Lh(a){var b;b=Kh(a);Sh(a,b);return b}
function Nh(){var a;a=Kh(null);a.e=2;return a}
function Ck(a,b){a.defaultValue=b;return a}
function Jk(a,b){a.onDoubleClick=b;return a}
function Ai(a,b){a.a[a.a.length]=b;return true}
function An(a,b){nj(b);a.a['key']=b;return a}
function qc(a){a.g&&a.e!==Ap&&a.I();return a}
function Ah(a){if(!a){throw ah(new _h)}return a}
function jj(a,b,c){this.a=a;this.b=b;this.c=c}
function wl(a,b,c){this.a=a;this.b=b;this.c=c}
function pm(a,b,c){this.a=a;this.b=b;this.c=c}
function xm(a,b,c){this.a=a;this.b=b;this.c=c}
function ko(a,b){this.a=a;this.c=b;this.b=false}
function Yo(a){this.b=a;this.a=new ul(this.b.a)}
function Zo(a){this.b=a;this.a=new Ll(this.b.b)}
function Ab(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function qj(a){if(!a.d){a.d=a.b.T();a.c=a.b.V()}}
function ti(a){var b;b=a.a.$();a.b=si(a);return b}
function Bl(a,b){var c;c=b.target;Dl(a,c.value)}
function Rb(a,b){a.i&&b.preventDefault();ac(a)}
function jb(a,b){Z(b,a);b.c.a.length>0||(b.a=4)}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ei(a,b){var c;c=a.a[b];Sj(a.a,b);return c}
function Ej(a,b,c){if(a.a.gb(c)){a.b=true;b.D(c)}}
function Uj(b,c,d){try{b[c]=d}catch(a){}}
function Uc(){Uc=qh;var a;!Wc();a=new Xc;Tc=a}
function zj(a){vj(a);return new Bj(a,new Ij(a.a))}
function cj(a,b){return !(a.a.get(b)===undefined)}
function hl(a){return Fh(),T(a.e.b).a>0?true:false}
function eo(a){return Fh(),0==T(a.e).a?true:false}
function Eo(a){return bi(Pp,a)||bi(Mp,a)||bi('',a)}
function ad(a){return Array.isArray(a)&&a.Ab===uh}
function kd(a){return !Array.isArray(a)&&a.Ab===uh}
function P(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function qm(a,b){var c;c=b.target;xo(a.e,c.checked)}
function Dl(a,b){var c;c=a.f;if(b!=c){a.f=b;ab(a.b)}}
function Gi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function tl(a){var b;b=new pl;Fm(b,a.a.K());return b}
function Kl(a){var b;b=new El;Gm(b,a.a.K());return b}
function nj(a){if(a==null){throw ah(new _h)}return a}
function qi(a,b){if(b){return ji(a.a,b)}return false}
function yj(a,b){vj(a);return new Bj(a,new Fj(b,a.a))}
function bm(a,b){var c;c=a.i;if(b!=c){a.i=b;ab(a.a)}}
function Un(a,b){var c;c=a.g;if(b!=c){a.g=b;ab(a.a)}}
function Wl(a){nc(a.e);gb(a.b);S(a.d);W(a.c);W(a.a)}
function Ho(a){gb(a.e);gb(a.a);S(a.b);S(a.c);W(a.d)}
function uj(a){if(!a.b){vj(a);a.c=true}else{uj(a.b)}}
function wj(a){if(!a){this.b=null;new Ii}else{this.b=a}}
function Ij(a){pj.call(this,a.eb(),a.db()&-6);this.a=a}
function pj(a,b){this.e=a;this.d=(b&64)!=0?b|op:b}
function rj(a,b){this.b=a;this.a=(b&4096)==0?b|64|op:b}
function Hk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Ni(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function tk(a){rk(a);return ld(a,11)&&a.B()?null:a.qb()}
function Xl(a,b,c,d){return Fh(),Ul(a,b,c,d)?true:false}
function ek(a,b){null!=b&&a.lb(b,a.q.props,true);a.ib()}
function $b(a,b){var c;c=a.e;if(b!=c){a.e=nj(b);ab(a.a)}}
function _b(a,b){var c;c=a.g;if(b!=c){a.g=nj(b);ab(a.b)}}
function Vn(a,b){var c;c=a.i;if(b!=c){a.i=nj(b);ab(a.b)}}
function Mh(a,b){var c;c=Kh(a);Sh(a,c);c.e=b?8:0;return c}
function cb(a){var b;J();!!Cb&&!!Cb.e&&Hb((b=Cb,b),a)}
function xb(a){while(true){if(!vb(a)&&!wb(a)){break}}}
function bk(){if(Yj==256){Xj=Zj;Zj=new o;Yj=0}++Yj}
function gh(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function Ph(a){if(a.R()){return null}var b=a.j;return mh[b]}
function qk(a){if(!a.o){a.o=true;a.p||a.q.forceUpdate()}}
function Vh(a){this.f=!a?null:sc(a,a.H());qc(this);this.I()}
function Nb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function gm(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function kk(a,b,c){a[c]===undefined&&(a[c]=b[c],undefined)}
function Bn(a,b){a.a['a']=b;return ik((bn(),an),a.a,null)}
function sc(a,b){var c;c=Ih(a.yb);return b==null?c:c+': '+b}
function Nl(a,b){var c;if(T(a.d)){c=b.target;bm(a,c.value)}}
function $h(a,b){var c,d;for(d=a.T();d.Z();){c=d.$();b.D(c)}}
function ki(a,b){return b===a?'(this Map)':b==null?Dp:th(b)}
function fp(){dp();return cd(Yc(Qg,1),qp,37,0,[ap,cp,bp])}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Ob(a,b){Cb=new Nb(Cb,b);a.d=false;Db(Cb);return Cb}
function yb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],nj(b))}
function vo(a,b){var c;Aj(bo(a.b),(c=new Ii,c)).S(new jp(b))}
function Oh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.M(b))}
function hb(a){var b;b=(J(),J(),I);yb(b.b,a);0!=(a.c&wp)&&D(b)}
function Db(a){if(a.e){2==(a.e.c&7)||nb(a.e,4,true);kb(a.e)}}
function yl(a,b){if(13==b.keyCode){b.preventDefault();zl(a)}}
function Qi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ql(a,b,c){27==c.which?Zl(a,b):13==c.which&&_l(a,b)}
function oh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function bn(){bn=qh;var a;an=(a=rh(_m.prototype.mb,_m,[]),a)}
function hn(){hn=qh;var a;gn=(a=rh(fn.prototype.mb,fn,[]),a)}
function Lm(){Lm=qh;var a;Km=(a=rh(Jm.prototype.mb,Jm,[]),a)}
function Rm(){Rm=qh;var a;Qm=(a=rh(Pm.prototype.mb,Pm,[]),a)}
function Xm(){Xm=qh;var a;Wm=(a=rh(Vm.prototype.mb,Vm,[]),a)}
function sh(a){function b(){}
;b.prototype=a||{};return new b}
function zh(a){xh();Ah(a);if(ld(a,46)){return a}return new yh(a)}
function Qb(a,b){a.j=b;bi(b,(bb(a.a),a.e))&&_b(a,b);Sb(b);ac(a)}
function Jo(a){var b;b=(bb(a.d),a.f);!!b&&!!b&&b.f<0&&Lo(a,null)}
function Ri(a,b){var c;return Pi(b,Qi(a,b==null?0:(c=r(b),c|0)))}
function bo(a){bb(a.d);return new Bj(null,new rj(new wi(a.g),0))}
function Ji(a){zi(this);Rj(this.a,ii(a,$c(ke,qp,1,pi(a.a),5,1)))}
function Xo(a){this.b=a;this.a=new wl(this.b.a,this.b.b,this.b.c)}
function $o(a){this.b=a;this.a=new pm(this.b.a,this.b.b,this.b.c)}
function _o(a){this.b=a;this.a=new xm(this.b.a,this.b.b,this.b.c)}
function Vi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function cq(){return Go(this.n)==(cb(this.c),this.q.props['a'])}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&op)?op:8192)|0|0,b)}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&op)?op:8192)|0|0,b)}
function Dh(a,b,c,d){a.addEventListener(b,c,(Fh(),d?true:false))}
function Eh(a,b,c,d){a.removeEventListener(b,c,(Fh(),d?true:false))}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function Lo(a,b){var c;c=a.f;if(!(b==c||!!b&&Pn(b,c))){a.f=b;ab(a.d)}}
function Y(a,b){var c,d;Ai(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function N(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function sj(a,b){!a.a?(a.a=new fi(a.d)):di(a.a,a.b);di(a.a,b);return a}
function Aj(a,b){var c;uj(a);c=new Lj;c.a=b;a.a.Y(new Oj(c));return c.a}
function xj(a){var b;uj(a);b=0;while(a.a.fb(new Mj)){b=bh(b,1)}return b}
function Gk(a){a.placeholder='What needs to be done?';return a}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function On(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Yn(a)),vp,null)}}
function uo(a){var b;Aj(yj(bo(a.b),new hp),(b=new Ii,b)).S(new ip(a.b))}
function ni(a,b){return pd(b)?b==null?Ti(a.a,null):fj(a.b,b):Ti(a.a,b)}
function Fo(a,b){return (dp(),bp)==a||(ap==a?(bb(b.a),!b.g):(bb(b.a),b.g))}
function Yl(a){return Fh(),Go(a.n)==(cb(a.c),a.q.props['a'])?true:false}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function xl(a){var b;b=ci((bb(a.b),a.f));if(b.length>0){ro(a.e,b);Dl(a,'')}}
function om(a){var b;b=new cm;En(b,a.a.K());a.b.K();Fn(b,a.c.K());return b}
function Pn(a,b){var c;if(ld(b,53)){c=b;return a.e==c.e}else{return false}}
function uk(a){var b;a.o=false;if(a.ob()){return null}else{b=a.kb();return b}}
function ij(a){if(a.a.c!=a.c){return dj(a.a,a.b.value[0])}return a.b.value[1]}
function hj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function ui(a){this.d=a;this.c=new hj(this.d.b);this.a=this.c;this.b=si(this)}
function tj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Fj(a,b){pj.call(this,b.eb(),b.db()&-16449);this.a=a;this.c=b}
function jk(a,b,c){!bi(c,'key')&&!bi(c,'ref')&&(a[c]=b[c],undefined)}
function Di(a,b,c){for(;c<a.a.length;++c){if(Ni(b,a.a[c])){return c}}return -1}
function Fi(a,b){var c;c=Di(a,b,0);if(c==-1){return false}Sj(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function vl(a){var b;b=new jl;Gm(b,a.a.K());Hm(b,a.b.K());Im(b,a.c.K());return b}
function wm(a){var b;b=new sm;Fm(b,a.a.K());Gm(b,a.b.K());Hm(b,a.c.K());return b}
function fk(a,b){var c;c=null!=b&&a.lb(a.q.props,b,false);c||(a.r=false);return c}
function gk(a,b){var c;if(b){c=a.r;a.r=false;return !c}else{a.r=true;return true}}
function Bi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.D(c)}}
function Io(a){var b,c;return b=T(a.b),Aj(yj(bo(a.j),new kp(b)),(c=new Ii,c))}
function mi(a,b,c){return pd(b)?b==null?Si(a.a,null,c):ej(a.b,b,c):Si(a.a,b,c)}
function Tj(a,b){return Zc(b)!=10&&cd(q(b),b.zb,b.__elementTypeId$,Zc(b),a),a}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===mp||typeof a==='function')&&!(a.Ab===uh)}
function Xb(a){Eh((Ch(),$wnd.window.window),yp,a.f,false);nc(a.c);W(a.b);W(a.a)}
function co(a){$h(new wi(a.g),new kc(a));oi(a.g);S(a.c);S(a.e);S(a.a);S(a.b);W(a.d)}
function S(a){if(!a.a){a.a=true;a.g=null;a.b=null;W(a.d);2==(a.e.c&7)||gb(a.e)}}
function W(a){if(-2!=a.e){t((J(),J(),I),new G(new fb(a)),0,null);!!a.b&&gb(a.b)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{xb(a.b)}finally{a.c=false}}}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Hb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;Ai((!a.b&&(a.b=new Ii),a.b),b)}}}
function Sh(a,b){var c;if(!a){return}b.j=a;var d=Ph(b);if(!d){mh[a]=[b];return}d.yb=b}
function _g(a){var b;if(ld(a,4)){return a}b=a&&a[Bp];if(!b){b=new yc(a);Vc(b)}return b}
function vb(a){var b;if(0==P(a.c)){return false}else{b=O(a.c);!!b&&b.A();return true}}
function rh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Kh(a){var b;b=new Jh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function fj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Wi(a.a,b);--a.b}return c}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);N(a,nj(b))}
function Jb(a,b){var c;if(!a.c){c=Gb(a);!c.c&&(c.c=new Ii);a.c=c.c}b.d=true;Ai(a.c,nj(b))}
function kb(a){var b,c;for(c=new Ki(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Li(a){var b,c,d;d=0;for(c=new ui(a.a);c.b;){b=ti(c);d=d+(b?r(b):0);d=d|0}return d}
function hi(a,b){var c,d;for(d=new ui(b.a);d.b;){c=ti(d);if(!qi(a,c)){return false}}return true}
function $n(a,b,c){var d;d=new Xn(b,c);mc(d.c,a,new lc(a,d));mi(a.g,Xh(d.e),d);ab(a.d);return d}
function hc(a,b,c){var d;d=ni(a.g,b?Xh(b.e):null);if(null!=d){oc(b.c,a);c&&!!b&&On(b);ab(a.d)}}
function sk(a){var b;b=(++a.pb().e,new Bb);try{a.p=true;ld(a,11)&&a.A()}finally{Ab(b)}}
function Pb(){var a;try{Eb(Cb);J()}finally{a=Cb.d;!a&&((J(),J(),I).d=true);Cb=Cb.d}}
function ih(){jh();var a=hh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function dp(){dp=qh;ap=new ep('ACTIVE',0);cp=new ep('COMPLETED',1);bp=new ep('ALL',2)}
function pl(){++ok;this.b=new pc;this.a=new qb(null,nj((J(),new ql(this))),Jp);D((null,I))}
function sm(){++ok;this.b=new pc;this.a=new qb(null,nj((J(),new tm(this))),Jp);D((null,I))}
function hk(a){$wnd.React.Component.call(this,a);this.a=this.nb();this.a.q=nj(this);this.a.jb()}
function si(a){if(a.a.Z()){return true}if(a.a!=a.c){return false}a.a=new Vi(a.d.a);return a.a.Z()}
function dh(a){var b;b=a.h;if(b==0){return a.l+a.m*wp}if(b==1048575){return a.l+a.m*wp-Ep}return a}
function fh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Ep;d=1048575}c=rd(e/wp);b=rd(e-c*wp);return dd(b,c,d)}
function Pi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Ni(a,c.ab())){return c}}return null}
function Ul(a,b,c,d){var e,f;e=false;f=gk(a,d);if(!(b['a']===c['a'])){f&&ab(a.c);e=true}return e||a.o}
function cd(a,b,c,d,e){e.yb=a;e.zb=b;e.Ab=uh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function ej(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Z(a,b){var c,d;d=a.c;Fi(d,b);d.a.length==0&&!!a.b&&sp!=(a.b.c&tp)&&(a.d||Jb((J(),c=Cb,c),a))}
function Ko(a){var b;b=Vb(a.i);bi(Pp,b)||bi(Mp,b)||bi('',b)?Ub(a.i,b):Eo(Wb(a.i))?Zb(a.i):Ub(a.i,'')}
function Tl(a,b){var c;c=(bb(a.a),a.i);if(null!=c&&c.length!=0){wo(b,c);Lo(a.n,null);bm(a,c)}else{ao(a.k,b)}}
function gb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new tb(a)),vp,null);!!a.a&&S(a.a);a.c=a.c&-8|1}}
function rk(a){if(!pk){pk=(++a.pb().e,new Bb);$wnd.Promise.resolve(null).then(rh(vk.prototype.L,vk,[]))}}
function T(a){bb(a.d);ob(a.e)&&ib(a.e);if(a.b){if(ld(a.b,5)){throw ah(a.b)}else{throw ah(a.b)}}return a.g}
function q(a){return pd(a)?ne:nd(a)?ce:md(a)?ae:kd(a)?a.yb:ad(a)?a.yb:a.yb||Array.isArray(a)&&Yc(Ud,1)||Ud}
function lh(a,b){typeof window===mp&&typeof window['$gwt']===mp&&(window['$gwt'][a]=b)}
function Jh(){this.g=Gh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function U(a,b){this.c=nj(a);this.f=null;this.g=null;this.e=new rb(this,b);this.d=new eb(this.e);sp==(b&tp)&&hb(this.e)}
function yc(a){wc();qc(this);this.e=a;a!=null&&Uj(a,Bp,this);this.f=a==null?Dp:th(a);this.a='';this.b=a;this.a=''}
function Wo(){this.a=zh((po(),po(),oo));this.b=zh(new Do(this.a));this.d=zh((Uo(),Uo(),To));this.c=zh(new So(this.a,this.d))}
function pb(a,b,c,d){this.b=new Ii;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&hb(this)}
function El(){var a;++ok;this.c=new pc;this.b=(a=new eb((J(),null)),a);this.a=new qb(null,nj(new Il(this)),Jp);D((null,I))}
function Xh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Zh(),Yh)[b];!c&&(c=Yh[b]=new Wh(a));return c}return new Wh(a)}
function th(a){var b;if(Array.isArray(a)&&a.Ab===uh){return Ih(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function ak(a){$j();var b,c,d;c=':'+a;d=Zj[c];if(d!=null){return rd(d)}d=Xj[c];b=d==null?_j(a):rd(d);bk();Zj[c]=b;return b}
function Mi(a){var b,c,d;d=1;for(c=new Ki(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function nc(a){var b,c;if(!a.a){for(c=new Ki(new Ji(new wi(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.C()}a.a=true}}
function Tb(a){var b,c;c=(b=(Ch(),$wnd.window.window).location.hash,null==b?'':b.substr(1));$b(a,c);bi(a.j,c)&&_b(a,c)}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function bh(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<Ep){return c}}return dh(ed(nd(a)?fh(a):a,nd(b)?fh(b):b))}
function vj(a){if(a.b){vj(a.b)}else if(a.c){throw ah(new Uh("Stream already terminated, can't be modified or used"))}}
function gl(){el();return cd(Yc(bf,1),qp,10,0,[Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl])}
function r(a){return pd(a)?ak(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.u():ad(a)?Wj(a):!!a&&!!a.hashCode?a.hashCode():Wj(a)}
function p(a,b){return pd(a)?bi(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.s(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function jl(){++ok;this.c=new pc;this.a=new U((J(),new kl(this)),136486912);this.b=new qb(null,nj(new ml(this)),Jp);D((null,I))}
function zb(){this.c=new Q;this.d=$c(vd,qp,20,5,0,1);this.d[0]=new Q;this.d[1]=new Q;this.d[2]=new Q;this.d[3]=new Q;this.d[4]=new Q}
function Ml(a){var b;b=T(a.d);if(!a.j&&b){a.j=true;am(a,(cb(a.c),a.q.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function Rh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Hi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Tj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function wk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function nk(a,b,c,d,e){var f;f=new $wnd.Object;f.$$typeof=$wnd.React.Element;f.type=nj(a);f.key=b;f.ref=c;f.props=nj(d);f._owner=e;return f}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.zb){return !!a.zb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function O(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function qb(a,b,c){pb.call(this,null,a,b,c|(!a?262144:sp)|(a?op:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:wp)|(0!=(c&229376)?0:98304)|0|0|0)}
function Mb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&nb(b,5,true)}}}
function Lb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Ki(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&nb(b,6,true)}}}
function Kb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?nb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function ci(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ib(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=Ei(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&nb(c.b,3,true);++b}}}return b}
function Xn(a,b){var c,d,e;this.i=nj(a);this.g=b;this.e=Nn++;this.d=(d=new eb((J(),null)),d);this.c=new pc;this.b=(e=new eb(null),e);this.a=(c=new eb(null),c)}
function Zb(b){var c;try{A((J(),J(),I),new ec(b),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){c=a;throw ah(c)}else if(ld(a,4)){c=a;throw ah(new Vh(c))}else throw ah(a)}}
function ac(b){var c;try{A((J(),J(),I),new fc(b),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){c=a;throw ah(c)}else if(ld(a,4)){c=a;throw ah(new Vh(c))}else throw ah(a)}}
function zl(b){var c;try{A((J(),J(),I),new Gl(b),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){c=a;throw ah(c)}else if(ld(a,4)){c=a;throw ah(new Vh(c))}else throw ah(a)}}
function Wn(b){var c;try{A((J(),J(),I),new Zn(b),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){c=a;throw ah(c)}else if(ld(a,4)){c=a;throw ah(new Vh(c))}else throw ah(a)}}
function to(b){var c;try{A((J(),J(),I),new Ao(b),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){c=a;throw ah(c)}else if(ld(a,4)){c=a;throw ah(new Vh(c))}else throw ah(a)}}
function ao(b,c){var d;try{A((J(),J(),I),new io(b,c),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function wo(b,c){var d;try{A((J(),J(),I),new zo(b,c),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function xo(b,c){var d;try{A((J(),J(),I),new Co(b,c),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function Al(b,c){var d;try{A((J(),J(),I),new Hl(b,c),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function Vl(b,c){var d;try{A((J(),J(),I),new mm(b,c),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function Zl(b,c){var d;try{A((J(),J(),I),new lm(b,c),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function $l(b,c){var d;try{A((J(),J(),I),new jm(b,c),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function _l(b,c){var d;try{A((J(),J(),I),new im(b,c),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function am(b,c){var d;try{A((J(),J(),I),new hm(b,c),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function Ub(b,c){var d;try{A((J(),J(),I),new dc(b,c),75505664)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function _n(b,c){var d;try{return t((J(),J(),I),new ko(b,c),zp,null)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){d=a;throw ah(d)}else if(ld(a,4)){d=a;throw ah(new Vh(d))}else throw ah(a)}}
function kh(b,c,d,e){jh();var f=hh;$moduleName=c;$moduleBase=d;$g=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{lp(g)()}catch(a){b(c,a)}}else{lp(g)()}}
function rb(a,b){pb.call(this,a,new sb(a),null,b|(sp==(b&tp)?0:524288)|(0!=(b&6291456)?0:sp==(b&tp)?wp:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function vh(){var a;a=new Wo;Nm(new Bm(a));Tm(new Em(a));dn(new Dn(a));kn(new Jn(a));Zm(new qn(a));$wnd.ReactDOM.render(Hn(new In),(Ch(),Bh).getElementById('todoapp'),null)}
function _i(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return aj()}}
function go(){var a;this.g=new Oi;this.d=(a=new eb((J(),null)),a);this.c=new U(new jo(this),Op);this.e=new U(new lo(this),Op);this.a=new U(new mo(this),Op);this.b=new U(new no(this),Op)}
function cm(){var a,b;++ok;this.e=new pc;this.c=(b=new eb((J(),null)),b);this.a=(a=new eb(null),a);this.d=new U(new km(this),136486912);this.b=new qb(null,nj(new nm(this)),Jp);D((null,I))}
function Mo(a,b){var c;this.j=nj(a);this.i=nj(b);this.d=(c=new eb((J(),null)),c);this.b=new U(new Oo(this),Op);this.c=new U(new Po(this),Op);this.e=u(new Qo(this),413155328);this.a=u(new Ro(this),681590784);D((null,I))}
function ii(a,b){var c,d,e,f,g;g=pi(a.a);b.length<g&&(b=Tj(new Array(g),b));e=(f=new ui((new ri(a.a)).a),new xi(f));for(d=0;d<g;++d){b[d]=(c=ti(e.a),c.bb())}b.length>g&&(b[g]=null);return b}
function nh(){mh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Bb()&&(c=Rc(c,g)):g[0].Bb()}catch(a){a=_g(a);if(ld(a,4)){d=a;Dc();Jc(ld(d,40)?d.J():d)}else throw ah(a)}}return c}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?Dp:od(b)?b==null?null:b.name:pd(b)?'String':Ih(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.g;try{d=b.c.w();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;$(b.d)}}catch(a){a=_g(a);if(ld(a,12)){c=a;if(!b.b){b.g=null;b.b=c;$(b.d)}throw ah(c)}else throw ah(a)}}
function Pj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Si(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Pi(b,e);if(f){return f.cb(c)}}e[e.length]=new yi(b,c);++a.b;return null}
function _j(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ai(a,c++)}b=b|0;return b}
function M(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=$c(ke,qp,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=op==(d&op)?c.w():c.w()}else{Ob(b,e);try{g=op==(d&op)?c.w():c.w()}finally{Pb()}}return g}catch(a){a=_g(a);if(ld(a,4)){f=a;throw ah(f)}else throw ah(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=op==(d&op)?(c.a.C(),null):(c.a.C(),null)}else{Ob(b,e);try{g=op==(d&op)?(c.a.C(),null):(c.a.C(),null)}finally{Pb()}}return g}catch(a){a=_g(a);if(ld(a,4)){f=a;throw ah(f)}else throw ah(a)}finally{D(b)}}
function Sb(a){var b;if(0==a.length){b=(Ch(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',Bh.title,b)}else{(Ch(),$wnd.window.window).location.hash=a}}
function ib(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.C()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=_g(a);if(ld(a,4)){J()}else throw ah(a)}}}
function Ti(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ni(b,e.ab())){if(d.length==1){d.length=0;Wi(a.a,g)}else{d.splice(h,1)}--a.b;return e.bb()}}return null}
function ph(a,b,c){var d=mh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=mh[b]),sh(h));_.zb=c;!b&&(_.Ab=uh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.yb=f)}
function Qh(a){if(a.Q()){var b=a.c;b.R()?(a.k='['+b.j):!b.Q()?(a.k='[L'+b.O()+';'):(a.k='['+b.O());a.b=b.N()+'[]';a.i=b.P()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Rh('.',[c,Rh('$',d)]);a.b=Rh('.',[c,Rh('.',d)]);a.i=d[d.length-1]}
function bc(){var a,b,c;this.f=new gc(this);this.c=new pc;this.b=(c=new eb((J(),null)),c);this.a=(b=new eb(null),b);Dh((Ch(),$wnd.window.window),yp,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function ji(a,b){var c,d,e;c=b.ab();e=b.bb();d=pd(c)?c==null?li(Ri(a.a,null)):dj(a.b,c):li(Ri(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Ri(a.a,null):cj(a.b,c):!!Ri(a.a,c))){return false}return true}
function ob(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ki(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=_g(a);if(!ld(a,4))throw ah(a)}if(6==(b.c&7)){return true}}}}}kb(b);return false}
function $i(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function nb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){db(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}Bi(a.b,new ub(a));a.b.a=$c(ke,qp,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function wb(a){var b,c,d,e,f,g,h,i;d=P(a.d[0]);c=P(a.d[1]);g=P(a.d[2]);e=P(a.d[3]);f=P(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;L(a.d[0]);L(a.d[1]);L(a.d[2]);L(a.d[3]);L(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=O(b);h.c&=-513;ib(h);return true}
function ik(a,b,c){var d,e,f,g,h;d={};f=null;g=null;if(null!=b){f='key' in b?''+b['key']:null;g='ref' in b?b['ref']:null;dk(b,rh(lk.prototype.hb,lk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));h=a;e=h['defaultProps'];null!=e&&dk(e,rh(mk.prototype.hb,mk,[d,e]));return nk(a,f,g,d,$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current)}
function el(){el=qh;Kk=new fl(Hp,0);Lk=new fl('checkbox',1);Mk=new fl('color',2);Nk=new fl('date',3);Ok=new fl('datetime',4);Pk=new fl('email',5);Qk=new fl('file',6);Rk=new fl('hidden',7);Sk=new fl('image',8);Tk=new fl('month',9);Uk=new fl(np,10);Vk=new fl('password',11);Wk=new fl('radio',12);Xk=new fl('range',13);Yk=new fl('reset',14);Zk=new fl('search',15);$k=new fl('submit',16);_k=new fl('tel',17);al=new fl('text',18);bl=new fl('time',19);cl=new fl('url',20);dl=new fl('week',21)}
function Fb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ci(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Gi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Z(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&nb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ci(a.b,g);if(-1==k.e){k.e=0;Y(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ei(a.b,g)}e&&mb(a.e,a.b)}else{e&&mb(a.e,new Ii)}if(V(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&sp!=(b.e.c&tp)&&Jb(a,k)}}
function aj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Gp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!$i()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Gp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var mp='object',np='number',op=16384,pp={15:1},qp={3:1,6:1},rp={11:1},sp=1048576,tp=1835008,up={8:1},vp=67108864,wp=4194304,xp={30:1},yp='hashchange',zp=142614528,Ap='__noinit__',Bp='__java$exception',Cp={3:1,12:1,5:1,4:1},Dp='null',Ep=17592186044416,Fp={44:1},Gp='delete',Hp='button',Ip='selected',Jp=1478635520,Kp={11:1,39:1},Lp='input',Mp='completed',Np='header',Op=136421376,Pp='active';var _,mh,hh,$g=-1;nh();ph(1,null,{},o);_.s=Rp;_.t=function(){return this.yb};_.u=Sp;_.v=function(){var a;return Ih(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.s(a)};_.hashCode=function(){return this.u()};_.toString=function(){return this.v()};var fd,gd,hd;ph(55,1,{},Jh);_.M=function(a){var b;b=new Jh;b.e=4;a>1?(b.c=Oh(this,a-1)):(b.c=this);return b};_.N=function(){Hh(this);return this.b};_.O=function(){return Ih(this)};_.P=function(){Hh(this);return this.i};_.Q=function(){return (this.e&4)!=0};_.R=function(){return (this.e&1)!=0};_.v=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Hh(this),this.k)};_.e=0;_.g=0;var Gh=1;var ke=Lh(1);var be=Lh(55);ph(89,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var ud=Lh(89);ph(16,1,pp,G);_.w=function(){return this.a.C(),null};var sd=Lh(16);ph(90,1,{},H);var td=Lh(90);var I;ph(20,1,{20:1},Q);_.b=0;_.c=false;_.d=0;var vd=Lh(20);ph(228,1,rp);_.v=function(){var a;return Ih(this.yb)+'@'+(a=r(this)>>>0,a.toString(16))};var xd=Lh(228);ph(21,228,rp,U);_.A=function(){S(this)};_.B=Qp;_.a=false;var wd=Lh(21);ph(17,228,{11:1,17:1},eb);_.A=function(){W(this)};_.B=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=Lh(17);ph(151,1,up,fb);_.C=function(){X(this.a)};var yd=Lh(151);ph(19,228,{11:1,19:1},qb,rb);_.A=function(){gb(this)};_.B=function(){return 1==(this.c&7)};_.c=0;var Dd=Lh(19);ph(152,1,xp,sb);_.C=function(){R(this.a)};var Ad=Lh(152);ph(153,1,up,tb);_.C=function(){lb(this.a)};var Bd=Lh(153);ph(154,1,{},ub);_.D=function(a){jb(this.a,a)};var Cd=Lh(154);ph(115,1,{},zb);_.a=0;_.b=100;_.e=0;var Ed=Lh(115);ph(71,1,rp,Bb);_.A=function(){Ab(this)};_.B=Qp;_.a=false;var Fd=Lh(71);ph(160,1,{},Nb);_.v=function(){var a;return Hh(Gd),Gd.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.a=0;var Cb;var Gd=Lh(160);ph(51,1,{51:1});_.e='';_.g='';_.i=true;_.j='';var Nd=Lh(51);ph(155,51,{11:1,51:1,39:1},bc);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new cc(this)),vp,null)}};_.s=Rp;_.F=Zp;_.u=Sp;_.B=$p;_.v=function(){var a;return Hh(Ld),Ld.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.d=0;var Ld=Lh(155);ph(156,1,up,cc);_.C=function(){Xb(this.a)};var Hd=Lh(156);ph(157,1,up,dc);_.C=function(){Qb(this.a,this.b)};var Id=Lh(157);ph(158,1,up,ec);_.C=function(){Yb(this.a)};var Jd=Lh(158);ph(159,1,up,fc);_.C=function(){Tb(this.a)};var Kd=Lh(159);ph(138,1,{},gc);_.handleEvent=function(a){Rb(this.a,a)};var Md=Lh(138);ph(117,1,{});var Qd=Lh(117);ph(127,1,{},kc);_.D=function(a){ic(this.a,a)};var Od=Lh(127);ph(128,1,up,lc);_.C=function(){jc(this.a,this.b)};var Pd=Lh(128);ph(118,117,{});var Rd=Lh(118);ph(27,1,rp,pc);_.A=function(){nc(this)};_.B=Qp;_.a=false;var Sd=Lh(27);ph(4,1,{3:1,4:1});_.G=function(a){return new Error(a)};_.H=function(){return this.f};_.I=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Ih(this.yb),c==null?a:a+': '+c);rc(this,tc(this.G(b)));Vc(this)};_.v=function(){return sc(this,this.H())};_.e=Ap;_.g=true;var oe=Lh(4);ph(12,4,{3:1,12:1,4:1});var ee=Lh(12);ph(5,12,Cp);var le=Lh(5);ph(56,5,Cp);var he=Lh(56);ph(86,56,Cp);var Wd=Lh(86);ph(40,86,{40:1,3:1,12:1,5:1,4:1},yc);_.H=function(){xc(this);return this.c};_.J=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Td=Lh(40);var Ud=Lh(0);ph(211,1,{});var Vd=Lh(211);var Ac=0,Bc=0,Cc=-1;ph(98,211,{},Qc);var Mc;var Xd=Lh(98);var Tc;ph(222,1,{});var Zd=Lh(222);ph(87,222,{},Xc);var Yd=Lh(87);ph(46,1,{46:1},yh);_.K=function(){var a,b;b=this.a;if(qd(b)===qd(wh)){b=this.a;if(qd(b)===qd(wh)){b=this.b.K();a=this.a;if(qd(a)!==qd(wh)&&qd(a)!==qd(b)){throw ah(new Uh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}this.a=b;this.b=null}}return b};var wh;var $d=Lh(46);var Bh;ph(84,1,{81:1});_.v=Qp;var _d=Lh(84);fd={3:1,82:1,31:1};var ae=Lh(82);ph(45,1,{3:1,45:1});var je=Lh(45);gd={3:1,31:1,45:1};var ce=Lh(221);ph(35,1,{3:1,31:1,35:1});_.s=Rp;_.u=Sp;_.v=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=Lh(35);ph(9,5,Cp,Uh,Vh);var fe=Lh(9);ph(32,45,{3:1,31:1,32:1,45:1},Wh);_.s=function(a){return ld(a,32)&&a.a==this.a};_.u=Qp;_.v=function(){return ''+this.a};_.a=0;var ge=Lh(32);var Yh;ph(282,1,{});ph(64,56,Cp,_h);_.G=function(a){return new TypeError(a)};var ie=Lh(64);hd={3:1,81:1,31:1,2:1};var ne=Lh(2);ph(85,84,{81:1},fi);var me=Lh(85);ph(286,1,{});ph(63,5,Cp,gi);var pe=Lh(63);ph(223,1,{43:1});_.S=Wp;_.W=function(){return new rj(this,0)};_.X=function(){return new Bj(null,this.W())};_.U=function(a){throw ah(new gi('Add not supported on this collection'))};_.v=function(){var a,b,c;c=new tj('[',']');for(b=this.T();b.Z();){a=b.$();sj(c,a===this?'(this Collection)':a==null?Dp:th(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var qe=Lh(223);ph(226,1,{210:1});_.s=function(a){var b,c,d;if(a===this){return true}if(!ld(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ui((new ri(d)).a);c.b;){b=ti(c);if(!ji(this,b)){return false}}return true};_.u=function(){return Li(new ri(this))};_.v=function(){var a,b,c;c=new tj('{','}');for(b=new ui((new ri(this)).a);b.b;){a=ti(b);sj(c,ki(this,a.ab())+'='+ki(this,a.bb()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Be=Lh(226);ph(114,226,{210:1});var te=Lh(114);ph(225,223,{43:1,234:1});_.W=function(){return new rj(this,1)};_.s=function(a){var b;if(a===this){return true}if(!ld(a,25)){return false}b=a;if(pi(b.a)!=this.V()){return false}return hi(this,b)};_.u=function(){return Li(this)};var Ce=Lh(225);ph(25,225,{25:1,43:1,234:1},ri);_.T=function(){return new ui(this.a)};_.V=Up;var se=Lh(25);ph(26,1,{},ui);_.Y=Tp;_.$=function(){return ti(this)};_.Z=Vp;_.b=false;var re=Lh(26);ph(224,223,{43:1,231:1});_.W=function(){return new rj(this,16)};_._=function(a,b){throw ah(new gi('Add not supported on this list'))};_.U=function(a){this._(this.V(),a);return true};_.s=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.V()!=f.a.length){return false}e=new Ki(f);for(c=new Ki(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.u=function(){return Mi(this)};_.T=function(){return new vi(this)};var ve=Lh(224);ph(96,1,{},vi);_.Y=Tp;_.Z=function(){return this.a<this.b.a.length};_.$=function(){return Ci(this.b,this.a++)};_.a=0;var ue=Lh(96);ph(47,223,{43:1},wi);_.T=function(){var a;return a=new ui((new ri(this.a)).a),new xi(a)};_.V=Up;var xe=Lh(47);ph(66,1,{},xi);_.Y=Tp;_.Z=function(){return this.a.b};_.$=function(){var a;return a=ti(this.a),a.bb()};var we=Lh(66);ph(103,1,Fp);_.s=function(a){var b;if(!ld(a,44)){return false}b=a;return Ni(this.a,b.ab())&&Ni(this.b,b.bb())};_.ab=Qp;_.bb=Vp;_.u=function(){return mj(this.a)^mj(this.b)};_.cb=function(a){var b;b=this.b;this.b=a;return b};_.v=function(){return this.a+'='+this.b};var ye=Lh(103);ph(104,103,Fp,yi);var ze=Lh(104);ph(227,1,Fp);_.s=function(a){var b;if(!ld(a,44)){return false}b=a;return Ni(this.b.value[0],b.ab())&&Ni(ij(this),b.bb())};_.u=function(){return mj(this.b.value[0])^mj(ij(this))};_.v=function(){return this.b.value[0]+'='+ij(this)};var Ae=Lh(227);ph(14,224,{3:1,14:1,43:1,231:1},Ii,Ji);_._=function(a,b){Qj(this.a,a,b)};_.U=function(a){return Ai(this,a)};_.S=function(a){Bi(this,a)};_.T=function(){return new Ki(this)};_.V=function(){return this.a.length};var Ee=Lh(14);ph(18,1,{},Ki);_.Y=Tp;_.Z=function(){return this.a<this.c.a.length};_.$=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var De=Lh(18);ph(41,114,{3:1,41:1,210:1},Oi);var Fe=Lh(41);ph(69,1,{},Ui);_.S=Wp;_.T=function(){return new Vi(this)};_.b=0;var He=Lh(69);ph(70,1,{},Vi);_.Y=Tp;_.$=function(){return this.d=this.a[this.c++],this.d};_.Z=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ge=Lh(70);var Yi;ph(67,1,{},gj);_.S=Wp;_.T=function(){return new hj(this)};_.b=0;_.c=0;var Ke=Lh(67);ph(68,1,{},hj);_.Y=Tp;_.$=function(){return this.c=this.a,this.a=this.b.next(),new jj(this.d,this.c,this.d.c)};_.Z=function(){return !this.a.done};var Ie=Lh(68);ph(116,227,Fp,jj);_.ab=function(){return this.b.value[0]};_.bb=function(){return ij(this)};_.cb=function(a){return ej(this.a,this.b.value[0],a)};_.c=0;var Je=Lh(116);ph(97,1,{});_.Y=function(a){oj(this,a)};_.db=function(){return this.d};_.eb=dq;_.d=0;_.e=0;var Me=Lh(97);ph(65,97,{});var Le=Lh(65);ph(24,1,{},rj);_.db=Qp;_.eb=function(){qj(this);return this.c};_.Y=function(a){qj(this);this.d.Y(a)};_.fb=function(a){qj(this);if(this.d.Z()){a.D(this.d.$());return true}return false};_.a=0;_.c=0;var Ne=Lh(24);ph(57,1,{},tj);_.v=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Oe=Lh(57);var Xe=Nh();ph(105,1,{});_.c=false;var Ye=Lh(105);ph(34,105,{},Bj);var We=Lh(34);ph(107,65,{},Fj);_.fb=function(a){this.b=false;while(!this.b&&this.c.fb(new Gj(this,a)));return this.b};_.b=false;var Qe=Lh(107);ph(110,1,{},Gj);_.D=function(a){Ej(this.a,this.b,a)};var Pe=Lh(110);ph(106,65,{},Ij);_.fb=function(a){return this.a.fb(new Jj(a))};var Se=Lh(106);ph(109,1,{},Jj);_.D=function(a){Hj(this.a,a)};var Re=Lh(109);ph(108,1,{},Lj);_.D=function(a){Kj(this,a)};var Te=Lh(108);ph(111,1,{},Mj);_.D=function(a){};var Ue=Lh(111);ph(112,1,{},Oj);_.D=function(a){Nj(this,a)};var Ve=Lh(112);ph(284,1,{});ph(230,1,{});var Ze=Lh(230);ph(281,1,{});var Vj=0;var Xj,Yj=0,Zj;ph(742,1,{});ph(757,1,{});ph(229,1,{});_.ib=Xp;_.jb=Xp;_.lb=function(a,b,c){return false};_.r=false;var $e=Lh(229);ph(33,$wnd.React.Component,{});oh(mh[1],_);_.render=function(){return tk(this.a)};var _e=Lh(33);ph(266,$wnd.Function,{},lk);_.hb=function(a){jk(this.a,this.b,a)};ph(267,$wnd.Function,{},mk);_.hb=function(a){kk(this.a,this.b,a)};ph(36,229,{});_.ob=function(){return false};_.qb=function(){return uk(this)};_.o=false;_.p=false;var ok=1,pk;var af=Lh(36);ph(249,$wnd.Function,{},vk);_.L=function(a){return Ab(pk),pk=null,null};ph(10,35,{3:1,31:1,35:1,10:1},fl);var Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl;var bf=Mh(10,gl);ph(161,36,{});_.vb=Yp;_.kb=function(){var a;a=T(this.g.b);return ik('footer',wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,['footer'])),[Cm(new Dm),ik('ul',wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,['filters'])),[ik('li',null,[ik('a',yk(wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,[(dp(),bp)==a?Ip:null])),'#'),['All'])]),ik('li',null,[ik('a',yk(wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,[ap==a?Ip:null])),'#active'),['Active'])]),ik('li',null,[ik('a',yk(wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,[cp==a?Ip:null])),'#completed'),['Completed'])])]),this.vb()?ik(Hp,zk(wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,['clear-completed'])),rh(ym.prototype.ub,ym,[this])),['Clear Completed']):null])};var Sf=Lh(161);ph(162,161,{});_.vb=Yp;var Wf=Lh(162);ph(163,162,Kp,jl);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new nl(this)),vp,null)}};_.s=Rp;_.pb=_p;_.F=Zp;_.vb=function(){return T(this.a)};_.u=Sp;_.B=$p;_.v=function(){var a;return Hh(nf),nf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((J(),J(),I),this.b,new ll(this))}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.d=0;var nf=Lh(163);ph(164,1,pp,kl);_.w=function(){return hl(this.a)};var cf=Lh(164);ph(167,1,pp,ll);_.w=bq;var df=Lh(167);ph(165,1,xp,ml);_.C=aq;var ef=Lh(165);ph(166,1,up,nl);_.C=function(){il(this.a)};var ff=Lh(166);ph(168,36,{});_.kb=function(){var a,b;b=T(this.d.e).a;a='item'+(b==1?'':'s');return ik('span',wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,['todo-count'])),[ik('strong',null,[b]),' '+a+' left'])};var Rf=Lh(168);ph(169,168,{});var Vf=Lh(169);ph(170,169,Kp,pl);_.A=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new rl(this)),vp,null)}};_.s=Rp;_.pb=_p;_.F=Vp;_.u=Sp;_.B=eq;_.v=function(){var a;return Hh(lf),lf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((J(),J(),I),this.a,new sl(this))}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.c=0;var lf=Lh(170);ph(171,1,xp,ql);_.C=aq;var gf=Lh(171);ph(172,1,up,rl);_.C=function(){ol(this.a)};var hf=Lh(172);ph(173,1,pp,sl);_.w=bq;var jf=Lh(173);ph(147,1,{},ul);_.K=function(){return tl(this)};var kf=Lh(147);ph(146,1,{},wl);_.K=function(){return vl(this)};var mf=Lh(146);ph(194,36,{});_.kb=function(){return ik(Lp,Ak(Ek(Fk(Ik(Gk(wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,['new-todo']))),(bb(this.b),this.f)),rh(mn.prototype.tb,mn,[this])),rh(nn.prototype.sb,nn,[this]))),null)};_.f='';var dg=Lh(194);ph(195,194,{});var Yf=Lh(195);ph(196,195,Kp,El);_.A=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Jl(this)),vp,null)}};_.s=Rp;_.pb=_p;_.F=Zp;_.u=Sp;_.B=$p;_.v=function(){var a;return Hh(uf),uf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((J(),J(),I),this.a,new Fl(this))}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.d=0;var uf=Lh(196);ph(199,1,pp,Fl);_.w=bq;var of=Lh(199);ph(200,1,up,Gl);_.C=function(){xl(this.a)};var pf=Lh(200);ph(201,1,up,Hl);_.C=function(){Bl(this.a,this.b)};var qf=Lh(201);ph(197,1,xp,Il);_.C=aq;var rf=Lh(197);ph(198,1,up,Jl);_.C=function(){Cl(this.a)};var sf=Lh(198);ph(150,1,{},Ll);_.K=function(){return Kl(this)};var tf=Lh(150);ph(174,36,{});_.ib=function(){Ml(this)};_.xb=cq;_.jb=function(){am(this,this.wb())};_.kb=function(){var a,b;b=this.wb();a=(bb(b.a),b.g);return ik('li',wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,[a?Mp:null,this.xb()?'editing':null])),[ik('div',wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,['view'])),[ik(Lp,Ek(Bk(Hk(wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,['toggle'])),(el(),Lk)),a),rh(tn.prototype.sb,tn,[b])),null),ik('label',Jk(new $wnd.Object,rh(un.prototype.ub,un,[this,b])),[(bb(b.b),b.i)]),ik(Hp,zk(wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,['destroy'])),rh(vn.prototype.ub,vn,[this,b])),null)]),ik(Lp,Fk(Ek(Dk(Ck(wk(xk(new $wnd.Object,rh(wn.prototype.D,wn,[this])),cd(Yc(ne,1),qp,2,6,['edit'])),(bb(this.a),this.i)),rh(xn.prototype.rb,xn,[this,b])),rh(sn.prototype.sb,sn,[this])),rh(yn.prototype.tb,yn,[this,b])),null)])};_.j=false;var gg=Lh(174);ph(175,174,{});_.ob=function(){var a;a=(cb(this.c),this.q.props['a']);if(!!a&&a.f<0){return true}return false};_.wb=function(){return this.q.props['a']};_.xb=cq;_.lb=function(a,b,c){return Ul(this,a,b,c)};var $f=Lh(175);ph(176,175,Kp,cm);_.ib=function(){var b;try{A((J(),J(),I),new fm(this),zp)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.A=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new dm(this)),vp,null)}};_.s=Rp;_.pb=_p;_.F=dq;_.wb=function(){return cb(this.c),this.q.props['a']};_.u=Sp;_.B=gq;_.xb=function(){return T(this.d)};_.lb=function(b,c,d){var e;try{return t((J(),J(),I),new gm(this,b,c,d),75505664,null)}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){e=a;throw ah(e)}else if(ld(a,4)){e=a;throw ah(new Vh(e))}else throw ah(a)}};_.v=function(){var a;return Hh(Hf),Hf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((J(),J(),I),this.b,new em(this))}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.f=0;var Hf=Lh(176);ph(179,1,up,dm);_.C=function(){Wl(this.a)};var vf=Lh(179);ph(180,1,pp,em);_.w=bq;var wf=Lh(180);ph(181,1,up,fm);_.C=function(){Ml(this.a)};var xf=Lh(181);ph(182,1,pp,gm);_.w=function(){return Xl(this.a,this.d,this.c,this.b)};_.b=false;var yf=Lh(182);ph(183,1,up,hm);_.C=function(){bm(this.a,Qn(this.b))};var zf=Lh(183);ph(184,1,up,im);_.C=function(){Tl(this.a,this.b)};var Af=Lh(184);ph(185,1,up,jm);_.C=function(){Sl(this.a,this.b)};var Bf=Lh(185);ph(177,1,pp,km);_.w=function(){return Yl(this.a)};var Cf=Lh(177);ph(186,1,up,lm);_.C=function(){Rl(this.a,this.b)};var Df=Lh(186);ph(187,1,up,mm);_.C=function(){Nl(this.a,this.b)};var Ef=Lh(187);ph(178,1,xp,nm);_.C=aq;var Ff=Lh(178);ph(148,1,{},pm);_.K=function(){return om(this)};var Gf=Lh(148);ph(188,36,{});_.kb=function(){var a,b;return ik('div',null,[ik('div',null,[ik(Np,wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,[Np])),[ik('h1',null,['todos']),on(new pn)]),T(this.d.c)?null:ik('section',wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,[Np])),[ik(Lp,Ek(Hk(wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,['toggle-all'])),(el(),Lk)),rh(Gn.prototype.sb,Gn,[this])),null),ik('ul',wk(new $wnd.Object,cd(Yc(ne,1),qp,2,6,['todo-list'])),(a=Aj(zj(T(this.f.c).X()),(b=new Ii,b)),Hi(a,bd(a.a.length))))]),T(this.d.c)?null:zm(new Am)])])};var jg=Lh(188);ph(189,188,{});var ag=Lh(189);ph(190,189,Kp,sm);_.A=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new um(this)),vp,null)}};_.s=Rp;_.pb=_p;_.F=Vp;_.u=Sp;_.B=eq;_.v=function(){var a;return Hh(Mf),Mf.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.qb=function(){var b;try{return B((J(),J(),I),this.a,new vm(this))}catch(a){a=_g(a);if(ld(a,5)||ld(a,7)){b=a;throw ah(b)}else if(ld(a,4)){b=a;throw ah(new Vh(b))}else throw ah(a)}};_.c=0;var Mf=Lh(190);ph(191,1,xp,tm);_.C=aq;var If=Lh(191);ph(192,1,up,um);_.C=function(){ol(this.a)};var Jf=Lh(192);ph(193,1,pp,vm);_.w=bq;var Kf=Lh(193);ph(149,1,{},xm);_.K=function(){return wm(this)};var Lf=Lh(149);ph(248,$wnd.Function,{},ym);_.ub=function(a){to(this.a.f)};ph(204,1,{},Am);var Nf=Lh(204);ph(75,1,{},Bm);_.K=function(){return vl((new Xo(this.a)).a)};var Of=Lh(75);ph(202,1,{},Dm);var Pf=Lh(202);ph(76,1,{},Em);_.K=function(){return tl((new Yo(this.a)).a)};var Qf=Lh(76);ph(247,$wnd.Function,{},Jm);_.mb=function(a){return new Om(a)};var Km;var Mm;ph(91,33,{},Om);_.nb=function(){return vl((new Xo(Mm.a)).a)};_.componentWillUnmount=fq;var Tf=Lh(91);ph(251,$wnd.Function,{},Pm);_.mb=function(a){return new Um(a)};var Qm;var Sm;ph(92,33,{},Um);_.nb=function(){return tl((new Yo(Sm.a)).a)};_.componentWillUnmount=fq;var Uf=Lh(92);ph(263,$wnd.Function,{},Vm);_.mb=function(a){return new $m(a)};var Wm;var Ym;ph(95,33,{},$m);_.nb=function(){return Kl((new Zo(Ym.a)).a)};_.componentWillUnmount=fq;var Xf=Lh(95);ph(252,$wnd.Function,{},_m);_.mb=function(a){return new en(a)};var an;var cn;ph(93,33,{},en);_.nb=function(){return om((new $o(cn.a)).a)};_.componentDidUpdate=function(a){ek(this.a,a)};_.componentWillUnmount=fq;_.shouldComponentUpdate=function(a){return fk(this.a,a)};var Zf=Lh(93);ph(261,$wnd.Function,{},fn);_.mb=function(a){return new ln(a)};var gn;var jn;ph(94,33,{},ln);_.nb=function(){return wm((new _o(jn.a)).a)};_.componentWillUnmount=fq;var _f=Lh(94);ph(264,$wnd.Function,{},mn);_.tb=function(a){yl(this.a,a)};ph(265,$wnd.Function,{},nn);_.sb=function(a){Al(this.a,a)};ph(203,1,{},pn);var bg=Lh(203);ph(79,1,{},qn);_.K=function(){return Kl((new Zo(this.a)).a)};var cg=Lh(79);ph(259,$wnd.Function,{},sn);_.sb=function(a){Vl(this.a,a)};ph(253,$wnd.Function,{},tn);_.sb=function(a){Wn(this.a)};ph(255,$wnd.Function,{},un);_.ub=function(a){$l(this.a,this.b)};ph(256,$wnd.Function,{},vn);_.ub=function(a){Ol(this.a,this.b)};ph(257,$wnd.Function,{},wn);_.D=function(a){Pl(this.a,a)};ph(258,$wnd.Function,{},xn);_.rb=function(a){_l(this.a,this.b)};ph(260,$wnd.Function,{},yn);_.tb=function(a){Ql(this.a,this.b,a)};ph(205,1,{},Cn);var eg=Lh(205);ph(77,1,{},Dn);_.K=function(){return om((new $o(this.a)).a)};var fg=Lh(77);ph(262,$wnd.Function,{},Gn);_.sb=function(a){qm(this.a,a)};ph(80,1,{},In);var hg=Lh(80);ph(78,1,{},Jn);_.K=function(){return wm((new _o(this.a)).a)};var ig=Lh(78);ph(52,1,{52:1});_.g=false;var Xg=Lh(52);ph(53,52,{11:1,39:1,53:1,52:1},Xn);_.A=function(){On(this)};_.s=function(a){return Pn(this,a)};_.F=Zp;_.u=dq;_.B=gq;_.v=function(){var a;return Hh(Bg),Bg.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var Nn=0;var Bg=Lh(53);ph(206,1,up,Yn);_.C=function(){Sn(this.a)};var kg=Lh(206);ph(207,1,up,Zn);_.C=function(){Tn(this.a)};var lg=Lh(207);ph(48,118,{48:1});var Sg=Lh(48);ph(119,48,{11:1,48:1},go);_.A=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new ho(this)),vp,null)}};_.s=Rp;_.u=Sp;_.B=gq;_.v=function(){var a;return Hh(ug),ug.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.f=0;var ug=Lh(119);ph(124,1,up,ho);_.C=function(){co(this.a)};var mg=Lh(124);ph(125,1,up,io);_.C=function(){hc(this.a,this.b,true)};var ng=Lh(125);ph(120,1,pp,jo);_.w=function(){return eo(this.a)};var og=Lh(120);ph(126,1,pp,ko);_.w=function(){return $n(this.a,this.c,this.b)};_.b=false;var pg=Lh(126);ph(121,1,pp,lo);_.w=function(){return Xh(gh(xj(bo(this.a))))};var qg=Lh(121);ph(122,1,pp,mo);_.w=function(){return Xh(gh(xj(yj(bo(this.a),new gp))))};var rg=Lh(122);ph(123,1,pp,no);_.w=function(){return fo(this.a)};var sg=Lh(123);ph(99,1,{},qo);_.K=function(){return new go};var oo;var tg=Lh(99);ph(49,1,{49:1});var Wg=Lh(49);ph(130,49,{11:1,49:1},yo);_.A=function(){if(this.a>=0){this.a=-2;t((J(),J(),I),new G(new Bo),vp,null)}};_.s=Rp;_.u=Sp;_.B=function(){return this.a<0};_.v=function(){var a;return Hh(Ag),Ag.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.a=0;var Ag=Lh(130);ph(133,1,up,zo);_.C=function(){Vn(this.b,this.a)};var vg=Lh(133);ph(134,1,up,Ao);_.C=function(){uo(this.a)};var wg=Lh(134);ph(131,1,up,Bo);_.C=Xp;var xg=Lh(131);ph(132,1,up,Co);_.C=function(){vo(this.a,this.b)};_.b=false;var yg=Lh(132);ph(100,1,{},Do);_.K=function(){return new yo(this.a.K())};var zg=Lh(100);ph(50,1,{50:1});var Zg=Lh(50);ph(139,50,{11:1,50:1},Mo);_.A=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new No(this)),vp,null)}};_.s=Rp;_.u=Sp;_.B=function(){return this.g<0};_.v=function(){var a;return Hh(Ig),Ig.k+'@'+(a=Wj(this)>>>0,a.toString(16))};_.g=0;var Ig=Lh(139);ph(144,1,up,No);_.C=function(){Ho(this.a)};var Cg=Lh(144);ph(140,1,pp,Oo);_.w=function(){var a;return a=Wb(this.a.i),bi(Pp,a)||bi(Mp,a)||bi('',a)?bi(Pp,a)?(dp(),ap):bi(Mp,a)?(dp(),cp):(dp(),bp):(dp(),bp)};var Dg=Lh(140);ph(141,1,pp,Po);_.w=function(){return Io(this.a)};var Eg=Lh(141);ph(142,1,xp,Qo);_.C=function(){Jo(this.a)};var Fg=Lh(142);ph(143,1,xp,Ro);_.C=function(){Ko(this.a)};var Gg=Lh(143);ph(102,1,{},So);_.K=function(){return new Mo(this.b.K(),this.a.K())};var Hg=Lh(102);ph(101,1,{},Vo);_.K=function(){return new bc};var To;var Jg=Lh(101);ph(74,1,{},Wo);var Pg=Lh(74);ph(58,1,{},Xo);var Kg=Lh(58);ph(62,1,{},Yo);var Lg=Lh(62);ph(61,1,{},Zo);var Mg=Lh(61);ph(59,1,{},$o);var Ng=Lh(59);ph(60,1,{},_o);var Og=Lh(60);ph(37,35,{3:1,31:1,35:1,37:1},ep);var ap,bp,cp;var Qg=Mh(37,fp);ph(129,1,{},gp);_.gb=function(a){return !Rn(a)};var Rg=Lh(129);ph(136,1,{},hp);_.gb=function(a){return Rn(a)};var Tg=Lh(136);ph(137,1,{},ip);_.D=function(a){ao(this.a,a)};var Ug=Lh(137);ph(135,1,{},jp);_.D=function(a){so(this.a,a)};_.a=false;var Vg=Lh(135);ph(145,1,{},kp);_.gb=function(a){return Fo(this.a,a)};var Yg=Lh(145);var lp=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=kh;ih(vh);lh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();