function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='B0157E59A8FC0161FCA3FA2EEBDBB739',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'B0157E59A8FC0161FCA3FA2EEBDBB739';function o(){}
function oh(){}
function sh(){}
function Lb(){}
function Qc(){}
function Xc(){}
function Xn(){}
function Ej(){}
function Fj(){}
function Tk(){}
function Jm(){}
function Nm(){}
function Rm(){}
function Vm(){}
function Zm(){}
function Eo(){}
function kp(){}
function lp(){}
function Vc(a){Uc()}
function Fm(a){Em=a}
function Im(a){Hm=a}
function fn(a){en=a}
function rn(a){qn=a}
function vn(a){un=a}
function Ah(){Ah=oh}
function Ci(){ti(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function pb(a){this.a=a}
function Db(a){this.a=a}
function Eb(a){this.a=a}
function Fb(a){this.a=a}
function Gb(a){this.a=a}
function gc(a){this.a=a}
function pc(a){this.a=a}
function Qh(a){this.a=a}
function _h(a){this.a=a}
function li(a){this.a=a}
function qi(a){this.a=a}
function ri(a){this.a=a}
function pi(a){this.b=a}
function Ei(a){this.c=a}
function Cj(a){this.a=a}
function Hj(a){this.a=a}
function al(a){this.a=a}
function dl(a){this.a=a}
function el(a){this.a=a}
function fl(a){this.a=a}
function ml(a){this.a=a}
function ol(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function Dl(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function Jl(a){this.a=a}
function em(a){this.a=a}
function hm(a){this.a=a}
function jm(a){this.a=a}
function om(a){this.a=a}
function pm(a){this.a=a}
function xm(a){this.a=a}
function Am(a){this.a=a}
function Bm(a){this.a=a}
function Cm(a){this.a=a}
function bn(a){this.a=a}
function cn(a){this.a=a}
function gn(a){this.a=a}
function hn(a){this.a=a}
function ln(a){this.a=a}
function sn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function An(a){this.a=a}
function Cn(a){this.a=a}
function En(a){this.a=a}
function Sn(a){this.a=a}
function Tn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function Wn(a){this.a=a}
function jo(a){this.a=a}
function ko(a){this.a=a}
function uo(a){this.a=a}
function vo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function cp(a){this.a=a}
function dp(a){this.a=a}
function mp(a){this.a=a}
function np(a){this.a=a}
function op(a){this.a=a}
function $p(){jc(this.c)}
function aq(){jc(this.b)}
function Oi(){this.a=Xi()}
function aj(){this.a=Xi()}
function Dj(a,b){a.a=b}
function Zj(a,b){a.key=b}
function Yj(a,b){Xj(a,b)}
function Go(a,b){cm(b,a)}
function Wp(a){ej(this,a)}
function Zp(a){Uh(this,a)}
function jb(a){Zb((J(),a))}
function kb(a){$b((J(),a))}
function nb(a){_b((J(),a))}
function w(a){--a.e;D(a)}
function Y(a){!!a&&fb(a)}
function kc(a){!!a&&a.v()}
function Ob(a){a.a=-4&a.a|1}
function $g(a){return a.e}
function Tp(){return this.a}
function Yp(){return this.b}
function cq(){qb(this.a.a)}
function nc(a,b){hi(a.e,b)}
function Gj(a,b){xj(a.a,b)}
function Ll(a,b){oo(a.j,b)}
function Fo(a,b){no(a.b,b)}
function C(a,b){db(a.f,b.f)}
function wb(a,b){a.b=hj(b)}
function gl(a){a.c=2;jc(a.b)}
function Sl(a){a.f=2;jc(a.e)}
function Uk(a){a.d=2;jc(a.c)}
function Yk(a){qb(a.b);R(a.a)}
function Ln(a){R(a.a);fb(a.b)}
function Ti(){Ti=oh;Si=Vi()}
function J(){J=oh;I=new F}
function wc(){wc=oh;vc=new o}
function Nc(){Nc=oh;Mc=new Qc}
function Do(){Do=oh;Co=new Eo}
function Vp(){return Pj(this)}
function Up(a){return this===a}
function Xh(a,b){return a===b}
function Ml(a,b){return a.g=b}
function wi(a,b){return a.a[b]}
function Dh(a){Ch(a);return a.k}
function xl(a){qb(a.a);fb(a.b)}
function $n(a){fb(a.b);fb(a.a)}
function ai(a){uc.call(this,a)}
function Xp(){return ji(this.a)}
function _p(){return this.c.i<0}
function bq(){return this.b.i<0}
function Yc(a,b){return Jh(a,b)}
function Lj(a,b){a.splice(b,1)}
function ic(a,b,c){gi(a.e,b,c)}
function _n(a,b,c){ic(a.c,b,c)}
function ij(a,b){while(a.ab(b));}
function xj(a,b){Dj(a,wj(a.a,b))}
function K(a,b){O(a);L(a,hj(b))}
function Tb(a){Ub(a);!a.d&&Xb(a)}
function T(a){sb(a.f);return V(a)}
function wj(a,b){a.P(b);return a}
function gk(a,b){a.ref=b;return a}
function Nn(a){lb(a.b);return a.e}
function co(a){lb(a.a);return a.d}
function To(a){lb(a.d);return a.f}
function Xi(){Ti();return new Si}
function gb(a){J();$b(a);a.e=-2}
function Z(a){return !!a&&a.c.i<0}
function ji(a){return a.a.b+a.b.b}
function dq(a){return 1==this.a.d}
function eq(a){return 1==this.a.c}
function bd(a){return new Array(a)}
function Zi(a,b){return a.a.get(b)}
function si(a,b){this.a=a;this.b=b}
function hc(a,b){this.a=a;this.b=b}
function Oh(a,b){this.a=a;this.b=b}
function Aj(a,b){this.a=a;this.b=b}
function ek(a,b){this.a=a;this.b=b}
function Il(a,b){this.a=a;this.b=b}
function im(a,b){this.a=a;this.b=b}
function km(a,b){this.a=a;this.b=b}
function lm(a,b){this.a=a;this.b=b}
function mm(a,b){this.a=a;this.b=b}
function nm(a,b){this.a=a;this.b=b}
function Pk(a,b){Oh.call(this,a,b)}
function Jj(a,b,c){a.splice(b,0,c)}
function v(a,b,c){s(a,new H(c),b)}
function jn(a,b){this.a=a;this.b=b}
function kn(a,b){this.a=a;this.b=b}
function mn(a,b){this.a=a;this.b=b}
function nn(a,b){this.a=a;this.b=b}
function Vh(){qc(this);this.C()}
function Dc(){Dc=oh;!!(Uc(),Tc)}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function hh(){fh==null&&(fh=[])}
function Dm(){this.a=$j((Lm(),Km))}
function Gm(){this.a=$j((Pm(),Om))}
function dn(){this.a=$j((Tm(),Sm))}
function pn(){this.a=$j((Xm(),Wm))}
function tn(){this.a=$j((_m(),$m))}
function On(a){Mn(a,(lb(a.b),a.e))}
function ip(a,b){Oh.call(this,a,b)}
function Yn(a,b){this.a=a;this.b=b}
function wo(a,b){this.a=a;this.b=b}
function Mo(a,b){this.a=a;this.b=b}
function No(a,b){this.b=a;this.a=b}
function hk(a,b){a.href=b;return a}
function qk(a,b){a.value=b;return a}
function Zh(a,b){a.a+=''+b;return a}
function lk(a,b){a.onBlur=b;return a}
function ii(a){a.a=new Oi;a.b=new aj}
function ob(a){this.c=new Ci;this.b=a}
function Kc(a){$wnd.clearTimeout(a)}
function fi(a){return !a?null:a.Y()}
function Vb(a){return !a.d?a:Vb(a.d)}
function gj(a){return a!=null?r(a):0}
function qd(a){return a==null?null:a}
function nd(a){return typeof a===rp}
function B(a,b,c){return t(a,c,2048,b)}
function A(a,b,c){t(a,new G(b),c,null)}
function Kj(a,b){Ij(b,0,a,0,b.length)}
function fc(a,b){dc(a,b,false);kb(a.d)}
function Wl(a){qb(a.b);R(a.c);fb(a.a)}
function eo(a){cm(a,(lb(a.a),!a.d))}
function vb(a){J();ub(a);yb(a,2,true)}
function ti(a){a.a=$c(je,tp,1,0,5,1)}
function P(){this.a=$c(je,tp,1,100,5,1)}
function Jb(a){this.d=hj(a);this.b=100}
function uh(a){this.b=hj(a);this.a=this}
function lb(a){var b;Wb((J(),b=Rb,b),a)}
function $(a){return !(!!a&&1==(a.c&7))}
function Pj(a){return a.$H||(a.$H=++Oj)}
function Wh(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function Xj(a,b){for(var c in a){b(c)}}
function ik(a,b){a.onClick=b;return a}
function mk(a,b){a.onChange=b;return a}
function kk(a,b){a.checked=b;return a}
function nk(a,b){a.onKeyDown=b;return a}
function jk(a){a.autoFocus=true;return a}
function Ch(a){if(a.k!=null){return}Lh(a)}
function ec(a,b){nc(b.c,a);ld(b,9)&&b.t()}
function uc(a){this.f=a;qc(this);this.C()}
function vj(a,b){qj.call(this,a);this.a=b}
function nl(a,b){return new ll(hj(b),a.a)}
function El(a,b){return new Cl(hj(b),a.a)}
function md(a){return typeof a==='boolean'}
function pd(a){return typeof a==='string'}
function Tj(){Tj=oh;Qj=new o;Sj=new o}
function Ii(){this.a=new Oi;this.b=new aj}
function Mb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&yb(a.f,5,true)}
function rc(a,b){a.e=b;b!=null&&Nj(b,Cp,a)}
function ej(a,b){while(a.U()){Gj(b,a.V())}}
function Qi(a,b){var c;c=a[Hp];c.call(a,b)}
function u(a,b){return new Bb(hj(a),null,b)}
function so(a){return Rh(S(a.e).a-S(a.a).a)}
function Vo(a){Z((lb(a.d),a.f))&&Xo(a,null)}
function ho(a){A((J(),J(),I),new ko(a),Mp)}
function Ho(a){A((J(),J(),I),new Oo(a),Mp)}
function _l(a){A((J(),J(),I),new pm(a),Mp)}
function Pn(a){A((J(),J(),I),new Vn(a),Mp)}
function Nj(b,c,d){try{b[c]=d}catch(a){}}
function cb(a,b,c){Ob(hj(c));K(a.a[b],hj(c))}
function dj(a,b,c){this.a=a;this.b=b;this.c=c}
function cl(a,b,c){this.a=a;this.b=b;this.c=c}
function gm(a,b,c){this.a=a;this.b=b;this.c=c}
function zm(a,b,c){this.a=a;this.b=b;this.c=c}
function Ec(a,b,c){return a.apply(b,c);var d}
function rk(a,b){a.onDoubleClick=b;return a}
function ui(a,b){a.a[a.a.length]=b;return true}
function qc(a){a.g&&a.e!==Bp&&a.C();return a}
function Gh(a){var b;b=Fh(a);Nh(a,b);return b}
function Th(){Th=oh;Sh=$c(fe,tp,32,256,0,1)}
function xh(){xh=oh;wh=$wnd.window.document}
function Uc(){Uc=oh;var a;!Wc();a=new Xc;Tc=a}
function Ib(a){while(true){if(!Hb(a)){break}}}
function db(a,b){cb(a,((b.a&229376)>>15)-1,b)}
function yl(a,b){A((J(),J(),I),new Il(a,b),Mp)}
function Xl(a,b){A((J(),J(),I),new nm(a,b),Mp)}
function Zl(a,b){A((J(),J(),I),new lm(a,b),Mp)}
function $l(a,b){A((J(),J(),I),new km(a,b),Mp)}
function bm(a,b){A((J(),J(),I),new im(a,b),Mp)}
function oo(a,b){A((J(),J(),I),new wo(a,b),Mp)}
function Ko(a,b){A((J(),J(),I),new Mo(a,b),Mp)}
function qo(a){Uh(new qi(a.g),new gc(a));ii(a.g)}
function F(){this.f=new eb;this.a=new Jb(this.f)}
function xo(a,b){this.a=a;this.c=b;this.b=false}
function zl(a,b){var c;c=b.target;Bl(a,c.value)}
function tb(a,b){ib(b,a);b.c.a.length>0||(b.a=4)}
function yh(a,b,c,d){a.addEventListener(b,c,d)}
function zh(a,b,c,d){a.removeEventListener(b,c,d)}
function yj(a,b,c){if(a.a.bb(c)){a.b=true;b.w(c)}}
function kj(a){if(!a.d){a.d=a.b.O();a.c=a.b.Q()}}
function Kb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function tj(a){pj(a);return new vj(a,new Bj(a.a))}
function vh(a){hj(a);return ld(a,44)?a:new uh(a)}
function fm(a,b){return new dm(hj(b),a.a,a.b,a.c)}
function ym(a,b){return new wm(hj(b),a.a,a.b,a.c)}
function bl(a,b){return new _k(hj(b),a.a,a.b,a.c)}
function Yi(a,b){return !(a.a.get(b)===undefined)}
function Zk(a){return Ah(),S(a.e.b).a>0?true:false}
function ro(a){return Ah(),0==S(a.e).a?true:false}
function $k(a){return B((J(),J(),I),a.b,new fl(a))}
function kl(a){return B((J(),J(),I),a.a,new ql(a))}
function Al(a){return B((J(),J(),I),a.a,new Gl(a))}
function ad(a){return Array.isArray(a)&&a.kb===sh}
function kd(a){return !Array.isArray(a)&&a.kb===sh}
function am(a){return B((J(),J(),I),a.b,new hm(a))}
function vm(a){return B((J(),J(),I),a.a,new Bm(a))}
function Qo(a){return Xh(Rp,a)||Xh(Sp,a)||Xh('',a)}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function yi(a,b){var c;c=a.a[b];Lj(a.a,b);return c}
function Ai(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ni(a){var b;b=a.a.V();a.b=mi(a);return b}
function Ih(a){var b;b=Fh(a);b.j=a;b.e=1;return b}
function qm(a,b){var c;c=b.target;Ko(a.e,c.checked)}
function mo(a){R(a.c);R(a.e);R(a.a);R(a.b);fb(a.d)}
function Bl(a,b){var c;c=a.f;if(b!=c){a.f=b;kb(a.b)}}
function cm(a,b){var c;c=a.d;if(b!=c){a.d=b;kb(a.a)}}
function Vk(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function hl(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function Tl(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function oj(a){if(!a.b){pj(a);a.c=true}else{oj(a.b)}}
function So(a){qb(a.e);qb(a.a);R(a.b);R(a.c);fb(a.d)}
function ki(a,b){if(b){return di(a.a,b)}return false}
function sj(a,b){pj(a);return new vj(a,new zj(b,a.a))}
function Mn(a,b){A((J(),J(),I),new Yn(a,b),75497472)}
function Hi(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function jj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function pk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Hh(a,b){var c;c=Fh(a);Nh(a,c);c.e=b?8:0;return c}
function Qn(a,b){var c;c=a.e;if(b!=c){a.e=hj(b);kb(a.b)}}
function Kn(a){var b;U(a.a);b=S(a.a);Xh(a.f,b)&&Qn(a,b)}
function mb(a){var b;J();!!Rb&&!!Rb.e&&Wb((b=Rb,b),a)}
function Pl(a,b){Xo(a.k,b);A((J(),J(),I),new im(a,b),Mp)}
function ac(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Bj(a){jj.call(this,a._(),a.$()&-6);this.a=a}
function qj(a){if(!a){this.b=null;new Ci}else{this.b=a}}
function hj(a){if(a==null){throw $g(new Vh)}return a}
function Wj(){if(Rj==256){Qj=Sj;Sj=new o;Rj=0}++Rj}
function eh(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function Kh(a){if(a.M()){return null}var b=a.j;return kh[b]}
function bc(a,b){Rb=new ac(Rb,b);a.d=false;Sb(Rb);return Rb}
function no(a,b){return t((J(),J(),I),new xo(a,b),Mp,null)}
function Ol(a,b){A((J(),J(),I),new im(a,b),Mp);Xo(a.k,null)}
function rb(a){C((J(),J(),I),a);0==(a.f.a&yp)&&D((null,I))}
function Gn(a){yh((xh(),$wnd.window.window),Pp,a.d,false)}
function Hn(a){zh((xh(),$wnd.window.window),Pp,a.d,false)}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function jp(){hp();return cd(Yc(Og,1),tp,34,0,[ep,gp,fp])}
function ei(a,b){return b===a?'(this Map)':b==null?Ep:rh(b)}
function sc(a,b){var c;c=Dh(a.ib);return b==null?c:c+': '+b}
function Kl(a,b){var c;if(S(a.c)){c=b.target;cm(a,c.value)}}
function Uh(a,b){var c,d;for(d=a.O();d.U();){c=d.V();b.w(c)}}
function xn(a){return new cl(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function Bn(a){return new gm(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function Dn(a){return new zm(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function Sb(a){if(a.e){2==(a.e.c&7)||yb(a.e,4,true);ub(a.e)}}
function pj(a){if(a.b){pj(a.b)}else if(a.c){throw $g(new Ph)}}
function Io(a,b){var c;uj(po(a.b),(c=new Ci,c)).N(new np(b))}
function Jh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function Ki(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function lj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Lm(){Lm=oh;var a;Km=(a=ph(Jm.prototype.hb,Jm,[]),a)}
function Pm(){Pm=oh;var a;Om=(a=ph(Nm.prototype.hb,Nm,[]),a)}
function Tm(){Tm=oh;var a;Sm=(a=ph(Rm.prototype.hb,Rm,[]),a)}
function Xm(){Xm=oh;var a;Wm=(a=ph(Vm.prototype.hb,Vm,[]),a)}
function _m(){_m=oh;var a;$m=(a=ph(Zm.prototype.hb,Zm,[]),a)}
function qh(a){function b(){}
;b.prototype=a||{};return new b}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function ok(a){a.placeholder='What needs to be done?';return a}
function In(a,b){b.preventDefault();A((J(),J(),I),new Wn(a),Mp)}
function po(a){lb(a.d);return new vj(null,new lj(new qi(a.g),0))}
function Li(a,b){var c;return Ji(b,Ki(a,b==null?0:(c=r(b),c|0)))}
function mh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Yl(a){return Ah(),To(a.k)==a.n.props['a']?true:false}
function Di(a){ti(this);Kj(this.a,ci(a,$c(je,tp,1,ji(a.a),5,1)))}
function Pi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Qm(a){$wnd.React.Component.call(this,a);this.a=nl(Hm,this)}
function Mm(a){$wnd.React.Component.call(this,a);this.a=bl(Em,this)}
function Um(a){$wnd.React.Component.call(this,a);this.a=El(en,this)}
function Ym(a){$wnd.React.Component.call(this,a);this.a=fm(qn,this)}
function an(a){$wnd.React.Component.call(this,a);this.a=ym(un,this)}
function zj(a,b){jj.call(this,b._(),b.$()&-16449);this.a=a;this.c=b}
function hb(a,b){var c,d;ui(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Xo(a,b){var c;c=a.f;if(!(b==c||!!b&&ao(b,c))){a.f=b;kb(a.d)}}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function dk(a,b,c){!Xh(c,'key')&&!Xh(c,'ref')&&(a[c]=b[c],undefined)}
function mc(a){kc(a.g);!!a.e&&lc(a);Y(a.a);Y(a.c);kc(a.b);kc(a.f)}
function mj(a,b){!a.a?(a.a=new _h(a.d)):Zh(a.a,a.b);Zh(a.a,b);return a}
function uj(a,b){var c;oj(a);c=new Ej;c.a=b;a.a.T(new Hj(c));return c.a}
function rj(a){var b;oj(a);b=0;while(a.a.ab(new Fj)){b=_g(b,1)}return b}
function Jo(a){var b;uj(sj(po(a.b),new lp),(b=new Ci,b)).N(new mp(a.b))}
function Pb(b){try{b.b.v()}catch(a){a=Zg(a);if(!ld(a,5))throw $g(a)}}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function bb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function rl(a){var b;b=Yh((lb(a.b),a.f));if(b.length>0){Fo(a.e,b);Bl(a,'')}}
function hi(a,b){return pd(b)?b==null?Ni(a.a,null):_i(a.b,b):Ni(a.a,b)}
function Ro(a,b){return (hp(),fp)==a||(ep==a?(lb(b.a),!b.d):(lb(b.a),b.d))}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Lo(a){this.b=hj(a);J();this.a=new oc(0,null,null,false,false)}
function bj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function oi(a){this.d=a;this.c=new bj(this.d.b);this.a=this.c;this.b=mi(this)}
function nj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function vi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Uo(a){var b,c;return b=S(a.b),uj(sj(po(a.j),new op(b)),(c=new Ci,c))}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function ao(a,b){var c;if(ld(b,49)){c=b;return a.c.d==c.c.d}else{return false}}
function zi(a,b){var c;c=xi(a,b,0);if(c==-1){return false}Lj(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function xi(a,b,c){for(;c<a.a.length;++c){if(Hi(b,a.a[c])){return c}}return -1}
function cj(a){if(a.a.c!=a.c){return Zi(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Ib(a.a)}finally{a.c=false}}}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;fb(a.e);2==(a.f.c&7)||qb(a.f)}}
function fb(a){if(-2!=a.e){t((J(),J(),I),new G(new pb(a)),0,null);!!a.b&&qb(a.b)}}
function jc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new pc(a)),67108864,null)}}
function Fn(a,b){a.f=b;Xh(b,S(a.a))&&Qn(a,b);Jn(b);A((J(),J(),I),new Wn(a),Mp)}
function sl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Hl(a),Mp)}}
function xb(b){if(b){try{b.v()}catch(a){a=Zg(a);if(ld(a,5)){J()}else throw $g(a)}}}
function V(a){if(a.b){if(ld(a.b,8)){throw $g(a.b)}else{throw $g(a.b)}}return a.n}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function gi(a,b,c){return pd(b)?b==null?Mi(a.a,null,c):$i(a.b,b,c):Mi(a.a,b,c)}
function Mj(a,b){return Zc(b)!=10&&cd(q(b),b.jb,b.__elementTypeId$,Zc(b),a),a}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===qp||typeof a==='function')&&!(a.kb===sh)}
function jh(a,b){typeof window===qp&&typeof window['$gwt']===qp&&(window['$gwt'][a]=b)}
function Nh(a,b){var c;if(!a){return}b.j=a;var d=Kh(b);if(!d){kh[a]=[b];return}d.ib=b}
function ph(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Zg(a){var b;if(ld(a,5)){return a}b=a&&a[Cp];if(!b){b=new yc(a);Vc(b)}return b}
function Fh(a){var b;b=new Eh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function _i(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Qi(a.a,b);--a.b}return c}
function Wb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;ui((!a.b&&(a.b=new Ci),a.b),b)}}}
function Yb(a,b){var c;if(!a.c){c=Vb(a);!c.c&&(c.c=new Ci);a.c=c.c}b.d=true;ui(a.c,hj(b))}
function ub(a){var b,c;for(c=new Ei(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Fi(a){var b,c,d;d=0;for(c=new oi(a.a);c.b;){b=ni(c);d=d+(b?r(b):0);d=d|0}return d}
function $j(a){var b;b=ak($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function _j(a,b,c,d){var e;e=ak($wnd.React.Element,a);e.key=b;e.ref=c;e.props=hj(d);return e}
function bk(a){var b;return _j($wnd.React.StrictMode,null,null,(b={},b[Ip]=hj(a),b))}
function eb(){var a;this.a=$c(wd,tp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function cc(){var a;try{Tb(Rb);J()}finally{a=Rb.d;!a&&((J(),J(),I).d=true);Rb=Rb.d}}
function gh(){hh();var a=fh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Ph(){uc.call(this,"Stream already terminated, can't be modified or used")}
function Bb(a,b,c){Ab.call(this,null,a,b,c|(!a?262144:vp)|(0==(c&6291456)?!a?yp:zp:0)|0|0|0)}
function Qb(a,b){this.b=hj(a);this.a=b|0|(0==(b&6291456)?zp:0)|(0!=(b&229376)?0:98304)}
function wn(){this.a=vh((Do(),Do(),Co));this.b=vh(new Po(this.a));this.c=vh(new cp(this.a))}
function hp(){hp=oh;ep=new ip('ACTIVE',0);gp=new ip('COMPLETED',1);fp=new ip('ALL',2)}
function bi(a,b){var c,d;for(d=new oi(b.a);d.b;){c=ni(d);if(!ki(a,c)){return false}}return true}
function Ji(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Hi(a,c.X())){return c}}return null}
function dh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Fp;d=1048575}c=rd(e/zp);b=rd(e-c*zp);return dd(b,c,d)}
function ah(a){var b;b=a.h;if(b==0){return a.l+a.m*zp}if(b==1048575){return a.l+a.m*zp-Fp}return a}
function mi(a){if(a.a.U()){return true}if(a.a!=a.c){return false}a.a=new Pi(a.d.a);return a.a.U()}
function on(a,b){Zj(a.a,(Ch(Yf),Yf.k+(''+(b?Rh(b.c.d):null))));hj(b);a.a.props['a']=b;return a.a}
function lo(a,b,c){var d;d=new io(b,c);_n(d,a,new hc(a,d));gi(a.g,Rh(d.c.d),d);kb(a.d);return d}
function $i(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function dc(a,b,c){var d;d=hi(a.g,b?Rh(b.c.d):null);if(null!=d){nc(b.c,a);c&&!!b&&jc(b.c);kb(a.d)}}
function Wo(a){var b;b=S(a.i.a);Xh(Rp,b)||Xh(Sp,b)||Xh('',b)?Mn(a.i,b):Qo(Nn(a.i))?Pn(a.i):Mn(a.i,'')}
function Nl(a,b,c){27==c.which?A((J(),J(),I),new mm(a,b),Mp):13==c.which&&A((J(),J(),I),new km(a,b),Mp)}
function qb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Fb(a)),67108864,null);!!a.a&&R(a.a);Mb(a.f);a.c=a.c&-8|1}}
function Sk(){if(!Rk){Rk=(++(J(),J(),I).e,new Lb);$wnd.Promise.resolve(null).then(ph(Tk.prototype.G,Tk,[]))}}
function cd(a,b,c,d,e){e.ib=a;e.jb=b;e.kb=sh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function ib(a,b){var c,d;d=a.c;zi(d,b);!!a.b&&vp!=(a.b.c&wp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Yb((J(),c=Rb,c),a))}
function Nb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&vp)?Pb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function q(a){return pd(a)?me:nd(a)?be:md(a)?_d:kd(a)?a.ib:ad(a)?a.ib:a.ib||Array.isArray(a)&&Yc(Td,1)||Td}
function r(a){return pd(a)?Vj(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.q():ad(a)?Pj(a):!!a&&!!a.hashCode?a.hashCode():Pj(a)}
function p(a,b){return pd(a)?Xh(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.o(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function Rl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;bm(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Rh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Th(),Sh)[b];!c&&(c=Sh[b]=new Qh(a));return c}return new Qh(a)}
function rh(a){var b;if(Array.isArray(a)&&a.kb===sh){return Dh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Vj(a){Tj();var b,c,d;c=':'+a;d=Sj[c];if(d!=null){return rd(d)}d=Qj[c];b=d==null?Uj(a):rd(d);Wj();Sj[c]=b;return b}
function yc(a){wc();qc(this);this.e=a;a!=null&&Nj(a,Cp,this);this.f=a==null?Ep:rh(a);this.a='';this.b=a;this.a=''}
function Eh(){this.g=Bh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Gi(a){var b,c,d;d=1;for(c=new Ei(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function ab(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Xb(a){var b;if(a.c){while(a.c.a.length!=0){b=yi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&yb(b.b,3,true)}}}
function lc(a){var b,c,d;for(c=new Ei(new Di(new li(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.X();ld(d,9)&&d.u()||b.Y().v()}}
function Qk(){Ok();return cd(Yc(Ye,1),tp,7,0,[sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk])}
function Cb(a,b){Ab.call(this,a,new Db(a),null,b|(vp==(b&wp)?0:524288)|(0==(b&6291456)?vp==(b&wp)?zp:yp:0)|0|268435456|0)}
function _g(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<Fp){return c}}return ah(ed(nd(a)?dh(a):a,nd(b)?dh(b):b))}
function Ql(a,b){var c;c=(lb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new No(b,c),Mp);Xo(a.k,null);cm(a,c)}else{oo(a.j,b)}}
function Mh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Bi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Mj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function ci(a,b){var c,d,e;e=ji(a.a);b.length<e&&(b=Mj(new Array(e),b));d=new oi(a.a);for(c=0;c<e;++c){b[c]=ni(d)}b.length>e&&(b[e]=null);return b}
function fk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function oc(a,b,c,d,e){var f;this.d=a;this.e=d?new Ii:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new ob((J(),null)),f):null;this.c=null}
function ll(a,b){var c;this.d=hj(b);this.n=hj(a);J();c=++jl;this.b=new oc(c,null,new ml(this),false,false);this.a=new Bb(null,hj(new pl(this)),Lp)}
function io(a,b){var c,d,e;this.e=hj(a);this.d=b;J();c=++Zn;this.c=new oc(c,null,new jo(this),true,true);this.b=(e=new ob(null),e);this.a=(d=new ob(null),d)}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.jb){return !!a.jb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function S(a){a.k?mb(a.e):lb(a.e);if(zb(a.f)){if(a.k&&(J(),!(!!Rb&&!!Rb.e))){return t((J(),J(),I),new X(a),83888128,null)}else{sb(a.f)}}return V(a)}
function $b(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&yb(b,6,true)}}}
function _b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&yb(b,5,true)}}}
function Zb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?yb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Yh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{bc(b,d);try{f=(c.a.v(),null)}finally{cc()}return f}catch(a){a=Zg(a);if(ld(a,5)){e=a;throw $g(e)}else throw $g(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Rb){g=c.s()}else{bc(b,e);try{g=c.s()}finally{cc()}}return g}catch(a){a=Zg(a);if(ld(a,5)){f=a;throw $g(f)}else throw $g(a)}finally{D(b)}}
function Hb(a){var b,c;if(0==a.c){b=bb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=ab(a.d);Nb(c);return true}
function ih(b,c,d,e){hh();var f=fh;$moduleName=c;$moduleBase=d;Yg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{pp(g)()}catch(a){b(c,a)}}else{pp(g)()}}
function W(a,b,c,d){this.c=hj(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new Cb(this,d&-16385);this.e=new ob(this.f);vp==(d&wp)&&rb(this.f)}
function Cl(a,b){var c,d;this.e=hj(b);this.n=hj(a);J();c=++wl;this.c=new oc(c,null,new Dl(this),false,false);this.b=(d=new ob(null),d);this.a=new Bb(null,hj(new Jl(this)),Lp)}
function wm(a,b,c,d){var e;this.d=hj(b);this.e=hj(c);this.f=hj(d);this.n=hj(a);J();e=++um;this.b=new oc(e,null,new xm(this),false,false);this.a=new Bb(null,hj(new Am(this)),Lp)}
function ak(a,b){var c;c=new $wnd.Object;c.$$typeof=hj(a);c.type=hj(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Vi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Wi()}}
function il(a){var b,c,d;a.c=0;Sk();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),ck('span',fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,['todo-count'])),[ck('strong',null,[c]),' '+d+' left']));return b}
function lh(){kh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].lb()&&(c=Rc(c,g)):g[0].lb()}catch(a){a=Zg(a);if(ld(a,5)){d=a;Dc();Jc(ld(d,35)?d.D():d)}else throw $g(a)}}return c}
function vl(a){var b;a.d=0;Sk();b=ck(Np,jk(mk(nk(qk(ok(fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,['new-todo']))),(lb(a.b),a.f)),ph(bn.prototype.fb,bn,[a])),ph(cn.prototype.eb,cn,[a]))),null);return b}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?Ep:od(b)?b==null?null:b.name:pd(b)?'String':Dh(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.n=d;b.b=null;jb(b.e)}}catch(a){a=Zg(a);if(ld(a,12)){c=a;if(!b.b){b.n=null;b.b=c;jb(b.e)}throw $g(c)}else throw $g(a)}}
function Mi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ji(b,e);if(f){return f.Z(c)}}e[e.length]=new si(b,c);++a.b;return null}
function Ij(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Uj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Wh(a,c++)}b=b|0;return b}
function sb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Zg(a);if(ld(a,5)){J()}else throw $g(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=$c(je,tp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function th(){var a;a=new wn;Fm(xn(new yn(a)));Im(new ol((new zn(a)).a.a.F()));rn(Bn(new Cn(a)));vn(Dn(new En(a)));fn(new Fl((new An(a)).a.b.F()));$wnd.ReactDOM.render(bk([(new tn).a]),(xh(),wh).getElementById('app'),null)}
function Jn(a){var b;if(0==a.length){b=(xh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',wh.title,b)}else{(xh(),$wnd.window.window).location.hash=a}}
function _k(a,b,c,d){var e;this.e=hj(b);this.f=hj(c);this.g=hj(d);this.n=hj(a);J();e=++Xk;this.c=new oc(e,null,new al(this),false,false);this.a=new W(new dl(this),null,null,136478720);this.b=new Bb(null,hj(new el(this)),Lp)}
function dm(a,b,c,d){var e,f;this.j=hj(b);hj(c);this.k=hj(d);this.n=hj(a);J();e=++Vl;this.e=new oc(e,null,new em(this),false,false);this.a=(f=new ob(null),f);this.c=new W(new jm(this),null,null,136478720);this.b=new Bb(null,hj(new om(this)),Lp);bm(this,this.n.props['a'])}
function Ab(a,b,c,d){this.b=new Ci;this.f=new Qb(new Eb(this),d&6520832|262144|vp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&yp)&&D((null,I)))}
function Ni(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Hi(b,e.X())){if(d.length==1){d.length=0;Qi(a.a,g)}else{d.splice(h,1)}--a.b;return e.Y()}}return null}
function nh(a,b,c){var d=kh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=kh[b]),qh(h));_.jb=c;!b&&(_.kb=sh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ib=f)}
function Lh(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Mh('.',[c,Mh('$',d)]);a.b=Mh('.',[c,Mh('.',d)]);a.i=d[d.length-1]}
function di(a,b){var c,d,e;c=b.X();e=b.Y();d=pd(c)?c==null?fi(Li(a.a,null)):Zi(a.b,c):fi(Li(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Li(a.a,null):Yi(a.b,c):!!Li(a.a,c))){return false}return true}
function ck(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Yj(b,ph(ek.prototype.cb,ek,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ip]=c[0],undefined):(d[Ip]=c,undefined));return _j(a,e,f,d)}
function Rn(){var a,b;this.d=new dp(this);this.f=this.e=(b=(xh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new oc(0,null,new Sn(this),false,false);this.b=(a=new ob(null),a);this.a=new W(new Xn,new Tn(this),new Un(this),35651584)}
function to(){var a;this.g=new Ii;J();this.f=new oc(0,new vo(this),new uo(this),false,false);this.d=(a=new ob(null),a);this.c=new W(new yo(this),null,null,Qp);this.e=new W(new zo(this),null,null,Qp);this.a=new W(new Ao(this),null,null,Qp);this.b=new W(new Bo(this),null,null,Qp)}
function Yo(a){var b;this.j=hj(a);this.i=new Rn;J();this.g=new oc(0,null,new Zo(this),false,false);this.d=(b=new ob(null),b);this.b=new W(new $o(this),null,null,Qp);this.c=new W(new _o(this),null,null,Qp);this.e=u(new ap(this),413138944);this.a=u(new bp(this),681574400);D((null,I))}
function zb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ei(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Zg(a);if(!ld(a,5))throw $g(a)}if(6==(b.c&7)){return true}}}}}ub(b);return false}
function Ui(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function yb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){nb(a.a.e);xb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;xb((e=d.i,e));d.n=null}vi(a.b,new Gb(a));a.b.a=$c(je,tp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&xb((f=a.a.g,f))}}
function Ok(){Ok=oh;sk=new Pk(Jp,0);tk=new Pk('checkbox',1);uk=new Pk('color',2);vk=new Pk('date',3);wk=new Pk('datetime',4);xk=new Pk('email',5);yk=new Pk('file',6);zk=new Pk('hidden',7);Ak=new Pk('image',8);Bk=new Pk('month',9);Ck=new Pk(rp,10);Dk=new Pk('password',11);Ek=new Pk('radio',12);Fk=new Pk('range',13);Gk=new Pk('reset',14);Hk=new Pk('search',15);Ik=new Pk('submit',16);Jk=new Pk('tel',17);Kk=new Pk('text',18);Lk=new Pk('time',19);Mk=new Pk('url',20);Nk=new Pk('week',21)}
function tm(a){var b,c,d;a.c=0;Sk();d=ck('div',null,[ck('div',null,[ck(Op,fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,[Op])),[ck('h1',null,['todos']),(new dn).a]),S(a.d.c)?null:ck('section',fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,[Op])),[ck(Np,mk(pk(fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,['toggle-all'])),(Ok(),tk)),ph(sn.prototype.eb,sn,[a])),null),ck('ul',fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,['todo-list'])),(b=uj(hj(tj(S(a.f.c).S())),(c=new Ci,c)),Bi(b,bd(b.a.length))))]),S(a.d.c)?null:(new Dm).a])]);return d}
function Ub(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=wi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ai(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{ib(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&yb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=wi(a.b,g);if(-1==k.e){k.e=0;hb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){yi(a.b,g)}e&&wb(a.e,a.b)}else{e&&wb(a.e,new Ci)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&vp!=(k.b.c&wp)&&k.c.a.length<=0&&0==k.b.a.d&&Yb(a,k)}}
function Wk(a){var b,c;a.d=0;Sk();c=(b=S(a.g.b),ck('footer',fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,['footer'])),[(new Gm).a,ck('ul',fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,['filters'])),[ck('li',null,[ck('a',hk(fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,[(hp(),fp)==b?Kp:null])),'#'),['All'])]),ck('li',null,[ck('a',hk(fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,[ep==b?Kp:null])),'#active'),['Active'])]),ck('li',null,[ck('a',hk(fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,[gp==b?Kp:null])),'#completed'),['Completed'])])]),S(a.a)?ck(Jp,ik(fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,['clear-completed'])),ph(Cm.prototype.gb,Cm,[a])),['Clear Completed']):null]));return c}
function Ul(a){var b,c,d,e;a.f=0;Sk();b=a.n.props['a'];if(b.c.i<0){return null}c=(d=a.n.props['a'],e=(lb(d.a),d.d),ck('li',fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[ck('div',fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,['view'])),[ck(Np,mk(kk(pk(fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,['toggle'])),(Ok(),tk)),e),ph(hn.prototype.eb,hn,[d])),null),ck('label',rk(new $wnd.Object,ph(jn.prototype.gb,jn,[a,d])),[(lb(d.b),d.e)]),ck(Jp,ik(fk(new $wnd.Object,cd(Yc(me,1),tp,2,6,['destroy'])),ph(kn.prototype.gb,kn,[a,d])),null)]),ck(Np,nk(mk(lk(qk(fk(gk(new $wnd.Object,ph(ln.prototype.w,ln,[a])),cd(Yc(me,1),tp,2,6,['edit'])),(lb(a.a),a.d)),ph(mn.prototype.db,mn,[a,d])),ph(gn.prototype.eb,gn,[a])),ph(nn.prototype.fb,nn,[a,d])),null)]));return c}
function Wi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Hp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ui()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Hp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var qp='object',rp='number',sp={11:1},tp={3:1,4:1},up={9:1},vp=1048576,wp=1835008,xp={6:1},yp=2097152,zp=4194304,Ap={22:1},Bp='__noinit__',Cp='__java$exception',Dp={3:1,12:1,8:1,5:1},Ep='null',Fp=17592186044416,Gp={40:1},Hp='delete',Ip='children',Jp='button',Kp='selected',Lp=1411518464,Mp=142606336,Np='input',Op='header',Pp='hashchange',Qp=136314880,Rp='active',Sp='completed';var _,kh,fh,Yg=-1;lh();nh(1,null,{},o);_.o=Up;_.p=function(){return this.ib};_.q=Vp;_.r=function(){var a;return Dh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var fd,gd,hd;nh(54,1,{},Eh);_.H=function(a){var b;b=new Eh;b.e=4;a>1?(b.c=Jh(this,a-1)):(b.c=this);return b};_.I=function(){Ch(this);return this.b};_.J=function(){return Dh(this)};_.K=function(){Ch(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Ch(this),this.k)};_.e=0;_.g=0;var Bh=1;var je=Gh(1);var ae=Gh(54);nh(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var vd=Gh(81);nh(36,1,sp,G);_.s=function(){return this.a.v(),null};var td=Gh(36);nh(82,1,{},H);var ud=Gh(82);var I;nh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var wd=Gh(43);nh(232,1,up);_.r=function(){var a;return Dh(this.ib)+'@'+(a=r(this)>>>0,a.toString(16))};var Ad=Gh(232);nh(20,232,up,W);_.t=function(){R(this)};_.u=Tp;_.a=false;_.d=0;_.k=false;var yd=Gh(20);nh(179,1,sp,X);_.s=function(){return T(this.a)};var xd=Gh(179);nh(143,1,{270:1},eb);var zd=Gh(143);nh(18,232,{9:1,18:1},ob);_.t=function(){fb(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Cd=Gh(18);nh(178,1,xp,pb);_.v=function(){gb(this.a)};var Bd=Gh(178);nh(19,232,{9:1,19:1},Bb,Cb);_.t=function(){qb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Hd=Gh(19);nh(180,1,Ap,Db);_.v=function(){Q(this.a)};var Dd=Gh(180);nh(181,1,xp,Eb);_.v=function(){sb(this.a)};var Ed=Gh(181);nh(182,1,xp,Fb);_.v=function(){vb(this.a)};var Fd=Gh(182);nh(183,1,{},Gb);_.w=function(a){tb(this.a,a)};var Gd=Gh(183);nh(144,1,{},Jb);_.a=0;_.b=0;_.c=0;var Id=Gh(144);nh(184,1,up,Lb);_.t=function(){Kb(this)};_.u=Tp;_.a=false;var Jd=Gh(184);nh(65,232,{9:1,65:1},Qb);_.t=function(){Mb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Kd=Gh(65);nh(188,1,{},ac);_.r=function(){var a;return Ch(Ld),Ld.k+'@'+(a=Pj(this)>>>0,a.toString(16))};_.a=0;var Rb;var Ld=Gh(188);nh(156,1,{});var Od=Gh(156);nh(149,1,{},gc);_.w=function(a){ec(this.a,a)};var Md=Gh(149);nh(150,1,xp,hc);_.v=function(){fc(this.a,this.b)};var Nd=Gh(150);nh(157,156,{});var Pd=Gh(157);nh(17,1,up,oc);_.t=function(){jc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Ch(Rd),Rd.k+'@'+(a=Pj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Rd=Gh(17);nh(177,1,xp,pc);_.v=function(){mc(this.a)};var Qd=Gh(177);nh(5,1,{3:1,5:1});_.A=function(a){return new Error(a)};_.B=function(){return this.f};_.C=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Dh(this.ib),c==null?a:a+': '+c);rc(this,tc(this.A(b)));Vc(this)};_.r=function(){return sc(this,this.B())};_.e=Bp;_.g=true;var ne=Gh(5);nh(12,5,{3:1,12:1,5:1});var de=Gh(12);nh(8,12,Dp);var ke=Gh(8);nh(55,8,Dp);var ge=Gh(55);nh(76,55,Dp);var Vd=Gh(76);nh(35,76,{35:1,3:1,12:1,8:1,5:1},yc);_.B=function(){xc(this);return this.c};_.D=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Sd=Gh(35);var Td=Gh(0);nh(214,1,{});var Ud=Gh(214);var Ac=0,Bc=0,Cc=-1;nh(90,214,{},Qc);var Mc;var Wd=Gh(90);var Tc;nh(225,1,{});var Yd=Gh(225);nh(77,225,{},Xc);var Xd=Gh(77);nh(44,1,{44:1,69:1},uh);_.F=function(){if(this===this.a){this.a=this.b.F();this.b=null}return this.a};var Zd=Gh(44);var wh;nh(74,1,{71:1});_.r=Tp;var $d=Gh(74);fd={3:1,72:1,31:1};var _d=Gh(72);nh(41,1,{3:1,41:1});var ie=Gh(41);gd={3:1,31:1,41:1};var be=Gh(224);nh(33,1,{3:1,31:1,33:1});_.o=Up;_.q=Vp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ce=Gh(33);nh(78,8,Dp,Ph);var ee=Gh(78);nh(32,41,{3:1,31:1,32:1,41:1},Qh);_.o=function(a){return ld(a,32)&&a.a==this.a};_.q=Tp;_.r=function(){return ''+this.a};_.a=0;var fe=Gh(32);var Sh;nh(288,1,{});nh(79,55,Dp,Vh);_.A=function(a){return new TypeError(a)};var he=Gh(79);hd={3:1,71:1,31:1,2:1};var me=Gh(2);nh(75,74,{71:1},_h);var le=Gh(75);nh(292,1,{});nh(57,8,Dp,ai);var oe=Gh(57);nh(226,1,{39:1});_.N=Zp;_.R=function(){return new lj(this,0)};_.S=function(){return new vj(null,this.R())};_.P=function(a){throw $g(new ai('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new nj('[',']');for(b=this.O();b.U();){a=b.V();mj(c,a===this?'(this Collection)':a==null?Ep:rh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=Gh(226);nh(230,1,{213:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ld(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new oi((new li(d)).a);c.b;){b=ni(c);if(!di(this,b)){return false}}return true};_.q=function(){return Fi(new li(this))};_.r=function(){var a,b,c;c=new nj('{','}');for(b=new oi((new li(this)).a);b.b;){a=ni(b);mj(c,ei(this,a.X())+'='+ei(this,a.Y()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=Gh(230);nh(142,230,{213:1});var se=Gh(142);nh(229,226,{39:1,237:1});_.R=function(){return new lj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ld(a,24)){return false}b=a;if(ji(b.a)!=this.Q()){return false}return bi(this,b)};_.q=function(){return Fi(this)};var Be=Gh(229);nh(24,229,{24:1,39:1,237:1},li);_.O=function(){return new oi(this.a)};_.Q=Xp;var re=Gh(24);nh(25,1,{},oi);_.T=Wp;_.V=function(){return ni(this)};_.U=Yp;_.b=false;var qe=Gh(25);nh(227,226,{39:1,233:1});_.R=function(){return new lj(this,16)};_.W=function(a,b){throw $g(new ai('Add not supported on this list'))};_.P=function(a){this.W(this.Q(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.Q()!=f.a.length){return false}e=new Ei(f);for(c=new Ei(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return Gi(this)};_.O=function(){return new pi(this)};var ue=Gh(227);nh(89,1,{},pi);_.T=Wp;_.U=function(){return this.a<this.b.a.length};_.V=function(){return wi(this.b,this.a++)};_.a=0;var te=Gh(89);nh(59,226,{39:1},qi);_.O=function(){var a;a=new oi((new li(this.a)).a);return new ri(a)};_.Q=Xp;var we=Gh(59);nh(141,1,{},ri);_.T=Wp;_.U=function(){return this.a.b};_.V=function(){var a;a=ni(this.a);return a.Y()};var ve=Gh(141);nh(139,1,Gp);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Hi(this.a,b.X())&&Hi(this.b,b.Y())};_.X=Tp;_.Y=Yp;_.q=function(){return gj(this.a)^gj(this.b)};_.Z=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var xe=Gh(139);nh(140,139,Gp,si);var ye=Gh(140);nh(231,1,Gp);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Hi(this.b.value[0],b.X())&&Hi(cj(this),b.Y())};_.q=function(){return gj(this.b.value[0])^gj(cj(this))};_.r=function(){return this.b.value[0]+'='+cj(this)};var ze=Gh(231);nh(14,227,{3:1,14:1,39:1,233:1},Ci,Di);_.W=function(a,b){Jj(this.a,a,b)};_.P=function(a){return ui(this,a)};_.N=function(a){vi(this,a)};_.O=function(){return new Ei(this)};_.Q=function(){return this.a.length};var De=Gh(14);nh(16,1,{},Ei);_.T=Wp;_.U=function(){return this.a<this.c.a.length};_.V=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=Gh(16);nh(37,142,{3:1,37:1,213:1},Ii);var Ee=Gh(37);nh(62,1,{},Oi);_.N=Zp;_.O=function(){return new Pi(this)};_.b=0;var Ge=Gh(62);nh(63,1,{},Pi);_.T=Wp;_.V=function(){return this.d=this.a[this.c++],this.d};_.U=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=Gh(63);var Si;nh(60,1,{},aj);_.N=Zp;_.O=function(){return new bj(this)};_.b=0;_.c=0;var Je=Gh(60);nh(61,1,{},bj);_.T=Wp;_.V=function(){return this.c=this.a,this.a=this.b.next(),new dj(this.d,this.c,this.d.c)};_.U=function(){return !this.a.done};var He=Gh(61);nh(148,231,Gp,dj);_.X=function(){return this.b.value[0]};_.Y=function(){return cj(this)};_.Z=function(a){return $i(this.a,this.b.value[0],a)};_.c=0;var Ie=Gh(148);nh(198,1,{});_.T=function(a){ij(this,a)};_.$=function(){return this.d};_._=function(){return this.e};_.d=0;_.e=0;var Le=Gh(198);nh(66,198,{});var Ke=Gh(66);nh(23,1,{},lj);_.$=Tp;_._=function(){kj(this);return this.c};_.T=function(a){kj(this);this.d.T(a)};_.ab=function(a){kj(this);if(this.d.U()){a.w(this.d.V());return true}return false};_.a=0;_.c=0;var Me=Gh(23);nh(56,1,{},nj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ne=Gh(56);nh(197,1,{});_.c=false;var We=Gh(197);nh(28,197,{273:1,28:1},vj);var Ve=Gh(28);nh(200,66,{},zj);_.ab=function(a){this.b=false;while(!this.b&&this.c.ab(new Aj(this,a)));return this.b};_.b=false;var Pe=Gh(200);nh(203,1,{},Aj);_.w=function(a){yj(this.a,this.b,a)};var Oe=Gh(203);nh(199,66,{},Bj);_.ab=function(a){return this.a.ab(new Cj(a))};var Re=Gh(199);nh(202,1,{},Cj);_.w=function(a){this.a.w(on(new pn,a))};var Qe=Gh(202);nh(201,1,{},Ej);_.w=function(a){Dj(this,a)};var Se=Gh(201);nh(204,1,{},Fj);_.w=function(a){};var Te=Gh(204);nh(205,1,{},Hj);_.w=function(a){Gj(this,a)};var Ue=Gh(205);nh(290,1,{});nh(287,1,{});var Oj=0;var Qj,Rj=0,Sj;nh(921,1,{});nh(956,1,{});nh(228,1,{});var Xe=Gh(228);nh(272,$wnd.Function,{},ek);_.cb=function(a){dk(this.a,this.b,a)};nh(7,33,{3:1,31:1,33:1,7:1},Pk);var sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk;var Ye=Hh(7,Qk);var Rk;nh(271,$wnd.Function,{},Tk);_.G=function(a){return Kb(Rk),Rk=null,null};nh(91,228,{});var Kf=Gh(91);nh(92,91,{});_.d=0;var Of=Gh(92);nh(93,92,up,_k);_.t=$p;_.o=Up;_.q=Vp;_.u=_p;_.r=function(){var a;return Ch(hf),hf.k+'@'+(a=Pj(this)>>>0,a.toString(16))};var Xk=0;var hf=Gh(93);nh(95,1,xp,al);_.v=function(){Yk(this.a)};var Ze=Gh(95);nh(94,1,{},cl);var $e=Gh(94);nh(96,1,sp,dl);_.s=function(){return Zk(this.a)};var _e=Gh(96);nh(97,1,Ap,el);_.v=function(){Vk(this.a)};var af=Gh(97);nh(98,1,sp,fl);_.s=function(){return Wk(this.a)};var bf=Gh(98);nh(100,228,{});var Jf=Gh(100);nh(101,100,{});_.c=0;var Nf=Gh(101);nh(102,101,up,ll);_.t=aq;_.o=Up;_.q=Vp;_.u=bq;_.r=function(){var a;return Ch(gf),gf.k+'@'+(a=Pj(this)>>>0,a.toString(16))};var jl=0;var gf=Gh(102);nh(104,1,xp,ml);_.v=cq;var cf=Gh(104);nh(103,1,{},ol);var df=Gh(103);nh(105,1,Ap,pl);_.v=function(){hl(this.a)};var ef=Gh(105);nh(106,1,sp,ql);_.s=function(){return il(this.a)};var ff=Gh(106);nh(129,228,{});_.f='';var Wf=Gh(129);nh(130,129,{});_.d=0;var Qf=Gh(130);nh(131,130,up,Cl);_.t=$p;_.o=Up;_.q=Vp;_.u=_p;_.r=function(){var a;return Ch(pf),pf.k+'@'+(a=Pj(this)>>>0,a.toString(16))};var wl=0;var pf=Gh(131);nh(133,1,xp,Dl);_.v=function(){xl(this.a)};var jf=Gh(133);nh(132,1,{},Fl);var kf=Gh(132);nh(135,1,sp,Gl);_.s=function(){return vl(this.a)};var lf=Gh(135);nh(136,1,xp,Hl);_.v=function(){rl(this.a)};var mf=Gh(136);nh(137,1,xp,Il);_.v=function(){zl(this.a,this.b)};var nf=Gh(137);nh(134,1,Ap,Jl);_.v=function(){Vk(this.a)};var of=Gh(134);nh(108,228,{});_.i=false;var Yf=Gh(108);nh(109,108,{});_.f=0;var Sf=Gh(109);nh(110,109,up,dm);_.t=function(){jc(this.e)};_.o=Up;_.q=Vp;_.u=function(){return this.e.i<0};_.r=function(){var a;return Ch(Bf),Bf.k+'@'+(a=Pj(this)>>>0,a.toString(16))};var Vl=0;var Bf=Gh(110);nh(112,1,xp,em);_.v=function(){Wl(this.a)};var qf=Gh(112);nh(111,1,{},gm);var rf=Gh(111);nh(115,1,sp,hm);_.s=function(){return Ul(this.a)};var sf=Gh(115);nh(42,1,xp,im);_.v=function(){cm(this.a,Nn(this.b))};var tf=Gh(42);nh(113,1,sp,jm);_.s=function(){return Yl(this.a)};var uf=Gh(113);nh(58,1,xp,km);_.v=function(){Ql(this.a,this.b)};var vf=Gh(58);nh(116,1,xp,lm);_.v=function(){Pl(this.a,this.b)};var wf=Gh(116);nh(117,1,xp,mm);_.v=function(){Ol(this.a,this.b)};var xf=Gh(117);nh(118,1,xp,nm);_.v=function(){Kl(this.a,this.b)};var yf=Gh(118);nh(114,1,Ap,om);_.v=function(){Tl(this.a)};var zf=Gh(114);nh(119,1,xp,pm);_.v=function(){Rl(this.a)};var Af=Gh(119);nh(121,228,{});var $f=Gh(121);nh(122,121,{});_.c=0;var Uf=Gh(122);nh(123,122,up,wm);_.t=aq;_.o=Up;_.q=Vp;_.u=bq;_.r=function(){var a;return Ch(Gf),Gf.k+'@'+(a=Pj(this)>>>0,a.toString(16))};var um=0;var Gf=Gh(123);nh(125,1,xp,xm);_.v=cq;var Cf=Gh(125);nh(124,1,{},zm);var Df=Gh(124);nh(126,1,Ap,Am);_.v=function(){hl(this.a)};var Ef=Gh(126);nh(127,1,sp,Bm);_.s=function(){return tm(this.a)};var Ff=Gh(127);nh(253,$wnd.Function,{},Cm);_.gb=function(a){Ho(this.a.f)};nh(186,1,{},Dm);var Hf=Gh(186);var Em;nh(208,1,{},Gm);var If=Gh(208);var Hm;nh(254,$wnd.Function,{},Jm);_.hb=function(a){return new Mm(a)};var Km;nh(99,$wnd.React.Component,{},Mm);mh(kh[1],_);_.componentWillUnmount=function(){Uk(this.a)};_.render=function(){return $k(this.a)};_.shouldComponentUpdate=dq;var Lf=Gh(99);nh(255,$wnd.Function,{},Nm);_.hb=function(a){return new Qm(a)};var Om;nh(107,$wnd.React.Component,{},Qm);mh(kh[1],_);_.componentWillUnmount=function(){gl(this.a)};_.render=function(){return kl(this.a)};_.shouldComponentUpdate=eq;var Mf=Gh(107);nh(269,$wnd.Function,{},Rm);_.hb=function(a){return new Um(a)};var Sm;nh(138,$wnd.React.Component,{},Um);mh(kh[1],_);_.componentWillUnmount=function(){Uk(this.a)};_.render=function(){return Al(this.a)};_.shouldComponentUpdate=dq;var Pf=Gh(138);nh(256,$wnd.Function,{},Vm);_.hb=function(a){return new Ym(a)};var Wm;nh(120,$wnd.React.Component,{},Ym);mh(kh[1],_);_.componentDidUpdate=function(a){_l(this.a)};_.componentWillUnmount=function(){Sl(this.a)};_.render=function(){return am(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Rf=Gh(120);nh(266,$wnd.Function,{},Zm);_.hb=function(a){return new an(a)};var $m;nh(128,$wnd.React.Component,{},an);mh(kh[1],_);_.componentWillUnmount=function(){gl(this.a)};_.render=function(){return vm(this.a)};_.shouldComponentUpdate=eq;var Tf=Gh(128);nh(267,$wnd.Function,{},bn);_.fb=function(a){sl(this.a,a)};nh(268,$wnd.Function,{},cn);_.eb=function(a){yl(this.a,a)};nh(185,1,{},dn);var Vf=Gh(185);var en;nh(263,$wnd.Function,{},gn);_.eb=function(a){Xl(this.a,a)};nh(257,$wnd.Function,{},hn);_.eb=function(a){ho(this.a)};nh(259,$wnd.Function,{},jn);_.gb=function(a){Zl(this.a,this.b)};nh(260,$wnd.Function,{},kn);_.gb=function(a){Ll(this.a,this.b)};nh(261,$wnd.Function,{},ln);_.w=function(a){Ml(this.a,a)};nh(262,$wnd.Function,{},mn);_.db=function(a){$l(this.a,this.b)};nh(264,$wnd.Function,{},nn);_.fb=function(a){Nl(this.a,this.b,a)};nh(207,1,{},pn);var Xf=Gh(207);var qn;nh(265,$wnd.Function,{},sn);_.eb=function(a){qm(this.a,a)};nh(70,1,{},tn);var Zf=Gh(70);var un;nh(83,1,{},wn);var eg=Gh(83);nh(84,1,{},yn);var _f=Gh(84);nh(88,1,{},zn);var ag=Gh(88);nh(87,1,{},An);var bg=Gh(87);nh(85,1,{},Cn);var cg=Gh(85);nh(86,1,{},En);var dg=Gh(86);nh(189,1,{});var Ng=Gh(189);nh(190,189,up,Rn);_.t=$p;_.o=Up;_.q=Vp;_.u=_p;_.r=function(){var a;return Ch(mg),mg.k+'@'+(a=Pj(this)>>>0,a.toString(16))};var mg=Gh(190);nh(191,1,xp,Sn);_.v=function(){Ln(this.a)};var fg=Gh(191);nh(193,1,Ap,Tn);_.v=function(){Gn(this.a)};var gg=Gh(193);nh(194,1,Ap,Un);_.v=function(){Hn(this.a)};var hg=Gh(194);nh(196,1,xp,Vn);_.v=function(){On(this.a)};var ig=Gh(196);nh(64,1,xp,Wn);_.v=function(){Kn(this.a)};var jg=Gh(64);nh(192,1,sp,Xn);_.s=function(){var a;return a=(xh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var kg=Gh(192);nh(195,1,xp,Yn);_.v=function(){Fn(this.a,this.b)};var lg=Gh(195);nh(48,1,{48:1});_.d=false;var Vg=Gh(48);nh(49,48,{9:1,274:1,49:1,48:1},io);_.t=$p;_.o=function(a){return ao(this,a)};_.q=function(){return this.c.d};_.u=_p;_.r=function(){var a;return Ch(Eg),Eg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Zn=0;var Eg=Gh(49);nh(209,1,xp,jo);_.v=function(){$n(this.a)};var ng=Gh(209);nh(210,1,xp,ko);_.v=function(){eo(this.a)};var og=Gh(210);nh(45,157,{45:1});var Qg=Gh(45);nh(158,45,{9:1,45:1},to);_.t=function(){jc(this.f)};_.o=Up;_.q=Vp;_.u=function(){return this.f.i<0};_.r=function(){var a;return Ch(yg),yg.k+'@'+(a=Pj(this)>>>0,a.toString(16))};var yg=Gh(158);nh(160,1,xp,uo);_.v=function(){mo(this.a)};var pg=Gh(160);nh(159,1,xp,vo);_.v=function(){qo(this.a)};var qg=Gh(159);nh(165,1,xp,wo);_.v=function(){dc(this.a,this.b,true)};var rg=Gh(165);nh(166,1,sp,xo);_.s=function(){return lo(this.a,this.c,this.b)};_.b=false;var sg=Gh(166);nh(161,1,sp,yo);_.s=function(){return ro(this.a)};var tg=Gh(161);nh(162,1,sp,zo);_.s=function(){return Rh(eh(rj(po(this.a))))};var ug=Gh(162);nh(163,1,sp,Ao);_.s=function(){return Rh(eh(rj(sj(po(this.a),new kp))))};var vg=Gh(163);nh(164,1,sp,Bo);_.s=function(){return so(this.a)};var wg=Gh(164);nh(145,1,{69:1},Eo);_.F=function(){return new to};var Co;var xg=Gh(145);nh(46,1,{46:1});var Ug=Gh(46);nh(167,46,{9:1,46:1},Lo);_.t=function(){jc(this.a)};_.o=Up;_.q=Vp;_.u=function(){return this.a.i<0};_.r=function(){var a;return Ch(Dg),Dg.k+'@'+(a=Pj(this)>>>0,a.toString(16))};var Dg=Gh(167);nh(168,1,xp,Mo);_.v=function(){Io(this.a,this.b)};_.b=false;var zg=Gh(168);nh(169,1,xp,No);_.v=function(){Qn(this.b,this.a)};var Ag=Gh(169);nh(170,1,xp,Oo);_.v=function(){Jo(this.a)};var Bg=Gh(170);nh(146,1,{69:1},Po);_.F=function(){return new Lo(this.a.F())};var Cg=Gh(146);nh(47,1,{47:1});var Xg=Gh(47);nh(171,47,{9:1,47:1},Yo);_.t=function(){jc(this.g)};_.o=Up;_.q=Vp;_.u=function(){return this.g.i<0};_.r=function(){var a;return Ch(Lg),Lg.k+'@'+(a=Pj(this)>>>0,a.toString(16))};var Lg=Gh(171);nh(172,1,xp,Zo);_.v=function(){So(this.a)};var Fg=Gh(172);nh(173,1,sp,$o);_.s=function(){var a;return a=Nn(this.a.i),Xh(Rp,a)?(hp(),ep):Xh(Sp,a)?(hp(),gp):(hp(),fp)};var Gg=Gh(173);nh(174,1,sp,_o);_.s=function(){return Uo(this.a)};var Hg=Gh(174);nh(175,1,Ap,ap);_.v=function(){Vo(this.a)};var Ig=Gh(175);nh(176,1,Ap,bp);_.v=function(){Wo(this.a)};var Jg=Gh(176);nh(147,1,{69:1},cp);_.F=function(){return new Yo(this.a.F())};var Kg=Gh(147);nh(187,1,{},dp);_.handleEvent=function(a){In(this.a,a)};var Mg=Gh(187);nh(34,33,{3:1,31:1,33:1,34:1},ip);var ep,fp,gp;var Og=Hh(34,jp);nh(151,1,{},kp);_.bb=function(a){return !co(a)};var Pg=Gh(151);nh(153,1,{},lp);_.bb=function(a){return co(a)};var Rg=Gh(153);nh(154,1,{},mp);_.w=function(a){oo(this.a,a)};var Sg=Gh(154);nh(152,1,{},np);_.w=function(a){Go(this.a,a)};_.a=false;var Tg=Gh(152);nh(155,1,{},op);_.bb=function(a){return Ro(this.a,a)};var Wg=Gh(155);var sd=Ih('D');var pp=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=ih;gh(th);jh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();