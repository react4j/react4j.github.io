function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='BDC2BAC8D2B052048AEFE43C77576482',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'BDC2BAC8D2B052048AEFE43C77576482';function p(){}
function Gh(){}
function Ch(){}
function Gb(){}
function Sc(){}
function Zc(){}
function si(){}
function Nj(){}
function _j(){}
function hk(){}
function ik(){}
function Hk(){}
function Yk(){}
function Yo(){}
function Oo(){}
function Xo(){}
function _o(){}
function Fm(){}
function Jm(){}
function Nm(){}
function Rm(){}
function Vm(){}
function pn(){}
function Nn(){}
function Xc(a){Wc()}
function Th(){Th=Ch}
function Vi(){Mi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function hc(a){this.a=a}
function qc(a){this.a=a}
function gi(a){this.a=a}
function ri(a){this.a=a}
function Ei(a){this.a=a}
function Ji(a){this.a=a}
function Ki(a){this.a=a}
function Ii(a){this.b=a}
function Xi(a){this.c=a}
function Oj(a){this.a=a}
function kk(a){this.a=a}
function fl(a){this.a=a}
function gl(a){this.a=a}
function hl(a){this.a=a}
function il(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function El(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function dm(a){this.a=a}
function em(a){this.a=a}
function fm(a){this.a=a}
function gm(a){this.a=a}
function km(a){this.a=a}
function nm(a){this.a=a}
function vm(a){this.a=a}
function wm(a){this.a=a}
function xm(a){this.a=a}
function ym(a){this.a=a}
function Zm(a){this.a=a}
function $m(a){this.a=a}
function cn(a){this.a=a}
function dn(a){this.a=a}
function gn(a){this.a=a}
function on(a){this.a=a}
function Hn(a){this.a=a}
function In(a){this.a=a}
function Jn(a){this.a=a}
function Ln(a){this.a=a}
function Mn(a){this.a=a}
function Zn(a){this.a=a}
function $n(a){this.a=a}
function io(a){this.a=a}
function jo(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function oo(a){this.a=a}
function po(a){this.a=a}
function zo(a){this.a=a}
function Io(a){this.a=a}
function Jo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function cp(a){this.a=a}
function dp(a){this.a=a}
function sp(a){this.a=a}
function tp(a){this.a=a}
function vp(a){this.a=a}
function xp(a){this.a=a}
function gk(a,b){a.a=b}
function rb(a,b){a.b=b}
function Ck(a,b){a.key=b}
function Ak(a,b){zk(a,b)}
function ro(a,b){bm(b,a)}
function Z(a){!!a&&ab(a)}
function lc(a){!!a&&a.t()}
function w(a){--a.e;D(a)}
function _p(a){zj(this,a)}
function eq(a){Cj(this,a)}
function cq(a){ki(this,a)}
function fq(){kc(this.c)}
function hq(){kc(this.b)}
function mq(){kc(this.f)}
function hj(){this.a=qj()}
function vj(){this.a=qj()}
function jq(){lb(this.a.a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function jk(a,b){$j(a.a,b)}
function oc(a,b){Ai(a.e,b)}
function Kl(a,b){co(a.n,b)}
function qo(a,b){bo(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function L(a,b){P(a);M(a,b)}
function jl(a){a.d=2;kc(a.b)}
function Pl(a){a.g=2;kc(a.e)}
function Zk(a){a.e=2;kc(a.c)}
function bl(a){lb(a.b);S(a.a)}
function nh(a){return a.e}
function dq(){return this.e}
function bq(){return this.b}
function Zp(){return this.a}
function Ll(a,b){return a.j=b}
function $p(){return rk(this)}
function mj(){mj=Ch;lj=oj()}
function K(){K=Ch;J=new F}
function yc(){yc=Ch;xc=new p}
function Pc(){Pc=Ch;Oc=new Sc}
function Jh(){Jh=Ch;Ih=new p}
function Qo(){Qo=Ch;Po=new Oo}
function $o(){$o=Ch;Zo=new Yo}
function An(a){S(a.a);ab(a.b)}
function yl(a){lb(a.a);ab(a.b)}
function Pn(a){ab(a.b);ab(a.a)}
function hp(a,b){np(a);M(a,b)}
function tc(a,b){a.e=b;sc(a,b)}
function ok(a,b){a.splice(b,1)}
function jc(a,b,c){zi(a.e,b,c)}
function Qn(a,b,c){jc(a.c,b,c)}
function Hj(a,b,c){b.A(a.a[c])}
function Pi(a,b){return a.a[b]}
function $c(a,b){return ai(a,b)}
function Wh(a){Vh(a);return a.k}
function Sh(a){wc.call(this,a)}
function fi(a){wc.call(this,a)}
function ti(a){wc.call(this,a)}
function li(){rc(this);this.H()}
function aq(){return Ci(this.a)}
function gq(){return this.c.i<0}
function iq(){return this.b.i<0}
function nq(){return this.f.i<0}
function qj(){mj();return new lj}
function Zj(a,b){a.U(b);return a}
function Cj(a,b){while(a.fb(b));}
function $j(a,b){gk(a,Zj(a.a,b))}
function dk(a,b,c){b.A(a.a.T(c))}
function v(a,b,c){t(a,new I(c),b)}
function vh(){th==null&&(th=[])}
function Fc(){Fc=Ch;!!(Wc(),Vc)}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function bb(a){K();Zb(a);a.e=-2}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function U(a){nb(a.f);return W(a)}
function Cn(a){gb(a.b);return a.e}
function Tn(a){gb(a.a);return a.d}
function Do(a){gb(a.d);return a.e}
function Kk(a,b){a.ref=b;return a}
function ic(a,b){this.a=a;this.b=b}
function Li(a,b){this.a=a;this.b=b}
function ck(a,b){this.a=a;this.b=b}
function fk(a,b){this.a=a;this.b=b}
function Kh(a){this.a=Ih;this.b=a}
function Ik(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function Il(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function im(a,b){this.a=a;this.b=b}
function jm(a,b){this.a=a;this.b=b}
function lm(a,b){this.a=a;this.b=b}
function mm(a,b){this.a=a;this.b=b}
function Dm(a){this.a=a;Em=this}
function an(a){this.a=a;bn=this}
function Ci(a){return a.a.b+a.b.b}
function sj(a,b){return a.a.get(b)}
function wp(a,b){return gp(a.a,b)}
function kq(a){return 1==this.a.e}
function lq(a){return 1==this.a.d}
function en(a,b){this.a=a;this.b=b}
function fn(a,b){this.a=a;this.b=b}
function hn(a,b){this.a=a;this.b=b}
function jn(a,b){this.a=a;this.b=b}
function Kn(a,b){this.a=a;this.b=b}
function ko(a,b){this.a=a;this.b=b}
function xo(a,b){this.a=a;this.b=b}
function Vo(a,b){this.a=a;this.b=b}
function yo(a,b){this.b=a;this.a=b}
function ep(a,b){this.b=a;this.a=b}
function Lk(a,b){a.href=b;return a}
function Uk(a,b){a.value=b;return a}
function pi(a,b){a.a+=''+b;return a}
function mk(a,b,c){a.splice(b,0,c)}
function zm(){this.a=Ek((Hm(),Gm))}
function Cm(){this.a=Ek((Lm(),Km))}
function _m(){this.a=Ek((Pm(),Om))}
function ln(){this.a=Ek((Tm(),Sm))}
function qn(){this.a=Ek((Xm(),Wm))}
function Dn(a){Bn(a,(gb(a.b),a.e))}
function Un(a){bm(a,(gb(a.a),!a.d))}
function Ub(a){return !a.d?a:Ub(a.d)}
function yi(a){return !a?null:a.bb()}
function rd(a){return a==null?null:a}
function Bj(a){return a!=null?s(a):0}
function o(a,b){return rd(a)===rd(b)}
function Pk(a,b){a.onBlur=b;return a}
function Mk(a,b){a.onClick=b;return a}
function Ok(a,b){a.checked=b;return a}
function Mc(a){$wnd.clearTimeout(a)}
function Mi(a){a.a=ad(me,Ep,1,0,5,1)}
function Bi(a){a.a=new hj;a.b=new vj}
function ip(a){a.b=0;a.d=0;a.c=false}
function Tl(a){lb(a.b);S(a.c);ab(a.a)}
function gc(a,b){cc(a,b,false);fb(a.c)}
function nk(a,b){lk(b,0,a,0,b.length)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function Ap(a){return wp((zp(),yp),a)}
function $(a){return !(md(a,8)&&a.w())}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function qb(a){K();pb(a);tb(a,2,true)}
function jb(a){this.c=new Vi;this.b=a}
function rp(){this.d=new op;this.b=100}
function vk(){vk=Ch;sk=new p;uk=new p}
function zp(){zp=Ch;yp=new xp(new rp)}
function to(a,b){Oi(ec(a.b),new bp(b))}
function zk(a,b){for(var c in a){b(c)}}
function Qk(a,b){a.onChange=b;return a}
function Rk(a,b){a.onKeyDown=b;return a}
function Bk(a,b){a.props['a']=b;return a}
function mi(a,b){return a.charCodeAt(b)}
function md(a,b){return a!=null&&kd(a,b)}
function ed(a,b,c){return {l:a,m:b,h:c}}
function rk(a){return a.$H||(a.$H=++qk)}
function Nk(a){return a.autoFocus=true,a}
function od(a){return typeof a==='number'}
function qd(a){return typeof a==='string'}
function nd(a){return typeof a==='boolean'}
function Tk(a){a.type='checkbox';return a}
function Vh(a){if(a.k!=null){return}ci(a)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function fc(a,b){oc(b.c,a);md(b,8)&&b.v()}
function wc(a){this.g=a;rc(this);this.H()}
function Yj(a,b){Rj.call(this,a);this.a=b}
function mn(a,b){this.a=a;this.b=b;nn=this}
function bj(){this.a=new hj;this.b=new vj}
function Q(){this.a=ad(me,Ep,1,100,5,1)}
function op(){this.a=ad(me,Ep,1,100,5,1)}
function ji(){ji=Ch;ii=ad(ie,Ep,26,256,0,1)}
function jj(a,b){var c;c=a[Pp];c.call(a,b)}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function Gc(a,b,c){return a.apply(b,c);var d}
function go(a){return hi(T(a.e).a-T(a.a).a)}
function Co(a){lb(a.a);S(a.b);S(a.c);ab(a.d)}
function so(a){A((K(),K(),J),new zo(a),Sp)}
function _l(a){A((K(),K(),J),new nm(a),Sp)}
function En(a){A((K(),K(),J),new Ln(a),Sp)}
function Xn(a){A((K(),K(),J),new $n(a),Sp)}
function zj(a,b){while(a.Z()){jk(b,a.$())}}
function Db(a){while(true){if(!Cb(a)){break}}}
function pp(a){while(true){if(!qp(a)){break}}}
function Fj(a,b){while(a.c<a.d){Hj(a,b,a.c++)}}
function yj(a,b,c){this.a=a;this.b=b;this.c=c}
function Vk(a,b){a.onDoubleClick=b;return a}
function Ni(a,b){a.a[a.a.length]=b;return true}
function rc(a){a.j&&a.e!==Kp&&a.H();return a}
function Zh(a){var b;b=Yh(a);ei(a,b);return b}
function Wc(){Wc=Ch;var a;!Yc();a=new Zc;Vc=a}
function Qh(a,b,c,d){a.addEventListener(b,c,d)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Al(a,b){A((K(),K(),J),new Il(a,b),Sp)}
function Vl(a,b){A((K(),K(),J),new mm(a,b),Sp)}
function Zl(a,b){A((K(),K(),J),new jm(a,b),Sp)}
function $l(a,b){A((K(),K(),J),new im(a,b),Sp)}
function am(a,b){A((K(),K(),J),new hm(a,b),Sp)}
function co(a,b){A((K(),K(),J),new ko(a,b),Sp)}
function vo(a,b){A((K(),K(),J),new xo(a,b),Sp)}
function Bl(a,b){var c;c=b.target;Cl(a,c.value)}
function Sj(a,b){var c;return Wj(a,(c=new Vi,c))}
function _h(a){var b;b=Yh(a);b.j=a;b.e=1;return b}
function Nh(a){if(!a){throw nh(new li)}return a}
function up(a){if(a.a){Fb(Wk);Wk=null;a.a=null}}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function Jj(a){if(!a.d){a.d=a.b.S();a.c=a.b.V()}}
function Gi(a){var b;b=a.a.$();a.b=Fi(a);return b}
function eo(a){ki(new Ji(a.g),new hc(a));Bi(a.g)}
function Ao(a){return o(Xp,a)||o(Yp,a)||o('',a)}
function Zi(a){return new Yj(null,Yi(a,a.length))}
function cd(a){return Array.isArray(a)&&a.qb===Gh}
function ld(a){return !Array.isArray(a)&&a.qb===Gh}
function rj(a,b){return !(a.a.get(b)===undefined)}
function Yi(a,b){return Dj(b,a.length),new Ij(a,b)}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ri(a,b){var c;c=a.a[b];ok(a.a,b);return c}
function ak(a,b,c){if(a.a.hb(c)){a.b=true;b.A(c)}}
function lo(a,b){this.a=a;this.c=b;this.b=false}
function fo(a){return Th(),0!=T(a.e).a?true:false}
function dl(a){return Th(),T(a.f.b).a>0?true:false}
function nl(a){return B((K(),K(),J),a.a,new rl(a))}
function zl(a){return B((K(),K(),J),a.a,new Fl(a))}
function cl(a){return B((K(),K(),J),a.b,new hl(a))}
function Ul(a){return B((K(),K(),J),a.b,new fm(a))}
function tm(a){return B((K(),K(),J),a.a,new xm(a))}
function Wl(a){return Th(),Do(a.o)==a.i?true:false}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function ao(a){S(a.d);S(a.e);S(a.a);S(a.b);ab(a.c)}
function _k(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function ll(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Rl(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function Pj(a){if(!a.b){Qj(a);a.c=true}else{Pj(a.b)}}
function Cl(a,b){var c;c=a.g;if(b!=c){a.g=b;fb(a.b)}}
function Fn(a,b){var c;c=a.e;if(b!=c){a.e=b;fb(a.b)}}
function bm(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function om(a,b){var c;c=b.target;vo(a.f,c.checked)}
function Ti(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Di(a,b){if(b){return wi(a.a,b)}return false}
function Vj(a,b){Qj(a);return new Yj(a,new ek(b,a.a))}
function Uj(a,b){Qj(a);return new Yj(a,new bk(b,a.a))}
function Bn(a,b){A((K(),K(),J),new Kn(a,b),75497472)}
function Rh(a,b,c,d){a.removeEventListener(b,c,d)}
function Am(a,b,c){this.a=a;this.b=b;this.c=c;Bm=this}
function rn(a,b,c){this.a=a;this.b=b;this.c=c;sn=this}
function Ij(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Ej(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function aj(a,b){return rd(a)===rd(b)||a!=null&&q(a,b)}
function zn(a){var b;V(a.a);b=T(a.a);o(a.f,b)&&Fn(a,b)}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&Ip)&&D((null,J))}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function Xl(a,b){Go(a.o,b);A((K(),K(),J),new hm(a,b),Sp)}
function Wo(){Uo();return dd($c(Sg,1),Ep,27,0,[Ro,To,So])}
function Ph(){Ph=Ch;Oh=$wnd.goog.global.document}
function yk(){if(tk==256){sk=uk;uk=new p;tk=0}++tk}
function sh(a){if(od(a)){return a|0}return a.l|a.m<<22}
function bi(a){if(a.Q()){return null}var b=a.j;return yh[b]}
function Rj(a){if(!a){this.b=null;new Vi}else{this.b=a}}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function Jl(a,b){var c;if(T(a.c)){c=b.target;bm(a,c.value)}}
function uc(a,b){var c;c=Wh(a.ob);return b==null?c:c+': '+b}
function $h(a,b){var c;c=Yh(a);ei(a,c);c.e=b?8:0;return c}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function Kj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function xi(a,b){return b===a?'(this Map)':b==null?Mp:Fh(b)}
function ki(a,b){var c,d;for(d=a.S();d.Z();){c=d.$();b.A(c)}}
function ai(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.L(b))}
function Yl(a,b){A((K(),K(),J),new hm(a,b),Sp);Go(a.o,null)}
function Xk(){if(!Wk){Wk=(++(K(),K(),J).e,new Gb);Ap(new Yk)}}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function vn(a){Qh((Ph(),$wnd.goog.global.window),Vp,a.d,false)}
function wn(a){Rh((Ph(),$wnd.goog.global.window),Vp,a.d,false)}
function Hm(){Hm=Ch;var a;Gm=(a=Dh(Fm.prototype.nb,Fm,[]),a)}
function Lm(){Lm=Ch;var a;Km=(a=Dh(Jm.prototype.nb,Jm,[]),a)}
function Pm(){Pm=Ch;var a;Om=(a=Dh(Nm.prototype.nb,Nm,[]),a)}
function Tm(){Tm=Ch;var a;Sm=(a=Dh(Rm.prototype.nb,Rm,[]),a)}
function Xm(){Xm=Ch;var a;Wm=(a=Dh(Vm.prototype.nb,Vm,[]),a)}
function Eh(a){function b(){}
;b.prototype=a||{};return new b}
function Lh(a){Jh();Nh(a);if(md(a,43)){return a}return new Kh(a)}
function dj(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function ej(a,b){var c;return cj(b,dj(a,b==null?0:(c=s(b),c|0)))}
function dc(a){gb(a.c);return new Yj(null,new Kj(new Ji(a.g),0))}
function xn(a,b){b.preventDefault();A((K(),K(),J),new Mn(a),Sp)}
function ek(a,b){Ej.call(this,b.eb(),b.db()&-6);this.a=a;this.b=b}
function ij(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function wo(a){this.b=a;K();this.a=new pc(0,null,null,false,false)}
function Wi(a){Mi(this);nk(this.a,vi(a,ad(me,Ep,1,Ci(a.a),5,1)))}
function nc(a){lc(a.g);!!a.e&&mc(a);Z(a.a);Z(a.c);lc(a.b);lc(a.f)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Gj(a,b){if(a.c<a.d){Hj(a,b,a.c++);return true}return false}
function Sk(a){a.placeholder='What needs to be done?';return a}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ah(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Gk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function bo(a,b){var c;return u((K(),K(),J),new lo(a,b),Sp,(c=null,c))}
function cb(a,b){var c,d;Ni(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Wj(a,b){var c;Pj(a);c=new hk;c.a=b;a.a.Y(new kk(c));return c.a}
function Tj(a){var b;Pj(a);b=0;while(a.a.fb(new ik)){b=oh(b,1)}return b}
function Lj(a,b){!a.a?(a.a=new ri(a.d)):pi(a.a,a.b);pi(a.a,b);return a}
function Ai(a,b){return qd(b)?b==null?gj(a.a,null):uj(a.b,b):gj(a.a,b)}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function uo(a){Sj(Uj(dc(a.b),new _o),new Oj(new Nj)).R(new ap(a.b))}
function bk(a,b){Ej.call(this,b.eb(),b.db()&-16449);this.a=a;this.c=b}
function wj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Mj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Mm(a){$wnd.React.Component.call(this,a);this.a=new ol(this,Em.a)}
function Qm(a){$wnd.React.Component.call(this,a);this.a=new Dl(this,bn.a)}
function Hi(a){this.d=a;this.c=new wj(this.d.b);this.a=this.c;this.b=Fi(this)}
function Xj(a,b){var c;c=Sj(a,new Oj(new Nj));return Ui(c,b.gb(c.a.length))}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function xj(a){if(a.a.c!=a.c){return sj(a.a,a.b.value[0])}return a.b.value[1]}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Qi(a,b,c){for(;c<a.a.length;++c){if(aj(b,a.a[c])){return c}}return -1}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function Rn(a,b){var c;if(md(b,50)){c=b;return a.c.d==c.c.d}else{return false}}
function Oi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.A(c)}}
function sl(a){var b;b=oi((gb(a.b),a.g));if(b.length>0){qo(a.f,b);Cl(a,'')}}
function Eo(a){var b;return b=T(a.b),Sj(Uj(dc(a.i),new dp(b)),new Oj(new Nj))}
function Bo(a,b){return (Uo(),So)==a||(Ro==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function zi(a,b,c){return qd(b)?b==null?fj(a.a,null,c):tj(a.b,b,c):fj(a.a,b,c)}
function pk(a,b){return _c(b)!=10&&dd(r(b),b.pb,b.__elementTypeId$,_c(b),a),a}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Um(a){$wnd.React.Component.call(this,a);this.a=new cm(this,nn.a,nn.b)}
function Jb(b){try{nb(b.b.a)}catch(a){a=mh(a);if(!md(a,4))throw nh(a)}}
function sb(b){if(b){try{b.t()}catch(a){a=mh(a);if(md(a,4)){K()}else throw nh(a)}}}
function W(a){if(a.b){if(md(a.b,6)){throw nh(a.b)}else{throw nh(a.b)}}return a.k}
function Si(a,b){var c;c=Qi(a,b,0);if(c==-1){return false}ok(a.a,c);return true}
function fp(b){var c;c=kp(b.d);try{up(c)}catch(a){a=mh(a);if(!md(a,4))throw nh(a)}}
function un(a,b){a.f=b;o(b,T(a.a))&&Fn(a,b);yn(b);A((K(),K(),J),new Mn(a),Sp)}
function tl(a,b){if(13==b.keyCode){b.preventDefault();A((K(),K(),J),new Gl(a),Sp)}}
function kc(a){if(a.i>=0){a.i=-2;u((K(),K(),J),new H(new qc(a)),67108864,null)}}
function ab(a){if(-2!=a.e){u((K(),K(),J),new H(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function S(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function Qc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Uc(b,c)}while(a.a);a.a=c}}
function Rc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Vi);Ni(a.b,b)}}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function Pb(){var a;this.a=ad(yd,Ep,42,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function uh(){vh();var a=th;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Yh(a){var b;b=new Xh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function kn(a,b){Ck(a.a,(b?hi(b.c.d):null)+(''+(Vh(fg),fg.k)));Bk(a.a,b);return a.a}
function ei(a,b){var c;if(!a){return}b.j=a;var d=bi(b);if(!d){yh[a]=[b];return}d.ob=b}
function Dh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function uj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{jj(a.a,b);--a.b}return c}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Vi);a.c=c.c}b.d=true;Ni(a.c,b)}
function pb(a){var b,c;for(c=new Xi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function $i(a){var b,c,d;d=0;for(c=new Hi(a.a);c.b;){b=Gi(c);d=d+(b?s(b):0);d=d|0}return d}
function Ek(a){var b;b=Dk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Ym(a){$wnd.React.Component.call(this,a);this.a=new um(this,sn.a,sn.b,sn.c)}
function Im(a){$wnd.React.Component.call(this,a);this.a=new el(this,Bm.a,Bm.b,Bm.c)}
function pd(a){return a!=null&&(typeof a===Cp||typeof a==='function')&&!(a.qb===Gh)}
function xh(a,b){typeof window===Cp&&typeof window['$gwt']===Cp&&(window['$gwt'][a]=b)}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Jp:0)|(0!=(b&229376)?0:98304)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:Gp)|(0==(c&6291456)?!a?Ip:Jp:0)|0|0|0)}
function ui(a,b){var c,d;for(d=new Hi(b.a);d.b;){c=Gi(d);if(!Di(a,c)){return false}}return true}
function _n(a,b,c){var d;d=new Yn(b,c);Qn(d,a,new ic(a,d));zi(a.g,hi(d.c.d),d);fb(a.c);return d}
function cc(a,b,c){var d;d=Ai(a.g,b?hi(b.c.d):null);if(null!=d){oc(b.c,a);c&&!!b&&kc(b.c);fb(a.c)}}
function Fo(a){var b;b=T(a.g.a);o(Xp,b)||o(Yp,b)||o('',b)?Bn(a.g,b):Ao(Cn(a.g))?En(a.g):Bn(a.g,'')}
function ec(a){return gb(a.c),Sj(new Yj(null,new Kj(new Ji(a.g),0)),new Oj(new Nj))}
function Uo(){Uo=Ch;Ro=new Vo('ACTIVE',0);To=new Vo('COMPLETED',1);So=new Vo('ALL',2)}
function Dj(a,b){if(0>a||a>b){throw nh(new Sh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Fi(a){if(a.a.Z()){return true}if(a.a!=a.c){return false}a.a=new ij(a.d.a);return a.a.Z()}
function mh(a){var b;if(md(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function ph(a){var b;b=a.h;if(b==0){return a.l+a.m*Jp}if(b==1048575){return a.l+a.m*Jp-Np}return a}
function rh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Np;d=1048575}c=sd(e/Jp);b=sd(e-c*Jp);return ed(b,c,d)}
function cj(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(aj(a,c.ab())){return c}}return null}
function dd(a,b,c,d,e){e.ob=a;e.pb=b;e.qb=Gh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function tj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Go(a,b){var c;c=a.e;if(!(b==c||!!b&&Rn(b,c))){!!c&&oc(c.c,a);a.e=b;!!b&&Qn(b,a,new Jo(a));fb(a.d)}}
function db(a,b){var c,d;d=a.c;Si(d,b);!!a.b&&Gp!=(a.b.c&Hp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function Ol(a){var b;b=T(a.c);if(!a.k&&b){a.k=true;am(a,a.i);a.j.focus();a.j.select()}else a.k&&!b&&(a.k=false)}
function hi(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ji(),ii)[b];!c&&(c=ii[b]=new gi(a));return c}return new gi(a)}
function Fh(a){var b;if(Array.isArray(a)&&a.qb===Gh){return Wh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function Ml(a,b,c){27==c.which?A((K(),K(),J),new lm(a,b),Sp):13==c.which&&A((K(),K(),J),new im(a,b),Sp)}
function Ac(a){yc();rc(this);this.e=a;sc(this,a);this.g=a==null?Mp:Fh(a);this.a='';this.b=a;this.a=''}
function Xh(){this.g=Uh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function tn(){this.a=Lh(($o(),Zo));this.b=Lh(new cp(this.a));this.c=Lh((Qo(),Po));this.d=Lh(new ep(this.a,this.c))}
function Qj(a){if(a.b){Qj(a.b)}else if(a.c){throw nh(new fi("Stream already terminated, can't be modified or used"))}}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Gp)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function r(a){return qd(a)?pe:od(a)?de:nd(a)?be:ld(a)?a.ob:cd(a)?a.ob:a.ob||Array.isArray(a)&&$c(Ud,1)||Ud}
function s(a){return qd(a)?xk(a):od(a)?sd(a):nd(a)?a?1231:1237:ld(a)?a.r():cd(a)?rk(a):!!a&&!!a.hashCode?a.hashCode():rk(a)}
function oh(a,b){var c;if(od(a)&&od(b)){c=a+b;if(-17592186044416<c&&c<Np){return c}}return ph(fd(od(a)?rh(a):a,od(b)?rh(b):b))}
function fd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ed(c&4194303,d&4194303,e&1048575)}
function np(a){var b,c;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){c=$wnd.Math.max(a.a.length-1,1)*2+1;lp(a,c,b)}}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function _i(a){var b,c,d;d=1;for(c=new Xi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function xk(a){vk();var b,c,d;c=':'+a;d=uk[c];if(d!=null){return sd(d)}d=sk[c];b=d==null?wk(a):sd(d);yk();uk[c]=b;return b}
function gp(a,b){var c,d;d=0==O(a.d);c=new vp(b);hp(a.d,c);d&&$wnd.Promise.resolve(null).then(Dh(sp.prototype.K,sp,[a]));return c}
function Ui(a,b){var c,d;d=a.a.length;b.length<d&&(b=pk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function di(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(Gp==(b&Hp)?0:524288)|(0==(b&6291456)?Gp==(b&Hp)?Jp:Ip:0)|0|268435456|0)}
function Nl(a,b){var c;c=(gb(a.a),a.d);if(null!=c&&c.length!=0){A((K(),K(),J),new yo(b,c),Sp);Go(a.o,null);bm(a,c)}else{co(a.n,b)}}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=Ri(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function mc(a){var b,c,d;for(c=new Xi(new Wi(new Ei(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.ab();md(d,8)&&d.w()||b.bb().t()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Xi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Xi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function ol(a,b){var c;this.e=b;this.c=a;K();c=++ml;this.b=new pc(c,null,new pl(this),false,false);this.a=new wb(null,new ql(this),Rp)}
function pc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new bj:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new jb((f=null,K(),f)),g):null;this.c=null}
function q(a,b){return qd(a)?o(a,b):od(a)?rd(a)===rd(b):nd(a)?rd(a)===rd(b):ld(a)?a.p(b):cd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function kd(a,b){if(qd(a)){return !!jd[b]}else if(a.pb){return !!a.pb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function Jk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function kp(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}else{b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}}
function qp(a){var b;if(0==a.c){b=O(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;ip(a.d);return false}else{a.a=a.a+1;a.c=b}}--a.c;fp(a);return true}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function T(a){a.j?hb(a.e):gb(a.e);if(ub(a.f)){if(a.j&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function lp(a,b,c){var d,e,f,g;d=ad(me,Ep,1,b,5,1);g=0;for(e=0;e<c;e++){f=(a.b+e)%a.a.length;d[g]=a.a[f];a.a[f]=null;++g}a.a=d;a.b=0;a.d=g;a.c=false}
function oi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function vi(a,b){var c,d,e,f;f=Ci(a.a);b.length<f&&(b=pk(new Array(f),b));e=b;d=new Hi(a.a);for(c=0;c<f;++c){e[c]=Gi(d)}b.length>f&&(b[f]=null);return b}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.t(),null)}finally{bc()}return f}catch(a){a=mh(a);if(md(a,4)){e=a;throw nh(e)}else throw nh(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.u()}else{ac(b,e);try{g=c.u()}finally{bc()}}return g}catch(a){a=mh(a);if(md(a,4)){f=a;throw nh(f)}else throw nh(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.i=c;this.k=null;this.j=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);Gp==(d&Hp)&&mb(this.f)}
function um(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.c=a;K();e=++sm;this.b=new pc(e,null,new vm(this),false,false);this.a=new wb(null,new wm(this),Rp)}
function Dl(a,b){var c,d,e;this.f=b;this.d=a;K();c=++xl;this.c=new pc(c,null,new El(this),false,false);this.b=(e=new jb((d=null,d)),e);this.a=new wb(null,new Hl(this),Rp)}
function Yn(a,b){var c,d,e,f,g;this.e=a;this.d=b;K();c=++On;this.c=new pc(c,null,new Zn(this),true,true);this.b=(g=new jb((e=null,e)),g);this.a=(f=new jb((d=null,d)),f)}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Xi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function wh(b,c,d,e){vh();var f=th;$moduleName=c;$moduleBase=d;lh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Bp(g)()}catch(a){b(c,a)}}else{Bp(g)()}}
function Dk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function oj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return pj()}}
function kl(a){var b,c;a.d=0;Xk();c=(b=T(a.e.e).a,Fk('span',Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,['todo-count'])),[Fk('strong',null,[b]),' item'+(b==1?'':'s')+' left']));return c}
function zh(){yh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].rb()&&(c=Tc(c,g)):g[0].rb()}catch(a){a=mh(a);if(md(a,4)){d=a;Fc();Lc(md(d,32)?d.I():d)}else throw nh(a)}}return c}
function vl(a){var b;a.e=0;Xk();b=Fk(Tp,Nk(Qk(Rk(Uk(Sk(Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,['new-todo']))),(gb(a.b),a.g)),Dh(Zm.prototype.lb,Zm,[a])),Dh($m.prototype.kb,$m,[a]))),null);return b}
function zc(a){var b;if(a.c==null){b=rd(a.b)===rd(xc)?null:a.b;a.d=b==null?Mp:pd(b)?b==null?null:b.name:qd(b)?'String':Wh(r(b));a.a=a.a+': '+(pd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.k;try{d=b.c.u();if(!(rd(e)===rd(d)||e!=null&&q(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=mh(a);if(md(a,9)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw nh(c)}else throw nh(a)}}
function lk(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function fj(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=cj(b,e);if(f){return f.cb(c)}}e[e.length]=new Li(b,c);++a.b;return null}
function el(a,b,c,d){var e;this.f=b;this.g=c;this.i=d;this.d=a;K();e=++al;this.c=new pc(e,null,new fl(this),false,false);this.a=new X(new gl(this),null,null,136478720);this.b=new wb(null,new il(this),Rp)}
function wk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+mi(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{b.e.t()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=mh(a);if(md(a,4)){K()}else throw nh(a)}}}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=ad(me,Ep,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Mh(a,b){var c;c=rd(a)!==rd(Ih);if(c&&rd(a)!==rd(b)){throw nh(new fi('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}return b}
function vb(a,b,c,d){this.b=new Vi;this.f=new Kb(new zb(this),d&6520832|262144|Gp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&Ip)&&D((null,J)))}
function Hh(){var a;a=new tn;new Am(a.a.J(),a.b.J(),a.d.J());new mn(a.a.J(),(a.b.J(),a.d.J()));new rn(a.a.J(),a.b.J(),a.d.J());new an(a.b.J());new Dm(a.a.J());$wnd.ReactDOM.render((new qn).a,(Ph(),Oh).getElementById('app'),null)}
function gj(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(aj(b,e.ab())){if(d.length==1){d.length=0;jj(a.a,g)}else{d.splice(h,1)}--a.b;return e.bb()}}return null}
function Bh(a,b,c){var d=yh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=yh[b]),Eh(h));_.pb=c;!b&&(_.qb=Gh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ob=f)}
function ci(a){if(a.P()){var b=a.c;b.Q()?(a.k='['+b.j):!b.P()?(a.k='[L'+b.N()+';'):(a.k='['+b.N());a.b=b.M()+'[]';a.i=b.O()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=di('.',[c,di('$',d)]);a.b=di('.',[c,di('.',d)]);a.i=d[d.length-1]}
function yn(a){var b;if(0==a.length){b=(Ph(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Oh.title,b)}else{(Ph(),$wnd.goog.global.window).location.hash=a}}
function wi(a,b){var c,d,e;c=b.ab();e=b.bb();d=qd(c)?c==null?yi(ej(a.a,null)):sj(a.b,c):yi(ej(a.a,c));if(!(rd(e)===rd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(qd(c)?c==null?!!ej(a.a,null):rj(a.b,c):!!ej(a.a,c))){return false}return true}
function Ho(a,b){var c,d;this.i=a;this.g=b;K();this.f=new pc(0,null,new Io(this),false,false);this.d=(d=new jb((c=null,c)),d);this.b=new X(new Ko(this),null,null,Wp);this.c=new X(new Lo(this),null,null,Wp);this.a=new wb(new Mo(this),null,681574400);D((null,J))}
function ho(){var a;this.g=new bj;K();this.f=new pc(0,new jo(this),new io(this),false,false);this.c=(a=new jb(null),a);this.d=new X(new mo(this),null,null,Wp);this.e=new X(new no(this),null,null,Wp);this.a=new X(new oo(this),null,null,Wp);this.b=new X(new po(this),null,null,Wp)}
function Gn(){var a,b,c;this.d=new No(this);this.f=this.e=(c=(Ph(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));K();this.c=new pc(0,null,new Hn(this),false,false);this.b=(b=new jb((a=null,a)),b);this.a=new X(new Nn,new In(this),new Jn(this),35651584)}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Xi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=mh(a);if(!md(a,4))throw nh(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.F();return a&&a.C()}},suppressed:{get:function(){return c.D()}}})}catch(a){}}}
function cm(a,b,c){var d,e,f;this.n=b;this.o=c;this.f=a;this.i=a.props['a'];K();d=++Sl;this.e=new pc(d,null,new dm(this),false,false);this.a=(f=new jb((e=null,e)),f);this.c=new X(new gm(this),null,null,136478720);this.b=new wb(null,new km(this),Rp);Qn(this.i,this,new em(this));am(this,this.i);D((null,J))}
function Fk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Ak(b,Dh(Ik.prototype.ib,Ik,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=Dk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function nj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}Oi(a.b,new Bb(a));a.b.a=ad(me,Ep,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function qm(a){var b;a.d=0;Xk();b=Fk('div',null,[Fk('div',null,[Fk(Up,Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,[Up])),[Fk('h1',null,['todos']),(new _m).a]),T(a.e.d)?Fk('section',Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,[Up])),[Fk(Tp,Qk(Tk(Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,['toggle-all']))),Dh(on.prototype.kb,on,[a])),null),Fk('ul',Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,['todo-list'])),Xj(Vj(T(a.g.c).X(),new pn),new Hk))]):null,T(a.e.d)?(new zm).a:null])]);return b}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Pi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ti(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Pi(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ri(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Vi)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Gp!=(k.b.c&Hp)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function $k(a){var b,c;a.e=0;Xk();c=(b=T(a.i.b),Fk('footer',Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,['footer'])),[(new Cm).a,Fk('ul',Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,['filters'])),[Fk('li',null,[Fk('a',Lk(Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,[(Uo(),So)==b?Qp:null])),'#'),['All'])]),Fk('li',null,[Fk('a',Lk(Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,[Ro==b?Qp:null])),'#active'),['Active'])]),Fk('li',null,[Fk('a',Lk(Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,[To==b?Qp:null])),'#completed'),['Completed'])])]),T(a.a)?Fk('button',Mk(Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,['clear-completed'])),Dh(ym.prototype.mb,ym,[a])),['Clear Completed']):null]));return c}
function Ql(a){var b,c,d;a.g=0;Xk();b=(c=a.i,d=(gb(c.a),c.d),Fk('li',Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,[d?'checked':null,T(a.c)?'editing':null])),[Fk('div',Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,['view'])),[Fk(Tp,Qk(Ok(Tk(Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,['toggle']))),d),Dh(dn.prototype.kb,dn,[c])),null),Fk('label',Vk(new $wnd.Object,Dh(en.prototype.mb,en,[a,c])),[(gb(c.b),c.e)]),Fk('button',Mk(Jk(new $wnd.Object,dd($c(pe,1),Ep,2,6,['destroy'])),Dh(fn.prototype.mb,fn,[a,c])),null)]),Fk(Tp,Rk(Qk(Pk(Uk(Jk(Kk(new $wnd.Object,Dh(gn.prototype.A,gn,[a])),dd($c(pe,1),Ep,2,6,['edit'])),(gb(a.a),a.d)),Dh(hn.prototype.jb,hn,[a,c])),Dh(cn.prototype.kb,cn,[a])),Dh(jn.prototype.lb,jn,[a,c])),null)]));return b}
function pj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Pp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!nj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Pp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Cp='object',Dp={5:1},Ep={3:1},Fp={8:1},Gp=1048576,Hp=1835008,Ip=2097152,Jp=4194304,Kp='__noinit__',Lp={3:1,9:1,6:1,4:1},Mp='null',Np=17592186044416,Op={38:1},Pp='delete',Qp='selected',Rp=1411518464,Sp=142606336,Tp='input',Up='header',Vp='hashchange',Wp=136314880,Xp='active',Yp='completed';var _,yh,th,lh=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;zh();Bh(1,null,{},p);_.p=function(a){return o(this,a)};_.q=function(){return this.ob};_.r=$p;_.s=function(){var a;return Wh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.p(a)};_.hashCode=function(){return this.r()};_.toString=function(){return this.s()};var gd,hd,jd;Bh(55,1,{},Xh);_.L=function(a){var b;b=new Xh;b.e=4;a>1?(b.c=ai(this,a-1)):(b.c=this);return b};_.M=function(){Vh(this);return this.b};_.N=function(){return Wh(this)};_.O=function(){Vh(this);return this.i};_.P=function(){return (this.e&4)!=0};_.Q=function(){return (this.e&1)!=0};_.s=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Vh(this),this.k)};_.e=0;_.g=0;var Uh=1;var me=Zh(1);var ce=Zh(55);Bh(82,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var xd=Zh(82);Bh(83,1,Dp,G);_.t=function(){Db(this.a)};var ud=Zh(83);Bh(33,1,{},H);_.u=function(){return this.a.t(),null};var vd=Zh(33);Bh(84,1,{},I);var wd=Zh(84);var J;Bh(42,1,{42:1},Q);_.b=0;_.c=false;_.d=0;var yd=Zh(42);Bh(241,1,Fp);_.s=function(){var a;return Wh(this.ob)+'@'+(a=s(this)>>>0,a.toString(16))};var Bd=Zh(241);Bh(17,241,Fp,X);_.v=function(){S(this)};_.w=Zp;_.a=false;_.d=0;_.j=false;var Ad=Zh(17);Bh(165,1,{},Y);_.u=function(){return U(this.a)};var zd=Zh(165);Bh(15,241,{8:1,15:1},jb);_.v=function(){ab(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Dd=Zh(15);Bh(164,1,Dp,kb);_.t=function(){bb(this.a)};var Cd=Zh(164);Bh(16,241,{8:1,16:1},wb,xb);_.v=function(){lb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Id=Zh(16);Bh(166,1,{},yb);_.t=function(){R(this.a)};var Ed=Zh(166);Bh(167,1,Dp,zb);_.t=function(){nb(this.a)};var Fd=Zh(167);Bh(168,1,Dp,Ab);_.t=function(){qb(this.a)};var Gd=Zh(168);Bh(169,1,{},Bb);_.A=function(a){ob(this.a,a)};var Hd=Zh(169);Bh(104,1,{},Eb);_.a=0;_.b=0;_.c=0;var Jd=Zh(104);Bh(170,1,Fp,Gb);_.v=function(){Fb(this)};_.w=Zp;_.a=false;var Kd=Zh(170);Bh(65,241,{8:1,65:1},Kb);_.v=function(){Hb(this)};_.w=function(){return 2==(3&this.a)};_.a=0;var Md=Zh(65);Bh(103,1,{},Pb);var Ld=Zh(103);Bh(175,1,{},_b);_.s=function(){var a;return Vh(Nd),Nd.k+'@'+(a=rk(this)>>>0,a.toString(16))};_.a=0;var Qb;var Nd=Zh(175);Bh(146,1,{});var Qd=Zh(146);Bh(110,1,{},hc);_.A=function(a){fc(this.a,a)};var Od=Zh(110);Bh(111,1,Dp,ic);_.t=function(){gc(this.a,this.b)};var Pd=Zh(111);Bh(14,1,Fp,pc);_.v=function(){kc(this)};_.w=function(){return this.i<0};_.s=function(){var a;return Vh(Sd),Sd.k+'@'+(a=rk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Sd=Zh(14);Bh(156,1,Dp,qc);_.t=function(){nc(this.a)};var Rd=Zh(156);Bh(4,1,{3:1,4:1});_.B=function(a){return new Error(a)};_.C=dq;_.D=function(){return Xj(Vj(Zi((this.i==null&&(this.i=ad(re,Ep,4,0,0,1)),this.i)),new si),new _j)};_.F=function(){return this.f};_.G=function(){return this.g};_.H=function(){tc(this,vc(this.B(uc(this,this.g))));Xc(this)};_.s=function(){return uc(this,this.G())};_.e=Kp;_.j=true;var re=Zh(4);Bh(9,4,{3:1,9:1,4:1});var fe=Zh(9);Bh(6,9,Lp);var ne=Zh(6);Bh(56,6,Lp);var je=Zh(56);Bh(79,56,Lp);var Wd=Zh(79);Bh(32,79,{32:1,3:1,9:1,6:1,4:1},Ac);_.G=function(){zc(this);return this.c};_.I=function(){return rd(this.b)===rd(xc)?null:this.b};var xc;var Td=Zh(32);var Ud=Zh(0);Bh(224,1,{});var Vd=Zh(224);var Cc=0,Dc=0,Ec=-1;Bh(94,224,{},Sc);var Oc;var Xd=Zh(94);var Vc;Bh(235,1,{});var Zd=Zh(235);Bh(80,235,{},Zc);var Yd=Zh(80);Bh(43,1,{43:1},Kh);_.J=function(){var a;a=this.a;if(rd(a)===rd(Ih)){a=this.a;if(rd(a)===rd(Ih)){a=this.b.J();this.a=Mh(this.a,a);this.b=null}}return a};var Ih;var $d=Zh(43);var Oh;Bh(77,1,{74:1});_.s=Zp;var _d=Zh(77);Bh(81,6,Lp);var he=Zh(81);Bh(128,81,Lp,Sh);var ae=Zh(128);gd={3:1,75:1,31:1};var be=Zh(75);Bh(39,1,{3:1,39:1});var le=Zh(39);hd={3:1,31:1,39:1};var de=Zh(234);Bh(40,1,{3:1,31:1,40:1});_.p=function(a){return this===a};_.r=$p;_.s=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ee=Zh(40);Bh(58,6,Lp,fi);var ge=Zh(58);Bh(26,39,{3:1,31:1,26:1,39:1},gi);_.p=function(a){return md(a,26)&&a.a==this.a};_.r=Zp;_.s=function(){return ''+this.a};_.a=0;var ie=Zh(26);var ii;Bh(299,1,{});Bh(85,56,Lp,li);_.B=function(a){return new TypeError(a)};var ke=Zh(85);jd={3:1,74:1,31:1,2:1};var pe=Zh(2);Bh(78,77,{74:1},ri);var oe=Zh(78);Bh(303,1,{});Bh(72,1,{},si);_.T=function(a){return a.e};var qe=Zh(72);Bh(59,6,Lp,ti);var se=Zh(59);Bh(236,1,{37:1});_.R=cq;_.W=function(){return new Kj(this,0)};_.X=function(){return new Yj(null,this.W())};_.U=function(a){throw nh(new ti('Add not supported on this collection'))};_.s=function(){var a,b,c;c=new Mj('[',']');for(b=this.S();b.Z();){a=b.$();Lj(c,a===this?'(this Collection)':a==null?Mp:Fh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var te=Zh(236);Bh(239,1,{222:1});_.p=function(a){var b,c,d;if(a===this){return true}if(!md(a,34)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Hi((new Ei(d)).a);c.b;){b=Gi(c);if(!wi(this,b)){return false}}return true};_.r=function(){return $i(new Ei(this))};_.s=function(){var a,b,c;c=new Mj('{','}');for(b=new Hi((new Ei(this)).a);b.b;){a=Gi(b);Lj(c,xi(this,a.ab())+'='+xi(this,a.bb()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ee=Zh(239);Bh(102,239,{222:1});var we=Zh(102);Bh(238,236,{37:1,245:1});_.W=function(){return new Kj(this,1)};_.p=function(a){var b;if(a===this){return true}if(!md(a,20)){return false}b=a;if(Ci(b.a)!=this.V()){return false}return ui(this,b)};_.r=function(){return $i(this)};var Fe=Zh(238);Bh(20,238,{20:1,37:1,245:1},Ei);_.S=function(){return new Hi(this.a)};_.V=aq;var ve=Zh(20);Bh(21,1,{},Hi);_.Y=_p;_.$=function(){return Gi(this)};_.Z=bq;_.b=false;var ue=Zh(21);Bh(237,236,{37:1,242:1});_.W=function(){return new Kj(this,16)};_._=function(a,b){throw nh(new ti('Add not supported on this list'))};_.U=function(a){this._(this.V(),a);return true};_.p=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,12)){return false}f=a;if(this.V()!=f.a.length){return false}e=new Xi(f);for(c=new Xi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(rd(b)===rd(d)||b!=null&&q(b,d))){return false}}return true};_.r=function(){return _i(this)};_.S=function(){return new Ii(this)};var ye=Zh(237);Bh(93,1,{},Ii);_.Y=_p;_.Z=function(){return this.a<this.b.a.length};_.$=function(){return Pi(this.b,this.a++)};_.a=0;var xe=Zh(93);Bh(41,236,{37:1},Ji);_.S=function(){var a;a=new Hi((new Ei(this.a)).a);return new Ki(a)};_.V=aq;var Ae=Zh(41);Bh(97,1,{},Ki);_.Y=_p;_.Z=function(){return this.a.b};_.$=function(){var a;a=Gi(this.a);return a.bb()};var ze=Zh(97);Bh(95,1,Op);_.p=function(a){var b;if(!md(a,38)){return false}b=a;return aj(this.a,b.ab())&&aj(this.b,b.bb())};_.ab=Zp;_.bb=bq;_.r=function(){return Bj(this.a)^Bj(this.b)};_.cb=function(a){var b;b=this.b;this.b=a;return b};_.s=function(){return this.a+'='+this.b};var Be=Zh(95);Bh(96,95,Op,Li);var Ce=Zh(96);Bh(240,1,Op);_.p=function(a){var b;if(!md(a,38)){return false}b=a;return aj(this.b.value[0],b.ab())&&aj(xj(this),b.bb())};_.r=function(){return Bj(this.b.value[0])^Bj(xj(this))};_.s=function(){return this.b.value[0]+'='+xj(this)};var De=Zh(240);Bh(12,237,{3:1,12:1,37:1,242:1},Vi,Wi);_._=function(a,b){mk(this.a,a,b)};_.U=function(a){return Ni(this,a)};_.R=function(a){Oi(this,a)};_.S=function(){return new Xi(this)};_.V=function(){return this.a.length};var He=Zh(12);Bh(13,1,{},Xi);_.Y=_p;_.Z=function(){return this.a<this.c.a.length};_.$=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ge=Zh(13);Bh(34,102,{3:1,34:1,222:1},bj);var Ie=Zh(34);Bh(62,1,{},hj);_.R=cq;_.S=function(){return new ij(this)};_.b=0;var Ke=Zh(62);Bh(63,1,{},ij);_.Y=_p;_.$=function(){return this.d=this.a[this.c++],this.d};_.Z=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Je=Zh(63);var lj;Bh(60,1,{},vj);_.R=cq;_.S=function(){return new wj(this)};_.b=0;_.c=0;var Ne=Zh(60);Bh(61,1,{},wj);_.Y=_p;_.$=function(){return this.c=this.a,this.a=this.b.next(),new yj(this.d,this.c,this.d.c)};_.Z=function(){return !this.a.done};var Le=Zh(61);Bh(116,240,Op,yj);_.ab=function(){return this.b.value[0]};_.bb=function(){return xj(this)};_.cb=function(a){return tj(this.a,this.b.value[0],a)};_.c=0;var Me=Zh(116);Bh(118,1,{});_.Y=eq;_.db=function(){return this.d};_.eb=dq;_.d=0;_.e=0;var Re=Zh(118);Bh(64,118,{});var Oe=Zh(64);Bh(98,1,{});_.Y=eq;_.db=bq;_.eb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Qe=Zh(98);Bh(99,98,{},Ij);_.Y=function(a){Fj(this,a)};_.fb=function(a){return Gj(this,a)};var Pe=Zh(99);Bh(18,1,{},Kj);_.db=Zp;_.eb=function(){Jj(this);return this.c};_.Y=function(a){Jj(this);this.d.Y(a)};_.fb=function(a){Jj(this);if(this.d.Z()){a.A(this.d.$());return true}return false};_.a=0;_.c=0;var Se=Zh(18);Bh(57,1,{},Mj);_.s=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Te=Zh(57);Bh(30,1,{},Nj);_.T=function(a){return a};var Ue=Zh(30);Bh(35,1,{},Oj);var Ve=Zh(35);Bh(117,1,{});_.c=false;var df=Zh(117);Bh(22,117,{},Yj);var cf=Zh(22);Bh(73,1,{},_j);_.gb=function(a){return ad(me,Ep,1,a,5,1)};var We=Zh(73);Bh(120,64,{},bk);_.fb=function(a){this.b=false;while(!this.b&&this.c.fb(new ck(this,a)));return this.b};_.b=false;var Ye=Zh(120);Bh(123,1,{},ck);_.A=function(a){ak(this.a,this.b,a)};var Xe=Zh(123);Bh(119,64,{},ek);_.fb=function(a){return this.b.fb(new fk(this,a))};var $e=Zh(119);Bh(122,1,{},fk);_.A=function(a){dk(this.a,this.b,a)};var Ze=Zh(122);Bh(121,1,{},hk);_.A=function(a){gk(this,a)};var _e=Zh(121);Bh(124,1,{},ik);_.A=function(a){};var af=Zh(124);Bh(125,1,{},kk);_.A=function(a){jk(this,a)};var bf=Zh(125);Bh(301,1,{});Bh(298,1,{});var qk=0;var sk,tk=0,uk;Bh(914,1,{});Bh(937,1,{});Bh(171,1,{},Hk);_.gb=function(a){return new Array(a)};var ef=Zh(171);Bh(265,$wnd.Function,{},Ik);_.ib=function(a){Gk(this.a,this.b,a)};var Wk;Bh(145,1,{264:1},Yk);var ff=Zh(145);Bh(193,1,{});var Rf=Zh(193);Bh(194,193,{});_.e=0;var Vf=Zh(194);Bh(195,194,Fp,el);_.v=fq;_.w=gq;_.s=function(){var a;return Vh(pf),pf.k+'@'+(a=rk(this)>>>0,a.toString(16))};var al=0;var pf=Zh(195);Bh(196,1,Dp,fl);_.t=function(){bl(this.a)};var gf=Zh(196);Bh(197,1,{},gl);_.u=function(){return dl(this.a)};var hf=Zh(197);Bh(199,1,{},hl);_.u=function(){return $k(this.a)};var jf=Zh(199);Bh(198,1,{},il);_.t=function(){_k(this.a)};var kf=Zh(198);Bh(215,1,{});var Qf=Zh(215);Bh(216,215,{});_.d=0;var Uf=Zh(216);Bh(217,216,Fp,ol);_.v=hq;_.w=iq;_.s=function(){var a;return Vh(of),of.k+'@'+(a=rk(this)>>>0,a.toString(16))};var ml=0;var of=Zh(217);Bh(218,1,Dp,pl);_.t=jq;var lf=Zh(218);Bh(219,1,{},ql);_.t=function(){ll(this.a)};var mf=Zh(219);Bh(220,1,{},rl);_.u=function(){return kl(this.a)};var nf=Zh(220);Bh(185,1,{});_.g='';var cg=Zh(185);Bh(186,185,{});_.e=0;var Xf=Zh(186);Bh(187,186,Fp,Dl);_.v=fq;_.w=gq;_.s=function(){var a;return Vh(vf),vf.k+'@'+(a=rk(this)>>>0,a.toString(16))};var xl=0;var vf=Zh(187);Bh(188,1,Dp,El);_.t=function(){yl(this.a)};var qf=Zh(188);Bh(190,1,{},Fl);_.u=function(){return vl(this.a)};var rf=Zh(190);Bh(191,1,Dp,Gl);_.t=function(){sl(this.a)};var sf=Zh(191);Bh(189,1,{},Hl);_.t=function(){_k(this.a)};var tf=Zh(189);Bh(192,1,Dp,Il);_.t=function(){Bl(this.a,this.b)};var uf=Zh(192);Bh(177,1,{});_.k=false;var fg=Zh(177);Bh(201,177,{});_.g=0;var Zf=Zh(201);Bh(202,201,Fp,cm);_.v=function(){kc(this.e)};_.w=function(){return this.e.i<0};_.s=function(){var a;return Vh(Hf),Hf.k+'@'+(a=rk(this)>>>0,a.toString(16))};var Sl=0;var Hf=Zh(202);Bh(203,1,Dp,dm);_.t=function(){Tl(this.a)};var wf=Zh(203);Bh(206,1,Dp,em);_.t=function(){kc(this.a.e)};var xf=Zh(206);Bh(207,1,{},fm);_.u=function(){return Ql(this.a)};var yf=Zh(207);Bh(204,1,{},gm);_.u=function(){return Wl(this.a)};var zf=Zh(204);Bh(48,1,Dp,hm);_.t=function(){bm(this.a,Cn(this.b))};var Af=Zh(48);Bh(69,1,Dp,im);_.t=function(){Nl(this.a,this.b)};var Bf=Zh(69);Bh(208,1,Dp,jm);_.t=function(){Xl(this.a,this.b)};var Cf=Zh(208);Bh(205,1,{},km);_.t=function(){Rl(this.a)};var Df=Zh(205);Bh(209,1,Dp,lm);_.t=function(){Yl(this.a,this.b)};var Ef=Zh(209);Bh(210,1,Dp,mm);_.t=function(){Jl(this.a,this.b)};var Ff=Zh(210);Bh(211,1,Dp,nm);_.t=function(){Ol(this.a)};var Gf=Zh(211);Bh(139,1,{});var jg=Zh(139);Bh(140,139,{});_.d=0;var _f=Zh(140);Bh(141,140,Fp,um);_.v=hq;_.w=iq;_.s=function(){var a;return Vh(Lf),Lf.k+'@'+(a=rk(this)>>>0,a.toString(16))};var sm=0;var Lf=Zh(141);Bh(142,1,Dp,vm);_.t=jq;var If=Zh(142);Bh(143,1,{},wm);_.t=function(){ll(this.a)};var Jf=Zh(143);Bh(144,1,{},xm);_.u=function(){return qm(this.a)};var Kf=Zh(144);Bh(269,$wnd.Function,{},ym);_.mb=function(a){so(this.a.g)};Bh(173,1,{},zm);var Mf=Zh(173);Bh(88,1,{},Am);var Nf=Zh(88);var Bm;Bh(200,1,{},Cm);var Of=Zh(200);Bh(92,1,{},Dm);var Pf=Zh(92);var Em;Bh(270,$wnd.Function,{},Fm);_.nb=function(a){return new Im(a)};var Gm;Bh(179,$wnd.React.Component,{},Im);Ah(yh[1],_);_.componentWillUnmount=function(){Zk(this.a)};_.render=function(){return cl(this.a)};_.shouldComponentUpdate=kq;var Sf=Zh(179);Bh(282,$wnd.Function,{},Jm);_.nb=function(a){return new Mm(a)};var Km;Bh(212,$wnd.React.Component,{},Mm);Ah(yh[1],_);_.componentWillUnmount=function(){jl(this.a)};_.render=function(){return nl(this.a)};_.shouldComponentUpdate=lq;var Tf=Zh(212);Bh(268,$wnd.Function,{},Nm);_.nb=function(a){return new Qm(a)};var Om;Bh(178,$wnd.React.Component,{},Qm);Ah(yh[1],_);_.componentWillUnmount=function(){Zk(this.a)};_.render=function(){return zl(this.a)};_.shouldComponentUpdate=kq;var Wf=Zh(178);Bh(272,$wnd.Function,{},Rm);_.nb=function(a){return new Um(a)};var Sm;Bh(184,$wnd.React.Component,{},Um);Ah(yh[1],_);_.componentDidUpdate=function(a){$(this.a)&&(_l(this.a),undefined)};_.componentWillUnmount=function(){$(this.a)&&Pl(this.a)};_.render=function(){return $(this.a)?Ul(this.a):null};_.shouldComponentUpdate=function(a){return $(this.a)&&1==this.a.g};var Yf=Zh(184);Bh(263,$wnd.Function,{},Vm);_.nb=function(a){return new Ym(a)};var Wm;Bh(100,$wnd.React.Component,{},Ym);Ah(yh[1],_);_.componentWillUnmount=function(){jl(this.a)};_.render=function(){return tm(this.a)};_.shouldComponentUpdate=lq;var $f=Zh(100);Bh(266,$wnd.Function,{},Zm);_.lb=function(a){tl(this.a,a)};Bh(267,$wnd.Function,{},$m);_.kb=function(a){Al(this.a,a)};Bh(172,1,{},_m);var ag=Zh(172);Bh(91,1,{},an);var bg=Zh(91);var bn;Bh(279,$wnd.Function,{},cn);_.kb=function(a){Vl(this.a,a)};Bh(273,$wnd.Function,{},dn);_.kb=function(a){Xn(this.a)};Bh(275,$wnd.Function,{},en);_.mb=function(a){Zl(this.a,this.b)};Bh(276,$wnd.Function,{},fn);_.mb=function(a){Kl(this.a,this.b)};Bh(277,$wnd.Function,{},gn);_.A=function(a){Ll(this.a,a)};Bh(278,$wnd.Function,{},hn);_.jb=function(a){$l(this.a,this.b)};Bh(280,$wnd.Function,{},jn);_.lb=function(a){Ml(this.a,this.b,a)};Bh(176,1,{},ln);var dg=Zh(176);Bh(89,1,{},mn);var eg=Zh(89);var nn;Bh(262,$wnd.Function,{},on);_.kb=function(a){om(this.a,a)};Bh(101,1,{},pn);_.T=function(a){return kn(new ln,a)};var gg=Zh(101);Bh(71,1,{},qn);var hg=Zh(71);Bh(90,1,{},rn);var ig=Zh(90);var sn;Bh(87,1,{},tn);var kg=Zh(87);Bh(47,1,{47:1});var Rg=Zh(47);Bh(157,47,{8:1,47:1},Gn);_.v=fq;_.w=gq;_.s=function(){var a;return Vh(sg),sg.k+'@'+(a=rk(this)>>>0,a.toString(16))};var sg=Zh(157);Bh(158,1,Dp,Hn);_.t=function(){An(this.a)};var lg=Zh(158);Bh(160,1,{},In);_.t=function(){vn(this.a)};var mg=Zh(160);Bh(161,1,{},Jn);_.t=function(){wn(this.a)};var ng=Zh(161);Bh(162,1,Dp,Kn);_.t=function(){un(this.a,this.b)};var og=Zh(162);Bh(163,1,Dp,Ln);_.t=function(){Dn(this.a)};var pg=Zh(163);Bh(66,1,Dp,Mn);_.t=function(){zn(this.a)};var qg=Zh(66);Bh(159,1,{},Nn);_.u=function(){var a;return a=(Ph(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var rg=Zh(159);Bh(49,1,{49:1});_.d=false;var _g=Zh(49);Bh(50,49,{8:1,281:1,50:1,49:1},Yn);_.v=fq;_.p=function(a){return Rn(this,a)};_.r=function(){return this.c.d};_.w=gq;_.s=function(){var a;return Vh(Ig),Ig.k+'@'+(a=this.c.d>>>0,a.toString(16))};var On=0;var Ig=Zh(50);Bh(213,1,Dp,Zn);_.t=function(){Pn(this.a)};var tg=Zh(213);Bh(214,1,Dp,$n);_.t=function(){Un(this.a)};var ug=Zh(214);Bh(46,146,{46:1});var Vg=Zh(46);Bh(147,46,{8:1,46:1},ho);_.v=mq;_.w=nq;_.s=function(){var a;return Vh(Dg),Dg.k+'@'+(a=rk(this)>>>0,a.toString(16))};var Dg=Zh(147);Bh(149,1,Dp,io);_.t=function(){ao(this.a)};var vg=Zh(149);Bh(148,1,Dp,jo);_.t=function(){eo(this.a)};var wg=Zh(148);Bh(154,1,Dp,ko);_.t=function(){cc(this.a,this.b,true)};var xg=Zh(154);Bh(155,1,{},lo);_.u=function(){return _n(this.a,this.c,this.b)};_.b=false;var yg=Zh(155);Bh(150,1,{},mo);_.u=function(){return fo(this.a)};var zg=Zh(150);Bh(151,1,{},no);_.u=function(){return hi(sh(Tj(dc(this.a))))};var Ag=Zh(151);Bh(152,1,{},oo);_.u=function(){return hi(sh(Tj(Uj(dc(this.a),new Xo))))};var Bg=Zh(152);Bh(153,1,{},po);_.u=function(){return go(this.a)};var Cg=Zh(153);Bh(44,1,{44:1});var $g=Zh(44);Bh(129,44,{8:1,44:1},wo);_.v=function(){kc(this.a)};_.w=function(){return this.a.i<0};_.s=function(){var a;return Vh(Hg),Hg.k+'@'+(a=rk(this)>>>0,a.toString(16))};var Hg=Zh(129);Bh(130,1,Dp,xo);_.t=function(){to(this.a,this.b)};_.b=false;var Eg=Zh(130);Bh(131,1,Dp,yo);_.t=function(){Fn(this.b,this.a)};var Fg=Zh(131);Bh(132,1,Dp,zo);_.t=function(){uo(this.a)};var Gg=Zh(132);Bh(45,1,{45:1});var dh=Zh(45);Bh(133,45,{8:1,45:1},Ho);_.v=mq;_.w=nq;_.s=function(){var a;return Vh(Og),Og.k+'@'+(a=rk(this)>>>0,a.toString(16))};var Og=Zh(133);Bh(134,1,Dp,Io);_.t=function(){Co(this.a)};var Jg=Zh(134);Bh(138,1,Dp,Jo);_.t=function(){Go(this.a,null)};var Kg=Zh(138);Bh(135,1,{},Ko);_.u=function(){var a;return a=Cn(this.a.g),o(Xp,a)?(Uo(),Ro):o(Yp,a)?(Uo(),To):(Uo(),So)};var Lg=Zh(135);Bh(136,1,{},Lo);_.u=function(){return Eo(this.a)};var Mg=Zh(136);Bh(137,1,{},Mo);_.t=function(){Fo(this.a)};var Ng=Zh(137);Bh(127,1,{},No);_.handleEvent=function(a){xn(this.a,a)};var Pg=Zh(127);Bh(107,1,{},Oo);_.J=function(){return new Gn};var Qg=Zh(107);var Po;Bh(27,40,{3:1,31:1,40:1,27:1},Vo);var Ro,So,To;var Sg=$h(27,Wo);Bh(109,1,{},Xo);_.hb=function(a){return !Tn(a)};var Tg=Zh(109);Bh(105,1,{},Yo);_.J=function(){return new ho};var Ug=Zh(105);var Zo;Bh(113,1,{},_o);_.hb=function(a){return Tn(a)};var Wg=Zh(113);Bh(114,1,{},ap);_.A=function(a){co(this.a,a)};var Xg=Zh(114);Bh(112,1,{},bp);_.A=function(a){ro(this.a,a)};_.a=false;var Yg=Zh(112);Bh(106,1,{},cp);_.J=function(){return new wo(this.a.J())};var Zg=Zh(106);Bh(115,1,{},dp);_.hb=function(a){return Bo(this.a,a)};var ah=Zh(115);Bh(108,1,{},ep);_.J=function(){return new Ho(this.b.J(),this.a.J())};var bh=Zh(108);Bh(180,1,{});var eh=Zh(180);Bh(183,1,{},op);_.b=0;_.c=false;_.d=0;var fh=Zh(183);Bh(67,180,{});_.a=0;_.b=0;_.c=0;var ih=Zh(67);Bh(182,67,{},rp);var gh=Zh(182);Bh(271,$wnd.Function,{},sp);_.K=function(a){return pp((new tp(this.a)).a),null};Bh(181,1,{},tp);var hh=Zh(181);Bh(68,1,{68:1},vp);_.s=function(){var a;return Vh(jh),jh.k+'@'+(a=rk(this)>>>0,a.toString(16))};var jh=Zh(68);Bh(174,1,{},xp);_.s=function(){var a;return Vh(kh),kh.k+'@'+(a=rk(this)>>>0,a.toString(16))};var kh=Zh(174);var yp;var td=_h('D');var Bp=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=wh;uh(Hh);xh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();