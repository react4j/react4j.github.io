function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='1E3BDBA4B6609EC04BE5A965864015C5',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '1E3BDBA4B6609EC04BE5A965864015C5';function o(){}
function ih(){}
function eh(){}
function Hb(){}
function Kc(){}
function Rc(){}
function pj(){}
function qj(){}
function Ek(){}
function um(){}
function ym(){}
function Cm(){}
function Gm(){}
function Km(){}
function In(){}
function po(){}
function Xo(){}
function Yo(){}
function Pc(a){Oc()}
function qm(a){pm=a}
function tm(a){sm=a}
function Sm(a){Rm=a}
function bn(a){an=a}
function fn(a){en=a}
function qh(){qh=eh}
function pi(){gi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function lb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function cc(a){this.a=a}
function lc(a){this.a=a}
function Gh(a){this.a=a}
function $h(a){this.a=a}
function di(a){this.a=a}
function ei(a){this.a=a}
function ci(a){this.b=a}
function ri(a){this.c=a}
function nj(a){this.a=a}
function sj(a){this.a=a}
function Nk(a){this.a=a}
function Qk(a){this.a=a}
function Rk(a){this.a=a}
function Sk(a){this.a=a}
function Zk(a){this.a=a}
function _k(a){this.a=a}
function al(a){this.a=a}
function bl(a){this.a=a}
function ol(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function ul(a){this.a=a}
function Rl(a){this.a=a}
function Ul(a){this.a=a}
function Wl(a){this.a=a}
function _l(a){this.a=a}
function am(a){this.a=a}
function im(a){this.a=a}
function lm(a){this.a=a}
function mm(a){this.a=a}
function nm(a){this.a=a}
function Om(a){this.a=a}
function Pm(a){this.a=a}
function Tm(a){this.a=a}
function Um(a){this.a=a}
function Xm(a){this.a=a}
function cn(a){this.a=a}
function jn(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function nn(a){this.a=a}
function pn(a){this.a=a}
function Dn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Hn(a){this.a=a}
function Vn(a){this.a=a}
function Wn(a){this.a=a}
function fo(a){this.a=a}
function go(a){this.a=a}
function jo(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function mo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function oj(a,b){a.a=b}
function Kj(a,b){a.key=b}
function Jj(a,b){Ij(a,b)}
function ro(a,b){Pl(b,a)}
function Fp(a){Ti(this,a)}
function Ip(a){Kh(this,a)}
function Jp(){fc(this.c)}
function Lp(){fc(this.b)}
function Bi(){this.a=Ki()}
function Pi(){this.a=Ki()}
function gc(a){!!a&&a.u()}
function V(a){!!a&&cb(a)}
function w(a){--a.e;D(a)}
function gb(a){Vb((J(),a))}
function hb(a){Wb((J(),a))}
function jb(a){Xb((J(),a))}
function jc(a,b){Wh(a.e,b)}
function rj(a,b){ij(a.a,b)}
function wl(a,b){$n(a.j,b)}
function qo(a,b){Zn(a.b,b)}
function C(a,b){ab(a.f,b.f)}
function sb(a,b){a.b=Wi(b)}
function Tk(a){a.c=2;fc(a.b)}
function Fk(a){a.d=2;fc(a.c)}
function Dl(a){a.f=2;fc(a.e)}
function Kb(a){a.a=-4&a.a|1}
function Qg(a){return a.b}
function xl(a,b){return a.g=b}
function Nh(a,b){return a===b}
function Hp(){return this.b}
function Cp(){return this.a}
function Ep(){return Aj(this)}
function Np(){mb(this.a.a)}
function Jk(a){mb(a.b);R(a.a)}
function wn(a){R(a.a);cb(a.b)}
function il(a){mb(a.a);cb(a.b)}
function Ln(a){cb(a.b);cb(a.a)}
function Qh(a){pc.call(this,a)}
function Dp(a){return this===a}
function ji(a,b){return a.a[b]}
function th(a){sh(a);return a.k}
function K(a,b){O(a);L(a,Wi(b))}
function wj(a,b){a.splice(b,1)}
function ec(a,b,c){Vh(a.e,b,c)}
function Mn(a,b,c){ec(a.c,b,c)}
function Sc(a,b){return zh(a,b)}
function Xi(a,b){while(a.$(b));}
function Gi(){Gi=eh;Fi=Ii()}
function J(){J=eh;I=new F}
function rc(){rc=eh;qc=new o}
function Hc(){Hc=eh;Gc=new Kc}
function oo(){oo=eh;no=new po}
function xc(){xc=eh;!!(Oc(),Nc)}
function Lh(){mc(this);this.A()}
function Gp(){return Yh(this.a)}
function Kp(){return this.c.i<0}
function Mp(){return this.b.i<0}
function W(a){return !!a&&a.c.i<0}
function Yh(a){return a.a.b+a.b.b}
function db(a){J();Wb(a);a.e=-2}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function Pn(a){ib(a.a);return a.d}
function yn(a){ib(a.b);return a.e}
function Eo(a){ib(a.d);return a.f}
function hj(a,b){a.N(b);return a}
function Tj(a,b){a.ref=b;return a}
function ij(a,b){oj(a,hj(a.a,b))}
function v(a,b,c){s(a,new H(c),b)}
function Mi(a,b){return a.a.get(b)}
function Xc(a){return new Array(a)}
function Op(a){return 1==this.a.d}
function Pp(a){return 1==this.a.c}
function dc(a,b){this.a=a;this.b=b}
function Eh(a,b){this.a=a;this.b=b}
function fi(a,b){this.a=a;this.b=b}
function lj(a,b){this.a=a;this.b=b}
function Rj(a,b){this.a=a;this.b=b}
function tl(a,b){this.a=a;this.b=b}
function Vl(a,b){this.a=a;this.b=b}
function Xl(a,b){this.a=a;this.b=b}
function Yl(a,b){this.a=a;this.b=b}
function Zl(a,b){this.a=a;this.b=b}
function $l(a,b){this.a=a;this.b=b}
function Vm(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function Ym(a,b){this.a=a;this.b=b}
function Zm(a,b){this.a=a;this.b=b}
function Ak(a,b){Eh.call(this,a,b)}
function uj(a,b,c){a.splice(b,0,c)}
function Uj(a,b){a.href=b;return a}
function Jn(a,b){this.a=a;this.b=b}
function ho(a,b){this.a=a;this.b=b}
function xo(a,b){this.a=a;this.b=b}
function yo(a,b){this.b=a;this.a=b}
function Vo(a,b){Eh.call(this,a,b)}
function zn(a){xn(a,(ib(a.b),a.e))}
function dn(){this.a=Lj((Mm(),Lm))}
function om(){this.a=Lj((wm(),vm))}
function rm(){this.a=Lj((Am(),zm))}
function Qm(){this.a=Lj((Em(),Dm))}
function _m(){this.a=Lj((Im(),Hm))}
function Yg(){Wg==null&&(Wg=[])}
function Fc(){uc!=0&&(uc=0);wc=-1}
function Ki(){Gi();return new Fi}
function gd(a){return typeof a===bp}
function Uh(a){return !a?null:a.W()}
function Rb(a){return !a.d?a:Rb(a.d)}
function Vi(a){return a!=null?r(a):0}
function jd(a){return a==null?null:a}
function Ec(a){$wnd.clearTimeout(a)}
function gi(a){a.a=Uc(ae,dp,1,0,5,1)}
function Xh(a){a.a=new Bi;a.b=new Pi}
function kb(a){this.c=new pi;this.b=a}
function Ej(){Ej=eh;Bj=new o;Dj=new o}
function Xj(a,b){a.checked=b;return a}
function bk(a,b){a.value=b;return a}
function Yj(a,b){a.onBlur=b;return a}
function Vj(a,b){a.onClick=b;return a}
function vj(a,b){tj(b,0,a,0,b.length)}
function bc(a,b){_b(a,b,false);hb(a.d)}
function Hl(a){mb(a.b);R(a.c);cb(a.a)}
function Qn(a){Pl(a,(ib(a.a),!a.d))}
function rb(a){J();qb(a);ub(a,2,true)}
function ib(a){var b;Sb((J(),b=Nb,b),a)}
function Fb(a){this.d=Wi(a);this.b=100}
function kh(a){this.b=Wi(a);this.a=this}
function P(){this.a=Uc(ae,dp,1,100,5,1)}
function B(a,b,c){return t(a,c,2048,b)}
function Zc(a,b,c){return {l:a,m:b,h:c}}
function Mh(a,b){return a.charCodeAt(b)}
function ed(a,b){return a!=null&&cd(a,b)}
function Ph(a){return !a?'null':''+a.a}
function Aj(a){return a.$H||(a.$H=++zj)}
function X(a){return !(!!a&&1==(a.c&7))}
function hd(a){return typeof a==='string'}
function $j(a,b){a.onKeyDown=b;return a}
function Zj(a,b){a.onChange=b;return a}
function Wj(a){a.autoFocus=true;return a}
function sh(a){if(a.k!=null){return}Bh(a)}
function ac(a,b){jc(b.c,a);ed(b,9)&&b.s()}
function pc(a){this.c=a;mc(this);this.A()}
function gj(a,b){bj.call(this,a);this.a=b}
function Ij(a,b){for(var c in a){b(c)}}
function yj(b,c,d){try{b[c]=d}catch(a){}}
function A(a,b,c){t(a,new G(b),c,null)}
function $k(a,b){return new Yk(Wi(b),a.a)}
function pl(a,b){return new nl(Wi(b),a.a)}
function fd(a){return typeof a==='boolean'}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function Ml(a){A((J(),J(),I),new am(a),vp)}
function An(a){A((J(),J(),I),new Gn(a),vp)}
function Tn(a){A((J(),J(),I),new Wn(a),vp)}
function so(a){A((J(),J(),I),new zo(a),vp)}
function co(a){return Hh(S(a.e).a-S(a.a).a)}
function u(a,b){return new xb(Wi(a),null,b)}
function Di(a,b){var c;c=a[qp];c.call(a,b)}
function nc(a,b){a.b=b;b!=null&&yj(b,mp,a)}
function Ti(a,b){while(a.S()){rj(b,a.T())}}
function $(a,b,c){Kb(Wi(c));K(a.a[b],Wi(c))}
function yc(a,b,c){return a.apply(b,c);var d}
function ck(a,b){a.onDoubleClick=b;return a}
function mc(a){a.d&&a.b!==lp&&a.A();return a}
function wh(a){var b;b=vh(a);Dh(a,b);return b}
function vi(){this.a=new Bi;this.b=new Pi}
function Si(a,b,c){this.a=a;this.b=b;this.c=c}
function Pk(a,b,c){this.a=a;this.b=b;this.c=c}
function Tl(a,b,c){this.a=a;this.b=b;this.c=c}
function km(a,b,c){this.a=a;this.b=b;this.c=c}
function oh(a,b,c,d){a.addEventListener(b,c,d)}
function hi(a,b){a.a[a.a.length]=b;return true}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function Go(a){W((ib(a.d),a.f))&&Io(a,null)}
function $n(a,b){A((J(),J(),I),new ho(a,b),vp)}
function vo(a,b){A((J(),J(),I),new xo(a,b),vp)}
function jl(a,b){A((J(),J(),I),new tl(a,b),vp)}
function Il(a,b){A((J(),J(),I),new $l(a,b),vp)}
function Kl(a,b){A((J(),J(),I),new Yl(a,b),vp)}
function Ll(a,b){A((J(),J(),I),new Xl(a,b),vp)}
function Ol(a,b){A((J(),J(),I),new Vl(a,b),vp)}
function kl(a,b){var c;c=b.target;ml(a,c.value)}
function pb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function io(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new bb;this.a=new Fb(this.f)}
function ao(a){Kh(new di(a.g),new cc(a));Xh(a.g)}
function Eb(a){while(true){if(!Db(a)){break}}}
function Gb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Zi(a){if(!a.d){a.d=a.b.M();a.c=a.b.O()}}
function jj(a,b,c){if(a.a._(c)){a.b=true;b.v(c)}}
function ai(a){var b;b=a.a.T();a.b=_h(a);return b}
function yh(a){var b;b=vh(a);b.j=a;b.e=1;return b}
function nh(){nh=eh;mh=$wnd.window.document}
function Jh(){Jh=eh;Ih=Uc(Yd,dp,31,256,0,1)}
function Oc(){Oc=eh;var a;!Qc();a=new Rc;Nc=a}
function lh(a){Wi(a);return ed(a,44)?a:new kh(a)}
function ej(a){aj(a);return new gj(a,new mj(a.a))}
function Ok(a,b){return new Mk(Wi(b),a.a,a.b,a.c)}
function Sl(a,b){return new Ql(Wi(b),a.a,a.b,a.c)}
function jm(a,b){return new hm(Wi(b),a.a,a.b,a.c)}
function Li(a,b){return !(a.a.get(b)===undefined)}
function Kk(a){return qh(),S(a.e.b).a>0?true:false}
function bo(a){return qh(),0==S(a.e).a?true:false}
function Xk(a){return B((J(),J(),I),a.a,new bl(a))}
function ll(a){return B((J(),J(),I),a.a,new rl(a))}
function Lk(a){return B((J(),J(),I),a.b,new Sk(a))}
function Nl(a){return B((J(),J(),I),a.b,new Ul(a))}
function gm(a){return B((J(),J(),I),a.a,new mm(a))}
function Wc(a){return Array.isArray(a)&&a.ib===ih}
function dd(a){return !Array.isArray(a)&&a.ib===ih}
function Bo(a){return Nh(Ap,a)||Nh(Bp,a)||Nh('',a)}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Lc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function li(a,b){var c;c=a.a[b];wj(a.a,b);return c}
function ni(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function bm(a,b){var c;c=b.target;vo(a.e,c.checked)}
function Yn(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function _i(a){if(!a.b){aj(a);a.c=true}else{_i(a.b)}}
function Gk(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function Uk(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function El(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Hj(){if(Cj==256){Bj=Dj;Dj=new o;Cj=0}++Cj}
function Wi(a){if(a==null){throw Qg(new Lh)}return a}
function Zh(a,b){if(b){return Th(a.a,b)}return false}
function dj(a,b){aj(a);return new gj(a,new kj(b,a.a))}
function xn(a,b){A((J(),J(),I),new Jn(a,b),75497472)}
function Do(a){mb(a.e);mb(a.a);R(a.b);R(a.c);cb(a.d)}
function vn(a){var b;T(a.a);b=S(a.a);Nh(a.f,b)&&Bn(a,b)}
function ml(a,b){var c;c=a.f;if(b!=c){a.f=b;hb(a.b)}}
function Pl(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function Bn(a,b){var c;c=a.e;if(b!=c){a.e=Wi(b);hb(a.b)}}
function xh(a,b){var c;c=vh(a);Dh(a,c);c.e=b?8:0;return c}
function ak(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Yi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function $i(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function mj(a){Yi.call(this,a.Z(),a.Y()&-6);this.a=a}
function bj(a){if(!a){this.b=null;new pi}else{this.b=a}}
function ph(a,b,c,d){a.removeEventListener(b,c,d)}
function Al(a,b){Io(a.k,b);A((J(),J(),I),new Vl(a,b),vp)}
function Zn(a,b){return t((J(),J(),I),new io(a,b),vp,null)}
function ui(a,b){return jd(a)===jd(b)||a!=null&&p(a,b)}
function Wo(){Uo();return Yc(Sc(Eg,1),dp,33,0,[Ro,To,So])}
function rn(a){oh((nh(),$wnd.window.window),yp,a.d,false)}
function sn(a){ph((nh(),$wnd.window.window),yp,a.d,false)}
function zl(a,b){A((J(),J(),I),new Vl(a,b),vp);Io(a.k,null)}
function nb(a){C((J(),J(),I),a);0==(a.f.a&ip)&&D((null,I))}
function hn(a){return new Pk(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function mn(a){return new Tl(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function on(a){return new km(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function Kh(a,b){var c,d;for(d=a.M();d.S();){c=d.T();b.v(c)}}
function vl(a,b){var c;if(S(a.c)){c=b.target;Pl(a,c.value)}}
function Vg(a){if(gd(a)){return a|0}return a.l|a.m<<22}
function Ah(a){if(a.K()){return null}var b=a.j;return _g[b]}
function gh(a){function b(){}
;b.prototype=a||{};return new b}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function to(a,b){var c;fj(_n(a.b),(c=new pi,c)).L(new $o(b))}
function zh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.F(b))}
function xi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Dc(a){xc();$wnd.setTimeout(function(){throw a},0)}
function aj(a){if(a.b){aj(a.b)}else if(a.c){throw Qg(new Fh)}}
function Ob(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);qb(a.e)}}
function qi(a){gi(this);vj(this.a,Sh(a,Uc(ae,dp,1,Yh(a.a),5,1)))}
function yi(a,b){var c;return wi(b,xi(a,b==null?0:(c=r(b),c|0)))}
function _n(a){ib(a.d);return new gj(null,new $i(new di(a.g),0))}
function tn(a,b){b.preventDefault();A((J(),J(),I),new Hn(a),vp)}
function _j(a){a.placeholder='What needs to be done?';return a}
function oc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function bh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function wm(){wm=eh;var a;vm=(a=fh(um.prototype.fb,um,[]),a)}
function Am(){Am=eh;var a;zm=(a=fh(ym.prototype.fb,ym,[]),a)}
function Em(){Em=eh;var a;Dm=(a=fh(Cm.prototype.fb,Cm,[]),a)}
function Im(){Im=eh;var a;Hm=(a=fh(Gm.prototype.fb,Gm,[]),a)}
function Mm(){Mm=eh;var a;Lm=(a=fh(Km.prototype.fb,Km,[]),a)}
function Jl(a){return qh(),Eo(a.k)==a.n.props['a']?true:false}
function kd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ci(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Nm(a){$wnd.React.Component.call(this,a);this.a=jm(en,this)}
function Jm(a){$wnd.React.Component.call(this,a);this.a=Sl(an,this)}
function Fm(a){$wnd.React.Component.call(this,a);this.a=pl(Rm,this)}
function xm(a){$wnd.React.Component.call(this,a);this.a=Ok(pm,this)}
function Bm(a){$wnd.React.Component.call(this,a);this.a=$k(sm,this)}
function kj(a,b){Yi.call(this,b.Z(),b.Y()&-16449);this.a=a;this.c=b}
function Qi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function ic(a){gc(a.g);!!a.e&&hc(a);V(a.a);V(a.c);gc(a.b);gc(a.f)}
function Io(a,b){var c;c=a.f;if(!(b==c||!!b&&Nn(b,c))){a.f=b;hb(a.d)}}
function eb(a,b){var c,d;hi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function fj(a,b){var c;_i(a);c=new pj;c.a=b;a.a.R(new sj(c));return c.a}
function cj(a){var b;_i(a);b=0;while(a.a.$(new qj)){b=Rg(b,1)}return b}
function wo(a){this.b=Wi(a);J();this.a=new kc(0,null,null,false,false)}
function Bc(a,b,c){var d;d=zc();try{return yc(a,b,c)}finally{Cc(d)}}
function Ac(b){xc();return function(){return Bc(b,this,arguments);var a}}
function tc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Lb(b){try{b.b.u()}catch(a){a=Pg(a);if(!ed(a,5))throw Qg(a)}}
function Cc(a){a&&Jc((Hc(),Gc));--uc;if(a){if(wc!=-1){Ec(wc);wc=-1}}}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function ii(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function cl(a){var b;b=Oh((ib(a.b),a.f));if(b.length>0){qo(a.e,b);ml(a,'')}}
function uo(a){var b;fj(dj(_n(a.b),new Yo),(b=new pi,b)).L(new Zo(a.b))}
function Fo(a){var b,c;return b=S(a.b),fj(dj(_n(a.j),new _o(b)),(c=new pi,c))}
function Wh(a,b){return hd(b)?b==null?Ai(a.a,null):Oi(a.b,b):Ai(a.a,b)}
function Vh(a,b,c){return hd(b)?b==null?zi(a.a,null,c):Ni(a.b,b,c):zi(a.a,b,c)}
function Co(a,b){return (Uo(),So)==a||(Ro==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function xj(a,b){return Tc(b)!=10&&Yc(q(b),b.hb,b.__elementTypeId$,Tc(b),a),a}
function qn(a,b){a.f=b;Nh(b,S(a.a))&&Bn(a,b);un(b);A((J(),J(),I),new Hn(a),vp)}
function Qj(a,b,c){!Nh(c,'key')&&!Nh(c,'ref')&&(a[c]=b[c],undefined)}
function ki(a,b,c){for(;c<a.a.length;++c){if(ui(b,a.a[c])){return c}}return -1}
function Ri(a){if(a.a.c!=a.c){return Mi(a.a,a.b.value[0])}return a.b.value[1]}
function Nn(a,b){var c;if(ed(b,49)){c=b;return a.c.d==c.c.d}else{return false}}
function mi(a,b){var c;c=ki(a,b,0);if(c==-1){return false}wj(a.a,c);return true}
function Uc(a,b,c,d,e,f){var g;g=Vc(e,d);e!=10&&Yc(Sc(a,f),b,c,e,g);return g}
function $m(a,b){Kj(a.a,Ph(b?Hh(b.c.d):null));Wi(b);a.a.props['a']=b;return a.a}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||mb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new lb(a)),0,null);!!a.b&&mb(a.b)}}
function fc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new lc(a)),67108864,null)}}
function dl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new sl(a),vp)}}
function tb(b){if(b){try{b.u()}catch(a){a=Pg(a);if(ed(a,5)){J()}else throw Qg(a)}}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function Ic(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Mc(b,c)}while(a.a);a.a=c}}
function Jc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Mc(b,c)}while(a.b);a.b=c}}
function bb(){var a;this.a=Uc(pd,dp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function bi(a){this.d=a;this.c=new Qi(this.d.b);this.a=this.c;this.b=_h(this)}
function Mb(a,b){this.b=Wi(a);this.a=b|0|(0==(b&6291456)?jp:0)|(0!=(b&229376)?0:98304)}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;hi((!a.b&&(a.b=new pi),a.b),b)}}}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new pi);a.c=c.c}b.d=true;hi(a.c,Wi(b))}
function Dh(a,b){var c;if(!a){return}b.j=a;var d=Ah(b);if(!d){_g[a]=[b];return}d.gb=b}
function Pg(a){var b;if(ed(a,5)){return a}b=a&&a[mp];if(!b){b=new sc(a);Pc(b)}return b}
function fh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function vh(a){var b;b=new uh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Lj(a){var b;b=Nj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Oj(a){var b;return Mj($wnd.React.StrictMode,null,null,(b={},b[rp]=Wi(a),b))}
function Mj(a,b,c,d){var e;e=Nj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Wi(d);return e}
function Oi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Di(a.a,b);--a.b}return c}
function Xn(a,b,c){var d;d=new Un(b,c);Mn(d,a,new dc(a,d));Vh(a.g,Hh(d.c.d),d);hb(a.d);return d}
function Rh(a,b){var c,d;for(d=new bi(b.a);d.b;){c=ai(d);if(!Zh(a,c)){return false}}return true}
function si(a){var b,c,d;d=0;for(c=new bi(a.a);c.b;){b=ai(c);d=d+(b?r(b):0);d=d|0}return d}
function qb(a){var b,c;for(c=new ri(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Xg(){Yg();var a=Wg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Fh(){pc.call(this,"Stream already terminated, can't be modified or used")}
function xb(a,b,c){wb.call(this,null,a,b,c|(!a?262144:fp)|(0==(c&6291456)?!a?ip:jp:0)|0|0|0)}
function _b(a,b,c){var d;d=Wh(a.g,b?Hh(b.c.d):null);if(null!=d){jc(b.c,a);c&&!!b&&fc(b.c);hb(a.d)}}
function wi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(ui(a,c.V())){return c}}return null}
function Ug(a){var b,c,d,e;e=a;d=0;if(e<0){e+=op;d=1048575}c=kd(e/jp);b=kd(e-c*jp);return Zc(b,c,d)}
function Sg(a){var b;b=a.h;if(b==0){return a.l+a.m*jp}if(b==1048575){return a.l+a.m*jp-op}return a}
function _h(a){if(a.a.S()){return true}if(a.a!=a.c){return false}a.a=new Ci(a.d.a);return a.a.S()}
function S(a){ib(a.e);vb(a.f)&&ob(a.f);if(a.b){if(ed(a.b,8)){throw Qg(a.b)}else{throw Qg(a.b)}}return a.k}
function Ho(a){var b;b=S(a.i.a);Nh(Ap,b)||Nh(Bp,b)||Nh('',b)?xn(a.i,b):Bo(yn(a.i))?An(a.i):xn(a.i,'')}
function gn(){this.a=lh((oo(),oo(),no));this.b=lh(new Ao(this.a));this.c=lh(new Po(this.a))}
function Uo(){Uo=eh;Ro=new Vo('ACTIVE',0);To=new Vo('COMPLETED',1);So=new Vo('ALL',2)}
function Tc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Yc(a,b,c,d,e){e.gb=a;e.hb=b;e.ib=ih;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ni(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function sc(a){rc();mc(this);this.b=a;a!=null&&yj(a,mp,this);this.c=a==null?'null':hh(a);this.a=a}
function uh(){this.g=rh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Dk(){if(!Ck){Ck=(++(J(),J(),I).e,new Hb);$wnd.Promise.resolve(null).then(fh(Ek.prototype.D,Ek,[]))}}
function mb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Bb(a)),67108864,null);!!a.a&&R(a.a);Ib(a.f);a.c=a.c&-8|1}}
function yl(a,b,c){27==c.which?A((J(),J(),I),new Zl(a,b),vp):13==c.which&&A((J(),J(),I),new Xl(a,b),vp)}
function $g(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function $c(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return Zc(c&4194303,d&4194303,e&1048575)}
function fb(a,b){var c,d;d=a.c;mi(d,b);!!a.b&&fp!=(a.b.c&gp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&fp)?Lb(a):a.b.u();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function q(a){return hd(a)?ce:gd(a)?Ud:fd(a)?Sd:dd(a)?a.gb:Wc(a)?a.gb:a.gb||Array.isArray(a)&&Sc(Ld,1)||Ld}
function r(a){return hd(a)?Gj(a):gd(a)?kd(a):fd(a)?a?1231:1237:dd(a)?a.q():Wc(a)?Aj(a):!!a&&!!a.hashCode?a.hashCode():Aj(a)}
function p(a,b){return hd(a)?Nh(a,b):gd(a)?a===b:fd(a)?a===b:dd(a)?a.o(b):Wc(a)?a===b:!!a&&!!a.equals?a.equals(b):jd(a)===jd(b)}
function Cl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Ol(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=li(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Hh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Jh(),Ih)[b];!c&&(c=Ih[b]=new Gh(a));return c}return new Gh(a)}
function hh(a){var b;if(Array.isArray(a)&&a.ib===ih){return th(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Gj(a){Ej();var b,c,d;c=':'+a;d=Dj[c];if(d!=null){return kd(d)}d=Bj[c];b=d==null?Fj(a):kd(d);Hj();Dj[c]=b;return b}
function ti(a){var b,c,d;d=1;for(c=new ri(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function hc(a){var b,c,d;for(c=new ri(new qi(new $h(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.V();ed(d,9)&&d.t()||b.W().u()}}
function Bk(){zk();return Yc(Sc(Oe,1),dp,7,0,[dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk])}
function yb(a,b){wb.call(this,a,new zb(a),null,b|(fp==(b&gp)?0:524288)|(0==(b&6291456)?fp==(b&gp)?jp:ip:0)|0|268435456|0)}
function Rg(a,b){var c;if(gd(a)&&gd(b)){c=a+b;if(-17592186044416<c&&c<op){return c}}return Sg($c(gd(a)?Ug(a):a,gd(b)?Ug(b):b))}
function Bl(a,b){var c;c=(ib(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new yo(b,c),vp);Io(a.k,null);Pl(a,c)}else{$n(a.j,b)}}
function Ch(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function oi(a,b){var c,d;d=a.a.length;b.length<d&&(b=xj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Sh(a,b){var c,d,e;e=Yh(a.a);b.length<e&&(b=xj(new Array(e),b));d=new bi(a.a);for(c=0;c<e;++c){b[c]=ai(d)}b.length>e&&(b[e]=null);return b}
function Sj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function zc(){var a;if(uc!=0){a=tc();if(a-vc>2000){vc=a;wc=$wnd.setTimeout(Fc,10)}}if(uc++==0){Ic((Hc(),Gc));return true}return false}
function Qc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a,b,c,d,e){var f;this.d=a;this.e=d?new vi:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new kb((J(),null)),f):null;this.c=null}
function U(a,b,c,d){this.c=Wi(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new yb(this,d);this.e=new kb(this.f);fp==(d&gp)&&nb(this.f)}
function Un(a,b){var c,d,e;this.e=Wi(a);this.d=b;J();c=++Kn;this.c=new kc(c,null,new Vn(this),true,true);this.b=(e=new kb(null),e);this.a=(d=new kb(null),d)}
function Yk(a,b){var c;this.d=Wi(b);this.n=Wi(a);J();c=++Wk;this.b=new kc(c,null,new Zk(this),false,false);this.a=new xb(null,Wi(new al(this)),up)}
function cd(a,b){if(hd(a)){return !!bd[b]}else if(a.hb){return !!a.hb[b]}else if(gd(a)){return !!ad[b]}else if(fd(a)){return !!_c[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Wb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ri(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&ub(b,6,true)}}}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Oh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Vc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{Zb(b,d);try{f=(c.a.u(),null)}finally{$b()}return f}catch(a){a=Pg(a);if(ed(a,5)){e=a;throw Qg(e)}else throw Qg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.r()}else{Zb(b,e);try{g=c.r()}finally{$b()}}return g}catch(a){a=Pg(a);if(ed(a,5)){f=a;throw Qg(f)}else throw Qg(a)}finally{D(b)}}
function Db(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Jb(c);return true}
function Zg(b,c,d,e){Yg();var f=Wg;$moduleName=c;$moduleBase=d;Og=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ap(g)()}catch(a){b(c,a)}}else{ap(g)()}}
function nl(a,b){var c,d;this.e=Wi(b);this.n=Wi(a);J();c=++hl;this.c=new kc(c,null,new ol(this),false,false);this.b=(d=new kb(null),d);this.a=new xb(null,Wi(new ul(this)),up)}
function hm(a,b,c,d){var e;this.d=Wi(b);this.e=Wi(c);this.f=Wi(d);this.n=Wi(a);J();e=++fm;this.b=new kc(e,null,new im(this),false,false);this.a=new xb(null,Wi(new lm(this)),up)}
function Nj(a,b){var c;c=new $wnd.Object;c.$$typeof=Wi(a);c.type=Wi(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ii(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ji()}}
function Vk(a){var b,c,d;a.c=0;Dk();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),Pj('span',Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,['todo-count'])),[Pj('strong',null,[c]),' '+d+' left']));return b}
function ah(){_g={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Mc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].jb()&&(c=Lc(c,g)):g[0].jb()}catch(a){a=Pg(a);if(ed(a,5)){d=a;xc();Dc(ed(d,35)?d.B():d)}else throw Qg(a)}}return c}
function gl(a){var b;a.d=0;Dk();b=Pj(wp,Wj(Zj($j(bk(_j(Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,['new-todo']))),(ib(a.b),a.f)),fh(Om.prototype.db,Om,[a])),fh(Pm.prototype.cb,Pm,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.r();if(!(jd(e)===jd(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Pg(a);if(ed(a,11)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Qg(c)}else throw Qg(a)}}
function zi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=wi(b,e);if(f){return f.X(c)}}e[e.length]=new fi(b,c);++a.b;return null}
function tj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Fj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Mh(a,c++)}b=b|0;return b}
function ob(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.u()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Pg(a);if(ed(a,5)){J()}else throw Qg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Uc(ae,dp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function jh(){var a;a=new gn;qm(hn(new jn(a)));tm(new _k((new kn(a)).a.a.C()));bn(mn(new nn(a)));fn(on(new pn(a)));Sm(new ql((new ln(a)).a.b.C()));$wnd.ReactDOM.render(Oj([(new dn).a]),(nh(),mh).getElementById('app'),null)}
function un(a){var b;if(0==a.length){b=(nh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',mh.title,b)}else{(nh(),$wnd.window.window).location.hash=a}}
function Mk(a,b,c,d){var e;this.e=Wi(b);this.f=Wi(c);this.g=Wi(d);this.n=Wi(a);J();e=++Ik;this.c=new kc(e,null,new Nk(this),false,false);this.a=new U(new Qk(this),null,null,136478720);this.b=new xb(null,Wi(new Rk(this)),up)}
function Ql(a,b,c,d){var e,f;this.j=Wi(b);Wi(c);this.k=Wi(d);this.n=Wi(a);J();e=++Gl;this.e=new kc(e,null,new Rl(this),false,false);this.a=(f=new kb(null),f);this.c=new U(new Wl(this),null,null,136478720);this.b=new xb(null,Wi(new _l(this)),up);Ol(this,this.n.props['a'])}
function wb(a,b,c,d){this.b=new pi;this.f=new Mb(new Ab(this),d&6520832|262144|fp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&ip)&&D((null,I)))}
function Ai(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(ui(b,e.V())){if(d.length==1){d.length=0;Di(a.a,g)}else{d.splice(h,1)}--a.b;return e.W()}}return null}
function dh(a,b,c){var d=_g,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=_g[b]),gh(h));_.hb=c;!b&&(_.ib=ih);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.gb=f)}
function Bh(a){if(a.J()){var b=a.c;b.K()?(a.k='['+b.j):!b.J()?(a.k='[L'+b.H()+';'):(a.k='['+b.H());a.b=b.G()+'[]';a.i=b.I()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Ch('.',[c,Ch('$',d)]);a.b=Ch('.',[c,Ch('.',d)]);a.i=d[d.length-1]}
function Th(a,b){var c,d,e;c=b.V();e=b.W();d=hd(c)?c==null?Uh(yi(a.a,null)):Mi(a.b,c):Uh(yi(a.a,c));if(!(jd(e)===jd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(hd(c)?c==null?!!yi(a.a,null):Li(a.b,c):!!yi(a.a,c))){return false}return true}
function Pj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Jj(b,fh(Rj.prototype.ab,Rj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[rp]=c[0],undefined):(d[rp]=c,undefined));return Mj(a,e,f,d)}
function Cn(){var a,b;this.d=new Qo(this);this.f=this.e=(b=(nh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new kc(0,null,new Dn(this),false,false);this.b=(a=new kb(null),a);this.a=new U(new In,new En(this),new Fn(this),35749888)}
function eo(){var a;this.g=new vi;J();this.f=new kc(0,new go(this),new fo(this),false,false);this.d=(a=new kb(null),a);this.c=new U(new jo(this),null,null,zp);this.e=new U(new ko(this),null,null,zp);this.a=new U(new lo(this),null,null,zp);this.b=new U(new mo(this),null,null,zp)}
function Jo(a){var b;this.j=Wi(a);this.i=new Cn;J();this.g=new kc(0,null,new Ko(this),false,false);this.d=(b=new kb(null),b);this.b=new U(new Lo(this),null,null,zp);this.c=new U(new Mo(this),null,null,zp);this.e=u(new No(this),413138944);this.a=u(new Oo(this),681574400);D((null,I))}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ri(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Pg(a);if(!ed(a,5))throw Qg(a)}if(6==(b.c&7)){return true}}}}}qb(b);return false}
function Hi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ub(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){jb(a.a.e);tb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;tb((e=d.i,e));d.k=null}ii(a.b,new Cb(a));a.b.a=Uc(ae,dp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&tb((f=a.a.g,f))}}
function zk(){zk=eh;dk=new Ak(sp,0);ek=new Ak('checkbox',1);fk=new Ak('color',2);gk=new Ak('date',3);hk=new Ak('datetime',4);ik=new Ak('email',5);jk=new Ak('file',6);kk=new Ak('hidden',7);lk=new Ak('image',8);mk=new Ak('month',9);nk=new Ak(bp,10);ok=new Ak('password',11);pk=new Ak('radio',12);qk=new Ak('range',13);rk=new Ak('reset',14);sk=new Ak('search',15);tk=new Ak('submit',16);uk=new Ak('tel',17);vk=new Ak('text',18);wk=new Ak('time',19);xk=new Ak('url',20);yk=new Ak('week',21)}
function em(a){var b,c,d;a.c=0;Dk();d=Pj('div',null,[Pj('div',null,[Pj(xp,Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,[xp])),[Pj('h1',null,['todos']),(new Qm).a]),S(a.d.c)?null:Pj('section',Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,[xp])),[Pj(wp,Zj(ak(Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,['toggle-all'])),(zk(),ek)),fh(cn.prototype.cb,cn,[a])),null),Pj('ul',Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,['todo-list'])),(b=fj(Wi(ej(S(a.f.c).Q())),(c=new pi,c)),oi(b,Xc(b.a.length))))]),S(a.d.c)?null:(new om).a])]);return d}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ji(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ni(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ji(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){li(a.b,g)}e&&sb(a.e,a.b)}else{e&&sb(a.e,new pi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&fp!=(k.b.c&gp)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function Hk(a){var b,c;a.d=0;Dk();c=(b=S(a.g.b),Pj('footer',Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,['footer'])),[(new rm).a,Pj('ul',Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,['filters'])),[Pj('li',null,[Pj('a',Uj(Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,[(Uo(),So)==b?tp:null])),'#'),['All'])]),Pj('li',null,[Pj('a',Uj(Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,[Ro==b?tp:null])),'#active'),['Active'])]),Pj('li',null,[Pj('a',Uj(Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,[To==b?tp:null])),'#completed'),['Completed'])])]),S(a.a)?Pj(sp,Vj(Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,['clear-completed'])),fh(nm.prototype.eb,nm,[a])),['Clear Completed']):null]));return c}
function Fl(a){var b,c,d,e;a.f=0;Dk();b=a.n.props['a'];if(b.c.i<0){return null}c=(d=a.n.props['a'],e=(ib(d.a),d.d),Pj('li',Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[Pj('div',Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,['view'])),[Pj(wp,Zj(Xj(ak(Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,['toggle'])),(zk(),ek)),e),fh(Um.prototype.cb,Um,[d])),null),Pj('label',ck(new $wnd.Object,fh(Vm.prototype.eb,Vm,[a,d])),[(ib(d.b),d.e)]),Pj(sp,Vj(Sj(new $wnd.Object,Yc(Sc(ce,1),dp,2,6,['destroy'])),fh(Wm.prototype.eb,Wm,[a,d])),null)]),Pj(wp,$j(Zj(Yj(bk(Sj(Tj(new $wnd.Object,fh(Xm.prototype.v,Xm,[a])),Yc(Sc(ce,1),dp,2,6,['edit'])),(ib(a.a),a.d)),fh(Ym.prototype.bb,Ym,[a,d])),fh(Tm.prototype.cb,Tm,[a])),fh(Zm.prototype.db,Zm,[a,d])),null)]));return c}
function Ji(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[qp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Hi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[qp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var bp='number',cp={14:1},dp={3:1,4:1},ep={9:1},fp=1048576,gp=1835008,hp={6:1},ip=2097152,jp=4194304,kp={22:1},lp='__noinit__',mp='__java$exception',np={3:1,11:1,8:1,5:1},op=17592186044416,pp={40:1},qp='delete',rp='children',sp='button',tp='selected',up=1411518464,vp=142606336,wp='input',xp='header',yp='hashchange',zp=136413184,Ap='active',Bp='completed';var _,_g,Wg,Og=-1;ah();dh(1,null,{},o);_.o=Dp;_.p=function(){return this.gb};_.q=Ep;_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};var _c,ad,bd;dh(54,1,{},uh);_.F=function(a){var b;b=new uh;b.e=4;a>1?(b.c=zh(this,a-1)):(b.c=this);return b};_.G=function(){sh(this);return this.b};_.H=function(){return th(this)};_.I=function(){sh(this);return this.i};_.J=function(){return (this.e&4)!=0};_.K=function(){return (this.e&1)!=0};_.e=0;_.g=0;var rh=1;var ae=wh(1);var Td=wh(54);dh(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var od=wh(81);dh(36,1,cp,G);_.r=function(){return this.a.u(),null};var md=wh(36);dh(82,1,{},H);var nd=wh(82);var I;dh(924,1,{});dh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var pd=wh(43);dh(231,1,ep);var sd=wh(231);dh(20,231,ep,U);_.s=function(){R(this)};_.t=Cp;_.a=false;_.d=0;var qd=wh(20);dh(143,1,{269:1},bb);var rd=wh(143);dh(18,231,{9:1,18:1},kb);_.s=function(){cb(this)};_.t=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var ud=wh(18);dh(178,1,hp,lb);_.u=function(){db(this.a)};var td=wh(178);dh(19,231,{9:1,19:1},xb,yb);_.s=function(){mb(this)};_.t=function(){return 1==(this.c&7)};_.c=0;var zd=wh(19);dh(179,1,kp,zb);_.u=function(){Q(this.a)};var vd=wh(179);dh(180,1,hp,Ab);_.u=function(){ob(this.a)};var wd=wh(180);dh(181,1,hp,Bb);_.u=function(){rb(this.a)};var xd=wh(181);dh(182,1,{},Cb);_.v=function(a){pb(this.a,a)};var yd=wh(182);dh(144,1,{},Fb);_.a=0;_.b=0;_.c=0;var Ad=wh(144);dh(183,1,ep,Hb);_.s=function(){Gb(this)};_.t=Cp;_.a=false;var Bd=wh(183);dh(65,231,{9:1,65:1},Mb);_.s=function(){Ib(this)};_.t=function(){return 2==(3&this.a)};_.a=0;var Cd=wh(65);dh(187,1,{},Yb);_.a=0;var Nb;var Dd=wh(187);dh(156,1,{});var Gd=wh(156);dh(149,1,{},cc);_.v=function(a){ac(this.a,a)};var Ed=wh(149);dh(150,1,hp,dc);_.u=function(){bc(this.a,this.b)};var Fd=wh(150);dh(157,156,{});var Hd=wh(157);dh(17,1,ep,kc);_.s=function(){fc(this)};_.t=function(){return this.i<0};_.d=0;_.i=0;var Jd=wh(17);dh(177,1,hp,lc);_.u=function(){ic(this.a)};var Id=wh(177);dh(5,1,{3:1,5:1});_.w=function(a){return new Error(a)};_.A=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=th(this.gb),c==null?a:a+': '+c);nc(this,oc(this.w(b)));Pc(this)};_.b=lp;_.d=true;var de=wh(5);dh(11,5,{3:1,11:1,5:1});var Wd=wh(11);dh(8,11,np);var be=wh(8);dh(55,8,np);var Zd=wh(55);dh(76,55,np);var Nd=wh(76);dh(35,76,{35:1,3:1,11:1,8:1,5:1},sc);_.B=function(){return jd(this.a)===jd(qc)?null:this.a};var qc;var Kd=wh(35);var Ld=wh(0);dh(213,1,{});var Md=wh(213);var uc=0,vc=0,wc=-1;dh(90,213,{},Kc);var Gc;var Od=wh(90);var Nc;dh(224,1,{});var Qd=wh(224);dh(77,224,{},Rc);var Pd=wh(77);dh(44,1,{44:1,69:1},kh);_.C=function(){if(this===this.a){this.a=this.b.C();this.b=null}return this.a};var Rd=wh(44);var mh;_c={3:1,72:1,30:1};var Sd=wh(72);dh(41,1,{3:1,41:1});var _d=wh(41);ad={3:1,30:1,41:1};var Ud=wh(223);dh(32,1,{3:1,30:1,32:1});_.o=Dp;_.q=Ep;_.b=0;var Vd=wh(32);dh(78,8,np,Fh);var Xd=wh(78);dh(31,41,{3:1,30:1,31:1,41:1},Gh);_.o=function(a){return ed(a,31)&&a.a==this.a};_.q=Cp;_.a=0;var Yd=wh(31);var Ih;dh(287,1,{});dh(79,55,np,Lh);_.w=function(a){return new TypeError(a)};var $d=wh(79);bd={3:1,71:1,30:1,2:1};var ce=wh(2);dh(291,1,{});dh(57,8,np,Qh);var ee=wh(57);dh(225,1,{39:1});_.L=Ip;_.P=function(){return new $i(this,0)};_.Q=function(){return new gj(null,this.P())};_.N=function(a){throw Qg(new Qh('Add not supported on this collection'))};var fe=wh(225);dh(229,1,{212:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ed(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new bi((new $h(d)).a);c.b;){b=ai(c);if(!Th(this,b)){return false}}return true};_.q=function(){return si(new $h(this))};var qe=wh(229);dh(142,229,{212:1});var ie=wh(142);dh(228,225,{39:1,236:1});_.P=function(){return new $i(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ed(a,24)){return false}b=a;if(Yh(b.a)!=this.O()){return false}return Rh(this,b)};_.q=function(){return si(this)};var re=wh(228);dh(24,228,{24:1,39:1,236:1},$h);_.M=function(){return new bi(this.a)};_.O=Gp;var he=wh(24);dh(25,1,{},bi);_.R=Fp;_.T=function(){return ai(this)};_.S=Hp;_.b=false;var ge=wh(25);dh(226,225,{39:1,233:1});_.P=function(){return new $i(this,16)};_.U=function(a,b){throw Qg(new Qh('Add not supported on this list'))};_.N=function(a){this.U(this.O(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ed(a,13)){return false}f=a;if(this.O()!=f.a.length){return false}e=new ri(f);for(c=new ri(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(jd(b)===jd(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return ti(this)};_.M=function(){return new ci(this)};var ke=wh(226);dh(89,1,{},ci);_.R=Fp;_.S=function(){return this.a<this.b.a.length};_.T=function(){return ji(this.b,this.a++)};_.a=0;var je=wh(89);dh(59,225,{39:1},di);_.M=function(){var a;a=new bi((new $h(this.a)).a);return new ei(a)};_.O=Gp;var me=wh(59);dh(141,1,{},ei);_.R=Fp;_.S=function(){return this.a.b};_.T=function(){var a;a=ai(this.a);return a.W()};var le=wh(141);dh(139,1,pp);_.o=function(a){var b;if(!ed(a,40)){return false}b=a;return ui(this.a,b.V())&&ui(this.b,b.W())};_.V=Cp;_.W=Hp;_.q=function(){return Vi(this.a)^Vi(this.b)};_.X=function(a){var b;b=this.b;this.b=a;return b};var ne=wh(139);dh(140,139,pp,fi);var oe=wh(140);dh(230,1,pp);_.o=function(a){var b;if(!ed(a,40)){return false}b=a;return ui(this.b.value[0],b.V())&&ui(Ri(this),b.W())};_.q=function(){return Vi(this.b.value[0])^Vi(Ri(this))};var pe=wh(230);dh(13,226,{3:1,13:1,39:1,233:1},pi,qi);_.U=function(a,b){uj(this.a,a,b)};_.N=function(a){return hi(this,a)};_.L=function(a){ii(this,a)};_.M=function(){return new ri(this)};_.O=function(){return this.a.length};var te=wh(13);dh(16,1,{},ri);_.R=Fp;_.S=function(){return this.a<this.c.a.length};_.T=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var se=wh(16);dh(37,142,{3:1,37:1,212:1},vi);var ue=wh(37);dh(62,1,{},Bi);_.L=Ip;_.M=function(){return new Ci(this)};_.b=0;var we=wh(62);dh(63,1,{},Ci);_.R=Fp;_.T=function(){return this.d=this.a[this.c++],this.d};_.S=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ve=wh(63);var Fi;dh(60,1,{},Pi);_.L=Ip;_.M=function(){return new Qi(this)};_.b=0;_.c=0;var ze=wh(60);dh(61,1,{},Qi);_.R=Fp;_.T=function(){return this.c=this.a,this.a=this.b.next(),new Si(this.d,this.c,this.d.c)};_.S=function(){return !this.a.done};var xe=wh(61);dh(148,230,pp,Si);_.V=function(){return this.b.value[0]};_.W=function(){return Ri(this)};_.X=function(a){return Ni(this.a,this.b.value[0],a)};_.c=0;var ye=wh(148);dh(197,1,{});_.R=function(a){Xi(this,a)};_.Y=function(){return this.d};_.Z=function(){return this.e};_.d=0;_.e=0;var Be=wh(197);dh(66,197,{});var Ae=wh(66);dh(23,1,{},$i);_.Y=Cp;_.Z=function(){Zi(this);return this.c};_.R=function(a){Zi(this);this.d.R(a)};_.$=function(a){Zi(this);if(this.d.S()){a.v(this.d.T());return true}return false};_.a=0;_.c=0;var Ce=wh(23);dh(196,1,{});_.c=false;var Le=wh(196);dh(27,196,{272:1,27:1},gj);var Ke=wh(27);dh(199,66,{},kj);_.$=function(a){this.b=false;while(!this.b&&this.c.$(new lj(this,a)));return this.b};_.b=false;var Ee=wh(199);dh(202,1,{},lj);_.v=function(a){jj(this.a,this.b,a)};var De=wh(202);dh(198,66,{},mj);_.$=function(a){return this.a.$(new nj(a))};var Ge=wh(198);dh(201,1,{},nj);_.v=function(a){this.a.v($m(new _m,a))};var Fe=wh(201);dh(200,1,{},pj);_.v=function(a){oj(this,a)};var He=wh(200);dh(203,1,{},qj);_.v=function(a){};var Ie=wh(203);dh(204,1,{},sj);_.v=function(a){rj(this,a)};var Je=wh(204);dh(289,1,{});dh(232,1,{});var Me=wh(232);dh(286,1,{});var zj=0;var Bj,Cj=0,Dj;dh(895,1,{});dh(227,1,{});var Ne=wh(227);dh(271,$wnd.Function,{},Rj);_.ab=function(a){Qj(this.a,this.b,a)};dh(7,32,{3:1,30:1,32:1,7:1},Ak);var dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk,yk;var Oe=xh(7,Bk);var Ck;dh(270,$wnd.Function,{},Ek);_.D=function(a){return Gb(Ck),Ck=null,null};dh(91,227,{});var Af=wh(91);dh(92,91,{});_.d=0;var Ef=wh(92);dh(93,92,ep,Mk);_.s=Jp;_.o=Dp;_.q=Ep;_.t=Kp;var Ik=0;var Ze=wh(93);dh(95,1,hp,Nk);_.u=function(){Jk(this.a)};var Pe=wh(95);dh(94,1,{},Pk);var Qe=wh(94);dh(96,1,cp,Qk);_.r=function(){return Kk(this.a)};var Re=wh(96);dh(97,1,kp,Rk);_.u=function(){Gk(this.a)};var Se=wh(97);dh(98,1,cp,Sk);_.r=function(){return Hk(this.a)};var Te=wh(98);dh(100,227,{});var zf=wh(100);dh(101,100,{});_.c=0;var Df=wh(101);dh(102,101,ep,Yk);_.s=Lp;_.o=Dp;_.q=Ep;_.t=Mp;var Wk=0;var Ye=wh(102);dh(104,1,hp,Zk);_.u=Np;var Ue=wh(104);dh(103,1,{},_k);var Ve=wh(103);dh(105,1,kp,al);_.u=function(){Uk(this.a)};var We=wh(105);dh(106,1,cp,bl);_.r=function(){return Vk(this.a)};var Xe=wh(106);dh(129,227,{});_.f='';var Mf=wh(129);dh(130,129,{});_.d=0;var Gf=wh(130);dh(131,130,ep,nl);_.s=Jp;_.o=Dp;_.q=Ep;_.t=Kp;var hl=0;var ef=wh(131);dh(133,1,hp,ol);_.u=function(){il(this.a)};var $e=wh(133);dh(132,1,{},ql);var _e=wh(132);dh(135,1,cp,rl);_.r=function(){return gl(this.a)};var af=wh(135);dh(136,1,hp,sl);_.u=function(){cl(this.a)};var bf=wh(136);dh(137,1,hp,tl);_.u=function(){kl(this.a,this.b)};var cf=wh(137);dh(134,1,kp,ul);_.u=function(){Gk(this.a)};var df=wh(134);dh(108,227,{});_.i=false;var Of=wh(108);dh(109,108,{});_.f=0;var If=wh(109);dh(110,109,ep,Ql);_.s=function(){fc(this.e)};_.o=Dp;_.q=Ep;_.t=function(){return this.e.i<0};var Gl=0;var rf=wh(110);dh(112,1,hp,Rl);_.u=function(){Hl(this.a)};var ff=wh(112);dh(111,1,{},Tl);var gf=wh(111);dh(115,1,cp,Ul);_.r=function(){return Fl(this.a)};var hf=wh(115);dh(42,1,hp,Vl);_.u=function(){Pl(this.a,yn(this.b))};var jf=wh(42);dh(113,1,cp,Wl);_.r=function(){return Jl(this.a)};var kf=wh(113);dh(58,1,hp,Xl);_.u=function(){Bl(this.a,this.b)};var lf=wh(58);dh(116,1,hp,Yl);_.u=function(){Al(this.a,this.b)};var mf=wh(116);dh(117,1,hp,Zl);_.u=function(){zl(this.a,this.b)};var nf=wh(117);dh(118,1,hp,$l);_.u=function(){vl(this.a,this.b)};var of=wh(118);dh(114,1,kp,_l);_.u=function(){El(this.a)};var pf=wh(114);dh(119,1,hp,am);_.u=function(){Cl(this.a)};var qf=wh(119);dh(121,227,{});var Qf=wh(121);dh(122,121,{});_.c=0;var Kf=wh(122);dh(123,122,ep,hm);_.s=Lp;_.o=Dp;_.q=Ep;_.t=Mp;var fm=0;var wf=wh(123);dh(125,1,hp,im);_.u=Np;var sf=wh(125);dh(124,1,{},km);var tf=wh(124);dh(126,1,kp,lm);_.u=function(){Uk(this.a)};var uf=wh(126);dh(127,1,cp,mm);_.r=function(){return em(this.a)};var vf=wh(127);dh(252,$wnd.Function,{},nm);_.eb=function(a){so(this.a.f)};dh(185,1,{},om);var xf=wh(185);var pm;dh(207,1,{},rm);var yf=wh(207);var sm;dh(253,$wnd.Function,{},um);_.fb=function(a){return new xm(a)};var vm;dh(99,$wnd.React.Component,{},xm);bh(_g[1],_);_.componentWillUnmount=function(){Fk(this.a)};_.render=function(){return Lk(this.a)};_.shouldComponentUpdate=Op;var Bf=wh(99);dh(254,$wnd.Function,{},ym);_.fb=function(a){return new Bm(a)};var zm;dh(107,$wnd.React.Component,{},Bm);bh(_g[1],_);_.componentWillUnmount=function(){Tk(this.a)};_.render=function(){return Xk(this.a)};_.shouldComponentUpdate=Pp;var Cf=wh(107);dh(268,$wnd.Function,{},Cm);_.fb=function(a){return new Fm(a)};var Dm;dh(138,$wnd.React.Component,{},Fm);bh(_g[1],_);_.componentWillUnmount=function(){Fk(this.a)};_.render=function(){return ll(this.a)};_.shouldComponentUpdate=Op;var Ff=wh(138);dh(255,$wnd.Function,{},Gm);_.fb=function(a){return new Jm(a)};var Hm;dh(120,$wnd.React.Component,{},Jm);bh(_g[1],_);_.componentDidUpdate=function(a){Ml(this.a)};_.componentWillUnmount=function(){Dl(this.a)};_.render=function(){return Nl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Hf=wh(120);dh(265,$wnd.Function,{},Km);_.fb=function(a){return new Nm(a)};var Lm;dh(128,$wnd.React.Component,{},Nm);bh(_g[1],_);_.componentWillUnmount=function(){Tk(this.a)};_.render=function(){return gm(this.a)};_.shouldComponentUpdate=Pp;var Jf=wh(128);dh(266,$wnd.Function,{},Om);_.db=function(a){dl(this.a,a)};dh(267,$wnd.Function,{},Pm);_.cb=function(a){jl(this.a,a)};dh(184,1,{},Qm);var Lf=wh(184);var Rm;dh(262,$wnd.Function,{},Tm);_.cb=function(a){Il(this.a,a)};dh(256,$wnd.Function,{},Um);_.cb=function(a){Tn(this.a)};dh(258,$wnd.Function,{},Vm);_.eb=function(a){Kl(this.a,this.b)};dh(259,$wnd.Function,{},Wm);_.eb=function(a){wl(this.a,this.b)};dh(260,$wnd.Function,{},Xm);_.v=function(a){xl(this.a,a)};dh(261,$wnd.Function,{},Ym);_.bb=function(a){Ll(this.a,this.b)};dh(263,$wnd.Function,{},Zm);_.db=function(a){yl(this.a,this.b,a)};dh(206,1,{},_m);var Nf=wh(206);var an;dh(264,$wnd.Function,{},cn);_.cb=function(a){bm(this.a,a)};dh(70,1,{},dn);var Pf=wh(70);var en;dh(83,1,{},gn);var Wf=wh(83);dh(84,1,{},jn);var Rf=wh(84);dh(88,1,{},kn);var Sf=wh(88);dh(87,1,{},ln);var Tf=wh(87);dh(85,1,{},nn);var Uf=wh(85);dh(86,1,{},pn);var Vf=wh(86);dh(188,1,{});var Dg=wh(188);dh(189,188,ep,Cn);_.s=Jp;_.o=Dp;_.q=Ep;_.t=Kp;var cg=wh(189);dh(190,1,hp,Dn);_.u=function(){wn(this.a)};var Xf=wh(190);dh(192,1,kp,En);_.u=function(){rn(this.a)};var Yf=wh(192);dh(193,1,kp,Fn);_.u=function(){sn(this.a)};var Zf=wh(193);dh(195,1,hp,Gn);_.u=function(){zn(this.a)};var $f=wh(195);dh(64,1,hp,Hn);_.u=function(){vn(this.a)};var _f=wh(64);dh(191,1,cp,In);_.r=function(){var a;return a=(nh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var ag=wh(191);dh(194,1,hp,Jn);_.u=function(){qn(this.a,this.b)};var bg=wh(194);dh(48,1,{48:1});_.d=false;var Lg=wh(48);dh(49,48,{9:1,273:1,49:1,48:1},Un);_.s=Jp;_.o=function(a){return Nn(this,a)};_.q=function(){return this.c.d};_.t=Kp;var Kn=0;var ug=wh(49);dh(208,1,hp,Vn);_.u=function(){Ln(this.a)};var dg=wh(208);dh(209,1,hp,Wn);_.u=function(){Qn(this.a)};var eg=wh(209);dh(45,157,{45:1});var Gg=wh(45);dh(158,45,{9:1,45:1},eo);_.s=function(){fc(this.f)};_.o=Dp;_.q=Ep;_.t=function(){return this.f.i<0};var og=wh(158);dh(160,1,hp,fo);_.u=function(){Yn(this.a)};var fg=wh(160);dh(159,1,hp,go);_.u=function(){ao(this.a)};var gg=wh(159);dh(165,1,hp,ho);_.u=function(){_b(this.a,this.b,true)};var hg=wh(165);dh(166,1,cp,io);_.r=function(){return Xn(this.a,this.c,this.b)};_.b=false;var ig=wh(166);dh(161,1,cp,jo);_.r=function(){return bo(this.a)};var jg=wh(161);dh(162,1,cp,ko);_.r=function(){return Hh(Vg(cj(_n(this.a))))};var kg=wh(162);dh(163,1,cp,lo);_.r=function(){return Hh(Vg(cj(dj(_n(this.a),new Xo))))};var lg=wh(163);dh(164,1,cp,mo);_.r=function(){return co(this.a)};var mg=wh(164);dh(145,1,{69:1},po);_.C=function(){return new eo};var no;var ng=wh(145);dh(46,1,{46:1});var Kg=wh(46);dh(167,46,{9:1,46:1},wo);_.s=function(){fc(this.a)};_.o=Dp;_.q=Ep;_.t=function(){return this.a.i<0};var tg=wh(167);dh(168,1,hp,xo);_.u=function(){to(this.a,this.b)};_.b=false;var pg=wh(168);dh(169,1,hp,yo);_.u=function(){Bn(this.b,this.a)};var qg=wh(169);dh(170,1,hp,zo);_.u=function(){uo(this.a)};var rg=wh(170);dh(146,1,{69:1},Ao);_.C=function(){return new wo(this.a.C())};var sg=wh(146);dh(47,1,{47:1});var Ng=wh(47);dh(171,47,{9:1,47:1},Jo);_.s=function(){fc(this.g)};_.o=Dp;_.q=Ep;_.t=function(){return this.g.i<0};var Bg=wh(171);dh(172,1,hp,Ko);_.u=function(){Do(this.a)};var vg=wh(172);dh(173,1,cp,Lo);_.r=function(){var a;return a=yn(this.a.i),Nh(Ap,a)?(Uo(),Ro):Nh(Bp,a)?(Uo(),To):(Uo(),So)};var wg=wh(173);dh(174,1,cp,Mo);_.r=function(){return Fo(this.a)};var xg=wh(174);dh(175,1,kp,No);_.u=function(){Go(this.a)};var yg=wh(175);dh(176,1,kp,Oo);_.u=function(){Ho(this.a)};var zg=wh(176);dh(147,1,{69:1},Po);_.C=function(){return new Jo(this.a.C())};var Ag=wh(147);dh(186,1,{},Qo);_.handleEvent=function(a){tn(this.a,a)};var Cg=wh(186);dh(33,32,{3:1,30:1,32:1,33:1},Vo);var Ro,So,To;var Eg=xh(33,Wo);dh(151,1,{},Xo);_._=function(a){return !Pn(a)};var Fg=wh(151);dh(153,1,{},Yo);_._=function(a){return Pn(a)};var Hg=wh(153);dh(154,1,{},Zo);_.v=function(a){$n(this.a,a)};var Ig=wh(154);dh(152,1,{},$o);_.v=function(a){ro(this.a,a)};_.a=false;var Jg=wh(152);dh(155,1,{},_o);_._=function(a){return Co(this.a,a)};var Mg=wh(155);var ld=yh('D');var ap=(xc(),Ac);var gwtOnLoad=gwtOnLoad=Zg;Xg(jh);$g('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();