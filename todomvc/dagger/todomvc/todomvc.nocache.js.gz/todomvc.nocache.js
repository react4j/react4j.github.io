function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='9500FCDA1F333ED4C8376B37FF7616C8',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '9500FCDA1F333ED4C8376B37FF7616C8';function o(){}
function oj(){}
function nj(){}
function hh(){}
function dh(){}
function Hb(){}
function Hn(){}
function Kc(){}
function Rc(){}
function Dk(){}
function tm(){}
function xm(){}
function Bm(){}
function Fm(){}
function Jm(){}
function oo(){}
function Wo(){}
function Xo(){}
function Pc(a){Oc()}
function pm(a){om=a}
function sm(a){rm=a}
function Rm(a){Qm=a}
function an(a){_m=a}
function en(a){dn=a}
function ph(){ph=dh}
function ni(){ei(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function lb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function cc(a){this.a=a}
function lc(a){this.a=a}
function lj(a){this.a=a}
function qj(a){this.a=a}
function Eh(a){this.a=a}
function Yh(a){this.a=a}
function Yk(a){this.a=a}
function Mk(a){this.a=a}
function Pk(a){this.a=a}
function Qk(a){this.a=a}
function Rk(a){this.a=a}
function $k(a){this.a=a}
function _k(a){this.a=a}
function bi(a){this.a=a}
function ci(a){this.a=a}
function ai(a){this.b=a}
function pi(a){this.c=a}
function pl(a){this.a=a}
function al(a){this.a=a}
function nl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function tl(a){this.a=a}
function Ql(a){this.a=a}
function Tl(a){this.a=a}
function Vl(a){this.a=a}
function $l(a){this.a=a}
function _l(a){this.a=a}
function hm(a){this.a=a}
function km(a){this.a=a}
function lm(a){this.a=a}
function mm(a){this.a=a}
function Nm(a){this.a=a}
function Om(a){this.a=a}
function Sm(a){this.a=a}
function Tm(a){this.a=a}
function Wm(a){this.a=a}
function bn(a){this.a=a}
function hn(a){this.a=a}
function jn(a){this.a=a}
function kn(a){this.a=a}
function mn(a){this.a=a}
function on(a){this.a=a}
function Cn(a){this.a=a}
function Dn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Gn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function eo(a){this.a=a}
function fo(a){this.a=a}
function io(a){this.a=a}
function jo(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Jo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function mj(a,b){a.a=b}
function Ij(a,b){a.key=b}
function Hj(a,b){Gj(a,b)}
function qo(a,b){Qn(b,a)}
function Ep(a){Ri(this,a)}
function Hp(a){Ih(this,a)}
function Ip(){fc(this.c)}
function Kp(){fc(this.b)}
function zi(){this.a=Ii()}
function Ni(){this.a=Ii()}
function gc(a){!!a&&a.u()}
function V(a){!!a&&cb(a)}
function w(a){--a.e;D(a)}
function gb(a){Vb((J(),a))}
function hb(a){Wb((J(),a))}
function jb(a){Xb((J(),a))}
function jc(a,b){Uh(a.e,b)}
function pj(a,b){gj(a.a,b)}
function po(a,b){Yn(a.b,b)}
function vl(a,b){Zn(a.j,b)}
function C(a,b){ab(a.f,b.f)}
function sb(a,b){a.b=Ui(b)}
function Sk(a){a.c=2;fc(a.b)}
function Ek(a){a.d=2;fc(a.c)}
function Cl(a){a.e=2;fc(a.d)}
function Kb(a){a.a=-4&a.a|1}
function Pg(a){return a.b}
function wl(a,b){return a.f=b}
function Lh(a,b){return a===b}
function Gp(){return this.b}
function Bp(){return this.a}
function Dp(){return yj(this)}
function Mp(){mb(this.a.a)}
function Ik(a){mb(a.b);R(a.a)}
function vn(a){R(a.a);cb(a.b)}
function hl(a){mb(a.a);cb(a.b)}
function Kn(a){cb(a.b);cb(a.a)}
function Oh(a){pc.call(this,a)}
function Cp(a){return this===a}
function hi(a,b){return a.a[b]}
function sh(a){rh(a);return a.k}
function rc(){rc=dh;qc=new o}
function Hc(){Hc=dh;Gc=new Kc}
function J(){J=dh;I=new F}
function no(){no=dh;mo=new oo}
function Ei(){Ei=dh;Di=Gi()}
function xc(){xc=dh;!!(Oc(),Nc)}
function Jh(){mc(this);this.A()}
function Fp(){return Wh(this.a)}
function Jp(){return this.c.i<0}
function Lp(){return this.b.i<0}
function Sc(a,b){return xh(a,b)}
function uj(a,b){a.splice(b,1)}
function ec(a,b,c){Th(a.e,b,c)}
function Ln(a,b,c){ec(a.c,b,c)}
function Vi(a,b){while(a.$(b));}
function gj(a,b){mj(a,fj(a.a,b))}
function v(a,b,c){s(a,new H(c),b)}
function fj(a,b){a.N(b);return a}
function Rj(a,b){a.ref=b;return a}
function xn(a){ib(a.b);return a.e}
function On(a){ib(a.a);return a.d}
function Do(a){ib(a.d);return a.f}
function Ii(){Ei();return new Di}
function Xc(a){return new Array(a)}
function Wh(a){return a.a.b+a.b.b}
function W(a){return !!a&&a.c.i<0}
function Np(a){return 1==this.a.d}
function Op(a){return 1==this.a.c}
function Ki(a,b){return a.a.get(b)}
function di(a,b){this.a=a;this.b=b}
function dc(a,b){this.a=a;this.b=b}
function Ch(a,b){this.a=a;this.b=b}
function jj(a,b){this.a=a;this.b=b}
function Pj(a,b){this.a=a;this.b=b}
function sl(a,b){this.a=a;this.b=b}
function Ul(a,b){this.a=a;this.b=b}
function Wl(a,b){this.a=a;this.b=b}
function Xl(a,b){this.a=a;this.b=b}
function Yl(a,b){this.a=a;this.b=b}
function Zl(a,b){this.a=a;this.b=b}
function zk(a,b){Ch.call(this,a,b)}
function Um(a,b){this.a=a;this.b=b}
function Vm(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function Ym(a,b){this.a=a;this.b=b}
function Sj(a,b){a.href=b;return a}
function sj(a,b,c){a.splice(b,0,c)}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function db(a){J();Wb(a);a.e=-2}
function yn(a){wn(a,(ib(a.b),a.e))}
function cn(){this.a=Jj((Lm(),Km))}
function nm(){this.a=Jj((vm(),um))}
function qm(){this.a=Jj((zm(),ym))}
function Pm(){this.a=Jj((Dm(),Cm))}
function $m(){this.a=Jj((Hm(),Gm))}
function In(a,b){this.a=a;this.b=b}
function go(a,b){this.a=a;this.b=b}
function wo(a,b){this.a=a;this.b=b}
function xo(a,b){this.b=a;this.a=b}
function Uo(a,b){Ch.call(this,a,b)}
function ak(a,b){a.value=b;return a}
function Vh(a){a.a=new zi;a.b=new Ni}
function ei(a){a.a=Uc(_d,cp,1,0,5,1)}
function Pn(a){Qn(a,(ib(a.a),!a.d))}
function Rb(a){return !a.d?a:Rb(a.d)}
function Sh(a){return !a?null:a.W()}
function jd(a){return a==null?null:a}
function Ti(a){return a!=null?r(a):0}
function gd(a){return typeof a===ap}
function Xg(){Vg==null&&(Vg=[])}
function Fc(){uc!=0&&(uc=0);wc=-1}
function Ec(a){$wnd.clearTimeout(a)}
function kb(a){this.c=new ni;this.b=a}
function Fb(a){this.d=Ui(a);this.b=100}
function Gl(a){mb(a.b);R(a.c);cb(a.a)}
function bc(a,b){_b(a,b,false);hb(a.d)}
function tj(a,b){rj(b,0,a,0,b.length)}
function Xj(a,b){a.onBlur=b;return a}
function Tj(a,b){a.onClick=b;return a}
function Yj(a,b){a.onChange=b;return a}
function Vj(a,b){a.checked=b;return a}
function Gj(a,b){for(var c in a){b(c)}}
function Zc(a,b,c){return {l:a,m:b,h:c}}
function B(a,b,c){return t(a,c,2048,b)}
function Kh(a,b){return a.charCodeAt(b)}
function Nh(a){return !a?'null':''+a.a}
function ed(a,b){return a!=null&&cd(a,b)}
function X(a){return !(!!a&&1==(a.c&7))}
function yj(a){return a.$H||(a.$H=++xj)}
function hd(a){return typeof a==='string'}
function Zj(a,b){a.onKeyDown=b;return a}
function Uj(a){a.autoFocus=true;return a}
function rh(a){if(a.k!=null){return}zh(a)}
function jh(a){this.b=Ui(a);this.a=this}
function pc(a){this.c=a;mc(this);this.A()}
function ej(a,b){_i.call(this,a);this.a=b}
function ac(a,b){jc(b.c,a);ed(b,9)&&b.s()}
function rb(a){J();qb(a);ub(a,2,true)}
function ib(a){var b;Sb((J(),b=Nb,b),a)}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function P(){this.a=Uc(_d,cp,1,100,5,1)}
function ti(){this.a=new zi;this.b=new Ni}
function Cj(){Cj=dh;zj=new o;Bj=new o}
function A(a,b,c){t(a,new G(b),c,null)}
function Zk(a,b){return new Xk(Ui(b),a.a)}
function ol(a,b){return new ml(Ui(b),a.a)}
function fd(a){return typeof a==='boolean'}
function u(a,b){return new xb(Ui(a),null,b)}
function Bi(a,b){var c;c=a[pp];c.call(a,b)}
function nc(a,b){a.b=b;b!=null&&wj(b,lp,a)}
function Ri(a,b){while(a.S()){pj(b,a.T())}}
function Wj(a,b){a.defaultValue=b;return a}
function bk(a,b){a.onDoubleClick=b;return a}
function $(a,b,c){Kb(Ui(c));K(a.a[b],Ui(c))}
function wj(b,c,d){try{b[c]=d}catch(a){}}
function Ll(a){A((J(),J(),I),new _l(a),up)}
function zn(a){A((J(),J(),I),new Fn(a),up)}
function Sn(a){A((J(),J(),I),new Vn(a),up)}
function ro(a){A((J(),J(),I),new yo(a),up)}
function Fo(a){W((ib(a.d),a.f))&&Ho(a,null)}
function bo(a){return Fh(S(a.e).a-S(a.a).a)}
function yc(a,b,c){return a.apply(b,c);var d}
function Qi(a,b,c){this.a=a;this.b=b;this.c=c}
function Ok(a,b,c){this.a=a;this.b=b;this.c=c}
function Sl(a,b,c){this.a=a;this.b=b;this.c=c}
function jm(a,b,c){this.a=a;this.b=b;this.c=c}
function fi(a,b){a.a[a.a.length]=b;return true}
function mc(a){a.d&&a.b!==kp&&a.A();return a}
function vh(a){var b;b=uh(a);Bh(a,b);return b}
function Hh(){Hh=dh;Gh=Uc(Xd,cp,30,256,0,1)}
function mh(){mh=dh;lh=$wnd.window.document}
function Oc(){Oc=dh;var a;!Qc();a=new Rc;Nc=a}
function Eb(a){while(true){if(!Db(a)){break}}}
function ho(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new bb;this.a=new Fb(this.f)}
function il(a,b){A((J(),J(),I),new sl(a,b),up)}
function Hl(a,b){A((J(),J(),I),new Zl(a,b),up)}
function Jl(a,b){A((J(),J(),I),new Xl(a,b),up)}
function Kl(a,b){A((J(),J(),I),new Wl(a,b),up)}
function Nl(a,b){A((J(),J(),I),new Ul(a,b),up)}
function Zn(a,b){A((J(),J(),I),new go(a,b),up)}
function uo(a,b){A((J(),J(),I),new wo(a,b),up)}
function _n(a){Ih(new bi(a.g),new cc(a));Vh(a.g)}
function Gb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Xi(a){if(!a.d){a.d=a.b.M();a.c=a.b.O()}}
function hj(a,b,c){if(a.a._(c)){a.b=true;b.v(c)}}
function pb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function jl(a,b){var c;c=b.target;ll(a,c.value)}
function $h(a){var b;b=a.a.T();a.b=Zh(a);return b}
function Lc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ji(a,b){var c;c=a.a[b];uj(a.a,b);return c}
function Ji(a,b){return !(a.a.get(b)===undefined)}
function Nk(a,b){return new Lk(Ui(b),a.a,a.b,a.c)}
function Rl(a,b){return new Pl(Ui(b),a.a,a.b,a.c)}
function im(a,b){return new gm(Ui(b),a.a,a.b,a.c)}
function cj(a){$i(a);return new ej(a,new kj(a.a))}
function kh(a){Ui(a);return ed(a,43)?a:new jh(a)}
function kl(a){return B((J(),J(),I),a.a,new ql(a))}
function Wk(a){return B((J(),J(),I),a.a,new al(a))}
function Kk(a){return B((J(),J(),I),a.b,new Rk(a))}
function Ml(a){return B((J(),J(),I),a.b,new Tl(a))}
function fm(a){return B((J(),J(),I),a.a,new lm(a))}
function Jk(a){return ph(),S(a.e.b).a>0?true:false}
function ao(a){return ph(),0==S(a.e).a?true:false}
function Ao(a){return Lh(Ap,a)||Lh(wp,a)||Lh('',a)}
function Wc(a){return Array.isArray(a)&&a.ib===hh}
function dd(a){return !Array.isArray(a)&&a.ib===hh}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Xn(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function Zi(a){if(!a.b){$i(a);a.c=true}else{Zi(a.b)}}
function Fk(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function Tk(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function Dl(a){if(0==a.e){a.e=1;a.n.forceUpdate()}}
function Fj(){if(Aj==256){zj=Bj;Bj=new o;Aj=0}++Aj}
function Ui(a){if(a==null){throw Pg(new Jh)}return a}
function Xh(a,b){if(b){return Rh(a.a,b)}return false}
function bj(a,b){$i(a);return new ej(a,new ij(b,a.a))}
function wn(a,b){A((J(),J(),I),new In(a,b),75497472)}
function am(a,b){var c;c=b.target;uo(a.e,c.checked)}
function ll(a,b){var c;c=a.f;if(b!=c){a.f=b;hb(a.b)}}
function Ol(a,b){var c;c=a.g;if(b!=c){a.g=b;hb(a.a)}}
function Qn(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function li(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function _j(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function wh(a,b){var c;c=uh(a);Bh(a,c);c.e=b?8:0;return c}
function An(a,b){var c;c=a.e;if(b!=c){a.e=Ui(b);hb(a.b)}}
function un(a){var b;T(a.a);b=S(a.a);Lh(a.f,b)&&An(a,b)}
function Co(a){mb(a.e);mb(a.a);R(a.b);R(a.c);cb(a.d)}
function zl(a,b){Ho(a.k,b);A((J(),J(),I),new Ul(a,b),up)}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function kj(a){Wi.call(this,a.Z(),a.Y()&-6);this.a=a}
function _i(a){if(!a){this.b=null;new ni}else{this.b=a}}
function Wi(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Yi(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function si(a,b){return jd(a)===jd(b)||a!=null&&p(a,b)}
function Yn(a,b){return t((J(),J(),I),new ho(a,b),up,null)}
function yl(a,b){A((J(),J(),I),new Ul(a,b),up);Ho(a.k,null)}
function nb(a){C((J(),J(),I),a);0==(a.f.a&hp)&&D((null,I))}
function qn(a){nh((mh(),$wnd.window.window),yp,a.d,false)}
function rn(a){oh((mh(),$wnd.window.window),yp,a.d,false)}
function Dc(a){xc();$wnd.setTimeout(function(){throw a},0)}
function Ug(a){if(gd(a)){return a|0}return a.l|a.m<<22}
function yh(a){if(a.K()){return null}var b=a.j;return $g[b]}
function Ob(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);qb(a.e)}}
function ul(a,b){var c;if(S(a.c)){c=b.target;Ol(a,c.value)}}
function Ih(a,b){var c,d;for(d=a.M();d.S();){c=d.T();b.v(c)}}
function gn(a){return new Ok(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function ln(a){return new Sl(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function nn(a){return new jm(a.a.a.C(),a.a.b.C(),a.a.c.C())}
function Vo(){To();return Yc(Sc(Dg,1),cp,32,0,[Qo,So,Ro])}
function vm(){vm=dh;var a;um=(a=eh(tm.prototype.fb,tm,[]),a)}
function zm(){zm=dh;var a;ym=(a=eh(xm.prototype.fb,xm,[]),a)}
function Dm(){Dm=dh;var a;Cm=(a=eh(Bm.prototype.fb,Bm,[]),a)}
function Hm(){Hm=dh;var a;Gm=(a=eh(Fm.prototype.fb,Fm,[]),a)}
function Lm(){Lm=dh;var a;Km=(a=eh(Jm.prototype.fb,Jm,[]),a)}
function so(a,b){var c;dj($n(a.b),(c=new ni,c)).L(new Zo(b))}
function xh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.F(b))}
function vi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function wi(a,b){var c;return ui(b,vi(a,b==null?0:(c=r(b),c|0)))}
function $n(a){ib(a.d);return new ej(null,new Yi(new bi(a.g),0))}
function $i(a){if(a.b){$i(a.b)}else if(a.c){throw Pg(new Dh)}}
function ic(a){gc(a.g);!!a.e&&hc(a);V(a.a);V(a.c);gc(a.b);gc(a.f)}
function oi(a){ei(this);tj(this.a,Qh(a,Uc(_d,cp,1,Wh(a.a),5,1)))}
function Ai(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function fh(a){function b(){}
;b.prototype=a||{};return new b}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function $j(a){a.placeholder='What needs to be done?';return a}
function oc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function ah(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Il(a){return ph(),Do(a.k)==a.n.props['a']?true:false}
function nh(a,b,c,d){a.addEventListener(b,c,(ph(),d?true:false))}
function oh(a,b,c,d){a.removeEventListener(b,c,(ph(),d?true:false))}
function sn(a,b){b.preventDefault();A((J(),J(),I),new Gn(a),up)}
function ij(a,b){Wi.call(this,b.Z(),b.Y()&-16449);this.a=a;this.c=b}
function wm(a){$wnd.React.Component.call(this,a);this.a=Nk(om,this)}
function Am(a){$wnd.React.Component.call(this,a);this.a=Zk(rm,this)}
function Em(a){$wnd.React.Component.call(this,a);this.a=ol(Qm,this)}
function Im(a){$wnd.React.Component.call(this,a);this.a=Rl(_m,this)}
function Mm(a){$wnd.React.Component.call(this,a);this.a=im(dn,this)}
function Oi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Ho(a,b){var c;c=a.f;if(!(b==c||!!b&&Mn(b,c))){a.f=b;hb(a.d)}}
function eb(a,b){var c,d;fi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function dj(a,b){var c;Zi(a);c=new nj;c.a=b;a.a.R(new qj(c));return c.a}
function aj(a){var b;Zi(a);b=0;while(a.a.$(new oj)){b=Qg(b,1)}return b}
function to(a){var b;dj(bj($n(a.b),new Xo),(b=new ni,b)).L(new Yo(a.b))}
function Lb(b){try{b.b.u()}catch(a){a=Og(a);if(!ed(a,5))throw Pg(a)}}
function Cc(a){a&&Jc((Hc(),Gc));--uc;if(a){if(wc!=-1){Ec(wc);wc=-1}}}
function Bc(a,b,c){var d;d=zc();try{return yc(a,b,c)}finally{Cc(d)}}
function Uc(a,b,c,d,e,f){var g;g=Vc(e,d);e!=10&&Yc(Sc(a,f),b,c,e,g);return g}
function Oj(a,b,c){!Lh(c,'key')&&!Lh(c,'ref')&&(a[c]=b[c],undefined)}
function Uh(a,b){return hd(b)?b==null?yi(a.a,null):Mi(a.b,b):yi(a.a,b)}
function Bo(a,b){return (To(),Ro)==a||(Qo==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function vj(a,b){return Tc(b)!=10&&Yc(q(b),b.hb,b.__elementTypeId$,Tc(b),a),a}
function kd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ac(b){xc();return function(){return Bc(b,this,arguments);var a}}
function tc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Pi(a){if(a.a.c!=a.c){return Ki(a.a,a.b.value[0])}return a.b.value[1]}
function Mn(a,b){var c;if(ed(b,48)){c=b;return a.c.d==c.c.d}else{return false}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function ii(a,b,c){for(;c<a.a.length;++c){if(si(b,a.a[c])){return c}}return -1}
function ki(a,b){var c;c=ii(a,b,0);if(c==-1){return false}uj(a.a,c);return true}
function bl(a){var b;b=Mh((ib(a.b),a.f));if(b.length>0){po(a.e,b);ll(a,'')}}
function Eo(a){var b,c;return b=S(a.b),dj(bj($n(a.j),new $o(b)),(c=new ni,c))}
function pn(a,b){a.f=b;Lh(b,S(a.a))&&An(a,b);tn(b);A((J(),J(),I),new Gn(a),up)}
function fc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new lc(a)),67108864,null)}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new lb(a)),0,null);!!a.b&&mb(a.b)}}
function vo(a){this.b=Ui(a);J();this.a=new kc(0,null,null,false,false)}
function _h(a){this.d=a;this.c=new Oi(this.d.b);this.a=this.c;this.b=Zh(this)}
function bb(){var a;this.a=Uc(od,cp,42,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function gi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.v(c)}}
function Ic(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Mc(b,c)}while(a.a);a.a=c}}
function Jc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Mc(b,c)}while(a.b);a.b=c}}
function Th(a,b,c){return hd(b)?b==null?xi(a.a,null,c):Li(a.b,b,c):xi(a.a,b,c)}
function Mj(a){var b;return Kj($wnd.React.StrictMode,null,null,(b={},b[qp]=Ui(a),b))}
function Tc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||mb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function tb(b){if(b){try{b.u()}catch(a){a=Og(a);if(ed(a,5)){J()}else throw Pg(a)}}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function cl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new rl(a),up)}}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;fi((!a.b&&(a.b=new ni),a.b),b)}}}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new ni);a.c=c.c}b.d=true;fi(a.c,Ui(b))}
function Bh(a,b){var c;if(!a){return}b.j=a;var d=yh(b);if(!d){$g[a]=[b];return}d.gb=b}
function Og(a){var b;if(ed(a,5)){return a}b=a&&a[lp];if(!b){b=new sc(a);Pc(b)}return b}
function eh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function uh(a){var b;b=new th;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Jj(a){var b;b=Lj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function qi(a){var b,c,d;d=0;for(c=new _h(a.a);c.b;){b=$h(c);d=d+(b?r(b):0);d=d|0}return d}
function qb(a){var b,c;for(c=new pi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Wg(){Xg();var a=Vg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Dh(){pc.call(this,"Stream already terminated, can't be modified or used")}
function xb(a,b,c){wb.call(this,null,a,b,c|(!a?262144:ep)|(0==(c&6291456)?!a?hp:ip:0)|0|0|0)}
function Mb(a,b){this.b=Ui(a);this.a=b|0|(0==(b&6291456)?ip:0)|(0!=(b&229376)?0:98304)}
function Zm(a,b){Ij(a.a,Nh(b?Fh(b.c.d):null));Ui(b);a.a.props['a']=b;return a.a}
function Mi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Bi(a.a,b);--a.b}return c}
function Wn(a,b,c){var d;d=new Tn(b,c);Ln(d,a,new dc(a,d));Th(a.g,Fh(d.c.d),d);hb(a.d);return d}
function Ph(a,b){var c,d;for(d=new _h(b.a);d.b;){c=$h(d);if(!Xh(a,c)){return false}}return true}
function Rg(a){var b;b=a.h;if(b==0){return a.l+a.m*ip}if(b==1048575){return a.l+a.m*ip-np}return a}
function Zh(a){if(a.a.S()){return true}if(a.a!=a.c){return false}a.a=new Ai(a.d.a);return a.a.S()}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&L(a,c);M(a,Ui(b))}
function _b(a,b,c){var d;d=Uh(a.g,b?Fh(b.c.d):null);if(null!=d){jc(b.c,a);c&&!!b&&fc(b.c);hb(a.d)}}
function Kj(a,b,c,d){var e;e=Lj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=Ui(d);return e}
function Yc(a,b,c,d,e){e.gb=a;e.hb=b;e.ib=hh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Li(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ui(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(si(a,c.V())){return c}}return null}
function Tg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=np;d=1048575}c=kd(e/ip);b=kd(e-c*ip);return Zc(b,c,d)}
function Go(a){var b;b=S(a.i.a);Lh(Ap,b)||Lh(wp,b)||Lh('',b)?wn(a.i,b):Ao(xn(a.i))?zn(a.i):wn(a.i,'')}
function fn(){this.a=kh((no(),no(),mo));this.b=kh(new zo(this.a));this.c=kh(new Oo(this.a))}
function To(){To=dh;Qo=new Uo('ACTIVE',0);So=new Uo('COMPLETED',1);Ro=new Uo('ALL',2)}
function Zg(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function xl(a,b,c){27==c.which?A((J(),J(),I),new Yl(a,b),up):13==c.which&&A((J(),J(),I),new Wl(a,b),up)}
function mb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Bb(a)),67108864,null);!!a.a&&R(a.a);Ib(a.f);a.c=a.c&-8|1}}
function Ck(){if(!Bk){Bk=(++(J(),J(),I).e,new Hb);$wnd.Promise.resolve(null).then(eh(Dk.prototype.D,Dk,[]))}}
function sc(a){rc();mc(this);this.b=a;a!=null&&wj(a,lp,this);this.c=a==null?'null':gh(a);this.a=a}
function th(){this.g=qh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function S(a){ib(a.e);vb(a.f)&&ob(a.f);if(a.b){if(ed(a.b,8)){throw Pg(a.b)}else{throw Pg(a.b)}}return a.k}
function q(a){return hd(a)?be:gd(a)?Td:fd(a)?Rd:dd(a)?a.gb:Wc(a)?a.gb:a.gb||Array.isArray(a)&&Sc(Kd,1)||Kd}
function r(a){return hd(a)?Ej(a):gd(a)?kd(a):fd(a)?a?1231:1237:dd(a)?a.q():Wc(a)?yj(a):!!a&&!!a.hashCode?a.hashCode():yj(a)}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&ep)?Lb(a):a.b.u();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function fb(a,b){var c,d;d=a.c;ki(d,b);!!a.b&&ep!=(a.b.c&fp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function $c(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return Zc(c&4194303,d&4194303,e&1048575)}
function Qg(a,b){var c;if(gd(a)&&gd(b)){c=a+b;if(-17592186044416<c&&c<np){return c}}return Rg($c(gd(a)?Tg(a):a,gd(b)?Tg(b):b))}
function Fh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Hh(),Gh)[b];!c&&(c=Gh[b]=new Eh(a));return c}return new Eh(a)}
function gh(a){var b;if(Array.isArray(a)&&a.ib===hh){return sh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Ej(a){Cj();var b,c,d;c=':'+a;d=Bj[c];if(d!=null){return kd(d)}d=zj[c];b=d==null?Dj(a):kd(d);Fj();Bj[c]=b;return b}
function ri(a){var b,c,d;d=1;for(c=new pi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=ji(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function Bl(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;Nl(a,a.n.props['a']);a.f.focus();a.f.select()}else a.i&&!b&&(a.i=false)}
function Al(a,b){var c;c=(ib(a.a),a.g);if(null!=c&&c.length!=0){A((J(),J(),I),new xo(b,c),up);Ho(a.k,null);Ol(a,c)}else{Zn(a.j,b)}}
function p(a,b){return hd(a)?Lh(a,b):gd(a)?a===b:fd(a)?a===b:dd(a)?a.o(b):Wc(a)?a===b:!!a&&!!a.equals?a.equals(b):jd(a)===jd(b)}
function yb(a,b){wb.call(this,a,new zb(a),null,b|(ep==(b&fp)?0:524288)|(0==(b&6291456)?ep==(b&fp)?ip:hp:0)|0|268435456|0)}
function Ak(){yk();return Yc(Sc(Ne,1),cp,7,0,[ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk])}
function Ah(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function mi(a,b){var c,d;d=a.a.length;b.length<d&&(b=vj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Qh(a,b){var c,d,e;e=Wh(a.a);b.length<e&&(b=vj(new Array(e),b));d=new _h(a.a);for(c=0;c<e;++c){b[c]=$h(d)}b.length>e&&(b[e]=null);return b}
function Qj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function zc(){var a;if(uc!=0){a=tc();if(a-vc>2000){vc=a;wc=$wnd.setTimeout(Fc,10)}}if(uc++==0){Ic((Hc(),Gc));return true}return false}
function Qc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function hc(a){var b,c,d;for(c=new pi(new oi(new Yh(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.V();ed(d,9)&&d.t()||b.W().u()}}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Wb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new pi(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&ub(b,6,true)}}}
function kc(a,b,c,d,e){var f;this.d=a;this.e=d?new ti:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new kb((J(),null)),f):null;this.c=null}
function U(a,b,c,d){this.c=Ui(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new yb(this,d);this.e=new kb(this.f);ep==(d&fp)&&nb(this.f)}
function Tn(a,b){var c,d,e;this.e=Ui(a);this.d=b;J();c=++Jn;this.c=new kc(c,null,new Un(this),true,true);this.b=(e=new kb(null),e);this.a=(d=new kb(null),d)}
function ml(a,b){var c,d;this.e=Ui(b);this.n=Ui(a);J();c=++gl;this.c=new kc(c,null,new nl(this),false,false);this.b=(d=new kb(null),d);this.a=new xb(null,Ui(new tl(this)),tp)}
function Xk(a,b){var c;this.d=Ui(b);this.n=Ui(a);J();c=++Vk;this.b=new kc(c,null,new Yk(this),false,false);this.a=new xb(null,Ui(new _k(this)),tp)}
function gm(a,b,c,d){var e;this.d=Ui(b);this.e=Ui(c);this.f=Ui(d);this.n=Ui(a);J();e=++em;this.b=new kc(e,null,new hm(this),false,false);this.a=new xb(null,Ui(new km(this)),tp)}
function cd(a,b){if(hd(a)){return !!bd[b]}else if(a.hb){return !!a.hb[b]}else if(gd(a)){return !!ad[b]}else if(fd(a)){return !!_c[b]}return false}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Mh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Vc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{Zb(b,d);try{f=(c.a.u(),null)}finally{$b()}return f}catch(a){a=Og(a);if(ed(a,5)){e=a;throw Pg(e)}else throw Pg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.r()}else{Zb(b,e);try{g=c.r()}finally{$b()}}return g}catch(a){a=Og(a);if(ed(a,5)){f=a;throw Pg(f)}else throw Pg(a)}finally{D(b)}}
function Db(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Jb(c);return true}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new pi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Yg(b,c,d,e){Xg();var f=Vg;$moduleName=c;$moduleBase=d;Ng=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{_o(g)()}catch(a){b(c,a)}}else{_o(g)()}}
function Lj(a,b){var c;c=new $wnd.Object;c.$$typeof=Ui(a);c.type=Ui(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Gi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Hi()}}
function Uk(a){var b,c,d;a.c=0;Ck();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),Nj('span',Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,['todo-count'])),[Nj('strong',null,[c]),' '+d+' left']));return b}
function _g(){$g={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Mc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].jb()&&(c=Lc(c,g)):g[0].jb()}catch(a){a=Og(a);if(ed(a,5)){d=a;xc();Dc(ed(d,34)?d.B():d)}else throw Pg(a)}}return c}
function fl(a){var b;a.d=0;Ck();b=Nj(vp,Uj(Yj(Zj(ak($j(Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,['new-todo']))),(ib(a.b),a.f)),eh(Nm.prototype.db,Nm,[a])),eh(Om.prototype.cb,Om,[a]))),null);return b}
function Q(b){var c,d,e;e=b.k;try{d=b.c.r();if(!(jd(e)===jd(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Og(a);if(ed(a,10)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Pg(c)}else throw Pg(a)}}
function xi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=ui(b,e);if(f){return f.X(c)}}e[e.length]=new di(b,c);++a.b;return null}
function rj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Dj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Kh(a,c++)}b=b|0;return b}
function L(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=Uc(_d,cp,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function ob(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.u()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Og(a);if(ed(a,5)){J()}else throw Pg(a)}}}
function ih(){var a;a=new fn;pm(gn(new hn(a)));sm(new $k((new jn(a)).a.a.C()));an(ln(new mn(a)));en(nn(new on(a)));Rm(new pl((new kn(a)).a.b.C()));$wnd.ReactDOM.render(Mj([(new cn).a]),(mh(),lh).getElementById('app'),null)}
function tn(a){var b;if(0==a.length){b=(mh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',lh.title,b)}else{(mh(),$wnd.window.window).location.hash=a}}
function Lk(a,b,c,d){var e;this.e=Ui(b);this.f=Ui(c);this.g=Ui(d);this.n=Ui(a);J();e=++Hk;this.c=new kc(e,null,new Mk(this),false,false);this.a=new U(new Pk(this),null,null,136478720);this.b=new xb(null,Ui(new Qk(this)),tp)}
function Pl(a,b,c,d){var e,f;this.j=Ui(b);Ui(c);this.k=Ui(d);this.n=Ui(a);J();e=++Fl;this.d=new kc(e,null,new Ql(this),false,false);this.a=(f=new kb(null),f);this.c=new U(new Vl(this),null,null,136478720);this.b=new xb(null,Ui(new $l(this)),tp);Nl(this,this.n.props['a'])}
function wb(a,b,c,d){this.b=new ni;this.f=new Mb(new Ab(this),d&6520832|262144|ep);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&hp)&&D((null,I)))}
function yi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(si(b,e.V())){if(d.length==1){d.length=0;Bi(a.a,g)}else{d.splice(h,1)}--a.b;return e.W()}}return null}
function bh(a,b,c){var d=$g,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=$g[b]),fh(h));_.hb=c;!b&&(_.ib=hh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.gb=f)}
function zh(a){if(a.J()){var b=a.c;b.K()?(a.k='['+b.j):!b.J()?(a.k='[L'+b.H()+';'):(a.k='['+b.H());a.b=b.G()+'[]';a.i=b.I()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Ah('.',[c,Ah('$',d)]);a.b=Ah('.',[c,Ah('.',d)]);a.i=d[d.length-1]}
function Rh(a,b){var c,d,e;c=b.V();e=b.W();d=hd(c)?c==null?Sh(wi(a.a,null)):Ki(a.b,c):Sh(wi(a.a,c));if(!(jd(e)===jd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(hd(c)?c==null?!!wi(a.a,null):Ji(a.b,c):!!wi(a.a,c))){return false}return true}
function Nj(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Hj(b,eh(Pj.prototype.ab,Pj,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[qp]=c[0],undefined):(d[qp]=c,undefined));return Kj(a,e,f,d)}
function Bn(){var a,b;this.d=new Po(this);this.f=this.e=(b=(mh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));J();this.c=new kc(0,null,new Cn(this),false,false);this.b=(a=new kb(null),a);this.a=new U(new Hn,new Dn(this),new En(this),35749888)}
function co(){var a;this.g=new ti;J();this.f=new kc(0,new fo(this),new eo(this),false,false);this.d=(a=new kb(null),a);this.c=new U(new io(this),null,null,zp);this.e=new U(new jo(this),null,null,zp);this.a=new U(new ko(this),null,null,zp);this.b=new U(new lo(this),null,null,zp)}
function Io(a){var b;this.j=Ui(a);this.i=new Bn;J();this.g=new kc(0,null,new Jo(this),false,false);this.d=(b=new kb(null),b);this.b=new U(new Ko(this),null,null,zp);this.c=new U(new Lo(this),null,null,zp);this.e=u(new Mo(this),413138944);this.a=u(new No(this),681574400);D((null,I))}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new pi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Og(a);if(!ed(a,5))throw Pg(a)}if(6==(b.c&7)){return true}}}}}qb(b);return false}
function Fi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ub(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){jb(a.a.e);tb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;tb((e=d.i,e));d.k=null}gi(a.b,new Cb(a));a.b.a=Uc(_d,cp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&tb((f=a.a.g,f))}}
function yk(){yk=dh;ck=new zk(rp,0);dk=new zk('checkbox',1);ek=new zk('color',2);fk=new zk('date',3);gk=new zk('datetime',4);hk=new zk('email',5);ik=new zk('file',6);jk=new zk('hidden',7);kk=new zk('image',8);lk=new zk('month',9);mk=new zk(ap,10);nk=new zk('password',11);ok=new zk('radio',12);pk=new zk('range',13);qk=new zk('reset',14);rk=new zk('search',15);sk=new zk('submit',16);tk=new zk('tel',17);uk=new zk('text',18);vk=new zk('time',19);wk=new zk('url',20);xk=new zk('week',21)}
function dm(a){var b,c,d;a.c=0;Ck();d=Nj('div',null,[Nj('div',null,[Nj(xp,Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,[xp])),[Nj('h1',null,['todos']),(new Pm).a]),S(a.d.c)?null:Nj('section',Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,[xp])),[Nj(vp,Yj(_j(Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,['toggle-all'])),(yk(),dk)),eh(bn.prototype.cb,bn,[a])),null),Nj('ul',Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,['todo-list'])),(b=dj(Ui(cj(S(a.f.c).Q())),(c=new ni,c)),mi(b,Xc(b.a.length))))]),S(a.d.c)?null:(new nm).a])]);return d}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=hi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&li(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=hi(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ji(a.b,g)}e&&sb(a.e,a.b)}else{e&&sb(a.e,new ni)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&ep!=(k.b.c&fp)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function Gk(a){var b,c;a.d=0;Ck();c=(b=S(a.g.b),Nj('footer',Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,['footer'])),[(new qm).a,Nj('ul',Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,['filters'])),[Nj('li',null,[Nj('a',Sj(Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,[(To(),Ro)==b?sp:null])),'#'),['All'])]),Nj('li',null,[Nj('a',Sj(Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,[Qo==b?sp:null])),'#active'),['Active'])]),Nj('li',null,[Nj('a',Sj(Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,[So==b?sp:null])),'#completed'),['Completed'])])]),S(a.a)?Nj(rp,Tj(Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,['clear-completed'])),eh(mm.prototype.eb,mm,[a])),['Clear Completed']):null]));return c}
function El(a){var b,c,d,e;a.e=0;Ck();b=a.n.props['a'];if(b.c.i<0){return null}c=(d=a.n.props['a'],e=(ib(d.a),d.d),Nj('li',Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,[e?wp:null,S(a.c)?'editing':null])),[Nj('div',Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,['view'])),[Nj(vp,Yj(Vj(_j(Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,['toggle'])),(yk(),dk)),e),eh(Tm.prototype.cb,Tm,[d])),null),Nj('label',bk(new $wnd.Object,eh(Um.prototype.eb,Um,[a,d])),[(ib(d.b),d.e)]),Nj(rp,Tj(Qj(new $wnd.Object,Yc(Sc(be,1),cp,2,6,['destroy'])),eh(Vm.prototype.eb,Vm,[a,d])),null)]),Nj(vp,Zj(Yj(Xj(Wj(Qj(Rj(new $wnd.Object,eh(Wm.prototype.v,Wm,[a])),Yc(Sc(be,1),cp,2,6,['edit'])),(ib(a.a),a.g)),eh(Xm.prototype.bb,Xm,[a,d])),eh(Sm.prototype.cb,Sm,[a])),eh(Ym.prototype.db,Ym,[a,d])),null)]));return c}
function Hi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[pp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Fi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[pp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var ap='number',bp={13:1},cp={3:1,4:1},dp={9:1},ep=1048576,fp=1835008,gp={6:1},hp=2097152,ip=4194304,jp={21:1},kp='__noinit__',lp='__java$exception',mp={3:1,10:1,8:1,5:1},np=17592186044416,op={39:1},pp='delete',qp='children',rp='button',sp='selected',tp=1411518464,up=142606336,vp='input',wp='completed',xp='header',yp='hashchange',zp=136413184,Ap='active';var _,$g,Vg,Ng=-1;_g();bh(1,null,{},o);_.o=Cp;_.p=function(){return this.gb};_.q=Dp;_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};var _c,ad,bd;bh(51,1,{},th);_.F=function(a){var b;b=new th;b.e=4;a>1?(b.c=xh(this,a-1)):(b.c=this);return b};_.G=function(){rh(this);return this.b};_.H=function(){return sh(this)};_.I=function(){rh(this);return this.i};_.J=function(){return (this.e&4)!=0};_.K=function(){return (this.e&1)!=0};_.e=0;_.g=0;var qh=1;var _d=vh(1);var Sd=vh(51);bh(78,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var nd=vh(78);bh(35,1,bp,G);_.r=function(){return this.a.u(),null};var ld=vh(35);bh(79,1,{},H);var md=vh(79);var I;bh(42,1,{42:1},P);_.b=0;_.c=false;_.d=0;var od=vh(42);bh(228,1,dp);var rd=vh(228);bh(18,228,dp,U);_.s=function(){R(this)};_.t=Bp;_.a=false;_.d=0;var pd=vh(18);bh(140,1,{264:1},bb);var qd=vh(140);bh(16,228,{9:1,16:1},kb);_.s=function(){cb(this)};_.t=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var td=vh(16);bh(175,1,gp,lb);_.u=function(){db(this.a)};var sd=vh(175);bh(17,228,{9:1,17:1},xb,yb);_.s=function(){mb(this)};_.t=function(){return 1==(this.c&7)};_.c=0;var yd=vh(17);bh(176,1,jp,zb);_.u=function(){Q(this.a)};var ud=vh(176);bh(177,1,gp,Ab);_.u=function(){ob(this.a)};var vd=vh(177);bh(178,1,gp,Bb);_.u=function(){rb(this.a)};var wd=vh(178);bh(179,1,{},Cb);_.v=function(a){pb(this.a,a)};var xd=vh(179);bh(141,1,{},Fb);_.a=0;_.b=0;_.c=0;var zd=vh(141);bh(180,1,dp,Hb);_.s=function(){Gb(this)};_.t=Bp;_.a=false;var Ad=vh(180);bh(62,228,{9:1,62:1},Mb);_.s=function(){Ib(this)};_.t=function(){return 2==(3&this.a)};_.a=0;var Bd=vh(62);bh(184,1,{},Yb);_.a=0;var Nb;var Cd=vh(184);bh(153,1,{});var Fd=vh(153);bh(146,1,{},cc);_.v=function(a){ac(this.a,a)};var Dd=vh(146);bh(147,1,gp,dc);_.u=function(){bc(this.a,this.b)};var Ed=vh(147);bh(154,153,{});var Gd=vh(154);bh(15,1,dp,kc);_.s=function(){fc(this)};_.t=function(){return this.i<0};_.d=0;_.i=0;var Id=vh(15);bh(174,1,gp,lc);_.u=function(){ic(this.a)};var Hd=vh(174);bh(5,1,{3:1,5:1});_.w=function(a){return new Error(a)};_.A=function(){var a,b,c;c=this.c==null?null:this.c.replace(new RegExp('\n','g'),' ');b=(a=sh(this.gb),c==null?a:a+': '+c);nc(this,oc(this.w(b)));Pc(this)};_.b=kp;_.d=true;var ce=vh(5);bh(10,5,{3:1,10:1,5:1});var Vd=vh(10);bh(8,10,mp);var ae=vh(8);bh(52,8,mp);var Yd=vh(52);bh(73,52,mp);var Md=vh(73);bh(34,73,{34:1,3:1,10:1,8:1,5:1},sc);_.B=function(){return jd(this.a)===jd(qc)?null:this.a};var qc;var Jd=vh(34);var Kd=vh(0);bh(210,1,{});var Ld=vh(210);var uc=0,vc=0,wc=-1;bh(87,210,{},Kc);var Gc;var Nd=vh(87);var Nc;bh(221,1,{});var Pd=vh(221);bh(74,221,{},Rc);var Od=vh(74);bh(43,1,{43:1,66:1},jh);_.C=function(){if(this===this.a){this.a=this.b.C();this.b=null}return this.a};var Qd=vh(43);var lh;_c={3:1,69:1,29:1};var Rd=vh(69);bh(40,1,{3:1,40:1});var $d=vh(40);ad={3:1,29:1,40:1};var Td=vh(220);bh(31,1,{3:1,29:1,31:1});_.o=Cp;_.q=Dp;_.b=0;var Ud=vh(31);bh(75,8,mp,Dh);var Wd=vh(75);bh(30,40,{3:1,29:1,30:1,40:1},Eh);_.o=function(a){return ed(a,30)&&a.a==this.a};_.q=Bp;_.a=0;var Xd=vh(30);var Gh;bh(282,1,{});bh(76,52,mp,Jh);_.w=function(a){return new TypeError(a)};var Zd=vh(76);bd={3:1,68:1,29:1,2:1};var be=vh(2);bh(286,1,{});bh(54,8,mp,Oh);var de=vh(54);bh(222,1,{38:1});_.L=Hp;_.P=function(){return new Yi(this,0)};_.Q=function(){return new ej(null,this.P())};_.N=function(a){throw Pg(new Oh('Add not supported on this collection'))};var ee=vh(222);bh(226,1,{209:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ed(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new _h((new Yh(d)).a);c.b;){b=$h(c);if(!Rh(this,b)){return false}}return true};_.q=function(){return qi(new Yh(this))};var pe=vh(226);bh(139,226,{209:1});var he=vh(139);bh(225,222,{38:1,233:1});_.P=function(){return new Yi(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ed(a,23)){return false}b=a;if(Wh(b.a)!=this.O()){return false}return Ph(this,b)};_.q=function(){return qi(this)};var qe=vh(225);bh(23,225,{23:1,38:1,233:1},Yh);_.M=function(){return new _h(this.a)};_.O=Fp;var ge=vh(23);bh(24,1,{},_h);_.R=Ep;_.T=function(){return $h(this)};_.S=Gp;_.b=false;var fe=vh(24);bh(223,222,{38:1,230:1});_.P=function(){return new Yi(this,16)};_.U=function(a,b){throw Pg(new Oh('Add not supported on this list'))};_.N=function(a){this.U(this.O(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ed(a,12)){return false}f=a;if(this.O()!=f.a.length){return false}e=new pi(f);for(c=new pi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(jd(b)===jd(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return ri(this)};_.M=function(){return new ai(this)};var je=vh(223);bh(86,1,{},ai);_.R=Ep;_.S=function(){return this.a<this.b.a.length};_.T=function(){return hi(this.b,this.a++)};_.a=0;var ie=vh(86);bh(56,222,{38:1},bi);_.M=function(){var a;a=new _h((new Yh(this.a)).a);return new ci(a)};_.O=Fp;var le=vh(56);bh(138,1,{},ci);_.R=Ep;_.S=function(){return this.a.b};_.T=function(){var a;a=$h(this.a);return a.W()};var ke=vh(138);bh(136,1,op);_.o=function(a){var b;if(!ed(a,39)){return false}b=a;return si(this.a,b.V())&&si(this.b,b.W())};_.V=Bp;_.W=Gp;_.q=function(){return Ti(this.a)^Ti(this.b)};_.X=function(a){var b;b=this.b;this.b=a;return b};var me=vh(136);bh(137,136,op,di);var ne=vh(137);bh(227,1,op);_.o=function(a){var b;if(!ed(a,39)){return false}b=a;return si(this.b.value[0],b.V())&&si(Pi(this),b.W())};_.q=function(){return Ti(this.b.value[0])^Ti(Pi(this))};var oe=vh(227);bh(12,223,{3:1,12:1,38:1,230:1},ni,oi);_.U=function(a,b){sj(this.a,a,b)};_.N=function(a){return fi(this,a)};_.L=function(a){gi(this,a)};_.M=function(){return new pi(this)};_.O=function(){return this.a.length};var se=vh(12);bh(14,1,{},pi);_.R=Ep;_.S=function(){return this.a<this.c.a.length};_.T=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var re=vh(14);bh(36,139,{3:1,36:1,209:1},ti);var te=vh(36);bh(59,1,{},zi);_.L=Hp;_.M=function(){return new Ai(this)};_.b=0;var ve=vh(59);bh(60,1,{},Ai);_.R=Ep;_.T=function(){return this.d=this.a[this.c++],this.d};_.S=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ue=vh(60);var Di;bh(57,1,{},Ni);_.L=Hp;_.M=function(){return new Oi(this)};_.b=0;_.c=0;var ye=vh(57);bh(58,1,{},Oi);_.R=Ep;_.T=function(){return this.c=this.a,this.a=this.b.next(),new Qi(this.d,this.c,this.d.c)};_.S=function(){return !this.a.done};var we=vh(58);bh(145,227,op,Qi);_.V=function(){return this.b.value[0]};_.W=function(){return Pi(this)};_.X=function(a){return Li(this.a,this.b.value[0],a)};_.c=0;var xe=vh(145);bh(194,1,{});_.R=function(a){Vi(this,a)};_.Y=function(){return this.d};_.Z=function(){return this.e};_.d=0;_.e=0;var Ae=vh(194);bh(63,194,{});var ze=vh(63);bh(22,1,{},Yi);_.Y=Bp;_.Z=function(){Xi(this);return this.c};_.R=function(a){Xi(this);this.d.R(a)};_.$=function(a){Xi(this);if(this.d.S()){a.v(this.d.T());return true}return false};_.a=0;_.c=0;var Be=vh(22);bh(193,1,{});_.c=false;var Ke=vh(193);bh(26,193,{267:1,26:1},ej);var Je=vh(26);bh(196,63,{},ij);_.$=function(a){this.b=false;while(!this.b&&this.c.$(new jj(this,a)));return this.b};_.b=false;var De=vh(196);bh(199,1,{},jj);_.v=function(a){hj(this.a,this.b,a)};var Ce=vh(199);bh(195,63,{},kj);_.$=function(a){return this.a.$(new lj(a))};var Fe=vh(195);bh(198,1,{},lj);_.v=function(a){this.a.v(Zm(new $m,a))};var Ee=vh(198);bh(197,1,{},nj);_.v=function(a){mj(this,a)};var Ge=vh(197);bh(200,1,{},oj);_.v=function(a){};var He=vh(200);bh(201,1,{},qj);_.v=function(a){pj(this,a)};var Ie=vh(201);bh(284,1,{});bh(229,1,{});var Le=vh(229);bh(281,1,{});var xj=0;var zj,Aj=0,Bj;bh(725,1,{});bh(755,1,{});bh(224,1,{});var Me=vh(224);bh(266,$wnd.Function,{},Pj);_.ab=function(a){Oj(this.a,this.b,a)};bh(7,31,{3:1,29:1,31:1,7:1},zk);var ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk,xk;var Ne=wh(7,Ak);var Bk;bh(265,$wnd.Function,{},Dk);_.D=function(a){return Gb(Bk),Bk=null,null};bh(88,224,{});var zf=vh(88);bh(89,88,{});_.d=0;var Df=vh(89);bh(90,89,dp,Lk);_.s=Ip;_.o=Cp;_.q=Dp;_.t=Jp;var Hk=0;var Ye=vh(90);bh(92,1,gp,Mk);_.u=function(){Ik(this.a)};var Oe=vh(92);bh(91,1,{},Ok);var Pe=vh(91);bh(93,1,bp,Pk);_.r=function(){return Jk(this.a)};var Qe=vh(93);bh(94,1,jp,Qk);_.u=function(){Fk(this.a)};var Re=vh(94);bh(95,1,bp,Rk);_.r=function(){return Gk(this.a)};var Se=vh(95);bh(97,224,{});var yf=vh(97);bh(98,97,{});_.c=0;var Cf=vh(98);bh(99,98,dp,Xk);_.s=Kp;_.o=Cp;_.q=Dp;_.t=Lp;var Vk=0;var Xe=vh(99);bh(101,1,gp,Yk);_.u=Mp;var Te=vh(101);bh(100,1,{},$k);var Ue=vh(100);bh(102,1,jp,_k);_.u=function(){Tk(this.a)};var Ve=vh(102);bh(103,1,bp,al);_.r=function(){return Uk(this.a)};var We=vh(103);bh(126,224,{});_.f='';var Lf=vh(126);bh(127,126,{});_.d=0;var Ff=vh(127);bh(128,127,dp,ml);_.s=Ip;_.o=Cp;_.q=Dp;_.t=Jp;var gl=0;var df=vh(128);bh(130,1,gp,nl);_.u=function(){hl(this.a)};var Ze=vh(130);bh(129,1,{},pl);var $e=vh(129);bh(132,1,bp,ql);_.r=function(){return fl(this.a)};var _e=vh(132);bh(133,1,gp,rl);_.u=function(){bl(this.a)};var af=vh(133);bh(134,1,gp,sl);_.u=function(){jl(this.a,this.b)};var bf=vh(134);bh(131,1,jp,tl);_.u=function(){Fk(this.a)};var cf=vh(131);bh(105,224,{});_.i=false;var Nf=vh(105);bh(106,105,{});_.e=0;var Hf=vh(106);bh(107,106,dp,Pl);_.s=function(){fc(this.d)};_.o=Cp;_.q=Dp;_.t=function(){return this.d.i<0};var Fl=0;var qf=vh(107);bh(109,1,gp,Ql);_.u=function(){Gl(this.a)};var ef=vh(109);bh(108,1,{},Sl);var ff=vh(108);bh(112,1,bp,Tl);_.r=function(){return El(this.a)};var gf=vh(112);bh(41,1,gp,Ul);_.u=function(){Ol(this.a,xn(this.b))};var hf=vh(41);bh(110,1,bp,Vl);_.r=function(){return Il(this.a)};var jf=vh(110);bh(55,1,gp,Wl);_.u=function(){Al(this.a,this.b)};var kf=vh(55);bh(113,1,gp,Xl);_.u=function(){zl(this.a,this.b)};var lf=vh(113);bh(114,1,gp,Yl);_.u=function(){yl(this.a,this.b)};var mf=vh(114);bh(115,1,gp,Zl);_.u=function(){ul(this.a,this.b)};var nf=vh(115);bh(111,1,jp,$l);_.u=function(){Dl(this.a)};var of=vh(111);bh(116,1,gp,_l);_.u=function(){Bl(this.a)};var pf=vh(116);bh(118,224,{});var Pf=vh(118);bh(119,118,{});_.c=0;var Jf=vh(119);bh(120,119,dp,gm);_.s=Kp;_.o=Cp;_.q=Dp;_.t=Lp;var em=0;var vf=vh(120);bh(122,1,gp,hm);_.u=Mp;var rf=vh(122);bh(121,1,{},jm);var sf=vh(121);bh(123,1,jp,km);_.u=function(){Tk(this.a)};var tf=vh(123);bh(124,1,bp,lm);_.r=function(){return dm(this.a)};var uf=vh(124);bh(247,$wnd.Function,{},mm);_.eb=function(a){ro(this.a.f)};bh(182,1,{},nm);var wf=vh(182);var om;bh(204,1,{},qm);var xf=vh(204);var rm;bh(248,$wnd.Function,{},tm);_.fb=function(a){return new wm(a)};var um;bh(96,$wnd.React.Component,{},wm);ah($g[1],_);_.componentWillUnmount=function(){Ek(this.a)};_.render=function(){return Kk(this.a)};_.shouldComponentUpdate=Np;var Af=vh(96);bh(249,$wnd.Function,{},xm);_.fb=function(a){return new Am(a)};var ym;bh(104,$wnd.React.Component,{},Am);ah($g[1],_);_.componentWillUnmount=function(){Sk(this.a)};_.render=function(){return Wk(this.a)};_.shouldComponentUpdate=Op;var Bf=vh(104);bh(263,$wnd.Function,{},Bm);_.fb=function(a){return new Em(a)};var Cm;bh(135,$wnd.React.Component,{},Em);ah($g[1],_);_.componentWillUnmount=function(){Ek(this.a)};_.render=function(){return kl(this.a)};_.shouldComponentUpdate=Np;var Ef=vh(135);bh(250,$wnd.Function,{},Fm);_.fb=function(a){return new Im(a)};var Gm;bh(117,$wnd.React.Component,{},Im);ah($g[1],_);_.componentDidUpdate=function(a){Ll(this.a)};_.componentWillUnmount=function(){Cl(this.a)};_.render=function(){return Ml(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.e};var Gf=vh(117);bh(260,$wnd.Function,{},Jm);_.fb=function(a){return new Mm(a)};var Km;bh(125,$wnd.React.Component,{},Mm);ah($g[1],_);_.componentWillUnmount=function(){Sk(this.a)};_.render=function(){return fm(this.a)};_.shouldComponentUpdate=Op;var If=vh(125);bh(261,$wnd.Function,{},Nm);_.db=function(a){cl(this.a,a)};bh(262,$wnd.Function,{},Om);_.cb=function(a){il(this.a,a)};bh(181,1,{},Pm);var Kf=vh(181);var Qm;bh(257,$wnd.Function,{},Sm);_.cb=function(a){Hl(this.a,a)};bh(251,$wnd.Function,{},Tm);_.cb=function(a){Sn(this.a)};bh(253,$wnd.Function,{},Um);_.eb=function(a){Jl(this.a,this.b)};bh(254,$wnd.Function,{},Vm);_.eb=function(a){vl(this.a,this.b)};bh(255,$wnd.Function,{},Wm);_.v=function(a){wl(this.a,a)};bh(256,$wnd.Function,{},Xm);_.bb=function(a){Kl(this.a,this.b)};bh(258,$wnd.Function,{},Ym);_.db=function(a){xl(this.a,this.b,a)};bh(203,1,{},$m);var Mf=vh(203);var _m;bh(259,$wnd.Function,{},bn);_.cb=function(a){am(this.a,a)};bh(67,1,{},cn);var Of=vh(67);var dn;bh(80,1,{},fn);var Vf=vh(80);bh(81,1,{},hn);var Qf=vh(81);bh(85,1,{},jn);var Rf=vh(85);bh(84,1,{},kn);var Sf=vh(84);bh(82,1,{},mn);var Tf=vh(82);bh(83,1,{},on);var Uf=vh(83);bh(185,1,{});var Cg=vh(185);bh(186,185,dp,Bn);_.s=Ip;_.o=Cp;_.q=Dp;_.t=Jp;var bg=vh(186);bh(187,1,gp,Cn);_.u=function(){vn(this.a)};var Wf=vh(187);bh(189,1,jp,Dn);_.u=function(){qn(this.a)};var Xf=vh(189);bh(190,1,jp,En);_.u=function(){rn(this.a)};var Yf=vh(190);bh(192,1,gp,Fn);_.u=function(){yn(this.a)};var Zf=vh(192);bh(61,1,gp,Gn);_.u=function(){un(this.a)};var $f=vh(61);bh(188,1,bp,Hn);_.r=function(){var a;return a=(mh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var _f=vh(188);bh(191,1,gp,In);_.u=function(){pn(this.a,this.b)};var ag=vh(191);bh(47,1,{47:1});_.d=false;var Kg=vh(47);bh(48,47,{9:1,268:1,48:1,47:1},Tn);_.s=Ip;_.o=function(a){return Mn(this,a)};_.q=function(){return this.c.d};_.t=Jp;var Jn=0;var tg=vh(48);bh(205,1,gp,Un);_.u=function(){Kn(this.a)};var cg=vh(205);bh(206,1,gp,Vn);_.u=function(){Pn(this.a)};var dg=vh(206);bh(44,154,{44:1});var Fg=vh(44);bh(155,44,{9:1,44:1},co);_.s=function(){fc(this.f)};_.o=Cp;_.q=Dp;_.t=function(){return this.f.i<0};var ng=vh(155);bh(157,1,gp,eo);_.u=function(){Xn(this.a)};var eg=vh(157);bh(156,1,gp,fo);_.u=function(){_n(this.a)};var fg=vh(156);bh(162,1,gp,go);_.u=function(){_b(this.a,this.b,true)};var gg=vh(162);bh(163,1,bp,ho);_.r=function(){return Wn(this.a,this.c,this.b)};_.b=false;var hg=vh(163);bh(158,1,bp,io);_.r=function(){return ao(this.a)};var ig=vh(158);bh(159,1,bp,jo);_.r=function(){return Fh(Ug(aj($n(this.a))))};var jg=vh(159);bh(160,1,bp,ko);_.r=function(){return Fh(Ug(aj(bj($n(this.a),new Wo))))};var kg=vh(160);bh(161,1,bp,lo);_.r=function(){return bo(this.a)};var lg=vh(161);bh(142,1,{66:1},oo);_.C=function(){return new co};var mo;var mg=vh(142);bh(45,1,{45:1});var Jg=vh(45);bh(164,45,{9:1,45:1},vo);_.s=function(){fc(this.a)};_.o=Cp;_.q=Dp;_.t=function(){return this.a.i<0};var sg=vh(164);bh(165,1,gp,wo);_.u=function(){so(this.a,this.b)};_.b=false;var og=vh(165);bh(166,1,gp,xo);_.u=function(){An(this.b,this.a)};var pg=vh(166);bh(167,1,gp,yo);_.u=function(){to(this.a)};var qg=vh(167);bh(143,1,{66:1},zo);_.C=function(){return new vo(this.a.C())};var rg=vh(143);bh(46,1,{46:1});var Mg=vh(46);bh(168,46,{9:1,46:1},Io);_.s=function(){fc(this.g)};_.o=Cp;_.q=Dp;_.t=function(){return this.g.i<0};var Ag=vh(168);bh(169,1,gp,Jo);_.u=function(){Co(this.a)};var ug=vh(169);bh(170,1,bp,Ko);_.r=function(){var a;return a=xn(this.a.i),Lh(Ap,a)||Lh(wp,a)||Lh('',a)?Lh(Ap,a)?(To(),Qo):Lh(wp,a)?(To(),So):(To(),Ro):(To(),Ro)};var vg=vh(170);bh(171,1,bp,Lo);_.r=function(){return Eo(this.a)};var wg=vh(171);bh(172,1,jp,Mo);_.u=function(){Fo(this.a)};var xg=vh(172);bh(173,1,jp,No);_.u=function(){Go(this.a)};var yg=vh(173);bh(144,1,{66:1},Oo);_.C=function(){return new Io(this.a.C())};var zg=vh(144);bh(183,1,{},Po);_.handleEvent=function(a){sn(this.a,a)};var Bg=vh(183);bh(32,31,{3:1,29:1,31:1,32:1},Uo);var Qo,Ro,So;var Dg=wh(32,Vo);bh(148,1,{},Wo);_._=function(a){return !On(a)};var Eg=vh(148);bh(150,1,{},Xo);_._=function(a){return On(a)};var Gg=vh(150);bh(151,1,{},Yo);_.v=function(a){Zn(this.a,a)};var Hg=vh(151);bh(149,1,{},Zo);_.v=function(a){qo(this.a,a)};_.a=false;var Ig=vh(149);bh(152,1,{},$o);_._=function(a){return Bo(this.a,a)};var Lg=vh(152);var _o=(xc(),Ac);var gwtOnLoad=gwtOnLoad=Yg;Wg(ih);Zg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();