function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='5F11CAD55D6972E6494E76E2BD830D7F',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '5F11CAD55D6972E6494E76E2BD830D7F';function p(){}
function ph(){}
function th(){}
function Eb(){}
function Oc(){}
function Vc(){}
function gi(){}
function Bj(){}
function Pj(){}
function Xj(){}
function Yj(){}
function wk(){}
function kl(){}
function Sm(){}
function Wm(){}
function $m(){}
function $n(){}
function cn(){}
function gn(){}
function Cn(){}
function _o(){}
function ip(){}
function jp(){}
function mp(){}
function Tc(a){Sc()}
function Gh(){Gh=ph}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function ib(a){this.a=a}
function wb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function dc(a){this.a=a}
function mc(a){this.a=a}
function Wh(a){this.a=a}
function fi(a){this.a=a}
function si(a){this.a=a}
function xi(a){this.a=a}
function yi(a){this.a=a}
function wi(a){this.b=a}
function Li(a){this.c=a}
function Cj(a){this.a=a}
function $j(a){this.a=a}
function tl(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function Dl(a){this.a=a}
function El(a){this.a=a}
function Fl(a){this.a=a}
function Sl(a){this.a=a}
function Tl(a){this.a=a}
function Ul(a){this.a=a}
function Wl(a){this.a=a}
function rm(a){this.a=a}
function sm(a){this.a=a}
function xm(a){this.a=a}
function zm(a){this.a=a}
function Am(a){this.a=a}
function Im(a){this.a=a}
function Jm(a){this.a=a}
function Km(a){this.a=a}
function Lm(a){this.a=a}
function ln(a){this.a=a}
function mn(a){this.a=a}
function qn(a){this.a=a}
function rn(a){this.a=a}
function un(a){this.a=a}
function Bn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function Wn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function vo(a){this.a=a}
function wo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Mo(a){this.a=a}
function Vo(a){this.a=a}
function Wo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function kp(a){this.a=a}
function lp(a){this.a=a}
function np(a){this.a=a}
function op(a){this.a=a}
function Zp(){gc(this.c)}
function _p(){gc(this.b)}
function eq(){gc(this.f)}
function Ji(){Ai(this)}
function Xi(){this.a=ej()}
function jj(){this.a=ej()}
function Wj(a,b){a.a=b}
function pb(a,b){a.b=b}
function pk(a,b){a.key=b}
function ok(a,b){nk(a,b)}
function Eo(a,b){pm(b,a)}
function Sp(a){nj(this,a)}
function Xp(a){qj(this,a)}
function Vp(a){$h(this,a)}
function cb(a){Wb((J(),a))}
function db(a){Xb((J(),a))}
function gb(a){Yb((J(),a))}
function w(a){--a.e;D(a)}
function hc(a){!!a&&a.v()}
function kc(a,b){oi(a.c,b)}
function Do(a,b){oo(a.b,b)}
function Yl(a,b){po(a.j,b)}
function Zj(a,b){Oj(a.a,b)}
function C(a,b){Mb(a.f,b.f)}
function K(a,b){O(a);L(a,b)}
function ll(a){a.d=2;gc(a.c)}
function xl(a){a.c=2;gc(a.b)}
function bm(a){a.f=2;gc(a.e)}
function Nn(a){R(a.a);Z(a.b)}
function ao(a){Z(a.b);Z(a.a)}
function bq(){jb(this.a.a)}
function pl(a){jb(a.b);R(a.a)}
function Ml(a){jb(a.a);Z(a.b)}
function _g(a){return a.e}
function Wp(){return this.e}
function Qp(){return this.a}
function Up(){return this.b}
function Rp(){return fk(this)}
function Zl(a,b){return a.g=b}
function pc(a,b){a.e=b;oc(a,b)}
function fc(a,b,c){ni(a.c,b,c)}
function Fh(a){sc.call(this,a)}
function Vh(a){sc.call(this,a)}
function hi(a){sc.call(this,a)}
function ck(a,b){a.splice(b,1)}
function bo(a,b,c){fc(a.c,b,c)}
function vj(a,b,c){b.w(a.a[c])}
function Di(a,b){return a.a[b]}
function Yp(a){return this===a}
function Jh(a){Ih(a);return a.k}
function wh(){wh=ph;vh=new p}
function uc(){uc=ph;tc=new p}
function Lc(){Lc=ph;Kc=new Oc}
function J(){J=ph;I=new F}
function bp(){bp=ph;ap=new _o}
function aj(){aj=ph;_i=cj()}
function Bc(){Bc=ph;!!(Sc(),Rc)}
function _h(){nc(this);this.G()}
function Tp(){return qi(this.a)}
function $p(){return this.c.f<0}
function aq(){return this.b.f<0}
function fq(){return this.f.f<0}
function Wc(a,b){return Ph(a,b)}
function Oj(a,b){Wj(a,Nj(a.a,b))}
function qj(a,b){while(a.eb(b));}
function Tj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function Nj(a,b){a.T(b);return a}
function ej(){aj();return new _i}
function T(a){lb(a.f);return V(a)}
function Pn(a){eb(a.b);return a.e}
function eo(a){eb(a.a);return a.d}
function Qo(a){eb(a.d);return a.e}
function zk(a,b){a.ref=b;return a}
function Qm(a){this.a=a;Rm=this}
function on(a){this.a=a;pn=this}
function xh(a){this.a=vh;this.b=a}
function Uh(a,b){this.a=a;this.b=b}
function ec(a,b){this.a=a;this.b=b}
function zi(a,b){this.a=a;this.b=b}
function Sj(a,b){this.a=a;this.b=b}
function Vj(a,b){this.a=a;this.b=b}
function Cb(a){this.d=a;this.b=100}
function xk(a,b){this.a=a;this.b=b}
function cq(a){return 1==this.a.d}
function dq(a){return 1==this.a.c}
function qi(a){return a.a.b+a.b.b}
function gj(a,b){return a.a.get(b)}
function gl(a,b){Uh.call(this,a,b)}
function Vl(a,b){this.a=a;this.b=b}
function tm(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function wm(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function sn(a,b){this.a=a;this.b=b}
function tn(a,b){this.a=a;this.b=b}
function vn(a,b){this.a=a;this.b=b}
function wn(a,b){this.a=a;this.b=b}
function Ak(a,b){a.href=b;return a}
function ak(a,b,c){a.splice(b,0,c)}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function Qn(a){On(a,(eb(a.b),a.e))}
function $(a){J();Xb(a);a.e=-2}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function ih(){gh==null&&(gh=[])}
function Mm(){this.a=qk((Um(),Tm))}
function Pm(){this.a=qk((Ym(),Xm))}
function nn(){this.a=qk((an(),_m))}
function yn(){this.a=qk((en(),dn))}
function Dn(){this.a=qk((jn(),hn))}
function Xn(a,b){this.a=a;this.b=b}
function xo(a,b){this.a=a;this.b=b}
function Ko(a,b){this.a=a;this.b=b}
function Lo(a,b){this.b=a;this.a=b}
function gp(a,b){Uh.call(this,a,b)}
function Jk(a,b){a.value=b;return a}
function di(a,b){a.a+=''+b;return a}
function pi(a){a.a=new Xi;a.b=new jj}
function Ai(a){a.a=Yc(he,sp,1,0,5,1)}
function Ic(a){$wnd.clearTimeout(a)}
function Sb(a){return !a.d?a:Sb(a.d)}
function mi(a){return !a?null:a.ab()}
function pj(a){return a!=null?s(a):0}
function nd(a){return a==null?null:a}
function kd(a){return typeof a===rp}
function o(a,b){return nd(a)===nd(b)}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function ob(a){J();nb(a);rb(a,2,true)}
function fo(a){pm(a,(eb(a.a),!a.d))}
function fm(a){jb(a.b);R(a.c);Z(a.a)}
function cc(a,b){ac(a,b,false);db(a.c)}
function bk(a,b){_j(b,0,a,0,b.length)}
function Ek(a,b){a.onBlur=b;return a}
function Bk(a,b){a.onClick=b;return a}
function Fk(a,b){a.onChange=b;return a}
function Dk(a,b){a.checked=b;return a}
function Gk(a,b){a.onKeyDown=b;return a}
function nk(a,b){for(var c in a){b(c)}}
function ad(a,b,c){return {l:a,m:b,h:c}}
function ai(a,b){return a.charCodeAt(b)}
function hd(a,b){return a!=null&&fd(a,b)}
function Y(a){return !(!!a&&1==(a.c&7))}
function fk(a){return a.$H||(a.$H=++ek)}
function md(a){return typeof a==='string'}
function hb(a){this.c=new Ji;this.b=a}
function Ri(){this.a=new Xi;this.b=new jj}
function jk(){jk=ph;gk=new p;ik=new p}
function Ck(a){a.autoFocus=true;return a}
function Ih(a){if(a.k!=null){return}Rh(a)}
function eb(a){var b;Tb((J(),b=Ob,b),a)}
function Zi(a,b){var c;c=a[Ep];c.call(a,b)}
function bc(a,b){kc(b.c,a);hd(b,9)&&b.t()}
function sc(a){this.g=a;nc(this);this.G()}
function Mj(a,b){Fj.call(this,a);this.a=b}
function zn(a,b){this.a=a;this.b=b;An=this}
function P(){this.a=Yc(he,sp,1,100,5,1)}
function Zh(){Zh=ph;Yh=Yc(de,sp,29,256,0,1)}
function U(a){4==(a.f.c&7)&&rb(a.f,5,true)}
function Fb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function Po(a){jb(a.a);R(a.b);R(a.c);Z(a.d)}
function to(a){return Xh(S(a.e).a-S(a.a).a)}
function jd(a){return typeof a==='boolean'}
function Cc(a,b,c){return a.apply(b,c);var d}
function Lb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function nj(a,b){while(a.Y()){Zj(b,a.Z())}}
function Bb(a){while(true){if(!Ab(a)){break}}}
function mm(a){A((J(),J(),I),new zm(a),Jp)}
function Rn(a){A((J(),J(),I),new Yn(a),Jp)}
function io(a){A((J(),J(),I),new lo(a),Jp)}
function Fo(a){A((J(),J(),I),new Mo(a),Jp)}
function Nl(a,b){A((J(),J(),I),new Vl(a,b),Jp)}
function gm(a,b){A((J(),J(),I),new ym(a,b),Jp)}
function km(a,b){A((J(),J(),I),new vm(a,b),Jp)}
function lm(a,b){A((J(),J(),I),new um(a,b),Jp)}
function om(a,b){A((J(),J(),I),new tm(a,b),Jp)}
function po(a,b){A((J(),J(),I),new xo(a,b),Jp)}
function Io(a,b){A((J(),J(),I),new Ko(a,b),Jp)}
function Mb(a,b){Lb(a,((b.a&229376)>>15)-1,b)}
function Ol(a,b){var c;c=b.target;Ql(a,c.value)}
function Mh(a){var b;b=Lh(a);Th(a,b);return b}
function nc(a){a.j&&a.e!==zp&&a.G();return a}
function Kk(a,b){a.onDoubleClick=b;return a}
function Bi(a,b){a.a[a.a.length]=b;return true}
function yo(a,b){this.a=a;this.c=b;this.b=false}
function mj(a,b,c){this.a=a;this.b=b;this.c=c}
function F(){this.f=new Nb;this.a=new Cb(this.f)}
function Sc(){Sc=ph;var a;!Uc();a=new Vc;Rc=a}
function Gj(a,b){var c;return Kj(a,(c=new Ji,c))}
function tj(a,b){while(a.c<a.d){vj(a,b,a.c++)}}
function xj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function Db(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Ah(a){if(!a){throw _g(new _h)}return a}
function Oh(a){var b;b=Lh(a);b.j=a;b.e=1;return b}
function ui(a){var b;b=a.a.Z();a.b=ti(a);return b}
function Qj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function Dh(a,b,c,d){a.addEventListener(b,c,d)}
function Eh(a,b,c,d){a.removeEventListener(b,c,d)}
function mb(a,b){bb(b,a);b.c.a.length>0||(b.a=4)}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Fi(a,b){var c;c=a.a[b];ck(a.a,b);return c}
function fj(a,b){return !(a.a.get(b)===undefined)}
function Mi(a,b){return rj(b,a.length),new wj(a,b)}
function No(a){return o(Op,a)||o(Pp,a)||o('',a)}
function Ni(a){return new Mj(null,Mi(a,a.length))}
function $c(a){return Array.isArray(a)&&a.pb===th}
function gd(a){return !Array.isArray(a)&&a.pb===th}
function so(a){return Gh(),0!=S(a.e).a?true:false}
function ql(a){return Gh(),S(a.e.b).a>0?true:false}
function Bl(a){return B((J(),J(),I),a.a,new Fl(a))}
function Pl(a){return B((J(),J(),I),a.a,new Tl(a))}
function rl(a){return B((J(),J(),I),a.b,new wl(a))}
function nm(a){return B((J(),J(),I),a.b,new sm(a))}
function Gm(a){return B((J(),J(),I),a.a,new Km(a))}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function ro(a){$h(new xi(a.g),new dc(a));pi(a.g)}
function no(a){R(a.d);R(a.e);R(a.a);R(a.b);Z(a.c)}
function jc(a){hc(a.e);!!a.c&&ic(a);hc(a.a);hc(a.d)}
function Dj(a){if(!a.b){Ej(a);a.c=true}else{Dj(a.b)}}
function ml(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function yl(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function cm(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function mk(){if(hk==256){gk=ik;ik=new p;hk=0}++hk}
function ri(a,b){if(b){return ki(a.a,b)}return false}
function Ij(a,b){Ej(a);return new Mj(a,new Rj(b,a.a))}
function Jj(a,b){Ej(a);return new Mj(a,new Uj(b,a.a))}
function On(a,b){A((J(),J(),I),new Xn(a,b),75497472)}
function Bm(a,b){var c;c=b.target;Io(a.e,c.checked)}
function pm(a,b){var c;c=a.d;if(b!=c){a.d=b;db(a.a)}}
function Ql(a,b){var c;c=a.f;if(b!=c){a.f=b;db(a.b)}}
function Sn(a,b){var c;c=a.e;if(b!=c){a.e=b;db(a.b)}}
function Mn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&Sn(a,b)}
function fb(a){var b;J();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function Hi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Ik(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function sj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Nm(a,b,c){this.a=a;this.b=b;this.c=c;Om=this}
function En(a,b,c){this.a=a;this.b=b;this.c=c;Fn=this}
function wj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Zb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function hm(a,b){To(a.k,b);A((J(),J(),I),new tm(a,b),Jp)}
function Go(a,b){Gj(qo(a.b),new Cj(new Bj)).Q(new lp(b))}
function fh(a){if(kd(a)){return a|0}return a.l|a.m<<22}
function Qh(a){if(a.P()){return null}var b=a.j;return lh[b]}
function Fj(a){if(!a){this.b=null;new Ji}else{this.b=a}}
function yj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function li(a,b){return b===a?'(this Map)':b==null?Bp:sh(b)}
function Qi(a,b){return nd(a)===nd(b)||a!=null&&q(a,b)}
function Nh(a,b){var c;c=Lh(a);Th(a,c);c.e=b?8:0;return c}
function qc(a,b){var c;c=Jh(a.nb);return b==null?c:c+': '+b}
function Xl(a,b){var c;if(S(a.c)){c=b.target;pm(a,c.value)}}
function $h(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function Pb(a){if(a.e){2==(a.e.c&7)||rb(a.e,4,true);nb(a.e)}}
function kb(a){C((J(),J(),I),a);0==(a.f.a&xp)&&D((null,I))}
function im(a,b){A((J(),J(),I),new tm(a,b),Jp);To(a.k,null)}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function rh(a){function b(){}
;b.prototype=a||{};return new b}
function Ch(){Ch=ph;Bh=$wnd.goog.global.document}
function en(){en=ph;var a;dn=(a=qh(cn.prototype.mb,cn,[]),a)}
function jn(){jn=ph;var a;hn=(a=qh(gn.prototype.mb,gn,[]),a)}
function an(){an=ph;var a;_m=(a=qh($m.prototype.mb,$m,[]),a)}
function Um(){Um=ph;var a;Tm=(a=qh(Sm.prototype.mb,Sm,[]),a)}
function Ym(){Ym=ph;var a;Xm=(a=qh(Wm.prototype.mb,Wm,[]),a)}
function hp(){fp();return _c(Wc(Ng,1),sp,31,0,[cp,ep,dp])}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function In(a){Dh((Ch(),$wnd.goog.global.window),Mp,a.d,false)}
function Jn(a){Eh((Ch(),$wnd.goog.global.window),Mp,a.d,false)}
function Jo(a){this.b=a;J();this.a=new lc(0,null,null,false)}
function Ki(a){Ai(this);bk(this.a,ji(a,Yc(he,sp,1,qi(a.a),5,1)))}
function Ui(a,b){var c;return Si(b,Ti(a,b==null?0:(c=s(b),c|0)))}
function Ti(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ph(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function nh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function vk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function yh(a){wh();Ah(a);if(hd(a,44)){return a}return new xh(a)}
function uj(a,b){if(a.c<a.d){vj(a,b,a.c++);return true}return false}
function jm(a){return Gh(),Qo(a.k)==a.n.props['a']?true:false}
function od(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kn(a,b){b.preventDefault();A((J(),J(),I),new Zn(a),Jp)}
function qo(a){eb(a.c);return new Mj(null,new yj(new xi(a.g),0))}
function Ho(a){Gj(Ij(qo(a.b),new jp),new Cj(new Bj)).Q(new kp(a.b))}
function Hk(a){a.placeholder='What needs to be done?';return a}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function zj(a,b){!a.a?(a.a=new fi(a.d)):di(a.a,a.b);di(a.a,b);return a}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Uj(a,b){sj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function Rj(a,b){sj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function kj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Yi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Aj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Zm(a){$wnd.React.Component.call(this,a);this.a=new Cl(this,Rm.a)}
function bn(a){$wnd.React.Component.call(this,a);this.a=new Rl(this,pn.a)}
function Hb(b){try{lb(b.b.a)}catch(a){a=$g(a);if(!hd(a,4))throw _g(a)}}
function oi(a,b){return md(b)?b==null?Wi(a.a,null):ij(a.b,b):Wi(a.a,b)}
function Oo(a,b){return (fp(),dp)==a||(cp==a?(eb(b.a),!b.d):(eb(b.a),b.d))}
function oo(a,b){var c;return u((J(),J(),I),new yo(a,b),Jp,(c=null,c))}
function Lj(a,b){var c;c=Gj(a,new Cj(new Bj));return Ii(c,b.fb(c.a.length))}
function Kj(a,b){var c;Dj(a);c=new Xj;c.a=b;a.a.X(new $j(c));return c.a}
function Hj(a){var b;Dj(a);b=0;while(a.a.eb(new Yj)){b=ah(b,1)}return b}
function Kb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Ci(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function ab(a,b){var c,d;Bi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Gl(a){var b;b=ci((eb(a.b),a.f));if(b.length>0){Do(a.e,b);Ql(a,'')}}
function Ro(a){var b;return b=S(a.b),Gj(Ij(qo(a.i),new np(b)),new Cj(new Bj))}
function Hn(a,b){a.f=b;o(b,S(a.a))&&Sn(a,b);Ln(b);A((J(),J(),I),new Zn(a),Jp)}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function lj(a){if(a.a.c!=a.c){return gj(a.a,a.b.value[0])}return a.b.value[1]}
function Ei(a,b,c){for(;c<a.a.length;++c){if(Qi(b,a.a[c])){return c}}return -1}
function Gi(a,b){var c;c=Ei(a,b,0);if(c==-1){return false}ck(a.a,c);return true}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&_c(Wc(a,f),b,c,e,g);return g}
function ni(a,b,c){return md(b)?b==null?Vi(a.a,null,c):hj(a.b,b,c):Vi(a.a,b,c)}
function dk(a,b){return Xc(b)!=10&&_c(r(b),b.ob,b.__elementTypeId$,Xc(b),a),a}
function gc(a){if(a.f>=0){a.f=-2;u((J(),J(),I),new G(new mc(a)),67108864,null)}}
function Z(a){if(-2!=a.e){u((J(),J(),I),new G(new ib(a)),0,null);!!a.b&&jb(a.b)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;Z(a.e);2==(a.f.c&7)||jb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Bb(a.a)}finally{a.c=false}}}}
function V(a){if(a.b){if(hd(a.b,7)){throw _g(a.b)}else{throw _g(a.b)}}return a.n}
function qb(b){if(b){try{b.v()}catch(a){a=$g(a);if(hd(a,4)){J()}else throw _g(a)}}}
function Hl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Ul(a),Jp)}}
function _b(){var a;try{Qb(Ob);J()}finally{a=Ob.d;!a&&((J(),J(),I).d=true);Ob=Ob.d}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function Nb(){var a;this.a=Yc(td,sp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function vi(a){this.d=a;this.c=new kj(this.d.b);this.a=this.c;this.b=ti(this)}
function lc(a,b,c,d){this.b=a;this.c=d?new Ri:null;this.e=b;this.a=c;this.d=null}
function fn(a){$wnd.React.Component.call(this,a);this.a=new qm(this,An.a,An.b)}
function kn(a){$wnd.React.Component.call(this,a);this.a=new Hm(this,Fn.a,Fn.b,Fn.c)}
function Vm(a){$wnd.React.Component.call(this,a);this.a=new sl(this,Om.a,Om.b,Om.c)}
function Gn(){this.a=yh(new mp);this.b=yh((bp(),ap));this.c=yh(new op(this.b))}
function fp(){fp=ph;cp=new gp('ACTIVE',0);ep=new gp('COMPLETED',1);dp=new gp('ALL',2)}
function Lh(a){var b;b=new Kh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new Ji);a.c=c.c}b.d=true;Bi(a.c,b)}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ji);Bi(a.b,b)}}}
function Th(a,b){var c;if(!a){return}b.j=a;var d=Qh(b);if(!d){lh[a]=[b];return}d.nb=b}
function qh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function rk(a,b,c,d){var e;e=sk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function qk(a){var b;b=sk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function tk(a){var b;return rk($wnd.React.StrictMode,null,null,(b={},b[Fp]=a,b))}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ld(a){return a!=null&&(typeof a===qp||typeof a==='function')&&!(a.pb===th)}
function kh(a,b){typeof window===qp&&typeof window['$gwt']===qp&&(window['$gwt'][a]=b)}
function Ib(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?yp:0)|(0!=(b&229376)?0:98304)}
function ub(a,b,c){tb.call(this,null,a,b,c|(!a?262144:up)|(0==(c&6291456)?!a?xp:yp:0)|0|0|0)}
function nb(a){var b,c;for(c=new Li(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Oi(a){var b,c,d;d=0;for(c=new vi(a.a);c.b;){b=ui(c);d=d+(b?s(b):0);d=d|0}return d}
function ii(a,b){var c,d;for(d=new vi(b.a);d.b;){c=ui(d);if(!ri(a,c)){return false}}return true}
function ij(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Zi(a.a,b);--a.b}return c}
function mo(a,b,c){var d;d=new jo(b,c);bo(d,a,new ec(a,d));ni(a.g,Xh(d.c.b),d);db(a.c);return d}
function ac(a,b,c){var d;d=oi(a.g,b?Xh(b.c.b):null);if(null!=d){kc(b.c,a);c&&!!b&&gc(b.c);db(a.c)}}
function So(a){var b;b=S(a.g.a);o(Op,b)||o(Pp,b)||o('',b)?On(a.g,b):No(Pn(a.g))?Rn(a.g):On(a.g,'')}
function eh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Cp;d=1048575}c=od(e/yp);b=od(e-c*yp);return ad(b,c,d)}
function bh(a){var b;b=a.h;if(b==0){return a.l+a.m*yp}if(b==1048575){return a.l+a.m*yp-Cp}return a}
function $g(a){var b;if(hd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new wc(a);Tc(b)}return b}
function ti(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new Yi(a.d.a);return a.a.Y()}
function xn(a,b){pk(a.a,(Ih(ag),ag.k+(''+(b?Xh(b.c.b):null))));a.a.props['a']=b;return a.a}
function hh(){ih();var a=gh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function rj(a,b){if(0>a||a>b){throw _g(new Fh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function hj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function _c(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=th;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Si(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Qi(a,c._())){return c}}return null}
function Xh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Zh(),Yh)[b];!c&&(c=Yh[b]=new Wh(a));return c}return new Wh(a)}
function To(a,b){var c;c=a.e;if(!(b==c||!!b&&b==c)){!!c&&kc(c.c,a);a.e=b;!!b&&bo(b,a,new Wo(a));db(a.d)}}
function bb(a,b){var c,d;d=a.c;Gi(d,b);!!a.b&&up!=(a.b.c&vp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((J(),c=Ob,c),a))}
function bd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ad(c&4194303,d&4194303,e&1048575)}
function wc(a){uc();nc(this);this.e=a;oc(this,a);this.g=a==null?Bp:sh(a);this.a='';this.b=a;this.a=''}
function Kh(){this.g=Hh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function jl(){if(!il){il=(++(J(),J(),I).e,new Eb);$wnd.Promise.resolve(null).then(qh(kl.prototype.J,kl,[]))}}
function jb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new yb(a)),67108864,null);!!a.a&&R(a.a);Fb(a.f);a.c=a.c&-8|1}}
function $l(a,b,c){27==c.which?A((J(),J(),I),new wm(a,b),Jp):13==c.which&&A((J(),J(),I),new um(a,b),Jp)}
function r(a){return md(a)?ke:kd(a)?$d:jd(a)?Yd:gd(a)?a.nb:$c(a)?a.nb:a.nb||Array.isArray(a)&&Wc(Pd,1)||Pd}
function s(a){return md(a)?lk(a):kd(a)?od(a):jd(a)?a?1231:1237:gd(a)?a.q():$c(a)?fk(a):!!a&&!!a.hashCode?a.hashCode():fk(a)}
function Gb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&up)?Hb(a):lb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function am(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;om(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function sh(a){var b;if(Array.isArray(a)&&a.pb===th){return Jh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function lk(a){jk();var b,c,d;c=':'+a;d=ik[c];if(d!=null){return od(d)}d=gk[c];b=d==null?kk(a):od(d);mk();ik[c]=b;return b}
function Pi(a){var b,c,d;d=1;for(c=new Li(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Jb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Ub(a){var b;if(a.c){while(a.c.a.length!=0){b=Fi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&rb(b.b,3,true)}}}
function _l(a,b){var c;c=(eb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Lo(b,c),Jp);To(a.k,null);pm(a,c)}else{po(a.j,b)}}
function Cl(a,b){var c;this.d=b;this.n=a;J();c=++Al;this.b=new lc(c,null,new Dl(this),false);this.a=new ub(null,new El(this),Ip)}
function Ej(a){if(a.b){Ej(a.b)}else if(a.c){throw _g(new Vh("Stream already terminated, can't be modified or used"))}}
function hl(){fl();return _c(Wc(bf,1),sp,6,0,[Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el])}
function vb(a,b){tb.call(this,a,new wb(a),null,b|(up==(b&vp)?0:524288)|(0==(b&6291456)?up==(b&vp)?yp:xp:0)|0|268435456|0)}
function ah(a,b){var c;if(kd(a)&&kd(b)){c=a+b;if(-17592186044416<c&&c<Cp){return c}}return bh(bd(kd(a)?eh(a):a,kd(b)?eh(b):b))}
function Sh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ii(a,b){var c,d;d=a.a.length;b.length<d&&(b=dk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function ic(a){var b,c,d;for(c=new Li(new Ki(new si(a.c)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();hd(d,9)&&d.u()||b.ab().v()}}
function Xb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Li(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&rb(b,6,true)}}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Li(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&rb(b,5,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Li(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?rb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function q(a,b){return md(a)?o(a,b):kd(a)?nd(a)===nd(b):jd(a)?nd(a)===nd(b):gd(a)?a.o(b):$c(a)?o(a,b):!!a&&!!a.equals?a.equals(b):nd(a)===nd(b)}
function fd(a,b){if(md(a)){return !!ed[b]}else if(a.ob){return !!a.ob[b]}else if(kd(a)){return !!dd[b]}else if(jd(a)){return !!cd[b]}return false}
function yk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?fb(a.e):eb(a.e);if(sb(a.f)){if(a.k&&(J(),!(!!Ob&&!!Ob.e))){return u((J(),J(),I),new X(a),83888128,null)}else{lb(a.f)}}return V(a)}
function Hm(a,b,c,d){var e;this.d=b;this.e=c;this.f=d;this.n=a;J();e=++Fm;this.b=new lc(e,null,new Im(this),false);this.a=new ub(null,new Jm(this),Ip)}
function Rl(a,b){var c,d,e;this.e=b;this.n=a;J();c=++Ll;this.c=new lc(c,null,new Sl(this),false);this.b=(e=new hb((d=null,d)),e);this.a=new ub(null,new Wl(this),Ip)}
function jo(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++_n;this.c=new lc(c,null,new ko(this),true);this.b=(g=new hb((e=null,e)),g);this.a=(f=new hb((d=null,d)),f)}
function ci(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ji(a,b){var c,d,e,f;f=qi(a.a);b.length<f&&(b=dk(new Array(f),b));e=b;d=new vi(a.a);for(c=0;c<f;++c){e[c]=ui(d)}b.length>f&&(b[f]=null);return b}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{$b(b,d);try{f=(c.a.v(),null)}finally{_b()}return f}catch(a){a=$g(a);if(hd(a,4)){e=a;throw _g(e)}else throw _g(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.s()}else{$b(b,e);try{g=c.s()}finally{_b()}}return g}catch(a){a=$g(a);if(hd(a,4)){f=a;throw _g(f)}else throw _g(a)}finally{D(b)}}
function Ab(a){var b,c;if(0==a.c){b=Kb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Jb(a.d);Gb(c);return true}
function jh(b,c,d,e){ih();var f=gh;$moduleName=c;$moduleBase=d;Zg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{pp(g)()}catch(a){b(c,a)}}else{pp(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new vb(this,d&-16385);this.e=new hb(this.f);up==(d&vp)&&kb(this.f)}
function sk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function cj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return dj()}}
function zl(a){var b,c,d;a.c=0;jl();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),uk('span',yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,['todo-count'])),[uk('strong',null,[c]),' '+d+' left']));return b}
function mh(){lh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Pc(c,g)):g[0].qb()}catch(a){a=$g(a);if(hd(a,4)){d=a;Bc();Hc(hd(d,35)?d.H():d)}else throw _g(a)}}return c}
function Kl(a){var b;a.d=0;jl();b=uk(Kp,Ck(Fk(Gk(Jk(Hk(yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,['new-todo']))),(eb(a.b),a.f)),qh(ln.prototype.kb,ln,[a])),qh(mn.prototype.jb,mn,[a]))),null);return b}
function sl(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.n=a;J();e=++ol;this.c=new lc(e,null,new tl(this),false);this.a=new W(new ul(this),null,null,136478720);this.b=new ub(null,new vl(this),Ip)}
function vc(a){var b;if(a.c==null){b=nd(a.b)===nd(tc)?null:a.b;a.d=b==null?Bp:ld(b)?b==null?null:b.name:md(b)?'String':Jh(r(b));a.a=a.a+': '+(ld(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(nd(e)===nd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;cb(b.e)}}catch(a){a=$g(a);if(hd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;cb(b.e)}throw _g(c)}else throw _g(a)}}
function _j(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Vi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Si(b,e);if(f){return f.bb(c)}}e[e.length]=new zi(b,c);++a.b;return null}
function kk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ai(a,c++)}b=b|0;return b}
function lb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=$g(a);if(hd(a,4)){J()}else throw _g(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Yc(he,sp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function zh(a,b){var c;c=nd(a)!==nd(vh);if(c&&nd(a)!==nd(b)){throw _g(new Vh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}return b}
function tb(a,b,c,d){this.b=new Ji;this.f=new Ib(new xb(this),d&6520832|262144|up);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&xp)&&D((null,I)))}
function uh(){var a;a=new Gn;new Nm(new uo,a.a.I(),a.c.I());new zn(new uo,(a.a.I(),a.c.I()));new En(new uo,a.a.I(),a.c.I());new on(a.a.I());new Qm(new uo);$wnd.ReactDOM.render(tk([(new Dn).a]),(Ch(),Bh).getElementById('app'),null)}
function Wi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Qi(b,e._())){if(d.length==1){d.length=0;Zi(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function oh(a,b,c){var d=lh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=lh[b]),rh(h));_.ob=c;!b&&(_.pb=th);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Rh(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Sh('.',[c,Sh('$',d)]);a.b=Sh('.',[c,Sh('.',d)]);a.i=d[d.length-1]}
function Ln(a){var b;if(0==a.length){b=(Ch(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Bh.title,b)}else{(Ch(),$wnd.goog.global.window).location.hash=a}}
function ki(a,b){var c,d,e;c=b._();e=b.ab();d=md(c)?c==null?mi(Ui(a.a,null)):gj(a.b,c):mi(Ui(a.a,c));if(!(nd(e)===nd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(md(c)?c==null?!!Ui(a.a,null):fj(a.b,c):!!Ui(a.a,c))){return false}return true}
function uk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ok(b,qh(xk.prototype.hb,xk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Fp]=c[0],undefined):(d[Fp]=c,undefined));return rk(a,e,f,d)}
function qm(a,b,c){var d,e,f;this.j=b;this.k=c;this.n=a;J();d=++em;this.e=new lc(d,null,new rm(this),false);this.a=(f=new hb((e=null,e)),f);this.c=new W(new xm(this),null,null,136478720);this.b=new ub(null,new Am(this),Ip);om(this,this.n.props['a'])}
function Uo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new lc(0,null,new Vo(this),false);this.d=(d=new hb((c=null,c)),d);this.b=new W(new Xo(this),null,null,Np);this.c=new W(new Yo(this),null,null,Np);this.a=new ub(new Zo(this),null,681574400);D((null,I))}
function uo(){var a;this.g=new Ri;J();this.f=new lc(0,new wo(this),new vo(this),false);this.c=(a=new hb(null),a);this.d=new W(new zo(this),null,null,Np);this.e=new W(new Ao(this),null,null,Np);this.a=new W(new Bo(this),null,null,Np);this.b=new W(new Co(this),null,null,Np)}
function Tn(){var a,b,c;this.d=new $o(this);this.f=this.e=(c=(Ch(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new lc(0,null,new Un(this),false);this.b=(b=new hb((a=null,a)),b);this.a=new W(new $n,new Vn(this),new Wn(this),35651584)}
function sb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Li(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=$g(a);if(!hd(a,4))throw _g(a)}if(6==(b.c&7)){return true}}}}}nb(b);return false}
function oc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function bj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function rb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){gb(a.a.e);qb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;qb((e=d.i,e));d.n=null}Ci(a.b,new zb(a));a.b.a=Yc(he,sp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&qb((f=a.a.g,f))}}
function Em(a){var b;a.c=0;jl();b=uk('div',null,[uk('div',null,[uk(Lp,yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,[Lp])),[uk('h1',null,['todos']),(new nn).a]),S(a.d.d)?uk('section',yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,[Lp])),[uk(Kp,Fk(Ik(yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,['toggle-all'])),(fl(),Mk)),qh(Bn.prototype.jb,Bn,[a])),null),uk('ul',yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,['todo-list'])),Lj(Jj(S(a.f.c).W(),new Cn),new wk))]):null,S(a.d.d)?(new Mm).a:null])]);return b}
function fl(){fl=ph;Lk=new gl(Gp,0);Mk=new gl('checkbox',1);Nk=new gl('color',2);Ok=new gl('date',3);Pk=new gl('datetime',4);Qk=new gl('email',5);Rk=new gl('file',6);Sk=new gl('hidden',7);Tk=new gl('image',8);Uk=new gl('month',9);Vk=new gl(rp,10);Wk=new gl('password',11);Xk=new gl('radio',12);Yk=new gl('range',13);Zk=new gl('reset',14);$k=new gl('search',15);_k=new gl('submit',16);al=new gl('tel',17);bl=new gl('text',18);cl=new gl('time',19);dl=new gl('url',20);el=new gl('week',21)}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Di(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Hi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{bb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&rb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Di(a.b,g);if(-1==k.e){k.e=0;ab(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Fi(a.b,g)}e&&pb(a.e,a.b)}else{e&&pb(a.e,new Ji)}if(Y(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&up!=(k.b.c&vp)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function nl(a){var b,c;a.d=0;jl();c=(b=S(a.g.b),uk('footer',yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,['footer'])),[(new Pm).a,uk('ul',yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,['filters'])),[uk('li',null,[uk('a',Ak(yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,[(fp(),dp)==b?Hp:null])),'#'),['All'])]),uk('li',null,[uk('a',Ak(yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,[cp==b?Hp:null])),'#active'),['Active'])]),uk('li',null,[uk('a',Ak(yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,[ep==b?Hp:null])),'#completed'),['Completed'])])]),S(a.a)?uk(Gp,Bk(yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,['clear-completed'])),qh(Lm.prototype.lb,Lm,[a])),['Clear Completed']):null]));return c}
function dm(a){var b,c,d,e;a.f=0;jl();b=a.n.props['a'];if(!!b&&b.c.f<0){return null}c=(d=a.n.props['a'],e=(eb(d.a),d.d),uk('li',yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[uk('div',yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,['view'])),[uk(Kp,Fk(Dk(Ik(yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,['toggle'])),(fl(),Mk)),e),qh(rn.prototype.jb,rn,[d])),null),uk('label',Kk(new $wnd.Object,qh(sn.prototype.lb,sn,[a,d])),[(eb(d.b),d.e)]),uk(Gp,Bk(yk(new $wnd.Object,_c(Wc(ke,1),sp,2,6,['destroy'])),qh(tn.prototype.lb,tn,[a,d])),null)]),uk(Kp,Gk(Fk(Ek(Jk(yk(zk(new $wnd.Object,qh(un.prototype.w,un,[a])),_c(Wc(ke,1),sp,2,6,['edit'])),(eb(a.a),a.d)),qh(vn.prototype.ib,vn,[a,d])),qh(qn.prototype.jb,qn,[a])),qh(wn.prototype.kb,wn,[a,d])),null)]));return c}
function dj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Ep]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!bj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Ep]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var qp='object',rp='number',sp={3:1},tp={9:1},up=1048576,vp=1835008,wp={5:1},xp=2097152,yp=4194304,zp='__noinit__',Ap={3:1,10:1,7:1,4:1},Bp='null',Cp=17592186044416,Dp={41:1},Ep='delete',Fp='children',Gp='button',Hp='selected',Ip=1411518464,Jp=142606336,Kp='input',Lp='header',Mp='hashchange',Np=136314880,Op='active',Pp='completed';var _,lh,gh,Zg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;mh();oh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=Rp;_.r=function(){var a;return Jh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var cd,dd,ed;oh(54,1,{},Kh);_.K=function(a){var b;b=new Kh;b.e=4;a>1?(b.c=Ph(this,a-1)):(b.c=this);return b};_.L=function(){Ih(this);return this.b};_.M=function(){return Jh(this)};_.N=function(){Ih(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Ih(this),this.k)};_.e=0;_.g=0;var Hh=1;var he=Mh(1);var Zd=Mh(54);oh(82,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var sd=Mh(82);oh(36,1,{},G);_.s=function(){return this.a.v(),null};var qd=Mh(36);oh(83,1,{},H);var rd=Mh(83);var I;oh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var td=Mh(43);oh(231,1,tp);_.r=function(){var a;return Jh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var wd=Mh(231);oh(18,231,tp,W);_.t=function(){R(this)};_.u=Qp;_.a=false;_.d=0;_.k=false;var vd=Mh(18);oh(125,1,{},X);_.s=function(){return T(this.a)};var ud=Mh(125);oh(17,231,{9:1,17:1},hb);_.t=function(){Z(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var yd=Mh(17);oh(124,1,wp,ib);_.v=function(){$(this.a)};var xd=Mh(124);oh(16,231,{9:1,16:1},ub,vb);_.t=function(){jb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Dd=Mh(16);oh(137,1,{},wb);_.v=function(){Q(this.a)};var zd=Mh(137);oh(138,1,wp,xb);_.v=function(){lb(this.a)};var Ad=Mh(138);oh(139,1,wp,yb);_.v=function(){ob(this.a)};var Bd=Mh(139);oh(140,1,{},zb);_.w=function(a){mb(this.a,a)};var Cd=Mh(140);oh(101,1,{},Cb);_.a=0;_.b=0;_.c=0;var Ed=Mh(101);oh(166,1,tp,Eb);_.t=function(){Db(this)};_.u=Qp;_.a=false;var Fd=Mh(166);oh(66,231,{9:1,66:1},Ib);_.t=function(){Fb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Hd=Mh(66);oh(100,1,{},Nb);var Gd=Mh(100);oh(141,1,{},Zb);_.r=function(){var a;return Ih(Id),Id.k+'@'+(a=fk(this)>>>0,a.toString(16))};_.a=0;var Ob;var Id=Mh(141);oh(113,1,{});var Ld=Mh(113);oh(106,1,{},dc);_.w=function(a){bc(this.a,a)};var Jd=Mh(106);oh(107,1,wp,ec);_.v=function(){cc(this.a,this.b)};var Kd=Mh(107);oh(15,1,tp,lc);_.t=function(){gc(this)};_.u=function(){return this.f<0};_.r=function(){var a;return Ih(Nd),Nd.k+'@'+(a=fk(this)>>>0,a.toString(16))};_.b=0;_.f=0;var Nd=Mh(15);oh(123,1,wp,mc);_.v=function(){jc(this.a)};var Md=Mh(123);oh(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=Wp;_.C=function(){return Lj(Jj(Ni((this.i==null&&(this.i=Yc(me,sp,4,0,0,1)),this.i)),new gi),new Pj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){pc(this,rc(this.A(qc(this,this.g))));Tc(this)};_.r=function(){return qc(this,this.F())};_.e=zp;_.j=true;var me=Mh(4);oh(10,4,{3:1,10:1,4:1});var ae=Mh(10);oh(7,10,Ap);var ie=Mh(7);oh(55,7,Ap);var ee=Mh(55);oh(77,55,Ap);var Rd=Mh(77);oh(35,77,{35:1,3:1,10:1,7:1,4:1},wc);_.F=function(){vc(this);return this.c};_.H=function(){return nd(this.b)===nd(tc)?null:this.b};var tc;var Od=Mh(35);var Pd=Mh(0);oh(214,1,{});var Qd=Mh(214);var yc=0,zc=0,Ac=-1;oh(91,214,{},Oc);var Kc;var Sd=Mh(91);var Rc;oh(225,1,{});var Ud=Mh(225);oh(78,225,{},Vc);var Td=Mh(78);oh(44,1,{44:1},xh);_.I=function(){var a;a=this.a;if(nd(a)===nd(vh)){a=this.a;if(nd(a)===nd(vh)){a=this.b.I();this.a=zh(this.a,a);this.b=null}}return a};var vh;var Vd=Mh(44);var Bh;oh(75,1,{72:1});_.r=Qp;var Wd=Mh(75);oh(79,7,Ap);var ce=Mh(79);oh(142,79,Ap,Fh);var Xd=Mh(142);cd={3:1,73:1,28:1};var Yd=Mh(73);oh(42,1,{3:1,42:1});var ge=Mh(42);dd={3:1,28:1,42:1};var $d=Mh(224);oh(30,1,{3:1,28:1,30:1});_.o=Yp;_.q=Rp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var _d=Mh(30);oh(57,7,Ap,Vh);var be=Mh(57);oh(29,42,{3:1,28:1,29:1,42:1},Wh);_.o=function(a){return hd(a,29)&&a.a==this.a};_.q=Qp;_.r=function(){return ''+this.a};_.a=0;var de=Mh(29);var Yh;oh(289,1,{});oh(80,55,Ap,_h);_.A=function(a){return new TypeError(a)};var fe=Mh(80);ed={3:1,72:1,28:1,2:1};var ke=Mh(2);oh(76,75,{72:1},fi);var je=Mh(76);oh(293,1,{});oh(70,1,{},gi);_.S=function(a){return a.e};var le=Mh(70);oh(58,7,Ap,hi);var ne=Mh(58);oh(226,1,{40:1});_.Q=Vp;_.V=function(){return new yj(this,0)};_.W=function(){return new Mj(null,this.V())};_.T=function(a){throw _g(new hi('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Aj('[',']');for(b=this.R();b.Y();){a=b.Z();zj(c,a===this?'(this Collection)':a==null?Bp:sh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var oe=Mh(226);oh(229,1,{212:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!hd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new vi((new si(d)).a);c.b;){b=ui(c);if(!ki(this,b)){return false}}return true};_.q=function(){return Oi(new si(this))};_.r=function(){var a,b,c;c=new Aj('{','}');for(b=new vi((new si(this)).a);b.b;){a=ui(b);zj(c,li(this,a._())+'='+li(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ze=Mh(229);oh(99,229,{212:1});var re=Mh(99);oh(228,226,{40:1,236:1});_.V=function(){return new yj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!hd(a,21)){return false}b=a;if(qi(b.a)!=this.U()){return false}return ii(this,b)};_.q=function(){return Oi(this)};var Ae=Mh(228);oh(21,228,{21:1,40:1,236:1},si);_.R=function(){return new vi(this.a)};_.U=Tp;var qe=Mh(21);oh(22,1,{},vi);_.X=Sp;_.Z=function(){return ui(this)};_.Y=Up;_.b=false;var pe=Mh(22);oh(227,226,{40:1,233:1});_.V=function(){return new yj(this,16)};_.$=function(a,b){throw _g(new hi('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!hd(a,13)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Li(f);for(c=new Li(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(nd(b)===nd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Pi(this)};_.R=function(){return new wi(this)};var te=Mh(227);oh(90,1,{},wi);_.X=Sp;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Di(this.b,this.a++)};_.a=0;var se=Mh(90);oh(59,226,{40:1},xi);_.R=function(){var a;a=new vi((new si(this.a)).a);return new yi(a)};_.U=Tp;var ve=Mh(59);oh(94,1,{},yi);_.X=Sp;_.Y=function(){return this.a.b};_.Z=function(){var a;a=ui(this.a);return a.ab()};var ue=Mh(94);oh(92,1,Dp);_.o=function(a){var b;if(!hd(a,41)){return false}b=a;return Qi(this.a,b._())&&Qi(this.b,b.ab())};_._=Qp;_.ab=Up;_.q=function(){return pj(this.a)^pj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var we=Mh(92);oh(93,92,Dp,zi);var xe=Mh(93);oh(230,1,Dp);_.o=function(a){var b;if(!hd(a,41)){return false}b=a;return Qi(this.b.value[0],b._())&&Qi(lj(this),b.ab())};_.q=function(){return pj(this.b.value[0])^pj(lj(this))};_.r=function(){return this.b.value[0]+'='+lj(this)};var ye=Mh(230);oh(13,227,{3:1,13:1,40:1,233:1},Ji,Ki);_.$=function(a,b){ak(this.a,a,b)};_.T=function(a){return Bi(this,a)};_.Q=function(a){Ci(this,a)};_.R=function(){return new Li(this)};_.U=function(){return this.a.length};var Ce=Mh(13);oh(14,1,{},Li);_.X=Sp;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Be=Mh(14);oh(37,99,{3:1,37:1,212:1},Ri);var De=Mh(37);oh(62,1,{},Xi);_.Q=Vp;_.R=function(){return new Yi(this)};_.b=0;var Fe=Mh(62);oh(63,1,{},Yi);_.X=Sp;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ee=Mh(63);var _i;oh(60,1,{},jj);_.Q=Vp;_.R=function(){return new kj(this)};_.b=0;_.c=0;var Ie=Mh(60);oh(61,1,{},kj);_.X=Sp;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new mj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Ge=Mh(61);oh(112,230,Dp,mj);_._=function(){return this.b.value[0]};_.ab=function(){return lj(this)};_.bb=function(a){return hj(this.a,this.b.value[0],a)};_.c=0;var He=Mh(112);oh(127,1,{});_.X=Xp;_.cb=function(){return this.d};_.db=Wp;_.d=0;_.e=0;var Me=Mh(127);oh(64,127,{});var Je=Mh(64);oh(95,1,{});_.X=Xp;_.cb=Up;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Le=Mh(95);oh(96,95,{},wj);_.X=function(a){tj(this,a)};_.eb=function(a){return uj(this,a)};var Ke=Mh(96);oh(20,1,{},yj);_.cb=Qp;_.db=function(){xj(this);return this.c};_.X=function(a){xj(this);this.d.X(a)};_.eb=function(a){xj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Ne=Mh(20);oh(56,1,{},Aj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Oe=Mh(56);oh(34,1,{},Bj);_.S=function(a){return a};var Pe=Mh(34);oh(38,1,{},Cj);var Qe=Mh(38);oh(126,1,{});_.c=false;var $e=Mh(126);oh(26,126,{},Mj);var Ze=Mh(26);oh(71,1,{},Pj);_.fb=function(a){return Yc(he,sp,1,a,5,1)};var Re=Mh(71);oh(129,64,{},Rj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Sj(this,a)));return this.b};_.b=false;var Te=Mh(129);oh(132,1,{},Sj);_.w=function(a){Qj(this.a,this.b,a)};var Se=Mh(132);oh(128,64,{},Uj);_.eb=function(a){return this.b.eb(new Vj(this,a))};var Ve=Mh(128);oh(131,1,{},Vj);_.w=function(a){Tj(this.a,this.b,a)};var Ue=Mh(131);oh(130,1,{},Xj);_.w=function(a){Wj(this,a)};var We=Mh(130);oh(133,1,{},Yj);_.w=function(a){};var Xe=Mh(133);oh(134,1,{},$j);_.w=function(a){Zj(this,a)};var Ye=Mh(134);oh(291,1,{});oh(288,1,{});var ek=0;var gk,hk=0,ik;oh(905,1,{});oh(926,1,{});oh(232,1,{});var _e=Mh(232);oh(167,1,{},wk);_.fb=function(a){return new Array(a)};var af=Mh(167);oh(256,$wnd.Function,{},xk);_.hb=function(a){vk(this.a,this.b,a)};oh(6,30,{3:1,28:1,30:1,6:1},gl);var Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el;var bf=Nh(6,hl);var il;oh(255,$wnd.Function,{},kl);_.J=function(a){return Db(il),il=null,null};oh(183,232,{});var Mf=Mh(183);oh(184,183,{});_.d=0;var Qf=Mh(184);oh(185,184,tp,sl);_.t=Zp;_.o=Yp;_.q=Rp;_.u=$p;_.r=function(){var a;return Ih(lf),lf.k+'@'+(a=fk(this)>>>0,a.toString(16))};var ol=0;var lf=Mh(185);oh(186,1,wp,tl);_.v=function(){pl(this.a)};var cf=Mh(186);oh(187,1,{},ul);_.s=function(){return ql(this.a)};var df=Mh(187);oh(188,1,{},vl);_.v=function(){ml(this.a)};var ef=Mh(188);oh(189,1,{},wl);_.s=function(){return nl(this.a)};var ff=Mh(189);oh(205,232,{});var Lf=Mh(205);oh(206,205,{});_.c=0;var Pf=Mh(206);oh(207,206,tp,Cl);_.t=_p;_.o=Yp;_.q=Rp;_.u=aq;_.r=function(){var a;return Ih(kf),kf.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Al=0;var kf=Mh(207);oh(208,1,wp,Dl);_.v=bq;var gf=Mh(208);oh(209,1,{},El);_.v=function(){yl(this.a)};var hf=Mh(209);oh(210,1,{},Fl);_.s=function(){return zl(this.a)};var jf=Mh(210);oh(175,232,{});_.f='';var Zf=Mh(175);oh(176,175,{});_.d=0;var Sf=Mh(176);oh(177,176,tp,Rl);_.t=Zp;_.o=Yp;_.q=Rp;_.u=$p;_.r=function(){var a;return Ih(rf),rf.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Ll=0;var rf=Mh(177);oh(178,1,wp,Sl);_.v=function(){Ml(this.a)};var mf=Mh(178);oh(180,1,{},Tl);_.s=function(){return Kl(this.a)};var nf=Mh(180);oh(181,1,wp,Ul);_.v=function(){Gl(this.a)};var of=Mh(181);oh(182,1,wp,Vl);_.v=function(){Ol(this.a,this.b)};var pf=Mh(182);oh(179,1,{},Wl);_.v=function(){ml(this.a)};var qf=Mh(179);oh(171,232,{});_.i=false;var ag=Mh(171);oh(191,171,{});_.f=0;var Uf=Mh(191);oh(192,191,tp,qm);_.t=function(){gc(this.e)};_.o=Yp;_.q=Rp;_.u=function(){return this.e.f<0};_.r=function(){var a;return Ih(Cf),Cf.k+'@'+(a=fk(this)>>>0,a.toString(16))};var em=0;var Cf=Mh(192);oh(193,1,wp,rm);_.v=function(){fm(this.a)};var sf=Mh(193);oh(196,1,{},sm);_.s=function(){return dm(this.a)};var tf=Mh(196);oh(48,1,wp,tm);_.v=function(){pm(this.a,Pn(this.b))};var uf=Mh(48);oh(67,1,wp,um);_.v=function(){_l(this.a,this.b)};var vf=Mh(67);oh(197,1,wp,vm);_.v=function(){hm(this.a,this.b)};var wf=Mh(197);oh(198,1,wp,wm);_.v=function(){im(this.a,this.b)};var xf=Mh(198);oh(194,1,{},xm);_.s=function(){return jm(this.a)};var yf=Mh(194);oh(199,1,wp,ym);_.v=function(){Xl(this.a,this.b)};var zf=Mh(199);oh(200,1,wp,zm);_.v=function(){am(this.a)};var Af=Mh(200);oh(195,1,{},Am);_.v=function(){cm(this.a)};var Bf=Mh(195);oh(153,232,{});var eg=Mh(153);oh(154,153,{});_.c=0;var Wf=Mh(154);oh(155,154,tp,Hm);_.t=_p;_.o=Yp;_.q=Rp;_.u=aq;_.r=function(){var a;return Ih(Gf),Gf.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Fm=0;var Gf=Mh(155);oh(156,1,wp,Im);_.v=bq;var Df=Mh(156);oh(157,1,{},Jm);_.v=function(){yl(this.a)};var Ef=Mh(157);oh(158,1,{},Km);_.s=function(){return Em(this.a)};var Ff=Mh(158);oh(261,$wnd.Function,{},Lm);_.lb=function(a){Fo(this.a.f)};oh(169,1,{},Mm);var Hf=Mh(169);oh(85,1,{},Nm);var If=Mh(85);var Om;oh(190,1,{},Pm);var Jf=Mh(190);oh(89,1,{},Qm);var Kf=Mh(89);var Rm;oh(262,$wnd.Function,{},Sm);_.mb=function(a){return new Vm(a)};var Tm;oh(173,$wnd.React.Component,{},Vm);nh(lh[1],_);_.componentWillUnmount=function(){ll(this.a)};_.render=function(){return rl(this.a)};_.shouldComponentUpdate=cq;var Nf=Mh(173);oh(272,$wnd.Function,{},Wm);_.mb=function(a){return new Zm(a)};var Xm;oh(201,$wnd.React.Component,{},Zm);nh(lh[1],_);_.componentWillUnmount=function(){xl(this.a)};_.render=function(){return Bl(this.a)};_.shouldComponentUpdate=dq;var Of=Mh(201);oh(260,$wnd.Function,{},$m);_.mb=function(a){return new bn(a)};var _m;oh(172,$wnd.React.Component,{},bn);nh(lh[1],_);_.componentWillUnmount=function(){ll(this.a)};_.render=function(){return Pl(this.a)};_.shouldComponentUpdate=cq;var Rf=Mh(172);oh(263,$wnd.Function,{},cn);_.mb=function(a){return new fn(a)};var dn;oh(174,$wnd.React.Component,{},fn);nh(lh[1],_);_.componentDidUpdate=function(a){mm(this.a)};_.componentWillUnmount=function(){bm(this.a)};_.render=function(){return nm(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Tf=Mh(174);oh(254,$wnd.Function,{},gn);_.mb=function(a){return new kn(a)};var hn;oh(97,$wnd.React.Component,{},kn);nh(lh[1],_);_.componentWillUnmount=function(){xl(this.a)};_.render=function(){return Gm(this.a)};_.shouldComponentUpdate=dq;var Vf=Mh(97);oh(258,$wnd.Function,{},ln);_.kb=function(a){Hl(this.a,a)};oh(259,$wnd.Function,{},mn);_.jb=function(a){Nl(this.a,a)};oh(168,1,{},nn);var Xf=Mh(168);oh(88,1,{},on);var Yf=Mh(88);var pn;oh(270,$wnd.Function,{},qn);_.jb=function(a){gm(this.a,a)};oh(264,$wnd.Function,{},rn);_.jb=function(a){io(this.a)};oh(266,$wnd.Function,{},sn);_.lb=function(a){km(this.a,this.b)};oh(267,$wnd.Function,{},tn);_.lb=function(a){Yl(this.a,this.b)};oh(268,$wnd.Function,{},un);_.w=function(a){Zl(this.a,a)};oh(269,$wnd.Function,{},vn);_.ib=function(a){lm(this.a,this.b)};oh(271,$wnd.Function,{},wn);_.kb=function(a){$l(this.a,this.b,a)};oh(170,1,{},yn);var $f=Mh(170);oh(86,1,{},zn);var _f=Mh(86);var An;oh(253,$wnd.Function,{},Bn);_.jb=function(a){Bm(this.a,a)};oh(98,1,{},Cn);_.S=function(a){return xn(new yn,a)};var bg=Mh(98);oh(69,1,{},Dn);var cg=Mh(69);oh(87,1,{},En);var dg=Mh(87);var Fn;oh(84,1,{},Gn);var fg=Mh(84);oh(47,1,{47:1});var Mg=Mh(47);oh(159,47,{9:1,47:1},Tn);_.t=Zp;_.o=Yp;_.q=Rp;_.u=$p;_.r=function(){var a;return Ih(ng),ng.k+'@'+(a=fk(this)>>>0,a.toString(16))};var ng=Mh(159);oh(160,1,wp,Un);_.v=function(){Nn(this.a)};var gg=Mh(160);oh(162,1,{},Vn);_.v=function(){In(this.a)};var hg=Mh(162);oh(163,1,{},Wn);_.v=function(){Jn(this.a)};var ig=Mh(163);oh(164,1,wp,Xn);_.v=function(){Hn(this.a,this.b)};var jg=Mh(164);oh(165,1,wp,Yn);_.v=function(){Qn(this.a)};var kg=Mh(165);oh(65,1,wp,Zn);_.v=function(){Mn(this.a)};var lg=Mh(65);oh(161,1,{},$n);_.s=function(){var a;return a=(Ch(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var mg=Mh(161);oh(49,1,{49:1});_.d=false;var Vg=Mh(49);oh(202,49,{9:1,257:1,49:1},jo);_.t=Zp;_.o=Yp;_.q=Rp;_.u=$p;_.r=function(){var a;return Ih(Dg),Dg.k+'@'+(a=fk(this)>>>0,a.toString(16))};var _n=0;var Dg=Mh(202);oh(203,1,wp,ko);_.v=function(){ao(this.a)};var og=Mh(203);oh(204,1,wp,lo);_.v=function(){fo(this.a)};var pg=Mh(204);oh(114,113,{});var Pg=Mh(114);oh(25,114,tp,uo);_.t=eq;_.o=Yp;_.q=Rp;_.u=fq;_.r=function(){var a;return Ih(yg),yg.k+'@'+(a=fk(this)>>>0,a.toString(16))};var yg=Mh(25);oh(116,1,wp,vo);_.v=function(){no(this.a)};var qg=Mh(116);oh(115,1,wp,wo);_.v=function(){ro(this.a)};var rg=Mh(115);oh(121,1,wp,xo);_.v=function(){ac(this.a,this.b,true)};var sg=Mh(121);oh(122,1,{},yo);_.s=function(){return mo(this.a,this.c,this.b)};_.b=false;var tg=Mh(122);oh(117,1,{},zo);_.s=function(){return so(this.a)};var ug=Mh(117);oh(118,1,{},Ao);_.s=function(){return Xh(fh(Hj(qo(this.a))))};var vg=Mh(118);oh(119,1,{},Bo);_.s=function(){return Xh(fh(Hj(Ij(qo(this.a),new ip))))};var wg=Mh(119);oh(120,1,{},Co);_.s=function(){return to(this.a)};var xg=Mh(120);oh(45,1,{45:1});var Ug=Mh(45);oh(143,45,{9:1,45:1},Jo);_.t=function(){gc(this.a)};_.o=Yp;_.q=Rp;_.u=function(){return this.a.f<0};_.r=function(){var a;return Ih(Cg),Cg.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Cg=Mh(143);oh(144,1,wp,Ko);_.v=function(){Go(this.a,this.b)};_.b=false;var zg=Mh(144);oh(145,1,wp,Lo);_.v=function(){Sn(this.b,this.a)};var Ag=Mh(145);oh(146,1,wp,Mo);_.v=function(){Ho(this.a)};var Bg=Mh(146);oh(46,1,{46:1});var Yg=Mh(46);oh(147,46,{9:1,46:1},Uo);_.t=eq;_.o=Yp;_.q=Rp;_.u=fq;_.r=function(){var a;return Ih(Jg),Jg.k+'@'+(a=fk(this)>>>0,a.toString(16))};var Jg=Mh(147);oh(148,1,wp,Vo);_.v=function(){Po(this.a)};var Eg=Mh(148);oh(152,1,wp,Wo);_.v=function(){To(this.a,null)};var Fg=Mh(152);oh(149,1,{},Xo);_.s=function(){var a;return a=Pn(this.a.g),o(Op,a)?(fp(),cp):o(Pp,a)?(fp(),ep):(fp(),dp)};var Gg=Mh(149);oh(150,1,{},Yo);_.s=function(){return Ro(this.a)};var Hg=Mh(150);oh(151,1,{},Zo);_.v=function(){So(this.a)};var Ig=Mh(151);oh(136,1,{},$o);_.handleEvent=function(a){Kn(this.a,a)};var Kg=Mh(136);oh(103,1,{},_o);_.I=function(){return new Tn};var Lg=Mh(103);var ap;oh(31,30,{3:1,28:1,30:1,31:1},gp);var cp,dp,ep;var Ng=Nh(31,hp);oh(105,1,{},ip);_.gb=function(a){return !eo(a)};var Og=Mh(105);oh(109,1,{},jp);_.gb=function(a){return eo(a)};var Qg=Mh(109);oh(110,1,{},kp);_.w=function(a){po(this.a,a)};var Rg=Mh(110);oh(108,1,{},lp);_.w=function(a){Eo(this.a,a)};_.a=false;var Sg=Mh(108);oh(102,1,{},mp);_.I=function(){return new Jo(new uo)};var Tg=Mh(102);oh(111,1,{},np);_.gb=function(a){return Oo(this.a,a)};var Wg=Mh(111);oh(104,1,{},op);_.I=function(){return new Uo(new uo,this.a.I())};var Xg=Mh(104);var pd=Oh('D');var pp=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=jh;hh(uh);kh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();