function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='BDA1A1364B07E929BFC60E41EAA18BFD',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'BDA1A1364B07E929BFC60E41EAA18BFD';function p(){}
function vh(){}
function rh(){}
function Fb(){}
function Qc(){}
function Xc(){}
function Xj(){}
function Aj(){}
function Oj(){}
function Wj(){}
function ei(){}
function vk(){}
function jl(){}
function jp(){}
function fp(){}
function fn(){}
function bn(){}
function Bn(){}
function Zn(){}
function Zm(){}
function Rm(){}
function Vm(){}
function ip(){}
function Vc(a){Uc()}
function Eh(){Eh=rh}
function Hi(){yi(this)}
function H(a){this.a=a}
function G(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function fc(a){this.a=a}
function oc(a){this.a=a}
function Uh(a){this.a=a}
function di(a){this.a=a}
function qi(a){this.a=a}
function vi(a){this.a=a}
function wi(a){this.a=a}
function ui(a){this.b=a}
function Ji(a){this.c=a}
function Bj(a){this.a=a}
function Zj(a){this.a=a}
function sl(a){this.a=a}
function tl(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function El(a){this.a=a}
function Rl(a){this.a=a}
function Sl(a){this.a=a}
function Tl(a){this.a=a}
function Vl(a){this.a=a}
function qm(a){this.a=a}
function rm(a){this.a=a}
function wm(a){this.a=a}
function ym(a){this.a=a}
function zm(a){this.a=a}
function Hm(a){this.a=a}
function Im(a){this.a=a}
function Jm(a){this.a=a}
function Km(a){this.a=a}
function kn(a){this.a=a}
function ln(a){this.a=a}
function pn(a){this.a=a}
function qn(a){this.a=a}
function tn(a){this.a=a}
function An(a){this.a=a}
function Tn(a){this.a=a}
function Un(a){this.a=a}
function Vn(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function vo(a){this.a=a}
function wo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Mo(a){this.a=a}
function Vo(a){this.a=a}
function Wo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function kp(a){this.a=a}
function lp(a){this.a=a}
function mp(a){this.a=a}
function np(a){this.a=a}
function op(a){this.a=a}
function _p(){ic(this.c)}
function bq(){ic(this.b)}
function gq(){ic(this.f)}
function Vi(){this.a=cj()}
function hj(){this.a=cj()}
function Vj(a,b){a.a=b}
function ok(a,b){a.key=b}
function nk(a,b){mk(a,b)}
function Eo(a,b){om(b,a)}
function Up(a){lj(this,a)}
function Zp(a){pj(this,a)}
function Xp(a){Yh(this,a)}
function db(a){Yb((J(),a))}
function eb(a){Zb((J(),a))}
function hb(a){$b((J(),a))}
function Y(a){!!a&&$(a)}
function jc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function qb(a,b){a.b=oj(b)}
function Xl(a,b){po(a.j,b)}
function Do(a,b){oo(a.b,b)}
function mc(a,b){mi(a.e,b)}
function Yj(a,b){Nj(a.a,b)}
function C(a,b){Ob(a.f,b.f)}
function dq(){kb(this.a.a)}
function bh(a){return a.e}
function Yp(){return this.e}
function Sp(){return this.a}
function Wp(){return this.b}
function J(){J=rh;I=new F}
function wc(){wc=rh;vc=new p}
function Nc(){Nc=rh;Mc=new Qc}
function $i(){$i=rh;Zi=aj()}
function hp(){hp=rh;gp=new fp}
function Tp(){return ek(this)}
function Yl(a,b){return a.g=b}
function Ib(a){a.a=-4&a.a|1}
function kl(a){a.d=2;ic(a.c)}
function wl(a){a.c=2;ic(a.b)}
function am(a){a.f=2;ic(a.e)}
function rc(a,b){a.e=b;qc(a,b)}
function bk(a,b){a.splice(b,1)}
function hc(a,b,c){li(a.e,b,c)}
function ao(a,b,c){hc(a.c,b,c)}
function uj(a,b,c){b.w(a.a[c])}
function Bi(a,b){return a.a[b]}
function $p(a){return this===a}
function Dh(a){uc.call(this,a)}
function fi(a){uc.call(this,a)}
function _n(a){$(a.b);$(a.a)}
function Mn(a){R(a.a);$(a.b)}
function Ll(a){kb(a.a);$(a.b)}
function ol(a){kb(a.b);R(a.a)}
function Hh(a){Gh(a);return a.k}
function Yc(a,b){return Nh(a,b)}
function Vp(){return oi(this.a)}
function aq(){return this.c.i<0}
function cq(){return this.b.i<0}
function hq(){return this.f.i<0}
function Zh(){pc(this);this.G()}
function kh(){ih==null&&(ih=[])}
function Dc(){Dc=rh;!!(Uc(),Tc)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function T(a){mb(a.f);return V(a)}
function Mj(a,b){a.T(b);return a}
function yk(a,b){a.ref=b;return a}
function On(a){fb(a.b);return a.e}
function eo(a){fb(a.a);return a.d}
function Qo(a){fb(a.d);return a.e}
function cj(){$i();return new Zi}
function ab(a){J();Zb(a);a.e=-2}
function K(a,b){O(a);L(a,oj(b))}
function Nj(a,b){Vj(a,Mj(a.a,b))}
function pj(a,b){while(a.eb(b));}
function Sj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function ej(a,b){return a.a.get(b)}
function oi(a){return a.a.b+a.b.b}
function eq(a){return 1==this.a.d}
function fq(a){return 1==this.a.c}
function gc(a,b){this.a=a;this.b=b}
function Sh(a,b){this.a=a;this.b=b}
function xi(a,b){this.a=a;this.b=b}
function Rj(a,b){this.a=a;this.b=b}
function Uj(a,b){this.a=a;this.b=b}
function Ul(a,b){this.a=a;this.b=b}
function wk(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function tm(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function xm(a,b){this.a=a;this.b=b}
function rn(a,b){this.a=a;this.b=b}
function sn(a,b){this.a=a;this.b=b}
function un(a,b){this.a=a;this.b=b}
function vn(a,b){this.a=a;this.b=b}
function fl(a,b){Sh.call(this,a,b)}
function Wn(a,b){this.a=a;this.b=b}
function xo(a,b){this.a=a;this.b=b}
function Ko(a,b){this.a=a;this.b=b}
function Lo(a,b){this.b=a;this.a=b}
function dp(a,b){Sh.call(this,a,b)}
function _j(a,b,c){a.splice(b,0,c)}
function zk(a,b){a.href=b;return a}
function bi(a,b){a.a+=''+b;return a}
function Ik(a,b){a.value=b;return a}
function Kc(a){$wnd.clearTimeout(a)}
function Lm(){this.a=pk((Tm(),Sm))}
function Om(){this.a=pk((Xm(),Wm))}
function mn(){this.a=pk((_m(),$m))}
function xn(){this.a=pk((dn(),cn))}
function Cn(){this.a=pk((hn(),gn))}
function nn(a){this.a=oj(a);on=this}
function Pm(a){this.a=oj(a);Qm=this}
function Pn(a){Nn(a,(fb(a.b),a.e))}
function fo(a){om(a,(fb(a.a),!a.d))}
function Ub(a){return !a.d?a:Ub(a.d)}
function ki(a){return !a?null:a.ab()}
function nj(a){return a!=null?s(a):0}
function pd(a){return a==null?null:a}
function md(a){return typeof a===rp}
function o(a,b){return pd(a)===pd(b)}
function ak(a,b){$j(b,0,a,0,b.length)}
function Dk(a,b){a.onBlur=b;return a}
function Ak(a,b){a.onClick=b;return a}
function Ck(a,b){a.checked=b;return a}
function yi(a){a.a=$c(je,tp,1,0,5,1)}
function ni(a){a.a=new Vi;a.b=new hj}
function ib(a){this.c=new Hi;this.b=a}
function Db(a){this.d=oj(a);this.b=100}
function P(){this.a=$c(je,tp,1,100,5,1)}
function B(a,b,c){return u(a,c,2048,b)}
function A(a,b,c){u(a,new G(b),c,null)}
function ec(a,b){cc(a,b,false);eb(a.d)}
function em(a){kb(a.b);R(a.c);$(a.a)}
function pb(a){J();ob(a);sb(a,2,true)}
function fb(a){var b;Vb((J(),b=Qb,b),a)}
function Z(a){return !(!!a&&1==(a.c&7))}
function ek(a){return a.$H||(a.$H=++dk)}
function $h(a,b){return a.charCodeAt(b)}
function kd(a,b){return a!=null&&hd(a,b)}
function cd(a,b,c){return {l:a,m:b,h:c}}
function mk(a,b){for(var c in a){b(c)}}
function Ek(a,b){a.onChange=b;return a}
function Fk(a,b){a.onKeyDown=b;return a}
function Bk(a){a.autoFocus=true;return a}
function Gh(a){if(a.k!=null){return}Ph(a)}
function xh(a){this.b=oj(a);this.a=this}
function uc(a){this.g=a;pc(this);this.G()}
function Lj(a,b){Ej.call(this,a);this.a=b}
function dc(a,b){mc(b.c,a);kd(b,9)&&b.t()}
function lj(a,b){while(a.Y()){Yj(b,a.Z())}}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function ik(){ik=rh;fk=new p;hk=new p}
function Pi(){this.a=new Vi;this.b=new hj}
function od(a){return typeof a==='string'}
function ld(a){return typeof a==='boolean'}
function to(a){return Vh(S(a.e).a-S(a.a).a)}
function Po(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function Xi(a,b){var c;c=a[Gp];c.call(a,b)}
function io(a){A((J(),J(),I),new lo(a),Lp)}
function Fo(a){A((J(),J(),I),new Mo(a),Lp)}
function lm(a){A((J(),J(),I),new ym(a),Lp)}
function Qn(a){A((J(),J(),I),new Xn(a),Lp)}
function Xh(){Xh=rh;Wh=$c(fe,tp,30,256,0,1)}
function Kh(a){var b;b=Jh(a);Rh(a,b);return b}
function pc(a){a.j&&a.e!==Bp&&a.G();return a}
function Jk(a,b){a.onDoubleClick=b;return a}
function zi(a,b){a.a[a.a.length]=b;return true}
function kj(a,b,c){this.a=a;this.b=b;this.c=c}
function Nb(a,b,c){Ib(oj(c));K(a.a[b],oj(c))}
function Ec(a,b,c){return a.apply(b,c);var d}
function Bh(a,b,c,d){a.addEventListener(b,c,d)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Ml(a,b){A((J(),J(),I),new Ul(a,b),Lp)}
function fm(a,b){A((J(),J(),I),new xm(a,b),Lp)}
function jm(a,b){A((J(),J(),I),new um(a,b),Lp)}
function km(a,b){A((J(),J(),I),new tm(a,b),Lp)}
function nm(a,b){A((J(),J(),I),new sm(a,b),Lp)}
function po(a,b){A((J(),J(),I),new xo(a,b),Lp)}
function Io(a,b){A((J(),J(),I),new Ko(a,b),Lp)}
function sj(a,b){while(a.c<a.d){uj(a,b,a.c++)}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function yo(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new Pb;this.a=new Db(this.f)}
function ro(a){Yh(new vi(a.g),new fc(a));ni(a.g)}
function No(a){return o(Qp,a)||o(Rp,a)||o('',a)}
function ad(a){return Array.isArray(a)&&a.pb===vh}
function wj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Nl(a,b){var c;c=b.target;Pl(a,c.value)}
function Fj(a,b){var c;return Jj(a,(c=new Hi,c))}
function yh(a){oj(a);return kd(a,45)?a:new xh(a)}
function Uc(){Uc=rh;var a;!Wc();a=new Xc;Tc=a}
function Ah(){Ah=rh;zh=$wnd.goog.global.document}
function si(a){var b;b=a.a.Z();a.b=ri(a);return b}
function Mh(a){var b;b=Jh(a);b.j=a;b.e=1;return b}
function Di(a,b){var c;c=a.a[b];bk(a.a,b);return c}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ki(a,b){return qj(b,a.length),new vj(a,b)}
function dj(a,b){return !(a.a.get(b)===undefined)}
function pl(a){return Eh(),S(a.e.b).a>0?true:false}
function so(a){return Eh(),0==S(a.e).a?true:false}
function ql(a){return B((J(),J(),I),a.b,new vl(a))}
function Al(a){return B((J(),J(),I),a.a,new El(a))}
function Ol(a){return B((J(),J(),I),a.a,new Sl(a))}
function mm(a){return B((J(),J(),I),a.b,new rm(a))}
function Fm(a){return B((J(),J(),I),a.a,new Jm(a))}
function Li(a){return new Lj(null,Ki(a,a.length))}
function jd(a){return !Array.isArray(a)&&a.pb===vh}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function no(a){R(a.c);R(a.e);R(a.a);R(a.b);$(a.d)}
function xl(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function ll(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function bm(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Cj(a){if(!a.b){Dj(a);a.c=true}else{Cj(a.b)}}
function Pj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function Pl(a,b){var c;c=a.f;if(b!=c){a.f=b;eb(a.b)}}
function om(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function Am(a,b){var c;c=b.target;Io(a.e,c.checked)}
function Fi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Hk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function pi(a,b){if(b){return ii(a.a,b)}return false}
function Hj(a,b){Dj(a);return new Lj(a,new Qj(b,a.a))}
function Ij(a,b){Dj(a);return new Lj(a,new Tj(b,a.a))}
function Nn(a,b){A((J(),J(),I),new Wn(a,b),75497472)}
function Ch(a,b,c,d){a.removeEventListener(b,c,d)}
function gm(a,b){To(a.k,b);A((J(),J(),I),new sm(a,b),Lp)}
function gb(a){var b;J();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Ln(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&Rn(a,b)}
function Rn(a,b){var c;c=a.e;if(b!=c){a.e=oj(b);eb(a.b)}}
function Lh(a,b){var c;c=Jh(a);Rh(a,c);c.e=b?8:0;return c}
function oj(a){if(a==null){throw bh(new Zh)}return a}
function lk(){if(gk==256){fk=hk;hk=new p;gk=0}++gk}
function hh(a){if(md(a)){return a|0}return a.l|a.m<<22}
function Ej(a){if(!a){this.b=null;new Hi}else{this.b=a}}
function vj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function rj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function xj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function _b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function lb(a){C((J(),J(),I),a);0==(a.f.a&yp)&&D((null,I))}
function hm(a,b){A((J(),J(),I),new sm(a,b),Lp);To(a.k,null)}
function Go(a,b){Fj(qo(a.b),new Bj(new Aj)).Q(new lp(b))}
function Oi(a,b){return pd(a)===pd(b)||a!=null&&q(a,b)}
function ji(a,b){return b===a?'(this Map)':b==null?Dp:uh(b)}
function sc(a,b){var c;c=Hh(a.nb);return b==null?c:c+': '+b}
function Wl(a,b){var c;if(S(a.c)){c=b.target;om(a,c.value)}}
function Yh(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function Rb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function Oh(a){if(a.P()){return null}var b=a.j;return nh[b]}
function th(a){function b(){}
;b.prototype=a||{};return new b}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Dj(a){if(a.b){Dj(a.b)}else if(a.c){throw bh(new Th)}}
function dn(){dn=rh;var a;cn=(a=sh(bn.prototype.mb,bn,[]),a)}
function hn(){hn=rh;var a;gn=(a=sh(fn.prototype.mb,fn,[]),a)}
function Tm(){Tm=rh;var a;Sm=(a=sh(Rm.prototype.mb,Rm,[]),a)}
function Xm(){Xm=rh;var a;Wm=(a=sh(Vm.prototype.mb,Vm,[]),a)}
function _m(){_m=rh;var a;$m=(a=sh(Zm.prototype.mb,Zm,[]),a)}
function ep(){cp();return bd(Yc(Og,1),tp,32,0,[_o,bp,ap])}
function Si(a,b){var c;return Qi(b,Ri(a,b==null?0:(c=s(b),c|0)))}
function Ri(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Nh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function ph(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function im(a){return Eh(),Qo(a.k)==a.n.props['a']?true:false}
function Hn(a){Bh((Ah(),$wnd.goog.global.window),Op,a.d,false)}
function In(a){Ch((Ah(),$wnd.goog.global.window),Op,a.d,false)}
function Ii(a){yi(this);ak(this.a,hi(a,$c(je,tp,1,oi(a.a),5,1)))}
function Wi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Tj(a,b){rj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function Mm(a,b,c){this.a=oj(a);this.b=oj(b);this.c=oj(c);Nm=this}
function yn(a,b,c){this.a=oj(a);this.b=oj(b);this.c=oj(c);zn=this}
function Dn(a,b,c){this.a=oj(a);this.b=oj(b);this.c=oj(c);En=this}
function uk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function lc(a){jc(a.g);!!a.e&&kc(a);Y(a.a);Y(a.c);jc(a.b);jc(a.f)}
function qo(a){fb(a.d);return new Lj(null,new xj(new vi(a.g),0))}
function Ho(a){Fj(Hj(qo(a.b),new jp),new Bj(new Aj)).Q(new kp(a.b))}
function Jn(a,b){b.preventDefault();A((J(),J(),I),new Yn(a),Lp)}
function Gk(a){a.placeholder='What needs to be done?';return a}
function tj(a,b){if(a.c<a.d){uj(a,b,a.c++);return true}return false}
function yj(a,b){!a.a?(a.a=new di(a.d)):bi(a.a,a.b);bi(a.a,b);return a}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function bb(a,b){var c,d;zi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Qj(a,b){rj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function ij(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Jo(a){this.b=oj(a);J();this.a=new nc(0,null,null,false,false)}
function Gj(a){var b;Cj(a);b=0;while(a.a.eb(new Xj)){b=dh(b,1)}return b}
function Jj(a,b){var c;Cj(a);c=new Wj;c.a=b;a.a.X(new Zj(c));return c.a}
function oo(a,b){var c;return u((J(),J(),I),new yo(a,b),Lp,(c=null,c))}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Fl(a){var b;b=ai((fb(a.b),a.f));if(b.length>0){Do(a.e,b);Pl(a,'')}}
function mi(a,b){return od(b)?b==null?Ui(a.a,null):gj(a.b,b):Ui(a.a,b)}
function Oo(a,b){return (cp(),ap)==a||(_o==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Jb(b){try{b.b.v()}catch(a){a=ah(a);if(!kd(a,4))throw bh(a)}}
function Gn(a,b){a.f=b;o(b,S(a.a))&&Rn(a,b);Kn(b);A((J(),J(),I),new Yn(a),Lp)}
function Ro(a){var b;return b=S(a.b),Fj(Hj(qo(a.i),new np(b)),new Bj(new Aj))}
function Kj(a,b){var c;c=Fj(a,new Bj(new Aj));return Gi(c,b.fb(c.a.length))}
function ti(a){this.d=a;this.c=new ij(this.d.b);this.a=this.c;this.b=ri(this)}
function zj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Ym(a){$wnd.React.Component.call(this,a);this.a=new Bl(this,Qm.a)}
function an(a){$wnd.React.Component.call(this,a);this.a=new Ql(this,on.a)}
function jj(a){if(a.a.c!=a.c){return ej(a.a,a.b.value[0])}return a.b.value[1]}
function bo(a,b){var c;if(kd(b,51)){c=b;return a.c.d==c.c.d}else{return false}}
function Ei(a,b){var c;c=Ci(a,b,0);if(c==-1){return false}bk(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&bd(Yc(a,f),b,c,e,g);return g}
function Ci(a,b,c){for(;c<a.a.length;++c){if(Oi(b,a.a[c])){return c}}return -1}
function V(a){if(a.b){if(kd(a.b,7)){throw bh(a.b)}else{throw bh(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=ah(a);if(kd(a,4)){J()}else throw bh(a)}}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function ic(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new oc(a)),67108864,null)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function li(a,b,c){return od(b)?b==null?Ti(a.a,null,c):fj(a.b,b,c):Ti(a.a,b,c)}
function ck(a,b){return Zc(b)!=10&&bd(r(b),b.ob,b.__elementTypeId$,Zc(b),a),a}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nd(a){return a!=null&&(typeof a===qp||typeof a==='function')&&!(a.pb===vh)}
function Um(a){$wnd.React.Component.call(this,a);this.a=new rl(this,Nm.a,Nm.b,Nm.c)}
function en(a){$wnd.React.Component.call(this,a);this.a=new pm(this,zn.a,zn.b,zn.c)}
function jn(a){$wnd.React.Component.call(this,a);this.a=new Gm(this,En.a,En.b,En.c)}
function Pb(){var a;this.a=$c(vd,tp,44,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Ai(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Hi);zi(a.b,b)}}}
function Rh(a,b){var c;if(!a){return}b.j=a;var d=Oh(b);if(!d){nh[a]=[b];return}d.nb=b}
function sh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Jh(a){var b;b=new Ih;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function sk(a){var b;return qk($wnd.React.StrictMode,null,null,(b={},b[Hp]=oj(a),b))}
function Gl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Tl(a),Lp)}}
function bc(){var a;try{Sb(Qb);J()}finally{a=Qb.d;!a&&((J(),J(),I).d=true);Qb=Qb.d}}
function jh(){kh();var a=ih;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ob(a){var b,c;for(c=new Ji(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Mi(a){var b,c,d;d=0;for(c=new ti(a.a);c.b;){b=si(c);d=d+(b?s(b):0);d=d|0}return d}
function pk(a){var b;b=rk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function qk(a,b,c,d){var e;e=rk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=oj(d);return e}
function gj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Xi(a.a,b);--a.b}return c}
function mo(a,b,c){var d;d=new jo(b,c);ao(d,a,new gc(a,d));li(a.g,Vh(d.c.d),d);eb(a.d);return d}
function gi(a,b){var c,d;for(d=new ti(b.a);d.b;){c=si(d);if(!pi(a,c)){return false}}return true}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Hi);a.c=c.c}b.d=true;zi(a.c,oj(b))}
function cc(a,b,c){var d;d=mi(a.g,b?Vh(b.c.d):null);if(null!=d){mc(b.c,a);c&&!!b&&ic(b.c);eb(a.d)}}
function wn(a,b){ok(a.a,(Gh(cg),cg.k+(''+(b?Vh(b.c.d):null))));oj(b);a.a.props['a']=b;return a.a}
function ri(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new Wi(a.d.a);return a.a.Y()}
function ah(a){var b;if(kd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new yc(a);Vc(b)}return b}
function eh(a){var b;b=a.h;if(b==0){return a.l+a.m*zp}if(b==1048575){return a.l+a.m*zp-Ep}return a}
function gh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Ep;d=1048575}c=qd(e/zp);b=qd(e-c*zp);return cd(b,c,d)}
function So(a){var b;b=S(a.g.a);o(Qp,b)||o(Rp,b)||o('',b)?Nn(a.g,b):No(On(a.g))?Qn(a.g):Nn(a.g,'')}
function Kb(a,b){this.b=oj(a);this.a=b|0|(0==(b&6291456)?zp:0)|(0!=(b&229376)?0:98304)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:vp)|(0==(c&6291456)?!a?yp:zp:0)|0|0|0)}
function Th(){uc.call(this,"Stream already terminated, can't be modified or used")}
function Fn(){this.a=yh((hp(),gp));this.b=yh(new mp(this.a));this.c=yh(new op(this.a))}
function cp(){cp=rh;_o=new dp('ACTIVE',0);bp=new dp('COMPLETED',1);ap=new dp('ALL',2)}
function mh(a,b){typeof window===qp&&typeof window['$gwt']===qp&&(window['$gwt'][a]=b)}
function qj(a,b){if(0>a||a>b){throw bh(new Dh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function fj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function bd(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=vh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Qi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Oi(a,c._())){return c}}return null}
function Vh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Xh(),Wh)[b];!c&&(c=Wh[b]=new Uh(a));return c}return new Uh(a)}
function To(a,b){var c;c=a.e;if(!(b==c||!!b&&bo(b,c))){!!c&&mc(c.c,a);a.e=b;!!b&&ao(b,a,new Wo(a));eb(a.d)}}
function cb(a,b){var c,d;d=a.c;Ei(d,b);!!a.b&&vp!=(a.b.c&wp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((J(),c=Qb,c),a))}
function Zl(a,b,c){27==c.which?A((J(),J(),I),new vm(a,b),Lp):13==c.which&&A((J(),J(),I),new tm(a,b),Lp)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function il(){if(!hl){hl=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(sh(jl.prototype.J,jl,[]))}}
function yc(a){wc();pc(this);this.e=a;qc(this,a);this.g=a==null?Dp:uh(a);this.a='';this.b=a;this.a=''}
function Ih(){this.g=Fh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function kk(a){ik();var b,c,d;c=':'+a;d=hk[c];if(d!=null){return qd(d)}d=fk[c];b=d==null?jk(a):qd(d);lk();hk[c]=b;return b}
function Ni(a){var b,c,d;d=1;for(c=new Ji(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function uh(a){var b;if(Array.isArray(a)&&a.pb===vh){return Hh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function _l(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;nm(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=Di(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function $l(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Lo(b,c),Lp);To(a.k,null);om(a,c)}else{po(a.j,b)}}
function dh(a,b){var c;if(md(a)&&md(b)){c=a+b;if(-17592186044416<c&&c<Ep){return c}}return eh(dd(md(a)?gh(a):a,md(b)?gh(b):b))}
function dd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return cd(c&4194303,d&4194303,e&1048575)}
function r(a){return od(a)?me:md(a)?ae:ld(a)?$d:jd(a)?a.nb:ad(a)?a.nb:a.nb||Array.isArray(a)&&Yc(Rd,1)||Rd}
function s(a){return od(a)?kk(a):md(a)?qd(a):ld(a)?a?1231:1237:jd(a)?a.q():ad(a)?ek(a):!!a&&!!a.hashCode?a.hashCode():ek(a)}
function q(a,b){return od(a)?o(a,b):md(a)?pd(a)===pd(b):ld(a)?pd(a)===pd(b):jd(a)?a.o(b):ad(a)?o(a,b):!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function gl(){el();return bd(Yc(df,1),tp,6,0,[Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl])}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&vp)?Jb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(vp==(b&wp)?0:524288)|(0==(b&6291456)?vp==(b&wp)?zp:yp:0)|0|268435456|0)}
function Qh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Gi(a,b){var c,d;d=a.a.length;b.length<d&&(b=ck(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a){var b,c,d;for(c=new Ji(new Ii(new qi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();kd(d,9)&&d.u()||b.ab().v()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ji(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function hd(a,b){if(od(a)){return !!gd[b]}else if(a.ob){return !!a.ob[b]}else if(md(a)){return !!fd[b]}else if(ld(a)){return !!ed[b]}return false}
function nc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Pi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Bl(a,b){var c;this.d=oj(b);this.n=oj(a);J();c=++zl;this.b=new nc(c,null,new Cl(this),false,false);this.a=new vb(null,oj(new Dl(this)),Kp)}
function jo(a,b){var c,d,e,f,g;this.e=oj(a);this.d=b;J();c=++$n;this.c=new nc(c,null,new ko(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function xk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Qb&&!!Qb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function ai(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function hi(a,b){var c,d,e,f;f=oi(a.a);b.length<f&&(b=ck(new Array(f),b));e=b;d=new ti(a.a);for(c=0;c<f;++c){e[c]=si(d)}b.length>f&&(b[f]=null);return b}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.v(),null)}finally{bc()}return f}catch(a){a=ah(a);if(kd(a,4)){e=a;throw bh(e)}else throw bh(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.s()}else{ac(b,e);try{g=c.s()}finally{bc()}}return g}catch(a){a=ah(a);if(kd(a,4)){f=a;throw bh(f)}else throw bh(a)}finally{D(b)}}
function Bb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Hb(c);return true}
function lh(b,c,d,e){kh();var f=ih;$moduleName=c;$moduleBase=d;_g=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{pp(g)()}catch(a){b(c,a)}}else{pp(g)()}}
function W(a,b,c,d){this.c=oj(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);vp==(d&wp)&&lb(this.f)}
function rk(a,b){var c;c=new $wnd.Object;c.$$typeof=oj(a);c.type=oj(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Gm(a,b,c,d){var e;this.d=oj(b);this.e=oj(c);this.f=oj(d);this.n=oj(a);J();e=++Em;this.b=new nc(e,null,new Hm(this),false,false);this.a=new vb(null,oj(new Im(this)),Kp)}
function Ql(a,b){var c,d,e;this.e=oj(b);this.n=oj(a);J();c=++Kl;this.c=new nc(c,null,new Rl(this),false,false);this.b=(e=new ib((d=null,d)),e);this.a=new vb(null,oj(new Vl(this)),Kp)}
function aj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return bj()}}
function yl(a){var b,c,d;a.c=0;il();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),tk('span',xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,['todo-count'])),[tk('strong',null,[c]),' '+d+' left']));return b}
function oh(){nh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Rc(c,g)):g[0].qb()}catch(a){a=ah(a);if(kd(a,4)){d=a;Dc();Jc(kd(d,36)?d.H():d)}else throw bh(a)}}return c}
function Jl(a){var b;a.d=0;il();b=tk(Mp,Bk(Ek(Fk(Ik(Gk(xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,['new-todo']))),(fb(a.b),a.f)),sh(kn.prototype.kb,kn,[a])),sh(ln.prototype.jb,ln,[a]))),null);return b}
function xc(a){var b;if(a.c==null){b=pd(a.b)===pd(vc)?null:a.b;a.d=b==null?Dp:nd(b)?b==null?null:b.name:od(b)?'String':Hh(r(b));a.a=a.a+': '+(nd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(pd(e)===pd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=ah(a);if(kd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw bh(c)}else throw bh(a)}}
function $j(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Ti(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Qi(b,e);if(f){return f.bb(c)}}e[e.length]=new xi(b,c);++a.b;return null}
function jk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+$h(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=ah(a);if(kd(a,4)){J()}else throw bh(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=$c(je,tp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function rl(a,b,c,d){var e;this.e=oj(b);this.f=oj(c);this.g=oj(d);this.n=oj(a);J();e=++nl;this.c=new nc(e,null,new sl(this),false,false);this.a=new W(new tl(this),null,null,136478720);this.b=new vb(null,oj(new ul(this)),Kp)}
function ub(a,b,c,d){this.b=new Hi;this.f=new Kb(new yb(this),d&6520832|262144|vp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&yp)&&D((null,I)))}
function Ui(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Oi(b,e._())){if(d.length==1){d.length=0;Xi(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function wh(){var a;a=new Fn;new Mm(a.a.I(),a.b.I(),a.c.I());new yn(a.a.I(),a.b.I(),a.c.I());new Dn(a.a.I(),a.b.I(),a.c.I());new nn(a.b.I());new Pm(a.a.I());$wnd.ReactDOM.render(sk([(new Cn).a]),(Ah(),zh).getElementById('app'),null)}
function qh(a,b,c){var d=nh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=nh[b]),th(h));_.ob=c;!b&&(_.pb=vh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Ph(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Qh('.',[c,Qh('$',d)]);a.b=Qh('.',[c,Qh('.',d)]);a.i=d[d.length-1]}
function Kn(a){var b;if(0==a.length){b=(Ah(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',zh.title,b)}else{(Ah(),$wnd.goog.global.window).location.hash=a}}
function ii(a,b){var c,d,e;c=b._();e=b.ab();d=od(c)?c==null?ki(Si(a.a,null)):ej(a.b,c):ki(Si(a.a,c));if(!(pd(e)===pd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(od(c)?c==null?!!Si(a.a,null):dj(a.b,c):!!Si(a.a,c))){return false}return true}
function tk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;nk(b,sh(wk.prototype.hb,wk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Hp]=c[0],undefined):(d[Hp]=c,undefined));return qk(a,e,f,d)}
function Sn(){var a,b,c;this.d=new $o(this);this.f=this.e=(c=(Ah(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new nc(0,null,new Tn(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new Zn,new Un(this),new Vn(this),35651584)}
function Uo(a){var b,c;this.i=oj(a);this.g=new Sn;J();this.f=new nc(0,null,new Vo(this),false,false);this.d=(c=new ib((b=null,b)),c);this.b=new W(new Xo(this),null,null,Pp);this.c=new W(new Yo(this),null,null,Pp);this.a=new vb(oj(new Zo(this)),null,681574400);D((null,I))}
function uo(){var a;this.g=new Pi;J();this.f=new nc(0,new wo(this),new vo(this),false,false);this.d=(a=new ib(null),a);this.c=new W(new zo(this),null,null,Pp);this.e=new W(new Ao(this),null,null,Pp);this.a=new W(new Bo(this),null,null,Pp);this.b=new W(new Co(this),null,null,Pp)}
function pm(a,b,c,d){var e,f,g;this.j=oj(b);oj(c);this.k=oj(d);this.n=oj(a);J();e=++dm;this.e=new nc(e,null,new qm(this),false,false);this.a=(g=new ib((f=null,f)),g);this.c=new W(new wm(this),null,null,136478720);this.b=new vb(null,oj(new zm(this)),Kp);nm(this,this.n.props['a'])}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ji(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=ah(a);if(!kd(a,4))throw bh(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function qc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function _i(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}Ai(a.b,new Ab(a));a.b.a=$c(je,tp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Dm(a){var b;a.c=0;il();b=tk('div',null,[tk('div',null,[tk(Np,xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,[Np])),[tk('h1',null,['todos']),(new mn).a]),S(a.d.c)?null:tk('section',xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,[Np])),[tk(Mp,Ek(Hk(xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,['toggle-all'])),(el(),Lk)),sh(An.prototype.jb,An,[a])),null),tk('ul',xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,['todo-list'])),Kj(oj(Ij(S(a.f.c).W(),new Bn)),new vk))]),S(a.d.c)?null:(new Lm).a])]);return b}
function el(){el=rh;Kk=new fl(Ip,0);Lk=new fl('checkbox',1);Mk=new fl('color',2);Nk=new fl('date',3);Ok=new fl('datetime',4);Pk=new fl('email',5);Qk=new fl('file',6);Rk=new fl('hidden',7);Sk=new fl('image',8);Tk=new fl('month',9);Uk=new fl(rp,10);Vk=new fl('password',11);Wk=new fl('radio',12);Xk=new fl('range',13);Yk=new fl('reset',14);Zk=new fl('search',15);$k=new fl('submit',16);_k=new fl('tel',17);al=new fl('text',18);bl=new fl('time',19);cl=new fl('url',20);dl=new fl('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Bi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Fi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Bi(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Di(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Hi)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&vp!=(k.b.c&wp)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function ml(a){var b,c;a.d=0;il();c=(b=S(a.g.b),tk('footer',xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,['footer'])),[(new Om).a,tk('ul',xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,['filters'])),[tk('li',null,[tk('a',zk(xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,[(cp(),ap)==b?Jp:null])),'#'),['All'])]),tk('li',null,[tk('a',zk(xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,[_o==b?Jp:null])),'#active'),['Active'])]),tk('li',null,[tk('a',zk(xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,[bp==b?Jp:null])),'#completed'),['Completed'])])]),S(a.a)?tk(Ip,Ak(xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,['clear-completed'])),sh(Km.prototype.lb,Km,[a])),['Clear Completed']):null]));return c}
function cm(a){var b,c,d,e;a.f=0;il();b=a.n.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.n.props['a'],e=(fb(d.a),d.d),tk('li',xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[tk('div',xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,['view'])),[tk(Mp,Ek(Ck(Hk(xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,['toggle'])),(el(),Lk)),e),sh(qn.prototype.jb,qn,[d])),null),tk('label',Jk(new $wnd.Object,sh(rn.prototype.lb,rn,[a,d])),[(fb(d.b),d.e)]),tk(Ip,Ak(xk(new $wnd.Object,bd(Yc(me,1),tp,2,6,['destroy'])),sh(sn.prototype.lb,sn,[a,d])),null)]),tk(Mp,Fk(Ek(Dk(Ik(xk(yk(new $wnd.Object,sh(tn.prototype.w,tn,[a])),bd(Yc(me,1),tp,2,6,['edit'])),(fb(a.a),a.d)),sh(un.prototype.ib,un,[a,d])),sh(pn.prototype.jb,pn,[a])),sh(vn.prototype.kb,vn,[a,d])),null)]));return c}
function bj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Gp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!_i()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Gp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var qp='object',rp='number',sp={11:1},tp={3:1},up={9:1},vp=1048576,wp=1835008,xp={5:1},yp=2097152,zp=4194304,Ap={25:1},Bp='__noinit__',Cp={3:1,10:1,7:1,4:1},Dp='null',Ep=17592186044416,Fp={42:1},Gp='delete',Hp='children',Ip='button',Jp='selected',Kp=1411518464,Lp=142606336,Mp='input',Np='header',Op='hashchange',Pp=136314880,Qp='active',Rp='completed';var _,nh,ih,_g=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;oh();qh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=Tp;_.r=function(){var a;return Hh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var ed,fd,gd;qh(56,1,{},Ih);_.K=function(a){var b;b=new Ih;b.e=4;a>1?(b.c=Nh(this,a-1)):(b.c=this);return b};_.L=function(){Gh(this);return this.b};_.M=function(){return Hh(this)};_.N=function(){Gh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Gh(this),this.k)};_.e=0;_.g=0;var Fh=1;var je=Kh(1);var _d=Kh(56);qh(86,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var ud=Kh(86);qh(37,1,sp,G);_.s=function(){return this.a.v(),null};var sd=Kh(37);qh(87,1,{},H);var td=Kh(87);var I;qh(44,1,{44:1},P);_.b=0;_.c=false;_.d=0;var vd=Kh(44);qh(235,1,up);_.r=function(){var a;return Hh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var yd=Kh(235);qh(19,235,up,W);_.t=function(){R(this)};_.u=Sp;_.a=false;_.d=0;_.k=false;var xd=Kh(19);qh(155,1,sp,X);_.s=function(){return T(this.a)};var wd=Kh(155);qh(17,235,{9:1,17:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Ad=Kh(17);qh(154,1,xp,jb);_.v=function(){ab(this.a)};var zd=Kh(154);qh(18,235,{9:1,18:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Fd=Kh(18);qh(156,1,Ap,xb);_.v=function(){Q(this.a)};var Bd=Kh(156);qh(157,1,xp,yb);_.v=function(){mb(this.a)};var Cd=Kh(157);qh(158,1,xp,zb);_.v=function(){pb(this.a)};var Dd=Kh(158);qh(159,1,{},Ab);_.w=function(a){nb(this.a,a)};var Ed=Kh(159);qh(104,1,{},Db);_.a=0;_.b=0;_.c=0;var Gd=Kh(104);qh(160,1,up,Fb);_.t=function(){Eb(this)};_.u=Sp;_.a=false;var Hd=Kh(160);qh(68,235,{9:1,68:1},Kb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Jd=Kh(68);qh(61,1,{61:1},Pb);var Id=Kh(61);qh(173,1,{},_b);_.r=function(){var a;return Gh(Kd),Kd.k+'@'+(a=ek(this)>>>0,a.toString(16))};_.a=0;var Qb;var Kd=Kh(173);qh(143,1,{});var Nd=Kh(143);qh(108,1,{},fc);_.w=function(a){dc(this.a,a)};var Ld=Kh(108);qh(109,1,xp,gc);_.v=function(){ec(this.a,this.b)};var Md=Kh(109);qh(16,1,up,nc);_.t=function(){ic(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Gh(Pd),Pd.k+'@'+(a=ek(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Pd=Kh(16);qh(153,1,xp,oc);_.v=function(){lc(this.a)};var Od=Kh(153);qh(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=Yp;_.C=function(){return Kj(Ij(Li((this.i==null&&(this.i=$c(oe,tp,4,0,0,1)),this.i)),new ei),new Oj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){rc(this,tc(this.A(sc(this,this.g))));Vc(this)};_.r=function(){return sc(this,this.F())};_.e=Bp;_.j=true;var oe=Kh(4);qh(10,4,{3:1,10:1,4:1});var ce=Kh(10);qh(7,10,Cp);var ke=Kh(7);qh(57,7,Cp);var ge=Kh(57);qh(80,57,Cp);var Td=Kh(80);qh(36,80,{36:1,3:1,10:1,7:1,4:1},yc);_.F=function(){xc(this);return this.c};_.H=function(){return pd(this.b)===pd(vc)?null:this.b};var vc;var Qd=Kh(36);var Rd=Kh(0);qh(217,1,{});var Sd=Kh(217);var Ac=0,Bc=0,Cc=-1;qh(95,217,{},Qc);var Mc;var Ud=Kh(95);var Tc;qh(228,1,{});var Wd=Kh(228);qh(81,228,{},Xc);var Vd=Kh(81);qh(45,1,{45:1,71:1},xh);_.I=function(){if(this===this.a){this.a=this.b.I();this.b=null}return this.a};var Xd=Kh(45);var zh;qh(78,1,{75:1});_.r=Sp;var Yd=Kh(78);qh(83,7,Cp);var ee=Kh(83);qh(126,83,Cp,Dh);var Zd=Kh(126);ed={3:1,76:1,29:1};var $d=Kh(76);qh(43,1,{3:1,43:1});var ie=Kh(43);fd={3:1,29:1,43:1};var ae=Kh(227);qh(31,1,{3:1,29:1,31:1});_.o=$p;_.q=Tp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=Kh(31);qh(82,7,Cp,Th);var de=Kh(82);qh(30,43,{3:1,29:1,30:1,43:1},Uh);_.o=function(a){return kd(a,30)&&a.a==this.a};_.q=Sp;_.r=function(){return ''+this.a};_.a=0;var fe=Kh(30);var Wh;qh(293,1,{});qh(84,57,Cp,Zh);_.A=function(a){return new TypeError(a)};var he=Kh(84);gd={3:1,75:1,29:1,2:1};var me=Kh(2);qh(79,78,{75:1},di);var le=Kh(79);qh(297,1,{});qh(73,1,{},ei);_.S=function(a){return a.e};var ne=Kh(73);qh(59,7,Cp,fi);var pe=Kh(59);qh(229,1,{41:1});_.Q=Xp;_.V=function(){return new xj(this,0)};_.W=function(){return new Lj(null,this.V())};_.T=function(a){throw bh(new fi('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new zj('[',']');for(b=this.R();b.Y();){a=b.Z();yj(c,a===this?'(this Collection)':a==null?Dp:uh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var qe=Kh(229);qh(232,1,{215:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!kd(a,38)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ti((new qi(d)).a);c.b;){b=si(c);if(!ii(this,b)){return false}}return true};_.q=function(){return Mi(new qi(this))};_.r=function(){var a,b,c;c=new zj('{','}');for(b=new ti((new qi(this)).a);b.b;){a=si(b);yj(c,ji(this,a._())+'='+ji(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Be=Kh(232);qh(103,232,{215:1});var te=Kh(103);qh(231,229,{41:1,239:1});_.V=function(){return new xj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!kd(a,22)){return false}b=a;if(oi(b.a)!=this.U()){return false}return gi(this,b)};_.q=function(){return Mi(this)};var Ce=Kh(231);qh(22,231,{22:1,41:1,239:1},qi);_.R=function(){return new ti(this.a)};_.U=Vp;var se=Kh(22);qh(23,1,{},ti);_.X=Up;_.Z=function(){return si(this)};_.Y=Wp;_.b=false;var re=Kh(23);qh(230,229,{41:1,236:1});_.V=function(){return new xj(this,16)};_.$=function(a,b){throw bh(new fi('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!kd(a,14)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Ji(f);for(c=new Ji(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(pd(b)===pd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Ni(this)};_.R=function(){return new ui(this)};var ve=Kh(230);qh(94,1,{},ui);_.X=Up;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Bi(this.b,this.a++)};_.a=0;var ue=Kh(94);qh(60,229,{41:1},vi);_.R=function(){var a;a=new ti((new qi(this.a)).a);return new wi(a)};_.U=Vp;var xe=Kh(60);qh(98,1,{},wi);_.X=Up;_.Y=function(){return this.a.b};_.Z=function(){var a;a=si(this.a);return a.ab()};var we=Kh(98);qh(96,1,Fp);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Oi(this.a,b._())&&Oi(this.b,b.ab())};_._=Sp;_.ab=Wp;_.q=function(){return nj(this.a)^nj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ye=Kh(96);qh(97,96,Fp,xi);var ze=Kh(97);qh(233,1,Fp);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Oi(this.b.value[0],b._())&&Oi(jj(this),b.ab())};_.q=function(){return nj(this.b.value[0])^nj(jj(this))};_.r=function(){return this.b.value[0]+'='+jj(this)};var Ae=Kh(233);qh(14,230,{3:1,14:1,41:1,236:1},Hi,Ii);_.$=function(a,b){_j(this.a,a,b)};_.T=function(a){return zi(this,a)};_.Q=function(a){Ai(this,a)};_.R=function(){return new Ji(this)};_.U=function(){return this.a.length};var Ee=Kh(14);qh(15,1,{},Ji);_.X=Up;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var De=Kh(15);qh(38,103,{3:1,38:1,215:1},Pi);var Fe=Kh(38);qh(64,1,{},Vi);_.Q=Xp;_.R=function(){return new Wi(this)};_.b=0;var He=Kh(64);qh(65,1,{},Wi);_.X=Up;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ge=Kh(65);var Zi;qh(62,1,{},hj);_.Q=Xp;_.R=function(){return new ij(this)};_.b=0;_.c=0;var Ke=Kh(62);qh(63,1,{},ij);_.X=Up;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new kj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Ie=Kh(63);qh(115,233,Fp,kj);_._=function(){return this.b.value[0]};_.ab=function(){return jj(this)};_.bb=function(a){return fj(this.a,this.b.value[0],a)};_.c=0;var Je=Kh(115);qh(117,1,{});_.X=Zp;_.cb=function(){return this.d};_.db=Yp;_.d=0;_.e=0;var Oe=Kh(117);qh(66,117,{});var Le=Kh(66);qh(99,1,{});_.X=Zp;_.cb=Wp;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Ne=Kh(99);qh(100,99,{},vj);_.X=function(a){sj(this,a)};_.eb=function(a){return tj(this,a)};var Me=Kh(100);qh(21,1,{},xj);_.cb=Sp;_.db=function(){wj(this);return this.c};_.X=function(a){wj(this);this.d.X(a)};_.eb=function(a){wj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Pe=Kh(21);qh(58,1,{},zj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Qe=Kh(58);qh(35,1,{},Aj);_.S=function(a){return a};var Re=Kh(35);qh(39,1,{},Bj);var Se=Kh(39);qh(116,1,{});_.c=false;var af=Kh(116);qh(27,116,{258:1},Lj);var _e=Kh(27);qh(74,1,{},Oj);_.fb=function(a){return $c(je,tp,1,a,5,1)};var Te=Kh(74);qh(119,66,{},Qj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Rj(this,a)));return this.b};_.b=false;var Ve=Kh(119);qh(122,1,{},Rj);_.w=function(a){Pj(this.a,this.b,a)};var Ue=Kh(122);qh(118,66,{},Tj);_.eb=function(a){return this.b.eb(new Uj(this,a))};var Xe=Kh(118);qh(121,1,{},Uj);_.w=function(a){Sj(this.a,this.b,a)};var We=Kh(121);qh(120,1,{},Wj);_.w=function(a){Vj(this,a)};var Ye=Kh(120);qh(123,1,{},Xj);_.w=function(a){};var Ze=Kh(123);qh(124,1,{},Zj);_.w=function(a){Yj(this,a)};var $e=Kh(124);qh(295,1,{});qh(292,1,{});var dk=0;var fk,gk=0,hk;qh(908,1,{});qh(929,1,{});qh(234,1,{});var bf=Kh(234);qh(161,1,{},vk);_.fb=function(a){return new Array(a)};var cf=Kh(161);qh(260,$wnd.Function,{},wk);_.hb=function(a){uk(this.a,this.b,a)};qh(6,31,{3:1,29:1,31:1,6:1},fl);var Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl;var df=Lh(6,gl);var hl;qh(259,$wnd.Function,{},jl);_.J=function(a){return Eb(hl),hl=null,null};qh(187,234,{});var Of=Kh(187);qh(188,187,{});_.d=0;var Sf=Kh(188);qh(189,188,up,rl);_.t=_p;_.o=$p;_.q=Tp;_.u=aq;_.r=function(){var a;return Gh(nf),nf.k+'@'+(a=ek(this)>>>0,a.toString(16))};var nl=0;var nf=Kh(189);qh(190,1,xp,sl);_.v=function(){ol(this.a)};var ef=Kh(190);qh(191,1,sp,tl);_.s=function(){return pl(this.a)};var ff=Kh(191);qh(192,1,Ap,ul);_.v=function(){ll(this.a)};var gf=Kh(192);qh(193,1,sp,vl);_.s=function(){return ml(this.a)};var hf=Kh(193);qh(208,234,{});var Nf=Kh(208);qh(209,208,{});_.c=0;var Rf=Kh(209);qh(210,209,up,Bl);_.t=bq;_.o=$p;_.q=Tp;_.u=cq;_.r=function(){var a;return Gh(mf),mf.k+'@'+(a=ek(this)>>>0,a.toString(16))};var zl=0;var mf=Kh(210);qh(211,1,xp,Cl);_.v=dq;var jf=Kh(211);qh(212,1,Ap,Dl);_.v=function(){xl(this.a)};var kf=Kh(212);qh(213,1,sp,El);_.s=function(){return yl(this.a)};var lf=Kh(213);qh(179,234,{});_.f='';var _f=Kh(179);qh(180,179,{});_.d=0;var Uf=Kh(180);qh(181,180,up,Ql);_.t=_p;_.o=$p;_.q=Tp;_.u=aq;_.r=function(){var a;return Gh(tf),tf.k+'@'+(a=ek(this)>>>0,a.toString(16))};var Kl=0;var tf=Kh(181);qh(182,1,xp,Rl);_.v=function(){Ll(this.a)};var of=Kh(182);qh(184,1,sp,Sl);_.s=function(){return Jl(this.a)};var pf=Kh(184);qh(185,1,xp,Tl);_.v=function(){Fl(this.a)};var qf=Kh(185);qh(186,1,xp,Ul);_.v=function(){Nl(this.a,this.b)};var rf=Kh(186);qh(183,1,Ap,Vl);_.v=function(){ll(this.a)};var sf=Kh(183);qh(175,234,{});_.i=false;var cg=Kh(175);qh(195,175,{});_.f=0;var Wf=Kh(195);qh(196,195,up,pm);_.t=function(){ic(this.e)};_.o=$p;_.q=Tp;_.u=function(){return this.e.i<0};_.r=function(){var a;return Gh(Ef),Ef.k+'@'+(a=ek(this)>>>0,a.toString(16))};var dm=0;var Ef=Kh(196);qh(197,1,xp,qm);_.v=function(){em(this.a)};var uf=Kh(197);qh(200,1,sp,rm);_.s=function(){return cm(this.a)};var vf=Kh(200);qh(49,1,xp,sm);_.v=function(){om(this.a,On(this.b))};var wf=Kh(49);qh(69,1,xp,tm);_.v=function(){$l(this.a,this.b)};var xf=Kh(69);qh(201,1,xp,um);_.v=function(){gm(this.a,this.b)};var yf=Kh(201);qh(202,1,xp,vm);_.v=function(){hm(this.a,this.b)};var zf=Kh(202);qh(198,1,sp,wm);_.s=function(){return im(this.a)};var Af=Kh(198);qh(203,1,xp,xm);_.v=function(){Wl(this.a,this.b)};var Bf=Kh(203);qh(204,1,xp,ym);_.v=function(){_l(this.a)};var Cf=Kh(204);qh(199,1,Ap,zm);_.v=function(){bm(this.a)};var Df=Kh(199);qh(137,234,{});var gg=Kh(137);qh(138,137,{});_.c=0;var Yf=Kh(138);qh(139,138,up,Gm);_.t=bq;_.o=$p;_.q=Tp;_.u=cq;_.r=function(){var a;return Gh(If),If.k+'@'+(a=ek(this)>>>0,a.toString(16))};var Em=0;var If=Kh(139);qh(140,1,xp,Hm);_.v=dq;var Ff=Kh(140);qh(141,1,Ap,Im);_.v=function(){xl(this.a)};var Gf=Kh(141);qh(142,1,sp,Jm);_.s=function(){return Dm(this.a)};var Hf=Kh(142);qh(264,$wnd.Function,{},Km);_.lb=function(a){Fo(this.a.f)};qh(163,1,{},Lm);var Jf=Kh(163);qh(89,1,{},Mm);var Kf=Kh(89);var Nm;qh(194,1,{},Om);var Lf=Kh(194);qh(93,1,{},Pm);var Mf=Kh(93);var Qm;qh(265,$wnd.Function,{},Rm);_.mb=function(a){return new Um(a)};var Sm;qh(177,$wnd.React.Component,{},Um);ph(nh[1],_);_.componentWillUnmount=function(){kl(this.a)};_.render=function(){return ql(this.a)};_.shouldComponentUpdate=eq;var Pf=Kh(177);qh(276,$wnd.Function,{},Vm);_.mb=function(a){return new Ym(a)};var Wm;qh(205,$wnd.React.Component,{},Ym);ph(nh[1],_);_.componentWillUnmount=function(){wl(this.a)};_.render=function(){return Al(this.a)};_.shouldComponentUpdate=fq;var Qf=Kh(205);qh(263,$wnd.Function,{},Zm);_.mb=function(a){return new an(a)};var $m;qh(176,$wnd.React.Component,{},an);ph(nh[1],_);_.componentWillUnmount=function(){kl(this.a)};_.render=function(){return Ol(this.a)};_.shouldComponentUpdate=eq;var Tf=Kh(176);qh(266,$wnd.Function,{},bn);_.mb=function(a){return new en(a)};var cn;qh(178,$wnd.React.Component,{},en);ph(nh[1],_);_.componentDidUpdate=function(a){lm(this.a)};_.componentWillUnmount=function(){am(this.a)};_.render=function(){return mm(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Vf=Kh(178);qh(257,$wnd.Function,{},fn);_.mb=function(a){return new jn(a)};var gn;qh(101,$wnd.React.Component,{},jn);ph(nh[1],_);_.componentWillUnmount=function(){wl(this.a)};_.render=function(){return Fm(this.a)};_.shouldComponentUpdate=fq;var Xf=Kh(101);qh(261,$wnd.Function,{},kn);_.kb=function(a){Gl(this.a,a)};qh(262,$wnd.Function,{},ln);_.jb=function(a){Ml(this.a,a)};qh(162,1,{},mn);var Zf=Kh(162);qh(92,1,{},nn);var $f=Kh(92);var on;qh(273,$wnd.Function,{},pn);_.jb=function(a){fm(this.a,a)};qh(267,$wnd.Function,{},qn);_.jb=function(a){io(this.a)};qh(269,$wnd.Function,{},rn);_.lb=function(a){jm(this.a,this.b)};qh(270,$wnd.Function,{},sn);_.lb=function(a){Xl(this.a,this.b)};qh(271,$wnd.Function,{},tn);_.w=function(a){Yl(this.a,a)};qh(272,$wnd.Function,{},un);_.ib=function(a){km(this.a,this.b)};qh(274,$wnd.Function,{},vn);_.kb=function(a){Zl(this.a,this.b,a)};qh(174,1,{},xn);var ag=Kh(174);qh(90,1,{},yn);var bg=Kh(90);var zn;qh(256,$wnd.Function,{},An);_.jb=function(a){Am(this.a,a)};qh(102,1,{},Bn);_.S=function(a){return wn(new xn,a)};var dg=Kh(102);qh(72,1,{},Cn);var eg=Kh(72);qh(91,1,{},Dn);var fg=Kh(91);var En;qh(88,1,{},Fn);var hg=Kh(88);qh(165,1,{});var Ng=Kh(165);qh(166,165,up,Sn);_.t=_p;_.o=$p;_.q=Tp;_.u=aq;_.r=function(){var a;return Gh(pg),pg.k+'@'+(a=ek(this)>>>0,a.toString(16))};var pg=Kh(166);qh(167,1,xp,Tn);_.v=function(){Mn(this.a)};var ig=Kh(167);qh(169,1,Ap,Un);_.v=function(){Hn(this.a)};var jg=Kh(169);qh(170,1,Ap,Vn);_.v=function(){In(this.a)};var kg=Kh(170);qh(171,1,xp,Wn);_.v=function(){Gn(this.a,this.b)};var lg=Kh(171);qh(172,1,xp,Xn);_.v=function(){Pn(this.a)};var mg=Kh(172);qh(67,1,xp,Yn);_.v=function(){Ln(this.a)};var ng=Kh(67);qh(168,1,sp,Zn);_.s=function(){var a;return a=(Ah(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var og=Kh(168);qh(50,1,{50:1});_.d=false;var Xg=Kh(50);qh(51,50,{9:1,275:1,51:1,50:1},jo);_.t=_p;_.o=function(a){return bo(this,a)};_.q=function(){return this.c.d};_.u=aq;_.r=function(){var a;return Gh(Fg),Fg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var $n=0;var Fg=Kh(51);qh(206,1,xp,ko);_.v=function(){_n(this.a)};var qg=Kh(206);qh(207,1,xp,lo);_.v=function(){fo(this.a)};var rg=Kh(207);qh(48,143,{48:1});var Rg=Kh(48);qh(144,48,{9:1,48:1},uo);_.t=gq;_.o=$p;_.q=Tp;_.u=hq;_.r=function(){var a;return Gh(Ag),Ag.k+'@'+(a=ek(this)>>>0,a.toString(16))};var Ag=Kh(144);qh(146,1,xp,vo);_.v=function(){no(this.a)};var sg=Kh(146);qh(145,1,xp,wo);_.v=function(){ro(this.a)};var tg=Kh(145);qh(151,1,xp,xo);_.v=function(){cc(this.a,this.b,true)};var ug=Kh(151);qh(152,1,sp,yo);_.s=function(){return mo(this.a,this.c,this.b)};_.b=false;var vg=Kh(152);qh(147,1,sp,zo);_.s=function(){return so(this.a)};var wg=Kh(147);qh(148,1,sp,Ao);_.s=function(){return Vh(hh(Gj(qo(this.a))))};var xg=Kh(148);qh(149,1,sp,Bo);_.s=function(){return Vh(hh(Gj(Hj(qo(this.a),new ip))))};var yg=Kh(149);qh(150,1,sp,Co);_.s=function(){return to(this.a)};var zg=Kh(150);qh(46,1,{46:1});var Wg=Kh(46);qh(127,46,{9:1,46:1},Jo);_.t=function(){ic(this.a)};_.o=$p;_.q=Tp;_.u=function(){return this.a.i<0};_.r=function(){var a;return Gh(Eg),Eg.k+'@'+(a=ek(this)>>>0,a.toString(16))};var Eg=Kh(127);qh(128,1,xp,Ko);_.v=function(){Go(this.a,this.b)};_.b=false;var Bg=Kh(128);qh(129,1,xp,Lo);_.v=function(){Rn(this.b,this.a)};var Cg=Kh(129);qh(130,1,xp,Mo);_.v=function(){Ho(this.a)};var Dg=Kh(130);qh(47,1,{47:1});var $g=Kh(47);qh(131,47,{9:1,47:1},Uo);_.t=gq;_.o=$p;_.q=Tp;_.u=hq;_.r=function(){var a;return Gh(Lg),Lg.k+'@'+(a=ek(this)>>>0,a.toString(16))};var Lg=Kh(131);qh(132,1,xp,Vo);_.v=function(){Po(this.a)};var Gg=Kh(132);qh(136,1,xp,Wo);_.v=function(){To(this.a,null)};var Hg=Kh(136);qh(133,1,sp,Xo);_.s=function(){var a;return a=On(this.a.g),o(Qp,a)?(cp(),_o):o(Rp,a)?(cp(),bp):(cp(),ap)};var Ig=Kh(133);qh(134,1,sp,Yo);_.s=function(){return Ro(this.a)};var Jg=Kh(134);qh(135,1,Ap,Zo);_.v=function(){So(this.a)};var Kg=Kh(135);qh(164,1,{},$o);_.handleEvent=function(a){Jn(this.a,a)};var Mg=Kh(164);qh(32,31,{3:1,29:1,31:1,32:1},dp);var _o,ap,bp;var Og=Lh(32,ep);qh(105,1,{71:1},fp);_.I=function(){return new uo};var Pg=Kh(105);var gp;qh(110,1,{},ip);_.gb=function(a){return !eo(a)};var Qg=Kh(110);qh(112,1,{},jp);_.gb=function(a){return eo(a)};var Sg=Kh(112);qh(113,1,{},kp);_.w=function(a){po(this.a,a)};var Tg=Kh(113);qh(111,1,{},lp);_.w=function(a){Eo(this.a,a)};_.a=false;var Ug=Kh(111);qh(106,1,{71:1},mp);_.I=function(){return new Jo(this.a.I())};var Vg=Kh(106);qh(114,1,{},np);_.gb=function(a){return Oo(this.a,a)};var Yg=Kh(114);qh(107,1,{71:1},op);_.I=function(){return new Uo(this.a.I())};var Zg=Kh(107);var rd=Mh('D');var pp=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=lh;jh(wh);mh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();