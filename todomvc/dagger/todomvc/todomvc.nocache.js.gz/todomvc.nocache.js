function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='0BF7AF93FB11FB18D92896F58832625E',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '0BF7AF93FB11FB18D92896F58832625E';function o(){}
function qh(){}
function mh(){}
function Eb(){}
function Oc(){}
function Vc(){}
function Vn(){}
function Cj(){}
function Dj(){}
function Rk(){}
function Hm(){}
function Lm(){}
function Pm(){}
function Tm(){}
function Xm(){}
function Co(){}
function hp(){}
function ip(){}
function Tc(a){Sc()}
function Dm(a){Cm=a}
function Gm(a){Fm=a}
function dn(a){cn=a}
function pn(a){on=a}
function tn(a){sn=a}
function yh(){yh=mh}
function Ai(){ri(this)}
function F(a){this.a=a}
function G(a){this.a=a}
function W(a){this.a=a}
function ib(a){this.a=a}
function wb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function ec(a){this.a=a}
function nc(a){this.a=a}
function Oh(a){this.a=a}
function Zh(a){this.a=a}
function ji(a){this.a=a}
function oi(a){this.a=a}
function pi(a){this.a=a}
function ni(a){this.b=a}
function Ci(a){this.c=a}
function Aj(a){this.a=a}
function Fj(a){this.a=a}
function $k(a){this.a=a}
function bl(a){this.a=a}
function cl(a){this.a=a}
function dl(a){this.a=a}
function kl(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function Bl(a){this.a=a}
function El(a){this.a=a}
function Fl(a){this.a=a}
function Hl(a){this.a=a}
function cm(a){this.a=a}
function fm(a){this.a=a}
function hm(a){this.a=a}
function mm(a){this.a=a}
function nm(a){this.a=a}
function vm(a){this.a=a}
function ym(a){this.a=a}
function zm(a){this.a=a}
function Am(a){this.a=a}
function _m(a){this.a=a}
function an(a){this.a=a}
function en(a){this.a=a}
function fn(a){this.a=a}
function jn(a){this.a=a}
function qn(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function yn(a){this.a=a}
function An(a){this.a=a}
function Cn(a){this.a=a}
function Qn(a){this.a=a}
function Rn(a){this.a=a}
function Sn(a){this.a=a}
function Tn(a){this.a=a}
function Un(a){this.a=a}
function ho(a){this.a=a}
function io(a){this.a=a}
function so(a){this.a=a}
function to(a){this.a=a}
function wo(a){this.a=a}
function xo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Wo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function jp(a){this.a=a}
function kp(a){this.a=a}
function lp(a){this.a=a}
function Xp(){hc(this.c)}
function Zp(){hc(this.b)}
function cq(){hc(this.f)}
function Mi(){this.a=Vi()}
function $i(){this.a=Vi()}
function ic(a){!!a&&a.v()}
function X(a){!!a&&Z(a)}
function v(a){--a.e;C(a)}
function Tp(a){cj(this,a)}
function Wp(a){Sh(this,a)}
function cb(a){Xb((I(),a))}
function db(a){Yb((I(),a))}
function gb(a){Zb((I(),a))}
function Eo(a,b){am(b,a)}
function Wj(a,b){Vj(a,b)}
function Ej(a,b){vj(a.a,b)}
function lc(a,b){fi(a.e,b)}
function Jl(a,b){mo(a.j,b)}
function Do(a,b){lo(a.b,b)}
function B(a,b){Nb(a.f,b.f)}
function Bj(a,b){a.a=b}
function Xj(a,b){a.key=b}
function pb(a,b){a.b=fj(b)}
function ml(a){this.a=fj(a)}
function Dl(a){this.a=fj(a)}
function _p(){jb(this.a.a)}
function Qp(){return this.a}
function Vp(){return this.b}
function Yg(a){return a.e}
function Hb(a){a.a=-4&a.a|1}
function Sk(a){a.d=2;hc(a.c)}
function el(a){a.c=2;hc(a.b)}
function Ql(a){a.f=2;hc(a.e)}
function Jn(a){Q(a.a);Z(a.b)}
function Yn(a){Z(a.b);Z(a.a)}
function Wk(a){jb(a.b);Q(a.a)}
function vl(a){jb(a.a);Z(a.b)}
function $(a){I();Yb(a);a.e=-2}
function I(){I=mh;H=new D}
function uc(){uc=mh;tc=new o}
function Lc(){Lc=mh;Kc=new Oc}
function Bo(){Bo=mh;Ao=new Co}
function Ri(){Ri=mh;Qi=Ti()}
function Sp(){return Nj(this)}
function Rp(a){return this===a}
function Vh(a,b){return a===b}
function Kl(a,b){return a.g=b}
function ui(a,b){return a.a[b]}
function Wc(a,b){return Hh(a,b)}
function Jj(a,b){a.splice(b,1)}
function gc(a,b,c){ei(a.e,b,c)}
function Zn(a,b,c){gc(a.c,b,c)}
function $h(a){sc.call(this,a)}
function Th(){oc(this);this.C()}
function Up(){return hi(this.a)}
function Yp(){return this.c.i<0}
function $p(){return this.b.i<0}
function dq(){return this.f.i<0}
function Vi(){Ri();return new Qi}
function Bh(a){Ah(a);return a.k}
function uj(a,b){a.P(b);return a}
function S(a){lb(a.f);return U(a)}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function J(a,b){N(a);K(a,fj(b))}
function vj(a,b){Bj(a,uj(a.a,b))}
function gj(a,b){while(a.ab(b));}
function u(a,b,c){s(a,new G(c),b)}
function Bc(){Bc=mh;!!(Sc(),Rc)}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function fh(){dh==null&&(dh=[])}
function hi(a){return a.a.b+a.b.b}
function aq(a){return 1==this.a.d}
function bq(a){return 1==this.a.c}
function _c(a){return new Array(a)}
function Xi(a,b){return a.a.get(b)}
function qi(a,b){this.a=a;this.b=b}
function fc(a,b){this.a=a;this.b=b}
function Mh(a,b){this.a=a;this.b=b}
function yj(a,b){this.a=a;this.b=b}
function ck(a,b){this.a=a;this.b=b}
function Gl(a,b){this.a=a;this.b=b}
function gm(a,b){this.a=a;this.b=b}
function im(a,b){this.a=a;this.b=b}
function jm(a,b){this.a=a;this.b=b}
function km(a,b){this.a=a;this.b=b}
function lm(a,b){this.a=a;this.b=b}
function Nk(a,b){Mh.call(this,a,b)}
function gn(a,b){this.a=a;this.b=b}
function hn(a,b){this.a=a;this.b=b}
function kn(a,b){this.a=a;this.b=b}
function ln(a,b){this.a=a;this.b=b}
function ek(a,b){a.ref=b;return a}
function fk(a,b){a.href=b;return a}
function Ln(a){eb(a.b);return a.e}
function Ro(a){eb(a.d);return a.e}
function ao(a){eb(a.a);return a.d}
function Mn(a){Kn(a,(eb(a.b),a.e))}
function bn(){this.a=Yj((Rm(),Qm))}
function nn(){this.a=Yj((Vm(),Um))}
function rn(){this.a=Yj((Zm(),Ym))}
function Bm(){this.a=Yj((Jm(),Im))}
function Em(){this.a=Yj((Nm(),Mm))}
function Wn(a,b){this.a=a;this.b=b}
function uo(a,b){this.a=a;this.b=b}
function Ko(a,b){this.a=a;this.b=b}
function Lo(a,b){this.b=a;this.a=b}
function fp(a,b){Mh.call(this,a,b)}
function Hj(a,b,c){a.splice(b,0,c)}
function ok(a,b){a.value=b;return a}
function Xh(a,b){a.a+=''+b;return a}
function jk(a,b){a.onBlur=b;return a}
function Ic(a){$wnd.clearTimeout(a)}
function di(a){return !a?null:a.Y()}
function Tb(a){return !a.d?a:Tb(a.d)}
function ej(a){return a!=null?r(a):0}
function od(a){return a==null?null:a}
function ld(a){return typeof a===op}
function bo(a){am(a,(eb(a.a),!a.d))}
function Ul(a){jb(a.b);Q(a.c);Z(a.a)}
function ob(a){I();nb(a);rb(a,2,true)}
function ri(a){a.a=Yc(he,qp,1,0,5,1)}
function gi(a){a.a=new Mi;a.b=new $i}
function hb(a){this.c=new Ai;this.b=a}
function Cb(a){this.d=fj(a);this.b=100}
function O(){this.a=Yc(he,qp,1,100,5,1)}
function A(a,b,c){return t(a,c,2048,b)}
function w(a,b,c){t(a,new F(b),c,null)}
function Ij(a,b){Gj(b,0,a,0,b.length)}
function dc(a,b){bc(a,b,false);db(a.d)}
function Vj(a,b){for(var c in a){b(c)}}
function bd(a,b,c){return {l:a,m:b,h:c}}
function Uh(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function Y(a){return !(!!a&&1==(a.c&7))}
function Nj(a){return a.$H||(a.$H=++Mj)}
function nd(a){return typeof a==='string'}
function lk(a,b){a.onKeyDown=b;return a}
function gk(a,b){a.onClick=b;return a}
function kk(a,b){a.onChange=b;return a}
function ik(a,b){a.checked=b;return a}
function hk(a){a.autoFocus=true;return a}
function Ah(a){if(a.k!=null){return}Jh(a)}
function sh(a){this.b=fj(a);this.a=this}
function sc(a){this.f=a;oc(this);this.C()}
function tj(a,b){oj.call(this,a);this.a=b}
function cc(a,b){lc(b.c,a);jd(b,9)&&b.t()}
function ll(a,b){return new jl(fj(b),a.a)}
function Cl(a,b){return new Al(fj(b),a.a)}
function kd(a){return typeof a==='boolean'}
function eb(a){var b;Ub((I(),b=Pb,b),a)}
function pc(a,b){a.e=b;b!=null&&Lj(b,zp,a)}
function cj(a,b){while(a.U()){Ej(b,a.V())}}
function Fb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function T(a){4==(a.f.c&7)&&rb(a.f,5,true)}
function Zl(a){w((I(),I(),H),new nm(a),Jp)}
function Nn(a){w((I(),I(),H),new Tn(a),Jp)}
function fo(a){w((I(),I(),H),new io(a),Jp)}
function Fo(a){w((I(),I(),H),new Mo(a),Jp)}
function Qo(a){jb(a.a);Q(a.b);Q(a.c);Z(a.d)}
function qo(a){return Ph(R(a.e).a-R(a.a).a)}
function Cc(a,b,c){return a.apply(b,c);var d}
function Lj(b,c,d){try{b[c]=d}catch(a){}}
function Oi(a,b){var c;c=a[Ep];c.call(a,b)}
function Eh(a){var b;b=Dh(a);Lh(a,b);return b}
function oc(a){a.g&&a.e!==yp&&a.C();return a}
function pk(a,b){a.onDoubleClick=b;return a}
function bj(a,b,c){this.a=a;this.b=b;this.c=c}
function Gi(){this.a=new Mi;this.b=new $i}
function Rj(){Rj=mh;Oj=new o;Qj=new o}
function vh(){vh=mh;uh=$wnd.window.document}
function Rh(){Rh=mh;Qh=Yc(de,qp,32,256,0,1)}
function Sc(){Sc=mh;var a;!Uc();a=new Vc;Rc=a}
function Mb(a,b,c){Hb(fj(c));J(a.a[b],fj(c))}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function wl(a,b){w((I(),I(),H),new Gl(a,b),Jp)}
function Vl(a,b){w((I(),I(),H),new lm(a,b),Jp)}
function Xl(a,b){w((I(),I(),H),new jm(a,b),Jp)}
function Yl(a,b){w((I(),I(),H),new im(a,b),Jp)}
function _l(a,b){w((I(),I(),H),new gm(a,b),Jp)}
function mo(a,b){w((I(),I(),H),new uo(a,b),Jp)}
function Io(a,b){w((I(),I(),H),new Ko(a,b),Jp)}
function xl(a,b){var c;c=b.target;zl(a,c.value)}
function mb(a,b){bb(b,a);b.c.a.length>0||(b.a=4)}
function si(a,b){a.a[a.a.length]=b;return true}
function vo(a,b){this.a=a;this.c=b;this.b=false}
function D(){this.f=new Ob;this.a=new Cb(this.f)}
function oo(a){Sh(new oi(a.g),new ec(a));gi(a.g)}
function Bb(a){while(true){if(!Ab(a)){break}}}
function Db(a){if(!a.a){a.a=true;v((I(),I(),H))}}
function ij(a){if(!a.d){a.d=a.b.O();a.c=a.b.Q()}}
function wj(a,b,c){if(a.a.bb(c)){a.b=true;b.w(c)}}
function wh(a,b,c,d){a.addEventListener(b,c,d)}
function xh(a,b,c,d){a.removeEventListener(b,c,d)}
function th(a){fj(a);return jd(a,44)?a:new sh(a)}
function rj(a){nj(a);return new tj(a,new zj(a.a))}
function _k(a,b){return new Zk(fj(b),a.a,a.b,a.c)}
function dm(a,b){return new bm(fj(b),a.a,a.b,a.c)}
function wm(a,b){return new um(fj(b),a.a,a.b,a.c)}
function Wi(a,b){return !(a.a.get(b)===undefined)}
function po(a){return yh(),0==R(a.e).a?true:false}
function Xk(a){return yh(),R(a.e.b).a>0?true:false}
function Yk(a){return A((I(),I(),H),a.b,new dl(a))}
function $c(a){return Array.isArray(a)&&a.kb===qh}
function hd(a){return !Array.isArray(a)&&a.kb===qh}
function il(a){return A((I(),I(),H),a.a,new ol(a))}
function yl(a){return A((I(),I(),H),a.a,new El(a))}
function $l(a){return A((I(),I(),H),a.b,new fm(a))}
function tm(a){return A((I(),I(),H),a.a,new zm(a))}
function Oo(a){return Vh(Op,a)||Vh(Pp,a)||Vh('',a)}
function M(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function wi(a,b){var c;c=a.a[b];Jj(a.a,b);return c}
function yi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function li(a){var b;b=a.a.V();a.b=ki(a);return b}
function Gh(a){var b;b=Dh(a);b.j=a;b.e=1;return b}
function om(a,b){var c;c=b.target;Io(a.e,c.checked)}
function ko(a){Q(a.c);Q(a.e);Q(a.a);Q(a.b);Z(a.d)}
function mj(a){if(!a.b){nj(a);a.c=true}else{mj(a.b)}}
function Tk(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function fl(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function Rl(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Uj(){if(Pj==256){Oj=Qj;Qj=new o;Pj=0}++Pj}
function fj(a){if(a==null){throw Yg(new Th)}return a}
function ii(a,b){if(b){return bi(a.a,b)}return false}
function qj(a,b){nj(a);return new tj(a,new xj(b,a.a))}
function Kn(a,b){w((I(),I(),H),new Wn(a,b),75497472)}
function zl(a,b){var c;c=a.f;if(b!=c){a.f=b;db(a.b)}}
function am(a,b){var c;c=a.d;if(b!=c){a.d=b;db(a.a)}}
function On(a,b){var c;c=a.e;if(b!=c){a.e=fj(b);db(a.b)}}
function Fh(a,b){var c;c=Dh(a);Lh(a,c);c.e=b?8:0;return c}
function nk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function hj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function jj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function al(a,b,c){this.a=fj(a);this.b=fj(b);this.c=fj(c)}
function em(a,b,c){this.a=fj(a);this.b=fj(b);this.c=fj(c)}
function xm(a,b,c){this.a=fj(a);this.b=fj(b);this.c=fj(c)}
function $b(a,b){this.a=(I(),I(),H).b++;this.d=a;this.e=b}
function zj(a){hj.call(this,a._(),a.$()&-6);this.a=a}
function oj(a){if(!a){this.b=null;new Ai}else{this.b=a}}
function bh(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function fb(a){var b;I();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function In(a){var b;T(a.a);b=R(a.a);Vh(a.f,b)&&On(a,b)}
function Fi(a,b){return od(a)===od(b)||a!=null&&p(a,b)}
function lo(a,b){return t((I(),I(),H),new vo(a,b),Jp,null)}
function Nl(a,b){Uo(a.k,b);w((I(),I(),H),new gm(a,b),Jp)}
function Il(a,b){var c;if(R(a.c)){c=b.target;am(a,c.value)}}
function qc(a,b){var c;c=Bh(a.ib);return b==null?c:c+': '+b}
function ci(a,b){return b===a?'(this Map)':b==null?Bp:ph(b)}
function vn(a){return new al(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function zn(a){return new em(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function Bn(a){return new xm(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function Sh(a,b){var c,d;for(d=a.O();d.U();){c=d.V();b.w(c)}}
function Qb(a){if(a.e){2==(a.e.c&7)||rb(a.e,4,true);nb(a.e)}}
function Ih(a){if(a.M()){return null}var b=a.j;return ih[b]}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function kb(a){B((I(),I(),H),a);0==(a.f.a&vp)&&C((null,H))}
function Ml(a,b){w((I(),I(),H),new gm(a,b),Jp);Uo(a.k,null)}
function En(a){wh((vh(),$wnd.window.window),Mp,a.d,false)}
function Fn(a){xh((vh(),$wnd.window.window),Mp,a.d,false)}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function nj(a){if(a.b){nj(a.b)}else if(a.c){throw Yg(new Nh)}}
function Go(a,b){var c;sj(no(a.b),(c=new Ai,c)).N(new kp(b))}
function Hh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function Ii(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function kh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function gp(){ep();return ad(Wc(Mg,1),qp,34,0,[bp,dp,cp])}
function Bi(a){ri(this);Ij(this.a,ai(a,Yc(he,qp,1,hi(a.a),5,1)))}
function Ji(a,b){var c;return Hi(b,Ii(a,b==null?0:(c=r(b),c|0)))}
function no(a){eb(a.d);return new tj(null,new jj(new oi(a.g),0))}
function Gn(a,b){b.preventDefault();w((I(),I(),H),new Un(a),Jp)}
function mk(a){a.placeholder='What needs to be done?';return a}
function oh(a){function b(){}
;b.prototype=a||{};return new b}
function rc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function kc(a){ic(a.g);!!a.e&&jc(a);X(a.a);X(a.c);ic(a.b);ic(a.f)}
function Jm(){Jm=mh;var a;Im=(a=nh(Hm.prototype.hb,Hm,[]),a)}
function Nm(){Nm=mh;var a;Mm=(a=nh(Lm.prototype.hb,Lm,[]),a)}
function Rm(){Rm=mh;var a;Qm=(a=nh(Pm.prototype.hb,Pm,[]),a)}
function Vm(){Vm=mh;var a;Um=(a=nh(Tm.prototype.hb,Tm,[]),a)}
function Zm(){Zm=mh;var a;Ym=(a=nh(Xm.prototype.hb,Xm,[]),a)}
function Wl(a){return yh(),Ro(a.k)==a.n.props['a']?true:false}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ni(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Km(a){$wnd.React.Component.call(this,a);this.a=_k(Cm,this)}
function Om(a){$wnd.React.Component.call(this,a);this.a=ll(Fm,this)}
function Sm(a){$wnd.React.Component.call(this,a);this.a=Cl(cn,this)}
function Wm(a){$wnd.React.Component.call(this,a);this.a=dm(on,this)}
function $m(a){$wnd.React.Component.call(this,a);this.a=wm(sn,this)}
function _i(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function xj(a,b){hj.call(this,b._(),b.$()&-16449);this.a=a;this.c=b}
function kj(a,b){!a.a?(a.a=new Zh(a.d)):Xh(a.a,a.b);Xh(a.a,b);return a}
function sj(a,b){var c;mj(a);c=new Cj;c.a=b;a.a.T(new Fj(c));return c.a}
function pj(a){var b;mj(a);b=0;while(a.a.ab(new Dj)){b=Zg(b,1)}return b}
function Ho(a){var b;sj(qj(no(a.b),new ip),(b=new Ai,b)).N(new jp(a.b))}
function Ib(b){try{b.b.v()}catch(a){a=Xg(a);if(!jd(a,5))throw Yg(a)}}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function ab(a,b){var c,d;si(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function fi(a,b){return nd(b)?b==null?Li(a.a,null):Zi(a.b,b):Li(a.a,b)}
function Po(a,b){return (ep(),cp)==a||(bp==a?(eb(b.a),!b.d):(eb(b.a),b.d))}
function K(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=M(a.a[c])}return b}
function ti(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function pl(a){var b;b=Wh((eb(a.b),a.f));if(b.length>0){Do(a.e,b);zl(a,'')}}
function So(a){var b,c;return b=R(a.b),sj(qj(no(a.i),new lp(b)),(c=new Ai,c))}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function Jo(a){this.b=fj(a);I();this.a=new mc(0,null,null,false,false)}
function lj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function mi(a){this.d=a;this.c=new _i(this.d.b);this.a=this.c;this.b=ki(this)}
function Ob(){var a;this.a=Yc(ud,qp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new O}}
function $n(a,b){var c;if(jd(b,49)){c=b;return a.c.d==c.c.d}else{return false}}
function xi(a,b){var c;c=vi(a,b,0);if(c==-1){return false}Jj(a.a,c);return true}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&ad(Wc(a,f),b,c,e,g);return g}
function bk(a,b,c){!Vh(c,'key')&&!Vh(c,'ref')&&(a[c]=b[c],undefined)}
function vi(a,b,c){for(;c<a.a.length;++c){if(Fi(b,a.a[c])){return c}}return -1}
function aj(a){if(a.a.c!=a.c){return Xi(a.a,a.b.value[0])}return a.b.value[1]}
function C(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Bb(a.a)}finally{a.c=false}}}}
function Z(a){if(-2!=a.e){t((I(),I(),H),new F(new ib(a)),0,null);!!a.b&&jb(a.b)}}
function hc(a){if(a.i>=0){a.i=-2;t((I(),I(),H),new F(new nc(a)),67108864,null)}}
function Q(a){if(!a.a){a.a=true;a.n=null;a.b=null;Z(a.e);2==(a.f.c&7)||jb(a.f)}}
function U(a){if(a.b){if(jd(a.b,8)){throw Yg(a.b)}else{throw Yg(a.b)}}return a.n}
function qb(b){if(b){try{b.v()}catch(a){a=Xg(a);if(jd(a,5)){I()}else throw Yg(a)}}}
function Dn(a,b){a.f=b;Vh(b,R(a.a))&&On(a,b);Hn(b);w((I(),I(),H),new Un(a),Jp)}
function ql(a,b){if(13==b.keyCode){b.preventDefault();w((I(),I(),H),new Fl(a),Jp)}}
function ac(){var a;try{Rb(Pb);I()}finally{a=Pb.d;!a&&((I(),I(),H).d=true);Pb=Pb.d}}
function Mc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Qc(b,c)}while(a.a);a.a=c}}
function Nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Qc(b,c)}while(a.b);a.b=c}}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ai);si(a.b,b)}}}
function Lh(a,b){var c;if(!a){return}b.j=a;var d=Ih(b);if(!d){ih[a]=[b];return}d.ib=b}
function Dh(a){var b;b=new Ch;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function nh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ei(a,b,c){return nd(b)?b==null?Ki(a.a,null,c):Yi(a.b,b,c):Ki(a.a,b,c)}
function Kj(a,b){return Xc(b)!=10&&ad(q(b),b.jb,b.__elementTypeId$,Xc(b),a),a}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function md(a){return a!=null&&(typeof a===np||typeof a==='function')&&!(a.kb===qh)}
function hh(a,b){typeof window===np&&typeof window['$gwt']===np&&(window['$gwt'][a]=b)}
function _j(a){var b;return Zj($wnd.React.StrictMode,null,null,(b={},b[Fp]=fj(a),b))}
function Yj(a){var b;b=$j($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Xg(a){var b;if(jd(a,5)){return a}b=a&&a[zp];if(!b){b=new wc(a);Tc(b)}return b}
function Di(a){var b,c,d;d=0;for(c=new mi(a.a);c.b;){b=li(c);d=d+(b?r(b):0);d=d|0}return d}
function nb(a){var b,c;for(c=new Ci(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function _h(a,b){var c,d;for(d=new mi(b.a);d.b;){c=li(d);if(!ii(a,c)){return false}}return true}
function jo(a,b,c){var d;d=new go(b,c);Zn(d,a,new fc(a,d));ei(a.g,Ph(d.c.d),d);db(a.d);return d}
function Zi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Oi(a.a,b);--a.b}return c}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new Ai);a.c=c.c}b.d=true;si(a.c,fj(b))}
function bc(a,b,c){var d;d=fi(a.g,b?Ph(b.c.d):null);if(null!=d){lc(b.c,a);c&&!!b&&hc(b.c);db(a.d)}}
function Zj(a,b,c,d){var e;e=$j($wnd.React.Element,a);e.key=b;e.ref=c;e.props=fj(d);return e}
function mn(a,b){Xj(a.a,(Ah(Wf),Wf.k+(''+(b?Ph(b.c.d):null))));fj(b);a.a.props['a']=b;return a.a}
function ki(a){if(a.a.U()){return true}if(a.a!=a.c){return false}a.a=new Ni(a.d.a);return a.a.U()}
function $g(a){var b;b=a.h;if(b==0){return a.l+a.m*wp}if(b==1048575){return a.l+a.m*wp-Cp}return a}
function ah(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Cp;d=1048575}c=pd(e/wp);b=pd(e-c*wp);return bd(b,c,d)}
function Hi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Fi(a,c.X())){return c}}return null}
function eh(){fh();var a=dh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Nh(){sc.call(this,"Stream already terminated, can't be modified or used")}
function ub(a,b,c){tb.call(this,null,a,b,c|(!a?262144:sp)|(0==(c&6291456)?!a?vp:wp:0)|0|0|0)}
function Jb(a,b){this.b=fj(a);this.a=b|0|(0==(b&6291456)?wp:0)|(0!=(b&229376)?0:98304)}
function un(){this.a=th((Bo(),Bo(),Ao));this.b=th(new No(this.a));this.c=th(new _o(this.a))}
function Ch(){this.g=zh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function wc(a){uc();oc(this);this.e=a;a!=null&&Lj(a,zp,this);this.f=a==null?Bp:ph(a);this.a='';this.b=a;this.a=''}
function To(a){var b;b=R(a.g.a);Vh(Op,b)||Vh(Pp,b)||Vh('',b)?Kn(a.g,b):Oo(Ln(a.g))?Nn(a.g):Kn(a.g,'')}
function Uo(a,b){var c;c=a.e;if(!(b==c||!!b&&$n(b,c))){!!c&&lc(c.c,a);a.e=b;!!b&&Zn(b,a,new Xo(a));db(a.d)}}
function Yi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ad(a,b,c,d,e){e.ib=a;e.jb=b;e.kb=qh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function ep(){ep=mh;bp=new fp('ACTIVE',0);dp=new fp('COMPLETED',1);cp=new fp('ALL',2)}
function Ll(a,b,c){27==c.which?w((I(),I(),H),new km(a,b),Jp):13==c.which&&w((I(),I(),H),new im(a,b),Jp)}
function jb(a){if(2<(a.c&7)){t((I(),I(),H),new F(new yb(a)),67108864,null);!!a.a&&Q(a.a);Fb(a.f);a.c=a.c&-8|1}}
function Qk(){if(!Pk){Pk=(++(I(),I(),H).e,new Eb);$wnd.Promise.resolve(null).then(nh(Rk.prototype.G,Rk,[]))}}
function Ok(){Mk();return ad(Wc(We,1),qp,7,0,[qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk])}
function q(a){return nd(a)?ke:ld(a)?_d:kd(a)?Zd:hd(a)?a.ib:$c(a)?a.ib:a.ib||Array.isArray(a)&&Wc(Rd,1)||Rd}
function r(a){return nd(a)?Tj(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.q():$c(a)?Nj(a):!!a&&!!a.hashCode?a.hashCode():Nj(a)}
function p(a,b){return nd(a)?Vh(a,b):ld(a)?a===b:kd(a)?a===b:hd(a)?a.o(b):$c(a)?a===b:!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function bb(a,b){var c,d;d=a.c;xi(d,b);!!a.b&&sp!=(a.b.c&tp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((I(),c=Pb,c),a))}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function Zg(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<Cp){return c}}return $g(cd(ld(a)?ah(a):a,ld(b)?ah(b):b))}
function Ph(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Rh(),Qh)[b];!c&&(c=Qh[b]=new Oh(a));return c}return new Oh(a)}
function ph(a){var b;if(Array.isArray(a)&&a.kb===qh){return Bh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Tj(a){Rj();var b,c,d;c=':'+a;d=Qj[c];if(d!=null){return pd(d)}d=Oj[c];b=d==null?Sj(a):pd(d);Uj();Qj[c]=b;return b}
function Ei(a){var b,c,d;d=1;for(c=new Ci(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=L(d);return c}}return null}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=wi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&rb(b.b,3,true)}}}
function Pl(a){var b;b=R(a.c);if(!a.i&&b){a.i=true;_l(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Gb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&sp)?Ib(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function vb(a,b){tb.call(this,a,new wb(a),null,b|(sp==(b&tp)?0:524288)|(0==(b&6291456)?sp==(b&tp)?wp:vp:0)|0|268435456|0)}
function Ol(a,b){var c;c=(eb(a.a),a.d);if(null!=c&&c.length!=0){w((I(),I(),H),new Lo(b,c),Jp);Uo(a.k,null);am(a,c)}else{mo(a.j,b)}}
function Kh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function zi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Kj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function ai(a,b){var c,d,e;e=hi(a.a);b.length<e&&(b=Kj(new Array(e),b));d=new mi(a.a);for(c=0;c<e;++c){b[c]=li(d)}b.length>e&&(b[e]=null);return b}
function dk(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function jc(a){var b,c,d;for(c=new Ci(new Bi(new ji(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.X();jd(d,9)&&d.u()||b.Y().v()}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ci(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&rb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ci(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&rb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ci(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?rb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function mc(a,b,c,d,e){var f;this.d=a;this.e=d?new Gi:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new hb((I(),null)),f):null;this.c=null}
function jl(a,b){var c;this.d=fj(b);this.n=fj(a);I();c=++hl;this.b=new mc(c,null,new kl(this),false,false);this.a=new ub(null,fj(new nl(this)),Ip)}
function go(a,b){var c,d,e;this.e=fj(a);this.d=b;I();c=++Xn;this.c=new mc(c,null,new ho(this),true,true);this.b=(e=new hb(null),e);this.a=(d=new hb(null),d)}
function Al(a,b){var c,d;this.e=fj(b);this.n=fj(a);I();c=++ul;this.c=new mc(c,null,new Bl(this),false,false);this.b=(d=new hb(null),d);this.a=new ub(null,fj(new Hl(this)),Ip)}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.jb){return !!a.jb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function L(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function R(a){a.k?fb(a.e):eb(a.e);if(sb(a.f)){if(a.k&&(I(),!(!!Pb&&!!Pb.e))){return t((I(),I(),H),new W(a),83888128,null)}else{lb(a.f)}}return U(a)}
function Wh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=Xg(a);if(jd(a,5)){e=a;throw Yg(e)}else throw Yg(a)}finally{C(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=Xg(a);if(jd(a,5)){f=a;throw Yg(f)}else throw Yg(a)}finally{C(b)}}
function Ab(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Gb(c);return true}
function gh(b,c,d,e){fh();var f=dh;$moduleName=c;$moduleBase=d;Wg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{mp(g)()}catch(a){b(c,a)}}else{mp(g)()}}
function V(a,b,c,d){this.c=fj(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new vb(this,d&-16385);this.e=new hb(this.f);sp==(d&tp)&&kb(this.f)}
function $j(a,b){var c;c=new $wnd.Object;c.$$typeof=fj(a);c.type=fj(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function um(a,b,c,d){var e;this.d=fj(b);this.e=fj(c);this.f=fj(d);this.n=fj(a);I();e=++sm;this.b=new mc(e,null,new vm(this),false,false);this.a=new ub(null,fj(new ym(this)),Ip)}
function Ti(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ui()}}
function gl(a){var b,c,d;a.c=0;Qk();b=(c=R(a.d.e).a,d='item'+(c==1?'':'s'),ak('span',dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,['todo-count'])),[ak('strong',null,[c]),' '+d+' left']));return b}
function jh(){ih={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].lb()&&(c=Pc(c,g)):g[0].lb()}catch(a){a=Xg(a);if(jd(a,5)){d=a;Bc();Hc(jd(d,35)?d.D():d)}else throw Yg(a)}}return c}
function tl(a){var b;a.d=0;Qk();b=ak(Kp,hk(kk(lk(ok(mk(dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,['new-todo']))),(eb(a.b),a.f)),nh(_m.prototype.fb,_m,[a])),nh(an.prototype.eb,an,[a]))),null);return b}
function vc(a){var b;if(a.c==null){b=od(a.b)===od(tc)?null:a.b;a.d=b==null?Bp:md(b)?b==null?null:b.name:nd(b)?'String':Bh(q(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function P(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(od(e)===od(d)||e!=null&&p(e,d))){b.n=d;b.b=null;cb(b.e)}}catch(a){a=Xg(a);if(jd(a,12)){c=a;if(!b.b){b.n=null;b.b=c;cb(b.e)}throw Yg(c)}else throw Yg(a)}}
function Ki(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Hi(b,e);if(f){return f.Z(c)}}e[e.length]=new qi(b,c);++a.b;return null}
function Gj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Sj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Uh(a,c++)}b=b|0;return b}
function lb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;u((I(),I(),H),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Xg(a);if(jd(a,5)){I()}else throw Yg(a)}}}
function N(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Yc(he,qp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function rh(){var a;a=new un;Dm(vn(new wn(a)));Gm(new ml((new xn(a)).a.a.F()));pn(zn(new An(a)));tn(Bn(new Cn(a)));dn(new Dl((new yn(a)).a.b.F()));$wnd.ReactDOM.render(_j([(new rn).a]),(vh(),uh).getElementById('app'),null)}
function Hn(a){var b;if(0==a.length){b=(vh(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',uh.title,b)}else{(vh(),$wnd.window.window).location.hash=a}}
function Zk(a,b,c,d){var e;this.e=fj(b);this.f=fj(c);this.g=fj(d);this.n=fj(a);I();e=++Vk;this.c=new mc(e,null,new $k(this),false,false);this.a=new V(new bl(this),null,null,136478720);this.b=new ub(null,fj(new cl(this)),Ip)}
function bm(a,b,c,d){var e,f;this.j=fj(b);fj(c);this.k=fj(d);this.n=fj(a);I();e=++Tl;this.e=new mc(e,null,new cm(this),false,false);this.a=(f=new hb(null),f);this.c=new V(new hm(this),null,null,136478720);this.b=new ub(null,fj(new mm(this)),Ip);_l(this,this.n.props['a'])}
function tb(a,b,c,d){this.b=new Ai;this.f=new Jb(new xb(this),d&6520832|262144|sp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(B((I(),I(),H),this),0==(this.f.a&vp)&&C((null,H)))}
function Li(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Fi(b,e.X())){if(d.length==1){d.length=0;Oi(a.a,g)}else{d.splice(h,1)}--a.b;return e.Y()}}return null}
function lh(a,b,c){var d=ih,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=ih[b]),oh(h));_.jb=c;!b&&(_.kb=qh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ib=f)}
function Jh(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Kh('.',[c,Kh('$',d)]);a.b=Kh('.',[c,Kh('.',d)]);a.i=d[d.length-1]}
function bi(a,b){var c,d,e;c=b.X();e=b.Y();d=nd(c)?c==null?di(Ji(a.a,null)):Xi(a.b,c):di(Ji(a.a,c));if(!(od(e)===od(d)||e!=null&&p(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!Ji(a.a,null):Wi(a.b,c):!!Ji(a.a,c))){return false}return true}
function ak(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Wj(b,nh(ck.prototype.cb,ck,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Fp]=c[0],undefined):(d[Fp]=c,undefined));return Zj(a,e,f,d)}
function Pn(){var a,b;this.d=new ap(this);this.f=this.e=(b=(vh(),$wnd.window.window).location.hash,null==b?'':b.substr(1));I();this.c=new mc(0,null,new Qn(this),false,false);this.b=(a=new hb(null),a);this.a=new V(new Vn,new Rn(this),new Sn(this),35651584)}
function Vo(a){var b;this.i=fj(a);this.g=new Pn;I();this.f=new mc(0,null,new Wo(this),false,false);this.d=(b=new hb(null),b);this.b=new V(new Yo(this),null,null,Np);this.c=new V(new Zo(this),null,null,Np);this.a=new ub(fj(new $o(this)),null,681574400);C((null,H))}
function ro(){var a;this.g=new Gi;I();this.f=new mc(0,new to(this),new so(this),false,false);this.d=(a=new hb(null),a);this.c=new V(new wo(this),null,null,Np);this.e=new V(new xo(this),null,null,Np);this.a=new V(new yo(this),null,null,Np);this.b=new V(new zo(this),null,null,Np)}
function sb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ci(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{R(c)}catch(a){a=Xg(a);if(!jd(a,5))throw Yg(a)}if(6==(b.c&7)){return true}}}}}nb(b);return false}
function Si(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function rb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||B((I(),I(),H),a))}else if(!!a.a&&4==g&&(6==b||5==b)){gb(a.a.e);qb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||B((I(),I(),H),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;qb((e=d.i,e));d.n=null}ti(a.b,new zb(a));a.b.a=Yc(he,qp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&qb((f=a.a.g,f))}}
function Mk(){Mk=mh;qk=new Nk(Gp,0);rk=new Nk('checkbox',1);sk=new Nk('color',2);tk=new Nk('date',3);uk=new Nk('datetime',4);vk=new Nk('email',5);wk=new Nk('file',6);xk=new Nk('hidden',7);yk=new Nk('image',8);zk=new Nk('month',9);Ak=new Nk(op,10);Bk=new Nk('password',11);Ck=new Nk('radio',12);Dk=new Nk('range',13);Ek=new Nk('reset',14);Fk=new Nk('search',15);Gk=new Nk('submit',16);Hk=new Nk('tel',17);Ik=new Nk('text',18);Jk=new Nk('time',19);Kk=new Nk('url',20);Lk=new Nk('week',21)}
function rm(a){var b,c,d;a.c=0;Qk();d=ak('div',null,[ak('div',null,[ak(Lp,dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,[Lp])),[ak('h1',null,['todos']),(new bn).a]),R(a.d.c)?null:ak('section',dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,[Lp])),[ak(Kp,kk(nk(dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,['toggle-all'])),(Mk(),rk)),nh(qn.prototype.eb,qn,[a])),null),ak('ul',dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,['todo-list'])),(b=sj(fj(rj(R(a.f.c).S())),(c=new Ai,c)),zi(b,_c(b.a.length))))]),R(a.d.c)?null:(new Bm).a])]);return d}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ui(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&yi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{bb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&rb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ui(a.b,g);if(-1==k.e){k.e=0;ab(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){wi(a.b,g)}e&&pb(a.e,a.b)}else{e&&pb(a.e,new Ai)}if(Y(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&sp!=(k.b.c&tp)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function Uk(a){var b,c;a.d=0;Qk();c=(b=R(a.g.b),ak('footer',dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,['footer'])),[(new Em).a,ak('ul',dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,['filters'])),[ak('li',null,[ak('a',fk(dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,[(ep(),cp)==b?Hp:null])),'#'),['All'])]),ak('li',null,[ak('a',fk(dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,[bp==b?Hp:null])),'#active'),['Active'])]),ak('li',null,[ak('a',fk(dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,[dp==b?Hp:null])),'#completed'),['Completed'])])]),R(a.a)?ak(Gp,gk(dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,['clear-completed'])),nh(Am.prototype.gb,Am,[a])),['Clear Completed']):null]));return c}
function Sl(a){var b,c,d,e;a.f=0;Qk();b=a.n.props['a'];if(b.c.i<0){return null}c=(d=a.n.props['a'],e=(eb(d.a),d.d),ak('li',dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,[e?'checked':null,R(a.c)?'editing':null])),[ak('div',dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,['view'])),[ak(Kp,kk(ik(nk(dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,['toggle'])),(Mk(),rk)),e),nh(fn.prototype.eb,fn,[d])),null),ak('label',pk(new $wnd.Object,nh(gn.prototype.gb,gn,[a,d])),[(eb(d.b),d.e)]),ak(Gp,gk(dk(new $wnd.Object,ad(Wc(ke,1),qp,2,6,['destroy'])),nh(hn.prototype.gb,hn,[a,d])),null)]),ak(Kp,lk(kk(jk(ok(dk(ek(new $wnd.Object,nh(jn.prototype.w,jn,[a])),ad(Wc(ke,1),qp,2,6,['edit'])),(eb(a.a),a.d)),nh(kn.prototype.db,kn,[a,d])),nh(en.prototype.eb,en,[a])),nh(ln.prototype.fb,ln,[a,d])),null)]));return c}
function Ui(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Ep]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Si()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Ep]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var np='object',op='number',pp={11:1},qp={3:1,4:1},rp={9:1},sp=1048576,tp=1835008,up={6:1},vp=2097152,wp=4194304,xp={26:1},yp='__noinit__',zp='__java$exception',Ap={3:1,12:1,8:1,5:1},Bp='null',Cp=17592186044416,Dp={40:1},Ep='delete',Fp='children',Gp='button',Hp='selected',Ip=1411518464,Jp=142606336,Kp='input',Lp='header',Mp='hashchange',Np=136314880,Op='active',Pp='completed';var _,ih,dh,Wg=-1;jh();lh(1,null,{},o);_.o=Rp;_.p=function(){return this.ib};_.q=Sp;_.r=function(){var a;return Bh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var dd,ed,fd;lh(54,1,{},Ch);_.H=function(a){var b;b=new Ch;b.e=4;a>1?(b.c=Hh(this,a-1)):(b.c=this);return b};_.I=function(){Ah(this);return this.b};_.J=function(){return Bh(this)};_.K=function(){Ah(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Ah(this),this.k)};_.e=0;_.g=0;var zh=1;var he=Eh(1);var $d=Eh(54);lh(82,1,{},D);_.b=1;_.c=false;_.d=true;_.e=0;var td=Eh(82);lh(36,1,pp,F);_.s=function(){return this.a.v(),null};var rd=Eh(36);lh(83,1,{},G);var sd=Eh(83);var H;lh(43,1,{43:1},O);_.b=0;_.c=false;_.d=0;var ud=Eh(43);lh(232,1,rp);_.r=function(){var a;return Bh(this.ib)+'@'+(a=r(this)>>>0,a.toString(16))};var xd=Eh(232);lh(20,232,rp,V);_.t=function(){Q(this)};_.u=Qp;_.a=false;_.d=0;_.k=false;var wd=Eh(20);lh(179,1,pp,W);_.s=function(){return S(this.a)};var vd=Eh(179);lh(18,232,{9:1,18:1},hb);_.t=function(){Z(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=Eh(18);lh(178,1,up,ib);_.v=function(){$(this.a)};var yd=Eh(178);lh(19,232,{9:1,19:1},ub,vb);_.t=function(){jb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Ed=Eh(19);lh(180,1,xp,wb);_.v=function(){P(this.a)};var Ad=Eh(180);lh(181,1,up,xb);_.v=function(){lb(this.a)};var Bd=Eh(181);lh(182,1,up,yb);_.v=function(){ob(this.a)};var Cd=Eh(182);lh(183,1,{},zb);_.w=function(a){mb(this.a,a)};var Dd=Eh(183);lh(144,1,{},Cb);_.a=0;_.b=0;_.c=0;var Fd=Eh(144);lh(184,1,rp,Eb);_.t=function(){Db(this)};_.u=Qp;_.a=false;var Gd=Eh(184);lh(66,232,{9:1,66:1},Jb);_.t=function(){Fb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Id=Eh(66);lh(60,1,{60:1},Ob);var Hd=Eh(60);lh(188,1,{},$b);_.r=function(){var a;return Ah(Jd),Jd.k+'@'+(a=Nj(this)>>>0,a.toString(16))};_.a=0;var Pb;var Jd=Eh(188);lh(156,1,{});var Md=Eh(156);lh(149,1,{},ec);_.w=function(a){cc(this.a,a)};var Kd=Eh(149);lh(150,1,up,fc);_.v=function(){dc(this.a,this.b)};var Ld=Eh(150);lh(157,156,{});var Nd=Eh(157);lh(17,1,rp,mc);_.t=function(){hc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Ah(Pd),Pd.k+'@'+(a=Nj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Pd=Eh(17);lh(177,1,up,nc);_.v=function(){kc(this.a)};var Od=Eh(177);lh(5,1,{3:1,5:1});_.A=function(a){return new Error(a)};_.B=function(){return this.f};_.C=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Bh(this.ib),c==null?a:a+': '+c);pc(this,rc(this.A(b)));Tc(this)};_.r=function(){return qc(this,this.B())};_.e=yp;_.g=true;var le=Eh(5);lh(12,5,{3:1,12:1,5:1});var be=Eh(12);lh(8,12,Ap);var ie=Eh(8);lh(55,8,Ap);var ee=Eh(55);lh(77,55,Ap);var Td=Eh(77);lh(35,77,{35:1,3:1,12:1,8:1,5:1},wc);_.B=function(){vc(this);return this.c};_.D=function(){return od(this.b)===od(tc)?null:this.b};var tc;var Qd=Eh(35);var Rd=Eh(0);lh(214,1,{});var Sd=Eh(214);var yc=0,zc=0,Ac=-1;lh(91,214,{},Oc);var Kc;var Ud=Eh(91);var Rc;lh(225,1,{});var Wd=Eh(225);lh(78,225,{},Vc);var Vd=Eh(78);lh(44,1,{44:1,70:1},sh);_.F=function(){if(this===this.a){this.a=this.b.F();this.b=null}return this.a};var Xd=Eh(44);var uh;lh(75,1,{72:1});_.r=Qp;var Yd=Eh(75);dd={3:1,73:1,31:1};var Zd=Eh(73);lh(41,1,{3:1,41:1});var ge=Eh(41);ed={3:1,31:1,41:1};var _d=Eh(224);lh(33,1,{3:1,31:1,33:1});_.o=Rp;_.q=Sp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ae=Eh(33);lh(79,8,Ap,Nh);var ce=Eh(79);lh(32,41,{3:1,31:1,32:1,41:1},Oh);_.o=function(a){return jd(a,32)&&a.a==this.a};_.q=Qp;_.r=function(){return ''+this.a};_.a=0;var de=Eh(32);var Qh;lh(287,1,{});lh(80,55,Ap,Th);_.A=function(a){return new TypeError(a)};var fe=Eh(80);fd={3:1,72:1,31:1,2:1};var ke=Eh(2);lh(76,75,{72:1},Zh);var je=Eh(76);lh(291,1,{});lh(57,8,Ap,$h);var me=Eh(57);lh(226,1,{39:1});_.N=Wp;_.R=function(){return new jj(this,0)};_.S=function(){return new tj(null,this.R())};_.P=function(a){throw Yg(new $h('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new lj('[',']');for(b=this.O();b.U();){a=b.V();kj(c,a===this?'(this Collection)':a==null?Bp:ph(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ne=Eh(226);lh(230,1,{213:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!jd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new mi((new ji(d)).a);c.b;){b=li(c);if(!bi(this,b)){return false}}return true};_.q=function(){return Di(new ji(this))};_.r=function(){var a,b,c;c=new lj('{','}');for(b=new mi((new ji(this)).a);b.b;){a=li(b);kj(c,ci(this,a.X())+'='+ci(this,a.Y()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ye=Eh(230);lh(143,230,{213:1});var qe=Eh(143);lh(229,226,{39:1,237:1});_.R=function(){return new jj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!jd(a,23)){return false}b=a;if(hi(b.a)!=this.Q()){return false}return _h(this,b)};_.q=function(){return Di(this)};var ze=Eh(229);lh(23,229,{23:1,39:1,237:1},ji);_.O=function(){return new mi(this.a)};_.Q=Up;var pe=Eh(23);lh(24,1,{},mi);_.T=Tp;_.V=function(){return li(this)};_.U=Vp;_.b=false;var oe=Eh(24);lh(227,226,{39:1,233:1});_.R=function(){return new jj(this,16)};_.W=function(a,b){throw Yg(new $h('Add not supported on this list'))};_.P=function(a){this.W(this.Q(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,14)){return false}f=a;if(this.Q()!=f.a.length){return false}e=new Ci(f);for(c=new Ci(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return Ei(this)};_.O=function(){return new ni(this)};var se=Eh(227);lh(90,1,{},ni);_.T=Tp;_.U=function(){return this.a<this.b.a.length};_.V=function(){return ui(this.b,this.a++)};_.a=0;var re=Eh(90);lh(59,226,{39:1},oi);_.O=function(){var a;a=new mi((new ji(this.a)).a);return new pi(a)};_.Q=Up;var ue=Eh(59);lh(142,1,{},pi);_.T=Tp;_.U=function(){return this.a.b};_.V=function(){var a;a=li(this.a);return a.Y()};var te=Eh(142);lh(140,1,Dp);_.o=function(a){var b;if(!jd(a,40)){return false}b=a;return Fi(this.a,b.X())&&Fi(this.b,b.Y())};_.X=Qp;_.Y=Vp;_.q=function(){return ej(this.a)^ej(this.b)};_.Z=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ve=Eh(140);lh(141,140,Dp,qi);var we=Eh(141);lh(231,1,Dp);_.o=function(a){var b;if(!jd(a,40)){return false}b=a;return Fi(this.b.value[0],b.X())&&Fi(aj(this),b.Y())};_.q=function(){return ej(this.b.value[0])^ej(aj(this))};_.r=function(){return this.b.value[0]+'='+aj(this)};var xe=Eh(231);lh(14,227,{3:1,14:1,39:1,233:1},Ai,Bi);_.W=function(a,b){Hj(this.a,a,b)};_.P=function(a){return si(this,a)};_.N=function(a){ti(this,a)};_.O=function(){return new Ci(this)};_.Q=function(){return this.a.length};var Be=Eh(14);lh(16,1,{},Ci);_.T=Tp;_.U=function(){return this.a<this.c.a.length};_.V=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ae=Eh(16);lh(37,143,{3:1,37:1,213:1},Gi);var Ce=Eh(37);lh(63,1,{},Mi);_.N=Wp;_.O=function(){return new Ni(this)};_.b=0;var Ee=Eh(63);lh(64,1,{},Ni);_.T=Tp;_.V=function(){return this.d=this.a[this.c++],this.d};_.U=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var De=Eh(64);var Qi;lh(61,1,{},$i);_.N=Wp;_.O=function(){return new _i(this)};_.b=0;_.c=0;var He=Eh(61);lh(62,1,{},_i);_.T=Tp;_.V=function(){return this.c=this.a,this.a=this.b.next(),new bj(this.d,this.c,this.d.c)};_.U=function(){return !this.a.done};var Fe=Eh(62);lh(148,231,Dp,bj);_.X=function(){return this.b.value[0]};_.Y=function(){return aj(this)};_.Z=function(a){return Yi(this.a,this.b.value[0],a)};_.c=0;var Ge=Eh(148);lh(198,1,{});_.T=function(a){gj(this,a)};_.$=function(){return this.d};_._=function(){return this.e};_.d=0;_.e=0;var Je=Eh(198);lh(67,198,{});var Ie=Eh(67);lh(22,1,{},jj);_.$=Qp;_._=function(){ij(this);return this.c};_.T=function(a){ij(this);this.d.T(a)};_.ab=function(a){ij(this);if(this.d.U()){a.w(this.d.V());return true}return false};_.a=0;_.c=0;var Ke=Eh(22);lh(56,1,{},lj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Le=Eh(56);lh(197,1,{});_.c=false;var Ue=Eh(197);lh(28,197,{272:1,28:1},tj);var Te=Eh(28);lh(200,67,{},xj);_.ab=function(a){this.b=false;while(!this.b&&this.c.ab(new yj(this,a)));return this.b};_.b=false;var Ne=Eh(200);lh(203,1,{},yj);_.w=function(a){wj(this.a,this.b,a)};var Me=Eh(203);lh(199,67,{},zj);_.ab=function(a){return this.a.ab(new Aj(a))};var Pe=Eh(199);lh(202,1,{},Aj);_.w=function(a){this.a.w(mn(new nn,a))};var Oe=Eh(202);lh(201,1,{},Cj);_.w=function(a){Bj(this,a)};var Qe=Eh(201);lh(204,1,{},Dj);_.w=function(a){};var Re=Eh(204);lh(205,1,{},Fj);_.w=function(a){Ej(this,a)};var Se=Eh(205);lh(289,1,{});lh(286,1,{});var Mj=0;var Oj,Pj=0,Qj;lh(920,1,{});lh(955,1,{});lh(228,1,{});var Ve=Eh(228);lh(271,$wnd.Function,{},ck);_.cb=function(a){bk(this.a,this.b,a)};lh(7,33,{3:1,31:1,33:1,7:1},Nk);var qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk;var We=Fh(7,Ok);var Pk;lh(270,$wnd.Function,{},Rk);_.G=function(a){return Db(Pk),Pk=null,null};lh(92,228,{});var If=Eh(92);lh(93,92,{});_.d=0;var Mf=Eh(93);lh(94,93,rp,Zk);_.t=Xp;_.o=Rp;_.q=Sp;_.u=Yp;_.r=function(){var a;return Ah(ff),ff.k+'@'+(a=Nj(this)>>>0,a.toString(16))};var Vk=0;var ff=Eh(94);lh(96,1,up,$k);_.v=function(){Wk(this.a)};var Xe=Eh(96);lh(95,1,{},al);var Ye=Eh(95);lh(97,1,pp,bl);_.s=function(){return Xk(this.a)};var Ze=Eh(97);lh(98,1,xp,cl);_.v=function(){Tk(this.a)};var $e=Eh(98);lh(99,1,pp,dl);_.s=function(){return Uk(this.a)};var _e=Eh(99);lh(101,228,{});var Hf=Eh(101);lh(102,101,{});_.c=0;var Lf=Eh(102);lh(103,102,rp,jl);_.t=Zp;_.o=Rp;_.q=Sp;_.u=$p;_.r=function(){var a;return Ah(ef),ef.k+'@'+(a=Nj(this)>>>0,a.toString(16))};var hl=0;var ef=Eh(103);lh(105,1,up,kl);_.v=_p;var af=Eh(105);lh(104,1,{},ml);var bf=Eh(104);lh(106,1,xp,nl);_.v=function(){fl(this.a)};var cf=Eh(106);lh(107,1,pp,ol);_.s=function(){return gl(this.a)};var df=Eh(107);lh(130,228,{});_.f='';var Uf=Eh(130);lh(131,130,{});_.d=0;var Of=Eh(131);lh(132,131,rp,Al);_.t=Xp;_.o=Rp;_.q=Sp;_.u=Yp;_.r=function(){var a;return Ah(nf),nf.k+'@'+(a=Nj(this)>>>0,a.toString(16))};var ul=0;var nf=Eh(132);lh(134,1,up,Bl);_.v=function(){vl(this.a)};var gf=Eh(134);lh(133,1,{},Dl);var hf=Eh(133);lh(136,1,pp,El);_.s=function(){return tl(this.a)};var jf=Eh(136);lh(137,1,up,Fl);_.v=function(){pl(this.a)};var kf=Eh(137);lh(138,1,up,Gl);_.v=function(){xl(this.a,this.b)};var lf=Eh(138);lh(135,1,xp,Hl);_.v=function(){Tk(this.a)};var mf=Eh(135);lh(109,228,{});_.i=false;var Wf=Eh(109);lh(110,109,{});_.f=0;var Qf=Eh(110);lh(111,110,rp,bm);_.t=function(){hc(this.e)};_.o=Rp;_.q=Sp;_.u=function(){return this.e.i<0};_.r=function(){var a;return Ah(zf),zf.k+'@'+(a=Nj(this)>>>0,a.toString(16))};var Tl=0;var zf=Eh(111);lh(113,1,up,cm);_.v=function(){Ul(this.a)};var of=Eh(113);lh(112,1,{},em);var pf=Eh(112);lh(116,1,pp,fm);_.s=function(){return Sl(this.a)};var qf=Eh(116);lh(42,1,up,gm);_.v=function(){am(this.a,Ln(this.b))};var rf=Eh(42);lh(114,1,pp,hm);_.s=function(){return Wl(this.a)};var sf=Eh(114);lh(58,1,up,im);_.v=function(){Ol(this.a,this.b)};var tf=Eh(58);lh(117,1,up,jm);_.v=function(){Nl(this.a,this.b)};var uf=Eh(117);lh(118,1,up,km);_.v=function(){Ml(this.a,this.b)};var vf=Eh(118);lh(119,1,up,lm);_.v=function(){Il(this.a,this.b)};var wf=Eh(119);lh(115,1,xp,mm);_.v=function(){Rl(this.a)};var xf=Eh(115);lh(120,1,up,nm);_.v=function(){Pl(this.a)};var yf=Eh(120);lh(122,228,{});var Yf=Eh(122);lh(123,122,{});_.c=0;var Sf=Eh(123);lh(124,123,rp,um);_.t=Zp;_.o=Rp;_.q=Sp;_.u=$p;_.r=function(){var a;return Ah(Ef),Ef.k+'@'+(a=Nj(this)>>>0,a.toString(16))};var sm=0;var Ef=Eh(124);lh(126,1,up,vm);_.v=_p;var Af=Eh(126);lh(125,1,{},xm);var Bf=Eh(125);lh(127,1,xp,ym);_.v=function(){fl(this.a)};var Cf=Eh(127);lh(128,1,pp,zm);_.s=function(){return rm(this.a)};var Df=Eh(128);lh(253,$wnd.Function,{},Am);_.gb=function(a){Fo(this.a.f)};lh(186,1,{},Bm);var Ff=Eh(186);var Cm;lh(208,1,{},Em);var Gf=Eh(208);var Fm;lh(254,$wnd.Function,{},Hm);_.hb=function(a){return new Km(a)};var Im;lh(100,$wnd.React.Component,{},Km);kh(ih[1],_);_.componentWillUnmount=function(){Sk(this.a)};_.render=function(){return Yk(this.a)};_.shouldComponentUpdate=aq;var Jf=Eh(100);lh(255,$wnd.Function,{},Lm);_.hb=function(a){return new Om(a)};var Mm;lh(108,$wnd.React.Component,{},Om);kh(ih[1],_);_.componentWillUnmount=function(){el(this.a)};_.render=function(){return il(this.a)};_.shouldComponentUpdate=bq;var Kf=Eh(108);lh(269,$wnd.Function,{},Pm);_.hb=function(a){return new Sm(a)};var Qm;lh(139,$wnd.React.Component,{},Sm);kh(ih[1],_);_.componentWillUnmount=function(){Sk(this.a)};_.render=function(){return yl(this.a)};_.shouldComponentUpdate=aq;var Nf=Eh(139);lh(256,$wnd.Function,{},Tm);_.hb=function(a){return new Wm(a)};var Um;lh(121,$wnd.React.Component,{},Wm);kh(ih[1],_);_.componentDidUpdate=function(a){Zl(this.a)};_.componentWillUnmount=function(){Ql(this.a)};_.render=function(){return $l(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Pf=Eh(121);lh(266,$wnd.Function,{},Xm);_.hb=function(a){return new $m(a)};var Ym;lh(129,$wnd.React.Component,{},$m);kh(ih[1],_);_.componentWillUnmount=function(){el(this.a)};_.render=function(){return tm(this.a)};_.shouldComponentUpdate=bq;var Rf=Eh(129);lh(267,$wnd.Function,{},_m);_.fb=function(a){ql(this.a,a)};lh(268,$wnd.Function,{},an);_.eb=function(a){wl(this.a,a)};lh(185,1,{},bn);var Tf=Eh(185);var cn;lh(263,$wnd.Function,{},en);_.eb=function(a){Vl(this.a,a)};lh(257,$wnd.Function,{},fn);_.eb=function(a){fo(this.a)};lh(259,$wnd.Function,{},gn);_.gb=function(a){Xl(this.a,this.b)};lh(260,$wnd.Function,{},hn);_.gb=function(a){Jl(this.a,this.b)};lh(261,$wnd.Function,{},jn);_.w=function(a){Kl(this.a,a)};lh(262,$wnd.Function,{},kn);_.db=function(a){Yl(this.a,this.b)};lh(264,$wnd.Function,{},ln);_.fb=function(a){Ll(this.a,this.b,a)};lh(207,1,{},nn);var Vf=Eh(207);var on;lh(265,$wnd.Function,{},qn);_.eb=function(a){om(this.a,a)};lh(71,1,{},rn);var Xf=Eh(71);var sn;lh(84,1,{},un);var cg=Eh(84);lh(85,1,{},wn);var Zf=Eh(85);lh(89,1,{},xn);var $f=Eh(89);lh(88,1,{},yn);var _f=Eh(88);lh(86,1,{},An);var ag=Eh(86);lh(87,1,{},Cn);var bg=Eh(87);lh(189,1,{});var Lg=Eh(189);lh(190,189,rp,Pn);_.t=Xp;_.o=Rp;_.q=Sp;_.u=Yp;_.r=function(){var a;return Ah(kg),kg.k+'@'+(a=Nj(this)>>>0,a.toString(16))};var kg=Eh(190);lh(191,1,up,Qn);_.v=function(){Jn(this.a)};var dg=Eh(191);lh(193,1,xp,Rn);_.v=function(){En(this.a)};var eg=Eh(193);lh(194,1,xp,Sn);_.v=function(){Fn(this.a)};var fg=Eh(194);lh(196,1,up,Tn);_.v=function(){Mn(this.a)};var gg=Eh(196);lh(65,1,up,Un);_.v=function(){In(this.a)};var hg=Eh(65);lh(192,1,pp,Vn);_.s=function(){var a;return a=(vh(),$wnd.window.window).location.hash,null==a?'':a.substr(1)};var ig=Eh(192);lh(195,1,up,Wn);_.v=function(){Dn(this.a,this.b)};var jg=Eh(195);lh(48,1,{48:1});_.d=false;var Tg=Eh(48);lh(49,48,{9:1,273:1,49:1,48:1},go);_.t=Xp;_.o=function(a){return $n(this,a)};_.q=function(){return this.c.d};_.u=Yp;_.r=function(){var a;return Ah(Cg),Cg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Xn=0;var Cg=Eh(49);lh(209,1,up,ho);_.v=function(){Yn(this.a)};var lg=Eh(209);lh(210,1,up,io);_.v=function(){bo(this.a)};var mg=Eh(210);lh(45,157,{45:1});var Og=Eh(45);lh(158,45,{9:1,45:1},ro);_.t=cq;_.o=Rp;_.q=Sp;_.u=dq;_.r=function(){var a;return Ah(wg),wg.k+'@'+(a=Nj(this)>>>0,a.toString(16))};var wg=Eh(158);lh(160,1,up,so);_.v=function(){ko(this.a)};var ng=Eh(160);lh(159,1,up,to);_.v=function(){oo(this.a)};var og=Eh(159);lh(165,1,up,uo);_.v=function(){bc(this.a,this.b,true)};var pg=Eh(165);lh(166,1,pp,vo);_.s=function(){return jo(this.a,this.c,this.b)};_.b=false;var qg=Eh(166);lh(161,1,pp,wo);_.s=function(){return po(this.a)};var rg=Eh(161);lh(162,1,pp,xo);_.s=function(){return Ph(bh(pj(no(this.a))))};var sg=Eh(162);lh(163,1,pp,yo);_.s=function(){return Ph(bh(pj(qj(no(this.a),new hp))))};var tg=Eh(163);lh(164,1,pp,zo);_.s=function(){return qo(this.a)};var ug=Eh(164);lh(145,1,{70:1},Co);_.F=function(){return new ro};var Ao;var vg=Eh(145);lh(46,1,{46:1});var Sg=Eh(46);lh(167,46,{9:1,46:1},Jo);_.t=function(){hc(this.a)};_.o=Rp;_.q=Sp;_.u=function(){return this.a.i<0};_.r=function(){var a;return Ah(Bg),Bg.k+'@'+(a=Nj(this)>>>0,a.toString(16))};var Bg=Eh(167);lh(168,1,up,Ko);_.v=function(){Go(this.a,this.b)};_.b=false;var xg=Eh(168);lh(169,1,up,Lo);_.v=function(){On(this.b,this.a)};var yg=Eh(169);lh(170,1,up,Mo);_.v=function(){Ho(this.a)};var zg=Eh(170);lh(146,1,{70:1},No);_.F=function(){return new Jo(this.a.F())};var Ag=Eh(146);lh(47,1,{47:1});var Vg=Eh(47);lh(171,47,{9:1,47:1},Vo);_.t=cq;_.o=Rp;_.q=Sp;_.u=dq;_.r=function(){var a;return Ah(Jg),Jg.k+'@'+(a=Nj(this)>>>0,a.toString(16))};var Jg=Eh(171);lh(172,1,up,Wo);_.v=function(){Qo(this.a)};var Dg=Eh(172);lh(176,1,up,Xo);_.v=function(){Uo(this.a,null)};var Eg=Eh(176);lh(173,1,pp,Yo);_.s=function(){var a;return a=Ln(this.a.g),Vh(Op,a)?(ep(),bp):Vh(Pp,a)?(ep(),dp):(ep(),cp)};var Fg=Eh(173);lh(174,1,pp,Zo);_.s=function(){return So(this.a)};var Gg=Eh(174);lh(175,1,xp,$o);_.v=function(){To(this.a)};var Hg=Eh(175);lh(147,1,{70:1},_o);_.F=function(){return new Vo(this.a.F())};var Ig=Eh(147);lh(187,1,{},ap);_.handleEvent=function(a){Gn(this.a,a)};var Kg=Eh(187);lh(34,33,{3:1,31:1,33:1,34:1},fp);var bp,cp,dp;var Mg=Fh(34,gp);lh(151,1,{},hp);_.bb=function(a){return !ao(a)};var Ng=Eh(151);lh(153,1,{},ip);_.bb=function(a){return ao(a)};var Pg=Eh(153);lh(154,1,{},jp);_.w=function(a){mo(this.a,a)};var Qg=Eh(154);lh(152,1,{},kp);_.w=function(a){Eo(this.a,a)};_.a=false;var Rg=Eh(152);lh(155,1,{},lp);_.bb=function(a){return Po(this.a,a)};var Ug=Eh(155);var qd=Gh('D');var mp=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=gh;eh(rh);hh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();