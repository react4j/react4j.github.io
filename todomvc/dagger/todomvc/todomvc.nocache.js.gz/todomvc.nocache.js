function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='295A09516A80DE184968C666CA8CFB78',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '295A09516A80DE184968C666CA8CFB78';function p(){}
function vh(){}
function rh(){}
function Fb(){}
function Pc(){}
function Wc(){}
function ii(){}
function Dj(){}
function Rj(){}
function Zj(){}
function $j(){}
function yk(){}
function ml(){}
function Um(){}
function Ym(){}
function an(){}
function en(){}
function jn(){}
function En(){}
function ao(){}
function cp(){}
function lp(){}
function op(){}
function pp(){}
function Uc(a){Tc()}
function Ih(){Ih=rh}
function Li(){Ci(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function ec(a){this.a=a}
function nc(a){this.a=a}
function Yh(a){this.a=a}
function hi(a){this.a=a}
function ui(a){this.a=a}
function zi(a){this.a=a}
function Ai(a){this.a=a}
function yi(a){this.b=a}
function Ni(a){this.c=a}
function Ej(a){this.a=a}
function ak(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function Ul(a){this.a=a}
function Vl(a){this.a=a}
function Wl(a){this.a=a}
function Yl(a){this.a=a}
function tm(a){this.a=a}
function um(a){this.a=a}
function zm(a){this.a=a}
function Bm(a){this.a=a}
function Cm(a){this.a=a}
function Km(a){this.a=a}
function Lm(a){this.a=a}
function Mm(a){this.a=a}
function Nm(a){this.a=a}
function nn(a){this.a=a}
function on(a){this.a=a}
function sn(a){this.a=a}
function tn(a){this.a=a}
function wn(a){this.a=a}
function Dn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function no(a){this.a=a}
function oo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Eo(a){this.a=a}
function Fo(a){this.a=a}
function Po(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function qp(a){this.a=a}
function rp(a){this.a=a}
function sp(a){this.a=a}
function tp(a){this.a=a}
function Yj(a,b){a.a=b}
function qb(a,b){a.b=b}
function rk(a,b){a.key=b}
function qk(a,b){pk(a,b)}
function Ho(a,b){rm(b,a)}
function Y(a){!!a&&$(a)}
function ic(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function Yp(a){pj(this,a)}
function _p(a){ai(this,a)}
function bq(a){sj(this,a)}
function dq(){hc(this.c)}
function fq(){hc(this.b)}
function kq(){hc(this.f)}
function Zi(){this.a=gj()}
function lj(){this.a=gj()}
function hq(){kb(this.a.a)}
function hb(a){Zb((J(),a))}
function db(a){Xb((J(),a))}
function eb(a){Yb((J(),a))}
function bh(a){return a.e}
function Wp(){return this.a}
function $p(){return this.b}
function aq(){return this.e}
function J(){J=rh;I=new F}
function vc(){vc=rh;uc=new p}
function yh(){yh=rh;xh=new p}
function cj(){cj=rh;bj=ej()}
function nl(a){a.d=2;hc(a.c)}
function zl(a){a.c=2;hc(a.b)}
function dm(a){a.f=2;hc(a.e)}
function Pn(a){R(a.a);$(a.b)}
function Ol(a){kb(a.a);$(a.b)}
function rl(a){kb(a.b);R(a.a)}
function co(a){$(a.b);$(a.a)}
function K(a,b){O(a);L(a,b)}
function _j(a,b){Qj(a.a,b)}
function lc(a,b){qi(a.e,b)}
function $l(a,b){so(a.j,b)}
function Go(a,b){ro(a.b,b)}
function C(a,b){Nb(a.f,b.f)}
function gc(a,b,c){pi(a.e,b,c)}
function qc(a,b){a.e=b;pc(a,b)}
function Fi(a,b){return a.a[b]}
function _l(a,b){return a.g=b}
function Xp(){return hk(this)}
function cq(a){return this===a}
function Hh(a){tc.call(this,a)}
function Xh(a){tc.call(this,a)}
function ji(a){tc.call(this,a)}
function ek(a,b){a.splice(b,1)}
function eo(a,b,c){gc(a.c,b,c)}
function xj(a,b,c){b.w(a.a[c])}
function ab(a){J();Yb(a);a.e=-2}
function Lh(a){Kh(a);return a.k}
function Xc(a,b){return Rh(a,b)}
function Zp(){return si(this.a)}
function eq(){return this.c.i<0}
function gq(){return this.b.i<0}
function lq(){return this.f.i<0}
function bi(){oc(this);this.G()}
function Cc(){Cc=rh;!!(Tc(),Sc)}
function Mc(){Mc=rh;Lc=new Pc}
function ep(){ep=rh;dp=new cp}
function np(){np=rh;mp=new lp}
function gj(){cj();return new bj}
function Pj(a,b){a.T(b);return a}
function T(a){mb(a.f);return V(a)}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function Qj(a,b){Yj(a,Pj(a.a,b))}
function sj(a,b){while(a.eb(b));}
function Vj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function Bk(a,b){a.ref=b;return a}
function Rn(a){fb(a.b);return a.e}
function To(a){fb(a.d);return a.e}
function ho(a){fb(a.a);return a.d}
function iq(a){return 1==this.a.d}
function jq(a){return 1==this.a.c}
function si(a){return a.a.b+a.b.b}
function ij(a,b){return a.a.get(b)}
function Uj(a,b){this.a=a;this.b=b}
function Xj(a,b){this.a=a;this.b=b}
function fc(a,b){this.a=a;this.b=b}
function Wh(a,b){this.a=a;this.b=b}
function Bi(a,b){this.a=a;this.b=b}
function zk(a,b){this.a=a;this.b=b}
function Xl(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function wm(a,b){this.a=a;this.b=b}
function xm(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function Am(a,b){this.a=a;this.b=b}
function zh(a){this.a=xh;this.b=a}
function Db(a){this.d=a;this.b=100}
function Sm(a){this.a=a;Tm=this}
function qn(a){this.a=a;rn=this}
function un(a,b){this.a=a;this.b=b}
function vn(a,b){this.a=a;this.b=b}
function xn(a,b){this.a=a;this.b=b}
function yn(a,b){this.a=a;this.b=b}
function il(a,b){Wh.call(this,a,b)}
function ck(a,b,c){a.splice(b,0,c)}
function Ck(a,b){a.href=b;return a}
function Zn(a,b){this.a=a;this.b=b}
function Ao(a,b){this.a=a;this.b=b}
function No(a,b){this.a=a;this.b=b}
function Oo(a,b){this.b=a;this.a=b}
function up(a,b){this.b=a;this.a=b}
function jp(a,b){Wh.call(this,a,b)}
function kh(){ih==null&&(ih=[])}
function Om(){this.a=sk((Wm(),Vm))}
function Rm(){this.a=sk(($m(),Zm))}
function pn(){this.a=sk((cn(),bn))}
function An(){this.a=sk((gn(),fn))}
function Fn(){this.a=sk((ln(),kn))}
function Sn(a){Qn(a,(fb(a.b),a.e))}
function io(a){rm(a,(fb(a.a),!a.d))}
function Tb(a){return !a.d?a:Tb(a.d)}
function oi(a){return !a?null:a.ab()}
function od(a){return a==null?null:a}
function rj(a){return a!=null?s(a):0}
function ld(a){return typeof a===xp}
function o(a,b){return od(a)===od(b)}
function Jc(a){$wnd.clearTimeout(a)}
function Ci(a){a.a=Zc(ie,yp,1,0,5,1)}
function ri(a){a.a=new Zi;a.b=new lj}
function ib(a){this.c=new Li;this.b=a}
function lk(){lk=rh;ik=new p;kk=new p}
function Fk(a,b){a.checked=b;return a}
function Lk(a,b){a.value=b;return a}
function Gk(a,b){a.onBlur=b;return a}
function Dk(a,b){a.onClick=b;return a}
function Hk(a,b){a.onChange=b;return a}
function fi(a,b){a.a+=''+b;return a}
function dk(a,b){bk(b,0,a,0,b.length)}
function dc(a,b){bc(a,b,false);eb(a.d)}
function hm(a){kb(a.b);R(a.c);$(a.a)}
function pb(a){J();ob(a);sb(a,2,true)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function Z(a){return !(!!a&&1==(a.c&7))}
function hk(a){return a.$H||(a.$H=++gk)}
function ci(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function B(a,b,c){return u(a,c,2048,b)}
function bd(a,b,c){return {l:a,m:b,h:c}}
function A(a,b,c){u(a,new G(b),c,null)}
function pk(a,b){for(var c in a){b(c)}}
function Ik(a,b){a.onKeyDown=b;return a}
function Ek(a){a.autoFocus=true;return a}
function Kh(a){if(a.k!=null){return}Th(a)}
function Kc(){zc!=0&&(zc=0);Bc=-1}
function tc(a){this.g=a;oc(this);this.G()}
function Oj(a,b){Hj.call(this,a);this.a=b}
function cc(a,b){lc(b.c,a);jd(b,9)&&b.t()}
function pj(a,b){while(a.Y()){_j(b,a.Z())}}
function Bn(a,b){this.a=a;this.b=b;Cn=this}
function Ti(){this.a=new Zi;this.b=new lj}
function P(){this.a=Zc(ie,yp,1,100,5,1)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function _i(a,b){var c;c=a[Kp];c.call(a,b)}
function So(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function wo(a){return Zh(S(a.e).a-S(a.a).a)}
function nd(a){return typeof a==='string'}
function kd(a){return typeof a==='boolean'}
function Dc(a,b,c){return a.apply(b,c);var d}
function Mk(a,b){a.onDoubleClick=b;return a}
function oc(a){a.j&&a.e!==Fp&&a.G();return a}
function Oh(a){var b;b=Nh(a);Vh(a,b);return b}
function _h(){_h=rh;$h=Zc(ee,yp,28,256,0,1)}
function om(a){A((J(),J(),I),new Bm(a),Pp)}
function Tn(a){A((J(),J(),I),new $n(a),Pp)}
function lo(a){A((J(),J(),I),new oo(a),Pp)}
function Io(a){A((J(),J(),I),new Po(a),Pp)}
function Pl(a,b){A((J(),J(),I),new Xl(a,b),Pp)}
function im(a,b){A((J(),J(),I),new Am(a,b),Pp)}
function mm(a,b){A((J(),J(),I),new xm(a,b),Pp)}
function nm(a,b){A((J(),J(),I),new wm(a,b),Pp)}
function qm(a,b){A((J(),J(),I),new vm(a,b),Pp)}
function so(a,b){A((J(),J(),I),new Ao(a,b),Pp)}
function Lo(a,b){A((J(),J(),I),new No(a,b),Pp)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function Ql(a,b){var c;c=b.target;Sl(a,c.value)}
function vj(a,b){while(a.c<a.d){xj(a,b,a.c++)}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function Ch(a){if(!a){throw bh(new bi)}return a}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function zj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Di(a,b){a.a[a.a.length]=b;return true}
function Bo(a,b){this.a=a;this.c=b;this.b=false}
function oj(a,b,c){this.a=a;this.b=b;this.c=c}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function uo(a){ai(new zi(a.g),new ec(a));ri(a.g)}
function Qo(a){return o(Up,a)||o(Vp,a)||o('',a)}
function hj(a,b){return !(a.a.get(b)===undefined)}
function Ij(a,b){var c;return Mj(a,(c=new Li,c))}
function Tc(){Tc=rh;var a;!Vc();a=new Wc;Sc=a}
function Eh(){Eh=rh;Dh=$wnd.goog.global.document}
function wi(a){var b;b=a.a.Z();a.b=vi(a);return b}
function Qh(a){var b;b=Nh(a);b.j=a;b.e=1;return b}
function Hi(a,b){var c;c=a.a[b];ek(a.a,b);return c}
function Qc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Oi(a,b){return tj(b,a.length),new yj(a,b)}
function vo(a){return Ih(),0==S(a.e).a?true:false}
function sl(a){return Ih(),S(a.e.b).a>0?true:false}
function tl(a){return B((J(),J(),I),a.b,new yl(a))}
function Pi(a){return new Oj(null,Oi(a,a.length))}
function Dl(a){return B((J(),J(),I),a.a,new Hl(a))}
function Rl(a){return B((J(),J(),I),a.a,new Vl(a))}
function _c(a){return Array.isArray(a)&&a.pb===vh}
function hd(a){return !Array.isArray(a)&&a.pb===vh}
function pm(a){return B((J(),J(),I),a.b,new um(a))}
function Im(a){return B((J(),J(),I),a.a,new Mm(a))}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function qo(a){R(a.c);R(a.e);R(a.a);R(a.b);$(a.d)}
function Al(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function ol(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function em(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Fj(a){if(!a.b){Gj(a);a.c=true}else{Fj(a.b)}}
function Sj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function Fh(a,b,c,d){a.addEventListener(b,c,d)}
function Gh(a,b,c,d){a.removeEventListener(b,c,d)}
function Dm(a,b){var c;c=b.target;Lo(a.e,c.checked)}
function rm(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function Sl(a,b){var c;c=a.f;if(b!=c){a.f=b;eb(a.b)}}
function Un(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function Ji(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Kk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ti(a,b){if(b){return mi(a.a,b)}return false}
function Kj(a,b){Gj(a);return new Oj(a,new Tj(b,a.a))}
function Lj(a,b){Gj(a);return new Oj(a,new Wj(b,a.a))}
function Qn(a,b){A((J(),J(),I),new Zn(a,b),75497472)}
function Si(a,b){return od(a)===od(b)||a!=null&&q(a,b)}
function On(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&Un(a,b)}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function jm(a,b){Wo(a.k,b);A((J(),J(),I),new vm(a,b),Pp)}
function Jo(a,b){Ij(to(a.b),new Ej(new Dj)).Q(new rp(b))}
function uj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Aj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function yj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Pm(a,b,c){this.a=a;this.b=b;this.c=c;Qm=this}
function Gn(a,b,c){this.a=a;this.b=b;this.c=c;Hn=this}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Hj(a){if(!a){this.b=null;new Li}else{this.b=a}}
function Sh(a){if(a.P()){return null}var b=a.j;return nh[b]}
function hh(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function ok(){if(jk==256){ik=kk;kk=new p;jk=0}++jk}
function Ph(a,b){var c;c=Nh(a);Vh(a,c);c.e=b?8:0;return c}
function rc(a,b){var c;c=Lh(a.nb);return b==null?c:c+': '+b}
function Zl(a,b){var c;if(S(a.c)){c=b.target;rm(a,c.value)}}
function ai(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function ni(a,b){return b===a?'(this Map)':b==null?Hp:uh(b)}
function kp(){ip();return ad(Xc(Og,1),yp,30,0,[fp,hp,gp])}
function km(a,b){A((J(),J(),I),new vm(a,b),Pp);Wo(a.k,null)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Dp)&&D((null,I))}
function Ic(a){Cc();$wnd.setTimeout(function(){throw a},0)}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function th(a){function b(){}
;b.prototype=a||{};return new b}
function Jk(a){a.placeholder='What needs to be done?';return a}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function lm(a){return Ih(),To(a.k)==a.n.props['a']?true:false}
function Kn(a){Fh((Eh(),$wnd.goog.global.window),Sp,a.d,false)}
function Ln(a){Gh((Eh(),$wnd.goog.global.window),Sp,a.d,false)}
function cn(){cn=rh;var a;bn=(a=sh(an.prototype.mb,an,[]),a)}
function gn(){gn=rh;var a;fn=(a=sh(en.prototype.mb,en,[]),a)}
function ln(){ln=rh;var a;kn=(a=sh(jn.prototype.mb,jn,[]),a)}
function Wm(){Wm=rh;var a;Vm=(a=sh(Um.prototype.mb,Um,[]),a)}
function $m(){$m=rh;var a;Zm=(a=sh(Ym.prototype.mb,Ym,[]),a)}
function Rh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function Vi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Wi(a,b){var c;return Ui(b,Vi(a,b==null?0:(c=s(b),c|0)))}
function to(a){fb(a.d);return new Oj(null,new Aj(new zi(a.g),0))}
function Mn(a,b){b.preventDefault();A((J(),J(),I),new _n(a),Pp)}
function Wj(a,b){uj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function $i(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Mo(a){this.b=a;J();this.a=new mc(0,null,null,false,false)}
function Mi(a){Ci(this);dk(this.a,li(a,Zc(ie,yp,1,si(a.a),5,1)))}
function kc(a){ic(a.g);!!a.e&&jc(a);Y(a.a);Y(a.c);ic(a.b);ic(a.f)}
function Ah(a){yh();Ch(a);if(jd(a,43)){return a}return new zh(a)}
function wj(a,b){if(a.c<a.d){xj(a,b,a.c++);return true}return false}
function sc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function ph(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function xk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Gc(a,b,c){var d;d=Ec();try{return Dc(a,b,c)}finally{Hc(d)}}
function bb(a,b){var c,d;Di(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Tj(a,b){uj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function mj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Bj(a,b){!a.a?(a.a=new hi(a.d)):fi(a.a,a.b);fi(a.a,b);return a}
function Mj(a,b){var c;Fj(a);c=new Zj;c.a=b;a.a.X(new ak(c));return c.a}
function Jj(a){var b;Fj(a);b=0;while(a.a.eb(new $j)){b=dh(b,1)}return b}
function Ko(a){Ij(Kj(to(a.b),new pp),new Ej(new Dj)).Q(new qp(a.b))}
function ro(a,b){var c;return u((J(),J(),I),new Bo(a,b),Pp,(c=null,c))}
function Fc(b){Cc();return function(){return Gc(b,this,arguments);var a}}
function yc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function _m(a){$wnd.React.Component.call(this,a);this.a=new El(this,Tm.a)}
function dn(a){$wnd.React.Component.call(this,a);this.a=new Tl(this,rn.a)}
function Cj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function xi(a){this.d=a;this.c=new mj(this.d.b);this.a=this.c;this.b=vi(this)}
function Nj(a,b){var c;c=Ij(a,new Ej(new Dj));return Ki(c,b.fb(c.a.length))}
function Ro(a,b){return (ip(),gp)==a||(fp==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function qi(a,b){return nd(b)?b==null?Yi(a.a,null):kj(a.b,b):Yi(a.a,b)}
function fk(a,b){return Yc(b)!=10&&ad(r(b),b.ob,b.__elementTypeId$,Yc(b),a),a}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Hc(a){a&&Oc((Mc(),Lc));--zc;if(a){if(Bc!=-1){Jc(Bc);Bc=-1}}}
function Ib(b){try{mb(b.b.a)}catch(a){a=ah(a);if(!jd(a,4))throw bh(a)}}
function Jn(a,b){a.f=b;o(b,S(a.a))&&Un(a,b);Nn(b);A((J(),J(),I),new _n(a),Pp)}
function Uo(a){var b;return b=S(a.b),Ij(Kj(to(a.i),new tp(b)),new Ej(new Dj))}
function Il(a){var b;b=ei((fb(a.b),a.f));if(b.length>0){Go(a.e,b);Sl(a,'')}}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Gi(a,b,c){for(;c<a.a.length;++c){if(Si(b,a.a[c])){return c}}return -1}
function Zc(a,b,c,d,e,f){var g;g=$c(e,d);e!=10&&ad(Xc(a,f),b,c,e,g);return g}
function Ii(a,b){var c;c=Gi(a,b,0);if(c==-1){return false}ek(a.a,c);return true}
function fo(a,b){var c;if(jd(b,50)){c=b;return a.c.d==c.c.d}else{return false}}
function nj(a){if(a.a.c!=a.c){return ij(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function hc(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new nc(a)),67108864,null)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function V(a){if(a.b){if(jd(a.b,7)){throw bh(a.b)}else{throw bh(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=ah(a);if(jd(a,4)){J()}else throw bh(a)}}}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function Nc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Rc(b,c)}while(a.a);a.a=c}}
function Oc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Rc(b,c)}while(a.b);a.b=c}}
function pi(a,b,c){return nd(b)?b==null?Xi(a.a,null,c):jj(a.b,b,c):Xi(a.a,b,c)}
function vk(a){var b;return tk($wnd.React.StrictMode,null,null,(b={},b[Lp]=a,b))}
function Ei(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Ob(){var a;this.a=Zc(ud,yp,42,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function hn(a){$wnd.React.Component.call(this,a);this.a=new sm(this,Cn.a,Cn.b)}
function mn(a){$wnd.React.Component.call(this,a);this.a=new Jm(this,Hn.a,Hn.b,Hn.c)}
function Xm(a){$wnd.React.Component.call(this,a);this.a=new ul(this,Qm.a,Qm.b,Qm.c)}
function md(a){return a!=null&&(typeof a===wp||typeof a==='function')&&!(a.pb===vh)}
function Yc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Jl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Wl(a),Pp)}}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Li);Di(a.b,b)}}}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new Li);a.c=c.c}b.d=true;Di(a.c,b)}
function Vh(a,b){var c;if(!a){return}b.j=a;var d=Sh(b);if(!d){nh[a]=[b];return}d.nb=b}
function sh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function tk(a,b,c,d){var e;e=uk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function sk(a){var b;b=uk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Nh(a){var b;b=new Mh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function kj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{_i(a.a,b);--a.b}return c}
function ki(a,b){var c,d;for(d=new xi(b.a);d.b;){c=wi(d);if(!ti(a,c)){return false}}return true}
function Qi(a){var b,c,d;d=0;for(c=new xi(a.a);c.b;){b=wi(c);d=d+(b?s(b):0);d=d|0}return d}
function ob(a){var b,c;for(c=new Ni(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function jh(){kh();var a=ih;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function tj(a,b){if(0>a||a>b){throw bh(new Hh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function mh(a,b){typeof window===wp&&typeof window['$gwt']===wp&&(window['$gwt'][a]=b)}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Ep:0)|(0!=(b&229376)?0:98304)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:Ap)|(0==(c&6291456)?!a?Dp:Ep:0)|0|0|0)}
function zn(a,b){rk(a.a,(Kh(bg),bg.k+(''+(b?Zh(b.c.d):null))));a.a.props['a']=b;return a.a}
function vi(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new $i(a.d.a);return a.a.Y()}
function ah(a){var b;if(jd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new xc(a);Uc(b)}return b}
function eh(a){var b;b=a.h;if(b==0){return a.l+a.m*Ep}if(b==1048575){return a.l+a.m*Ep-Ip}return a}
function gh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Ip;d=1048575}c=pd(e/Ep);b=pd(e-c*Ep);return bd(b,c,d)}
function Ui(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Si(a,c._())){return c}}return null}
function po(a,b,c){var d;d=new mo(b,c);eo(d,a,new fc(a,d));pi(a.g,Zh(d.c.d),d);eb(a.d);return d}
function jj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function bc(a,b,c){var d;d=qi(a.g,b?Zh(b.c.d):null);if(null!=d){lc(b.c,a);c&&!!b&&hc(b.c);eb(a.d)}}
function Wo(a,b){var c;c=a.e;if(!(b==c||!!b&&fo(b,c))){!!c&&lc(c.c,a);a.e=b;!!b&&eo(b,a,new Zo(a));eb(a.d)}}
function Vo(a){var b;b=S(a.g.a);o(Up,b)||o(Vp,b)||o('',b)?Qn(a.g,b):Qo(Rn(a.g))?Tn(a.g):Qn(a.g,'')}
function ip(){ip=rh;fp=new jp('ACTIVE',0);hp=new jp('COMPLETED',1);gp=new jp('ALL',2)}
function am(a,b,c){27==c.which?A((J(),J(),I),new ym(a,b),Pp):13==c.which&&A((J(),J(),I),new wm(a,b),Pp)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function ll(){if(!kl){kl=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(sh(ml.prototype.J,ml,[]))}}
function In(){this.a=Ah((np(),mp));this.b=Ah(new sp(this.a));this.c=Ah((ep(),dp));this.d=Ah(new up(this.a,this.c))}
function xc(a){vc();oc(this);this.e=a;pc(this,a);this.g=a==null?Hp:uh(a);this.a='';this.b=a;this.a=''}
function Mh(){this.g=Jh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function ad(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=vh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function cb(a,b){var c,d;d=a.c;Ii(d,b);!!a.b&&Ap!=(a.b.c&Bp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Ap)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function r(a){return nd(a)?le:ld(a)?_d:kd(a)?Zd:hd(a)?a.nb:_c(a)?a.nb:a.nb||Array.isArray(a)&&Xc(Qd,1)||Qd}
function s(a){return nd(a)?nk(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.q():_c(a)?hk(a):!!a&&!!a.hashCode?a.hashCode():hk(a)}
function Zh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(_h(),$h)[b];!c&&(c=$h[b]=new Yh(a));return c}return new Yh(a)}
function uh(a){var b;if(Array.isArray(a)&&a.pb===vh){return Lh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function nk(a){lk();var b,c,d;c=':'+a;d=kk[c];if(d!=null){return pd(d)}d=ik[c];b=d==null?mk(a):pd(d);ok();kk[c]=b;return b}
function Ri(a){var b,c,d;d=1;for(c=new Ni(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=Hi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function cm(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;qm(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function bm(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Oo(b,c),Pp);Wo(a.k,null);rm(a,c)}else{so(a.j,b)}}
function dh(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<Ip){return c}}return eh(cd(ld(a)?gh(a):a,ld(b)?gh(b):b))}
function jl(){hl();return ad(Xc(cf,1),yp,6,0,[Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl])}
function Gj(a){if(a.b){Gj(a.b)}else if(a.c){throw bh(new Xh("Stream already terminated, can't be modified or used"))}}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.ob){return !!a.ob[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(Ap==(b&Bp)?0:524288)|(0==(b&6291456)?Ap==(b&Bp)?Ep:Dp:0)|0|268435456|0)}
function Uh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ki(a,b){var c,d;d=a.a.length;b.length<d&&(b=fk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Ec(){var a;if(zc!=0){a=yc();if(a-Ac>2000){Ac=a;Bc=$wnd.setTimeout(Kc,10)}}if(zc++==0){Nc((Mc(),Lc));return true}return false}
function Vc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function El(a,b){var c;this.d=b;this.n=a;J();c=++Cl;this.b=new mc(c,null,new Fl(this),false,false);this.a=new vb(null,new Gl(this),Op)}
function mc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ti:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function jc(a){var b,c,d;for(c=new Ni(new Mi(new ui(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();jd(d,9)&&d.u()||b.ab().v()}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ni(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ni(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ni(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function q(a,b){return nd(a)?o(a,b):ld(a)?od(a)===od(b):kd(a)?od(a)===od(b):hd(a)?a.o(b):_c(a)?o(a,b):!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function Ak(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function ei(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function li(a,b){var c,d,e,f;f=si(a.a);b.length<f&&(b=fk(new Array(f),b));e=b;d=new xi(a.a);for(c=0;c<f;++c){e[c]=wi(d)}b.length>f&&(b[f]=null);return b}
function $c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=ah(a);if(jd(a,4)){e=a;throw bh(e)}else throw bh(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=ah(a);if(jd(a,4)){f=a;throw bh(f)}else throw bh(a)}finally{D(b)}}
function Jm(a,b,c,d){var e;this.d=b;this.e=c;this.f=d;this.n=a;J();e=++Hm;this.b=new mc(e,null,new Km(this),false,false);this.a=new vb(null,new Lm(this),Op)}
function Tl(a,b){var c,d,e;this.e=b;this.n=a;J();c=++Nl;this.c=new mc(c,null,new Ul(this),false,false);this.b=(e=new ib((d=null,d)),e);this.a=new vb(null,new Yl(this),Op)}
function mo(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++bo;this.c=new mc(c,null,new no(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function lh(b,c,d,e){kh();var f=ih;$moduleName=c;$moduleBase=d;_g=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{vp(g)()}catch(a){b(c,a)}}else{vp(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);Ap==(d&Bp)&&lb(this.f)}
function uk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function ej(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return fj()}}
function Bl(a){var b,c,d;a.c=0;ll();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),wk('span',Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,['todo-count'])),[wk('strong',null,[c]),' '+d+' left']));return b}
function oh(){nh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Rc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Qc(c,g)):g[0].qb()}catch(a){a=ah(a);if(jd(a,4)){d=a;Cc();Ic(jd(d,34)?d.H():d)}else throw bh(a)}}return c}
function Ml(a){var b;a.d=0;ll();b=wk(Qp,Ek(Hk(Ik(Lk(Jk(Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,['new-todo']))),(fb(a.b),a.f)),sh(nn.prototype.kb,nn,[a])),sh(on.prototype.jb,on,[a]))),null);return b}
function wc(a){var b;if(a.c==null){b=od(a.b)===od(uc)?null:a.b;a.d=b==null?Hp:md(b)?b==null?null:b.name:nd(b)?'String':Lh(r(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(od(e)===od(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=ah(a);if(jd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw bh(c)}else throw bh(a)}}
function bk(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Xi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ui(b,e);if(f){return f.bb(c)}}e[e.length]=new Bi(b,c);++a.b;return null}
function ul(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.n=a;J();e=++ql;this.c=new mc(e,null,new vl(this),false,false);this.a=new W(new wl(this),null,null,136478720);this.b=new vb(null,new xl(this),Op)}
function mk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ci(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=ah(a);if(jd(a,4)){J()}else throw bh(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Zc(ie,yp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Bh(a,b){var c;c=od(a)!==od(xh);if(c&&od(a)!==od(b)){throw bh(new Xh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}return b}
function ub(a,b,c,d){this.b=new Li;this.f=new Jb(new yb(this),d&6520832|262144|Ap);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Dp)&&D((null,I)))}
function Yi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Si(b,e._())){if(d.length==1){d.length=0;_i(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function wh(){var a;a=new In;new Pm(a.a.I(),a.b.I(),a.d.I());new Bn(a.a.I(),(a.b.I(),a.d.I()));new Gn(a.a.I(),a.b.I(),a.d.I());new qn(a.b.I());new Sm(a.a.I());$wnd.ReactDOM.render(vk([(new Fn).a]),(Eh(),Dh).getElementById('app'),null)}
function qh(a,b,c){var d=nh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=nh[b]),th(h));_.ob=c;!b&&(_.pb=vh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Th(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Uh('.',[c,Uh('$',d)]);a.b=Uh('.',[c,Uh('.',d)]);a.i=d[d.length-1]}
function Nn(a){var b;if(0==a.length){b=(Eh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Dh.title,b)}else{(Eh(),$wnd.goog.global.window).location.hash=a}}
function mi(a,b){var c,d,e;c=b._();e=b.ab();d=nd(c)?c==null?oi(Wi(a.a,null)):ij(a.b,c):oi(Wi(a.a,c));if(!(od(e)===od(d)||e!=null&&q(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!Wi(a.a,null):hj(a.b,c):!!Wi(a.a,c))){return false}return true}
function wk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;qk(b,sh(zk.prototype.hb,zk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Lp]=c[0],undefined):(d[Lp]=c,undefined));return tk(a,e,f,d)}
function sm(a,b,c){var d,e,f;this.j=b;this.k=c;this.n=a;J();d=++gm;this.e=new mc(d,null,new tm(this),false,false);this.a=(f=new ib((e=null,e)),f);this.c=new W(new zm(this),null,null,136478720);this.b=new vb(null,new Cm(this),Op);qm(this,this.n.props['a'])}
function Xo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new mc(0,null,new Yo(this),false,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new $o(this),null,null,Tp);this.c=new W(new _o(this),null,null,Tp);this.a=new vb(new ap(this),null,681574400);D((null,I))}
function xo(){var a;this.g=new Ti;J();this.f=new mc(0,new zo(this),new yo(this),false,false);this.d=(a=new ib(null),a);this.c=new W(new Co(this),null,null,Tp);this.e=new W(new Do(this),null,null,Tp);this.a=new W(new Eo(this),null,null,Tp);this.b=new W(new Fo(this),null,null,Tp)}
function Vn(){var a,b,c;this.d=new bp(this);this.f=this.e=(c=(Eh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new mc(0,null,new Wn(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new ao,new Xn(this),new Yn(this),35651584)}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ni(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=ah(a);if(!jd(a,4))throw bh(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function pc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function dj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}Ei(a.b,new Ab(a));a.b.a=Zc(ie,yp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Gm(a){var b;a.c=0;ll();b=wk('div',null,[wk('div',null,[wk(Rp,Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,[Rp])),[wk('h1',null,['todos']),(new pn).a]),S(a.d.c)?null:wk('section',Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,[Rp])),[wk(Qp,Hk(Kk(Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,['toggle-all'])),(hl(),Ok)),sh(Dn.prototype.jb,Dn,[a])),null),wk('ul',Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,['todo-list'])),Nj(Lj(S(a.f.c).W(),new En),new yk))]),S(a.d.c)?null:(new Om).a])]);return b}
function hl(){hl=rh;Nk=new il(Mp,0);Ok=new il('checkbox',1);Pk=new il('color',2);Qk=new il('date',3);Rk=new il('datetime',4);Sk=new il('email',5);Tk=new il('file',6);Uk=new il('hidden',7);Vk=new il('image',8);Wk=new il('month',9);Xk=new il(xp,10);Yk=new il('password',11);Zk=new il('radio',12);$k=new il('range',13);_k=new il('reset',14);al=new il('search',15);bl=new il('submit',16);cl=new il('tel',17);dl=new il('text',18);el=new il('time',19);fl=new il('url',20);gl=new il('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Fi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ji(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Fi(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Hi(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Li)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Ap!=(k.b.c&Bp)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function pl(a){var b,c;a.d=0;ll();c=(b=S(a.g.b),wk('footer',Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,['footer'])),[(new Rm).a,wk('ul',Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,['filters'])),[wk('li',null,[wk('a',Ck(Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,[(ip(),gp)==b?Np:null])),'#'),['All'])]),wk('li',null,[wk('a',Ck(Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,[fp==b?Np:null])),'#active'),['Active'])]),wk('li',null,[wk('a',Ck(Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,[hp==b?Np:null])),'#completed'),['Completed'])])]),S(a.a)?wk(Mp,Dk(Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,['clear-completed'])),sh(Nm.prototype.lb,Nm,[a])),['Clear Completed']):null]));return c}
function fm(a){var b,c,d,e;a.f=0;ll();b=a.n.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.n.props['a'],e=(fb(d.a),d.d),wk('li',Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[wk('div',Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,['view'])),[wk(Qp,Hk(Fk(Kk(Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,['toggle'])),(hl(),Ok)),e),sh(tn.prototype.jb,tn,[d])),null),wk('label',Mk(new $wnd.Object,sh(un.prototype.lb,un,[a,d])),[(fb(d.b),d.e)]),wk(Mp,Dk(Ak(new $wnd.Object,ad(Xc(le,1),yp,2,6,['destroy'])),sh(vn.prototype.lb,vn,[a,d])),null)]),wk(Qp,Ik(Hk(Gk(Lk(Ak(Bk(new $wnd.Object,sh(wn.prototype.w,wn,[a])),ad(Xc(le,1),yp,2,6,['edit'])),(fb(a.a),a.d)),sh(xn.prototype.ib,xn,[a,d])),sh(sn.prototype.jb,sn,[a])),sh(yn.prototype.kb,yn,[a,d])),null)]));return c}
function fj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Kp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!dj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Kp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var wp='object',xp='number',yp={3:1},zp={9:1},Ap=1048576,Bp=1835008,Cp={5:1},Dp=2097152,Ep=4194304,Fp='__noinit__',Gp={3:1,10:1,7:1,4:1},Hp='null',Ip=17592186044416,Jp={40:1},Kp='delete',Lp='children',Mp='button',Np='selected',Op=1411518464,Pp=142606336,Qp='input',Rp='header',Sp='hashchange',Tp=136314880,Up='active',Vp='completed';var _,nh,ih,_g=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;oh();qh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=Xp;_.r=function(){var a;return Lh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var dd,ed,fd;qh(55,1,{},Mh);_.K=function(a){var b;b=new Mh;b.e=4;a>1?(b.c=Rh(this,a-1)):(b.c=this);return b};_.L=function(){Kh(this);return this.b};_.M=function(){return Lh(this)};_.N=function(){Kh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Kh(this),this.k)};_.e=0;_.g=0;var Jh=1;var ie=Oh(1);var $d=Oh(55);qh(83,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var td=Oh(83);qh(35,1,{},G);_.s=function(){return this.a.v(),null};var rd=Oh(35);qh(84,1,{},H);var sd=Oh(84);var I;qh(42,1,{42:1},P);_.b=0;_.c=false;_.d=0;var ud=Oh(42);qh(233,1,zp);_.r=function(){var a;return Lh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var xd=Oh(233);qh(18,233,zp,W);_.t=function(){R(this)};_.u=Wp;_.a=false;_.d=0;_.k=false;var wd=Oh(18);qh(162,1,{},X);_.s=function(){return T(this.a)};var vd=Oh(162);qh(16,233,{9:1,16:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=Oh(16);qh(161,1,Cp,jb);_.v=function(){ab(this.a)};var yd=Oh(161);qh(17,233,{9:1,17:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Ed=Oh(17);qh(163,1,{},xb);_.v=function(){Q(this.a)};var Ad=Oh(163);qh(164,1,Cp,yb);_.v=function(){mb(this.a)};var Bd=Oh(164);qh(165,1,Cp,zb);_.v=function(){pb(this.a)};var Cd=Oh(165);qh(166,1,{},Ab);_.w=function(a){nb(this.a,a)};var Dd=Oh(166);qh(102,1,{},Db);_.a=0;_.b=0;_.c=0;var Fd=Oh(102);qh(167,1,zp,Fb);_.t=function(){Eb(this)};_.u=Wp;_.a=false;var Gd=Oh(167);qh(67,233,{9:1,67:1},Jb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Id=Oh(67);qh(101,1,{},Ob);var Hd=Oh(101);qh(171,1,{},$b);_.r=function(){var a;return Kh(Jd),Jd.k+'@'+(a=hk(this)>>>0,a.toString(16))};_.a=0;var Pb;var Jd=Oh(171);qh(143,1,{});var Md=Oh(143);qh(107,1,{},ec);_.w=function(a){cc(this.a,a)};var Kd=Oh(107);qh(108,1,Cp,fc);_.v=function(){dc(this.a,this.b)};var Ld=Oh(108);qh(15,1,zp,mc);_.t=function(){hc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Kh(Od),Od.k+'@'+(a=hk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Od=Oh(15);qh(153,1,Cp,nc);_.v=function(){kc(this.a)};var Nd=Oh(153);qh(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=aq;_.C=function(){return Nj(Lj(Pi((this.i==null&&(this.i=Zc(ne,yp,4,0,0,1)),this.i)),new ii),new Rj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){qc(this,sc(this.A(rc(this,this.g))));Uc(this)};_.r=function(){return rc(this,this.F())};_.e=Fp;_.j=true;var ne=Oh(4);qh(10,4,{3:1,10:1,4:1});var be=Oh(10);qh(7,10,Gp);var je=Oh(7);qh(56,7,Gp);var fe=Oh(56);qh(78,56,Gp);var Sd=Oh(78);qh(34,78,{34:1,3:1,10:1,7:1,4:1},xc);_.F=function(){wc(this);return this.c};_.H=function(){return od(this.b)===od(uc)?null:this.b};var uc;var Pd=Oh(34);var Qd=Oh(0);qh(215,1,{});var Rd=Oh(215);var zc=0,Ac=0,Bc=-1;qh(92,215,{},Pc);var Lc;var Td=Oh(92);var Sc;qh(226,1,{});var Vd=Oh(226);qh(79,226,{},Wc);var Ud=Oh(79);qh(43,1,{43:1},zh);_.I=function(){var a;a=this.a;if(od(a)===od(xh)){a=this.a;if(od(a)===od(xh)){a=this.b.I();this.a=Bh(this.a,a);this.b=null}}return a};var xh;var Wd=Oh(43);var Dh;qh(76,1,{73:1});_.r=Wp;var Xd=Oh(76);qh(80,7,Gp);var de=Oh(80);qh(126,80,Gp,Hh);var Yd=Oh(126);dd={3:1,74:1,27:1};var Zd=Oh(74);qh(41,1,{3:1,41:1});var he=Oh(41);ed={3:1,27:1,41:1};var _d=Oh(225);qh(29,1,{3:1,27:1,29:1});_.o=cq;_.q=Xp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ae=Oh(29);qh(58,7,Gp,Xh);var ce=Oh(58);qh(28,41,{3:1,27:1,28:1,41:1},Yh);_.o=function(a){return jd(a,28)&&a.a==this.a};_.q=Wp;_.r=function(){return ''+this.a};_.a=0;var ee=Oh(28);var $h;qh(290,1,{});qh(81,56,Gp,bi);_.A=function(a){return new TypeError(a)};var ge=Oh(81);fd={3:1,73:1,27:1,2:1};var le=Oh(2);qh(77,76,{73:1},hi);var ke=Oh(77);qh(294,1,{});qh(71,1,{},ii);_.S=function(a){return a.e};var me=Oh(71);qh(59,7,Gp,ji);var oe=Oh(59);qh(227,1,{39:1});_.Q=_p;_.V=function(){return new Aj(this,0)};_.W=function(){return new Oj(null,this.V())};_.T=function(a){throw bh(new ji('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Cj('[',']');for(b=this.R();b.Y();){a=b.Z();Bj(c,a===this?'(this Collection)':a==null?Hp:uh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=Oh(227);qh(230,1,{213:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!jd(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new xi((new ui(d)).a);c.b;){b=wi(c);if(!mi(this,b)){return false}}return true};_.q=function(){return Qi(new ui(this))};_.r=function(){var a,b,c;c=new Cj('{','}');for(b=new xi((new ui(this)).a);b.b;){a=wi(b);Bj(c,ni(this,a._())+'='+ni(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=Oh(230);qh(100,230,{213:1});var se=Oh(100);qh(229,227,{39:1,237:1});_.V=function(){return new Aj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!jd(a,21)){return false}b=a;if(si(b.a)!=this.U()){return false}return ki(this,b)};_.q=function(){return Qi(this)};var Be=Oh(229);qh(21,229,{21:1,39:1,237:1},ui);_.R=function(){return new xi(this.a)};_.U=Zp;var re=Oh(21);qh(22,1,{},xi);_.X=Yp;_.Z=function(){return wi(this)};_.Y=$p;_.b=false;var qe=Oh(22);qh(228,227,{39:1,234:1});_.V=function(){return new Aj(this,16)};_.$=function(a,b){throw bh(new ji('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,13)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Ni(f);for(c=new Ni(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Ri(this)};_.R=function(){return new yi(this)};var ue=Oh(228);qh(91,1,{},yi);_.X=Yp;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Fi(this.b,this.a++)};_.a=0;var te=Oh(91);qh(60,227,{39:1},zi);_.R=function(){var a;a=new xi((new ui(this.a)).a);return new Ai(a)};_.U=Zp;var we=Oh(60);qh(95,1,{},Ai);_.X=Yp;_.Y=function(){return this.a.b};_.Z=function(){var a;a=wi(this.a);return a.ab()};var ve=Oh(95);qh(93,1,Jp);_.o=function(a){var b;if(!jd(a,40)){return false}b=a;return Si(this.a,b._())&&Si(this.b,b.ab())};_._=Wp;_.ab=$p;_.q=function(){return rj(this.a)^rj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var xe=Oh(93);qh(94,93,Jp,Bi);var ye=Oh(94);qh(231,1,Jp);_.o=function(a){var b;if(!jd(a,40)){return false}b=a;return Si(this.b.value[0],b._())&&Si(nj(this),b.ab())};_.q=function(){return rj(this.b.value[0])^rj(nj(this))};_.r=function(){return this.b.value[0]+'='+nj(this)};var ze=Oh(231);qh(13,228,{3:1,13:1,39:1,234:1},Li,Mi);_.$=function(a,b){ck(this.a,a,b)};_.T=function(a){return Di(this,a)};_.Q=function(a){Ei(this,a)};_.R=function(){return new Ni(this)};_.U=function(){return this.a.length};var De=Oh(13);qh(14,1,{},Ni);_.X=Yp;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=Oh(14);qh(36,100,{3:1,36:1,213:1},Ti);var Ee=Oh(36);qh(63,1,{},Zi);_.Q=_p;_.R=function(){return new $i(this)};_.b=0;var Ge=Oh(63);qh(64,1,{},$i);_.X=Yp;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=Oh(64);var bj;qh(61,1,{},lj);_.Q=_p;_.R=function(){return new mj(this)};_.b=0;_.c=0;var Je=Oh(61);qh(62,1,{},mj);_.X=Yp;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new oj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var He=Oh(62);qh(114,231,Jp,oj);_._=function(){return this.b.value[0]};_.ab=function(){return nj(this)};_.bb=function(a){return jj(this.a,this.b.value[0],a)};_.c=0;var Ie=Oh(114);qh(116,1,{});_.X=bq;_.cb=function(){return this.d};_.db=aq;_.d=0;_.e=0;var Ne=Oh(116);qh(65,116,{});var Ke=Oh(65);qh(96,1,{});_.X=bq;_.cb=$p;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Me=Oh(96);qh(97,96,{},yj);_.X=function(a){vj(this,a)};_.eb=function(a){return wj(this,a)};var Le=Oh(97);qh(20,1,{},Aj);_.cb=Wp;_.db=function(){zj(this);return this.c};_.X=function(a){zj(this);this.d.X(a)};_.eb=function(a){zj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Oe=Oh(20);qh(57,1,{},Cj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Pe=Oh(57);qh(33,1,{},Dj);_.S=function(a){return a};var Qe=Oh(33);qh(37,1,{},Ej);var Re=Oh(37);qh(115,1,{});_.c=false;var _e=Oh(115);qh(25,115,{},Oj);var $e=Oh(25);qh(72,1,{},Rj);_.fb=function(a){return Zc(ie,yp,1,a,5,1)};var Se=Oh(72);qh(118,65,{},Tj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Uj(this,a)));return this.b};_.b=false;var Ue=Oh(118);qh(121,1,{},Uj);_.w=function(a){Sj(this.a,this.b,a)};var Te=Oh(121);qh(117,65,{},Wj);_.eb=function(a){return this.b.eb(new Xj(this,a))};var We=Oh(117);qh(120,1,{},Xj);_.w=function(a){Vj(this.a,this.b,a)};var Ve=Oh(120);qh(119,1,{},Zj);_.w=function(a){Yj(this,a)};var Xe=Oh(119);qh(122,1,{},$j);_.w=function(a){};var Ye=Oh(122);qh(123,1,{},ak);_.w=function(a){_j(this,a)};var Ze=Oh(123);qh(292,1,{});qh(289,1,{});var gk=0;var ik,jk=0,kk;qh(906,1,{});qh(927,1,{});qh(232,1,{});var af=Oh(232);qh(168,1,{},yk);_.fb=function(a){return new Array(a)};var bf=Oh(168);qh(257,$wnd.Function,{},zk);_.hb=function(a){xk(this.a,this.b,a)};qh(6,29,{3:1,27:1,29:1,6:1},il);var Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl;var cf=Ph(6,jl);var kl;qh(256,$wnd.Function,{},ml);_.J=function(a){return Eb(kl),kl=null,null};qh(185,232,{});var Nf=Oh(185);qh(186,185,{});_.d=0;var Rf=Oh(186);qh(187,186,zp,ul);_.t=dq;_.o=cq;_.q=Xp;_.u=eq;_.r=function(){var a;return Kh(mf),mf.k+'@'+(a=hk(this)>>>0,a.toString(16))};var ql=0;var mf=Oh(187);qh(188,1,Cp,vl);_.v=function(){rl(this.a)};var df=Oh(188);qh(189,1,{},wl);_.s=function(){return sl(this.a)};var ef=Oh(189);qh(190,1,{},xl);_.v=function(){ol(this.a)};var ff=Oh(190);qh(191,1,{},yl);_.s=function(){return pl(this.a)};var gf=Oh(191);qh(206,232,{});var Mf=Oh(206);qh(207,206,{});_.c=0;var Qf=Oh(207);qh(208,207,zp,El);_.t=fq;_.o=cq;_.q=Xp;_.u=gq;_.r=function(){var a;return Kh(lf),lf.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Cl=0;var lf=Oh(208);qh(209,1,Cp,Fl);_.v=hq;var hf=Oh(209);qh(210,1,{},Gl);_.v=function(){Al(this.a)};var jf=Oh(210);qh(211,1,{},Hl);_.s=function(){return Bl(this.a)};var kf=Oh(211);qh(177,232,{});_.f='';var $f=Oh(177);qh(178,177,{});_.d=0;var Tf=Oh(178);qh(179,178,zp,Tl);_.t=dq;_.o=cq;_.q=Xp;_.u=eq;_.r=function(){var a;return Kh(sf),sf.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Nl=0;var sf=Oh(179);qh(180,1,Cp,Ul);_.v=function(){Ol(this.a)};var nf=Oh(180);qh(182,1,{},Vl);_.s=function(){return Ml(this.a)};var of=Oh(182);qh(183,1,Cp,Wl);_.v=function(){Il(this.a)};var pf=Oh(183);qh(184,1,Cp,Xl);_.v=function(){Ql(this.a,this.b)};var qf=Oh(184);qh(181,1,{},Yl);_.v=function(){ol(this.a)};var rf=Oh(181);qh(173,232,{});_.i=false;var bg=Oh(173);qh(193,173,{});_.f=0;var Vf=Oh(193);qh(194,193,zp,sm);_.t=function(){hc(this.e)};_.o=cq;_.q=Xp;_.u=function(){return this.e.i<0};_.r=function(){var a;return Kh(Df),Df.k+'@'+(a=hk(this)>>>0,a.toString(16))};var gm=0;var Df=Oh(194);qh(195,1,Cp,tm);_.v=function(){hm(this.a)};var tf=Oh(195);qh(198,1,{},um);_.s=function(){return fm(this.a)};var uf=Oh(198);qh(48,1,Cp,vm);_.v=function(){rm(this.a,Rn(this.b))};var vf=Oh(48);qh(68,1,Cp,wm);_.v=function(){bm(this.a,this.b)};var wf=Oh(68);qh(199,1,Cp,xm);_.v=function(){jm(this.a,this.b)};var xf=Oh(199);qh(200,1,Cp,ym);_.v=function(){km(this.a,this.b)};var yf=Oh(200);qh(196,1,{},zm);_.s=function(){return lm(this.a)};var zf=Oh(196);qh(201,1,Cp,Am);_.v=function(){Zl(this.a,this.b)};var Af=Oh(201);qh(202,1,Cp,Bm);_.v=function(){cm(this.a)};var Bf=Oh(202);qh(197,1,{},Cm);_.v=function(){em(this.a)};var Cf=Oh(197);qh(137,232,{});var fg=Oh(137);qh(138,137,{});_.c=0;var Xf=Oh(138);qh(139,138,zp,Jm);_.t=fq;_.o=cq;_.q=Xp;_.u=gq;_.r=function(){var a;return Kh(Hf),Hf.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Hm=0;var Hf=Oh(139);qh(140,1,Cp,Km);_.v=hq;var Ef=Oh(140);qh(141,1,{},Lm);_.v=function(){Al(this.a)};var Ff=Oh(141);qh(142,1,{},Mm);_.s=function(){return Gm(this.a)};var Gf=Oh(142);qh(261,$wnd.Function,{},Nm);_.lb=function(a){Io(this.a.f)};qh(170,1,{},Om);var If=Oh(170);qh(86,1,{},Pm);var Jf=Oh(86);var Qm;qh(192,1,{},Rm);var Kf=Oh(192);qh(90,1,{},Sm);var Lf=Oh(90);var Tm;qh(262,$wnd.Function,{},Um);_.mb=function(a){return new Xm(a)};var Vm;qh(175,$wnd.React.Component,{},Xm);ph(nh[1],_);_.componentWillUnmount=function(){nl(this.a)};_.render=function(){return tl(this.a)};_.shouldComponentUpdate=iq;var Of=Oh(175);qh(273,$wnd.Function,{},Ym);_.mb=function(a){return new _m(a)};var Zm;qh(203,$wnd.React.Component,{},_m);ph(nh[1],_);_.componentWillUnmount=function(){zl(this.a)};_.render=function(){return Dl(this.a)};_.shouldComponentUpdate=jq;var Pf=Oh(203);qh(260,$wnd.Function,{},an);_.mb=function(a){return new dn(a)};var bn;qh(174,$wnd.React.Component,{},dn);ph(nh[1],_);_.componentWillUnmount=function(){nl(this.a)};_.render=function(){return Rl(this.a)};_.shouldComponentUpdate=iq;var Sf=Oh(174);qh(263,$wnd.Function,{},en);_.mb=function(a){return new hn(a)};var fn;qh(176,$wnd.React.Component,{},hn);ph(nh[1],_);_.componentDidUpdate=function(a){om(this.a)};_.componentWillUnmount=function(){dm(this.a)};_.render=function(){return pm(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Uf=Oh(176);qh(255,$wnd.Function,{},jn);_.mb=function(a){return new mn(a)};var kn;qh(98,$wnd.React.Component,{},mn);ph(nh[1],_);_.componentWillUnmount=function(){zl(this.a)};_.render=function(){return Im(this.a)};_.shouldComponentUpdate=jq;var Wf=Oh(98);qh(258,$wnd.Function,{},nn);_.kb=function(a){Jl(this.a,a)};qh(259,$wnd.Function,{},on);_.jb=function(a){Pl(this.a,a)};qh(169,1,{},pn);var Yf=Oh(169);qh(89,1,{},qn);var Zf=Oh(89);var rn;qh(270,$wnd.Function,{},sn);_.jb=function(a){im(this.a,a)};qh(264,$wnd.Function,{},tn);_.jb=function(a){lo(this.a)};qh(266,$wnd.Function,{},un);_.lb=function(a){mm(this.a,this.b)};qh(267,$wnd.Function,{},vn);_.lb=function(a){$l(this.a,this.b)};qh(268,$wnd.Function,{},wn);_.w=function(a){_l(this.a,a)};qh(269,$wnd.Function,{},xn);_.ib=function(a){nm(this.a,this.b)};qh(271,$wnd.Function,{},yn);_.kb=function(a){am(this.a,this.b,a)};qh(172,1,{},An);var _f=Oh(172);qh(87,1,{},Bn);var ag=Oh(87);var Cn;qh(254,$wnd.Function,{},Dn);_.jb=function(a){Dm(this.a,a)};qh(99,1,{},En);_.S=function(a){return zn(new An,a)};var cg=Oh(99);qh(70,1,{},Fn);var dg=Oh(70);qh(88,1,{},Gn);var eg=Oh(88);var Hn;qh(85,1,{},In);var gg=Oh(85);qh(47,1,{47:1});var Ng=Oh(47);qh(154,47,{9:1,47:1},Vn);_.t=dq;_.o=cq;_.q=Xp;_.u=eq;_.r=function(){var a;return Kh(og),og.k+'@'+(a=hk(this)>>>0,a.toString(16))};var og=Oh(154);qh(155,1,Cp,Wn);_.v=function(){Pn(this.a)};var hg=Oh(155);qh(157,1,{},Xn);_.v=function(){Kn(this.a)};var ig=Oh(157);qh(158,1,{},Yn);_.v=function(){Ln(this.a)};var jg=Oh(158);qh(159,1,Cp,Zn);_.v=function(){Jn(this.a,this.b)};var kg=Oh(159);qh(160,1,Cp,$n);_.v=function(){Sn(this.a)};var lg=Oh(160);qh(66,1,Cp,_n);_.v=function(){On(this.a)};var mg=Oh(66);qh(156,1,{},ao);_.s=function(){var a;return a=(Eh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var ng=Oh(156);qh(49,1,{49:1});_.d=false;var Xg=Oh(49);qh(50,49,{9:1,272:1,50:1,49:1},mo);_.t=dq;_.o=function(a){return fo(this,a)};_.q=function(){return this.c.d};_.u=eq;_.r=function(){var a;return Kh(Eg),Eg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var bo=0;var Eg=Oh(50);qh(204,1,Cp,no);_.v=function(){co(this.a)};var pg=Oh(204);qh(205,1,Cp,oo);_.v=function(){io(this.a)};var qg=Oh(205);qh(46,143,{46:1});var Rg=Oh(46);qh(144,46,{9:1,46:1},xo);_.t=kq;_.o=cq;_.q=Xp;_.u=lq;_.r=function(){var a;return Kh(zg),zg.k+'@'+(a=hk(this)>>>0,a.toString(16))};var zg=Oh(144);qh(146,1,Cp,yo);_.v=function(){qo(this.a)};var rg=Oh(146);qh(145,1,Cp,zo);_.v=function(){uo(this.a)};var sg=Oh(145);qh(151,1,Cp,Ao);_.v=function(){bc(this.a,this.b,true)};var tg=Oh(151);qh(152,1,{},Bo);_.s=function(){return po(this.a,this.c,this.b)};_.b=false;var ug=Oh(152);qh(147,1,{},Co);_.s=function(){return vo(this.a)};var vg=Oh(147);qh(148,1,{},Do);_.s=function(){return Zh(hh(Jj(to(this.a))))};var wg=Oh(148);qh(149,1,{},Eo);_.s=function(){return Zh(hh(Jj(Kj(to(this.a),new op))))};var xg=Oh(149);qh(150,1,{},Fo);_.s=function(){return wo(this.a)};var yg=Oh(150);qh(44,1,{44:1});var Wg=Oh(44);qh(127,44,{9:1,44:1},Mo);_.t=function(){hc(this.a)};_.o=cq;_.q=Xp;_.u=function(){return this.a.i<0};_.r=function(){var a;return Kh(Dg),Dg.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Dg=Oh(127);qh(128,1,Cp,No);_.v=function(){Jo(this.a,this.b)};_.b=false;var Ag=Oh(128);qh(129,1,Cp,Oo);_.v=function(){Un(this.b,this.a)};var Bg=Oh(129);qh(130,1,Cp,Po);_.v=function(){Ko(this.a)};var Cg=Oh(130);qh(45,1,{45:1});var $g=Oh(45);qh(131,45,{9:1,45:1},Xo);_.t=kq;_.o=cq;_.q=Xp;_.u=lq;_.r=function(){var a;return Kh(Kg),Kg.k+'@'+(a=hk(this)>>>0,a.toString(16))};var Kg=Oh(131);qh(132,1,Cp,Yo);_.v=function(){So(this.a)};var Fg=Oh(132);qh(136,1,Cp,Zo);_.v=function(){Wo(this.a,null)};var Gg=Oh(136);qh(133,1,{},$o);_.s=function(){var a;return a=Rn(this.a.g),o(Up,a)?(ip(),fp):o(Vp,a)?(ip(),hp):(ip(),gp)};var Hg=Oh(133);qh(134,1,{},_o);_.s=function(){return Uo(this.a)};var Ig=Oh(134);qh(135,1,{},ap);_.v=function(){Vo(this.a)};var Jg=Oh(135);qh(125,1,{},bp);_.handleEvent=function(a){Mn(this.a,a)};var Lg=Oh(125);qh(105,1,{},cp);_.I=function(){return new Vn};var Mg=Oh(105);var dp;qh(30,29,{3:1,27:1,29:1,30:1},jp);var fp,gp,hp;var Og=Ph(30,kp);qh(103,1,{},lp);_.I=function(){return new xo};var Pg=Oh(103);var mp;qh(109,1,{},op);_.gb=function(a){return !ho(a)};var Qg=Oh(109);qh(111,1,{},pp);_.gb=function(a){return ho(a)};var Sg=Oh(111);qh(112,1,{},qp);_.w=function(a){so(this.a,a)};var Tg=Oh(112);qh(110,1,{},rp);_.w=function(a){Ho(this.a,a)};_.a=false;var Ug=Oh(110);qh(104,1,{},sp);_.I=function(){return new Mo(this.a.I())};var Vg=Oh(104);qh(113,1,{},tp);_.gb=function(a){return Ro(this.a,a)};var Yg=Oh(113);qh(106,1,{},up);_.I=function(){return new Xo(this.b.I(),this.a.I())};var Zg=Oh(106);var qd=Qh('D');var vp=(Cc(),Fc);var gwtOnLoad=gwtOnLoad=lh;jh(wh);mh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();