function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='1A16E0AA3FD497C37C4F404116BD0F50',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '1A16E0AA3FD497C37C4F404116BD0F50';function p(){}
function wh(){}
function sh(){}
function Fb(){}
function Rc(){}
function Yc(){}
function ji(){}
function Ej(){}
function Sj(){}
function $j(){}
function _j(){}
function zk(){}
function nl(){}
function Vm(){}
function Zm(){}
function bn(){}
function fn(){}
function kn(){}
function Fn(){}
function bo(){}
function cp(){}
function lp(){}
function mp(){}
function pp(){}
function Wc(a){Vc()}
function Jh(){Jh=sh}
function Mi(){Di(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Ai(a){this.a=a}
function ii(a){this.a=a}
function vi(a){this.a=a}
function Bi(a){this.a=a}
function gc(a){this.a=a}
function pc(a){this.a=a}
function Zh(a){this.a=a}
function Fj(a){this.a=a}
function bk(a){this.a=a}
function wl(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function Gl(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Vl(a){this.a=a}
function Wl(a){this.a=a}
function Xl(a){this.a=a}
function Zl(a){this.a=a}
function um(a){this.a=a}
function vm(a){this.a=a}
function Am(a){this.a=a}
function Cm(a){this.a=a}
function Dm(a){this.a=a}
function Lm(a){this.a=a}
function Mm(a){this.a=a}
function Nm(a){this.a=a}
function Om(a){this.a=a}
function Oi(a){this.c=a}
function zi(a){this.b=a}
function on(a){this.a=a}
function pn(a){this.a=a}
function tn(a){this.a=a}
function un(a){this.a=a}
function xn(a){this.a=a}
function En(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function oo(a){this.a=a}
function po(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Eo(a){this.a=a}
function Fo(a){this.a=a}
function Po(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function np(a){this.a=a}
function op(a){this.a=a}
function qp(a){this.a=a}
function rp(a){this.a=a}
function Zj(a,b){a.a=b}
function qb(a,b){a.b=b}
function sk(a,b){a.key=b}
function rk(a,b){qk(a,b)}
function Ho(a,b){sm(b,a)}
function Y(a){!!a&&$(a)}
function kc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function Vp(a){qj(this,a)}
function $p(a){tj(this,a)}
function Yp(a){bi(this,a)}
function aq(){jc(this.c)}
function cq(){jc(this.b)}
function hq(){jc(this.f)}
function $i(){this.a=hj()}
function mj(){this.a=hj()}
function eq(){kb(this.a.a)}
function eb(a){Yb((J(),a))}
function db(a){Xb((J(),a))}
function hb(a){Zb((J(),a))}
function dh(a){return a.e}
function Tp(){return this.a}
function Xp(){return this.b}
function Zp(){return this.e}
function J(){J=sh;I=new F}
function xc(){xc=sh;wc=new p}
function zh(){zh=sh;yh=new p}
function dj(){dj=sh;cj=fj()}
function ol(a){a.d=2;jc(a.c)}
function Al(a){a.c=2;jc(a.b)}
function em(a){a.f=2;jc(a.e)}
function eo(a){$(a.b);$(a.a)}
function Qn(a){R(a.a);$(a.b)}
function Pl(a){kb(a.a);$(a.b)}
function sl(a){kb(a.b);R(a.a)}
function ak(a,b){Rj(a.a,b)}
function nc(a,b){ri(a.e,b)}
function _l(a,b){to(a.j,b)}
function Go(a,b){so(a.b,b)}
function C(a,b){Nb(a.f,b.f)}
function ic(a,b,c){qi(a.e,b,c)}
function K(a,b){O(a);L(a,b)}
function sc(a,b){a.e=b;rc(a,b)}
function fk(a,b){a.splice(b,1)}
function fo(a,b,c){ic(a.c,b,c)}
function yj(a,b,c){b.w(a.a[c])}
function Gi(a,b){return a.a[b]}
function am(a,b){return a.g=b}
function _p(a){return this===a}
function Up(){return ik(this)}
function Zc(a,b){return Sh(a,b)}
function Mh(a){Lh(a);return a.k}
function Ih(a){vc.call(this,a)}
function Yh(a){vc.call(this,a)}
function ki(a){vc.call(this,a)}
function ci(){qc(this);this.G()}
function Wp(){return ti(this.a)}
function bq(){return this.c.i<0}
function dq(){return this.b.i<0}
function iq(){return this.f.i<0}
function hj(){dj();return new cj}
function Qj(a,b){a.T(b);return a}
function tj(a,b){while(a.eb(b));}
function Rj(a,b){Zj(a,Qj(a.a,b))}
function Wj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function Oc(){Oc=sh;Nc=new Rc}
function ep(){ep=sh;dp=new cp}
function Ec(){Ec=sh;!!(Vc(),Uc)}
function Mc(){Bc!=0&&(Bc=0);Dc=-1}
function ab(a){J();Yb(a);a.e=-2}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function T(a){mb(a.f);return V(a)}
function To(a){fb(a.d);return a.e}
function Sn(a){fb(a.b);return a.e}
function io(a){fb(a.a);return a.d}
function Ck(a,b){a.ref=b;return a}
function hc(a,b){this.a=a;this.b=b}
function Xh(a,b){this.a=a;this.b=b}
function Ci(a,b){this.a=a;this.b=b}
function Vj(a,b){this.a=a;this.b=b}
function Yj(a,b){this.a=a;this.b=b}
function Ah(a){this.a=yh;this.b=a}
function Ak(a,b){this.a=a;this.b=b}
function Db(a){this.d=a;this.b=100}
function Tm(a){this.a=a;Um=this}
function rn(a){this.a=a;sn=this}
function Yl(a,b){this.a=a;this.b=b}
function wm(a,b){this.a=a;this.b=b}
function xm(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function zm(a,b){this.a=a;this.b=b}
function Bm(a,b){this.a=a;this.b=b}
function jl(a,b){Xh.call(this,a,b)}
function jj(a,b){return a.a.get(b)}
function ti(a){return a.a.b+a.b.b}
function fq(a){return 1==this.a.d}
function gq(a){return 1==this.a.c}
function vn(a,b){this.a=a;this.b=b}
function wn(a,b){this.a=a;this.b=b}
function yn(a,b){this.a=a;this.b=b}
function zn(a,b){this.a=a;this.b=b}
function $n(a,b){this.a=a;this.b=b}
function Ao(a,b){this.a=a;this.b=b}
function No(a,b){this.a=a;this.b=b}
function Oo(a,b){this.b=a;this.a=b}
function jp(a,b){Xh.call(this,a,b)}
function dk(a,b,c){a.splice(b,0,c)}
function Dk(a,b){a.href=b;return a}
function gi(a,b){a.a+=''+b;return a}
function Mk(a,b){a.value=b;return a}
function Lc(a){$wnd.clearTimeout(a)}
function Pm(){this.a=tk((Xm(),Wm))}
function Sm(){this.a=tk((_m(),$m))}
function qn(){this.a=tk((dn(),cn))}
function Bn(){this.a=tk((hn(),gn))}
function Gn(){this.a=tk((mn(),ln))}
function Tn(a){Rn(a,(fb(a.b),a.e))}
function jo(a){sm(a,(fb(a.a),!a.d))}
function Tb(a){return !a.d?a:Tb(a.d)}
function pi(a){return !a?null:a.ab()}
function sj(a){return a!=null?s(a):0}
function qd(a){return a==null?null:a}
function nd(a){return typeof a===up}
function o(a,b){return qd(a)===qd(b)}
function ek(a,b){ck(b,0,a,0,b.length)}
function Hk(a,b){a.onBlur=b;return a}
function Ek(a,b){a.onClick=b;return a}
function Gk(a,b){a.checked=b;return a}
function Di(a){a.a=_c(ke,vp,1,0,5,1)}
function si(a){a.a=new $i;a.b=new mj}
function ib(a){this.c=new Mi;this.b=a}
function mk(){mk=sh;jk=new p;lk=new p}
function lh(){jh==null&&(jh=[])}
function im(a){kb(a.b);R(a.c);$(a.a)}
function fc(a,b){bc(a,b,false);eb(a.c)}
function qk(a,b){for(var c in a){b(c)}}
function Jo(a,b){Fi(dc(a.b),new op(b))}
function di(a,b){return a.charCodeAt(b)}
function B(a,b,c){return u(a,c,2048,b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function ld(a,b){return a!=null&&jd(a,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function ik(a){return a.$H||(a.$H=++hk)}
function pd(a){return typeof a==='string'}
function pb(a){J();ob(a);sb(a,2,true)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function ec(a,b){nc(b.c,a);ld(b,9)&&b.t()}
function vc(a){this.g=a;qc(this);this.G()}
function Pj(a,b){Ij.call(this,a);this.a=b}
function Ik(a,b){a.onChange=b;return a}
function Jk(a,b){a.onKeyDown=b;return a}
function Fk(a){a.autoFocus=true;return a}
function Lh(a){if(a.k!=null){return}Uh(a)}
function Un(a){A((J(),J(),I),new _n(a),Mp)}
function pm(a){A((J(),J(),I),new Cm(a),Mp)}
function mo(a){A((J(),J(),I),new po(a),Mp)}
function Io(a){A((J(),J(),I),new Po(a),Mp)}
function A(a,b,c){u(a,new G(b),c,null)}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function aj(a,b){var c;c=a[Hp];c.call(a,b)}
function So(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function wo(a){return $h(S(a.e).a-S(a.a).a)}
function md(a){return typeof a==='boolean'}
function Fc(a,b,c){return a.apply(b,c);var d}
function qj(a,b){while(a.Y()){ak(b,a.Z())}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function P(){this.a=_c(ke,vp,1,100,5,1)}
function ai(){ai=sh;_h=_c(ge,vp,29,256,0,1)}
function Ui(){this.a=new $i;this.b=new mj}
function Cn(a,b){this.a=a;this.b=b;Dn=this}
function pj(a,b,c){this.a=a;this.b=b;this.c=c}
function Nk(a,b){a.onDoubleClick=b;return a}
function Ei(a,b){a.a[a.a.length]=b;return true}
function qc(a){a.j&&a.e!==Cp&&a.G();return a}
function Ph(a){var b;b=Oh(a);Wh(a,b);return b}
function Vc(){Vc=sh;var a;!Xc();a=new Yc;Uc=a}
function Gh(a,b,c,d){a.addEventListener(b,c,d)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function Ql(a,b){A((J(),J(),I),new Yl(a,b),Mp)}
function jm(a,b){A((J(),J(),I),new Bm(a,b),Mp)}
function nm(a,b){A((J(),J(),I),new ym(a,b),Mp)}
function om(a,b){A((J(),J(),I),new xm(a,b),Mp)}
function rm(a,b){A((J(),J(),I),new wm(a,b),Mp)}
function to(a,b){A((J(),J(),I),new Ao(a,b),Mp)}
function Lo(a,b){A((J(),J(),I),new No(a,b),Mp)}
function wj(a,b){while(a.c<a.d){yj(a,b,a.c++)}}
function Aj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Dh(a){if(!a){throw dh(new ci)}return a}
function Rh(a){var b;b=Oh(a);b.j=a;b.e=1;return b}
function Rl(a,b){var c;c=b.target;Tl(a,c.value)}
function Jj(a,b){var c;return Nj(a,(c=new Mi,c))}
function Hh(a,b,c,d){a.removeEventListener(b,c,d)}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Bo(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function uo(a){bi(new Ai(a.g),new gc(a));si(a.g)}
function ro(a){R(a.d);R(a.e);R(a.a);R(a.b);$(a.c)}
function xi(a){var b;b=a.a.Z();a.b=wi(a);return b}
function Ii(a,b){var c;c=a.a[b];fk(a.a,b);return c}
function Sc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Pi(a,b){return uj(b,a.length),new zj(a,b)}
function ij(a,b){return !(a.a.get(b)===undefined)}
function Qo(a){return o(Rp,a)||o(Sp,a)||o('',a)}
function ul(a){return B((J(),J(),I),a.b,new zl(a))}
function vo(a){return Jh(),0!=S(a.e).a?true:false}
function tl(a){return Jh(),S(a.e.b).a>0?true:false}
function El(a){return B((J(),J(),I),a.a,new Il(a))}
function Sl(a){return B((J(),J(),I),a.a,new Wl(a))}
function qm(a){return B((J(),J(),I),a.b,new vm(a))}
function Jm(a){return B((J(),J(),I),a.a,new Nm(a))}
function Qi(a){return new Pj(null,Pi(a,a.length))}
function bd(a){return Array.isArray(a)&&a.pb===wh}
function kd(a){return !Array.isArray(a)&&a.pb===wh}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Bl(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function pl(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function fm(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Gj(a){if(!a.b){Hj(a);a.c=true}else{Gj(a.b)}}
function Tj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function Tl(a,b){var c;c=a.f;if(b!=c){a.f=b;eb(a.b)}}
function Vn(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function sm(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function Em(a,b){var c;c=b.target;Lo(a.e,c.checked)}
function Ki(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Lk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ui(a,b){if(b){return ni(a.a,b)}return false}
function Lj(a,b){Hj(a);return new Pj(a,new Uj(b,a.a))}
function Mj(a,b){Hj(a);return new Pj(a,new Xj(b,a.a))}
function Rn(a,b){A((J(),J(),I),new $n(a,b),75497472)}
function Ti(a,b){return qd(a)===qd(b)||a!=null&&q(a,b)}
function Pn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&Vn(a,b)}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function km(a,b){Wo(a.k,b);A((J(),J(),I),new wm(a,b),Mp)}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function zj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Qm(a,b,c){this.a=a;this.b=b;this.c=c;Rm=this}
function Hn(a,b,c){this.a=a;this.b=b;this.c=c;In=this}
function vj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Bj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Ij(a){if(!a){this.b=null;new Mi}else{this.b=a}}
function Th(a){if(a.P()){return null}var b=a.j;return oh[b]}
function ih(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function pk(){if(kk==256){jk=lk;lk=new p;kk=0}++kk}
function Fh(){Fh=sh;Eh=$wnd.goog.global.document}
function Qh(a,b){var c;c=Oh(a);Wh(a,c);c.e=b?8:0;return c}
function tc(a,b){var c;c=Mh(a.nb);return b==null?c:c+': '+b}
function $l(a,b){var c;if(S(a.c)){c=b.target;sm(a,c.value)}}
function bi(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function oi(a,b){return b===a?'(this Map)':b==null?Ep:vh(b)}
function kp(){ip();return cd(Zc(Qg,1),vp,31,0,[fp,hp,gp])}
function Kc(a){Ec();$wnd.setTimeout(function(){throw a},0)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Ap)&&D((null,I))}
function lm(a,b){A((J(),J(),I),new wm(a,b),Mp);Wo(a.k,null)}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function uh(a){function b(){}
;b.prototype=a||{};return new b}
function Kk(a){a.placeholder='What needs to be done?';return a}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function mm(a){return Jh(),To(a.k)==a.n.props['a']?true:false}
function Ln(a){Gh((Fh(),$wnd.goog.global.window),Pp,a.d,false)}
function Mn(a){Hh((Fh(),$wnd.goog.global.window),Pp,a.d,false)}
function hn(){hn=sh;var a;gn=(a=th(fn.prototype.mb,fn,[]),a)}
function dn(){dn=sh;var a;cn=(a=th(bn.prototype.mb,bn,[]),a)}
function mn(){mn=sh;var a;ln=(a=th(kn.prototype.mb,kn,[]),a)}
function Xm(){Xm=sh;var a;Wm=(a=th(Vm.prototype.mb,Vm,[]),a)}
function _m(){_m=sh;var a;$m=(a=th(Zm.prototype.mb,Zm,[]),a)}
function Ni(a){Di(this);ek(this.a,mi(a,_c(ke,vp,1,ti(a.a),5,1)))}
function cc(a){fb(a.c);return new Pj(null,new Bj(new Ai(a.g),0))}
function Nn(a,b){b.preventDefault();A((J(),J(),I),new ao(a),Mp)}
function Wi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Sh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function qh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Xi(a,b){var c;return Vi(b,Wi(a,b==null?0:(c=s(b),c|0)))}
function Ic(a,b,c){var d;d=Gc();try{return Fc(a,b,c)}finally{Jc(d)}}
function Bh(a){zh();Dh(a);if(ld(a,45)){return a}return new Ah(a)}
function xj(a,b){if(a.c<a.d){yj(a,b,a.c++);return true}return false}
function mc(a){kc(a.g);!!a.e&&lc(a);Y(a.a);Y(a.c);kc(a.b);kc(a.f)}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Xj(a,b){vj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function Uj(a,b){vj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function _i(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function nj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Mo(a){this.b=a;J();this.a=new oc(0,null,null,false,false)}
function Ko(a){Jj(Lj(cc(a.b),new mp),new Fj(new Ej)).Q(new np(a.b))}
function Kj(a){var b;Gj(a);b=0;while(a.a.eb(new _j)){b=eh(b,1)}return b}
function Nj(a,b){var c;Gj(a);c=new $j;c.a=b;a.a.X(new bk(c));return c.a}
function Cj(a,b){!a.a?(a.a=new ii(a.d)):gi(a.a,a.b);gi(a.a,b);return a}
function ri(a,b){return pd(b)?b==null?Zi(a.a,null):lj(a.b,b):Zi(a.a,b)}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Jc(a){a&&Qc((Oc(),Nc));--Bc;if(a){if(Dc!=-1){Lc(Dc);Dc=-1}}}
function Ib(b){try{mb(b.b.a)}catch(a){a=bh(a);if(!ld(a,4))throw dh(a)}}
function uc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Hc(b){Ec();return function(){return Ic(b,this,arguments);var a}}
function Ac(){if(Date.now){return Date.now()}return (new Date).getTime()}
function so(a,b){var c;return u((J(),J(),I),new Bo(a,b),Mp,(c=null,c))}
function Oj(a,b){var c;c=Jj(a,new Fj(new Ej));return Li(c,b.fb(c.a.length))}
function bb(a,b){var c,d;Ei(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Fi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Jl(a){var b;b=fi((fb(a.b),a.f));if(b.length>0){Go(a.e,b);Tl(a,'')}}
function Kn(a,b){a.f=b;o(b,S(a.a))&&Vn(a,b);On(b);A((J(),J(),I),new ao(a),Mp)}
function yk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function _c(a,b,c,d,e,f){var g;g=ad(e,d);e!=10&&cd(Zc(a,f),b,c,e,g);return g}
function Hi(a,b,c){for(;c<a.a.length;++c){if(Ti(b,a.a[c])){return c}}return -1}
function oj(a){if(a.a.c!=a.c){return jj(a.a,a.b.value[0])}return a.b.value[1]}
function yi(a){this.d=a;this.c=new nj(this.d.b);this.a=this.c;this.b=wi(this)}
function Dj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Jn(){this.a=Bh(new pp);this.b=Bh((ep(),dp));this.c=Bh(new rp(this.b))}
function an(a){$wnd.React.Component.call(this,a);this.a=new Fl(this,Um.a)}
function en(a){$wnd.React.Component.call(this,a);this.a=new Ul(this,sn.a)}
function jn(a){$wnd.React.Component.call(this,a);this.a=new tm(this,Dn.a,Dn.b)}
function Ro(a,b){return (ip(),gp)==a||(fp==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function qi(a,b,c){return pd(b)?b==null?Yi(a.a,null,c):kj(a.b,b,c):Yi(a.a,b,c)}
function gk(a,b){return $c(b)!=10&&cd(r(b),b.ob,b.__elementTypeId$,$c(b),a),a}
function $c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function wk(a){var b;return uk($wnd.React.StrictMode,null,null,(b={},b[Ip]=a,b))}
function Uo(a){var b;return b=S(a.b),Jj(Lj(cc(a.i),new qp(b)),new Fj(new Ej))}
function jc(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new pc(a)),67108864,null)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function V(a){if(a.b){if(ld(a.b,7)){throw dh(a.b)}else{throw dh(a.b)}}return a.n}
function go(a,b){var c;if(ld(b,51)){c=b;return a.c.d==c.c.d}else{return false}}
function Ji(a,b){var c;c=Hi(a,b,0);if(c==-1){return false}fk(a.a,c);return true}
function Ob(){var a;this.a=_c(wd,vp,44,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Pc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Tc(b,c)}while(a.a);a.a=c}}
function Qc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Tc(b,c)}while(a.b);a.b=c}}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Mi);Ei(a.b,b)}}}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function rb(b){if(b){try{b.v()}catch(a){a=bh(a);if(ld(a,4)){J()}else throw dh(a)}}}
function Wh(a,b){var c;if(!a){return}b.j=a;var d=Th(b);if(!d){oh[a]=[b];return}d.nb=b}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new Mi);a.c=c.c}b.d=true;Ei(a.c,b)}
function Oh(a){var b;b=new Nh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function th(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function uk(a,b,c,d){var e;e=vk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function lj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{aj(a.a,b);--a.b}return c}
function tk(a){var b;b=vk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Ri(a){var b,c,d;d=0;for(c=new yi(a.a);c.b;){b=xi(c);d=d+(b?s(b):0);d=d|0}return d}
function dc(a){return fb(a.c),Jj(new Pj(null,new Bj(new Ai(a.g),0)),new Fj(new Ej))}
function Kl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Xl(a),Mp)}}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Bp:0)|(0!=(b&229376)?0:98304)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:xp)|(0==(c&6291456)?!a?Ap:Bp:0)|0|0|0)}
function od(a){return a!=null&&(typeof a===tp||typeof a==='function')&&!(a.pb===wh)}
function nh(a,b){typeof window===tp&&typeof window['$gwt']===tp&&(window['$gwt'][a]=b)}
function nn(a){$wnd.React.Component.call(this,a);this.a=new Km(this,In.a,In.b,In.c)}
function Ym(a){$wnd.React.Component.call(this,a);this.a=new vl(this,Rm.a,Rm.b,Rm.c)}
function ob(a){var b,c;for(c=new Oi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function li(a,b){var c,d;for(d=new yi(b.a);d.b;){c=xi(d);if(!ui(a,c)){return false}}return true}
function qo(a,b,c){var d;d=new no(b,c);fo(d,a,new hc(a,d));qi(a.g,$h(d.c.d),d);eb(a.c);return d}
function bc(a,b,c){var d;d=ri(a.g,b?$h(b.c.d):null);if(null!=d){nc(b.c,a);c&&!!b&&jc(b.c);eb(a.c)}}
function An(a,b){sk(a.a,(b?$h(b.c.d):null)+(''+(Lh(dg),dg.k)));a.a.props['a']=b;return a.a}
function wi(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new _i(a.d.a);return a.a.Y()}
function bh(a){var b;if(ld(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new zc(a);Wc(b)}return b}
function fh(a){var b;b=a.h;if(b==0){return a.l+a.m*Bp}if(b==1048575){return a.l+a.m*Bp-Fp}return a}
function hh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Fp;d=1048575}c=rd(e/Bp);b=rd(e-c*Bp);return dd(b,c,d)}
function Vi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ti(a,c._())){return c}}return null}
function kh(){lh();var a=jh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function uj(a,b){if(0>a||a>b){throw dh(new Ih('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function ip(){ip=sh;fp=new jp('ACTIVE',0);hp=new jp('COMPLETED',1);gp=new jp('ALL',2)}
function bm(a,b,c){27==c.which?A((J(),J(),I),new zm(a,b),Mp):13==c.which&&A((J(),J(),I),new xm(a,b),Mp)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function ml(){if(!ll){ll=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(th(nl.prototype.J,nl,[]))}}
function Vo(a){var b;b=S(a.g.a);o(Rp,b)||o(Sp,b)||o('',b)?Rn(a.g,b):Qo(Sn(a.g))?Un(a.g):Rn(a.g,'')}
function Wo(a,b){var c;c=a.e;if(!(b==c||!!b&&go(b,c))){!!c&&nc(c.c,a);a.e=b;!!b&&fo(b,a,new Zo(a));eb(a.d)}}
function kj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function cd(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=wh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function zc(a){xc();qc(this);this.e=a;rc(this,a);this.g=a==null?Ep:vh(a);this.a='';this.b=a;this.a=''}
function Nh(){this.g=Kh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function $h(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ai(),_h)[b];!c&&(c=_h[b]=new Zh(a));return c}return new Zh(a)}
function vh(a){var b;if(Array.isArray(a)&&a.pb===wh){return Mh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function ok(a){mk();var b,c,d;c=':'+a;d=lk[c];if(d!=null){return rd(d)}d=jk[c];b=d==null?nk(a):rd(d);pk();lk[c]=b;return b}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function cb(a,b){var c,d;d=a.c;Ji(d,b);!!a.b&&xp!=(a.b.c&yp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function r(a){return pd(a)?ne:nd(a)?be:md(a)?_d:kd(a)?a.nb:bd(a)?a.nb:a.nb||Array.isArray(a)&&Zc(Sd,1)||Sd}
function s(a){return pd(a)?ok(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.q():bd(a)?ik(a):!!a&&!!a.hashCode?a.hashCode():ik(a)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&xp)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Hj(a){if(a.b){Hj(a.b)}else if(a.c){throw dh(new Yh("Stream already terminated, can't be modified or used"))}}
function dm(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;rm(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=Ii(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Si(a){var b,c,d;d=1;for(c=new Oi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function lc(a){var b,c,d;for(c=new Oi(new Ni(new vi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();ld(d,9)&&d.u()||b.ab().v()}}
function kl(){il();return cd(Zc(ef,1),vp,6,0,[Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl])}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(xp==(b&yp)?0:524288)|(0==(b&6291456)?xp==(b&yp)?Bp:Ap:0)|0|268435456|0)}
function eh(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<Fp){return c}}return fh(ed(nd(a)?hh(a):a,nd(b)?hh(b):b))}
function cm(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Oo(b,c),Mp);Wo(a.k,null);sm(a,c)}else{to(a.j,b)}}
function Vh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Li(a,b){var c,d;d=a.a.length;b.length<d&&(b=gk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Gc(){var a;if(Bc!=0){a=Ac();if(a-Cc>2000){Cc=a;Dc=$wnd.setTimeout(Mc,10)}}if(Bc++==0){Pc((Oc(),Nc));return true}return false}
function Xc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Fl(a,b){var c;this.d=b;this.n=a;J();c=++Dl;this.b=new oc(c,null,new Gl(this),false,false);this.a=new vb(null,new Hl(this),Lp)}
function oc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ui:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function q(a,b){return pd(a)?o(a,b):nd(a)?qd(a)===qd(b):md(a)?qd(a)===qd(b):kd(a)?a.o(b):bd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.ob){return !!a.ob[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function Bk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function fi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function mi(a,b){var c,d,e,f;f=ti(a.a);b.length<f&&(b=gk(new Array(f),b));e=b;d=new yi(a.a);for(c=0;c<f;++c){e[c]=xi(d)}b.length>f&&(b[f]=null);return b}
function ad(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=bh(a);if(ld(a,4)){e=a;throw dh(e)}else throw dh(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=bh(a);if(ld(a,4)){f=a;throw dh(f)}else throw dh(a)}finally{D(b)}}
function Km(a,b,c,d){var e;this.d=b;this.e=c;this.f=d;this.n=a;J();e=++Im;this.b=new oc(e,null,new Lm(this),false,false);this.a=new vb(null,new Mm(this),Lp)}
function Ul(a,b){var c,d,e;this.e=b;this.n=a;J();c=++Ol;this.c=new oc(c,null,new Vl(this),false,false);this.b=(e=new ib((d=null,d)),e);this.a=new vb(null,new Zl(this),Lp)}
function no(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++co;this.c=new oc(c,null,new oo(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function mh(b,c,d,e){lh();var f=jh;$moduleName=c;$moduleBase=d;ah=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{sp(g)()}catch(a){b(c,a)}}else{sp(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);xp==(d&yp)&&lb(this.f)}
function vk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function fj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return gj()}}
function Cl(a){var b,c,d;a.c=0;ml();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),xk('span',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['todo-count'])),[xk('strong',null,[c]),' '+d+' left']));return b}
function ph(){oh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Tc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Sc(c,g)):g[0].qb()}catch(a){a=bh(a);if(ld(a,4)){d=a;Ec();Kc(ld(d,35)?d.H():d)}else throw dh(a)}}return c}
function Nl(a){var b;a.d=0;ml();b=xk(Np,Fk(Ik(Jk(Mk(Kk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['new-todo']))),(fb(a.b),a.f)),th(on.prototype.kb,on,[a])),th(pn.prototype.jb,pn,[a]))),null);return b}
function yc(a){var b;if(a.c==null){b=qd(a.b)===qd(wc)?null:a.b;a.d=b==null?Ep:od(b)?b==null?null:b.name:pd(b)?'String':Mh(r(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(qd(e)===qd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=bh(a);if(ld(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw dh(c)}else throw dh(a)}}
function ck(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Yi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Vi(b,e);if(f){return f.bb(c)}}e[e.length]=new Ci(b,c);++a.b;return null}
function vl(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.n=a;J();e=++rl;this.c=new oc(e,null,new wl(this),false,false);this.a=new W(new xl(this),null,null,136478720);this.b=new vb(null,new yl(this),Lp)}
function nk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+di(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=bh(a);if(ld(a,4)){J()}else throw dh(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=_c(ke,vp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Ch(a,b){var c;c=qd(a)!==qd(yh);if(c&&qd(a)!==qd(b)){throw dh(new Yh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}return b}
function ub(a,b,c,d){this.b=new Mi;this.f=new Jb(new yb(this),d&6520832|262144|xp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Ap)&&D((null,I)))}
function xh(){var a;a=new Jn;new Qm(new xo,a.a.I(),a.c.I());new Cn(new xo,(a.a.I(),a.c.I()));new Hn(new xo,a.a.I(),a.c.I());new rn(a.a.I());new Tm(new xo);$wnd.ReactDOM.render(wk([(new Gn).a]),(Fh(),Eh).getElementById('app'),null)}
function Zi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ti(b,e._())){if(d.length==1){d.length=0;aj(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function rh(a,b,c){var d=oh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=oh[b]),uh(h));_.ob=c;!b&&(_.pb=wh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Uh(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Vh('.',[c,Vh('$',d)]);a.b=Vh('.',[c,Vh('.',d)]);a.i=d[d.length-1]}
function On(a){var b;if(0==a.length){b=(Fh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Eh.title,b)}else{(Fh(),$wnd.goog.global.window).location.hash=a}}
function ni(a,b){var c,d,e;c=b._();e=b.ab();d=pd(c)?c==null?pi(Xi(a.a,null)):jj(a.b,c):pi(Xi(a.a,c));if(!(qd(e)===qd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Xi(a.a,null):ij(a.b,c):!!Xi(a.a,c))){return false}return true}
function xk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;rk(b,th(Ak.prototype.hb,Ak,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ip]=c[0],undefined):(d[Ip]=c,undefined));return uk(a,e,f,d)}
function tm(a,b,c){var d,e,f;this.j=b;this.k=c;this.n=a;J();d=++hm;this.e=new oc(d,null,new um(this),false,false);this.a=(f=new ib((e=null,e)),f);this.c=new W(new Am(this),null,null,136478720);this.b=new vb(null,new Dm(this),Lp);rm(this,this.n.props['a'])}
function Xo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new oc(0,null,new Yo(this),false,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new $o(this),null,null,Qp);this.c=new W(new _o(this),null,null,Qp);this.a=new vb(new ap(this),null,681574400);D((null,I))}
function xo(){var a;this.g=new Ui;J();this.f=new oc(0,new zo(this),new yo(this),false,false);this.c=(a=new ib(null),a);this.d=new W(new Co(this),null,null,Qp);this.e=new W(new Do(this),null,null,Qp);this.a=new W(new Eo(this),null,null,Qp);this.b=new W(new Fo(this),null,null,Qp)}
function Wn(){var a,b,c;this.d=new bp(this);this.f=this.e=(c=(Fh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new oc(0,null,new Xn(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new bo,new Yn(this),new Zn(this),35651584)}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Oi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=bh(a);if(!ld(a,4))throw dh(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function rc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function ej(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}Fi(a.b,new Ab(a));a.b.a=_c(ke,vp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Hm(a){var b;a.c=0;ml();b=xk('div',null,[xk('div',null,[xk(Op,Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[Op])),[xk('h1',null,['todos']),(new qn).a]),S(a.d.d)?xk('section',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[Op])),[xk(Np,Ik(Lk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['toggle-all'])),(il(),Pk)),th(En.prototype.jb,En,[a])),null),xk('ul',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['todo-list'])),Oj(Mj(S(a.f.c).W(),new Fn),new zk))]):null,S(a.d.d)?(new Pm).a:null])]);return b}
function il(){il=sh;Ok=new jl(Jp,0);Pk=new jl('checkbox',1);Qk=new jl('color',2);Rk=new jl('date',3);Sk=new jl('datetime',4);Tk=new jl('email',5);Uk=new jl('file',6);Vk=new jl('hidden',7);Wk=new jl('image',8);Xk=new jl('month',9);Yk=new jl(up,10);Zk=new jl('password',11);$k=new jl('radio',12);_k=new jl('range',13);al=new jl('reset',14);bl=new jl('search',15);cl=new jl('submit',16);dl=new jl('tel',17);el=new jl('text',18);fl=new jl('time',19);gl=new jl('url',20);hl=new jl('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Gi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ki(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Gi(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ii(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Mi)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&xp!=(k.b.c&yp)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function ql(a){var b,c;a.d=0;ml();c=(b=S(a.g.b),xk('footer',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['footer'])),[(new Sm).a,xk('ul',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['filters'])),[xk('li',null,[xk('a',Dk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[(ip(),gp)==b?Kp:null])),'#'),['All'])]),xk('li',null,[xk('a',Dk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[fp==b?Kp:null])),'#active'),['Active'])]),xk('li',null,[xk('a',Dk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[hp==b?Kp:null])),'#completed'),['Completed'])])]),S(a.a)?xk(Jp,Ek(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['clear-completed'])),th(Om.prototype.lb,Om,[a])),['Clear Completed']):null]));return c}
function gm(a){var b,c,d,e;a.f=0;ml();b=a.n.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.n.props['a'],e=(fb(d.a),d.d),xk('li',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[xk('div',Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['view'])),[xk(Np,Ik(Gk(Lk(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['toggle'])),(il(),Pk)),e),th(un.prototype.jb,un,[d])),null),xk('label',Nk(new $wnd.Object,th(vn.prototype.lb,vn,[a,d])),[(fb(d.b),d.e)]),xk(Jp,Ek(Bk(new $wnd.Object,cd(Zc(ne,1),vp,2,6,['destroy'])),th(wn.prototype.lb,wn,[a,d])),null)]),xk(Np,Jk(Ik(Hk(Mk(Bk(Ck(new $wnd.Object,th(xn.prototype.w,xn,[a])),cd(Zc(ne,1),vp,2,6,['edit'])),(fb(a.a),a.d)),th(yn.prototype.ib,yn,[a,d])),th(tn.prototype.jb,tn,[a])),th(zn.prototype.kb,zn,[a,d])),null)]));return c}
function gj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Hp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!ej()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Hp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var tp='object',up='number',vp={3:1},wp={9:1},xp=1048576,yp=1835008,zp={5:1},Ap=2097152,Bp=4194304,Cp='__noinit__',Dp={3:1,10:1,7:1,4:1},Ep='null',Fp=17592186044416,Gp={41:1},Hp='delete',Ip='children',Jp='button',Kp='selected',Lp=1411518464,Mp=142606336,Np='input',Op='header',Pp='hashchange',Qp=136314880,Rp='active',Sp='completed';var _,oh,jh,ah=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;ph();rh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=Up;_.r=function(){var a;return Mh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var fd,gd,hd;rh(56,1,{},Nh);_.K=function(a){var b;b=new Nh;b.e=4;a>1?(b.c=Sh(this,a-1)):(b.c=this);return b};_.L=function(){Lh(this);return this.b};_.M=function(){return Mh(this)};_.N=function(){Lh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Lh(this),this.k)};_.e=0;_.g=0;var Kh=1;var ke=Ph(1);var ae=Ph(56);rh(83,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var vd=Ph(83);rh(36,1,{},G);_.s=function(){return this.a.v(),null};var td=Ph(36);rh(84,1,{},H);var ud=Ph(84);var I;rh(44,1,{44:1},P);_.b=0;_.c=false;_.d=0;var wd=Ph(44);rh(231,1,wp);_.r=function(){var a;return Mh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var zd=Ph(231);rh(18,231,wp,W);_.t=function(){R(this)};_.u=Tp;_.a=false;_.d=0;_.k=false;var yd=Ph(18);rh(126,1,{},X);_.s=function(){return T(this.a)};var xd=Ph(126);rh(16,231,{9:1,16:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Bd=Ph(16);rh(125,1,zp,jb);_.v=function(){ab(this.a)};var Ad=Ph(125);rh(17,231,{9:1,17:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Gd=Ph(17);rh(138,1,{},xb);_.v=function(){Q(this.a)};var Cd=Ph(138);rh(139,1,zp,yb);_.v=function(){mb(this.a)};var Dd=Ph(139);rh(140,1,zp,zb);_.v=function(){pb(this.a)};var Ed=Ph(140);rh(141,1,{},Ab);_.w=function(a){nb(this.a,a)};var Fd=Ph(141);rh(102,1,{},Db);_.a=0;_.b=0;_.c=0;var Hd=Ph(102);rh(167,1,wp,Fb);_.t=function(){Eb(this)};_.u=Tp;_.a=false;var Id=Ph(167);rh(67,231,{9:1,67:1},Jb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Kd=Ph(67);rh(101,1,{},Ob);var Jd=Ph(101);rh(142,1,{},$b);_.r=function(){var a;return Lh(Ld),Ld.k+'@'+(a=ik(this)>>>0,a.toString(16))};_.a=0;var Pb;var Ld=Ph(142);rh(114,1,{});var Od=Ph(114);rh(107,1,{},gc);_.w=function(a){ec(this.a,a)};var Md=Ph(107);rh(108,1,zp,hc);_.v=function(){fc(this.a,this.b)};var Nd=Ph(108);rh(15,1,wp,oc);_.t=function(){jc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Lh(Qd),Qd.k+'@'+(a=ik(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Qd=Ph(15);rh(124,1,zp,pc);_.v=function(){mc(this.a)};var Pd=Ph(124);rh(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=Zp;_.C=function(){return Oj(Mj(Qi((this.i==null&&(this.i=_c(pe,vp,4,0,0,1)),this.i)),new ji),new Sj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){sc(this,uc(this.A(tc(this,this.g))));Wc(this)};_.r=function(){return tc(this,this.F())};_.e=Cp;_.j=true;var pe=Ph(4);rh(10,4,{3:1,10:1,4:1});var de=Ph(10);rh(7,10,Dp);var le=Ph(7);rh(57,7,Dp);var he=Ph(57);rh(78,57,Dp);var Ud=Ph(78);rh(35,78,{35:1,3:1,10:1,7:1,4:1},zc);_.F=function(){yc(this);return this.c};_.H=function(){return qd(this.b)===qd(wc)?null:this.b};var wc;var Rd=Ph(35);var Sd=Ph(0);rh(214,1,{});var Td=Ph(214);var Bc=0,Cc=0,Dc=-1;rh(92,214,{},Rc);var Nc;var Vd=Ph(92);var Uc;rh(225,1,{});var Xd=Ph(225);rh(79,225,{},Yc);var Wd=Ph(79);rh(45,1,{45:1},Ah);_.I=function(){var a;a=this.a;if(qd(a)===qd(yh)){a=this.a;if(qd(a)===qd(yh)){a=this.b.I();this.a=Ch(this.a,a);this.b=null}}return a};var yh;var Yd=Ph(45);var Eh;rh(76,1,{73:1});_.r=Tp;var Zd=Ph(76);rh(80,7,Dp);var fe=Ph(80);rh(143,80,Dp,Ih);var $d=Ph(143);fd={3:1,74:1,28:1};var _d=Ph(74);rh(42,1,{3:1,42:1});var je=Ph(42);gd={3:1,28:1,42:1};var be=Ph(224);rh(30,1,{3:1,28:1,30:1});_.o=_p;_.q=Up;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ce=Ph(30);rh(59,7,Dp,Yh);var ee=Ph(59);rh(29,42,{3:1,28:1,29:1,42:1},Zh);_.o=function(a){return ld(a,29)&&a.a==this.a};_.q=Tp;_.r=function(){return ''+this.a};_.a=0;var ge=Ph(29);var _h;rh(289,1,{});rh(81,57,Dp,ci);_.A=function(a){return new TypeError(a)};var ie=Ph(81);hd={3:1,73:1,28:1,2:1};var ne=Ph(2);rh(77,76,{73:1},ii);var me=Ph(77);rh(293,1,{});rh(71,1,{},ji);_.S=function(a){return a.e};var oe=Ph(71);rh(60,7,Dp,ki);var qe=Ph(60);rh(226,1,{40:1});_.Q=Yp;_.V=function(){return new Bj(this,0)};_.W=function(){return new Pj(null,this.V())};_.T=function(a){throw dh(new ki('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Dj('[',']');for(b=this.R();b.Y();){a=b.Z();Cj(c,a===this?'(this Collection)':a==null?Ep:vh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var re=Ph(226);rh(229,1,{212:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ld(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new yi((new vi(d)).a);c.b;){b=xi(c);if(!ni(this,b)){return false}}return true};_.q=function(){return Ri(new vi(this))};_.r=function(){var a,b,c;c=new Dj('{','}');for(b=new yi((new vi(this)).a);b.b;){a=xi(b);Cj(c,oi(this,a._())+'='+oi(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ce=Ph(229);rh(100,229,{212:1});var ue=Ph(100);rh(228,226,{40:1,236:1});_.V=function(){return new Bj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ld(a,21)){return false}b=a;if(ti(b.a)!=this.U()){return false}return li(this,b)};_.q=function(){return Ri(this)};var De=Ph(228);rh(21,228,{21:1,40:1,236:1},vi);_.R=function(){return new yi(this.a)};_.U=Wp;var te=Ph(21);rh(22,1,{},yi);_.X=Vp;_.Z=function(){return xi(this)};_.Y=Xp;_.b=false;var se=Ph(22);rh(227,226,{40:1,233:1});_.V=function(){return new Bj(this,16)};_.$=function(a,b){throw dh(new ki('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,13)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Oi(f);for(c=new Oi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Si(this)};_.R=function(){return new zi(this)};var we=Ph(227);rh(91,1,{},zi);_.X=Vp;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Gi(this.b,this.a++)};_.a=0;var ve=Ph(91);rh(43,226,{40:1},Ai);_.R=function(){var a;a=new yi((new vi(this.a)).a);return new Bi(a)};_.U=Wp;var ye=Ph(43);rh(95,1,{},Bi);_.X=Vp;_.Y=function(){return this.a.b};_.Z=function(){var a;a=xi(this.a);return a.ab()};var xe=Ph(95);rh(93,1,Gp);_.o=function(a){var b;if(!ld(a,41)){return false}b=a;return Ti(this.a,b._())&&Ti(this.b,b.ab())};_._=Tp;_.ab=Xp;_.q=function(){return sj(this.a)^sj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ze=Ph(93);rh(94,93,Gp,Ci);var Ae=Ph(94);rh(230,1,Gp);_.o=function(a){var b;if(!ld(a,41)){return false}b=a;return Ti(this.b.value[0],b._())&&Ti(oj(this),b.ab())};_.q=function(){return sj(this.b.value[0])^sj(oj(this))};_.r=function(){return this.b.value[0]+'='+oj(this)};var Be=Ph(230);rh(13,227,{3:1,13:1,40:1,233:1},Mi,Ni);_.$=function(a,b){dk(this.a,a,b)};_.T=function(a){return Ei(this,a)};_.Q=function(a){Fi(this,a)};_.R=function(){return new Oi(this)};_.U=function(){return this.a.length};var Fe=Ph(13);rh(14,1,{},Oi);_.X=Vp;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ee=Ph(14);rh(37,100,{3:1,37:1,212:1},Ui);var Ge=Ph(37);rh(63,1,{},$i);_.Q=Yp;_.R=function(){return new _i(this)};_.b=0;var Ie=Ph(63);rh(64,1,{},_i);_.X=Vp;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var He=Ph(64);var cj;rh(61,1,{},mj);_.Q=Yp;_.R=function(){return new nj(this)};_.b=0;_.c=0;var Le=Ph(61);rh(62,1,{},nj);_.X=Vp;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new pj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Je=Ph(62);rh(113,230,Gp,pj);_._=function(){return this.b.value[0]};_.ab=function(){return oj(this)};_.bb=function(a){return kj(this.a,this.b.value[0],a)};_.c=0;var Ke=Ph(113);rh(128,1,{});_.X=$p;_.cb=function(){return this.d};_.db=Zp;_.d=0;_.e=0;var Pe=Ph(128);rh(65,128,{});var Me=Ph(65);rh(96,1,{});_.X=$p;_.cb=Xp;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Oe=Ph(96);rh(97,96,{},zj);_.X=function(a){wj(this,a)};_.eb=function(a){return xj(this,a)};var Ne=Ph(97);rh(19,1,{},Bj);_.cb=Tp;_.db=function(){Aj(this);return this.c};_.X=function(a){Aj(this);this.d.X(a)};_.eb=function(a){Aj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Qe=Ph(19);rh(58,1,{},Dj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Re=Ph(58);rh(34,1,{},Ej);_.S=function(a){return a};var Se=Ph(34);rh(38,1,{},Fj);var Te=Ph(38);rh(127,1,{});_.c=false;var bf=Ph(127);rh(23,127,{},Pj);var af=Ph(23);rh(72,1,{},Sj);_.fb=function(a){return _c(ke,vp,1,a,5,1)};var Ue=Ph(72);rh(130,65,{},Uj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Vj(this,a)));return this.b};_.b=false;var We=Ph(130);rh(133,1,{},Vj);_.w=function(a){Tj(this.a,this.b,a)};var Ve=Ph(133);rh(129,65,{},Xj);_.eb=function(a){return this.b.eb(new Yj(this,a))};var Ye=Ph(129);rh(132,1,{},Yj);_.w=function(a){Wj(this.a,this.b,a)};var Xe=Ph(132);rh(131,1,{},$j);_.w=function(a){Zj(this,a)};var Ze=Ph(131);rh(134,1,{},_j);_.w=function(a){};var $e=Ph(134);rh(135,1,{},bk);_.w=function(a){ak(this,a)};var _e=Ph(135);rh(291,1,{});rh(288,1,{});var hk=0;var jk,kk=0,lk;rh(905,1,{});rh(926,1,{});rh(232,1,{});var cf=Ph(232);rh(168,1,{},zk);_.fb=function(a){return new Array(a)};var df=Ph(168);rh(256,$wnd.Function,{},Ak);_.hb=function(a){yk(this.a,this.b,a)};rh(6,30,{3:1,28:1,30:1,6:1},jl);var Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl;var ef=Qh(6,kl);var ll;rh(255,$wnd.Function,{},nl);_.J=function(a){return Eb(ll),ll=null,null};rh(184,232,{});var Pf=Ph(184);rh(185,184,{});_.d=0;var Tf=Ph(185);rh(186,185,wp,vl);_.t=aq;_.o=_p;_.q=Up;_.u=bq;_.r=function(){var a;return Lh(of),of.k+'@'+(a=ik(this)>>>0,a.toString(16))};var rl=0;var of=Ph(186);rh(187,1,zp,wl);_.v=function(){sl(this.a)};var ff=Ph(187);rh(188,1,{},xl);_.s=function(){return tl(this.a)};var gf=Ph(188);rh(189,1,{},yl);_.v=function(){pl(this.a)};var hf=Ph(189);rh(190,1,{},zl);_.s=function(){return ql(this.a)};var jf=Ph(190);rh(205,232,{});var Of=Ph(205);rh(206,205,{});_.c=0;var Sf=Ph(206);rh(207,206,wp,Fl);_.t=cq;_.o=_p;_.q=Up;_.u=dq;_.r=function(){var a;return Lh(nf),nf.k+'@'+(a=ik(this)>>>0,a.toString(16))};var Dl=0;var nf=Ph(207);rh(208,1,zp,Gl);_.v=eq;var kf=Ph(208);rh(209,1,{},Hl);_.v=function(){Bl(this.a)};var lf=Ph(209);rh(210,1,{},Il);_.s=function(){return Cl(this.a)};var mf=Ph(210);rh(176,232,{});_.f='';var ag=Ph(176);rh(177,176,{});_.d=0;var Vf=Ph(177);rh(178,177,wp,Ul);_.t=aq;_.o=_p;_.q=Up;_.u=bq;_.r=function(){var a;return Lh(uf),uf.k+'@'+(a=ik(this)>>>0,a.toString(16))};var Ol=0;var uf=Ph(178);rh(179,1,zp,Vl);_.v=function(){Pl(this.a)};var pf=Ph(179);rh(181,1,{},Wl);_.s=function(){return Nl(this.a)};var qf=Ph(181);rh(182,1,zp,Xl);_.v=function(){Jl(this.a)};var rf=Ph(182);rh(183,1,zp,Yl);_.v=function(){Rl(this.a,this.b)};var sf=Ph(183);rh(180,1,{},Zl);_.v=function(){pl(this.a)};var tf=Ph(180);rh(172,232,{});_.i=false;var dg=Ph(172);rh(192,172,{});_.f=0;var Xf=Ph(192);rh(193,192,wp,tm);_.t=function(){jc(this.e)};_.o=_p;_.q=Up;_.u=function(){return this.e.i<0};_.r=function(){var a;return Lh(Ff),Ff.k+'@'+(a=ik(this)>>>0,a.toString(16))};var hm=0;var Ff=Ph(193);rh(194,1,zp,um);_.v=function(){im(this.a)};var vf=Ph(194);rh(197,1,{},vm);_.s=function(){return gm(this.a)};var wf=Ph(197);rh(49,1,zp,wm);_.v=function(){sm(this.a,Sn(this.b))};var xf=Ph(49);rh(68,1,zp,xm);_.v=function(){cm(this.a,this.b)};var yf=Ph(68);rh(198,1,zp,ym);_.v=function(){km(this.a,this.b)};var zf=Ph(198);rh(199,1,zp,zm);_.v=function(){lm(this.a,this.b)};var Af=Ph(199);rh(195,1,{},Am);_.s=function(){return mm(this.a)};var Bf=Ph(195);rh(200,1,zp,Bm);_.v=function(){$l(this.a,this.b)};var Cf=Ph(200);rh(201,1,zp,Cm);_.v=function(){dm(this.a)};var Df=Ph(201);rh(196,1,{},Dm);_.v=function(){fm(this.a)};var Ef=Ph(196);rh(154,232,{});var hg=Ph(154);rh(155,154,{});_.c=0;var Zf=Ph(155);rh(156,155,wp,Km);_.t=cq;_.o=_p;_.q=Up;_.u=dq;_.r=function(){var a;return Lh(Jf),Jf.k+'@'+(a=ik(this)>>>0,a.toString(16))};var Im=0;var Jf=Ph(156);rh(157,1,zp,Lm);_.v=eq;var Gf=Ph(157);rh(158,1,{},Mm);_.v=function(){Bl(this.a)};var Hf=Ph(158);rh(159,1,{},Nm);_.s=function(){return Hm(this.a)};var If=Ph(159);rh(261,$wnd.Function,{},Om);_.lb=function(a){Io(this.a.f)};rh(170,1,{},Pm);var Kf=Ph(170);rh(86,1,{},Qm);var Lf=Ph(86);var Rm;rh(191,1,{},Sm);var Mf=Ph(191);rh(90,1,{},Tm);var Nf=Ph(90);var Um;rh(262,$wnd.Function,{},Vm);_.mb=function(a){return new Ym(a)};var Wm;rh(174,$wnd.React.Component,{},Ym);qh(oh[1],_);_.componentWillUnmount=function(){ol(this.a)};_.render=function(){return ul(this.a)};_.shouldComponentUpdate=fq;var Qf=Ph(174);rh(272,$wnd.Function,{},Zm);_.mb=function(a){return new an(a)};var $m;rh(202,$wnd.React.Component,{},an);qh(oh[1],_);_.componentWillUnmount=function(){Al(this.a)};_.render=function(){return El(this.a)};_.shouldComponentUpdate=gq;var Rf=Ph(202);rh(260,$wnd.Function,{},bn);_.mb=function(a){return new en(a)};var cn;rh(173,$wnd.React.Component,{},en);qh(oh[1],_);_.componentWillUnmount=function(){ol(this.a)};_.render=function(){return Sl(this.a)};_.shouldComponentUpdate=fq;var Uf=Ph(173);rh(263,$wnd.Function,{},fn);_.mb=function(a){return new jn(a)};var gn;rh(175,$wnd.React.Component,{},jn);qh(oh[1],_);_.componentDidUpdate=function(a){pm(this.a)};_.componentWillUnmount=function(){em(this.a)};_.render=function(){return qm(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Wf=Ph(175);rh(254,$wnd.Function,{},kn);_.mb=function(a){return new nn(a)};var ln;rh(98,$wnd.React.Component,{},nn);qh(oh[1],_);_.componentWillUnmount=function(){Al(this.a)};_.render=function(){return Jm(this.a)};_.shouldComponentUpdate=gq;var Yf=Ph(98);rh(258,$wnd.Function,{},on);_.kb=function(a){Kl(this.a,a)};rh(259,$wnd.Function,{},pn);_.jb=function(a){Ql(this.a,a)};rh(169,1,{},qn);var $f=Ph(169);rh(89,1,{},rn);var _f=Ph(89);var sn;rh(270,$wnd.Function,{},tn);_.jb=function(a){jm(this.a,a)};rh(264,$wnd.Function,{},un);_.jb=function(a){mo(this.a)};rh(266,$wnd.Function,{},vn);_.lb=function(a){nm(this.a,this.b)};rh(267,$wnd.Function,{},wn);_.lb=function(a){_l(this.a,this.b)};rh(268,$wnd.Function,{},xn);_.w=function(a){am(this.a,a)};rh(269,$wnd.Function,{},yn);_.ib=function(a){om(this.a,this.b)};rh(271,$wnd.Function,{},zn);_.kb=function(a){bm(this.a,this.b,a)};rh(171,1,{},Bn);var bg=Ph(171);rh(87,1,{},Cn);var cg=Ph(87);var Dn;rh(253,$wnd.Function,{},En);_.jb=function(a){Em(this.a,a)};rh(99,1,{},Fn);_.S=function(a){return An(new Bn,a)};var eg=Ph(99);rh(70,1,{},Gn);var fg=Ph(70);rh(88,1,{},Hn);var gg=Ph(88);var In;rh(85,1,{},Jn);var ig=Ph(85);rh(48,1,{48:1});var Pg=Ph(48);rh(160,48,{9:1,48:1},Wn);_.t=aq;_.o=_p;_.q=Up;_.u=bq;_.r=function(){var a;return Lh(qg),qg.k+'@'+(a=ik(this)>>>0,a.toString(16))};var qg=Ph(160);rh(161,1,zp,Xn);_.v=function(){Qn(this.a)};var jg=Ph(161);rh(163,1,{},Yn);_.v=function(){Ln(this.a)};var kg=Ph(163);rh(164,1,{},Zn);_.v=function(){Mn(this.a)};var lg=Ph(164);rh(165,1,zp,$n);_.v=function(){Kn(this.a,this.b)};var mg=Ph(165);rh(166,1,zp,_n);_.v=function(){Tn(this.a)};var ng=Ph(166);rh(66,1,zp,ao);_.v=function(){Pn(this.a)};var og=Ph(66);rh(162,1,{},bo);_.s=function(){var a;return a=(Fh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var pg=Ph(162);rh(50,1,{50:1});_.d=false;var Yg=Ph(50);rh(51,50,{9:1,257:1,51:1,50:1},no);_.t=aq;_.o=function(a){return go(this,a)};_.q=function(){return this.c.d};_.u=bq;_.r=function(){var a;return Lh(Gg),Gg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var co=0;var Gg=Ph(51);rh(203,1,zp,oo);_.v=function(){eo(this.a)};var rg=Ph(203);rh(204,1,zp,po);_.v=function(){jo(this.a)};var sg=Ph(204);rh(115,114,{});var Sg=Ph(115);rh(26,115,wp,xo);_.t=hq;_.o=_p;_.q=Up;_.u=iq;_.r=function(){var a;return Lh(Bg),Bg.k+'@'+(a=ik(this)>>>0,a.toString(16))};var Bg=Ph(26);rh(117,1,zp,yo);_.v=function(){ro(this.a)};var tg=Ph(117);rh(116,1,zp,zo);_.v=function(){uo(this.a)};var ug=Ph(116);rh(122,1,zp,Ao);_.v=function(){bc(this.a,this.b,true)};var vg=Ph(122);rh(123,1,{},Bo);_.s=function(){return qo(this.a,this.c,this.b)};_.b=false;var wg=Ph(123);rh(118,1,{},Co);_.s=function(){return vo(this.a)};var xg=Ph(118);rh(119,1,{},Do);_.s=function(){return $h(ih(Kj(cc(this.a))))};var yg=Ph(119);rh(120,1,{},Eo);_.s=function(){return $h(ih(Kj(Lj(cc(this.a),new lp))))};var zg=Ph(120);rh(121,1,{},Fo);_.s=function(){return wo(this.a)};var Ag=Ph(121);rh(46,1,{46:1});var Xg=Ph(46);rh(144,46,{9:1,46:1},Mo);_.t=function(){jc(this.a)};_.o=_p;_.q=Up;_.u=function(){return this.a.i<0};_.r=function(){var a;return Lh(Fg),Fg.k+'@'+(a=ik(this)>>>0,a.toString(16))};var Fg=Ph(144);rh(145,1,zp,No);_.v=function(){Jo(this.a,this.b)};_.b=false;var Cg=Ph(145);rh(146,1,zp,Oo);_.v=function(){Vn(this.b,this.a)};var Dg=Ph(146);rh(147,1,zp,Po);_.v=function(){Ko(this.a)};var Eg=Ph(147);rh(47,1,{47:1});var _g=Ph(47);rh(148,47,{9:1,47:1},Xo);_.t=hq;_.o=_p;_.q=Up;_.u=iq;_.r=function(){var a;return Lh(Mg),Mg.k+'@'+(a=ik(this)>>>0,a.toString(16))};var Mg=Ph(148);rh(149,1,zp,Yo);_.v=function(){So(this.a)};var Hg=Ph(149);rh(153,1,zp,Zo);_.v=function(){Wo(this.a,null)};var Ig=Ph(153);rh(150,1,{},$o);_.s=function(){var a;return a=Sn(this.a.g),o(Rp,a)?(ip(),fp):o(Sp,a)?(ip(),hp):(ip(),gp)};var Jg=Ph(150);rh(151,1,{},_o);_.s=function(){return Uo(this.a)};var Kg=Ph(151);rh(152,1,{},ap);_.v=function(){Vo(this.a)};var Lg=Ph(152);rh(137,1,{},bp);_.handleEvent=function(a){Nn(this.a,a)};var Ng=Ph(137);rh(104,1,{},cp);_.I=function(){return new Wn};var Og=Ph(104);var dp;rh(31,30,{3:1,28:1,30:1,31:1},jp);var fp,gp,hp;var Qg=Qh(31,kp);rh(106,1,{},lp);_.gb=function(a){return !io(a)};var Rg=Ph(106);rh(110,1,{},mp);_.gb=function(a){return io(a)};var Tg=Ph(110);rh(111,1,{},np);_.w=function(a){to(this.a,a)};var Ug=Ph(111);rh(109,1,{},op);_.w=function(a){Ho(this.a,a)};_.a=false;var Vg=Ph(109);rh(103,1,{},pp);_.I=function(){return new Mo(new xo)};var Wg=Ph(103);rh(112,1,{},qp);_.gb=function(a){return Ro(this.a,a)};var Zg=Ph(112);rh(105,1,{},rp);_.I=function(){return new Xo(new xo,this.a.I())};var $g=Ph(105);var sd=Rh('D');var sp=(Ec(),Hc);var gwtOnLoad=gwtOnLoad=mh;kh(xh);nh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();