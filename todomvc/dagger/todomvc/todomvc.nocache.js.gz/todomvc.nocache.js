function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='6DBB1D82F9CE5F54FF82A0DD0A7EFD7B',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '6DBB1D82F9CE5F54FF82A0DD0A7EFD7B';function o(){}
function oh(){}
function kh(){}
function Hb(){}
function Mc(){}
function Tc(){}
function Bj(){}
function Cj(){}
function Qk(){}
function Gm(){}
function Km(){}
function Om(){}
function Sm(){}
function Wm(){}
function Un(){}
function Bo(){}
function hp(){}
function ip(){}
function Rc(a){Qc()}
function Cm(a){Bm=a}
function Fm(a){Em=a}
function cn(a){bn=a}
function on(a){nn=a}
function sn(a){rn=a}
function xh(){xh=kh}
function zi(){qi(this)}
function zb(a){this.a=a}
function lb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function G(a){this.a=a}
function H(a){this.a=a}
function cc(a){this.a=a}
function lc(a){this.a=a}
function Nh(a){this.a=a}
function Yh(a){this.a=a}
function ii(a){this.a=a}
function ni(a){this.a=a}
function oi(a){this.a=a}
function mi(a){this.b=a}
function Bi(a){this.c=a}
function zj(a){this.a=a}
function Ej(a){this.a=a}
function Zk(a){this.a=a}
function al(a){this.a=a}
function bl(a){this.a=a}
function cl(a){this.a=a}
function jl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function Al(a){this.a=a}
function Cl(a){this.a=a}
function Dl(a){this.a=a}
function El(a){this.a=a}
function Gl(a){this.a=a}
function bm(a){this.a=a}
function em(a){this.a=a}
function gm(a){this.a=a}
function lm(a){this.a=a}
function mm(a){this.a=a}
function um(a){this.a=a}
function xm(a){this.a=a}
function ym(a){this.a=a}
function zm(a){this.a=a}
function $m(a){this.a=a}
function _m(a){this.a=a}
function dn(a){this.a=a}
function en(a){this.a=a}
function hn(a){this.a=a}
function pn(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function zn(a){this.a=a}
function Bn(a){this.a=a}
function Pn(a){this.a=a}
function Qn(a){this.a=a}
function Rn(a){this.a=a}
function Sn(a){this.a=a}
function Tn(a){this.a=a}
function go(a){this.a=a}
function ho(a){this.a=a}
function ro(a){this.a=a}
function so(a){this.a=a}
function vo(a){this.a=a}
function wo(a){this.a=a}
function xo(a){this.a=a}
function yo(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function Wo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function jp(a){this.a=a}
function kp(a){this.a=a}
function lp(a){this.a=a}
function Xp(){fc(this.c)}
function Zp(){fc(this.b)}
function Li(){this.a=Ui()}
function Zi(){this.a=Ui()}
function gc(a){!!a&&a.v()}
function V(a){!!a&&cb(a)}
function w(a){--a.e;D(a)}
function Tp(a){bj(this,a)}
function Wp(a){Rh(this,a)}
function gb(a){Vb((J(),a))}
function hb(a){Wb((J(),a))}
function jb(a){Xb((J(),a))}
function Do(a,b){_l(b,a)}
function Vj(a,b){Uj(a,b)}
function Dj(a,b){uj(a.a,b)}
function jc(a,b){ei(a.e,b)}
function Il(a,b){lo(a.j,b)}
function Co(a,b){ko(a.b,b)}
function C(a,b){ab(a.f,b.f)}
function Aj(a,b){a.a=b}
function Wj(a,b){a.key=b}
function sb(a,b){a.b=ej(b)}
function dl(a){a.c=2;fc(a.b)}
function Pl(a){a.f=2;fc(a.e)}
function Rk(a){a.d=2;fc(a.c)}
function Kb(a){a.a=-4&a.a|1}
function Wg(a){return a.e}
function Jl(a,b){return a.g=b}
function Uh(a,b){return a===b}
function Vp(){return this.b}
function Qp(){return this.a}
function Sp(){return Mj(this)}
function _p(){mb(this.a.a)}
function Vk(a){mb(a.b);R(a.a)}
function In(a){R(a.a);cb(a.b)}
function ul(a){mb(a.a);cb(a.b)}
function Xn(a){cb(a.b);cb(a.a)}
function Zh(a){qc.call(this,a)}
function Rp(a){return this===a}
function ti(a,b){return a.a[b]}
function Ah(a){zh(a);return a.k}
function sc(){sc=kh;rc=new o}
function Jc(){Jc=kh;Ic=new Mc}
function J(){J=kh;I=new F}
function Ao(){Ao=kh;zo=new Bo}
function Qi(){Qi=kh;Pi=Si()}
function zc(){zc=kh;!!(Qc(),Pc)}
function Sh(){mc(this);this.C()}
function Up(){return gi(this.a)}
function Yp(){return this.c.i<0}
function $p(){return this.b.i<0}
function Uc(a,b){return Gh(a,b)}
function Ij(a,b){a.splice(b,1)}
function ec(a,b,c){di(a.e,b,c)}
function Yn(a,b,c){ec(a.c,b,c)}
function uj(a,b){Aj(a,tj(a.a,b))}
function K(a,b){O(a);L(a,ej(b))}
function fj(a,b){while(a.ab(b));}
function tj(a,b){a.P(b);return a}
function dk(a,b){a.ref=b;return a}
function Kn(a){ib(a.b);return a.e}
function _n(a){ib(a.a);return a.d}
function Qo(a){ib(a.d);return a.f}
function Ui(){Qi();return new Pi}
function db(a){J();Wb(a);a.e=-2}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function gi(a){return a.a.b+a.b.b}
function W(a){return !!a&&a.c.i<0}
function aq(a){return 1==this.a.d}
function bq(a){return 1==this.a.c}
function Zc(a){return new Array(a)}
function Wi(a,b){return a.a.get(b)}
function pi(a,b){this.a=a;this.b=b}
function dc(a,b){this.a=a;this.b=b}
function Lh(a,b){this.a=a;this.b=b}
function xj(a,b){this.a=a;this.b=b}
function bk(a,b){this.a=a;this.b=b}
function Fl(a,b){this.a=a;this.b=b}
function fm(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function im(a,b){this.a=a;this.b=b}
function jm(a,b){this.a=a;this.b=b}
function km(a,b){this.a=a;this.b=b}
function fn(a,b){this.a=a;this.b=b}
function gn(a,b){this.a=a;this.b=b}
function jn(a,b){this.a=a;this.b=b}
function kn(a,b){this.a=a;this.b=b}
function Mk(a,b){Lh.call(this,a,b)}
function Gj(a,b,c){a.splice(b,0,c)}
function v(a,b,c){s(a,new H(c),b)}
function Ln(a){Jn(a,(ib(a.b),a.e))}
function an(){this.a=Xj((Qm(),Pm))}
function mn(){this.a=Xj((Um(),Tm))}
function qn(){this.a=Xj((Ym(),Xm))}
function Am(){this.a=Xj((Im(),Hm))}
function Dm(){this.a=Xj((Mm(),Lm))}
function dh(){ah==null&&(ah=[])}
function Hc(){wc!=0&&(wc=0);yc=-1}
function Gc(a){$wnd.clearTimeout(a)}
function ek(a,b){a.href=b;return a}
function nk(a,b){a.value=b;return a}
function Wh(a,b){a.a+=''+b;return a}
function Vn(a,b){this.a=a;this.b=b}
function to(a,b){this.a=a;this.b=b}
function Jo(a,b){this.a=a;this.b=b}
function Ko(a,b){this.b=a;this.a=b}
function fp(a,b){Lh.call(this,a,b)}
function ao(a){_l(a,(ib(a.a),!a.d))}
function Rb(a){return !a.d?a:Rb(a.d)}
function ci(a){return !a?null:a.Y()}
function md(a){return a==null?null:a}
function dj(a){return a!=null?r(a):0}
function jd(a){return typeof a===op}
function fi(a){a.a=new Li;a.b=new Zi}
function qi(a){a.a=Wc(ee,qp,1,0,5,1)}
function rb(a){J();qb(a);ub(a,2,true)}
function Tl(a){mb(a.b);R(a.c);cb(a.a)}
function bc(a,b){_b(a,b,false);hb(a.d)}
function Hj(a,b){Fj(b,0,a,0,b.length)}
function A(a,b,c){t(a,new G(b),c,null)}
function B(a,b,c){return t(a,c,2048,b)}
function X(a){return !(!!a&&1==(a.c&7))}
function ib(a){var b;Sb((J(),b=Nb,b),a)}
function Fb(a){this.d=ej(a);this.b=100}
function qh(a){this.b=ej(a);this.a=this}
function kb(a){this.c=new zi;this.b=a}
function Qj(){Qj=kh;Nj=new o;Pj=new o}
function hk(a,b){a.checked=b;return a}
function ik(a,b){a.onBlur=b;return a}
function fk(a,b){a.onClick=b;return a}
function jk(a,b){a.onChange=b;return a}
function kk(a,b){a.onKeyDown=b;return a}
function gk(a){a.autoFocus=true;return a}
function zh(a){if(a.k!=null){return}Ih(a)}
function gd(a,b){return a!=null&&ed(a,b)}
function Th(a,b){return a.charCodeAt(b)}
function _c(a,b,c){return {l:a,m:b,h:c}}
function Uj(a,b){for(var c in a){b(c)}}
function Kj(b,c,d){try{b[c]=d}catch(a){}}
function sj(a,b){nj.call(this,a);this.a=b}
function qc(a){this.f=a;mc(this);this.C()}
function Fi(){this.a=new Li;this.b=new Zi}
function P(){this.a=Wc(ee,qp,1,100,5,1)}
function Dn(a){vh((uh(),th),Mp,a.d,false)}
function En(a){wh((uh(),th),Mp,a.d,false)}
function T(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function Mj(a){return a.$H||(a.$H=++Lj)}
function kl(a,b){return new il(ej(b),a.a)}
function Bl(a,b){return new zl(ej(b),a.a)}
function hd(a){return typeof a==='boolean'}
function ld(a){return typeof a==='string'}
function u(a,b){return new xb(ej(a),null,b)}
function nc(a,b){a.e=b;b!=null&&Kj(b,zp,a)}
function ac(a,b){jc(b.c,a);gd(b,9)&&b.t()}
function bj(a,b){while(a.U()){Dj(b,a.V())}}
function $(a,b,c){Kb(ej(c));K(a.a[b],ej(c))}
function Ni(a,b){var c;c=a[Ep];c.call(a,b)}
function ab(a,b){$(a,((b.a&229376)>>15)-1,b)}
function So(a){W((ib(a.d),a.f))&&Uo(a,null)}
function eo(a){A((J(),J(),I),new ho(a),Jp)}
function Eo(a){A((J(),J(),I),new Lo(a),Jp)}
function Yl(a){A((J(),J(),I),new mm(a),Jp)}
function Mn(a){A((J(),J(),I),new Sn(a),Jp)}
function po(a){return Oh(S(a.e).a-S(a.a).a)}
function Ac(a,b,c){return a.apply(b,c);var d}
function aj(a,b,c){this.a=a;this.b=b;this.c=c}
function _k(a,b,c){this.a=a;this.b=b;this.c=c}
function dm(a,b,c){this.a=a;this.b=b;this.c=c}
function wm(a,b,c){this.a=a;this.b=b;this.c=c}
function ok(a,b){a.onDoubleClick=b;return a}
function ri(a,b){a.a[a.a.length]=b;return true}
function mc(a){a.g&&a.e!==yp&&a.C();return a}
function Dh(a){var b;b=Ch(a);Kh(a,b);return b}
function Qh(){Qh=kh;Ph=Wc(ae,qp,32,256,0,1)}
function Qc(){Qc=kh;var a;!Sc();a=new Tc;Pc=a}
function Eb(a){while(true){if(!Db(a)){break}}}
function uo(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new bb;this.a=new Fb(this.f)}
function vl(a,b){A((J(),J(),I),new Fl(a,b),Jp)}
function Ul(a,b){A((J(),J(),I),new km(a,b),Jp)}
function Wl(a,b){A((J(),J(),I),new im(a,b),Jp)}
function Xl(a,b){A((J(),J(),I),new hm(a,b),Jp)}
function $l(a,b){A((J(),J(),I),new fm(a,b),Jp)}
function lo(a,b){A((J(),J(),I),new to(a,b),Jp)}
function Ho(a,b){A((J(),J(),I),new Jo(a,b),Jp)}
function no(a){Rh(new ni(a.g),new cc(a));fi(a.g)}
function Gb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function hj(a){if(!a.d){a.d=a.b.O();a.c=a.b.Q()}}
function ki(a){var b;b=a.a.V();a.b=ji(a);return b}
function Fh(a){var b;b=Ch(a);b.j=a;b.e=1;return b}
function wl(a,b){var c;c=b.target;yl(a,c.value)}
function pb(a,b){fb(b,a);b.c.a.length>0||(b.a=4)}
function vj(a,b,c){if(a.a.bb(c)){a.b=true;b.w(c)}}
function vh(a,b,c,d){a.addEventListener(b,c,d)}
function wh(a,b,c,d){a.removeEventListener(b,c,d)}
function $k(a,b){return new Yk(ej(b),a.a,a.b,a.c)}
function cm(a,b){return new am(ej(b),a.a,a.b,a.c)}
function vm(a,b){return new tm(ej(b),a.a,a.b,a.c)}
function Vi(a,b){return !(a.a.get(b)===undefined)}
function Wk(a){return xh(),S(a.e.b).a>0?true:false}
function oo(a){return xh(),0==S(a.e).a?true:false}
function Xk(a){return B((J(),J(),I),a.b,new cl(a))}
function hl(a){return B((J(),J(),I),a.a,new nl(a))}
function xl(a){return B((J(),J(),I),a.a,new Dl(a))}
function rh(a){ej(a);return gd(a,44)?a:new qh(a)}
function qj(a){mj(a);return new sj(a,new yj(a.a))}
function sm(a){return B((J(),J(),I),a.a,new ym(a))}
function Zl(a){return B((J(),J(),I),a.b,new em(a))}
function No(a){return Uh(Op,a)||Uh(Pp,a)||Uh('',a)}
function Yc(a){return Array.isArray(a)&&a.kb===oh}
function fd(a){return !Array.isArray(a)&&a.kb===oh}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Nc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function vi(a,b){var c;c=a.a[b];Ij(a.a,b);return c}
function xi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function nm(a,b){var c;c=b.target;Ho(a.e,c.checked)}
function jo(a){R(a.c);R(a.e);R(a.a);R(a.b);cb(a.d)}
function yl(a,b){var c;c=a.f;if(b!=c){a.f=b;hb(a.b)}}
function _l(a,b){var c;c=a.d;if(b!=c){a.d=b;hb(a.a)}}
function Sk(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function el(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function Ql(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function lj(a){if(!a.b){mj(a);a.c=true}else{lj(a.b)}}
function Po(a){mb(a.e);mb(a.a);R(a.b);R(a.c);cb(a.d)}
function pj(a,b){mj(a);return new sj(a,new wj(b,a.a))}
function hi(a,b){if(b){return ai(a.a,b)}return false}
function _g(a){if(jd(a)){return a|0}return a.l|a.m<<22}
function ej(a){if(a==null){throw Wg(new Sh)}return a}
function Tj(){if(Oj==256){Nj=Pj;Pj=new o;Oj=0}++Oj}
function nj(a){if(!a){this.b=null;new zi}else{this.b=a}}
function yj(a){gj.call(this,a._(),a.$()&-6);this.a=a}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Jn(a,b){A((J(),J(),I),new Vn(a,b),75497472)}
function Ml(a,b){Uo(a.k,b);A((J(),J(),I),new fm(a,b),Jp)}
function Ei(a,b){return md(a)===md(b)||a!=null&&p(a,b)}
function ko(a,b){return t((J(),J(),I),new uo(a,b),Jp,null)}
function gp(){ep();return $c(Uc(Kg,1),qp,34,0,[bp,dp,cp])}
function Hh(a){if(a.M()){return null}var b=a.j;return gh[b]}
function mk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Eh(a,b){var c;c=Ch(a);Kh(a,c);c.e=b?8:0;return c}
function Nn(a,b){var c;c=a.e;if(b!=c){a.e=ej(b);hb(a.b)}}
function Hn(a){var b;T(a.a);b=S(a.a);Uh(a.f,b)&&Nn(a,b)}
function Hl(a,b){var c;if(S(a.c)){c=b.target;_l(a,c.value)}}
function oc(a,b){var c;c=Ah(a.ib);return b==null?c:c+': '+b}
function bi(a,b){return b===a?'(this Map)':b==null?Bp:nh(b)}
function gj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function ij(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function Ll(a,b){A((J(),J(),I),new fm(a,b),Jp);Uo(a.k,null)}
function nb(a){C((J(),J(),I),a);0==(a.f.a&vp)&&D((null,I))}
function un(a){return new _k(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function yn(a){return new dm(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function An(a){return new wm(a.a.a.F(),a.a.b.F(),a.a.c.F())}
function Rh(a,b){var c,d;for(d=a.O();d.U();){c=d.V();b.w(c)}}
function Fo(a,b){var c;rj(mo(a.b),(c=new zi,c)).N(new kp(b))}
function Gh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.H(b))}
function Ob(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);qb(a.e)}}
function mj(a){if(a.b){mj(a.b)}else if(a.c){throw Wg(new Mh)}}
function Fc(a){zc();$wnd.setTimeout(function(){throw a},0)}
function Hi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Fn(a,b){b.preventDefault();A((J(),J(),I),new Tn(a),Jp)}
function lk(a){a.placeholder='What needs to be done?';return a}
function mh(a){function b(){}
;b.prototype=a||{};return new b}
function Vl(a){return xh(),Qo(a.k)==a.n.props['a']?true:false}
function Ii(a,b){var c;return Gi(b,Hi(a,b==null?0:(c=r(b),c|0)))}
function mo(a){ib(a.d);return new sj(null,new ij(new ni(a.g),0))}
function Ai(a){qi(this);Hj(this.a,_h(a,Wc(ee,qp,1,gi(a.a),5,1)))}
function ic(a){gc(a.g);!!a.e&&hc(a);V(a.a);V(a.c);gc(a.b);gc(a.f)}
function Mi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function wj(a,b){gj.call(this,b._(),b.$()&-16449);this.a=a;this.c=b}
function Jm(a){$wnd.React.Component.call(this,a);this.a=$k(Bm,this)}
function Nm(a){$wnd.React.Component.call(this,a);this.a=kl(Em,this)}
function Rm(a){$wnd.React.Component.call(this,a);this.a=Bl(bn,this)}
function Vm(a){$wnd.React.Component.call(this,a);this.a=cm(nn,this)}
function Zm(a){$wnd.React.Component.call(this,a);this.a=vm(rn,this)}
function Im(){Im=kh;var a;Hm=(a=lh(Gm.prototype.hb,Gm,[]),a)}
function Mm(){Mm=kh;var a;Lm=(a=lh(Km.prototype.hb,Km,[]),a)}
function Qm(){Qm=kh;var a;Pm=(a=lh(Om.prototype.hb,Om,[]),a)}
function Um(){Um=kh;var a;Tm=(a=lh(Sm.prototype.hb,Sm,[]),a)}
function Ym(){Ym=kh;var a;Xm=(a=lh(Wm.prototype.hb,Wm,[]),a)}
function ih(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ak(a,b,c){!Uh(c,'key')&&!Uh(c,'ref')&&(a[c]=b[c],undefined)}
function Dc(a,b,c){var d;d=Bc();try{return Ac(a,b,c)}finally{Ec(d)}}
function Uo(a,b){var c;c=a.f;if(!(b==c||!!b&&Zn(b,c))){a.f=b;hb(a.d)}}
function eb(a,b){var c,d;ri(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function ei(a,b){return ld(b)?b==null?Ki(a.a,null):Yi(a.b,b):Ki(a.a,b)}
function jj(a,b){!a.a?(a.a=new Yh(a.d)):Wh(a.a,a.b);Wh(a.a,b);return a}
function rj(a,b){var c;lj(a);c=new Bj;c.a=b;a.a.T(new Ej(c));return c.a}
function oj(a){var b;lj(a);b=0;while(a.a.ab(new Cj)){b=Xg(b,1)}return b}
function Go(a){var b;rj(pj(mo(a.b),new ip),(b=new zi,b)).N(new jp(a.b))}
function Lb(b){try{b.b.v()}catch(a){a=Vg(a);if(!gd(a,5))throw Wg(a)}}
function Ec(a){a&&Lc((Jc(),Ic));--wc;if(a){if(yc!=-1){Gc(yc);yc=-1}}}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Z(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function ol(a){var b;b=Vh((ib(a.b),a.f));if(b.length>0){Co(a.e,b);yl(a,'')}}
function Io(a){this.b=ej(a);J();this.a=new kc(0,null,null,false,false)}
function $i(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function li(a){this.d=a;this.c=new $i(this.d.b);this.a=this.c;this.b=ji(this)}
function kj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function uh(){uh=kh;sh=$wnd.window.document;th=$wnd.window.window}
function pc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Cc(b){zc();return function(){return Dc(b,this,arguments);var a}}
function vc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function _i(a){if(a.a.c!=a.c){return Wi(a.a,a.b.value[0])}return a.b.value[1]}
function Zn(a,b){var c;if(gd(b,49)){c=b;return a.c.d==c.c.d}else{return false}}
function Wc(a,b,c,d,e,f){var g;g=Xc(e,d);e!=10&&$c(Uc(a,f),b,c,e,g);return g}
function ui(a,b,c){for(;c<a.a.length;++c){if(Ei(b,a.a[c])){return c}}return -1}
function wi(a,b){var c;c=ui(a,b,0);if(c==-1){return false}Ij(a.a,c);return true}
function si(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Ro(a){var b,c;return b=S(a.b),rj(pj(mo(a.j),new lp(b)),(c=new zi,c))}
function Oo(a,b){return (ep(),cp)==a||(bp==a?(ib(b.a),!b.d):(ib(b.a),b.d))}
function di(a,b,c){return ld(b)?b==null?Ji(a.a,null,c):Xi(a.b,b,c):Ji(a.a,b,c)}
function Jj(a,b){return Vc(b)!=10&&$c(q(b),b.jb,b.__elementTypeId$,Vc(b),a),a}
function Vc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Cn(a,b){a.f=b;Uh(b,S(a.a))&&Nn(a,b);Gn(b);A((J(),J(),I),new Tn(a),Jp)}
function pl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new El(a),Jp)}}
function fc(a){if(a.i>=0){a.i=-2;t((J(),J(),I),new G(new lc(a)),67108864,null)}}
function cb(a){if(-2!=a.e){t((J(),J(),I),new G(new lb(a)),0,null);!!a.b&&mb(a.b)}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;cb(a.e);2==(a.f.c&7)||mb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function Kc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Oc(b,c)}while(a.a);a.a=c}}
function Lc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Oc(b,c)}while(a.b);a.b=c}}
function Kh(a,b){var c;if(!a){return}b.j=a;var d=Hh(b);if(!d){gh[a]=[b];return}d.ib=b}
function tb(b){if(b){try{b.v()}catch(a){a=Vg(a);if(gd(a,5)){J()}else throw Wg(a)}}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function bb(){var a;this.a=Wc(sd,qp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function bh(){dh();var a=ah;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function lh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Vg(a){var b;if(gd(a,5)){return a}b=a&&a[zp];if(!b){b=new uc(a);Rc(b)}return b}
function Ch(a){var b;b=new Bh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Xj(a){var b;b=Zj($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function $j(a){var b;return Yj($wnd.React.StrictMode,null,null,(b={},b[Fp]=ej(a),b))}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new zi);a.c=c.c}b.d=true;ri(a.c,ej(b))}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;ri((!a.b&&(a.b=new zi),a.b),b)}}}
function Yi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ni(a.a,b);--a.b}return c}
function Ci(a){var b,c,d;d=0;for(c=new li(a.a);c.b;){b=ki(c);d=d+(b?r(b):0);d=d|0}return d}
function $h(a,b){var c,d;for(d=new li(b.a);d.b;){c=ki(d);if(!hi(a,c)){return false}}return true}
function qb(a){var b,c;for(c=new Bi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function io(a,b,c){var d;d=new fo(b,c);Yn(d,a,new dc(a,d));di(a.g,Oh(d.c.d),d);hb(a.d);return d}
function Yj(a,b,c,d){var e;e=Zj($wnd.React.Element,a);e.key=b;e.ref=c;e.props=ej(d);return e}
function ln(a,b){Wj(a.a,(zh(Uf),Uf.k+(''+(b?Oh(b.c.d):null))));ej(b);a.a.props['a']=b;return a.a}
function ji(a){if(a.a.U()){return true}if(a.a!=a.c){return false}a.a=new Mi(a.d.a);return a.a.U()}
function Yg(a){var b;b=a.h;if(b==0){return a.l+a.m*wp}if(b==1048575){return a.l+a.m*wp-Cp}return a}
function $g(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Cp;d=1048575}c=nd(e/wp);b=nd(e-c*wp);return _c(b,c,d)}
function Gi(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(Ei(a,c.X())){return c}}return null}
function _b(a,b,c){var d;d=ei(a.g,b?Oh(b.c.d):null);if(null!=d){jc(b.c,a);c&&!!b&&fc(b.c);hb(a.d)}}
function Mb(a,b){this.b=ej(a);this.a=b|0|(0==(b&6291456)?wp:0)|(0!=(b&229376)?0:98304)}
function xb(a,b,c){wb.call(this,null,a,b,c|(!a?262144:sp)|(0==(c&6291456)?!a?vp:wp:0)|0|0|0)}
function Mh(){qc.call(this,"Stream already terminated, can't be modified or used")}
function kd(a){return a!=null&&(typeof a===np||typeof a==='function')&&!(a.kb===oh)}
function fh(a,b){typeof window===np&&typeof window['$gwt']===np&&(window['$gwt'][a]=b)}
function ep(){ep=kh;bp=new fp('ACTIVE',0);dp=new fp('COMPLETED',1);cp=new fp('ALL',2)}
function tn(){this.a=rh((Ao(),Ao(),zo));this.b=rh(new Mo(this.a));this.c=rh(new _o(this.a))}
function Bh(){this.g=yh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function uc(a){sc();mc(this);this.e=a;a!=null&&Kj(a,zp,this);this.f=a==null?Bp:nh(a);this.a='';this.b=a;this.a=''}
function To(a){var b;b=S(a.i.a);Uh(Op,b)||Uh(Pp,b)||Uh('',b)?Jn(a.i,b):No(Kn(a.i))?Mn(a.i):Jn(a.i,'')}
function S(a){ib(a.e);vb(a.f)&&ob(a.f);if(a.b){if(gd(a.b,8)){throw Wg(a.b)}else{throw Wg(a.b)}}return a.k}
function $c(a,b,c,d,e){e.ib=a;e.jb=b;e.kb=oh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Xi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function fb(a,b){var c,d;d=a.c;wi(d,b);!!a.b&&sp!=(a.b.c&tp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function Kl(a,b,c){27==c.which?A((J(),J(),I),new jm(a,b),Jp):13==c.which&&A((J(),J(),I),new hm(a,b),Jp)}
function mb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new Bb(a)),67108864,null);!!a.a&&R(a.a);Ib(a.f);a.c=a.c&-8|1}}
function Pk(){if(!Ok){Ok=(++(J(),J(),I).e,new Hb);$wnd.Promise.resolve(null).then(lh(Qk.prototype.G,Qk,[]))}}
function Nk(){Lk();return $c(Uc(Ue,1),qp,7,0,[pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk])}
function q(a){return ld(a)?he:jd(a)?Yd:hd(a)?Wd:fd(a)?a.ib:Yc(a)?a.ib:a.ib||Array.isArray(a)&&Uc(Od,1)||Od}
function p(a,b){return ld(a)?Uh(a,b):jd(a)?a===b:hd(a)?a===b:fd(a)?a.o(b):Yc(a)?a===b:!!a&&!!a.equals?a.equals(b):md(a)===md(b)}
function r(a){return ld(a)?Sj(a):jd(a)?nd(a):hd(a)?a?1231:1237:fd(a)?a.q():Yc(a)?Mj(a):!!a&&!!a.hashCode?a.hashCode():Mj(a)}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&sp)?Lb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Ol(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;$l(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=vi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function Y(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Oh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Qh(),Ph)[b];!c&&(c=Ph[b]=new Nh(a));return c}return new Nh(a)}
function nh(a){var b;if(Array.isArray(a)&&a.kb===oh){return Ah(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Sj(a){Qj();var b,c,d;c=':'+a;d=Pj[c];if(d!=null){return nd(d)}d=Nj[c];b=d==null?Rj(a):nd(d);Tj();Pj[c]=b;return b}
function Di(a){var b,c,d;d=1;for(c=new Bi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function hc(a){var b,c,d;for(c=new Bi(new Ai(new ii(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.X();gd(d,9)&&d.u()||b.Y().v()}}
function ad(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return _c(c&4194303,d&4194303,e&1048575)}
function Xg(a,b){var c;if(jd(a)&&jd(b)){c=a+b;if(-17592186044416<c&&c<Cp){return c}}return Yg(ad(jd(a)?$g(a):a,jd(b)?$g(b):b))}
function Nl(a,b){var c;c=(ib(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Ko(b,c),Jp);Uo(a.k,null);_l(a,c)}else{lo(a.j,b)}}
function yb(a,b){wb.call(this,a,new zb(a),null,b|(sp==(b&tp)?0:524288)|(0==(b&6291456)?sp==(b&tp)?wp:vp:0)|0|268435456|0)}
function Jh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function yi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Jj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function _h(a,b){var c,d,e;e=gi(a.a);b.length<e&&(b=Jj(new Array(e),b));d=new li(a.a);for(c=0;c<e;++c){b[c]=ki(d)}b.length>e&&(b[e]=null);return b}
function ck(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Bc(){var a;if(wc!=0){a=vc();if(a-xc>2000){xc=a;yc=$wnd.setTimeout(Hc,10)}}if(wc++==0){Kc((Jc(),Ic));return true}return false}
function Sc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a,b,c,d,e){var f;this.d=a;this.e=d?new Fi:null;this.g=b;this.b=c;this.f=null;this.a=e?(f=new kb((J(),null)),f):null;this.c=null}
function U(a,b,c,d){this.c=ej(a);this.g=b;this.i=c;this.j=null;this.k=null;this.f=new yb(this,d);this.e=new kb(this.f);sp==(d&tp)&&nb(this.f)}
function fo(a,b){var c,d,e;this.e=ej(a);this.d=b;J();c=++Wn;this.c=new kc(c,null,new go(this),true,true);this.b=(e=new kb(null),e);this.a=(d=new kb(null),d)}
function il(a,b){var c;this.d=ej(b);this.n=ej(a);J();c=++gl;this.b=new kc(c,null,new jl(this),false,false);this.a=new xb(null,ej(new ml(this)),Ip)}
function ed(a,b){if(ld(a)){return !!dd[b]}else if(a.jb){return !!a.jb[b]}else if(jd(a)){return !!cd[b]}else if(hd(a)){return !!bd[b]}return false}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Bi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Wb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new Bi(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&ub(b,6,true)}}}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Bi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Vh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Xc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function s(b,c,d){var e,f;try{Zb(b,d);try{f=(c.a.v(),null)}finally{$b()}return f}catch(a){a=Vg(a);if(gd(a,5)){e=a;throw Wg(e)}else throw Wg(a)}finally{D(b)}}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.s()}else{Zb(b,e);try{g=c.s()}finally{$b()}}return g}catch(a){a=Vg(a);if(gd(a,5)){f=a;throw Wg(f)}else throw Wg(a)}finally{D(b)}}
function Gn(a){var b;if(0==a.length){b=(uh(),th).location.pathname+(''+th.location.search);th.history.pushState('',sh.title,b)}else{(uh(),th).location.hash=a}}
function Db(a){var b,c;if(0==a.c){b=Z(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Y(a.d);Jb(c);return true}
function eh(b,c,d,e){dh();var f=ah;$moduleName=c;$moduleBase=d;Ug=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{mp(g)()}catch(a){b(c,a)}}else{mp(g)()}}
function zl(a,b){var c,d;this.e=ej(b);this.n=ej(a);J();c=++tl;this.c=new kc(c,null,new Al(this),false,false);this.b=(d=new kb(null),d);this.a=new xb(null,ej(new Gl(this)),Ip)}
function tm(a,b,c,d){var e;this.d=ej(b);this.e=ej(c);this.f=ej(d);this.n=ej(a);J();e=++rm;this.b=new kc(e,null,new um(this),false,false);this.a=new xb(null,ej(new xm(this)),Ip)}
function Zj(a,b){var c;c=new $wnd.Object;c.$$typeof=ej(a);c.type=ej(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Si(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ti()}}
function fl(a){var b,c,d;a.c=0;Pk();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),_j('span',ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,['todo-count'])),[_j('strong',null,[c]),' '+d+' left']));return b}
function hh(){gh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Oc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].lb()&&(c=Nc(c,g)):g[0].lb()}catch(a){a=Vg(a);if(gd(a,5)){d=a;zc();Fc(gd(d,35)?d.D():d)}else throw Wg(a)}}return c}
function sl(a){var b;a.d=0;Pk();b=_j(Kp,gk(jk(kk(nk(lk(ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,['new-todo']))),(ib(a.b),a.f)),lh($m.prototype.fb,$m,[a])),lh(_m.prototype.eb,_m,[a]))),null);return b}
function tc(a){var b;if(a.c==null){b=md(a.b)===md(rc)?null:a.b;a.d=b==null?Bp:kd(b)?b==null?null:b.name:ld(b)?'String':Ah(q(b));a.a=a.a+': '+(kd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.k;try{d=b.c.s();if(!(md(e)===md(d)||e!=null&&p(e,d))){b.k=d;b.b=null;gb(b.e)}}catch(a){a=Vg(a);if(gd(a,11)){c=a;if(!b.b){b.k=null;b.b=c;gb(b.e)}throw Wg(c)}else throw Wg(a)}}
function Ji(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Gi(b,e);if(f){return f.Z(c)}}e[e.length]=new pi(b,c);++a.b;return null}
function Fj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Rj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Th(a,c++)}b=b|0;return b}
function ob(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Vg(a);if(gd(a,5)){J()}else throw Wg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Wc(ee,qp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function ph(){var a;a=new tn;Cm(un(new vn(a)));Fm(new ll((new wn(a)).a.a.F()));on(yn(new zn(a)));sn(An(new Bn(a)));cn(new Cl((new xn(a)).a.b.F()));$wnd.ReactDOM.render($j([(new qn).a]),(uh(),sh).getElementById('app'),null)}
function Yk(a,b,c,d){var e;this.e=ej(b);this.f=ej(c);this.g=ej(d);this.n=ej(a);J();e=++Uk;this.c=new kc(e,null,new Zk(this),false,false);this.a=new U(new al(this),null,null,136478720);this.b=new xb(null,ej(new bl(this)),Ip)}
function am(a,b,c,d){var e,f;this.j=ej(b);ej(c);this.k=ej(d);this.n=ej(a);J();e=++Sl;this.e=new kc(e,null,new bm(this),false,false);this.a=(f=new kb(null),f);this.c=new U(new gm(this),null,null,136478720);this.b=new xb(null,ej(new lm(this)),Ip);$l(this,this.n.props['a'])}
function wb(a,b,c,d){this.b=new zi;this.f=new Mb(new Ab(this),d&6520832|262144|sp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&vp)&&D((null,I)))}
function Ki(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ei(b,e.X())){if(d.length==1){d.length=0;Ni(a.a,g)}else{d.splice(h,1)}--a.b;return e.Y()}}return null}
function jh(a,b,c){var d=gh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=gh[b]),mh(h));_.jb=c;!b&&(_.kb=oh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ib=f)}
function On(){var a,b;this.d=new ap(this);this.f=this.e=(b=(uh(),th).location.hash,null==b?'':b.substr(1));J();this.c=new kc(0,null,new Pn(this),false,false);this.b=(a=new kb(null),a);this.a=new U(new Un,new Qn(this),new Rn(this),35749888)}
function Ih(a){if(a.L()){var b=a.c;b.M()?(a.k='['+b.j):!b.L()?(a.k='[L'+b.J()+';'):(a.k='['+b.J());a.b=b.I()+'[]';a.i=b.K()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Jh('.',[c,Jh('$',d)]);a.b=Jh('.',[c,Jh('.',d)]);a.i=d[d.length-1]}
function ai(a,b){var c,d,e;c=b.X();e=b.Y();d=ld(c)?c==null?ci(Ii(a.a,null)):Wi(a.b,c):ci(Ii(a.a,c));if(!(md(e)===md(d)||e!=null&&p(e,d))){return false}if(d==null&&!(ld(c)?c==null?!!Ii(a.a,null):Vi(a.b,c):!!Ii(a.a,c))){return false}return true}
function _j(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Vj(b,lh(bk.prototype.cb,bk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Fp]=c[0],undefined):(d[Fp]=c,undefined));return Yj(a,e,f,d)}
function qo(){var a;this.g=new Fi;J();this.f=new kc(0,new so(this),new ro(this),false,false);this.d=(a=new kb(null),a);this.c=new U(new vo(this),null,null,Np);this.e=new U(new wo(this),null,null,Np);this.a=new U(new xo(this),null,null,Np);this.b=new U(new yo(this),null,null,Np)}
function Vo(a){var b;this.j=ej(a);this.i=new On;J();this.g=new kc(0,null,new Wo(this),false,false);this.d=(b=new kb(null),b);this.b=new U(new Xo(this),null,null,Np);this.c=new U(new Yo(this),null,null,Np);this.e=u(new Zo(this),413138944);this.a=u(new $o(this),681574400);D((null,I))}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Bi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Vg(a);if(!gd(a,5))throw Wg(a)}if(6==(b.c&7)){return true}}}}}qb(b);return false}
function Ri(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ub(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){jb(a.a.e);tb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;tb((e=d.i,e));d.k=null}si(a.b,new Cb(a));a.b.a=Wc(ee,qp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&tb((f=a.a.g,f))}}
function Lk(){Lk=kh;pk=new Mk(Gp,0);qk=new Mk('checkbox',1);rk=new Mk('color',2);sk=new Mk('date',3);tk=new Mk('datetime',4);uk=new Mk('email',5);vk=new Mk('file',6);wk=new Mk('hidden',7);xk=new Mk('image',8);yk=new Mk('month',9);zk=new Mk(op,10);Ak=new Mk('password',11);Bk=new Mk('radio',12);Ck=new Mk('range',13);Dk=new Mk('reset',14);Ek=new Mk('search',15);Fk=new Mk('submit',16);Gk=new Mk('tel',17);Hk=new Mk('text',18);Ik=new Mk('time',19);Jk=new Mk('url',20);Kk=new Mk('week',21)}
function qm(a){var b,c,d;a.c=0;Pk();d=_j('div',null,[_j('div',null,[_j(Lp,ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,[Lp])),[_j('h1',null,['todos']),(new an).a]),S(a.d.c)?null:_j('section',ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,[Lp])),[_j(Kp,jk(mk(ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,['toggle-all'])),(Lk(),qk)),lh(pn.prototype.eb,pn,[a])),null),_j('ul',ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,['todo-list'])),(b=rj(ej(qj(S(a.f.c).S())),(c=new zi,c)),yi(b,Zc(b.a.length))))]),S(a.d.c)?null:(new Am).a])]);return d}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ti(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&xi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{fb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ti(a.b,g);if(-1==k.e){k.e=0;eb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){vi(a.b,g)}e&&sb(a.e,a.b)}else{e&&sb(a.e,new zi)}if(X(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&sp!=(k.b.c&tp)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function Tk(a){var b,c;a.d=0;Pk();c=(b=S(a.g.b),_j('footer',ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,['footer'])),[(new Dm).a,_j('ul',ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,['filters'])),[_j('li',null,[_j('a',ek(ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,[(ep(),cp)==b?Hp:null])),'#'),['All'])]),_j('li',null,[_j('a',ek(ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,[bp==b?Hp:null])),'#active'),['Active'])]),_j('li',null,[_j('a',ek(ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,[dp==b?Hp:null])),'#completed'),['Completed'])])]),S(a.a)?_j(Gp,fk(ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,['clear-completed'])),lh(zm.prototype.gb,zm,[a])),['Clear Completed']):null]));return c}
function Rl(a){var b,c,d,e;a.f=0;Pk();b=a.n.props['a'];if(b.c.i<0){return null}c=(d=a.n.props['a'],e=(ib(d.a),d.d),_j('li',ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[_j('div',ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,['view'])),[_j(Kp,jk(hk(mk(ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,['toggle'])),(Lk(),qk)),e),lh(en.prototype.eb,en,[d])),null),_j('label',ok(new $wnd.Object,lh(fn.prototype.gb,fn,[a,d])),[(ib(d.b),d.e)]),_j(Gp,fk(ck(new $wnd.Object,$c(Uc(he,1),qp,2,6,['destroy'])),lh(gn.prototype.gb,gn,[a,d])),null)]),_j(Kp,kk(jk(ik(nk(ck(dk(new $wnd.Object,lh(hn.prototype.w,hn,[a])),$c(Uc(he,1),qp,2,6,['edit'])),(ib(a.a),a.d)),lh(jn.prototype.db,jn,[a,d])),lh(dn.prototype.eb,dn,[a])),lh(kn.prototype.fb,kn,[a,d])),null)]));return c}
function Ti(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Ep]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ri()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Ep]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var np='object',op='number',pp={14:1},qp={3:1,4:1},rp={9:1},sp=1048576,tp=1835008,up={6:1},vp=2097152,wp=4194304,xp={22:1},yp='__noinit__',zp='__java$exception',Ap={3:1,11:1,8:1,5:1},Bp='null',Cp=17592186044416,Dp={40:1},Ep='delete',Fp='children',Gp='button',Hp='selected',Ip=1411518464,Jp=142606336,Kp='input',Lp='header',Mp='hashchange',Np=136413184,Op='active',Pp='completed';var _,gh,ah,Ug=-1;hh();jh(1,null,{},o);_.o=Rp;_.p=function(){return this.ib};_.q=Sp;_.r=function(){var a;return Ah(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var bd,cd,dd;jh(54,1,{},Bh);_.H=function(a){var b;b=new Bh;b.e=4;a>1?(b.c=Gh(this,a-1)):(b.c=this);return b};_.I=function(){zh(this);return this.b};_.J=function(){return Ah(this)};_.K=function(){zh(this);return this.i};_.L=function(){return (this.e&4)!=0};_.M=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(zh(this),this.k)};_.e=0;_.g=0;var yh=1;var ee=Dh(1);var Xd=Dh(54);jh(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var rd=Dh(81);jh(36,1,pp,G);_.s=function(){return this.a.v(),null};var pd=Dh(36);jh(82,1,{},H);var qd=Dh(82);var I;jh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var sd=Dh(43);jh(231,1,rp);_.r=function(){var a;return Ah(this.ib)+'@'+(a=r(this)>>>0,a.toString(16))};var vd=Dh(231);jh(20,231,rp,U);_.t=function(){R(this)};_.u=Qp;_.a=false;_.d=0;var td=Dh(20);jh(143,1,{270:1},bb);var ud=Dh(143);jh(18,231,{9:1,18:1},kb);_.t=function(){cb(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var xd=Dh(18);jh(178,1,up,lb);_.v=function(){db(this.a)};var wd=Dh(178);jh(19,231,{9:1,19:1},xb,yb);_.t=function(){mb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Cd=Dh(19);jh(179,1,xp,zb);_.v=function(){Q(this.a)};var yd=Dh(179);jh(180,1,up,Ab);_.v=function(){ob(this.a)};var zd=Dh(180);jh(181,1,up,Bb);_.v=function(){rb(this.a)};var Ad=Dh(181);jh(182,1,{},Cb);_.w=function(a){pb(this.a,a)};var Bd=Dh(182);jh(144,1,{},Fb);_.a=0;_.b=0;_.c=0;var Dd=Dh(144);jh(183,1,rp,Hb);_.t=function(){Gb(this)};_.u=Qp;_.a=false;var Ed=Dh(183);jh(65,231,{9:1,65:1},Mb);_.t=function(){Ib(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Fd=Dh(65);jh(187,1,{},Yb);_.r=function(){var a;return zh(Gd),Gd.k+'@'+(a=Mj(this)>>>0,a.toString(16))};_.a=0;var Nb;var Gd=Dh(187);jh(156,1,{});var Jd=Dh(156);jh(149,1,{},cc);_.w=function(a){ac(this.a,a)};var Hd=Dh(149);jh(150,1,up,dc);_.v=function(){bc(this.a,this.b)};var Id=Dh(150);jh(157,156,{});var Kd=Dh(157);jh(17,1,rp,kc);_.t=function(){fc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return zh(Md),Md.k+'@'+(a=Mj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Md=Dh(17);jh(177,1,up,lc);_.v=function(){ic(this.a)};var Ld=Dh(177);jh(5,1,{3:1,5:1});_.A=function(a){return new Error(a)};_.B=function(){return this.f};_.C=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=Ah(this.ib),c==null?a:a+': '+c);nc(this,pc(this.A(b)));Rc(this)};_.r=function(){return oc(this,this.B())};_.e=yp;_.g=true;var ie=Dh(5);jh(11,5,{3:1,11:1,5:1});var $d=Dh(11);jh(8,11,Ap);var fe=Dh(8);jh(55,8,Ap);var be=Dh(55);jh(76,55,Ap);var Qd=Dh(76);jh(35,76,{35:1,3:1,11:1,8:1,5:1},uc);_.B=function(){tc(this);return this.c};_.D=function(){return md(this.b)===md(rc)?null:this.b};var rc;var Nd=Dh(35);var Od=Dh(0);jh(213,1,{});var Pd=Dh(213);var wc=0,xc=0,yc=-1;jh(90,213,{},Mc);var Ic;var Rd=Dh(90);var Pc;jh(224,1,{});var Td=Dh(224);jh(77,224,{},Tc);var Sd=Dh(77);jh(44,1,{44:1,69:1},qh);_.F=function(){if(this===this.a){this.a=this.b.F();this.b=null}return this.a};var Ud=Dh(44);var sh,th;jh(74,1,{71:1});_.r=Qp;var Vd=Dh(74);bd={3:1,72:1,31:1};var Wd=Dh(72);jh(41,1,{3:1,41:1});var de=Dh(41);cd={3:1,31:1,41:1};var Yd=Dh(223);jh(33,1,{3:1,31:1,33:1});_.o=Rp;_.q=Sp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var Zd=Dh(33);jh(78,8,Ap,Mh);var _d=Dh(78);jh(32,41,{3:1,31:1,32:1,41:1},Nh);_.o=function(a){return gd(a,32)&&a.a==this.a};_.q=Qp;_.r=function(){return ''+this.a};_.a=0;var ae=Dh(32);var Ph;jh(288,1,{});jh(79,55,Ap,Sh);_.A=function(a){return new TypeError(a)};var ce=Dh(79);dd={3:1,71:1,31:1,2:1};var he=Dh(2);jh(75,74,{71:1},Yh);var ge=Dh(75);jh(292,1,{});jh(57,8,Ap,Zh);var je=Dh(57);jh(225,1,{39:1});_.N=Wp;_.R=function(){return new ij(this,0)};_.S=function(){return new sj(null,this.R())};_.P=function(a){throw Wg(new Zh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new kj('[',']');for(b=this.O();b.U();){a=b.V();jj(c,a===this?'(this Collection)':a==null?Bp:nh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ke=Dh(225);jh(229,1,{212:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!gd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new li((new ii(d)).a);c.b;){b=ki(c);if(!ai(this,b)){return false}}return true};_.q=function(){return Ci(new ii(this))};_.r=function(){var a,b,c;c=new kj('{','}');for(b=new li((new ii(this)).a);b.b;){a=ki(b);jj(c,bi(this,a.X())+'='+bi(this,a.Y()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var ve=Dh(229);jh(142,229,{212:1});var ne=Dh(142);jh(228,225,{39:1,237:1});_.R=function(){return new ij(this,1)};_.o=function(a){var b;if(a===this){return true}if(!gd(a,24)){return false}b=a;if(gi(b.a)!=this.Q()){return false}return $h(this,b)};_.q=function(){return Ci(this)};var we=Dh(228);jh(24,228,{24:1,39:1,237:1},ii);_.O=function(){return new li(this.a)};_.Q=Up;var me=Dh(24);jh(25,1,{},li);_.T=Tp;_.V=function(){return ki(this)};_.U=Vp;_.b=false;var le=Dh(25);jh(226,225,{39:1,233:1});_.R=function(){return new ij(this,16)};_.W=function(a,b){throw Wg(new Zh('Add not supported on this list'))};_.P=function(a){this.W(this.Q(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!gd(a,13)){return false}f=a;if(this.Q()!=f.a.length){return false}e=new Bi(f);for(c=new Bi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(md(b)===md(d)||b!=null&&p(b,d))){return false}}return true};_.q=function(){return Di(this)};_.O=function(){return new mi(this)};var pe=Dh(226);jh(89,1,{},mi);_.T=Tp;_.U=function(){return this.a<this.b.a.length};_.V=function(){return ti(this.b,this.a++)};_.a=0;var oe=Dh(89);jh(59,225,{39:1},ni);_.O=function(){var a;a=new li((new ii(this.a)).a);return new oi(a)};_.Q=Up;var re=Dh(59);jh(141,1,{},oi);_.T=Tp;_.U=function(){return this.a.b};_.V=function(){var a;a=ki(this.a);return a.Y()};var qe=Dh(141);jh(139,1,Dp);_.o=function(a){var b;if(!gd(a,40)){return false}b=a;return Ei(this.a,b.X())&&Ei(this.b,b.Y())};_.X=Qp;_.Y=Vp;_.q=function(){return dj(this.a)^dj(this.b)};_.Z=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var se=Dh(139);jh(140,139,Dp,pi);var te=Dh(140);jh(230,1,Dp);_.o=function(a){var b;if(!gd(a,40)){return false}b=a;return Ei(this.b.value[0],b.X())&&Ei(_i(this),b.Y())};_.q=function(){return dj(this.b.value[0])^dj(_i(this))};_.r=function(){return this.b.value[0]+'='+_i(this)};var ue=Dh(230);jh(13,226,{3:1,13:1,39:1,233:1},zi,Ai);_.W=function(a,b){Gj(this.a,a,b)};_.P=function(a){return ri(this,a)};_.N=function(a){si(this,a)};_.O=function(){return new Bi(this)};_.Q=function(){return this.a.length};var ye=Dh(13);jh(16,1,{},Bi);_.T=Tp;_.U=function(){return this.a<this.c.a.length};_.V=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var xe=Dh(16);jh(37,142,{3:1,37:1,212:1},Fi);var ze=Dh(37);jh(62,1,{},Li);_.N=Wp;_.O=function(){return new Mi(this)};_.b=0;var Be=Dh(62);jh(63,1,{},Mi);_.T=Tp;_.V=function(){return this.d=this.a[this.c++],this.d};_.U=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ae=Dh(63);var Pi;jh(60,1,{},Zi);_.N=Wp;_.O=function(){return new $i(this)};_.b=0;_.c=0;var Ee=Dh(60);jh(61,1,{},$i);_.T=Tp;_.V=function(){return this.c=this.a,this.a=this.b.next(),new aj(this.d,this.c,this.d.c)};_.U=function(){return !this.a.done};var Ce=Dh(61);jh(148,230,Dp,aj);_.X=function(){return this.b.value[0]};_.Y=function(){return _i(this)};_.Z=function(a){return Xi(this.a,this.b.value[0],a)};_.c=0;var De=Dh(148);jh(197,1,{});_.T=function(a){fj(this,a)};_.$=function(){return this.d};_._=function(){return this.e};_.d=0;_.e=0;var Ge=Dh(197);jh(66,197,{});var Fe=Dh(66);jh(23,1,{},ij);_.$=Qp;_._=function(){hj(this);return this.c};_.T=function(a){hj(this);this.d.T(a)};_.ab=function(a){hj(this);if(this.d.U()){a.w(this.d.V());return true}return false};_.a=0;_.c=0;var He=Dh(23);jh(56,1,{},kj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ie=Dh(56);jh(196,1,{});_.c=false;var Re=Dh(196);jh(28,196,{273:1,28:1},sj);var Qe=Dh(28);jh(199,66,{},wj);_.ab=function(a){this.b=false;while(!this.b&&this.c.ab(new xj(this,a)));return this.b};_.b=false;var Ke=Dh(199);jh(202,1,{},xj);_.w=function(a){vj(this.a,this.b,a)};var Je=Dh(202);jh(198,66,{},yj);_.ab=function(a){return this.a.ab(new zj(a))};var Me=Dh(198);jh(201,1,{},zj);_.w=function(a){this.a.w(ln(new mn,a))};var Le=Dh(201);jh(200,1,{},Bj);_.w=function(a){Aj(this,a)};var Ne=Dh(200);jh(203,1,{},Cj);_.w=function(a){};var Oe=Dh(203);jh(204,1,{},Ej);_.w=function(a){Dj(this,a)};var Pe=Dh(204);jh(290,1,{});jh(232,1,{});var Se=Dh(232);jh(287,1,{});var Lj=0;var Nj,Oj=0,Pj;jh(914,1,{});jh(227,1,{});var Te=Dh(227);jh(272,$wnd.Function,{},bk);_.cb=function(a){ak(this.a,this.b,a)};jh(7,33,{3:1,31:1,33:1,7:1},Mk);var pk,qk,rk,sk,tk,uk,vk,wk,xk,yk,zk,Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk;var Ue=Eh(7,Nk);var Ok;jh(271,$wnd.Function,{},Qk);_.G=function(a){return Gb(Ok),Ok=null,null};jh(91,227,{});var Gf=Dh(91);jh(92,91,{});_.d=0;var Kf=Dh(92);jh(93,92,rp,Yk);_.t=Xp;_.o=Rp;_.q=Sp;_.u=Yp;_.r=function(){var a;return zh(df),df.k+'@'+(a=Mj(this)>>>0,a.toString(16))};var Uk=0;var df=Dh(93);jh(95,1,up,Zk);_.v=function(){Vk(this.a)};var Ve=Dh(95);jh(94,1,{},_k);var We=Dh(94);jh(96,1,pp,al);_.s=function(){return Wk(this.a)};var Xe=Dh(96);jh(97,1,xp,bl);_.v=function(){Sk(this.a)};var Ye=Dh(97);jh(98,1,pp,cl);_.s=function(){return Tk(this.a)};var Ze=Dh(98);jh(100,227,{});var Ff=Dh(100);jh(101,100,{});_.c=0;var Jf=Dh(101);jh(102,101,rp,il);_.t=Zp;_.o=Rp;_.q=Sp;_.u=$p;_.r=function(){var a;return zh(cf),cf.k+'@'+(a=Mj(this)>>>0,a.toString(16))};var gl=0;var cf=Dh(102);jh(104,1,up,jl);_.v=_p;var $e=Dh(104);jh(103,1,{},ll);var _e=Dh(103);jh(105,1,xp,ml);_.v=function(){el(this.a)};var af=Dh(105);jh(106,1,pp,nl);_.s=function(){return fl(this.a)};var bf=Dh(106);jh(129,227,{});_.f='';var Sf=Dh(129);jh(130,129,{});_.d=0;var Mf=Dh(130);jh(131,130,rp,zl);_.t=Xp;_.o=Rp;_.q=Sp;_.u=Yp;_.r=function(){var a;return zh(lf),lf.k+'@'+(a=Mj(this)>>>0,a.toString(16))};var tl=0;var lf=Dh(131);jh(133,1,up,Al);_.v=function(){ul(this.a)};var ef=Dh(133);jh(132,1,{},Cl);var ff=Dh(132);jh(135,1,pp,Dl);_.s=function(){return sl(this.a)};var gf=Dh(135);jh(136,1,up,El);_.v=function(){ol(this.a)};var hf=Dh(136);jh(137,1,up,Fl);_.v=function(){wl(this.a,this.b)};var jf=Dh(137);jh(134,1,xp,Gl);_.v=function(){Sk(this.a)};var kf=Dh(134);jh(108,227,{});_.i=false;var Uf=Dh(108);jh(109,108,{});_.f=0;var Of=Dh(109);jh(110,109,rp,am);_.t=function(){fc(this.e)};_.o=Rp;_.q=Sp;_.u=function(){return this.e.i<0};_.r=function(){var a;return zh(xf),xf.k+'@'+(a=Mj(this)>>>0,a.toString(16))};var Sl=0;var xf=Dh(110);jh(112,1,up,bm);_.v=function(){Tl(this.a)};var mf=Dh(112);jh(111,1,{},dm);var nf=Dh(111);jh(115,1,pp,em);_.s=function(){return Rl(this.a)};var of=Dh(115);jh(42,1,up,fm);_.v=function(){_l(this.a,Kn(this.b))};var pf=Dh(42);jh(113,1,pp,gm);_.s=function(){return Vl(this.a)};var qf=Dh(113);jh(58,1,up,hm);_.v=function(){Nl(this.a,this.b)};var rf=Dh(58);jh(116,1,up,im);_.v=function(){Ml(this.a,this.b)};var sf=Dh(116);jh(117,1,up,jm);_.v=function(){Ll(this.a,this.b)};var tf=Dh(117);jh(118,1,up,km);_.v=function(){Hl(this.a,this.b)};var uf=Dh(118);jh(114,1,xp,lm);_.v=function(){Ql(this.a)};var vf=Dh(114);jh(119,1,up,mm);_.v=function(){Ol(this.a)};var wf=Dh(119);jh(121,227,{});var Wf=Dh(121);jh(122,121,{});_.c=0;var Qf=Dh(122);jh(123,122,rp,tm);_.t=Zp;_.o=Rp;_.q=Sp;_.u=$p;_.r=function(){var a;return zh(Cf),Cf.k+'@'+(a=Mj(this)>>>0,a.toString(16))};var rm=0;var Cf=Dh(123);jh(125,1,up,um);_.v=_p;var yf=Dh(125);jh(124,1,{},wm);var zf=Dh(124);jh(126,1,xp,xm);_.v=function(){el(this.a)};var Af=Dh(126);jh(127,1,pp,ym);_.s=function(){return qm(this.a)};var Bf=Dh(127);jh(253,$wnd.Function,{},zm);_.gb=function(a){Eo(this.a.f)};jh(185,1,{},Am);var Df=Dh(185);var Bm;jh(207,1,{},Dm);var Ef=Dh(207);var Em;jh(254,$wnd.Function,{},Gm);_.hb=function(a){return new Jm(a)};var Hm;jh(99,$wnd.React.Component,{},Jm);ih(gh[1],_);_.componentWillUnmount=function(){Rk(this.a)};_.render=function(){return Xk(this.a)};_.shouldComponentUpdate=aq;var Hf=Dh(99);jh(255,$wnd.Function,{},Km);_.hb=function(a){return new Nm(a)};var Lm;jh(107,$wnd.React.Component,{},Nm);ih(gh[1],_);_.componentWillUnmount=function(){dl(this.a)};_.render=function(){return hl(this.a)};_.shouldComponentUpdate=bq;var If=Dh(107);jh(269,$wnd.Function,{},Om);_.hb=function(a){return new Rm(a)};var Pm;jh(138,$wnd.React.Component,{},Rm);ih(gh[1],_);_.componentWillUnmount=function(){Rk(this.a)};_.render=function(){return xl(this.a)};_.shouldComponentUpdate=aq;var Lf=Dh(138);jh(256,$wnd.Function,{},Sm);_.hb=function(a){return new Vm(a)};var Tm;jh(120,$wnd.React.Component,{},Vm);ih(gh[1],_);_.componentDidUpdate=function(a){Yl(this.a)};_.componentWillUnmount=function(){Pl(this.a)};_.render=function(){return Zl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Nf=Dh(120);jh(266,$wnd.Function,{},Wm);_.hb=function(a){return new Zm(a)};var Xm;jh(128,$wnd.React.Component,{},Zm);ih(gh[1],_);_.componentWillUnmount=function(){dl(this.a)};_.render=function(){return sm(this.a)};_.shouldComponentUpdate=bq;var Pf=Dh(128);jh(267,$wnd.Function,{},$m);_.fb=function(a){pl(this.a,a)};jh(268,$wnd.Function,{},_m);_.eb=function(a){vl(this.a,a)};jh(184,1,{},an);var Rf=Dh(184);var bn;jh(263,$wnd.Function,{},dn);_.eb=function(a){Ul(this.a,a)};jh(257,$wnd.Function,{},en);_.eb=function(a){eo(this.a)};jh(259,$wnd.Function,{},fn);_.gb=function(a){Wl(this.a,this.b)};jh(260,$wnd.Function,{},gn);_.gb=function(a){Il(this.a,this.b)};jh(261,$wnd.Function,{},hn);_.w=function(a){Jl(this.a,a)};jh(262,$wnd.Function,{},jn);_.db=function(a){Xl(this.a,this.b)};jh(264,$wnd.Function,{},kn);_.fb=function(a){Kl(this.a,this.b,a)};jh(206,1,{},mn);var Tf=Dh(206);var nn;jh(265,$wnd.Function,{},pn);_.eb=function(a){nm(this.a,a)};jh(70,1,{},qn);var Vf=Dh(70);var rn;jh(83,1,{},tn);var ag=Dh(83);jh(84,1,{},vn);var Xf=Dh(84);jh(88,1,{},wn);var Yf=Dh(88);jh(87,1,{},xn);var Zf=Dh(87);jh(85,1,{},zn);var $f=Dh(85);jh(86,1,{},Bn);var _f=Dh(86);jh(188,1,{});var Jg=Dh(188);jh(189,188,rp,On);_.t=Xp;_.o=Rp;_.q=Sp;_.u=Yp;_.r=function(){var a;return zh(ig),ig.k+'@'+(a=Mj(this)>>>0,a.toString(16))};var ig=Dh(189);jh(190,1,up,Pn);_.v=function(){In(this.a)};var bg=Dh(190);jh(192,1,xp,Qn);_.v=function(){Dn(this.a)};var cg=Dh(192);jh(193,1,xp,Rn);_.v=function(){En(this.a)};var dg=Dh(193);jh(195,1,up,Sn);_.v=function(){Ln(this.a)};var eg=Dh(195);jh(64,1,up,Tn);_.v=function(){Hn(this.a)};var fg=Dh(64);jh(191,1,pp,Un);_.s=function(){var a;return a=(uh(),th).location.hash,null==a?'':a.substr(1)};var gg=Dh(191);jh(194,1,up,Vn);_.v=function(){Cn(this.a,this.b)};var hg=Dh(194);jh(48,1,{48:1});_.d=false;var Rg=Dh(48);jh(49,48,{9:1,274:1,49:1,48:1},fo);_.t=Xp;_.o=function(a){return Zn(this,a)};_.q=function(){return this.c.d};_.u=Yp;_.r=function(){var a;return zh(Ag),Ag.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Wn=0;var Ag=Dh(49);jh(208,1,up,go);_.v=function(){Xn(this.a)};var jg=Dh(208);jh(209,1,up,ho);_.v=function(){ao(this.a)};var kg=Dh(209);jh(45,157,{45:1});var Mg=Dh(45);jh(158,45,{9:1,45:1},qo);_.t=function(){fc(this.f)};_.o=Rp;_.q=Sp;_.u=function(){return this.f.i<0};_.r=function(){var a;return zh(ug),ug.k+'@'+(a=Mj(this)>>>0,a.toString(16))};var ug=Dh(158);jh(160,1,up,ro);_.v=function(){jo(this.a)};var lg=Dh(160);jh(159,1,up,so);_.v=function(){no(this.a)};var mg=Dh(159);jh(165,1,up,to);_.v=function(){_b(this.a,this.b,true)};var ng=Dh(165);jh(166,1,pp,uo);_.s=function(){return io(this.a,this.c,this.b)};_.b=false;var og=Dh(166);jh(161,1,pp,vo);_.s=function(){return oo(this.a)};var pg=Dh(161);jh(162,1,pp,wo);_.s=function(){return Oh(_g(oj(mo(this.a))))};var qg=Dh(162);jh(163,1,pp,xo);_.s=function(){return Oh(_g(oj(pj(mo(this.a),new hp))))};var rg=Dh(163);jh(164,1,pp,yo);_.s=function(){return po(this.a)};var sg=Dh(164);jh(145,1,{69:1},Bo);_.F=function(){return new qo};var zo;var tg=Dh(145);jh(46,1,{46:1});var Qg=Dh(46);jh(167,46,{9:1,46:1},Io);_.t=function(){fc(this.a)};_.o=Rp;_.q=Sp;_.u=function(){return this.a.i<0};_.r=function(){var a;return zh(zg),zg.k+'@'+(a=Mj(this)>>>0,a.toString(16))};var zg=Dh(167);jh(168,1,up,Jo);_.v=function(){Fo(this.a,this.b)};_.b=false;var vg=Dh(168);jh(169,1,up,Ko);_.v=function(){Nn(this.b,this.a)};var wg=Dh(169);jh(170,1,up,Lo);_.v=function(){Go(this.a)};var xg=Dh(170);jh(146,1,{69:1},Mo);_.F=function(){return new Io(this.a.F())};var yg=Dh(146);jh(47,1,{47:1});var Tg=Dh(47);jh(171,47,{9:1,47:1},Vo);_.t=function(){fc(this.g)};_.o=Rp;_.q=Sp;_.u=function(){return this.g.i<0};_.r=function(){var a;return zh(Hg),Hg.k+'@'+(a=Mj(this)>>>0,a.toString(16))};var Hg=Dh(171);jh(172,1,up,Wo);_.v=function(){Po(this.a)};var Bg=Dh(172);jh(173,1,pp,Xo);_.s=function(){var a;return a=Kn(this.a.i),Uh(Op,a)?(ep(),bp):Uh(Pp,a)?(ep(),dp):(ep(),cp)};var Cg=Dh(173);jh(174,1,pp,Yo);_.s=function(){return Ro(this.a)};var Dg=Dh(174);jh(175,1,xp,Zo);_.v=function(){So(this.a)};var Eg=Dh(175);jh(176,1,xp,$o);_.v=function(){To(this.a)};var Fg=Dh(176);jh(147,1,{69:1},_o);_.F=function(){return new Vo(this.a.F())};var Gg=Dh(147);jh(186,1,{},ap);_.handleEvent=function(a){Fn(this.a,a)};var Ig=Dh(186);jh(34,33,{3:1,31:1,33:1,34:1},fp);var bp,cp,dp;var Kg=Eh(34,gp);jh(151,1,{},hp);_.bb=function(a){return !_n(a)};var Lg=Dh(151);jh(153,1,{},ip);_.bb=function(a){return _n(a)};var Ng=Dh(153);jh(154,1,{},jp);_.w=function(a){lo(this.a,a)};var Og=Dh(154);jh(152,1,{},kp);_.w=function(a){Do(this.a,a)};_.a=false;var Pg=Dh(152);jh(155,1,{},lp);_.bb=function(a){return Oo(this.a,a)};var Sg=Dh(155);var od=Fh('D');var mp=(zc(),Cc);var gwtOnLoad=gwtOnLoad=eh;bh(ph);fh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();