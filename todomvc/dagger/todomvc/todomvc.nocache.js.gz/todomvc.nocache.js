function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='949281695D751E3575BEFCB2FC155620',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '949281695D751E3575BEFCB2FC155620';function p(){}
function Ah(){}
function wh(){}
function Fb(){}
function Fj(){}
function Tj(){}
function _j(){}
function Qc(){}
function Xc(){}
function ji(){}
function jn(){}
function en(){}
function nn(){}
function rn(){}
function vn(){}
function Qn(){}
function ak(){}
function Ak(){}
function ol(){}
function vo(){}
function $o(){}
function Hp(){}
function Ip(){}
function Vc(a){Uc()}
function an(a){_m=a}
function dn(a){cn=a}
function Dn(a){Cn=a}
function On(a){Nn=a}
function Tn(a){Sn=a}
function Jh(){Jh=wh}
function Mi(){Di(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Ai(a){this.a=a}
function ii(a){this.a=a}
function vi(a){this.a=a}
function Bi(a){this.a=a}
function fc(a){this.a=a}
function oc(a){this.a=a}
function Zh(a){this.a=a}
function Gj(a){this.a=a}
function ck(a){this.a=a}
function xl(a){this.a=a}
function Al(a){this.a=a}
function Bl(a){this.a=a}
function Cl(a){this.a=a}
function Jl(a){this.a=a}
function Ml(a){this.a=a}
function Nl(a){this.a=a}
function $l(a){this.a=a}
function bm(a){this.a=a}
function cm(a){this.a=a}
function em(a){this.a=a}
function Bm(a){this.a=a}
function Em(a){this.a=a}
function Jm(a){this.a=a}
function Lm(a){this.a=a}
function Mm(a){this.a=a}
function Um(a){this.a=a}
function Xm(a){this.a=a}
function Ym(a){this.a=a}
function Zm(a){this.a=a}
function zn(a){this.a=a}
function An(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function In(a){this.a=a}
function Pn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function Yn(a){this.a=a}
function $n(a){this.a=a}
function ao(a){this.a=a}
function po(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function to(a){this.a=a}
function uo(a){this.a=a}
function Ho(a){this.a=a}
function Io(a){this.a=a}
function So(a){this.a=a}
function To(a){this.a=a}
function Wo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function kp(a){this.a=a}
function lp(a){this.a=a}
function up(a){this.a=a}
function vp(a){this.a=a}
function wp(a){this.a=a}
function xp(a){this.a=a}
function yp(a){this.a=a}
function zp(a){this.a=a}
function Ap(a){this.a=a}
function Jp(a){this.a=a}
function Kp(a){this.a=a}
function Lp(a){this.a=a}
function zi(a){this.b=a}
function Oi(a){this.c=a}
function wq(){ic(this.c)}
function yq(){ic(this.b)}
function Dq(){ic(this.f)}
function $i(){this.a=hj()}
function mj(){this.a=hj()}
function $j(a,b){a.a=b}
function tk(a,b){a.key=b}
function sk(a,b){rk(a,b)}
function cp(a,b){zm(b,a)}
function pq(a){qj(this,a)}
function uq(a){uj(this,a)}
function sq(a){bi(this,a)}
function db(a){Yb((J(),a))}
function eb(a){Zb((J(),a))}
function hb(a){$b((J(),a))}
function Y(a){!!a&&$(a)}
function jc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function qb(a,b){a.b=tj(b)}
function gm(a,b){Mo(a.j,b)}
function bp(a,b){Lo(a.b,b)}
function bk(a,b){Sj(a.a,b)}
function mc(a,b){ri(a.e,b)}
function C(a,b){Ob(a.f,b.f)}
function Aq(){kb(this.a.a)}
function Ll(a){this.a=tj(a)}
function am(a){this.a=tj(a)}
function Ib(a){a.a=-4&a.a|1}
function pl(a){a.d=2;ic(a.c)}
function Dl(a){a.c=2;ic(a.b)}
function lm(a){a.f=2;ic(a.e)}
function io(a){R(a.a);$(a.b)}
function xo(a){$(a.b);$(a.a)}
function tl(a){kb(a.b);R(a.a)}
function Ul(a){kb(a.a);$(a.b)}
function hh(a){return a.e}
function hm(a,b){return a.g=b}
function rq(){return this.b}
function nq(){return this.a}
function tq(){return this.e}
function oq(){return jk(this)}
function Gi(a,b){return a.a[b]}
function rc(a,b){a.e=b;qc(a,b)}
function gk(a,b){a.splice(b,1)}
function hc(a,b,c){qi(a.e,b,c)}
function yo(a,b,c){hc(a.c,b,c)}
function zj(a,b,c){b.w(a.a[c])}
function Ih(a){uc.call(this,a)}
function ki(a){uc.call(this,a)}
function vq(a){return this===a}
function Mh(a){Lh(a);return a.k}
function Yc(a,b){return Sh(a,b)}
function K(a,b){O(a);L(a,tj(b))}
function ab(a){J();Zb(a);a.e=-2}
function J(){J=wh;I=new F}
function wc(){wc=wh;vc=new p}
function Nc(){Nc=wh;Mc=new Qc}
function ap(){ap=wh;_o=new $o}
function dj(){dj=wh;cj=fj()}
function Dc(){Dc=wh;!!(Uc(),Tc)}
function ci(){pc(this);this.G()}
function qq(){return ti(this.a)}
function xq(){return this.c.i<0}
function zq(){return this.b.i<0}
function Eq(){return this.f.i<0}
function hj(){dj();return new cj}
function Rj(a,b){a.T(b);return a}
function Dk(a,b){a.ref=b;return a}
function ko(a){fb(a.b);return a.e}
function Bo(a){fb(a.a);return a.d}
function pp(a){fb(a.d);return a.e}
function T(a){mb(a.f);return V(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function Sj(a,b){$j(a,Rj(a.a,b))}
function uj(a,b){while(a.eb(b));}
function Xj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function jj(a,b){return a.a.get(b)}
function ti(a){return a.a.b+a.b.b}
function Bq(a){return 1==this.a.d}
function Cq(a){return 1==this.a.c}
function Ci(a,b){this.a=a;this.b=b}
function gc(a,b){this.a=a;this.b=b}
function Xh(a,b){this.a=a;this.b=b}
function Wj(a,b){this.a=a;this.b=b}
function Zj(a,b){this.a=a;this.b=b}
function Bk(a,b){this.a=a;this.b=b}
function dm(a,b){this.a=a;this.b=b}
function Fm(a,b){this.a=a;this.b=b}
function Gm(a,b){this.a=a;this.b=b}
function Hm(a,b){this.a=a;this.b=b}
function Im(a,b){this.a=a;this.b=b}
function Km(a,b){this.a=a;this.b=b}
function Gn(a,b){this.a=a;this.b=b}
function Hn(a,b){this.a=a;this.b=b}
function Jn(a,b){this.a=a;this.b=b}
function Kn(a,b){this.a=a;this.b=b}
function kl(a,b){Xh.call(this,a,b)}
function ek(a,b,c){a.splice(b,0,c)}
function Ek(a,b){a.href=b;return a}
function so(a,b){this.a=a;this.b=b}
function Uo(a,b){this.a=a;this.b=b}
function ip(a,b){this.a=a;this.b=b}
function jp(a,b){this.b=a;this.a=b}
function Fp(a,b){Xh.call(this,a,b)}
function ph(){nh==null&&(nh=[])}
function $m(){this.a=uk((gn(),fn))}
function bn(){this.a=uk((ln(),kn))}
function Bn(){this.a=uk((pn(),on))}
function Mn(){this.a=uk((tn(),sn))}
function Rn(){this.a=uk((xn(),wn))}
function lo(a){jo(a,(fb(a.b),a.e))}
function Co(a){zm(a,(fb(a.a),!a.d))}
function Ub(a){return !a.d?a:Ub(a.d)}
function pi(a){return !a?null:a.ab()}
function pd(a){return a==null?null:a}
function sj(a){return a!=null?s(a):0}
function md(a){return typeof a===Op}
function o(a,b){return pd(a)===pd(b)}
function Kc(a){$wnd.clearTimeout(a)}
function Di(a){a.a=$c(je,Qp,1,0,5,1)}
function si(a){a.a=new $i;a.b=new mj}
function ib(a){this.c=new Mi;this.b=a}
function nk(){nk=wh;kk=new p;mk=new p}
function Hk(a,b){a.checked=b;return a}
function Nk(a,b){a.value=b;return a}
function Ik(a,b){a.onBlur=b;return a}
function Fk(a,b){a.onClick=b;return a}
function gi(a,b){a.a+=''+b;return a}
function Jk(a,b){a.onChange=b;return a}
function fk(a,b){dk(b,0,a,0,b.length)}
function ec(a,b){cc(a,b,false);eb(a.d)}
function pm(a){kb(a.b);R(a.c);$(a.a)}
function pb(a){J();ob(a);sb(a,2,true)}
function fb(a){var b;Vb((J(),b=Qb,b),a)}
function Db(a){this.d=tj(a);this.b=100}
function Ch(a){this.b=tj(a);this.a=this}
function P(){this.a=$c(je,Qp,1,100,5,1)}
function B(a,b,c){return u(a,c,2048,b)}
function cd(a,b,c){return {l:a,m:b,h:c}}
function di(a,b){return a.charCodeAt(b)}
function kd(a,b){return a!=null&&hd(a,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function jk(a){return a.$H||(a.$H=++ik)}
function od(a){return typeof a==='string'}
function Kk(a,b){a.onKeyDown=b;return a}
function Gk(a){a.autoFocus=true;return a}
function Lh(a){if(a.k!=null){return}Uh(a)}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function uc(a){this.g=a;pc(this);this.G()}
function Qj(a,b){Jj.call(this,a);this.a=b}
function rk(a,b){for(var c in a){b(c)}}
function A(a,b,c){u(a,new G(b),c,null)}
function Kl(a,b){return new Il(tj(b),a.a)}
function _l(a,b){return new Zl(tj(b),a.a)}
function ld(a){return typeof a==='boolean'}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function dc(a,b){mc(b.c,a);kd(b,9)&&b.t()}
function qj(a,b){while(a.Y()){bk(b,a.Z())}}
function aj(a,b){var c;c=a[bq];c.call(a,b)}
function op(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function dp(a){A((J(),J(),I),new kp(a),gq)}
function wm(a){A((J(),J(),I),new Lm(a),gq)}
function mo(a){A((J(),J(),I),new to(a),gq)}
function Fo(a){A((J(),J(),I),new Io(a),gq)}
function Qo(a){return $h(S(a.e).a-S(a.a).a)}
function Ec(a,b,c){return a.apply(b,c);var d}
function Nb(a,b,c){Ib(tj(c));K(a.a[b],tj(c))}
function pj(a,b,c){this.a=a;this.b=b;this.c=c}
function Ui(){this.a=new $i;this.b=new mj}
function Uc(){Uc=wh;var a;!Wc();a=new Xc;Tc=a}
function ai(){ai=wh;_h=$c(fe,Qp,30,256,0,1)}
function Ph(a){var b;b=Oh(a);Wh(a,b);return b}
function pc(a){a.j&&a.e!==Yp&&a.G();return a}
function Ok(a,b){a.onDoubleClick=b;return a}
function Ei(a,b){a.a[a.a.length]=b;return true}
function Gh(a,b,c,d){a.addEventListener(b,c,d)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Vl(a,b){A((J(),J(),I),new dm(a,b),gq)}
function qm(a,b){A((J(),J(),I),new Km(a,b),gq)}
function um(a,b){A((J(),J(),I),new Hm(a,b),gq)}
function vm(a,b){A((J(),J(),I),new Gm(a,b),gq)}
function ym(a,b){A((J(),J(),I),new Fm(a,b),gq)}
function Mo(a,b){A((J(),J(),I),new Uo(a,b),gq)}
function gp(a,b){A((J(),J(),I),new ip(a,b),gq)}
function xj(a,b){while(a.c<a.d){zj(a,b,a.c++)}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function Vo(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new Pb;this.a=new Db(this.f)}
function Oo(a){bi(new Ai(a.g),new fc(a));si(a.g)}
function mp(a){return o(lq,a)||o(mq,a)||o('',a)}
function ad(a){return Array.isArray(a)&&a.pb===Ah}
function Bj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Wl(a,b){var c;c=b.target;Yl(a,c.value)}
function Kj(a,b){var c;return Oj(a,(c=new Mi,c))}
function Dh(a){tj(a);return kd(a,46)?a:new Ch(a)}
function Qi(a){return new Qj(null,Pi(a,a.length))}
function yl(a,b){return new wl(tj(b),a.a,a.b,a.c)}
function Cm(a,b){return new Am(tj(b),a.a,a.b,a.c)}
function Vm(a,b){return new Tm(tj(b),a.a,a.b,a.c)}
function ij(a,b){return !(a.a.get(b)===undefined)}
function Po(a){return Jh(),0==S(a.e).a?true:false}
function Pi(a,b){return vj(b,a.length),new Aj(a,b)}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ii(a,b){var c;c=a.a[b];gk(a.a,b);return c}
function xi(a){var b;b=a.a.Z();a.b=wi(a);return b}
function Rh(a){var b;b=Oh(a);b.j=a;b.e=1;return b}
function Ko(a){R(a.c);R(a.e);R(a.a);R(a.b);$(a.d)}
function vl(a){return B((J(),J(),I),a.b,new Cl(a))}
function Hl(a){return B((J(),J(),I),a.a,new Nl(a))}
function Xl(a){return B((J(),J(),I),a.a,new bm(a))}
function xm(a){return B((J(),J(),I),a.b,new Em(a))}
function Sm(a){return B((J(),J(),I),a.a,new Ym(a))}
function ul(a){return Jh(),S(a.e.b).a>0?true:false}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function jd(a){return !Array.isArray(a)&&a.pb===Ah}
function ql(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function El(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function mm(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Hj(a){if(!a.b){Ij(a);a.c=true}else{Hj(a.b)}}
function Uj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function Yl(a,b){var c;c=a.f;if(b!=c){a.f=b;eb(a.b)}}
function zm(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function Nm(a,b){var c;c=b.target;gp(a.e,c.checked)}
function Ki(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function ui(a,b){if(b){return ni(a.a,b)}return false}
function Mj(a,b){Ij(a);return new Qj(a,new Vj(b,a.a))}
function Nj(a,b){Ij(a);return new Qj(a,new Yj(b,a.a))}
function jo(a,b){A((J(),J(),I),new so(a,b),75497472)}
function ho(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&no(a,b)}
function gb(a){var b;J();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Hh(a,b,c,d){a.removeEventListener(b,c,d)}
function rm(a,b){sp(a.k,b);A((J(),J(),I),new Fm(a,b),gq)}
function Ti(a,b){return pd(a)===pd(b)||a!=null&&q(a,b)}
function wj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Aj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Cj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function zl(a,b,c){this.a=tj(a);this.b=tj(b);this.c=tj(c)}
function Dm(a,b,c){this.a=tj(a);this.b=tj(b);this.c=tj(c)}
function Wm(a,b,c){this.a=tj(a);this.b=tj(b);this.c=tj(c)}
function Jj(a){if(!a){this.b=null;new Mi}else{this.b=a}}
function tj(a){if(a==null){throw hh(new ci)}return a}
function qk(){if(lk==256){kk=mk;mk=new p;lk=0}++lk}
function mh(a){if(md(a)){return a|0}return a.l|a.m<<22}
function Th(a){if(a.P()){return null}var b=a.j;return sh[b]}
function Mk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Qh(a,b){var c;c=Oh(a);Wh(a,c);c.e=b?8:0;return c}
function no(a,b){var c;c=a.e;if(b!=c){a.e=tj(b);eb(a.b)}}
function fm(a,b){var c;if(S(a.c)){c=b.target;zm(a,c.value)}}
function sc(a,b){var c;c=Mh(a.nb);return b==null?c:c+': '+b}
function oi(a,b){return b===a?'(this Map)':b==null?$p:zh(b)}
function Vn(a){return new zl(a.a.a.I(),a.a.b.I(),a.a.c.I())}
function Zn(a){return new Dm(a.a.a.I(),a.a.b.I(),a.a.c.I())}
function _n(a){return new Wm(a.a.a.I(),a.a.b.I(),a.a.c.I())}
function bi(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function ep(a,b){Kj(No(a.b),new Gj(new Fj)).Q(new Kp(b))}
function sm(a,b){A((J(),J(),I),new Fm(a,b),gq);sp(a.k,null)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Vp)&&D((null,I))}
function Rb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function Fh(){Fh=wh;Eh=$wnd.goog.global.document}
function gn(){gn=wh;var a;fn=(a=xh(en.prototype.mb,en,[]),a)}
function ln(){ln=wh;var a;kn=(a=xh(jn.prototype.mb,jn,[]),a)}
function pn(){pn=wh;var a;on=(a=xh(nn.prototype.mb,nn,[]),a)}
function tn(){tn=wh;var a;sn=(a=xh(rn.prototype.mb,rn,[]),a)}
function xn(){xn=wh;var a;wn=(a=xh(vn.prototype.mb,vn,[]),a)}
function Gp(){Ep();return bd(Yc(Wg,1),Qp,32,0,[Bp,Dp,Cp])}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Ij(a){if(a.b){Ij(a.b)}else if(a.c){throw hh(new Yh)}}
function yh(a){function b(){}
;b.prototype=a||{};return new b}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function Lk(a){a.placeholder='What needs to be done?';return a}
function fo(a,b){b.preventDefault();A((J(),J(),I),new uo(a),gq)}
function No(a){fb(a.d);return new Qj(null,new Cj(new Ai(a.g),0))}
function Xi(a,b){var c;return Vi(b,Wi(a,b==null?0:(c=s(b),c|0)))}
function Wi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Sh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function uh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function zk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function lc(a){jc(a.g);!!a.e&&kc(a);Y(a.a);Y(a.c);jc(a.b);jc(a.f)}
function Ni(a){Di(this);fk(this.a,mi(a,$c(je,Qp,1,ti(a.a),5,1)))}
function _i(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function hn(a){$wnd.React.Component.call(this,a);this.a=yl(_m,this)}
function mn(a){$wnd.React.Component.call(this,a);this.a=Kl(cn,this)}
function qn(a){$wnd.React.Component.call(this,a);this.a=_l(Cn,this)}
function un(a){$wnd.React.Component.call(this,a);this.a=Cm(Nn,this)}
function yn(a){$wnd.React.Component.call(this,a);this.a=Vm(Sn,this)}
function Yj(a,b){wj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function yj(a,b){if(a.c<a.d){zj(a,b,a.c++);return true}return false}
function tm(a){return Jh(),pp(a.k)==a.n.props['a']?true:false}
function co(a){Gh((Fh(),$wnd.goog.global.window),jq,a.d,false)}
function eo(a){Hh((Fh(),$wnd.goog.global.window),jq,a.d,false)}
function fp(a){Kj(Mj(No(a.b),new Ip),new Gj(new Fj)).Q(new Jp(a.b))}
function Lo(a,b){var c;return u((J(),J(),I),new Vo(a,b),gq,(c=null,c))}
function bb(a,b){var c,d;Ei(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Vj(a,b){wj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function nj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function hp(a){this.b=tj(a);J();this.a=new nc(0,null,null,false,false)}
function Lj(a){var b;Hj(a);b=0;while(a.a.eb(new ak)){b=ih(b,1)}return b}
function Oj(a,b){var c;Hj(a);c=new _j;c.a=b;a.a.X(new ck(c));return c.a}
function Dj(a,b){!a.a?(a.a=new ii(a.d)):gi(a.a,a.b);gi(a.a,b);return a}
function ri(a,b){return od(b)?b==null?Zi(a.a,null):lj(a.b,b):Zi(a.a,b)}
function np(a,b){return (Ep(),Cp)==a||(Bp==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Jb(b){try{b.b.v()}catch(a){a=gh(a);if(!kd(a,4))throw hh(a)}}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function oj(a){if(a.a.c!=a.c){return jj(a.a,a.b.value[0])}return a.b.value[1]}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Ol(a){var b;b=fi((fb(a.b),a.f));if(b.length>0){bp(a.e,b);Yl(a,'')}}
function qp(a){var b;return b=S(a.b),Kj(Mj(No(a.i),new Lp(b)),new Gj(new Fj))}
function bo(a,b){a.f=b;o(b,S(a.a))&&no(a,b);go(b);A((J(),J(),I),new uo(a),gq)}
function hk(a,b){return Zc(b)!=10&&bd(r(b),b.ob,b.__elementTypeId$,Zc(b),a),a}
function qi(a,b,c){return od(b)?b==null?Yi(a.a,null,c):kj(a.b,b,c):Yi(a.a,b,c)}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function ic(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new oc(a)),67108864,null)}}
function Pj(a,b){var c;c=Kj(a,new Gj(new Fj));return Li(c,b.fb(c.a.length))}
function Ji(a,b){var c;c=Hi(a,b,0);if(c==-1){return false}gk(a.a,c);return true}
function zo(a,b){var c;if(kd(b,51)){c=b;return a.c.d==c.c.d}else{return false}}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&bd(Yc(a,f),b,c,e,g);return g}
function Hi(a,b,c){for(;c<a.a.length;++c){if(Ti(b,a.a[c])){return c}}return -1}
function V(a){if(a.b){if(kd(a.b,7)){throw hh(a.b)}else{throw hh(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=gh(a);if(kd(a,4)){J()}else throw hh(a)}}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function Pl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new cm(a),gq)}}
function Fi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Pb(){var a;this.a=$c(vd,Qp,45,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function yi(a){this.d=a;this.c=new nj(this.d.b);this.a=this.c;this.b=wi(this)}
function Ej(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Mi);Ei(a.b,b)}}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function bc(){var a;try{Sb(Qb);J()}finally{a=Qb.d;!a&&((J(),J(),I).d=true);Qb=Qb.d}}
function Oh(a){var b;b=new Nh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function xh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Wh(a,b){var c;if(!a){return}b.j=a;var d=Th(b);if(!d){sh[a]=[b];return}d.nb=b}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Mi);a.c=c.c}b.d=true;Ei(a.c,tj(b))}
function lj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{aj(a.a,b);--a.b}return c}
function uk(a){var b;b=wk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function xk(a){var b;return vk($wnd.React.StrictMode,null,null,(b={},b[cq]=tj(a),b))}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nd(a){return a!=null&&(typeof a===Np||typeof a==='function')&&!(a.pb===Ah)}
function rh(a,b){typeof window===Np&&typeof window['$gwt']===Np&&(window['$gwt'][a]=b)}
function oh(){ph();var a=nh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ob(a){var b,c;for(c=new Oi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ri(a){var b,c,d;d=0;for(c=new yi(a.a);c.b;){b=xi(c);d=d+(b?s(b):0);d=d|0}return d}
function li(a,b){var c,d;for(d=new yi(b.a);d.b;){c=xi(d);if(!ui(a,c)){return false}}return true}
function Jo(a,b,c){var d;d=new Go(b,c);yo(d,a,new gc(a,d));qi(a.g,$h(d.c.d),d);eb(a.d);return d}
function vk(a,b,c,d){var e;e=wk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=tj(d);return e}
function Ln(a,b){tk(a.a,(Lh(dg),dg.k+(''+(b?$h(b.c.d):null))));tj(b);a.a.props['a']=b;return a.a}
function wi(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new _i(a.d.a);return a.a.Y()}
function gh(a){var b;if(kd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new yc(a);Vc(b)}return b}
function jh(a){var b;b=a.h;if(b==0){return a.l+a.m*Wp}if(b==1048575){return a.l+a.m*Wp-_p}return a}
function lh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=_p;d=1048575}c=qd(e/Wp);b=qd(e-c*Wp);return cd(b,c,d)}
function rp(a){var b;b=S(a.g.a);o(lq,b)||o(mq,b)||o('',b)?jo(a.g,b):mp(ko(a.g))?mo(a.g):jo(a.g,'')}
function cc(a,b,c){var d;d=ri(a.g,b?$h(b.c.d):null);if(null!=d){mc(b.c,a);c&&!!b&&ic(b.c);eb(a.d)}}
function kj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function bd(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=Ah;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Vi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ti(a,c._())){return c}}return null}
function sp(a,b){var c;c=a.e;if(!(b==c||!!b&&zo(b,c))){!!c&&mc(c.c,a);a.e=b;!!b&&yo(b,a,new vp(a));eb(a.d)}}
function im(a,b,c){27==c.which?A((J(),J(),I),new Im(a,b),gq):13==c.which&&A((J(),J(),I),new Gm(a,b),gq)}
function Un(){this.a=Dh((ap(),_o));this.b=Dh(new lp(this.a));this.c=Dh(new zp(this.a))}
function Ep(){Ep=wh;Bp=new Fp('ACTIVE',0);Dp=new Fp('COMPLETED',1);Cp=new Fp('ALL',2)}
function Yh(){uc.call(this,"Stream already terminated, can't be modified or used")}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:Sp)|(0==(c&6291456)?!a?Vp:Wp:0)|0|0|0)}
function Kb(a,b){this.b=tj(a);this.a=b|0|(0==(b&6291456)?Wp:0)|(0!=(b&229376)?0:98304)}
function vj(a,b){if(0>a||a>b){throw hh(new Ih('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function yc(a){wc();pc(this);this.e=a;qc(this,a);this.g=a==null?$p:zh(a);this.a='';this.b=a;this.a=''}
function Nh(){this.g=Kh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function nl(){if(!ml){ml=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(xh(ol.prototype.J,ol,[]))}}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Sp)?Jb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function cb(a,b){var c,d;d=a.c;Ji(d,b);!!a.b&&Sp!=(a.b.c&Tp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((J(),c=Qb,c),a))}
function dd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return cd(c&4194303,d&4194303,e&1048575)}
function ih(a,b){var c;if(md(a)&&md(b)){c=a+b;if(-17592186044416<c&&c<_p){return c}}return jh(dd(md(a)?lh(a):a,md(b)?lh(b):b))}
function $h(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ai(),_h)[b];!c&&(c=_h[b]=new Zh(a));return c}return new Zh(a)}
function zh(a){var b;if(Array.isArray(a)&&a.pb===Ah){return Mh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function pk(a){nk();var b,c,d;c=':'+a;d=mk[c];if(d!=null){return qd(d)}d=kk[c];b=d==null?ok(a):qd(d);qk();mk[c]=b;return b}
function Si(a){var b,c,d;d=1;for(c=new Oi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=Ii(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function km(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;ym(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function r(a){return od(a)?me:md(a)?ae:ld(a)?$d:jd(a)?a.nb:ad(a)?a.nb:a.nb||Array.isArray(a)&&Yc(Rd,1)||Rd}
function s(a){return od(a)?pk(a):md(a)?qd(a):ld(a)?a?1231:1237:jd(a)?a.q():ad(a)?jk(a):!!a&&!!a.hashCode?a.hashCode():jk(a)}
function q(a,b){return od(a)?o(a,b):md(a)?pd(a)===pd(b):ld(a)?pd(a)===pd(b):jd(a)?a.o(b):ad(a)?o(a,b):!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function ll(){jl();return bd(Yc(df,1),Qp,6,0,[Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il])}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(Sp==(b&Tp)?0:524288)|(0==(b&6291456)?Sp==(b&Tp)?Wp:Vp:0)|0|268435456|0)}
function jm(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new jp(b,c),gq);sp(a.k,null);zm(a,c)}else{Mo(a.j,b)}}
function Vh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Li(a,b){var c,d;d=a.a.length;b.length<d&&(b=hk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a){var b,c,d;for(c=new Oi(new Ni(new vi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();kd(d,9)&&d.u()||b.ab().v()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function hd(a,b){if(od(a)){return !!gd[b]}else if(a.ob){return !!a.ob[b]}else if(md(a)){return !!fd[b]}else if(ld(a)){return !!ed[b]}return false}
function nc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ui:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Il(a,b){var c;this.d=tj(b);this.n=tj(a);J();c=++Gl;this.b=new nc(c,null,new Jl(this),false,false);this.a=new vb(null,tj(new Ml(this)),fq)}
function Go(a,b){var c,d,e,f,g;this.e=tj(a);this.d=b;J();c=++wo;this.c=new nc(c,null,new Ho(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Ck(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Qb&&!!Qb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function fi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function mi(a,b){var c,d,e,f;f=ti(a.a);b.length<f&&(b=hk(new Array(f),b));e=b;d=new yi(a.a);for(c=0;c<f;++c){e[c]=xi(d)}b.length>f&&(b[f]=null);return b}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.v(),null)}finally{bc()}return f}catch(a){a=gh(a);if(kd(a,4)){e=a;throw hh(e)}else throw hh(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.s()}else{ac(b,e);try{g=c.s()}finally{bc()}}return g}catch(a){a=gh(a);if(kd(a,4)){f=a;throw hh(f)}else throw hh(a)}finally{D(b)}}
function Bb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Hb(c);return true}
function qh(b,c,d,e){ph();var f=nh;$moduleName=c;$moduleBase=d;fh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Mp(g)()}catch(a){b(c,a)}}else{Mp(g)()}}
function W(a,b,c,d){this.c=tj(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);Sp==(d&Tp)&&lb(this.f)}
function wk(a,b){var c;c=new $wnd.Object;c.$$typeof=tj(a);c.type=tj(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Tm(a,b,c,d){var e;this.d=tj(b);this.e=tj(c);this.f=tj(d);this.n=tj(a);J();e=++Rm;this.b=new nc(e,null,new Um(this),false,false);this.a=new vb(null,tj(new Xm(this)),fq)}
function Zl(a,b){var c,d,e;this.e=tj(b);this.n=tj(a);J();c=++Tl;this.c=new nc(c,null,new $l(this),false,false);this.b=(e=new ib((d=null,d)),e);this.a=new vb(null,tj(new em(this)),fq)}
function fj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return gj()}}
function Fl(a){var b,c,d;a.c=0;nl();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),yk('span',Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,['todo-count'])),[yk('strong',null,[c]),' '+d+' left']));return b}
function th(){sh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Rc(c,g)):g[0].qb()}catch(a){a=gh(a);if(kd(a,4)){d=a;Dc();Jc(kd(d,36)?d.H():d)}else throw hh(a)}}return c}
function Sl(a){var b;a.d=0;nl();b=yk(hq,Gk(Jk(Kk(Nk(Lk(Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,['new-todo']))),(fb(a.b),a.f)),xh(zn.prototype.kb,zn,[a])),xh(An.prototype.jb,An,[a]))),null);return b}
function xc(a){var b;if(a.c==null){b=pd(a.b)===pd(vc)?null:a.b;a.d=b==null?$p:nd(b)?b==null?null:b.name:od(b)?'String':Mh(r(b));a.a=a.a+': '+(nd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(pd(e)===pd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=gh(a);if(kd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw hh(c)}else throw hh(a)}}
function dk(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Yi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Vi(b,e);if(f){return f.bb(c)}}e[e.length]=new Ci(b,c);++a.b;return null}
function ok(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+di(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=gh(a);if(kd(a,4)){J()}else throw hh(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=$c(je,Qp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Bh(){var a;a=new Un;an(Vn(new Wn(a)));dn(new Ll((new Xn(a)).a.a.I()));On(Zn(new $n(a)));Tn(_n(new ao(a)));Dn(new am((new Yn(a)).a.b.I()));$wnd.ReactDOM.render(xk([(new Rn).a]),(Fh(),Eh).getElementById('app'),null)}
function wl(a,b,c,d){var e;this.e=tj(b);this.f=tj(c);this.g=tj(d);this.n=tj(a);J();e=++sl;this.c=new nc(e,null,new xl(this),false,false);this.a=new W(new Al(this),null,null,136478720);this.b=new vb(null,tj(new Bl(this)),fq)}
function ub(a,b,c,d){this.b=new Mi;this.f=new Kb(new yb(this),d&6520832|262144|Sp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Vp)&&D((null,I)))}
function Zi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ti(b,e._())){if(d.length==1){d.length=0;aj(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function vh(a,b,c){var d=sh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=sh[b]),yh(h));_.ob=c;!b&&(_.pb=Ah);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Uh(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Vh('.',[c,Vh('$',d)]);a.b=Vh('.',[c,Vh('.',d)]);a.i=d[d.length-1]}
function go(a){var b;if(0==a.length){b=(Fh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Eh.title,b)}else{(Fh(),$wnd.goog.global.window).location.hash=a}}
function ni(a,b){var c,d,e;c=b._();e=b.ab();d=od(c)?c==null?pi(Xi(a.a,null)):jj(a.b,c):pi(Xi(a.a,c));if(!(pd(e)===pd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(od(c)?c==null?!!Xi(a.a,null):ij(a.b,c):!!Xi(a.a,c))){return false}return true}
function yk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;sk(b,xh(Bk.prototype.hb,Bk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[cq]=c[0],undefined):(d[cq]=c,undefined));return vk(a,e,f,d)}
function oo(){var a,b,c;this.d=new Ap(this);this.f=this.e=(c=(Fh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new nc(0,null,new po(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new vo,new qo(this),new ro(this),35651584)}
function tp(a){var b,c;this.i=tj(a);this.g=new oo;J();this.f=new nc(0,null,new up(this),false,false);this.d=(c=new ib((b=null,b)),c);this.b=new W(new wp(this),null,null,kq);this.c=new W(new xp(this),null,null,kq);this.a=new vb(tj(new yp(this)),null,681574400);D((null,I))}
function Ro(){var a;this.g=new Ui;J();this.f=new nc(0,new To(this),new So(this),false,false);this.d=(a=new ib(null),a);this.c=new W(new Wo(this),null,null,kq);this.e=new W(new Xo(this),null,null,kq);this.a=new W(new Yo(this),null,null,kq);this.b=new W(new Zo(this),null,null,kq)}
function Am(a,b,c,d){var e,f,g;this.j=tj(b);tj(c);this.k=tj(d);this.n=tj(a);J();e=++om;this.e=new nc(e,null,new Bm(this),false,false);this.a=(g=new ib((f=null,f)),g);this.c=new W(new Jm(this),null,null,136478720);this.b=new vb(null,tj(new Mm(this)),fq);ym(this,this.n.props['a'])}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Oi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=gh(a);if(!kd(a,4))throw hh(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function qc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function ej(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}Fi(a.b,new Ab(a));a.b.a=$c(je,Qp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Qm(a){var b;a.c=0;nl();b=yk('div',null,[yk('div',null,[yk(iq,Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,[iq])),[yk('h1',null,['todos']),(new Bn).a]),S(a.d.c)?null:yk('section',Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,[iq])),[yk(hq,Jk(Mk(Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,['toggle-all'])),(jl(),Qk)),xh(Pn.prototype.jb,Pn,[a])),null),yk('ul',Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,['todo-list'])),Pj(tj(Nj(S(a.f.c).W(),new Qn)),new Ak))]),S(a.d.c)?null:(new $m).a])]);return b}
function jl(){jl=wh;Pk=new kl(dq,0);Qk=new kl('checkbox',1);Rk=new kl('color',2);Sk=new kl('date',3);Tk=new kl('datetime',4);Uk=new kl('email',5);Vk=new kl('file',6);Wk=new kl('hidden',7);Xk=new kl('image',8);Yk=new kl('month',9);Zk=new kl(Op,10);$k=new kl('password',11);_k=new kl('radio',12);al=new kl('range',13);bl=new kl('reset',14);cl=new kl('search',15);dl=new kl('submit',16);el=new kl('tel',17);fl=new kl('text',18);gl=new kl('time',19);hl=new kl('url',20);il=new kl('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Gi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ki(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Gi(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ii(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Mi)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Sp!=(k.b.c&Tp)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function rl(a){var b,c;a.d=0;nl();c=(b=S(a.g.b),yk('footer',Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,['footer'])),[(new bn).a,yk('ul',Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,['filters'])),[yk('li',null,[yk('a',Ek(Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,[(Ep(),Cp)==b?eq:null])),'#'),['All'])]),yk('li',null,[yk('a',Ek(Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,[Bp==b?eq:null])),'#active'),['Active'])]),yk('li',null,[yk('a',Ek(Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,[Dp==b?eq:null])),'#completed'),['Completed'])])]),S(a.a)?yk(dq,Fk(Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,['clear-completed'])),xh(Zm.prototype.lb,Zm,[a])),['Clear Completed']):null]));return c}
function nm(a){var b,c,d,e;a.f=0;nl();b=a.n.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.n.props['a'],e=(fb(d.a),d.d),yk('li',Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[yk('div',Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,['view'])),[yk(hq,Jk(Hk(Mk(Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,['toggle'])),(jl(),Qk)),e),xh(Fn.prototype.jb,Fn,[d])),null),yk('label',Ok(new $wnd.Object,xh(Gn.prototype.lb,Gn,[a,d])),[(fb(d.b),d.e)]),yk(dq,Fk(Ck(new $wnd.Object,bd(Yc(me,1),Qp,2,6,['destroy'])),xh(Hn.prototype.lb,Hn,[a,d])),null)]),yk(hq,Kk(Jk(Ik(Nk(Ck(Dk(new $wnd.Object,xh(In.prototype.w,In,[a])),bd(Yc(me,1),Qp,2,6,['edit'])),(fb(a.a),a.d)),xh(Jn.prototype.ib,Jn,[a,d])),xh(En.prototype.jb,En,[a])),xh(Kn.prototype.kb,Kn,[a,d])),null)]));return c}
function gj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[bq]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!ej()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[bq]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Np='object',Op='number',Pp={11:1},Qp={3:1},Rp={9:1},Sp=1048576,Tp=1835008,Up={5:1},Vp=2097152,Wp=4194304,Xp={25:1},Yp='__noinit__',Zp={3:1,10:1,7:1,4:1},$p='null',_p=17592186044416,aq={42:1},bq='delete',cq='children',dq='button',eq='selected',fq=1411518464,gq=142606336,hq='input',iq='header',jq='hashchange',kq=136314880,lq='active',mq='completed';var _,sh,nh,fh=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;th();vh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=oq;_.r=function(){var a;return Mh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var ed,fd,gd;vh(56,1,{},Nh);_.K=function(a){var b;b=new Nh;b.e=4;a>1?(b.c=Sh(this,a-1)):(b.c=this);return b};_.L=function(){Lh(this);return this.b};_.M=function(){return Mh(this)};_.N=function(){Lh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Lh(this),this.k)};_.e=0;_.g=0;var Kh=1;var je=Ph(1);var _d=Ph(56);vh(86,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var ud=Ph(86);vh(37,1,Pp,G);_.s=function(){return this.a.v(),null};var sd=Ph(37);vh(87,1,{},H);var td=Ph(87);var I;vh(45,1,{45:1},P);_.b=0;_.c=false;_.d=0;var vd=Ph(45);vh(240,1,Rp);_.r=function(){var a;return Mh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var yd=Ph(240);vh(19,240,Rp,W);_.t=function(){R(this)};_.u=nq;_.a=false;_.d=0;_.k=false;var xd=Ph(19);vh(196,1,Pp,X);_.s=function(){return T(this.a)};var wd=Ph(196);vh(17,240,{9:1,17:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Ad=Ph(17);vh(195,1,Up,jb);_.v=function(){ab(this.a)};var zd=Ph(195);vh(18,240,{9:1,18:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Fd=Ph(18);vh(197,1,Xp,xb);_.v=function(){Q(this.a)};var Bd=Ph(197);vh(198,1,Up,yb);_.v=function(){mb(this.a)};var Cd=Ph(198);vh(199,1,Up,zb);_.v=function(){pb(this.a)};var Dd=Ph(199);vh(200,1,{},Ab);_.w=function(a){nb(this.a,a)};var Ed=Ph(200);vh(151,1,{},Db);_.a=0;_.b=0;_.c=0;var Gd=Ph(151);vh(202,1,Rp,Fb);_.t=function(){Eb(this)};_.u=nq;_.a=false;var Hd=Ph(202);vh(69,240,{9:1,69:1},Kb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Jd=Ph(69);vh(62,1,{62:1},Pb);var Id=Ph(62);vh(214,1,{},_b);_.r=function(){var a;return Lh(Kd),Kd.k+'@'+(a=jk(this)>>>0,a.toString(16))};_.a=0;var Qb;var Kd=Ph(214);vh(183,1,{});var Nd=Ph(183);vh(156,1,{},fc);_.w=function(a){dc(this.a,a)};var Ld=Ph(156);vh(157,1,Up,gc);_.v=function(){ec(this.a,this.b)};var Md=Ph(157);vh(16,1,Rp,nc);_.t=function(){ic(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Lh(Pd),Pd.k+'@'+(a=jk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Pd=Ph(16);vh(194,1,Up,oc);_.v=function(){lc(this.a)};var Od=Ph(194);vh(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=tq;_.C=function(){return Pj(Nj(Qi((this.i==null&&(this.i=$c(oe,Qp,4,0,0,1)),this.i)),new ji),new Tj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){rc(this,tc(this.A(sc(this,this.g))));Vc(this)};_.r=function(){return sc(this,this.F())};_.e=Yp;_.j=true;var oe=Ph(4);vh(10,4,{3:1,10:1,4:1});var ce=Ph(10);vh(7,10,Zp);var ke=Ph(7);vh(57,7,Zp);var ge=Ph(57);vh(80,57,Zp);var Td=Ph(80);vh(36,80,{36:1,3:1,10:1,7:1,4:1},yc);_.F=function(){xc(this);return this.c};_.H=function(){return pd(this.b)===pd(vc)?null:this.b};var vc;var Qd=Ph(36);var Rd=Ph(0);vh(222,1,{});var Sd=Ph(222);var Ac=0,Bc=0,Cc=-1;vh(95,222,{},Qc);var Mc;var Ud=Ph(95);var Tc;vh(233,1,{});var Wd=Ph(233);vh(81,233,{},Xc);var Vd=Ph(81);vh(46,1,{46:1,71:1},Ch);_.I=function(){if(this===this.a){this.a=this.b.I();this.b=null}return this.a};var Xd=Ph(46);var Eh;vh(78,1,{75:1});_.r=nq;var Yd=Ph(78);vh(83,7,Zp);var ee=Ph(83);vh(193,83,Zp,Ih);var Zd=Ph(193);ed={3:1,76:1,29:1};var $d=Ph(76);vh(43,1,{3:1,43:1});var ie=Ph(43);fd={3:1,29:1,43:1};var ae=Ph(232);vh(31,1,{3:1,29:1,31:1});_.o=vq;_.q=oq;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=Ph(31);vh(82,7,Zp,Yh);var de=Ph(82);vh(30,43,{3:1,29:1,30:1,43:1},Zh);_.o=function(a){return kd(a,30)&&a.a==this.a};_.q=nq;_.r=function(){return ''+this.a};_.a=0;var fe=Ph(30);var _h;vh(298,1,{});vh(84,57,Zp,ci);_.A=function(a){return new TypeError(a)};var he=Ph(84);gd={3:1,75:1,29:1,2:1};var me=Ph(2);vh(79,78,{75:1},ii);var le=Ph(79);vh(302,1,{});vh(73,1,{},ji);_.S=function(a){return a.e};var ne=Ph(73);vh(59,7,Zp,ki);var pe=Ph(59);vh(234,1,{41:1});_.Q=sq;_.V=function(){return new Cj(this,0)};_.W=function(){return new Qj(null,this.V())};_.T=function(a){throw hh(new ki('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Ej('[',']');for(b=this.R();b.Y();){a=b.Z();Dj(c,a===this?'(this Collection)':a==null?$p:zh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var qe=Ph(234);vh(238,1,{221:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!kd(a,38)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new yi((new vi(d)).a);c.b;){b=xi(c);if(!ni(this,b)){return false}}return true};_.q=function(){return Ri(new vi(this))};_.r=function(){var a,b,c;c=new Ej('{','}');for(b=new yi((new vi(this)).a);b.b;){a=xi(b);Dj(c,oi(this,a._())+'='+oi(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Be=Ph(238);vh(150,238,{221:1});var te=Ph(150);vh(237,234,{41:1,245:1});_.V=function(){return new Cj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!kd(a,22)){return false}b=a;if(ti(b.a)!=this.U()){return false}return li(this,b)};_.q=function(){return Ri(this)};var Ce=Ph(237);vh(22,237,{22:1,41:1,245:1},vi);_.R=function(){return new yi(this.a)};_.U=qq;var se=Ph(22);vh(23,1,{},yi);_.X=pq;_.Z=function(){return xi(this)};_.Y=rq;_.b=false;var re=Ph(23);vh(235,234,{41:1,241:1});_.V=function(){return new Cj(this,16)};_.$=function(a,b){throw hh(new ki('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!kd(a,14)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Oi(f);for(c=new Oi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(pd(b)===pd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Si(this)};_.R=function(){return new zi(this)};var ve=Ph(235);vh(94,1,{},zi);_.X=pq;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Gi(this.b,this.a++)};_.a=0;var ue=Ph(94);vh(61,234,{41:1},Ai);_.R=function(){var a;a=new yi((new vi(this.a)).a);return new Bi(a)};_.U=qq;var xe=Ph(61);vh(147,1,{},Bi);_.X=pq;_.Y=function(){return this.a.b};_.Z=function(){var a;a=xi(this.a);return a.ab()};var we=Ph(147);vh(145,1,aq);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Ti(this.a,b._())&&Ti(this.b,b.ab())};_._=nq;_.ab=rq;_.q=function(){return sj(this.a)^sj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ye=Ph(145);vh(146,145,aq,Ci);var ze=Ph(146);vh(239,1,aq);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Ti(this.b.value[0],b._())&&Ti(oj(this),b.ab())};_.q=function(){return sj(this.b.value[0])^sj(oj(this))};_.r=function(){return this.b.value[0]+'='+oj(this)};var Ae=Ph(239);vh(14,235,{3:1,14:1,41:1,241:1},Mi,Ni);_.$=function(a,b){ek(this.a,a,b)};_.T=function(a){return Ei(this,a)};_.Q=function(a){Fi(this,a)};_.R=function(){return new Oi(this)};_.U=function(){return this.a.length};var Ee=Ph(14);vh(15,1,{},Oi);_.X=pq;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var De=Ph(15);vh(38,150,{3:1,38:1,221:1},Ui);var Fe=Ph(38);vh(65,1,{},$i);_.Q=sq;_.R=function(){return new _i(this)};_.b=0;var He=Ph(65);vh(66,1,{},_i);_.X=pq;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ge=Ph(66);var cj;vh(63,1,{},mj);_.Q=sq;_.R=function(){return new nj(this)};_.b=0;_.c=0;var Ke=Ph(63);vh(64,1,{},nj);_.X=pq;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new pj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Ie=Ph(64);vh(155,239,aq,pj);_._=function(){return this.b.value[0]};_.ab=function(){return oj(this)};_.bb=function(a){return kj(this.a,this.b.value[0],a)};_.c=0;var Je=Ph(155);vh(174,1,{});_.X=uq;_.cb=function(){return this.d};_.db=tq;_.d=0;_.e=0;var Oe=Ph(174);vh(67,174,{});var Le=Ph(67);vh(148,1,{});_.X=uq;_.cb=rq;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Ne=Ph(148);vh(149,148,{},Aj);_.X=function(a){xj(this,a)};_.eb=function(a){return yj(this,a)};var Me=Ph(149);vh(21,1,{},Cj);_.cb=nq;_.db=function(){Bj(this);return this.c};_.X=function(a){Bj(this);this.d.X(a)};_.eb=function(a){Bj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Pe=Ph(21);vh(58,1,{},Ej);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Qe=Ph(58);vh(35,1,{},Fj);_.S=function(a){return a};var Re=Ph(35);vh(39,1,{},Gj);var Se=Ph(39);vh(173,1,{});_.c=false;var af=Ph(173);vh(27,173,{278:1},Qj);var _e=Ph(27);vh(74,1,{},Tj);_.fb=function(a){return $c(je,Qp,1,a,5,1)};var Te=Ph(74);vh(176,67,{},Vj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Wj(this,a)));return this.b};_.b=false;var Ve=Ph(176);vh(179,1,{},Wj);_.w=function(a){Uj(this.a,this.b,a)};var Ue=Ph(179);vh(175,67,{},Yj);_.eb=function(a){return this.b.eb(new Zj(this,a))};var Xe=Ph(175);vh(178,1,{},Zj);_.w=function(a){Xj(this.a,this.b,a)};var We=Ph(178);vh(177,1,{},_j);_.w=function(a){$j(this,a)};var Ye=Ph(177);vh(180,1,{},ak);_.w=function(a){};var Ze=Ph(180);vh(181,1,{},ck);_.w=function(a){bk(this,a)};var $e=Ph(181);vh(300,1,{});vh(297,1,{});var ik=0;var kk,lk=0,mk;vh(928,1,{});vh(963,1,{});vh(236,1,{});var bf=Ph(236);vh(203,1,{},Ak);_.fb=function(a){return new Array(a)};var cf=Ph(203);vh(280,$wnd.Function,{},Bk);_.hb=function(a){zk(this.a,this.b,a)};vh(6,31,{3:1,29:1,31:1,6:1},kl);var Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il;var df=Qh(6,ll);var ml;vh(279,$wnd.Function,{},ol);_.J=function(a){return Eb(ml),ml=null,null};vh(96,236,{});var Rf=Ph(96);vh(97,96,{});_.d=0;var Vf=Ph(97);vh(98,97,Rp,wl);_.t=wq;_.o=vq;_.q=oq;_.u=xq;_.r=function(){var a;return Lh(pf),pf.k+'@'+(a=jk(this)>>>0,a.toString(16))};var sl=0;var pf=Ph(98);vh(100,1,Up,xl);_.v=function(){tl(this.a)};var ef=Ph(100);vh(99,1,{},zl);var ff=Ph(99);vh(101,1,Pp,Al);_.s=function(){return ul(this.a)};var gf=Ph(101);vh(102,1,Xp,Bl);_.v=function(){ql(this.a)};var hf=Ph(102);vh(103,1,Pp,Cl);_.s=function(){return rl(this.a)};var jf=Ph(103);vh(105,236,{});var Qf=Ph(105);vh(106,105,{});_.c=0;var Uf=Ph(106);vh(107,106,Rp,Il);_.t=yq;_.o=vq;_.q=oq;_.u=zq;_.r=function(){var a;return Lh(of),of.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Gl=0;var of=Ph(107);vh(109,1,Up,Jl);_.v=Aq;var kf=Ph(109);vh(108,1,{},Ll);var lf=Ph(108);vh(110,1,Xp,Ml);_.v=function(){El(this.a)};var mf=Ph(110);vh(111,1,Pp,Nl);_.s=function(){return Fl(this.a)};var nf=Ph(111);vh(135,236,{});_.f='';var bg=Ph(135);vh(136,135,{});_.d=0;var Xf=Ph(136);vh(137,136,Rp,Zl);_.t=wq;_.o=vq;_.q=oq;_.u=xq;_.r=function(){var a;return Lh(wf),wf.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Tl=0;var wf=Ph(137);vh(139,1,Up,$l);_.v=function(){Ul(this.a)};var qf=Ph(139);vh(138,1,{},am);var rf=Ph(138);vh(141,1,Pp,bm);_.s=function(){return Sl(this.a)};var sf=Ph(141);vh(142,1,Up,cm);_.v=function(){Ol(this.a)};var tf=Ph(142);vh(143,1,Up,dm);_.v=function(){Wl(this.a,this.b)};var uf=Ph(143);vh(140,1,Xp,em);_.v=function(){ql(this.a)};var vf=Ph(140);vh(113,236,{});_.i=false;var dg=Ph(113);vh(114,113,{});_.f=0;var Zf=Ph(114);vh(115,114,Rp,Am);_.t=function(){ic(this.e)};_.o=vq;_.q=oq;_.u=function(){return this.e.i<0};_.r=function(){var a;return Lh(If),If.k+'@'+(a=jk(this)>>>0,a.toString(16))};var om=0;var If=Ph(115);vh(117,1,Up,Bm);_.v=function(){pm(this.a)};var xf=Ph(117);vh(116,1,{},Dm);var yf=Ph(116);vh(120,1,Pp,Em);_.s=function(){return nm(this.a)};var zf=Ph(120);vh(44,1,Up,Fm);_.v=function(){zm(this.a,ko(this.b))};var Af=Ph(44);vh(60,1,Up,Gm);_.v=function(){jm(this.a,this.b)};var Bf=Ph(60);vh(121,1,Up,Hm);_.v=function(){rm(this.a,this.b)};var Cf=Ph(121);vh(122,1,Up,Im);_.v=function(){sm(this.a,this.b)};var Df=Ph(122);vh(118,1,Pp,Jm);_.s=function(){return tm(this.a)};var Ef=Ph(118);vh(123,1,Up,Km);_.v=function(){fm(this.a,this.b)};var Ff=Ph(123);vh(124,1,Up,Lm);_.v=function(){km(this.a)};var Gf=Ph(124);vh(119,1,Xp,Mm);_.v=function(){mm(this.a)};var Hf=Ph(119);vh(126,236,{});var gg=Ph(126);vh(127,126,{});_.c=0;var _f=Ph(127);vh(128,127,Rp,Tm);_.t=yq;_.o=vq;_.q=oq;_.u=zq;_.r=function(){var a;return Lh(Nf),Nf.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Rm=0;var Nf=Ph(128);vh(130,1,Up,Um);_.v=Aq;var Jf=Ph(130);vh(129,1,{},Wm);var Kf=Ph(129);vh(131,1,Xp,Xm);_.v=function(){El(this.a)};var Lf=Ph(131);vh(132,1,Pp,Ym);_.s=function(){return Qm(this.a)};var Mf=Ph(132);vh(261,$wnd.Function,{},Zm);_.lb=function(a){dp(this.a.f)};vh(205,1,{},$m);var Of=Ph(205);var _m;vh(216,1,{},bn);var Pf=Ph(216);var cn;vh(262,$wnd.Function,{},en);_.mb=function(a){return new hn(a)};var fn;vh(104,$wnd.React.Component,{},hn);uh(sh[1],_);_.componentWillUnmount=function(){pl(this.a)};_.render=function(){return vl(this.a)};_.shouldComponentUpdate=Bq;var Sf=Ph(104);vh(263,$wnd.Function,{},jn);_.mb=function(a){return new mn(a)};var kn;vh(112,$wnd.React.Component,{},mn);uh(sh[1],_);_.componentWillUnmount=function(){Dl(this.a)};_.render=function(){return Hl(this.a)};_.shouldComponentUpdate=Cq;var Tf=Ph(112);vh(277,$wnd.Function,{},nn);_.mb=function(a){return new qn(a)};var on;vh(144,$wnd.React.Component,{},qn);uh(sh[1],_);_.componentWillUnmount=function(){pl(this.a)};_.render=function(){return Xl(this.a)};_.shouldComponentUpdate=Bq;var Wf=Ph(144);vh(264,$wnd.Function,{},rn);_.mb=function(a){return new un(a)};var sn;vh(125,$wnd.React.Component,{},un);uh(sh[1],_);_.componentDidUpdate=function(a){wm(this.a)};_.componentWillUnmount=function(){lm(this.a)};_.render=function(){return xm(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Yf=Ph(125);vh(274,$wnd.Function,{},vn);_.mb=function(a){return new yn(a)};var wn;vh(133,$wnd.React.Component,{},yn);uh(sh[1],_);_.componentWillUnmount=function(){Dl(this.a)};_.render=function(){return Sm(this.a)};_.shouldComponentUpdate=Cq;var $f=Ph(133);vh(275,$wnd.Function,{},zn);_.kb=function(a){Pl(this.a,a)};vh(276,$wnd.Function,{},An);_.jb=function(a){Vl(this.a,a)};vh(204,1,{},Bn);var ag=Ph(204);var Cn;vh(271,$wnd.Function,{},En);_.jb=function(a){qm(this.a,a)};vh(265,$wnd.Function,{},Fn);_.jb=function(a){Fo(this.a)};vh(267,$wnd.Function,{},Gn);_.lb=function(a){um(this.a,this.b)};vh(268,$wnd.Function,{},Hn);_.lb=function(a){gm(this.a,this.b)};vh(269,$wnd.Function,{},In);_.w=function(a){hm(this.a,a)};vh(270,$wnd.Function,{},Jn);_.ib=function(a){vm(this.a,this.b)};vh(272,$wnd.Function,{},Kn);_.kb=function(a){im(this.a,this.b,a)};vh(215,1,{},Mn);var cg=Ph(215);var Nn;vh(273,$wnd.Function,{},Pn);_.jb=function(a){Nm(this.a,a)};vh(134,1,{},Qn);_.S=function(a){return Ln(new Mn,a)};var eg=Ph(134);vh(72,1,{},Rn);var fg=Ph(72);var Sn;vh(88,1,{},Un);var mg=Ph(88);vh(89,1,{},Wn);var hg=Ph(89);vh(93,1,{},Xn);var ig=Ph(93);vh(92,1,{},Yn);var jg=Ph(92);vh(90,1,{},$n);var kg=Ph(90);vh(91,1,{},ao);var lg=Ph(91);vh(206,1,{});var Vg=Ph(206);vh(207,206,Rp,oo);_.t=wq;_.o=vq;_.q=oq;_.u=xq;_.r=function(){var a;return Lh(ug),ug.k+'@'+(a=jk(this)>>>0,a.toString(16))};var ug=Ph(207);vh(208,1,Up,po);_.v=function(){io(this.a)};var ng=Ph(208);vh(210,1,Xp,qo);_.v=function(){co(this.a)};var og=Ph(210);vh(211,1,Xp,ro);_.v=function(){eo(this.a)};var pg=Ph(211);vh(212,1,Up,so);_.v=function(){bo(this.a,this.b)};var qg=Ph(212);vh(213,1,Up,to);_.v=function(){lo(this.a)};var rg=Ph(213);vh(68,1,Up,uo);_.v=function(){ho(this.a)};var sg=Ph(68);vh(209,1,Pp,vo);_.s=function(){var a;return a=(Fh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var tg=Ph(209);vh(50,1,{50:1});_.d=false;var bh=Ph(50);vh(51,50,{9:1,281:1,51:1,50:1},Go);_.t=wq;_.o=function(a){return zo(this,a)};_.q=function(){return this.c.d};_.u=xq;_.r=function(){var a;return Lh(Mg),Mg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var wo=0;var Mg=Ph(51);vh(217,1,Up,Ho);_.v=function(){xo(this.a)};var vg=Ph(217);vh(218,1,Up,Io);_.v=function(){Co(this.a)};var wg=Ph(218);vh(49,183,{49:1});var Yg=Ph(49);vh(184,49,{9:1,49:1},Ro);_.t=Dq;_.o=vq;_.q=oq;_.u=Eq;_.r=function(){var a;return Lh(Gg),Gg.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Gg=Ph(184);vh(186,1,Up,So);_.v=function(){Ko(this.a)};var xg=Ph(186);vh(185,1,Up,To);_.v=function(){Oo(this.a)};var yg=Ph(185);vh(191,1,Up,Uo);_.v=function(){cc(this.a,this.b,true)};var zg=Ph(191);vh(192,1,Pp,Vo);_.s=function(){return Jo(this.a,this.c,this.b)};_.b=false;var Ag=Ph(192);vh(187,1,Pp,Wo);_.s=function(){return Po(this.a)};var Bg=Ph(187);vh(188,1,Pp,Xo);_.s=function(){return $h(mh(Lj(No(this.a))))};var Cg=Ph(188);vh(189,1,Pp,Yo);_.s=function(){return $h(mh(Lj(Mj(No(this.a),new Hp))))};var Dg=Ph(189);vh(190,1,Pp,Zo);_.s=function(){return Qo(this.a)};var Eg=Ph(190);vh(152,1,{71:1},$o);_.I=function(){return new Ro};var Fg=Ph(152);var _o;vh(47,1,{47:1});var ah=Ph(47);vh(163,47,{9:1,47:1},hp);_.t=function(){ic(this.a)};_.o=vq;_.q=oq;_.u=function(){return this.a.i<0};_.r=function(){var a;return Lh(Lg),Lg.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Lg=Ph(163);vh(164,1,Up,ip);_.v=function(){ep(this.a,this.b)};_.b=false;var Hg=Ph(164);vh(165,1,Up,jp);_.v=function(){no(this.b,this.a)};var Ig=Ph(165);vh(166,1,Up,kp);_.v=function(){fp(this.a)};var Jg=Ph(166);vh(153,1,{71:1},lp);_.I=function(){return new hp(this.a.I())};var Kg=Ph(153);vh(48,1,{48:1});var eh=Ph(48);vh(167,48,{9:1,48:1},tp);_.t=Dq;_.o=vq;_.q=oq;_.u=Eq;_.r=function(){var a;return Lh(Tg),Tg.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Tg=Ph(167);vh(168,1,Up,up);_.v=function(){op(this.a)};var Ng=Ph(168);vh(172,1,Up,vp);_.v=function(){sp(this.a,null)};var Og=Ph(172);vh(169,1,Pp,wp);_.s=function(){var a;return a=ko(this.a.g),o(lq,a)?(Ep(),Bp):o(mq,a)?(Ep(),Dp):(Ep(),Cp)};var Pg=Ph(169);vh(170,1,Pp,xp);_.s=function(){return qp(this.a)};var Qg=Ph(170);vh(171,1,Xp,yp);_.v=function(){rp(this.a)};var Rg=Ph(171);vh(154,1,{71:1},zp);_.I=function(){return new tp(this.a.I())};var Sg=Ph(154);vh(201,1,{},Ap);_.handleEvent=function(a){fo(this.a,a)};var Ug=Ph(201);vh(32,31,{3:1,29:1,31:1,32:1},Fp);var Bp,Cp,Dp;var Wg=Qh(32,Gp);vh(158,1,{},Hp);_.gb=function(a){return !Bo(a)};var Xg=Ph(158);vh(160,1,{},Ip);_.gb=function(a){return Bo(a)};var Zg=Ph(160);vh(161,1,{},Jp);_.w=function(a){Mo(this.a,a)};var $g=Ph(161);vh(159,1,{},Kp);_.w=function(a){cp(this.a,a)};_.a=false;var _g=Ph(159);vh(162,1,{},Lp);_.gb=function(a){return np(this.a,a)};var dh=Ph(162);var rd=Rh('D');var Mp=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=qh;oh(Bh);rh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();