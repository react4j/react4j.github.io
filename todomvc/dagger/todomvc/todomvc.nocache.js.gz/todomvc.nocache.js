function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='43B905705C5EF95DCFCA8E62ED959B8E',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '43B905705C5EF95DCFCA8E62ED959B8E';function p(){}
function wh(){}
function sh(){}
function Fb(){}
function Fj(){}
function Tj(){}
function _j(){}
function Qc(){}
function Xc(){}
function ji(){}
function ak(){}
function Ak(){}
function ol(){}
function Wm(){}
function $m(){}
function cn(){}
function gn(){}
function ln(){}
function Gn(){}
function co(){}
function ep(){}
function np(){}
function qp(){}
function rp(){}
function Vc(a){Uc()}
function Jh(){Jh=sh}
function Mi(){Di(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Ai(a){this.a=a}
function ii(a){this.a=a}
function vi(a){this.a=a}
function Bi(a){this.a=a}
function fc(a){this.a=a}
function oc(a){this.a=a}
function Zh(a){this.a=a}
function Gj(a){this.a=a}
function ck(a){this.a=a}
function xl(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function Al(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Jl(a){this.a=a}
function Wl(a){this.a=a}
function Xl(a){this.a=a}
function Yl(a){this.a=a}
function $l(a){this.a=a}
function vm(a){this.a=a}
function wm(a){this.a=a}
function Bm(a){this.a=a}
function Dm(a){this.a=a}
function Em(a){this.a=a}
function Mm(a){this.a=a}
function Nm(a){this.a=a}
function Om(a){this.a=a}
function Pm(a){this.a=a}
function pn(a){this.a=a}
function qn(a){this.a=a}
function un(a){this.a=a}
function vn(a){this.a=a}
function yn(a){this.a=a}
function Fn(a){this.a=a}
function Yn(a){this.a=a}
function Zn(a){this.a=a}
function $n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function po(a){this.a=a}
function qo(a){this.a=a}
function Ao(a){this.a=a}
function Bo(a){this.a=a}
function Eo(a){this.a=a}
function Fo(a){this.a=a}
function Go(a){this.a=a}
function Ho(a){this.a=a}
function Ro(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function cp(a){this.a=a}
function dp(a){this.a=a}
function sp(a){this.a=a}
function tp(a){this.a=a}
function up(a){this.a=a}
function vp(a){this.a=a}
function zi(a){this.b=a}
function Oi(a){this.c=a}
function hq(){ic(this.c)}
function jq(){ic(this.b)}
function oq(){ic(this.f)}
function $i(){this.a=hj()}
function mj(){this.a=hj()}
function $j(a,b){a.a=b}
function tk(a,b){a.key=b}
function sk(a,b){rk(a,b)}
function Jo(a,b){tm(b,a)}
function dq(a){bi(this,a)}
function aq(a){qj(this,a)}
function fq(a){uj(this,a)}
function db(a){Yb((J(),a))}
function eb(a){Zb((J(),a))}
function hb(a){$b((J(),a))}
function Y(a){!!a&&$(a)}
function jc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function qb(a,b){a.b=tj(b)}
function am(a,b){uo(a.j,b)}
function Io(a,b){to(a.b,b)}
function mc(a,b){ri(a.e,b)}
function bk(a,b){Sj(a.a,b)}
function C(a,b){Ob(a.f,b.f)}
function lq(){kb(this.a.a)}
function dh(a){return a.e}
function eq(){return this.e}
function cq(){return this.b}
function $p(){return this.a}
function J(){J=sh;I=new F}
function wc(){wc=sh;vc=new p}
function Nc(){Nc=sh;Mc=new Qc}
function zh(){zh=sh;yh=new p}
function dj(){dj=sh;cj=fj()}
function gp(){gp=sh;fp=new ep}
function pp(){pp=sh;op=new np}
function pl(a){a.d=2;ic(a.c)}
function Bl(a){a.c=2;ic(a.b)}
function fm(a){a.f=2;ic(a.e)}
function fo(a){$(a.b);$(a.a)}
function Rn(a){R(a.a);$(a.b)}
function Ql(a){kb(a.a);$(a.b)}
function tl(a){kb(a.b);R(a.a)}
function Ib(a){a.a=-4&a.a|1}
function rc(a,b){a.e=b;qc(a,b)}
function gk(a,b){a.splice(b,1)}
function go(a,b,c){hc(a.c,b,c)}
function hc(a,b,c){qi(a.e,b,c)}
function zj(a,b,c){b.w(a.a[c])}
function Gi(a,b){return a.a[b]}
function bm(a,b){return a.g=b}
function gq(a){return this===a}
function _p(){return jk(this)}
function Yc(a,b){return Sh(a,b)}
function bq(){return ti(this.a)}
function iq(){return this.c.i<0}
function kq(){return this.b.i<0}
function pq(){return this.f.i<0}
function ci(){pc(this);this.G()}
function ki(a){uc.call(this,a)}
function Ih(a){uc.call(this,a)}
function Yh(a){uc.call(this,a)}
function lh(){jh==null&&(jh=[])}
function Dc(){Dc=sh;!!(Uc(),Tc)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function T(a){mb(a.f);return V(a)}
function Mh(a){Lh(a);return a.k}
function Rj(a,b){a.T(b);return a}
function hj(){dj();return new cj}
function ab(a){J();Zb(a);a.e=-2}
function K(a,b){O(a);L(a,tj(b))}
function Sj(a,b){$j(a,Rj(a.a,b))}
function uj(a,b){while(a.eb(b));}
function Xj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function gc(a,b){this.a=a;this.b=b}
function Xh(a,b){this.a=a;this.b=b}
function Ci(a,b){this.a=a;this.b=b}
function Ah(a){this.a=yh;this.b=a}
function Wj(a,b){this.a=a;this.b=b}
function Zj(a,b){this.a=a;this.b=b}
function mq(a){return 1==this.a.d}
function nq(a){return 1==this.a.c}
function ti(a){return a.a.b+a.b.b}
function jj(a,b){return a.a.get(b)}
function Tn(a){fb(a.b);return a.e}
function Vo(a){fb(a.d);return a.e}
function jo(a){fb(a.a);return a.d}
function Dk(a,b){a.ref=b;return a}
function Ek(a,b){a.href=b;return a}
function Bk(a,b){this.a=a;this.b=b}
function Zl(a,b){this.a=a;this.b=b}
function xm(a,b){this.a=a;this.b=b}
function ym(a,b){this.a=a;this.b=b}
function zm(a,b){this.a=a;this.b=b}
function Am(a,b){this.a=a;this.b=b}
function Cm(a,b){this.a=a;this.b=b}
function wn(a,b){this.a=a;this.b=b}
function xn(a,b){this.a=a;this.b=b}
function zn(a,b){this.a=a;this.b=b}
function An(a,b){this.a=a;this.b=b}
function _n(a,b){this.a=a;this.b=b}
function Co(a,b){this.a=a;this.b=b}
function Po(a,b){this.a=a;this.b=b}
function Qo(a,b){this.b=a;this.a=b}
function kl(a,b){Xh.call(this,a,b)}
function lp(a,b){Xh.call(this,a,b)}
function wp(a,b){this.b=a;this.a=b}
function Qm(){this.a=uk((Ym(),Xm))}
function Tm(){this.a=uk((an(),_m))}
function rn(){this.a=uk((en(),dn))}
function Cn(){this.a=uk((jn(),hn))}
function Hn(){this.a=uk((nn(),mn))}
function sn(a){this.a=tj(a);tn=this}
function Um(a){this.a=tj(a);Vm=this}
function Un(a){Sn(a,(fb(a.b),a.e))}
function ko(a){tm(a,(fb(a.a),!a.d))}
function Ub(a){return !a.d?a:Ub(a.d)}
function pi(a){return !a?null:a.ab()}
function pd(a){return a==null?null:a}
function sj(a){return a!=null?s(a):0}
function md(a){return typeof a===zp}
function o(a,b){return pd(a)===pd(b)}
function ek(a,b,c){a.splice(b,0,c)}
function Nk(a,b){a.value=b;return a}
function Ik(a,b){a.onBlur=b;return a}
function gi(a,b){a.a+=''+b;return a}
function Fk(a,b){a.onClick=b;return a}
function Hk(a,b){a.checked=b;return a}
function Kc(a){$wnd.clearTimeout(a)}
function Di(a){a.a=$c(je,Bp,1,0,5,1)}
function si(a){a.a=new $i;a.b=new mj}
function ib(a){this.c=new Mi;this.b=a}
function Db(a){this.d=tj(a);this.b=100}
function jm(a){kb(a.b);R(a.c);$(a.a)}
function ec(a,b){cc(a,b,false);eb(a.d)}
function fk(a,b){dk(b,0,a,0,b.length)}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function cd(a,b,c){return {l:a,m:b,h:c}}
function di(a,b){return a.charCodeAt(b)}
function jk(a){return a.$H||(a.$H=++ik)}
function Z(a){return !(!!a&&1==(a.c&7))}
function kd(a,b){return a!=null&&hd(a,b)}
function rk(a,b){for(var c in a){b(c)}}
function Jk(a,b){a.onChange=b;return a}
function Kk(a,b){a.onKeyDown=b;return a}
function Gk(a){a.autoFocus=true;return a}
function Lh(a){if(a.k!=null){return}Uh(a)}
function pb(a){J();ob(a);sb(a,2,true)}
function fb(a){var b;Vb((J(),b=Qb,b),a)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function P(){this.a=$c(je,Bp,1,100,5,1)}
function uc(a){this.g=a;pc(this);this.G()}
function Qj(a,b){Jj.call(this,a);this.a=b}
function dc(a,b){mc(b.c,a);kd(b,9)&&b.t()}
function qj(a,b){while(a.Y()){bk(b,a.Z())}}
function aj(a,b){var c;c=a[Op];c.call(a,b)}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function nk(){nk=sh;kk=new p;mk=new p}
function Ui(){this.a=new $i;this.b=new mj}
function Uo(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function yo(a){return $h(S(a.e).a-S(a.a).a)}
function od(a){return typeof a==='string'}
function ld(a){return typeof a==='boolean'}
function Ec(a,b,c){return a.apply(b,c);var d}
function Nb(a,b,c){Ib(tj(c));K(a.a[b],tj(c))}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Ok(a,b){a.onDoubleClick=b;return a}
function pc(a){a.j&&a.e!==Jp&&a.G();return a}
function Ph(a){var b;b=Oh(a);Wh(a,b);return b}
function Ei(a,b){a.a[a.a.length]=b;return true}
function pj(a,b,c){this.a=a;this.b=b;this.c=c}
function Gh(a,b,c,d){a.addEventListener(b,c,d)}
function Rl(a,b){A((J(),J(),I),new Zl(a,b),Tp)}
function km(a,b){A((J(),J(),I),new Cm(a,b),Tp)}
function om(a,b){A((J(),J(),I),new zm(a,b),Tp)}
function pm(a,b){A((J(),J(),I),new ym(a,b),Tp)}
function sm(a,b){A((J(),J(),I),new xm(a,b),Tp)}
function uo(a,b){A((J(),J(),I),new Co(a,b),Tp)}
function No(a,b){A((J(),J(),I),new Po(a,b),Tp)}
function no(a){A((J(),J(),I),new qo(a),Tp)}
function Ko(a){A((J(),J(),I),new Ro(a),Tp)}
function Vn(a){A((J(),J(),I),new ao(a),Tp)}
function qm(a){A((J(),J(),I),new Dm(a),Tp)}
function Dh(a){if(!a){throw dh(new ci)}return a}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function xj(a,b){while(a.c<a.d){zj(a,b,a.c++)}}
function Bj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Sl(a,b){var c;c=b.target;Ul(a,c.value)}
function Kj(a,b){var c;return Oj(a,(c=new Mi,c))}
function Uc(){Uc=sh;var a;!Wc();a=new Xc;Tc=a}
function ai(){ai=sh;_h=$c(fe,Bp,30,256,0,1)}
function Fh(){Fh=sh;Eh=$wnd.goog.global.document}
function F(){this.f=new Pb;this.a=new Db(this.f)}
function Do(a,b){this.a=a;this.c=b;this.b=false}
function Uj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function ij(a,b){return !(a.a.get(b)===undefined)}
function So(a){return o(Yp,a)||o(Zp,a)||o('',a)}
function xo(a){return Jh(),0==S(a.e).a?true:false}
function Qi(a){return new Qj(null,Pi(a,a.length))}
function ad(a){return Array.isArray(a)&&a.pb===wh}
function jd(a){return !Array.isArray(a)&&a.pb===wh}
function Pi(a,b){return vj(b,a.length),new Aj(a,b)}
function ul(a){return Jh(),S(a.e.b).a>0?true:false}
function vl(a){return B((J(),J(),I),a.b,new Al(a))}
function so(a){R(a.c);R(a.e);R(a.a);R(a.b);$(a.d)}
function wo(a){bi(new Ai(a.g),new fc(a));si(a.g)}
function xi(a){var b;b=a.a.Z();a.b=wi(a);return b}
function Rh(a){var b;b=Oh(a);b.j=a;b.e=1;return b}
function Ii(a,b){var c;c=a.a[b];gk(a.a,b);return c}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function rm(a){return B((J(),J(),I),a.b,new wm(a))}
function Km(a){return B((J(),J(),I),a.a,new Om(a))}
function Fl(a){return B((J(),J(),I),a.a,new Jl(a))}
function Tl(a){return B((J(),J(),I),a.a,new Xl(a))}
function ui(a,b){if(b){return ni(a.a,b)}return false}
function tj(a){if(a==null){throw dh(new ci)}return a}
function qk(){if(lk==256){kk=mk;mk=new p;lk=0}++lk}
function ql(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function Cl(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function gm(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Hj(a){if(!a.b){Ij(a);a.c=true}else{Hj(a.b)}}
function Mj(a,b){Ij(a);return new Qj(a,new Vj(b,a.a))}
function Nj(a,b){Ij(a);return new Qj(a,new Yj(b,a.a))}
function Sn(a,b){A((J(),J(),I),new _n(a,b),75497472)}
function Fm(a,b){var c;c=b.target;No(a.e,c.checked)}
function tm(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function Ul(a,b){var c;c=a.f;if(b!=c){a.f=b;eb(a.b)}}
function Qn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&Wn(a,b)}
function gb(a){var b;J();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Wn(a,b){var c;c=a.e;if(b!=c){a.e=tj(b);eb(a.b)}}
function Ki(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Qh(a,b){var c;c=Oh(a);Wh(a,c);c.e=b?8:0;return c}
function Mk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function wj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Cj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Aj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function lm(a,b){Yo(a.k,b);A((J(),J(),I),new xm(a,b),Tp)}
function Lo(a,b){Kj(vo(a.b),new Gj(new Fj)).Q(new tp(b))}
function Hh(a,b,c,d){a.removeEventListener(b,c,d)}
function ih(a){if(md(a)){return a|0}return a.l|a.m<<22}
function Th(a){if(a.P()){return null}var b=a.j;return oh[b]}
function Jj(a){if(!a){this.b=null;new Mi}else{this.b=a}}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Ti(a,b){return pd(a)===pd(b)||a!=null&&q(a,b)}
function oi(a,b){return b===a?'(this Map)':b==null?Lp:vh(b)}
function sc(a,b){var c;c=Mh(a.nb);return b==null?c:c+': '+b}
function _l(a,b){var c;if(S(a.c)){c=b.target;tm(a,c.value)}}
function bi(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function Rb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function lb(a){C((J(),J(),I),a);0==(a.f.a&Gp)&&D((null,I))}
function mm(a,b){A((J(),J(),I),new xm(a,b),Tp);Yo(a.k,null)}
function mp(){kp();return bd(Yc(Pg,1),Bp,32,0,[hp,jp,ip])}
function jn(){jn=sh;var a;hn=(a=th(gn.prototype.mb,gn,[]),a)}
function en(){en=sh;var a;dn=(a=th(cn.prototype.mb,cn,[]),a)}
function nn(){nn=sh;var a;mn=(a=th(ln.prototype.mb,ln,[]),a)}
function an(){an=sh;var a;_m=(a=th($m.prototype.mb,$m,[]),a)}
function Ym(){Ym=sh;var a;Xm=(a=th(Wm.prototype.mb,Wm,[]),a)}
function uh(a){function b(){}
;b.prototype=a||{};return new b}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function Lk(a){a.placeholder='What needs to be done?';return a}
function On(a,b){b.preventDefault();A((J(),J(),I),new bo(a),Tp)}
function Wi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Sh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function qh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Xi(a,b){var c;return Vi(b,Wi(a,b==null?0:(c=s(b),c|0)))}
function vo(a){fb(a.d);return new Qj(null,new Cj(new Ai(a.g),0))}
function Ni(a){Di(this);fk(this.a,mi(a,$c(je,Bp,1,ti(a.a),5,1)))}
function Nn(a){Hh((Fh(),$wnd.goog.global.window),Wp,a.d,false)}
function Mn(a){Gh((Fh(),$wnd.goog.global.window),Wp,a.d,false)}
function nm(a){return Jh(),Vo(a.k)==a.n.props['a']?true:false}
function Bh(a){zh();Dh(a);if(kd(a,45)){return a}return new Ah(a)}
function yj(a,b){if(a.c<a.d){zj(a,b,a.c++);return true}return false}
function lc(a){jc(a.g);!!a.e&&kc(a);Y(a.a);Y(a.c);jc(a.b);jc(a.f)}
function Rm(a,b,c){this.a=tj(a);this.b=tj(b);this.c=tj(c);Sm=this}
function Dn(a,b,c){this.a=tj(a);this.b=tj(b);this.c=tj(c);En=this}
function In(a,b,c){this.a=tj(a);this.b=tj(b);this.c=tj(c);Jn=this}
function _i(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Yj(a,b){wj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function Vj(a,b){wj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function bb(a,b){var c,d;Ei(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function zk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function to(a,b){var c;return u((J(),J(),I),new Do(a,b),Tp,(c=null,c))}
function Mo(a){Kj(Mj(vo(a.b),new rp),new Gj(new Fj)).Q(new sp(a.b))}
function Oo(a){this.b=tj(a);J();this.a=new nc(0,null,null,false,false)}
function nj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Dj(a,b){!a.a?(a.a=new ii(a.d)):gi(a.a,a.b);gi(a.a,b);return a}
function Oj(a,b){var c;Hj(a);c=new _j;c.a=b;a.a.X(new ck(c));return c.a}
function Lj(a){var b;Hj(a);b=0;while(a.a.eb(new ak)){b=eh(b,1)}return b}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Pj(a,b){var c;c=Kj(a,new Gj(new Fj));return Li(c,b.fb(c.a.length))}
function To(a,b){return (kp(),ip)==a||(hp==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function ri(a,b){return od(b)?b==null?Zi(a.a,null):lj(a.b,b):Zi(a.a,b)}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Jb(b){try{b.b.v()}catch(a){a=bh(a);if(!kd(a,4))throw dh(a)}}
function Kl(a){var b;b=fi((fb(a.b),a.f));if(b.length>0){Io(a.e,b);Ul(a,'')}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Fi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Ej(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function yi(a){this.d=a;this.c=new nj(this.d.b);this.a=this.c;this.b=wi(this)}
function fn(a){$wnd.React.Component.call(this,a);this.a=new Vl(this,tn.a)}
function bn(a){$wnd.React.Component.call(this,a);this.a=new Gl(this,Vm.a)}
function Wo(a){var b;return b=S(a.b),Kj(Mj(vo(a.i),new vp(b)),new Gj(new Fj))}
function Ln(a,b){a.f=b;o(b,S(a.a))&&Wn(a,b);Pn(b);A((J(),J(),I),new bo(a),Tp)}
function hk(a,b){return Zc(b)!=10&&bd(r(b),b.ob,b.__elementTypeId$,Zc(b),a),a}
function qi(a,b,c){return od(b)?b==null?Yi(a.a,null,c):kj(a.b,b,c):Yi(a.a,b,c)}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function ic(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new oc(a)),67108864,null)}}
function oj(a){if(a.a.c!=a.c){return jj(a.a,a.b.value[0])}return a.b.value[1]}
function ho(a,b){var c;if(kd(b,52)){c=b;return a.c.d==c.c.d}else{return false}}
function Ji(a,b){var c;c=Hi(a,b,0);if(c==-1){return false}gk(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&bd(Yc(a,f),b,c,e,g);return g}
function Hi(a,b,c){for(;c<a.a.length;++c){if(Ti(b,a.a[c])){return c}}return -1}
function V(a){if(a.b){if(kd(a.b,7)){throw dh(a.b)}else{throw dh(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=bh(a);if(kd(a,4)){J()}else throw dh(a)}}}
function bc(){var a;try{Sb(Qb);J()}finally{a=Qb.d;!a&&((J(),J(),I).d=true);Qb=Qb.d}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Mi);Ei(a.b,b)}}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function Ll(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Yl(a),Tp)}}
function xk(a){var b;return vk($wnd.React.StrictMode,null,null,(b={},b[Pp]=tj(a),b))}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nd(a){return a!=null&&(typeof a===yp||typeof a==='function')&&!(a.pb===wh)}
function nh(a,b){typeof window===yp&&typeof window['$gwt']===yp&&(window['$gwt'][a]=b)}
function Wh(a,b){var c;if(!a){return}b.j=a;var d=Th(b);if(!d){oh[a]=[b];return}d.nb=b}
function th(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Oh(a){var b;b=new Nh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function uk(a){var b;b=wk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Ri(a){var b,c,d;d=0;for(c=new yi(a.a);c.b;){b=xi(c);d=d+(b?s(b):0);d=d|0}return d}
function ob(a){var b,c;for(c=new Oi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function kh(){lh();var a=jh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Pb(){var a;this.a=$c(vd,Bp,44,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Zm(a){$wnd.React.Component.call(this,a);this.a=new wl(this,Sm.a,Sm.b,Sm.c)}
function kn(a){$wnd.React.Component.call(this,a);this.a=new um(this,En.a,En.b,En.c)}
function on(a){$wnd.React.Component.call(this,a);this.a=new Lm(this,Jn.a,Jn.b,Jn.c)}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Mi);a.c=c.c}b.d=true;Ei(a.c,tj(b))}
function lj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{aj(a.a,b);--a.b}return c}
function ro(a,b,c){var d;d=new oo(b,c);go(d,a,new gc(a,d));qi(a.g,$h(d.c.d),d);eb(a.d);return d}
function vk(a,b,c,d){var e;e=wk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=tj(d);return e}
function Bn(a,b){tk(a.a,(Lh(cg),cg.k+(''+(b?$h(b.c.d):null))));tj(b);a.a.props['a']=b;return a.a}
function wi(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new _i(a.d.a);return a.a.Y()}
function bh(a){var b;if(kd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new yc(a);Vc(b)}return b}
function fh(a){var b;b=a.h;if(b==0){return a.l+a.m*Hp}if(b==1048575){return a.l+a.m*Hp-Mp}return a}
function li(a,b){var c,d;for(d=new yi(b.a);d.b;){c=xi(d);if(!ui(a,c)){return false}}return true}
function hh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Mp;d=1048575}c=qd(e/Hp);b=qd(e-c*Hp);return cd(b,c,d)}
function Xo(a){var b;b=S(a.g.a);o(Yp,b)||o(Zp,b)||o('',b)?Sn(a.g,b):So(Tn(a.g))?Vn(a.g):Sn(a.g,'')}
function cc(a,b,c){var d;d=ri(a.g,b?$h(b.c.d):null);if(null!=d){mc(b.c,a);c&&!!b&&ic(b.c);eb(a.d)}}
function kj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function bd(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=wh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Vi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ti(a,c._())){return c}}return null}
function Yo(a,b){var c;c=a.e;if(!(b==c||!!b&&ho(b,c))){!!c&&mc(c.c,a);a.e=b;!!b&&go(b,a,new _o(a));eb(a.d)}}
function cm(a,b,c){27==c.which?A((J(),J(),I),new Am(a,b),Tp):13==c.which&&A((J(),J(),I),new ym(a,b),Tp)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:Dp)|(0==(c&6291456)?!a?Gp:Hp:0)|0|0|0)}
function Kb(a,b){this.b=tj(a);this.a=b|0|(0==(b&6291456)?Hp:0)|(0!=(b&229376)?0:98304)}
function vj(a,b){if(0>a||a>b){throw dh(new Ih('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function kp(){kp=sh;hp=new lp('ACTIVE',0);jp=new lp('COMPLETED',1);ip=new lp('ALL',2)}
function yc(a){wc();pc(this);this.e=a;qc(this,a);this.g=a==null?Lp:vh(a);this.a='';this.b=a;this.a=''}
function Nh(){this.g=Kh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function Kn(){this.a=Bh((pp(),op));this.b=Bh(new up(this.a));this.c=Bh((gp(),fp));this.d=Bh(new wp(this.a,this.c))}
function nl(){if(!ml){ml=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(th(ol.prototype.J,ol,[]))}}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Dp)?Jb(a):a.b.v();0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function cb(a,b){var c,d;d=a.c;Ji(d,b);!!a.b&&Dp!=(a.b.c&Ep)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((J(),c=Qb,c),a))}
function dd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return cd(c&4194303,d&4194303,e&1048575)}
function eh(a,b){var c;if(md(a)&&md(b)){c=a+b;if(-17592186044416<c&&c<Mp){return c}}return fh(dd(md(a)?hh(a):a,md(b)?hh(b):b))}
function $h(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ai(),_h)[b];!c&&(c=_h[b]=new Zh(a));return c}return new Zh(a)}
function vh(a){var b;if(Array.isArray(a)&&a.pb===wh){return Mh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function pk(a){nk();var b,c,d;c=':'+a;d=mk[c];if(d!=null){return qd(d)}d=kk[c];b=d==null?ok(a):qd(d);qk();mk[c]=b;return b}
function Si(a){var b,c,d;d=1;for(c=new Oi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=Ii(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function em(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;sm(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function r(a){return od(a)?me:md(a)?ae:ld(a)?$d:jd(a)?a.nb:ad(a)?a.nb:a.nb||Array.isArray(a)&&Yc(Rd,1)||Rd}
function s(a){return od(a)?pk(a):md(a)?qd(a):ld(a)?a?1231:1237:jd(a)?a.q():ad(a)?jk(a):!!a&&!!a.hashCode?a.hashCode():jk(a)}
function q(a,b){return od(a)?o(a,b):md(a)?pd(a)===pd(b):ld(a)?pd(a)===pd(b):jd(a)?a.o(b):ad(a)?o(a,b):!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function ll(){jl();return bd(Yc(df,1),Bp,6,0,[Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il])}
function Ij(a){if(a.b){Ij(a.b)}else if(a.c){throw dh(new Yh("Stream already terminated, can't be modified or used"))}}
function hd(a,b){if(od(a)){return !!gd[b]}else if(a.ob){return !!a.ob[b]}else if(md(a)){return !!fd[b]}else if(ld(a)){return !!ed[b]}return false}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(Dp==(b&Ep)?0:524288)|(0==(b&6291456)?Dp==(b&Ep)?Hp:Gp:0)|0|268435456|0)}
function dm(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Qo(b,c),Tp);Yo(a.k,null);tm(a,c)}else{uo(a.j,b)}}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Qb&&!!Qb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Vh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Li(a,b){var c,d;d=a.a.length;b.length<d&&(b=hk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function kc(a){var b,c,d;for(c=new Oi(new Ni(new vi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();kd(d,9)&&d.u()||b.ab().v()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Oi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function nc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ui:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Gl(a,b){var c;this.d=tj(b);this.n=tj(a);J();c=++El;this.b=new nc(c,null,new Hl(this),false,false);this.a=new vb(null,tj(new Il(this)),Sp)}
function oo(a,b){var c,d,e,f,g;this.e=tj(a);this.d=b;J();c=++eo;this.c=new nc(c,null,new po(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Lm(a,b,c,d){var e;this.d=tj(b);this.e=tj(c);this.f=tj(d);this.n=tj(a);J();e=++Jm;this.b=new nc(e,null,new Mm(this),false,false);this.a=new vb(null,tj(new Nm(this)),Sp)}
function Ck(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function fi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function mi(a,b){var c,d,e,f;f=ti(a.a);b.length<f&&(b=hk(new Array(f),b));e=b;d=new yi(a.a);for(c=0;c<f;++c){e[c]=xi(d)}b.length>f&&(b[f]=null);return b}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.v(),null)}finally{bc()}return f}catch(a){a=bh(a);if(kd(a,4)){e=a;throw dh(e)}else throw dh(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.s()}else{ac(b,e);try{g=c.s()}finally{bc()}}return g}catch(a){a=bh(a);if(kd(a,4)){f=a;throw dh(f)}else throw dh(a)}finally{D(b)}}
function Bb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Hb(c);return true}
function mh(b,c,d,e){lh();var f=jh;$moduleName=c;$moduleBase=d;ah=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{xp(g)()}catch(a){b(c,a)}}else{xp(g)()}}
function W(a,b,c,d){this.c=tj(a);this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);Dp==(d&Ep)&&lb(this.f)}
function wk(a,b){var c;c=new $wnd.Object;c.$$typeof=tj(a);c.type=tj(b);c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function fj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return gj()}}
function Vl(a,b){var c,d,e;this.e=tj(b);this.n=tj(a);J();c=++Pl;this.c=new nc(c,null,new Wl(this),false,false);this.b=(e=new ib((d=null,d)),e);this.a=new vb(null,tj(new $l(this)),Sp)}
function Dl(a){var b,c,d;a.c=0;nl();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),yk('span',Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,['todo-count'])),[yk('strong',null,[c]),' '+d+' left']));return b}
function ph(){oh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Rc(c,g)):g[0].qb()}catch(a){a=bh(a);if(kd(a,4)){d=a;Dc();Jc(kd(d,36)?d.H():d)}else throw dh(a)}}return c}
function Ol(a){var b;a.d=0;nl();b=yk(Up,Gk(Jk(Kk(Nk(Lk(Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,['new-todo']))),(fb(a.b),a.f)),th(pn.prototype.kb,pn,[a])),th(qn.prototype.jb,qn,[a]))),null);return b}
function xc(a){var b;if(a.c==null){b=pd(a.b)===pd(vc)?null:a.b;a.d=b==null?Lp:nd(b)?b==null?null:b.name:od(b)?'String':Mh(r(b));a.a=a.a+': '+(nd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(pd(e)===pd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=bh(a);if(kd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw dh(c)}else throw dh(a)}}
function dk(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Yi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Vi(b,e);if(f){return f.bb(c)}}e[e.length]=new Ci(b,c);++a.b;return null}
function ok(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+di(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=bh(a);if(kd(a,4)){J()}else throw dh(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=$c(je,Bp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Ch(a,b){var c;c=pd(a)!==pd(yh);if(c&&pd(a)!==pd(b)){throw dh(new Yh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}return b}
function wl(a,b,c,d){var e;this.e=tj(b);this.f=tj(c);this.g=tj(d);this.n=tj(a);J();e=++sl;this.c=new nc(e,null,new xl(this),false,false);this.a=new W(new yl(this),null,null,136478720);this.b=new vb(null,tj(new zl(this)),Sp)}
function ub(a,b,c,d){this.b=new Mi;this.f=new Kb(new yb(this),d&6520832|262144|Dp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&Gp)&&D((null,I)))}
function Zi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ti(b,e._())){if(d.length==1){d.length=0;aj(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function xh(){var a;a=new Kn;new Rm(a.a.I(),a.b.I(),a.d.I());new Dn(a.a.I(),a.b.I(),a.d.I());new In(a.a.I(),a.b.I(),a.d.I());new sn(a.b.I());new Um(a.a.I());$wnd.ReactDOM.render(xk([(new Hn).a]),(Fh(),Eh).getElementById('app'),null)}
function rh(a,b,c){var d=oh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=oh[b]),uh(h));_.ob=c;!b&&(_.pb=wh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Uh(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Vh('.',[c,Vh('$',d)]);a.b=Vh('.',[c,Vh('.',d)]);a.i=d[d.length-1]}
function Pn(a){var b;if(0==a.length){b=(Fh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Eh.title,b)}else{(Fh(),$wnd.goog.global.window).location.hash=a}}
function ni(a,b){var c,d,e;c=b._();e=b.ab();d=od(c)?c==null?pi(Xi(a.a,null)):jj(a.b,c):pi(Xi(a.a,c));if(!(pd(e)===pd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(od(c)?c==null?!!Xi(a.a,null):ij(a.b,c):!!Xi(a.a,c))){return false}return true}
function yk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;sk(b,th(Bk.prototype.hb,Bk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Pp]=c[0],undefined):(d[Pp]=c,undefined));return vk(a,e,f,d)}
function Xn(){var a,b,c;this.d=new dp(this);this.f=this.e=(c=(Fh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new nc(0,null,new Yn(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new co,new Zn(this),new $n(this),35651584)}
function Zo(a,b){var c,d;this.i=tj(a);this.g=tj(b);J();this.f=new nc(0,null,new $o(this),false,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new ap(this),null,null,Xp);this.c=new W(new bp(this),null,null,Xp);this.a=new vb(tj(new cp(this)),null,681574400);D((null,I))}
function zo(){var a;this.g=new Ui;J();this.f=new nc(0,new Bo(this),new Ao(this),false,false);this.d=(a=new ib(null),a);this.c=new W(new Eo(this),null,null,Xp);this.e=new W(new Fo(this),null,null,Xp);this.a=new W(new Go(this),null,null,Xp);this.b=new W(new Ho(this),null,null,Xp)}
function um(a,b,c,d){var e,f,g;this.j=tj(b);tj(c);this.k=tj(d);this.n=tj(a);J();e=++im;this.e=new nc(e,null,new vm(this),false,false);this.a=(g=new ib((f=null,f)),g);this.c=new W(new Bm(this),null,null,136478720);this.b=new vb(null,tj(new Em(this)),Sp);sm(this,this.n.props['a'])}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Oi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=bh(a);if(!kd(a,4))throw dh(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function qc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function ej(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}Fi(a.b,new Ab(a));a.b.a=$c(je,Bp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Im(a){var b;a.c=0;nl();b=yk('div',null,[yk('div',null,[yk(Vp,Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,[Vp])),[yk('h1',null,['todos']),(new rn).a]),S(a.d.c)?null:yk('section',Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,[Vp])),[yk(Up,Jk(Mk(Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,['toggle-all'])),(jl(),Qk)),th(Fn.prototype.jb,Fn,[a])),null),yk('ul',Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,['todo-list'])),Pj(tj(Nj(S(a.f.c).W(),new Gn)),new Ak))]),S(a.d.c)?null:(new Qm).a])]);return b}
function jl(){jl=sh;Pk=new kl(Qp,0);Qk=new kl('checkbox',1);Rk=new kl('color',2);Sk=new kl('date',3);Tk=new kl('datetime',4);Uk=new kl('email',5);Vk=new kl('file',6);Wk=new kl('hidden',7);Xk=new kl('image',8);Yk=new kl('month',9);Zk=new kl(zp,10);$k=new kl('password',11);_k=new kl('radio',12);al=new kl('range',13);bl=new kl('reset',14);cl=new kl('search',15);dl=new kl('submit',16);el=new kl('tel',17);fl=new kl('text',18);gl=new kl('time',19);hl=new kl('url',20);il=new kl('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Gi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ki(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Gi(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ii(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Mi)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Dp!=(k.b.c&Ep)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function rl(a){var b,c;a.d=0;nl();c=(b=S(a.g.b),yk('footer',Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,['footer'])),[(new Tm).a,yk('ul',Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,['filters'])),[yk('li',null,[yk('a',Ek(Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,[(kp(),ip)==b?Rp:null])),'#'),['All'])]),yk('li',null,[yk('a',Ek(Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,[hp==b?Rp:null])),'#active'),['Active'])]),yk('li',null,[yk('a',Ek(Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,[jp==b?Rp:null])),'#completed'),['Completed'])])]),S(a.a)?yk(Qp,Fk(Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,['clear-completed'])),th(Pm.prototype.lb,Pm,[a])),['Clear Completed']):null]));return c}
function hm(a){var b,c,d,e;a.f=0;nl();b=a.n.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.n.props['a'],e=(fb(d.a),d.d),yk('li',Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[yk('div',Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,['view'])),[yk(Up,Jk(Hk(Mk(Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,['toggle'])),(jl(),Qk)),e),th(vn.prototype.jb,vn,[d])),null),yk('label',Ok(new $wnd.Object,th(wn.prototype.lb,wn,[a,d])),[(fb(d.b),d.e)]),yk(Qp,Fk(Ck(new $wnd.Object,bd(Yc(me,1),Bp,2,6,['destroy'])),th(xn.prototype.lb,xn,[a,d])),null)]),yk(Up,Kk(Jk(Ik(Nk(Ck(Dk(new $wnd.Object,th(yn.prototype.w,yn,[a])),bd(Yc(me,1),Bp,2,6,['edit'])),(fb(a.a),a.d)),th(zn.prototype.ib,zn,[a,d])),th(un.prototype.jb,un,[a])),th(An.prototype.kb,An,[a,d])),null)]));return c}
function gj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Op]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!ej()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Op]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var yp='object',zp='number',Ap={11:1},Bp={3:1},Cp={9:1},Dp=1048576,Ep=1835008,Fp={5:1},Gp=2097152,Hp=4194304,Ip={25:1},Jp='__noinit__',Kp={3:1,10:1,7:1,4:1},Lp='null',Mp=17592186044416,Np={42:1},Op='delete',Pp='children',Qp='button',Rp='selected',Sp=1411518464,Tp=142606336,Up='input',Vp='header',Wp='hashchange',Xp=136314880,Yp='active',Zp='completed';var _,oh,jh,ah=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;ph();rh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=_p;_.r=function(){var a;return Mh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var ed,fd,gd;rh(57,1,{},Nh);_.K=function(a){var b;b=new Nh;b.e=4;a>1?(b.c=Sh(this,a-1)):(b.c=this);return b};_.L=function(){Lh(this);return this.b};_.M=function(){return Mh(this)};_.N=function(){Lh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Lh(this),this.k)};_.e=0;_.g=0;var Kh=1;var je=Ph(1);var _d=Ph(57);rh(86,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var ud=Ph(86);rh(37,1,Ap,G);_.s=function(){return this.a.v(),null};var sd=Ph(37);rh(87,1,{},H);var td=Ph(87);var I;rh(44,1,{44:1},P);_.b=0;_.c=false;_.d=0;var vd=Ph(44);rh(235,1,Cp);_.r=function(){var a;return Mh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var yd=Ph(235);rh(19,235,Cp,W);_.t=function(){R(this)};_.u=$p;_.a=false;_.d=0;_.k=false;var xd=Ph(19);rh(164,1,Ap,X);_.s=function(){return T(this.a)};var wd=Ph(164);rh(17,235,{9:1,17:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Ad=Ph(17);rh(163,1,Fp,jb);_.v=function(){ab(this.a)};var zd=Ph(163);rh(18,235,{9:1,18:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Fd=Ph(18);rh(165,1,Ip,xb);_.v=function(){Q(this.a)};var Bd=Ph(165);rh(166,1,Fp,yb);_.v=function(){mb(this.a)};var Cd=Ph(166);rh(167,1,Fp,zb);_.v=function(){pb(this.a)};var Dd=Ph(167);rh(168,1,{},Ab);_.w=function(a){nb(this.a,a)};var Ed=Ph(168);rh(104,1,{},Db);_.a=0;_.b=0;_.c=0;var Gd=Ph(104);rh(169,1,Cp,Fb);_.t=function(){Eb(this)};_.u=$p;_.a=false;var Hd=Ph(169);rh(71,235,{9:1,71:1},Kb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Jd=Ph(71);rh(64,1,{64:1},Pb);var Id=Ph(64);rh(173,1,{},_b);_.r=function(){var a;return Lh(Kd),Kd.k+'@'+(a=jk(this)>>>0,a.toString(16))};_.a=0;var Qb;var Kd=Ph(173);rh(145,1,{});var Nd=Ph(145);rh(109,1,{},fc);_.w=function(a){dc(this.a,a)};var Ld=Ph(109);rh(110,1,Fp,gc);_.v=function(){ec(this.a,this.b)};var Md=Ph(110);rh(16,1,Cp,nc);_.t=function(){ic(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Lh(Pd),Pd.k+'@'+(a=jk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Pd=Ph(16);rh(155,1,Fp,oc);_.v=function(){lc(this.a)};var Od=Ph(155);rh(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=eq;_.C=function(){return Pj(Nj(Qi((this.i==null&&(this.i=$c(oe,Bp,4,0,0,1)),this.i)),new ji),new Tj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){rc(this,tc(this.A(sc(this,this.g))));Vc(this)};_.r=function(){return sc(this,this.F())};_.e=Jp;_.j=true;var oe=Ph(4);rh(10,4,{3:1,10:1,4:1});var ce=Ph(10);rh(7,10,Kp);var ke=Ph(7);rh(58,7,Kp);var ge=Ph(58);rh(82,58,Kp);var Td=Ph(82);rh(36,82,{36:1,3:1,10:1,7:1,4:1},yc);_.F=function(){xc(this);return this.c};_.H=function(){return pd(this.b)===pd(vc)?null:this.b};var vc;var Qd=Ph(36);var Rd=Ph(0);rh(217,1,{});var Sd=Ph(217);var Ac=0,Bc=0,Cc=-1;rh(95,217,{},Qc);var Mc;var Ud=Ph(95);var Tc;rh(228,1,{});var Wd=Ph(228);rh(83,228,{},Xc);var Vd=Ph(83);rh(45,1,{45:1},Ah);_.I=function(){var a;a=this.a;if(pd(a)===pd(yh)){a=this.a;if(pd(a)===pd(yh)){a=this.b.I();this.a=Ch(this.a,a);this.b=null}}return a};var yh;var Xd=Ph(45);var Eh;rh(80,1,{77:1});_.r=$p;var Yd=Ph(80);rh(84,7,Kp);var ee=Ph(84);rh(128,84,Kp,Ih);var Zd=Ph(128);ed={3:1,78:1,29:1};var $d=Ph(78);rh(43,1,{3:1,43:1});var ie=Ph(43);fd={3:1,29:1,43:1};var ae=Ph(227);rh(31,1,{3:1,29:1,31:1});_.o=gq;_.q=_p;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=Ph(31);rh(60,7,Kp,Yh);var de=Ph(60);rh(30,43,{3:1,29:1,30:1,43:1},Zh);_.o=function(a){return kd(a,30)&&a.a==this.a};_.q=$p;_.r=function(){return ''+this.a};_.a=0;var fe=Ph(30);var _h;rh(293,1,{});rh(62,58,Kp,ci);_.A=function(a){return new TypeError(a)};var he=Ph(62);gd={3:1,77:1,29:1,2:1};var me=Ph(2);rh(81,80,{77:1},ii);var le=Ph(81);rh(297,1,{});rh(75,1,{},ji);_.S=function(a){return a.e};var ne=Ph(75);rh(61,7,Kp,ki);var pe=Ph(61);rh(229,1,{41:1});_.Q=dq;_.V=function(){return new Cj(this,0)};_.W=function(){return new Qj(null,this.V())};_.T=function(a){throw dh(new ki('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Ej('[',']');for(b=this.R();b.Y();){a=b.Z();Dj(c,a===this?'(this Collection)':a==null?Lp:vh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var qe=Ph(229);rh(232,1,{215:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!kd(a,38)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new yi((new vi(d)).a);c.b;){b=xi(c);if(!ni(this,b)){return false}}return true};_.q=function(){return Ri(new vi(this))};_.r=function(){var a,b,c;c=new Ej('{','}');for(b=new yi((new vi(this)).a);b.b;){a=xi(b);Dj(c,oi(this,a._())+'='+oi(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Be=Ph(232);rh(103,232,{215:1});var te=Ph(103);rh(231,229,{41:1,239:1});_.V=function(){return new Cj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!kd(a,22)){return false}b=a;if(ti(b.a)!=this.U()){return false}return li(this,b)};_.q=function(){return Ri(this)};var Ce=Ph(231);rh(22,231,{22:1,41:1,239:1},vi);_.R=function(){return new yi(this.a)};_.U=bq;var se=Ph(22);rh(23,1,{},yi);_.X=aq;_.Z=function(){return xi(this)};_.Y=cq;_.b=false;var re=Ph(23);rh(230,229,{41:1,236:1});_.V=function(){return new Cj(this,16)};_.$=function(a,b){throw dh(new ki('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!kd(a,14)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Oi(f);for(c=new Oi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(pd(b)===pd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Si(this)};_.R=function(){return new zi(this)};var ve=Ph(230);rh(94,1,{},zi);_.X=aq;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Gi(this.b,this.a++)};_.a=0;var ue=Ph(94);rh(63,229,{41:1},Ai);_.R=function(){var a;a=new yi((new vi(this.a)).a);return new Bi(a)};_.U=bq;var xe=Ph(63);rh(98,1,{},Bi);_.X=aq;_.Y=function(){return this.a.b};_.Z=function(){var a;a=xi(this.a);return a.ab()};var we=Ph(98);rh(96,1,Np);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Ti(this.a,b._())&&Ti(this.b,b.ab())};_._=$p;_.ab=cq;_.q=function(){return sj(this.a)^sj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ye=Ph(96);rh(97,96,Np,Ci);var ze=Ph(97);rh(233,1,Np);_.o=function(a){var b;if(!kd(a,42)){return false}b=a;return Ti(this.b.value[0],b._())&&Ti(oj(this),b.ab())};_.q=function(){return sj(this.b.value[0])^sj(oj(this))};_.r=function(){return this.b.value[0]+'='+oj(this)};var Ae=Ph(233);rh(14,230,{3:1,14:1,41:1,236:1},Mi,Ni);_.$=function(a,b){ek(this.a,a,b)};_.T=function(a){return Ei(this,a)};_.Q=function(a){Fi(this,a)};_.R=function(){return new Oi(this)};_.U=function(){return this.a.length};var Ee=Ph(14);rh(15,1,{},Oi);_.X=aq;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var De=Ph(15);rh(38,103,{3:1,38:1,215:1},Ui);var Fe=Ph(38);rh(67,1,{},$i);_.Q=dq;_.R=function(){return new _i(this)};_.b=0;var He=Ph(67);rh(68,1,{},_i);_.X=aq;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Ge=Ph(68);var cj;rh(65,1,{},mj);_.Q=dq;_.R=function(){return new nj(this)};_.b=0;_.c=0;var Ke=Ph(65);rh(66,1,{},nj);_.X=aq;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new pj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var Ie=Ph(66);rh(116,233,Np,pj);_._=function(){return this.b.value[0]};_.ab=function(){return oj(this)};_.bb=function(a){return kj(this.a,this.b.value[0],a)};_.c=0;var Je=Ph(116);rh(118,1,{});_.X=fq;_.cb=function(){return this.d};_.db=eq;_.d=0;_.e=0;var Oe=Ph(118);rh(69,118,{});var Le=Ph(69);rh(99,1,{});_.X=fq;_.cb=cq;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Ne=Ph(99);rh(100,99,{},Aj);_.X=function(a){xj(this,a)};_.eb=function(a){return yj(this,a)};var Me=Ph(100);rh(21,1,{},Cj);_.cb=$p;_.db=function(){Bj(this);return this.c};_.X=function(a){Bj(this);this.d.X(a)};_.eb=function(a){Bj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Pe=Ph(21);rh(59,1,{},Ej);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Qe=Ph(59);rh(35,1,{},Fj);_.S=function(a){return a};var Re=Ph(35);rh(39,1,{},Gj);var Se=Ph(39);rh(117,1,{});_.c=false;var af=Ph(117);rh(27,117,{258:1},Qj);var _e=Ph(27);rh(76,1,{},Tj);_.fb=function(a){return $c(je,Bp,1,a,5,1)};var Te=Ph(76);rh(120,69,{},Vj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Wj(this,a)));return this.b};_.b=false;var Ve=Ph(120);rh(123,1,{},Wj);_.w=function(a){Uj(this.a,this.b,a)};var Ue=Ph(123);rh(119,69,{},Yj);_.eb=function(a){return this.b.eb(new Zj(this,a))};var Xe=Ph(119);rh(122,1,{},Zj);_.w=function(a){Xj(this.a,this.b,a)};var We=Ph(122);rh(121,1,{},_j);_.w=function(a){$j(this,a)};var Ye=Ph(121);rh(124,1,{},ak);_.w=function(a){};var Ze=Ph(124);rh(125,1,{},ck);_.w=function(a){bk(this,a)};var $e=Ph(125);rh(295,1,{});rh(292,1,{});var ik=0;var kk,lk=0,mk;rh(908,1,{});rh(929,1,{});rh(234,1,{});var bf=Ph(234);rh(170,1,{},Ak);_.fb=function(a){return new Array(a)};var cf=Ph(170);rh(260,$wnd.Function,{},Bk);_.hb=function(a){zk(this.a,this.b,a)};rh(6,31,{3:1,29:1,31:1,6:1},kl);var Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il;var df=Qh(6,ll);var ml;rh(259,$wnd.Function,{},ol);_.J=function(a){return Eb(ml),ml=null,null};rh(187,234,{});var Of=Ph(187);rh(188,187,{});_.d=0;var Sf=Ph(188);rh(189,188,Cp,wl);_.t=hq;_.o=gq;_.q=_p;_.u=iq;_.r=function(){var a;return Lh(nf),nf.k+'@'+(a=jk(this)>>>0,a.toString(16))};var sl=0;var nf=Ph(189);rh(190,1,Fp,xl);_.v=function(){tl(this.a)};var ef=Ph(190);rh(191,1,Ap,yl);_.s=function(){return ul(this.a)};var ff=Ph(191);rh(192,1,Ip,zl);_.v=function(){ql(this.a)};var gf=Ph(192);rh(193,1,Ap,Al);_.s=function(){return rl(this.a)};var hf=Ph(193);rh(208,234,{});var Nf=Ph(208);rh(209,208,{});_.c=0;var Rf=Ph(209);rh(210,209,Cp,Gl);_.t=jq;_.o=gq;_.q=_p;_.u=kq;_.r=function(){var a;return Lh(mf),mf.k+'@'+(a=jk(this)>>>0,a.toString(16))};var El=0;var mf=Ph(210);rh(211,1,Fp,Hl);_.v=lq;var jf=Ph(211);rh(212,1,Ip,Il);_.v=function(){Cl(this.a)};var kf=Ph(212);rh(213,1,Ap,Jl);_.s=function(){return Dl(this.a)};var lf=Ph(213);rh(179,234,{});_.f='';var _f=Ph(179);rh(180,179,{});_.d=0;var Uf=Ph(180);rh(181,180,Cp,Vl);_.t=hq;_.o=gq;_.q=_p;_.u=iq;_.r=function(){var a;return Lh(tf),tf.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Pl=0;var tf=Ph(181);rh(182,1,Fp,Wl);_.v=function(){Ql(this.a)};var of=Ph(182);rh(184,1,Ap,Xl);_.s=function(){return Ol(this.a)};var pf=Ph(184);rh(185,1,Fp,Yl);_.v=function(){Kl(this.a)};var qf=Ph(185);rh(186,1,Fp,Zl);_.v=function(){Sl(this.a,this.b)};var rf=Ph(186);rh(183,1,Ip,$l);_.v=function(){ql(this.a)};var sf=Ph(183);rh(175,234,{});_.i=false;var cg=Ph(175);rh(195,175,{});_.f=0;var Wf=Ph(195);rh(196,195,Cp,um);_.t=function(){ic(this.e)};_.o=gq;_.q=_p;_.u=function(){return this.e.i<0};_.r=function(){var a;return Lh(Ef),Ef.k+'@'+(a=jk(this)>>>0,a.toString(16))};var im=0;var Ef=Ph(196);rh(197,1,Fp,vm);_.v=function(){jm(this.a)};var uf=Ph(197);rh(200,1,Ap,wm);_.s=function(){return hm(this.a)};var vf=Ph(200);rh(50,1,Fp,xm);_.v=function(){tm(this.a,Tn(this.b))};var wf=Ph(50);rh(72,1,Fp,ym);_.v=function(){dm(this.a,this.b)};var xf=Ph(72);rh(201,1,Fp,zm);_.v=function(){lm(this.a,this.b)};var yf=Ph(201);rh(202,1,Fp,Am);_.v=function(){mm(this.a,this.b)};var zf=Ph(202);rh(198,1,Ap,Bm);_.s=function(){return nm(this.a)};var Af=Ph(198);rh(203,1,Fp,Cm);_.v=function(){_l(this.a,this.b)};var Bf=Ph(203);rh(204,1,Fp,Dm);_.v=function(){em(this.a)};var Cf=Ph(204);rh(199,1,Ip,Em);_.v=function(){gm(this.a)};var Df=Ph(199);rh(139,234,{});var gg=Ph(139);rh(140,139,{});_.c=0;var Yf=Ph(140);rh(141,140,Cp,Lm);_.t=jq;_.o=gq;_.q=_p;_.u=kq;_.r=function(){var a;return Lh(If),If.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Jm=0;var If=Ph(141);rh(142,1,Fp,Mm);_.v=lq;var Ff=Ph(142);rh(143,1,Ip,Nm);_.v=function(){Cl(this.a)};var Gf=Ph(143);rh(144,1,Ap,Om);_.s=function(){return Im(this.a)};var Hf=Ph(144);rh(264,$wnd.Function,{},Pm);_.lb=function(a){Ko(this.a.f)};rh(172,1,{},Qm);var Jf=Ph(172);rh(89,1,{},Rm);var Kf=Ph(89);var Sm;rh(194,1,{},Tm);var Lf=Ph(194);rh(93,1,{},Um);var Mf=Ph(93);var Vm;rh(265,$wnd.Function,{},Wm);_.mb=function(a){return new Zm(a)};var Xm;rh(177,$wnd.React.Component,{},Zm);qh(oh[1],_);_.componentWillUnmount=function(){pl(this.a)};_.render=function(){return vl(this.a)};_.shouldComponentUpdate=mq;var Pf=Ph(177);rh(276,$wnd.Function,{},$m);_.mb=function(a){return new bn(a)};var _m;rh(205,$wnd.React.Component,{},bn);qh(oh[1],_);_.componentWillUnmount=function(){Bl(this.a)};_.render=function(){return Fl(this.a)};_.shouldComponentUpdate=nq;var Qf=Ph(205);rh(263,$wnd.Function,{},cn);_.mb=function(a){return new fn(a)};var dn;rh(176,$wnd.React.Component,{},fn);qh(oh[1],_);_.componentWillUnmount=function(){pl(this.a)};_.render=function(){return Tl(this.a)};_.shouldComponentUpdate=mq;var Tf=Ph(176);rh(266,$wnd.Function,{},gn);_.mb=function(a){return new kn(a)};var hn;rh(178,$wnd.React.Component,{},kn);qh(oh[1],_);_.componentDidUpdate=function(a){qm(this.a)};_.componentWillUnmount=function(){fm(this.a)};_.render=function(){return rm(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Vf=Ph(178);rh(257,$wnd.Function,{},ln);_.mb=function(a){return new on(a)};var mn;rh(101,$wnd.React.Component,{},on);qh(oh[1],_);_.componentWillUnmount=function(){Bl(this.a)};_.render=function(){return Km(this.a)};_.shouldComponentUpdate=nq;var Xf=Ph(101);rh(261,$wnd.Function,{},pn);_.kb=function(a){Ll(this.a,a)};rh(262,$wnd.Function,{},qn);_.jb=function(a){Rl(this.a,a)};rh(171,1,{},rn);var Zf=Ph(171);rh(92,1,{},sn);var $f=Ph(92);var tn;rh(273,$wnd.Function,{},un);_.jb=function(a){km(this.a,a)};rh(267,$wnd.Function,{},vn);_.jb=function(a){no(this.a)};rh(269,$wnd.Function,{},wn);_.lb=function(a){om(this.a,this.b)};rh(270,$wnd.Function,{},xn);_.lb=function(a){am(this.a,this.b)};rh(271,$wnd.Function,{},yn);_.w=function(a){bm(this.a,a)};rh(272,$wnd.Function,{},zn);_.ib=function(a){pm(this.a,this.b)};rh(274,$wnd.Function,{},An);_.kb=function(a){cm(this.a,this.b,a)};rh(174,1,{},Cn);var ag=Ph(174);rh(90,1,{},Dn);var bg=Ph(90);var En;rh(256,$wnd.Function,{},Fn);_.jb=function(a){Fm(this.a,a)};rh(102,1,{},Gn);_.S=function(a){return Bn(new Cn,a)};var dg=Ph(102);rh(74,1,{},Hn);var eg=Ph(74);rh(91,1,{},In);var fg=Ph(91);var Jn;rh(88,1,{},Kn);var hg=Ph(88);rh(49,1,{49:1});var Og=Ph(49);rh(156,49,{9:1,49:1},Xn);_.t=hq;_.o=gq;_.q=_p;_.u=iq;_.r=function(){var a;return Lh(pg),pg.k+'@'+(a=jk(this)>>>0,a.toString(16))};var pg=Ph(156);rh(157,1,Fp,Yn);_.v=function(){Rn(this.a)};var ig=Ph(157);rh(159,1,Ip,Zn);_.v=function(){Mn(this.a)};var jg=Ph(159);rh(160,1,Ip,$n);_.v=function(){Nn(this.a)};var kg=Ph(160);rh(161,1,Fp,_n);_.v=function(){Ln(this.a,this.b)};var lg=Ph(161);rh(162,1,Fp,ao);_.v=function(){Un(this.a)};var mg=Ph(162);rh(70,1,Fp,bo);_.v=function(){Qn(this.a)};var ng=Ph(70);rh(158,1,Ap,co);_.s=function(){var a;return a=(Fh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var og=Ph(158);rh(51,1,{51:1});_.d=false;var Yg=Ph(51);rh(52,51,{9:1,275:1,52:1,51:1},oo);_.t=hq;_.o=function(a){return ho(this,a)};_.q=function(){return this.c.d};_.u=iq;_.r=function(){var a;return Lh(Fg),Fg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var eo=0;var Fg=Ph(52);rh(206,1,Fp,po);_.v=function(){fo(this.a)};var qg=Ph(206);rh(207,1,Fp,qo);_.v=function(){ko(this.a)};var rg=Ph(207);rh(48,145,{48:1});var Sg=Ph(48);rh(146,48,{9:1,48:1},zo);_.t=oq;_.o=gq;_.q=_p;_.u=pq;_.r=function(){var a;return Lh(Ag),Ag.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Ag=Ph(146);rh(148,1,Fp,Ao);_.v=function(){so(this.a)};var sg=Ph(148);rh(147,1,Fp,Bo);_.v=function(){wo(this.a)};var tg=Ph(147);rh(153,1,Fp,Co);_.v=function(){cc(this.a,this.b,true)};var ug=Ph(153);rh(154,1,Ap,Do);_.s=function(){return ro(this.a,this.c,this.b)};_.b=false;var vg=Ph(154);rh(149,1,Ap,Eo);_.s=function(){return xo(this.a)};var wg=Ph(149);rh(150,1,Ap,Fo);_.s=function(){return $h(ih(Lj(vo(this.a))))};var xg=Ph(150);rh(151,1,Ap,Go);_.s=function(){return $h(ih(Lj(Mj(vo(this.a),new qp))))};var yg=Ph(151);rh(152,1,Ap,Ho);_.s=function(){return yo(this.a)};var zg=Ph(152);rh(46,1,{46:1});var Xg=Ph(46);rh(129,46,{9:1,46:1},Oo);_.t=function(){ic(this.a)};_.o=gq;_.q=_p;_.u=function(){return this.a.i<0};_.r=function(){var a;return Lh(Eg),Eg.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Eg=Ph(129);rh(130,1,Fp,Po);_.v=function(){Lo(this.a,this.b)};_.b=false;var Bg=Ph(130);rh(131,1,Fp,Qo);_.v=function(){Wn(this.b,this.a)};var Cg=Ph(131);rh(132,1,Fp,Ro);_.v=function(){Mo(this.a)};var Dg=Ph(132);rh(47,1,{47:1});var _g=Ph(47);rh(133,47,{9:1,47:1},Zo);_.t=oq;_.o=gq;_.q=_p;_.u=pq;_.r=function(){var a;return Lh(Lg),Lg.k+'@'+(a=jk(this)>>>0,a.toString(16))};var Lg=Ph(133);rh(134,1,Fp,$o);_.v=function(){Uo(this.a)};var Gg=Ph(134);rh(138,1,Fp,_o);_.v=function(){Yo(this.a,null)};var Hg=Ph(138);rh(135,1,Ap,ap);_.s=function(){var a;return a=Tn(this.a.g),o(Yp,a)?(kp(),hp):o(Zp,a)?(kp(),jp):(kp(),ip)};var Ig=Ph(135);rh(136,1,Ap,bp);_.s=function(){return Wo(this.a)};var Jg=Ph(136);rh(137,1,Ip,cp);_.v=function(){Xo(this.a)};var Kg=Ph(137);rh(127,1,{},dp);_.handleEvent=function(a){On(this.a,a)};var Mg=Ph(127);rh(107,1,{},ep);_.I=function(){return new Xn};var Ng=Ph(107);var fp;rh(32,31,{3:1,29:1,31:1,32:1},lp);var hp,ip,jp;var Pg=Qh(32,mp);rh(105,1,{},np);_.I=function(){return new zo};var Qg=Ph(105);var op;rh(111,1,{},qp);_.gb=function(a){return !jo(a)};var Rg=Ph(111);rh(113,1,{},rp);_.gb=function(a){return jo(a)};var Tg=Ph(113);rh(114,1,{},sp);_.w=function(a){uo(this.a,a)};var Ug=Ph(114);rh(112,1,{},tp);_.w=function(a){Jo(this.a,a)};_.a=false;var Vg=Ph(112);rh(106,1,{},up);_.I=function(){return new Oo(this.a.I())};var Wg=Ph(106);rh(115,1,{},vp);_.gb=function(a){return To(this.a,a)};var Zg=Ph(115);rh(108,1,{},wp);_.I=function(){return new Zo(this.b.I(),this.a.I())};var $g=Ph(108);var rd=Rh('D');var xp=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=mh;kh(xh);nh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();