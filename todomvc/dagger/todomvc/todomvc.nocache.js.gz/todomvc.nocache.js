function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='F87E9BD9D3662729C86175A9F92DC1BC',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "0.0.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'F87E9BD9D3662729C86175A9F92DC1BC';function p(){}
function uh(){}
function qh(){}
function Fb(){}
function Pc(){}
function Wc(){}
function hi(){}
function Cj(){}
function Qj(){}
function Yj(){}
function Zj(){}
function xk(){}
function ll(){}
function lp(){}
function bp(){}
function kp(){}
function op(){}
function Tm(){}
function Xm(){}
function _m(){}
function _n(){}
function dn(){}
function hn(){}
function Dn(){}
function Uc(a){Tc()}
function Hh(){Hh=qh}
function H(a){this.a=a}
function G(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function ec(a){this.a=a}
function nc(a){this.a=a}
function Xh(a){this.a=a}
function gi(a){this.a=a}
function ti(a){this.a=a}
function yi(a){this.a=a}
function zi(a){this.a=a}
function xi(a){this.b=a}
function Mi(a){this.c=a}
function Dj(a){this.a=a}
function _j(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function xl(a){this.a=a}
function El(a){this.a=a}
function Fl(a){this.a=a}
function Gl(a){this.a=a}
function Tl(a){this.a=a}
function Ul(a){this.a=a}
function Vl(a){this.a=a}
function Xl(a){this.a=a}
function sm(a){this.a=a}
function tm(a){this.a=a}
function ym(a){this.a=a}
function Am(a){this.a=a}
function Bm(a){this.a=a}
function Jm(a){this.a=a}
function Km(a){this.a=a}
function Lm(a){this.a=a}
function Mm(a){this.a=a}
function mn(a){this.a=a}
function nn(a){this.a=a}
function rn(a){this.a=a}
function sn(a){this.a=a}
function vn(a){this.a=a}
function Cn(a){this.a=a}
function Vn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function Zn(a){this.a=a}
function $n(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function xo(a){this.a=a}
function yo(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Do(a){this.a=a}
function Eo(a){this.a=a}
function Oo(a){this.a=a}
function Xo(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function mp(a){this.a=a}
function np(a){this.a=a}
function pp(a){this.a=a}
function qp(a){this.a=a}
function _p(){hc(this.c)}
function bq(){hc(this.b)}
function gq(){hc(this.f)}
function Ki(){Bi(this)}
function Y(a){!!a&&$(a)}
function ic(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function Up(a){oj(this,a)}
function Xp(a){_h(this,a)}
function Zp(a){rj(this,a)}
function db(a){Xb((J(),a))}
function eb(a){Yb((J(),a))}
function hb(a){Zb((J(),a))}
function Go(a,b){qm(b,a)}
function pk(a,b){ok(a,b)}
function lc(a,b){pi(a.e,b)}
function $j(a,b){Pj(a.a,b)}
function Zl(a,b){ro(a.j,b)}
function Fo(a,b){qo(a.b,b)}
function qb(a,b){a.b=b}
function Xj(a,b){a.a=b}
function qk(a,b){a.key=b}
function C(a,b){Nb(a.f,b.f)}
function K(a,b){O(a);L(a,b)}
function ah(a){return a.e}
function Yp(){return this.e}
function Sp(){return this.a}
function Wp(){return this.b}
function dq(){kb(this.a.a)}
function Yi(){this.a=fj()}
function kj(){this.a=fj()}
function bj(){bj=qh;aj=dj()}
function J(){J=qh;I=new F}
function vc(){vc=qh;uc=new p}
function Mc(){Mc=qh;Lc=new Pc}
function xh(){xh=qh;wh=new p}
function dp(){dp=qh;cp=new bp}
function yl(a){a.c=2;hc(a.b)}
function ml(a){a.d=2;hc(a.c)}
function cm(a){a.f=2;hc(a.e)}
function qc(a,b){a.e=b;pc(a,b)}
function On(a){R(a.a);$(a.b)}
function Nl(a){kb(a.a);$(a.b)}
function ql(a){kb(a.b);R(a.a)}
function bo(a){$(a.b);$(a.a)}
function Gh(a){tc.call(this,a)}
function Wh(a){tc.call(this,a)}
function ii(a){tc.call(this,a)}
function Tp(){return gk(this)}
function $p(a){return this===a}
function $l(a,b){return a.g=b}
function Ei(a,b){return a.a[b]}
function Xc(a,b){return Qh(a,b)}
function dk(a,b){a.splice(b,1)}
function gc(a,b,c){oi(a.e,b,c)}
function co(a,b,c){gc(a.c,b,c)}
function wj(a,b,c){b.w(a.a[c])}
function ab(a){J();Yb(a);a.e=-2}
function Kh(a){Jh(a);return a.k}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function Cc(){Cc=qh;!!(Tc(),Sc)}
function ai(){oc(this);this.G()}
function Vp(){return ri(this.a)}
function aq(){return this.c.i<0}
function cq(){return this.b.i<0}
function hq(){return this.f.i<0}
function fj(){bj();return new aj}
function Oj(a,b){a.T(b);return a}
function T(a){mb(a.f);return V(a)}
function yh(a){this.a=wh;this.b=a}
function Rm(a){this.a=a;Sm=this}
function pn(a){this.a=a;qn=this}
function rj(a,b){while(a.eb(b));}
function Pj(a,b){Xj(a,Oj(a.a,b))}
function Uj(a,b,c){b.w(a.a.S(c))}
function v(a,b,c){t(a,new H(c),b)}
function Ak(a,b){a.ref=b;return a}
function Qn(a){fb(a.b);return a.e}
function So(a){fb(a.d);return a.e}
function go(a){fb(a.a);return a.d}
function eq(a){return 1==this.a.d}
function fq(a){return 1==this.a.c}
function ri(a){return a.a.b+a.b.b}
function hj(a,b){return a.a.get(b)}
function Tj(a,b){this.a=a;this.b=b}
function Wj(a,b){this.a=a;this.b=b}
function fc(a,b){this.a=a;this.b=b}
function Vh(a,b){this.a=a;this.b=b}
function Ai(a,b){this.a=a;this.b=b}
function yk(a,b){this.a=a;this.b=b}
function Wl(a,b){this.a=a;this.b=b}
function um(a,b){this.a=a;this.b=b}
function vm(a,b){this.a=a;this.b=b}
function wm(a,b){this.a=a;this.b=b}
function xm(a,b){this.a=a;this.b=b}
function zm(a,b){this.a=a;this.b=b}
function tn(a,b){this.a=a;this.b=b}
function un(a,b){this.a=a;this.b=b}
function wn(a,b){this.a=a;this.b=b}
function xn(a,b){this.a=a;this.b=b}
function Db(a){this.d=a;this.b=100}
function Nm(){this.a=rk((Vm(),Um))}
function Qm(){this.a=rk((Zm(),Ym))}
function on(){this.a=rk((bn(),an))}
function zn(){this.a=rk((fn(),en))}
function En(){this.a=rk((kn(),jn))}
function Rn(a){Pn(a,(fb(a.b),a.e))}
function hl(a,b){Vh.call(this,a,b)}
function ip(a,b){Vh.call(this,a,b)}
function Yn(a,b){this.a=a;this.b=b}
function zo(a,b){this.a=a;this.b=b}
function Mo(a,b){this.a=a;this.b=b}
function No(a,b){this.b=a;this.a=b}
function Bk(a,b){a.href=b;return a}
function Kk(a,b){a.value=b;return a}
function ei(a,b){a.a+=''+b;return a}
function bk(a,b,c){a.splice(b,0,c)}
function jh(){hh==null&&(hh=[])}
function Kc(){zc!=0&&(zc=0);Bc=-1}
function ld(a){return typeof a===tp}
function od(a){return a==null?null:a}
function qj(a){return a!=null?s(a):0}
function ni(a){return !a?null:a.ab()}
function Tb(a){return !a.d?a:Tb(a.d)}
function o(a,b){return od(a)===od(b)}
function ho(a){qm(a,(fb(a.a),!a.d))}
function gm(a){kb(a.b);R(a.c);$(a.a)}
function Jc(a){$wnd.clearTimeout(a)}
function Bi(a){a.a=Zc(ie,up,1,0,5,1)}
function qi(a){a.a=new Yi;a.b=new kj}
function ib(a){this.c=new Ki;this.b=a}
function kk(){kk=qh;hk=new p;jk=new p}
function Ek(a,b){a.checked=b;return a}
function Fk(a,b){a.onBlur=b;return a}
function Ck(a,b){a.onClick=b;return a}
function Gk(a,b){a.onChange=b;return a}
function ck(a,b){ak(b,0,a,0,b.length)}
function dc(a,b){bc(a,b,false);eb(a.c)}
function ok(a,b){for(var c in a){b(c)}}
function bd(a,b,c){return {l:a,m:b,h:c}}
function B(a,b,c){return u(a,c,2048,b)}
function bi(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function gk(a){return a.$H||(a.$H=++fk)}
function nd(a){return typeof a==='string'}
function Hk(a,b){a.onKeyDown=b;return a}
function Dk(a){a.autoFocus=true;return a}
function Jh(a){if(a.k!=null){return}Sh(a)}
function pb(a){J();ob(a);sb(a,2,true)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function $i(a,b){var c;c=a[Gp];c.call(a,b)}
function cc(a,b){lc(b.c,a);jd(b,9)&&b.t()}
function oj(a,b){while(a.Y()){$j(b,a.Z())}}
function An(a,b){this.a=a;this.b=b;Bn=this}
function tc(a){this.g=a;oc(this);this.G()}
function Nj(a,b){Gj.call(this,a);this.a=b}
function A(a,b,c){u(a,new G(b),c,null)}
function nm(a){A((J(),J(),I),new Am(a),Lp)}
function Sn(a){A((J(),J(),I),new Zn(a),Lp)}
function ko(a){A((J(),J(),I),new no(a),Lp)}
function Ho(a){A((J(),J(),I),new Oo(a),Lp)}
function Ro(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function vo(a){return Yh(S(a.e).a-S(a.a).a)}
function kd(a){return typeof a==='boolean'}
function Dc(a,b,c){return a.apply(b,c);var d}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function nj(a,b,c){this.a=a;this.b=b;this.c=c}
function Si(){this.a=new Yi;this.b=new kj}
function P(){this.a=Zc(ie,up,1,100,5,1)}
function $h(){$h=qh;Zh=Zc(ee,up,29,256,0,1)}
function Nh(a){var b;b=Mh(a);Uh(a,b);return b}
function oc(a){a.j&&a.e!==Bp&&a.G();return a}
function Lk(a,b){a.onDoubleClick=b;return a}
function Ci(a,b){a.a[a.a.length]=b;return true}
function Eh(a,b,c,d){a.addEventListener(b,c,d)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function Ol(a,b){A((J(),J(),I),new Wl(a,b),Lp)}
function hm(a,b){A((J(),J(),I),new zm(a,b),Lp)}
function lm(a,b){A((J(),J(),I),new wm(a,b),Lp)}
function mm(a,b){A((J(),J(),I),new vm(a,b),Lp)}
function pm(a,b){A((J(),J(),I),new um(a,b),Lp)}
function ro(a,b){A((J(),J(),I),new zo(a,b),Lp)}
function Ko(a,b){A((J(),J(),I),new Mo(a,b),Lp)}
function uj(a,b){while(a.c<a.d){wj(a,b,a.c++)}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function Bh(a){if(!a){throw ah(new ai)}return a}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function yj(a){if(!a.d){a.d=a.b.R();a.c=a.b.U()}}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Pl(a,b){var c;c=b.target;Rl(a,c.value)}
function Hj(a,b){var c;return Lj(a,(c=new Ki,c))}
function Tc(){Tc=qh;var a;!Vc();a=new Wc;Sc=a}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function Ao(a,b){this.a=a;this.c=b;this.b=false}
function Rj(a,b,c){if(a.a.gb(c)){a.b=true;b.w(c)}}
function gj(a,b){return !(a.a.get(b)===undefined)}
function Po(a){return o(Qp,a)||o(Rp,a)||o('',a)}
function uo(a){return Hh(),0!=S(a.e).a?true:false}
function Oi(a){return new Nj(null,Ni(a,a.length))}
function _c(a){return Array.isArray(a)&&a.pb===uh}
function hd(a){return !Array.isArray(a)&&a.pb===uh}
function Ni(a,b){return sj(b,a.length),new xj(a,b)}
function Qc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Gi(a,b){var c;c=a.a[b];dk(a.a,b);return c}
function vi(a){var b;b=a.a.Z();a.b=ui(a);return b}
function Ph(a){var b;b=Mh(a);b.j=a;b.e=1;return b}
function po(a){R(a.d);R(a.e);R(a.a);R(a.b);$(a.c)}
function to(a){_h(new yi(a.g),new ec(a));qi(a.g)}
function sl(a){return B((J(),J(),I),a.b,new xl(a))}
function Cl(a){return B((J(),J(),I),a.a,new Gl(a))}
function Ql(a){return B((J(),J(),I),a.a,new Ul(a))}
function Hm(a){return B((J(),J(),I),a.a,new Lm(a))}
function om(a){return B((J(),J(),I),a.b,new tm(a))}
function rl(a){return Hh(),S(a.e.b).a>0?true:false}
function si(a,b){if(b){return li(a.a,b)}return false}
function Ii(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Cm(a,b){var c;c=b.target;Ko(a.e,c.checked)}
function Rl(a,b){var c;c=a.f;if(b!=c){a.f=b;eb(a.b)}}
function qm(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function nl(a){if(0==a.d){a.d=1;a.n.forceUpdate()}}
function zl(a){if(0==a.c){a.c=1;a.n.forceUpdate()}}
function dm(a){if(0==a.f){a.f=1;a.n.forceUpdate()}}
function Ej(a){if(!a.b){Fj(a);a.c=true}else{Ej(a.b)}}
function Jj(a,b){Fj(a);return new Nj(a,new Sj(b,a.a))}
function Kj(a,b){Fj(a);return new Nj(a,new Vj(b,a.a))}
function Pn(a,b){A((J(),J(),I),new Yn(a,b),75497472)}
function Tn(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function Fh(a,b,c,d){a.removeEventListener(b,c,d)}
function Fn(a,b,c){this.a=a;this.b=b;this.c=c;Gn=this}
function Om(a,b,c){this.a=a;this.b=b;this.c=c;Pm=this}
function xj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function tj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Ri(a,b){return od(a)===od(b)||a!=null&&q(a,b)}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Nn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&Tn(a,b)}
function Oh(a,b){var c;c=Mh(a);Uh(a,c);c.e=b?8:0;return c}
function Jk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Dh(){Dh=qh;Ch=$wnd.goog.global.document}
function nk(){if(ik==256){hk=jk;jk=new p;ik=0}++ik}
function Gj(a){if(!a){this.b=null;new Ki}else{this.b=a}}
function Rh(a){if(a.P()){return null}var b=a.j;return mh[b]}
function gh(a){if(ld(a)){return a|0}return a.l|a.m<<22}
function Io(a,b){Hj(so(a.b),new Dj(new Cj)).Q(new np(b))}
function im(a,b){Vo(a.k,b);A((J(),J(),I),new um(a,b),Lp)}
function jm(a,b){A((J(),J(),I),new um(a,b),Lp);Vo(a.k,null)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&zp)&&D((null,I))}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function zj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function mi(a,b){return b===a?'(this Map)':b==null?Dp:th(b)}
function rc(a,b){var c;c=Kh(a.nb);return b==null?c:c+': '+b}
function Yl(a,b){var c;if(S(a.c)){c=b.target;qm(a,c.value)}}
function _h(a,b){var c,d;for(d=a.R();d.Y();){c=d.Z();b.w(c)}}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function jp(){hp();return ad(Xc(Og,1),up,31,0,[ep,gp,fp])}
function Vm(){Vm=qh;var a;Um=(a=rh(Tm.prototype.mb,Tm,[]),a)}
function Zm(){Zm=qh;var a;Ym=(a=rh(Xm.prototype.mb,Xm,[]),a)}
function bn(){bn=qh;var a;an=(a=rh(_m.prototype.mb,_m,[]),a)}
function fn(){fn=qh;var a;en=(a=rh(dn.prototype.mb,dn,[]),a)}
function kn(){kn=qh;var a;jn=(a=rh(hn.prototype.mb,hn,[]),a)}
function sh(a){function b(){}
;b.prototype=a||{};return new b}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function Ik(a){a.placeholder='What needs to be done?';return a}
function Ic(a){Cc();$wnd.setTimeout(function(){throw a},0)}
function Jn(a){Eh((Dh(),$wnd.goog.global.window),Op,a.d,false)}
function Kn(a){Fh((Dh(),$wnd.goog.global.window),Op,a.d,false)}
function km(a){return Hh(),So(a.k)==a.n.props['a']?true:false}
function Vi(a,b){var c;return Ti(b,Ui(a,b==null?0:(c=s(b),c|0)))}
function Ui(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Qh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.K(b))}
function oh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function wk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Gc(a,b,c){var d;d=Ec();try{return Dc(a,b,c)}finally{Hc(d)}}
function zh(a){xh();Bh(a);if(jd(a,44)){return a}return new yh(a)}
function vj(a,b){if(a.c<a.d){wj(a,b,a.c++);return true}return false}
function kc(a){ic(a.g);!!a.e&&jc(a);Y(a.a);Y(a.c);ic(a.b);ic(a.f)}
function so(a){fb(a.c);return new Nj(null,new zj(new yi(a.g),0))}
function Jo(a){Hj(Jj(so(a.b),new lp),new Dj(new Cj)).Q(new mp(a.b))}
function Lo(a){this.b=a;J();this.a=new mc(0,null,null,false,false)}
function Li(a){Bi(this);ck(this.a,ki(a,Zc(ie,up,1,ri(a.a),5,1)))}
function Zi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Vj(a,b){tj.call(this,b.db(),b.cb()&-6);this.a=a;this.b=b}
function Sj(a,b){tj.call(this,b.db(),b.cb()&-16449);this.a=a;this.c=b}
function lj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Aj(a,b){!a.a?(a.a=new gi(a.d)):ei(a.a,a.b);ei(a.a,b);return a}
function Lj(a,b){var c;Ej(a);c=new Yj;c.a=b;a.a.X(new _j(c));return c.a}
function Ij(a){var b;Ej(a);b=0;while(a.a.eb(new Zj)){b=bh(b,1)}return b}
function sc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Fc(b){Cc();return function(){return Gc(b,this,arguments);var a}}
function yc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function qo(a,b){var c;return u((J(),J(),I),new Ao(a,b),Lp,(c=null,c))}
function Ln(a,b){b.preventDefault();A((J(),J(),I),new $n(a),Lp)}
function bb(a,b){var c,d;Ci(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function pi(a,b){return nd(b)?b==null?Xi(a.a,null):jj(a.b,b):Xi(a.a,b)}
function Qo(a,b){return (hp(),fp)==a||(ep==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function pd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Hc(a){a&&Oc((Mc(),Lc));--zc;if(a){if(Bc!=-1){Jc(Bc);Bc=-1}}}
function Hl(a){var b;b=di((fb(a.b),a.f));if(b.length>0){Fo(a.e,b);Rl(a,'')}}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Di(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Mj(a,b){var c;c=Hj(a,new Dj(new Cj));return Ji(c,b.fb(c.a.length))}
function wi(a){this.d=a;this.c=new lj(this.d.b);this.a=this.c;this.b=ui(this)}
function Bj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function $m(a){$wnd.React.Component.call(this,a);this.a=new Dl(this,Sm.a)}
function cn(a){$wnd.React.Component.call(this,a);this.a=new Sl(this,qn.a)}
function gn(a){$wnd.React.Component.call(this,a);this.a=new rm(this,Bn.a,Bn.b)}
function Hn(){this.a=zh(new op);this.b=zh((dp(),cp));this.c=zh(new qp(this.b))}
function To(a){var b;return b=S(a.b),Hj(Jj(so(a.i),new pp(b)),new Dj(new Cj))}
function In(a,b){a.f=b;o(b,S(a.a))&&Tn(a,b);Mn(b);A((J(),J(),I),new $n(a),Lp)}
function Ib(b){try{mb(b.b.a)}catch(a){a=_g(a);if(!jd(a,4))throw ah(a)}}
function oi(a,b,c){return nd(b)?b==null?Wi(a.a,null,c):ij(a.b,b,c):Wi(a.a,b,c)}
function ek(a,b){return Yc(b)!=10&&ad(r(b),b.ob,b.__elementTypeId$,Yc(b),a),a}
function eo(a,b){var c;if(jd(b,50)){c=b;return a.c.d==c.c.d}else{return false}}
function Hi(a,b){var c;c=Fi(a,b,0);if(c==-1){return false}dk(a.a,c);return true}
function Zc(a,b,c,d,e,f){var g;g=$c(e,d);e!=10&&ad(Xc(a,f),b,c,e,g);return g}
function Fi(a,b,c){for(;c<a.a.length;++c){if(Ri(b,a.a[c])){return c}}return -1}
function mj(a){if(a.a.c!=a.c){return hj(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function hc(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new nc(a)),67108864,null)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function Nc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Rc(b,c)}while(a.a);a.a=c}}
function Oc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Rc(b,c)}while(a.b);a.b=c}}
function Ob(){var a;this.a=Zc(ud,up,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function uk(a){var b;return sk($wnd.React.StrictMode,null,null,(b={},b[Hp]=a,b))}
function Yc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function md(a){return a!=null&&(typeof a===sp||typeof a==='function')&&!(a.pb===uh)}
function Wm(a){$wnd.React.Component.call(this,a);this.a=new tl(this,Pm.a,Pm.b,Pm.c)}
function ln(a){$wnd.React.Component.call(this,a);this.a=new Im(this,Gn.a,Gn.b,Gn.c)}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ki);Ci(a.b,b)}}}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new Ki);a.c=c.c}b.d=true;Ci(a.c,b)}
function Uh(a,b){var c;if(!a){return}b.j=a;var d=Rh(b);if(!d){mh[a]=[b];return}d.nb=b}
function rh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function sk(a,b,c,d){var e;e=tk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function Mh(a){var b;b=new Lh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function rk(a){var b;b=tk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Pi(a){var b,c,d;d=0;for(c=new wi(a.a);c.b;){b=vi(c);d=d+(b?s(b):0);d=d|0}return d}
function jj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{$i(a.a,b);--a.b}return c}
function V(a){if(a.b){if(jd(a.b,7)){throw ah(a.b)}else{throw ah(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=_g(a);if(jd(a,4)){J()}else throw ah(a)}}}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function Il(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Vl(a),Lp)}}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Ap:0)|(0!=(b&229376)?0:98304)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:wp)|(0==(c&6291456)?!a?zp:Ap:0)|0|0|0)}
function ob(a){var b,c;for(c=new Mi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function ji(a,b){var c,d;for(d=new wi(b.a);d.b;){c=vi(d);if(!si(a,c)){return false}}return true}
function oo(a,b,c){var d;d=new lo(b,c);co(d,a,new fc(a,d));oi(a.g,Yh(d.c.d),d);eb(a.c);return d}
function bc(a,b,c){var d;d=pi(a.g,b?Yh(b.c.d):null);if(null!=d){lc(b.c,a);c&&!!b&&hc(b.c);eb(a.c)}}
function Uo(a){var b;b=S(a.g.a);o(Qp,b)||o(Rp,b)||o('',b)?Pn(a.g,b):Po(Qn(a.g))?Sn(a.g):Pn(a.g,'')}
function yn(a,b){qk(a.a,(Jh(bg),bg.k+(''+(b?Yh(b.c.d):null))));a.a.props['a']=b;return a.a}
function ui(a){if(a.a.Y()){return true}if(a.a!=a.c){return false}a.a=new Zi(a.d.a);return a.a.Y()}
function _g(a){var b;if(jd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new xc(a);Uc(b)}return b}
function dh(a){var b;b=a.h;if(b==0){return a.l+a.m*Ap}if(b==1048575){return a.l+a.m*Ap-Ep}return a}
function fh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Ep;d=1048575}c=pd(e/Ap);b=pd(e-c*Ap);return bd(b,c,d)}
function Ti(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ri(a,c._())){return c}}return null}
function ih(){jh();var a=hh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function sj(a,b){if(0>a||a>b){throw ah(new Gh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function lh(a,b){typeof window===sp&&typeof window['$gwt']===sp&&(window['$gwt'][a]=b)}
function hp(){hp=qh;ep=new ip('ACTIVE',0);gp=new ip('COMPLETED',1);fp=new ip('ALL',2)}
function _l(a,b,c){27==c.which?A((J(),J(),I),new xm(a,b),Lp):13==c.which&&A((J(),J(),I),new vm(a,b),Lp)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function kl(){if(!jl){jl=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(rh(ll.prototype.J,ll,[]))}}
function xc(a){vc();oc(this);this.e=a;pc(this,a);this.g=a==null?Dp:th(a);this.a='';this.b=a;this.a=''}
function Lh(){this.g=Ih++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function ij(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function ad(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=uh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Vo(a,b){var c;c=a.e;if(!(b==c||!!b&&eo(b,c))){!!c&&lc(c.c,a);a.e=b;!!b&&co(b,a,new Yo(a));eb(a.d)}}
function cb(a,b){var c,d;d=a.c;Hi(d,b);!!a.b&&wp!=(a.b.c&xp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function cd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return bd(c&4194303,d&4194303,e&1048575)}
function r(a){return nd(a)?le:ld(a)?_d:kd(a)?Zd:hd(a)?a.nb:_c(a)?a.nb:a.nb||Array.isArray(a)&&Xc(Qd,1)||Qd}
function s(a){return nd(a)?mk(a):ld(a)?pd(a):kd(a)?a?1231:1237:hd(a)?a.q():_c(a)?gk(a):!!a&&!!a.hashCode?a.hashCode():gk(a)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&wp)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function bm(a){var b;b=S(a.c);if(!a.i&&b){a.i=true;pm(a,a.n.props['a']);a.g.focus();a.g.select()}else a.i&&!b&&(a.i=false)}
function Yh(a){var b,c;if(a>-129&&a<128){b=a+128;c=($h(),Zh)[b];!c&&(c=Zh[b]=new Xh(a));return c}return new Xh(a)}
function th(a){var b;if(Array.isArray(a)&&a.pb===uh){return Kh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function mk(a){kk();var b,c,d;c=':'+a;d=jk[c];if(d!=null){return pd(d)}d=hk[c];b=d==null?lk(a):pd(d);nk();jk[c]=b;return b}
function Qi(a){var b,c,d;d=1;for(c=new Mi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=Gi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function am(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new No(b,c),Lp);Vo(a.k,null);qm(a,c)}else{ro(a.j,b)}}
function bh(a,b){var c;if(ld(a)&&ld(b)){c=a+b;if(-17592186044416<c&&c<Ep){return c}}return dh(cd(ld(a)?fh(a):a,ld(b)?fh(b):b))}
function il(){gl();return ad(Xc(cf,1),up,6,0,[Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl])}
function Fj(a){if(a.b){Fj(a.b)}else if(a.c){throw ah(new Wh("Stream already terminated, can't be modified or used"))}}
function gd(a,b){if(nd(a)){return !!fd[b]}else if(a.ob){return !!a.ob[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(wp==(b&xp)?0:524288)|(0==(b&6291456)?wp==(b&xp)?Ap:zp:0)|0|268435456|0)}
function Th(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ji(a,b){var c,d;d=a.a.length;b.length<d&&(b=ek(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Ec(){var a;if(zc!=0){a=yc();if(a-Ac>2000){Ac=a;Bc=$wnd.setTimeout(Kc,10)}}if(zc++==0){Nc((Mc(),Lc));return true}return false}
function Vc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Dl(a,b){var c;this.d=b;this.n=a;J();c=++Bl;this.b=new mc(c,null,new El(this),false,false);this.a=new vb(null,new Fl(this),Kp)}
function mc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Si:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function jc(a){var b,c,d;for(c=new Mi(new Li(new ti(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b._();jd(d,9)&&d.u()||b.ab().v()}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Mi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Mi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Mi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function q(a,b){return nd(a)?o(a,b):ld(a)?od(a)===od(b):kd(a)?od(a)===od(b):hd(a)?a.o(b):_c(a)?o(a,b):!!a&&!!a.equals?a.equals(b):od(a)===od(b)}
function zk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function di(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ki(a,b){var c,d,e,f;f=ri(a.a);b.length<f&&(b=ek(new Array(f),b));e=b;d=new wi(a.a);for(c=0;c<f;++c){e[c]=vi(d)}b.length>f&&(b[f]=null);return b}
function $c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=_g(a);if(jd(a,4)){e=a;throw ah(e)}else throw ah(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=_g(a);if(jd(a,4)){f=a;throw ah(f)}else throw ah(a)}finally{D(b)}}
function Im(a,b,c,d){var e;this.d=b;this.e=c;this.f=d;this.n=a;J();e=++Gm;this.b=new mc(e,null,new Jm(this),false,false);this.a=new vb(null,new Km(this),Kp)}
function Sl(a,b){var c,d,e;this.e=b;this.n=a;J();c=++Ml;this.c=new mc(c,null,new Tl(this),false,false);this.b=(e=new ib((d=null,d)),e);this.a=new vb(null,new Xl(this),Kp)}
function lo(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++ao;this.c=new mc(c,null,new mo(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function kh(b,c,d,e){jh();var f=hh;$moduleName=c;$moduleBase=d;$g=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{rp(g)()}catch(a){b(c,a)}}else{rp(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);wp==(d&xp)&&lb(this.f)}
function tk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function dj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return ej()}}
function Al(a){var b,c,d;a.c=0;kl();b=(c=S(a.d.e).a,d='item'+(c==1?'':'s'),vk('span',zk(new $wnd.Object,ad(Xc(le,1),up,2,6,['todo-count'])),[vk('strong',null,[c]),' '+d+' left']));return b}
function nh(){mh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Rc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Qc(c,g)):g[0].qb()}catch(a){a=_g(a);if(jd(a,4)){d=a;Cc();Ic(jd(d,35)?d.H():d)}else throw ah(a)}}return c}
function Ll(a){var b;a.d=0;kl();b=vk(Mp,Dk(Gk(Hk(Kk(Ik(zk(new $wnd.Object,ad(Xc(le,1),up,2,6,['new-todo']))),(fb(a.b),a.f)),rh(mn.prototype.kb,mn,[a])),rh(nn.prototype.jb,nn,[a]))),null);return b}
function wc(a){var b;if(a.c==null){b=od(a.b)===od(uc)?null:a.b;a.d=b==null?Dp:md(b)?b==null?null:b.name:nd(b)?'String':Kh(r(b));a.a=a.a+': '+(md(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(od(e)===od(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=_g(a);if(jd(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw ah(c)}else throw ah(a)}}
function ak(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Wi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ti(b,e);if(f){return f.bb(c)}}e[e.length]=new Ai(b,c);++a.b;return null}
function tl(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.n=a;J();e=++pl;this.c=new mc(e,null,new ul(this),false,false);this.a=new W(new vl(this),null,null,136478720);this.b=new vb(null,new wl(this),Kp)}
function lk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+bi(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=_g(a);if(jd(a,4)){J()}else throw ah(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Zc(ie,up,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Ah(a,b){var c;c=od(a)!==od(wh);if(c&&od(a)!==od(b)){throw ah(new Wh('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}return b}
function ub(a,b,c,d){this.b=new Ki;this.f=new Jb(new yb(this),d&6520832|262144|wp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&zp)&&D((null,I)))}
function vh(){var a;a=new Hn;new Om(new wo,a.a.I(),a.c.I());new An(new wo,(a.a.I(),a.c.I()));new Fn(new wo,a.a.I(),a.c.I());new pn(a.a.I());new Rm(new wo);$wnd.ReactDOM.render(uk([(new En).a]),(Dh(),Ch).getElementById('app'),null)}
function Xi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ri(b,e._())){if(d.length==1){d.length=0;$i(a.a,g)}else{d.splice(h,1)}--a.b;return e.ab()}}return null}
function ph(a,b,c){var d=mh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=mh[b]),sh(h));_.ob=c;!b&&(_.pb=uh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function Sh(a){if(a.O()){var b=a.c;b.P()?(a.k='['+b.j):!b.O()?(a.k='[L'+b.M()+';'):(a.k='['+b.M());a.b=b.L()+'[]';a.i=b.N()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Th('.',[c,Th('$',d)]);a.b=Th('.',[c,Th('.',d)]);a.i=d[d.length-1]}
function Mn(a){var b;if(0==a.length){b=(Dh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Ch.title,b)}else{(Dh(),$wnd.goog.global.window).location.hash=a}}
function li(a,b){var c,d,e;c=b._();e=b.ab();d=nd(c)?c==null?ni(Vi(a.a,null)):hj(a.b,c):ni(Vi(a.a,c));if(!(od(e)===od(d)||e!=null&&q(e,d))){return false}if(d==null&&!(nd(c)?c==null?!!Vi(a.a,null):gj(a.b,c):!!Vi(a.a,c))){return false}return true}
function vk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;pk(b,rh(yk.prototype.hb,yk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Hp]=c[0],undefined):(d[Hp]=c,undefined));return sk(a,e,f,d)}
function rm(a,b,c){var d,e,f;this.j=b;this.k=c;this.n=a;J();d=++fm;this.e=new mc(d,null,new sm(this),false,false);this.a=(f=new ib((e=null,e)),f);this.c=new W(new ym(this),null,null,136478720);this.b=new vb(null,new Bm(this),Kp);pm(this,this.n.props['a'])}
function Wo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new mc(0,null,new Xo(this),false,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new Zo(this),null,null,Pp);this.c=new W(new $o(this),null,null,Pp);this.a=new vb(new _o(this),null,681574400);D((null,I))}
function wo(){var a;this.g=new Si;J();this.f=new mc(0,new yo(this),new xo(this),false,false);this.c=(a=new ib(null),a);this.d=new W(new Bo(this),null,null,Pp);this.e=new W(new Co(this),null,null,Pp);this.a=new W(new Do(this),null,null,Pp);this.b=new W(new Eo(this),null,null,Pp)}
function Un(){var a,b,c;this.d=new ap(this);this.f=this.e=(c=(Dh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new mc(0,null,new Vn(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new _n,new Wn(this),new Xn(this),35651584)}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Mi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=_g(a);if(!jd(a,4))throw ah(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function pc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function cj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}Di(a.b,new Ab(a));a.b.a=Zc(ie,up,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Fm(a){var b;a.c=0;kl();b=vk('div',null,[vk('div',null,[vk(Np,zk(new $wnd.Object,ad(Xc(le,1),up,2,6,[Np])),[vk('h1',null,['todos']),(new on).a]),S(a.d.d)?vk('section',zk(new $wnd.Object,ad(Xc(le,1),up,2,6,[Np])),[vk(Mp,Gk(Jk(zk(new $wnd.Object,ad(Xc(le,1),up,2,6,['toggle-all'])),(gl(),Nk)),rh(Cn.prototype.jb,Cn,[a])),null),vk('ul',zk(new $wnd.Object,ad(Xc(le,1),up,2,6,['todo-list'])),Mj(Kj(S(a.f.c).W(),new Dn),new xk))]):null,S(a.d.d)?(new Nm).a:null])]);return b}
function gl(){gl=qh;Mk=new hl(Ip,0);Nk=new hl('checkbox',1);Ok=new hl('color',2);Pk=new hl('date',3);Qk=new hl('datetime',4);Rk=new hl('email',5);Sk=new hl('file',6);Tk=new hl('hidden',7);Uk=new hl('image',8);Vk=new hl('month',9);Wk=new hl(tp,10);Xk=new hl('password',11);Yk=new hl('radio',12);Zk=new hl('range',13);$k=new hl('reset',14);_k=new hl('search',15);al=new hl('submit',16);bl=new hl('tel',17);cl=new hl('text',18);dl=new hl('time',19);el=new hl('url',20);fl=new hl('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ei(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ii(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ei(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Gi(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Ki)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&wp!=(k.b.c&xp)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function ol(a){var b,c;a.d=0;kl();c=(b=S(a.g.b),vk('footer',zk(new $wnd.Object,ad(Xc(le,1),up,2,6,['footer'])),[(new Qm).a,vk('ul',zk(new $wnd.Object,ad(Xc(le,1),up,2,6,['filters'])),[vk('li',null,[vk('a',Bk(zk(new $wnd.Object,ad(Xc(le,1),up,2,6,[(hp(),fp)==b?Jp:null])),'#'),['All'])]),vk('li',null,[vk('a',Bk(zk(new $wnd.Object,ad(Xc(le,1),up,2,6,[ep==b?Jp:null])),'#active'),['Active'])]),vk('li',null,[vk('a',Bk(zk(new $wnd.Object,ad(Xc(le,1),up,2,6,[gp==b?Jp:null])),'#completed'),['Completed'])])]),S(a.a)?vk(Ip,Ck(zk(new $wnd.Object,ad(Xc(le,1),up,2,6,['clear-completed'])),rh(Mm.prototype.lb,Mm,[a])),['Clear Completed']):null]));return c}
function em(a){var b,c,d,e;a.f=0;kl();b=a.n.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.n.props['a'],e=(fb(d.a),d.d),vk('li',zk(new $wnd.Object,ad(Xc(le,1),up,2,6,[e?'checked':null,S(a.c)?'editing':null])),[vk('div',zk(new $wnd.Object,ad(Xc(le,1),up,2,6,['view'])),[vk(Mp,Gk(Ek(Jk(zk(new $wnd.Object,ad(Xc(le,1),up,2,6,['toggle'])),(gl(),Nk)),e),rh(sn.prototype.jb,sn,[d])),null),vk('label',Lk(new $wnd.Object,rh(tn.prototype.lb,tn,[a,d])),[(fb(d.b),d.e)]),vk(Ip,Ck(zk(new $wnd.Object,ad(Xc(le,1),up,2,6,['destroy'])),rh(un.prototype.lb,un,[a,d])),null)]),vk(Mp,Hk(Gk(Fk(Kk(zk(Ak(new $wnd.Object,rh(vn.prototype.w,vn,[a])),ad(Xc(le,1),up,2,6,['edit'])),(fb(a.a),a.d)),rh(wn.prototype.ib,wn,[a,d])),rh(rn.prototype.jb,rn,[a])),rh(xn.prototype.kb,xn,[a,d])),null)]));return c}
function ej(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Gp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!cj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Gp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var sp='object',tp='number',up={3:1},vp={9:1},wp=1048576,xp=1835008,yp={5:1},zp=2097152,Ap=4194304,Bp='__noinit__',Cp={3:1,10:1,7:1,4:1},Dp='null',Ep=17592186044416,Fp={41:1},Gp='delete',Hp='children',Ip='button',Jp='selected',Kp=1411518464,Lp=142606336,Mp='input',Np='header',Op='hashchange',Pp=136314880,Qp='active',Rp='completed';var _,mh,hh,$g=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;nh();ph(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.nb};_.q=Tp;_.r=function(){var a;return Kh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var dd,ed,fd;ph(55,1,{},Lh);_.K=function(a){var b;b=new Lh;b.e=4;a>1?(b.c=Qh(this,a-1)):(b.c=this);return b};_.L=function(){Jh(this);return this.b};_.M=function(){return Kh(this)};_.N=function(){Jh(this);return this.i};_.O=function(){return (this.e&4)!=0};_.P=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Jh(this),this.k)};_.e=0;_.g=0;var Ih=1;var ie=Nh(1);var $d=Nh(55);ph(83,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var td=Nh(83);ph(36,1,{},G);_.s=function(){return this.a.v(),null};var rd=Nh(36);ph(84,1,{},H);var sd=Nh(84);var I;ph(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var ud=Nh(43);ph(231,1,vp);_.r=function(){var a;return Kh(this.nb)+'@'+(a=s(this)>>>0,a.toString(16))};var xd=Nh(231);ph(18,231,vp,W);_.t=function(){R(this)};_.u=Sp;_.a=false;_.d=0;_.k=false;var wd=Nh(18);ph(126,1,{},X);_.s=function(){return T(this.a)};var vd=Nh(126);ph(16,231,{9:1,16:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=Nh(16);ph(125,1,yp,jb);_.v=function(){ab(this.a)};var yd=Nh(125);ph(17,231,{9:1,17:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Ed=Nh(17);ph(138,1,{},xb);_.v=function(){Q(this.a)};var Ad=Nh(138);ph(139,1,yp,yb);_.v=function(){mb(this.a)};var Bd=Nh(139);ph(140,1,yp,zb);_.v=function(){pb(this.a)};var Cd=Nh(140);ph(141,1,{},Ab);_.w=function(a){nb(this.a,a)};var Dd=Nh(141);ph(102,1,{},Db);_.a=0;_.b=0;_.c=0;var Fd=Nh(102);ph(167,1,vp,Fb);_.t=function(){Eb(this)};_.u=Sp;_.a=false;var Gd=Nh(167);ph(67,231,{9:1,67:1},Jb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Id=Nh(67);ph(101,1,{},Ob);var Hd=Nh(101);ph(142,1,{},$b);_.r=function(){var a;return Jh(Jd),Jd.k+'@'+(a=gk(this)>>>0,a.toString(16))};_.a=0;var Pb;var Jd=Nh(142);ph(114,1,{});var Md=Nh(114);ph(107,1,{},ec);_.w=function(a){cc(this.a,a)};var Kd=Nh(107);ph(108,1,yp,fc);_.v=function(){dc(this.a,this.b)};var Ld=Nh(108);ph(15,1,vp,mc);_.t=function(){hc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return Jh(Od),Od.k+'@'+(a=gk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Od=Nh(15);ph(124,1,yp,nc);_.v=function(){kc(this.a)};var Nd=Nh(124);ph(4,1,{3:1,4:1});_.A=function(a){return new Error(a)};_.B=Yp;_.C=function(){return Mj(Kj(Oi((this.i==null&&(this.i=Zc(ne,up,4,0,0,1)),this.i)),new hi),new Qj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){qc(this,sc(this.A(rc(this,this.g))));Uc(this)};_.r=function(){return rc(this,this.F())};_.e=Bp;_.j=true;var ne=Nh(4);ph(10,4,{3:1,10:1,4:1});var be=Nh(10);ph(7,10,Cp);var je=Nh(7);ph(56,7,Cp);var fe=Nh(56);ph(78,56,Cp);var Sd=Nh(78);ph(35,78,{35:1,3:1,10:1,7:1,4:1},xc);_.F=function(){wc(this);return this.c};_.H=function(){return od(this.b)===od(uc)?null:this.b};var uc;var Pd=Nh(35);var Qd=Nh(0);ph(214,1,{});var Rd=Nh(214);var zc=0,Ac=0,Bc=-1;ph(92,214,{},Pc);var Lc;var Td=Nh(92);var Sc;ph(225,1,{});var Vd=Nh(225);ph(79,225,{},Wc);var Ud=Nh(79);ph(44,1,{44:1},yh);_.I=function(){var a;a=this.a;if(od(a)===od(wh)){a=this.a;if(od(a)===od(wh)){a=this.b.I();this.a=Ah(this.a,a);this.b=null}}return a};var wh;var Wd=Nh(44);var Ch;ph(76,1,{73:1});_.r=Sp;var Xd=Nh(76);ph(80,7,Cp);var de=Nh(80);ph(143,80,Cp,Gh);var Yd=Nh(143);dd={3:1,74:1,28:1};var Zd=Nh(74);ph(42,1,{3:1,42:1});var he=Nh(42);ed={3:1,28:1,42:1};var _d=Nh(224);ph(30,1,{3:1,28:1,30:1});_.o=$p;_.q=Tp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ae=Nh(30);ph(58,7,Cp,Wh);var ce=Nh(58);ph(29,42,{3:1,28:1,29:1,42:1},Xh);_.o=function(a){return jd(a,29)&&a.a==this.a};_.q=Sp;_.r=function(){return ''+this.a};_.a=0;var ee=Nh(29);var Zh;ph(289,1,{});ph(81,56,Cp,ai);_.A=function(a){return new TypeError(a)};var ge=Nh(81);fd={3:1,73:1,28:1,2:1};var le=Nh(2);ph(77,76,{73:1},gi);var ke=Nh(77);ph(293,1,{});ph(71,1,{},hi);_.S=function(a){return a.e};var me=Nh(71);ph(59,7,Cp,ii);var oe=Nh(59);ph(226,1,{40:1});_.Q=Xp;_.V=function(){return new zj(this,0)};_.W=function(){return new Nj(null,this.V())};_.T=function(a){throw ah(new ii('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new Bj('[',']');for(b=this.R();b.Y();){a=b.Z();Aj(c,a===this?'(this Collection)':a==null?Dp:th(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=Nh(226);ph(229,1,{212:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!jd(a,37)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new wi((new ti(d)).a);c.b;){b=vi(c);if(!li(this,b)){return false}}return true};_.q=function(){return Pi(new ti(this))};_.r=function(){var a,b,c;c=new Bj('{','}');for(b=new wi((new ti(this)).a);b.b;){a=vi(b);Aj(c,mi(this,a._())+'='+mi(this,a.ab()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=Nh(229);ph(100,229,{212:1});var se=Nh(100);ph(228,226,{40:1,236:1});_.V=function(){return new zj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!jd(a,21)){return false}b=a;if(ri(b.a)!=this.U()){return false}return ji(this,b)};_.q=function(){return Pi(this)};var Be=Nh(228);ph(21,228,{21:1,40:1,236:1},ti);_.R=function(){return new wi(this.a)};_.U=Vp;var re=Nh(21);ph(22,1,{},wi);_.X=Up;_.Z=function(){return vi(this)};_.Y=Wp;_.b=false;var qe=Nh(22);ph(227,226,{40:1,233:1});_.V=function(){return new zj(this,16)};_.$=function(a,b){throw ah(new ii('Add not supported on this list'))};_.T=function(a){this.$(this.U(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,13)){return false}f=a;if(this.U()!=f.a.length){return false}e=new Mi(f);for(c=new Mi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(od(b)===od(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Qi(this)};_.R=function(){return new xi(this)};var ue=Nh(227);ph(91,1,{},xi);_.X=Up;_.Y=function(){return this.a<this.b.a.length};_.Z=function(){return Ei(this.b,this.a++)};_.a=0;var te=Nh(91);ph(60,226,{40:1},yi);_.R=function(){var a;a=new wi((new ti(this.a)).a);return new zi(a)};_.U=Vp;var we=Nh(60);ph(95,1,{},zi);_.X=Up;_.Y=function(){return this.a.b};_.Z=function(){var a;a=vi(this.a);return a.ab()};var ve=Nh(95);ph(93,1,Fp);_.o=function(a){var b;if(!jd(a,41)){return false}b=a;return Ri(this.a,b._())&&Ri(this.b,b.ab())};_._=Sp;_.ab=Wp;_.q=function(){return qj(this.a)^qj(this.b)};_.bb=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var xe=Nh(93);ph(94,93,Fp,Ai);var ye=Nh(94);ph(230,1,Fp);_.o=function(a){var b;if(!jd(a,41)){return false}b=a;return Ri(this.b.value[0],b._())&&Ri(mj(this),b.ab())};_.q=function(){return qj(this.b.value[0])^qj(mj(this))};_.r=function(){return this.b.value[0]+'='+mj(this)};var ze=Nh(230);ph(13,227,{3:1,13:1,40:1,233:1},Ki,Li);_.$=function(a,b){bk(this.a,a,b)};_.T=function(a){return Ci(this,a)};_.Q=function(a){Di(this,a)};_.R=function(){return new Mi(this)};_.U=function(){return this.a.length};var De=Nh(13);ph(14,1,{},Mi);_.X=Up;_.Y=function(){return this.a<this.c.a.length};_.Z=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=Nh(14);ph(37,100,{3:1,37:1,212:1},Si);var Ee=Nh(37);ph(63,1,{},Yi);_.Q=Xp;_.R=function(){return new Zi(this)};_.b=0;var Ge=Nh(63);ph(64,1,{},Zi);_.X=Up;_.Z=function(){return this.d=this.a[this.c++],this.d};_.Y=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=Nh(64);var aj;ph(61,1,{},kj);_.Q=Xp;_.R=function(){return new lj(this)};_.b=0;_.c=0;var Je=Nh(61);ph(62,1,{},lj);_.X=Up;_.Z=function(){return this.c=this.a,this.a=this.b.next(),new nj(this.d,this.c,this.d.c)};_.Y=function(){return !this.a.done};var He=Nh(62);ph(113,230,Fp,nj);_._=function(){return this.b.value[0]};_.ab=function(){return mj(this)};_.bb=function(a){return ij(this.a,this.b.value[0],a)};_.c=0;var Ie=Nh(113);ph(128,1,{});_.X=Zp;_.cb=function(){return this.d};_.db=Yp;_.d=0;_.e=0;var Ne=Nh(128);ph(65,128,{});var Ke=Nh(65);ph(96,1,{});_.X=Zp;_.cb=Wp;_.db=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Me=Nh(96);ph(97,96,{},xj);_.X=function(a){uj(this,a)};_.eb=function(a){return vj(this,a)};var Le=Nh(97);ph(20,1,{},zj);_.cb=Sp;_.db=function(){yj(this);return this.c};_.X=function(a){yj(this);this.d.X(a)};_.eb=function(a){yj(this);if(this.d.Y()){a.w(this.d.Z());return true}return false};_.a=0;_.c=0;var Oe=Nh(20);ph(57,1,{},Bj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Pe=Nh(57);ph(34,1,{},Cj);_.S=function(a){return a};var Qe=Nh(34);ph(38,1,{},Dj);var Re=Nh(38);ph(127,1,{});_.c=false;var _e=Nh(127);ph(26,127,{},Nj);var $e=Nh(26);ph(72,1,{},Qj);_.fb=function(a){return Zc(ie,up,1,a,5,1)};var Se=Nh(72);ph(130,65,{},Sj);_.eb=function(a){this.b=false;while(!this.b&&this.c.eb(new Tj(this,a)));return this.b};_.b=false;var Ue=Nh(130);ph(133,1,{},Tj);_.w=function(a){Rj(this.a,this.b,a)};var Te=Nh(133);ph(129,65,{},Vj);_.eb=function(a){return this.b.eb(new Wj(this,a))};var We=Nh(129);ph(132,1,{},Wj);_.w=function(a){Uj(this.a,this.b,a)};var Ve=Nh(132);ph(131,1,{},Yj);_.w=function(a){Xj(this,a)};var Xe=Nh(131);ph(134,1,{},Zj);_.w=function(a){};var Ye=Nh(134);ph(135,1,{},_j);_.w=function(a){$j(this,a)};var Ze=Nh(135);ph(291,1,{});ph(288,1,{});var fk=0;var hk,ik=0,jk;ph(905,1,{});ph(926,1,{});ph(232,1,{});var af=Nh(232);ph(168,1,{},xk);_.fb=function(a){return new Array(a)};var bf=Nh(168);ph(256,$wnd.Function,{},yk);_.hb=function(a){wk(this.a,this.b,a)};ph(6,30,{3:1,28:1,30:1,6:1},hl);var Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl;var cf=Oh(6,il);var jl;ph(255,$wnd.Function,{},ll);_.J=function(a){return Eb(jl),jl=null,null};ph(184,232,{});var Nf=Nh(184);ph(185,184,{});_.d=0;var Rf=Nh(185);ph(186,185,vp,tl);_.t=_p;_.o=$p;_.q=Tp;_.u=aq;_.r=function(){var a;return Jh(mf),mf.k+'@'+(a=gk(this)>>>0,a.toString(16))};var pl=0;var mf=Nh(186);ph(187,1,yp,ul);_.v=function(){ql(this.a)};var df=Nh(187);ph(188,1,{},vl);_.s=function(){return rl(this.a)};var ef=Nh(188);ph(189,1,{},wl);_.v=function(){nl(this.a)};var ff=Nh(189);ph(190,1,{},xl);_.s=function(){return ol(this.a)};var gf=Nh(190);ph(205,232,{});var Mf=Nh(205);ph(206,205,{});_.c=0;var Qf=Nh(206);ph(207,206,vp,Dl);_.t=bq;_.o=$p;_.q=Tp;_.u=cq;_.r=function(){var a;return Jh(lf),lf.k+'@'+(a=gk(this)>>>0,a.toString(16))};var Bl=0;var lf=Nh(207);ph(208,1,yp,El);_.v=dq;var hf=Nh(208);ph(209,1,{},Fl);_.v=function(){zl(this.a)};var jf=Nh(209);ph(210,1,{},Gl);_.s=function(){return Al(this.a)};var kf=Nh(210);ph(176,232,{});_.f='';var $f=Nh(176);ph(177,176,{});_.d=0;var Tf=Nh(177);ph(178,177,vp,Sl);_.t=_p;_.o=$p;_.q=Tp;_.u=aq;_.r=function(){var a;return Jh(sf),sf.k+'@'+(a=gk(this)>>>0,a.toString(16))};var Ml=0;var sf=Nh(178);ph(179,1,yp,Tl);_.v=function(){Nl(this.a)};var nf=Nh(179);ph(181,1,{},Ul);_.s=function(){return Ll(this.a)};var of=Nh(181);ph(182,1,yp,Vl);_.v=function(){Hl(this.a)};var pf=Nh(182);ph(183,1,yp,Wl);_.v=function(){Pl(this.a,this.b)};var qf=Nh(183);ph(180,1,{},Xl);_.v=function(){nl(this.a)};var rf=Nh(180);ph(172,232,{});_.i=false;var bg=Nh(172);ph(192,172,{});_.f=0;var Vf=Nh(192);ph(193,192,vp,rm);_.t=function(){hc(this.e)};_.o=$p;_.q=Tp;_.u=function(){return this.e.i<0};_.r=function(){var a;return Jh(Df),Df.k+'@'+(a=gk(this)>>>0,a.toString(16))};var fm=0;var Df=Nh(193);ph(194,1,yp,sm);_.v=function(){gm(this.a)};var tf=Nh(194);ph(197,1,{},tm);_.s=function(){return em(this.a)};var uf=Nh(197);ph(48,1,yp,um);_.v=function(){qm(this.a,Qn(this.b))};var vf=Nh(48);ph(68,1,yp,vm);_.v=function(){am(this.a,this.b)};var wf=Nh(68);ph(198,1,yp,wm);_.v=function(){im(this.a,this.b)};var xf=Nh(198);ph(199,1,yp,xm);_.v=function(){jm(this.a,this.b)};var yf=Nh(199);ph(195,1,{},ym);_.s=function(){return km(this.a)};var zf=Nh(195);ph(200,1,yp,zm);_.v=function(){Yl(this.a,this.b)};var Af=Nh(200);ph(201,1,yp,Am);_.v=function(){bm(this.a)};var Bf=Nh(201);ph(196,1,{},Bm);_.v=function(){dm(this.a)};var Cf=Nh(196);ph(154,232,{});var fg=Nh(154);ph(155,154,{});_.c=0;var Xf=Nh(155);ph(156,155,vp,Im);_.t=bq;_.o=$p;_.q=Tp;_.u=cq;_.r=function(){var a;return Jh(Hf),Hf.k+'@'+(a=gk(this)>>>0,a.toString(16))};var Gm=0;var Hf=Nh(156);ph(157,1,yp,Jm);_.v=dq;var Ef=Nh(157);ph(158,1,{},Km);_.v=function(){zl(this.a)};var Ff=Nh(158);ph(159,1,{},Lm);_.s=function(){return Fm(this.a)};var Gf=Nh(159);ph(261,$wnd.Function,{},Mm);_.lb=function(a){Ho(this.a.f)};ph(170,1,{},Nm);var If=Nh(170);ph(86,1,{},Om);var Jf=Nh(86);var Pm;ph(191,1,{},Qm);var Kf=Nh(191);ph(90,1,{},Rm);var Lf=Nh(90);var Sm;ph(262,$wnd.Function,{},Tm);_.mb=function(a){return new Wm(a)};var Um;ph(174,$wnd.React.Component,{},Wm);oh(mh[1],_);_.componentWillUnmount=function(){ml(this.a)};_.render=function(){return sl(this.a)};_.shouldComponentUpdate=eq;var Of=Nh(174);ph(272,$wnd.Function,{},Xm);_.mb=function(a){return new $m(a)};var Ym;ph(202,$wnd.React.Component,{},$m);oh(mh[1],_);_.componentWillUnmount=function(){yl(this.a)};_.render=function(){return Cl(this.a)};_.shouldComponentUpdate=fq;var Pf=Nh(202);ph(260,$wnd.Function,{},_m);_.mb=function(a){return new cn(a)};var an;ph(173,$wnd.React.Component,{},cn);oh(mh[1],_);_.componentWillUnmount=function(){ml(this.a)};_.render=function(){return Ql(this.a)};_.shouldComponentUpdate=eq;var Sf=Nh(173);ph(263,$wnd.Function,{},dn);_.mb=function(a){return new gn(a)};var en;ph(175,$wnd.React.Component,{},gn);oh(mh[1],_);_.componentDidUpdate=function(a){nm(this.a)};_.componentWillUnmount=function(){cm(this.a)};_.render=function(){return om(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Uf=Nh(175);ph(254,$wnd.Function,{},hn);_.mb=function(a){return new ln(a)};var jn;ph(98,$wnd.React.Component,{},ln);oh(mh[1],_);_.componentWillUnmount=function(){yl(this.a)};_.render=function(){return Hm(this.a)};_.shouldComponentUpdate=fq;var Wf=Nh(98);ph(258,$wnd.Function,{},mn);_.kb=function(a){Il(this.a,a)};ph(259,$wnd.Function,{},nn);_.jb=function(a){Ol(this.a,a)};ph(169,1,{},on);var Yf=Nh(169);ph(89,1,{},pn);var Zf=Nh(89);var qn;ph(270,$wnd.Function,{},rn);_.jb=function(a){hm(this.a,a)};ph(264,$wnd.Function,{},sn);_.jb=function(a){ko(this.a)};ph(266,$wnd.Function,{},tn);_.lb=function(a){lm(this.a,this.b)};ph(267,$wnd.Function,{},un);_.lb=function(a){Zl(this.a,this.b)};ph(268,$wnd.Function,{},vn);_.w=function(a){$l(this.a,a)};ph(269,$wnd.Function,{},wn);_.ib=function(a){mm(this.a,this.b)};ph(271,$wnd.Function,{},xn);_.kb=function(a){_l(this.a,this.b,a)};ph(171,1,{},zn);var _f=Nh(171);ph(87,1,{},An);var ag=Nh(87);var Bn;ph(253,$wnd.Function,{},Cn);_.jb=function(a){Cm(this.a,a)};ph(99,1,{},Dn);_.S=function(a){return yn(new zn,a)};var cg=Nh(99);ph(70,1,{},En);var dg=Nh(70);ph(88,1,{},Fn);var eg=Nh(88);var Gn;ph(85,1,{},Hn);var gg=Nh(85);ph(47,1,{47:1});var Ng=Nh(47);ph(160,47,{9:1,47:1},Un);_.t=_p;_.o=$p;_.q=Tp;_.u=aq;_.r=function(){var a;return Jh(og),og.k+'@'+(a=gk(this)>>>0,a.toString(16))};var og=Nh(160);ph(161,1,yp,Vn);_.v=function(){On(this.a)};var hg=Nh(161);ph(163,1,{},Wn);_.v=function(){Jn(this.a)};var ig=Nh(163);ph(164,1,{},Xn);_.v=function(){Kn(this.a)};var jg=Nh(164);ph(165,1,yp,Yn);_.v=function(){In(this.a,this.b)};var kg=Nh(165);ph(166,1,yp,Zn);_.v=function(){Rn(this.a)};var lg=Nh(166);ph(66,1,yp,$n);_.v=function(){Nn(this.a)};var mg=Nh(66);ph(162,1,{},_n);_.s=function(){var a;return a=(Dh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var ng=Nh(162);ph(49,1,{49:1});_.d=false;var Wg=Nh(49);ph(50,49,{9:1,257:1,50:1,49:1},lo);_.t=_p;_.o=function(a){return eo(this,a)};_.q=function(){return this.c.d};_.u=aq;_.r=function(){var a;return Jh(Eg),Eg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var ao=0;var Eg=Nh(50);ph(203,1,yp,mo);_.v=function(){bo(this.a)};var pg=Nh(203);ph(204,1,yp,no);_.v=function(){ho(this.a)};var qg=Nh(204);ph(115,114,{});var Qg=Nh(115);ph(25,115,vp,wo);_.t=gq;_.o=$p;_.q=Tp;_.u=hq;_.r=function(){var a;return Jh(zg),zg.k+'@'+(a=gk(this)>>>0,a.toString(16))};var zg=Nh(25);ph(117,1,yp,xo);_.v=function(){po(this.a)};var rg=Nh(117);ph(116,1,yp,yo);_.v=function(){to(this.a)};var sg=Nh(116);ph(122,1,yp,zo);_.v=function(){bc(this.a,this.b,true)};var tg=Nh(122);ph(123,1,{},Ao);_.s=function(){return oo(this.a,this.c,this.b)};_.b=false;var ug=Nh(123);ph(118,1,{},Bo);_.s=function(){return uo(this.a)};var vg=Nh(118);ph(119,1,{},Co);_.s=function(){return Yh(gh(Ij(so(this.a))))};var wg=Nh(119);ph(120,1,{},Do);_.s=function(){return Yh(gh(Ij(Jj(so(this.a),new kp))))};var xg=Nh(120);ph(121,1,{},Eo);_.s=function(){return vo(this.a)};var yg=Nh(121);ph(45,1,{45:1});var Vg=Nh(45);ph(144,45,{9:1,45:1},Lo);_.t=function(){hc(this.a)};_.o=$p;_.q=Tp;_.u=function(){return this.a.i<0};_.r=function(){var a;return Jh(Dg),Dg.k+'@'+(a=gk(this)>>>0,a.toString(16))};var Dg=Nh(144);ph(145,1,yp,Mo);_.v=function(){Io(this.a,this.b)};_.b=false;var Ag=Nh(145);ph(146,1,yp,No);_.v=function(){Tn(this.b,this.a)};var Bg=Nh(146);ph(147,1,yp,Oo);_.v=function(){Jo(this.a)};var Cg=Nh(147);ph(46,1,{46:1});var Zg=Nh(46);ph(148,46,{9:1,46:1},Wo);_.t=gq;_.o=$p;_.q=Tp;_.u=hq;_.r=function(){var a;return Jh(Kg),Kg.k+'@'+(a=gk(this)>>>0,a.toString(16))};var Kg=Nh(148);ph(149,1,yp,Xo);_.v=function(){Ro(this.a)};var Fg=Nh(149);ph(153,1,yp,Yo);_.v=function(){Vo(this.a,null)};var Gg=Nh(153);ph(150,1,{},Zo);_.s=function(){var a;return a=Qn(this.a.g),o(Qp,a)?(hp(),ep):o(Rp,a)?(hp(),gp):(hp(),fp)};var Hg=Nh(150);ph(151,1,{},$o);_.s=function(){return To(this.a)};var Ig=Nh(151);ph(152,1,{},_o);_.v=function(){Uo(this.a)};var Jg=Nh(152);ph(137,1,{},ap);_.handleEvent=function(a){Ln(this.a,a)};var Lg=Nh(137);ph(104,1,{},bp);_.I=function(){return new Un};var Mg=Nh(104);var cp;ph(31,30,{3:1,28:1,30:1,31:1},ip);var ep,fp,gp;var Og=Oh(31,jp);ph(106,1,{},kp);_.gb=function(a){return !go(a)};var Pg=Nh(106);ph(110,1,{},lp);_.gb=function(a){return go(a)};var Rg=Nh(110);ph(111,1,{},mp);_.w=function(a){ro(this.a,a)};var Sg=Nh(111);ph(109,1,{},np);_.w=function(a){Go(this.a,a)};_.a=false;var Tg=Nh(109);ph(103,1,{},op);_.I=function(){return new Lo(new wo)};var Ug=Nh(103);ph(112,1,{},pp);_.gb=function(a){return Qo(this.a,a)};var Xg=Nh(112);ph(105,1,{},qp);_.I=function(){return new Wo(new wo,this.a.I())};var Yg=Nh(105);var qd=Ph('D');var rp=(Cc(),Fc);var gwtOnLoad=gwtOnLoad=kh;ih(vh);lh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();