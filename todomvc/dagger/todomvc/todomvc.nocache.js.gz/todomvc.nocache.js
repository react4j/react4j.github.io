function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='3102FED42777BF45A12DA98AF16FAC58',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '3102FED42777BF45A12DA98AF16FAC58';function p(){}
function zh(){}
function vh(){}
function Gb(){}
function Sc(){}
function Zc(){}
function mi(){}
function Hj(){}
function Vj(){}
function bk(){}
function ck(){}
function Bk(){}
function pl(){}
function pp(){}
function fp(){}
function fo(){}
function Ym(){}
function an(){}
function en(){}
function jn(){}
function nn(){}
function In(){}
function op(){}
function sp(){}
function Xc(a){Wc()}
function Mh(){Mh=vh}
function Pi(){Gi(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function hc(a){this.a=a}
function qc(a){this.a=a}
function ai(a){this.a=a}
function li(a){this.a=a}
function yi(a){this.a=a}
function Di(a){this.a=a}
function Ei(a){this.a=a}
function Ci(a){this.b=a}
function Ri(a){this.c=a}
function Ij(a){this.a=a}
function Il(a){this.a=a}
function yl(a){this.a=a}
function zl(a){this.a=a}
function Al(a){this.a=a}
function Bl(a){this.a=a}
function Jl(a){this.a=a}
function Kl(a){this.a=a}
function Xl(a){this.a=a}
function Yl(a){this.a=a}
function Zl(a){this.a=a}
function $l(a){this.a=a}
function ek(a){this.a=a}
function wm(a){this.a=a}
function xm(a){this.a=a}
function ym(a){this.a=a}
function zm(a){this.a=a}
function Dm(a){this.a=a}
function Gm(a){this.a=a}
function Om(a){this.a=a}
function Pm(a){this.a=a}
function Qm(a){this.a=a}
function Rm(a){this.a=a}
function rn(a){this.a=a}
function sn(a){this.a=a}
function wn(a){this.a=a}
function xn(a){this.a=a}
function An(a){this.a=a}
function Hn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function co(a){this.a=a}
function eo(a){this.a=a}
function ro(a){this.a=a}
function so(a){this.a=a}
function Bo(a){this.a=a}
function Co(a){this.a=a}
function Fo(a){this.a=a}
function Go(a){this.a=a}
function Ho(a){this.a=a}
function Io(a){this.a=a}
function So(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function cp(a){this.a=a}
function dp(a){this.a=a}
function ep(a){this.a=a}
function tp(a){this.a=a}
function up(a){this.a=a}
function vp(a){this.a=a}
function wp(a){this.a=a}
function ak(a,b){a.a=b}
function rb(a,b){a.b=b}
function wk(a,b){a.key=b}
function uk(a,b){tk(a,b)}
function Ko(a,b){um(b,a)}
function Z(a){!!a&&ab(a)}
function lc(a){!!a&&a.t()}
function w(a){--a.e;D(a)}
function $p(a){tj(this,a)}
function dq(a){wj(this,a)}
function bq(a){ei(this,a)}
function eq(){kc(this.c)}
function gq(){kc(this.b)}
function lq(){kc(this.f)}
function bj(){this.a=kj()}
function pj(){this.a=kj()}
function iq(){lb(this.a.a)}
function ib(a){$b((K(),a))}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function gh(a){return a.e}
function Yp(){return this.a}
function aq(){return this.b}
function cq(){return this.e}
function gj(){gj=vh;fj=ij()}
function K(){K=vh;J=new F}
function yc(){yc=vh;xc=new p}
function Ch(){Ch=vh;Bh=new p}
function Pc(){Pc=vh;Oc=new Sc}
function ql(a){a.e=2;kc(a.c)}
function Cl(a){a.d=2;kc(a.b)}
function gm(a){a.g=2;kc(a.e)}
function Tn(a){S(a.a);ab(a.b)}
function ul(a){lb(a.b);S(a.a)}
function L(a,b){P(a);M(a,b)}
function dk(a,b){Uj(a.a,b)}
function oc(a,b){ui(a.e,b)}
function bm(a,b){wo(a.n,b)}
function Jo(a,b){vo(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function jc(a,b,c){ti(a.e,b,c)}
function Bj(a,b,c){b.A(a.a[c])}
function Ji(a,b){return a.a[b]}
function cm(a,b){return a.j=b}
function Zp(){return lk(this)}
function Lh(a){wc.call(this,a)}
function _h(a){wc.call(this,a)}
function ni(a){wc.call(this,a)}
function ik(a,b){a.splice(b,1)}
function tc(a,b){a.e=b;sc(a,b)}
function $c(a,b){return Vh(a,b)}
function Rl(a){lb(a.a);ab(a.b)}
function ho(a){ab(a.b);ab(a.a)}
function io(a,b,c){jc(a.c,b,c)}
function bb(a){K();Zb(a);a.e=-2}
function Ph(a){Oh(a);return a.k}
function hp(){hp=vh;gp=new fp}
function rp(){rp=vh;qp=new pp}
function Fc(){Fc=vh;!!(Wc(),Vc)}
function fi(){rc(this);this.H()}
function _p(){return wi(this.a)}
function fq(){return this.c.i<0}
function hq(){return this.b.i<0}
function mq(){return this.f.i<0}
function kj(){gj();return new fj}
function Tj(a,b){a.U(b);return a}
function U(a){nb(a.f);return W(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function Uj(a,b){ak(a,Tj(a.a,b))}
function wj(a,b){while(a.fb(b));}
function Zj(a,b,c){b.A(a.a.T(c))}
function v(a,b,c){t(a,new I(c),b)}
function Ek(a,b){a.ref=b;return a}
function Vn(a){gb(a.b);return a.e}
function Wo(a){gb(a.d);return a.e}
function lo(a){gb(a.a);return a.d}
function kq(a){return 1==this.a.d}
function jq(a){return 1==this.a.e}
function wi(a){return a.a.b+a.b.b}
function mj(a,b){return a.a.get(b)}
function Yj(a,b){this.a=a;this.b=b}
function _j(a,b){this.a=a;this.b=b}
function ic(a,b){this.a=a;this.b=b}
function $h(a,b){this.a=a;this.b=b}
function Fi(a,b){this.a=a;this.b=b}
function Ck(a,b){this.a=a;this.b=b}
function _l(a,b){this.a=a;this.b=b}
function Am(a,b){this.a=a;this.b=b}
function Bm(a,b){this.a=a;this.b=b}
function Cm(a,b){this.a=a;this.b=b}
function Em(a,b){this.a=a;this.b=b}
function Fm(a,b){this.a=a;this.b=b}
function Dh(a){this.a=Bh;this.b=a}
function Eb(a){this.d=a;this.b=100}
function Wm(a){this.a=a;Xm=this}
function un(a){this.a=a;vn=this}
function yn(a,b){this.a=a;this.b=b}
function zn(a,b){this.a=a;this.b=b}
function Bn(a,b){this.a=a;this.b=b}
function Cn(a,b){this.a=a;this.b=b}
function ll(a,b){$h.call(this,a,b)}
function gk(a,b,c){a.splice(b,0,c)}
function Fk(a,b){a.href=b;return a}
function bo(a,b){this.a=a;this.b=b}
function Do(a,b){this.a=a;this.b=b}
function Qo(a,b){this.a=a;this.b=b}
function Ro(a,b){this.b=a;this.a=b}
function xp(a,b){this.b=a;this.a=b}
function mp(a,b){$h.call(this,a,b)}
function oh(){mh==null&&(mh=[])}
function Sm(){this.a=yk(($m(),Zm))}
function Vm(){this.a=yk((cn(),bn))}
function tn(){this.a=yk((gn(),fn))}
function En(){this.a=yk((ln(),kn))}
function Jn(){this.a=yk((pn(),on))}
function Wn(a){Un(a,(gb(a.b),a.e))}
function mo(a){um(a,(gb(a.a),!a.d))}
function Ub(a){return !a.d?a:Ub(a.d)}
function si(a){return !a?null:a.bb()}
function rd(a){return a==null?null:a}
function vj(a){return a!=null?s(a):0}
function od(a){return typeof a===Ap}
function o(a,b){return rd(a)===rd(b)}
function Jk(a,b){a.onBlur=b;return a}
function Ok(a,b){a.value=b;return a}
function Gk(a,b){a.onClick=b;return a}
function Ik(a,b){a.checked=b;return a}
function ji(a,b){a.a+=''+b;return a}
function vi(a){a.a=new bj;a.b=new pj}
function pk(){pk=vh;mk=new p;ok=new p}
function jb(a){this.c=new Pi;this.b=a}
function Mc(a){$wnd.clearTimeout(a)}
function km(a){lb(a.b);S(a.c);ab(a.a)}
function gc(a,b){cc(a,b,false);fb(a.c)}
function hk(a,b){fk(b,0,a,0,b.length)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function ed(a,b,c){return {l:a,m:b,h:c}}
function gi(a,b){return a.charCodeAt(b)}
function $(a){return !(md(a,9)&&a.w())}
function lk(a){return a.$H||(a.$H=++kk)}
function md(a,b){return a!=null&&kd(a,b)}
function tk(a,b){for(var c in a){b(c)}}
function Mo(a,b){Ii(ec(a.b),new up(b))}
function Kk(a,b){a.onChange=b;return a}
function Lk(a,b){a.onKeyDown=b;return a}
function vk(a,b){a.props['a']=b;return a}
function qb(a){K();pb(a);tb(a,2,true)}
function Gi(a){a.a=ad(me,Cp,1,0,5,1)}
function Q(){this.a=ad(me,Cp,1,100,5,1)}
function wc(a){this.g=a;rc(this);this.H()}
function Sj(a,b){Lj.call(this,a);this.a=b}
function fc(a,b){oc(b.c,a);md(b,9)&&b.v()}
function tj(a,b){while(a.Z()){dk(b,a.$())}}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function dj(a,b){var c;c=a[Np];c.call(a,b)}
function Fn(a,b){this.a=a;this.b=b;Gn=this}
function Xi(){this.a=new bj;this.b=new pj}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function Hk(a){return a.autoFocus=true,a}
function qd(a){return typeof a==='string'}
function nd(a){return typeof a==='boolean'}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Oh(a){if(a.k!=null){return}Xh(a)}
function rc(a){a.j&&a.e!==Ip&&a.H();return a}
function Pk(a,b){a.onDoubleClick=b;return a}
function Sh(a){var b;b=Rh(a);Zh(a,b);return b}
function Vo(a){lb(a.a);S(a.b);S(a.c);ab(a.d)}
function Xn(a){A((K(),K(),J),new co(a),Rp)}
function po(a){A((K(),K(),J),new so(a),Rp)}
function Lo(a){A((K(),K(),J),new So(a),Rp)}
function sm(a){A((K(),K(),J),new Gm(a),Rp)}
function zo(a){return bi(T(a.e).a-T(a.a).a)}
function Gc(a,b,c){return a.apply(b,c);var d}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function Jh(a,b,c,d){a.addEventListener(b,c,d)}
function sj(a,b,c){this.a=a;this.b=b;this.c=c}
function zj(a,b){while(a.c<a.d){Bj(a,b,a.c++)}}
function Db(a){while(true){if(!Cb(a)){break}}}
function di(){di=vh;ci=ad(ie,Cp,28,256,0,1)}
function Wc(){Wc=vh;var a;!Yc();a=new Zc;Vc=a}
function Hi(a,b){a.a[a.a.length]=b;return true}
function Ul(a,b){var c;c=b.target;Vl(a,c.value)}
function Tl(a,b){A((K(),K(),J),new _l(a,b),Rp)}
function mm(a,b){A((K(),K(),J),new Fm(a,b),Rp)}
function qm(a,b){A((K(),K(),J),new Cm(a,b),Rp)}
function rm(a,b){A((K(),K(),J),new Bm(a,b),Rp)}
function tm(a,b){A((K(),K(),J),new Am(a,b),Rp)}
function wo(a,b){A((K(),K(),J),new Do(a,b),Rp)}
function Oo(a,b){A((K(),K(),J),new Qo(a,b),Rp)}
function xo(a){ei(new Di(a.g),new hc(a));vi(a.g)}
function Gh(a){if(!a){throw gh(new fi)}return a}
function Uh(a){var b;b=Rh(a);b.j=a;b.e=1;return b}
function Mj(a,b){var c;return Qj(a,(c=new Pi,c))}
function Kh(a,b,c,d){a.removeEventListener(b,c,d)}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function Dj(a){if(!a.d){a.d=a.b.S();a.c=a.b.V()}}
function Wj(a,b,c){if(a.a.hb(c)){a.b=true;b.A(c)}}
function Eo(a,b){this.a=a;this.c=b;this.b=false}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Li(a,b){var c;c=a.a[b];ik(a.a,b);return c}
function Ai(a){var b;b=a.a.$();a.b=zi(a);return b}
function Ti(a){return new Sj(null,Si(a,a.length))}
function To(a){return o(Wp,a)||o(Xp,a)||o('',a)}
function Si(a,b){return xj(b,a.length),new Cj(a,b)}
function lj(a,b){return !(a.a.get(b)===undefined)}
function yo(a){return Mh(),0!=T(a.e).a?true:false}
function wl(a){return Mh(),T(a.f.b).a>0?true:false}
function Gl(a){return B((K(),K(),J),a.a,new Kl(a))}
function Sl(a){return B((K(),K(),J),a.a,new Yl(a))}
function vl(a){return B((K(),K(),J),a.b,new Al(a))}
function lm(a){return B((K(),K(),J),a.b,new ym(a))}
function Mm(a){return B((K(),K(),J),a.a,new Qm(a))}
function nm(a){return Mh(),Wo(a.o)==a.i?true:false}
function cd(a){return Array.isArray(a)&&a.qb===zh}
function ld(a){return !Array.isArray(a)&&a.qb===zh}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function uo(a){S(a.d);S(a.e);S(a.a);S(a.b);ab(a.c)}
function Jj(a){if(!a.b){Kj(a);a.c=true}else{Jj(a.b)}}
function El(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function sl(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function im(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function sk(){if(nk==256){mk=ok;ok=new p;nk=0}++nk}
function Ih(){Ih=vh;Hh=$wnd.goog.global.document}
function Hm(a,b){var c;c=b.target;Oo(a.f,c.checked)}
function um(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function Vl(a,b){var c;c=a.g;if(b!=c){a.g=b;fb(a.b)}}
function Yn(a,b){var c;c=a.e;if(b!=c){a.e=b;fb(a.b)}}
function Ni(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Nk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function xi(a,b){if(b){return qi(a.a,b)}return false}
function Oj(a,b){Kj(a);return new Sj(a,new Xj(b,a.a))}
function Pj(a,b){Kj(a);return new Sj(a,new $j(b,a.a))}
function Un(a,b){A((K(),K(),J),new bo(a,b),75497472)}
function om(a,b){Zo(a.o,b);A((K(),K(),J),new Am(a,b),Rp)}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Sn(a){var b;V(a.a);b=T(a.a);o(a.f,b)&&Yn(a,b)}
function Wi(a,b){return rd(a)===rd(b)||a!=null&&q(a,b)}
function yj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Ej(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Cj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Tm(a,b,c){this.a=a;this.b=b;this.c=c;Um=this}
function Kn(a,b,c){this.a=a;this.b=b;this.c=c;Ln=this}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function Lj(a){if(!a){this.b=null;new Pi}else{this.b=a}}
function Wh(a){if(a.Q()){return null}var b=a.j;return rh[b]}
function lh(a){if(od(a)){return a|0}return a.l|a.m<<22}
function uc(a,b){var c;c=Ph(a.ob);return b==null?c:c+': '+b}
function Th(a,b){var c;c=Rh(a);Zh(a,c);c.e=b?8:0;return c}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function am(a,b){var c;if(T(a.c)){c=b.target;um(a,c.value)}}
function ei(a,b){var c,d;for(d=a.S();d.Z();){c=d.$();b.A(c)}}
function ri(a,b){return b===a?'(this Map)':b==null?Kp:yh(b)}
function np(){lp();return dd($c(Sg,1),Cp,30,0,[ip,kp,jp])}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&Gp)&&D((null,J))}
function pm(a,b){A((K(),K(),J),new Am(a,b),Rp);Zo(a.o,null)}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function xh(a){function b(){}
;b.prototype=a||{};return new b}
function Mk(a){a.placeholder='What needs to be done?';return a}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function gn(){gn=vh;var a;fn=(a=wh(en.prototype.nb,en,[]),a)}
function cn(){cn=vh;var a;bn=(a=wh(an.prototype.nb,an,[]),a)}
function ln(){ln=vh;var a;kn=(a=wh(jn.prototype.nb,jn,[]),a)}
function pn(){pn=vh;var a;on=(a=wh(nn.prototype.nb,nn,[]),a)}
function $m(){$m=vh;var a;Zm=(a=wh(Ym.prototype.nb,Ym,[]),a)}
function Vh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.L(b))}
function Zi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function $i(a,b){var c;return Yi(b,Zi(a,b==null?0:(c=s(b),c|0)))}
function dc(a){gb(a.c);return new Sj(null,new Ej(new Di(a.g),0))}
function Qn(a,b){b.preventDefault();A((K(),K(),J),new eo(a),Rp)}
function Qi(a){Gi(this);hk(this.a,pi(a,ad(me,Cp,1,wi(a.a),5,1)))}
function Po(a){this.b=a;K();this.a=new pc(0,null,null,false,false)}
function cj(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function $j(a,b){yj.call(this,b.eb(),b.db()&-6);this.a=a;this.b=b}
function Aj(a,b){if(a.c<a.d){Bj(a,b,a.c++);return true}return false}
function Eh(a){Ch();Gh(a);if(md(a,44)){return a}return new Dh(a)}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function th(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Ak(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function nc(a){lc(a.g);!!a.e&&mc(a);Z(a.a);Z(a.c);lc(a.b);lc(a.f)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function cb(a,b){var c,d;Hi(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Xj(a,b){yj.call(this,b.eb(),b.db()&-16449);this.a=a;this.c=b}
function qj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function On(a){Jh((Ih(),$wnd.goog.global.window),Up,a.d,false)}
function Pn(a){Kh((Ih(),$wnd.goog.global.window),Up,a.d,false)}
function No(a){Mj(Oj(dc(a.b),new sp),new Ij(new Hj)).R(new tp(a.b))}
function Nj(a){var b;Jj(a);b=0;while(a.a.fb(new ck)){b=hh(b,1)}return b}
function Qj(a,b){var c;Jj(a);c=new bk;c.a=b;a.a.Y(new ek(c));return c.a}
function Fj(a,b){!a.a?(a.a=new li(a.d)):ji(a.a,a.b);ji(a.a,b);return a}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function vo(a,b){var c;return u((K(),K(),J),new Eo(a,b),Rp,(c=null,c))}
function Rj(a,b){var c;c=Mj(a,new Ij(new Hj));return Oi(c,b.gb(c.a.length))}
function Uo(a,b){return (lp(),jp)==a||(ip==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function ui(a,b){return qd(b)?b==null?aj(a.a,null):oj(a.b,b):aj(a.a,b)}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function Jb(b){try{nb(b.b.a)}catch(a){a=fh(a);if(!md(a,4))throw gh(a)}}
function dn(a){$wnd.React.Component.call(this,a);this.a=new Hl(this,Xm.a)}
function hn(a){$wnd.React.Component.call(this,a);this.a=new Wl(this,vn.a)}
function Bi(a){this.d=a;this.c=new qj(this.d.b);this.a=this.c;this.b=zi(this)}
function Gj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Ii(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.A(c)}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Ki(a,b,c){for(;c<a.a.length;++c){if(Wi(b,a.a[c])){return c}}return -1}
function rj(a){if(a.a.c!=a.c){return mj(a.a,a.b.value[0])}return a.b.value[1]}
function jo(a,b){var c;if(md(b,51)){c=b;return a.c.d==c.c.d}else{return false}}
function Mi(a,b){var c;c=Ki(a,b,0);if(c==-1){return false}ik(a.a,c);return true}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function Nn(a,b){a.f=b;o(b,T(a.a))&&Yn(a,b);Rn(b);A((K(),K(),J),new eo(a),Rp)}
function Xo(a){var b;return b=T(a.b),Mj(Oj(dc(a.i),new wp(b)),new Ij(new Hj))}
function Ll(a){var b;b=ii((gb(a.b),a.g));if(b.length>0){Jo(a.f,b);Vl(a,'')}}
function ti(a,b,c){return qd(b)?b==null?_i(a.a,null,c):nj(a.b,b,c):_i(a.a,b,c)}
function jk(a,b){return _c(b)!=10&&dd(r(b),b.pb,b.__elementTypeId$,_c(b),a),a}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function mn(a){$wnd.React.Component.call(this,a);this.a=new vm(this,Gn.a,Gn.b)}
function kc(a){if(a.i>=0){a.i=-2;u((K(),K(),J),new H(new qc(a)),67108864,null)}}
function ab(a){if(-2!=a.e){u((K(),K(),J),new H(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function S(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function W(a){if(a.b){if(md(a.b,7)){throw gh(a.b)}else{throw gh(a.b)}}return a.k}
function sb(b){if(b){try{b.t()}catch(a){a=fh(a);if(md(a,4)){K()}else throw gh(a)}}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function Qc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Uc(b,c)}while(a.a);a.a=c}}
function Rc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Pi);Hi(a.b,b)}}}
function Pb(){var a;this.a=ad(yd,Cp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?Hp:0)|(0!=(b&229376)?0:98304)}
function Dn(a,b){wk(a.a,(b?bi(b.c.d):null)+(''+(Oh(fg),fg.k)));vk(a.a,b);return a.a}
function Rh(a){var b;b=new Qh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Pi);a.c=c.c}b.d=true;Hi(a.c,b)}
function Zh(a,b){var c;if(!a){return}b.j=a;var d=Wh(b);if(!d){rh[a]=[b];return}d.ob=b}
function wh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function oj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{dj(a.a,b);--a.b}return c}
function Ui(a){var b,c,d;d=0;for(c=new Bi(a.a);c.b;){b=Ai(c);d=d+(b?s(b):0);d=d|0}return d}
function pb(a){var b,c;for(c=new Ri(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function nh(){oh();var a=mh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Ml(a,b){if(13==b.keyCode){b.preventDefault();A((K(),K(),J),new Zl(a),Rp)}}
function ec(a){return gb(a.c),Mj(new Sj(null,new Ej(new Di(a.g),0)),new Ij(new Hj))}
function pd(a){return a!=null&&(typeof a===zp||typeof a==='function')&&!(a.qb===zh)}
function qh(a,b){typeof window===zp&&typeof window['$gwt']===zp&&(window['$gwt'][a]=b)}
function qn(a){$wnd.React.Component.call(this,a);this.a=new Nm(this,Ln.a,Ln.b,Ln.c)}
function _m(a){$wnd.React.Component.call(this,a);this.a=new xl(this,Um.a,Um.b,Um.c)}
function yk(a){var b;b=xk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function ih(a){var b;b=a.h;if(b==0){return a.l+a.m*Hp}if(b==1048575){return a.l+a.m*Hp-Lp}return a}
function fh(a){var b;if(md(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function zi(a){if(a.a.Z()){return true}if(a.a!=a.c){return false}a.a=new cj(a.d.a);return a.a.Z()}
function oi(a,b){var c,d;for(d=new Bi(b.a);d.b;){c=Ai(d);if(!xi(a,c)){return false}}return true}
function to(a,b,c){var d;d=new qo(b,c);io(d,a,new ic(a,d));ti(a.g,bi(d.c.d),d);fb(a.c);return d}
function nj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function cc(a,b,c){var d;d=ui(a.g,b?bi(b.c.d):null);if(null!=d){oc(b.c,a);c&&!!b&&kc(b.c);fb(a.c)}}
function Yo(a){var b;b=T(a.g.a);o(Wp,b)||o(Xp,b)||o('',b)?Un(a.g,b):To(Vn(a.g))?Xn(a.g):Un(a.g,'')}
function Zo(a,b){var c;c=a.e;if(!(b==c||!!b&&jo(b,c))){!!c&&oc(c.c,a);a.e=b;!!b&&io(b,a,new ap(a));fb(a.d)}}
function dm(a,b,c){27==c.which?A((K(),K(),J),new Em(a,b),Rp):13==c.which&&A((K(),K(),J),new Bm(a,b),Rp)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:Ep)|(0==(c&6291456)?!a?Gp:Hp:0)|0|0|0)}
function lp(){lp=vh;ip=new mp('ACTIVE',0);kp=new mp('COMPLETED',1);jp=new mp('ALL',2)}
function xj(a,b){if(0>a||a>b){throw gh(new Lh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function dd(a,b,c,d,e){e.ob=a;e.pb=b;e.qb=zh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Yi(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Wi(a,c.ab())){return c}}return null}
function bi(a){var b,c;if(a>-129&&a<128){b=a+128;c=(di(),ci)[b];!c&&(c=ci[b]=new ai(a));return c}return new ai(a)}
function kh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Lp;d=1048575}c=sd(e/Hp);b=sd(e-c*Hp);return ed(b,c,d)}
function fd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ed(c&4194303,d&4194303,e&1048575)}
function db(a,b){var c,d;d=a.c;Mi(d,b);!!a.b&&Ep!=(a.b.c&Fp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function fm(a){var b;b=T(a.c);if(!a.k&&b){a.k=true;tm(a,a.i);a.j.focus();a.j.select()}else a.k&&!b&&(a.k=false)}
function r(a){return qd(a)?pe:od(a)?de:nd(a)?be:ld(a)?a.ob:cd(a)?a.ob:a.ob||Array.isArray(a)&&$c(Ud,1)||Ud}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function ol(){if(!nl){nl=(++(K(),K(),J).e,new Gb);$wnd.Promise.resolve(null).then(wh(pl.prototype.K,pl,[]))}}
function Mn(){this.a=Eh((rp(),qp));this.b=Eh(new vp(this.a));this.c=Eh((hp(),gp));this.d=Eh(new xp(this.a,this.c))}
function Ac(a){yc();rc(this);this.e=a;sc(this,a);this.g=a==null?Kp:yh(a);this.a='';this.b=a;this.a=''}
function Qh(){this.g=Nh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function rk(a){pk();var b,c,d;c=':'+a;d=ok[c];if(d!=null){return sd(d)}d=mk[c];b=d==null?qk(a):sd(d);sk();ok[c]=b;return b}
function Vi(a){var b,c,d;d=1;for(c=new Ri(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=Li(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function em(a,b){var c;c=(gb(a.a),a.d);if(null!=c&&c.length!=0){A((K(),K(),J),new Ro(b,c),Rp);Zo(a.o,null);um(a,c)}else{wo(a.n,b)}}
function hh(a,b){var c;if(od(a)&&od(b)){c=a+b;if(-17592186044416<c&&c<Lp){return c}}return ih(fd(od(a)?kh(a):a,od(b)?kh(b):b))}
function yh(a){var b;if(Array.isArray(a)&&a.qb===zh){return Ph(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Ep)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Kj(a){if(a.b){Kj(a.b)}else if(a.c){throw gh(new _h("Stream already terminated, can't be modified or used"))}}
function ml(){kl();return dd($c(ff,1),Cp,6,0,[Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il,jl])}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(Ep==(b&Fp)?0:524288)|(0==(b&6291456)?Ep==(b&Fp)?Hp:Gp:0)|0|268435456|0)}
function s(a){return qd(a)?rk(a):od(a)?sd(a):nd(a)?a?1231:1237:ld(a)?a.r():cd(a)?lk(a):!!a&&!!a.hashCode?a.hashCode():lk(a)}
function q(a,b){return qd(a)?o(a,b):od(a)?rd(a)===rd(b):nd(a)?rd(a)===rd(b):ld(a)?a.p(b):cd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function Yh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Oi(a,b){var c,d;d=a.a.length;b.length<d&&(b=jk(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Hl(a,b){var c;this.e=b;this.c=a;K();c=++Fl;this.b=new pc(c,null,new Il(this),false,false);this.a=new wb(null,new Jl(this),Qp)}
function pc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Xi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new jb((f=null,K(),f)),g):null;this.c=null}
function mc(a){var b,c,d;for(c=new Ri(new Qi(new yi(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.ab();md(d,9)&&d.w()||b.bb().t()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ri(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function kd(a,b){if(qd(a)){return !!jd[b]}else if(a.pb){return !!a.pb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function Dk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function T(a){a.j?hb(a.e):gb(a.e);if(ub(a.f)){if(a.j&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function ii(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function pi(a,b){var c,d,e,f;f=wi(a.a);b.length<f&&(b=jk(new Array(f),b));e=b;d=new Bi(a.a);for(c=0;c<f;++c){e[c]=Ai(d)}b.length>f&&(b[f]=null);return b}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.t(),null)}finally{bc()}return f}catch(a){a=fh(a);if(md(a,4)){e=a;throw gh(e)}else throw gh(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.u()}else{ac(b,e);try{g=c.u()}finally{bc()}}return g}catch(a){a=fh(a);if(md(a,4)){f=a;throw gh(f)}else throw gh(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.i=c;this.k=null;this.j=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);Ep==(d&Fp)&&mb(this.f)}
function Nm(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.c=a;K();e=++Lm;this.b=new pc(e,null,new Om(this),false,false);this.a=new wb(null,new Pm(this),Qp)}
function Wl(a,b){var c,d,e;this.f=b;this.d=a;K();c=++Ql;this.c=new pc(c,null,new Xl(this),false,false);this.b=(e=new jb((d=null,d)),e);this.a=new wb(null,new $l(this),Qp)}
function qo(a,b){var c,d,e,f,g;this.e=a;this.d=b;K();c=++go;this.c=new pc(c,null,new ro(this),true,true);this.b=(g=new jb((e=null,e)),g);this.a=(f=new jb((d=null,d)),f)}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function ph(b,c,d,e){oh();var f=mh;$moduleName=c;$moduleBase=d;eh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{yp(g)()}catch(a){b(c,a)}}else{yp(g)()}}
function xk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function ij(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return jj()}}
function Dl(a){var b,c;a.d=0;ol();c=(b=T(a.e.e).a,zk('span',Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,['todo-count'])),[zk('strong',null,[b]),' item'+(b==1?'':'s')+' left']));return c}
function sh(){rh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].rb()&&(c=Tc(c,g)):g[0].rb()}catch(a){a=fh(a);if(md(a,4)){d=a;Fc();Lc(md(d,34)?d.I():d)}else throw gh(a)}}return c}
function Ol(a){var b;a.e=0;ol();b=zk(Sp,Hk(Kk(Lk(Ok(Mk(Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,['new-todo']))),(gb(a.b),a.g)),wh(rn.prototype.lb,rn,[a])),wh(sn.prototype.kb,sn,[a]))),null);return b}
function zc(a){var b;if(a.c==null){b=rd(a.b)===rd(xc)?null:a.b;a.d=b==null?Kp:pd(b)?b==null?null:b.name:qd(b)?'String':Ph(r(b));a.a=a.a+': '+(pd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.k;try{d=b.c.u();if(!(rd(e)===rd(d)||e!=null&&q(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=fh(a);if(md(a,10)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw gh(c)}else throw gh(a)}}
function fk(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function _i(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Yi(b,e);if(f){return f.cb(c)}}e[e.length]=new Fi(b,c);++a.b;return null}
function xl(a,b,c,d){var e;this.f=b;this.g=c;this.i=d;this.d=a;K();e=++tl;this.c=new pc(e,null,new yl(this),false,false);this.a=new X(new zl(this),null,null,136478720);this.b=new wb(null,new Bl(this),Qp)}
function qk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+gi(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{b.e.t()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=fh(a);if(md(a,4)){K()}else throw gh(a)}}}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=ad(me,Cp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function Fh(a,b){var c;c=rd(a)!==rd(Bh);if(c&&rd(a)!==rd(b)){throw gh(new _h('Scoped provider was invoked recursively returning different results: '+a+' & '+b+'. This is likely '+'due to a circular dependency.'))}return b}
function vb(a,b,c,d){this.b=new Pi;this.f=new Kb(new zb(this),d&6520832|262144|Ep);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&Gp)&&D((null,J)))}
function Ah(){var a;a=new Mn;new Tm(a.a.J(),a.b.J(),a.d.J());new Fn(a.a.J(),(a.b.J(),a.d.J()));new Kn(a.a.J(),a.b.J(),a.d.J());new un(a.b.J());new Wm(a.a.J());$wnd.ReactDOM.render((new Jn).a,(Ih(),Hh).getElementById('app'),null)}
function aj(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Wi(b,e.ab())){if(d.length==1){d.length=0;dj(a.a,g)}else{d.splice(h,1)}--a.b;return e.bb()}}return null}
function uh(a,b,c){var d=rh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=rh[b]),xh(h));_.pb=c;!b&&(_.qb=zh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ob=f)}
function Xh(a){if(a.P()){var b=a.c;b.Q()?(a.k='['+b.j):!b.P()?(a.k='[L'+b.N()+';'):(a.k='['+b.N());a.b=b.M()+'[]';a.i=b.O()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Yh('.',[c,Yh('$',d)]);a.b=Yh('.',[c,Yh('.',d)]);a.i=d[d.length-1]}
function Rn(a){var b;if(0==a.length){b=(Ih(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Hh.title,b)}else{(Ih(),$wnd.goog.global.window).location.hash=a}}
function qi(a,b){var c,d,e;c=b.ab();e=b.bb();d=qd(c)?c==null?si($i(a.a,null)):mj(a.b,c):si($i(a.a,c));if(!(rd(e)===rd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(qd(c)?c==null?!!$i(a.a,null):lj(a.b,c):!!$i(a.a,c))){return false}return true}
function $o(a,b){var c,d;this.i=a;this.g=b;K();this.f=new pc(0,null,new _o(this),false,false);this.d=(d=new jb((c=null,c)),d);this.b=new X(new bp(this),null,null,Vp);this.c=new X(new cp(this),null,null,Vp);this.a=new wb(new dp(this),null,681574400);D((null,J))}
function Ao(){var a;this.g=new Xi;K();this.f=new pc(0,new Co(this),new Bo(this),false,false);this.c=(a=new jb(null),a);this.d=new X(new Fo(this),null,null,Vp);this.e=new X(new Go(this),null,null,Vp);this.a=new X(new Ho(this),null,null,Vp);this.b=new X(new Io(this),null,null,Vp)}
function Zn(){var a,b,c;this.d=new ep(this);this.f=this.e=(c=(Ih(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));K();this.c=new pc(0,null,new $n(this),false,false);this.b=(b=new jb((a=null,a)),b);this.a=new X(new fo,new _n(this),new ao(this),35651584)}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ri(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=fh(a);if(!md(a,4))throw gh(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.F();return a&&a.C()}},suppressed:{get:function(){return c.D()}}})}catch(a){}}}
function vm(a,b,c){var d,e,f;this.n=b;this.o=c;this.f=a;this.i=a.props['a'];K();d=++jm;this.e=new pc(d,null,new wm(this),false,false);this.a=(f=new jb((e=null,e)),f);this.c=new X(new zm(this),null,null,136478720);this.b=new wb(null,new Dm(this),Qp);io(this.i,this,new xm(this));tm(this,this.i);D((null,J))}
function zk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;uk(b,wh(Ck.prototype.ib,Ck,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=xk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function hj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}Ii(a.b,new Bb(a));a.b.a=ad(me,Cp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function Jm(a){var b;a.d=0;ol();b=zk('div',null,[zk('div',null,[zk(Tp,Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,[Tp])),[zk('h1',null,['todos']),(new tn).a]),T(a.e.d)?zk('section',Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,[Tp])),[zk(Sp,Kk(Nk(Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,['toggle-all'])),(kl(),Rk)),wh(Hn.prototype.kb,Hn,[a])),null),zk('ul',Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,['todo-list'])),Rj(Pj(T(a.g.c).X(),new In),new Bk))]):null,T(a.e.d)?(new Sm).a:null])]);return b}
function kl(){kl=vh;Qk=new ll(Op,0);Rk=new ll('checkbox',1);Sk=new ll('color',2);Tk=new ll('date',3);Uk=new ll('datetime',4);Vk=new ll('email',5);Wk=new ll('file',6);Xk=new ll('hidden',7);Yk=new ll('image',8);Zk=new ll('month',9);$k=new ll(Ap,10);_k=new ll('password',11);al=new ll('radio',12);bl=new ll('range',13);cl=new ll('reset',14);dl=new ll('search',15);el=new ll('submit',16);fl=new ll('tel',17);gl=new ll('text',18);hl=new ll('time',19);il=new ll('url',20);jl=new ll('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ji(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ni(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ji(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Li(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Pi)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Ep!=(k.b.c&Fp)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function rl(a){var b,c;a.e=0;ol();c=(b=T(a.i.b),zk('footer',Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,['footer'])),[(new Vm).a,zk('ul',Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,['filters'])),[zk('li',null,[zk('a',Fk(Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,[(lp(),jp)==b?Pp:null])),'#'),['All'])]),zk('li',null,[zk('a',Fk(Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,[ip==b?Pp:null])),'#active'),['Active'])]),zk('li',null,[zk('a',Fk(Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,[kp==b?Pp:null])),'#completed'),['Completed'])])]),T(a.a)?zk(Op,Gk(Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,['clear-completed'])),wh(Rm.prototype.mb,Rm,[a])),['Clear Completed']):null]));return c}
function hm(a){var b,c,d;a.g=0;ol();b=(c=a.i,d=(gb(c.a),c.d),zk('li',Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,[d?'checked':null,T(a.c)?'editing':null])),[zk('div',Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,['view'])),[zk(Sp,Kk(Ik(Nk(Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,['toggle'])),(kl(),Rk)),d),wh(xn.prototype.kb,xn,[c])),null),zk('label',Pk(new $wnd.Object,wh(yn.prototype.mb,yn,[a,c])),[(gb(c.b),c.e)]),zk(Op,Gk(Dk(new $wnd.Object,dd($c(pe,1),Cp,2,6,['destroy'])),wh(zn.prototype.mb,zn,[a,c])),null)]),zk(Sp,Lk(Kk(Jk(Ok(Dk(Ek(new $wnd.Object,wh(An.prototype.A,An,[a])),dd($c(pe,1),Cp,2,6,['edit'])),(gb(a.a),a.d)),wh(Bn.prototype.jb,Bn,[a,c])),wh(wn.prototype.kb,wn,[a])),wh(Cn.prototype.lb,Cn,[a,c])),null)]));return b}
function jj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Np]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!hj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Np]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var zp='object',Ap='number',Bp={5:1},Cp={3:1},Dp={9:1},Ep=1048576,Fp=1835008,Gp=2097152,Hp=4194304,Ip='__noinit__',Jp={3:1,10:1,7:1,4:1},Kp='null',Lp=17592186044416,Mp={40:1},Np='delete',Op='button',Pp='selected',Qp=1411518464,Rp=142606336,Sp='input',Tp='header',Up='hashchange',Vp=136314880,Wp='active',Xp='completed';var _,rh,mh,eh=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;sh();uh(1,null,{},p);_.p=function(a){return o(this,a)};_.q=function(){return this.ob};_.r=Zp;_.s=function(){var a;return Ph(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.p(a)};_.hashCode=function(){return this.r()};_.toString=function(){return this.s()};var gd,hd,jd;uh(56,1,{},Qh);_.L=function(a){var b;b=new Qh;b.e=4;a>1?(b.c=Vh(this,a-1)):(b.c=this);return b};_.M=function(){Oh(this);return this.b};_.N=function(){return Ph(this)};_.O=function(){Oh(this);return this.i};_.P=function(){return (this.e&4)!=0};_.Q=function(){return (this.e&1)!=0};_.s=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Oh(this),this.k)};_.e=0;_.g=0;var Nh=1;var me=Sh(1);var ce=Sh(56);uh(81,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var xd=Sh(81);uh(82,1,Bp,G);_.t=function(){Db(this.a)};var ud=Sh(82);uh(35,1,{},H);_.u=function(){return this.a.t(),null};var vd=Sh(35);uh(83,1,{},I);var wd=Sh(83);var J;uh(43,1,{43:1},Q);_.b=0;_.c=false;_.d=0;var yd=Sh(43);uh(234,1,Dp);_.s=function(){var a;return Ph(this.ob)+'@'+(a=s(this)>>>0,a.toString(16))};var Bd=Sh(234);uh(18,234,Dp,X);_.v=function(){S(this)};_.w=Yp;_.a=false;_.d=0;_.j=false;var Ad=Sh(18);uh(163,1,{},Y);_.u=function(){return U(this.a)};var zd=Sh(163);uh(16,234,{9:1,16:1},jb);_.v=function(){ab(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Dd=Sh(16);uh(162,1,Bp,kb);_.t=function(){bb(this.a)};var Cd=Sh(162);uh(17,234,{9:1,17:1},wb,xb);_.v=function(){lb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Id=Sh(17);uh(164,1,{},yb);_.t=function(){R(this.a)};var Ed=Sh(164);uh(165,1,Bp,zb);_.t=function(){nb(this.a)};var Fd=Sh(165);uh(166,1,Bp,Ab);_.t=function(){qb(this.a)};var Gd=Sh(166);uh(167,1,{},Bb);_.A=function(a){ob(this.a,a)};var Hd=Sh(167);uh(103,1,{},Eb);_.a=0;_.b=0;_.c=0;var Jd=Sh(103);uh(168,1,Dp,Gb);_.v=function(){Fb(this)};_.w=Yp;_.a=false;var Kd=Sh(168);uh(66,234,{9:1,66:1},Kb);_.v=function(){Hb(this)};_.w=function(){return 2==(3&this.a)};_.a=0;var Md=Sh(66);uh(102,1,{},Pb);var Ld=Sh(102);uh(172,1,{},_b);_.s=function(){var a;return Oh(Nd),Nd.k+'@'+(a=lk(this)>>>0,a.toString(16))};_.a=0;var Qb;var Nd=Sh(172);uh(144,1,{});var Qd=Sh(144);uh(109,1,{},hc);_.A=function(a){fc(this.a,a)};var Od=Sh(109);uh(110,1,Bp,ic);_.t=function(){gc(this.a,this.b)};var Pd=Sh(110);uh(15,1,Dp,pc);_.v=function(){kc(this)};_.w=function(){return this.i<0};_.s=function(){var a;return Oh(Sd),Sd.k+'@'+(a=lk(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Sd=Sh(15);uh(154,1,Bp,qc);_.t=function(){nc(this.a)};var Rd=Sh(154);uh(4,1,{3:1,4:1});_.B=function(a){return new Error(a)};_.C=cq;_.D=function(){return Rj(Pj(Ti((this.i==null&&(this.i=ad(re,Cp,4,0,0,1)),this.i)),new mi),new Vj)};_.F=function(){return this.f};_.G=function(){return this.g};_.H=function(){tc(this,vc(this.B(uc(this,this.g))));Xc(this)};_.s=function(){return uc(this,this.G())};_.e=Ip;_.j=true;var re=Sh(4);uh(10,4,{3:1,10:1,4:1});var fe=Sh(10);uh(7,10,Jp);var ne=Sh(7);uh(57,7,Jp);var je=Sh(57);uh(78,57,Jp);var Wd=Sh(78);uh(34,78,{34:1,3:1,10:1,7:1,4:1},Ac);_.G=function(){zc(this);return this.c};_.I=function(){return rd(this.b)===rd(xc)?null:this.b};var xc;var Td=Sh(34);var Ud=Sh(0);uh(217,1,{});var Vd=Sh(217);var Cc=0,Dc=0,Ec=-1;uh(93,217,{},Sc);var Oc;var Xd=Sh(93);var Vc;uh(228,1,{});var Zd=Sh(228);uh(79,228,{},Zc);var Yd=Sh(79);uh(44,1,{44:1},Dh);_.J=function(){var a;a=this.a;if(rd(a)===rd(Bh)){a=this.a;if(rd(a)===rd(Bh)){a=this.b.J();this.a=Fh(this.a,a);this.b=null}}return a};var Bh;var $d=Sh(44);var Hh;uh(76,1,{73:1});_.s=Yp;var _d=Sh(76);uh(80,7,Jp);var he=Sh(80);uh(127,80,Jp,Lh);var ae=Sh(127);gd={3:1,74:1,27:1};var be=Sh(74);uh(41,1,{3:1,41:1});var le=Sh(41);hd={3:1,27:1,41:1};var de=Sh(227);uh(29,1,{3:1,27:1,29:1});_.p=function(a){return this===a};_.r=Zp;_.s=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ee=Sh(29);uh(59,7,Jp,_h);var ge=Sh(59);uh(28,41,{3:1,27:1,28:1,41:1},ai);_.p=function(a){return md(a,28)&&a.a==this.a};_.r=Yp;_.s=function(){return ''+this.a};_.a=0;var ie=Sh(28);var ci;uh(291,1,{});uh(84,57,Jp,fi);_.B=function(a){return new TypeError(a)};var ke=Sh(84);jd={3:1,73:1,27:1,2:1};var pe=Sh(2);uh(77,76,{73:1},li);var oe=Sh(77);uh(295,1,{});uh(71,1,{},mi);_.T=function(a){return a.e};var qe=Sh(71);uh(60,7,Jp,ni);var se=Sh(60);uh(229,1,{39:1});_.R=bq;_.W=function(){return new Ej(this,0)};_.X=function(){return new Sj(null,this.W())};_.U=function(a){throw gh(new ni('Add not supported on this collection'))};_.s=function(){var a,b,c;c=new Gj('[',']');for(b=this.S();b.Z();){a=b.$();Fj(c,a===this?'(this Collection)':a==null?Kp:yh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var te=Sh(229);uh(232,1,{215:1});_.p=function(a){var b,c,d;if(a===this){return true}if(!md(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Bi((new yi(d)).a);c.b;){b=Ai(c);if(!qi(this,b)){return false}}return true};_.r=function(){return Ui(new yi(this))};_.s=function(){var a,b,c;c=new Gj('{','}');for(b=new Bi((new yi(this)).a);b.b;){a=Ai(b);Fj(c,ri(this,a.ab())+'='+ri(this,a.bb()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ee=Sh(232);uh(101,232,{215:1});var we=Sh(101);uh(231,229,{39:1,238:1});_.W=function(){return new Ej(this,1)};_.p=function(a){var b;if(a===this){return true}if(!md(a,21)){return false}b=a;if(wi(b.a)!=this.V()){return false}return oi(this,b)};_.r=function(){return Ui(this)};var Fe=Sh(231);uh(21,231,{21:1,39:1,238:1},yi);_.S=function(){return new Bi(this.a)};_.V=_p;var ve=Sh(21);uh(22,1,{},Bi);_.Y=$p;_.$=function(){return Ai(this)};_.Z=aq;_.b=false;var ue=Sh(22);uh(230,229,{39:1,235:1});_.W=function(){return new Ej(this,16)};_._=function(a,b){throw gh(new ni('Add not supported on this list'))};_.U=function(a){this._(this.V(),a);return true};_.p=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,13)){return false}f=a;if(this.V()!=f.a.length){return false}e=new Ri(f);for(c=new Ri(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(rd(b)===rd(d)||b!=null&&q(b,d))){return false}}return true};_.r=function(){return Vi(this)};_.S=function(){return new Ci(this)};var ye=Sh(230);uh(92,1,{},Ci);_.Y=$p;_.Z=function(){return this.a<this.b.a.length};_.$=function(){return Ji(this.b,this.a++)};_.a=0;var xe=Sh(92);uh(42,229,{39:1},Di);_.S=function(){var a;a=new Bi((new yi(this.a)).a);return new Ei(a)};_.V=_p;var Ae=Sh(42);uh(96,1,{},Ei);_.Y=$p;_.Z=function(){return this.a.b};_.$=function(){var a;a=Ai(this.a);return a.bb()};var ze=Sh(96);uh(94,1,Mp);_.p=function(a){var b;if(!md(a,40)){return false}b=a;return Wi(this.a,b.ab())&&Wi(this.b,b.bb())};_.ab=Yp;_.bb=aq;_.r=function(){return vj(this.a)^vj(this.b)};_.cb=function(a){var b;b=this.b;this.b=a;return b};_.s=function(){return this.a+'='+this.b};var Be=Sh(94);uh(95,94,Mp,Fi);var Ce=Sh(95);uh(233,1,Mp);_.p=function(a){var b;if(!md(a,40)){return false}b=a;return Wi(this.b.value[0],b.ab())&&Wi(rj(this),b.bb())};_.r=function(){return vj(this.b.value[0])^vj(rj(this))};_.s=function(){return this.b.value[0]+'='+rj(this)};var De=Sh(233);uh(13,230,{3:1,13:1,39:1,235:1},Pi,Qi);_._=function(a,b){gk(this.a,a,b)};_.U=function(a){return Hi(this,a)};_.R=function(a){Ii(this,a)};_.S=function(){return new Ri(this)};_.V=function(){return this.a.length};var He=Sh(13);uh(14,1,{},Ri);_.Y=$p;_.Z=function(){return this.a<this.c.a.length};_.$=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ge=Sh(14);uh(36,101,{3:1,36:1,215:1},Xi);var Ie=Sh(36);uh(63,1,{},bj);_.R=bq;_.S=function(){return new cj(this)};_.b=0;var Ke=Sh(63);uh(64,1,{},cj);_.Y=$p;_.$=function(){return this.d=this.a[this.c++],this.d};_.Z=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Je=Sh(64);var fj;uh(61,1,{},pj);_.R=bq;_.S=function(){return new qj(this)};_.b=0;_.c=0;var Ne=Sh(61);uh(62,1,{},qj);_.Y=$p;_.$=function(){return this.c=this.a,this.a=this.b.next(),new sj(this.d,this.c,this.d.c)};_.Z=function(){return !this.a.done};var Le=Sh(62);uh(115,233,Mp,sj);_.ab=function(){return this.b.value[0]};_.bb=function(){return rj(this)};_.cb=function(a){return nj(this.a,this.b.value[0],a)};_.c=0;var Me=Sh(115);uh(117,1,{});_.Y=dq;_.db=function(){return this.d};_.eb=cq;_.d=0;_.e=0;var Re=Sh(117);uh(65,117,{});var Oe=Sh(65);uh(97,1,{});_.Y=dq;_.db=aq;_.eb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Qe=Sh(97);uh(98,97,{},Cj);_.Y=function(a){zj(this,a)};_.fb=function(a){return Aj(this,a)};var Pe=Sh(98);uh(19,1,{},Ej);_.db=Yp;_.eb=function(){Dj(this);return this.c};_.Y=function(a){Dj(this);this.d.Y(a)};_.fb=function(a){Dj(this);if(this.d.Z()){a.A(this.d.$());return true}return false};_.a=0;_.c=0;var Se=Sh(19);uh(58,1,{},Gj);_.s=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Te=Sh(58);uh(33,1,{},Hj);_.T=function(a){return a};var Ue=Sh(33);uh(37,1,{},Ij);var Ve=Sh(37);uh(116,1,{});_.c=false;var df=Sh(116);uh(23,116,{},Sj);var cf=Sh(23);uh(72,1,{},Vj);_.gb=function(a){return ad(me,Cp,1,a,5,1)};var We=Sh(72);uh(119,65,{},Xj);_.fb=function(a){this.b=false;while(!this.b&&this.c.fb(new Yj(this,a)));return this.b};_.b=false;var Ye=Sh(119);uh(122,1,{},Yj);_.A=function(a){Wj(this.a,this.b,a)};var Xe=Sh(122);uh(118,65,{},$j);_.fb=function(a){return this.b.fb(new _j(this,a))};var $e=Sh(118);uh(121,1,{},_j);_.A=function(a){Zj(this.a,this.b,a)};var Ze=Sh(121);uh(120,1,{},bk);_.A=function(a){ak(this,a)};var _e=Sh(120);uh(123,1,{},ck);_.A=function(a){};var af=Sh(123);uh(124,1,{},ek);_.A=function(a){dk(this,a)};var bf=Sh(124);uh(293,1,{});uh(290,1,{});var kk=0;var mk,nk=0,ok;uh(906,1,{});uh(929,1,{});uh(169,1,{},Bk);_.gb=function(a){return new Array(a)};var ef=Sh(169);uh(258,$wnd.Function,{},Ck);_.ib=function(a){Ak(this.a,this.b,a)};uh(6,29,{3:1,27:1,29:1,6:1},ll);var Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk,Zk,$k,_k,al,bl,cl,dl,el,fl,gl,hl,il,jl;var ff=Th(6,ml);var nl;uh(257,$wnd.Function,{},pl);_.K=function(a){return Fb(nl),nl=null,null};uh(186,1,{});var Rf=Sh(186);uh(187,186,{});_.e=0;var Vf=Sh(187);uh(188,187,Dp,xl);_.v=eq;_.w=fq;_.s=function(){var a;return Oh(pf),pf.k+'@'+(a=lk(this)>>>0,a.toString(16))};var tl=0;var pf=Sh(188);uh(189,1,Bp,yl);_.t=function(){ul(this.a)};var gf=Sh(189);uh(190,1,{},zl);_.u=function(){return wl(this.a)};var hf=Sh(190);uh(192,1,{},Al);_.u=function(){return rl(this.a)};var jf=Sh(192);uh(191,1,{},Bl);_.t=function(){sl(this.a)};var kf=Sh(191);uh(208,1,{});var Qf=Sh(208);uh(209,208,{});_.d=0;var Uf=Sh(209);uh(210,209,Dp,Hl);_.v=gq;_.w=hq;_.s=function(){var a;return Oh(of),of.k+'@'+(a=lk(this)>>>0,a.toString(16))};var Fl=0;var of=Sh(210);uh(211,1,Bp,Il);_.t=iq;var lf=Sh(211);uh(212,1,{},Jl);_.t=function(){El(this.a)};var mf=Sh(212);uh(213,1,{},Kl);_.u=function(){return Dl(this.a)};var nf=Sh(213);uh(178,1,{});_.g='';var cg=Sh(178);uh(179,178,{});_.e=0;var Xf=Sh(179);uh(180,179,Dp,Wl);_.v=eq;_.w=fq;_.s=function(){var a;return Oh(vf),vf.k+'@'+(a=lk(this)>>>0,a.toString(16))};var Ql=0;var vf=Sh(180);uh(181,1,Bp,Xl);_.t=function(){Rl(this.a)};var qf=Sh(181);uh(183,1,{},Yl);_.u=function(){return Ol(this.a)};var rf=Sh(183);uh(184,1,Bp,Zl);_.t=function(){Ll(this.a)};var sf=Sh(184);uh(182,1,{},$l);_.t=function(){sl(this.a)};var tf=Sh(182);uh(185,1,Bp,_l);_.t=function(){Ul(this.a,this.b)};var uf=Sh(185);uh(174,1,{});_.k=false;var fg=Sh(174);uh(194,174,{});_.g=0;var Zf=Sh(194);uh(195,194,Dp,vm);_.v=function(){kc(this.e)};_.w=function(){return this.e.i<0};_.s=function(){var a;return Oh(Hf),Hf.k+'@'+(a=lk(this)>>>0,a.toString(16))};var jm=0;var Hf=Sh(195);uh(196,1,Bp,wm);_.t=function(){km(this.a)};var wf=Sh(196);uh(199,1,Bp,xm);_.t=function(){kc(this.a.e)};var xf=Sh(199);uh(200,1,{},ym);_.u=function(){return hm(this.a)};var yf=Sh(200);uh(197,1,{},zm);_.u=function(){return nm(this.a)};var zf=Sh(197);uh(49,1,Bp,Am);_.t=function(){um(this.a,Vn(this.b))};var Af=Sh(49);uh(68,1,Bp,Bm);_.t=function(){em(this.a,this.b)};var Bf=Sh(68);uh(201,1,Bp,Cm);_.t=function(){om(this.a,this.b)};var Cf=Sh(201);uh(198,1,{},Dm);_.t=function(){im(this.a)};var Df=Sh(198);uh(202,1,Bp,Em);_.t=function(){pm(this.a,this.b)};var Ef=Sh(202);uh(203,1,Bp,Fm);_.t=function(){am(this.a,this.b)};var Ff=Sh(203);uh(204,1,Bp,Gm);_.t=function(){fm(this.a)};var Gf=Sh(204);uh(138,1,{});var jg=Sh(138);uh(139,138,{});_.d=0;var _f=Sh(139);uh(140,139,Dp,Nm);_.v=gq;_.w=hq;_.s=function(){var a;return Oh(Lf),Lf.k+'@'+(a=lk(this)>>>0,a.toString(16))};var Lm=0;var Lf=Sh(140);uh(141,1,Bp,Om);_.t=iq;var If=Sh(141);uh(142,1,{},Pm);_.t=function(){El(this.a)};var Jf=Sh(142);uh(143,1,{},Qm);_.u=function(){return Jm(this.a)};var Kf=Sh(143);uh(262,$wnd.Function,{},Rm);_.mb=function(a){Lo(this.a.g)};uh(171,1,{},Sm);var Mf=Sh(171);uh(87,1,{},Tm);var Nf=Sh(87);var Um;uh(193,1,{},Vm);var Of=Sh(193);uh(91,1,{},Wm);var Pf=Sh(91);var Xm;uh(263,$wnd.Function,{},Ym);_.nb=function(a){return new _m(a)};var Zm;uh(176,$wnd.React.Component,{},_m);th(rh[1],_);_.componentWillUnmount=function(){ql(this.a)};_.render=function(){return vl(this.a)};_.shouldComponentUpdate=jq;var Sf=Sh(176);uh(274,$wnd.Function,{},an);_.nb=function(a){return new dn(a)};var bn;uh(205,$wnd.React.Component,{},dn);th(rh[1],_);_.componentWillUnmount=function(){Cl(this.a)};_.render=function(){return Gl(this.a)};_.shouldComponentUpdate=kq;var Tf=Sh(205);uh(261,$wnd.Function,{},en);_.nb=function(a){return new hn(a)};var fn;uh(175,$wnd.React.Component,{},hn);th(rh[1],_);_.componentWillUnmount=function(){ql(this.a)};_.render=function(){return Sl(this.a)};_.shouldComponentUpdate=jq;var Wf=Sh(175);uh(264,$wnd.Function,{},jn);_.nb=function(a){return new mn(a)};var kn;uh(177,$wnd.React.Component,{},mn);th(rh[1],_);_.componentDidUpdate=function(a){$(this.a)&&(sm(this.a),undefined)};_.componentWillUnmount=function(){$(this.a)&&gm(this.a)};_.render=function(){return $(this.a)?lm(this.a):null};_.shouldComponentUpdate=function(a){return $(this.a)&&1==this.a.g};var Yf=Sh(177);uh(256,$wnd.Function,{},nn);_.nb=function(a){return new qn(a)};var on;uh(99,$wnd.React.Component,{},qn);th(rh[1],_);_.componentWillUnmount=function(){Cl(this.a)};_.render=function(){return Mm(this.a)};_.shouldComponentUpdate=kq;var $f=Sh(99);uh(259,$wnd.Function,{},rn);_.lb=function(a){Ml(this.a,a)};uh(260,$wnd.Function,{},sn);_.kb=function(a){Tl(this.a,a)};uh(170,1,{},tn);var ag=Sh(170);uh(90,1,{},un);var bg=Sh(90);var vn;uh(271,$wnd.Function,{},wn);_.kb=function(a){mm(this.a,a)};uh(265,$wnd.Function,{},xn);_.kb=function(a){po(this.a)};uh(267,$wnd.Function,{},yn);_.mb=function(a){qm(this.a,this.b)};uh(268,$wnd.Function,{},zn);_.mb=function(a){bm(this.a,this.b)};uh(269,$wnd.Function,{},An);_.A=function(a){cm(this.a,a)};uh(270,$wnd.Function,{},Bn);_.jb=function(a){rm(this.a,this.b)};uh(272,$wnd.Function,{},Cn);_.lb=function(a){dm(this.a,this.b,a)};uh(173,1,{},En);var dg=Sh(173);uh(88,1,{},Fn);var eg=Sh(88);var Gn;uh(255,$wnd.Function,{},Hn);_.kb=function(a){Hm(this.a,a)};uh(100,1,{},In);_.T=function(a){return Dn(new En,a)};var gg=Sh(100);uh(70,1,{},Jn);var hg=Sh(70);uh(89,1,{},Kn);var ig=Sh(89);var Ln;uh(86,1,{},Mn);var kg=Sh(86);uh(48,1,{48:1});var Rg=Sh(48);uh(155,48,{9:1,48:1},Zn);_.v=eq;_.w=fq;_.s=function(){var a;return Oh(sg),sg.k+'@'+(a=lk(this)>>>0,a.toString(16))};var sg=Sh(155);uh(156,1,Bp,$n);_.t=function(){Tn(this.a)};var lg=Sh(156);uh(158,1,{},_n);_.t=function(){On(this.a)};var mg=Sh(158);uh(159,1,{},ao);_.t=function(){Pn(this.a)};var ng=Sh(159);uh(160,1,Bp,bo);_.t=function(){Nn(this.a,this.b)};var og=Sh(160);uh(161,1,Bp,co);_.t=function(){Wn(this.a)};var pg=Sh(161);uh(67,1,Bp,eo);_.t=function(){Sn(this.a)};var qg=Sh(67);uh(157,1,{},fo);_.u=function(){var a;return a=(Ih(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var rg=Sh(157);uh(50,1,{50:1});_.d=false;var _g=Sh(50);uh(51,50,{9:1,273:1,51:1,50:1},qo);_.v=eq;_.p=function(a){return jo(this,a)};_.r=function(){return this.c.d};_.w=fq;_.s=function(){var a;return Oh(Ig),Ig.k+'@'+(a=this.c.d>>>0,a.toString(16))};var go=0;var Ig=Sh(51);uh(206,1,Bp,ro);_.t=function(){ho(this.a)};var tg=Sh(206);uh(207,1,Bp,so);_.t=function(){mo(this.a)};var ug=Sh(207);uh(47,144,{47:1});var Vg=Sh(47);uh(145,47,{9:1,47:1},Ao);_.v=lq;_.w=mq;_.s=function(){var a;return Oh(Dg),Dg.k+'@'+(a=lk(this)>>>0,a.toString(16))};var Dg=Sh(145);uh(147,1,Bp,Bo);_.t=function(){uo(this.a)};var vg=Sh(147);uh(146,1,Bp,Co);_.t=function(){xo(this.a)};var wg=Sh(146);uh(152,1,Bp,Do);_.t=function(){cc(this.a,this.b,true)};var xg=Sh(152);uh(153,1,{},Eo);_.u=function(){return to(this.a,this.c,this.b)};_.b=false;var yg=Sh(153);uh(148,1,{},Fo);_.u=function(){return yo(this.a)};var zg=Sh(148);uh(149,1,{},Go);_.u=function(){return bi(lh(Nj(dc(this.a))))};var Ag=Sh(149);uh(150,1,{},Ho);_.u=function(){return bi(lh(Nj(Oj(dc(this.a),new op))))};var Bg=Sh(150);uh(151,1,{},Io);_.u=function(){return zo(this.a)};var Cg=Sh(151);uh(45,1,{45:1});var $g=Sh(45);uh(128,45,{9:1,45:1},Po);_.v=function(){kc(this.a)};_.w=function(){return this.a.i<0};_.s=function(){var a;return Oh(Hg),Hg.k+'@'+(a=lk(this)>>>0,a.toString(16))};var Hg=Sh(128);uh(129,1,Bp,Qo);_.t=function(){Mo(this.a,this.b)};_.b=false;var Eg=Sh(129);uh(130,1,Bp,Ro);_.t=function(){Yn(this.b,this.a)};var Fg=Sh(130);uh(131,1,Bp,So);_.t=function(){No(this.a)};var Gg=Sh(131);uh(46,1,{46:1});var dh=Sh(46);uh(132,46,{9:1,46:1},$o);_.v=lq;_.w=mq;_.s=function(){var a;return Oh(Og),Og.k+'@'+(a=lk(this)>>>0,a.toString(16))};var Og=Sh(132);uh(133,1,Bp,_o);_.t=function(){Vo(this.a)};var Jg=Sh(133);uh(137,1,Bp,ap);_.t=function(){Zo(this.a,null)};var Kg=Sh(137);uh(134,1,{},bp);_.u=function(){var a;return a=Vn(this.a.g),o(Wp,a)?(lp(),ip):o(Xp,a)?(lp(),kp):(lp(),jp)};var Lg=Sh(134);uh(135,1,{},cp);_.u=function(){return Xo(this.a)};var Mg=Sh(135);uh(136,1,{},dp);_.t=function(){Yo(this.a)};var Ng=Sh(136);uh(126,1,{},ep);_.handleEvent=function(a){Qn(this.a,a)};var Pg=Sh(126);uh(106,1,{},fp);_.J=function(){return new Zn};var Qg=Sh(106);var gp;uh(30,29,{3:1,27:1,29:1,30:1},mp);var ip,jp,kp;var Sg=Th(30,np);uh(108,1,{},op);_.hb=function(a){return !lo(a)};var Tg=Sh(108);uh(104,1,{},pp);_.J=function(){return new Ao};var Ug=Sh(104);var qp;uh(112,1,{},sp);_.hb=function(a){return lo(a)};var Wg=Sh(112);uh(113,1,{},tp);_.A=function(a){wo(this.a,a)};var Xg=Sh(113);uh(111,1,{},up);_.A=function(a){Ko(this.a,a)};_.a=false;var Yg=Sh(111);uh(105,1,{},vp);_.J=function(){return new Po(this.a.J())};var Zg=Sh(105);uh(114,1,{},wp);_.hb=function(a){return Uo(this.a,a)};var ah=Sh(114);uh(107,1,{},xp);_.J=function(){return new $o(this.b.J(),this.a.J())};var bh=Sh(107);var td=Uh('D');var yp=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=ph;nh(Ah);qh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();