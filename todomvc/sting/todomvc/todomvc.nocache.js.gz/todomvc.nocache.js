function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='2FF5FBC3B8FC892066BE6DD95B5BEAD0',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '2FF5FBC3B8FC892066BE6DD95B5BEAD0';function p(){}
function ph(){}
function th(){}
function _h(){}
function Gb(){}
function Sc(){}
function Zc(){}
function uj(){}
function Ij(){}
function Qj(){}
function Rj(){}
function ok(){}
function cl(){}
function Lm(){}
function Pm(){}
function Tm(){}
function Xm(){}
function _m(){}
function _o(){}
function $o(){}
function vn(){}
function Tn(){}
function Xc(a){Wc()}
function Ah(){Ah=ph}
function Ci(){ti(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function hc(a){this.a=a}
function qc(a){this.a=a}
function qi(a){this.a=a}
function li(a){this.a=a}
function ri(a){this.a=a}
function Qh(a){this.a=a}
function $h(a){this.a=a}
function vj(a){this.a=a}
function Tj(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function xl(a){this.a=a}
function Kl(a){this.a=a}
function Ll(a){this.a=a}
function Ml(a){this.a=a}
function Nl(a){this.a=a}
function jm(a){this.a=a}
function km(a){this.a=a}
function lm(a){this.a=a}
function mm(a){this.a=a}
function qm(a){this.a=a}
function tm(a){this.a=a}
function Bm(a){this.a=a}
function Cm(a){this.a=a}
function Dm(a){this.a=a}
function Em(a){this.a=a}
function Ei(a){this.c=a}
function pi(a){this.b=a}
function dn(a){this.a=a}
function en(a){this.a=a}
function jn(a){this.a=a}
function kn(a){this.a=a}
function nn(a){this.a=a}
function un(a){this.a=a}
function Nn(a){this.a=a}
function On(a){this.a=a}
function Pn(a){this.a=a}
function Rn(a){this.a=a}
function Sn(a){this.a=a}
function eo(a){this.a=a}
function fo(a){this.a=a}
function oo(a){this.a=a}
function po(a){this.a=a}
function so(a){this.a=a}
function to(a){this.a=a}
function uo(a){this.a=a}
function vo(a){this.a=a}
function Fo(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function Ro(a){this.a=a}
function So(a){this.a=a}
function To(a){this.a=a}
function ap(a){this.a=a}
function bp(a){this.a=a}
function cp(a){this.a=a}
function Lp(){kc(this.c)}
function Np(){kc(this.b)}
function Sp(){kc(this.f)}
function w(a){--a.e;D(a)}
function Z(a){!!a&&ab(a)}
function lc(a){!!a&&a.t()}
function Qi(){this.a=Zi()}
function cj(){this.a=Zi()}
function Pj(a,b){a.a=b}
function rb(a,b){a.b=b}
function jk(a,b){a.key=b}
function hk(a,b){gk(a,b)}
function xo(a,b){hm(b,a)}
function oc(a,b){hi(a.e,b)}
function Sj(a,b){Hj(a.a,b)}
function Ql(a,b){jo(a.n,b)}
function wo(a,b){io(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function L(a,b){P(a);M(a,b)}
function Fp(a){gj(this,a)}
function Kp(a){jj(this,a)}
function Ip(a){Uh(this,a)}
function Pp(){lb(this.a.a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function _g(a){return a.e}
function Jp(){return this.e}
function Dp(){return this.a}
function Hp(){return this.b}
function Rl(a,b){return a.j=b}
function Ep(){return $j(this)}
function Vi(){Vi=ph;Ui=Xi()}
function K(){K=ph;J=new F}
function yc(){yc=ph;xc=new p}
function Pc(){Pc=ph;Oc=new Sc}
function dl(a){a.e=2;kc(a.c)}
function pl(a){a.d=2;kc(a.b)}
function Vl(a){a.g=2;kc(a.e)}
function tc(a,b){a.e=b;sc(a,b)}
function Xj(a,b){a.splice(b,1)}
function jc(a,b,c){gi(a.e,b,c)}
function Wn(a,b,c){jc(a.c,b,c)}
function oj(a,b,c){b.A(a.a[c])}
function wi(a,b){return a.a[b]}
function Dh(a){Ch(a);return a.k}
function hl(a){lb(a.b);S(a.a)}
function El(a){lb(a.a);ab(a.b)}
function Gn(a){S(a.a);ab(a.b)}
function Vn(a){ab(a.b);ab(a.a)}
function zh(a){wc.call(this,a)}
function ai(a){wc.call(this,a)}
function Gp(){return ji(this.a)}
function Mp(){return this.c.i<0}
function Op(){return this.b.i<0}
function Tp(){return this.f.i<0}
function $c(a,b){return Jh(a,b)}
function Hj(a,b){Pj(a,Gj(a.a,b))}
function jj(a,b){while(a.db(b));}
function Mj(a,b,c){b.A(a.a.R(c))}
function v(a,b,c){t(a,new I(c),b)}
function Gj(a,b){a.S(b);return a}
function U(a){nb(a.f);return W(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function bb(a){K();Zb(a);a.e=-2}
function Jm(a){this.a=a;Km=this}
function gn(a){this.a=a;hn=this}
function ji(a){return a.a.b+a.b.b}
function Qp(a){return 1==this.a.e}
function Rp(a){return 1==this.a.d}
function Zn(a){gb(a.a);return a.d}
function In(a){gb(a.b);return a.e}
function Jo(a){gb(a.d);return a.e}
function rk(a,b){a.ref=b;return a}
function ic(a,b){this.a=a;this.b=b}
function Oh(a,b){this.a=a;this.b=b}
function Oj(a,b){this.a=a;this.b=b}
function Lj(a,b){this.a=a;this.b=b}
function si(a,b){this.a=a;this.b=b}
function pk(a,b){this.a=a;this.b=b}
function Ol(a,b){this.a=a;this.b=b}
function nm(a,b){this.a=a;this.b=b}
function om(a,b){this.a=a;this.b=b}
function pm(a,b){this.a=a;this.b=b}
function rm(a,b){this.a=a;this.b=b}
function sm(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function Fm(){this.a=lk((Nm(),Mm))}
function Im(){this.a=lk((Rm(),Qm))}
function fn(){this.a=lk((Vm(),Um))}
function Fc(){Fc=ph;!!(Wc(),Vc)}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function ih(){gh==null&&(gh=[])}
function rn(){this.a=lk((Zm(),Ym))}
function wn(){this.a=lk((bn(),an))}
function Jn(a){Hn(a,(gb(a.b),a.e))}
function $k(a,b){Oh.call(this,a,b)}
function ln(a,b){this.a=a;this.b=b}
function mn(a,b){this.a=a;this.b=b}
function on(a,b){this.a=a;this.b=b}
function pn(a,b){this.a=a;this.b=b}
function Qn(a,b){this.a=a;this.b=b}
function qo(a,b){this.a=a;this.b=b}
function Do(a,b){this.a=a;this.b=b}
function Eo(a,b){this.b=a;this.a=b}
function Yo(a,b){Oh.call(this,a,b)}
function Vj(a,b,c){a.splice(b,0,c)}
function Bk(a,b){a.value=b;return a}
function sk(a,b){a.href=b;return a}
function Yh(a,b){a.a+=''+b;return a}
function _i(a,b){return a.a.get(b)}
function o(a,b){return rd(a)===rd(b)}
function od(a){return typeof a===fp}
function fi(a){return !a?null:a._()}
function Ub(a){return !a.d?a:Ub(a.d)}
function ij(a){return a!=null?s(a):0}
function rd(a){return a==null?null:a}
function Zi(){Vi();return new Ui}
function ii(a){a.a=new Qi;a.b=new cj}
function ti(a){a.a=ad(ke,hp,1,0,5,1)}
function $n(a){hm(a,(gb(a.a),!a.d))}
function Zl(a){lb(a.b);S(a.c);ab(a.a)}
function qb(a){K();pb(a);tb(a,2,true)}
function Mc(a){$wnd.clearTimeout(a)}
function jb(a){this.c=new Ci;this.b=a}
function ck(){ck=ph;_j=new p;bk=new p}
function vk(a,b){a.checked=b;return a}
function wk(a,b){a.onBlur=b;return a}
function tk(a,b){a.onClick=b;return a}
function xk(a,b){a.onChange=b;return a}
function Wj(a,b){Uj(b,0,a,0,b.length)}
function gc(a,b){cc(a,b,false);fb(a.c)}
function gk(a,b){for(var c in a){b(c)}}
function zo(a,b){vi(ec(a.b),new bp(b))}
function Vh(a,b){return a.charCodeAt(b)}
function md(a,b){return a!=null&&kd(a,b)}
function B(a,b,c){return u(a,c,2048,b)}
function ed(a,b,c){return {l:a,m:b,h:c}}
function A(a,b,c){u(a,new H(b),c,null)}
function yk(a,b){a.onKeyDown=b;return a}
function ik(a,b){a.props['a']=b;return a}
function Ch(a){if(a.k!=null){return}Lh(a)}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function $(a){return !(md(a,9)&&a.w())}
function $j(a){return a.$H||(a.$H=++Zj)}
function uk(a){return a.autoFocus=true,a}
function qd(a){return typeof a==='string'}
function nd(a){return typeof a==='boolean'}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Q(){this.a=ad(ke,hp,1,100,5,1)}
function wc(a){this.g=a;rc(this);this.G()}
function Fj(a,b){yj.call(this,a);this.a=b}
function sn(a,b){this.a=a;this.b=b;tn=this}
function Ki(){this.a=new Qi;this.b=new cj}
function gj(a,b){while(a.X()){Sj(b,a.Y())}}
function fc(a,b){oc(b.c,a);md(b,9)&&b.v()}
function Si(a,b){var c;c=a[sp];c.call(a,b)}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function Gc(a,b,c){return a.apply(b,c);var d}
function mo(a){return Rh(T(a.e).a-T(a.a).a)}
function Io(a){lb(a.a);S(a.b);S(a.c);ab(a.d)}
function bo(a){A((K(),K(),J),new fo(a),wp)}
function yo(a){A((K(),K(),J),new Fo(a),wp)}
function fm(a){A((K(),K(),J),new tm(a),wp)}
function Kn(a){A((K(),K(),J),new Rn(a),wp)}
function Th(){Th=ph;Sh=ad(he,hp,28,256,0,1)}
function Gh(a){var b;b=Fh(a);Nh(a,b);return b}
function rc(a){a.j&&a.e!==np&&a.G();return a}
function Ck(a,b){a.onDoubleClick=b;return a}
function ui(a,b){a.a[a.a.length]=b;return true}
function fj(a,b,c){this.a=a;this.b=b;this.c=c}
function xh(a,b,c,d){a.addEventListener(b,c,d)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Gl(a,b){A((K(),K(),J),new Ol(a,b),wp)}
function _l(a,b){A((K(),K(),J),new sm(a,b),wp)}
function dm(a,b){A((K(),K(),J),new pm(a,b),wp)}
function em(a,b){A((K(),K(),J),new om(a,b),wp)}
function gm(a,b){A((K(),K(),J),new nm(a,b),wp)}
function jo(a,b){A((K(),K(),J),new qo(a,b),wp)}
function Bo(a,b){A((K(),K(),J),new Do(a,b),wp)}
function mj(a,b){while(a.c<a.d){oj(a,b,a.c++)}}
function Db(a){while(true){if(!Cb(a)){break}}}
function ko(a){Uh(new qi(a.g),new hc(a));ii(a.g)}
function Go(a){return o(Bp,a)||o(Cp,a)||o('',a)}
function cd(a){return Array.isArray(a)&&a.ob===th}
function qj(a){if(!a.d){a.d=a.b.Q();a.c=a.b.T()}}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Hl(a,b){var c;c=b.target;Il(a,c.value)}
function zj(a,b){var c;return Dj(a,(c=new Ci,c))}
function $i(a,b){return !(a.a.get(b)===undefined)}
function Gi(a){return new Fj(null,Fi(a,a.length))}
function ld(a){return !Array.isArray(a)&&a.ob===th}
function lo(a){return Ah(),0!=T(a.e).a?true:false}
function Fi(a,b){return kj(b,a.length),new pj(a,b)}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function yi(a,b){var c;c=a.a[b];Xj(a.a,b);return c}
function ni(a){var b;b=a.a.Y();a.b=mi(a);return b}
function Ih(a){var b;b=Fh(a);b.j=a;b.e=1;return b}
function fl(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function rl(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Jj(a,b,c){if(a.a.fb(c)){a.b=true;b.A(c)}}
function ro(a,b){this.a=a;this.c=b;this.b=false}
function jl(a){return Ah(),T(a.f.b).a>0?true:false}
function am(a){return Ah(),Jo(a.o)==a.i?true:false}
function zm(a){return B((K(),K(),J),a.a,new Dm(a))}
function tl(a){return B((K(),K(),J),a.a,new xl(a))}
function Fl(a){return B((K(),K(),J),a.a,new Ll(a))}
function il(a){return B((K(),K(),J),a.b,new nl(a))}
function $l(a){return B((K(),K(),J),a.b,new lm(a))}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function ho(a){S(a.d);S(a.e);S(a.a);S(a.b);ab(a.c)}
function wj(a){if(!a.b){xj(a);a.c=true}else{wj(a.b)}}
function Xl(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function fk(){if(ak==256){_j=bk;bk=new p;ak=0}++ak}
function Wc(){Wc=ph;var a;!Yc();a=new Zc;Vc=a}
function wh(){wh=ph;vh=$wnd.goog.global.document}
function um(a,b){var c;c=b.target;Bo(a.f,c.checked)}
function hm(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function Il(a,b){var c;c=a.g;if(b!=c){a.g=b;fb(a.b)}}
function Ln(a,b){var c;c=a.e;if(b!=c){a.e=b;fb(a.b)}}
function Ai(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Ak(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ki(a,b){if(b){return di(a.a,b)}return false}
function Bj(a,b){xj(a);return new Fj(a,new Kj(b,a.a))}
function Cj(a,b){xj(a);return new Fj(a,new Nj(b,a.a))}
function Hn(a,b){A((K(),K(),J),new Qn(a,b),75497472)}
function yh(a,b,c,d){a.removeEventListener(b,c,d)}
function Gm(a,b,c){this.a=a;this.b=b;this.c=c;Hm=this}
function xn(a,b,c){this.a=a;this.b=b;this.c=c;yn=this}
function pj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function lj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function rj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function bm(a,b){Mo(a.o,b);A((K(),K(),J),new nm(a,b),wp)}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Fn(a){var b;V(a.a);b=T(a.a);o(a.f,b)&&Ln(a,b)}
function Ji(a,b){return rd(a)===rd(b)||a!=null&&q(a,b)}
function ei(a,b){return b===a?'(this Map)':b==null?pp:sh(b)}
function uc(a,b){var c;c=Dh(a.mb);return b==null?c:c+': '+b}
function Hh(a,b){var c;c=Fh(a);Nh(a,c);c.e=b?8:0;return c}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function Kh(a){if(a.O()){return null}var b=a.j;return lh[b]}
function fh(a){if(od(a)){return a|0}return a.l|a.m<<22}
function yj(a){if(!a){this.b=null;new Ci}else{this.b=a}}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function Pl(a,b){var c;if(T(a.c)){c=b.target;hm(a,c.value)}}
function Uh(a,b){var c,d;for(d=a.Q();d.X();){c=d.Y();b.A(c)}}
function cm(a,b){A((K(),K(),J),new nm(a,b),wp);Mo(a.o,null)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&lp)&&D((null,J))}
function xj(a){if(a.b){xj(a.b)}else if(a.c){throw _g(new Ph)}}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function Zo(){Xo();return dd($c(Pg,1),hp,30,0,[Uo,Wo,Vo])}
function Zm(){Zm=ph;var a;Ym=(a=qh(Xm.prototype.lb,Xm,[]),a)}
function Nm(){Nm=ph;var a;Mm=(a=qh(Lm.prototype.lb,Lm,[]),a)}
function Rm(){Rm=ph;var a;Qm=(a=qh(Pm.prototype.lb,Pm,[]),a)}
function Vm(){Vm=ph;var a;Um=(a=qh(Tm.prototype.lb,Tm,[]),a)}
function bn(){bn=ph;var a;an=(a=qh(_m.prototype.lb,_m,[]),a)}
function rh(a){function b(){}
;b.prototype=a||{};return new b}
function zk(a){a.placeholder='What needs to be done?';return a}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function Di(a){ti(this);Wj(this.a,ci(a,ad(ke,hp,1,ji(a.a),5,1)))}
function Ni(a,b){var c;return Li(b,Mi(a,b==null?0:(c=s(b),c|0)))}
function Mi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Jh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function nh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function nk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function nc(a){lc(a.g);!!a.e&&mc(a);Z(a.a);Z(a.c);lc(a.b);lc(a.f)}
function dc(a){gb(a.c);return new Fj(null,new rj(new qi(a.g),0))}
function Ao(a){zj(Bj(dc(a.b),new _o),new vj(new uj)).P(new ap(a.b))}
function Bn(a){xh((wh(),$wnd.goog.global.window),zp,a.d,false)}
function Cn(a){yh((wh(),$wnd.goog.global.window),zp,a.d,false)}
function Co(a){this.b=a;K();this.a=new pc(0,null,null,false,false)}
function Ri(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Nj(a,b){lj.call(this,b.cb(),b.bb()&-6);this.a=a;this.b=b}
function Kj(a,b){lj.call(this,b.cb(),b.bb()&-16449);this.a=a;this.c=b}
function cb(a,b){var c,d;ui(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Dn(a,b){b.preventDefault();A((K(),K(),J),new Sn(a),wp)}
function hi(a,b){return qd(b)?b==null?Pi(a.a,null):bj(a.b,b):Pi(a.a,b)}
function sj(a,b){!a.a?(a.a=new $h(a.d)):Yh(a.a,a.b);Yh(a.a,b);return a}
function nj(a,b){if(a.c<a.d){oj(a,b,a.c++);return true}return false}
function Dj(a,b){var c;wj(a);c=new Qj;c.a=b;a.a.W(new Tj(c));return c.a}
function Aj(a){var b;wj(a);b=0;while(a.a.db(new Rj)){b=ah(b,1)}return b}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function io(a,b){var c;return u((K(),K(),J),new ro(a,b),wp,(c=null,c))}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Sm(a){$wnd.React.Component.call(this,a);this.a=new ul(this,Km.a)}
function Wm(a){$wnd.React.Component.call(this,a);this.a=new Jl(this,hn.a)}
function dj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function tj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function oi(a){this.d=a;this.c=new dj(this.d.b);this.a=this.c;this.b=mi(this)}
function Ej(a,b){var c;c=zj(a,new vj(new uj));return Bi(c,b.eb(c.a.length))}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function vi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.A(c)}}
function yl(a){var b;b=Xh((gb(a.b),a.g));if(b.length>0){wo(a.f,b);Il(a,'')}}
function Ko(a){var b;return b=T(a.b),zj(Bj(dc(a.i),new cp(b)),new vj(new uj))}
function An(a,b){a.f=b;o(b,T(a.a))&&Ln(a,b);En(b);A((K(),K(),J),new Sn(a),wp)}
function Jb(b){try{nb(b.b.a)}catch(a){a=$g(a);if(!md(a,4))throw _g(a)}}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ho(a,b){return (Xo(),Vo)==a||(Uo==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function gi(a,b,c){return qd(b)?b==null?Oi(a.a,null,c):aj(a.b,b,c):Oi(a.a,b,c)}
function Yj(a,b){return _c(b)!=10&&dd(r(b),b.nb,b.__elementTypeId$,_c(b),a),a}
function Xn(a,b){var c;if(md(b,46)){c=b;return a.c.d==c.c.d}else{return false}}
function zi(a,b){var c;c=xi(a,b,0);if(c==-1){return false}Xj(a.a,c);return true}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function xi(a,b,c){for(;c<a.a.length;++c){if(Ji(b,a.a[c])){return c}}return -1}
function ej(a){if(a.a.c!=a.c){return _i(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function S(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function ab(a){if(-2!=a.e){u((K(),K(),J),new H(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function kc(a){if(a.i>=0){a.i=-2;u((K(),K(),J),new H(new qc(a)),67108864,null)}}
function W(a){if(a.b){if(md(a.b,8)){throw _g(a.b)}else{throw _g(a.b)}}return a.k}
function sb(b){if(b){try{b.t()}catch(a){a=$g(a);if(md(a,4)){K()}else throw _g(a)}}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function Qc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Uc(b,c)}while(a.a);a.a=c}}
function Rc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function Pb(){var a;this.a=ad(yd,hp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function $m(a){$wnd.React.Component.call(this,a);this.a=new im(this,tn.a,tn.b)}
function cn(a){$wnd.React.Component.call(this,a);this.a=new Am(this,yn.a,yn.b,yn.c)}
function Om(a){$wnd.React.Component.call(this,a);this.a=new kl(this,Hm.a,Hm.b,Hm.c)}
function pd(a){return a!=null&&(typeof a===ep||typeof a==='function')&&!(a.ob===th)}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ec(a){return gb(a.c),zj(new Fj(null,new rj(new qi(a.g),0)),new vj(new uj))}
function zl(a,b){if(13==b.keyCode){b.preventDefault();A((K(),K(),J),new Ml(a),wp)}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ci);ui(a.b,b)}}}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Ci);a.c=c.c}b.d=true;ui(a.c,b)}
function Nh(a,b){var c;if(!a){return}b.j=a;var d=Kh(b);if(!d){lh[a]=[b];return}d.mb=b}
function qh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function qn(a,b){jk(a.a,(b?Rh(b.c.d):null)+(''+(Ch(dg),dg.k)));ik(a.a,b);return a.a}
function Fh(a){var b;b=new Eh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function lk(a){var b;b=kk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Hi(a){var b,c,d;d=0;for(c=new oi(a.a);c.b;){b=ni(c);d=d+(b?s(b):0);d=d|0}return d}
function pb(a){var b,c;for(c=new Ei(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function bi(a,b){var c,d;for(d=new oi(b.a);d.b;){c=ni(d);if(!ki(a,c)){return false}}return true}
function bj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Si(a.a,b);--a.b}return c}
function go(a,b,c){var d;d=new co(b,c);Wn(d,a,new ic(a,d));gi(a.g,Rh(d.c.d),d);fb(a.c);return d}
function cc(a,b,c){var d;d=hi(a.g,b?Rh(b.c.d):null);if(null!=d){oc(b.c,a);c&&!!b&&kc(b.c);fb(a.c)}}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:jp)|(0==(c&6291456)?!a?lp:mp:0)|0|0|0)}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?mp:0)|(0!=(b&229376)?0:98304)}
function kh(a,b){typeof window===ep&&typeof window['$gwt']===ep&&(window['$gwt'][a]=b)}
function kj(a,b){if(0>a||a>b){throw _g(new zh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function hh(){ih();var a=gh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Ph(){wc.call(this,"Stream already terminated, can't be modified or used")}
function uh(){new zn;$wnd.ReactDOM.render((new wn).a,(wh(),vh).getElementById('app'),null)}
function Xo(){Xo=ph;Uo=new Yo('ACTIVE',0);Wo=new Yo('COMPLETED',1);Vo=new Yo('ALL',2)}
function Lo(a){var b;b=T(a.g.a);o(Bp,b)||o(Cp,b)||o('',b)?Hn(a.g,b):Go(In(a.g))?Kn(a.g):Hn(a.g,'')}
function bh(a){var b;b=a.h;if(b==0){return a.l+a.m*mp}if(b==1048575){return a.l+a.m*mp-qp}return a}
function $g(a){var b;if(md(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function mi(a){if(a.a.X()){return true}if(a.a!=a.c){return false}a.a=new Ri(a.d.a);return a.a.X()}
function eh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=qp;d=1048575}c=sd(e/mp);b=sd(e-c*mp);return ed(b,c,d)}
function Li(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ji(a,c.$())){return c}}return null}
function dd(a,b,c,d,e){e.mb=a;e.nb=b;e.ob=th;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function aj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Mo(a,b){var c;c=a.e;if(!(b==c||!!b&&Xn(b,c))){!!c&&oc(c.c,a);a.e=b;!!b&&Wn(b,a,new Po(a));fb(a.d)}}
function Ul(a){var b;b=T(a.c);if(!a.k&&b){a.k=true;gm(a,a.i);a.j.focus();a.j.select()}else a.k&&!b&&(a.k=false)}
function db(a,b){var c,d;d=a.c;zi(d,b);!!a.b&&jp!=(a.b.c&kp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function Sl(a,b,c){27==c.which?A((K(),K(),J),new rm(a,b),wp):13==c.which&&A((K(),K(),J),new om(a,b),wp)}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function bl(){if(!al){al=(++(K(),K(),J).e,new Gb);$wnd.Promise.resolve(null).then(qh(cl.prototype.I,cl,[]))}}
function Ac(a){yc();rc(this);this.e=a;sc(this,a);this.g=a==null?pp:sh(a);this.a='';this.b=a;this.a=''}
function Eh(){this.g=Bh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function r(a){return qd(a)?ne:od(a)?ce:nd(a)?ae:ld(a)?a.mb:cd(a)?a.mb:a.mb||Array.isArray(a)&&$c(Ud,1)||Ud}
function s(a){return qd(a)?ek(a):od(a)?sd(a):nd(a)?a?1231:1237:ld(a)?a.r():cd(a)?$j(a):!!a&&!!a.hashCode?a.hashCode():$j(a)}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&jp)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(jp==(b&kp)?0:524288)|(0==(b&6291456)?jp==(b&kp)?mp:lp:0)|0|268435456|0)}
function fd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ed(c&4194303,d&4194303,e&1048575)}
function ah(a,b){var c;if(od(a)&&od(b)){c=a+b;if(-17592186044416<c&&c<qp){return c}}return bh(fd(od(a)?eh(a):a,od(b)?eh(b):b))}
function Rh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Th(),Sh)[b];!c&&(c=Sh[b]=new Qh(a));return c}return new Qh(a)}
function sh(a){var b;if(Array.isArray(a)&&a.ob===th){return Dh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function ek(a){ck();var b,c,d;c=':'+a;d=bk[c];if(d!=null){return sd(d)}d=_j[c];b=d==null?dk(a):sd(d);fk();bk[c]=b;return b}
function Ii(a){var b,c,d;d=1;for(c=new Ei(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function mc(a){var b,c,d;for(c=new Ei(new Di(new li(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.$();md(d,9)&&d.w()||b._().t()}}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=yi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Tl(a,b){var c;c=(gb(a.a),a.d);if(null!=c&&c.length!=0){A((K(),K(),J),new Eo(b,c),wp);Mo(a.o,null);hm(a,c)}else{jo(a.n,b)}}
function ul(a,b){var c;this.e=b;this.c=a;K();c=++sl;this.b=new pc(c,null,new vl(this),false,false);this.a=new wb(null,new wl(this),vp)}
function pc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ki:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new jb((f=null,K(),f)),g):null;this.c=null}
function _k(){Zk();return dd($c(df,1),hp,6,0,[Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk])}
function Mh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Bi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Yj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return qd(a)?o(a,b):od(a)?rd(a)===rd(b):nd(a)?rd(a)===rd(b):ld(a)?a.p(b):cd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function kd(a,b){if(qd(a)){return !!jd[b]}else if(a.nb){return !!a.nb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function qk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function T(a){a.j?hb(a.e):gb(a.e);if(ub(a.f)){if(a.j&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ei(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Xh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ci(a,b){var c,d,e,f;f=ji(a.a);b.length<f&&(b=Yj(new Array(f),b));e=b;d=new oi(a.a);for(c=0;c<f;++c){e[c]=ni(d)}b.length>f&&(b[f]=null);return b}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.t(),null)}finally{bc()}return f}catch(a){a=$g(a);if(md(a,4)){e=a;throw _g(e)}else throw _g(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.u()}else{ac(b,e);try{g=c.u()}finally{bc()}}return g}catch(a){a=$g(a);if(md(a,4)){f=a;throw _g(f)}else throw _g(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.i=c;this.k=null;this.j=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);jp==(d&kp)&&mb(this.f)}
function Am(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.c=a;K();e=++ym;this.b=new pc(e,null,new Bm(this),false,false);this.a=new wb(null,new Cm(this),vp)}
function Jl(a,b){var c,d,e;this.f=b;this.d=a;K();c=++Dl;this.c=new pc(c,null,new Kl(this),false,false);this.b=(e=new jb((d=null,d)),e);this.a=new wb(null,new Nl(this),vp)}
function co(a,b){var c,d,e,f,g;this.e=a;this.d=b;K();c=++Un;this.c=new pc(c,null,new eo(this),true,true);this.b=(g=new jb((e=null,e)),g);this.a=(f=new jb((d=null,d)),f)}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function jh(b,c,d,e){ih();var f=gh;$moduleName=c;$moduleBase=d;Zg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{dp(g)()}catch(a){b(c,a)}}else{dp(g)()}}
function kk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Xi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Yi()}}
function ql(a){var b,c;a.d=0;bl();c=(b=T(a.e.e).a,mk('span',qk(new $wnd.Object,dd($c(ne,1),hp,2,6,['todo-count'])),[mk('strong',null,[b]),' item'+(b==1?'':'s')+' left']));return c}
function mh(){lh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].pb()&&(c=Tc(c,g)):g[0].pb()}catch(a){a=$g(a);if(md(a,4)){d=a;Fc();Lc(md(d,34)?d.H():d)}else throw _g(a)}}return c}
function Bl(a){var b;a.e=0;bl();b=mk(xp,uk(xk(yk(Bk(zk(qk(new $wnd.Object,dd($c(ne,1),hp,2,6,['new-todo']))),(gb(a.b),a.g)),qh(dn.prototype.jb,dn,[a])),qh(en.prototype.ib,en,[a]))),null);return b}
function zc(a){var b;if(a.c==null){b=rd(a.b)===rd(xc)?null:a.b;a.d=b==null?pp:pd(b)?b==null?null:b.name:qd(b)?'String':Dh(r(b));a.a=a.a+': '+(pd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.k;try{d=b.c.u();if(!(rd(e)===rd(d)||e!=null&&q(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=$g(a);if(md(a,10)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw _g(c)}else throw _g(a)}}
function Uj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Oi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Li(b,e);if(f){return f.ab(c)}}e[e.length]=new si(b,c);++a.b;return null}
function zn(){this.a=new no;new Jm(this.a);this.b=new Mn;this.c=new Co(this.a);this.d=new No(this.a,this.b);new Gm(this.a,this.c,this.d);new xn(this.a,this.c,this.d);new gn(this.c);new sn(this.a,this.d)}
function kl(a,b,c,d){var e;this.f=b;this.g=c;this.i=d;this.d=a;K();e=++gl;this.c=new pc(e,null,new ll(this),false,false);this.a=new X(new ml(this),null,null,136478720);this.b=new wb(null,new ol(this),vp)}
function dk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Vh(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{b.e.t()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=$g(a);if(md(a,4)){K()}else throw _g(a)}}}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=ad(ke,hp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function vb(a,b,c,d){this.b=new Ci;this.f=new Kb(new zb(this),d&6520832|262144|jp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&lp)&&D((null,J)))}
function Pi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ji(b,e.$())){if(d.length==1){d.length=0;Si(a.a,g)}else{d.splice(h,1)}--a.b;return e._()}}return null}
function oh(a,b,c){var d=lh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=lh[b]),rh(h));_.nb=c;!b&&(_.ob=th);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.mb=f)}
function Lh(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Mh('.',[c,Mh('$',d)]);a.b=Mh('.',[c,Mh('.',d)]);a.i=d[d.length-1]}
function di(a,b){var c,d,e;c=b.$();e=b._();d=qd(c)?c==null?fi(Ni(a.a,null)):_i(a.b,c):fi(Ni(a.a,c));if(!(rd(e)===rd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(qd(c)?c==null?!!Ni(a.a,null):$i(a.b,c):!!Ni(a.a,c))){return false}return true}
function En(a){var b;if(0==a.length){b=(wh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',vh.title,b)}else{(wh(),$wnd.goog.global.window).location.hash=a}}
function No(a,b){var c,d;this.i=a;this.g=b;K();this.f=new pc(0,null,new Oo(this),false,false);this.d=(d=new jb((c=null,c)),d);this.b=new X(new Qo(this),null,null,Ap);this.c=new X(new Ro(this),null,null,Ap);this.a=new wb(new So(this),null,681574400);D((null,J))}
function no(){var a;this.g=new Ki;K();this.f=new pc(0,new po(this),new oo(this),false,false);this.c=(a=new jb(null),a);this.d=new X(new so(this),null,null,Ap);this.e=new X(new to(this),null,null,Ap);this.a=new X(new uo(this),null,null,Ap);this.b=new X(new vo(this),null,null,Ap)}
function Mn(){var a,b,c;this.d=new To(this);this.f=this.e=(c=(wh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));K();this.c=new pc(0,null,new Nn(this),false,false);this.b=(b=new jb((a=null,a)),b);this.a=new X(new Tn,new On(this),new Pn(this),35651584)}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ei(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=$g(a);if(!md(a,4))throw _g(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function im(a,b,c){var d,e,f;this.n=b;this.o=c;this.f=a;this.i=a.props['a'];K();d=++Yl;this.e=new pc(d,null,new jm(this),false,false);this.a=(f=new jb((e=null,e)),f);this.c=new X(new mm(this),null,null,136478720);this.b=new wb(null,new qm(this),vp);Wn(this.i,this,new km(this));gm(this,this.i);D((null,J))}
function mk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;hk(b,qh(pk.prototype.gb,pk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=kk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function Wi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}vi(a.b,new Bb(a));a.b.a=ad(ke,hp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function wm(a){var b;a.d=0;bl();b=mk('div',null,[mk('div',null,[mk(yp,qk(new $wnd.Object,dd($c(ne,1),hp,2,6,[yp])),[mk('h1',null,['todos']),(new fn).a]),T(a.e.d)?mk('section',qk(new $wnd.Object,dd($c(ne,1),hp,2,6,[yp])),[mk(xp,xk(Ak(qk(new $wnd.Object,dd($c(ne,1),hp,2,6,['toggle-all'])),(Zk(),Ek)),qh(un.prototype.ib,un,[a])),null),mk('ul',qk(new $wnd.Object,dd($c(ne,1),hp,2,6,['todo-list'])),Ej(Cj(T(a.g.c).V(),new vn),new ok))]):null,T(a.e.d)?(new Fm).a:null])]);return b}
function Zk(){Zk=ph;Dk=new $k(tp,0);Ek=new $k('checkbox',1);Fk=new $k('color',2);Gk=new $k('date',3);Hk=new $k('datetime',4);Ik=new $k('email',5);Jk=new $k('file',6);Kk=new $k('hidden',7);Lk=new $k('image',8);Mk=new $k('month',9);Nk=new $k(fp,10);Ok=new $k('password',11);Pk=new $k('radio',12);Qk=new $k('range',13);Rk=new $k('reset',14);Sk=new $k('search',15);Tk=new $k('submit',16);Uk=new $k('tel',17);Vk=new $k('text',18);Wk=new $k('time',19);Xk=new $k('url',20);Yk=new $k('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=wi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ai(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=wi(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){yi(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Ci)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&jp!=(k.b.c&kp)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function el(a){var b,c;a.e=0;bl();c=(b=T(a.i.b),mk('footer',qk(new $wnd.Object,dd($c(ne,1),hp,2,6,['footer'])),[(new Im).a,mk('ul',qk(new $wnd.Object,dd($c(ne,1),hp,2,6,['filters'])),[mk('li',null,[mk('a',sk(qk(new $wnd.Object,dd($c(ne,1),hp,2,6,[(Xo(),Vo)==b?up:null])),'#'),['All'])]),mk('li',null,[mk('a',sk(qk(new $wnd.Object,dd($c(ne,1),hp,2,6,[Uo==b?up:null])),'#active'),['Active'])]),mk('li',null,[mk('a',sk(qk(new $wnd.Object,dd($c(ne,1),hp,2,6,[Wo==b?up:null])),'#completed'),['Completed'])])]),T(a.a)?mk(tp,tk(qk(new $wnd.Object,dd($c(ne,1),hp,2,6,['clear-completed'])),qh(Em.prototype.kb,Em,[a])),['Clear Completed']):null]));return c}
function Wl(a){var b,c,d;a.g=0;bl();b=(c=a.i,d=(gb(c.a),c.d),mk('li',qk(new $wnd.Object,dd($c(ne,1),hp,2,6,[d?'checked':null,T(a.c)?'editing':null])),[mk('div',qk(new $wnd.Object,dd($c(ne,1),hp,2,6,['view'])),[mk(xp,xk(vk(Ak(qk(new $wnd.Object,dd($c(ne,1),hp,2,6,['toggle'])),(Zk(),Ek)),d),qh(kn.prototype.ib,kn,[c])),null),mk('label',Ck(new $wnd.Object,qh(ln.prototype.kb,ln,[a,c])),[(gb(c.b),c.e)]),mk(tp,tk(qk(new $wnd.Object,dd($c(ne,1),hp,2,6,['destroy'])),qh(mn.prototype.kb,mn,[a,c])),null)]),mk(xp,yk(xk(wk(Bk(qk(rk(new $wnd.Object,qh(nn.prototype.A,nn,[a])),dd($c(ne,1),hp,2,6,['edit'])),(gb(a.a),a.d)),qh(on.prototype.hb,on,[a,c])),qh(jn.prototype.ib,jn,[a])),qh(pn.prototype.jb,pn,[a,c])),null)]));return b}
function Yi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[sp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Wi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[sp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var ep='object',fp='number',gp={5:1},hp={3:1},ip={9:1},jp=1048576,kp=1835008,lp=2097152,mp=4194304,np='__noinit__',op={3:1,10:1,8:1,4:1},pp='null',qp=17592186044416,rp={40:1},sp='delete',tp='button',up='selected',vp=1411518464,wp=142606336,xp='input',yp='header',zp='hashchange',Ap=136314880,Bp='active',Cp='completed';var _,lh,gh,Zg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;mh();oh(1,null,{},p);_.p=function(a){return o(this,a)};_.q=function(){return this.mb};_.r=Ep;_.s=function(){var a;return Dh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.p(a)};_.hashCode=function(){return this.r()};_.toString=function(){return this.s()};var gd,hd,jd;oh(51,1,{},Eh);_.J=function(a){var b;b=new Eh;b.e=4;a>1?(b.c=Jh(this,a-1)):(b.c=this);return b};_.K=function(){Ch(this);return this.b};_.L=function(){return Dh(this)};_.M=function(){Ch(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.s=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Ch(this),this.k)};_.e=0;_.g=0;var Bh=1;var ke=Gh(1);var be=Gh(51);oh(77,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var xd=Gh(77);oh(78,1,gp,G);_.t=function(){Db(this.a)};var ud=Gh(78);oh(35,1,{},H);_.u=function(){return this.a.t(),null};var vd=Gh(35);oh(79,1,{},I);var wd=Gh(79);var J;oh(43,1,{43:1},Q);_.b=0;_.c=false;_.d=0;var yd=Gh(43);oh(225,1,ip);_.s=function(){var a;return Dh(this.mb)+'@'+(a=s(this)>>>0,a.toString(16))};var Bd=Gh(225);oh(18,225,ip,X);_.v=function(){S(this)};_.w=Dp;_.a=false;_.d=0;_.j=false;var Ad=Gh(18);oh(129,1,{},Y);_.u=function(){return U(this.a)};var zd=Gh(129);oh(16,225,{9:1,16:1},jb);_.v=function(){ab(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Dd=Gh(16);oh(128,1,gp,kb);_.t=function(){bb(this.a)};var Cd=Gh(128);oh(17,225,{9:1,17:1},wb,xb);_.v=function(){lb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Id=Gh(17);oh(130,1,{},yb);_.t=function(){R(this.a)};var Ed=Gh(130);oh(131,1,gp,zb);_.t=function(){nb(this.a)};var Fd=Gh(131);oh(132,1,gp,Ab);_.t=function(){qb(this.a)};var Gd=Gh(132);oh(133,1,{},Bb);_.A=function(a){ob(this.a,a)};var Hd=Gh(133);oh(143,1,{},Eb);_.a=0;_.b=0;_.c=0;var Jd=Gh(143);oh(163,1,ip,Gb);_.v=function(){Fb(this)};_.w=Dp;_.a=false;var Kd=Gh(163);oh(59,225,{9:1,59:1},Kb);_.v=function(){Hb(this)};_.w=function(){return 2==(3&this.a)};_.a=0;var Md=Gh(59);oh(142,1,{},Pb);var Ld=Gh(142);oh(145,1,{},_b);_.s=function(){var a;return Ch(Nd),Nd.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.a=0;var Qb;var Nd=Gh(145);oh(96,1,{});var Qd=Gh(96);oh(85,1,{},hc);_.A=function(a){fc(this.a,a)};var Od=Gh(85);oh(86,1,gp,ic);_.t=function(){gc(this.a,this.b)};var Pd=Gh(86);oh(15,1,ip,pc);_.v=function(){kc(this)};_.w=function(){return this.i<0};_.s=function(){var a;return Ch(Sd),Sd.k+'@'+(a=$j(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Sd=Gh(15);oh(127,1,gp,qc);_.t=function(){nc(this.a)};var Rd=Gh(127);oh(4,1,{3:1,4:1});_.B=Jp;_.C=function(){return Ej(Cj(Gi((this.i==null&&(this.i=ad(pe,hp,4,0,0,1)),this.i)),new _h),new Ij)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){tc(this,vc(new Error(uc(this,this.g))));Xc(this)};_.s=function(){return uc(this,this.F())};_.e=np;_.j=true;var pe=Gh(4);oh(10,4,{3:1,10:1,4:1});var ee=Gh(10);oh(8,10,op);var le=Gh(8);oh(72,8,op);var ie=Gh(72);oh(73,72,op);var Wd=Gh(73);oh(34,73,{34:1,3:1,10:1,8:1,4:1},Ac);_.F=function(){zc(this);return this.c};_.H=function(){return rd(this.b)===rd(xc)?null:this.b};var xc;var Td=Gh(34);var Ud=Gh(0);oh(211,1,{});var Vd=Gh(211);var Cc=0,Dc=0,Ec=-1;oh(82,211,{},Sc);var Oc;var Xd=Gh(82);var Vc;oh(222,1,{});var Zd=Gh(222);oh(74,222,{},Zc);var Yd=Gh(74);var vh;oh(70,1,{67:1});_.s=Dp;var $d=Gh(70);oh(76,8,op);var ge=Gh(76);oh(156,76,op,zh);var _d=Gh(156);gd={3:1,68:1,27:1};var ae=Gh(68);oh(41,1,{3:1,41:1});var je=Gh(41);hd={3:1,27:1,41:1};var ce=Gh(221);oh(29,1,{3:1,27:1,29:1});_.p=function(a){return this===a};_.r=Ep;_.s=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=Gh(29);oh(75,8,op,Ph);var fe=Gh(75);oh(28,41,{3:1,27:1,28:1,41:1},Qh);_.p=function(a){return md(a,28)&&a.a==this.a};_.r=Dp;_.s=function(){return ''+this.a};_.a=0;var he=Gh(28);var Sh;oh(284,1,{});jd={3:1,67:1,27:1,2:1};var ne=Gh(2);oh(71,70,{67:1},$h);var me=Gh(71);oh(288,1,{});oh(65,1,{},_h);_.R=function(a){return a.e};var oe=Gh(65);oh(53,8,op,ai);var qe=Gh(53);oh(223,1,{39:1});_.P=Ip;_.U=function(){return new rj(this,0)};_.V=function(){return new Fj(null,this.U())};_.S=function(a){throw _g(new ai('Add not supported on this collection'))};_.s=function(){var a,b,c;c=new tj('[',']');for(b=this.Q();b.X();){a=b.Y();sj(c,a===this?'(this Collection)':a==null?pp:sh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var re=Gh(223);oh(227,1,{209:1});_.p=function(a){var b,c,d;if(a===this){return true}if(!md(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new oi((new li(d)).a);c.b;){b=ni(c);if(!di(this,b)){return false}}return true};_.r=function(){return Hi(new li(this))};_.s=function(){var a,b,c;c=new tj('{','}');for(b=new oi((new li(this)).a);b.b;){a=ni(b);sj(c,ei(this,a.$())+'='+ei(this,a._()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ce=Gh(227);oh(141,227,{209:1});var ue=Gh(141);oh(226,223,{39:1,232:1});_.U=function(){return new rj(this,1)};_.p=function(a){var b;if(a===this){return true}if(!md(a,21)){return false}b=a;if(ji(b.a)!=this.T()){return false}return bi(this,b)};_.r=function(){return Hi(this)};var De=Gh(226);oh(21,226,{21:1,39:1,232:1},li);_.Q=function(){return new oi(this.a)};_.T=Gp;var te=Gh(21);oh(22,1,{},oi);_.W=Fp;_.Y=function(){return ni(this)};_.X=Hp;_.b=false;var se=Gh(22);oh(224,223,{39:1,229:1});_.U=function(){return new rj(this,16)};_.Z=function(a,b){throw _g(new ai('Add not supported on this list'))};_.S=function(a){this.Z(this.T(),a);return true};_.p=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,13)){return false}f=a;if(this.T()!=f.a.length){return false}e=new Ei(f);for(c=new Ei(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(rd(b)===rd(d)||b!=null&&q(b,d))){return false}}return true};_.r=function(){return Ii(this)};_.Q=function(){return new pi(this)};var we=Gh(224);oh(81,1,{},pi);_.W=Fp;_.X=function(){return this.a<this.b.a.length};_.Y=function(){return wi(this.b,this.a++)};_.a=0;var ve=Gh(81);oh(42,223,{39:1},qi);_.Q=function(){var a;a=new oi((new li(this.a)).a);return new ri(a)};_.T=Gp;var ye=Gh(42);oh(136,1,{},ri);_.W=Fp;_.X=function(){return this.a.b};_.Y=function(){var a;a=ni(this.a);return a._()};var xe=Gh(136);oh(134,1,rp);_.p=function(a){var b;if(!md(a,40)){return false}b=a;return Ji(this.a,b.$())&&Ji(this.b,b._())};_.$=Dp;_._=Hp;_.r=function(){return ij(this.a)^ij(this.b)};_.ab=function(a){var b;b=this.b;this.b=a;return b};_.s=function(){return this.a+'='+this.b};var ze=Gh(134);oh(135,134,rp,si);var Ae=Gh(135);oh(228,1,rp);_.p=function(a){var b;if(!md(a,40)){return false}b=a;return Ji(this.b.value[0],b.$())&&Ji(ej(this),b._())};_.r=function(){return ij(this.b.value[0])^ij(ej(this))};_.s=function(){return this.b.value[0]+'='+ej(this)};var Be=Gh(228);oh(13,224,{3:1,13:1,39:1,229:1},Ci,Di);_.Z=function(a,b){Vj(this.a,a,b)};_.S=function(a){return ui(this,a)};_.P=function(a){vi(this,a)};_.Q=function(){return new Ei(this)};_.T=function(){return this.a.length};var Fe=Gh(13);oh(14,1,{},Ei);_.W=Fp;_.X=function(){return this.a<this.c.a.length};_.Y=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ee=Gh(14);oh(36,141,{3:1,36:1,209:1},Ki);var Ge=Gh(36);oh(57,1,{},Qi);_.P=Ip;_.Q=function(){return new Ri(this)};_.b=0;var Ie=Gh(57);oh(58,1,{},Ri);_.W=Fp;_.Y=function(){return this.d=this.a[this.c++],this.d};_.X=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var He=Gh(58);var Ui;oh(55,1,{},cj);_.P=Ip;_.Q=function(){return new dj(this)};_.b=0;_.c=0;var Le=Gh(55);oh(56,1,{},dj);_.W=Fp;_.Y=function(){return this.c=this.a,this.a=this.b.next(),new fj(this.d,this.c,this.d.c)};_.X=function(){return !this.a.done};var Je=Gh(56);oh(144,228,rp,fj);_.$=function(){return this.b.value[0]};_._=function(){return ej(this)};_.ab=function(a){return aj(this.a,this.b.value[0],a)};_.c=0;var Ke=Gh(144);oh(147,1,{});_.W=Kp;_.bb=function(){return this.d};_.cb=Jp;_.d=0;_.e=0;var Pe=Gh(147);oh(60,147,{});var Me=Gh(60);oh(137,1,{});_.W=Kp;_.bb=Hp;_.cb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Oe=Gh(137);oh(138,137,{},pj);_.W=function(a){mj(this,a)};_.db=function(a){return nj(this,a)};var Ne=Gh(138);oh(19,1,{},rj);_.bb=Dp;_.cb=function(){qj(this);return this.c};_.W=function(a){qj(this);this.d.W(a)};_.db=function(a){qj(this);if(this.d.X()){a.A(this.d.Y());return true}return false};_.a=0;_.c=0;var Qe=Gh(19);oh(52,1,{},tj);_.s=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Re=Gh(52);oh(33,1,{},uj);_.R=function(a){return a};var Se=Gh(33);oh(37,1,{},vj);var Te=Gh(37);oh(146,1,{});_.c=false;var bf=Gh(146);oh(23,146,{},Fj);var af=Gh(23);oh(66,1,{},Ij);_.eb=function(a){return ad(ke,hp,1,a,5,1)};var Ue=Gh(66);oh(149,60,{},Kj);_.db=function(a){this.b=false;while(!this.b&&this.c.db(new Lj(this,a)));return this.b};_.b=false;var We=Gh(149);oh(152,1,{},Lj);_.A=function(a){Jj(this.a,this.b,a)};var Ve=Gh(152);oh(148,60,{},Nj);_.db=function(a){return this.b.db(new Oj(this,a))};var Ye=Gh(148);oh(151,1,{},Oj);_.A=function(a){Mj(this.a,this.b,a)};var Xe=Gh(151);oh(150,1,{},Qj);_.A=function(a){Pj(this,a)};var Ze=Gh(150);oh(153,1,{},Rj);_.A=function(a){};var $e=Gh(153);oh(154,1,{},Tj);_.A=function(a){Sj(this,a)};var _e=Gh(154);oh(286,1,{});oh(283,1,{});var Zj=0;var _j,ak=0,bk;oh(900,1,{});oh(925,1,{});oh(164,1,{},ok);_.eb=function(a){return new Array(a)};var cf=Gh(164);oh(252,$wnd.Function,{},pk);_.gb=function(a){nk(this.a,this.b,a)};oh(6,29,{3:1,27:1,29:1,6:1},$k);var Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk,Yk;var df=Hh(6,_k);var al;oh(250,$wnd.Function,{},cl);_.I=function(a){return Fb(al),al=null,null};oh(180,1,{});var Pf=Gh(180);oh(181,180,{});_.e=0;var Tf=Gh(181);oh(182,181,ip,kl);_.v=Lp;_.w=Mp;_.s=function(){var a;return Ch(nf),nf.k+'@'+(a=$j(this)>>>0,a.toString(16))};var gl=0;var nf=Gh(182);oh(183,1,gp,ll);_.t=function(){hl(this.a)};var ef=Gh(183);oh(184,1,{},ml);_.u=function(){return jl(this.a)};var ff=Gh(184);oh(186,1,{},nl);_.u=function(){return el(this.a)};var gf=Gh(186);oh(185,1,{},ol);_.t=function(){fl(this.a)};var hf=Gh(185);oh(202,1,{});var Of=Gh(202);oh(203,202,{});_.d=0;var Sf=Gh(203);oh(204,203,ip,ul);_.v=Np;_.w=Op;_.s=function(){var a;return Ch(mf),mf.k+'@'+(a=$j(this)>>>0,a.toString(16))};var sl=0;var mf=Gh(204);oh(205,1,gp,vl);_.t=Pp;var jf=Gh(205);oh(206,1,{},wl);_.t=function(){rl(this.a)};var kf=Gh(206);oh(207,1,{},xl);_.u=function(){return ql(this.a)};var lf=Gh(207);oh(172,1,{});_.g='';var ag=Gh(172);oh(173,172,{});_.e=0;var Vf=Gh(173);oh(174,173,ip,Jl);_.v=Lp;_.w=Mp;_.s=function(){var a;return Ch(tf),tf.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Dl=0;var tf=Gh(174);oh(175,1,gp,Kl);_.t=function(){El(this.a)};var of=Gh(175);oh(177,1,{},Ll);_.u=function(){return Bl(this.a)};var pf=Gh(177);oh(178,1,gp,Ml);_.t=function(){yl(this.a)};var qf=Gh(178);oh(176,1,{},Nl);_.t=function(){fl(this.a)};var rf=Gh(176);oh(179,1,gp,Ol);_.t=function(){Hl(this.a,this.b)};var sf=Gh(179);oh(168,1,{});_.k=false;var dg=Gh(168);oh(188,168,{});_.g=0;var Xf=Gh(188);oh(189,188,ip,im);_.v=function(){kc(this.e)};_.w=function(){return this.e.i<0};_.s=function(){var a;return Ch(Ff),Ff.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Yl=0;var Ff=Gh(189);oh(190,1,gp,jm);_.t=function(){Zl(this.a)};var uf=Gh(190);oh(193,1,gp,km);_.t=function(){kc(this.a.e)};var vf=Gh(193);oh(194,1,{},lm);_.u=function(){return Wl(this.a)};var wf=Gh(194);oh(191,1,{},mm);_.u=function(){return am(this.a)};var xf=Gh(191);oh(44,1,gp,nm);_.t=function(){hm(this.a,In(this.b))};var yf=Gh(44);oh(61,1,gp,om);_.t=function(){Tl(this.a,this.b)};var zf=Gh(61);oh(195,1,gp,pm);_.t=function(){bm(this.a,this.b)};var Af=Gh(195);oh(192,1,{},qm);_.t=function(){Xl(this.a)};var Bf=Gh(192);oh(196,1,gp,rm);_.t=function(){cm(this.a,this.b)};var Cf=Gh(196);oh(197,1,gp,sm);_.t=function(){Pl(this.a,this.b)};var Df=Gh(197);oh(198,1,gp,tm);_.t=function(){Ul(this.a)};var Ef=Gh(198);oh(157,1,{});var hg=Gh(157);oh(158,157,{});_.d=0;var Zf=Gh(158);oh(159,158,ip,Am);_.v=Np;_.w=Op;_.s=function(){var a;return Ch(Jf),Jf.k+'@'+(a=$j(this)>>>0,a.toString(16))};var ym=0;var Jf=Gh(159);oh(160,1,gp,Bm);_.t=Pp;var Gf=Gh(160);oh(161,1,{},Cm);_.t=function(){rl(this.a)};var Hf=Gh(161);oh(162,1,{},Dm);_.u=function(){return wm(this.a)};var If=Gh(162);oh(256,$wnd.Function,{},Em);_.kb=function(a){yo(this.a.g)};oh(166,1,{},Fm);var Kf=Gh(166);oh(88,1,{},Gm);var Lf=Gh(88);var Hm;oh(187,1,{},Im);var Mf=Gh(187);oh(83,1,{},Jm);var Nf=Gh(83);var Km;oh(257,$wnd.Function,{},Lm);_.lb=function(a){return new Om(a)};var Mm;oh(170,$wnd.React.Component,{},Om);nh(lh[1],_);_.componentWillUnmount=function(){dl(this.a)};_.render=function(){return il(this.a)};_.shouldComponentUpdate=Qp;var Qf=Gh(170);oh(267,$wnd.Function,{},Pm);_.lb=function(a){return new Sm(a)};var Qm;oh(199,$wnd.React.Component,{},Sm);nh(lh[1],_);_.componentWillUnmount=function(){pl(this.a)};_.render=function(){return tl(this.a)};_.shouldComponentUpdate=Rp;var Rf=Gh(199);oh(255,$wnd.Function,{},Tm);_.lb=function(a){return new Wm(a)};var Um;oh(169,$wnd.React.Component,{},Wm);nh(lh[1],_);_.componentWillUnmount=function(){dl(this.a)};_.render=function(){return Fl(this.a)};_.shouldComponentUpdate=Qp;var Uf=Gh(169);oh(258,$wnd.Function,{},Xm);_.lb=function(a){return new $m(a)};var Ym;oh(171,$wnd.React.Component,{},$m);nh(lh[1],_);_.componentDidUpdate=function(a){$(this.a)&&(fm(this.a),undefined)};_.componentWillUnmount=function(){$(this.a)&&Vl(this.a)};_.render=function(){return $(this.a)?$l(this.a):null};_.shouldComponentUpdate=function(a){return $(this.a)&&1==this.a.g};var Wf=Gh(171);oh(249,$wnd.Function,{},_m);_.lb=function(a){return new cn(a)};var an;oh(139,$wnd.React.Component,{},cn);nh(lh[1],_);_.componentWillUnmount=function(){pl(this.a)};_.render=function(){return zm(this.a)};_.shouldComponentUpdate=Rp;var Yf=Gh(139);oh(253,$wnd.Function,{},dn);_.jb=function(a){zl(this.a,a)};oh(254,$wnd.Function,{},en);_.ib=function(a){Gl(this.a,a)};oh(165,1,{},fn);var $f=Gh(165);oh(94,1,{},gn);var _f=Gh(94);var hn;oh(265,$wnd.Function,{},jn);_.ib=function(a){_l(this.a,a)};oh(259,$wnd.Function,{},kn);_.ib=function(a){bo(this.a)};oh(261,$wnd.Function,{},ln);_.kb=function(a){dm(this.a,this.b)};oh(262,$wnd.Function,{},mn);_.kb=function(a){Ql(this.a,this.b)};oh(263,$wnd.Function,{},nn);_.A=function(a){Rl(this.a,a)};oh(264,$wnd.Function,{},on);_.hb=function(a){em(this.a,this.b)};oh(266,$wnd.Function,{},pn);_.jb=function(a){Sl(this.a,this.b,a)};oh(167,1,{},rn);var bg=Gh(167);oh(95,1,{},sn);var cg=Gh(95);var tn;oh(248,$wnd.Function,{},un);_.ib=function(a){um(this.a,a)};oh(140,1,{},vn);_.R=function(a){return qn(new rn,a)};var eg=Gh(140);oh(64,1,{},wn);var fg=Gh(64);oh(93,1,{},xn);var gg=Gh(93);var yn;oh(63,1,{},zn);var ig=Gh(63);oh(107,1,{});var Og=Gh(107);oh(108,107,ip,Mn);_.v=Lp;_.w=Mp;_.s=function(){var a;return Ch(qg),qg.k+'@'+(a=$j(this)>>>0,a.toString(16))};var qg=Gh(108);oh(109,1,gp,Nn);_.t=function(){Gn(this.a)};var jg=Gh(109);oh(111,1,{},On);_.t=function(){Bn(this.a)};var kg=Gh(111);oh(112,1,{},Pn);_.t=function(){Cn(this.a)};var lg=Gh(112);oh(113,1,gp,Qn);_.t=function(){An(this.a,this.b)};var mg=Gh(113);oh(114,1,gp,Rn);_.t=function(){Jn(this.a)};var ng=Gh(114);oh(54,1,gp,Sn);_.t=function(){Fn(this.a)};var og=Gh(54);oh(110,1,{},Tn);_.u=function(){var a;return a=(wh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var pg=Gh(110);oh(45,1,{45:1});_.d=false;var Wg=Gh(45);oh(46,45,{9:1,251:1,46:1,45:1},co);_.v=Lp;_.p=function(a){return Xn(this,a)};_.r=function(){return this.c.d};_.w=Mp;_.s=function(){var a;return Ch(Gg),Gg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Un=0;var Gg=Gh(46);oh(200,1,gp,eo);_.t=function(){Vn(this.a)};var rg=Gh(200);oh(201,1,gp,fo);_.t=function(){$n(this.a)};var sg=Gh(201);oh(97,96,{});var Rg=Gh(97);oh(98,97,ip,no);_.v=Sp;_.w=Tp;_.s=function(){var a;return Ch(Bg),Bg.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Bg=Gh(98);oh(100,1,gp,oo);_.t=function(){ho(this.a)};var tg=Gh(100);oh(99,1,gp,po);_.t=function(){ko(this.a)};var ug=Gh(99);oh(105,1,gp,qo);_.t=function(){cc(this.a,this.b,true)};var vg=Gh(105);oh(106,1,{},ro);_.u=function(){return go(this.a,this.c,this.b)};_.b=false;var wg=Gh(106);oh(101,1,{},so);_.u=function(){return lo(this.a)};var xg=Gh(101);oh(102,1,{},to);_.u=function(){return Rh(fh(Aj(dc(this.a))))};var yg=Gh(102);oh(103,1,{},uo);_.u=function(){return Rh(fh(Aj(Bj(dc(this.a),new $o))))};var zg=Gh(103);oh(104,1,{},vo);_.u=function(){return mo(this.a)};var Ag=Gh(104);oh(115,1,{});var Vg=Gh(115);oh(116,115,ip,Co);_.v=function(){kc(this.a)};_.w=function(){return this.a.i<0};_.s=function(){var a;return Ch(Fg),Fg.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Fg=Gh(116);oh(117,1,gp,Do);_.t=function(){zo(this.a,this.b)};_.b=false;var Cg=Gh(117);oh(118,1,gp,Eo);_.t=function(){Ln(this.b,this.a)};var Dg=Gh(118);oh(119,1,gp,Fo);_.t=function(){Ao(this.a)};var Eg=Gh(119);oh(120,1,{});var Yg=Gh(120);oh(121,120,ip,No);_.v=Sp;_.w=Tp;_.s=function(){var a;return Ch(Mg),Mg.k+'@'+(a=$j(this)>>>0,a.toString(16))};var Mg=Gh(121);oh(122,1,gp,Oo);_.t=function(){Io(this.a)};var Hg=Gh(122);oh(126,1,gp,Po);_.t=function(){Mo(this.a,null)};var Ig=Gh(126);oh(123,1,{},Qo);_.u=function(){var a;return a=In(this.a.g),o(Bp,a)?(Xo(),Uo):o(Cp,a)?(Xo(),Wo):(Xo(),Vo)};var Jg=Gh(123);oh(124,1,{},Ro);_.u=function(){return Ko(this.a)};var Kg=Gh(124);oh(125,1,{},So);_.t=function(){Lo(this.a)};var Lg=Gh(125);oh(87,1,{},To);_.handleEvent=function(a){Dn(this.a,a)};var Ng=Gh(87);oh(30,29,{3:1,27:1,29:1,30:1},Yo);var Uo,Vo,Wo;var Pg=Hh(30,Zo);oh(84,1,{},$o);_.fb=function(a){return !Zn(a)};var Qg=Gh(84);oh(90,1,{},_o);_.fb=function(a){return Zn(a)};var Sg=Gh(90);oh(91,1,{},ap);_.A=function(a){jo(this.a,a)};var Tg=Gh(91);oh(89,1,{},bp);_.A=function(a){xo(this.a,a)};_.a=false;var Ug=Gh(89);oh(92,1,{},cp);_.fb=function(a){return Ho(this.a,a)};var Xg=Gh(92);var td=Ih('D');var dp=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=jh;hh(uh);kh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();