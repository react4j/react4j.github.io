function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='B88DA1BC05E2A84BC97C6218B971FA50',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'B88DA1BC05E2A84BC97C6218B971FA50';function p(){}
function Ah(){}
function wh(){}
function Gb(){}
function Sc(){}
function Zc(){}
function fi(){}
function Aj(){}
function Oj(){}
function Wj(){}
function Xj(){}
function uk(){}
function Lk(){}
function sm(){}
function wm(){}
function Am(){}
function Em(){}
function Im(){}
function Io(){}
function Ho(){}
function bn(){}
function An(){}
function Xc(a){Wc()}
function Hh(){Hh=wh}
function H(a){this.a=a}
function G(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function hc(a){this.a=a}
function qc(a){this.a=a}
function Wh(a){this.a=a}
function ei(a){this.a=a}
function ri(a){this.a=a}
function wi(a){this.a=a}
function xi(a){this.a=a}
function vi(a){this.b=a}
function Ki(a){this.c=a}
function Bj(a){this.a=a}
function Zj(a){this.a=a}
function Uk(a){this.a=a}
function Vk(a){this.a=a}
function Wk(a){this.a=a}
function Xk(a){this.a=a}
function cl(a){this.a=a}
function dl(a){this.a=a}
function el(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function tl(a){this.a=a}
function ul(a){this.a=a}
function Sl(a){this.a=a}
function Tl(a){this.a=a}
function Ul(a){this.a=a}
function Vl(a){this.a=a}
function Zl(a){this.a=a}
function am(a){this.a=a}
function im(a){this.a=a}
function jm(a){this.a=a}
function km(a){this.a=a}
function lm(a){this.a=a}
function Mm(a){this.a=a}
function Nm(a){this.a=a}
function Rm(a){this.a=a}
function Sm(a){this.a=a}
function Vm(a){this.a=a}
function an(a){this.a=a}
function un(a){this.a=a}
function vn(a){this.a=a}
function wn(a){this.a=a}
function yn(a){this.a=a}
function zn(a){this.a=a}
function Mn(a){this.a=a}
function Nn(a){this.a=a}
function Wn(a){this.a=a}
function Xn(a){this.a=a}
function $n(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function bo(a){this.a=a}
function mo(a){this.a=a}
function vo(a){this.a=a}
function wo(a){this.a=a}
function xo(a){this.a=a}
function yo(a){this.a=a}
function zo(a){this.a=a}
function Ao(a){this.a=a}
function Jo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function ap(a){this.a=a}
function cp(a){this.a=a}
function Mp(){kc(this.c)}
function Op(){kc(this.b)}
function Tp(){kc(this.f)}
function Ii(){zi(this)}
function nk(a,b){mk(a,b)}
function eo(a,b){Ql(b,a)}
function rb(a,b){a.b=b}
function Vj(a,b){a.a=b}
function pk(a,b){a.key=b}
function w(a){--a.e;D(a)}
function Z(a){!!a&&ab(a)}
function lc(a){!!a&&a.t()}
function Wi(){this.a=dj()}
function ij(){this.a=dj()}
function Gp(a){mj(this,a)}
function Lp(a){pj(this,a)}
function Jp(a){$h(this,a)}
function Qp(){lb(this.a.a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function hh(a){return a.e}
function Ep(){return this.a}
function Ip(){return this.b}
function Kp(){return this.e}
function K(){K=wh;J=new F}
function yc(){yc=wh;xc=new p}
function _i(){_i=wh;$i=bj()}
function Pc(){Pc=wh;Oc=new Sc}
function Mk(a){a.e=2;kc(a.c)}
function Yk(a){a.d=2;kc(a.b)}
function Cl(a){a.g=2;kc(a.e)}
function nn(a){S(a.a);ab(a.b)}
function Qk(a){lb(a.b);S(a.a)}
function L(a,b){P(a);M(a,b)}
function Oo(a,b){Uo(a);M(a,b)}
function Yj(a,b){Nj(a.a,b)}
function oc(a,b){ni(a.e,b)}
function xl(a,b){Rn(a.n,b)}
function co(a,b){Qn(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function jc(a,b,c){mi(a.e,b,c)}
function uj(a,b,c){b.A(a.a[c])}
function Dn(a,b,c){jc(a.c,b,c)}
function bk(a,b){a.splice(b,1)}
function tc(a,b){a.e=b;sc(a,b)}
function Ci(a,b){return a.a[b]}
function yl(a,b){return a.j=b}
function $c(a,b){return Qh(a,b)}
function Fp(){return ek(this)}
function Gh(a){wc.call(this,a)}
function gi(a){wc.call(this,a)}
function Hp(){return pi(this.a)}
function Np(){return this.c.i<0}
function Pp(){return this.b.i<0}
function Up(){return this.f.i<0}
function dj(){_i();return new $i}
function Kh(a){Jh(a);return a.k}
function Mj(a,b){a.S(b);return a}
function Cn(a){ab(a.b);ab(a.a)}
function ll(a){lb(a.a);ab(a.b)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function U(a){nb(a.f);return W(a)}
function ph(){nh==null&&(nh=[])}
function Fc(){Fc=wh;!!(Wc(),Vc)}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function bb(a){K();Zb(a);a.e=-2}
function qm(a){this.a=a;rm=this}
function Pm(a){this.a=a;Qm=this}
function pj(a,b){while(a.db(b));}
function Nj(a,b){Vj(a,Mj(a.a,b))}
function bp(a,b){return No(a.a,b)}
function pi(a){return a.a.b+a.b.b}
function Rp(a){return 1==this.a.e}
function Sp(a){return 1==this.a.d}
function fj(a,b){return a.a.get(b)}
function Sj(a,b,c){b.A(a.a.R(c))}
function v(a,b,c){t(a,new I(c),b)}
function _j(a,b,c){a.splice(b,0,c)}
function xk(a,b){a.ref=b;return a}
function yk(a,b){a.href=b;return a}
function pn(a){gb(a.b);return a.e}
function Gn(a){gb(a.a);return a.d}
function qo(a){gb(a.d);return a.e}
function Eb(a){this.d=a;this.b=100}
function ic(a,b){this.a=a;this.b=b}
function yi(a,b){this.a=a;this.b=b}
function Rj(a,b){this.a=a;this.b=b}
function Uj(a,b){this.a=a;this.b=b}
function vk(a,b){this.a=a;this.b=b}
function vl(a,b){this.a=a;this.b=b}
function Wl(a,b){this.a=a;this.b=b}
function Xl(a,b){this.a=a;this.b=b}
function Yl(a,b){this.a=a;this.b=b}
function $l(a,b){this.a=a;this.b=b}
function _l(a,b){this.a=a;this.b=b}
function Tm(a,b){this.a=a;this.b=b}
function Um(a,b){this.a=a;this.b=b}
function Wm(a,b){this.a=a;this.b=b}
function Xm(a,b){this.a=a;this.b=b}
function xn(a,b){this.a=a;this.b=b}
function Yn(a,b){this.a=a;this.b=b}
function ko(a,b){this.a=a;this.b=b}
function Fo(a,b){this.a=a;this.b=b}
function lo(a,b){this.b=a;this.a=b}
function Hk(a,b){a.value=b;return a}
function ci(a,b){a.a+=''+b;return a}
function cn(){this.a=rk((Km(),Jm))}
function mm(){this.a=rk((um(),tm))}
function pm(){this.a=rk((ym(),xm))}
function Om(){this.a=rk((Cm(),Bm))}
function Zm(){this.a=rk((Gm(),Fm))}
function qn(a){on(a,(gb(a.b),a.e))}
function Hn(a){Ql(a,(gb(a.a),!a.d))}
function Ub(a){return !a.d?a:Ub(a.d)}
function li(a){return !a?null:a._()}
function rd(a){return a==null?null:a}
function oj(a){return a!=null?s(a):0}
function o(a,b){return rd(a)===rd(b)}
function Ck(a,b){a.onBlur=b;return a}
function zk(a,b){a.onClick=b;return a}
function Bk(a,b){a.checked=b;return a}
function Mc(a){$wnd.clearTimeout(a)}
function jb(a){this.c=new Ii;this.b=a}
function oi(a){a.a=new Wi;a.b=new ij}
function Po(a){a.b=0;a.d=0;a.c=false}
function Gl(a){lb(a.b);S(a.c);ab(a.a)}
function gc(a,b){cc(a,b,false);fb(a.c)}
function ak(a,b){$j(b,0,a,0,b.length)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function fp(a){return bp((ep(),dp),a)}
function $(a){return !(md(a,8)&&a.w())}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function qb(a){K();pb(a);tb(a,2,true)}
function zi(a){a.a=ad(ke,jp,1,0,5,1)}
function Q(){this.a=ad(ke,jp,1,100,5,1)}
function Yo(){this.d=new Vo;this.b=100}
function ik(){ik=wh;fk=new p;hk=new p}
function ep(){ep=wh;dp=new cp(new Yo)}
function go(a,b){Bi(ec(a.b),new Ko(b))}
function mk(a,b){for(var c in a){b(c)}}
function Dk(a,b){a.onChange=b;return a}
function Ek(a,b){a.onKeyDown=b;return a}
function ok(a,b){a.props['a']=b;return a}
function _h(a,b){return a.charCodeAt(b)}
function md(a,b){return a!=null&&kd(a,b)}
function ed(a,b,c){return {l:a,m:b,h:c}}
function ek(a){return a.$H||(a.$H=++dk)}
function Ak(a){return a.autoFocus=true,a}
function od(a){return typeof a==='number'}
function qd(a){return typeof a==='string'}
function nd(a){return typeof a==='boolean'}
function Gk(a){a.type='checkbox';return a}
function Jh(a){if(a.k!=null){return}Sh(a)}
function Ol(a){A((K(),K(),J),new am(a),xp)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Vo(){this.a=ad(ke,jp,1,100,5,1)}
function wc(a){this.g=a;rc(this);this.G()}
function Lj(a,b){Ej.call(this,a);this.a=b}
function $m(a,b){this.a=a;this.b=b;_m=this}
function Qi(){this.a=new Wi;this.b=new ij}
function mj(a,b){while(a.X()){Yj(b,a.Y())}}
function fc(a,b){oc(b.c,a);md(b,8)&&b.v()}
function Yi(a,b){var c;c=a[up];c.call(a,b)}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function Gc(a,b,c){return a.apply(b,c);var d}
function Un(a){return Xh(T(a.e).a-T(a.a).a)}
function po(a){lb(a.a);S(a.b);S(a.c);ab(a.d)}
function fo(a){A((K(),K(),J),new mo(a),xp)}
function rn(a){A((K(),K(),J),new yn(a),xp)}
function Kn(a){A((K(),K(),J),new Nn(a),xp)}
function Zh(){Zh=wh;Yh=ad(he,jp,26,256,0,1)}
function Wc(){Wc=wh;var a;!Yc();a=new Zc;Vc=a}
function Nh(a){var b;b=Mh(a);Uh(a,b);return b}
function rc(a){a.j&&a.e!==pp&&a.G();return a}
function Ik(a,b){a.onDoubleClick=b;return a}
function Ai(a,b){a.a[a.a.length]=b;return true}
function lj(a,b,c){this.a=a;this.b=b;this.c=c}
function Eh(a,b,c,d){a.addEventListener(b,c,d)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function nl(a,b){A((K(),K(),J),new vl(a,b),xp)}
function Il(a,b){A((K(),K(),J),new _l(a,b),xp)}
function Ml(a,b){A((K(),K(),J),new Yl(a,b),xp)}
function Nl(a,b){A((K(),K(),J),new Xl(a,b),xp)}
function Pl(a,b){A((K(),K(),J),new Wl(a,b),xp)}
function Rn(a,b){A((K(),K(),J),new Yn(a,b),xp)}
function io(a,b){A((K(),K(),J),new ko(a,b),xp)}
function sj(a,b){while(a.c<a.d){uj(a,b,a.c++)}}
function Db(a){while(true){if(!Cb(a)){break}}}
function Wo(a){while(true){if(!Xo(a)){break}}}
function Sn(a){$h(new wi(a.g),new hc(a));oi(a.g)}
function no(a){return o(Cp,a)||o(Dp,a)||o('',a)}
function cd(a){return Array.isArray(a)&&a.ob===Ah}
function wj(a){if(!a.d){a.d=a.b.Q();a.c=a.b.T()}}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function _o(a){if(a.a){Fb(Jk);Jk=null;a.a=null}}
function Zn(a,b){this.a=a;this.c=b;this.b=false}
function ol(a,b){var c;c=b.target;pl(a,c.value)}
function Fj(a,b){var c;return Jj(a,(c=new Ii,c))}
function ej(a,b){return !(a.a.get(b)===undefined)}
function Tn(a){return Hh(),0!=T(a.e).a?true:false}
function Mi(a){return new Lj(null,Li(a,a.length))}
function ld(a){return !Array.isArray(a)&&a.ob===Ah}
function Li(a,b){return qj(b,a.length),new vj(a,b)}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ei(a,b){var c;c=a.a[b];bk(a.a,b);return c}
function ti(a){var b;b=a.a.Y();a.b=si(a);return b}
function Ph(a){var b;b=Mh(a);b.j=a;b.e=1;return b}
function Ok(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function $k(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function El(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function Pj(a,b,c){if(a.a.fb(c)){a.b=true;b.A(c)}}
function Fh(a,b,c,d){a.removeEventListener(b,c,d)}
function Pn(a){S(a.d);S(a.e);S(a.a);S(a.b);ab(a.c)}
function Rk(a){return B((K(),K(),J),a.b,new Wk(a))}
function Hl(a){return B((K(),K(),J),a.b,new Ul(a))}
function al(a){return B((K(),K(),J),a.a,new el(a))}
function ml(a){return B((K(),K(),J),a.a,new sl(a))}
function gm(a){return B((K(),K(),J),a.a,new km(a))}
function Sk(a){return Hh(),T(a.f.b).a>0?true:false}
function Jl(a){return Hh(),qo(a.o)==a.i?true:false}
function qi(a,b){if(b){return ji(a.a,b)}return false}
function Gi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function bm(a,b){var c;c=b.target;io(a.f,c.checked)}
function pl(a,b){var c;c=a.g;if(b!=c){a.g=b;fb(a.b)}}
function Ql(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function sn(a,b){var c;c=a.e;if(b!=c){a.e=b;fb(a.b)}}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function Dh(){Dh=wh;Ch=$wnd.goog.global.document}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Pi(a,b){return rd(a)===rd(b)||a!=null&&q(a,b)}
function mn(a){var b;V(a.a);b=T(a.a);o(a.f,b)&&sn(a,b)}
function Cj(a){if(!a.b){Dj(a);a.c=true}else{Cj(a.b)}}
function Ej(a){if(!a){this.b=null;new Ii}else{this.b=a}}
function vj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function nm(a,b,c){this.a=a;this.b=b;this.c=c;om=this}
function dn(a,b,c){this.a=a;this.b=b;this.c=c;en=this}
function rj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function xj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function on(a,b){A((K(),K(),J),new xn(a,b),75497472)}
function Kl(a,b){to(a.o,b);A((K(),K(),J),new Wl(a,b),xp)}
function Hj(a,b){Dj(a);return new Lj(a,new Qj(b,a.a))}
function Ij(a,b){Dj(a);return new Lj(a,new Tj(b,a.a))}
function mh(a){if(od(a)){return a|0}return a.l|a.m<<22}
function Rh(a){if(a.O()){return null}var b=a.j;return sh[b]}
function Oh(a,b){var c;c=Mh(a);Uh(a,c);c.e=b?8:0;return c}
function uc(a,b){var c;c=Kh(a.mb);return b==null?c:c+': '+b}
function wl(a,b){var c;if(T(a.c)){c=b.target;Ql(a,c.value)}}
function $h(a,b){var c,d;for(d=a.Q();d.X();){c=d.Y();b.A(c)}}
function ki(a,b){return b===a?'(this Map)':b==null?rp:zh(b)}
function Go(){Eo();return dd($c(Pg,1),jp,27,0,[Bo,Do,Co])}
function Ll(a,b){A((K(),K(),J),new Wl(a,b),xp);to(a.o,null)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&np)&&D((null,J))}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function yh(a){function b(){}
;b.prototype=a||{};return new b}
function ym(){ym=wh;var a;xm=(a=xh(wm.prototype.lb,wm,[]),a)}
function um(){um=wh;var a;tm=(a=xh(sm.prototype.lb,sm,[]),a)}
function Cm(){Cm=wh;var a;Bm=(a=xh(Am.prototype.lb,Am,[]),a)}
function Gm(){Gm=wh;var a;Fm=(a=xh(Em.prototype.lb,Em,[]),a)}
function Km(){Km=wh;var a;Jm=(a=xh(Im.prototype.lb,Im,[]),a)}
function lk(){if(gk==256){fk=hk;hk=new p;gk=0}++gk}
function Kk(){if(!Jk){Jk=(++(K(),K(),J).e,new Gb);fp(new Lk)}}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function Dj(a){if(a.b){Dj(a.b)}else if(a.c){throw hh(new Vh)}}
function dc(a){gb(a.c);return new Lj(null,new xj(new wi(a.g),0))}
function kn(a,b){b.preventDefault();A((K(),K(),J),new zn(a),xp)}
function Si(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Qh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function uh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Ti(a,b){var c;return Ri(b,Si(a,b==null?0:(c=s(b),c|0)))}
function Ji(a){zi(this);ak(this.a,ii(a,ad(ke,jp,1,pi(a.a),5,1)))}
function jo(a){this.b=a;K();this.a=new pc(0,null,null,false,false)}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function Xi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Tj(a,b){rj.call(this,b.cb(),b.bb()&-6);this.a=a;this.b=b}
function tj(a,b){if(a.c<a.d){uj(a,b,a.c++);return true}return false}
function Fk(a){a.placeholder='What needs to be done?';return a}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function nc(a){lc(a.g);!!a.e&&mc(a);Z(a.a);Z(a.c);lc(a.b);lc(a.f)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function cb(a,b){var c,d;Ai(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function tk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function hn(a){Eh((Dh(),$wnd.goog.global.window),Ap,a.d,false)}
function jn(a){Fh((Dh(),$wnd.goog.global.window),Ap,a.d,false)}
function ho(a){Fj(Hj(dc(a.b),new Io),new Bj(new Aj)).P(new Jo(a.b))}
function Gj(a){var b;Cj(a);b=0;while(a.a.db(new Xj)){b=ih(b,1)}return b}
function Jj(a,b){var c;Cj(a);c=new Wj;c.a=b;a.a.W(new Zj(c));return c.a}
function yj(a,b){!a.a?(a.a=new ei(a.d)):ci(a.a,a.b);ci(a.a,b);return a}
function ni(a,b){return qd(b)?b==null?Vi(a.a,null):hj(a.b,b):Vi(a.a,b)}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function Jb(b){try{nb(b.b.a)}catch(a){a=gh(a);if(!md(a,4))throw hh(a)}}
function Qj(a,b){rj.call(this,b.cb(),b.bb()&-16449);this.a=a;this.c=b}
function jj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function zj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function zm(a){$wnd.React.Component.call(this,a);this.a=new bl(this,rm.a)}
function Dm(a){$wnd.React.Component.call(this,a);this.a=new ql(this,Qm.a)}
function ui(a){this.d=a;this.c=new jj(this.d.b);this.a=this.c;this.b=si(this)}
function Kj(a,b){var c;c=Fj(a,new Bj(new Aj));return Hi(c,b.eb(c.a.length))}
function Qn(a,b){var c;return u((K(),K(),J),new Zn(a,b),xp,(c=null,c))}
function oo(a,b){return (Eo(),Co)==a||(Bo==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function ck(a,b){return _c(b)!=10&&dd(r(b),b.nb,b.__elementTypeId$,_c(b),a),a}
function mi(a,b,c){return qd(b)?b==null?Ui(a.a,null,c):gj(a.b,b,c):Ui(a.a,b,c)}
function fl(a){var b;b=bi((gb(a.b),a.g));if(b.length>0){co(a.f,b);pl(a,'')}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Di(a,b,c){for(;c<a.a.length;++c){if(Pi(b,a.a[c])){return c}}return -1}
function kj(a){if(a.a.c!=a.c){return fj(a.a,a.b.value[0])}return a.b.value[1]}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function En(a,b){var c;if(md(b,45)){c=b;return a.c.d==c.c.d}else{return false}}
function Fi(a,b){var c;c=Di(a,b,0);if(c==-1){return false}bk(a.a,c);return true}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function Bi(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.A(c)}}
function Pb(){var a;this.a=ad(yd,jp,42,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function ro(a){var b;return b=T(a.b),Fj(Hj(dc(a.i),new Lo(b)),new Bj(new Aj))}
function gn(a,b){a.f=b;o(b,T(a.a))&&sn(a,b);ln(b);A((K(),K(),J),new zn(a),xp)}
function kc(a){if(a.i>=0){a.i=-2;u((K(),K(),J),new H(new qc(a)),67108864,null)}}
function ab(a){if(-2!=a.e){u((K(),K(),J),new H(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function S(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function W(a){if(a.b){if(md(a.b,7)){throw hh(a.b)}else{throw hh(a.b)}}return a.k}
function sb(b){if(b){try{b.t()}catch(a){a=gh(a);if(md(a,4)){K()}else throw hh(a)}}}
function Mo(b){var c;c=Ro(b.d);try{_o(c)}catch(a){a=gh(a);if(!md(a,4))throw hh(a)}}
function Qc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Uc(b,c)}while(a.a);a.a=c}}
function Rc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function gl(a,b){if(13==b.keyCode){b.preventDefault();A((K(),K(),J),new tl(a),xp)}}
function ec(a){return gb(a.c),Fj(new Lj(null,new xj(new wi(a.g),0)),new Bj(new Aj))}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function pd(a){return a!=null&&(typeof a===hp||typeof a==='function')&&!(a.ob===Ah)}
function Hm(a){$wnd.React.Component.call(this,a);this.a=new Rl(this,_m.a,_m.b)}
function vm(a){$wnd.React.Component.call(this,a);this.a=new Tk(this,om.a,om.b,om.c)}
function Lm(a){$wnd.React.Component.call(this,a);this.a=new hm(this,en.a,en.b,en.c)}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ii);Ai(a.b,b)}}}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Ii);a.c=c.c}b.d=true;Ai(a.c,b)}
function Uh(a,b){var c;if(!a){return}b.j=a;var d=Rh(b);if(!d){sh[a]=[b];return}d.mb=b}
function xh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Mh(a){var b;b=new Lh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function rk(a){var b;b=qk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Ni(a){var b,c,d;d=0;for(c=new ui(a.a);c.b;){b=ti(c);d=d+(b?s(b):0);d=d|0}return d}
function pb(a){var b,c;for(c=new Ki(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function oh(){ph();var a=nh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Vh(){wc.call(this,"Stream already terminated, can't be modified or used")}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:lp)|(0==(c&6291456)?!a?np:op:0)|0|0|0)}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?op:0)|(0!=(b&229376)?0:98304)}
function Ym(a,b){pk(a.a,(b?Xh(b.c.d):null)+(''+(Jh(dg),dg.k)));ok(a.a,b);return a.a}
function cc(a,b,c){var d;d=ni(a.g,b?Xh(b.c.d):null);if(null!=d){oc(b.c,a);c&&!!b&&kc(b.c);fb(a.c)}}
function On(a,b,c){var d;d=new Ln(b,c);Dn(d,a,new ic(a,d));mi(a.g,Xh(d.c.d),d);fb(a.c);return d}
function hj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Yi(a.a,b);--a.b}return c}
function hi(a,b){var c,d;for(d=new ui(b.a);d.b;){c=ti(d);if(!qi(a,c)){return false}}return true}
function jh(a){var b;b=a.h;if(b==0){return a.l+a.m*op}if(b==1048575){return a.l+a.m*op-sp}return a}
function gh(a){var b;if(md(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function si(a){if(a.a.X()){return true}if(a.a!=a.c){return false}a.a=new Xi(a.d.a);return a.a.X()}
function qj(a,b){if(0>a||a>b){throw hh(new Gh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function rh(a,b){typeof window===hp&&typeof window['$gwt']===hp&&(window['$gwt'][a]=b)}
function Eo(){Eo=wh;Bo=new Fo('ACTIVE',0);Do=new Fo('COMPLETED',1);Co=new Fo('ALL',2)}
function Bh(){new fn;$wnd.ReactDOM.render((new cn).a,(Dh(),Ch).getElementById('app'),null)}
function so(a){var b;b=T(a.g.a);o(Cp,b)||o(Dp,b)||o('',b)?on(a.g,b):no(pn(a.g))?rn(a.g):on(a.g,'')}
function lh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=sp;d=1048575}c=sd(e/op);b=sd(e-c*op);return ed(b,c,d)}
function Ri(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Pi(a,c.$())){return c}}return null}
function dd(a,b,c,d,e){e.mb=a;e.nb=b;e.ob=Ah;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function gj(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function to(a,b){var c;c=a.e;if(!(b==c||!!b&&En(b,c))){!!c&&oc(c.c,a);a.e=b;!!b&&Dn(b,a,new wo(a));fb(a.d)}}
function db(a,b){var c,d;d=a.c;Fi(d,b);!!a.b&&lp!=(a.b.c&mp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function zl(a,b,c){27==c.which?A((K(),K(),J),new $l(a,b),xp):13==c.which&&A((K(),K(),J),new Xl(a,b),xp)}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&lp)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Bl(a){var b;b=T(a.c);if(!a.k&&b){a.k=true;Pl(a,a.i);a.j.focus();a.j.select()}else a.k&&!b&&(a.k=false)}
function r(a){return qd(a)?ne:od(a)?ce:nd(a)?ae:ld(a)?a.mb:cd(a)?a.mb:a.mb||Array.isArray(a)&&$c(Ud,1)||Ud}
function s(a){return qd(a)?kk(a):od(a)?sd(a):nd(a)?a?1231:1237:ld(a)?a.r():cd(a)?ek(a):!!a&&!!a.hashCode?a.hashCode():ek(a)}
function Ac(a){yc();rc(this);this.e=a;sc(this,a);this.g=a==null?rp:zh(a);this.a='';this.b=a;this.a=''}
function Lh(){this.g=Ih++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function kk(a){ik();var b,c,d;c=':'+a;d=hk[c];if(d!=null){return sd(d)}d=fk[c];b=d==null?jk(a):sd(d);lk();hk[c]=b;return b}
function Oi(a){var b,c,d;d=1;for(c=new Ki(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Uo(a){var b,c;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){c=$wnd.Math.max(a.a.length-1,1)*2+1;So(a,c,b)}}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=Ei(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Al(a,b){var c;c=(gb(a.a),a.d);if(null!=c&&c.length!=0){A((K(),K(),J),new lo(b,c),xp);to(a.o,null);Ql(a,c)}else{Rn(a.n,b)}}
function Xh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Zh(),Yh)[b];!c&&(c=Yh[b]=new Wh(a));return c}return new Wh(a)}
function zh(a){var b;if(Array.isArray(a)&&a.ob===Ah){return Kh(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function fd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ed(c&4194303,d&4194303,e&1048575)}
function ih(a,b){var c;if(od(a)&&od(b)){c=a+b;if(-17592186044416<c&&c<sp){return c}}return jh(fd(od(a)?lh(a):a,od(b)?lh(b):b))}
function No(a,b){var c,d;d=0==O(a.d);c=new ap(b);Oo(a.d,c);d&&$wnd.Promise.resolve(null).then(xh(Zo.prototype.I,Zo,[a]));return c}
function Hi(a,b){var c,d;d=a.a.length;b.length<d&&(b=ck(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Th(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(lp==(b&mp)?0:524288)|(0==(b&6291456)?lp==(b&mp)?op:np:0)|0|268435456|0)}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function bl(a,b){var c;this.e=b;this.c=a;K();c=++_k;this.b=new pc(c,null,new cl(this),false,false);this.a=new wb(null,new dl(this),wp)}
function pc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Qi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new jb((f=null,K(),f)),g):null;this.c=null}
function mc(a){var b,c,d;for(c=new Ki(new Ji(new ri(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.$();md(d,8)&&d.w()||b._().t()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function q(a,b){return qd(a)?o(a,b):od(a)?rd(a)===rd(b):nd(a)?rd(a)===rd(b):ld(a)?a.p(b):cd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function kd(a,b){if(qd(a)){return !!jd[b]}else if(a.nb){return !!a.nb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function wk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Ro(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}else{b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}}
function Xo(a){var b;if(0==a.c){b=O(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;Po(a.d);return false}else{a.a=a.a+1;a.c=b}}--a.c;Mo(a);return true}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function T(a){a.j?hb(a.e):gb(a.e);if(ub(a.f)){if(a.j&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function So(a,b,c){var d,e,f,g;d=ad(ke,jp,1,b,5,1);g=0;for(e=0;e<c;e++){f=(a.b+e)%a.a.length;d[g]=a.a[f];a.a[f]=null;++g}a.a=d;a.b=0;a.d=g;a.c=false}
function bi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function ii(a,b){var c,d,e,f;f=pi(a.a);b.length<f&&(b=ck(new Array(f),b));e=b;d=new ui(a.a);for(c=0;c<f;++c){e[c]=ti(d)}b.length>f&&(b[f]=null);return b}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.t(),null)}finally{bc()}return f}catch(a){a=gh(a);if(md(a,4)){e=a;throw hh(e)}else throw hh(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.u()}else{ac(b,e);try{g=c.u()}finally{bc()}}return g}catch(a){a=gh(a);if(md(a,4)){f=a;throw hh(f)}else throw hh(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.i=c;this.k=null;this.j=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);lp==(d&mp)&&mb(this.f)}
function hm(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.c=a;K();e=++fm;this.b=new pc(e,null,new im(this),false,false);this.a=new wb(null,new jm(this),wp)}
function ql(a,b){var c,d,e;this.f=b;this.d=a;K();c=++kl;this.c=new pc(c,null,new rl(this),false,false);this.b=(e=new jb((d=null,d)),e);this.a=new wb(null,new ul(this),wp)}
function Ln(a,b){var c,d,e,f,g;this.e=a;this.d=b;K();c=++Bn;this.c=new pc(c,null,new Mn(this),true,true);this.b=(g=new jb((e=null,e)),g);this.a=(f=new jb((d=null,d)),f)}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Ki(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function qh(b,c,d,e){ph();var f=nh;$moduleName=c;$moduleBase=d;fh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{gp(g)()}catch(a){b(c,a)}}else{gp(g)()}}
function qk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function bj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return cj()}}
function Zk(a){var b,c;a.d=0;Kk();c=(b=T(a.e.e).a,sk('span',wk(new $wnd.Object,dd($c(ne,1),jp,2,6,['todo-count'])),[sk('strong',null,[b]),' item'+(b==1?'':'s')+' left']));return c}
function th(){sh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].pb()&&(c=Tc(c,g)):g[0].pb()}catch(a){a=gh(a);if(md(a,4)){d=a;Fc();Lc(md(d,32)?d.H():d)}else throw hh(a)}}return c}
function il(a){var b;a.e=0;Kk();b=sk(yp,Ak(Dk(Ek(Hk(Fk(wk(new $wnd.Object,dd($c(ne,1),jp,2,6,['new-todo']))),(gb(a.b),a.g)),xh(Mm.prototype.jb,Mm,[a])),xh(Nm.prototype.ib,Nm,[a]))),null);return b}
function zc(a){var b;if(a.c==null){b=rd(a.b)===rd(xc)?null:a.b;a.d=b==null?rp:pd(b)?b==null?null:b.name:qd(b)?'String':Kh(r(b));a.a=a.a+': '+(pd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.k;try{d=b.c.u();if(!(rd(e)===rd(d)||e!=null&&q(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=gh(a);if(md(a,9)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw hh(c)}else throw hh(a)}}
function $j(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Ui(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ri(b,e);if(f){return f.ab(c)}}e[e.length]=new yi(b,c);++a.b;return null}
function fn(){this.a=new Vn;new qm(this.a);this.b=new tn;this.c=new jo(this.a);this.d=new uo(this.a,this.b);new nm(this.a,this.c,this.d);new dn(this.a,this.c,this.d);new Pm(this.c);new $m(this.a,this.d)}
function Tk(a,b,c,d){var e;this.f=b;this.g=c;this.i=d;this.d=a;K();e=++Pk;this.c=new pc(e,null,new Uk(this),false,false);this.a=new X(new Vk(this),null,null,136478720);this.b=new wb(null,new Xk(this),wp)}
function jk(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+_h(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{b.e.t()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=gh(a);if(md(a,4)){K()}else throw hh(a)}}}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=ad(ke,jp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function vb(a,b,c,d){this.b=new Ii;this.f=new Kb(new zb(this),d&6520832|262144|lp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&np)&&D((null,J)))}
function Vi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Pi(b,e.$())){if(d.length==1){d.length=0;Yi(a.a,g)}else{d.splice(h,1)}--a.b;return e._()}}return null}
function vh(a,b,c){var d=sh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=sh[b]),yh(h));_.nb=c;!b&&(_.ob=Ah);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.mb=f)}
function Sh(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Th('.',[c,Th('$',d)]);a.b=Th('.',[c,Th('.',d)]);a.i=d[d.length-1]}
function ji(a,b){var c,d,e;c=b.$();e=b._();d=qd(c)?c==null?li(Ti(a.a,null)):fj(a.b,c):li(Ti(a.a,c));if(!(rd(e)===rd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(qd(c)?c==null?!!Ti(a.a,null):ej(a.b,c):!!Ti(a.a,c))){return false}return true}
function ln(a){var b;if(0==a.length){b=(Dh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',Ch.title,b)}else{(Dh(),$wnd.goog.global.window).location.hash=a}}
function uo(a,b){var c,d;this.i=a;this.g=b;K();this.f=new pc(0,null,new vo(this),false,false);this.d=(d=new jb((c=null,c)),d);this.b=new X(new xo(this),null,null,Bp);this.c=new X(new yo(this),null,null,Bp);this.a=new wb(new zo(this),null,681574400);D((null,J))}
function Vn(){var a;this.g=new Qi;K();this.f=new pc(0,new Xn(this),new Wn(this),false,false);this.c=(a=new jb(null),a);this.d=new X(new $n(this),null,null,Bp);this.e=new X(new _n(this),null,null,Bp);this.a=new X(new ao(this),null,null,Bp);this.b=new X(new bo(this),null,null,Bp)}
function tn(){var a,b,c;this.d=new Ao(this);this.f=this.e=(c=(Dh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));K();this.c=new pc(0,null,new un(this),false,false);this.b=(b=new jb((a=null,a)),b);this.a=new X(new An,new vn(this),new wn(this),35651584)}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Ki(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=gh(a);if(!md(a,4))throw hh(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.D();return a&&a.B()}},suppressed:{get:function(){return c.C()}}})}catch(a){}}}
function Rl(a,b,c){var d,e,f;this.n=b;this.o=c;this.f=a;this.i=a.props['a'];K();d=++Fl;this.e=new pc(d,null,new Sl(this),false,false);this.a=(f=new jb((e=null,e)),f);this.c=new X(new Vl(this),null,null,136478720);this.b=new wb(null,new Zl(this),wp);Dn(this.i,this,new Tl(this));Pl(this,this.i);D((null,J))}
function sk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;nk(b,xh(vk.prototype.gb,vk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=qk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function aj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}Bi(a.b,new Bb(a));a.b.a=ad(ke,jp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function dm(a){var b;a.d=0;Kk();b=sk('div',null,[sk('div',null,[sk(zp,wk(new $wnd.Object,dd($c(ne,1),jp,2,6,[zp])),[sk('h1',null,['todos']),(new Om).a]),T(a.e.d)?sk('section',wk(new $wnd.Object,dd($c(ne,1),jp,2,6,[zp])),[sk(yp,Dk(Gk(wk(new $wnd.Object,dd($c(ne,1),jp,2,6,['toggle-all']))),xh(an.prototype.ib,an,[a])),null),sk('ul',wk(new $wnd.Object,dd($c(ne,1),jp,2,6,['todo-list'])),Kj(Ij(T(a.g.c).V(),new bn),new uk))]):null,T(a.e.d)?(new mm).a:null])]);return b}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ci(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Gi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ci(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Ei(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Ii)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&lp!=(k.b.c&mp)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function Nk(a){var b,c;a.e=0;Kk();c=(b=T(a.i.b),sk('footer',wk(new $wnd.Object,dd($c(ne,1),jp,2,6,['footer'])),[(new pm).a,sk('ul',wk(new $wnd.Object,dd($c(ne,1),jp,2,6,['filters'])),[sk('li',null,[sk('a',yk(wk(new $wnd.Object,dd($c(ne,1),jp,2,6,[(Eo(),Co)==b?vp:null])),'#'),['All'])]),sk('li',null,[sk('a',yk(wk(new $wnd.Object,dd($c(ne,1),jp,2,6,[Bo==b?vp:null])),'#active'),['Active'])]),sk('li',null,[sk('a',yk(wk(new $wnd.Object,dd($c(ne,1),jp,2,6,[Do==b?vp:null])),'#completed'),['Completed'])])]),T(a.a)?sk('button',zk(wk(new $wnd.Object,dd($c(ne,1),jp,2,6,['clear-completed'])),xh(lm.prototype.kb,lm,[a])),['Clear Completed']):null]));return c}
function Dl(a){var b,c,d;a.g=0;Kk();b=(c=a.i,d=(gb(c.a),c.d),sk('li',wk(new $wnd.Object,dd($c(ne,1),jp,2,6,[d?'checked':null,T(a.c)?'editing':null])),[sk('div',wk(new $wnd.Object,dd($c(ne,1),jp,2,6,['view'])),[sk(yp,Dk(Bk(Gk(wk(new $wnd.Object,dd($c(ne,1),jp,2,6,['toggle']))),d),xh(Sm.prototype.ib,Sm,[c])),null),sk('label',Ik(new $wnd.Object,xh(Tm.prototype.kb,Tm,[a,c])),[(gb(c.b),c.e)]),sk('button',zk(wk(new $wnd.Object,dd($c(ne,1),jp,2,6,['destroy'])),xh(Um.prototype.kb,Um,[a,c])),null)]),sk(yp,Ek(Dk(Ck(Hk(wk(xk(new $wnd.Object,xh(Vm.prototype.A,Vm,[a])),dd($c(ne,1),jp,2,6,['edit'])),(gb(a.a),a.d)),xh(Wm.prototype.hb,Wm,[a,c])),xh(Rm.prototype.ib,Rm,[a])),xh(Xm.prototype.jb,Xm,[a,c])),null)]));return b}
function cj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[up]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!aj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[up]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var hp='object',ip={5:1},jp={3:1},kp={8:1},lp=1048576,mp=1835008,np=2097152,op=4194304,pp='__noinit__',qp={3:1,9:1,7:1,4:1},rp='null',sp=17592186044416,tp={38:1},up='delete',vp='selected',wp=1411518464,xp=142606336,yp='input',zp='header',Ap='hashchange',Bp=136314880,Cp='active',Dp='completed';var _,sh,nh,fh=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;th();vh(1,null,{},p);_.p=function(a){return o(this,a)};_.q=function(){return this.mb};_.r=Fp;_.s=function(){var a;return Kh(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.p(a)};_.hashCode=function(){return this.r()};_.toString=function(){return this.s()};var gd,hd,jd;vh(50,1,{},Lh);_.J=function(a){var b;b=new Lh;b.e=4;a>1?(b.c=Qh(this,a-1)):(b.c=this);return b};_.K=function(){Jh(this);return this.b};_.L=function(){return Kh(this)};_.M=function(){Jh(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.s=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Jh(this),this.k)};_.e=0;_.g=0;var Ih=1;var ke=Nh(1);var be=Nh(50);vh(78,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var xd=Nh(78);vh(79,1,ip,G);_.t=function(){Db(this.a)};var ud=Nh(79);vh(33,1,{},H);_.u=function(){return this.a.t(),null};var vd=Nh(33);vh(80,1,{},I);var wd=Nh(80);var J;vh(42,1,{42:1},Q);_.b=0;_.c=false;_.d=0;var yd=Nh(42);vh(232,1,kp);_.s=function(){var a;return Kh(this.mb)+'@'+(a=s(this)>>>0,a.toString(16))};var Bd=Nh(232);vh(17,232,kp,X);_.v=function(){S(this)};_.w=Ep;_.a=false;_.d=0;_.j=false;var Ad=Nh(17);vh(130,1,{},Y);_.u=function(){return U(this.a)};var zd=Nh(130);vh(15,232,{8:1,15:1},jb);_.v=function(){ab(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Dd=Nh(15);vh(129,1,ip,kb);_.t=function(){bb(this.a)};var Cd=Nh(129);vh(16,232,{8:1,16:1},wb,xb);_.v=function(){lb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Id=Nh(16);vh(131,1,{},yb);_.t=function(){R(this.a)};var Ed=Nh(131);vh(132,1,ip,zb);_.t=function(){nb(this.a)};var Fd=Nh(132);vh(133,1,ip,Ab);_.t=function(){qb(this.a)};var Gd=Nh(133);vh(134,1,{},Bb);_.A=function(a){ob(this.a,a)};var Hd=Nh(134);vh(144,1,{},Eb);_.a=0;_.b=0;_.c=0;var Jd=Nh(144);vh(165,1,kp,Gb);_.v=function(){Fb(this)};_.w=Ep;_.a=false;var Kd=Nh(165);vh(58,232,{8:1,58:1},Kb);_.v=function(){Hb(this)};_.w=function(){return 2==(3&this.a)};_.a=0;var Md=Nh(58);vh(143,1,{},Pb);var Ld=Nh(143);vh(146,1,{},_b);_.s=function(){var a;return Jh(Nd),Nd.k+'@'+(a=ek(this)>>>0,a.toString(16))};_.a=0;var Qb;var Nd=Nh(146);vh(97,1,{});var Qd=Nh(97);vh(86,1,{},hc);_.A=function(a){fc(this.a,a)};var Od=Nh(86);vh(87,1,ip,ic);_.t=function(){gc(this.a,this.b)};var Pd=Nh(87);vh(14,1,kp,pc);_.v=function(){kc(this)};_.w=function(){return this.i<0};_.s=function(){var a;return Jh(Sd),Sd.k+'@'+(a=ek(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Sd=Nh(14);vh(128,1,ip,qc);_.t=function(){nc(this.a)};var Rd=Nh(128);vh(4,1,{3:1,4:1});_.B=Kp;_.C=function(){return Kj(Ij(Mi((this.i==null&&(this.i=ad(pe,jp,4,0,0,1)),this.i)),new fi),new Oj)};_.D=function(){return this.f};_.F=function(){return this.g};_.G=function(){tc(this,vc(new Error(uc(this,this.g))));Xc(this)};_.s=function(){return uc(this,this.F())};_.e=pp;_.j=true;var pe=Nh(4);vh(9,4,{3:1,9:1,4:1});var ee=Nh(9);vh(7,9,qp);var le=Nh(7);vh(73,7,qp);var ie=Nh(73);vh(74,73,qp);var Wd=Nh(74);vh(32,74,{32:1,3:1,9:1,7:1,4:1},Ac);_.F=function(){zc(this);return this.c};_.H=function(){return rd(this.b)===rd(xc)?null:this.b};var xc;var Td=Nh(32);var Ud=Nh(0);vh(218,1,{});var Vd=Nh(218);var Cc=0,Dc=0,Ec=-1;vh(83,218,{},Sc);var Oc;var Xd=Nh(83);var Vc;vh(229,1,{});var Zd=Nh(229);vh(75,229,{},Zc);var Yd=Nh(75);var Ch;vh(71,1,{68:1});_.s=Ep;var $d=Nh(71);vh(77,7,qp);var ge=Nh(77);vh(157,77,qp,Gh);var _d=Nh(157);gd={3:1,69:1,31:1};var ae=Nh(69);vh(39,1,{3:1,39:1});var je=Nh(39);hd={3:1,31:1,39:1};var ce=Nh(228);vh(40,1,{3:1,31:1,40:1});_.p=function(a){return this===a};_.r=Fp;_.s=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=Nh(40);vh(76,7,qp,Vh);var fe=Nh(76);vh(26,39,{3:1,31:1,26:1,39:1},Wh);_.p=function(a){return md(a,26)&&a.a==this.a};_.r=Ep;_.s=function(){return ''+this.a};_.a=0;var he=Nh(26);var Yh;vh(292,1,{});jd={3:1,68:1,31:1,2:1};var ne=Nh(2);vh(72,71,{68:1},ei);var me=Nh(72);vh(296,1,{});vh(66,1,{},fi);_.R=function(a){return a.e};var oe=Nh(66);vh(52,7,qp,gi);var qe=Nh(52);vh(230,1,{37:1});_.P=Jp;_.U=function(){return new xj(this,0)};_.V=function(){return new Lj(null,this.U())};_.S=function(a){throw hh(new gi('Add not supported on this collection'))};_.s=function(){var a,b,c;c=new zj('[',']');for(b=this.Q();b.X();){a=b.Y();yj(c,a===this?'(this Collection)':a==null?rp:zh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var re=Nh(230);vh(234,1,{216:1});_.p=function(a){var b,c,d;if(a===this){return true}if(!md(a,34)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ui((new ri(d)).a);c.b;){b=ti(c);if(!ji(this,b)){return false}}return true};_.r=function(){return Ni(new ri(this))};_.s=function(){var a,b,c;c=new zj('{','}');for(b=new ui((new ri(this)).a);b.b;){a=ti(b);yj(c,ki(this,a.$())+'='+ki(this,a._()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ce=Nh(234);vh(142,234,{216:1});var ue=Nh(142);vh(233,230,{37:1,239:1});_.U=function(){return new xj(this,1)};_.p=function(a){var b;if(a===this){return true}if(!md(a,20)){return false}b=a;if(pi(b.a)!=this.T()){return false}return hi(this,b)};_.r=function(){return Ni(this)};var De=Nh(233);vh(20,233,{20:1,37:1,239:1},ri);_.Q=function(){return new ui(this.a)};_.T=Hp;var te=Nh(20);vh(21,1,{},ui);_.W=Gp;_.Y=function(){return ti(this)};_.X=Ip;_.b=false;var se=Nh(21);vh(231,230,{37:1,236:1});_.U=function(){return new xj(this,16)};_.Z=function(a,b){throw hh(new gi('Add not supported on this list'))};_.S=function(a){this.Z(this.T(),a);return true};_.p=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,12)){return false}f=a;if(this.T()!=f.a.length){return false}e=new Ki(f);for(c=new Ki(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(rd(b)===rd(d)||b!=null&&q(b,d))){return false}}return true};_.r=function(){return Oi(this)};_.Q=function(){return new vi(this)};var we=Nh(231);vh(82,1,{},vi);_.W=Gp;_.X=function(){return this.a<this.b.a.length};_.Y=function(){return Ci(this.b,this.a++)};_.a=0;var ve=Nh(82);vh(41,230,{37:1},wi);_.Q=function(){var a;a=new ui((new ri(this.a)).a);return new xi(a)};_.T=Hp;var ye=Nh(41);vh(137,1,{},xi);_.W=Gp;_.X=function(){return this.a.b};_.Y=function(){var a;a=ti(this.a);return a._()};var xe=Nh(137);vh(135,1,tp);_.p=function(a){var b;if(!md(a,38)){return false}b=a;return Pi(this.a,b.$())&&Pi(this.b,b._())};_.$=Ep;_._=Ip;_.r=function(){return oj(this.a)^oj(this.b)};_.ab=function(a){var b;b=this.b;this.b=a;return b};_.s=function(){return this.a+'='+this.b};var ze=Nh(135);vh(136,135,tp,yi);var Ae=Nh(136);vh(235,1,tp);_.p=function(a){var b;if(!md(a,38)){return false}b=a;return Pi(this.b.value[0],b.$())&&Pi(kj(this),b._())};_.r=function(){return oj(this.b.value[0])^oj(kj(this))};_.s=function(){return this.b.value[0]+'='+kj(this)};var Be=Nh(235);vh(12,231,{3:1,12:1,37:1,236:1},Ii,Ji);_.Z=function(a,b){_j(this.a,a,b)};_.S=function(a){return Ai(this,a)};_.P=function(a){Bi(this,a)};_.Q=function(){return new Ki(this)};_.T=function(){return this.a.length};var Fe=Nh(12);vh(13,1,{},Ki);_.W=Gp;_.X=function(){return this.a<this.c.a.length};_.Y=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ee=Nh(13);vh(34,142,{3:1,34:1,216:1},Qi);var Ge=Nh(34);vh(56,1,{},Wi);_.P=Jp;_.Q=function(){return new Xi(this)};_.b=0;var Ie=Nh(56);vh(57,1,{},Xi);_.W=Gp;_.Y=function(){return this.d=this.a[this.c++],this.d};_.X=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var He=Nh(57);var $i;vh(54,1,{},ij);_.P=Jp;_.Q=function(){return new jj(this)};_.b=0;_.c=0;var Le=Nh(54);vh(55,1,{},jj);_.W=Gp;_.Y=function(){return this.c=this.a,this.a=this.b.next(),new lj(this.d,this.c,this.d.c)};_.X=function(){return !this.a.done};var Je=Nh(55);vh(145,235,tp,lj);_.$=function(){return this.b.value[0]};_._=function(){return kj(this)};_.ab=function(a){return gj(this.a,this.b.value[0],a)};_.c=0;var Ke=Nh(145);vh(148,1,{});_.W=Lp;_.bb=function(){return this.d};_.cb=Kp;_.d=0;_.e=0;var Pe=Nh(148);vh(59,148,{});var Me=Nh(59);vh(138,1,{});_.W=Lp;_.bb=Ip;_.cb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Oe=Nh(138);vh(139,138,{},vj);_.W=function(a){sj(this,a)};_.db=function(a){return tj(this,a)};var Ne=Nh(139);vh(18,1,{},xj);_.bb=Ep;_.cb=function(){wj(this);return this.c};_.W=function(a){wj(this);this.d.W(a)};_.db=function(a){wj(this);if(this.d.X()){a.A(this.d.Y());return true}return false};_.a=0;_.c=0;var Qe=Nh(18);vh(51,1,{},zj);_.s=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Re=Nh(51);vh(30,1,{},Aj);_.R=function(a){return a};var Se=Nh(30);vh(35,1,{},Bj);var Te=Nh(35);vh(147,1,{});_.c=false;var bf=Nh(147);vh(22,147,{},Lj);var af=Nh(22);vh(67,1,{},Oj);_.eb=function(a){return ad(ke,jp,1,a,5,1)};var Ue=Nh(67);vh(150,59,{},Qj);_.db=function(a){this.b=false;while(!this.b&&this.c.db(new Rj(this,a)));return this.b};_.b=false;var We=Nh(150);vh(153,1,{},Rj);_.A=function(a){Pj(this.a,this.b,a)};var Ve=Nh(153);vh(149,59,{},Tj);_.db=function(a){return this.b.db(new Uj(this,a))};var Ye=Nh(149);vh(152,1,{},Uj);_.A=function(a){Sj(this.a,this.b,a)};var Xe=Nh(152);vh(151,1,{},Wj);_.A=function(a){Vj(this,a)};var Ze=Nh(151);vh(154,1,{},Xj);_.A=function(a){};var $e=Nh(154);vh(155,1,{},Zj);_.A=function(a){Yj(this,a)};var _e=Nh(155);vh(294,1,{});vh(291,1,{});var dk=0;var fk,gk=0,hk;vh(908,1,{});vh(933,1,{});vh(166,1,{},uk);_.eb=function(a){return new Array(a)};var cf=Nh(166);vh(259,$wnd.Function,{},vk);_.gb=function(a){tk(this.a,this.b,a)};var Jk;vh(164,1,{257:1},Lk);var df=Nh(164);vh(187,1,{});var Pf=Nh(187);vh(188,187,{});_.e=0;var Tf=Nh(188);vh(189,188,kp,Tk);_.v=Mp;_.w=Np;_.s=function(){var a;return Jh(nf),nf.k+'@'+(a=ek(this)>>>0,a.toString(16))};var Pk=0;var nf=Nh(189);vh(190,1,ip,Uk);_.t=function(){Qk(this.a)};var ef=Nh(190);vh(191,1,{},Vk);_.u=function(){return Sk(this.a)};var ff=Nh(191);vh(193,1,{},Wk);_.u=function(){return Nk(this.a)};var gf=Nh(193);vh(192,1,{},Xk);_.t=function(){Ok(this.a)};var hf=Nh(192);vh(209,1,{});var Of=Nh(209);vh(210,209,{});_.d=0;var Sf=Nh(210);vh(211,210,kp,bl);_.v=Op;_.w=Pp;_.s=function(){var a;return Jh(mf),mf.k+'@'+(a=ek(this)>>>0,a.toString(16))};var _k=0;var mf=Nh(211);vh(212,1,ip,cl);_.t=Qp;var jf=Nh(212);vh(213,1,{},dl);_.t=function(){$k(this.a)};var kf=Nh(213);vh(214,1,{},el);_.u=function(){return Zk(this.a)};var lf=Nh(214);vh(179,1,{});_.g='';var ag=Nh(179);vh(180,179,{});_.e=0;var Vf=Nh(180);vh(181,180,kp,ql);_.v=Mp;_.w=Np;_.s=function(){var a;return Jh(tf),tf.k+'@'+(a=ek(this)>>>0,a.toString(16))};var kl=0;var tf=Nh(181);vh(182,1,ip,rl);_.t=function(){ll(this.a)};var of=Nh(182);vh(184,1,{},sl);_.u=function(){return il(this.a)};var pf=Nh(184);vh(185,1,ip,tl);_.t=function(){fl(this.a)};var qf=Nh(185);vh(183,1,{},ul);_.t=function(){Ok(this.a)};var rf=Nh(183);vh(186,1,ip,vl);_.t=function(){ol(this.a,this.b)};var sf=Nh(186);vh(171,1,{});_.k=false;var dg=Nh(171);vh(195,171,{});_.g=0;var Xf=Nh(195);vh(196,195,kp,Rl);_.v=function(){kc(this.e)};_.w=function(){return this.e.i<0};_.s=function(){var a;return Jh(Ff),Ff.k+'@'+(a=ek(this)>>>0,a.toString(16))};var Fl=0;var Ff=Nh(196);vh(197,1,ip,Sl);_.t=function(){Gl(this.a)};var uf=Nh(197);vh(200,1,ip,Tl);_.t=function(){kc(this.a.e)};var vf=Nh(200);vh(201,1,{},Ul);_.u=function(){return Dl(this.a)};var wf=Nh(201);vh(198,1,{},Vl);_.u=function(){return Jl(this.a)};var xf=Nh(198);vh(43,1,ip,Wl);_.t=function(){Ql(this.a,pn(this.b))};var yf=Nh(43);vh(62,1,ip,Xl);_.t=function(){Al(this.a,this.b)};var zf=Nh(62);vh(202,1,ip,Yl);_.t=function(){Kl(this.a,this.b)};var Af=Nh(202);vh(199,1,{},Zl);_.t=function(){El(this.a)};var Bf=Nh(199);vh(203,1,ip,$l);_.t=function(){Ll(this.a,this.b)};var Cf=Nh(203);vh(204,1,ip,_l);_.t=function(){wl(this.a,this.b)};var Df=Nh(204);vh(205,1,ip,am);_.t=function(){Bl(this.a)};var Ef=Nh(205);vh(158,1,{});var hg=Nh(158);vh(159,158,{});_.d=0;var Zf=Nh(159);vh(160,159,kp,hm);_.v=Op;_.w=Pp;_.s=function(){var a;return Jh(Jf),Jf.k+'@'+(a=ek(this)>>>0,a.toString(16))};var fm=0;var Jf=Nh(160);vh(161,1,ip,im);_.t=Qp;var Gf=Nh(161);vh(162,1,{},jm);_.t=function(){$k(this.a)};var Hf=Nh(162);vh(163,1,{},km);_.u=function(){return dm(this.a)};var If=Nh(163);vh(263,$wnd.Function,{},lm);_.kb=function(a){fo(this.a.g)};vh(168,1,{},mm);var Kf=Nh(168);vh(89,1,{},nm);var Lf=Nh(89);var om;vh(194,1,{},pm);var Mf=Nh(194);vh(84,1,{},qm);var Nf=Nh(84);var rm;vh(264,$wnd.Function,{},sm);_.lb=function(a){return new vm(a)};var tm;vh(173,$wnd.React.Component,{},vm);uh(sh[1],_);_.componentWillUnmount=function(){Mk(this.a)};_.render=function(){return Rk(this.a)};_.shouldComponentUpdate=Rp;var Qf=Nh(173);vh(275,$wnd.Function,{},wm);_.lb=function(a){return new zm(a)};var xm;vh(206,$wnd.React.Component,{},zm);uh(sh[1],_);_.componentWillUnmount=function(){Yk(this.a)};_.render=function(){return al(this.a)};_.shouldComponentUpdate=Sp;var Rf=Nh(206);vh(262,$wnd.Function,{},Am);_.lb=function(a){return new Dm(a)};var Bm;vh(172,$wnd.React.Component,{},Dm);uh(sh[1],_);_.componentWillUnmount=function(){Mk(this.a)};_.render=function(){return ml(this.a)};_.shouldComponentUpdate=Rp;var Uf=Nh(172);vh(266,$wnd.Function,{},Em);_.lb=function(a){return new Hm(a)};var Fm;vh(178,$wnd.React.Component,{},Hm);uh(sh[1],_);_.componentDidUpdate=function(a){$(this.a)&&(Ol(this.a),undefined)};_.componentWillUnmount=function(){$(this.a)&&Cl(this.a)};_.render=function(){return $(this.a)?Hl(this.a):null};_.shouldComponentUpdate=function(a){return $(this.a)&&1==this.a.g};var Wf=Nh(178);vh(256,$wnd.Function,{},Im);_.lb=function(a){return new Lm(a)};var Jm;vh(140,$wnd.React.Component,{},Lm);uh(sh[1],_);_.componentWillUnmount=function(){Yk(this.a)};_.render=function(){return gm(this.a)};_.shouldComponentUpdate=Sp;var Yf=Nh(140);vh(260,$wnd.Function,{},Mm);_.jb=function(a){gl(this.a,a)};vh(261,$wnd.Function,{},Nm);_.ib=function(a){nl(this.a,a)};vh(167,1,{},Om);var $f=Nh(167);vh(95,1,{},Pm);var _f=Nh(95);var Qm;vh(273,$wnd.Function,{},Rm);_.ib=function(a){Il(this.a,a)};vh(267,$wnd.Function,{},Sm);_.ib=function(a){Kn(this.a)};vh(269,$wnd.Function,{},Tm);_.kb=function(a){Ml(this.a,this.b)};vh(270,$wnd.Function,{},Um);_.kb=function(a){xl(this.a,this.b)};vh(271,$wnd.Function,{},Vm);_.A=function(a){yl(this.a,a)};vh(272,$wnd.Function,{},Wm);_.hb=function(a){Nl(this.a,this.b)};vh(274,$wnd.Function,{},Xm);_.jb=function(a){zl(this.a,this.b,a)};vh(170,1,{},Zm);var bg=Nh(170);vh(96,1,{},$m);var cg=Nh(96);var _m;vh(255,$wnd.Function,{},an);_.ib=function(a){bm(this.a,a)};vh(141,1,{},bn);_.R=function(a){return Ym(new Zm,a)};var eg=Nh(141);vh(65,1,{},cn);var fg=Nh(65);vh(94,1,{},dn);var gg=Nh(94);var en;vh(64,1,{},fn);var ig=Nh(64);vh(108,1,{});var Og=Nh(108);vh(109,108,kp,tn);_.v=Mp;_.w=Np;_.s=function(){var a;return Jh(qg),qg.k+'@'+(a=ek(this)>>>0,a.toString(16))};var qg=Nh(109);vh(110,1,ip,un);_.t=function(){nn(this.a)};var jg=Nh(110);vh(112,1,{},vn);_.t=function(){hn(this.a)};var kg=Nh(112);vh(113,1,{},wn);_.t=function(){jn(this.a)};var lg=Nh(113);vh(114,1,ip,xn);_.t=function(){gn(this.a,this.b)};var mg=Nh(114);vh(115,1,ip,yn);_.t=function(){qn(this.a)};var ng=Nh(115);vh(53,1,ip,zn);_.t=function(){mn(this.a)};var og=Nh(53);vh(111,1,{},An);_.u=function(){var a;return a=(Dh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var pg=Nh(111);vh(44,1,{44:1});_.d=false;var Wg=Nh(44);vh(45,44,{8:1,258:1,45:1,44:1},Ln);_.v=Mp;_.p=function(a){return En(this,a)};_.r=function(){return this.c.d};_.w=Np;_.s=function(){var a;return Jh(Gg),Gg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Bn=0;var Gg=Nh(45);vh(207,1,ip,Mn);_.t=function(){Cn(this.a)};var rg=Nh(207);vh(208,1,ip,Nn);_.t=function(){Hn(this.a)};var sg=Nh(208);vh(98,97,{});var Rg=Nh(98);vh(99,98,kp,Vn);_.v=Tp;_.w=Up;_.s=function(){var a;return Jh(Bg),Bg.k+'@'+(a=ek(this)>>>0,a.toString(16))};var Bg=Nh(99);vh(101,1,ip,Wn);_.t=function(){Pn(this.a)};var tg=Nh(101);vh(100,1,ip,Xn);_.t=function(){Sn(this.a)};var ug=Nh(100);vh(106,1,ip,Yn);_.t=function(){cc(this.a,this.b,true)};var vg=Nh(106);vh(107,1,{},Zn);_.u=function(){return On(this.a,this.c,this.b)};_.b=false;var wg=Nh(107);vh(102,1,{},$n);_.u=function(){return Tn(this.a)};var xg=Nh(102);vh(103,1,{},_n);_.u=function(){return Xh(mh(Gj(dc(this.a))))};var yg=Nh(103);vh(104,1,{},ao);_.u=function(){return Xh(mh(Gj(Hj(dc(this.a),new Ho))))};var zg=Nh(104);vh(105,1,{},bo);_.u=function(){return Un(this.a)};var Ag=Nh(105);vh(116,1,{});var Vg=Nh(116);vh(117,116,kp,jo);_.v=function(){kc(this.a)};_.w=function(){return this.a.i<0};_.s=function(){var a;return Jh(Fg),Fg.k+'@'+(a=ek(this)>>>0,a.toString(16))};var Fg=Nh(117);vh(118,1,ip,ko);_.t=function(){go(this.a,this.b)};_.b=false;var Cg=Nh(118);vh(119,1,ip,lo);_.t=function(){sn(this.b,this.a)};var Dg=Nh(119);vh(120,1,ip,mo);_.t=function(){ho(this.a)};var Eg=Nh(120);vh(121,1,{});var Yg=Nh(121);vh(122,121,kp,uo);_.v=Tp;_.w=Up;_.s=function(){var a;return Jh(Mg),Mg.k+'@'+(a=ek(this)>>>0,a.toString(16))};var Mg=Nh(122);vh(123,1,ip,vo);_.t=function(){po(this.a)};var Hg=Nh(123);vh(127,1,ip,wo);_.t=function(){to(this.a,null)};var Ig=Nh(127);vh(124,1,{},xo);_.u=function(){var a;return a=pn(this.a.g),o(Cp,a)?(Eo(),Bo):o(Dp,a)?(Eo(),Do):(Eo(),Co)};var Jg=Nh(124);vh(125,1,{},yo);_.u=function(){return ro(this.a)};var Kg=Nh(125);vh(126,1,{},zo);_.t=function(){so(this.a)};var Lg=Nh(126);vh(88,1,{},Ao);_.handleEvent=function(a){kn(this.a,a)};var Ng=Nh(88);vh(27,40,{3:1,31:1,40:1,27:1},Fo);var Bo,Co,Do;var Pg=Oh(27,Go);vh(85,1,{},Ho);_.fb=function(a){return !Gn(a)};var Qg=Nh(85);vh(91,1,{},Io);_.fb=function(a){return Gn(a)};var Sg=Nh(91);vh(92,1,{},Jo);_.A=function(a){Rn(this.a,a)};var Tg=Nh(92);vh(90,1,{},Ko);_.A=function(a){eo(this.a,a)};_.a=false;var Ug=Nh(90);vh(93,1,{},Lo);_.fb=function(a){return oo(this.a,a)};var Xg=Nh(93);vh(174,1,{});var Zg=Nh(174);vh(177,1,{},Vo);_.b=0;_.c=false;_.d=0;var $g=Nh(177);vh(60,174,{});_.a=0;_.b=0;_.c=0;var bh=Nh(60);vh(176,60,{},Yo);var _g=Nh(176);vh(265,$wnd.Function,{},Zo);_.I=function(a){return Wo((new $o(this.a)).a),null};vh(175,1,{},$o);var ah=Nh(175);vh(61,1,{61:1},ap);_.s=function(){var a;return Jh(dh),dh.k+'@'+(a=ek(this)>>>0,a.toString(16))};var dh=Nh(61);vh(169,1,{},cp);_.s=function(){var a;return Jh(eh),eh.k+'@'+(a=ek(this)>>>0,a.toString(16))};var eh=Nh(169);var dp;var td=Ph('D');var gp=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=qh;oh(Bh);rh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();