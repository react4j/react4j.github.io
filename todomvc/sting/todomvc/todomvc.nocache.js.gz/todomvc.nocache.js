function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='7028EF1FF066791D323DF2589F30A09E',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '7028EF1FF066791D323DF2589F30A09E';function p(){}
function sh(){}
function oh(){}
function $h(){}
function Gb(){}
function Sc(){}
function Zc(){}
function tj(){}
function Hj(){}
function Pj(){}
function Qj(){}
function nk(){}
function bl(){}
function Jm(){}
function Nm(){}
function Rm(){}
function Vm(){}
function Zm(){}
function Zo(){}
function Yo(){}
function tn(){}
function Rn(){}
function Xc(a){Wc()}
function zh(){zh=oh}
function Bi(){si(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function hc(a){this.a=a}
function qc(a){this.a=a}
function qi(a){this.a=a}
function ki(a){this.a=a}
function pi(a){this.a=a}
function Ph(a){this.a=a}
function Zh(a){this.a=a}
function uj(a){this.a=a}
function Sj(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function Jl(a){this.a=a}
function Kl(a){this.a=a}
function Ll(a){this.a=a}
function Ml(a){this.a=a}
function im(a){this.a=a}
function jm(a){this.a=a}
function km(a){this.a=a}
function pm(a){this.a=a}
function rm(a){this.a=a}
function zm(a){this.a=a}
function Am(a){this.a=a}
function Bm(a){this.a=a}
function Cm(a){this.a=a}
function bn(a){this.a=a}
function cn(a){this.a=a}
function gn(a){this.a=a}
function hn(a){this.a=a}
function ln(a){this.a=a}
function sn(a){this.a=a}
function Ln(a){this.a=a}
function Mn(a){this.a=a}
function Nn(a){this.a=a}
function Pn(a){this.a=a}
function Qn(a){this.a=a}
function bo(a){this.a=a}
function co(a){this.a=a}
function mo(a){this.a=a}
function no(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function so(a){this.a=a}
function to(a){this.a=a}
function Do(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Qo(a){this.a=a}
function Ro(a){this.a=a}
function $o(a){this.a=a}
function _o(a){this.a=a}
function ap(a){this.a=a}
function oi(a){this.b=a}
function Di(a){this.c=a}
function Jp(){kc(this.c)}
function Lp(){kc(this.b)}
function Qp(){kc(this.f)}
function w(a){--a.e;D(a)}
function Z(a){!!a&&ab(a)}
function lc(a){!!a&&a.s()}
function Pi(){this.a=Yi()}
function bj(){this.a=Yi()}
function Oj(a,b){a.a=b}
function rb(a,b){a.b=b}
function ik(a,b){a.key=b}
function gk(a,b){fk(a,b)}
function vo(a,b){gm(b,a)}
function oc(a,b){gi(a.e,b)}
function Rj(a,b){Gj(a.a,b)}
function Pl(a,b){ho(a.k,b)}
function uo(a,b){go(a.b,b)}
function C(a,b){Ob(a.f,b.f)}
function L(a,b){P(a);M(a,b)}
function Dp(a){fj(this,a)}
function Ip(a){ij(this,a)}
function Gp(a){Th(this,a)}
function Np(){lb(this.a.a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function $g(a){return a.e}
function Hp(){return this.e}
function Bp(){return this.a}
function Fp(){return this.b}
function Ql(a,b){return a.i=b}
function Cp(){return Zj(this)}
function Ui(){Ui=oh;Ti=Wi()}
function K(){K=oh;J=new F}
function yc(){yc=oh;xc=new p}
function Pc(){Pc=oh;Oc=new Sc}
function cl(a){a.e=2;kc(a.c)}
function ol(a){a.d=2;kc(a.b)}
function Ul(a){a.g=2;kc(a.e)}
function tc(a,b){a.e=b;sc(a,b)}
function Wj(a,b){a.splice(b,1)}
function jc(a,b,c){fi(a.e,b,c)}
function Un(a,b,c){jc(a.c,b,c)}
function nj(a,b,c){b.w(a.a[c])}
function vi(a,b){return a.a[b]}
function Ch(a){Bh(a);return a.k}
function gl(a){lb(a.b);S(a.a)}
function Dl(a){lb(a.a);ab(a.b)}
function En(a){S(a.a);ab(a.b)}
function Tn(a){ab(a.b);ab(a.a)}
function yh(a){wc.call(this,a)}
function _h(a){wc.call(this,a)}
function Ep(){return ii(this.a)}
function Kp(){return this.c.i<0}
function Mp(){return this.b.i<0}
function Rp(){return this.f.i<0}
function $c(a,b){return Ih(a,b)}
function Gj(a,b){Oj(a,Fj(a.a,b))}
function ij(a,b){while(a.cb(b));}
function Lj(a,b,c){b.w(a.a.Q(c))}
function v(a,b,c){t(a,new I(c),b)}
function Fj(a,b){a.R(b);return a}
function U(a){nb(a.f);return W(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function bb(a){K();Zb(a);a.e=-2}
function Hm(a){this.a=a;Im=this}
function en(a){this.a=a;fn=this}
function ii(a){return a.a.b+a.b.b}
function Op(a){return 1==this.a.e}
function Pp(a){return 1==this.a.d}
function Xn(a){gb(a.a);return a.d}
function Gn(a){gb(a.b);return a.e}
function Ho(a){gb(a.d);return a.e}
function qk(a,b){a.ref=b;return a}
function ic(a,b){this.a=a;this.b=b}
function Nh(a,b){this.a=a;this.b=b}
function Nj(a,b){this.a=a;this.b=b}
function Kj(a,b){this.a=a;this.b=b}
function ri(a,b){this.a=a;this.b=b}
function ok(a,b){this.a=a;this.b=b}
function Nl(a,b){this.a=a;this.b=b}
function lm(a,b){this.a=a;this.b=b}
function mm(a,b){this.a=a;this.b=b}
function nm(a,b){this.a=a;this.b=b}
function om(a,b){this.a=a;this.b=b}
function qm(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function Dm(){this.a=kk((Lm(),Km))}
function Gm(){this.a=kk((Pm(),Om))}
function dn(){this.a=kk((Tm(),Sm))}
function Fc(){Fc=oh;!!(Wc(),Vc)}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function hh(){fh==null&&(fh=[])}
function pn(){this.a=kk((Xm(),Wm))}
function un(){this.a=kk((_m(),$m))}
function jn(a,b){this.a=a;this.b=b}
function kn(a,b){this.a=a;this.b=b}
function mn(a,b){this.a=a;this.b=b}
function nn(a,b){this.a=a;this.b=b}
function On(a,b){this.a=a;this.b=b}
function oo(a,b){this.a=a;this.b=b}
function Bo(a,b){this.a=a;this.b=b}
function Co(a,b){this.b=a;this.a=b}
function Wo(a,b){Nh.call(this,a,b)}
function Zk(a,b){Nh.call(this,a,b)}
function Uj(a,b,c){a.splice(b,0,c)}
function Ak(a,b){a.value=b;return a}
function rk(a,b){a.href=b;return a}
function Xh(a,b){a.a+=''+b;return a}
function $i(a,b){return a.a.get(b)}
function o(a,b){return rd(a)===rd(b)}
function od(a){return typeof a===dp}
function ei(a){return !a?null:a.$()}
function Ub(a){return !a.d?a:Ub(a.d)}
function hj(a){return a!=null?s(a):0}
function rd(a){return a==null?null:a}
function Yi(){Ui();return new Ti}
function hi(a){a.a=new Pi;a.b=new bj}
function bk(){bk=oh;$j=new p;ak=new p}
function jb(a){this.c=new Bi;this.b=a}
function Mc(a){$wnd.clearTimeout(a)}
function Hn(a){Fn(a,(gb(a.b),a.e))}
function Yn(a){gm(a,(gb(a.a),!a.d))}
function Yl(a){lb(a.b);S(a.c);ab(a.a)}
function gc(a,b){cc(a,b,false);fb(a.c)}
function Vj(a,b){Tj(b,0,a,0,b.length)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function $(a){return !(!!a&&1==(a.c&7))}
function qb(a){K();pb(a);tb(a,2,true)}
function si(a){a.a=ad(ke,fp,1,0,5,1)}
function Q(){this.a=ad(ke,fp,1,100,5,1)}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function xo(a,b){ui(ec(a.b),new _o(b))}
function fk(a,b){for(var c in a){b(c)}}
function vk(a,b){a.onBlur=b;return a}
function sk(a,b){a.onClick=b;return a}
function wk(a,b){a.onChange=b;return a}
function uk(a,b){a.checked=b;return a}
function xk(a,b){a.onKeyDown=b;return a}
function hk(a,b){a.props['a']=b;return a}
function tk(a){a.autoFocus=true;return a}
function Bh(a){if(a.k!=null){return}Kh(a)}
function md(a,b){return a!=null&&kd(a,b)}
function Uh(a,b){return a.charCodeAt(b)}
function ed(a,b,c){return {l:a,m:b,h:c}}
function Zj(a){return a.$H||(a.$H=++Yj)}
function qd(a){return typeof a==='string'}
function nd(a){return typeof a==='boolean'}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function fc(a,b){oc(b.c,a);md(b,9)&&b.u()}
function fj(a,b){while(a.W()){Rj(b,a.X())}}
function qn(a,b){this.a=a;this.b=b;rn=this}
function wc(a){this.g=a;rc(this);this.F()}
function Ej(a,b){xj.call(this,a);this.a=b}
function Ri(a,b){var c;c=a[qp];c.call(a,b)}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function Gc(a,b,c){return a.apply(b,c);var d}
function ko(a){return Qh(T(a.e).a-T(a.a).a)}
function Go(a){lb(a.a);S(a.b);S(a.c);ab(a.d)}
function _n(a){A((K(),K(),J),new co(a),up)}
function In(a){A((K(),K(),J),new Pn(a),up)}
function em(a){A((K(),K(),J),new rm(a),up)}
function wo(a){A((K(),K(),J),new Do(a),up)}
function Sh(){Sh=oh;Rh=ad(he,fp,28,256,0,1)}
function Wc(){Wc=oh;var a;!Yc();a=new Zc;Vc=a}
function Ji(){this.a=new Pi;this.b=new bj}
function ej(a,b,c){this.a=a;this.b=b;this.c=c}
function Bk(a,b){a.onDoubleClick=b;return a}
function ti(a,b){a.a[a.a.length]=b;return true}
function rc(a){a.j&&a.e!==lp&&a.F();return a}
function Fh(a){var b;b=Eh(a);Mh(a,b);return b}
function Db(a){while(true){if(!Cb(a)){break}}}
function lj(a,b){while(a.c<a.d){nj(a,b,a.c++)}}
function Fl(a,b){A((K(),K(),J),new Nl(a,b),up)}
function $l(a,b){A((K(),K(),J),new qm(a,b),up)}
function cm(a,b){A((K(),K(),J),new nm(a,b),up)}
function dm(a,b){A((K(),K(),J),new mm(a,b),up)}
function fm(a,b){A((K(),K(),J),new lm(a,b),up)}
function ho(a,b){A((K(),K(),J),new oo(a,b),up)}
function zo(a,b){A((K(),K(),J),new Bo(a,b),up)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Gl(a,b){var c;c=b.target;Hl(a,c.value)}
function yj(a,b){var c;return Cj(a,(c=new Bi,c))}
function Hh(a){var b;b=Eh(a);b.j=a;b.e=1;return b}
function mi(a){var b;b=a.a.X();a.b=li(a);return b}
function pj(a){if(!a.d){a.d=a.b.P();a.c=a.b.S()}}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function Ij(a,b,c){if(a.a.eb(c)){a.b=true;b.w(c)}}
function wh(a,b,c,d){a.addEventListener(b,c,d)}
function xh(a,b,c,d){a.removeEventListener(b,c,d)}
function Zi(a,b){return !(a.a.get(b)===undefined)}
function Eo(a){return o(zp,a)||o(Ap,a)||o('',a)}
function Ei(a,b){return jj(b,a.length),new oj(a,b)}
function jo(a){return zh(),0!=T(a.e).a?true:false}
function Fi(a){return new Ej(null,Ei(a,a.length))}
function hl(a){return B((K(),K(),J),a.b,new ml(a))}
function il(a){return zh(),T(a.f.b).a>0?true:false}
function cd(a){return Array.isArray(a)&&a.nb===sh}
function ld(a){return !Array.isArray(a)&&a.nb===sh}
function sl(a){return B((K(),K(),J),a.a,new wl(a))}
function El(a){return B((K(),K(),J),a.a,new Kl(a))}
function Zl(a){return B((K(),K(),J),a.b,new jm(a))}
function xm(a){return B((K(),K(),J),a.a,new Bm(a))}
function fo(a){S(a.d);S(a.e);S(a.a);S(a.b);ab(a.c)}
function io(a){Th(new pi(a.g),new hc(a));hi(a.g)}
function Wl(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function el(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function ql(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function ek(){if(_j==256){$j=ak;ak=new p;_j=0}++_j}
function vj(a){if(!a.b){wj(a);a.c=true}else{vj(a.b)}}
function Hl(a,b){var c;c=a.g;if(b!=c){a.g=b;fb(a.b)}}
function gm(a,b){var c;c=a.d;if(b!=c){a.d=b;fb(a.a)}}
function xi(a,b){var c;c=a.a[b];Wj(a.a,b);return c}
function zi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function po(a,b){this.a=a;this.c=b;this.b=false}
function kj(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Jn(a,b){var c;c=a.e;if(b!=c){a.e=b;fb(a.b)}}
function sm(a,b){var c;c=b.target;zo(a.f,c.checked)}
function zk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function ji(a,b){if(b){return ci(a.a,b)}return false}
function Aj(a,b){wj(a);return new Ej(a,new Jj(b,a.a))}
function Bj(a,b){wj(a);return new Ej(a,new Mj(b,a.a))}
function Fn(a,b){A((K(),K(),J),new On(a,b),75497472)}
function Ii(a,b){return rd(a)===rd(b)||a!=null&&q(a,b)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Dn(a){var b;V(a.a);b=T(a.a);o(a.f,b)&&Jn(a,b)}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function am(a,b){Ko(a.n,b);A((K(),K(),J),new lm(a,b),up)}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function oj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Em(a,b,c){this.a=a;this.b=b;this.c=c;Fm=this}
function vn(a,b,c){this.a=a;this.b=b;this.c=c;wn=this}
function qj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function xj(a){if(!a){this.b=null;new Bi}else{this.b=a}}
function Jh(a){if(a.N()){return null}var b=a.j;return kh[b]}
function eh(a){if(od(a)){return a|0}return a.l|a.m<<22}
function vh(){vh=oh;uh=$wnd.goog.global.document}
function Gh(a,b){var c;c=Eh(a);Mh(a,c);c.e=b?8:0;return c}
function uc(a,b){var c;c=Ch(a.lb);return b==null?c:c+': '+b}
function Ol(a,b){var c;if(T(a.c)){c=b.target;gm(a,c.value)}}
function Th(a,b){var c,d;for(d=a.P();d.W();){c=d.X();b.w(c)}}
function di(a,b){return b===a?'(this Map)':b==null?np:rh(b)}
function Xo(){Vo();return dd($c(Og,1),fp,30,0,[So,Uo,To])}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&jp)&&D((null,J))}
function bm(a,b){A((K(),K(),J),new lm(a,b),up);Ko(a.n,null)}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function qh(a){function b(){}
;b.prototype=a||{};return new b}
function wj(a){if(a.b){wj(a.b)}else if(a.c){throw $g(new Oh)}}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function Ih(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.I(b))}
function Li(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Lm(){Lm=oh;var a;Km=(a=ph(Jm.prototype.kb,Jm,[]),a)}
function Pm(){Pm=oh;var a;Om=(a=ph(Nm.prototype.kb,Nm,[]),a)}
function Tm(){Tm=oh;var a;Sm=(a=ph(Rm.prototype.kb,Rm,[]),a)}
function Xm(){Xm=oh;var a;Wm=(a=ph(Vm.prototype.kb,Vm,[]),a)}
function _m(){_m=oh;var a;$m=(a=ph(Zm.prototype.kb,Zm,[]),a)}
function _l(a){return zh(),Ho(a.n)==a.f.props['a']?true:false}
function zn(a){wh((vh(),$wnd.goog.global.window),xp,a.d,false)}
function An(a){xh((vh(),$wnd.goog.global.window),xp,a.d,false)}
function Ci(a){si(this);Vj(this.a,bi(a,ad(ke,fp,1,ii(a.a),5,1)))}
function Mi(a,b){var c;return Ki(b,Li(a,b==null?0:(c=s(b),c|0)))}
function dc(a){gb(a.c);return new Ej(null,new qj(new pi(a.g),0))}
function Bn(a,b){b.preventDefault();A((K(),K(),J),new Qn(a),up)}
function Mj(a,b){kj.call(this,b.bb(),b.ab()&-6);this.a=a;this.b=b}
function Qi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function Ao(a){this.b=a;K();this.a=new pc(0,null,null,false,false)}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function mh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function mk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function nc(a){lc(a.g);!!a.e&&mc(a);Z(a.a);Z(a.c);lc(a.b);lc(a.f)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function mj(a,b){if(a.c<a.d){nj(a,b,a.c++);return true}return false}
function yk(a){a.placeholder='What needs to be done?';return a}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function rj(a,b){!a.a?(a.a=new Zh(a.d)):Xh(a.a,a.b);Xh(a.a,b);return a}
function zj(a){var b;vj(a);b=0;while(a.a.cb(new Qj)){b=_g(b,1)}return b}
function Cj(a,b){var c;vj(a);c=new Pj;c.a=b;a.a.V(new Sj(c));return c.a}
function cb(a,b){var c,d;ti(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Jj(a,b){kj.call(this,b.bb(),b.ab()&-16449);this.a=a;this.c=b}
function cj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function sj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Qm(a){$wnd.React.Component.call(this,a);this.a=new tl(this,Im.a)}
function Um(a){$wnd.React.Component.call(this,a);this.a=new Il(this,fn.a)}
function yo(a){yj(Aj(dc(a.b),new Zo),new uj(new tj)).O(new $o(a.b))}
function Dj(a,b){var c;c=yj(a,new uj(new tj));return Ai(c,b.db(c.a.length))}
function go(a,b){var c;return u((K(),K(),J),new po(a,b),up,(c=null,c))}
function Fo(a,b){return (Vo(),To)==a||(So==a?(gb(b.a),!b.d):(gb(b.a),b.d))}
function gi(a,b){return qd(b)?b==null?Oi(a.a,null):aj(a.b,b):Oi(a.a,b)}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function Jb(b){try{nb(b.b.a)}catch(a){a=Zg(a);if(!md(a,4))throw $g(a)}}
function yn(a,b){a.f=b;o(b,T(a.a))&&Jn(a,b);Cn(b);A((K(),K(),J),new Qn(a),up)}
function Io(a){var b;return b=T(a.b),yj(Aj(dc(a.i),new ap(b)),new uj(new tj))}
function xl(a){var b;b=Wh((gb(a.b),a.g));if(b.length>0){uo(a.f,b);Hl(a,'')}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function wi(a,b,c){for(;c<a.a.length;++c){if(Ii(b,a.a[c])){return c}}return -1}
function dj(a){if(a.a.c!=a.c){return $i(a.a,a.b.value[0])}return a.b.value[1]}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function Vn(a,b){var c;if(md(b,46)){c=b;return a.c.d==c.c.d}else{return false}}
function yi(a,b){var c;c=wi(a,b,0);if(c==-1){return false}Wj(a.a,c);return true}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function ui(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Pb(){var a;this.a=ad(yd,fp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function ni(a){this.d=a;this.c=new cj(this.d.b);this.a=this.c;this.b=li(this)}
function Ym(a){$wnd.React.Component.call(this,a);this.a=new hm(this,rn.a,rn.b)}
function kc(a){if(a.i>=0){a.i=-2;u((K(),K(),J),new H(new qc(a)),67108864,null)}}
function ab(a){if(-2!=a.e){u((K(),K(),J),new H(new kb(a)),0,null);!!a.b&&lb(a.b)}}
function S(a){if(!a.a){a.a=true;a.k=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function W(a){if(a.b){if(md(a.b,8)){throw $g(a.b)}else{throw $g(a.b)}}return a.k}
function sb(b){if(b){try{b.s()}catch(a){a=Zg(a);if(md(a,4)){K()}else throw $g(a)}}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function Qc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Uc(b,c)}while(a.a);a.a=c}}
function Rc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function fi(a,b,c){return qd(b)?b==null?Ni(a.a,null,c):_i(a.b,b,c):Ni(a.a,b,c)}
function Xj(a,b){return _c(b)!=10&&dd(r(b),b.mb,b.__elementTypeId$,_c(b),a),a}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function pd(a){return a!=null&&(typeof a===cp||typeof a==='function')&&!(a.nb===sh)}
function ec(a){return gb(a.c),yj(new Ej(null,new qj(new pi(a.g),0)),new uj(new tj))}
function yl(a,b){if(13==b.keyCode){b.preventDefault();A((K(),K(),J),new Ll(a),up)}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Bi);ti(a.b,b)}}}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Bi);a.c=c.c}b.d=true;ti(a.c,b)}
function Mh(a,b){var c;if(!a){return}b.j=a;var d=Jh(b);if(!d){kh[a]=[b];return}d.lb=b}
function ph(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Eh(a){var b;b=new Dh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function kk(a){var b;b=jk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function an(a){$wnd.React.Component.call(this,a);this.a=new ym(this,wn.a,wn.b,wn.c)}
function Mm(a){$wnd.React.Component.call(this,a);this.a=new jl(this,Fm.a,Fm.b,Fm.c)}
function th(){new xn;$wnd.ReactDOM.render((new un).a,(vh(),uh).getElementById('app'),null)}
function Oh(){wc.call(this,"Stream already terminated, can't be modified or used")}
function gh(){hh();var a=fh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function pb(a){var b,c;for(c=new Di(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Gi(a){var b,c,d;d=0;for(c=new ni(a.a);c.b;){b=mi(c);d=d+(b?s(b):0);d=d|0}return d}
function ai(a,b){var c,d;for(d=new ni(b.a);d.b;){c=mi(d);if(!ji(a,c)){return false}}return true}
function aj(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Ri(a.a,b);--a.b}return c}
function eo(a,b,c){var d;d=new ao(b,c);Un(d,a,new ic(a,d));fi(a.g,Qh(d.c.d),d);fb(a.c);return d}
function on(a,b){ik(a.a,(b?Qh(b.c.d):null)+(''+(Bh(cg),cg.k)));hk(a.a,b);return a.a}
function cc(a,b,c){var d;d=gi(a.g,b?Qh(b.c.d):null);if(null!=d){oc(b.c,a);c&&!!b&&kc(b.c);fb(a.c)}}
function Jo(a){var b;b=T(a.g.a);o(zp,b)||o(Ap,b)||o('',b)?Fn(a.g,b):Eo(Gn(a.g))?In(a.g):Fn(a.g,'')}
function Vo(){Vo=oh;So=new Wo('ACTIVE',0);Uo=new Wo('COMPLETED',1);To=new Wo('ALL',2)}
function jh(a,b){typeof window===cp&&typeof window['$gwt']===cp&&(window['$gwt'][a]=b)}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?kp:0)|(0!=(b&229376)?0:98304)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:hp)|(0==(c&6291456)?!a?jp:kp:0)|0|0|0)}
function Rl(a,b,c){27==c.which?A((K(),K(),J),new om(a,b),up):13==c.which&&A((K(),K(),J),new mm(a,b),up)}
function jj(a,b){if(0>a||a>b){throw $g(new yh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function li(a){if(a.a.W()){return true}if(a.a!=a.c){return false}a.a=new Qi(a.d.a);return a.a.W()}
function Zg(a){var b;if(md(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function ah(a){var b;b=a.h;if(b==0){return a.l+a.m*kp}if(b==1048575){return a.l+a.m*kp-op}return a}
function dh(a){var b,c,d,e;e=a;d=0;if(e<0){e+=op;d=1048575}c=sd(e/kp);b=sd(e-c*kp);return ed(b,c,d)}
function Ki(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Ii(a,c.Z())){return c}}return null}
function Qh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Sh(),Rh)[b];!c&&(c=Rh[b]=new Ph(a));return c}return new Ph(a)}
function Ko(a,b){var c;c=a.e;if(!(b==c||!!b&&Vn(b,c))){!!c&&oc(c.c,a);a.e=b;!!b&&Un(b,a,new No(a));fb(a.d)}}
function _i(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function dd(a,b,c,d,e){e.lb=a;e.mb=b;e.nb=sh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function fd(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return ed(c&4194303,d&4194303,e&1048575)}
function db(a,b){var c,d;d=a.c;yi(d,b);!!a.b&&hp!=(a.b.c&ip)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function r(a){return qd(a)?ne:od(a)?ce:nd(a)?ae:ld(a)?a.lb:cd(a)?a.lb:a.lb||Array.isArray(a)&&$c(Ud,1)||Ud}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function al(){if(!_k){_k=(++(K(),K(),J).e,new Gb);$wnd.Promise.resolve(null).then(ph(bl.prototype.H,bl,[]))}}
function Ac(a){yc();rc(this);this.e=a;sc(this,a);this.g=a==null?np:rh(a);this.a='';this.b=a;this.a=''}
function Dh(){this.g=Ah++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function dk(a){bk();var b,c,d;c=':'+a;d=ak[c];if(d!=null){return sd(d)}d=$j[c];b=d==null?ck(a):sd(d);ek();ak[c]=b;return b}
function Hi(a){var b,c,d;d=1;for(c=new Di(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Wb(a){var b;if(a.c){while(a.c.a.length!=0){b=xi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Tl(a){var b;b=T(a.c);if(!a.j&&b){a.j=true;fm(a,a.f.props['a']);a.i.focus();a.i.select()}else a.j&&!b&&(a.j=false)}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&hp)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(hp==(b&ip)?0:524288)|(0==(b&6291456)?hp==(b&ip)?kp:jp:0)|0|268435456|0)}
function rh(a){var b;if(Array.isArray(a)&&a.nb===sh){return Ch(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function Sl(a,b){var c;c=(gb(a.a),a.d);if(null!=c&&c.length!=0){A((K(),K(),J),new Co(b,c),up);Ko(a.n,null);gm(a,c)}else{ho(a.k,b)}}
function _g(a,b){var c;if(od(a)&&od(b)){c=a+b;if(-17592186044416<c&&c<op){return c}}return ah(fd(od(a)?dh(a):a,od(b)?dh(b):b))}
function s(a){return qd(a)?dk(a):od(a)?sd(a):nd(a)?a?1231:1237:ld(a)?a.q():cd(a)?Zj(a):!!a&&!!a.hashCode?a.hashCode():Zj(a)}
function q(a,b){return qd(a)?o(a,b):od(a)?rd(a)===rd(b):nd(a)?rd(a)===rd(b):ld(a)?a.o(b):cd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function $k(){Yk();return dd($c(df,1),fp,6,0,[Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk])}
function Lh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ai(a,b){var c,d;d=a.a.length;b.length<d&&(b=Xj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function tl(a,b){var c;this.e=b;this.c=a;K();c=++rl;this.b=new pc(c,null,new ul(this),false,false);this.a=new wb(null,new vl(this),tp)}
function pc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Ji:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new jb((f=null,K(),f)),g):null;this.c=null}
function mc(a){var b,c,d;for(c=new Di(new Ci(new ki(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.Z();md(d,9)&&d.v()||b.$().s()}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Di(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Di(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Di(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function kd(a,b){if(qd(a)){return !!jd[b]}else if(a.mb){return !!a.mb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function pk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function T(a){a.j?hb(a.e):gb(a.e);if(ub(a.f)){if(a.j&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function Wh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function bi(a,b){var c,d,e,f;f=ii(a.a);b.length<f&&(b=Xj(new Array(f),b));e=b;d=new ni(a.a);for(c=0;c<f;++c){e[c]=mi(d)}b.length>f&&(b[f]=null);return b}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.s(),null)}finally{bc()}return f}catch(a){a=Zg(a);if(md(a,4)){e=a;throw $g(e)}else throw $g(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.t()}else{ac(b,e);try{g=c.t()}finally{bc()}}return g}catch(a){a=Zg(a);if(md(a,4)){f=a;throw $g(f)}else throw $g(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.i=c;this.k=null;this.j=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);hp==(d&ip)&&mb(this.f)}
function ym(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.c=a;K();e=++wm;this.b=new pc(e,null,new zm(this),false,false);this.a=new wb(null,new Am(this),tp)}
function Il(a,b){var c,d,e;this.f=b;this.d=a;K();c=++Cl;this.c=new pc(c,null,new Jl(this),false,false);this.b=(e=new jb((d=null,d)),e);this.a=new wb(null,new Ml(this),tp)}
function ao(a,b){var c,d,e,f,g;this.e=a;this.d=b;K();c=++Sn;this.c=new pc(c,null,new bo(this),true,true);this.b=(g=new jb((e=null,e)),g);this.a=(f=new jb((d=null,d)),f)}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function ih(b,c,d,e){hh();var f=fh;$moduleName=c;$moduleBase=d;Yg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{bp(g)()}catch(a){b(c,a)}}else{bp(g)()}}
function jk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Wi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Xi()}}
function pl(a){var b,c;a.d=0;al();c=(b=T(a.e.e).a,lk('span',pk(new $wnd.Object,dd($c(ne,1),fp,2,6,['todo-count'])),[lk('strong',null,[b]),' item'+(b==1?'':'s')+' left']));return c}
function lh(){kh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].ob()&&(c=Tc(c,g)):g[0].ob()}catch(a){a=Zg(a);if(md(a,4)){d=a;Fc();Lc(md(d,34)?d.G():d)}else throw $g(a)}}return c}
function Al(a){var b;a.e=0;al();b=lk(vp,tk(wk(xk(Ak(yk(pk(new $wnd.Object,dd($c(ne,1),fp,2,6,['new-todo']))),(gb(a.b),a.g)),ph(bn.prototype.ib,bn,[a])),ph(cn.prototype.hb,cn,[a]))),null);return b}
function zc(a){var b;if(a.c==null){b=rd(a.b)===rd(xc)?null:a.b;a.d=b==null?np:pd(b)?b==null?null:b.name:qd(b)?'String':Ch(r(b));a.a=a.a+': '+(pd(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.k;try{d=b.c.t();if(!(rd(e)===rd(d)||e!=null&&q(e,d))){b.k=d;b.b=null;eb(b.e)}}catch(a){a=Zg(a);if(md(a,10)){c=a;if(!b.b){b.k=null;b.b=c;eb(b.e)}throw $g(c)}else throw $g(a)}}
function Ni(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ki(b,e);if(f){return f._(c)}}e[e.length]=new ri(b,c);++a.b;return null}
function Tj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function xn(){this.a=new lo;new Hm(this.a);this.b=new Kn;this.c=new Ao(this.a);this.d=new Lo(this.a,this.b);new Em(this.a,this.c,this.d);new vn(this.a,this.c,this.d);new en(this.c);new qn(this.a,this.d)}
function jl(a,b,c,d){var e;this.f=b;this.g=c;this.i=d;this.d=a;K();e=++fl;this.c=new pc(e,null,new kl(this),false,false);this.a=new X(new ll(this),null,null,136478720);this.b=new wb(null,new nl(this),tp)}
function hm(a,b,c){var d,e,f;this.k=b;this.n=c;this.f=a;K();d=++Xl;this.e=new pc(d,null,new im(this),false,false);this.a=(f=new jb((e=null,e)),f);this.c=new X(new km(this),null,null,136478720);this.b=new wb(null,new pm(this),tp);fm(this,this.f.props['a'])}
function ck(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Uh(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{b.e.s()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Zg(a);if(md(a,4)){K()}else throw $g(a)}}}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=ad(ke,fp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function vb(a,b,c,d){this.b=new Bi;this.f=new Kb(new zb(this),d&6520832|262144|hp);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&jp)&&D((null,J)))}
function Oi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Ii(b,e.Z())){if(d.length==1){d.length=0;Ri(a.a,g)}else{d.splice(h,1)}--a.b;return e.$()}}return null}
function nh(a,b,c){var d=kh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=kh[b]),qh(h));_.mb=c;!b&&(_.nb=sh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.lb=f)}
function Kh(a){if(a.M()){var b=a.c;b.N()?(a.k='['+b.j):!b.M()?(a.k='[L'+b.K()+';'):(a.k='['+b.K());a.b=b.J()+'[]';a.i=b.L()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Lh('.',[c,Lh('$',d)]);a.b=Lh('.',[c,Lh('.',d)]);a.i=d[d.length-1]}
function ci(a,b){var c,d,e;c=b.Z();e=b.$();d=qd(c)?c==null?ei(Mi(a.a,null)):$i(a.b,c):ei(Mi(a.a,c));if(!(rd(e)===rd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(qd(c)?c==null?!!Mi(a.a,null):Zi(a.b,c):!!Mi(a.a,c))){return false}return true}
function Cn(a){var b;if(0==a.length){b=(vh(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',uh.title,b)}else{(vh(),$wnd.goog.global.window).location.hash=a}}
function Lo(a,b){var c,d;this.i=a;this.g=b;K();this.f=new pc(0,null,new Mo(this),false,false);this.d=(d=new jb((c=null,c)),d);this.b=new X(new Oo(this),null,null,yp);this.c=new X(new Po(this),null,null,yp);this.a=new wb(new Qo(this),null,681574400);D((null,J))}
function lo(){var a;this.g=new Ji;K();this.f=new pc(0,new no(this),new mo(this),false,false);this.c=(a=new jb(null),a);this.d=new X(new qo(this),null,null,yp);this.e=new X(new ro(this),null,null,yp);this.a=new X(new so(this),null,null,yp);this.b=new X(new to(this),null,null,yp)}
function Kn(){var a,b,c;this.d=new Ro(this);this.f=this.e=(c=(vh(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));K();this.c=new pc(0,null,new Ln(this),false,false);this.b=(b=new jb((a=null,a)),b);this.a=new X(new Rn,new Mn(this),new Nn(this),35651584)}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Di(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Zg(a);if(!md(a,4))throw $g(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.C();return a&&a.A()}},suppressed:{get:function(){return c.B()}}})}catch(a){}}}
function lk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;gk(b,ph(ok.prototype.fb,ok,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=jk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function Vi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.i,e));d.k=null}ui(a.b,new Bb(a));a.b.a=ad(ke,fp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function um(a){var b;a.d=0;al();b=lk('div',null,[lk('div',null,[lk(wp,pk(new $wnd.Object,dd($c(ne,1),fp,2,6,[wp])),[lk('h1',null,['todos']),(new dn).a]),T(a.e.d)?lk('section',pk(new $wnd.Object,dd($c(ne,1),fp,2,6,[wp])),[lk(vp,wk(zk(pk(new $wnd.Object,dd($c(ne,1),fp,2,6,['toggle-all'])),(Yk(),Dk)),ph(sn.prototype.hb,sn,[a])),null),lk('ul',pk(new $wnd.Object,dd($c(ne,1),fp,2,6,['todo-list'])),Dj(Bj(T(a.g.c).U(),new tn),new nk))]):null,T(a.e.d)?(new Dm).a:null])]);return b}
function Yk(){Yk=oh;Ck=new Zk(rp,0);Dk=new Zk('checkbox',1);Ek=new Zk('color',2);Fk=new Zk('date',3);Gk=new Zk('datetime',4);Hk=new Zk('email',5);Ik=new Zk('file',6);Jk=new Zk('hidden',7);Kk=new Zk('image',8);Lk=new Zk('month',9);Mk=new Zk(dp,10);Nk=new Zk('password',11);Ok=new Zk('radio',12);Pk=new Zk('range',13);Qk=new Zk('reset',14);Rk=new Zk('search',15);Sk=new Zk('submit',16);Tk=new Zk('tel',17);Uk=new Zk('text',18);Vk=new Zk('time',19);Wk=new Zk('url',20);Xk=new Zk('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=vi(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&zi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=vi(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){xi(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Bi)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&hp!=(k.b.c&ip)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function dl(a){var b,c;a.e=0;al();c=(b=T(a.i.b),lk('footer',pk(new $wnd.Object,dd($c(ne,1),fp,2,6,['footer'])),[(new Gm).a,lk('ul',pk(new $wnd.Object,dd($c(ne,1),fp,2,6,['filters'])),[lk('li',null,[lk('a',rk(pk(new $wnd.Object,dd($c(ne,1),fp,2,6,[(Vo(),To)==b?sp:null])),'#'),['All'])]),lk('li',null,[lk('a',rk(pk(new $wnd.Object,dd($c(ne,1),fp,2,6,[So==b?sp:null])),'#active'),['Active'])]),lk('li',null,[lk('a',rk(pk(new $wnd.Object,dd($c(ne,1),fp,2,6,[Uo==b?sp:null])),'#completed'),['Completed'])])]),T(a.a)?lk(rp,sk(pk(new $wnd.Object,dd($c(ne,1),fp,2,6,['clear-completed'])),ph(Cm.prototype.jb,Cm,[a])),['Clear Completed']):null]));return c}
function Vl(a){var b,c,d,e;a.g=0;al();b=a.f.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.f.props['a'],e=(gb(d.a),d.d),lk('li',pk(new $wnd.Object,dd($c(ne,1),fp,2,6,[e?'checked':null,T(a.c)?'editing':null])),[lk('div',pk(new $wnd.Object,dd($c(ne,1),fp,2,6,['view'])),[lk(vp,wk(uk(zk(pk(new $wnd.Object,dd($c(ne,1),fp,2,6,['toggle'])),(Yk(),Dk)),e),ph(hn.prototype.hb,hn,[d])),null),lk('label',Bk(new $wnd.Object,ph(jn.prototype.jb,jn,[a,d])),[(gb(d.b),d.e)]),lk(rp,sk(pk(new $wnd.Object,dd($c(ne,1),fp,2,6,['destroy'])),ph(kn.prototype.jb,kn,[a,d])),null)]),lk(vp,xk(wk(vk(Ak(pk(qk(new $wnd.Object,ph(ln.prototype.w,ln,[a])),dd($c(ne,1),fp,2,6,['edit'])),(gb(a.a),a.d)),ph(mn.prototype.gb,mn,[a,d])),ph(gn.prototype.hb,gn,[a])),ph(nn.prototype.ib,nn,[a,d])),null)]));return c}
function Xi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[qp]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Vi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[qp]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var cp='object',dp='number',ep={5:1},fp={3:1},gp={9:1},hp=1048576,ip=1835008,jp=2097152,kp=4194304,lp='__noinit__',mp={3:1,10:1,8:1,4:1},np='null',op=17592186044416,pp={40:1},qp='delete',rp='button',sp='selected',tp=1411518464,up=142606336,vp='input',wp='header',xp='hashchange',yp=136314880,zp='active',Ap='completed';var _,kh,fh,Yg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;lh();nh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.lb};_.q=Cp;_.r=function(){var a;return Ch(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var gd,hd,jd;nh(51,1,{},Dh);_.I=function(a){var b;b=new Dh;b.e=4;a>1?(b.c=Ih(this,a-1)):(b.c=this);return b};_.J=function(){Bh(this);return this.b};_.K=function(){return Ch(this)};_.L=function(){Bh(this);return this.i};_.M=function(){return (this.e&4)!=0};_.N=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(Bh(this),this.k)};_.e=0;_.g=0;var Ah=1;var ke=Fh(1);var be=Fh(51);nh(77,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var xd=Fh(77);nh(78,1,ep,G);_.s=function(){Db(this.a)};var ud=Fh(78);nh(35,1,{},H);_.t=function(){return this.a.s(),null};var vd=Fh(35);nh(79,1,{},I);var wd=Fh(79);var J;nh(43,1,{43:1},Q);_.b=0;_.c=false;_.d=0;var yd=Fh(43);nh(224,1,gp);_.r=function(){var a;return Ch(this.lb)+'@'+(a=s(this)>>>0,a.toString(16))};var Bd=Fh(224);nh(18,224,gp,X);_.u=function(){S(this)};_.v=Bp;_.a=false;_.d=0;_.j=false;var Ad=Fh(18);nh(129,1,{},Y);_.t=function(){return U(this.a)};var zd=Fh(129);nh(16,224,{9:1,16:1},jb);_.u=function(){ab(this)};_.v=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Dd=Fh(16);nh(128,1,ep,kb);_.s=function(){bb(this.a)};var Cd=Fh(128);nh(17,224,{9:1,17:1},wb,xb);_.u=function(){lb(this)};_.v=function(){return 1==(this.c&7)};_.c=0;var Id=Fh(17);nh(130,1,{},yb);_.s=function(){R(this.a)};var Ed=Fh(130);nh(131,1,ep,zb);_.s=function(){nb(this.a)};var Fd=Fh(131);nh(132,1,ep,Ab);_.s=function(){qb(this.a)};var Gd=Fh(132);nh(133,1,{},Bb);_.w=function(a){ob(this.a,a)};var Hd=Fh(133);nh(143,1,{},Eb);_.a=0;_.b=0;_.c=0;var Jd=Fh(143);nh(163,1,gp,Gb);_.u=function(){Fb(this)};_.v=Bp;_.a=false;var Kd=Fh(163);nh(59,224,{9:1,59:1},Kb);_.u=function(){Hb(this)};_.v=function(){return 2==(3&this.a)};_.a=0;var Md=Fh(59);nh(142,1,{},Pb);var Ld=Fh(142);nh(145,1,{},_b);_.r=function(){var a;return Bh(Nd),Nd.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.a=0;var Qb;var Nd=Fh(145);nh(96,1,{});var Qd=Fh(96);nh(85,1,{},hc);_.w=function(a){fc(this.a,a)};var Od=Fh(85);nh(86,1,ep,ic);_.s=function(){gc(this.a,this.b)};var Pd=Fh(86);nh(15,1,gp,pc);_.u=function(){kc(this)};_.v=function(){return this.i<0};_.r=function(){var a;return Bh(Sd),Sd.k+'@'+(a=Zj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Sd=Fh(15);nh(127,1,ep,qc);_.s=function(){nc(this.a)};var Rd=Fh(127);nh(4,1,{3:1,4:1});_.A=Hp;_.B=function(){return Dj(Bj(Fi((this.i==null&&(this.i=ad(pe,fp,4,0,0,1)),this.i)),new $h),new Hj)};_.C=function(){return this.f};_.D=function(){return this.g};_.F=function(){tc(this,vc(new Error(uc(this,this.g))));Xc(this)};_.r=function(){return uc(this,this.D())};_.e=lp;_.j=true;var pe=Fh(4);nh(10,4,{3:1,10:1,4:1});var ee=Fh(10);nh(8,10,mp);var le=Fh(8);nh(72,8,mp);var ie=Fh(72);nh(73,72,mp);var Wd=Fh(73);nh(34,73,{34:1,3:1,10:1,8:1,4:1},Ac);_.D=function(){zc(this);return this.c};_.G=function(){return rd(this.b)===rd(xc)?null:this.b};var xc;var Td=Fh(34);var Ud=Fh(0);nh(210,1,{});var Vd=Fh(210);var Cc=0,Dc=0,Ec=-1;nh(82,210,{},Sc);var Oc;var Xd=Fh(82);var Vc;nh(221,1,{});var Zd=Fh(221);nh(74,221,{},Zc);var Yd=Fh(74);var uh;nh(70,1,{67:1});_.r=Bp;var $d=Fh(70);nh(76,8,mp);var ge=Fh(76);nh(156,76,mp,yh);var _d=Fh(156);gd={3:1,68:1,27:1};var ae=Fh(68);nh(41,1,{3:1,41:1});var je=Fh(41);hd={3:1,27:1,41:1};var ce=Fh(220);nh(29,1,{3:1,27:1,29:1});_.o=function(a){return this===a};_.q=Cp;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var de=Fh(29);nh(75,8,mp,Oh);var fe=Fh(75);nh(28,41,{3:1,27:1,28:1,41:1},Ph);_.o=function(a){return md(a,28)&&a.a==this.a};_.q=Bp;_.r=function(){return ''+this.a};_.a=0;var he=Fh(28);var Rh;nh(283,1,{});jd={3:1,67:1,27:1,2:1};var ne=Fh(2);nh(71,70,{67:1},Zh);var me=Fh(71);nh(287,1,{});nh(65,1,{},$h);_.Q=function(a){return a.e};var oe=Fh(65);nh(53,8,mp,_h);var qe=Fh(53);nh(222,1,{39:1});_.O=Gp;_.T=function(){return new qj(this,0)};_.U=function(){return new Ej(null,this.T())};_.R=function(a){throw $g(new _h('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new sj('[',']');for(b=this.P();b.W();){a=b.X();rj(c,a===this?'(this Collection)':a==null?np:rh(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var re=Fh(222);nh(226,1,{208:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!md(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new ni((new ki(d)).a);c.b;){b=mi(c);if(!ci(this,b)){return false}}return true};_.q=function(){return Gi(new ki(this))};_.r=function(){var a,b,c;c=new sj('{','}');for(b=new ni((new ki(this)).a);b.b;){a=mi(b);rj(c,di(this,a.Z())+'='+di(this,a.$()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ce=Fh(226);nh(141,226,{208:1});var ue=Fh(141);nh(225,222,{39:1,231:1});_.T=function(){return new qj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!md(a,21)){return false}b=a;if(ii(b.a)!=this.S()){return false}return ai(this,b)};_.q=function(){return Gi(this)};var De=Fh(225);nh(21,225,{21:1,39:1,231:1},ki);_.P=function(){return new ni(this.a)};_.S=Ep;var te=Fh(21);nh(22,1,{},ni);_.V=Dp;_.X=function(){return mi(this)};_.W=Fp;_.b=false;var se=Fh(22);nh(223,222,{39:1,228:1});_.T=function(){return new qj(this,16)};_.Y=function(a,b){throw $g(new _h('Add not supported on this list'))};_.R=function(a){this.Y(this.S(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,13)){return false}f=a;if(this.S()!=f.a.length){return false}e=new Di(f);for(c=new Di(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(rd(b)===rd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Hi(this)};_.P=function(){return new oi(this)};var we=Fh(223);nh(81,1,{},oi);_.V=Dp;_.W=function(){return this.a<this.b.a.length};_.X=function(){return vi(this.b,this.a++)};_.a=0;var ve=Fh(81);nh(42,222,{39:1},pi);_.P=function(){var a;a=new ni((new ki(this.a)).a);return new qi(a)};_.S=Ep;var ye=Fh(42);nh(136,1,{},qi);_.V=Dp;_.W=function(){return this.a.b};_.X=function(){var a;a=mi(this.a);return a.$()};var xe=Fh(136);nh(134,1,pp);_.o=function(a){var b;if(!md(a,40)){return false}b=a;return Ii(this.a,b.Z())&&Ii(this.b,b.$())};_.Z=Bp;_.$=Fp;_.q=function(){return hj(this.a)^hj(this.b)};_._=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var ze=Fh(134);nh(135,134,pp,ri);var Ae=Fh(135);nh(227,1,pp);_.o=function(a){var b;if(!md(a,40)){return false}b=a;return Ii(this.b.value[0],b.Z())&&Ii(dj(this),b.$())};_.q=function(){return hj(this.b.value[0])^hj(dj(this))};_.r=function(){return this.b.value[0]+'='+dj(this)};var Be=Fh(227);nh(13,223,{3:1,13:1,39:1,228:1},Bi,Ci);_.Y=function(a,b){Uj(this.a,a,b)};_.R=function(a){return ti(this,a)};_.O=function(a){ui(this,a)};_.P=function(){return new Di(this)};_.S=function(){return this.a.length};var Fe=Fh(13);nh(14,1,{},Di);_.V=Dp;_.W=function(){return this.a<this.c.a.length};_.X=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ee=Fh(14);nh(36,141,{3:1,36:1,208:1},Ji);var Ge=Fh(36);nh(57,1,{},Pi);_.O=Gp;_.P=function(){return new Qi(this)};_.b=0;var Ie=Fh(57);nh(58,1,{},Qi);_.V=Dp;_.X=function(){return this.d=this.a[this.c++],this.d};_.W=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var He=Fh(58);var Ti;nh(55,1,{},bj);_.O=Gp;_.P=function(){return new cj(this)};_.b=0;_.c=0;var Le=Fh(55);nh(56,1,{},cj);_.V=Dp;_.X=function(){return this.c=this.a,this.a=this.b.next(),new ej(this.d,this.c,this.d.c)};_.W=function(){return !this.a.done};var Je=Fh(56);nh(144,227,pp,ej);_.Z=function(){return this.b.value[0]};_.$=function(){return dj(this)};_._=function(a){return _i(this.a,this.b.value[0],a)};_.c=0;var Ke=Fh(144);nh(147,1,{});_.V=Ip;_.ab=function(){return this.d};_.bb=Hp;_.d=0;_.e=0;var Pe=Fh(147);nh(60,147,{});var Me=Fh(60);nh(137,1,{});_.V=Ip;_.ab=Fp;_.bb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Oe=Fh(137);nh(138,137,{},oj);_.V=function(a){lj(this,a)};_.cb=function(a){return mj(this,a)};var Ne=Fh(138);nh(19,1,{},qj);_.ab=Bp;_.bb=function(){pj(this);return this.c};_.V=function(a){pj(this);this.d.V(a)};_.cb=function(a){pj(this);if(this.d.W()){a.w(this.d.X());return true}return false};_.a=0;_.c=0;var Qe=Fh(19);nh(52,1,{},sj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Re=Fh(52);nh(33,1,{},tj);_.Q=function(a){return a};var Se=Fh(33);nh(37,1,{},uj);var Te=Fh(37);nh(146,1,{});_.c=false;var bf=Fh(146);nh(23,146,{},Ej);var af=Fh(23);nh(66,1,{},Hj);_.db=function(a){return ad(ke,fp,1,a,5,1)};var Ue=Fh(66);nh(149,60,{},Jj);_.cb=function(a){this.b=false;while(!this.b&&this.c.cb(new Kj(this,a)));return this.b};_.b=false;var We=Fh(149);nh(152,1,{},Kj);_.w=function(a){Ij(this.a,this.b,a)};var Ve=Fh(152);nh(148,60,{},Mj);_.cb=function(a){return this.b.cb(new Nj(this,a))};var Ye=Fh(148);nh(151,1,{},Nj);_.w=function(a){Lj(this.a,this.b,a)};var Xe=Fh(151);nh(150,1,{},Pj);_.w=function(a){Oj(this,a)};var Ze=Fh(150);nh(153,1,{},Qj);_.w=function(a){};var $e=Fh(153);nh(154,1,{},Sj);_.w=function(a){Rj(this,a)};var _e=Fh(154);nh(285,1,{});nh(282,1,{});var Yj=0;var $j,_j=0,ak;nh(899,1,{});nh(924,1,{});nh(164,1,{},nk);_.db=function(a){return new Array(a)};var cf=Fh(164);nh(251,$wnd.Function,{},ok);_.fb=function(a){mk(this.a,this.b,a)};nh(6,29,{3:1,27:1,29:1,6:1},Zk);var Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk,Wk,Xk;var df=Gh(6,$k);var _k;nh(249,$wnd.Function,{},bl);_.H=function(a){return Fb(_k),_k=null,null};nh(180,1,{});var Of=Fh(180);nh(181,180,{});_.e=0;var Sf=Fh(181);nh(182,181,gp,jl);_.u=Jp;_.v=Kp;_.r=function(){var a;return Bh(nf),nf.k+'@'+(a=Zj(this)>>>0,a.toString(16))};var fl=0;var nf=Fh(182);nh(183,1,ep,kl);_.s=function(){gl(this.a)};var ef=Fh(183);nh(184,1,{},ll);_.t=function(){return il(this.a)};var ff=Fh(184);nh(186,1,{},ml);_.t=function(){return dl(this.a)};var gf=Fh(186);nh(185,1,{},nl);_.s=function(){el(this.a)};var hf=Fh(185);nh(201,1,{});var Nf=Fh(201);nh(202,201,{});_.d=0;var Rf=Fh(202);nh(203,202,gp,tl);_.u=Lp;_.v=Mp;_.r=function(){var a;return Bh(mf),mf.k+'@'+(a=Zj(this)>>>0,a.toString(16))};var rl=0;var mf=Fh(203);nh(204,1,ep,ul);_.s=Np;var jf=Fh(204);nh(205,1,{},vl);_.s=function(){ql(this.a)};var kf=Fh(205);nh(206,1,{},wl);_.t=function(){return pl(this.a)};var lf=Fh(206);nh(172,1,{});_.g='';var _f=Fh(172);nh(173,172,{});_.e=0;var Uf=Fh(173);nh(174,173,gp,Il);_.u=Jp;_.v=Kp;_.r=function(){var a;return Bh(tf),tf.k+'@'+(a=Zj(this)>>>0,a.toString(16))};var Cl=0;var tf=Fh(174);nh(175,1,ep,Jl);_.s=function(){Dl(this.a)};var of=Fh(175);nh(177,1,{},Kl);_.t=function(){return Al(this.a)};var pf=Fh(177);nh(178,1,ep,Ll);_.s=function(){xl(this.a)};var qf=Fh(178);nh(176,1,{},Ml);_.s=function(){el(this.a)};var rf=Fh(176);nh(179,1,ep,Nl);_.s=function(){Gl(this.a,this.b)};var sf=Fh(179);nh(168,1,{});_.j=false;var cg=Fh(168);nh(188,168,{});_.g=0;var Wf=Fh(188);nh(189,188,gp,hm);_.u=function(){kc(this.e)};_.v=function(){return this.e.i<0};_.r=function(){var a;return Bh(Ef),Ef.k+'@'+(a=Zj(this)>>>0,a.toString(16))};var Xl=0;var Ef=Fh(189);nh(190,1,ep,im);_.s=function(){Yl(this.a)};var uf=Fh(190);nh(193,1,{},jm);_.t=function(){return Vl(this.a)};var vf=Fh(193);nh(191,1,{},km);_.t=function(){return _l(this.a)};var wf=Fh(191);nh(44,1,ep,lm);_.s=function(){gm(this.a,Gn(this.b))};var xf=Fh(44);nh(61,1,ep,mm);_.s=function(){Sl(this.a,this.b)};var yf=Fh(61);nh(194,1,ep,nm);_.s=function(){am(this.a,this.b)};var zf=Fh(194);nh(195,1,ep,om);_.s=function(){bm(this.a,this.b)};var Af=Fh(195);nh(192,1,{},pm);_.s=function(){Wl(this.a)};var Bf=Fh(192);nh(196,1,ep,qm);_.s=function(){Ol(this.a,this.b)};var Cf=Fh(196);nh(197,1,ep,rm);_.s=function(){Tl(this.a)};var Df=Fh(197);nh(157,1,{});var gg=Fh(157);nh(158,157,{});_.d=0;var Yf=Fh(158);nh(159,158,gp,ym);_.u=Lp;_.v=Mp;_.r=function(){var a;return Bh(If),If.k+'@'+(a=Zj(this)>>>0,a.toString(16))};var wm=0;var If=Fh(159);nh(160,1,ep,zm);_.s=Np;var Ff=Fh(160);nh(161,1,{},Am);_.s=function(){ql(this.a)};var Gf=Fh(161);nh(162,1,{},Bm);_.t=function(){return um(this.a)};var Hf=Fh(162);nh(255,$wnd.Function,{},Cm);_.jb=function(a){wo(this.a.g)};nh(166,1,{},Dm);var Jf=Fh(166);nh(88,1,{},Em);var Kf=Fh(88);var Fm;nh(187,1,{},Gm);var Lf=Fh(187);nh(83,1,{},Hm);var Mf=Fh(83);var Im;nh(256,$wnd.Function,{},Jm);_.kb=function(a){return new Mm(a)};var Km;nh(170,$wnd.React.Component,{},Mm);mh(kh[1],_);_.componentWillUnmount=function(){cl(this.a)};_.render=function(){return hl(this.a)};_.shouldComponentUpdate=Op;var Pf=Fh(170);nh(266,$wnd.Function,{},Nm);_.kb=function(a){return new Qm(a)};var Om;nh(198,$wnd.React.Component,{},Qm);mh(kh[1],_);_.componentWillUnmount=function(){ol(this.a)};_.render=function(){return sl(this.a)};_.shouldComponentUpdate=Pp;var Qf=Fh(198);nh(254,$wnd.Function,{},Rm);_.kb=function(a){return new Um(a)};var Sm;nh(169,$wnd.React.Component,{},Um);mh(kh[1],_);_.componentWillUnmount=function(){cl(this.a)};_.render=function(){return El(this.a)};_.shouldComponentUpdate=Op;var Tf=Fh(169);nh(257,$wnd.Function,{},Vm);_.kb=function(a){return new Ym(a)};var Wm;nh(171,$wnd.React.Component,{},Ym);mh(kh[1],_);_.componentDidUpdate=function(a){em(this.a)};_.componentWillUnmount=function(){Ul(this.a)};_.render=function(){return Zl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.g};var Vf=Fh(171);nh(248,$wnd.Function,{},Zm);_.kb=function(a){return new an(a)};var $m;nh(139,$wnd.React.Component,{},an);mh(kh[1],_);_.componentWillUnmount=function(){ol(this.a)};_.render=function(){return xm(this.a)};_.shouldComponentUpdate=Pp;var Xf=Fh(139);nh(252,$wnd.Function,{},bn);_.ib=function(a){yl(this.a,a)};nh(253,$wnd.Function,{},cn);_.hb=function(a){Fl(this.a,a)};nh(165,1,{},dn);var Zf=Fh(165);nh(94,1,{},en);var $f=Fh(94);var fn;nh(264,$wnd.Function,{},gn);_.hb=function(a){$l(this.a,a)};nh(258,$wnd.Function,{},hn);_.hb=function(a){_n(this.a)};nh(260,$wnd.Function,{},jn);_.jb=function(a){cm(this.a,this.b)};nh(261,$wnd.Function,{},kn);_.jb=function(a){Pl(this.a,this.b)};nh(262,$wnd.Function,{},ln);_.w=function(a){Ql(this.a,a)};nh(263,$wnd.Function,{},mn);_.gb=function(a){dm(this.a,this.b)};nh(265,$wnd.Function,{},nn);_.ib=function(a){Rl(this.a,this.b,a)};nh(167,1,{},pn);var ag=Fh(167);nh(95,1,{},qn);var bg=Fh(95);var rn;nh(247,$wnd.Function,{},sn);_.hb=function(a){sm(this.a,a)};nh(140,1,{},tn);_.Q=function(a){return on(new pn,a)};var dg=Fh(140);nh(64,1,{},un);var eg=Fh(64);nh(93,1,{},vn);var fg=Fh(93);var wn;nh(63,1,{},xn);var hg=Fh(63);nh(107,1,{});var Ng=Fh(107);nh(108,107,gp,Kn);_.u=Jp;_.v=Kp;_.r=function(){var a;return Bh(pg),pg.k+'@'+(a=Zj(this)>>>0,a.toString(16))};var pg=Fh(108);nh(109,1,ep,Ln);_.s=function(){En(this.a)};var ig=Fh(109);nh(111,1,{},Mn);_.s=function(){zn(this.a)};var jg=Fh(111);nh(112,1,{},Nn);_.s=function(){An(this.a)};var kg=Fh(112);nh(113,1,ep,On);_.s=function(){yn(this.a,this.b)};var lg=Fh(113);nh(114,1,ep,Pn);_.s=function(){Hn(this.a)};var mg=Fh(114);nh(54,1,ep,Qn);_.s=function(){Dn(this.a)};var ng=Fh(54);nh(110,1,{},Rn);_.t=function(){var a;return a=(vh(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var og=Fh(110);nh(45,1,{45:1});_.d=false;var Vg=Fh(45);nh(46,45,{9:1,250:1,46:1,45:1},ao);_.u=Jp;_.o=function(a){return Vn(this,a)};_.q=function(){return this.c.d};_.v=Kp;_.r=function(){var a;return Bh(Fg),Fg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Sn=0;var Fg=Fh(46);nh(199,1,ep,bo);_.s=function(){Tn(this.a)};var qg=Fh(199);nh(200,1,ep,co);_.s=function(){Yn(this.a)};var rg=Fh(200);nh(97,96,{});var Qg=Fh(97);nh(98,97,gp,lo);_.u=Qp;_.v=Rp;_.r=function(){var a;return Bh(Ag),Ag.k+'@'+(a=Zj(this)>>>0,a.toString(16))};var Ag=Fh(98);nh(100,1,ep,mo);_.s=function(){fo(this.a)};var sg=Fh(100);nh(99,1,ep,no);_.s=function(){io(this.a)};var tg=Fh(99);nh(105,1,ep,oo);_.s=function(){cc(this.a,this.b,true)};var ug=Fh(105);nh(106,1,{},po);_.t=function(){return eo(this.a,this.c,this.b)};_.b=false;var vg=Fh(106);nh(101,1,{},qo);_.t=function(){return jo(this.a)};var wg=Fh(101);nh(102,1,{},ro);_.t=function(){return Qh(eh(zj(dc(this.a))))};var xg=Fh(102);nh(103,1,{},so);_.t=function(){return Qh(eh(zj(Aj(dc(this.a),new Yo))))};var yg=Fh(103);nh(104,1,{},to);_.t=function(){return ko(this.a)};var zg=Fh(104);nh(115,1,{});var Ug=Fh(115);nh(116,115,gp,Ao);_.u=function(){kc(this.a)};_.v=function(){return this.a.i<0};_.r=function(){var a;return Bh(Eg),Eg.k+'@'+(a=Zj(this)>>>0,a.toString(16))};var Eg=Fh(116);nh(117,1,ep,Bo);_.s=function(){xo(this.a,this.b)};_.b=false;var Bg=Fh(117);nh(118,1,ep,Co);_.s=function(){Jn(this.b,this.a)};var Cg=Fh(118);nh(119,1,ep,Do);_.s=function(){yo(this.a)};var Dg=Fh(119);nh(120,1,{});var Xg=Fh(120);nh(121,120,gp,Lo);_.u=Qp;_.v=Rp;_.r=function(){var a;return Bh(Lg),Lg.k+'@'+(a=Zj(this)>>>0,a.toString(16))};var Lg=Fh(121);nh(122,1,ep,Mo);_.s=function(){Go(this.a)};var Gg=Fh(122);nh(126,1,ep,No);_.s=function(){Ko(this.a,null)};var Hg=Fh(126);nh(123,1,{},Oo);_.t=function(){var a;return a=Gn(this.a.g),o(zp,a)?(Vo(),So):o(Ap,a)?(Vo(),Uo):(Vo(),To)};var Ig=Fh(123);nh(124,1,{},Po);_.t=function(){return Io(this.a)};var Jg=Fh(124);nh(125,1,{},Qo);_.s=function(){Jo(this.a)};var Kg=Fh(125);nh(87,1,{},Ro);_.handleEvent=function(a){Bn(this.a,a)};var Mg=Fh(87);nh(30,29,{3:1,27:1,29:1,30:1},Wo);var So,To,Uo;var Og=Gh(30,Xo);nh(84,1,{},Yo);_.eb=function(a){return !Xn(a)};var Pg=Fh(84);nh(90,1,{},Zo);_.eb=function(a){return Xn(a)};var Rg=Fh(90);nh(91,1,{},$o);_.w=function(a){ho(this.a,a)};var Sg=Fh(91);nh(89,1,{},_o);_.w=function(a){vo(this.a,a)};_.a=false;var Tg=Fh(89);nh(92,1,{},ap);_.eb=function(a){return Fo(this.a,a)};var Wg=Fh(92);var td=Hh('D');var bp=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=ih;gh(th);jh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();