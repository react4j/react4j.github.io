function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='CA4B8B1697EA535A930FF38DA5CC4110',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'CA4B8B1697EA535A930FF38DA5CC4110';function p(){}
function qh(){}
function mh(){}
function Yh(){}
function Yc(){}
function Rc(){}
function Fb(){}
function Fj(){}
function rj(){}
function Nj(){}
function Oj(){}
function lk(){}
function _k(){}
function Hm(){}
function Lm(){}
function Pm(){}
function Tm(){}
function Xm(){}
function Xo(){}
function Wo(){}
function rn(){}
function Pn(){}
function Wc(a){Vc()}
function xh(){xh=mh}
function zi(){qi(this)}
function zb(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function Ab(a){this.a=a}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function Xh(a){this.a=a}
function Nh(a){this.a=a}
function gc(a){this.a=a}
function pc(a){this.a=a}
function ii(a){this.a=a}
function ni(a){this.a=a}
function oi(a){this.a=a}
function mi(a){this.b=a}
function Bi(a){this.c=a}
function sj(a){this.a=a}
function Qj(a){this.a=a}
function il(a){this.a=a}
function jl(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function sl(a){this.a=a}
function tl(a){this.a=a}
function ul(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Jl(a){this.a=a}
function Kl(a){this.a=a}
function gm(a){this.a=a}
function hm(a){this.a=a}
function im(a){this.a=a}
function nm(a){this.a=a}
function pm(a){this.a=a}
function xm(a){this.a=a}
function ym(a){this.a=a}
function zm(a){this.a=a}
function Am(a){this.a=a}
function _m(a){this.a=a}
function an(a){this.a=a}
function en(a){this.a=a}
function fn(a){this.a=a}
function jn(a){this.a=a}
function qn(a){this.a=a}
function Jn(a){this.a=a}
function Kn(a){this.a=a}
function Ln(a){this.a=a}
function Nn(a){this.a=a}
function On(a){this.a=a}
function _n(a){this.a=a}
function ao(a){this.a=a}
function ko(a){this.a=a}
function lo(a){this.a=a}
function oo(a){this.a=a}
function po(a){this.a=a}
function qo(a){this.a=a}
function ro(a){this.a=a}
function Bo(a){this.a=a}
function Ko(a){this.a=a}
function Lo(a){this.a=a}
function Mo(a){this.a=a}
function No(a){this.a=a}
function Oo(a){this.a=a}
function Po(a){this.a=a}
function Yo(a){this.a=a}
function Zo(a){this.a=a}
function $o(a){this.a=a}
function Mj(a,b){a.a=b}
function qb(a,b){a.b=b}
function gk(a,b){a.key=b}
function ek(a,b){dk(a,b)}
function to(a,b){em(b,a)}
function Y(a){!!a&&$(a)}
function kc(a){!!a&&a.v()}
function w(a){--a.e;D(a)}
function Bp(a){dj(this,a)}
function Gp(a){gj(this,a)}
function Ep(a){Rh(this,a)}
function Hp(){jc(this.c)}
function Jp(){jc(this.b)}
function Op(){jc(this.f)}
function Ni(){this.a=Wi()}
function _i(){this.a=Wi()}
function Lp(){kb(this.a.a)}
function db(a){Xb((J(),a))}
function eb(a){Yb((J(),a))}
function hb(a){Zb((J(),a))}
function Yg(a){return a.e}
function zp(){return this.a}
function Dp(){return this.b}
function Fp(){return this.e}
function J(){J=mh;I=new F}
function xc(){xc=mh;wc=new p}
function Si(){Si=mh;Ri=Ui()}
function Sl(a){a.g=2;jc(a.e)}
function al(a){a.e=2;jc(a.c)}
function ml(a){a.d=2;jc(a.b)}
function Cn(a){R(a.a);$(a.b)}
function Rn(a){$(a.b);$(a.a)}
function el(a){kb(a.b);R(a.a)}
function Bl(a){kb(a.a);$(a.b)}
function K(a,b){O(a);L(a,b)}
function Pj(a,b){Ej(a.a,b)}
function nc(a,b){ei(a.e,b)}
function so(a,b){eo(a.b,b)}
function Nl(a,b){fo(a.k,b)}
function C(a,b){Nb(a.f,b.f)}
function ic(a,b,c){di(a.e,b,c)}
function Sn(a,b,c){ic(a.c,b,c)}
function lj(a,b,c){b.w(a.a[c])}
function ti(a,b){return a.a[b]}
function Ol(a,b){return a.i=b}
function Ap(){return Xj(this)}
function Zc(a,b){return Gh(a,b)}
function sc(a,b){a.e=b;rc(a,b)}
function Uj(a,b){a.splice(b,1)}
function wh(a){vc.call(this,a)}
function Zh(a){vc.call(this,a)}
function Cp(){return gi(this.a)}
function Ip(){return this.c.i<0}
function Kp(){return this.b.i<0}
function Pp(){return this.f.i<0}
function Wi(){Si();return new Ri}
function Ah(a){zh(a);return a.k}
function Dj(a,b){a.R(b);return a}
function gj(a,b){while(a.cb(b));}
function Ej(a,b){Mj(a,Dj(a.a,b))}
function Jj(a,b,c){b.w(a.a.Q(c))}
function v(a,b,c){t(a,new H(c),b)}
function Oc(){Oc=mh;Nc=new Rc}
function Ec(){Ec=mh;!!(Vc(),Uc)}
function Mc(){Bc!=0&&(Bc=0);Dc=-1}
function ab(a){J();Yb(a);a.e=-2}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function T(a){mb(a.f);return V(a)}
function En(a){fb(a.b);return a.e}
function Vn(a){fb(a.a);return a.d}
function Fo(a){fb(a.d);return a.e}
function ok(a,b){a.ref=b;return a}
function hc(a,b){this.a=a;this.b=b}
function Lh(a,b){this.a=a;this.b=b}
function pi(a,b){this.a=a;this.b=b}
function Ij(a,b){this.a=a;this.b=b}
function Lj(a,b){this.a=a;this.b=b}
function mk(a,b){this.a=a;this.b=b}
function Db(a){this.d=a;this.b=100}
function Fm(a){this.a=a;Gm=this}
function cn(a){this.a=a;dn=this}
function Ll(a,b){this.a=a;this.b=b}
function jm(a,b){this.a=a;this.b=b}
function km(a,b){this.a=a;this.b=b}
function lm(a,b){this.a=a;this.b=b}
function mm(a,b){this.a=a;this.b=b}
function om(a,b){this.a=a;this.b=b}
function Xk(a,b){Lh.call(this,a,b)}
function Sj(a,b,c){a.splice(b,0,c)}
function pk(a,b){a.href=b;return a}
function gn(a,b){this.a=a;this.b=b}
function hn(a,b){this.a=a;this.b=b}
function kn(a,b){this.a=a;this.b=b}
function ln(a,b){this.a=a;this.b=b}
function Mp(a){return 1==this.a.e}
function Np(a){return 1==this.a.d}
function gi(a){return a.a.b+a.b.b}
function Yi(a,b){return a.a.get(b)}
function Mn(a,b){this.a=a;this.b=b}
function mo(a,b){this.a=a;this.b=b}
function zo(a,b){this.a=a;this.b=b}
function Ao(a,b){this.b=a;this.a=b}
function Uo(a,b){Lh.call(this,a,b)}
function fh(){dh==null&&(dh=[])}
function Bm(){this.a=ik((Jm(),Im))}
function Em(){this.a=ik((Nm(),Mm))}
function bn(){this.a=ik((Rm(),Qm))}
function nn(){this.a=ik((Vm(),Um))}
function sn(){this.a=ik((Zm(),Ym))}
function Fn(a){Dn(a,(fb(a.b),a.e))}
function Wn(a){em(a,(fb(a.a),!a.d))}
function Tb(a){return !a.d?a:Tb(a.d)}
function ci(a){return !a?null:a.$()}
function qd(a){return a==null?null:a}
function fj(a){return a!=null?s(a):0}
function nd(a){return typeof a===bp}
function o(a,b){return qd(a)===qd(b)}
function Tj(a,b){Rj(b,0,a,0,b.length)}
function Vh(a,b){a.a+=''+b;return a}
function yk(a,b){a.value=b;return a}
function tk(a,b){a.onBlur=b;return a}
function qk(a,b){a.onClick=b;return a}
function sk(a,b){a.checked=b;return a}
function Lc(a){$wnd.clearTimeout(a)}
function qi(a){a.a=_c(ie,cp,1,0,5,1)}
function fi(a){a.a=new Ni;a.b=new _i}
function ib(a){this.c=new zi;this.b=a}
function _j(){_j=mh;Yj=new p;$j=new p}
function Wl(a){kb(a.b);R(a.c);$(a.a)}
function fc(a,b){bc(a,b,false);eb(a.c)}
function dk(a,b){for(var c in a){b(c)}}
function vo(a,b){si(dc(a.b),new Zo(b))}
function Sh(a,b){return a.charCodeAt(b)}
function B(a,b,c){return u(a,c,2048,b)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function ld(a,b){return a!=null&&jd(a,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function Xj(a){return a.$H||(a.$H=++Wj)}
function pd(a){return typeof a==='string'}
function pb(a){J();ob(a);sb(a,2,true)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function ec(a,b){nc(b.c,a);ld(b,9)&&b.t()}
function vc(a){this.g=a;qc(this);this.F()}
function Cj(a,b){vj.call(this,a);this.a=b}
function uk(a,b){a.onChange=b;return a}
function vk(a,b){a.onKeyDown=b;return a}
function fk(a,b){a.props['a']=b;return a}
function rk(a){a.autoFocus=true;return a}
function zh(a){if(a.k!=null){return}Ih(a)}
function Gn(a){A((J(),J(),I),new Nn(a),sp)}
function Zn(a){A((J(),J(),I),new ao(a),sp)}
function uo(a){A((J(),J(),I),new Bo(a),sp)}
function cm(a){A((J(),J(),I),new pm(a),sp)}
function A(a,b,c){u(a,new G(b),c,null)}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function Pi(a,b){var c;c=a[op];c.call(a,b)}
function Eo(a){kb(a.a);R(a.b);R(a.c);$(a.d)}
function io(a){return Oh(S(a.e).a-S(a.a).a)}
function md(a){return typeof a==='boolean'}
function Fc(a,b,c){return a.apply(b,c);var d}
function dj(a,b){while(a.W()){Pj(b,a.X())}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function P(){this.a=_c(ie,cp,1,100,5,1)}
function Qh(){Qh=mh;Ph=_c(fe,cp,28,256,0,1)}
function Hi(){this.a=new Ni;this.b=new _i}
function on(a,b){this.a=a;this.b=b;pn=this}
function cj(a,b,c){this.a=a;this.b=b;this.c=c}
function zk(a,b){a.onDoubleClick=b;return a}
function ri(a,b){a.a[a.a.length]=b;return true}
function qc(a){a.j&&a.e!==jp&&a.F();return a}
function Dh(a){var b;b=Ch(a);Kh(a,b);return b}
function Vc(){Vc=mh;var a;!Xc();a=new Yc;Uc=a}
function uh(a,b,c,d){a.addEventListener(b,c,d)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function Dl(a,b){A((J(),J(),I),new Ll(a,b),sp)}
function Yl(a,b){A((J(),J(),I),new om(a,b),sp)}
function am(a,b){A((J(),J(),I),new lm(a,b),sp)}
function bm(a,b){A((J(),J(),I),new km(a,b),sp)}
function dm(a,b){A((J(),J(),I),new jm(a,b),sp)}
function fo(a,b){A((J(),J(),I),new mo(a,b),sp)}
function xo(a,b){A((J(),J(),I),new zo(a,b),sp)}
function jj(a,b){while(a.c<a.d){lj(a,b,a.c++)}}
function nj(a){if(!a.d){a.d=a.b.P();a.c=a.b.S()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function El(a,b){var c;c=b.target;Fl(a,c.value)}
function wj(a,b){var c;return Aj(a,(c=new zi,c))}
function Fh(a){var b;b=Ch(a);b.j=a;b.e=1;return b}
function ki(a){var b;b=a.a.X();a.b=ji(a);return b}
function go(a){Rh(new ni(a.g),new gc(a));fi(a.g)}
function co(a){R(a.d);R(a.e);R(a.a);R(a.b);$(a.c)}
function ho(a){return xh(),0!=S(a.e).a?true:false}
function Co(a){return o(xp,a)||o(yp,a)||o('',a)}
function Xi(a,b){return !(a.a.get(b)===undefined)}
function bd(a){return Array.isArray(a)&&a.nb===qh}
function kd(a){return !Array.isArray(a)&&a.nb===qh}
function Di(a){return new Cj(null,Ci(a,a.length))}
function Ci(a,b){return hj(b,a.length),new mj(a,b)}
function fl(a){return B((J(),J(),I),a.b,new kl(a))}
function gl(a){return xh(),S(a.f.b).a>0?true:false}
function no(a,b){this.a=a;this.c=b;this.b=false}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function ck(){if(Zj==256){Yj=$j;$j=new p;Zj=0}++Zj}
function cl(a){if(0==a.e){a.e=1;a.d.forceUpdate()}}
function ol(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Ul(a){if(0==a.g){a.g=1;a.f.forceUpdate()}}
function Gj(a,b,c){if(a.a.eb(c)){a.b=true;b.w(c)}}
function vh(a,b,c,d){a.removeEventListener(b,c,d)}
function Sc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function vi(a,b){var c;c=a.a[b];Uj(a.a,b);return c}
function xi(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function qm(a,b){var c;c=b.target;xo(a.f,c.checked)}
function Fl(a,b){var c;c=a.g;if(b!=c){a.g=b;eb(a.b)}}
function em(a,b){var c;c=a.d;if(b!=c){a.d=b;eb(a.a)}}
function vm(a){return B((J(),J(),I),a.a,new zm(a))}
function ql(a){return B((J(),J(),I),a.a,new ul(a))}
function Cl(a){return B((J(),J(),I),a.a,new Il(a))}
function Xl(a){return B((J(),J(),I),a.b,new hm(a))}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Hn(a,b){var c;c=a.e;if(b!=c){a.e=b;eb(a.b)}}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function xk(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function hi(a,b){if(b){return ai(a.a,b)}return false}
function yj(a,b){uj(a);return new Cj(a,new Hj(b,a.a))}
function zj(a,b){uj(a);return new Cj(a,new Kj(b,a.a))}
function Dn(a,b){A((J(),J(),I),new Mn(a,b),75497472)}
function Gi(a,b){return qd(a)===qd(b)||a!=null&&q(a,b)}
function Bn(a){var b;U(a.a);b=S(a.a);o(a.f,b)&&Hn(a,b)}
function Eh(a,b){var c;c=Ch(a);Kh(a,c);c.e=b?8:0;return c}
function mj(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Cm(a,b,c){this.a=a;this.b=b;this.c=c;Dm=this}
function tn(a,b,c){this.a=a;this.b=b;this.c=c;un=this}
function ij(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function oj(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function $l(a,b){Io(a.n,b);A((J(),J(),I),new jm(a,b),sp)}
function tj(a){if(!a.b){uj(a);a.c=true}else{tj(a.b)}}
function vj(a){if(!a){this.b=null;new zi}else{this.b=a}}
function Hh(a){if(a.N()){return null}var b=a.j;return ih[b]}
function bh(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function th(){th=mh;sh=$wnd.goog.global.document}
function Kc(a){Ec();$wnd.setTimeout(function(){throw a},0)}
function Vo(){To();return cd(Zc(Mg,1),cp,30,0,[Qo,So,Ro])}
function bi(a,b){return b===a?'(this Map)':b==null?lp:ph(b)}
function tc(a,b){var c;c=Ah(a.lb);return b==null?c:c+': '+b}
function Ml(a,b){var c;if(S(a.c)){c=b.target;em(a,c.value)}}
function Rh(a,b){var c,d;for(d=a.P();d.W();){c=d.X();b.w(c)}}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function lb(a){C((J(),J(),I),a);0==(a.f.a&hp)&&D((null,I))}
function _l(a,b){A((J(),J(),I),new jm(a,b),sp);Io(a.n,null)}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function oh(a){function b(){}
;b.prototype=a||{};return new b}
function wk(a){a.placeholder='What needs to be done?';return a}
function uj(a){if(a.b){uj(a.b)}else if(a.c){throw Yg(new Mh)}}
function Zl(a){return xh(),Fo(a.n)==a.f.props['a']?true:false}
function xn(a){uh((th(),$wnd.goog.global.window),vp,a.d,false)}
function yn(a){vh((th(),$wnd.goog.global.window),vp,a.d,false)}
function Jm(){Jm=mh;var a;Im=(a=nh(Hm.prototype.kb,Hm,[]),a)}
function Nm(){Nm=mh;var a;Mm=(a=nh(Lm.prototype.kb,Lm,[]),a)}
function Rm(){Rm=mh;var a;Qm=(a=nh(Pm.prototype.kb,Pm,[]),a)}
function Vm(){Vm=mh;var a;Um=(a=nh(Tm.prototype.kb,Tm,[]),a)}
function Zm(){Zm=mh;var a;Ym=(a=nh(Xm.prototype.kb,Xm,[]),a)}
function Gh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.I(b))}
function Ji(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function Ki(a,b){var c;return Ii(b,Ji(a,b==null?0:(c=s(b),c|0)))}
function cc(a){fb(a.c);return new Cj(null,new oj(new ni(a.g),0))}
function zn(a,b){b.preventDefault();A((J(),J(),I),new On(a),sp)}
function Kj(a,b){ij.call(this,b.bb(),b.ab()&-6);this.a=a;this.b=b}
function Oi(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function yo(a){this.b=a;J();this.a=new oc(0,null,null,false,false)}
function Ai(a){qi(this);Tj(this.a,_h(a,_c(ie,cp,1,gi(a.a),5,1)))}
function mc(a){kc(a.g);!!a.e&&lc(a);Y(a.a);Y(a.c);kc(a.b);kc(a.f)}
function kj(a,b){if(a.c<a.d){lj(a,b,a.c++);return true}return false}
function kh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function kk(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Ic(a,b,c){var d;d=Gc();try{return Fc(a,b,c)}finally{Jc(d)}}
function bb(a,b){var c,d;ri(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Hj(a,b){ij.call(this,b.bb(),b.ab()&-16449);this.a=a;this.c=b}
function aj(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function pj(a,b){!a.a?(a.a=new Xh(a.d)):Vh(a.a,a.b);Vh(a.a,b);return a}
function Aj(a,b){var c;tj(a);c=new Nj;c.a=b;a.a.V(new Qj(c));return c.a}
function xj(a){var b;tj(a);b=0;while(a.a.cb(new Oj)){b=Zg(b,1)}return b}
function uc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Hc(b){Ec();return function(){return Ic(b,this,arguments);var a}}
function Ac(){if(Date.now){return Date.now()}return (new Date).getTime()}
function wo(a){wj(yj(cc(a.b),new Xo),new sj(new rj)).O(new Yo(a.b))}
function Ib(b){try{mb(b.b.a)}catch(a){a=Xg(a);if(!ld(a,4))throw Yg(a)}}
function Jc(a){a&&Qc((Oc(),Nc));--Bc;if(a){if(Dc!=-1){Lc(Dc);Dc=-1}}}
function vl(a){var b;b=Uh((fb(a.b),a.g));if(b.length>0){so(a.f,b);Fl(a,'')}}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function _c(a,b,c,d,e,f){var g;g=ad(e,d);e!=10&&cd(Zc(a,f),b,c,e,g);return g}
function eo(a,b){var c;return u((J(),J(),I),new no(a,b),sp,(c=null,c))}
function Bj(a,b){var c;c=wj(a,new sj(new rj));return yi(c,b.db(c.a.length))}
function qj(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function li(a){this.d=a;this.c=new aj(this.d.b);this.a=this.c;this.b=ji(this)}
function Om(a){$wnd.React.Component.call(this,a);this.a=new rl(this,Gm.a)}
function Sm(a){$wnd.React.Component.call(this,a);this.a=new Gl(this,dn.a)}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function ei(a,b){return pd(b)?b==null?Mi(a.a,null):$i(a.b,b):Mi(a.a,b)}
function di(a,b,c){return pd(b)?b==null?Li(a.a,null,c):Zi(a.b,b,c):Li(a.a,b,c)}
function Do(a,b){return (To(),Ro)==a||(Qo==a?(fb(b.a),!b.d):(fb(b.a),b.d))}
function Vj(a,b){return $c(b)!=10&&cd(r(b),b.mb,b.__elementTypeId$,$c(b),a),a}
function wn(a,b){a.f=b;o(b,S(a.a))&&Hn(a,b);An(b);A((J(),J(),I),new On(a),sp)}
function Go(a){var b;return b=S(a.b),wj(yj(cc(a.i),new $o(b)),new sj(new rj))}
function jc(a){if(a.i>=0){a.i=-2;u((J(),J(),I),new G(new pc(a)),67108864,null)}}
function R(a){if(!a.a){a.a=true;a.n=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function $(a){if(-2!=a.e){u((J(),J(),I),new G(new jb(a)),0,null);!!a.b&&kb(a.b)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function bj(a){if(a.a.c!=a.c){return Yi(a.a,a.b.value[0])}return a.b.value[1]}
function Tn(a,b){var c;if(ld(b,46)){c=b;return a.c.d==c.c.d}else{return false}}
function wi(a,b){var c;c=ui(a,b,0);if(c==-1){return false}Uj(a.a,c);return true}
function si(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.w(c)}}
function Ob(){var a;this.a=_c(wd,cp,43,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Wm(a){$wnd.React.Component.call(this,a);this.a=new fm(this,pn.a,pn.b)}
function $c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===ap||typeof a==='function')&&!(a.nb===qh)}
function dc(a){return fb(a.c),wj(new Cj(null,new oj(new ni(a.g),0)),new sj(new rj))}
function V(a){if(a.b){if(ld(a.b,8)){throw Yg(a.b)}else{throw Yg(a.b)}}return a.n}
function rb(b){if(b){try{b.v()}catch(a){a=Xg(a);if(ld(a,4)){J()}else throw Yg(a)}}}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function Pc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Tc(b,c)}while(a.a);a.a=c}}
function Qc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Tc(b,c)}while(a.b);a.b=c}}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new zi);ri(a.b,b)}}}
function Kh(a,b){var c;if(!a){return}b.j=a;var d=Hh(b);if(!d){ih[a]=[b];return}d.lb=b}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new zi);a.c=c.c}b.d=true;ri(a.c,b)}
function Ch(a){var b;b=new Bh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function mn(a,b){gk(a.a,(b?Oh(b.c.d):null)+(''+(zh(ag),ag.k)));fk(a.a,b);return a.a}
function ui(a,b,c){for(;c<a.a.length;++c){if(Gi(b,a.a[c])){return c}}return -1}
function $i(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{Pi(a.a,b);--a.b}return c}
function nh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function eh(){fh();var a=dh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Mh(){vc.call(this,"Stream already terminated, can't be modified or used")}
function wl(a,b){if(13==b.keyCode){b.preventDefault();A((J(),J(),I),new Jl(a),sp)}}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?ip:0)|(0!=(b&229376)?0:98304)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:ep)|(0==(c&6291456)?!a?hp:ip:0)|0|0|0)}
function ob(a){var b,c;for(c=new Bi(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ei(a){var b,c,d;d=0;for(c=new li(a.a);c.b;){b=ki(c);d=d+(b?s(b):0);d=d|0}return d}
function $h(a,b){var c,d;for(d=new li(b.a);d.b;){c=ki(d);if(!hi(a,c)){return false}}return true}
function bo(a,b,c){var d;d=new $n(b,c);Sn(d,a,new hc(a,d));di(a.g,Oh(d.c.d),d);eb(a.c);return d}
function bc(a,b,c){var d;d=ei(a.g,b?Oh(b.c.d):null);if(null!=d){nc(b.c,a);c&&!!b&&jc(b.c);eb(a.c)}}
function ik(a){var b;b=hk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function $m(a){$wnd.React.Component.call(this,a);this.a=new wm(this,un.a,un.b,un.c)}
function Km(a){$wnd.React.Component.call(this,a);this.a=new hl(this,Dm.a,Dm.b,Dm.c)}
function rh(){new vn;$wnd.ReactDOM.render((new sn).a,(th(),sh).getElementById('app'),null)}
function To(){To=mh;Qo=new Uo('ACTIVE',0);So=new Uo('COMPLETED',1);Ro=new Uo('ALL',2)}
function hh(a,b){typeof window===ap&&typeof window['$gwt']===ap&&(window['$gwt'][a]=b)}
function hj(a,b){if(0>a||a>b){throw Yg(new wh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function ji(a){if(a.a.W()){return true}if(a.a!=a.c){return false}a.a=new Oi(a.d.a);return a.a.W()}
function Xg(a){var b;if(ld(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new zc(a);Wc(b)}return b}
function $g(a){var b;b=a.h;if(b==0){return a.l+a.m*ip}if(b==1048575){return a.l+a.m*ip-mp}return a}
function ah(a){var b,c,d,e;e=a;d=0;if(e<0){e+=mp;d=1048575}c=rd(e/ip);b=rd(e-c*ip);return dd(b,c,d)}
function Ii(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Gi(a,c.Z())){return c}}return null}
function cd(a,b,c,d,e){e.lb=a;e.mb=b;e.nb=qh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Zi(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Io(a,b){var c;c=a.e;if(!(b==c||!!b&&Tn(b,c))){!!c&&nc(c.c,a);a.e=b;!!b&&Sn(b,a,new Lo(a));eb(a.d)}}
function Ho(a){var b;b=S(a.g.a);o(xp,b)||o(yp,b)||o('',b)?Dn(a.g,b):Co(En(a.g))?Gn(a.g):Dn(a.g,'')}
function zc(a){xc();qc(this);this.e=a;rc(this,a);this.g=a==null?lp:ph(a);this.a='';this.b=a;this.a=''}
function Bh(){this.g=yh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function $k(){if(!Zk){Zk=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(nh(_k.prototype.H,_k,[]))}}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function Pl(a,b,c){27==c.which?A((J(),J(),I),new mm(a,b),sp):13==c.which&&A((J(),J(),I),new km(a,b),sp)}
function cb(a,b){var c,d;d=a.c;wi(d,b);!!a.b&&ep!=(a.b.c&fp)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function Zg(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<mp){return c}}return $g(ed(nd(a)?ah(a):a,nd(b)?ah(b):b))}
function Oh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Qh(),Ph)[b];!c&&(c=Ph[b]=new Nh(a));return c}return new Nh(a)}
function ph(a){var b;if(Array.isArray(a)&&a.nb===qh){return Ah(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function bk(a){_j();var b,c,d;c=':'+a;d=$j[c];if(d!=null){return rd(d)}d=Yj[c];b=d==null?ak(a):rd(d);ck();$j[c]=b;return b}
function Fi(a){var b,c,d;d=1;for(c=new Bi(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Vb(a){var b;if(a.c){while(a.c.a.length!=0){b=vi(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function Rl(a){var b;b=S(a.c);if(!a.j&&b){a.j=true;dm(a,a.f.props['a']);a.i.focus();a.i.select()}else a.j&&!b&&(a.j=false)}
function r(a){return pd(a)?le:nd(a)?ae:md(a)?$d:kd(a)?a.lb:bd(a)?a.lb:a.lb||Array.isArray(a)&&Zc(Sd,1)||Sd}
function s(a){return pd(a)?bk(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.q():bd(a)?Xj(a):!!a&&!!a.hashCode?a.hashCode():Xj(a)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&ep)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(ep==(b&fp)?0:524288)|(0==(b&6291456)?ep==(b&fp)?ip:hp:0)|0|268435456|0)}
function Yk(){Wk();return cd(Zc(bf,1),cp,6,0,[Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk])}
function Ql(a,b){var c;c=(fb(a.a),a.d);if(null!=c&&c.length!=0){A((J(),J(),I),new Ao(b,c),sp);Io(a.n,null);em(a,c)}else{fo(a.k,b)}}
function rl(a,b){var c;this.e=b;this.c=a;J();c=++pl;this.b=new oc(c,null,new sl(this),false,false);this.a=new vb(null,new tl(this),rp)}
function oc(a,b,c,d,e){var f,g;this.d=a;this.e=d?new Hi:null;this.g=b;this.b=c;this.f=null;this.a=e?(g=new ib((f=null,J(),f)),g):null;this.c=null}
function Jh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function yi(a,b){var c,d;d=a.a.length;b.length<d&&(b=Vj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Gc(){var a;if(Bc!=0){a=Ac();if(a-Cc>2000){Cc=a;Dc=$wnd.setTimeout(Mc,10)}}if(Bc++==0){Pc((Oc(),Nc));return true}return false}
function Xc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function lc(a){var b,c,d;for(c=new Bi(new Ai(new ii(a.e)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.Z();ld(d,9)&&d.u()||b.$().v()}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Bi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Bi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Bi(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function q(a,b){return pd(a)?o(a,b):nd(a)?qd(a)===qd(b):md(a)?qd(a)===qd(b):kd(a)?a.o(b):bd(a)?o(a,b):!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.mb){return !!a.mb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function nk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.k?gb(a.e):fb(a.e);if(tb(a.f)){if(a.k&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Uh(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _h(a,b){var c,d,e,f;f=gi(a.a);b.length<f&&(b=Vj(new Array(f),b));e=b;d=new li(a.a);for(c=0;c<f;++c){e[c]=ki(d)}b.length>f&&(b[f]=null);return b}
function ad(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.v(),null)}finally{ac()}return f}catch(a){a=Xg(a);if(ld(a,4)){e=a;throw Yg(e)}else throw Yg(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.s()}else{_b(b,e);try{g=c.s()}finally{ac()}}return g}catch(a){a=Xg(a);if(ld(a,4)){f=a;throw Yg(f)}else throw Yg(a)}finally{D(b)}}
function wm(a,b,c,d){var e;this.e=b;this.f=c;this.g=d;this.c=a;J();e=++um;this.b=new oc(e,null,new xm(this),false,false);this.a=new vb(null,new ym(this),rp)}
function Gl(a,b){var c,d,e;this.f=b;this.d=a;J();c=++Al;this.c=new oc(c,null,new Hl(this),false,false);this.b=(e=new ib((d=null,d)),e);this.a=new vb(null,new Kl(this),rp)}
function $n(a,b){var c,d,e,f,g;this.e=a;this.d=b;J();c=++Qn;this.c=new oc(c,null,new _n(this),true,true);this.b=(g=new ib((e=null,e)),g);this.a=(f=new ib((d=null,d)),f)}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function gh(b,c,d,e){fh();var f=dh;$moduleName=c;$moduleBase=d;Wg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{_o(g)()}catch(a){b(c,a)}}else{_o(g)()}}
function W(a,b,c,d){this.c=a;this.g=b;this.i=c;this.j=null;this.n=null;this.k=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);ep==(d&fp)&&lb(this.f)}
function hk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Ui(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Vi()}}
function nl(a){var b,c;a.d=0;$k();c=(b=S(a.e.e).a,jk('span',nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,['todo-count'])),[jk('strong',null,[b]),' item'+(b==1?'':'s')+' left']));return c}
function jh(){ih={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Tc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].ob()&&(c=Sc(c,g)):g[0].ob()}catch(a){a=Xg(a);if(ld(a,4)){d=a;Ec();Kc(ld(d,34)?d.G():d)}else throw Yg(a)}}return c}
function yl(a){var b;a.e=0;$k();b=jk(tp,rk(uk(vk(yk(wk(nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,['new-todo']))),(fb(a.b),a.g)),nh(_m.prototype.ib,_m,[a])),nh(an.prototype.hb,an,[a]))),null);return b}
function yc(a){var b;if(a.c==null){b=qd(a.b)===qd(wc)?null:a.b;a.d=b==null?lp:od(b)?b==null?null:b.name:pd(b)?'String':Ah(r(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function Q(b){var c,d,e;e=b.n;try{d=b.c.s();if(!(qd(e)===qd(d)||e!=null&&q(e,d))){b.n=d;b.b=null;db(b.e)}}catch(a){a=Xg(a);if(ld(a,10)){c=a;if(!b.b){b.n=null;b.b=c;db(b.e)}throw Yg(c)}else throw Yg(a)}}
function Li(a,b,c){var d,e,f,g,h;h=b==null?0:(g=s(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=Ii(b,e);if(f){return f._(c)}}e[e.length]=new pi(b,c);++a.b;return null}
function Rj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function vn(){this.a=new jo;new Fm(this.a);this.b=new In;this.c=new yo(this.a);this.d=new Jo(this.a,this.b);new Cm(this.a,this.c,this.d);new tn(this.a,this.c,this.d);new cn(this.c);new on(this.a,this.d)}
function hl(a,b,c,d){var e;this.f=b;this.g=c;this.i=d;this.d=a;J();e=++dl;this.c=new oc(e,null,new il(this),false,false);this.a=new W(new jl(this),null,null,136478720);this.b=new vb(null,new ll(this),rp)}
function fm(a,b,c){var d,e,f;this.k=b;this.n=c;this.f=a;J();d=++Vl;this.e=new oc(d,null,new gm(this),false,false);this.a=(f=new ib((e=null,e)),f);this.c=new W(new im(this),null,null,136478720);this.b=new vb(null,new nm(this),rp);dm(this,this.f.props['a'])}
function ak(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Sh(a,c++)}b=b|0;return b}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{b.e.v()}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Xg(a);if(ld(a,4)){J()}else throw Yg(a)}}}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=_c(ie,cp,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function ub(a,b,c,d){this.b=new zi;this.f=new Jb(new yb(this),d&6520832|262144|ep);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&hp)&&D((null,I)))}
function Mi(a,b){var c,d,e,f,g,h;g=b==null?0:(f=s(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Gi(b,e.Z())){if(d.length==1){d.length=0;Pi(a.a,g)}else{d.splice(h,1)}--a.b;return e.$()}}return null}
function lh(a,b,c){var d=ih,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=ih[b]),oh(h));_.mb=c;!b&&(_.nb=qh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.lb=f)}
function Ih(a){if(a.M()){var b=a.c;b.N()?(a.k='['+b.j):!b.M()?(a.k='[L'+b.K()+';'):(a.k='['+b.K());a.b=b.J()+'[]';a.i=b.L()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=Jh('.',[c,Jh('$',d)]);a.b=Jh('.',[c,Jh('.',d)]);a.i=d[d.length-1]}
function ai(a,b){var c,d,e;c=b.Z();e=b.$();d=pd(c)?c==null?ci(Ki(a.a,null)):Yi(a.b,c):ci(Ki(a.a,c));if(!(qd(e)===qd(d)||e!=null&&q(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!Ki(a.a,null):Xi(a.b,c):!!Ki(a.a,c))){return false}return true}
function An(a){var b;if(0==a.length){b=(th(),$wnd.goog.global.window).location.pathname+(''+$wnd.goog.global.window.location.search);$wnd.goog.global.window.history.pushState('',sh.title,b)}else{(th(),$wnd.goog.global.window).location.hash=a}}
function Jo(a,b){var c,d;this.i=a;this.g=b;J();this.f=new oc(0,null,new Ko(this),false,false);this.d=(d=new ib((c=null,c)),d);this.b=new W(new Mo(this),null,null,wp);this.c=new W(new No(this),null,null,wp);this.a=new vb(new Oo(this),null,681574400);D((null,I))}
function jo(){var a;this.g=new Hi;J();this.f=new oc(0,new lo(this),new ko(this),false,false);this.c=(a=new ib(null),a);this.d=new W(new oo(this),null,null,wp);this.e=new W(new po(this),null,null,wp);this.a=new W(new qo(this),null,null,wp);this.b=new W(new ro(this),null,null,wp)}
function In(){var a,b,c;this.d=new Po(this);this.f=this.e=(c=(th(),$wnd.goog.global.window).location.hash,null==c?'':c.substr(1));J();this.c=new oc(0,null,new Jn(this),false,false);this.b=(b=new ib((a=null,a)),b);this.a=new W(new Pn,new Kn(this),new Ln(this),35651584)}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Bi(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Xg(a);if(!ld(a,4))throw Yg(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function rc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.C();return a&&a.A()}},suppressed:{get:function(){return c.B()}}})}catch(a){}}}
function jk(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ek(b,nh(mk.prototype.fb,mk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=hk($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function Ti(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.j,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.i,e));d.n=null}si(a.b,new Ab(a));a.b.a=_c(ie,cp,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function sm(a){var b;a.d=0;$k();b=jk('div',null,[jk('div',null,[jk(up,nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,[up])),[jk('h1',null,['todos']),(new bn).a]),S(a.e.d)?jk('section',nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,[up])),[jk(tp,uk(xk(nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,['toggle-all'])),(Wk(),Bk)),nh(qn.prototype.hb,qn,[a])),null),jk('ul',nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,['todo-list'])),Bj(zj(S(a.g.c).U(),new rn),new lk))]):null,S(a.e.d)?(new Bm).a:null])]);return b}
function Wk(){Wk=mh;Ak=new Xk(pp,0);Bk=new Xk('checkbox',1);Ck=new Xk('color',2);Dk=new Xk('date',3);Ek=new Xk('datetime',4);Fk=new Xk('email',5);Gk=new Xk('file',6);Hk=new Xk('hidden',7);Ik=new Xk('image',8);Jk=new Xk('month',9);Kk=new Xk(bp,10);Lk=new Xk('password',11);Mk=new Xk('radio',12);Nk=new Xk('range',13);Ok=new Xk('reset',14);Pk=new Xk('search',15);Qk=new Xk('submit',16);Rk=new Xk('tel',17);Sk=new Xk('text',18);Tk=new Xk('time',19);Uk=new Xk('url',20);Vk=new Xk('week',21)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ti(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&xi(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ti(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){vi(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new zi)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&ep!=(k.b.c&fp)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function bl(a){var b,c;a.e=0;$k();c=(b=S(a.i.b),jk('footer',nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,['footer'])),[(new Em).a,jk('ul',nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,['filters'])),[jk('li',null,[jk('a',pk(nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,[(To(),Ro)==b?qp:null])),'#'),['All'])]),jk('li',null,[jk('a',pk(nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,[Qo==b?qp:null])),'#active'),['Active'])]),jk('li',null,[jk('a',pk(nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,[So==b?qp:null])),'#completed'),['Completed'])])]),S(a.a)?jk(pp,qk(nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,['clear-completed'])),nh(Am.prototype.jb,Am,[a])),['Clear Completed']):null]));return c}
function Tl(a){var b,c,d,e;a.g=0;$k();b=a.f.props['a'];if(!!b&&b.c.i<0){return null}c=(d=a.f.props['a'],e=(fb(d.a),d.d),jk('li',nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,[e?'checked':null,S(a.c)?'editing':null])),[jk('div',nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,['view'])),[jk(tp,uk(sk(xk(nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,['toggle'])),(Wk(),Bk)),e),nh(fn.prototype.hb,fn,[d])),null),jk('label',zk(new $wnd.Object,nh(gn.prototype.jb,gn,[a,d])),[(fb(d.b),d.e)]),jk(pp,qk(nk(new $wnd.Object,cd(Zc(le,1),cp,2,6,['destroy'])),nh(hn.prototype.jb,hn,[a,d])),null)]),jk(tp,vk(uk(tk(yk(nk(ok(new $wnd.Object,nh(jn.prototype.w,jn,[a])),cd(Zc(le,1),cp,2,6,['edit'])),(fb(a.a),a.d)),nh(kn.prototype.gb,kn,[a,d])),nh(en.prototype.hb,en,[a])),nh(ln.prototype.ib,ln,[a,d])),null)]));return c}
function Vi(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[op]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ti()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[op]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var ap='object',bp='number',cp={3:1},dp={9:1},ep=1048576,fp=1835008,gp={5:1},hp=2097152,ip=4194304,jp='__noinit__',kp={3:1,10:1,8:1,4:1},lp='null',mp=17592186044416,np={40:1},op='delete',pp='button',qp='selected',rp=1411518464,sp=142606336,tp='input',up='header',vp='hashchange',wp=136314880,xp='active',yp='completed';var _,ih,dh,Wg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;jh();lh(1,null,{},p);_.o=function(a){return o(this,a)};_.p=function(){return this.lb};_.q=Ap;_.r=function(){var a;return Ah(r(this))+'@'+(a=s(this)>>>0,a.toString(16))};_.equals=function(a){return this.o(a)};_.hashCode=function(){return this.q()};_.toString=function(){return this.r()};var fd,gd,hd;lh(51,1,{},Bh);_.I=function(a){var b;b=new Bh;b.e=4;a>1?(b.c=Gh(this,a-1)):(b.c=this);return b};_.J=function(){zh(this);return this.b};_.K=function(){return Ah(this)};_.L=function(){zh(this);return this.i};_.M=function(){return (this.e&4)!=0};_.N=function(){return (this.e&1)!=0};_.r=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(zh(this),this.k)};_.e=0;_.g=0;var yh=1;var ie=Dh(1);var _d=Dh(51);lh(78,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var vd=Dh(78);lh(35,1,{},G);_.s=function(){return this.a.v(),null};var td=Dh(35);lh(79,1,{},H);var ud=Dh(79);var I;lh(43,1,{43:1},P);_.b=0;_.c=false;_.d=0;var wd=Dh(43);lh(223,1,dp);_.r=function(){var a;return Ah(this.lb)+'@'+(a=s(this)>>>0,a.toString(16))};var zd=Dh(223);lh(18,223,dp,W);_.t=function(){R(this)};_.u=zp;_.a=false;_.d=0;_.k=false;var yd=Dh(18);lh(128,1,{},X);_.s=function(){return T(this.a)};var xd=Dh(128);lh(16,223,{9:1,16:1},ib);_.t=function(){$(this)};_.u=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var Bd=Dh(16);lh(127,1,gp,jb);_.v=function(){ab(this.a)};var Ad=Dh(127);lh(17,223,{9:1,17:1},vb,wb);_.t=function(){kb(this)};_.u=function(){return 1==(this.c&7)};_.c=0;var Gd=Dh(17);lh(129,1,{},xb);_.v=function(){Q(this.a)};var Cd=Dh(129);lh(130,1,gp,yb);_.v=function(){mb(this.a)};var Dd=Dh(130);lh(131,1,gp,zb);_.v=function(){pb(this.a)};var Ed=Dh(131);lh(132,1,{},Ab);_.w=function(a){nb(this.a,a)};var Fd=Dh(132);lh(142,1,{},Db);_.a=0;_.b=0;_.c=0;var Hd=Dh(142);lh(162,1,dp,Fb);_.t=function(){Eb(this)};_.u=zp;_.a=false;var Id=Dh(162);lh(59,223,{9:1,59:1},Jb);_.t=function(){Gb(this)};_.u=function(){return 2==(3&this.a)};_.a=0;var Kd=Dh(59);lh(141,1,{},Ob);var Jd=Dh(141);lh(144,1,{},$b);_.r=function(){var a;return zh(Ld),Ld.k+'@'+(a=Xj(this)>>>0,a.toString(16))};_.a=0;var Pb;var Ld=Dh(144);lh(95,1,{});var Od=Dh(95);lh(84,1,{},gc);_.w=function(a){ec(this.a,a)};var Md=Dh(84);lh(85,1,gp,hc);_.v=function(){fc(this.a,this.b)};var Nd=Dh(85);lh(15,1,dp,oc);_.t=function(){jc(this)};_.u=function(){return this.i<0};_.r=function(){var a;return zh(Qd),Qd.k+'@'+(a=Xj(this)>>>0,a.toString(16))};_.d=0;_.i=0;var Qd=Dh(15);lh(126,1,gp,pc);_.v=function(){mc(this.a)};var Pd=Dh(126);lh(4,1,{3:1,4:1});_.A=Fp;_.B=function(){return Bj(zj(Di((this.i==null&&(this.i=_c(ne,cp,4,0,0,1)),this.i)),new Yh),new Fj)};_.C=function(){return this.f};_.D=function(){return this.g};_.F=function(){sc(this,uc(new Error(tc(this,this.g))));Wc(this)};_.r=function(){return tc(this,this.D())};_.e=jp;_.j=true;var ne=Dh(4);lh(10,4,{3:1,10:1,4:1});var ce=Dh(10);lh(8,10,kp);var je=Dh(8);lh(72,8,kp);var ge=Dh(72);lh(73,72,kp);var Ud=Dh(73);lh(34,73,{34:1,3:1,10:1,8:1,4:1},zc);_.D=function(){yc(this);return this.c};_.G=function(){return qd(this.b)===qd(wc)?null:this.b};var wc;var Rd=Dh(34);var Sd=Dh(0);lh(209,1,{});var Td=Dh(209);var Bc=0,Cc=0,Dc=-1;lh(81,209,{},Rc);var Nc;var Vd=Dh(81);var Uc;lh(220,1,{});var Xd=Dh(220);lh(74,220,{},Yc);var Wd=Dh(74);var sh;lh(70,1,{67:1});_.r=zp;var Yd=Dh(70);lh(76,8,kp);var ee=Dh(76);lh(155,76,kp,wh);var Zd=Dh(155);fd={3:1,68:1,27:1};var $d=Dh(68);lh(41,1,{3:1,41:1});var he=Dh(41);gd={3:1,27:1,41:1};var ae=Dh(219);lh(29,1,{3:1,27:1,29:1});_.o=function(a){return this===a};_.q=Ap;_.r=function(){return this.a!=null?this.a:''+this.b};_.b=0;var be=Dh(29);lh(75,8,kp,Mh);var de=Dh(75);lh(28,41,{3:1,27:1,28:1,41:1},Nh);_.o=function(a){return ld(a,28)&&a.a==this.a};_.q=zp;_.r=function(){return ''+this.a};_.a=0;var fe=Dh(28);var Ph;lh(282,1,{});hd={3:1,67:1,27:1,2:1};var le=Dh(2);lh(71,70,{67:1},Xh);var ke=Dh(71);lh(286,1,{});lh(65,1,{},Yh);_.Q=function(a){return a.e};var me=Dh(65);lh(53,8,kp,Zh);var oe=Dh(53);lh(221,1,{39:1});_.O=Ep;_.T=function(){return new oj(this,0)};_.U=function(){return new Cj(null,this.T())};_.R=function(a){throw Yg(new Zh('Add not supported on this collection'))};_.r=function(){var a,b,c;c=new qj('[',']');for(b=this.P();b.W();){a=b.X();pj(c,a===this?'(this Collection)':a==null?lp:ph(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=Dh(221);lh(225,1,{207:1});_.o=function(a){var b,c,d;if(a===this){return true}if(!ld(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new li((new ii(d)).a);c.b;){b=ki(c);if(!ai(this,b)){return false}}return true};_.q=function(){return Ei(new ii(this))};_.r=function(){var a,b,c;c=new qj('{','}');for(b=new li((new ii(this)).a);b.b;){a=ki(b);pj(c,bi(this,a.Z())+'='+bi(this,a.$()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=Dh(225);lh(140,225,{207:1});var se=Dh(140);lh(224,221,{39:1,230:1});_.T=function(){return new oj(this,1)};_.o=function(a){var b;if(a===this){return true}if(!ld(a,21)){return false}b=a;if(gi(b.a)!=this.S()){return false}return $h(this,b)};_.q=function(){return Ei(this)};var Be=Dh(224);lh(21,224,{21:1,39:1,230:1},ii);_.P=function(){return new li(this.a)};_.S=Cp;var re=Dh(21);lh(22,1,{},li);_.V=Bp;_.X=function(){return ki(this)};_.W=Dp;_.b=false;var qe=Dh(22);lh(222,221,{39:1,227:1});_.T=function(){return new oj(this,16)};_.Y=function(a,b){throw Yg(new Zh('Add not supported on this list'))};_.R=function(a){this.Y(this.S(),a);return true};_.o=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,13)){return false}f=a;if(this.S()!=f.a.length){return false}e=new Bi(f);for(c=new Bi(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&q(b,d))){return false}}return true};_.q=function(){return Fi(this)};_.P=function(){return new mi(this)};var ue=Dh(222);lh(80,1,{},mi);_.V=Bp;_.W=function(){return this.a<this.b.a.length};_.X=function(){return ti(this.b,this.a++)};_.a=0;var te=Dh(80);lh(42,221,{39:1},ni);_.P=function(){var a;a=new li((new ii(this.a)).a);return new oi(a)};_.S=Cp;var we=Dh(42);lh(135,1,{},oi);_.V=Bp;_.W=function(){return this.a.b};_.X=function(){var a;a=ki(this.a);return a.$()};var ve=Dh(135);lh(133,1,np);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Gi(this.a,b.Z())&&Gi(this.b,b.$())};_.Z=zp;_.$=Dp;_.q=function(){return fj(this.a)^fj(this.b)};_._=function(a){var b;b=this.b;this.b=a;return b};_.r=function(){return this.a+'='+this.b};var xe=Dh(133);lh(134,133,np,pi);var ye=Dh(134);lh(226,1,np);_.o=function(a){var b;if(!ld(a,40)){return false}b=a;return Gi(this.b.value[0],b.Z())&&Gi(bj(this),b.$())};_.q=function(){return fj(this.b.value[0])^fj(bj(this))};_.r=function(){return this.b.value[0]+'='+bj(this)};var ze=Dh(226);lh(13,222,{3:1,13:1,39:1,227:1},zi,Ai);_.Y=function(a,b){Sj(this.a,a,b)};_.R=function(a){return ri(this,a)};_.O=function(a){si(this,a)};_.P=function(){return new Bi(this)};_.S=function(){return this.a.length};var De=Dh(13);lh(14,1,{},Bi);_.V=Bp;_.W=function(){return this.a<this.c.a.length};_.X=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=Dh(14);lh(36,140,{3:1,36:1,207:1},Hi);var Ee=Dh(36);lh(57,1,{},Ni);_.O=Ep;_.P=function(){return new Oi(this)};_.b=0;var Ge=Dh(57);lh(58,1,{},Oi);_.V=Bp;_.X=function(){return this.d=this.a[this.c++],this.d};_.W=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=Dh(58);var Ri;lh(55,1,{},_i);_.O=Ep;_.P=function(){return new aj(this)};_.b=0;_.c=0;var Je=Dh(55);lh(56,1,{},aj);_.V=Bp;_.X=function(){return this.c=this.a,this.a=this.b.next(),new cj(this.d,this.c,this.d.c)};_.W=function(){return !this.a.done};var He=Dh(56);lh(143,226,np,cj);_.Z=function(){return this.b.value[0]};_.$=function(){return bj(this)};_._=function(a){return Zi(this.a,this.b.value[0],a)};_.c=0;var Ie=Dh(143);lh(146,1,{});_.V=Gp;_.ab=function(){return this.d};_.bb=Fp;_.d=0;_.e=0;var Ne=Dh(146);lh(60,146,{});var Ke=Dh(60);lh(136,1,{});_.V=Gp;_.ab=Dp;_.bb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var Me=Dh(136);lh(137,136,{},mj);_.V=function(a){jj(this,a)};_.cb=function(a){return kj(this,a)};var Le=Dh(137);lh(19,1,{},oj);_.ab=zp;_.bb=function(){nj(this);return this.c};_.V=function(a){nj(this);this.d.V(a)};_.cb=function(a){nj(this);if(this.d.W()){a.w(this.d.X());return true}return false};_.a=0;_.c=0;var Oe=Dh(19);lh(52,1,{},qj);_.r=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Pe=Dh(52);lh(33,1,{},rj);_.Q=function(a){return a};var Qe=Dh(33);lh(37,1,{},sj);var Re=Dh(37);lh(145,1,{});_.c=false;var _e=Dh(145);lh(23,145,{},Cj);var $e=Dh(23);lh(66,1,{},Fj);_.db=function(a){return _c(ie,cp,1,a,5,1)};var Se=Dh(66);lh(148,60,{},Hj);_.cb=function(a){this.b=false;while(!this.b&&this.c.cb(new Ij(this,a)));return this.b};_.b=false;var Ue=Dh(148);lh(151,1,{},Ij);_.w=function(a){Gj(this.a,this.b,a)};var Te=Dh(151);lh(147,60,{},Kj);_.cb=function(a){return this.b.cb(new Lj(this,a))};var We=Dh(147);lh(150,1,{},Lj);_.w=function(a){Jj(this.a,this.b,a)};var Ve=Dh(150);lh(149,1,{},Nj);_.w=function(a){Mj(this,a)};var Xe=Dh(149);lh(152,1,{},Oj);_.w=function(a){};var Ye=Dh(152);lh(153,1,{},Qj);_.w=function(a){Pj(this,a)};var Ze=Dh(153);lh(284,1,{});lh(281,1,{});var Wj=0;var Yj,Zj=0,$j;lh(898,1,{});lh(923,1,{});lh(163,1,{},lk);_.db=function(a){return new Array(a)};var af=Dh(163);lh(250,$wnd.Function,{},mk);_.fb=function(a){kk(this.a,this.b,a)};lh(6,29,{3:1,27:1,29:1,6:1},Xk);var Ak,Bk,Ck,Dk,Ek,Fk,Gk,Hk,Ik,Jk,Kk,Lk,Mk,Nk,Ok,Pk,Qk,Rk,Sk,Tk,Uk,Vk;var bf=Eh(6,Yk);var Zk;lh(248,$wnd.Function,{},_k);_.H=function(a){return Eb(Zk),Zk=null,null};lh(179,1,{});var Mf=Dh(179);lh(180,179,{});_.e=0;var Qf=Dh(180);lh(181,180,dp,hl);_.t=Hp;_.u=Ip;_.r=function(){var a;return zh(lf),lf.k+'@'+(a=Xj(this)>>>0,a.toString(16))};var dl=0;var lf=Dh(181);lh(182,1,gp,il);_.v=function(){el(this.a)};var cf=Dh(182);lh(183,1,{},jl);_.s=function(){return gl(this.a)};var df=Dh(183);lh(185,1,{},kl);_.s=function(){return bl(this.a)};var ef=Dh(185);lh(184,1,{},ll);_.v=function(){cl(this.a)};var ff=Dh(184);lh(200,1,{});var Lf=Dh(200);lh(201,200,{});_.d=0;var Pf=Dh(201);lh(202,201,dp,rl);_.t=Jp;_.u=Kp;_.r=function(){var a;return zh(kf),kf.k+'@'+(a=Xj(this)>>>0,a.toString(16))};var pl=0;var kf=Dh(202);lh(203,1,gp,sl);_.v=Lp;var gf=Dh(203);lh(204,1,{},tl);_.v=function(){ol(this.a)};var hf=Dh(204);lh(205,1,{},ul);_.s=function(){return nl(this.a)};var jf=Dh(205);lh(171,1,{});_.g='';var Zf=Dh(171);lh(172,171,{});_.e=0;var Sf=Dh(172);lh(173,172,dp,Gl);_.t=Hp;_.u=Ip;_.r=function(){var a;return zh(rf),rf.k+'@'+(a=Xj(this)>>>0,a.toString(16))};var Al=0;var rf=Dh(173);lh(174,1,gp,Hl);_.v=function(){Bl(this.a)};var mf=Dh(174);lh(176,1,{},Il);_.s=function(){return yl(this.a)};var nf=Dh(176);lh(177,1,gp,Jl);_.v=function(){vl(this.a)};var of=Dh(177);lh(175,1,{},Kl);_.v=function(){cl(this.a)};var pf=Dh(175);lh(178,1,gp,Ll);_.v=function(){El(this.a,this.b)};var qf=Dh(178);lh(167,1,{});_.j=false;var ag=Dh(167);lh(187,167,{});_.g=0;var Uf=Dh(187);lh(188,187,dp,fm);_.t=function(){jc(this.e)};_.u=function(){return this.e.i<0};_.r=function(){var a;return zh(Cf),Cf.k+'@'+(a=Xj(this)>>>0,a.toString(16))};var Vl=0;var Cf=Dh(188);lh(189,1,gp,gm);_.v=function(){Wl(this.a)};var sf=Dh(189);lh(192,1,{},hm);_.s=function(){return Tl(this.a)};var tf=Dh(192);lh(190,1,{},im);_.s=function(){return Zl(this.a)};var uf=Dh(190);lh(44,1,gp,jm);_.v=function(){em(this.a,En(this.b))};var vf=Dh(44);lh(61,1,gp,km);_.v=function(){Ql(this.a,this.b)};var wf=Dh(61);lh(193,1,gp,lm);_.v=function(){$l(this.a,this.b)};var xf=Dh(193);lh(194,1,gp,mm);_.v=function(){_l(this.a,this.b)};var yf=Dh(194);lh(191,1,{},nm);_.v=function(){Ul(this.a)};var zf=Dh(191);lh(195,1,gp,om);_.v=function(){Ml(this.a,this.b)};var Af=Dh(195);lh(196,1,gp,pm);_.v=function(){Rl(this.a)};var Bf=Dh(196);lh(156,1,{});var eg=Dh(156);lh(157,156,{});_.d=0;var Wf=Dh(157);lh(158,157,dp,wm);_.t=Jp;_.u=Kp;_.r=function(){var a;return zh(Gf),Gf.k+'@'+(a=Xj(this)>>>0,a.toString(16))};var um=0;var Gf=Dh(158);lh(159,1,gp,xm);_.v=Lp;var Df=Dh(159);lh(160,1,{},ym);_.v=function(){ol(this.a)};var Ef=Dh(160);lh(161,1,{},zm);_.s=function(){return sm(this.a)};var Ff=Dh(161);lh(254,$wnd.Function,{},Am);_.jb=function(a){uo(this.a.g)};lh(165,1,{},Bm);var Hf=Dh(165);lh(87,1,{},Cm);var If=Dh(87);var Dm;lh(186,1,{},Em);var Jf=Dh(186);lh(82,1,{},Fm);var Kf=Dh(82);var Gm;lh(255,$wnd.Function,{},Hm);_.kb=function(a){return new Km(a)};var Im;lh(169,$wnd.React.Component,{},Km);kh(ih[1],_);_.componentWillUnmount=function(){al(this.a)};_.render=function(){return fl(this.a)};_.shouldComponentUpdate=Mp;var Nf=Dh(169);lh(265,$wnd.Function,{},Lm);_.kb=function(a){return new Om(a)};var Mm;lh(197,$wnd.React.Component,{},Om);kh(ih[1],_);_.componentWillUnmount=function(){ml(this.a)};_.render=function(){return ql(this.a)};_.shouldComponentUpdate=Np;var Of=Dh(197);lh(253,$wnd.Function,{},Pm);_.kb=function(a){return new Sm(a)};var Qm;lh(168,$wnd.React.Component,{},Sm);kh(ih[1],_);_.componentWillUnmount=function(){al(this.a)};_.render=function(){return Cl(this.a)};_.shouldComponentUpdate=Mp;var Rf=Dh(168);lh(256,$wnd.Function,{},Tm);_.kb=function(a){return new Wm(a)};var Um;lh(170,$wnd.React.Component,{},Wm);kh(ih[1],_);_.componentDidUpdate=function(a){cm(this.a)};_.componentWillUnmount=function(){Sl(this.a)};_.render=function(){return Xl(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.g};var Tf=Dh(170);lh(247,$wnd.Function,{},Xm);_.kb=function(a){return new $m(a)};var Ym;lh(138,$wnd.React.Component,{},$m);kh(ih[1],_);_.componentWillUnmount=function(){ml(this.a)};_.render=function(){return vm(this.a)};_.shouldComponentUpdate=Np;var Vf=Dh(138);lh(251,$wnd.Function,{},_m);_.ib=function(a){wl(this.a,a)};lh(252,$wnd.Function,{},an);_.hb=function(a){Dl(this.a,a)};lh(164,1,{},bn);var Xf=Dh(164);lh(93,1,{},cn);var Yf=Dh(93);var dn;lh(263,$wnd.Function,{},en);_.hb=function(a){Yl(this.a,a)};lh(257,$wnd.Function,{},fn);_.hb=function(a){Zn(this.a)};lh(259,$wnd.Function,{},gn);_.jb=function(a){am(this.a,this.b)};lh(260,$wnd.Function,{},hn);_.jb=function(a){Nl(this.a,this.b)};lh(261,$wnd.Function,{},jn);_.w=function(a){Ol(this.a,a)};lh(262,$wnd.Function,{},kn);_.gb=function(a){bm(this.a,this.b)};lh(264,$wnd.Function,{},ln);_.ib=function(a){Pl(this.a,this.b,a)};lh(166,1,{},nn);var $f=Dh(166);lh(94,1,{},on);var _f=Dh(94);var pn;lh(246,$wnd.Function,{},qn);_.hb=function(a){qm(this.a,a)};lh(139,1,{},rn);_.Q=function(a){return mn(new nn,a)};var bg=Dh(139);lh(64,1,{},sn);var cg=Dh(64);lh(92,1,{},tn);var dg=Dh(92);var un;lh(63,1,{},vn);var fg=Dh(63);lh(106,1,{});var Lg=Dh(106);lh(107,106,dp,In);_.t=Hp;_.u=Ip;_.r=function(){var a;return zh(ng),ng.k+'@'+(a=Xj(this)>>>0,a.toString(16))};var ng=Dh(107);lh(108,1,gp,Jn);_.v=function(){Cn(this.a)};var gg=Dh(108);lh(110,1,{},Kn);_.v=function(){xn(this.a)};var hg=Dh(110);lh(111,1,{},Ln);_.v=function(){yn(this.a)};var ig=Dh(111);lh(112,1,gp,Mn);_.v=function(){wn(this.a,this.b)};var jg=Dh(112);lh(113,1,gp,Nn);_.v=function(){Fn(this.a)};var kg=Dh(113);lh(54,1,gp,On);_.v=function(){Bn(this.a)};var lg=Dh(54);lh(109,1,{},Pn);_.s=function(){var a;return a=(th(),$wnd.goog.global.window).location.hash,null==a?'':a.substr(1)};var mg=Dh(109);lh(45,1,{45:1});_.d=false;var Tg=Dh(45);lh(46,45,{9:1,249:1,46:1,45:1},$n);_.t=Hp;_.o=function(a){return Tn(this,a)};_.q=function(){return this.c.d};_.u=Ip;_.r=function(){var a;return zh(Dg),Dg.k+'@'+(a=this.c.d>>>0,a.toString(16))};var Qn=0;var Dg=Dh(46);lh(198,1,gp,_n);_.v=function(){Rn(this.a)};var og=Dh(198);lh(199,1,gp,ao);_.v=function(){Wn(this.a)};var pg=Dh(199);lh(96,95,{});var Og=Dh(96);lh(97,96,dp,jo);_.t=Op;_.u=Pp;_.r=function(){var a;return zh(yg),yg.k+'@'+(a=Xj(this)>>>0,a.toString(16))};var yg=Dh(97);lh(99,1,gp,ko);_.v=function(){co(this.a)};var qg=Dh(99);lh(98,1,gp,lo);_.v=function(){go(this.a)};var rg=Dh(98);lh(104,1,gp,mo);_.v=function(){bc(this.a,this.b,true)};var sg=Dh(104);lh(105,1,{},no);_.s=function(){return bo(this.a,this.c,this.b)};_.b=false;var tg=Dh(105);lh(100,1,{},oo);_.s=function(){return ho(this.a)};var ug=Dh(100);lh(101,1,{},po);_.s=function(){return Oh(bh(xj(cc(this.a))))};var vg=Dh(101);lh(102,1,{},qo);_.s=function(){return Oh(bh(xj(yj(cc(this.a),new Wo))))};var wg=Dh(102);lh(103,1,{},ro);_.s=function(){return io(this.a)};var xg=Dh(103);lh(114,1,{});var Sg=Dh(114);lh(115,114,dp,yo);_.t=function(){jc(this.a)};_.u=function(){return this.a.i<0};_.r=function(){var a;return zh(Cg),Cg.k+'@'+(a=Xj(this)>>>0,a.toString(16))};var Cg=Dh(115);lh(116,1,gp,zo);_.v=function(){vo(this.a,this.b)};_.b=false;var zg=Dh(116);lh(117,1,gp,Ao);_.v=function(){Hn(this.b,this.a)};var Ag=Dh(117);lh(118,1,gp,Bo);_.v=function(){wo(this.a)};var Bg=Dh(118);lh(119,1,{});var Vg=Dh(119);lh(120,119,dp,Jo);_.t=Op;_.u=Pp;_.r=function(){var a;return zh(Jg),Jg.k+'@'+(a=Xj(this)>>>0,a.toString(16))};var Jg=Dh(120);lh(121,1,gp,Ko);_.v=function(){Eo(this.a)};var Eg=Dh(121);lh(125,1,gp,Lo);_.v=function(){Io(this.a,null)};var Fg=Dh(125);lh(122,1,{},Mo);_.s=function(){var a;return a=En(this.a.g),o(xp,a)?(To(),Qo):o(yp,a)?(To(),So):(To(),Ro)};var Gg=Dh(122);lh(123,1,{},No);_.s=function(){return Go(this.a)};var Hg=Dh(123);lh(124,1,{},Oo);_.v=function(){Ho(this.a)};var Ig=Dh(124);lh(86,1,{},Po);_.handleEvent=function(a){zn(this.a,a)};var Kg=Dh(86);lh(30,29,{3:1,27:1,29:1,30:1},Uo);var Qo,Ro,So;var Mg=Eh(30,Vo);lh(83,1,{},Wo);_.eb=function(a){return !Vn(a)};var Ng=Dh(83);lh(89,1,{},Xo);_.eb=function(a){return Vn(a)};var Pg=Dh(89);lh(90,1,{},Yo);_.w=function(a){fo(this.a,a)};var Qg=Dh(90);lh(88,1,{},Zo);_.w=function(a){to(this.a,a)};_.a=false;var Rg=Dh(88);lh(91,1,{},$o);_.eb=function(a){return Do(this.a,a)};var Ug=Dh(91);var sd=Fh('D');var _o=(Ec(),Hc);var gwtOnLoad=gwtOnLoad=gh;eh(rh);hh('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();