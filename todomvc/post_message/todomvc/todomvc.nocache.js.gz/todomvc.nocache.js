function todomvc(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='todomvc',tb='__gwt_marker_todomvc',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='B8C15153044C6FA7D18A093EF2C95ADF',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};todomvc.onScriptLoad=function(a){todomvc=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
todomvc();(function () {var $gwt_version = "2.8.2";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'B8C15153044C6FA7D18A093EF2C95ADF';function o(){}
function Yg(){}
function Ug(){}
function Bb(){}
function Qc(){}
function Xc(){}
function Xl(){}
function Kl(){}
function Pl(){}
function Rl(){}
function Tl(){}
function Vl(){}
function jj(){}
function kj(){}
function Oj(){}
function Ek(){}
function mm(){}
function Bn(){}
function Cn(){}
function ro(){}
function Vc(a){Uc()}
function dh(){dh=Ug}
function gi(){Zh(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function fb(a){this.a=a}
function sb(a){this.a=a}
function tb(a){this.a=a}
function ub(a){this.a=a}
function uh(a){this.a=a}
function Fh(a){this.a=a}
function Rh(a){this.a=a}
function Wh(a){this.a=a}
function Xh(a){this.a=a}
function cc(a){this.a=a}
function ec(a){this.a=a}
function fc(a){this.a=a}
function gc(a){this.a=a}
function kc(a){this.a=a}
function hj(a){this.a=a}
function mj(a){this.a=a}
function Fk(a){this.a=a}
function Gk(a){this.a=a}
function Hk(a){this.a=a}
function Mk(a){this.a=a}
function Nk(a){this.a=a}
function Ok(a){this.a=a}
function Zk(a){this.a=a}
function $k(a){this.a=a}
function al(a){this.a=a}
function bl(a){this.a=a}
function ul(a){this.a=a}
function vl(a){this.a=a}
function wl(a){this.a=a}
function Bl(a){this.a=a}
function Cl(a){this.a=a}
function Hl(a){this.a=a}
function Il(a){this.a=a}
function Jl(a){this.a=a}
function Zl(a){this.a=a}
function $l(a){this.a=a}
function bm(a){this.a=a}
function cm(a){this.a=a}
function em(a){this.a=a}
function fm(a){this.a=a}
function Fm(a){this.a=a}
function Gm(a){this.a=a}
function Pm(a){this.a=a}
function Rm(a){this.a=a}
function Tm(a){this.a=a}
function Um(a){this.a=a}
function Vm(a){this.a=a}
function Vh(a){this.b=a}
function ii(a){this.c=a}
function dn(a){this.a=a}
function en(a){this.a=a}
function qn(a){this.a=a}
function rn(a){this.a=a}
function sn(a){this.a=a}
function tn(a){this.a=a}
function un(a){this.a=a}
function Dn(a){this.a=a}
function En(a){this.a=a}
function Fn(a){this.a=a}
function Ml(){this.a={}}
function Ol(){this.a={}}
function am(){this.a={}}
function lm(){this.a={}}
function om(){this.a={}}
function wo(){Jj(this.a)}
function Bo(){Lj(this.a)}
function si(){this.a=Bi()}
function Gi(){this.a=Bi()}
function no(a){Ki(this,a)}
function qo(a){yh(this,a)}
function $(a){Kb((J(),a))}
function ab(a){Lb((J(),a))}
function db(a){Mb((J(),a))}
function w(a){--a.e;D(a)}
function C(a,b){yb(a.b,b)}
function oc(a,b){Nh(a.b,b)}
function lj(a,b){bj(a.a,b)}
function Wm(a,b){Im(a.c,b)}
function Xm(a,b){Bm(b,a)}
function ij(a,b){a.a=b}
function Cj(a,b,c){a[b]=c}
function mb(a,b){a.b=Ni(b)}
function Fg(a){return a.e}
function zo(){return this.e}
function ko(){return this.a}
function po(){return this.b}
function to(){return this.c}
function Do(){return this.f}
function uo(){return this.d<0}
function Ao(){return this.c<0}
function Co(){return this.f<0}
function mo(){return uj(this)}
function Bh(a,b){return a===b}
function fl(a,b){return a.g=b}
function ai(a,b){return a.a[b]}
function qj(a,b){a.splice(b,1)}
function mc(a,b,c){Mh(a.b,b,c)}
function Kk(a){nc(a.b);gb(a.a)}
function Gh(a){uc.call(this,a)}
function Ql(a){Gj.call(this,a)}
function Sl(a){Gj.call(this,a)}
function Ul(a){Gj.call(this,a)}
function Wl(a){Gj.call(this,a)}
function Yl(a){Gj.call(this,a)}
function il(a){Jm((tm(),qm),a)}
function X(a){J();Lb(a);a.e=-2}
function J(){J=Ug;I=new F}
function wc(){wc=Ug;vc=new o}
function Nc(){Nc=Ug;Mc=new Qc}
function pc(){this.b=new mi}
function F(){this.b=new zb}
function xi(){xi=Ug;wi=zi()}
function Dc(){Dc=Ug;!!(Uc(),Tc)}
function vo(){return J(),J(),I}
function oo(){return Ph(this.a)}
function xo(){return Nj(this.a)}
function lo(a){return this===a}
function Yc(a,b){return mh(a,b)}
function bj(a,b){ij(a,aj(a.a,b))}
function Oi(a,b){while(a.cb(b));}
function aj(a,b){a.R(b);return a}
function Qj(a,b){a.ref=b;return a}
function gh(a){fh(a);return a.k}
function Vb(a){bb(a.a);return a.e}
function Wb(a){bb(a.b);return a.g}
function xm(a){bb(a.b);return a.i}
function ym(a){bb(a.a);return a.g}
function jn(a){bb(a.d);return a.f}
function Bi(){xi();return new wi}
function bd(a){return new Array(a)}
function Ph(a){return a.a.b+a.b.b}
function Di(a,b){return a.a.get(b)}
function Eb(a){Fb(a);!a.d&&Ib(a)}
function Yb(a){Ub(a,(bb(a.b),a.g))}
function zh(){qc(this);this.G()}
function rh(a,b){this.a=a;this.b=b}
function Yh(a,b){this.a=a;this.b=b}
function dc(a,b){this.a=a;this.b=b}
function lc(a,b){this.a=a;this.b=b}
function ej(a,b){this.a=a;this.b=b}
function _k(a,b){this.a=a;this.b=b}
function yl(a,b){this.a=a;this.b=b}
function zl(a,b){this.a=a;this.b=b}
function Al(a,b){this.a=a;this.b=b}
function dm(a,b){this.a=a;this.b=b}
function gm(a,b){this.a=a;this.b=b}
function hm(a,b){this.a=a;this.b=b}
function Qm(a,b){this.a=a;this.b=b}
function fn(a,b){this.a=a;this.b=b}
function cn(a,b){this.b=a;this.a=b}
function zn(a,b){rh.call(this,a,b)}
function yk(a,b){rh.call(this,a,b)}
function oj(a,b,c){a.splice(b,0,c)}
function fj(a,b){a.B(km(im(b.e),b))}
function Rj(a,b){a.href=b;return a}
function _j(a,b){a.value=b;return a}
function Dh(a,b){a.a+=''+b;return a}
function im(a){return jm(new lm,a)}
function Lh(a){return !a?null:a.$()}
function Gb(a){return !a.d?a:Gb(a.d)}
function Mi(a){return a!=null?r(a):0}
function qd(a){return a==null?null:a}
function nd(a){return typeof a===In}
function Ng(){Lg==null&&(Lg=[])}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function L(a){a.b=0;a.d=0;a.c=false}
function Oh(a){a.a=new si;a.b=new Gi}
function Zh(a){a.a=$c(je,Ln,1,0,5,1)}
function Kc(a){$wnd.clearTimeout(a)}
function Ck(a){nc(a.c);gb(a.b);S(a.a)}
function Wk(a){nc(a.c);gb(a.a);W(a.b)}
function Am(a){Bm(a,(bb(a.a),!a.g))}
function jc(a,b){hc(a,b,false);ab(a.d)}
function pj(a,b){nj(b,0,a,0,b.length)}
function Wj(a,b){a.onBlur=b;return a}
function Sj(a,b){a.onClick=b;return a}
function Xj(a,b){a.onChange=b;return a}
function Uj(a,b){a.checked=b;return a}
function eb(a){this.c=new gi;this.b=a}
function yj(){yj=Ug;vj=new o;xj=new o}
function A(a,b,c){t(a,new G(b),c,null)}
function dd(a,b,c){return {l:a,m:b,h:c}}
function Ah(a,b){return a.charCodeAt(b)}
function ld(a,b){return a!=null&&jd(a,b)}
function V(a){return !(!!a&&1==(a.c&7))}
function uj(a){return a.$H||(a.$H=++tj)}
function pd(a){return typeof a==='string'}
function so(){return T((tm(),qm).b).a>0}
function el(a,b){on((tm(),sm),b);rl(a,b)}
function _i(a,b){Wi.call(this,a);this.a=b}
function uc(a){this.f=a;qc(this);this.G()}
function bn(a){this.c=Ni(a);this.a=new pc}
function mi(){this.a=new si;this.b=new Gi}
function Q(){this.a=$c(je,Ln,1,100,5,1)}
function bb(a){var b;Hb((J(),b=Cb,b),a)}
function lb(a){J();kb(a);nb(a,2,true)}
function Yj(a,b){a.onKeyDown=b;return a}
function Vj(a,b){a.defaultValue=b;return a}
function Tj(a){a.autoFocus=true;return a}
function ak(a,b){a.onDoubleClick=b;return a}
function rc(a,b){a.e=b;b!=null&&sj(b,Wn,a)}
function fh(a){if(a.k!=null){return}oh(a)}
function zm(a){nc(a.c);W(a.d);W(a.b);W(a.a)}
function Nm(a){return vh(T(a.e).a-T(a.a).a)}
function md(a){return typeof a==='boolean'}
function u(a,b){return new qb(Ni(a),null,b)}
function ui(a,b){var c;c=a[_n];c.call(a,b)}
function sj(b,c,d){try{b[c]=d}catch(a){}}
function Ec(a,b,c){return a.apply(b,c);var d}
function ic(a,b){oc(b.C(),a);ld(b,11)&&b.v()}
function Ki(a,b){while(a.W()){lj(b,a.X())}}
function Ji(a,b,c){this.a=a;this.b=b;this.c=c}
function $h(a,b){a.a[a.a.length]=b;return true}
function qc(a){a.g&&a.e!==Vn&&a.G();return a}
function lh(){var a;a=ih(null);a.e=2;return a}
function jh(a){var b;b=ih(a);qh(a,b);return b}
function jm(a,b){Ni(b);Cj(a.a,'key',b);return a}
function jb(a,b){Z(b,a);b.c.a.length>0||(b.a=4)}
function Rb(a,b){a.i&&b.preventDefault();ac(a)}
function Vk(a,b){var c;c=b.target;Xk(a,c.value)}
function Sm(a,b){this.a=a;this.c=b;this.b=false}
function Pi(a,b){this.e=a;this.d=(b&64)!=0?b|Jn:b}
function Qi(a){if(!a.d){a.d=a.b.Q();a.c=a.b.S()}}
function Ab(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function cj(a,b,c){if(a.a.db(c)){a.b=true;b.B(c)}}
function Th(a){var b;b=a.a.X();a.b=Sh(a);return b}
function ci(a,b){var c;c=a.a[b];qj(a.a,b);return c}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ci(a,b){return !(a.a.get(b)===undefined)}
function P(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function ad(a){return Array.isArray(a)&&a.wb===Yg}
function kd(a){return !Array.isArray(a)&&a.wb===Yg}
function Mm(a){return dh(),0==T(a.e).a?true:false}
function gn(a){return Bh(jo,a)||Bh(go,a)||Bh('',a)}
function Zi(a){Vi(a);return new _i(a,new gj(a.a))}
function Qh(a,b){if(b){return Jh(a.a,b)}return false}
function Ni(a){if(a==null){throw Fg(new zh)}return a}
function Bj(){if(wj==256){vj=xj;xj=new o;wj=0}++wj}
function Uc(){Uc=Ug;var a;!Wc();a=new Xc;Tc=a}
function _g(){_g=Ug;$g=$wnd.window.document}
function xh(){xh=Ug;wh=$c(fe,Ln,33,256,0,1)}
function nl(a){nc(a.e);gb(a.b);S(a.d);W(a.c);W(a.a)}
function Ui(a){if(!a.b){Vi(a);a.c=true}else{Ui(a.b)}}
function Xk(a,b){var c;c=a.e;if(b!=c){a.e=b;ab(a.b)}}
function sl(a,b){var c;c=a.i;if(b!=c){a.i=b;ab(a.a)}}
function Bm(a,b){var c;c=a.g;if(b!=c){a.g=b;ab(a.a)}}
function ei(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function $j(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function li(a,b){return qd(a)===qd(b)||a!=null&&p(a,b)}
function Mj(a){Kj(a);return ld(a,11)&&a.w()?null:a.mb()}
function Yi(a,b){Vi(a);return new _i(a,new dj(b,a.a))}
function ol(a,b,c,d){return dh(),ll(a,b,c,d)?true:false}
function Dj(a,b){null!=b&&a.hb(b,a.o.props,true);a.eb()}
function gj(a){Pi.call(this,a.bb(),a.ab()&-6);this.a=a}
function Wi(a){if(!a){this.b=null;new gi}else{this.b=a}}
function xl(a,b,c,d){this.a=a;this.d=b;this.c=c;this.b=d}
function Nb(a,b){this.a=(J(),J(),I).a++;this.d=a;this.e=b}
function Ri(a,b){this.b=a;this.a=(b&4096)==0?b|64|Jn:b}
function _b(a,b){var c;c=a.g;if(b!=c){a.g=Ni(b);ab(a.b)}}
function $b(a,b){var c;c=a.e;if(b!=c){a.e=Ni(b);ab(a.a)}}
function Cm(a,b){var c;c=a.i;if(b!=c){a.i=Ni(b);ab(a.b)}}
function kh(a,b){var c;c=ih(a);qh(a,c);c.e=b?8:0;return c}
function sc(a,b){var c;c=gh(a.ub);return b==null?c:c+': '+b}
function Kh(a,b){return b===a?'(this Map)':b==null?Yn:Xg(b)}
function An(){yn();return cd(Yc(tg,1),Ln,37,0,[vn,xn,wn])}
function Kg(a){if(nd(a)){return a|0}return a.l|a.m<<22}
function nh(a){if(a.O()){return null}var b=a.j;return Qg[b]}
function Jj(a){if(!a.k){a.k=true;a.n||a.o.forceUpdate()}}
function Db(a){if(a.e){2==(a.e.c&7)||nb(a.e,4,true);kb(a.e)}}
function kn(a){nc(a.g);gb(a.e);gb(a.a);S(a.b);S(a.c);W(a.d)}
function xb(a){while(true){if(!vb(a)&&!wb(a)){break}}}
function cb(a){var b;J();!!Cb&&!!Cb.e&&Hb((b=Cb,b),a)}
function dl(a,b){var c;if(T(a.d)){c=b.target;sl(a,c.value)}}
function yh(a,b){var c,d;for(d=a.Q();d.W();){c=d.X();b.B(c)}}
function th(a){this.f=!a?null:sc(a,a.F());qc(this);this.G()}
function gl(a,b,c){27==c.which?ql(a,b):13==c.which&&hl(a,b)}
function $m(a,b){var c;$i(Km(a.c),(c=new gi,c)).P(new En(b))}
function yb(a,b){b.c|=512;K(a.d[((b.c&229376)>>15)-1],Ni(b))}
function mh(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.J(b))}
function Qk(a,b){if(13==b.keyCode){b.preventDefault();Tk(a)}}
function Ob(a,b){Cb=new Nb(Cb,b);a.d=false;Db(Cb);return Cb}
function Wg(a){function b(){}
;b.prototype=a||{};return new b}
function Vi(a){if(a.b){Vi(a.b)}else if(a.c){throw Fg(new sh)}}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function oi(a,b){var c;c=a.a.get(b);return c==null?new Array:c}
function hb(a){var b;b=(J(),J(),I);yb(b.b,a);0!=(a.c&Rn)&&D(b)}
function Qb(a,b){a.j=b;Bh(b,(bb(a.a),a.e))&&_b(a,b);Sb(b);ac(a)}
function B(a,b,c){return t(a,c,2048|(0!=(b.c&Jn)?Jn:8192)|0,b)}
function v(a,b,c){s(a,new H(c),2048|(0!=(b.c&Jn)?Jn:8192)|0,b)}
function ah(a,b,c,d){a.addEventListener(b,c,(dh(),d?true:false))}
function pi(a,b){var c;return ni(b,oi(a,b==null?0:(c=r(b),c|0)))}
function Km(a){bb(a.d);return new _i(null,new Ri(new Wh(a.i),0))}
function hi(a){Zh(this);pj(this.a,Ih(a,$c(je,Ln,1,Ph(a.a),5,1)))}
function ti(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Zj(a){a.placeholder='What needs to be done?';return a}
function tc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Sg(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Sk(){Sk=Ug;var a;Rk=(a=Vg(Tl.prototype.ib,Tl,[]),a)}
function Bk(){Bk=Ug;var a;Ak=(a=Vg(Pl.prototype.ib,Pl,[]),a)}
function Jk(){Jk=Ug;var a;Ik=(a=Vg(Rl.prototype.ib,Rl,[]),a)}
function kl(){kl=Ug;var a;jl=(a=Vg(Vl.prototype.ib,Vl,[]),a)}
function El(){El=Ug;var a;Dl=(a=Vg(Xl.prototype.ib,Xl,[]),a)}
function mn(a){var b;b=(bb(a.d),a.f);!!b&&!!b&&b.f<0&&on(a,null)}
function on(a,b){var c;c=a.f;if(!(b==c||!!b&&wm(b,c))){a.f=b;ab(a.d)}}
function Y(a,b){var c,d;$h(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function bh(a,b,c,d){a.removeEventListener(b,c,(dh(),d?true:false))}
function Nh(a,b){return pd(b)?b==null?ri(a.a,null):Fi(a.b,b):ri(a.a,b)}
function Si(a,b){!a.a?(a.a=new Fh(a.d)):Dh(a.a,a.b);Dh(a.a,b);return a}
function $i(a,b){var c;Ui(a);c=new jj;c.a=b;a.a.V(new mj(c));return c.a}
function Xi(a){var b;Ui(a);b=0;while(a.a.cb(new kj)){b=Gg(b,1)}return b}
function N(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function dj(a,b){Pi.call(this,b.bb(),b.ab()&-16449);this.a=a;this.c=b}
function Hi(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function yo(){return jn((tm(),sm))==(cb(this.c),this.o.props['a'])}
function rd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ll(a){return $wnd.React.createElement((Bk(),Ak),a.a,undefined)}
function Nl(a){return $wnd.React.createElement((Jk(),Ik),a.a,undefined)}
function _l(a){return $wnd.React.createElement((Sk(),Rk),a.a,undefined)}
function nm(a){return $wnd.React.createElement((El(),Dl),a.a,undefined)}
function hn(a,b){return (yn(),wn)==a||(vn==a?(bb(b.a),!b.g):(bb(b.a),b.g))}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Zm(a){var b;$i(Yi(Km(a.c),new Cn),(b=new gi,b)).P(new Dn(a.c))}
function tm(){tm=Ug;pm=new bc;qm=new Om;rm=new bn(qm);sm=new pn(qm,pm)}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function Nj(a){var b;a.k=false;if(a.kb()){return null}else{b=a.gb();return b}}
function Ii(a){if(a.a.c!=a.c){return Di(a.a,a.b.value[0])}return a.b.value[1]}
function vm(a){if(a.f>=0){a.f=-2;t((J(),J(),I),new G(new Fm(a)),Qn,null)}}
function ln(a){var b,c;return b=T(a.b),$i(Yi(Km(a.k),new Fn(b)),(c=new gi,c))}
function _h(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.B(c)}}
function di(a,b){var c;c=bi(a,b,0);if(c==-1){return false}qj(a.a,c);return true}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&cd(Yc(a,f),b,c,e,g);return g}
function bi(a,b,c){for(;c<a.a.length;++c){if(li(b,a.a[c])){return c}}return -1}
function Ti(a,b){this.b=', ';this.d=a;this.e=b;this.c=this.d+(''+this.e)}
function Uh(a){this.d=a;this.c=new Hi(this.d.b);this.a=this.c;this.b=Sh(this)}
function Xb(a){bh((_g(),$wnd.window.window),Tn,a.f,false);nc(a.c);W(a.b);W(a.a)}
function S(a){if(!a.a){a.a=true;a.g=null;a.b=null;W(a.d);2==(a.e.c&7)||gb(a.e)}}
function W(a){if(-2!=a.e){t((J(),J(),I),new G(new fb(a)),0,null);!!a.b&&gb(a.b)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{xb(a.b)}finally{a.c=false}}}}
function Oc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Sc(b,c)}while(a.a);a.a=c}}
function Pc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Sc(b,c)}while(a.b);a.b=c}}
function Mh(a,b,c){return pd(b)?b==null?qi(a.a,null,c):Ei(a.b,b,c):qi(a.a,b,c)}
function rj(a,b){return Zc(b)!=10&&cd(q(b),b.vb,b.__elementTypeId$,Zc(b),a),a}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===Hn||typeof a==='function')&&!(a.wb===Yg)}
function pl(a){return dh(),jn((tm(),sm))==(cb(a.c),a.o.props['a'])?true:false}
function Ej(a,b){var c;c=null!=b&&a.hb(a.o.props,b,false);c||(a.p=false);return c}
function Vg(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function qh(a,b){var c;if(!a){return}b.j=a;var d=nh(b);if(!d){Qg[a]=[b];return}d.ub=b}
function Eg(a){var b;if(ld(a,4)){return a}b=a&&a[Wn];if(!b){b=new yc(a);Vc(b)}return b}
function vb(a){var b;if(0==P(a.c)){return false}else{b=O(a.c);!!b&&b.v();return true}}
function Pk(a){var b;b=Ch((bb(a.b),a.e));if(b.length>0){Wm((tm(),rm),b);Xk(a,'')}}
function Lj(a){var b;b=(++a.lb().e,new Bb);try{a.n=true;ld(a,11)&&a.v()}finally{Ab(b)}}
function Hb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;$h((!a.b&&(a.b=new gi),a.b),b)}}}
function Jb(a,b){var c;if(!a.c){c=Gb(a);!c.c&&(c.c=new gi);a.c=c.c}b.d=true;$h(a.c,Ni(b))}
function K(a,b){var c;c=(a.c?a.a.length-a.b+a.d:a.d-a.b)+1;c>a.a.length&&M(a,c);N(a,Ni(b))}
function Fi(a,b){var c;c=a.a.get(b);if(c===undefined){++a.c}else{ui(a.a,b);--a.b}return c}
function Fj(a,b){var c;if(b){c=a.p;a.p=false;if(c){return false}}else{a.p=true}return true}
function ih(a){var b;b=new hh;b.k='Class$'+(a?'S'+a:''+b.g);b.b=b.k;b.i=b.k;return b}
function ji(a){var b,c,d;d=0;for(c=new Uh(a.a);c.b;){b=Th(c);d=d+(b?r(b):0);d=d|0}return d}
function kb(a){var b,c;for(c=new ii(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Mg(){Ng();var a=Lg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function sh(){uc.call(this,"Stream already terminated, can't be modified or used")}
function km(a,b){Cj(a.a,(kl(),'a'),b);return $wnd.React.createElement(jl,a.a,undefined)}
function Lm(a){yh(new Wh(a.i),new kc(a));Oh(a.i);nc(a.f);S(a.c);S(a.e);S(a.a);S(a.b);W(a.d)}
function Hm(a,b,c){var d;d=new Em(b,c);mc(d.c,a,new lc(a,d));Mh(a.i,vh(d.e),d);ab(a.d);return d}
function Hh(a,b){var c,d;for(d=new Uh(b.a);d.b;){c=Th(d);if(!Qh(a,c)){return false}}return true}
function hc(a,b,c){var d;d=Nh(a.i,b?vh(b.e):null);if(null!=d){oc(b.c,a);c&&!!b&&vm(b);ab(a.d)}}
function Pb(){var a;try{Eb(Cb);J()}finally{a=Cb.d;!a&&((J(),J(),I).d=true);Cb=Cb.d}}
function yn(){yn=Ug;vn=new zn('ACTIVE',0);xn=new zn('COMPLETED',1);wn=new zn('ALL',2)}
function Pg(a,b){typeof window===Hn&&typeof window['$gwt']===Hn&&(window['$gwt'][a]=b)}
function Zg(){tm();$wnd.ReactDOM.render(nm(new om),(_g(),$g).getElementById('todoapp'),null)}
function Lk(){Jk();++Hj;this.b=new pc;this.a=new qb(null,Ni((J(),new Mk(this))),co);D((null,I))}
function Gl(){El();++Hj;this.b=new pc;this.a=new qb(null,Ni((J(),new Hl(this))),co);D((null,I))}
function Gj(a){$wnd.React.Component.call(this,a);this.a=this.jb();this.a.o=Ni(this);this.a.fb()}
function Sh(a){if(a.a.W()){return true}if(a.a!=a.c){return false}a.a=new ti(a.d.a);return a.a.W()}
function Hg(a){var b;b=a.h;if(b==0){return a.l+a.m*Rn}if(b==1048575){return a.l+a.m*Rn-Zn}return a}
function Jg(a){var b,c,d,e;e=a;d=0;if(e<0){e+=Zn;d=1048575}c=rd(e/Rn);b=rd(e-c*Rn);return dd(b,c,d)}
function ni(a,b){var c,d,e;for(d=0,e=b.length;d<e;++d){c=b[d];if(li(a,c.Z())){return c}}return null}
function ll(a,b,c,d){var e,f;e=false;f=Fj(a,d);if(!(b['a']===c['a'])){f&&ab(a.c);e=true}return e||a.k}
function cd(a,b,c,d,e){e.ub=a;e.vb=b;e.wb=Yg;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Ei(a,b,c){var d;d=a.a.get(b);a.a.set(b,c===undefined?null:c);d===undefined?++a.b:++a.c;return d}
function Z(a,b){var c,d;d=a.c;di(d,b);d.a.length==0&&!!a.b&&Nn!=(a.b.c&On)&&(a.d||Jb((J(),c=Cb,c),a))}
function nn(a){var b;b=Vb(a.j);Bh(jo,b)||Bh(go,b)||Bh('',b)?Ub(a.j,b):gn(Wb(a.j))?Zb(a.j):Ub(a.j,'')}
function gb(a){if(2<(a.c&7)){t((J(),J(),I),new G(new tb(a)),Qn,null);!!a.a&&S(a.a);a.c=a.c&-8|1}}
function Kj(a){if(!Ij){Ij=(++a.lb().e,new Bb);$wnd.Promise.resolve(null).then(Vg(Oj.prototype.I,Oj,[]))}}
function T(a){bb(a.d);ob(a.e)&&ib(a.e);if(a.b){if(ld(a.b,6)){throw Fg(a.b)}else{throw Fg(a.b)}}return a.g}
function wm(a,b){var c;if(a===b){return true}else if(null==b||!ld(b,50)){return false}else{c=b;return a.e==c.e}}
function vh(a){var b,c;if(a>-129&&a<128){b=a+128;c=(xh(),wh)[b];!c&&(c=wh[b]=new uh(a));return c}return new uh(a)}
function Xg(a){var b;if(Array.isArray(a)&&a.wb===Yg){return gh(q(a))+'@'+(b=r(a)>>>0,b.toString(16))}return a.toString()}
function Aj(a){yj();var b,c,d;c=':'+a;d=xj[c];if(d!=null){return rd(d)}d=vj[c];b=d==null?zj(a):rd(d);Bj();xj[c]=b;return b}
function yc(a){wc();qc(this);this.e=a;a!=null&&sj(a,Wn,this);this.f=a==null?Yn:Xg(a);this.a='';this.b=a;this.a=''}
function hh(){this.g=eh++;this.k=null;this.i=null;this.f=null;this.d=null;this.b=null;this.j=null;this.a=null}
function U(a,b){this.c=Ni(a);this.f=null;this.g=null;this.e=new rb(this,b);this.d=new eb(this.e);Nn==(b&On)&&hb(this.e)}
function pb(a,b,c,d){this.b=new gi;this.c=d|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=1024);!this.a&&!!this.d&&hb(this)}
function Dk(){Bk();++Hj;this.c=new pc;this.a=new U((J(),new Ek),136486912);this.b=new qb(null,Ni(new Gk(this)),co);D((null,I))}
function zk(){xk();return cd(Yc(af,1),Ln,9,0,[bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk])}
function q(a){return pd(a)?me:nd(a)?be:md(a)?_d:kd(a)?a.ub:ad(a)?a.ub:a.ub||Array.isArray(a)&&Yc(Ud,1)||Ud}
function r(a){return pd(a)?Aj(a):nd(a)?rd(a):md(a)?a?1231:1237:kd(a)?a.s():ad(a)?uj(a):!!a&&!!a.hashCode?a.hashCode():uj(a)}
function p(a,b){return pd(a)?Bh(a,b):nd(a)?a===b:md(a)?a===b:kd(a)?a.q(b):ad(a)?a===b:!!a&&!!a.equals?a.equals(b):qd(a)===qd(b)}
function hl(a,b){var c;c=(bb(a.a),a.i);if(null!=c&&c.length!=0){_m((tm(),b),c);on(sm,null);sl(a,c)}else{Jm((tm(),qm),b)}}
function Tb(a){var b,c;c=(b=(_g(),$wnd.window.window).location.hash,null==b?'':b.substr(1));$b(a,c);Bh(a.j,c)&&_b(a,c)}
function ed(a,b){var c,d,e;c=a.l+b.l;d=a.m+b.m+(c>>22);e=a.h+b.h+(d>>22);return dd(c&4194303,d&4194303,e&1048575)}
function Gg(a,b){var c;if(nd(a)&&nd(b)){c=a+b;if(-17592186044416<c&&c<Zn){return c}}return Hg(ed(nd(a)?Jg(a):a,nd(b)?Jg(b):b))}
function nc(a){var b,c;if(!a.a){for(c=new ii(new hi(new Wh(a.b)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.A()}a.a=true}}
function ki(a){var b,c,d;d=1;for(c=new ii(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?r(b):0);d=d|0}return d}
function fi(a,b){var c,d;d=a.a.length;b.length<d&&(b=rj(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function ph(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Yk(){Sk();var a;++Hj;this.c=new pc;this.b=(a=new eb((J(),null)),a);this.a=new qb(null,Ni(new al(this)),co);D((null,I))}
function zb(){this.c=new Q;this.d=$c(vd,Ln,22,5,0,1);this.d[0]=new Q;this.d[1]=new Q;this.d[2]=new Q;this.d[3]=new Q;this.d[4]=new Q}
function cl(a){var b;b=T(a.d);if(!a.j&&b){a.j=true;rl(a,(cb(a.c),a.o.props['a']));a.g.focus();a.g.select()}else a.j&&!b&&(a.j=false)}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Pj(a,b){var c,d,e,f;c=null;for(e=0,f=b.length;e<f;++e){d=b[e];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function jd(a,b){if(pd(a)){return !!hd[b]}else if(a.vb){return !!a.vb[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function O(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function qb(a,b,c){pb.call(this,null,a,b,c|(!a?262144:Nn)|(a?Jn:0!=(c&24576)?0:8192)|(0!=(c&6291456)?0:!a?2097152:Rn)|(0!=(c&229376)?0:98304)|0|0|0)}
function Mb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new ii(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&nb(b,5,true)}}}
function Lb(a){var b,c,d,e;if(a.c.a.length>0&&6!=a.a){a.a=6;d=a.c;for(c=new ii(d);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);e=b.c&7;6!=e&&nb(b,6,true)}}}
function Kb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new ii(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?nb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Ch(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function Ib(a){var b,c;b=0;if(a.c){while(a.c.a.length!=0){c=ci(a.c,a.c.a.length-1);c.d=false;if(c.c.a.length<=0){(c.b.c&7)>3&&nb(c.b,3,true);++b}}}return b}
function Em(a,b){var c,d,e;this.i=Ni(a);this.g=b;this.e=um++;this.d=(d=new eb((J(),null)),d);this.c=new pc;this.b=(e=new eb(null),e);this.a=(c=new eb(null),c)}
function Zb(b){var c;try{A((J(),J(),I),new ec(b),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function ac(b){var c;try{A((J(),J(),I),new fc(b),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function Tk(b){var c;try{A((J(),J(),I),new $k(b),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function Dm(b){var c;try{A((J(),J(),I),new Gm(b),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function Ym(b){var c;try{A((J(),J(),I),new dn(b),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){c=a;throw Fg(c)}else if(ld(a,4)){c=a;throw Fg(new th(c))}else throw Fg(a)}}
function _m(b,c){var d;try{A((J(),J(),I),new cn(b,c),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Jm(b,c){var d;try{A((J(),J(),I),new Qm(b,c),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Uk(b,c){var d;try{A((J(),J(),I),new _k(b,c),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function ml(b,c){var d;try{A((J(),J(),I),new Al(b,c),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function ql(b,c){var d;try{A((J(),J(),I),new zl(b,c),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function rl(b,c){var d;try{A((J(),J(),I),new yl(b,c),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function an(b,c){var d;try{A((J(),J(),I),new fn(b,c),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Ub(b,c){var d;try{A((J(),J(),I),new dc(b,c),75505664)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Im(b,c){var d;try{return t((J(),J(),I),new Sm(b,c),Un,null)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){d=a;throw Fg(d)}else if(ld(a,4)){d=a;throw Fg(new th(d))}else throw Fg(a)}}
function Og(b,c,d,e){Ng();var f=Lg;$moduleName=c;$moduleBase=d;Dg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Gn(g)()}catch(a){b(c,a)}}else{Gn(g)()}}
function rb(a,b){pb.call(this,a,new sb(a),null,b|(Nn==(b&On)?0:524288)|(0!=(b&6291456)?0:Nn==(b&On)?Rn:2097152)|(0!=(b&24576)?0:8192)|0|268435456|0|(0!=(b&229376)?0:98304))}
function zi(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ai()}}
function Ih(a,b){var c,d,e,f,g;g=Ph(a.a);b.length<g&&(b=rj(new Array(g),b));e=(f=new Uh((new Rh(a.a)).a),new Xh(f));for(d=0;d<g;++d){b[d]=(c=Th(e.a),c.$())}b.length>g&&(b[g]=null);return b}
function Rg(){Qg={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].xb()&&(c=Rc(c,g)):g[0].xb()}catch(a){a=Eg(a);if(ld(a,4)){d=a;Dc();Jc(ld(d,40)?d.H():d)}else throw Fg(a)}}return c}
function tl(){kl();var a,b;++Hj;this.e=new pc;this.c=(b=new eb((J(),null)),b);this.a=(a=new eb(null),a);this.d=new U(new Bl(this),136486912);this.b=new qb(null,Ni(new Cl(this)),co);D((null,I))}
function Om(){var a;this.i=new mi;this.f=new pc;this.d=(a=new eb((J(),null)),a);this.c=new U(new Rm(this),io);this.e=new U(new Tm(this),io);this.a=new U(new Um(this),io);this.b=new U(new Vm(this),io)}
function xc(a){var b;if(a.c==null){b=qd(a.b)===qd(vc)?null:a.b;a.d=b==null?Yn:od(b)?b==null?null:b.name:pd(b)?'String':gh(q(b));a.a=a.a+': '+(od(b)?b==null?null:b.message:b+'');a.c='('+a.d+') '+a.a}}
function R(b){var c,d,e;e=b.g;try{d=b.c.u();if(!(qd(e)===qd(d)||e!=null&&p(e,d))){b.g=d;b.b=null;$(b.d)}}catch(a){a=Eg(a);if(ld(a,12)){c=a;if(!b.b){b.g=null;b.b=c;$(b.d)}throw Fg(c)}else throw Fg(a)}}
function qi(a,b,c){var d,e,f,g,h;h=b==null?0:(g=r(b),g|0);e=(d=a.a.get(h),d==null?new Array:d);if(e.length==0){a.a.set(h,e)}else{f=ni(b,e);if(f){return f._(c)}}e[e.length]=new Yh(b,c);++a.b;return null}
function nj(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function zj(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ah(a,c++)}b=b|0;return b}
function M(a,b){var c,d,e,f,g,h;g=a.a.length;while(g<b){g=(g-1)*2+1}c=$c(je,Ln,1,g,5,1);f=0;h=a.c?a.a.length-a.b+a.d:a.d-a.b;for(d=0;d<h;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}
function t(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=Jn==(d&Jn)?c.u():c.u()}else{Ob(b,e);try{g=Jn==(d&Jn)?c.u():c.u()}finally{Pb()}}return g}catch(a){a=Eg(a);if(ld(a,4)){f=a;throw Fg(f)}else throw Fg(a)}finally{D(b)}}
function s(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Cb){g=Jn==(d&Jn)?(c.a.A(),null):(c.a.A(),null)}else{Ob(b,e);try{g=Jn==(d&Jn)?(c.a.A(),null):(c.a.A(),null)}finally{Pb()}}return g}catch(a){a=Eg(a);if(ld(a,4)){f=a;throw Fg(f)}else throw Fg(a)}finally{D(b)}}
function Sb(a){var b;if(0==a.length){b=(_g(),$wnd.window.window).location.pathname+(''+$wnd.window.window.location.search);$wnd.window.window.history.pushState('',$g.title,b)}else{(_g(),$wnd.window.window).location.hash=a}}
function ib(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&1024)){!!b.e&&(b.c&=-1025);c=b.d;v((J(),J(),I),b,c)}else{b.e.A()}}else 0!=(b.c&1024)&&!!b.e&&(b.c&=-1025)}catch(a){a=Eg(a);if(ld(a,4)){J()}else throw Fg(a)}}}
function ri(a,b){var c,d,e,f,g,h;g=b==null?0:(f=r(b),f|0);d=(c=a.a.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(li(b,e.Z())){if(d.length==1){d.length=0;ui(a.a,g)}else{d.splice(h,1)}--a.b;return e.$()}}return null}
function pn(a,b){var c;this.k=Ni(a);this.j=Ni(b);this.g=new pc;this.d=(c=new eb((J(),null)),c);this.b=new U(new rn(this),io);this.c=new U(new sn(this),io);this.e=u(new tn(this),413155328);this.a=u(new un(this),681590784);D((null,I))}
function Tg(a,b,c){var d=Qg,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Qg[b]),Wg(h));_.vb=c;!b&&(_.wb=Yg);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.ub=f)}
function oh(a){if(a.N()){var b=a.c;b.O()?(a.k='['+b.j):!b.N()?(a.k='[L'+b.L()+';'):(a.k='['+b.L());a.b=b.K()+'[]';a.i=b.M()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.k=ph('.',[c,ph('$',d)]);a.b=ph('.',[c,ph('.',d)]);a.i=d[d.length-1]}
function bc(){var a,b,c;this.f=new gc(this);this.c=new pc;this.b=(c=new eb((J(),null)),c);this.a=(b=new eb(null),b);ah((_g(),$wnd.window.window),Tn,this.f,false);this.j=this.e=this.g=(a=$wnd.window.window.location.hash,null==a?'':a.substr(1))}
function Jh(a,b){var c,d,e;c=b.Z();e=b.$();d=pd(c)?c==null?Lh(pi(a.a,null)):Di(a.b,c):Lh(pi(a.a,c));if(!(qd(e)===qd(d)||e!=null&&p(e,d))){return false}if(d==null&&!(pd(c)?c==null?!!pi(a.a,null):Ci(a.b,c):!!pi(a.a,c))){return false}return true}
function ob(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new ii(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Eg(a);if(!ld(a,4))throw Fg(a)}if(6==(b.c&7)){return true}}}}}kb(b);return false}
function yi(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function nb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){db(a.a.d);c&&(1==(a.c&7)||0!=(a.c&512)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.g=null}_h(a.b,new ub(a));a.b.a=$c(je,Ln,1,0,5,1)}else 3==f&&!!a.a&&(e=a.a.f,e)}}
function wb(a){var b,c,d,e,f,g,h,i;d=P(a.d[0]);c=P(a.d[1]);g=P(a.d[2]);e=P(a.d[3]);f=P(a.d[4]);i=d+c+g+e+f;if(0==a.e){if(0==i){a.a=0;return false}else if(a.a+1>a.b){a.a=0;L(a.d[0]);L(a.d[1]);L(a.d[2]);L(a.d[3]);L(a.d[4]);return false}else{a.a=a.a+1;a.e=i}}--a.e;b=d>0?a.d[0]:c>0?a.d[1]:g>0?a.d[2]:e>0?a.d[3]:a.d[4];h=O(b);h.c&=-513;ib(h);return true}
function xk(){xk=Ug;bk=new yk(ao,0);ck=new yk('checkbox',1);dk=new yk('color',2);ek=new yk('date',3);fk=new yk('datetime',4);gk=new yk('email',5);hk=new yk('file',6);ik=new yk('hidden',7);jk=new yk('image',8);kk=new yk('month',9);lk=new yk(In,10);mk=new yk('password',11);nk=new yk('radio',12);ok=new yk('range',13);pk=new yk('reset',14);qk=new yk('search',15);rk=new yk('submit',16);sk=new yk('tel',17);tk=new yk('text',18);uk=new yk('time',19);vk=new yk('url',20);wk=new yk('week',21)}
function Fb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=ai(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&ei(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=6)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{Z(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&nb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=ai(a.b,g);if(-1==k.e){k.e=0;Y(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){ci(a.b,g)}e&&mb(a.e,a.b)}else{e&&mb(a.e,new gi)}if(V(a.e)&&!!a.e.a){b=a.e.a;k=b.d;k.c.a.length<=0&&Nn!=(b.e.c&On)&&Jb(a,k)}}
function Ai(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[_n]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!yi()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[_n]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Hn='object',In='number',Jn=16384,Kn={15:1},Ln={3:1,5:1},Mn={11:1},Nn=1048576,On=1835008,Pn={8:1},Qn=67108864,Rn=4194304,Sn={30:1},Tn='hashchange',Un=142614528,Vn='__noinit__',Wn='__java$exception',Xn={3:1,12:1,6:1,4:1},Yn='null',Zn=17592186044416,$n={44:1},_n='delete',ao='button',bo='selected',co=1478631424,eo={11:1,24:1},fo='input',go='completed',ho='header',io=136323072,jo='active';var _,Qg,Lg,Dg=-1;Rg();Tg(1,null,{},o);_.q=lo;_.r=function(){return this.ub};_.s=mo;_.t=function(){var a;return gh(q(this))+'@'+(a=r(this)>>>0,a.toString(16))};_.equals=function(a){return this.q(a)};_.hashCode=function(){return this.s()};_.toString=function(){return this.t()};var fd,gd,hd;Tg(52,1,{},hh);_.J=function(a){var b;b=new hh;b.e=4;a>1?(b.c=mh(this,a-1)):(b.c=this);return b};_.K=function(){fh(this);return this.b};_.L=function(){return gh(this)};_.M=function(){fh(this);return this.i};_.N=function(){return (this.e&4)!=0};_.O=function(){return (this.e&1)!=0};_.t=function(){return ((this.e&2)!=0?'interface ':(this.e&1)!=0?'':'class ')+(fh(this),this.k)};_.e=0;_.g=0;var eh=1;var je=jh(1);var ae=jh(52);Tg(74,1,{},F);_.a=1;_.c=false;_.d=true;_.e=0;var ud=jh(74);Tg(16,1,Kn,G);_.u=function(){return this.a.A(),null};var sd=jh(16);Tg(75,1,{},H);var td=jh(75);var I;Tg(22,1,{22:1},Q);_.b=0;_.c=false;_.d=0;var vd=jh(22);Tg(204,1,Mn);_.t=function(){var a;return gh(this.ub)+'@'+(a=r(this)>>>0,a.toString(16))};var xd=jh(204);Tg(21,204,Mn,U);_.v=function(){S(this)};_.w=ko;_.a=false;var wd=jh(21);Tg(17,204,{11:1,17:1},eb);_.v=function(){W(this)};_.w=function(){return -2==this.e};_.a=4;_.d=false;_.e=0;var zd=jh(17);Tg(119,1,Pn,fb);_.A=function(){X(this.a)};var yd=jh(119);Tg(20,204,{11:1,20:1},qb,rb);_.v=function(){gb(this)};_.w=function(){return 1==(this.c&7)};_.c=0;var Dd=jh(20);Tg(120,1,Sn,sb);_.A=function(){R(this.a)};var Ad=jh(120);Tg(121,1,Pn,tb);_.A=function(){lb(this.a)};var Bd=jh(121);Tg(122,1,{},ub);_.B=function(a){jb(this.a,a)};var Cd=jh(122);Tg(124,1,{},zb);_.a=0;_.b=100;_.e=0;var Ed=jh(124);Tg(62,1,Mn,Bb);_.v=function(){Ab(this)};_.w=ko;_.a=false;var Fd=jh(62);Tg(135,1,{},Nb);_.t=function(){var a;return fh(Gd),Gd.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.a=0;var Cb;var Gd=jh(135);Tg(47,1,{47:1});_.e='';_.g='';_.i=true;_.j='';var Nd=jh(47);Tg(104,47,{11:1,47:1,24:1},bc);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new cc(this)),Qn,null)}};_.q=lo;_.C=to;_.s=mo;_.w=uo;_.t=function(){var a;return fh(Ld),Ld.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.d=0;var Ld=jh(104);Tg(105,1,Pn,cc);_.A=function(){Xb(this.a)};var Hd=jh(105);Tg(106,1,Pn,dc);_.A=function(){Qb(this.a,this.b)};var Id=jh(106);Tg(107,1,Pn,ec);_.A=function(){Yb(this.a)};var Jd=jh(107);Tg(108,1,Pn,fc);_.A=function(){Tb(this.a)};var Kd=jh(108);Tg(79,1,{},gc);_.handleEvent=function(a){Rb(this.a,a)};var Md=jh(79);Tg(109,1,{});var Qd=jh(109);Tg(80,1,{},kc);_.B=function(a){ic(this.a,a)};var Od=jh(80);Tg(81,1,Pn,lc);_.A=function(){jc(this.a,this.b)};var Pd=jh(81);Tg(110,109,{});var Rd=jh(110);Tg(19,1,Mn,pc);_.v=function(){nc(this)};_.w=ko;_.a=false;var Sd=jh(19);Tg(4,1,{3:1,4:1});_.D=function(a){return new Error(a)};_.F=Do;_.G=function(){var a,b,c;c=this.f==null?null:this.f.replace(new RegExp('\n','g'),' ');b=(a=gh(this.ub),c==null?a:a+': '+c);rc(this,tc(this.D(b)));Vc(this)};_.t=function(){return sc(this,this.F())};_.e=Vn;_.g=true;var ne=jh(4);Tg(12,4,{3:1,12:1,4:1});var de=jh(12);Tg(6,12,Xn);var ke=jh(6);Tg(53,6,Xn);var ge=jh(53);Tg(71,53,Xn);var Wd=jh(71);Tg(40,71,{40:1,3:1,12:1,6:1,4:1},yc);_.F=function(){xc(this);return this.c};_.H=function(){return qd(this.b)===qd(vc)?null:this.b};var vc;var Td=jh(40);var Ud=jh(0);Tg(188,1,{});var Vd=jh(188);var Ac=0,Bc=0,Cc=-1;Tg(100,188,{},Qc);var Mc;var Xd=jh(100);var Tc;Tg(199,1,{});var Zd=jh(199);Tg(72,199,{},Xc);var Yd=jh(72);var $g;Tg(69,1,{66:1});_.t=ko;var $d=jh(69);fd={3:1,67:1,32:1};var _d=jh(67);Tg(45,1,{3:1,45:1});var ie=jh(45);gd={3:1,32:1,45:1};var be=jh(198);Tg(34,1,{3:1,32:1,34:1});_.q=lo;_.s=mo;_.t=function(){return this.a!=null?this.a:''+this.b};_.b=0;var ce=jh(34);Tg(10,6,Xn,sh,th);var ee=jh(10);Tg(33,45,{3:1,32:1,33:1,45:1},uh);_.q=function(a){return ld(a,33)&&a.a==this.a};_.s=ko;_.t=function(){return ''+this.a};_.a=0;var fe=jh(33);var wh;Tg(256,1,{});Tg(76,53,Xn,zh);_.D=function(a){return new TypeError(a)};var he=jh(76);hd={3:1,66:1,32:1,2:1};var me=jh(2);Tg(70,69,{66:1},Fh);var le=jh(70);Tg(260,1,{});Tg(55,6,Xn,Gh);var oe=jh(55);Tg(200,1,{43:1});_.P=qo;_.T=function(){return new Ri(this,0)};_.U=function(){return new _i(null,this.T())};_.R=function(a){throw Fg(new Gh('Add not supported on this collection'))};_.t=function(){var a,b,c;c=new Ti('[',']');for(b=this.Q();b.W();){a=b.X();Si(c,a===this?'(this Collection)':a==null?Yn:Xg(a))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var pe=jh(200);Tg(202,1,{186:1});_.q=function(a){var b,c,d;if(a===this){return true}if(!ld(a,41)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Uh((new Rh(d)).a);c.b;){b=Th(c);if(!Jh(this,b)){return false}}return true};_.s=function(){return ji(new Rh(this))};_.t=function(){var a,b,c;c=new Ti('{','}');for(b=new Uh((new Rh(this)).a);b.b;){a=Th(b);Si(c,Kh(this,a.Z())+'='+Kh(this,a.$()))}return !c.a?c.c:c.e.length==0?c.a.a:c.a.a+(''+c.e)};var Ae=jh(202);Tg(101,202,{186:1});var se=jh(101);Tg(203,200,{43:1,210:1});_.T=function(){return new Ri(this,1)};_.q=function(a){var b;if(a===this){return true}if(!ld(a,27)){return false}b=a;if(Ph(b.a)!=this.S()){return false}return Hh(this,b)};_.s=function(){return ji(this)};var Be=jh(203);Tg(27,203,{27:1,43:1,210:1},Rh);_.Q=function(){return new Uh(this.a)};_.S=oo;var re=jh(27);Tg(28,1,{},Uh);_.V=no;_.X=function(){return Th(this)};_.W=po;_.b=false;var qe=jh(28);Tg(201,200,{43:1,208:1});_.T=function(){return new Ri(this,16)};_.Y=function(a,b){throw Fg(new Gh('Add not supported on this list'))};_.R=function(a){this.Y(this.S(),a);return true};_.q=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,14)){return false}f=a;if(this.S()!=f.a.length){return false}e=new ii(f);for(c=new ii(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(qd(b)===qd(d)||b!=null&&p(b,d))){return false}}return true};_.s=function(){return ki(this)};_.Q=function(){return new Vh(this)};var ue=jh(201);Tg(78,1,{},Vh);_.V=no;_.W=function(){return this.a<this.b.a.length};_.X=function(){return ai(this.b,this.a++)};_.a=0;var te=jh(78);Tg(46,200,{43:1},Wh);_.Q=function(){var a;return a=new Uh((new Rh(this.a)).a),new Xh(a)};_.S=oo;var we=jh(46);Tg(57,1,{},Xh);_.V=no;_.W=function(){return this.a.b};_.X=function(){var a;return a=Th(this.a),a.$()};var ve=jh(57);Tg(102,1,$n);_.q=function(a){var b;if(!ld(a,44)){return false}b=a;return li(this.a,b.Z())&&li(this.b,b.$())};_.Z=ko;_.$=po;_.s=function(){return Mi(this.a)^Mi(this.b)};_._=function(a){var b;b=this.b;this.b=a;return b};_.t=function(){return this.a+'='+this.b};var xe=jh(102);Tg(103,102,$n,Yh);var ye=jh(103);Tg(205,1,$n);_.q=function(a){var b;if(!ld(a,44)){return false}b=a;return li(this.b.value[0],b.Z())&&li(Ii(this),b.$())};_.s=function(){return Mi(this.b.value[0])^Mi(Ii(this))};_.t=function(){return this.b.value[0]+'='+Ii(this)};var ze=jh(205);Tg(14,201,{3:1,14:1,43:1,208:1},gi,hi);_.Y=function(a,b){oj(this.a,a,b)};_.R=function(a){return $h(this,a)};_.P=function(a){_h(this,a)};_.Q=function(){return new ii(this)};_.S=function(){return this.a.length};var De=jh(14);Tg(18,1,{},ii);_.V=no;_.W=function(){return this.a<this.c.a.length};_.X=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var Ce=jh(18);Tg(41,101,{3:1,41:1,186:1},mi);var Ee=jh(41);Tg(60,1,{},si);_.P=qo;_.Q=function(){return new ti(this)};_.b=0;var Ge=jh(60);Tg(61,1,{},ti);_.V=no;_.X=function(){return this.d=this.a[this.c++],this.d};_.W=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var Fe=jh(61);var wi;Tg(58,1,{},Gi);_.P=qo;_.Q=function(){return new Hi(this)};_.b=0;_.c=0;var Je=jh(58);Tg(59,1,{},Hi);_.V=no;_.X=function(){return this.c=this.a,this.a=this.b.next(),new Ji(this.d,this.c,this.d.c)};_.W=function(){return !this.a.done};var He=jh(59);Tg(125,205,$n,Ji);_.Z=function(){return this.b.value[0]};_.$=function(){return Ii(this)};_._=function(a){return Ei(this.a,this.b.value[0],a)};_.c=0;var Ie=jh(125);Tg(99,1,{});_.V=function(a){Oi(this,a)};_.ab=function(){return this.d};_.bb=zo;_.d=0;_.e=0;var Le=jh(99);Tg(56,99,{});var Ke=jh(56);Tg(26,1,{},Ri);_.ab=ko;_.bb=function(){Qi(this);return this.c};_.V=function(a){Qi(this);this.d.V(a)};_.cb=function(a){Qi(this);if(this.d.W()){a.B(this.d.X());return true}return false};_.a=0;_.c=0;var Me=jh(26);Tg(54,1,{},Ti);_.t=function(){return !this.a?this.c:this.e.length==0?this.a.a:this.a.a+(''+this.e)};var Ne=jh(54);var We=lh();Tg(126,1,{});_.c=false;var Xe=jh(126);Tg(36,126,{},_i);var Ve=jh(36);Tg(128,56,{},dj);_.cb=function(a){this.b=false;while(!this.b&&this.c.cb(new ej(this,a)));return this.b};_.b=false;var Pe=jh(128);Tg(131,1,{},ej);_.B=function(a){cj(this.a,this.b,a)};var Oe=jh(131);Tg(127,56,{},gj);_.cb=function(a){return this.a.cb(new hj(a))};var Re=jh(127);Tg(130,1,{},hj);_.B=function(a){fj(this.a,a)};var Qe=jh(130);Tg(129,1,{},jj);_.B=function(a){ij(this,a)};var Se=jh(129);Tg(132,1,{},kj);_.B=function(a){};var Te=jh(132);Tg(133,1,{},mj);_.B=function(a){lj(this,a)};var Ue=jh(133);Tg(258,1,{});Tg(207,1,{});var Ye=jh(207);Tg(255,1,{});var tj=0;var vj,wj=0,xj;Tg(679,1,{});Tg(706,1,{});Tg(206,1,{});_.eb=ro;_.fb=ro;_.hb=function(a,b,c){return false};_.p=false;var Ze=jh(206);Tg(35,$wnd.React.Component,{});Sg(Qg[1],_);_.render=function(){return Mj(this.a)};var $e=jh(35);Tg(38,206,{});_.kb=function(){return false};_.mb=function(){return Nj(this)};_.k=false;_.n=false;var Hj=1,Ij;var _e=jh(38);Tg(227,$wnd.Function,{},Oj);_.I=function(a){return Ab(Ij),Ij=null,null};Tg(9,34,{3:1,32:1,34:1,9:1},yk);var bk,ck,dk,ek,fk,gk,hk,ik,jk,kk,lk,mk,nk,ok,pk,qk,rk,sk,tk,uk,vk,wk;var af=kh(9,zk);Tg(156,38,{});_.rb=so;_.gb=function(){var a;a=T((tm(),sm).b);return $wnd.React.createElement('footer',Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,['footer'])),Nl(new Ol),$wnd.React.createElement('ul',Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,['filters'])),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Rj(Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,[(yn(),wn)==a?bo:null])),'#'),'All')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Rj(Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,[vn==a?bo:null])),'#active'),'Active')),$wnd.React.createElement('li',null,$wnd.React.createElement('a',Rj(Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,[xn==a?bo:null])),'#completed'),'Completed'))),this.rb()?$wnd.React.createElement(ao,Sj(Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,['clear-completed'])),Vg(Kl.prototype.qb,Kl,[])),'Clear Completed'):null)};var If=jh(156);Tg(157,156,{});_.rb=so;var Ak;var Mf=jh(157);Tg(158,157,eo,Dk);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new Hk(this)),Qn,null)}};_.q=lo;_.lb=vo;_.C=to;_.rb=function(){return T(this.a)};_.s=mo;_.w=uo;_.t=function(){var a;return fh(kf),kf.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.mb=function(){var b;try{return B((J(),J(),I),this.b,new Fk(this))}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.d=0;var kf=jh(158);Tg(159,1,Kn,Ek);_.u=function(){return dh(),T((tm(),qm).b).a>0?true:false};var bf=jh(159);Tg(162,1,Kn,Fk);_.u=xo;var cf=jh(162);Tg(160,1,Sn,Gk);_.A=wo;var df=jh(160);Tg(161,1,Pn,Hk);_.A=function(){Ck(this.a)};var ef=jh(161);Tg(179,38,{});_.gb=function(){var a,b;b=T((tm(),qm).e).a;a='item'+(b==1?'':'s');return $wnd.React.createElement('span',Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,['todo-count'])),$wnd.React.createElement('strong',null,b),' '+a+' left')};var Hf=jh(179);Tg(180,179,{});var Ik;var Lf=jh(180);Tg(181,180,eo,Lk);_.v=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Nk(this)),Qn,null)}};_.q=lo;_.lb=vo;_.C=po;_.s=mo;_.w=Ao;_.t=function(){var a;return fh(jf),jf.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.mb=function(){var b;try{return B((J(),J(),I),this.a,new Ok(this))}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.c=0;var jf=jh(181);Tg(182,1,Sn,Mk);_.A=wo;var ff=jh(182);Tg(183,1,Pn,Nk);_.A=function(){Kk(this.a)};var gf=jh(183);Tg(184,1,Kn,Ok);_.u=xo;var hf=jh(184);Tg(148,38,{});_.gb=function(){return $wnd.React.createElement(fo,Tj(Xj(Yj(_j(Zj(Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,['new-todo']))),(bb(this.b),this.e)),Vg(Zl.prototype.pb,Zl,[this])),Vg($l.prototype.ob,$l,[this]))))};_.e='';var Uf=jh(148);Tg(149,148,{});var Rk;var Of=jh(149);Tg(150,149,eo,Yk);_.v=function(){if(this.d>=0){this.d=-2;t((J(),J(),I),new G(new bl(this)),Qn,null)}};_.q=lo;_.lb=vo;_.C=to;_.s=mo;_.w=uo;_.t=function(){var a;return fh(qf),qf.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.mb=function(){var b;try{return B((J(),J(),I),this.a,new Zk(this))}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.d=0;var qf=jh(150);Tg(153,1,Kn,Zk);_.u=xo;var lf=jh(153);Tg(154,1,Pn,$k);_.A=function(){Pk(this.a)};var mf=jh(154);Tg(155,1,Pn,_k);_.A=function(){Vk(this.a,this.b)};var nf=jh(155);Tg(151,1,Sn,al);_.A=wo;var of=jh(151);Tg(152,1,Pn,bl);_.A=function(){Wk(this.a)};var pf=jh(152);Tg(165,38,{});_.eb=function(){cl(this)};_.tb=yo;_.fb=function(){rl(this,this.sb())};_.gb=function(){var a,b;b=this.sb();a=(bb(b.a),b.g);return $wnd.React.createElement('li',Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,[a?go:null,this.tb()?'editing':null])),$wnd.React.createElement('div',Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,['view'])),$wnd.React.createElement(fo,Xj(Uj($j(Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,['toggle'])),(xk(),ck)),a),Vg(cm.prototype.ob,cm,[b]))),$wnd.React.createElement('label',ak(new $wnd.Object,Vg(dm.prototype.qb,dm,[this,b])),(bb(b.b),b.i)),$wnd.React.createElement(ao,Sj(Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,['destroy'])),Vg(em.prototype.qb,em,[b])))),$wnd.React.createElement(fo,Yj(Xj(Wj(Vj(Pj(Qj(new $wnd.Object,Vg(fm.prototype.B,fm,[this])),cd(Yc(me,1),Ln,2,6,['edit'])),(bb(this.a),this.i)),Vg(gm.prototype.nb,gm,[this,b])),Vg(bm.prototype.ob,bm,[this])),Vg(hm.prototype.pb,hm,[this,b]))))};_.j=false;var Wf=jh(165);Tg(166,165,{});_.kb=function(){var a;a=(cb(this.c),this.o.props['a']);if(!!a&&a.f<0){return true}return false};_.sb=function(){return this.o.props['a']};_.tb=yo;_.hb=function(a,b,c){return ll(this,a,b,c)};var jl;var Qf=jh(166);Tg(167,166,eo,tl);_.eb=function(){var b;try{A((J(),J(),I),new wl(this),Un)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.v=function(){if(this.f>=0){this.f=-2;t((J(),J(),I),new G(new ul(this)),Qn,null)}};_.q=lo;_.lb=vo;_.C=zo;_.sb=function(){return cb(this.c),this.o.props['a']};_.s=mo;_.w=Co;_.tb=function(){return T(this.d)};_.hb=function(b,c,d){var e;try{return t((J(),J(),I),new xl(this,b,c,d),75505664,null)}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){e=a;throw Fg(e)}else if(ld(a,4)){e=a;throw Fg(new th(e))}else throw Fg(a)}};_.t=function(){var a;return fh(Af),Af.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.mb=function(){var b;try{return B((J(),J(),I),this.b,new vl(this))}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.f=0;var Af=jh(167);Tg(170,1,Pn,ul);_.A=function(){nl(this.a)};var rf=jh(170);Tg(171,1,Kn,vl);_.u=xo;var sf=jh(171);Tg(172,1,Pn,wl);_.A=function(){cl(this.a)};var tf=jh(172);Tg(173,1,Kn,xl);_.u=function(){return ol(this.a,this.d,this.c,this.b)};_.b=false;var uf=jh(173);Tg(174,1,Pn,yl);_.A=function(){sl(this.a,xm(this.b))};var vf=jh(174);Tg(175,1,Pn,zl);_.A=function(){rl(this.a,this.b);on((tm(),sm),null)};var wf=jh(175);Tg(176,1,Pn,Al);_.A=function(){dl(this.a,this.b)};var xf=jh(176);Tg(168,1,Kn,Bl);_.u=function(){return pl(this.a)};var yf=jh(168);Tg(169,1,Sn,Cl);_.A=wo;var zf=jh(169);Tg(136,38,{});_.gb=function(){var a,b;return $wnd.React.createElement('div',null,$wnd.React.createElement('div',null,$wnd.React.createElement(ho,Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,[ho])),$wnd.React.createElement('h1',null,'todos'),_l(new am)),T((tm(),qm).c)?null:$wnd.React.createElement('section',Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,[ho])),$wnd.React.createElement(fo,Xj($j(Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,['toggle-all'])),(xk(),ck)),Vg(mm.prototype.ob,mm,[]))),$wnd.React.createElement.apply(null,['ul',Pj(new $wnd.Object,cd(Yc(me,1),Ln,2,6,['todo-list']))].concat((a=$i(Zi(T(sm.c).U()),(b=new gi,b)),fi(a,bd(a.a.length)))))),T(qm.c)?null:Ll(new Ml)))};var Yf=jh(136);Tg(137,136,{});var Dl;var Sf=jh(137);Tg(138,137,eo,Gl);_.v=function(){if(this.c>=0){this.c=-2;t((J(),J(),I),new G(new Il(this)),Qn,null)}};_.q=lo;_.lb=vo;_.C=po;_.s=mo;_.w=Ao;_.t=function(){var a;return fh(Ef),Ef.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.mb=function(){var b;try{return B((J(),J(),I),this.a,new Jl(this))}catch(a){a=Eg(a);if(ld(a,6)||ld(a,7)){b=a;throw Fg(b)}else if(ld(a,4)){b=a;throw Fg(new th(b))}else throw Fg(a)}};_.c=0;var Ef=jh(138);Tg(139,1,Sn,Hl);_.A=wo;var Bf=jh(139);Tg(140,1,Pn,Il);_.A=function(){Kk(this.a)};var Cf=jh(140);Tg(141,1,Kn,Jl);_.u=xo;var Df=jh(141);Tg(232,$wnd.Function,{},Kl);_.qb=function(a){Ym((tm(),rm))};Tg(143,1,{},Ml);var Ff=jh(143);Tg(163,1,{},Ol);var Gf=jh(163);Tg(231,$wnd.Function,{},Pl);_.ib=function(a){return new Ql(a)};Tg(145,35,{},Ql);_.jb=function(){return new Dk};_.componentWillUnmount=Bo;var Jf=jh(145);Tg(242,$wnd.Function,{},Rl);_.ib=function(a){return new Sl(a)};Tg(164,35,{},Sl);_.jb=function(){return new Lk};_.componentWillUnmount=Bo;var Kf=jh(164);Tg(228,$wnd.Function,{},Tl);_.ib=function(a){return new Ul(a)};Tg(144,35,{},Ul);_.jb=function(){return new Yk};_.componentWillUnmount=Bo;var Nf=jh(144);Tg(233,$wnd.Function,{},Vl);_.ib=function(a){return new Wl(a)};Tg(147,35,{},Wl);_.jb=function(){return new tl};_.componentDidUpdate=function(a){Dj(this.a,a)};_.componentWillUnmount=Bo;_.shouldComponentUpdate=function(a){return Ej(this.a,a)};var Pf=jh(147);Tg(225,$wnd.Function,{},Xl);_.ib=function(a){return new Yl(a)};Tg(123,35,{},Yl);_.jb=function(){return new Gl};_.componentWillUnmount=Bo;var Rf=jh(123);Tg(229,$wnd.Function,{},Zl);_.pb=function(a){Qk(this.a,a)};Tg(230,$wnd.Function,{},$l);_.ob=function(a){Uk(this.a,a)};Tg(142,1,{},am);var Tf=jh(142);Tg(240,$wnd.Function,{},bm);_.ob=function(a){ml(this.a,a)};Tg(234,$wnd.Function,{},cm);_.ob=function(a){Dm(this.a)};Tg(236,$wnd.Function,{},dm);_.qb=function(a){el(this.a,this.b)};Tg(237,$wnd.Function,{},em);_.qb=function(a){il(this.a)};Tg(238,$wnd.Function,{},fm);_.B=function(a){fl(this.a,a)};Tg(239,$wnd.Function,{},gm);_.nb=function(a){hl(this.a,this.b)};Tg(241,$wnd.Function,{},hm);_.pb=function(a){gl(this.a,this.b,a)};Tg(146,1,{},lm);var Vf=jh(146);Tg(226,$wnd.Function,{},mm);_.ob=function(a){var b;b=a.target;an((tm(),rm),b.checked)};Tg(65,1,{},om);var Xf=jh(65);var pm,qm,rm,sm;Tg(49,1,{49:1});_.g=false;var Ag=jh(49);Tg(50,49,{11:1,24:1,50:1,49:1},Em);_.v=function(){vm(this)};_.q=function(a){return wm(this,a)};_.C=to;_.s=zo;_.w=Co;_.t=function(){var a;return fh(mg),mg.k+'@'+(a=this.e>>>0,a.toString(16))};_.e=0;_.f=0;var um=0;var mg=jh(50);Tg(177,1,Pn,Fm);_.A=function(){zm(this.a)};var Zf=jh(177);Tg(178,1,Pn,Gm);_.A=function(){Am(this.a)};var $f=jh(178);Tg(48,110,{48:1});var vg=jh(48);Tg(111,48,{11:1,24:1,48:1},Om);_.v=function(){if(this.g>=0){this.g=-2;t((J(),J(),I),new G(new Pm(this)),Qn,null)}};_.q=lo;_.C=Do;_.s=mo;_.w=function(){return this.g<0};_.t=function(){var a;return fh(gg),gg.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.g=0;var gg=jh(111);Tg(116,1,Pn,Pm);_.A=function(){Lm(this.a)};var _f=jh(116);Tg(117,1,Pn,Qm);_.A=function(){hc(this.a,this.b,true)};var ag=jh(117);Tg(112,1,Kn,Rm);_.u=function(){return Mm(this.a)};var bg=jh(112);Tg(118,1,Kn,Sm);_.u=function(){return Hm(this.a,this.c,this.b)};_.b=false;var cg=jh(118);Tg(113,1,Kn,Tm);_.u=function(){return vh(Kg(Xi(Km(this.a))))};var dg=jh(113);Tg(114,1,Kn,Um);_.u=function(){return vh(Kg(Xi(Yi(Km(this.a),new Bn))))};var eg=jh(114);Tg(115,1,Kn,Vm);_.u=function(){return Nm(this.a)};var fg=jh(115);Tg(86,1,{});var zg=jh(86);Tg(87,86,eo,bn);_.v=function(){if(this.b>=0){this.b=-2;t((J(),J(),I),new G(new en(this)),Qn,null)}};_.q=lo;_.C=ko;_.s=mo;_.w=function(){return this.b<0};_.t=function(){var a;return fh(lg),lg.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.b=0;var lg=jh(87);Tg(90,1,Pn,cn);_.A=function(){Cm(this.b,this.a)};var hg=jh(90);Tg(91,1,Pn,dn);_.A=function(){Zm(this.a)};var ig=jh(91);Tg(88,1,Pn,en);_.A=function(){nc(this.a.a)};var jg=jh(88);Tg(89,1,Pn,fn);_.A=function(){$m(this.a,this.b)};_.b=false;var kg=jh(89);Tg(92,1,{});var Cg=jh(92);Tg(93,92,eo,pn);_.v=function(){if(this.i>=0){this.i=-2;t((J(),J(),I),new G(new qn(this)),Qn,null)}};_.q=lo;_.C=function(){return this.g};_.s=mo;_.w=function(){return this.i<0};_.t=function(){var a;return fh(sg),sg.k+'@'+(a=uj(this)>>>0,a.toString(16))};_.i=0;var sg=jh(93);Tg(98,1,Pn,qn);_.A=function(){kn(this.a)};var ng=jh(98);Tg(94,1,Kn,rn);_.u=function(){var a;return a=Wb(this.a.j),Bh(jo,a)||Bh(go,a)||Bh('',a)?Bh(jo,a)?(yn(),vn):Bh(go,a)?(yn(),xn):(yn(),wn):(yn(),wn)};var og=jh(94);Tg(95,1,Kn,sn);_.u=function(){return ln(this.a)};var pg=jh(95);Tg(96,1,Sn,tn);_.A=function(){mn(this.a)};var qg=jh(96);Tg(97,1,Sn,un);_.A=function(){nn(this.a)};var rg=jh(97);Tg(37,34,{3:1,32:1,34:1,37:1},zn);var vn,wn,xn;var tg=kh(37,An);Tg(82,1,{},Bn);_.db=function(a){return !ym(a)};var ug=jh(82);Tg(84,1,{},Cn);_.db=function(a){return ym(a)};var wg=jh(84);Tg(85,1,{},Dn);_.B=function(a){Jm(this.a,a)};var xg=jh(85);Tg(83,1,{},En);_.B=function(a){Xm(this.a,a)};_.a=false;var yg=jh(83);Tg(73,1,{},Fn);_.db=function(a){return hn(this.a,a)};var Bg=jh(73);var Gn=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=Og;Mg(Zg);Pg('permProps',[[]]);if (todomvc) todomvc.onScriptLoad(gwtOnLoad);})();