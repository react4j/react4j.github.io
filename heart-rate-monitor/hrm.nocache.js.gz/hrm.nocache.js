function hrm(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='hrm',tb='__gwt_marker_hrm',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='49740BCA0F91C168E1A60C6A1BA1F8CC',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};hrm.onScriptLoad=function(a){hrm=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
hrm();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '49740BCA0F91C168E1A60C6A1BA1F8CC';function p(){}
function _e(){}
function Xe(){}
function Xh(){}
function nh(){}
function oh(){}
function _h(){}
function Db(){}
function Gc(){}
function Nc(){}
function Ig(){}
function bi(){}
function hi(){}
function Lc(a){Kc()}
function jf(){jf=Xe}
function Tf(){Kf(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function vb(a){this.a=a}
function wb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function fc(a){this.a=a}
function Gf(a){this.a=a}
function Gg(a){this.a=a}
function Jg(a){this.a=a}
function ph(a){this.a=a}
function qh(a){this.a=a}
function rh(a){this.a=a}
function Fh(a){this.a=a}
function Gh(a){this.a=a}
function Hh(a){this.a=a}
function Rh(a){this.a=a}
function Sh(a){this.a=a}
function Uh(a){this.a=a}
function Vh(a){this.a=a}
function Wh(a){this.a=a}
function Yh(a){this.a=a}
function Zh(a){this.a=a}
function $h(a){this.a=a}
function ai(a){this.a=a}
function Vf(a){this.c=a}
function ag(){this.a=hg()}
function kg(){this.a=hg()}
function Hg(a,b){a.a=b}
function pb(a,b){a.b=b}
function Zg(a,b){Yg(a,b)}
function C(a,b){Lb(a.f,b.f)}
function K(a,b){O(a);L(a,b)}
function w(a){--a.e;D(a)}
function Y(a){!!a&&_b(a.d)}
function ac(a){!!a&&a.o()}
function ri(a){qg(this,a)}
function db(a){Vb((J(),a))}
function eb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function Nh(a){kb(a.b);$(a.a)}
function Ah(a){R(a.a);$(a.b)}
function Jh(a){a.f=2;_b(a.d)}
function ic(a,b){a.b=b;hc(a,b)}
function Nf(a,b){return a.a[b]}
function Ne(a){return a.b}
function pi(){return this.b}
function qi(){return this.c}
function hf(a){lc.call(this,a)}
function zf(a){lc.call(this,a)}
function mf(a){lf(a);return a.j}
function Oc(a,b){return rf(a,b)}
function Ng(a,b){a.splice(b,1)}
function vg(a,b,c){b.p(a.a[c])}
function qg(a,b){while(a.O(b));}
function dg(){dg=Xe;cg=fg()}
function J(){J=Xe;I=new F}
function nc(){nc=Xe;mc=new p}
function Dc(){Dc=Xe;Cc=new Gc}
function tc(){tc=Xe;!!(Kc(),Jc)}
function Bc(){qc!=0&&(qc=0);sc=-1}
function ab(a){J();Wb(a);a.e=-2}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function T(a){lb(a.f);return V(a)}
function Ch(a){fb(a.b);return a.c}
function Dg(a,b){a.G(b);return a}
function hg(){dg();return new cg}
function jg(a,b){return a.a.get(b)}
function Ef(a){return a.a.b+a.b.b}
function Eg(a,b){Hg(a,Dg(a.a,b))}
function v(a,b,c){t(a,new H(c),b)}
function Lg(a,b,c){a.splice(b,0,c)}
function fh(a,b){a.style=b;return a}
function dh(a,b){this.a=a;this.b=b}
function Ih(a,b){this.a=a;this.b=b}
function Th(a,b){this.a=a;this.b=b}
function Bb(a){this.d=a;this.b=100}
function ib(a){this.c=new Tf;this.b=a}
function sh(){this.a=_g((di(),ci))}
function Qe(){Oe==null&&(Oe=[])}
function bd(a){return a==null?null:a}
function pg(a){return a!=null?s(a):0}
function Df(a){return !a?null:mg(a)}
function Rb(a){return !a.d?a:Rb(a.d)}
function o(a,b){return bd(a)===bd(b)}
function B(a,b,c){return u(a,c,2048,b)}
function A(a,b,c){u(a,new G(b),c,null)}
function Mg(a,b){Kg(b,0,a,0,b.length)}
function gf(a,b){a.filters=b;return a}
function ef(a,b){a.services=b;return a}
function hh(a,b){a.onClick=b;return a}
function gh(a,b){a.disabled=b;return a}
function Ac(a){$wnd.clearTimeout(a)}
function xf(a,b){return a.charCodeAt(b)}
function Zc(a,b){return a!=null&&Xc(a,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function Qg(a){return a.$H||(a.$H=++Pg)}
function _c(a){return typeof a==='number'}
function ad(a){return typeof a==='string'}
function ob(a){J();nb(a);qb(a,2,true)}
function Kf(a){a.a=Qc(Qd,ji,1,0,5,1)}
function P(){this.a=Qc(Qd,ji,1,100,5,1)}
function lc(a){this.d=a;gc(this);this.t()}
function Cg(a,b){zg.call(this,a);this.a=b}
function Yg(a,b){for(var c in a){b(c)}}
function fb(a){var b;Sb((J(),b=Nb,b),a)}
function dc(a){J();Nb?a.o():A((null,I),a,0)}
function Eb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&qb(a.f,5,true)}
function lf(a){if(a.j!=null){return}tf(a)}
function gc(a){a.f&&a.b!==mi&&a.t();return a}
function pf(a){var b;b=of(a);vf(a,b);return b}
function $c(a){return typeof a==='boolean'}
function uc(a,b,c){return a.apply(b,c);var d}
function Kb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function ng(a,b,c){this.a=a;this.b=b;this.c=c}
function $f(){this.a=new ag;this.b=new kg}
function F(){this.f=new Mb;this.a=new Bb(this.f)}
function Ug(){Ug=Xe;Rg=new p;Tg=new p}
function Kc(){Kc=Xe;var a;!Mc();a=new Nc;Jc=a}
function uh(a){null!=a.g&&a.g.disconnect()}
function kh(a){a.src='img/heart.svg';return a}
function ff(a){a.acceptAllDevices=false;return a}
function Lf(a,b){a.a[a.a.length]=b;return true}
function If(a){var b;b=a.a.J();a.b=Hf(a);return b}
function Kh(a){var b;a.f=0;gi();b=mh(a);return b}
function qf(a){var b;b=of(a);b.i=a;b.e=1;return b}
function ig(a,b){return !(a.a.get(b)===undefined)}
function Sc(a){return Array.isArray(a)&&a.V===_e}
function Yc(a){return !Array.isArray(a)&&a.V===_e}
function Xf(a){return new Cg(null,Wf(a,a.length))}
function Ag(a){yg(a);return new Cg(a,new Fg(a.a))}
function Wf(a,b){return rg(b,a.length),new wg(a,b)}
function Ph(a){return B((J(),J(),I),a.b,new Uh(a))}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function mb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Lb(a,b){Kb(a,((b.a&229376)>>15)-1,b)}
function tg(a,b){while(a.c<a.d){vg(a,b,a.c++)}}
function Ab(a){while(true){if(!zb(a)){break}}}
function Cb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function xg(a){if(!a.b){yg(a);a.c=true}else{xg(a.b)}}
function Lh(a){if(0==a.f){a.f=1;a.e.forceUpdate()}}
function Xg(){if(Sg==256){Rg=Tg;Tg=new p;Sg=0}++Sg}
function Hc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Pf(a,b){var c;c=a.a[b];Ng(a.a,b);return c}
function Rf(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Bh(a,b){var c;c=a.c;if(b!=c){a.c=b;eb(a.b)}}
function Oh(a,b){var c;c=a.c;if(b!=c){a.c=b;eb(a.a)}}
function sg(a,b){this.c=a;this.b=(b&64)!=0?b|16384:b}
function wg(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Fg(a){sg.call(this,a.M(),a.L()&-6);this.a=a}
function tb(a){sb.call(this,null,null,a,1411780608)}
function ub(a){sb.call(this,a,new vb(a),null,304611328)}
function zg(a){if(!a){this.b=null;new Tf}else{this.b=a}}
function sf(a){if(a.F()){return null}var b=a.i;return Te[b]}
function Ff(a,b){if(b){return Cf(a.a,b)}return false}
function og(a,b){return bd(a)===bd(b)||a!=null&&q(a,b)}
function jc(a,b){var c;c=mf(a.T);return b==null?c:c+': '+b}
function rf(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.w(b))}
function gb(a){var b;J();!!Nb&&!!Nb.e&&Sb((b=Nb,b),a)}
function di(){di=Xe;var a;ci=(a=Ye(bi.prototype.S,bi,[]),a)}
function Ze(a){function b(){}
;b.prototype=a||{};return new b}
function ih(a){a.animationDirection='alternate';return a}
function jh(a){a.animationIterationCount='infinite';return a}
function zc(a){tc();$wnd.setTimeout(function(){throw a},0)}
function yg(a){if(a.b){yg(a.b)}else if(a.c){throw Ne(new wf)}}
function Ob(a){if(a.e){2==(a.e.c&7)||qb(a.e,4,true);nb(a.e)}}
function cc(a){ac(a.f);!!a.d&&bc(a);Y(a.a);Y(a.c);ac(a.b);ac(a.e)}
function Uf(a){Kf(this);Mg(this.a,Bf(a,Qc(Qd,ji,1,Ef(a.a),5,1)))}
function si(a){(df(),$wnd.goog.global.console).log(a.nativeEvent)}
function Dh(a){return jf(),null!=a.g&&a.g.connected?true:false}
function ug(a,b){if(a.c<a.d){vg(a,b,a.c++);return true}return false}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function Ve(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function bh(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function xc(a,b,c){var d;d=vc();try{return uc(a,b,c)}finally{yc(d)}}
function bb(a,b){var c,d;Lf(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Bg(a,b){var c;xg(a);c=new Ig;c.a=b;a.a.N(new Jg(c));return c.a}
function kc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function wc(b){tc();return function(){return xc(b,this,arguments);var a}}
function pc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function xh(a,b){var c,d;c=b.target;d=c.value;dc(new Ih(a,d.getInt8(1)))}
function Jb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function bg(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function lg(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Jf(a){this.d=a;this.c=new lg(this.d.b);this.a=this.c;this.b=Hf(this)}
function ei(a){$wnd.React.Component.call(this,a);this.a=new Qh(this)}
function $(a){if(-2!=a.e){A((J(),J(),I),new jb(a),0);!!a.b&&kb(a.b)}}
function R(a){if(!a.a){a.a=true;a.i=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function mg(a){if(a.a.c!=a.c){return jg(a.a,a.b.value[0])}return a.b.value[1]}
function Of(a,b,c){for(;c<a.a.length;++c){if(og(b,a.a[c])){return c}}return -1}
function Qf(a,b){var c;c=Of(a,b,0);if(c==-1){return false}Ng(a.a,c);return true}
function Qc(a,b,c,d,e,f){var g;g=Rc(e,d);e!=10&&Tc(Oc(a,f),b,c,e,g);return g}
function yc(a){a&&Fc((Dc(),Cc));--qc;if(a){if(sc!=-1){Ac(sc);sc=-1}}}
function Gb(b){try{lb(b.b.a)}catch(a){a=Me(a);if(!Zc(a,5))throw Ne(a)}}
function cd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Og(a,b){return Pc(b)!=10&&Tc(r(b),b.U,b.__elementTypeId$,Pc(b),a),a}
function Pc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Mf(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.p(c)}}
function Mb(){var a;this.a=Qc(hd,ji,27,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function Ec(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Ic(b,c)}while(a.a);a.a=c}}
function Fc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Ic(b,c)}while(a.b);a.b=c}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Ab(a.a)}finally{a.c=false}}}}
function V(a){if(a.b){if(Zc(a.b,6)){throw Ne(a.b)}else{throw Ne(a.b)}}return a.i}
function wh(a,b){b.addEventListener('characteristicvaluechanged',a.e);return null}
function vf(a,b){var c;if(!a){return}b.i=a;var d=sf(b);if(!d){Te[a]=[b];return}d.T=b}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Tf);Lf(a.b,b)}}}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new Tf);a.c=c.c}b.d=true;Lf(a.c,b)}
function of(a){var b;b=new nf;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function Ye(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Pe(){Qe();var a=Oe;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function nb(a){var b,c;for(c=new Vf(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function _b(a){if(a.g>=0){a.g=-2;u((J(),J(),I),new G(new fc(a)),67108864,null)}}
function af(){$wnd.ReactDOM.render((new sh).a,(df(),bf).getElementById('app'),null)}
function wf(){lc.call(this,"Stream already terminated, can't be modified or used")}
function oc(a){nc();gc(this);this.b=a;hc(this,a);this.d=a==null?'null':$e(a);this.a=a}
function ec(a,b,c){this.d=c?new $f:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function _g(a){var b;b=$g($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function df(){df=Xe;bf=$wnd.goog.global.document;cf=$wnd.goog.global.navigator}
function lh(a,b){(df(),$wnd.goog.global.console).log(b.nativeEvent);dc(new Th(a,(gb(a.a),!a.c)))}
function vh(a,b){A((J(),J(),I),new Gh(a),142606336);return b.getPrimaryService(oi)}
function Af(a,b){var c,d;for(d=new Jf(b.a);d.b;){c=If(d);if(!Ff(a,c)){return false}}return true}
function Hf(a){if(a.a.I()){return true}if(a.a!=a.c){return false}a.a=new bg(a.d.a);return a.a.I()}
function Me(a){var b;if(Zc(a,5)){return a}b=a&&a.__java$exception;if(!b){b=new oc(a);Lc(b)}return b}
function Tc(a,b,c,d,e){e.T=a;e.U=b;e.V=_e;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function _f(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function Yf(a){var b,c,d;d=0;for(c=new Jf(a.a);c.b;){b=If(c);d=d+(b?pg(b.b.value[0])^pg(mg(b)):0);d=d|0}return d}
function bc(a){var b,c;for(c=new Vf(new Uf(new Gf(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);mg(b).o()}}
function rg(a,b){if(0>a||a>b){throw Ne(new hf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Hb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function W(a){this.c=a;this.g=null;this.i=null;this.h=false;this.f=new ub(this);this.e=new ib(this.f)}
function nf(){this.g=kf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function gi(){if(!fi){fi=(++(J(),J(),I).e,new Db);$wnd.Promise.resolve(null).then(Ye(hi.prototype.v,hi,[]))}}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new xb(a)),67108864,null);!!a.a&&R(a.a);Eb(a.f);a.c=a.c&-8|1}}
function Fb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&ki)?Gb(a):lb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function r(a){return ad(a)?Sd:_c(a)?Kd:$c(a)?Id:Yc(a)?a.T:Sc(a)?a.T:a.T||Array.isArray(a)&&Oc(Bd,1)||Bd}
function s(a){return ad(a)?Wg(a):_c(a)?cd(a):$c(a)?a?1231:1237:Yc(a)?a.m():Sc(a)?Qg(a):!!a&&!!a.hashCode?a.hashCode():Qg(a)}
function $e(a){var b;if(Array.isArray(a)&&a.V===_e){return mf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function Wg(a){Ug();var b,c,d;c=':'+a;d=Tg[c];if(d!=null){return cd(d)}d=Rg[c];b=d==null?Vg(a):cd(d);Xg();Tg[c]=b;return b}
function Zf(a){var b,c,d;d=1;for(c=new Vf(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Ib(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=Pf(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&qb(b.b,3,true)}}}
function cb(a,b){var c,d;d=a.c;Qf(d,b);!!a.b&&ki!=(a.b.c&1835008)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function Se(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function uf(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Sf(a,b){var c,d;d=a.a.length;b.length<d&&(b=Og(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function vc(){var a;if(qc!=0){a=pc();if(a-rc>2000){rc=a;sc=$wnd.setTimeout(Bc,10)}}if(qc++==0){Ec((Dc(),Cc));return true}return false}
function Xc(a,b){if(ad(a)){return !!Wc[b]}else if(a.U){return !!a.U[b]}else if(_c(a)){return !!Vc[b]}else if($c(a)){return !!Uc[b]}return false}
function Mc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return ad(a)?o(a,b):_c(a)?bd(a)===bd(b):$c(a)?a===b:Yc(a)?a.k(b):Sc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):bd(a)===bd(b)}
function th(a){(df(),cf).bluetooth.requestDevice(gf(ff({}),$wnd.Array.from([ef({},$wnd.Array.from([oi]))]))).then(Ye(Zh.prototype.v,Zh,[a]))}
function eh(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function S(a){a.h?gb(a.e):fb(a.e);if(rb(a.f)){if(a.h&&(J(),!(!!Nb&&!!Nb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{lb(a.f)}}return V(a)}
function Wb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Vf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&qb(b,6,true)}}}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Vf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&qb(b,5,true)}}}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Vf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?qb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Bf(a,b){var c,d,e,f;f=Ef(a.a);b.length<f&&(b=Og(new Array(f),b));e=b;d=new Jf(a.a);for(c=0;c<f;++c){e[c]=If(d)}b.length>f&&(b[f]=null);return b}
function Rc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{Zb(b,d);try{f=(Q(c.a.a),null)}finally{$b()}return f}catch(a){a=Me(a);if(Zc(a,5)){e=a;throw Ne(e)}else throw Ne(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.n()}else{Zb(b,e);try{g=c.n()}finally{$b()}}return g}catch(a){a=Me(a);if(Zc(a,5)){f=a;throw Ne(f)}else throw Ne(a)}finally{D(b)}}
function Qh(a){var b,c;this.g=new Eh;this.e=a;J();++Mh;this.d=new ec(new Rh(this),new Sh(this),false);this.a=(c=new ib((b=null,b)),c);this.b=new tb(new Vh(this))}
function Eh(){var a,b;this.e=new Wh(this);this.f=new Yh(this);J();++zh;this.d=new ec(null,new Fh(this),true);this.b=(b=new ib((a=null,a)),b);this.a=new W(new Hh(this))}
function zb(a){var b,c;if(0==a.c){b=Jb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Ib(a.d);Fb(c);return true}
function Re(b,c,d,e){Qe();var f=Oe;$moduleName=c;$moduleBase=d;Le=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ii(g)()}catch(a){b(c,a)}}else{ii(g)()}}
function $g(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function fg(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return gg()}}
function Ic(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].W()&&(c=Hc(c,g)):g[0].W()}catch(a){a=Me(a);if(Zc(a,5)){d=a;tc();zc(Zc(d,22)?d.u():d)}else throw Ne(a)}}return c}
function Ue(){Te={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Q(b){var c,d,e;e=b.i;try{d=Dh(b.c.a);if(!(e==d||e!=null&&e==d)){b.i=d;b.b=null;db(b.e)}}catch(a){a=Me(a);if(Zc(a,7)){c=a;if(!b.b){b.i=null;b.b=c;db(b.e)}throw Ne(c)}else throw Ne(a)}}
function Kg(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Vg(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+xf(a,c++)}b=b|0;return b}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Qc(Qd,ji,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function lb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{Lh(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Me(a);if(Zc(a,5)){J()}else throw Ne(a)}}}
function sb(a,b,c,d){this.b=new Tf;this.f=new Hb(new wb(this),d&6520832|262144|ki);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&2097152)&&D((null,I)))}
function We(a,b,c){var d=Te,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Te[b]),Ze(h));_.U=c;!b&&(_.V=_e);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.T=f)}
function tf(a){if(a.D()){var b=a.c;b.F()?(a.j='['+b.i):!b.D()?(a.j='[L'+b.B()+';'):(a.j='['+b.B());a.b=b.A()+'[]';a.h=b.C()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=uf('.',[c,uf('$',d)]);a.b=uf('.',[c,uf('.',d)]);a.h=d[d.length-1]}
function Cf(a,b){var c,d,e,f,g;e=b.b.value[0];g=mg(b);f=e==null?Df(_f((d=a.a.a.get(0),d==null?new Array:d))):jg(a.b,e);if(!(bd(g)===bd(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!_f((c=a.a.a.get(0),c==null?new Array:c)):ig(a.b,e))){return false}return true}
function rb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Vf(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Me(a);if(!Zc(a,5))throw Ne(a)}if(6==(b.c&7)){return true}}}}}nb(b);return false}
function hc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.s();return a&&a.q()}},suppressed:{get:function(){return c.r()}}})}catch(a){}}}
function yh(a,b){if(null==b){a.g=null;dc(new Ih(a,0))}else{a.g=b.gatt;null!=a.g&&a.g.connect().then(Ye($h.prototype.v,$h,[a])).then(Ye(_h.prototype.v,_h,[])).then(Ye(Xh.prototype.v,Xh,[])).then(Ye(ai.prototype.v,ai,[a]));b.addEventListener('gattserverdisconnected',a.f)}A((J(),J(),I),new Gh(a),142606336)}
function ah(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Zg(b,Ye(dh.prototype.P,dh,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=$g($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function eg(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function qb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){hb(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.i=null}Mf(a.b,new yb(a));a.b.a=Qc(Qd,ji,1,0,5,1)}else 3==f&&(3&b)==0&&!!a.a&&(e=a.a.g,e)}}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Nf(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Rf(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&qb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Nf(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Pf(a.b,g)}e&&pb(a.e,a.b)}else{e&&pb(a.e,new Tf)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&ki!=(k.b.c&1835008)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function mh(a){var b,c,d,e,f,g,h;c=new $wnd.Object;d=Ch(a.g);if(d>0){jh(ih((c.animationName='beating',c)));c['animationTimingFunction']='ease-in';c['animationDuration']='0.8s'}b=S(a.g.a);e=kh(fh(eh(new $wnd.Object,Tc(Oc(Sd,1),ji,2,6,['heart'])),c));h=Ye(nh.prototype.R,nh,[]);e['onAnimationStart']=h;f=Ye(oh.prototype.R,oh,[]);e['onAnimationEnd']=f;g=Ye(ph.prototype.R,ph,[a]);e['onAnimationIteration']=g;return ah('div',eh(new $wnd.Object,Tc(Oc(Sd,1),ji,2,6,['container'])),[ah('div',eh(new $wnd.Object,Tc(Oc(Sd,1),ji,2,6,['hrm_panel'])),[ah('h1',null,['Heart Rate Monitor']),ah('img',e,null),0!=d?d:null,0!=d?(gb(a.a),a.c?' Expand':' Contract'):null,ah('button',hh(gh(new $wnd.Object,b),Ye(qh.prototype.Q,qh,[a])),['Start']),ah('button',hh(gh(new $wnd.Object,!b),Ye(rh.prototype.Q,rh,[a])),['Stop'])])])}
function gg(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!eg()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var ji={4:1},ki=1048576,li={14:1},mi='__noinit__',ni={4:1,7:1,6:1,5:1},oi='heart_rate';var _,Te,Oe,Le=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Ue();We(1,null,{},p);_.k=function(a){return o(this,a)};_.l=function(){return this.T};_.m=function(){return Qg(this)};_.equals=function(a){return this.k(a)};_.hashCode=function(){return this.m()};We(33,1,{},nf);_.w=function(a){var b;b=new nf;b.e=4;a>1?(b.c=rf(this,a-1)):(b.c=this);return b};_.A=function(){lf(this);return this.b};_.B=function(){return mf(this)};_.C=function(){lf(this);return this.h};_.D=function(){return (this.e&4)!=0};_.F=function(){return (this.e&1)!=0};_.e=0;_.g=0;var kf=1;var Qd=pf(1);var Jd=pf(33);We(75,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var gd=pf(75);We(24,1,{},G);_.n=function(){return this.a.o(),null};var ed=pf(24);We(76,1,{},H);var fd=pf(76);var I;We(27,1,{27:1},P);_.b=0;_.c=false;_.d=0;var hd=pf(27);We(121,1,{});var ld=pf(121);We(85,121,{},W);_.a=false;_.d=0;_.h=false;var kd=pf(85);We(86,1,{},X);_.n=function(){return T(this.a)};var jd=pf(86);We(23,121,{23:1},ib);_.a=4;_.d=false;_.e=0;var nd=pf(23);We(78,1,li,jb);_.o=function(){ab(this.a)};var md=pf(78);We(19,121,{19:1},tb,ub);_.c=0;var sd=pf(19);We(79,1,{},vb);var od=pf(79);We(80,1,li,wb);_.o=function(){lb(this.a)};var pd=pf(80);We(81,1,li,xb);_.o=function(){ob(this.a)};var qd=pf(81);We(82,1,{},yb);_.p=function(a){mb(this.a,a)};var rd=pf(82);We(100,1,{},Bb);_.a=0;_.b=0;_.c=0;var td=pf(100);We(89,1,{},Db);_.a=false;var ud=pf(89);We(38,121,{38:1},Hb);_.a=0;var wd=pf(38);We(99,1,{},Mb);var vd=pf(99);We(94,1,{},Yb);_.a=0;var Nb;var xd=pf(94);We(37,1,{},ec);_.g=0;var zd=pf(37);We(77,1,li,fc);_.o=function(){cc(this.a)};var yd=pf(77);We(5,1,{4:1,5:1});_.q=pi;_.r=function(){var a,b;return a=Bg(Ag(Xf((this.e==null&&(this.e=Qc(Td,ji,5,0,0,1)),this.e))),(b=new Tf,b)),Sf(a,Qc(Qd,ji,1,a.a.length,5,1))};_.s=qi;_.t=function(){ic(this,kc(new Error(jc(this,this.d))));Lc(this)};_.b=mi;_.f=true;var Td=pf(5);We(7,5,{4:1,7:1,5:1});var Ld=pf(7);We(6,7,ni);var Rd=pf(6);We(48,6,ni);var Od=pf(48);We(49,48,ni);var Dd=pf(49);We(22,49,{22:1,4:1,7:1,6:1,5:1},oc);_.u=function(){return bd(this.a)===bd(mc)?null:this.a};var mc;var Ad=pf(22);var Bd=pf(0);We(104,1,{});var Cd=pf(104);var qc=0,rc=0,sc=-1;We(55,104,{},Gc);var Cc;var Ed=pf(55);var Jc;We(116,1,{});var Gd=pf(116);We(50,116,{},Nc);var Fd=pf(50);var Uc,Vc,Wc;var bf,cf;We(52,6,ni);var Nd=pf(52);We(83,52,ni,hf);var Hd=pf(83);Uc={4:1,44:1,42:1};var Id=pf(44);We(114,1,ji);var Pd=pf(114);Vc={4:1,42:1};var Kd=pf(115);We(51,6,ni,wf);var Md=pf(51);We(174,1,{});Wc={4:1,43:1,42:1,2:1};var Sd=pf(2);We(178,1,{});We(35,6,ni,zf);var Ud=pf(35);We(117,1,{29:1});_.G=function(a){throw Ne(new zf('Add not supported on this collection'))};var Vd=pf(117);We(120,1,{102:1});_.k=function(a){var b,c,d;if(a===this){return true}if(!Zc(a,25)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Jf((new Gf(d)).a);c.b;){b=If(c);if(!Cf(this,b)){return false}}return true};_.m=function(){return Yf(new Gf(this))};var _d=pf(120);We(84,120,{102:1});var Yd=pf(84);We(119,117,{29:1,126:1});_.k=function(a){var b;if(a===this){return true}if(!Zc(a,17)){return false}b=a;if(Ef(b.a)!=this.H()){return false}return Af(this,b)};_.m=function(){return Yf(this)};var ae=pf(119);We(17,119,{17:1,29:1,126:1},Gf);_.H=function(){return Ef(this.a)};var Xd=pf(17);We(18,1,{},Jf);_.J=function(){return If(this)};_.I=pi;_.b=false;var Wd=pf(18);We(118,117,{29:1,123:1});_.K=function(a,b){throw Ne(new zf('Add not supported on this list'))};_.G=function(a){this.K(this.H(),a);return true};_.k=function(a){var b,c,d,e,f;if(a===this){return true}if(!Zc(a,9)){return false}f=a;if(this.H()!=f.a.length){return false}e=new Vf(f);for(c=new Vf(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(bd(b)===bd(d)||b!=null&&q(b,d))){return false}}return true};_.m=function(){return Zf(this)};var Zd=pf(118);We(122,1,{127:1});_.k=function(a){var b;if(!Zc(a,26)){return false}b=a;return og(this.b.value[0],b.b.value[0])&&og(mg(this),mg(b))};_.m=function(){return pg(this.b.value[0])^pg(mg(this))};var $d=pf(122);We(9,118,{4:1,9:1,29:1,123:1},Tf,Uf);_.K=function(a,b){Lg(this.a,a,b)};_.G=function(a){return Lf(this,a)};_.H=function(){return this.a.length};var ce=pf(9);We(11,1,{},Vf);_.I=function(){return this.a<this.c.a.length};_.J=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var be=pf(11);We(25,84,{4:1,25:1,102:1},$f);var de=pf(25);We(92,1,{},ag);_.b=0;var fe=pf(92);We(93,1,{},bg);_.J=function(){return this.d=this.a[this.c++],this.d};_.I=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ee=pf(93);var cg;We(90,1,{},kg);_.b=0;_.c=0;var ie=pf(90);We(91,1,{},lg);_.J=function(){return this.c=this.a,this.a=this.b.next(),new ng(this.d,this.c,this.d.c)};_.I=function(){return !this.a.done};var ge=pf(91);We(26,122,{26:1,127:1},ng);_.c=0;var he=pf(26);We(60,1,{});_.N=ri;_.L=pi;_.M=qi;_.b=0;_.c=0;var me=pf(60);We(61,60,{});var je=pf(61);We(56,1,{});_.N=ri;_.L=pi;_.M=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var le=pf(56);We(57,56,{},wg);_.N=function(a){tg(this,a)};_.O=function(a){return ug(this,a)};var ke=pf(57);We(59,1,{});_.c=false;var se=pf(59);We(36,59,{},Cg);var re=pf(36);We(62,61,{},Fg);_.O=function(a){return this.a.O(new Gg(a))};var oe=pf(62);We(64,1,{},Gg);_.p=function(a){this.a.p(a.b)};var ne=pf(64);We(63,1,{},Ig);_.p=function(a){Hg(this,a)};var pe=pf(63);We(65,1,{},Jg);_.p=function(a){Eg(this.a,a)};var qe=pf(65);We(176,1,{});We(173,1,{});var Pg=0;var Rg,Sg=0,Tg;We(780,1,{});We(805,1,{});We(157,$wnd.Function,{},dh);_.P=function(a){bh(this.a,this.b,a)};We(67,1,{});var ue=pf(67);We(147,$wnd.Function,{},nh);_.R=si;We(148,$wnd.Function,{},oh);_.R=si;We(149,$wnd.Function,{},ph);_.R=function(a){lh(this.a,a)};We(150,$wnd.Function,{},qh);_.Q=function(a){th(this.a.g)};We(151,$wnd.Function,{},rh);_.Q=function(a){uh(this.a.g)};We(41,1,{},sh);var te=pf(41);We(95,1,{});var Ie=pf(95);We(96,95,{},Eh);_.c=0;var zh=0;var ze=pf(96);We(97,1,li,Fh);_.o=function(){Ah(this.a)};var ve=pf(97);We(40,1,li,Gh);_.o=function(){U(this.a.a)};var we=pf(40);We(98,1,{},Hh);_.n=function(){return Dh(this.a)};var xe=pf(98);We(39,1,li,Ih);_.o=function(){Bh(this.a,this.b)};_.b=0;var ye=pf(39);We(68,67,{});_.f=0;var Ke=pf(68);We(69,68,{},Qh);_.c=false;var Mh=0;var Fe=pf(69);We(70,1,li,Rh);_.o=function(){Y(this.a.g)};var Ae=pf(70);We(71,1,li,Sh);_.o=function(){Nh(this.a)};var Be=pf(71);We(73,1,li,Th);_.o=function(){Oh(this.a,this.b)};_.b=false;var Ce=pf(73);We(74,1,{},Uh);_.n=function(){return Kh(this.a)};var De=pf(74);We(72,1,{},Vh);var Ee=pf(72);We(87,1,{},Wh);_.handleEvent=function(a){xh(this.a,a)};var Ge=pf(87);We(155,$wnd.Function,{},Xh);_.v=function(a){return a.startNotifications()};We(88,1,{},Yh);_.handleEvent=function(a){yh(this.a,null)};var He=pf(88);We(152,$wnd.Function,{},Zh);_.v=function(a){return yh(this.a,a),null};We(153,$wnd.Function,{},$h);_.v=function(a){return vh(this.a,a)};We(154,$wnd.Function,{},_h);_.v=function(a){return a.getCharacteristic('heart_rate_measurement')};We(156,$wnd.Function,{},ai);_.v=function(a){return wh(this.a,a)};We(144,$wnd.Function,{},bi);_.S=function(a){return new ei(a)};var ci;We(58,$wnd.React.Component,{},ei);Ve(Te[1],_);_.componentWillUnmount=function(){Jh(this.a)};_.render=function(){return Ph(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.f};var Je=pf(58);var fi;We(158,$wnd.Function,{},hi);_.v=function(a){return Cb(fi),fi=null,null};var dd=qf('D');var ii=(tc(),wc);var gwtOnLoad=gwtOnLoad=Re;Pe(af);Se('permProps',[[]]);if (hrm) hrm.onScriptLoad(gwtOnLoad);})();