function hrm(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='hrm',tb='__gwt_marker_hrm',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='FE8310355B7A8491CFBC2D60D670694A',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};hrm.onScriptLoad=function(a){hrm=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
hrm();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'FE8310355B7A8491CFBC2D60D670694A';function p(){}
function af(){}
function Ye(){}
function Eb(){}
function Hc(){}
function Oc(){}
function Ig(){}
function Nh(){}
function Ph(){}
function Rh(){}
function Th(){}
function Uh(){}
function $h(){}
function Mc(a){Lc()}
function jf(){jf=Ye}
function Tf(){Kf(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function wb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function gc(a){this.a=a}
function Gf(a){this.a=a}
function Gg(a){this.a=a}
function Jg(a){this.a=a}
function ih(a){this.a=a}
function jh(a){this.a=a}
function xh(a){this.a=a}
function zh(a){this.a=a}
function Ah(a){this.a=a}
function Hh(a){this.a=a}
function Ih(a){this.a=a}
function Jh(a){this.a=a}
function Kh(a){this.a=a}
function Lh(a){this.a=a}
function Mh(a){this.a=a}
function Oh(a){this.a=a}
function Qh(a){this.a=a}
function Sh(a){this.a=a}
function Vf(a){this.c=a}
function ag(){this.a=hg()}
function kg(){this.a=hg()}
function Hg(a,b){a.a=b}
function qb(a,b){a.b=b}
function Zg(a,b){Yg(a,b)}
function ii(a){qg(this,a)}
function ib(a){Yb((K(),a))}
function eb(a){Wb((K(),a))}
function fb(a){Xb((K(),a))}
function w(a){--a.e;D(a)}
function Z(a){!!a&&ac(a.d)}
function bc(a){!!a&&a.n()}
function Oe(a){return a.b}
function ji(a){return null}
function gi(){return this.b}
function hi(){return this.c}
function hf(a){mc.call(this,a)}
function zf(a){mc.call(this,a)}
function Bh(a){a.d=2;ac(a.b)}
function sh(a){S(a.a);ab(a.b)}
function L(a,b){P(a);M(a,b)}
function jc(a,b){a.b=b;ic(a,b)}
function Ng(a,b){a.splice(b,1)}
function C(a,b){Mb(a.f,b.f)}
function vg(a,b,c){b.p(a.a[c])}
function Nf(a,b){return a.a[b]}
function Pc(a,b){return rf(a,b)}
function mf(a){lf(a);return a.j}
function hg(){dg();return new cg}
function Dg(a,b){a.J(b);return a}
function qg(a,b){while(a.R(b));}
function Eg(a,b){Hg(a,Dg(a.a,b))}
function v(a,b,c){t(a,new I(c),b)}
function K(){K=Ye;J=new F}
function oc(){oc=Ye;nc=new p}
function Ec(){Ec=Ye;Dc=new Hc}
function dg(){dg=Ye;cg=fg()}
function uc(){uc=Ye;!!(Lc(),Kc)}
function Cc(){rc!=0&&(rc=0);tc=-1}
function bb(a){K();Xb(a);a.e=-2}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function U(a){mb(a.f);return W(a)}
function uh(a){gb(a.b);return a.c}
function jg(a,b){return a.a.get(b)}
function Ef(a){return a.a.b+a.b.b}
function Sb(a){return !a.d?a:Sb(a.d)}
function Df(a){return !a?null:mg(a)}
function cd(a){return a==null?null:a}
function pg(a){return a!=null?s(a):0}
function o(a,b){return cd(a)===cd(b)}
function Lg(a,b,c){a.splice(b,0,c)}
function dh(a,b){this.a=a;this.b=b}
function yh(a,b){this.a=a;this.b=b}
function Cb(a){this.d=a;this.b=100}
function jb(a){this.c=new Tf;this.b=a}
function kh(){this.a=_g((Wh(),Vh))}
function Re(){Pe==null&&(Pe=[])}
function Bc(a){$wnd.clearTimeout(a)}
function Kf(a){a.a=Rc(Sd,bi,1,0,5,1)}
function pb(a){K();ob(a);rb(a,2,true)}
function Mg(a,b){Kg(b,0,a,0,b.length)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function xf(a,b){return a.charCodeAt(b)}
function Qg(a){return a.$H||(a.$H=++Pg)}
function $(a){return !(!!a&&1==(a.c&7))}
function $c(a,b){return a!=null&&Yc(a,b)}
function Yg(a,b){for(var c in a){b(c)}}
function gh(a,b){a.onClick=b;return a}
function gf(a,b){a.filters=b;return a}
function ef(a,b){a.services=b;return a}
function fh(a,b){a.disabled=b;return a}
function lf(a){if(a.j!=null){return}tf(a)}
function gb(a){var b;Tb((K(),b=Ob,b),a)}
function Q(){this.a=Rc(Sd,bi,1,100,5,1)}
function mc(a){this.d=a;hc(this);this.t()}
function Cg(a,b){zg.call(this,a);this.a=b}
function Ug(){Ug=Ye;Rg=new p;Tg=new p}
function $f(){this.a=new ag;this.b=new kg}
function mh(a){null!=a.g&&a.g.disconnect()}
function Fb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&rb(a.f,5,true)}
function hc(a){a.f&&a.b!==di&&a.t();return a}
function pf(a){var b;b=of(a);vf(a,b);return b}
function hh(a){a.src='img/heart.svg';return a}
function Lf(a,b){a.a[a.a.length]=b;return true}
function ng(a,b,c){this.a=a;this.b=b;this.c=c}
function Lb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function vc(a,b,c){return a.apply(b,c);var d}
function bd(a){return typeof a==='string'}
function ad(a){return typeof a==='number'}
function _c(a){return typeof a==='boolean'}
function Tc(a){return Array.isArray(a)&&a.X===af}
function Bb(a){while(true){if(!Ab(a)){break}}}
function tg(a,b){while(a.c<a.d){vg(a,b,a.c++)}}
function nb(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Mb(a,b){Lb(a,((b.a&229376)>>15)-1,b)}
function Db(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function ec(a){K();Ob?th(a.a,a.b):A((null,J),a,0)}
function If(a){var b;b=a.a.M();a.b=Hf(a);return b}
function qf(a){var b;b=of(a);b.i=a;b.e=1;return b}
function Pf(a,b){var c;c=a.a[b];Ng(a.a,b);return c}
function Ic(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ff(a){a.acceptAllDevices=false;return a}
function Lc(){Lc=Ye;var a;!Nc();a=new Oc;Kc=a}
function Ag(a){yg(a);return new Cg(a,new Fg(a.a))}
function Xf(a){return new Cg(null,Wf(a,a.length))}
function Fh(a){return B((K(),K(),J),a.a,new Jh(a))}
function Wf(a,b){return rg(b,a.length),new wg(a,b)}
function ig(a,b){return !(a.a.get(b)===undefined)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Zc(a){return !Array.isArray(a)&&a.X===af}
function Ff(a,b){if(b){return Cf(a.a,b)}return false}
function Rf(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function th(a,b){var c;c=a.c;if(b!=c){a.c=b;fb(a.b)}}
function og(a,b){return cd(a)===cd(b)||a!=null&&q(a,b)}
function sg(a,b){this.c=a;this.b=(b&64)!=0?b|16384:b}
function wg(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Zb(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function Fg(a){sg.call(this,a.P(),a.O()&-6);this.a=a}
function ub(a){tb.call(this,null,null,a,1411780608)}
function vb(a){tb.call(this,a,new wb(a),null,304611328)}
function zg(a){if(!a){this.b=null;new Tf}else{this.b=a}}
function xg(a){if(!a.b){yg(a);a.c=true}else{xg(a.b)}}
function Dh(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Xg(){if(Sg==256){Rg=Tg;Tg=new p;Sg=0}++Sg}
function df(){df=Ye;cf=$wnd.goog.global.document}
function hb(a){var b;K();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function Wh(){Wh=Ye;var a;Vh=(a=Ze(Uh.prototype.U,Uh,[]),a)}
function F(){this.f=new Nb;this.a=new Cb(this.f);new G(this.a)}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function $e(a){function b(){}
;b.prototype=a||{};return new b}
function sf(a){if(a.I()){return null}var b=a.i;return Ue[b]}
function Pb(a){if(a.e){2==(a.e.c&7)||rb(a.e,4,true);ob(a.e)}}
function yg(a){if(a.b){yg(a.b)}else if(a.c){throw Oe(new wf)}}
function Ac(a){uc();$wnd.setTimeout(function(){throw a},0)}
function kc(a,b){var c;c=mf(a.V);return b==null?c:c+': '+b}
function rf(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.C(b))}
function We(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function bh(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function dc(a){bc(a.f);!!a.d&&cc(a);Z(a.a);Z(a.c);bc(a.b);bc(a.e)}
function Uf(a){Kf(this);Mg(this.a,Bf(a,Rc(Sd,bi,1,Ef(a.a),5,1)))}
function bg(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Xh(a){$wnd.React.Component.call(this,a);this.a=new Gh(this)}
function oh(a,b){b.addEventListener('characteristicvaluechanged',a.e)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function ug(a,b){if(a.c<a.d){vg(a,b,a.c++);return true}return false}
function vh(a){return jf(),null!=a.g&&a.g.connected?true:false}
function dd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function zc(a){a&&Gc((Ec(),Dc));--rc;if(a){if(tc!=-1){Bc(tc);tc=-1}}}
function yc(a,b,c){var d;d=wc();try{return vc(a,b,c)}finally{zc(d)}}
function cb(a,b){var c,d;Lf(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function ph(a,b){var c,d;c=b.target;d=c.value;ec(new yh(a,d.getInt8(1)))}
function Bg(a,b){var c;xg(a);c=new Ig;c.a=b;a.a.Q(new Jg(c));return c.a}
function Kb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Mf(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.p(c)}}
function lg(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Jf(a){this.d=a;this.c=new lg(this.d.b);this.a=this.c;this.b=Hf(this)}
function Nb(){var a;this.a=Rc(kd,bi,23,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function Hb(b){try{mb(b.b.a)}catch(a){a=Ne(a);if(!$c(a,4))throw Oe(a)}}
function ab(a){if(-2!=a.e){A((K(),K(),J),new kb(a),0);!!a.b&&lb(a.b)}}
function ac(a){if(a.g>=0){a.g=-2;u((K(),K(),J),new H(new gc(a)),67108864,null)}}
function qc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function xc(b){uc();return function(){return yc(b,this,arguments);var a}}
function lc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function W(a){if(a.b){if($c(a.b,6)){throw Oe(a.b)}else{throw Oe(a.b)}}return a.i}
function mg(a){if(a.a.c!=a.c){return jg(a.a,a.b.value[0])}return a.b.value[1]}
function Of(a,b,c){for(;c<a.a.length;++c){if(og(b,a.a[c])){return c}}return -1}
function Qf(a,b){var c;c=Of(a,b,0);if(c==-1){return false}Ng(a.a,c);return true}
function Rc(a,b,c,d,e,f){var g;g=Sc(e,d);e!=10&&Uc(Pc(a,f),b,c,e,g);return g}
function Og(a,b){return Qc(b)!=10&&Uc(r(b),b.W,b.__elementTypeId$,Qc(b),a),a}
function Qc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function S(a){if(!a.a){a.a=true;a.i=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Bb(a.a)}finally{a.c=false}}}}
function Fc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Jc(b,c)}while(a.a);a.a=c}}
function Gc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Jc(b,c)}while(a.b);a.b=c}}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Tf);Lf(a.b,b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new Tf);a.c=c.c}b.d=true;Lf(a.c,b)}
function vf(a,b){var c;if(!a){return}b.i=a;var d=sf(b);if(!d){Ue[a]=[b];return}d.V=b}
function Ze(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function of(a){var b;b=new nf;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function _g(a){var b;b=$g($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function _b(){var a;try{Qb(Ob);K()}finally{a=Ob.d;!a&&((K(),K(),J).d=true);Ob=Ob.d}}
function ob(a){var b,c;for(c=new Vf(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Af(a,b){var c,d;for(d=new Jf(b.a);d.b;){c=If(d);if(!Ff(a,c)){return false}}return true}
function nh(a,b){A((K(),K(),J),new zh(a),142606336);return b.getPrimaryService(fi)}
function wf(){mc.call(this,"Stream already terminated, can't be modified or used")}
function pc(a){oc();hc(this);this.b=a;ic(this,a);this.d=a==null?'null':_e(a);this.a=a}
function fc(a,b,c){this.d=c?new $f:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function X(a){this.c=a;this.g=null;this.i=null;this.h=false;this.f=new vb(this);this.e=new jb(this.f)}
function Hf(a){if(a.a.L()){return true}if(a.a!=a.c){return false}a.a=new bg(a.d.a);return a.a.L()}
function Ne(a){var b;if($c(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new pc(a);Mc(b)}return b}
function Uc(a,b,c,d,e){e.V=a;e.W=b;e.X=af;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function bf(){$wnd.ReactDOM.render((new kh).a,(df(),cf).getElementById('app'),null)}
function Qe(){Re();var a=Pe;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function rg(a,b){if(0>a||a>b){throw Oe(new hf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Ib(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function Te(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function _f(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function Yf(a){var b,c,d;d=0;for(c=new Jf(a.a);c.b;){b=If(c);d=d+(b?pg(b.b.value[0])^pg(mg(b)):0);d=d|0}return d}
function cc(a){var b,c;for(c=new Vf(new Uf(new Gf(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);mg(b).n()}}
function db(a,b){var c,d;d=a.c;Qf(d,b);!!a.b&&ci!=(a.b.c&1835008)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((K(),c=Ob,c),a))}
function Gb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&ci)?Hb(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new yb(a)),67108864,null);!!a.a&&S(a.a);Fb(a.f);a.c=a.c&-8|1}}
function Zh(){if(!Yh){Yh=(++(K(),K(),J).e,new Eb);$wnd.Promise.resolve(null).then(Ze($h.prototype.v,$h,[]))}}
function nf(){this.g=kf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function Gh(a){this.e=new wh;this.c=a;K();++Eh;this.b=new fc(new Hh(this),new Ih(this),false);this.a=new ub(new Kh(this))}
function _e(a){var b;if(Array.isArray(a)&&a.X===af){return mf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function r(a){return bd(a)?Ud:ad(a)?Md:_c(a)?Kd:Zc(a)?a.V:Tc(a)?a.V:a.V||Array.isArray(a)&&Pc(Dd,1)||Dd}
function s(a){return bd(a)?Wg(a):ad(a)?dd(a):_c(a)?a?1231:1237:Zc(a)?a.m():Tc(a)?Qg(a):!!a&&!!a.hashCode?a.hashCode():Qg(a)}
function q(a,b){return bd(a)?o(a,b):ad(a)?cd(a)===cd(b):_c(a)?a===b:Zc(a)?a.k(b):Tc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):cd(a)===cd(b)}
function Wg(a){Ug();var b,c,d;c=':'+a;d=Tg[c];if(d!=null){return dd(d)}d=Rg[c];b=d==null?Vg(a):dd(d);Xg();Tg[c]=b;return b}
function Zf(a){var b,c,d;d=1;for(c=new Vf(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Jb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Ub(a){var b;if(a.c){while(a.c.a.length!=0){b=Pf(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&rb(b.b,3,true)}}}
function Xb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Vf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&rb(b,6,true)}}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Vf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&rb(b,5,true)}}}
function uf(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Sf(a,b){var c,d;d=a.a.length;b.length<d&&(b=Og(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Bf(a,b){var c,d,e,f;f=Ef(a.a);b.length<f&&(b=Og(new Array(f),b));e=b;d=new Jf(a.a);for(c=0;c<f;++c){e[c]=If(d)}b.length>f&&(b[f]=null);return b}
function wc(){var a;if(rc!=0){a=qc();if(a-sc>2000){sc=a;tc=$wnd.setTimeout(Cc,10)}}if(rc++==0){Fc((Ec(),Dc));return true}return false}
function Yc(a,b){if(bd(a)){return !!Xc[b]}else if(a.W){return !!a.W[b]}else if(ad(a)){return !!Wc[b]}else if(_c(a)){return !!Vc[b]}return false}
function Nc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function eh(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function lh(a){$wnd['navigator'].bluetooth.requestDevice(gf(ff({}),[ef({},[fi])])).then(Ze(Mh.prototype.w,Mh,[a])).catch(Ze(Ph.prototype.B,Ph,[]))}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function T(a){a.h?hb(a.e):gb(a.e);if(sb(a.f)){if(a.h&&(K(),!(!!Ob&&!!Ob.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{mb(a.f)}}return W(a)}
function Sc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{$b(b,d);try{f=(R(c.a.a),null)}finally{_b()}return f}catch(a){a=Ne(a);if($c(a,4)){e=a;throw Oe(e)}else throw Oe(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.o()}else{$b(b,e);try{g=c.o()}finally{_b()}}return g}catch(a){a=Ne(a);if($c(a,4)){f=a;throw Oe(f)}else throw Oe(a)}finally{D(b)}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Vf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?rb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Ab(a){var b,c;if(0==a.c){b=Kb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Jb(a.d);Gb(c);return true}
function Se(b,c,d,e){Re();var f=Pe;$moduleName=c;$moduleBase=d;Me=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{_h(g)()}catch(a){b(c,a)}}else{_h(g)()}}
function wh(){var a,b;this.e=new Lh(this);this.f=new Oh(this);K();++rh;this.d=new fc(null,new xh(this),true);this.b=(b=new jb((a=null,a)),b);this.a=new X(new Ah(this))}
function $g(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function fg(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return gg()}}
function Jc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Y()&&(c=Ic(c,g)):g[0].Y()}catch(a){a=Ne(a);if($c(a,4)){d=a;uc();Ac($c(d,21)?d.u():d)}else throw Oe(a)}}return c}
function Ve(){Ue={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function R(b){var c,d,e;e=b.i;try{d=vh(b.c.a);if(!(e==d||e!=null&&e==d)){b.i=d;b.b=null;eb(b.e)}}catch(a){a=Ne(a);if($c(a,7)){c=a;if(!b.b){b.i=null;b.b=c;eb(b.e)}throw Oe(c)}else throw Oe(a)}}
function Kg(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Vg(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+xf(a,c++)}b=b|0;return b}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Rc(Sd,bi,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{Dh(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Ne(a);if($c(a,4)){K()}else throw Oe(a)}}}
function tb(a,b,c,d){this.b=new Tf;this.f=new Ib(new xb(this),d&6520832|262144|ci);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&2097152)&&D((null,J)))}
function Xe(a,b,c){var d=Ue,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Ue[b]),$e(h));_.W=c;!b&&(_.X=af);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.V=f)}
function tf(a){if(a.H()){var b=a.c;b.I()?(a.j='['+b.i):!b.H()?(a.j='[L'+b.F()+';'):(a.j='['+b.F());a.b=b.D()+'[]';a.h=b.G()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=uf('.',[c,uf('$',d)]);a.b=uf('.',[c,uf('.',d)]);a.h=d[d.length-1]}
function Cf(a,b){var c,d,e,f,g;e=b.b.value[0];g=mg(b);f=e==null?Df(_f((d=a.a.a.get(0),d==null?new Array:d))):jg(a.b,e);if(!(cd(g)===cd(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!_f((c=a.a.a.get(0),c==null?new Array:c)):ig(a.b,e))){return false}return true}
function sb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Vf(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Ne(a);if(!$c(a,4))throw Oe(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function ic(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.s();return a&&a.q()}},suppressed:{get:function(){return c.r()}}})}catch(a){}}}
function ah(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Zg(b,Ze(dh.prototype.S,dh,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=$g($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function eg(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function qh(a,b){if(null==b){a.g=null;ec(new yh(a,0))}else{a.g=b.gatt;null!=a.g&&a.g.connect().then(Ze(Qh.prototype.A,Qh,[a])).then(Ze(Rh.prototype.A,Rh,[])).then(Ze(Nh.prototype.A,Nh,[])).then(Ze(Sh.prototype.w,Sh,[a])).catch(Ze(Th.prototype.B,Th,[]));b.addEventListener('gattserverdisconnected',a.f)}A((K(),K(),J),new zh(a),142606336)}
function rb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==f&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.i=null}Mf(a.b,new zb(a));a.b.a=Rc(Sd,bi,1,0,5,1)}else 3==f&&(3&b)==0&&!!a.a&&(e=a.a.g,e)}}
function Ch(a){var b,c,d;a.d=0;Zh();b=(c=uh(a.e),d=T(a.e.a),ah('div',eh(new $wnd.Object,Uc(Pc(Ud,1),bi,2,6,['container'])),[ah('div',eh(new $wnd.Object,Uc(Pc(Ud,1),bi,2,6,['hrm_panel'])),[ah('h1',null,['Heart Rate Monitor']),ah('img',hh(eh(new $wnd.Object,Uc(Pc(Ud,1),bi,2,6,['heart',c>0?'beating':null]))),null),0!=c?c:null,ah('button',gh(fh(new $wnd.Object,d),Ze(ih.prototype.T,ih,[a])),['Start']),ah('button',gh(fh(new $wnd.Object,!d),Ze(jh.prototype.T,jh,[a])),['Stop'])])]));return b}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Nf(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Rf(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&rb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Nf(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Pf(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Tf)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&ci!=(k.b.c&1835008)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function gg(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!eg()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var ai={12:1},bi={3:1},ci=1048576,di='__noinit__',ei={3:1,7:1,6:1,4:1},fi='heart_rate';var _,Ue,Pe,Me=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Ve();Xe(1,null,{},p);_.k=function(a){return o(this,a)};_.l=function(){return this.V};_.m=function(){return Qg(this)};_.equals=function(a){return this.k(a)};_.hashCode=function(){return this.m()};Xe(32,1,{},nf);_.C=function(a){var b;b=new nf;b.e=4;a>1?(b.c=rf(this,a-1)):(b.c=this);return b};_.D=function(){lf(this);return this.b};_.F=function(){return mf(this)};_.G=function(){lf(this);return this.h};_.H=function(){return (this.e&4)!=0};_.I=function(){return (this.e&1)!=0};_.e=0;_.g=0;var kf=1;var Sd=pf(1);var Ld=pf(32);Xe(52,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var jd=pf(52);Xe(53,1,ai,G);_.n=function(){Bb(this.a)};var fd=pf(53);Xe(22,1,{},H);_.o=function(){return this.a.n(),null};var gd=pf(22);Xe(54,1,{},I);var hd=pf(54);var J;Xe(23,1,{23:1},Q);_.b=0;_.c=false;_.d=0;var kd=pf(23);Xe(122,1,{});var nd=pf(122);Xe(90,122,{},X);_.a=false;_.d=0;_.h=false;var md=pf(90);Xe(91,1,{},Y);_.o=function(){return U(this.a)};var ld=pf(91);Xe(26,122,{26:1},jb);_.a=4;_.d=false;_.e=0;var pd=pf(26);Xe(89,1,ai,kb);_.n=function(){bb(this.a)};var od=pf(89);Xe(18,122,{18:1},ub,vb);_.c=0;var ud=pf(18);Xe(84,1,{},wb);var qd=pf(84);Xe(85,1,ai,xb);_.n=function(){mb(this.a)};var rd=pf(85);Xe(86,1,ai,yb);_.n=function(){pb(this.a)};var sd=pf(86);Xe(87,1,{},zb);_.p=function(a){nb(this.a,a)};var td=pf(87);Xe(62,1,{},Cb);_.a=0;_.b=0;_.c=0;var vd=pf(62);Xe(94,1,{},Eb);_.a=false;var wd=pf(94);Xe(36,122,{36:1},Ib);_.a=0;var yd=pf(36);Xe(61,1,{},Nb);var xd=pf(61);Xe(95,1,{},Zb);_.a=0;var Ob;var zd=pf(95);Xe(37,1,{},fc);_.g=0;var Bd=pf(37);Xe(83,1,ai,gc);_.n=function(){dc(this.a)};var Ad=pf(83);Xe(4,1,{3:1,4:1});_.q=gi;_.r=function(){var a,b;return a=Bg(Ag(Xf((this.e==null&&(this.e=Rc(Vd,bi,4,0,0,1)),this.e))),(b=new Tf,b)),Sf(a,Rc(Sd,bi,1,a.a.length,5,1))};_.s=hi;_.t=function(){jc(this,lc(new Error(kc(this,this.d))));Mc(this)};_.b=di;_.f=true;var Vd=pf(4);Xe(7,4,{3:1,7:1,4:1});var Nd=pf(7);Xe(6,7,ei);var Td=pf(6);Xe(47,6,ei);var Qd=pf(47);Xe(48,47,ei);var Fd=pf(48);Xe(21,48,{21:1,3:1,7:1,6:1,4:1},pc);_.u=function(){return cd(this.a)===cd(nc)?null:this.a};var nc;var Cd=pf(21);var Dd=pf(0);Xe(104,1,{});var Ed=pf(104);var rc=0,sc=0,tc=-1;Xe(57,104,{},Hc);var Dc;var Gd=pf(57);var Kc;Xe(116,1,{});var Id=pf(116);Xe(49,116,{},Oc);var Hd=pf(49);var Vc,Wc,Xc;var cf;Xe(51,6,ei);var Pd=pf(51);Xe(88,51,ei,hf);var Jd=pf(88);Vc={3:1,43:1,41:1};var Kd=pf(43);Xe(114,1,bi);var Rd=pf(114);Wc={3:1,41:1};var Md=pf(115);Xe(50,6,ei,wf);var Od=pf(50);Xe(174,1,{});Xc={3:1,42:1,41:1,2:1};var Ud=pf(2);Xe(178,1,{});Xe(34,6,ei,zf);var Wd=pf(34);Xe(117,1,{28:1});_.J=function(a){throw Oe(new zf('Add not supported on this collection'))};var Xd=pf(117);Xe(120,1,{101:1});_.k=function(a){var b,c,d;if(a===this){return true}if(!$c(a,24)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Jf((new Gf(d)).a);c.b;){b=If(c);if(!Cf(this,b)){return false}}return true};_.m=function(){return Yf(new Gf(this))};var be=pf(120);Xe(63,120,{101:1});var $d=pf(63);Xe(119,117,{28:1,126:1});_.k=function(a){var b;if(a===this){return true}if(!$c(a,16)){return false}b=a;if(Ef(b.a)!=this.K()){return false}return Af(this,b)};_.m=function(){return Yf(this)};var ce=pf(119);Xe(16,119,{16:1,28:1,126:1},Gf);_.K=function(){return Ef(this.a)};var Zd=pf(16);Xe(17,1,{},Jf);_.M=function(){return If(this)};_.L=gi;_.b=false;var Yd=pf(17);Xe(118,117,{28:1,123:1});_.N=function(a,b){throw Oe(new zf('Add not supported on this list'))};_.J=function(a){this.N(this.K(),a);return true};_.k=function(a){var b,c,d,e,f;if(a===this){return true}if(!$c(a,9)){return false}f=a;if(this.K()!=f.a.length){return false}e=new Vf(f);for(c=new Vf(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(cd(b)===cd(d)||b!=null&&q(b,d))){return false}}return true};_.m=function(){return Zf(this)};var _d=pf(118);Xe(121,1,{127:1});_.k=function(a){var b;if(!$c(a,25)){return false}b=a;return og(this.b.value[0],b.b.value[0])&&og(mg(this),mg(b))};_.m=function(){return pg(this.b.value[0])^pg(mg(this))};var ae=pf(121);Xe(9,118,{3:1,9:1,28:1,123:1},Tf,Uf);_.N=function(a,b){Lg(this.a,a,b)};_.J=function(a){return Lf(this,a)};_.K=function(){return this.a.length};var ee=pf(9);Xe(11,1,{},Vf);_.L=function(){return this.a<this.c.a.length};_.M=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var de=pf(11);Xe(24,63,{3:1,24:1,101:1},$f);var fe=pf(24);Xe(64,1,{},ag);_.b=0;var he=pf(64);Xe(65,1,{},bg);_.M=function(){return this.d=this.a[this.c++],this.d};_.L=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ge=pf(65);var cg;Xe(66,1,{},kg);_.b=0;_.c=0;var ke=pf(66);Xe(67,1,{},lg);_.M=function(){return this.c=this.a,this.a=this.b.next(),new ng(this.d,this.c,this.d.c)};_.L=function(){return !this.a.done};var ie=pf(67);Xe(25,121,{25:1,127:1},ng);_.c=0;var je=pf(25);Xe(69,1,{});_.Q=ii;_.O=gi;_.P=hi;_.b=0;_.c=0;var oe=pf(69);Xe(70,69,{});var le=pf(70);Xe(58,1,{});_.Q=ii;_.O=gi;_.P=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var ne=pf(58);Xe(59,58,{},wg);_.Q=function(a){tg(this,a)};_.R=function(a){return ug(this,a)};var me=pf(59);Xe(68,1,{});_.c=false;var ue=pf(68);Xe(35,68,{},Cg);var te=pf(35);Xe(71,70,{},Fg);_.R=function(a){return this.a.R(new Gg(a))};var qe=pf(71);Xe(73,1,{},Gg);_.p=function(a){this.a.p(a.b)};var pe=pf(73);Xe(72,1,{},Ig);_.p=function(a){Hg(this,a)};var re=pf(72);Xe(74,1,{},Jg);_.p=function(a){Eg(this.a,a)};var se=pf(74);Xe(176,1,{});Xe(173,1,{});var Pg=0;var Rg,Sg=0,Tg;Xe(782,1,{});Xe(807,1,{});Xe(157,$wnd.Function,{},dh);_.S=function(a){bh(this.a,this.b,a)};Xe(76,1,{});var we=pf(76);Xe(147,$wnd.Function,{},ih);_.T=function(a){lh(this.a.e)};Xe(148,$wnd.Function,{},jh);_.T=function(a){mh(this.a.e)};Xe(40,1,{},kh);var ve=pf(40);Xe(96,1,{});var Je=pf(96);Xe(97,96,{},wh);_.c=0;var rh=0;var Be=pf(97);Xe(98,1,ai,xh);_.n=function(){sh(this.a)};var xe=pf(98);Xe(38,1,ai,yh);_.n=function(){th(this.a,this.b)};_.b=0;var ye=pf(38);Xe(39,1,ai,zh);_.n=function(){V(this.a.a)};var ze=pf(39);Xe(99,1,{},Ah);_.o=function(){return vh(this.a)};var Ae=pf(99);Xe(77,76,{});_.d=0;var Le=pf(77);Xe(78,77,{},Gh);var Eh=0;var Ge=pf(78);Xe(79,1,ai,Hh);_.n=function(){Z(this.a.e)};var Ce=pf(79);Xe(80,1,ai,Ih);_.n=function(){lb(this.a.a)};var De=pf(80);Xe(82,1,{},Jh);_.o=function(){return Ch(this.a)};var Ee=pf(82);Xe(81,1,{},Kh);var Fe=pf(81);Xe(92,1,{},Lh);_.handleEvent=function(a){ph(this.a,a)};var He=pf(92);Xe(149,$wnd.Function,{},Mh);_.w=function(a){qh(this.a,a)};Xe(153,$wnd.Function,{},Nh);_.A=function(a){return a.startNotifications()};Xe(93,1,{},Oh);_.handleEvent=function(a){qh(this.a,null)};var Ie=pf(93);Xe(150,$wnd.Function,{},Ph);_.B=ji;Xe(151,$wnd.Function,{},Qh);_.A=function(a){return nh(this.a,a)};Xe(152,$wnd.Function,{},Rh);_.A=function(a){return a.getCharacteristic('heart_rate_measurement')};Xe(154,$wnd.Function,{},Sh);_.w=function(a){oh(this.a,a)};Xe(155,$wnd.Function,{},Th);_.B=ji;Xe(145,$wnd.Function,{},Uh);_.U=function(a){return new Xh(a)};var Vh;Xe(60,$wnd.React.Component,{},Xh);We(Ue[1],_);_.componentWillUnmount=function(){Bh(this.a)};_.render=function(){return Fh(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var Ke=pf(60);var Yh;Xe(158,$wnd.Function,{},$h);_.v=function(a){return Db(Yh),Yh=null,null};var ed=qf('D');var _h=(uc(),xc);var gwtOnLoad=gwtOnLoad=Se;Qe(bf);Te('permProps',[[]]);if (hrm) hrm.onScriptLoad(gwtOnLoad);})();