function hrm(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='hrm',tb='__gwt_marker_hrm',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='BF01FD21526F7DD0309390A4CD0A98F0',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};hrm.onScriptLoad=function(a){hrm=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
hrm();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'BF01FD21526F7DD0309390A4CD0A98F0';function p(){}
function af(){}
function Ye(){}
function Eb(){}
function Hc(){}
function Oc(){}
function Jg(){}
function Nh(){}
function Qh(){}
function Sh(){}
function Uh(){}
function Vh(){}
function _h(){}
function Mc(a){Lc()}
function kf(){kf=Ye}
function Uf(){Lf(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function wb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function gc(a){this.a=a}
function Hf(a){this.a=a}
function Hg(a){this.a=a}
function Kg(a){this.a=a}
function jh(a){this.a=a}
function kh(a){this.a=a}
function yh(a){this.a=a}
function Ah(a){this.a=a}
function Bh(a){this.a=a}
function Ih(a){this.a=a}
function Jh(a){this.a=a}
function Kh(a){this.a=a}
function Lh(a){this.a=a}
function Mh(a){this.a=a}
function Oh(a){this.a=a}
function Ph(a){this.a=a}
function Rh(a){this.a=a}
function Th(a){this.a=a}
function Wf(a){this.c=a}
function bg(){this.a=ig()}
function lg(){this.a=ig()}
function Ig(a,b){a.a=b}
function qb(a,b){a.b=b}
function $g(a,b){Zg(a,b)}
function ji(a){rg(this,a)}
function eb(a){Wb((K(),a))}
function fb(a){Xb((K(),a))}
function ib(a){Yb((K(),a))}
function w(a){--a.e;D(a)}
function Z(a){!!a&&ac(a.d)}
function bc(a){!!a&&a.n()}
function Oe(a){return a.b}
function ki(a){return null}
function hi(){return this.b}
function ii(){return this.c}
function jf(a){mc.call(this,a)}
function Af(a){mc.call(this,a)}
function Ch(a){a.d=2;ac(a.b)}
function th(a){S(a.a);ab(a.b)}
function L(a,b){P(a);M(a,b)}
function jc(a,b){a.b=b;ic(a,b)}
function Og(a,b){a.splice(b,1)}
function C(a,b){Mb(a.f,b.f)}
function wg(a,b,c){b.p(a.a[c])}
function Of(a,b){return a.a[b]}
function Pc(a,b){return sf(a,b)}
function nf(a){mf(a);return a.j}
function ig(){eg();return new dg}
function Eg(a,b){a.G(b);return a}
function rg(a,b){while(a.O(b));}
function Fg(a,b){Ig(a,Eg(a.a,b))}
function v(a,b,c){t(a,new I(c),b)}
function K(){K=Ye;J=new F}
function oc(){oc=Ye;nc=new p}
function Ec(){Ec=Ye;Dc=new Hc}
function eg(){eg=Ye;dg=gg()}
function uc(){uc=Ye;!!(Lc(),Kc)}
function Cc(){rc!=0&&(rc=0);tc=-1}
function bb(a){K();Xb(a);a.e=-2}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function U(a){mb(a.f);return W(a)}
function vh(a){gb(a.b);return a.c}
function kg(a,b){return a.a.get(b)}
function Ff(a){return a.a.b+a.b.b}
function Sb(a){return !a.d?a:Sb(a.d)}
function Ef(a){return !a?null:ng(a)}
function cd(a){return a==null?null:a}
function qg(a){return a!=null?s(a):0}
function o(a,b){return cd(a)===cd(b)}
function Mg(a,b,c){a.splice(b,0,c)}
function eh(a,b){this.a=a;this.b=b}
function zh(a,b){this.a=a;this.b=b}
function Cb(a){this.d=a;this.b=100}
function jb(a){this.c=new Uf;this.b=a}
function lh(){this.a=ah((Xh(),Wh))}
function Re(){Pe==null&&(Pe=[])}
function Bc(a){$wnd.clearTimeout(a)}
function Lf(a){a.a=Rc(Sd,ci,1,0,5,1)}
function pb(a){K();ob(a);rb(a,2,true)}
function Ng(a,b){Lg(b,0,a,0,b.length)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function yf(a,b){return a.charCodeAt(b)}
function Rg(a){return a.$H||(a.$H=++Qg)}
function $(a){return !(!!a&&1==(a.c&7))}
function $c(a,b){return a!=null&&Yc(a,b)}
function Zg(a,b){for(var c in a){b(c)}}
function hh(a,b){a.onClick=b;return a}
function hf(a,b){a.filters=b;return a}
function ff(a,b){a.services=b;return a}
function gh(a,b){a.disabled=b;return a}
function mf(a){if(a.j!=null){return}uf(a)}
function gb(a){var b;Tb((K(),b=Ob,b),a)}
function Fb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&rb(a.f,5,true)}
function Q(){this.a=Rc(Sd,ci,1,100,5,1)}
function mc(a){this.d=a;hc(this);this.t()}
function Dg(a,b){Ag.call(this,a);this.a=b}
function Vg(){Vg=Ye;Sg=new p;Ug=new p}
function _f(){this.a=new bg;this.b=new lg}
function nh(a){null!=a.g&&a.g.disconnect()}
function hc(a){a.f&&a.b!==ei&&a.t();return a}
function qf(a){var b;b=pf(a);wf(a,b);return b}
function ih(a){a.src='img/heart.svg';return a}
function Mf(a,b){a.a[a.a.length]=b;return true}
function og(a,b,c){this.a=a;this.b=b;this.c=c}
function Lb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function vc(a,b,c){return a.apply(b,c);var d}
function bd(a){return typeof a==='string'}
function ad(a){return typeof a==='number'}
function _c(a){return typeof a==='boolean'}
function Tc(a){return Array.isArray(a)&&a.U===af}
function Zc(a){return !Array.isArray(a)&&a.U===af}
function Bb(a){while(true){if(!Ab(a)){break}}}
function ug(a,b){while(a.c<a.d){wg(a,b,a.c++)}}
function nb(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Mb(a,b){Lb(a,((b.a&229376)>>15)-1,b)}
function Db(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function ec(a){K();Ob?uh(a.a,a.b):A((null,J),a,0)}
function Jf(a){var b;b=a.a.J();a.b=If(a);return b}
function rf(a){var b;b=pf(a);b.i=a;b.e=1;return b}
function Qf(a,b){var c;c=a.a[b];Og(a.a,b);return c}
function Ic(a,b){!a&&(a=[]);a[a.length]=b;return a}
function gf(a){a.acceptAllDevices=false;return a}
function Lc(){Lc=Ye;var a;!Nc();a=new Oc;Kc=a}
function Bg(a){zg(a);return new Dg(a,new Gg(a.a))}
function Yf(a){return new Dg(null,Xf(a,a.length))}
function Gh(a){return B((K(),K(),J),a.a,new Kh(a))}
function Xf(a,b){return sg(b,a.length),new xg(a,b)}
function jg(a,b){return !(a.a.get(b)===undefined)}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Eh(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function yg(a){if(!a.b){zg(a);a.c=true}else{yg(a.b)}}
function Yg(){if(Tg==256){Sg=Ug;Ug=new p;Tg=0}++Tg}
function Ag(a){if(!a){this.b=null;new Uf}else{this.b=a}}
function Gg(a){tg.call(this,a.M(),a.L()&-6);this.a=a}
function ub(a){tb.call(this,null,null,a,1411780608)}
function vb(a){tb.call(this,a,new wb(a),null,304611328)}
function tg(a,b){this.c=a;this.b=(b&64)!=0?b|16384:b}
function xg(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function Zb(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function uh(a,b){var c;c=a.c;if(b!=c){a.c=b;fb(a.b)}}
function Sf(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Gf(a,b){if(b){return Df(a.a,b)}return false}
function tf(a){if(a.F()){return null}var b=a.i;return Ue[b]}
function Pb(a){if(a.e){2==(a.e.c&7)||rb(a.e,4,true);ob(a.e)}}
function zg(a){if(a.b){zg(a.b)}else if(a.c){throw Oe(new xf)}}
function Ac(a){uc();$wnd.setTimeout(function(){throw a},0)}
function pg(a,b){return cd(a)===cd(b)||a!=null&&q(a,b)}
function kc(a,b){var c;c=nf(a.S);return b==null?c:c+': '+b}
function sf(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.w(b))}
function We(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function hb(a){var b;K();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function Xh(){Xh=Ye;var a;Wh=(a=Ze(Vh.prototype.R,Vh,[]),a)}
function F(){this.f=new Nb;this.a=new Cb(this.f);new G(this.a)}
function cg(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Vf(a){Lf(this);Ng(this.a,Cf(a,Rc(Sd,ci,1,Ff(a.a),5,1)))}
function dc(a){bc(a.f);!!a.d&&cc(a);Z(a.a);Z(a.c);bc(a.b);bc(a.e)}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function $e(a){function b(){}
;b.prototype=a||{};return new b}
function lc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function vg(a,b){if(a.c<a.d){wg(a,b,a.c++);return true}return false}
function wh(a){return kf(),null!=a.g&&a.g.connected?true:false}
function dd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function zc(a){a&&Gc((Ec(),Dc));--rc;if(a){if(tc!=-1){Bc(tc);tc=-1}}}
function yc(a,b,c){var d;d=wc();try{return vc(a,b,c)}finally{zc(d)}}
function cb(a,b){var c,d;Mf(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function qh(a,b){var c,d;c=b.target;d=c.value;ec(new zh(a,d.getInt8(1)))}
function Cg(a,b){var c;yg(a);c=new Jg;c.a=b;a.a.N(new Kg(c));return c.a}
function Kb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function mg(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Kf(a){this.d=a;this.c=new mg(this.d.b);this.a=this.c;this.b=If(this)}
function Yh(a){$wnd.React.Component.call(this,a);this.a=new Hh(this)}
function qc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function xc(b){uc();return function(){return yc(b,this,arguments);var a}}
function ab(a){if(-2!=a.e){A((K(),K(),J),new kb(a),0);!!a.b&&lb(a.b)}}
function ac(a){if(a.g>=0){a.g=-2;u((K(),K(),J),new H(new gc(a)),67108864,null)}}
function ng(a){if(a.a.c!=a.c){return kg(a.a,a.b.value[0])}return a.b.value[1]}
function Pf(a,b,c){for(;c<a.a.length;++c){if(pg(b,a.a[c])){return c}}return -1}
function dh(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Rc(a,b,c,d,e,f){var g;g=Sc(e,d);e!=10&&Uc(Pc(a,f),b,c,e,g);return g}
function Rf(a,b){var c;c=Pf(a,b,0);if(c==-1){return false}Og(a.a,c);return true}
function ph(a,b){b.addEventListener('characteristicvaluechanged',a.e);return null}
function W(a){if(a.b){if($c(a.b,6)){throw Oe(a.b)}else{throw Oe(a.b)}}return a.i}
function Hb(b){try{mb(b.b.a)}catch(a){a=Ne(a);if(!$c(a,5))throw Oe(a)}}
function _b(){var a;try{Qb(Ob);K()}finally{a=Ob.d;!a&&((K(),K(),J).d=true);Ob=Ob.d}}
function Fc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Jc(b,c)}while(a.a);a.a=c}}
function Gc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Jc(b,c)}while(a.b);a.b=c}}
function S(a){if(!a.a){a.a=true;a.i=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Bb(a.a)}finally{a.c=false}}}}
function Nf(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.p(c)}}
function Nb(){var a;this.a=Rc(kd,ci,24,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Uf);Mf(a.b,b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new Uf);a.c=c.c}b.d=true;Mf(a.c,b)}
function wf(a,b){var c;if(!a){return}b.i=a;var d=tf(b);if(!d){Ue[a]=[b];return}d.S=b}
function Ze(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function pf(a){var b;b=new of;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function ah(a){var b;b=_g($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function ef(){ef=Ye;cf=$wnd.goog.global.document;df=$wnd.goog.global.navigator}
function xf(){mc.call(this,"Stream already terminated, can't be modified or used")}
function pc(a){oc();hc(this);this.b=a;ic(this,a);this.d=a==null?'null':_e(a);this.a=a}
function fc(a,b,c){this.d=c?new _f:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function ob(a){var b,c;for(c=new Wf(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Bf(a,b){var c,d;for(d=new Kf(b.a);d.b;){c=Jf(d);if(!Gf(a,c)){return false}}return true}
function oh(a,b){A((K(),K(),J),new Ah(a),142606336);return b.getPrimaryService(gi)}
function Pg(a,b){return Qc(b)!=10&&Uc(r(b),b.T,b.__elementTypeId$,Qc(b),a),a}
function Qc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Uc(a,b,c,d,e){e.S=a;e.T=b;e.U=af;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function bf(){$wnd.ReactDOM.render((new lh).a,(ef(),cf).getElementById('app'),null)}
function Qe(){Re();var a=Pe;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function sg(a,b){if(0>a||a>b){throw Oe(new jf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Ib(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function X(a){this.c=a;this.g=null;this.i=null;this.h=false;this.f=new vb(this);this.e=new jb(this.f)}
function of(){this.g=lf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function ag(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function Zf(a){var b,c,d;d=0;for(c=new Kf(a.a);c.b;){b=Jf(c);d=d+(b?qg(b.b.value[0])^qg(ng(b)):0);d=d|0}return d}
function Ne(a){var b;if($c(a,5)){return a}b=a&&a.__java$exception;if(!b){b=new pc(a);Mc(b)}return b}
function If(a){if(a.a.I()){return true}if(a.a!=a.c){return false}a.a=new cg(a.d.a);return a.a.I()}
function _e(a){var b;if(Array.isArray(a)&&a.U===af){return nf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function r(a){return bd(a)?Ud:ad(a)?Md:_c(a)?Kd:Zc(a)?a.S:Tc(a)?a.S:a.S||Array.isArray(a)&&Pc(Dd,1)||Dd}
function s(a){return bd(a)?Xg(a):ad(a)?dd(a):_c(a)?a?1231:1237:Zc(a)?a.m():Tc(a)?Rg(a):!!a&&!!a.hashCode?a.hashCode():Rg(a)}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new yb(a)),67108864,null);!!a.a&&S(a.a);Fb(a.f);a.c=a.c&-8|1}}
function $h(){if(!Zh){Zh=(++(K(),K(),J).e,new Eb);$wnd.Promise.resolve(null).then(Ze(_h.prototype.v,_h,[]))}}
function cc(a){var b,c;for(c=new Wf(new Vf(new Hf(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);ng(b).n()}}
function $f(a){var b,c,d;d=1;for(c=new Wf(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Jb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function Ub(a){var b;if(a.c){while(a.c.a.length!=0){b=Qf(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&rb(b.b,3,true)}}}
function db(a,b){var c,d;d=a.c;Rf(d,b);!!a.b&&di!=(a.b.c&1835008)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((K(),c=Ob,c),a))}
function Gb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&di)?Hb(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Te(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Xg(a){Vg();var b,c,d;c=':'+a;d=Ug[c];if(d!=null){return dd(d)}d=Sg[c];b=d==null?Wg(a):dd(d);Yg();Ug[c]=b;return b}
function Tf(a,b){var c,d;d=a.a.length;b.length<d&&(b=Pg(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function vf(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Hh(a){this.e=new xh;this.c=a;K();++Fh;this.b=new fc(new Ih(this),new Jh(this),false);this.a=new ub(new Lh(this))}
function wc(){var a;if(rc!=0){a=qc();if(a-sc>2000){sc=a;tc=$wnd.setTimeout(Cc,10)}}if(rc++==0){Fc((Ec(),Dc));return true}return false}
function Yc(a,b){if(bd(a)){return !!Xc[b]}else if(a.T){return !!a.T[b]}else if(ad(a)){return !!Wc[b]}else if(_c(a)){return !!Vc[b]}return false}
function Nc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return bd(a)?o(a,b):ad(a)?cd(a)===cd(b):_c(a)?a===b:Zc(a)?a.k(b):Tc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):cd(a)===cd(b)}
function mh(a){(ef(),df).bluetooth.requestDevice(hf(gf({}),[ff({},[gi])])).then(Ze(Ph.prototype.v,Ph,[a])).catch(Ze(Qh.prototype.v,Qh,[]))}
function fh(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function T(a){a.h?hb(a.e):gb(a.e);if(sb(a.f)){if(a.h&&(K(),!(!!Ob&&!!Ob.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{mb(a.f)}}return W(a)}
function Xb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Wf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&rb(b,6,true)}}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Wf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&rb(b,5,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Wf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?rb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Cf(a,b){var c,d,e,f;f=Ff(a.a);b.length<f&&(b=Pg(new Array(f),b));e=b;d=new Kf(a.a);for(c=0;c<f;++c){e[c]=Jf(d)}b.length>f&&(b[f]=null);return b}
function Sc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{$b(b,d);try{f=(R(c.a.a),null)}finally{_b()}return f}catch(a){a=Ne(a);if($c(a,5)){e=a;throw Oe(e)}else throw Oe(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.o()}else{$b(b,e);try{g=c.o()}finally{_b()}}return g}catch(a){a=Ne(a);if($c(a,5)){f=a;throw Oe(f)}else throw Oe(a)}finally{D(b)}}
function Ab(a){var b,c;if(0==a.c){b=Kb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Jb(a.d);Gb(c);return true}
function Se(b,c,d,e){Re();var f=Pe;$moduleName=c;$moduleBase=d;Me=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ai(g)()}catch(a){b(c,a)}}else{ai(g)()}}
function xh(){var a,b;this.e=new Mh(this);this.f=new Oh(this);K();++sh;this.d=new fc(null,new yh(this),true);this.b=(b=new jb((a=null,a)),b);this.a=new X(new Bh(this))}
function _g(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function gg(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return hg()}}
function Jc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].V()&&(c=Ic(c,g)):g[0].V()}catch(a){a=Ne(a);if($c(a,5)){d=a;uc();Ac($c(d,22)?d.u():d)}else throw Oe(a)}}return c}
function Ve(){Ue={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function R(b){var c,d,e;e=b.i;try{d=wh(b.c.a);if(!(e==d||e!=null&&e==d)){b.i=d;b.b=null;eb(b.e)}}catch(a){a=Ne(a);if($c(a,7)){c=a;if(!b.b){b.i=null;b.b=c;eb(b.e)}throw Oe(c)}else throw Oe(a)}}
function Lg(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Wg(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+yf(a,c++)}b=b|0;return b}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Rc(Sd,ci,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{Eh(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Ne(a);if($c(a,5)){K()}else throw Oe(a)}}}
function tb(a,b,c,d){this.b=new Uf;this.f=new Ib(new xb(this),d&6520832|262144|di);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&2097152)&&D((null,J)))}
function Xe(a,b,c){var d=Ue,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Ue[b]),$e(h));_.T=c;!b&&(_.U=af);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.S=f)}
function uf(a){if(a.D()){var b=a.c;b.F()?(a.j='['+b.i):!b.D()?(a.j='[L'+b.B()+';'):(a.j='['+b.B());a.b=b.A()+'[]';a.h=b.C()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=vf('.',[c,vf('$',d)]);a.b=vf('.',[c,vf('.',d)]);a.h=d[d.length-1]}
function Df(a,b){var c,d,e,f,g;e=b.b.value[0];g=ng(b);f=e==null?Ef(ag((d=a.a.a.get(0),d==null?new Array:d))):kg(a.b,e);if(!(cd(g)===cd(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!ag((c=a.a.a.get(0),c==null?new Array:c)):jg(a.b,e))){return false}return true}
function sb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Wf(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Ne(a);if(!$c(a,5))throw Oe(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function ic(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.s();return a&&a.q()}},suppressed:{get:function(){return c.r()}}})}catch(a){}}}
function bh(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;$g(b,Ze(eh.prototype.P,eh,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=_g($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function fg(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function rh(a,b){if(null==b){a.g=null;ec(new zh(a,0))}else{a.g=b.gatt;null!=a.g&&a.g.connect().then(Ze(Rh.prototype.v,Rh,[a])).then(Ze(Sh.prototype.v,Sh,[])).then(Ze(Nh.prototype.v,Nh,[])).then(Ze(Th.prototype.v,Th,[a])).catch(Ze(Uh.prototype.v,Uh,[]));b.addEventListener('gattserverdisconnected',a.f)}A((K(),K(),J),new Ah(a),142606336)}
function rb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==f&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.i=null}Nf(a.b,new zb(a));a.b.a=Rc(Sd,ci,1,0,5,1)}else 3==f&&(3&b)==0&&!!a.a&&(e=a.a.g,e)}}
function Dh(a){var b,c,d;a.d=0;$h();b=(c=vh(a.e),d=T(a.e.a),bh('div',fh(new $wnd.Object,Uc(Pc(Ud,1),ci,2,6,['container'])),[bh('div',fh(new $wnd.Object,Uc(Pc(Ud,1),ci,2,6,['hrm_panel'])),[bh('h1',null,['Heart Rate Monitor']),bh('img',ih(fh(new $wnd.Object,Uc(Pc(Ud,1),ci,2,6,['heart',c>0?'beating':null]))),null),0!=c?c:null,bh('button',hh(gh(new $wnd.Object,d),Ze(jh.prototype.Q,jh,[a])),['Start']),bh('button',hh(gh(new $wnd.Object,!d),Ze(kh.prototype.Q,kh,[a])),['Stop'])])]));return b}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Of(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Sf(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&rb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Of(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Qf(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Uf)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&di!=(k.b.c&1835008)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function hg(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!fg()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var bi={13:1},ci={4:1},di=1048576,ei='__noinit__',fi={4:1,7:1,6:1,5:1},gi='heart_rate';var _,Ue,Pe,Me=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Ve();Xe(1,null,{},p);_.k=function(a){return o(this,a)};_.l=function(){return this.S};_.m=function(){return Rg(this)};_.equals=function(a){return this.k(a)};_.hashCode=function(){return this.m()};Xe(33,1,{},of);_.w=function(a){var b;b=new of;b.e=4;a>1?(b.c=sf(this,a-1)):(b.c=this);return b};_.A=function(){mf(this);return this.b};_.B=function(){return nf(this)};_.C=function(){mf(this);return this.h};_.D=function(){return (this.e&4)!=0};_.F=function(){return (this.e&1)!=0};_.e=0;_.g=0;var lf=1;var Sd=qf(1);var Ld=qf(33);Xe(53,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var jd=qf(53);Xe(54,1,bi,G);_.n=function(){Bb(this.a)};var fd=qf(54);Xe(23,1,{},H);_.o=function(){return this.a.n(),null};var gd=qf(23);Xe(55,1,{},I);var hd=qf(55);var J;Xe(24,1,{24:1},Q);_.b=0;_.c=false;_.d=0;var kd=qf(24);Xe(123,1,{});var nd=qf(123);Xe(91,123,{},X);_.a=false;_.d=0;_.h=false;var md=qf(91);Xe(92,1,{},Y);_.o=function(){return U(this.a)};var ld=qf(92);Xe(27,123,{27:1},jb);_.a=4;_.d=false;_.e=0;var pd=qf(27);Xe(90,1,bi,kb);_.n=function(){bb(this.a)};var od=qf(90);Xe(19,123,{19:1},ub,vb);_.c=0;var ud=qf(19);Xe(85,1,{},wb);var qd=qf(85);Xe(86,1,bi,xb);_.n=function(){mb(this.a)};var rd=qf(86);Xe(87,1,bi,yb);_.n=function(){pb(this.a)};var sd=qf(87);Xe(88,1,{},zb);_.p=function(a){nb(this.a,a)};var td=qf(88);Xe(63,1,{},Cb);_.a=0;_.b=0;_.c=0;var vd=qf(63);Xe(95,1,{},Eb);_.a=false;var wd=qf(95);Xe(37,123,{37:1},Ib);_.a=0;var yd=qf(37);Xe(62,1,{},Nb);var xd=qf(62);Xe(96,1,{},Zb);_.a=0;var Ob;var zd=qf(96);Xe(38,1,{},fc);_.g=0;var Bd=qf(38);Xe(84,1,bi,gc);_.n=function(){dc(this.a)};var Ad=qf(84);Xe(5,1,{4:1,5:1});_.q=hi;_.r=function(){var a,b;return a=Cg(Bg(Yf((this.e==null&&(this.e=Rc(Vd,ci,5,0,0,1)),this.e))),(b=new Uf,b)),Tf(a,Rc(Sd,ci,1,a.a.length,5,1))};_.s=ii;_.t=function(){jc(this,lc(new Error(kc(this,this.d))));Mc(this)};_.b=ei;_.f=true;var Vd=qf(5);Xe(7,5,{4:1,7:1,5:1});var Nd=qf(7);Xe(6,7,fi);var Td=qf(6);Xe(48,6,fi);var Qd=qf(48);Xe(49,48,fi);var Fd=qf(49);Xe(22,49,{22:1,4:1,7:1,6:1,5:1},pc);_.u=function(){return cd(this.a)===cd(nc)?null:this.a};var nc;var Cd=qf(22);var Dd=qf(0);Xe(105,1,{});var Ed=qf(105);var rc=0,sc=0,tc=-1;Xe(58,105,{},Hc);var Dc;var Gd=qf(58);var Kc;Xe(117,1,{});var Id=qf(117);Xe(50,117,{},Oc);var Hd=qf(50);var Vc,Wc,Xc;var cf,df;Xe(52,6,fi);var Pd=qf(52);Xe(89,52,fi,jf);var Jd=qf(89);Vc={4:1,44:1,42:1};var Kd=qf(44);Xe(115,1,ci);var Rd=qf(115);Wc={4:1,42:1};var Md=qf(116);Xe(51,6,fi,xf);var Od=qf(51);Xe(173,1,{});Xc={4:1,43:1,42:1,2:1};var Ud=qf(2);Xe(177,1,{});Xe(35,6,fi,Af);var Wd=qf(35);Xe(118,1,{29:1});_.G=function(a){throw Oe(new Af('Add not supported on this collection'))};var Xd=qf(118);Xe(121,1,{102:1});_.k=function(a){var b,c,d;if(a===this){return true}if(!$c(a,25)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Kf((new Hf(d)).a);c.b;){b=Jf(c);if(!Df(this,b)){return false}}return true};_.m=function(){return Zf(new Hf(this))};var be=qf(121);Xe(64,121,{102:1});var $d=qf(64);Xe(120,118,{29:1,127:1});_.k=function(a){var b;if(a===this){return true}if(!$c(a,17)){return false}b=a;if(Ff(b.a)!=this.H()){return false}return Bf(this,b)};_.m=function(){return Zf(this)};var ce=qf(120);Xe(17,120,{17:1,29:1,127:1},Hf);_.H=function(){return Ff(this.a)};var Zd=qf(17);Xe(18,1,{},Kf);_.J=function(){return Jf(this)};_.I=hi;_.b=false;var Yd=qf(18);Xe(119,118,{29:1,124:1});_.K=function(a,b){throw Oe(new Af('Add not supported on this list'))};_.G=function(a){this.K(this.H(),a);return true};_.k=function(a){var b,c,d,e,f;if(a===this){return true}if(!$c(a,9)){return false}f=a;if(this.H()!=f.a.length){return false}e=new Wf(f);for(c=new Wf(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(cd(b)===cd(d)||b!=null&&q(b,d))){return false}}return true};_.m=function(){return $f(this)};var _d=qf(119);Xe(122,1,{128:1});_.k=function(a){var b;if(!$c(a,26)){return false}b=a;return pg(this.b.value[0],b.b.value[0])&&pg(ng(this),ng(b))};_.m=function(){return qg(this.b.value[0])^qg(ng(this))};var ae=qf(122);Xe(9,119,{4:1,9:1,29:1,124:1},Uf,Vf);_.K=function(a,b){Mg(this.a,a,b)};_.G=function(a){return Mf(this,a)};_.H=function(){return this.a.length};var ee=qf(9);Xe(11,1,{},Wf);_.I=function(){return this.a<this.c.a.length};_.J=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var de=qf(11);Xe(25,64,{4:1,25:1,102:1},_f);var fe=qf(25);Xe(65,1,{},bg);_.b=0;var he=qf(65);Xe(66,1,{},cg);_.J=function(){return this.d=this.a[this.c++],this.d};_.I=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ge=qf(66);var dg;Xe(67,1,{},lg);_.b=0;_.c=0;var ke=qf(67);Xe(68,1,{},mg);_.J=function(){return this.c=this.a,this.a=this.b.next(),new og(this.d,this.c,this.d.c)};_.I=function(){return !this.a.done};var ie=qf(68);Xe(26,122,{26:1,128:1},og);_.c=0;var je=qf(26);Xe(70,1,{});_.N=ji;_.L=hi;_.M=ii;_.b=0;_.c=0;var oe=qf(70);Xe(71,70,{});var le=qf(71);Xe(59,1,{});_.N=ji;_.L=hi;_.M=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var ne=qf(59);Xe(60,59,{},xg);_.N=function(a){ug(this,a)};_.O=function(a){return vg(this,a)};var me=qf(60);Xe(69,1,{});_.c=false;var ue=qf(69);Xe(36,69,{},Dg);var te=qf(36);Xe(72,71,{},Gg);_.O=function(a){return this.a.O(new Hg(a))};var qe=qf(72);Xe(74,1,{},Hg);_.p=function(a){this.a.p(a.b)};var pe=qf(74);Xe(73,1,{},Jg);_.p=function(a){Ig(this,a)};var re=qf(73);Xe(75,1,{},Kg);_.p=function(a){Fg(this.a,a)};var se=qf(75);Xe(175,1,{});Xe(172,1,{});var Qg=0;var Sg,Tg=0,Ug;Xe(781,1,{});Xe(806,1,{});Xe(156,$wnd.Function,{},eh);_.P=function(a){dh(this.a,this.b,a)};Xe(77,1,{});var we=qf(77);Xe(147,$wnd.Function,{},jh);_.Q=function(a){mh(this.a.e)};Xe(148,$wnd.Function,{},kh);_.Q=function(a){nh(this.a.e)};Xe(41,1,{},lh);var ve=qf(41);Xe(97,1,{});var Je=qf(97);Xe(98,97,{},xh);_.c=0;var sh=0;var Be=qf(98);Xe(99,1,bi,yh);_.n=function(){th(this.a)};var xe=qf(99);Xe(39,1,bi,zh);_.n=function(){uh(this.a,this.b)};_.b=0;var ye=qf(39);Xe(40,1,bi,Ah);_.n=function(){V(this.a.a)};var ze=qf(40);Xe(100,1,{},Bh);_.o=function(){return wh(this.a)};var Ae=qf(100);Xe(78,77,{});_.d=0;var Le=qf(78);Xe(79,78,{},Hh);var Fh=0;var Ge=qf(79);Xe(80,1,bi,Ih);_.n=function(){Z(this.a.e)};var Ce=qf(80);Xe(81,1,bi,Jh);_.n=function(){lb(this.a.a)};var De=qf(81);Xe(83,1,{},Kh);_.o=function(){return Dh(this.a)};var Ee=qf(83);Xe(82,1,{},Lh);var Fe=qf(82);Xe(93,1,{},Mh);_.handleEvent=function(a){qh(this.a,a)};var He=qf(93);Xe(153,$wnd.Function,{},Nh);_.v=function(a){return a.startNotifications()};Xe(94,1,{},Oh);_.handleEvent=function(a){rh(this.a,null)};var Ie=qf(94);Xe(149,$wnd.Function,{},Ph);_.v=function(a){return rh(this.a,a),null};Xe(150,$wnd.Function,{},Qh);_.v=ki;Xe(151,$wnd.Function,{},Rh);_.v=function(a){return oh(this.a,a)};Xe(152,$wnd.Function,{},Sh);_.v=function(a){return a.getCharacteristic('heart_rate_measurement')};Xe(154,$wnd.Function,{},Th);_.v=function(a){return ph(this.a,a)};Xe(155,$wnd.Function,{},Uh);_.v=ki;Xe(145,$wnd.Function,{},Vh);_.R=function(a){return new Yh(a)};var Wh;Xe(61,$wnd.React.Component,{},Yh);We(Ue[1],_);_.componentWillUnmount=function(){Ch(this.a)};_.render=function(){return Gh(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var Ke=qf(61);var Zh;Xe(157,$wnd.Function,{},_h);_.v=function(a){return Db(Zh),Zh=null,null};var ed=rf('D');var ai=(uc(),xc);var gwtOnLoad=gwtOnLoad=Se;Qe(bf);Te('permProps',[[]]);if (hrm) hrm.onScriptLoad(gwtOnLoad);})();