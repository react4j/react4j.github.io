function hrm(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='hrm',tb='__gwt_marker_hrm',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='7047061CAE76AAA327B55F17B68E169A',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};hrm.onScriptLoad=function(a){hrm=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
hrm();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '7047061CAE76AAA327B55F17B68E169A';function p(){}
function $e(){}
function We(){}
function Db(){}
function Gc(){}
function Nc(){}
function Hg(){}
function Lh(){}
function Ph(){}
function Rh(){}
function Xh(){}
function Lc(a){Kc()}
function hf(){hf=We}
function Sf(){Jf(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function vb(a){this.a=a}
function wb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function fc(a){this.a=a}
function Ff(a){this.a=a}
function Fg(a){this.a=a}
function Ig(a){this.a=a}
function hh(a){this.a=a}
function ih(a){this.a=a}
function wh(a){this.a=a}
function xh(a){this.a=a}
function yh(a){this.a=a}
function Gh(a){this.a=a}
function Hh(a){this.a=a}
function Ih(a){this.a=a}
function Jh(a){this.a=a}
function Kh(a){this.a=a}
function Mh(a){this.a=a}
function Nh(a){this.a=a}
function Oh(a){this.a=a}
function Qh(a){this.a=a}
function Uf(a){this.c=a}
function _f(){this.a=gg()}
function jg(){this.a=gg()}
function Gg(a,b){a.a=b}
function pb(a,b){a.b=b}
function Yg(a,b){Xg(a,b)}
function C(a,b){Lb(a.f,b.f)}
function K(a,b){O(a);L(a,b)}
function w(a){--a.e;D(a)}
function Y(a){!!a&&_b(a.d)}
function ac(a){!!a&&a.o()}
function fi(a){pg(this,a)}
function db(a){Vb((J(),a))}
function eb(a){Wb((J(),a))}
function hb(a){Xb((J(),a))}
function Me(a){return a.b}
function di(){return this.b}
function ei(){return this.c}
function Mf(a,b){return a.a[b]}
function ic(a,b){a.b=b;hc(a,b)}
function Ah(a){a.d=2;_b(a.b)}
function rh(a){R(a.a);$(a.b)}
function cg(){cg=We;bg=eg()}
function J(){J=We;I=new F}
function nc(){nc=We;mc=new p}
function Dc(){Dc=We;Cc=new Gc}
function tc(){tc=We;!!(Kc(),Jc)}
function gf(a){lc.call(this,a)}
function yf(a){lc.call(this,a)}
function Mg(a,b){a.splice(b,1)}
function ug(a,b,c){b.p(a.a[c])}
function pg(a,b){while(a.O(b));}
function Dg(a,b){Gg(a,Cg(a.a,b))}
function Oc(a,b){return qf(a,b)}
function Df(a){return a.a.b+a.b.b}
function lf(a){kf(a);return a.j}
function th(a){fb(a.b);return a.c}
function T(a){lb(a.f);return V(a)}
function Pb(a){Qb(a);!a.d&&Tb(a)}
function ab(a){J();Wb(a);a.e=-2}
function gg(){cg();return new bg}
function Cg(a,b){a.G(b);return a}
function Kg(a,b,c){a.splice(b,0,c)}
function v(a,b,c){t(a,new H(c),b)}
function ig(a,b){return a.a.get(b)}
function o(a,b){return bd(a)===bd(b)}
function Cf(a){return !a?null:lg(a)}
function Rb(a){return !a.d?a:Rb(a.d)}
function og(a){return a!=null?s(a):0}
function bd(a){return a==null?null:a}
function Pe(){Ne==null&&(Ne=[])}
function Bc(){qc!=0&&(qc=0);sc=-1}
function Bb(a){this.d=a;this.b=100}
function bh(a,b){this.a=a;this.b=b}
function zh(a,b){this.a=a;this.b=b}
function ib(a){this.c=new Sf;this.b=a}
function jh(){this.a=$g((Th(),Sh))}
function Jf(a){a.a=Qc(Qd,Zh,1,0,5,1)}
function ob(a){J();nb(a);qb(a,2,true)}
function Lg(a,b){Jg(b,0,a,0,b.length)}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function Z(a){return !(!!a&&1==(a.c&7))}
function wf(a,b){return a.charCodeAt(b)}
function Pg(a){return a.$H||(a.$H=++Og)}
function Zc(a,b){return a!=null&&Xc(a,b)}
function Xg(a,b){for(var c in a){b(c)}}
function fh(a,b){a.onClick=b;return a}
function ff(a,b){a.filters=b;return a}
function df(a,b){a.services=b;return a}
function eh(a,b){a.disabled=b;return a}
function Ac(a){$wnd.clearTimeout(a)}
function kf(a){if(a.j!=null){return}sf(a)}
function fb(a){var b;Sb((J(),b=Nb,b),a)}
function Eb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&qb(a.f,5,true)}
function P(){this.a=Qc(Qd,Zh,1,100,5,1)}
function Zf(){this.a=new _f;this.b=new jg}
function Tg(){Tg=We;Qg=new p;Sg=new p}
function _c(a){return typeof a==='number'}
function $c(a){return typeof a==='boolean'}
function ad(a){return typeof a==='string'}
function uc(a,b,c){return a.apply(b,c);var d}
function Kb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function mg(a,b,c){this.a=a;this.b=b;this.c=c}
function lc(a){this.d=a;gc(this);this.t()}
function Bg(a,b){yg.call(this,a);this.a=b}
function Kf(a,b){a.a[a.a.length]=b;return true}
function gc(a){a.f&&a.b!==ai&&a.t();return a}
function gh(a){a.src='img/heart.svg';return a}
function of(a){var b;b=nf(a);uf(a,b);return b}
function ef(a){a.acceptAllDevices=false;return a}
function pf(a){var b;b=nf(a);b.i=a;b.e=1;return b}
function lh(a){null!=a.g&&a.g.disconnect()}
function sg(a,b){while(a.c<a.d){ug(a,b,a.c++)}}
function Ab(a){while(true){if(!zb(a)){break}}}
function Cb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function dc(a){J();Nb?sh(a.a,a.b):A((null,I),a,0)}
function Lb(a,b){Kb(a,((b.a&229376)>>15)-1,b)}
function mb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Hc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Of(a,b){var c;c=a.a[b];Mg(a.a,b);return c}
function Hf(a){var b;b=a.a.J();a.b=Gf(a);return b}
function Wf(a){return new Bg(null,Vf(a,a.length))}
function zg(a){xg(a);return new Bg(a,new Eg(a.a))}
function Vf(a,b){return qg(b,a.length),new vg(a,b)}
function hg(a,b){return !(a.a.get(b)===undefined)}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Sc(a){return Array.isArray(a)&&a.U===$e}
function Yc(a){return !Array.isArray(a)&&a.U===$e}
function Eh(a){return B((J(),J(),I),a.a,new Jh(a))}
function Ef(a,b){if(b){return Bf(a.a,b)}return false}
function Qf(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function sh(a,b){var c;c=a.c;if(b!=c){a.c=b;eb(a.b)}}
function Ch(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function wg(a){if(!a.b){xg(a);a.c=true}else{wg(a.b)}}
function yg(a){if(!a){this.b=null;new Sf}else{this.b=a}}
function Eg(a){rg.call(this,a.M(),a.L()&-6);this.a=a}
function tb(a){sb.call(this,null,null,a,1411780608)}
function ub(a){sb.call(this,a,new vb(a),null,304611328)}
function F(){this.f=new Mb;this.a=new Bb(this.f)}
function vg(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function rg(a,b){this.c=a;this.b=(b&64)!=0?b|16384:b}
function ng(a,b){return bd(a)===bd(b)||a!=null&&q(a,b)}
function Kc(){Kc=We;var a;!Mc();a=new Nc;Jc=a}
function Wg(){if(Rg==256){Qg=Sg;Sg=new p;Rg=0}++Rg}
function gb(a){var b;J();!!Nb&&!!Nb.e&&Sb((b=Nb,b),a)}
function Th(){Th=We;var a;Sh=(a=Xe(Rh.prototype.R,Rh,[]),a)}
function jc(a,b){var c;c=lf(a.S);return b==null?c:c+': '+b}
function qf(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.w(b))}
function Ue(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Yb(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Zb(a,b){Nb=new Yb(Nb,b);a.d=false;Ob(Nb);return Nb}
function Ye(a){function b(){}
;b.prototype=a||{};return new b}
function rf(a){if(a.F()){return null}var b=a.i;return Se[b]}
function Ob(a){if(a.e){2==(a.e.c&7)||qb(a.e,4,true);nb(a.e)}}
function xg(a){if(a.b){xg(a.b)}else if(a.c){throw Me(new vf)}}
function zc(a){tc();$wnd.setTimeout(function(){throw a},0)}
function ag(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Tf(a){Jf(this);Lg(this.a,Af(a,Qc(Qd,Zh,1,Df(a.a),5,1)))}
function cc(a){ac(a.f);!!a.d&&bc(a);Y(a.a);Y(a.c);ac(a.b);ac(a.e)}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function tg(a,b){if(a.c<a.d){ug(a,b,a.c++);return true}return false}
function uh(a){return hf(),null!=a.g&&a.g.connected?true:false}
function cd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function yc(a){a&&Fc((Dc(),Cc));--qc;if(a){if(sc!=-1){Ac(sc);sc=-1}}}
function Gb(b){try{lb(b.b.a)}catch(a){a=Le(a);if(!Zc(a,5))throw Me(a)}}
function $(a){if(-2!=a.e){A((J(),J(),I),new jb(a),0);!!a.b&&kb(a.b)}}
function xc(a,b,c){var d;d=vc();try{return uc(a,b,c)}finally{yc(d)}}
function bb(a,b){var c,d;Kf(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function oh(a,b){var c,d;c=b.target;d=c.value;dc(new zh(a,d.getInt8(1)))}
function Ag(a,b){var c;wg(a);c=new Hg;c.a=b;a.a.N(new Ig(c));return c.a}
function Jb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Lf(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.p(c)}}
function kg(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function If(a){this.d=a;this.c=new kg(this.d.b);this.a=this.c;this.b=Gf(this)}
function Uh(a){$wnd.React.Component.call(this,a);this.a=new Fh(this)}
function pc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function wc(b){tc();return function(){return xc(b,this,arguments);var a}}
function kc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Nf(a,b,c){for(;c<a.a.length;++c){if(ng(b,a.a[c])){return c}}return -1}
function ah(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Qc(a,b,c,d,e,f){var g;g=Rc(e,d);e!=10&&Tc(Oc(a,f),b,c,e,g);return g}
function Pf(a,b){var c;c=Nf(a,b,0);if(c==-1){return false}Mg(a.a,c);return true}
function nh(a,b){b.addEventListener('characteristicvaluechanged',a.e);return null}
function V(a){if(a.b){if(Zc(a.b,6)){throw Me(a.b)}else{throw Me(a.b)}}return a.i}
function lg(a){if(a.a.c!=a.c){return ig(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Ab(a.a)}finally{a.c=false}}}}
function R(a){if(!a.a){a.a=true;a.i=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function Ec(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Ic(b,c)}while(a.a);a.a=c}}
function Fc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Ic(b,c)}while(a.b);a.b=c}}
function Mb(){var a;this.a=Qc(hd,Zh,27,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function $b(){var a;try{Pb(Nb);J()}finally{a=Nb.d;!a&&((J(),J(),I).d=true);Nb=Nb.d}}
function Sb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Sf);Kf(a.b,b)}}}
function uf(a,b){var c;if(!a){return}b.i=a;var d=rf(b);if(!d){Se[a]=[b];return}d.S=b}
function Ub(a,b){var c;if(!a.c){c=Rb(a);!c.c&&(c.c=new Sf);a.c=c.c}b.d=true;Kf(a.c,b)}
function nf(a){var b;b=new mf;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function Xe(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Oe(){Pe();var a=Ne;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function cf(){cf=We;af=$wnd.goog.global.document;bf=$wnd.goog.global.navigator}
function vf(){lc.call(this,"Stream already terminated, can't be modified or used")}
function oc(a){nc();gc(this);this.b=a;hc(this,a);this.d=a==null?'null':Ze(a);this.a=a}
function ec(a,b,c){this.d=c?new Zf:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function $g(a){var b;b=Zg($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Pc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Ng(a,b){return Pc(b)!=10&&Tc(r(b),b.T,b.__elementTypeId$,Pc(b),a),a}
function _e(){$wnd.ReactDOM.render((new jh).a,(cf(),af).getElementById('app'),null)}
function _b(a){if(a.g>=0){a.g=-2;u((J(),J(),I),new G(new fc(a)),67108864,null)}}
function qg(a,b){if(0>a||a>b){throw Me(new gf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function mh(a,b){A((J(),J(),I),new xh(a),142606336);return b.getPrimaryService(ci)}
function zf(a,b){var c,d;for(d=new If(b.a);d.b;){c=Hf(d);if(!Ef(a,c)){return false}}return true}
function nb(a){var b,c;for(c=new Uf(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Le(a){var b;if(Zc(a,5)){return a}b=a&&a.__java$exception;if(!b){b=new oc(a);Lc(b)}return b}
function Gf(a){if(a.a.I()){return true}if(a.a!=a.c){return false}a.a=new ag(a.d.a);return a.a.I()}
function W(a){this.c=a;this.g=null;this.i=null;this.h=false;this.f=new ub(this);this.e=new ib(this.f)}
function mf(){this.g=jf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function $f(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function Xf(a){var b,c,d;d=0;for(c=new If(a.a);c.b;){b=Hf(c);d=d+(b?og(b.b.value[0])^og(lg(b)):0);d=d|0}return d}
function bc(a){var b,c;for(c=new Uf(new Tf(new Ff(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);lg(b).o()}}
function cb(a,b){var c,d;d=a.c;Pf(d,b);!!a.b&&$h!=(a.b.c&1835008)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Ub((J(),c=Nb,c),a))}
function Hb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function Re(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Tc(a,b,c,d,e){e.S=a;e.T=b;e.U=$e;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function kh(a){(cf(),bf).bluetooth.requestDevice(ff(ef({}),[df({},[ci])])).then(Xe(Nh.prototype.v,Nh,[a]))}
function Wh(){if(!Vh){Vh=(++(J(),J(),I).e,new Db);$wnd.Promise.resolve(null).then(Xe(Xh.prototype.v,Xh,[]))}}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new xb(a)),67108864,null);!!a.a&&R(a.a);Eb(a.f);a.c=a.c&-8|1}}
function Fb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&$h)?Gb(a):lb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function r(a){return ad(a)?Sd:_c(a)?Kd:$c(a)?Id:Yc(a)?a.S:Sc(a)?a.S:a.S||Array.isArray(a)&&Oc(Bd,1)||Bd}
function s(a){return ad(a)?Vg(a):_c(a)?cd(a):$c(a)?a?1231:1237:Yc(a)?a.m():Sc(a)?Pg(a):!!a&&!!a.hashCode?a.hashCode():Pg(a)}
function Ze(a){var b;if(Array.isArray(a)&&a.U===$e){return lf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function Vg(a){Tg();var b,c,d;c=':'+a;d=Sg[c];if(d!=null){return cd(d)}d=Qg[c];b=d==null?Ug(a):cd(d);Wg();Sg[c]=b;return b}
function Yf(a){var b,c,d;d=1;for(c=new Uf(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Ib(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function Tb(a){var b;if(a.c){while(a.c.a.length!=0){b=Of(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&qb(b.b,3,true)}}}
function Rf(a,b){var c,d;d=a.a.length;b.length<d&&(b=Ng(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function tf(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Fh(a){this.e=new vh;this.c=a;J();++Dh;this.b=new ec(new Gh(this),new Hh(this),false);this.a=new tb(new Ih(this))}
function vc(){var a;if(qc!=0){a=pc();if(a-rc>2000){rc=a;sc=$wnd.setTimeout(Bc,10)}}if(qc++==0){Ec((Dc(),Cc));return true}return false}
function Xc(a,b){if(ad(a)){return !!Wc[b]}else if(a.T){return !!a.T[b]}else if(_c(a)){return !!Vc[b]}else if($c(a)){return !!Uc[b]}return false}
function Mc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return ad(a)?o(a,b):_c(a)?bd(a)===bd(b):$c(a)?a===b:Yc(a)?a.k(b):Sc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):bd(a)===bd(b)}
function dh(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function S(a){a.h?gb(a.e):fb(a.e);if(rb(a.f)){if(a.h&&(J(),!(!!Nb&&!!Nb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{lb(a.f)}}return V(a)}
function Wb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Uf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&qb(b,6,true)}}}
function Xb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Uf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&qb(b,5,true)}}}
function Vb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Uf(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?qb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Af(a,b){var c,d,e,f;f=Df(a.a);b.length<f&&(b=Ng(new Array(f),b));e=b;d=new If(a.a);for(c=0;c<f;++c){e[c]=Hf(d)}b.length>f&&(b[f]=null);return b}
function Rc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{Zb(b,d);try{f=(Q(c.a.a),null)}finally{$b()}return f}catch(a){a=Le(a);if(Zc(a,5)){e=a;throw Me(e)}else throw Me(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Nb){g=c.n()}else{Zb(b,e);try{g=c.n()}finally{$b()}}return g}catch(a){a=Le(a);if(Zc(a,5)){f=a;throw Me(f)}else throw Me(a)}finally{D(b)}}
function zb(a){var b,c;if(0==a.c){b=Jb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Ib(a.d);Fb(c);return true}
function Qe(b,c,d,e){Pe();var f=Ne;$moduleName=c;$moduleBase=d;Ke=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Yh(g)()}catch(a){b(c,a)}}else{Yh(g)()}}
function vh(){var a,b;this.e=new Kh(this);this.f=new Mh(this);J();++qh;this.d=new ec(null,new wh(this),true);this.b=(b=new ib((a=null,a)),b);this.a=new W(new yh(this))}
function Zg(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function eg(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return fg()}}
function Ic(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].V()&&(c=Hc(c,g)):g[0].V()}catch(a){a=Le(a);if(Zc(a,5)){d=a;tc();zc(Zc(d,22)?d.u():d)}else throw Me(a)}}return c}
function Te(){Se={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Q(b){var c,d,e;e=b.i;try{d=uh(b.c.a);if(!(e==d||e!=null&&e==d)){b.i=d;b.b=null;db(b.e)}}catch(a){a=Le(a);if(Zc(a,7)){c=a;if(!b.b){b.i=null;b.b=c;db(b.e)}throw Me(c)}else throw Me(a)}}
function Jg(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Ug(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+wf(a,c++)}b=b|0;return b}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Qc(Qd,Zh,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function lb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{Ch(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Le(a);if(Zc(a,5)){J()}else throw Me(a)}}}
function sb(a,b,c,d){this.b=new Sf;this.f=new Hb(new wb(this),d&6520832|262144|$h);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&2097152)&&D((null,I)))}
function Ve(a,b,c){var d=Se,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Se[b]),Ye(h));_.T=c;!b&&(_.U=$e);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.S=f)}
function sf(a){if(a.D()){var b=a.c;b.F()?(a.j='['+b.i):!b.D()?(a.j='[L'+b.B()+';'):(a.j='['+b.B());a.b=b.A()+'[]';a.h=b.C()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=tf('.',[c,tf('$',d)]);a.b=tf('.',[c,tf('.',d)]);a.h=d[d.length-1]}
function Bf(a,b){var c,d,e,f,g;e=b.b.value[0];g=lg(b);f=e==null?Cf($f((d=a.a.a.get(0),d==null?new Array:d))):ig(a.b,e);if(!(bd(g)===bd(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!$f((c=a.a.a.get(0),c==null?new Array:c)):hg(a.b,e))){return false}return true}
function rb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Uf(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Le(a);if(!Zc(a,5))throw Me(a)}if(6==(b.c&7)){return true}}}}}nb(b);return false}
function hc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.s();return a&&a.q()}},suppressed:{get:function(){return c.r()}}})}catch(a){}}}
function ph(a,b){if(null==b){a.g=null;dc(new zh(a,0))}else{a.g=b.gatt;null!=a.g&&a.g.connect().then(Xe(Oh.prototype.v,Oh,[a])).then(Xe(Ph.prototype.v,Ph,[])).then(Xe(Lh.prototype.v,Lh,[])).then(Xe(Qh.prototype.v,Qh,[a]));b.addEventListener('gattserverdisconnected',a.f)}A((J(),J(),I),new xh(a),142606336)}
function _g(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Yg(b,Xe(bh.prototype.P,bh,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=Zg($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function dg(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function qb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==f&&(6==b||5==b)){hb(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.i=null}Lf(a.b,new yb(a));a.b.a=Qc(Qd,Zh,1,0,5,1)}else 3==f&&(3&b)==0&&!!a.a&&(e=a.a.g,e)}}
function Bh(a){var b,c,d;a.d=0;Wh();b=(c=th(a.e),d=S(a.e.a),_g('div',dh(new $wnd.Object,Tc(Oc(Sd,1),Zh,2,6,['container'])),[_g('div',dh(new $wnd.Object,Tc(Oc(Sd,1),Zh,2,6,['hrm_panel'])),[_g('h1',null,['Heart Rate Monitor']),_g('img',gh(dh(new $wnd.Object,Tc(Oc(Sd,1),Zh,2,6,['heart',c>0?'beating':null]))),null),0!=c?c:null,_g('button',fh(eh(new $wnd.Object,d),Xe(hh.prototype.Q,hh,[a])),['Start']),_g('button',fh(eh(new $wnd.Object,!d),Xe(ih.prototype.Q,ih,[a])),['Stop'])])]));return b}
function Qb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Mf(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Qf(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&qb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Mf(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Of(a.b,g)}e&&pb(a.e,a.b)}else{e&&pb(a.e,new Sf)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&$h!=(k.b.c&1835008)&&k.c.a.length<=0&&0==k.b.a.d&&Ub(a,k)}}
function fg(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!dg()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Zh={4:1},$h=1048576,_h={15:1},ai='__noinit__',bi={4:1,7:1,6:1,5:1},ci='heart_rate';var _,Se,Ne,Ke=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Te();Ve(1,null,{},p);_.k=function(a){return o(this,a)};_.l=function(){return this.S};_.m=function(){return Pg(this)};_.equals=function(a){return this.k(a)};_.hashCode=function(){return this.m()};Ve(33,1,{},mf);_.w=function(a){var b;b=new mf;b.e=4;a>1?(b.c=qf(this,a-1)):(b.c=this);return b};_.A=function(){kf(this);return this.b};_.B=function(){return lf(this)};_.C=function(){kf(this);return this.h};_.D=function(){return (this.e&4)!=0};_.F=function(){return (this.e&1)!=0};_.e=0;_.g=0;var jf=1;var Qd=of(1);var Jd=of(33);Ve(74,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var gd=of(74);Ve(23,1,{},G);_.n=function(){return this.a.o(),null};var ed=of(23);Ve(75,1,{},H);var fd=of(75);var I;Ve(27,1,{27:1},P);_.b=0;_.c=false;_.d=0;var hd=of(27);Ve(120,1,{});var ld=of(120);Ve(84,120,{},W);_.a=false;_.d=0;_.h=false;var kd=of(84);Ve(85,1,{},X);_.n=function(){return T(this.a)};var jd=of(85);Ve(25,120,{25:1},ib);_.a=4;_.d=false;_.e=0;var nd=of(25);Ve(83,1,_h,jb);_.o=function(){ab(this.a)};var md=of(83);Ve(19,120,{19:1},tb,ub);_.c=0;var sd=of(19);Ve(77,1,{},vb);var od=of(77);Ve(78,1,_h,wb);_.o=function(){lb(this.a)};var pd=of(78);Ve(79,1,_h,xb);_.o=function(){ob(this.a)};var qd=of(79);Ve(80,1,{},yb);_.p=function(a){mb(this.a,a)};var rd=of(80);Ve(99,1,{},Bb);_.a=0;_.b=0;_.c=0;var td=of(99);Ve(88,1,{},Db);_.a=false;var ud=of(88);Ve(38,120,{38:1},Hb);_.a=0;var wd=of(38);Ve(98,1,{},Mb);var vd=of(98);Ve(93,1,{},Yb);_.a=0;var Nb;var xd=of(93);Ve(37,1,{},ec);_.g=0;var zd=of(37);Ve(76,1,_h,fc);_.o=function(){cc(this.a)};var yd=of(76);Ve(5,1,{4:1,5:1});_.q=di;_.r=function(){var a,b;return a=Ag(zg(Wf((this.e==null&&(this.e=Qc(Td,Zh,5,0,0,1)),this.e))),(b=new Sf,b)),Rf(a,Qc(Qd,Zh,1,a.a.length,5,1))};_.s=ei;_.t=function(){ic(this,kc(new Error(jc(this,this.d))));Lc(this)};_.b=ai;_.f=true;var Td=of(5);Ve(7,5,{4:1,7:1,5:1});var Ld=of(7);Ve(6,7,bi);var Rd=of(6);Ve(48,6,bi);var Od=of(48);Ve(49,48,bi);var Dd=of(49);Ve(22,49,{22:1,4:1,7:1,6:1,5:1},oc);_.u=function(){return bd(this.a)===bd(mc)?null:this.a};var mc;var Ad=of(22);var Bd=of(0);Ve(103,1,{});var Cd=of(103);var qc=0,rc=0,sc=-1;Ve(55,103,{},Gc);var Cc;var Ed=of(55);var Jc;Ve(115,1,{});var Gd=of(115);Ve(50,115,{},Nc);var Fd=of(50);var Uc,Vc,Wc;var af,bf;Ve(52,6,bi);var Nd=of(52);Ve(81,52,bi,gf);var Hd=of(81);Uc={4:1,44:1,42:1};var Id=of(44);Ve(113,1,Zh);var Pd=of(113);Vc={4:1,42:1};var Kd=of(114);Ve(51,6,bi,vf);var Md=of(51);Ve(169,1,{});Wc={4:1,43:1,42:1,2:1};var Sd=of(2);Ve(173,1,{});Ve(35,6,bi,yf);var Ud=of(35);Ve(116,1,{29:1});_.G=function(a){throw Me(new yf('Add not supported on this collection'))};var Vd=of(116);Ve(119,1,{101:1});_.k=function(a){var b,c,d;if(a===this){return true}if(!Zc(a,24)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new If((new Ff(d)).a);c.b;){b=Hf(c);if(!Bf(this,b)){return false}}return true};_.m=function(){return Xf(new Ff(this))};var _d=of(119);Ve(82,119,{101:1});var Yd=of(82);Ve(118,116,{29:1,125:1});_.k=function(a){var b;if(a===this){return true}if(!Zc(a,17)){return false}b=a;if(Df(b.a)!=this.H()){return false}return zf(this,b)};_.m=function(){return Xf(this)};var ae=of(118);Ve(17,118,{17:1,29:1,125:1},Ff);_.H=function(){return Df(this.a)};var Xd=of(17);Ve(18,1,{},If);_.J=function(){return Hf(this)};_.I=di;_.b=false;var Wd=of(18);Ve(117,116,{29:1,122:1});_.K=function(a,b){throw Me(new yf('Add not supported on this list'))};_.G=function(a){this.K(this.H(),a);return true};_.k=function(a){var b,c,d,e,f;if(a===this){return true}if(!Zc(a,9)){return false}f=a;if(this.H()!=f.a.length){return false}e=new Uf(f);for(c=new Uf(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(bd(b)===bd(d)||b!=null&&q(b,d))){return false}}return true};_.m=function(){return Yf(this)};var Zd=of(117);Ve(121,1,{126:1});_.k=function(a){var b;if(!Zc(a,26)){return false}b=a;return ng(this.b.value[0],b.b.value[0])&&ng(lg(this),lg(b))};_.m=function(){return og(this.b.value[0])^og(lg(this))};var $d=of(121);Ve(9,117,{4:1,9:1,29:1,122:1},Sf,Tf);_.K=function(a,b){Kg(this.a,a,b)};_.G=function(a){return Kf(this,a)};_.H=function(){return this.a.length};var ce=of(9);Ve(11,1,{},Uf);_.I=function(){return this.a<this.c.a.length};_.J=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var be=of(11);Ve(24,82,{4:1,24:1,101:1},Zf);var de=of(24);Ve(91,1,{},_f);_.b=0;var fe=of(91);Ve(92,1,{},ag);_.J=function(){return this.d=this.a[this.c++],this.d};_.I=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ee=of(92);var bg;Ve(89,1,{},jg);_.b=0;_.c=0;var ie=of(89);Ve(90,1,{},kg);_.J=function(){return this.c=this.a,this.a=this.b.next(),new mg(this.d,this.c,this.d.c)};_.I=function(){return !this.a.done};var ge=of(90);Ve(26,121,{26:1,126:1},mg);_.c=0;var he=of(26);Ve(60,1,{});_.N=fi;_.L=di;_.M=ei;_.b=0;_.c=0;var me=of(60);Ve(61,60,{});var je=of(61);Ve(56,1,{});_.N=fi;_.L=di;_.M=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var le=of(56);Ve(57,56,{},vg);_.N=function(a){sg(this,a)};_.O=function(a){return tg(this,a)};var ke=of(57);Ve(59,1,{});_.c=false;var se=of(59);Ve(36,59,{},Bg);var re=of(36);Ve(62,61,{},Eg);_.O=function(a){return this.a.O(new Fg(a))};var oe=of(62);Ve(64,1,{},Fg);_.p=function(a){this.a.p(a.b)};var ne=of(64);Ve(63,1,{},Hg);_.p=function(a){Gg(this,a)};var pe=of(63);Ve(65,1,{},Ig);_.p=function(a){Dg(this.a,a)};var qe=of(65);Ve(171,1,{});Ve(168,1,{});var Og=0;var Qg,Rg=0,Sg;Ve(775,1,{});Ve(800,1,{});Ve(152,$wnd.Function,{},bh);_.P=function(a){ah(this.a,this.b,a)};Ve(67,1,{});var ue=of(67);Ve(145,$wnd.Function,{},hh);_.Q=function(a){kh(this.a.e)};Ve(146,$wnd.Function,{},ih);_.Q=function(a){lh(this.a.e)};Ve(41,1,{},jh);var te=of(41);Ve(94,1,{});var He=of(94);Ve(95,94,{},vh);_.c=0;var qh=0;var ze=of(95);Ve(96,1,_h,wh);_.o=function(){rh(this.a)};var ve=of(96);Ve(40,1,_h,xh);_.o=function(){U(this.a.a)};var we=of(40);Ve(97,1,{},yh);_.n=function(){return uh(this.a)};var xe=of(97);Ve(39,1,_h,zh);_.o=function(){sh(this.a,this.b)};_.b=0;var ye=of(39);Ve(68,67,{});_.d=0;var Je=of(68);Ve(69,68,{},Fh);var Dh=0;var Ee=of(69);Ve(70,1,_h,Gh);_.o=function(){Y(this.a.e)};var Ae=of(70);Ve(71,1,_h,Hh);_.o=function(){kb(this.a.a)};var Be=of(71);Ve(72,1,{},Ih);var Ce=of(72);Ve(73,1,{},Jh);_.n=function(){return Bh(this.a)};var De=of(73);Ve(86,1,{},Kh);_.handleEvent=function(a){oh(this.a,a)};var Fe=of(86);Ve(150,$wnd.Function,{},Lh);_.v=function(a){return a.startNotifications()};Ve(87,1,{},Mh);_.handleEvent=function(a){ph(this.a,null)};var Ge=of(87);Ve(147,$wnd.Function,{},Nh);_.v=function(a){return ph(this.a,a),null};Ve(148,$wnd.Function,{},Oh);_.v=function(a){return mh(this.a,a)};Ve(149,$wnd.Function,{},Ph);_.v=function(a){return a.getCharacteristic('heart_rate_measurement')};Ve(151,$wnd.Function,{},Qh);_.v=function(a){return nh(this.a,a)};Ve(143,$wnd.Function,{},Rh);_.R=function(a){return new Uh(a)};var Sh;Ve(58,$wnd.React.Component,{},Uh);Ue(Se[1],_);_.componentWillUnmount=function(){Ah(this.a)};_.render=function(){return Eh(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var Ie=of(58);var Vh;Ve(153,$wnd.Function,{},Xh);_.v=function(a){return Cb(Vh),Vh=null,null};var dd=pf('D');var Yh=(tc(),wc);var gwtOnLoad=gwtOnLoad=Qe;Oe(_e);Re('permProps',[[]]);if (hrm) hrm.onScriptLoad(gwtOnLoad);})();