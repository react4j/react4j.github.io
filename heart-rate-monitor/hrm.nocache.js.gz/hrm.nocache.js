function hrm(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='hrm',tb='__gwt_marker_hrm',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='E1664C0790ADB3D59154345BD88F8995',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};hrm.onScriptLoad=function(a){hrm=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
hrm();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'E1664C0790ADB3D59154345BD88F8995';function p(){}
function jf(){}
function ef(){}
function Eb(){}
function Hc(){}
function Oc(){}
function Qg(){}
function Vh(){}
function Xh(){}
function Zh(){}
function _h(){}
function ai(){}
function gi(){}
function Mc(a){Lc()}
function rf(){rf=ef}
function _f(){Sf(this)}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function wb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function gc(a){this.a=a}
function Of(a){this.a=a}
function Og(a){this.a=a}
function Rg(a){this.a=a}
function bg(a){this.c=a}
function qh(a){this.a=a}
function rh(a){this.a=a}
function Fh(a){this.a=a}
function Hh(a){this.a=a}
function Ih(a){this.a=a}
function Ph(a){this.a=a}
function Qh(a){this.a=a}
function Rh(a){this.a=a}
function Sh(a){this.a=a}
function Th(a){this.a=a}
function Uh(a){this.a=a}
function Wh(a){this.a=a}
function Yh(a){this.a=a}
function $h(a){this.a=a}
function ui(a){this.a=a}
function vi(a){this.a=a}
function xi(a){this.a=a}
function zi(a){this.a=a}
function ig(){this.a=pg()}
function sg(){this.a=pg()}
function Pg(a,b){a.a=b}
function qb(a,b){a.b=b}
function gh(a,b){fh(a,b)}
function Mi(a){yg(this,a)}
function eb(a){Wb((K(),a))}
function fb(a){Xb((K(),a))}
function ib(a){Yb((K(),a))}
function w(a){--a.e;D(a)}
function Z(a){!!a&&ac(a.d)}
function bc(a){!!a&&a.n()}
function We(a){return a.b}
function Ni(a){return null}
function Ki(){return this.b}
function Li(){return this.c}
function K(){K=ef;J=new F}
function oc(){oc=ef;nc=new p}
function Ec(){Ec=ef;Dc=new Hc}
function lg(){lg=ef;kg=ng()}
function Jh(a){a.d=2;ac(a.b)}
function Ah(a){S(a.a);ab(a.b)}
function L(a,b){P(a);M(a,b)}
function ji(a,b){pi(a);M(a,b)}
function jc(a,b){a.b=b;ic(a,b)}
function Vg(a,b){a.splice(b,1)}
function C(a,b){Mb(a.f,b.f)}
function Dg(a,b,c){b.p(a.a[c])}
function Vf(a,b){return a.a[b]}
function Pc(a,b){return zf(a,b)}
function uf(a){tf(a);return a.j}
function Lg(a,b){a.J(b);return a}
function pg(){lg();return new kg}
function U(a){mb(a.f);return W(a)}
function Qb(a){Rb(a);!a.d&&Ub(a)}
function bb(a){K();Xb(a);a.e=-2}
function Mg(a,b){Pg(a,Lg(a.a,b))}
function yg(a,b){while(a.R(b));}
function yi(a,b){return ii(a.a,b)}
function rg(a,b){return a.a.get(b)}
function Mf(a){return a.a.b+a.b.b}
function lh(a,b){this.a=a;this.b=b}
function Cb(a){this.d=a;this.b=100}
function Gh(a,b){this.a=a;this.b=b}
function sh(){this.a=ih((ci(),bi))}
function uc(){uc=ef;!!(Lc(),Kc)}
function qf(a){mc.call(this,a)}
function Hf(a){mc.call(this,a)}
function Ze(){Xe==null&&(Xe=[])}
function Cc(){rc!=0&&(rc=0);tc=-1}
function Ch(a){gb(a.b);return a.c}
function Bc(a){$wnd.clearTimeout(a)}
function Lf(a){return !a?null:ug(a)}
function xg(a){return a!=null?s(a):0}
function cd(a){return a==null?null:a}
function Sb(a){return !a.d?a:Sb(a.d)}
function o(a,b){return cd(a)===cd(b)}
function v(a,b,c){t(a,new I(c),b)}
function Tg(a,b,c){a.splice(b,0,c)}
function oh(a,b){a.onClick=b;return a}
function pf(a,b){a.filters=b;return a}
function ki(a){a.b=0;a.d=0;a.c=false}
function Sf(a){a.a=Rc(Sd,Fi,1,0,5,1)}
function pb(a){K();ob(a);rb(a,2,true)}
function Ug(a,b){Sg(b,0,a,0,b.length)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function Ci(a){return yi((Bi(),Ai),a)}
function $(a){return !(!!a&&1==(a.c&7))}
function Ff(a,b){return a.charCodeAt(b)}
function Yg(a){return a.$H||(a.$H=++Xg)}
function $c(a,b){return a!=null&&Yc(a,b)}
function fh(a,b){for(var c in a){b(c)}}
function nh(a,b){a.disabled=b;return a}
function nf(a,b){a.services=b;return a}
function tf(a){if(a.j!=null){return}Bf(a)}
function jb(a){this.c=new _f;this.b=a}
function ti(){this.d=new qi;this.b=100}
function gg(){this.a=new ig;this.b=new sg}
function ah(){ah=ef;Zg=new p;_g=new p}
function Bi(){Bi=ef;Ai=new zi(new ti)}
function gb(a){var b;Tb((K(),b=Ob,b),a)}
function Fb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&rb(a.f,5,true)}
function Q(){this.a=Rc(Sd,Fi,1,100,5,1)}
function qi(){this.a=Rc(Sd,Fi,1,100,5,1)}
function mc(a){this.d=a;hc(this);this.t()}
function Kg(a,b){Hg.call(this,a);this.a=b}
function Lb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function vc(a,b,c){return a.apply(b,c);var d}
function bd(a){return typeof a==='string'}
function ad(a){return typeof a==='number'}
function _c(a){return typeof a==='boolean'}
function uh(a){null!=a.g&&a.g.disconnect()}
function hc(a){a.f&&a.b!==Hi&&a.t();return a}
function ph(a){a.src='img/heart.svg';return a}
function xf(a){var b;b=wf(a);Df(a,b);return b}
function Tf(a,b){a.a[a.a.length]=b;return true}
function nb(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Mb(a,b){Lb(a,((b.a&229376)>>15)-1,b)}
function Bg(a,b){while(a.c<a.d){Dg(a,b,a.c++)}}
function Bb(a){while(true){if(!Ab(a)){break}}}
function ri(a){while(true){if(!si(a)){break}}}
function wi(a){if(a.a){Db(ei);ei=null;a.a=null}}
function Db(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function ec(a){K();Ob?Bh(a.a,a.b):A((null,J),a,0)}
function Qf(a){var b;b=a.a.M();a.b=Pf(a);return b}
function yf(a){var b;b=wf(a);b.i=a;b.e=1;return b}
function of(a){a.acceptAllDevices=false;return a}
function Xf(a,b){var c;c=a.a[b];Vg(a.a,b);return c}
function Ic(a,b){!a&&(a=[]);a[a.length]=b;return a}
function cg(a,b){return zg(b,a.length),new Eg(a,b)}
function qg(a,b){return !(a.a.get(b)===undefined)}
function Zc(a){return !Array.isArray(a)&&a.X===jf}
function Tc(a){return Array.isArray(a)&&a.X===jf}
function dg(a){return new Kg(null,cg(a,a.length))}
function Ig(a){Gg(a);return new Kg(a,new Ng(a.a))}
function Nh(a){return B((K(),K(),J),a.a,new Rh(a))}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function vg(a,b,c){this.a=a;this.b=b;this.c=c}
function Ag(a,b){this.c=a;this.b=(b&64)!=0?b|16384:b}
function Bh(a,b){var c;c=a.c;if(b!=c){a.c=b;fb(a.b)}}
function Zf(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Nf(a,b){if(b){return Kf(a.a,b)}return false}
function wg(a,b){return cd(a)===cd(b)||a!=null&&q(a,b)}
function Lc(){Lc=ef;var a;!Nc();a=new Oc;Kc=a}
function mf(){mf=ef;lf=$wnd.goog.global.document}
function eh(){if($g==256){Zg=_g;_g=new p;$g=0}++$g}
function Lh(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Fg(a){if(!a.b){Gg(a);a.c=true}else{Fg(a.b)}}
function Hg(a){if(!a){this.b=null;new _f}else{this.b=a}}
function Ng(a){Ag.call(this,a.P(),a.O()&-6);this.a=a}
function ub(a){tb.call(this,null,null,a,1411780608)}
function vb(a){tb.call(this,a,new wb(a),null,304611328)}
function hb(a){var b;K();!!Ob&&!!Ob.e&&Tb((b=Ob,b),a)}
function ci(){ci=ef;var a;bi=(a=ff(ai.prototype.U,ai,[]),a)}
function gf(a){function b(){}
;b.prototype=a||{};return new b}
function Af(a){if(a.I()){return null}var b=a.i;return af[b]}
function Pb(a){if(a.e){2==(a.e.c&7)||rb(a.e,4,true);ob(a.e)}}
function Gg(a){if(a.b){Gg(a.b)}else if(a.c){throw We(new Ef)}}
function fi(){if(!ei){ei=(++(K(),K(),J).e,new Eb);Ci(new gi)}}
function Zb(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function Eg(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function F(){this.f=new Nb;this.a=new Cb(this.f);new G(this.a)}
function jg(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Ac(a){uc();$wnd.setTimeout(function(){throw a},0)}
function kc(a,b){var c;c=uf(a.V);return b==null?c:c+': '+b}
function zf(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.C(b))}
function cf(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function $b(a,b){Ob=new Zb(Ob,b);a.d=false;Pb(Ob);return Ob}
function Cg(a,b){if(a.c<a.d){Dg(a,b,a.c++);return true}return false}
function Dh(a){return rf(),null!=a.g&&a.g.connected?true:false}
function dd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function ag(a){Sf(this);Ug(this.a,Jf(a,Rc(Sd,Fi,1,Mf(a.a),5,1)))}
function dc(a){bc(a.f);!!a.d&&cc(a);Z(a.a);Z(a.c);bc(a.b);bc(a.e)}
function ab(a){if(-2!=a.e){A((K(),K(),J),new kb(a),0);!!a.b&&lb(a.b)}}
function yc(a,b,c){var d;d=wc();try{return vc(a,b,c)}finally{zc(d)}}
function cb(a,b){var c,d;Tf(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Jg(a,b){var c;Fg(a);c=new Qg;c.a=b;a.a.Q(new Rg(c));return c.a}
function lc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function xc(b){uc();return function(){return yc(b,this,arguments);var a}}
function qc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function xh(a,b){var c,d;c=b.target;d=c.value;ec(new Gh(a,d.getInt8(1)))}
function wh(a,b){b.addEventListener('characteristicvaluechanged',a.e)}
function kh(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Rc(a,b,c,d,e,f){var g;g=Sc(e,d);e!=10&&Uc(Pc(a,f),b,c,e,g);return g}
function Kb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Wf(a,b,c){for(;c<a.a.length;++c){if(wg(b,a.a[c])){return c}}return -1}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function tg(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Rf(a){this.d=a;this.c=new tg(this.d.b);this.a=this.c;this.b=Pf(this)}
function di(a){$wnd.React.Component.call(this,a);this.a=new Oh(this)}
function zc(a){a&&Gc((Ec(),Dc));--rc;if(a){if(tc!=-1){Bc(tc);tc=-1}}}
function Hb(b){try{mb(b.b.a)}catch(a){a=Ve(a);if(!$c(a,4))throw We(a)}}
function Wg(a,b){return Qc(b)!=10&&Uc(r(b),b.W,b.__elementTypeId$,Qc(b),a),a}
function Qc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Uf(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.p(c)}}
function Nb(){var a;this.a=Rc(kd,Fi,23,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function hi(b){var c;c=mi(b.d);try{wi(c)}catch(a){a=Ve(a);if(!$c(a,4))throw We(a)}}
function Yf(a,b){var c;c=Wf(a,b,0);if(c==-1){return false}Vg(a.a,c);return true}
function ug(a){if(a.a.c!=a.c){return rg(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Bb(a.a)}finally{a.c=false}}}}
function S(a){if(!a.a){a.a=true;a.i=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function Fc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Jc(b,c)}while(a.a);a.a=c}}
function Gc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Jc(b,c)}while(a.b);a.b=c}}
function Tb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new _f);Tf(a.b,b)}}}
function Vb(a,b){var c;if(!a.c){c=Sb(a);!c.c&&(c.c=new _f);a.c=c.c}b.d=true;Tf(a.c,b)}
function Df(a,b){var c;if(!a){return}b.i=a;var d=Af(b);if(!d){af[a]=[b];return}d.V=b}
function ff(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function wf(a){var b;b=new vf;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function ih(a){var b;b=hh($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function W(a){if(a.b){if($c(a.b,6)){throw We(a.b)}else{throw We(a.b)}}return a.i}
function ac(a){if(a.g>=0){a.g=-2;u((K(),K(),J),new H(new gc(a)),67108864,null)}}
function kf(){$wnd.ReactDOM.render((new sh).a,(mf(),lf).getElementById('app'),null)}
function Ef(){mc.call(this,"Stream already terminated, can't be modified or used")}
function pc(a){oc();hc(this);this.b=a;ic(this,a);this.d=a==null?'null':hf(a);this.a=a}
function fc(a,b,c){this.d=c?new gg:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function ob(a){var b,c;for(c=new bg(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Ye(){Ze();var a=Xe;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function _b(){var a;try{Qb(Ob);K()}finally{a=Ob.d;!a&&((K(),K(),J).d=true);Ob=Ob.d}}
function vh(a,b){A((K(),K(),J),new Hh(a),142606336);return b.getPrimaryService(Ji)}
function If(a,b){var c,d;for(d=new Rf(b.a);d.b;){c=Qf(d);if(!Nf(a,c)){return false}}return true}
function Pf(a){if(a.a.L()){return true}if(a.a!=a.c){return false}a.a=new jg(a.d.a);return a.a.L()}
function Ve(a){var b;if($c(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new pc(a);Mc(b)}return b}
function Uc(a,b,c,d,e){e.V=a;e.W=b;e.X=jf;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function hg(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function eg(a){var b,c,d;d=0;for(c=new Rf(a.a);c.b;){b=Qf(c);d=d+(b?xg(b.b.value[0])^xg(ug(b)):0);d=d|0}return d}
function cc(a){var b,c;for(c=new bg(new ag(new Of(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);ug(b).n()}}
function db(a,b){var c,d;d=a.c;Yf(d,b);!!a.b&&Gi!=(a.b.c&1835008)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Vb((K(),c=Ob,c),a))}
function Ib(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function zg(a,b){if(0>a||a>b){throw We(new qf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function _e(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function X(a){this.c=a;this.g=null;this.i=null;this.h=false;this.f=new vb(this);this.e=new jb(this.f)}
function vf(){this.g=sf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function Oh(a){this.e=new Eh;this.c=a;K();++Mh;this.b=new fc(new Ph(this),new Qh(this),false);this.a=new ub(new Sh(this))}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new yb(a)),67108864,null);!!a.a&&S(a.a);Fb(a.f);a.c=a.c&-8|1}}
function Gb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Gi)?Hb(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function r(a){return bd(a)?Ud:ad(a)?Md:_c(a)?Kd:Zc(a)?a.V:Tc(a)?a.V:a.V||Array.isArray(a)&&Pc(Dd,1)||Dd}
function s(a){return bd(a)?dh(a):ad(a)?dd(a):_c(a)?a?1231:1237:Zc(a)?a.m():Tc(a)?Yg(a):!!a&&!!a.hashCode?a.hashCode():Yg(a)}
function hf(a){var b;if(Array.isArray(a)&&a.X===jf){return uf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function dh(a){ah();var b,c,d;c=':'+a;d=_g[c];if(d!=null){return dd(d)}d=Zg[c];b=d==null?bh(a):dd(d);eh();_g[c]=b;return b}
function fg(a){var b,c,d;d=1;for(c=new bg(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Jb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function pi(a){var b,c;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){c=$wnd.Math.max(a.a.length-1,1)*2+1;ni(a,c,b)}}
function Ub(a){var b;if(a.c){while(a.c.a.length!=0){b=Xf(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&rb(b.b,3,true)}}}
function $f(a,b){var c,d;d=a.a.length;b.length<d&&(b=Wg(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Cf(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function ii(a,b){var c,d;d=0==O(a.d);c=new xi(b);ji(a.d,c);d&&$wnd.Promise.resolve(null).then(ff(ui.prototype.v,ui,[a]));return c}
function wc(){var a;if(rc!=0){a=qc();if(a-sc>2000){sc=a;tc=$wnd.setTimeout(Cc,10)}}if(rc++==0){Fc((Ec(),Dc));return true}return false}
function Yc(a,b){if(bd(a)){return !!Xc[b]}else if(a.W){return !!a.W[b]}else if(ad(a)){return !!Wc[b]}else if(_c(a)){return !!Vc[b]}return false}
function Nc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return bd(a)?o(a,b):ad(a)?cd(a)===cd(b):_c(a)?a===b:Zc(a)?a.k(b):Tc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):cd(a)===cd(b)}
function mh(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function th(a){$wnd['navigator'].bluetooth.requestDevice(pf(of({}),[nf({},[Ji])])).then(ff(Uh.prototype.w,Uh,[a])).catch(ff(Xh.prototype.B,Xh,[]))}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function mi(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}else{b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}}
function si(a){var b;if(0==a.c){b=O(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;ki(a.d);return false}else{a.a=a.a+1;a.c=b}}--a.c;hi(a);return true}
function Ab(a){var b,c;if(0==a.c){b=Kb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Jb(a.d);Gb(c);return true}
function T(a){a.h?hb(a.e):gb(a.e);if(sb(a.f)){if(a.h&&(K(),!(!!Ob&&!!Ob.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{mb(a.f)}}return W(a)}
function Xb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new bg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&rb(b,6,true)}}}
function Yb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new bg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&rb(b,5,true)}}}
function Wb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new bg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?rb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function ni(a,b,c){var d,e,f,g;d=Rc(Sd,Fi,1,b,5,1);g=0;for(e=0;e<c;e++){f=(a.b+e)%a.a.length;d[g]=a.a[f];a.a[f]=null;++g}a.a=d;a.b=0;a.d=g;a.c=false}
function Jf(a,b){var c,d,e,f;f=Mf(a.a);b.length<f&&(b=Wg(new Array(f),b));e=b;d=new Rf(a.a);for(c=0;c<f;++c){e[c]=Qf(d)}b.length>f&&(b[f]=null);return b}
function Sc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{$b(b,d);try{f=(R(c.a.a),null)}finally{_b()}return f}catch(a){a=Ve(a);if($c(a,4)){e=a;throw We(e)}else throw We(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ob){g=c.o()}else{$b(b,e);try{g=c.o()}finally{_b()}}return g}catch(a){a=Ve(a);if($c(a,4)){f=a;throw We(f)}else throw We(a)}finally{D(b)}}
function $e(b,c,d,e){Ze();var f=Xe;$moduleName=c;$moduleBase=d;Ue=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Di(g)()}catch(a){b(c,a)}}else{Di(g)()}}
function Eh(){var a,b;this.e=new Th(this);this.f=new Wh(this);K();++zh;this.d=new fc(null,new Fh(this),true);this.b=(b=new jb((a=null,a)),b);this.a=new X(new Ih(this))}
function hh(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function ng(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return og()}}
function Jc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Y()&&(c=Ic(c,g)):g[0].Y()}catch(a){a=Ve(a);if($c(a,4)){d=a;uc();Ac($c(d,21)?d.u():d)}else throw We(a)}}return c}
function bf(){af={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function R(b){var c,d,e;e=b.i;try{d=Dh(b.c.a);if(!(e==d||e!=null&&e==d)){b.i=d;b.b=null;eb(b.e)}}catch(a){a=Ve(a);if($c(a,7)){c=a;if(!b.b){b.i=null;b.b=c;eb(b.e)}throw We(c)}else throw We(a)}}
function Sg(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function bh(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ff(a,c++)}b=b|0;return b}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Rc(Sd,Fi,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{Lh(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Ve(a);if($c(a,4)){K()}else throw We(a)}}}
function tb(a,b,c,d){this.b=new _f;this.f=new Ib(new xb(this),d&6520832|262144|Gi);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&2097152)&&D((null,J)))}
function df(a,b,c){var d=af,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=af[b]),gf(h));_.W=c;!b&&(_.X=jf);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.V=f)}
function Bf(a){if(a.H()){var b=a.c;b.I()?(a.j='['+b.i):!b.H()?(a.j='[L'+b.F()+';'):(a.j='['+b.F());a.b=b.D()+'[]';a.h=b.G()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=Cf('.',[c,Cf('$',d)]);a.b=Cf('.',[c,Cf('.',d)]);a.h=d[d.length-1]}
function Kf(a,b){var c,d,e,f,g;e=b.b.value[0];g=ug(b);f=e==null?Lf(hg((d=a.a.a.get(0),d==null?new Array:d))):rg(a.b,e);if(!(cd(g)===cd(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!hg((c=a.a.a.get(0),c==null?new Array:c)):qg(a.b,e))){return false}return true}
function sb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new bg(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Ve(a);if(!$c(a,4))throw We(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function ic(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.s();return a&&a.q()}},suppressed:{get:function(){return c.r()}}})}catch(a){}}}
function jh(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;gh(b,ff(lh.prototype.S,lh,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=hh($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function mg(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function yh(a,b){if(null==b){a.g=null;ec(new Gh(a,0))}else{a.g=b.gatt;null!=a.g&&a.g.connect().then(ff(Yh.prototype.A,Yh,[a])).then(ff(Zh.prototype.A,Zh,[])).then(ff(Vh.prototype.A,Vh,[])).then(ff($h.prototype.w,$h,[a])).catch(ff(_h.prototype.B,_h,[]));b.addEventListener('gattserverdisconnected',a.f)}A((K(),K(),J),new Hh(a),142606336)}
function rb(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==f&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.i=null}Uf(a.b,new zb(a));a.b.a=Rc(Sd,Fi,1,0,5,1)}else 3==f&&(3&b)==0&&!!a.a&&(e=a.a.g,e)}}
function Kh(a){var b,c,d;a.d=0;fi();b=(c=Ch(a.e),d=T(a.e.a),jh('div',mh(new $wnd.Object,Uc(Pc(Ud,1),Fi,2,6,['container'])),[jh('div',mh(new $wnd.Object,Uc(Pc(Ud,1),Fi,2,6,['hrm_panel'])),[jh('h1',null,['Heart Rate Monitor']),jh('img',ph(mh(new $wnd.Object,Uc(Pc(Ud,1),Fi,2,6,['heart',c>0?'beating':null]))),null),0!=c?c:null,jh('button',oh(nh(new $wnd.Object,d),ff(qh.prototype.T,qh,[a])),['Start']),jh('button',oh(nh(new $wnd.Object,!d),ff(rh.prototype.T,rh,[a])),['Stop'])])]));return b}
function Rb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Vf(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Zf(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&rb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Vf(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Xf(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new _f)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Gi!=(k.b.c&1835008)&&k.c.a.length<=0&&0==k.b.a.d&&Vb(a,k)}}
function og(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!mg()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Ei={12:1},Fi={3:1},Gi=1048576,Hi='__noinit__',Ii={3:1,7:1,6:1,4:1},Ji='heart_rate';var _,af,Xe,Ue=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;bf();df(1,null,{},p);_.k=function(a){return o(this,a)};_.l=function(){return this.V};_.m=function(){return Yg(this)};_.equals=function(a){return this.k(a)};_.hashCode=function(){return this.m()};df(32,1,{},vf);_.C=function(a){var b;b=new vf;b.e=4;a>1?(b.c=zf(this,a-1)):(b.c=this);return b};_.D=function(){tf(this);return this.b};_.F=function(){return uf(this)};_.G=function(){tf(this);return this.h};_.H=function(){return (this.e&4)!=0};_.I=function(){return (this.e&1)!=0};_.e=0;_.g=0;var sf=1;var Sd=xf(1);var Ld=xf(32);df(54,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var jd=xf(54);df(55,1,Ei,G);_.n=function(){Bb(this.a)};var fd=xf(55);df(22,1,{},H);_.o=function(){return this.a.n(),null};var gd=xf(22);df(56,1,{},I);var hd=xf(56);var J;df(23,1,{23:1},Q);_.b=0;_.c=false;_.d=0;var kd=xf(23);df(130,1,{});var nd=xf(130);df(92,130,{},X);_.a=false;_.d=0;_.h=false;var md=xf(92);df(93,1,{},Y);_.o=function(){return U(this.a)};var ld=xf(93);df(26,130,{26:1},jb);_.a=4;_.d=false;_.e=0;var pd=xf(26);df(91,1,Ei,kb);_.n=function(){bb(this.a)};var od=xf(91);df(18,130,{18:1},ub,vb);_.c=0;var ud=xf(18);df(86,1,{},wb);var qd=xf(86);df(87,1,Ei,xb);_.n=function(){mb(this.a)};var rd=xf(87);df(88,1,Ei,yb);_.n=function(){pb(this.a)};var sd=xf(88);df(89,1,{},zb);_.p=function(a){nb(this.a,a)};var td=xf(89);df(64,1,{},Cb);_.a=0;_.b=0;_.c=0;var vd=xf(64);df(97,1,{},Eb);_.a=false;var wd=xf(97);df(36,130,{36:1},Ib);_.a=0;var yd=xf(36);df(63,1,{},Nb);var xd=xf(63);df(98,1,{},Zb);_.a=0;var Ob;var zd=xf(98);df(37,1,{},fc);_.g=0;var Bd=xf(37);df(85,1,Ei,gc);_.n=function(){dc(this.a)};var Ad=xf(85);df(4,1,{3:1,4:1});_.q=Ki;_.r=function(){var a,b;return a=Jg(Ig(dg((this.e==null&&(this.e=Rc(Vd,Fi,4,0,0,1)),this.e))),(b=new _f,b)),$f(a,Rc(Sd,Fi,1,a.a.length,5,1))};_.s=Li;_.t=function(){jc(this,lc(new Error(kc(this,this.d))));Mc(this)};_.b=Hi;_.f=true;var Vd=xf(4);df(7,4,{3:1,7:1,4:1});var Nd=xf(7);df(6,7,Ii);var Td=xf(6);df(49,6,Ii);var Qd=xf(49);df(50,49,Ii);var Fd=xf(50);df(21,50,{21:1,3:1,7:1,6:1,4:1},pc);_.u=function(){return cd(this.a)===cd(nc)?null:this.a};var nc;var Cd=xf(21);var Dd=xf(0);df(112,1,{});var Ed=xf(112);var rc=0,sc=0,tc=-1;df(59,112,{},Hc);var Dc;var Gd=xf(59);var Kc;df(124,1,{});var Id=xf(124);df(51,124,{},Oc);var Hd=xf(51);var Vc,Wc,Xc;var lf;df(53,6,Ii);var Pd=xf(53);df(90,53,Ii,qf);var Jd=xf(90);Vc={3:1,45:1,43:1};var Kd=xf(45);df(122,1,Fi);var Rd=xf(122);Wc={3:1,43:1};var Md=xf(123);df(52,6,Ii,Ef);var Od=xf(52);df(183,1,{});Xc={3:1,44:1,43:1,2:1};var Ud=xf(2);df(187,1,{});df(34,6,Ii,Hf);var Wd=xf(34);df(125,1,{28:1});_.J=function(a){throw We(new Hf('Add not supported on this collection'))};var Xd=xf(125);df(128,1,{109:1});_.k=function(a){var b,c,d;if(a===this){return true}if(!$c(a,24)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Rf((new Of(d)).a);c.b;){b=Qf(c);if(!Kf(this,b)){return false}}return true};_.m=function(){return eg(new Of(this))};var be=xf(128);df(65,128,{109:1});var $d=xf(65);df(127,125,{28:1,134:1});_.k=function(a){var b;if(a===this){return true}if(!$c(a,16)){return false}b=a;if(Mf(b.a)!=this.K()){return false}return If(this,b)};_.m=function(){return eg(this)};var ce=xf(127);df(16,127,{16:1,28:1,134:1},Of);_.K=function(){return Mf(this.a)};var Zd=xf(16);df(17,1,{},Rf);_.M=function(){return Qf(this)};_.L=Ki;_.b=false;var Yd=xf(17);df(126,125,{28:1,131:1});_.N=function(a,b){throw We(new Hf('Add not supported on this list'))};_.J=function(a){this.N(this.K(),a);return true};_.k=function(a){var b,c,d,e,f;if(a===this){return true}if(!$c(a,9)){return false}f=a;if(this.K()!=f.a.length){return false}e=new bg(f);for(c=new bg(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(cd(b)===cd(d)||b!=null&&q(b,d))){return false}}return true};_.m=function(){return fg(this)};var _d=xf(126);df(129,1,{135:1});_.k=function(a){var b;if(!$c(a,25)){return false}b=a;return wg(this.b.value[0],b.b.value[0])&&wg(ug(this),ug(b))};_.m=function(){return xg(this.b.value[0])^xg(ug(this))};var ae=xf(129);df(9,126,{3:1,9:1,28:1,131:1},_f,ag);_.N=function(a,b){Tg(this.a,a,b)};_.J=function(a){return Tf(this,a)};_.K=function(){return this.a.length};var ee=xf(9);df(11,1,{},bg);_.L=function(){return this.a<this.c.a.length};_.M=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var de=xf(11);df(24,65,{3:1,24:1,109:1},gg);var fe=xf(24);df(66,1,{},ig);_.b=0;var he=xf(66);df(67,1,{},jg);_.M=function(){return this.d=this.a[this.c++],this.d};_.L=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var ge=xf(67);var kg;df(68,1,{},sg);_.b=0;_.c=0;var ke=xf(68);df(69,1,{},tg);_.M=function(){return this.c=this.a,this.a=this.b.next(),new vg(this.d,this.c,this.d.c)};_.L=function(){return !this.a.done};var ie=xf(69);df(25,129,{25:1,135:1},vg);_.c=0;var je=xf(25);df(71,1,{});_.Q=Mi;_.O=Ki;_.P=Li;_.b=0;_.c=0;var oe=xf(71);df(72,71,{});var le=xf(72);df(60,1,{});_.Q=Mi;_.O=Ki;_.P=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var ne=xf(60);df(61,60,{},Eg);_.Q=function(a){Bg(this,a)};_.R=function(a){return Cg(this,a)};var me=xf(61);df(70,1,{});_.c=false;var ue=xf(70);df(35,70,{},Kg);var te=xf(35);df(73,72,{},Ng);_.R=function(a){return this.a.R(new Og(a))};var qe=xf(73);df(75,1,{},Og);_.p=function(a){this.a.p(a.b)};var pe=xf(75);df(74,1,{},Qg);_.p=function(a){Pg(this,a)};var re=xf(74);df(76,1,{},Rg);_.p=function(a){Mg(this.a,a)};var se=xf(76);df(185,1,{});df(182,1,{});var Xg=0;var Zg,$g=0,_g;df(791,1,{});df(816,1,{});df(166,$wnd.Function,{},lh);_.S=function(a){kh(this.a,this.b,a)};df(78,1,{});var we=xf(78);df(155,$wnd.Function,{},qh);_.T=function(a){th(this.a.e)};df(156,$wnd.Function,{},rh);_.T=function(a){uh(this.a.e)};df(42,1,{},sh);var ve=xf(42);df(99,1,{});var Je=xf(99);df(100,99,{},Eh);_.c=0;var zh=0;var Be=xf(100);df(101,1,Ei,Fh);_.n=function(){Ah(this.a)};var xe=xf(101);df(38,1,Ei,Gh);_.n=function(){Bh(this.a,this.b)};_.b=0;var ye=xf(38);df(39,1,Ei,Hh);_.n=function(){V(this.a.a)};var ze=xf(39);df(102,1,{},Ih);_.o=function(){return Dh(this.a)};var Ae=xf(102);df(79,78,{});_.d=0;var Le=xf(79);df(80,79,{},Oh);var Mh=0;var Ge=xf(80);df(81,1,Ei,Ph);_.n=function(){Z(this.a.e)};var Ce=xf(81);df(82,1,Ei,Qh);_.n=function(){lb(this.a.a)};var De=xf(82);df(84,1,{},Rh);_.o=function(){return Kh(this.a)};var Ee=xf(84);df(83,1,{},Sh);var Fe=xf(83);df(94,1,{},Th);_.handleEvent=function(a){xh(this.a,a)};var He=xf(94);df(158,$wnd.Function,{},Uh);_.w=function(a){yh(this.a,a)};df(162,$wnd.Function,{},Vh);_.A=function(a){return a.startNotifications()};df(95,1,{},Wh);_.handleEvent=function(a){yh(this.a,null)};var Ie=xf(95);df(159,$wnd.Function,{},Xh);_.B=Ni;df(160,$wnd.Function,{},Yh);_.A=function(a){return vh(this.a,a)};df(161,$wnd.Function,{},Zh);_.A=function(a){return a.getCharacteristic('heart_rate_measurement')};df(163,$wnd.Function,{},$h);_.w=function(a){wh(this.a,a)};df(164,$wnd.Function,{},_h);_.B=Ni;df(153,$wnd.Function,{},ai);_.U=function(a){return new di(a)};var bi;df(62,$wnd.React.Component,{},di);cf(af[1],_);_.componentWillUnmount=function(){Jh(this.a)};_.render=function(){return Nh(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var Ke=xf(62);var ei;df(96,1,{157:1},gi);var Me=xf(96);df(104,1,{});var Ne=xf(104);df(107,1,{},qi);_.b=0;_.c=false;_.d=0;var Oe=xf(107);df(40,104,{});_.a=0;_.b=0;_.c=0;var Re=xf(40);df(106,40,{},ti);var Pe=xf(106);df(167,$wnd.Function,{},ui);_.v=function(a){return ri((new vi(this.a)).a),null};df(105,1,{},vi);var Qe=xf(105);df(41,1,{41:1},xi);var Se=xf(41);df(103,1,{},zi);var Te=xf(103);var Ai;var ed=yf('D');var Di=(uc(),xc);var gwtOnLoad=gwtOnLoad=$e;Ye(kf);_e('permProps',[[]]);if (hrm) hrm.onScriptLoad(gwtOnLoad);})();