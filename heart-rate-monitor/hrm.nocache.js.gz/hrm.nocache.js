function hrm(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='hrm',tb='__gwt_marker_hrm',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='BB8AAF8F74341E7A02DA66F8A1FB8F49',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};hrm.onScriptLoad=function(a){hrm=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
hrm();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'BB8AAF8F74341E7A02DA66F8A1FB8F49';function p(){}
function mf(){}
function hf(){}
function Hb(){}
function Kc(){}
function Rc(){}
function Qg(){}
function Vh(){}
function Xh(){}
function Zh(){}
function _h(){}
function ai(){}
function gi(){}
function Pc(a){Oc()}
function rf(){rf=hf}
function _f(){Sf(this)}
function J(a){this.a=a}
function K(a){this.a=a}
function L(a){this.a=a}
function ab(a){this.a=a}
function nb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function Cb(a){this.a=a}
function jc(a){this.a=a}
function Of(a){this.a=a}
function Og(a){this.a=a}
function Rg(a){this.a=a}
function bg(a){this.c=a}
function qh(a){this.a=a}
function rh(a){this.a=a}
function Fh(a){this.a=a}
function Hh(a){this.a=a}
function Ih(a){this.a=a}
function Ph(a){this.a=a}
function Qh(a){this.a=a}
function Rh(a){this.a=a}
function Sh(a){this.a=a}
function Th(a){this.a=a}
function Uh(a){this.a=a}
function Wh(a){this.a=a}
function Yh(a){this.a=a}
function $h(a){this.a=a}
function ui(a){this.a=a}
function vi(a){this.a=a}
function xi(a){this.a=a}
function zi(a){this.a=a}
function ig(){this.a=pg()}
function sg(){this.a=pg()}
function Pg(a,b){a.a=b}
function tb(a,b){a.b=b}
function gh(a,b){fh(a,b)}
function G(a,b){Pb(a.f,b.f)}
function O(a,b){S(a);P(a,b)}
function C(a){--a.e;H(a)}
function ec(a){!!a&&a.q()}
function bb(a){!!a&&dc(a.d)}
function hb(a){Zb((N(),a))}
function ib(a){$b((N(),a))}
function lb(a){_b((N(),a))}
function Mi(a){yg(this,a)}
function Ze(a){return a.b}
function Ni(a){return null}
function Ki(){return this.b}
function Li(){return this.c}
function qf(a){pc.call(this,a)}
function Hf(a){pc.call(this,a)}
function Jh(a){a.d=2;dc(a.b)}
function Ah(a){V(a.a);db(a.b)}
function ji(a,b){pi(a);P(a,b)}
function mc(a,b){a.b=b;lc(a,b)}
function Vg(a,b){a.splice(b,1)}
function Dg(a,b,c){b.s(a.a[c])}
function Vf(a,b){return a.a[b]}
function Sc(a,b){return zf(a,b)}
function uf(a){tf(a);return a.j}
function pg(){lg();return new kg}
function Lg(a,b){a.J(b);return a}
function yg(a,b){while(a.R(b));}
function Mg(a,b){Pg(a,Lg(a.a,b))}
function B(a,b,c){w(a,new L(c),b)}
function N(){N=hf;M=new I}
function rc(){rc=hf;qc=new p}
function Hc(){Hc=hf;Gc=new Kc}
function lg(){lg=hf;kg=ng()}
function xc(){xc=hf;!!(Oc(),Nc)}
function Fc(){uc!=0&&(uc=0);wc=-1}
function eb(a){N();$b(a);a.e=-2}
function Tb(a){Ub(a);!a.d&&Xb(a)}
function X(a){pb(a.f);return Z(a)}
function Ch(a){jb(a.b);return a.c}
function yi(a,b){return ii(a.a,b)}
function rg(a,b){return a.a.get(b)}
function Mf(a){return a.a.b+a.b.b}
function Lf(a){return !a?null:ug(a)}
function Vb(a){return !a.d?a:Vb(a.d)}
function o(a,b){return fd(a)===fd(b)}
function fd(a){return a==null?null:a}
function xg(a){return a!=null?s(a):0}
function af(){$e==null&&($e=[])}
function sh(){this.a=ih((ci(),bi))}
function lh(a,b){this.a=a;this.b=b}
function Gh(a,b){this.a=a;this.b=b}
function Fb(a){this.d=a;this.b=100}
function mb(a){this.c=new _f;this.b=a}
function ah(){ah=hf;Zg=new p;_g=new p}
function Bi(){Bi=hf;Ai=new zi(new ti)}
function Ec(a){$wnd.clearTimeout(a)}
function Sf(a){a.a=Uc(Vd,Fi,1,0,5,1)}
function ki(a){a.b=0;a.d=0;a.c=false}
function v(a,b){a.filters=b;return a}
function t(a,b){a.services=b;return a}
function oh(a,b){a.onClick=b;return a}
function nh(a,b){a.disabled=b;return a}
function Tg(a,b,c){a.splice(b,0,c)}
function D(a,b,c){A(a,new K(b),c,null)}
function F(a,b,c){return A(a,c,2048,b)}
function Ff(a,b){return a.charCodeAt(b)}
function bd(a,b){return a!=null&&_c(a,b)}
function Ci(a){return yi((Bi(),Ai),a)}
function Yg(a){return a.$H||(a.$H=++Xg)}
function cb(a){return !(!!a&&1==(a.c&7))}
function sb(a){N();rb(a);ub(a,2,true)}
function jb(a){var b;Wb((N(),b=Rb,b),a)}
function Ug(a,b){Sg(b,0,a,0,b.length)}
function fh(a,b){for(var c in a){b(c)}}
function Kg(a,b){Hg.call(this,a);this.a=b}
function pc(a){this.d=a;kc(this);this.w()}
function ti(){this.d=new qi;this.b=100}
function gg(){this.a=new ig;this.b=new sg}
function T(){this.a=Uc(Vd,Fi,1,100,5,1)}
function qi(){this.a=Uc(Vd,Fi,1,100,5,1)}
function tf(a){if(a.j!=null){return}Bf(a)}
function kc(a){a.f&&a.b!==Hi&&a.w();return a}
function xf(a){var b;b=wf(a);Df(a,b);return b}
function ed(a){return typeof a==='string'}
function dd(a){return typeof a==='number'}
function cd(a){return typeof a==='boolean'}
function yc(a,b,c){return a.apply(b,c);var d}
function Ob(a,b,c){c.a=-4&c.a|1;O(a.a[b],c)}
function Ib(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function Y(a){4==(a.f.c&7)&&ub(a.f,5,true)}
function Tf(a,b){a.a[a.a.length]=b;return true}
function ph(a){a.src='img/heart.svg';return a}
function u(a){a.acceptAllDevices=false;return a}
function ri(a){while(true){if(!si(a)){break}}}
function Eb(a){while(true){if(!Db(a)){break}}}
function Bg(a,b){while(a.c<a.d){Dg(a,b,a.c++)}}
function uh(a){null!=a.g&&a.g.disconnect()}
function Pb(a,b){Ob(a,((b.a&229376)>>15)-1,b)}
function qb(a,b){gb(b,a);b.c.a.length>0||(b.a=4)}
function vg(a,b,c){this.a=a;this.b=b;this.c=c}
function Oc(){Oc=hf;var a;!Qc();a=new Rc;Nc=a}
function Wc(a){return Array.isArray(a)&&a.X===mf}
function ad(a){return !Array.isArray(a)&&a.X===mf}
function dg(a){return new Kg(null,cg(a,a.length))}
function Ig(a){Gg(a);return new Kg(a,new Ng(a.a))}
function cg(a,b){return zg(b,a.length),new Eg(a,b)}
function qg(a,b){return !(a.a.get(b)===undefined)}
function Lc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Xf(a,b){var c;c=a.a[b];Vg(a.a,b);return c}
function Qf(a){var b;b=a.a.M();a.b=Pf(a);return b}
function yf(a){var b;b=wf(a);b.i=a;b.e=1;return b}
function Zf(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Nf(a,b){if(b){return Kf(a.a,b)}return false}
function Nh(a){return F((N(),N(),M),a.a,new Rh(a))}
function R(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Lh(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Gb(a){if(!a.a){a.a=true;C((N(),N(),M))}}
function Fg(a){if(!a.b){Gg(a);a.c=true}else{Fg(a.b)}}
function wi(a){if(a.a){Gb(ei);ei=null;a.a=null}}
function hc(a){N();Rb?Bh(a.a,a.b):D((null,M),a,0)}
function kb(a){var b;N();!!Rb&&!!Rb.e&&Wb((b=Rb,b),a)}
function Bh(a,b){var c;c=a.c;if(b!=c){a.c=b;ib(a.b)}}
function wg(a,b){return fd(a)===fd(b)||a!=null&&q(a,b)}
function Ag(a,b){this.c=a;this.b=(b&64)!=0?b|16384:b}
function Eg(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function ac(a,b){this.a=(N(),N(),M).b++;this.d=a;this.e=b}
function Ng(a){Ag.call(this,a.P(),a.O()&-6);this.a=a}
function xb(a){wb.call(this,null,null,a,1411780608)}
function yb(a){wb.call(this,a,new zb(a),null,304611328)}
function Hg(a){if(!a){this.b=null;new _f}else{this.b=a}}
function Af(a){if(a.I()){return null}var b=a.i;return df[b]}
function Sb(a){if(a.e){2==(a.e.c&7)||ub(a.e,4,true);rb(a.e)}}
function Gg(a){if(a.b){Gg(a.b)}else if(a.c){throw Ze(new Ef)}}
function fi(){if(!ei){ei=(++(N(),N(),M).e,new Hb);Ci(new gi)}}
function eh(){if($g==256){Zg=_g;_g=new p;$g=0}++$g}
function pf(){pf=hf;of=$wnd.goog.global.document}
function Dc(a){xc();$wnd.setTimeout(function(){throw a},0)}
function nc(a,b){var c;c=uf(a.V);return b==null?c:c+': '+b}
function zf(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.C(b))}
function ff(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function bc(a,b){Rb=new ac(Rb,b);a.d=false;Sb(Rb);return Rb}
function kf(a){function b(){}
;b.prototype=a||{};return new b}
function oc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Cg(a,b){if(a.c<a.d){Dg(a,b,a.c++);return true}return false}
function Dh(a){return rf(),null!=a.g&&a.g.connected?true:false}
function ci(){ci=hf;var a;bi=(a=jf(ai.prototype.U,ai,[]),a)}
function I(){this.f=new Qb;this.a=new Fb(this.f);new J(this.a)}
function jg(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function di(a){$wnd.React.Component.call(this,a);this.a=new Oh(this)}
function wh(a,b){b.addEventListener('characteristicvaluechanged',a.e)}
function kh(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Bc(a,b,c){var d;d=zc();try{return yc(a,b,c)}finally{Cc(d)}}
function fb(a,b){var c,d;Tf(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Jg(a,b){var c;Fg(a);c=new Qg;c.a=b;a.a.Q(new Rg(c));return c.a}
function P(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function gc(a){ec(a.f);!!a.d&&fc(a);bb(a.a);bb(a.c);ec(a.b);ec(a.e)}
function db(a){if(-2!=a.e){D((N(),N(),M),new nb(a),0);!!a.b&&ob(a.b)}}
function ag(a){Sf(this);Ug(this.a,Jf(a,Uc(Vd,Fi,1,Mf(a.a),5,1)))}
function tg(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Rf(a){this.d=a;this.c=new tg(this.d.b);this.a=this.c;this.b=Pf(this)}
function Kb(b){try{pb(b.b.a)}catch(a){a=Ye(a);if(!bd(a,5))throw Ze(a)}}
function Cc(a){a&&Jc((Hc(),Gc));--uc;if(a){if(wc!=-1){Ec(wc);wc=-1}}}
function gd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ac(b){xc();return function(){return Bc(b,this,arguments);var a}}
function tc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function ug(a){if(a.a.c!=a.c){return rg(a.a,a.b.value[0])}return a.b.value[1]}
function Wf(a,b,c){for(;c<a.a.length;++c){if(wg(b,a.a[c])){return c}}return -1}
function Nb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=R(a.a[c])}return b}
function Uf(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.s(c)}}
function xh(a,b){var c,d;c=b.target;d=c.value;hc(new Gh(a,d.getInt8(1)))}
function Yf(a,b){var c;c=Wf(a,b,0);if(c==-1){return false}Vg(a.a,c);return true}
function Uc(a,b,c,d,e,f){var g;g=Vc(e,d);e!=10&&Xc(Sc(a,f),b,c,e,g);return g}
function Wg(a,b){return Tc(b)!=10&&Xc(r(b),b.W,b.__elementTypeId$,Tc(b),a),a}
function Tc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function V(a){if(!a.a){a.a=true;a.i=null;a.b=null;db(a.e);2==(a.f.c&7)||ob(a.f)}}
function H(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Eb(a.a)}finally{a.c=false}}}}
function Z(a){if(a.b){if(bd(a.b,6)){throw Ze(a.b)}else{throw Ze(a.b)}}return a.i}
function dc(a){if(a.g>=0){a.g=-2;A((N(),N(),M),new K(new jc(a)),67108864,null)}}
function nf(){$wnd.ReactDOM.render((new sh).a,(pf(),of).getElementById('app'),null)}
function Qb(){var a;this.a=Uc(nd,Fi,23,5,0,1);for(a=0;a<5;a++){this.a[a]=new T}}
function Ic(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Mc(b,c)}while(a.a);a.a=c}}
function Jc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Mc(b,c)}while(a.b);a.b=c}}
function Wb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new _f);Tf(a.b,b)}}}
function Yb(a,b){var c;if(!a.c){c=Vb(a);!c.c&&(c.c=new _f);a.c=c.c}b.d=true;Tf(a.c,b)}
function Df(a,b){var c;if(!a){return}b.i=a;var d=Af(b);if(!d){df[a]=[b];return}d.V=b}
function jf(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function wf(a){var b;b=new vf;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function ih(a){var b;b=hh($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function sc(a){rc();kc(this);this.b=a;lc(this,a);this.d=a==null?'null':lf(a);this.a=a}
function ic(a,b,c){this.d=c?new gg:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function rb(a){var b,c;for(c=new bg(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function _e(){af();var a=$e;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Ef(){pc.call(this,"Stream already terminated, can't be modified or used")}
function vh(a,b){D((N(),N(),M),new Hh(a),142606336);return b.getPrimaryService(Ji)}
function hi(b){var c;c=mi(b.d);try{wi(c)}catch(a){a=Ye(a);if(!bd(a,5))throw Ze(a)}}
function cc(){var a;try{Tb(Rb);N()}finally{a=Rb.d;!a&&((N(),N(),M).d=true);Rb=Rb.d}}
function If(a,b){var c,d;for(d=new Rf(b.a);d.b;){c=Qf(d);if(!Nf(a,c)){return false}}return true}
function Pf(a){if(a.a.L()){return true}if(a.a!=a.c){return false}a.a=new jg(a.d.a);return a.a.L()}
function Ye(a){var b;if(bd(a,5)){return a}b=a&&a.__java$exception;if(!b){b=new sc(a);Pc(b)}return b}
function Xc(a,b,c,d,e){e.V=a;e.W=b;e.X=mf;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function hg(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function eg(a){var b,c,d;d=0;for(c=new Rf(a.a);c.b;){b=Qf(c);d=d+(b?xg(b.b.value[0])^xg(ug(b)):0);d=d|0}return d}
function fc(a){var b,c;for(c=new bg(new ag(new Of(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);ug(b).q()}}
function gb(a,b){var c,d;d=a.c;Yf(d,b);!!a.b&&Gi!=(a.b.c&1835008)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Yb((N(),c=Rb,c),a))}
function Lb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function zg(a,b){if(0>a||a>b){throw Ze(new qf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function cf(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function $(a){this.c=a;this.g=null;this.i=null;this.h=false;this.f=new yb(this);this.e=new mb(this.f)}
function vf(){this.g=sf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function Oh(a){this.e=new Eh;this.c=a;N();++Mh;this.b=new ic(new Ph(this),new Qh(this),false);this.a=new xb(new Sh(this))}
function ob(a){if(2<(a.c&7)){A((N(),N(),M),new K(new Bb(a)),67108864,null);!!a.a&&V(a.a);Ib(a.f);a.c=a.c&-8|1}}
function Jb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&Gi)?Kb(a):pb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function r(a){return ed(a)?Xd:dd(a)?Pd:cd(a)?Nd:ad(a)?a.V:Wc(a)?a.V:a.V||Array.isArray(a)&&Sc(Gd,1)||Gd}
function s(a){return ed(a)?dh(a):dd(a)?gd(a):cd(a)?a?1231:1237:ad(a)?a.m():Wc(a)?Yg(a):!!a&&!!a.hashCode?a.hashCode():Yg(a)}
function lf(a){var b;if(Array.isArray(a)&&a.X===mf){return uf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function dh(a){ah();var b,c,d;c=':'+a;d=_g[c];if(d!=null){return gd(d)}d=Zg[c];b=d==null?bh(a):gd(d);eh();_g[c]=b;return b}
function fg(a){var b,c,d;d=1;for(c=new bg(a);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Mb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=Q(d);return c}}return null}
function pi(a){var b,c;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){c=$wnd.Math.max(a.a.length-1,1)*2+1;ni(a,c,b)}}
function Xb(a){var b;if(a.c){while(a.c.a.length!=0){b=Xf(a.c,a.c.a.length-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&ub(b.b,3,true)}}}
function $f(a,b){var c,d;d=a.a.length;b.length<d&&(b=Wg(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Cf(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function ii(a,b){var c,d;d=0==R(a.d);c=new xi(b);ji(a.d,c);d&&$wnd.Promise.resolve(null).then(jf(ui.prototype.B,ui,[a]));return c}
function zc(){var a;if(uc!=0){a=tc();if(a-vc>2000){vc=a;wc=$wnd.setTimeout(Fc,10)}}if(uc++==0){Ic((Hc(),Gc));return true}return false}
function _c(a,b){if(ed(a)){return !!$c[b]}else if(a.W){return !!a.W[b]}else if(dd(a)){return !!Zc[b]}else if(cd(a)){return !!Yc[b]}return false}
function Qc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return ed(a)?o(a,b):dd(a)?fd(a)===fd(b):cd(a)?a===b:ad(a)?a.k(b):Wc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):fd(a)===fd(b)}
function th(a){$wnd['navigator'].bluetooth.requestDevice(v(u({}),[t({},[Ji])])).then(jf(Uh.prototype.n,Uh,[a])).catch(jf(Xh.prototype.p,Xh,[]))}
function mh(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Q(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function mi(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}else{b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}}
function si(a){var b;if(0==a.c){b=R(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;ki(a.d);return false}else{a.a=a.a+1;a.c=b}}--a.c;hi(a);return true}
function Db(a){var b,c;if(0==a.c){b=Nb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Mb(a.d);Jb(c);return true}
function W(a){a.h?kb(a.e):jb(a.e);if(vb(a.f)){if(a.h&&(N(),!(!!Rb&&!!Rb.e))){return A((N(),N(),M),new ab(a),83888128,null)}else{pb(a.f)}}return Z(a)}
function $b(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new bg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&ub(b,6,true)}}}
function _b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new bg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&ub(b,5,true)}}}
function Zb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new bg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?ub(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function ni(a,b,c){var d,e,f,g;d=Uc(Vd,Fi,1,b,5,1);g=0;for(e=0;e<c;e++){f=(a.b+e)%a.a.length;d[g]=a.a[f];a.a[f]=null;++g}a.a=d;a.b=0;a.d=g;a.c=false}
function Jf(a,b){var c,d,e,f;f=Mf(a.a);b.length<f&&(b=Wg(new Array(f),b));e=b;d=new Rf(a.a);for(c=0;c<f;++c){e[c]=Qf(d)}b.length>f&&(b[f]=null);return b}
function Vc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function w(b,c,d){var e,f;try{bc(b,d);try{f=(U(c.a.a),null)}finally{cc()}return f}catch(a){a=Ye(a);if(bd(a,5)){e=a;throw Ze(e)}else throw Ze(a)}finally{H(b)}}
function A(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Rb){g=c.r()}else{bc(b,e);try{g=c.r()}finally{cc()}}return g}catch(a){a=Ye(a);if(bd(a,5)){f=a;throw Ze(f)}else throw Ze(a)}finally{H(b)}}
function bf(b,c,d,e){af();var f=$e;$moduleName=c;$moduleBase=d;Xe=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Di(g)()}catch(a){b(c,a)}}else{Di(g)()}}
function Eh(){var a,b;this.e=new Th(this);this.f=new Wh(this);N();++zh;this.d=new ic(null,new Fh(this),true);this.b=(b=new mb((a=null,a)),b);this.a=new $(new Ih(this))}
function hh(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function ng(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return og()}}
function Mc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Y()&&(c=Lc(c,g)):g[0].Y()}catch(a){a=Ye(a);if(bd(a,5)){d=a;xc();Dc(bd(d,21)?d.A():d)}else throw Ze(a)}}return c}
function ef(){df={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function U(b){var c,d,e;e=b.i;try{d=Dh(b.c.a);if(!(e==d||e!=null&&e==d)){b.i=d;b.b=null;hb(b.e)}}catch(a){a=Ye(a);if(bd(a,7)){c=a;if(!b.b){b.i=null;b.b=c;hb(b.e)}throw Ze(c)}else throw Ze(a)}}
function Sg(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function bh(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Ff(a,c++)}b=b|0;return b}
function S(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Uc(Vd,Fi,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function pb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;B((N(),N(),M),b,c)}else{Lh(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Ye(a);if(bd(a,5)){N()}else throw Ze(a)}}}
function wb(a,b,c,d){this.b=new _f;this.f=new Lb(new Ab(this),d&6520832|262144|Gi);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(G((N(),N(),M),this),0==(this.f.a&2097152)&&H((null,M)))}
function gf(a,b,c){var d=df,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=df[b]),kf(h));_.W=c;!b&&(_.X=mf);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.V=f)}
function Bf(a){if(a.H()){var b=a.c;b.I()?(a.j='['+b.i):!b.H()?(a.j='[L'+b.F()+';'):(a.j='['+b.F());a.b=b.D()+'[]';a.h=b.G()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=Cf('.',[c,Cf('$',d)]);a.b=Cf('.',[c,Cf('.',d)]);a.h=d[d.length-1]}
function Kf(a,b){var c,d,e,f,g;e=b.b.value[0];g=ug(b);f=e==null?Lf(hg((d=a.a.a.get(0),d==null?new Array:d))):rg(a.b,e);if(!(fd(g)===fd(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!hg((c=a.a.a.get(0),c==null?new Array:c)):qg(a.b,e))){return false}return true}
function vb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new bg(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{W(c)}catch(a){a=Ye(a);if(!bd(a,5))throw Ze(a)}if(6==(b.c&7)){return true}}}}}rb(b);return false}
function lc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.v();return a&&a.t()}},suppressed:{get:function(){return c.u()}}})}catch(a){}}}
function jh(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;gh(b,jf(lh.prototype.S,lh,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return g=hh($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function mg(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function yh(a,b){if(null==b){a.g=null;hc(new Gh(a,0))}else{a.g=b.gatt;null!=a.g&&a.g.connect().then(jf(Yh.prototype.o,Yh,[a])).then(jf(Zh.prototype.o,Zh,[])).then(jf(Vh.prototype.o,Vh,[])).then(jf($h.prototype.n,$h,[a])).catch(jf(_h.prototype.p,_h,[]));b.addEventListener('gattserverdisconnected',a.f)}D((N(),N(),M),new Hh(a),142606336)}
function ub(a,b,c){var d,e,f;f=a.c&7;if(b!=f){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||G((N(),N(),M),a))}else if(!!a.a&&4==f&&(6==b||5==b)){lb(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||G((N(),N(),M),a))}else if(3==b||3!=f&&2==b){if(a.a){d=a.a;d.i=null}Uf(a.b,new Cb(a));a.b.a=Uc(Vd,Fi,1,0,5,1)}else 3==f&&(3&b)==0&&!!a.a&&(e=a.a.g,e)}}
function Kh(a){var b,c,d;a.d=0;fi();b=(c=Ch(a.e),d=W(a.e.a),jh('div',mh(new $wnd.Object,Xc(Sc(Xd,1),Fi,2,6,['container'])),[jh('div',mh(new $wnd.Object,Xc(Sc(Xd,1),Fi,2,6,['hrm_panel'])),[jh('h1',null,['Heart Rate Monitor']),jh('img',ph(mh(new $wnd.Object,Xc(Sc(Xd,1),Fi,2,6,['heart',c>0?'beating':null]))),null),0!=c?c:null,jh('button',oh(nh(new $wnd.Object,d),jf(qh.prototype.T,qh,[a])),['Start']),jh('button',oh(nh(new $wnd.Object,!d),jf(rh.prototype.T,rh,[a])),['Stop'])])]));return b}
function Ub(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Vf(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Zf(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{gb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&ub(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Vf(a.b,g);if(-1==k.e){k.e=0;fb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Xf(a.b,g)}e&&tb(a.e,a.b)}else{e&&tb(a.e,new _f)}if(cb(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&Gi!=(k.b.c&1835008)&&k.c.a.length<=0&&0==k.b.a.d&&Yb(a,k)}}
function og(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!mg()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
var Ei={12:1},Fi={3:1},Gi=1048576,Hi='__noinit__',Ii={3:1,7:1,6:1,5:1},Ji='heart_rate';var _,df,$e,Xe=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;ef();gf(1,null,{},p);_.k=function(a){return o(this,a)};_.l=function(){return this.V};_.m=function(){return Yg(this)};_.equals=function(a){return this.k(a)};_.hashCode=function(){return this.m()};gf(32,1,{},vf);_.C=function(a){var b;b=new vf;b.e=4;a>1?(b.c=zf(this,a-1)):(b.c=this);return b};_.D=function(){tf(this);return this.b};_.F=function(){return uf(this)};_.G=function(){tf(this);return this.h};_.H=function(){return (this.e&4)!=0};_.I=function(){return (this.e&1)!=0};_.e=0;_.g=0;var sf=1;var Vd=xf(1);var Od=xf(32);gf(54,1,{},I);_.b=1;_.c=false;_.d=true;_.e=0;var md=xf(54);gf(55,1,Ei,J);_.q=function(){Eb(this.a)};var jd=xf(55);gf(22,1,{},K);_.r=function(){return this.a.q(),null};var kd=xf(22);gf(56,1,{},L);var ld=xf(56);var M;gf(23,1,{23:1},T);_.b=0;_.c=false;_.d=0;var nd=xf(23);gf(131,1,{});var qd=xf(131);gf(92,131,{},$);_.a=false;_.d=0;_.h=false;var pd=xf(92);gf(93,1,{},ab);_.r=function(){return X(this.a)};var od=xf(93);gf(26,131,{26:1},mb);_.a=4;_.d=false;_.e=0;var sd=xf(26);gf(91,1,Ei,nb);_.q=function(){eb(this.a)};var rd=xf(91);gf(18,131,{18:1},xb,yb);_.c=0;var xd=xf(18);gf(86,1,{},zb);var td=xf(86);gf(87,1,Ei,Ab);_.q=function(){pb(this.a)};var ud=xf(87);gf(88,1,Ei,Bb);_.q=function(){sb(this.a)};var vd=xf(88);gf(89,1,{},Cb);_.s=function(a){qb(this.a,a)};var wd=xf(89);gf(64,1,{},Fb);_.a=0;_.b=0;_.c=0;var yd=xf(64);gf(97,1,{},Hb);_.a=false;var zd=xf(97);gf(36,131,{36:1},Lb);_.a=0;var Bd=xf(36);gf(63,1,{},Qb);var Ad=xf(63);gf(98,1,{},ac);_.a=0;var Rb;var Cd=xf(98);gf(37,1,{},ic);_.g=0;var Ed=xf(37);gf(85,1,Ei,jc);_.q=function(){gc(this.a)};var Dd=xf(85);gf(5,1,{3:1,5:1});_.t=Ki;_.u=function(){var a,b;return a=Jg(Ig(dg((this.e==null&&(this.e=Uc(Yd,Fi,5,0,0,1)),this.e))),(b=new _f,b)),$f(a,Uc(Vd,Fi,1,a.a.length,5,1))};_.v=Li;_.w=function(){mc(this,oc(new Error(nc(this,this.d))));Pc(this)};_.b=Hi;_.f=true;var Yd=xf(5);gf(7,5,{3:1,7:1,5:1});var Qd=xf(7);gf(6,7,Ii);var Wd=xf(6);gf(49,6,Ii);var Td=xf(49);gf(50,49,Ii);var Id=xf(50);gf(21,50,{21:1,3:1,7:1,6:1,5:1},sc);_.A=function(){return fd(this.a)===fd(qc)?null:this.a};var qc;var Fd=xf(21);var Gd=xf(0);gf(113,1,{});var Hd=xf(113);var uc=0,vc=0,wc=-1;gf(59,113,{},Kc);var Gc;var Jd=xf(59);var Nc;gf(125,1,{});var Ld=xf(125);gf(51,125,{},Rc);var Kd=xf(51);var Yc,Zc,$c;var of;gf(53,6,Ii);var Sd=xf(53);gf(90,53,Ii,qf);var Md=xf(90);Yc={3:1,45:1,43:1};var Nd=xf(45);gf(123,1,Fi);var Ud=xf(123);Zc={3:1,43:1};var Pd=xf(124);gf(52,6,Ii,Ef);var Rd=xf(52);gf(183,1,{});$c={3:1,44:1,43:1,2:1};var Xd=xf(2);gf(187,1,{});gf(34,6,Ii,Hf);var Zd=xf(34);gf(126,1,{28:1});_.J=function(a){throw Ze(new Hf('Add not supported on this collection'))};var $d=xf(126);gf(129,1,{109:1});_.k=function(a){var b,c,d;if(a===this){return true}if(!bd(a,24)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Rf((new Of(d)).a);c.b;){b=Qf(c);if(!Kf(this,b)){return false}}return true};_.m=function(){return eg(new Of(this))};var ee=xf(129);gf(65,129,{109:1});var be=xf(65);gf(128,126,{28:1,135:1});_.k=function(a){var b;if(a===this){return true}if(!bd(a,16)){return false}b=a;if(Mf(b.a)!=this.K()){return false}return If(this,b)};_.m=function(){return eg(this)};var fe=xf(128);gf(16,128,{16:1,28:1,135:1},Of);_.K=function(){return Mf(this.a)};var ae=xf(16);gf(17,1,{},Rf);_.M=function(){return Qf(this)};_.L=Ki;_.b=false;var _d=xf(17);gf(127,126,{28:1,132:1});_.N=function(a,b){throw Ze(new Hf('Add not supported on this list'))};_.J=function(a){this.N(this.K(),a);return true};_.k=function(a){var b,c,d,e,f;if(a===this){return true}if(!bd(a,9)){return false}f=a;if(this.K()!=f.a.length){return false}e=new bg(f);for(c=new bg(this);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=(e.b=e.a++,e.c.a[e.b]);if(!(fd(b)===fd(d)||b!=null&&q(b,d))){return false}}return true};_.m=function(){return fg(this)};var ce=xf(127);gf(130,1,{136:1});_.k=function(a){var b;if(!bd(a,25)){return false}b=a;return wg(this.b.value[0],b.b.value[0])&&wg(ug(this),ug(b))};_.m=function(){return xg(this.b.value[0])^xg(ug(this))};var de=xf(130);gf(9,127,{3:1,9:1,28:1,132:1},_f,ag);_.N=function(a,b){Tg(this.a,a,b)};_.J=function(a){return Tf(this,a)};_.K=function(){return this.a.length};var he=xf(9);gf(11,1,{},bg);_.L=function(){return this.a<this.c.a.length};_.M=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ge=xf(11);gf(24,65,{3:1,24:1,109:1},gg);var ie=xf(24);gf(66,1,{},ig);_.b=0;var ke=xf(66);gf(67,1,{},jg);_.M=function(){return this.d=this.a[this.c++],this.d};_.L=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var je=xf(67);var kg;gf(68,1,{},sg);_.b=0;_.c=0;var ne=xf(68);gf(69,1,{},tg);_.M=function(){return this.c=this.a,this.a=this.b.next(),new vg(this.d,this.c,this.d.c)};_.L=function(){return !this.a.done};var le=xf(69);gf(25,130,{25:1,136:1},vg);_.c=0;var me=xf(25);gf(71,1,{});_.Q=Mi;_.O=Ki;_.P=Li;_.b=0;_.c=0;var re=xf(71);gf(72,71,{});var oe=xf(72);gf(60,1,{});_.Q=Mi;_.O=Ki;_.P=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var qe=xf(60);gf(61,60,{},Eg);_.Q=function(a){Bg(this,a)};_.R=function(a){return Cg(this,a)};var pe=xf(61);gf(70,1,{});_.c=false;var xe=xf(70);gf(35,70,{},Kg);var we=xf(35);gf(73,72,{},Ng);_.R=function(a){return this.a.R(new Og(a))};var te=xf(73);gf(75,1,{},Og);_.s=function(a){this.a.s(a.b)};var se=xf(75);gf(74,1,{},Qg);_.s=function(a){Pg(this,a)};var ue=xf(74);gf(76,1,{},Rg);_.s=function(a){Mg(this.a,a)};var ve=xf(76);gf(185,1,{});gf(182,1,{});var Xg=0;var Zg,$g=0,_g;gf(791,1,{});gf(816,1,{});gf(166,$wnd.Function,{},lh);_.S=function(a){kh(this.a,this.b,a)};gf(78,1,{});var ze=xf(78);gf(156,$wnd.Function,{},qh);_.T=function(a){th(this.a.e)};gf(157,$wnd.Function,{},rh);_.T=function(a){uh(this.a.e)};gf(42,1,{},sh);var ye=xf(42);gf(99,1,{});var Me=xf(99);gf(100,99,{},Eh);_.c=0;var zh=0;var Ee=xf(100);gf(101,1,Ei,Fh);_.q=function(){Ah(this.a)};var Ae=xf(101);gf(38,1,Ei,Gh);_.q=function(){Bh(this.a,this.b)};_.b=0;var Be=xf(38);gf(39,1,Ei,Hh);_.q=function(){Y(this.a.a)};var Ce=xf(39);gf(102,1,{},Ih);_.r=function(){return Dh(this.a)};var De=xf(102);gf(79,78,{});_.d=0;var Oe=xf(79);gf(80,79,{},Oh);var Mh=0;var Je=xf(80);gf(81,1,Ei,Ph);_.q=function(){bb(this.a.e)};var Fe=xf(81);gf(82,1,Ei,Qh);_.q=function(){ob(this.a.a)};var Ge=xf(82);gf(84,1,{},Rh);_.r=function(){return Kh(this.a)};var He=xf(84);gf(83,1,{},Sh);var Ie=xf(83);gf(94,1,{},Th);_.handleEvent=function(a){xh(this.a,a)};var Ke=xf(94);gf(159,$wnd.Function,{},Uh);_.n=function(a){yh(this.a,a)};gf(163,$wnd.Function,{},Vh);_.o=function(a){return a.startNotifications()};gf(95,1,{},Wh);_.handleEvent=function(a){yh(this.a,null)};var Le=xf(95);gf(160,$wnd.Function,{},Xh);_.p=Ni;gf(161,$wnd.Function,{},Yh);_.o=function(a){return vh(this.a,a)};gf(162,$wnd.Function,{},Zh);_.o=function(a){return a.getCharacteristic('heart_rate_measurement')};gf(164,$wnd.Function,{},$h);_.n=function(a){wh(this.a,a)};gf(165,$wnd.Function,{},_h);_.p=Ni;gf(154,$wnd.Function,{},ai);_.U=function(a){return new di(a)};var bi;gf(62,$wnd.React.Component,{},di);ff(df[1],_);_.componentWillUnmount=function(){Jh(this.a)};_.render=function(){return Nh(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var Ne=xf(62);var ei;gf(96,1,{158:1},gi);var Pe=xf(96);gf(104,1,{});var Qe=xf(104);gf(107,1,{},qi);_.b=0;_.c=false;_.d=0;var Re=xf(107);gf(40,104,{});_.a=0;_.b=0;_.c=0;var Ue=xf(40);gf(106,40,{},ti);var Se=xf(106);gf(167,$wnd.Function,{},ui);_.B=function(a){return ri((new vi(this.a)).a),null};gf(105,1,{},vi);var Te=xf(105);gf(41,1,{41:1},xi);var Ve=xf(41);gf(103,1,{},zi);var We=xf(103);var Ai;var hd=yf('D');var Di=(xc(),Ac);var gwtOnLoad=gwtOnLoad=bf;_e(nf);cf('permProps',[[]]);if (hrm) hrm.onScriptLoad(gwtOnLoad);})();