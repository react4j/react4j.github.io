function vchat(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='vchat',tb='__gwt_marker_vchat',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='93377318280FFDB6FED554B24018E287',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};vchat.onScriptLoad=function(a){vchat=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
vchat();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '93377318280FFDB6FED554B24018E287';function t(){}
function yh(){}
function uh(){}
function Kb(){}
function Qc(){}
function Xc(){}
function wi(){}
function wl(){}
function Yj(){}
function sk(){}
function Jk(){}
function Rk(){}
function Sk(){}
function zm(){}
function Tm(){}
function np(){}
function op(){}
function pp(){}
function up(){}
function vp(){}
function wp(){}
function yp(){}
function Ap(){}
function Cp(){}
function rq(){}
function ir(){}
function Fr(){}
function Jr(){}
function Nr(){}
function Rr(){}
function Vr(){}
function Wr(){}
function ms(){}
function Vc(a){Uc()}
function Qh(){Qh=uh}
function ut(){Qi(this)}
function ej(){Wi(this)}
function K(a){this.g=a}
function L(a){this.g=a}
function M(a){this.g=a}
function bb(a){this.g=a}
function ob(a){this.g=a}
function Cb(a){this.g=a}
function Db(a){this.g=a}
function Eb(a){this.g=a}
function Fb(a){this.g=a}
function nc(a){this.g=a}
function Oh(a){this.g=a}
function fi(a){this.g=a}
function Li(a){this.g=a}
function Ti(a){this.g=a}
function Ui(a){this.g=a}
function Uk(a){this.g=a}
function tk(a){this.g=a}
function Im(a){this.g=a}
function Jm(a){this.g=a}
function Qm(a){this.g=a}
function Rm(a){this.g=a}
function Sm(a){this.g=a}
function Um(a){this.g=a}
function Bn(a){this.g=a}
function Cn(a){this.g=a}
function Dn(a){this.g=a}
function Gn(a){this.g=a}
function Hn(a){this.g=a}
function In(a){this.g=a}
function Kn(a){this.g=a}
function Wo(a){this.g=a}
function Xo(a){this.g=a}
function Yo(a){this.g=a}
function Zo(a){this.g=a}
function _o(a){this.g=a}
function ap(a){this.g=a}
function ep(a){this.g=a}
function jp(a){this.g=a}
function mp(a){this.g=a}
function sp(a){this.g=a}
function tp(a){this.g=a}
function xp(a){this.g=a}
function zp(a){this.g=a}
function Bp(a){this.g=a}
function Dp(a){this.g=a}
function Ep(a){this.g=a}
function Fp(a){this.g=a}
function Gp(a){this.g=a}
function Hp(a){this.g=a}
function Ip(a){this.g=a}
function Jp(a){this.g=a}
function iq(a){this.g=a}
function kq(a){this.g=a}
function lq(a){this.g=a}
function mq(a){this.g=a}
function nq(a){this.g=a}
function oq(a){this.g=a}
function pq(a){this.g=a}
function qq(a){this.g=a}
function sq(a){this.g=a}
function tq(a){this.g=a}
function uq(a){this.g=a}
function vq(a){this.g=a}
function wq(a){this.g=a}
function Aq(a){this.g=a}
function Iq(a){this.g=a}
function Jq(a){this.g=a}
function Kq(a){this.g=a}
function Lq(a){this.g=a}
function br(a){this.g=a}
function cr(a){this.g=a}
function dr(a){this.g=a}
function er(a){this.g=a}
function fr(a){this.g=a}
function gr(a){this.g=a}
function hr(a){this.g=a}
function jr(a){this.g=a}
function ur(a){this.g=a}
function vr(a){this.g=a}
function xr(a){this.g=a}
function yr(a){this.g=a}
function Er(a){this.g=a}
function Xr(a){this.g=a}
function Yr(a){this.g=a}
function Zr(a){this.g=a}
function as(a){this.g=a}
function bs(a){this.g=a}
function cs(a){this.g=a}
function ds(a){this.g=a}
function es(a){this.g=a}
function fs(a){this.g=a}
function gs(a){this.g=a}
function ls(a){this.g=a}
function ns(a){this.g=a}
function rs(a){this.g=a}
function Ri(a){this.j=a}
function gj(a){this.i=a}
function vt(){Ii(this.g)}
function Ct(){hc(this.h)}
function vj(){this.g=Ej()}
function Jj(){this.g=Ej()}
function Qk(a,b){a.g=b}
function vb(a,b){a.h=b}
function pl(a,b){a.key=b}
function kl(a,b){jl(a,b)}
function zt(a){ji(this,a)}
function tt(a){Nj(this,a)}
function Bt(a){gk(this,a)}
function It(a){xn(this.g)}
function Ht(){Z(this.g.g)}
function ic(a){!!a&&a.Q()}
function D(a){--a.l;I(a)}
function P(a,b){T(a);Q(a,b)}
function Tk(a,b){Ik(a.g,b)}
function H(a,b){Sb(a.m,b.m)}
function ib(a){ac((O(),a))}
function jb(a){bc((O(),a))}
function mb(a){cc((O(),a))}
function Gt(a){Mn(this.g,a)}
function rt(){return this.g}
function xt(){return this.h}
function At(){return this.l}
function kh(a){return a.l}
function Cq(a){a.j=2;hc(a.h)}
function Vq(a){a.l=2;hc(a.i)}
function mr(a){a.m=2;hc(a.j)}
function Zq(a){pb(a.h);W(a.g)}
function di(){tc.call(this)}
function xi(){tc.call(this)}
function st(){return bl(this)}
function Mq(a,b){return a.v=b}
function qc(a,b){a.l=b;pc(a,b)}
function gc(a,b,c){Gi(a.l,b,c)}
function Ph(a){uc.call(this,a)}
function yi(a){uc.call(this,a)}
function vi(a){Oh.call(this,a)}
function ui(){Oh.call(this,'')}
function O(){O=uh;N=new J}
function wc(){wc=uh;vc=new t}
function Nc(){Nc=uh;Mc=new Qc}
function yk(){yk=uh;xk=new Sk}
function pj(){this.g=new mj}
function Aj(){Aj=uh;zj=Cj()}
function cb(a){jd(a,11)&&a.S()}
function Ft(a){jd(a,11)&&a.S()}
function vo(a){cb(a.B);cb(a.K)}
function qr(a){pb(a.g);eb(a.h)}
function Th(a){Sh(a);return a.v}
function Ek(a){uk(a);return a.g}
function $i(a,b){return a.g[b]}
function $k(a,b){return cd(a,b)}
function Yc(a,b){return Zh(a,b)}
function wt(){return Ji(this.g)}
function Dt(){return this.h.s<0}
function tc(){oc(this);this.Z()}
function Dc(){Dc=uh;!!(Uc(),Tc)}
function nh(){lh==null&&(lh=[])}
function lk(a,b,c){b.U(a.g[c])}
function Fm(a,b,c){gc(a.h,b,c)}
function mn(a,b,c){gc(a.H,b,c)}
function Zk(a,b,c){a.splice(b,c)}
function C(a,b,c){A(a,new M(c),b)}
function ro(a,b){return s(b.g,a)}
function Y(a){rb(a.m);return $(a)}
function Wb(a){Xb(a);!a.j&&$b(a)}
function fb(a){O();bc(a);a.l=-2}
function Sj(a){return Tj(a,a.i.h)}
function Ji(a){return a.g.h+a.h.h}
function Ej(){Aj();return new zj}
function Hk(a,b){a.sb(b);return a}
function zl(a,b){a.id=b;return a}
function Ch(a,b){a.min=b;return a}
function Bh(a,b){a.max=b;return a}
function Mh(a,b){a.sdp=b;return a}
function Jl(a,b){a.src=b;return a}
function Al(a,b){a.key=b;return a}
function Bl(a,b){a.ref=b;return a}
function nn(a){kb(a.o);return a.D}
function on(a){kb(a.i);return a.A}
function yo(a){kb(a.i);return a.H}
function zo(a){kb(a.j);return a.I}
function Po(a){kb(a.l);return a.s}
function To(a){kb(a.o);return a.v}
function Qo(a){lb(a.m);return a.u}
function Nh(a,b){a.type=b;return a}
function _n(a,b){null!=b&&Mn(a,b)}
function gk(a,b){while(a.Qb(b));}
function Nk(a,b,c){b.U(a.g.rb(c))}
function Gj(a,b){return a.g.get(b)}
function Oj(a,b){Qj(a,b,a.g,a.g.g)}
function Pj(a,b){Qj(a,b,a.i.h,a.i)}
function Pk(a,b){this.g=a;this.h=b}
function Mk(a,b){this.g=a;this.h=b}
function ci(a,b){this.g=a;this.h=b}
function Vi(a,b){this.g=a;this.h=b}
function xl(a,b){this.g=a;this.h=b}
function Am(a,b){this.g=a;this.h=b}
function Km(a,b){this.g=a;this.h=b}
function En(a,b){this.g=a;this.h=b}
function Fn(a,b){this.g=a;this.h=b}
function Jn(a,b){this.g=a;this.h=b}
function Ln(a,b){this.g=a;this.h=b}
function $o(a,b){this.g=a;this.h=b}
function bp(a,b){this.g=a;this.h=b}
function cp(a,b){this.g=a;this.h=b}
function dp(a,b){this.g=a;this.h=b}
function fp(a,b){this.g=a;this.h=b}
function gp(a,b){this.g=a;this.h=b}
function hp(a,b){this.g=a;this.h=b}
function ip(a,b){this.g=a;this.h=b}
function kp(a,b){this.g=a;this.h=b}
function lp(a,b){this.g=a;this.h=b}
function qp(a,b){this.g=a;this.h=b}
function rp(a,b){this.g=a;this.h=b}
function Ib(a){this.j=a;this.h=100}
function Yl(a,b){ci.call(this,a,b)}
function vm(a,b){ci.call(this,a,b)}
function Qp(a,b){ci.call(this,a,b)}
function Wp(a,b){ci.call(this,a,b)}
function gq(a,b){ci.call(this,a,b)}
function jq(a,b){this.g=a;this.h=b}
function xq(a,b){this.g=a;this.h=b}
function yq(a,b){this.g=a;this.h=b}
function zq(a,b){this.g=a;this.h=b}
function wr(a,b){this.g=a;this.h=b}
function $r(a,b){this.g=a;this.h=b}
function _r(a,b){this.g=a;this.h=b}
function Dl(a,b){a.href=b;return a}
function Xk(a,b,c){a.splice(b,0,c)}
function so(a,b){return s(b.g,a.g)}
function ss(a){return us(new ws,a)}
function hs(a){return is(new ks,a)}
function os(a){return ps(new qs,a)}
function yt(a){return Ei(this.g,a)}
function qi(a){return !a?Hs:''+a.g}
function Kc(a){$wnd.clearTimeout(a)}
function Ah(a,b){a.ideal=b;return a}
function Fh(a,b){a.video=b;return a}
function Hh(a,b){a.width=b;return a}
function Sl(a,b){a.value=b;return a}
function si(a,b){a.g+=''+b;return a}
function Eh(a){a.audio=true;return a}
function Gh(a,b){a.height=b;return a}
function Bq(){this.g=tl((Hr(),Gr))}
function ks(){this.g=tl((Lr(),Kr))}
function qs(){this.g=tl((Pr(),Or))}
function ws(){this.g=tl((Tr(),Sr))}
function qn(a){sn(a,(kb(a.i),!a.A))}
function Co(a,b){lo(a,b,new yq(a,b))}
function Do(a,b){lo(a,b,new zq(a,b))}
function s(a,b){return pd(a)===pd(b)}
function Di(a){return !a?null:a.Mb()}
function pd(a){return a==null?null:a}
function $j(a){return a!=null?w(a):0}
function Yb(a){return !a.j?a:Yb(a.j)}
function Ii(a){a.g=new vj;a.h=new Jj}
function nb(a){this.i=new ej;this.h=a}
function Dh(a){a.audio=false;return a}
function Fl(a,b){a.onClick=b;return a}
function Tl(a,b){a.htmlFor=b;return a}
function El(a,b){a.disabled=b;return a}
function Hl(a,b){a.onSubmit=b;return a}
function Kl(a,b){a.width=''+b;return a}
function Nl(a,b){a.onChange=b;return a}
function jl(a,b){for(var c in a){b(c)}}
function Ik(a,b){yk();Qk(a,Hk(a.g,b))}
function ub(a){O();tb(a);xb(a,2,true)}
function Wi(a){a.g=$c(ge,As,1,0,5,1)}
function U(){this.g=$c(ge,As,1,100,5,1)}
function qk(){rk.call(this,'|','','')}
function kb(a){var b;Zb((O(),b=Ub,b),a)}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function fl(){fl=uh;cl=new t;el=new t}
function _k(a){if(!a){throw kh(new di)}}
function Ql(a){return a.required=true,a}
function bl(a){return a.$H||(a.$H=++al)}
function ki(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function G(a,b,c){return B(a,c,2048,b)}
function oj(a,b){return Hi(a.g,b)!=null}
function db(a){return !(jd(a,11)&&a.T())}
function Ll(a){return a.autoFocus=true,a}
function ld(a){return typeof a==='number'}
function od(a){return typeof a==='string'}
function ol(a,b,c){a.props[b]=c;return a}
function Ml(a,b){a.maxLength=b;return a}
function Jh(a,b){a.candidate=b;return a}
function Ih(a,b){a.iceServers=b;return a}
function Il(a,b){a.height=''+b;return a}
function is(a,b){ol(a.g,'a',b);return a}
function ts(a,b){ol(a.g,'b',b);return a}
function vs(a,b){ol(a.g,'c',b);return a.g}
function Pl(a,b){a.placeholder=b;return a}
function Sh(a){if(a.v!=null){return}_h(a)}
function Oi(a){a.i.Eb();a.i=null;a.h=Mi(a)}
function Qi(a){a.j.Ib(a.i);a.h=a.i;a.i=-1}
function Lb(a){2==(3&a.g)||(a.g=-4&a.g|2)}
function Z(a){4==(a.m.i&7)&&xb(a.m,5,true)}
function F(a,b,c){B(a,new L(b),c,null)}
function Yk(a,b,c){Wk(c,0,a,b,c.length)}
function ni(a,b,c){return a.substr(b,c-b)}
function kd(a){return typeof a==='boolean'}
function uc(a){this.o=a;oc(this);this.Z()}
function mj(){this.g=new vj;this.h=new Jj}
function Ol(a){a.pattern='^\\w+$';return a}
function Om(a){F((O(),O(),N),new Um(a),Us)}
function xn(a){F((O(),O(),N),new Hn(a),Us)}
function yn(a){F((O(),O(),N),new Gn(a),Us)}
function zn(a){F((O(),O(),N),new In(a),Us)}
function Mo(a){F((O(),O(),N),new ap(a),Us)}
function Uo(a){F((O(),O(),N),new _o(a),Us)}
function _q(a){F((O(),O(),N),new hr(a),Us)}
function Eo(a){F((O(),O(),N),new ep(a),bt)}
function Oo(a){F((O(),O(),N),new jp(a),bt)}
function lc(a){O();Ub?a.Q():F((null,N),a,0)}
function xj(a,b){var c;c=a[Ns];c.call(a,b)}
function ll(a,b){var c;c={};c[a]=b;return c}
function Kh(a,b){a.sdpMLineIndex=b;return a}
function oc(a){a.u&&a.l!==Fs&&a.Z();return a}
function Wh(a){var b;b=Vh(a);bi(a,b);return b}
function Ec(a,b,c){return a.apply(b,c);var d}
function nd(a,b){return a&&b&&a instanceof b}
function qo(a,b){return pd(b.track)===pd(a)}
function Uq(a,b){b.preventDefault();Oo(a.u)}
function Nj(a,b){while(a.Cb()){Tk(b,a.Db())}}
function Hb(a){while(true){if(!Gb(a)){break}}}
function jk(a,b){while(a.i<a.j){lk(a,b,a.i++)}}
function bo(a){if(!a.F&&a.G){a.G=false;ao(a)}}
function fj(a){Wi(this);Yk(this.g,0,a.zb())}
function Mj(a,b,c){this.g=a;this.h=b;this.i=c}
function Xj(a,b,c){this.j=a;this.h=c;this.g=b}
function Gk(a,b){yk();wk.call(this,a);this.g=b}
function Xi(a,b){a.g[a.g.length]=b;return true}
function Rb(a,b,c){c.g=-4&c.g|1;P(a.g[b],c)}
function Sb(a,b){Rb(a,((b.g&229376)>>15)-1,b)}
function xo(a,b){F((O(),O(),N),new kp(a,b),bt)}
function Fo(a,b){F((O(),O(),N),new hp(a,b),bt)}
function Go(a,b){F((O(),O(),N),new bp(a,b),bt)}
function Ho(a,b){F((O(),O(),N),new fp(a,b),bt)}
function Io(a,b){F((O(),O(),N),new ip(a,b),bt)}
function Jo(a,b){F((O(),O(),N),new gp(a,b),bt)}
function Lo(a,b){F((O(),O(),N),new cp(a,b),bt)}
function No(a,b){F((O(),O(),N),new lp(a,b),bt)}
function Ko(a,b){F((O(),O(),N),new dp(a,b),Us)}
function Gm(a,b){F((O(),O(),N),new Km(a,b),Us)}
function sn(a,b){F((O(),O(),N),new Fn(a,b),Us)}
function sb(a,b){hb(b,a);b.i.g.length>0||(b.g=4)}
function Nq(a,b,c){c.preventDefault();xo(a.u,b)}
function Oq(a,b,c){c.preventDefault();No(a.u,b)}
function On(a,b,c){a.D.addTrack(c,b);return null}
function zk(a,b){var c;return Dk(a,(c=new ej,c))}
function Fj(a,b){return !(a.g.get(b)===undefined)}
function Ei(a,b){return od(b)?Fi(a,b):!!sj(a.g,b)}
function ij(a){return new Gk(null,hj(a,a.length))}
function ad(a){return Array.isArray(a)&&a.$b===yh}
function hd(a){return !Array.isArray(a)&&a.$b===yh}
function hj(a,b){return hk(b,a.length),new mk(a,b)}
function lr(a,b){lc(new wr(a,b.length==0?null:b))}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Yh(a){var b;b=Vh(a);b.u=a;b.l=1;return b}
function Vm(a){vn(a,null);un(a,null);tn(a,null)}
function Jb(a){if(!a.g){a.g=true;D((O(),O(),N))}}
function nk(a){if(!a.j){a.j=a.h.qb();a.i=a.h.wb()}}
function Eq(a){if(0==a.j){a.j=1;a.i.forceUpdate()}}
function Xq(a){if(0==a.l){a.l=1;a.j.forceUpdate()}}
function or(a){if(0==a.m){a.m=1;a.l.forceUpdate()}}
function Kk(a,b,c){if(a.g.Sb(c)){a.h=true;b.U(c)}}
function dj(a,b,c){var d;d=a.g[b];a.g[b]=c;return d}
function nj(a,b){var c;c=Gi(a.g,b,a);return c==null}
function aj(a,b){var c;c=a.g[b];Zk(a.g,b,1);return c}
function Wj(a){a.i=a.h;a.h=a.h.g;++a.g;return a.i.i}
function uk(a){if(!a.h){vk(a);a.i=true}else{uk(a.h)}}
function Gq(a){return G((O(),O(),N),a.g,new Kq(a))}
function $q(a){return G((O(),O(),N),a.h,new gr(a))}
function sr(a){return G((O(),O(),N),a.g,new xr(a))}
function S(a){return a.i?a.g.length-a.h+a.j:a.j-a.h}
function rn(a,b){var c;c=a.v;if(b!=c){a.v=b;jb(a.h)}}
function ln(a,b){var c;c=a.A;if(b!=c){a.A=b;jb(a.i)}}
function tn(a,b){var c;c=a.B;if(b!=c){a.B=b;jb(a.j)}}
function un(a,b){var c;c=a.C;if(b!=c){a.C=b;jb(a.l)}}
function wn(a,b){var c;c=a.G;if(b!=c){a.G=b;jb(a.u)}}
function wo(a,b){var c;c=a.s;if(b!=c){a.s=b;jb(a.l)}}
function rr(a,b){var c;c=a.i;if(b!=c){a.i=b;jb(a.h)}}
function Vk(a,b){var c;c=a.slice(0,b);return cd(c,a)}
function ml(a,b,c){var d;d={};d[Is]=a;d[b]=c;return d}
function Gl(a,b){a.type=b.g!=null?b.g:''+b.h;return a}
function ri(a,b){a.g+=String.fromCharCode(b);return a}
function ik(a,b){this.l=a;this.j=(b&64)!=0?b|16384:b}
function Vj(){this.g=new Yj;this.i=new Yj;Uj(this)}
function Uc(){Uc=uh;var a;!Wc();a=new Xc;Tc=a}
function ii(){ii=uh;hi=$c(de,As,37,256,0,1)}
function il(){if(dl==256){cl=el;el=new t;dl=0}++dl}
function wk(a){if(!a){this.h=null;new ej}else{this.h=a}}
function mk(a,b){this.i=0;this.j=b;this.h=17488;this.g=a}
function Si(a,b){this.g=a;Ri.call(this,a);a.wb();this.h=b}
function dc(a,b){this.g=(O(),O(),N).h++;this.j=a;this.l=b}
function ok(a,b){this.h=a;this.g=(b&4096)==0?b|64|16384:b}
function Xh(a,b){var c;c=Vh(a);bi(a,c);c.l=b?8:0;return c}
function lb(a){var b;O();!!Ub&&!!Ub.l&&Zb((b=Ub,b),a)}
function qb(a){H((O(),O(),N),a);0==(a.m.g&Es)&&I((null,N))}
function Hi(a,b){return b==null?uj(a.g,null):Ij(a.h,b)}
function Fi(a,b){return b==null?!!sj(a.g,null):Fj(a.h,b)}
function lj(a,b){return pd(a)===pd(b)||a!=null&&u(a,b)}
function Bo(a,b){pd(a.L)===pd(b.currentTarget)&&Z(a.g)}
function Bk(a,b){vk(a);return new Gk(a,new Ok(b,a.g))}
function Ak(a,b){vk(a);return new Gk(a,new Lk(b,a.g))}
function Ki(a,b){if(jd(b,44)){return Bi(a.g,b)}return false}
function $h(a){if(a.ob()){return null}var b=a.u;return qh[b]}
function Ni(a){var b;a.i=a.g;b=a.g.Db();a.h=Mi(a);return b}
function Uj(a){a.g.g=a.i;a.i.h=a.g;a.g.h=a.i.g=null;a.h=0}
function no(a,b){null!=a.L&&a.L.send($wnd.JSON.stringify(b))}
function Zm(a){!(!!a&&a.H.s<0)&&F((O(),O(),N),new Kn(a),Us)}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function ec(a,b){Ub=new dc(Ub,b);a.j=false;Vb(Ub);return Ub}
function rc(a,b){var c;c=Th(a.Yb);return b==null?c:c+': '+b}
function Ci(a,b){return b===a?'(this Map)':b==null?Hs:xh(b)}
function Zl(){Xl();return bd(Yc(gf,1),As,40,0,[Ul,Vl,Wl])}
function Xp(){Vp();return bd(Yc(ig,1),As,41,0,[Up,Tp,Sp])}
function Hr(){Hr=uh;var a;Gr=(a=vh(Fr.prototype.Xb,Fr,[]),a)}
function Lr(){Lr=uh;var a;Kr=(a=vh(Jr.prototype.Xb,Jr,[]),a)}
function Pr(){Pr=uh;var a;Or=(a=vh(Nr.prototype.Xb,Nr,[]),a)}
function Tr(){Tr=uh;var a;Sr=(a=vh(Rr.prototype.Xb,Rr,[]),a)}
function wh(a){function b(){}
;b.prototype=a||{};return new b}
function Lh(a){a.urls='stun:stun.l.google.com:19302';return a}
function Vb(a){if(a.l){2==(a.l.i&7)||xb(a.l,4,true);tb(a.l)}}
function vk(a){if(a.h){vk(a.h)}else if(a.i){throw kh(new ei)}}
function zr(a,b){var c;c=a.i;!(!!c&&c.H.s<0)&&lc(new En(c,b))}
function rj(a,b){var c;c=a.g.get(b);return c==null?new Array:c}
function Zh(a,b){var c=a.g=a.g||[];return c[b]||(c[b]=a.jb(b))}
function sh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function sj(a,b){var c;return qj(b,rj(a,b==null?0:(c=w(b),c|0)))}
function Pq(a,b){var c;lc(new $o(a.u,oi((c=b.target,c).value)))}
function ji(a,b){var c,d;for(d=a.qb();d.Cb();){c=d.Db();b.U(c)}}
function Ro(a,b){var c;c=a.u;if(!(b==c||!!b&&b==c)){a.u=b;jb(a.m)}}
function So(a,b){var c;c=a.v;if(!(b==c||!!b&&b==c)){a.v=b;jb(a.o)}}
function Ok(a,b){ik.call(this,b.Pb(),b.Ob()&-6);this.g=a;this.h=b}
function wj(a){this.l=a;this.h=this.l.g.entries();this.g=new Array}
function J(){this.m=new Tb;this.g=new Ib(this.m);new K(this.g)}
function Rp(){Pp();return bd(Yc(hg,1),As,25,0,[Mp,Op,Lp,Kp,Np])}
function Et(a,b,c){return Qh(),(a.enabled=!a.enabled)?true:false}
function Ck(a,b){return !(vk(a),Ek(new Gk(a,new Lk(b,a.g)))).Qb(xk)}
function Un(a,b){var c;return c=(kb(b.o),b.D),null!=c&&s(c.id,a.id)}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function Ym(a,b){b.onended=vh(tp.prototype.eb,tp,[a]);return null}
function Xm(a,b,c){a.K==b&&F((O(),O(),N),new Ln(a,c),Us);return null}
function kk(a,b){if(a.i<a.j){lk(a,b,a.i++);return true}return false}
function Rn(a){no(a,ml('offer',Xs,a.D.localDescription));return null}
function Nn(a){var b;b=new ej;on(a.K)&&Xi(b,a.K);Yi(b,a.J);return b}
function kc(a){ic(a.o);!!a.l&&jc(a);cb(a.g);cb(a.i);ic(a.h);ic(a.m)}
function uo(a){W(a.g);W(a.h);eb(a.o);eb(a.m);eb(a.l);eb(a.j);eb(a.i)}
function Q(a,b){a.g[a.j]=b;++a.j;if(a.j>=a.g.length){a.j=0;a.i=true}}
function nl(a,b,c,d,e,f){var g;g={};g[a]=b;g[c]=d;g[e]=f;return g}
function vl(a,b,c){!s(c,'key')&&!s(c,'ref')&&(a[c]=b[c],undefined)}
function gb(a,b){var c,d;Xi(a.i,b);d=(c=b.i&7,c>3?c:4);a.g>d&&(a.g=d)}
function Lk(a,b){ik.call(this,b.Pb(),b.Ob()&-16449);this.g=a;this.i=b}
function Mr(a){$wnd.React.Component.call(this,a);this.g=new ar(this)}
function Qr(a){$wnd.React.Component.call(this,a);this.g=new tr(this)}
function Ur(a){$wnd.React.Component.call(this,a);this.g=new Dr(this)}
function Ir(a){$wnd.React.Component.call(this,a);this.g=new Hq(this)}
function Kj(a){this.j=a;this.h=this.j.g.entries();this.g=this.h.next()}
function rk(a,b,c){this.h=a;this.j=b;this.l=c;this.i=this.j+(''+this.l)}
function Qj(a,b,c,d){var e;e=new Yj;e.i=b;e.h=c;e.g=d;d.h=c.g=e;++a.h}
function Fk(a,b){var c;c=zk(a,new tk(new sk));return c.Ab(b.Rb(c.wb()))}
function Dk(a,b){var c;uk(a);c=new Rk;c.g=b;a.g.Bb(new Uk(c));return c.g}
function pk(a,b){!a.g?(a.g=new vi(a.j)):si(a.g,a.h);si(a.g,b);return a}
function sc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Qn(a,b){return a.D.setLocalDescription(Nh(Mh({},b.sdp),b.type))}
function Wn(a,b){return a.D.setLocalDescription(Mh(Nh({},b.type),b.sdp))}
function Vn(a,b){var c;return c=(kb(b.o),b.D),!(null!=c&&!s(c.id,a.id))}
function hq(){fq();return bd(Yc(jg,1),As,17,0,[eq,Zp,cq,bq,aq,Yp,dq,_p,$p])}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function Nb(b){try{rb(b.h.g)}catch(a){a=jh(a);if(!jd(a,8))throw kh(a)}}
function eb(a){if(-2!=a.l){F((O(),O(),N),new ob(a),0);!!a.h&&pb(a.h)}}
function lo(a,b,c){if(null!=a.L&&bj(a.I,b)){cj(a.I,new Aq(b));jb(a.j);c.Q()}}
function cd(a,b){Zc(b)!=10&&bd(v(b),b.Zb,b.__elementTypeId$,Zc(b),a);return a}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&bd(Yc(a,f),b,c,e,g);return g}
function Yn(a,b,c){b.log('Answer error: ',c);a.F=false;bo(a);return null}
function gn(a){if(s('live',a.readyState)){a.onended=null;a.stop()}return null}
function Qb(a){var b,c;b=0;for(c=0;c<a.g.length;c++){b+=S(a.g[c])}return b}
function _i(a,b,c){for(;c<a.g.length;++c){if(lj(b,a.g[c])){return c}}return -1}
function Lj(a){if(a.g.i!=a.i){return Gj(a.g,a.h.value[0])}return a.h.value[1]}
function Lm(a){$wnd.goog.global.globalThis.addEventListener(Vs,a.i,false)}
function Mm(a){$wnd.goog.global.globalThis.removeEventListener(Vs,a.i,false)}
function Sq(a){$wnd.goog.global.globalThis.document.removeEventListener(dt,a.s)}
function Rq(a){$wnd.goog.global.globalThis.document.addEventListener(dt,a.s)}
function Pi(a){this.l=a;this.j=new Kj(this.l.h);this.g=this.j;this.h=Mi(this)}
function Tb(){var a;this.g=$c(wd,As,58,5,0,1);for(a=0;a<5;a++){this.g[a]=new U}}
function Zi(a,b){var c,d,e,f;for(d=a.g,e=0,f=d.length;e<f;++e){c=d[e];b.U(c)}}
function kn(a,b){var c;c=a.F;if(!(pd(b)===pd(c)||b!=null&&u(b,c))){a.F=b;jb(a.s)}}
function vn(a,b){var c;c=a.D;if(!(pd(b)===pd(c)||b!=null&&u(b,c))){a.D=b;jb(a.o)}}
function bj(a,b){var c;c=_i(a,b,0);if(c==-1){return false}Zk(a.g,c,1);return true}
function ps(a,b){pl(a.g,gi(b.h.j)+(''+(Sh(fh),fh.v)));ol(a.g,'a',b);return a.g}
function $(a){if(a.h){if(jd(a.h,10)){throw kh(a.h)}else{throw kh(a.h)}}return a.v}
function wb(b){if(b){try{b.Q()}catch(a){a=jh(a);if(jd(a,8)){O()}else throw kh(a)}}}
function mo(a){if(null!=a.L){no(a,ml(_s,'message',(kb(a.l),a.s)));So(a,(fq(),cq))}}
function W(a){if(!a.g){a.g=true;a.v=null;a.h=null;eb(a.l);2==(a.m.i&7)||pb(a.m)}}
function I(a){if(a.j&&a.l==0){if(!a.i){a.i=true;try{Hb(a.g)}finally{a.i=false}}}}
function hc(a){if(a.s>=0){a.s=-2;B((O(),O(),N),new L(new nc(a)),67108864,null)}}
function fo(a,b){if(pd(a.L)===pd(b.currentTarget)){Z(a.g);So(a,(fq(),$p));a.L=null}}
function Gi(a,b,c){return od(b)?b==null?tj(a.g,null,c):Hj(a.h,b,c):tj(a.g,b,c)}
function Oc(a){var b,c;if(a.g){c=null;do{b=a.g;a.g=null;c=Sc(b,c)}while(a.g);a.g=c}}
function Pc(a){var b,c;if(a.h){c=null;do{b=a.h;a.h=null;c=Sc(b,c)}while(a.h);a.h=c}}
function Zb(a,b){var c;if(a.l){c=a.g;if(b.l!=c){b.l=c;!a.h&&(a.h=new ej);Xi(a.h,b)}}}
function bi(a,b){var c;if(!a){return}b.u=a;var d=$h(b);if(!d){qh[a]=[b];return}d.Yb=b}
function _b(a,b){var c;if(!a.i){c=Yb(a);!c.i&&(c.i=new ej);a.i=c.i}b.j=true;a.i.sb(b)}
function Tj(a,b){var c;c=b.i;b.g.h=b.h;b.h.g=b.g;b.g=b.h=null;b.i=null;--a.h;return c}
function Vh(a){var b;b=new Uh;b.v='Class$'+(a?'S'+a:''+b.o);b.h=b.v;b.s=b.v;return b}
function Cl(a){a.title='Room code should only contain letters or numbers.';return a}
function Xn(a){no(a,ml('answer',Xs,a.D.localDescription));a.F=false;bo(a);return null}
function us(a,b){pl(a.g,(b?gi(b.H.j):null)+(''+(Sh(hh),hh.v)));ol(a.g,'a',b);return a}
function jn(a){pb(a.m);W(a.g);eb(a.h);eb(a.o);eb(a.l);eb(a.j);eb(a.i);eb(a.u);eb(a.s)}
function io(a,b){var c;c=b.track;a.J=zk(Ak(a.J.yb(),new tq(c)),new tk(new sk));Z(a.h)}
function Zn(a,b){var c;c=b.g;no(a,ml('approve_access','id',c));nj(a.H,c);jb(a.i);oo(a)}
function Xl(){Xl=uh;Ul=new Yl(Ss,0);Vl=new Yl('reset',1);Wl=new Yl('submit',2)}
function Vp(){Vp=uh;Up=new Wp('UNKNOWN',0);Tp=new Wp('HOST',1);Sp=new Wp('GUEST',2)}
function md(a){return a!=null&&(typeof a===ys||typeof a==='function')&&!(a.$b===yh)}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function ei(){uc.call(this,"Stream already terminated, can't be modified or used")}
function mh(){nh();var a=lh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function vh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function rl(a,b,c,d){var e;e=sl($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function tl(a){var b;b=sl($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function jj(a){var b,c,d;d=0;for(c=a.qb();c.Cb();){b=c.Db();d=d+(b!=null?w(b):0);d=d|0}return d}
function Ai(a,b){var c,d;for(d=b.qb();d.Cb();){c=d.Db();if(!a.ub(c)){return false}}return true}
function Ij(a,b){var c;c=a.g.get(b);if(c===undefined){++a.i}else{xj(a.g,b);--a.h}return c}
function kj(a){var b,c,d;d=1;for(c=a.qb();c.Cb();){b=c.Db();d=31*d+(b!=null?w(b):0);d=d|0}return d}
function tb(a){var b,c;for(c=new gj(a.h);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);b.g=4}}
function fc(){var a;try{Wb(Ub);O()}finally{a=Ub.j;!a&&((O(),O(),N).j=true);Ub=Ub.j}}
function Ob(a,b){this.h=a;this.g=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function Ab(a,b,c){zb.call(this,null,a,b,c|(!a?262144:Cs)|(0==(c&6291456)?!a?Es:4194304:0)|0|0|0)}
function bn(a,b){rn(a,false);vn(a,b);b.getTracks().forEach(vh(sp.prototype._,sp,[a]));a.J.U(b)}
function Mn(a,b){if(null!=a.D){b.getTracks().forEach(vh(jq.prototype._,jq,[a,b]));a.G=true;bo(a)}}
function hk(a,b){if(0>a||a>b){throw kh(new Ph('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function ph(a,b){typeof window===ys&&typeof window['$gwt']===ys&&(window['$gwt'][a]=b)}
function Mi(a){if(a.g.Cb()){return true}if(a.g!=a.j){return false}a.g=new wj(a.l.g);return a.g.Cb()}
function Yi(a,b){var c,d;c=b.zb();d=c.length;if(d==0){return false}Yk(a.g,a.g.length,c);return true}
function qj(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(lj(a,c.Lb())){return c}}return null}
function Sn(a,b){$wnd.goog.global.globalThis.console.log('Offer error: ',b);a.F=false;return null}
function Hj(a,b,c){var d;d=a.g.get(b);a.g.set(b,c===undefined?null:c);d===undefined?++a.h:++a.i;return d}
function bd(a,b,c,d,e){e.Yb=a;e.Zb=b;e.$b=yh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function jh(a){var b;if(jd(a,8)){return a}b=a&&a.__java$exception;if(!b){b=new yc(a);Vc(b)}return b}
function gi(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ii(),hi)[b];!c&&(c=hi[b]=new fi(a));return c}return new fi(a)}
function en(a){var b;b=(kb(a.o),a.D);null!=b&&b.getAudioTracks().forEach(vh(op.prototype._,op,[]));Z(a.g)}
function ym(){if(!xm){xm=(++(O(),O(),N).l,new Kb);$wnd.Promise.resolve(null).then(vh(zm.prototype.bb,zm,[]))}}
function pb(a){if(2<(a.i&7)){B((O(),O(),N),new L(new Eb(a)),67108864,null);!!a.g&&W(a.g);Lb(a.m);a.i=a.i&-8|1}}
function Wm(a,b,c){a.K==b?F((O(),O(),N),new Jn(a,c),Us):c.getTracks().forEach(vh(vp.prototype._,vp,[]));return null}
function mc(a,b,c,d){this.j=a;this.l=d?new mj:null;this.o=b;this.h=c;this.m=null;this.g=null;this.i=null}
function Uh(){this.o=Rh++;this.v=null;this.s=null;this.m=null;this.j=null;this.h=null;this.u=null;this.g=null}
function yc(a){wc();oc(this);this.l=a;pc(this,a);this.o=a==null?Hs:xh(a);this.g='';this.h=a;this.g=''}
function Ao(a){return null==a.L?(Pp(),Np):(Pp(),bd(Yc(hg,1),As,25,0,[Mp,Op,Lp,Kp,Np]))[a.L.readyState]}
function Ar(a){return rl('video',null,a.j,nl('autoPlay',true,'className',a.h.props['b'],'muted',a.h.props['c']))}
function v(a){return od(a)?je:ld(a)?Zd:kd(a)?Xd:hd(a)?a.Yb:ad(a)?a.Yb:a.Yb||Array.isArray(a)&&Yc(Pd,1)||Pd}
function Dq(a){var b,c,d;a.j=0;ym();c=(d=(b=X(a.l.j.g),b.length==0?null:b),null==d?os(a.l):js(hs(a.l),d));return c}
function ql(a){var b;b=sl($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=ll(Rs,a);return b}
function Qq(a){var b;b=$wnd.goog.global.globalThis.document;b.fullscreen?b.exitFullscreen():a.v.requestFullscreen()}
function zh(){var a;a=$wnd.goog.global.globalThis.document.getElementById('app');$wnd.ReactDOM.render((new Bq).g,a,null)}
function pn(a){var b;return Qh(),b=(kb(a.o),a.D),null!=b&&b.getAudioTracks().some(vh(np.prototype._,np,[]))?true:false}
function fn(a){var b;wn(a,(kb(a.u),!a.G));b=(kb(a.o),a.D);null!=b&&b.getVideoTracks().forEach(vh(pp.prototype._,pp,[]))}
function $b(a){var b;if(a.i){while(!a.i.vb()){b=a.i.Ib(a.i.wb()-1);b.j=false;b.i.g.length>0||(b.h.i&7)>3&&xb(b.h,3,true)}}}
function hb(a,b){var c,d;d=a.i;bj(d,b);!!a.h&&Cs!=(a.h.i&Ds)&&a.i.g.length<=0&&0==a.h.g.j&&(a.j||_b((O(),c=Ub,c),a))}
function js(a,b){var c;ol(a.g,'b',b);return c=a.g.props,pl(a.g,qi(c['a']?gi(c['a'].h.j):null)+'-'+c['b']+(Sh(bh),bh.v)),a.g}
function Br(a,b){var c;c=a.h.props;if(!(c['b']===b['b'])){return true}if(!(c['c']===b['c'])){return true}return false}
function xh(a){var b;if(Array.isArray(a)&&a.$b===yh){return Th(v(a))+'@'+(b=w(a)>>>0,b.toString(16))}return a.toString()}
function hl(a){fl();var b,c,d;c=':'+a;d=el[c];if(d!=null){return qd(d)}d=cl[c];b=d==null?gl(a):qd(d);il();el[c]=b;return b}
function $m(a){var b,c,d;c=(kb(a.o),a.D);d=(kb(a.s),a.F);if(null!=c&&null!=d){b=c;pd(b)!==pd(d.srcObject)&&(d.srcObject=b)}}
function Pb(a){var b,c,d;for(b=0;b<a.g.length;b++){d=a.g[b];if(0!=(d.i?d.g.length-d.h+d.j:d.j-d.h)){c=R(d);return c}}return null}
function zi(a,b,c){var d,e;for(e=a.qb();e.Cb();){d=e.Db();if(pd(b)===pd(d)||b!=null&&u(b,d)){c&&e.Eb();return true}}return false}
function Rj(a,b){var c,d;if(b>=a.h>>1){d=a.i;for(c=a.h;c>b;--c){d=d.h}}else{d=a.g.g;for(c=0;c<b;++c){d=d.g}}return new Xj(a,b,d)}
function jo(a,b){var c;if(pd(a.D)===pd(b.currentTarget)){c=b.streams;a.J=new fj(a.J);c.forEach(vh(pq.prototype._,pq,[a]));Z(a.h)}}
function co(a,b){var c;if(pd(a.L)===pd(b.currentTarget)){a.L=null;c=(kb(a.o),a.v);(fq(),dq)!=c&&Yp!=c&&$p!=c&&So(a,Yp);Z(a.g)}}
function Mb(a){if(1==(3&a.g)){a.g=-4&a.g|0;0==(a.g&Cs)?Nb(a):rb(a.h.g);0!=(a.g&524288)&&(2==(3&a.g)||(a.g=-4&a.g|2))}}
function Cm(a,b){zi(a.i,b,true);3==a.i.h&&Sj(a.i);Oj(a.i,b);jb(a.g);$wnd.goog.global.globalThis.localStorage.setItem(Ts,pi(a.i))}
function _m(a){var b;++a.K;b=a.K;Vm(a);rn(a,true);a.I.Tb().then(vh(qp.prototype.bb,qp,[a,b])).catch(vh(rp.prototype.bb,rp,[a,b]))}
function cn(a){var b;b=(kb(a.o),a.D);Vm(a);F((O(),O(),N),new Fn(a,false),Us);null!=b&&b.getTracks().forEach(vh(up.prototype._,up,[]))}
function Hm(){var a,b;Dm.call(this);O();a=++Em;this.h=new mc(a,new Im(this),new Jm(this),true);this.g=(b=new nb(null),b)}
function fk(){ck();var a,b,c;c=bk+++Date.now();a=qd($wnd.Math.floor(c*Ps))&16777215;b=qd(c-a*Qs);this.g=a^1502;this.h=b^Os}
function wm(){um();return bd(Yc(hf,1),As,9,0,[$l,_l,am,bm,cm,dm,em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm,qm,rm,sm,tm])}
function w(a){return od(a)?hl(a):ld(a)?qd(a):kd(a)?a?1231:1237:hd(a)?a.O():ad(a)?bl(a):!!a&&!!a.hashCode?a.hashCode():bl(a)}
function Bb(a,b){zb.call(this,a,new Cb(a),null,b|(Cs==(b&Ds)?0:524288)|(0==(b&6291456)?Cs==(b&Ds)?4194304:Es:0)|0|268435456|0)}
function Pn(a,b){var c;c=a.D.getSenders().find(vh(lq.prototype.ab,lq,[b]));if(null!=c){a.D.removeTrack(c);a.G=true;bo(a)}return null}
function ai(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function dk(a,b){var c,d;_k(b>0);if((b&-b)==b){return qd(b*ek(a)*4.6566128730773926E-10)}do{c=ek(a);d=c%b}while(c-d+(b-1)<0);return qd(d)}
function dn(a,b){var c;rn(a,false);if(nd(b,$wnd.DOMException)){c=b;un(a,c.name);tn(a,c.message)}else{un(a,Th(v(b)));tn(a,b==null?Hs:xh(b))}}
function Pp(){Pp=uh;Mp=new Qp('CONNECTING',0);Op=new Qp('OPEN',1);Lp=new Qp('CLOSING',2);Kp=new Qp('CLOSED',3);Np=new Qp('NOT_REQUESTED',4)}
function Hq(a){var b;this.l=new Hm;this.i=a;O();b=++Fq;this.h=new mc(b,new Iq(this),new Jq(this),false);this.g=new Ab(null,new Lq(this),ct)}
function Pm(){var a;this.i=new mp(this);O();a=++Nm;this.h=new mc(a,null,new Qm(this),true);this.g=new ab(new Tm,new Rm(this),new Sm(this),Ws)}
function jc(a){var b,c,d;for(c=new gj(new fj(new Li(a.l)));c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.Lb();jd(d,11)&&d.T()||b.Mb().Q()}}
function bc(a){var b,c,d;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new gj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;6!=d&&xb(b,6,true)}}}
function cc(a){var b,c,d;if(a.i.g.length>0&&4==a.g){a.g=5;for(c=new gj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;4==d&&xb(b,5,true)}}}
function go(a,b){var c;if(pd(a.D)===pd(b.currentTarget)){c=b.candidate;null!=c&&null!=a.L&&no(a,nl(Is,Zs,$s,c.sdpMLineIndex,Zs,c.candidate))}}
function u(a,b){return od(a)?s(a,b):ld(a)?pd(a)===pd(b):kd(a)?pd(a)===pd(b):hd(a)?a.M(b):ad(a)?s(a,b):!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function Bm(){var a,b,c;b=new fk;c=new ui;for(a=0;a<10;a++){ri(c,ki('abcdefghijklmnopqrstuvwxyz1234567890',$wnd.Math.abs(dk(b,36))))}return c.g}
function gd(a,b){if(od(a)){return !!fd[b]}else if(a.Zb){return !!a.Zb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function an(a,b){var c;ln(a,b);c=(kb(a.o),a.D);if(b){null==c&&_m(a)}else{if(null!=c){c.getTracks().forEach(vh(vp.prototype._,vp,[]));vn(a,null)}}}
function Tn(a,b){var c,d;if(Ck(a.J.yb(),new qq(b))){c=new rq;d=new An(new sq(b),c,true);_m(d);a.J.sb(d);b.onremovetrack=vh(zp.prototype.gb,zp,[a])}return null}
function yl(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function R(a){var b;if(0==(a.i?a.g.length-a.h+a.j:a.j-a.h)){return null}b=a.g[a.h];a.g[a.h]=null;++a.h;if(a.h>=a.g.length){a.h=0;a.i=false}return b}
function X(a){a.u?lb(a.l):kb(a.l);if(yb(a.m)){if(a.u&&(O(),!(!!Ub&&!!Ub.l))){return B((O(),O(),N),new bb(a),83888128,null)}else{rb(a.m)}}return $(a)}
function oi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function A(b,c,d){var e,f;try{ec(b,d);try{f=(c.g.Q(),null)}finally{fc()}return f}catch(a){a=jh(a);if(jd(a,8)){e=a;throw kh(e)}else throw kh(a)}finally{I(b)}}
function ab(a,b,c,d){this.i=a;this.o=b;this.s=c;this.v=null;this.u=16384==(d&16384);this.m=new Bb(this,d&-16385);this.l=new nb(this.m);Cs==(d&Ds)&&qb(this.m)}
function ac(a){var b,c;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new gj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);5==(b.i&7)?xb(b,6,true):4==(b.i&7)&&(a.g=4)}}}
function pi(a){var b,c,d;d=new qk;for(c=Rj(a,0);c.h!=c.j.i;){b=Wj(c);!d.g?(d.g=new vi(d.j)):si(d.g,d.h);si(d.g,b)}return !d.g?d.i:d.l.length==0?d.g.g:d.g.g+(''+d.l)}
function po(a){var b;b=nn(a.K);null!=a.D&&null!=b&&on(a.K)&&null!=a.D&&b.getTracks().forEach(vh(kq.prototype._,kq,[a]));yn(a.K);null!=a.D&&on(a.K)&&null!=b&&Mn(a,b)}
function Gb(a){var b,c;if(0==a.i){b=Qb(a.j);if(0==b){a.g=0;return false}else if(a.g+1>a.h){a.g=0;return false}else{a.g=a.g+1;a.i=b}}--a.i;c=Pb(a.j);Mb(c);return true}
function oh(b,c,d,e){nh();var f=lh;$moduleName=c;$moduleBase=d;ih=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{xs(g)()}catch(a){b(c,a)}}else{xs(g)()}}
function kr(a,b){var c,d,e;b.preventDefault();c=(lb(a.h),a.i);null!=c&&(d=$wnd.goog.global.globalThis.location,e=c.length==0?c:'#'+c,s(d.hash,e)||(d.hash=e),undefined)}
function sl(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Dr(a){var b;this.j=vh(rs.prototype.U,rs,[this]);this.h=a;this.i=a.props['a'];O();b=++Cr;this.g=new mc(b,null,null,false);mn(this.i,this,new Er(this));I((null,N))}
function ck(){ck=uh;var a,b,c,d;_j=$c(rd,As,236,25,15,1);ak=$c(rd,As,236,33,15,1);d=1.52587890625E-5;for(b=32;b>=0;b--){ak[b]=d;d*=0.5}c=1;for(a=24;a>=0;a--){_j[a]=c;c*=0.5}}
function Cj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Dj()}}
function Dm(){var a,b,c,d,e;this.i=new Vj;this.j=new Pm;e=$wnd.goog.global.globalThis.localStorage.getItem(Ts);if(null!=e){for(b=mi(e),c=0,d=b.length;c<d;++c){a=b[c];Pj(this.i,a)}}}
function eo(a,b){var c;if(pd(a.D)===pd(b.currentTarget)){c=a.D.iceConnectionState;if(s('disconnected',c)||s('failed',c)||s('closed',c)){a.J.pb(new yp);a.J=new ej;Z(a.h)}else{ao(a)}}}
function cj(a,b){var c,d,e,f;e=null;f=0;for(d=0;d<a.g.length;++d){c=a.g[d];if(b.Sb(c)){if(e==null){e=Vk(a.g,d);f=d}}else e!=null&&(e[f++]=c)}if(e==null){return false}a.g=e;return true}
function B(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ub){g=c.R()}else{ec(b,e);try{g=c.R()}finally{fc()}}return g}catch(a){a=jh(a);if(jd(a,8)){f=a;throw kh(f)}else throw kh(a)}finally{I(b)}}
function $n(a,b){if(null!=a.L){a.I.g=$c(ge,As,1,0,5,1);a.L.close();a.L=null;So(a,b)}if(null!=a.D){a.J.pb(new Ap);a.J.tb();Ii(a.H.g);a.D.close();a.D=null;a.F=false;a.G=false;jb(a.i);Z(a.h)}}
function rh(){qh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0]._b()&&(c=Rc(c,g)):g[0]._b()}catch(a){a=jh(a);if(jd(a,8)){d=a;Dc();Jc(jd(d,48)?d.$():d)}else throw kh(a)}}return c}
function xc(a){var b;if(a.i==null){b=pd(a.h)===pd(vc)?null:a.h;a.j=b==null?Hs:md(b)?b==null?null:b.name:od(b)?'String':Th(v(b));a.g=a.g+': '+(md(b)?b==null?null:b.message:b+'');a.i='('+a.j+') '+a.g}}
function V(b){var c,d,e;e=b.v;try{d=b.i.R();if(!(pd(e)===pd(d)||e!=null&&u(e,d))){b.v=d;b.h=null;ib(b.l)}}catch(a){a=jh(a);if(jd(a,13)){c=a;if(!b.h){b.v=null;b.h=c;ib(b.l)}throw kh(c)}else throw kh(a)}}
function ek(a){var b,c,d,e,f,g;e=a.g*Os+a.h*1502;g=a.h*Os+11;b=$wnd.Math.floor(g*Ps);e+=b;g-=b*Qs;e%=Qs;a.g=e;a.h=g;d=a.g*128;f=$wnd.Math.floor(a.h*ak[31]);c=d+f;c>=2147483648&&(c-=4294967296);return c}
function tj(a,b,c){var d,e,f,g,h;h=b==null?0:(g=w(b),g|0);e=(d=a.g.get(h),d==null?new Array:d);if(e.length==0){a.g.set(h,e)}else{f=qj(b,e);if(f){return f.Nb(c)}}e[e.length]=new Vi(b,c);++a.h;return null}
function gl(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ki(a,c++)}b=b|0;return b}
function Wk(a,b,c,d,e){var f,g,h,i,j;if(pd(a)===pd(c)){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function ao(a){var b;if(!a.F){b=(lb(a.m),a.u);if((Vp(),Tp)==b){a.F=true;a.D.createOffer().then(vh(mq.prototype.bb,mq,[a])).then(vh(nq.prototype.bb,nq,[a])).catch(vh(oq.prototype.bb,oq,[a]))}else{no(a,ll(Is,Ys))}}}
function rb(b){var c;if(1!=(b.i&7)){try{if(4!=(b.i&7)){if(0!=(b.i&512)){!!b.l&&(b.i&=-513);c=b.j;C((O(),O(),N),b,c)}else{b.l.Q()}}else 0!=(b.i&512)&&!!b.l&&(b.i&=-513)}catch(a){a=jh(a);if(jd(a,8)){O()}else throw kh(a)}}}
function Bi(a,b){var c,d,e;c=b.Lb();e=b.Mb();d=od(c)?c==null?Di(sj(a.g,null)):Gj(a.h,c):Di(sj(a.g,c));if(!(pd(e)===pd(d)||e!=null&&u(e,d))){return false}if(d==null&&!(od(c)?Fi(a,c):!!sj(a.g,c))){return false}return true}
function T(a){var b,c,d,e,f,g;b=a.i?a.g.length-a.h+a.j:a.j-a.h;if(b+1>a.g.length){g=(a.g.length-1)*2+1;c=$c(ge,As,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.h+d)%a.g.length;c[f]=a.g[e];a.g[e]=null;++f}a.g=c;a.h=0;a.j=f;a.i=false}}
function zb(a,b,c,d){this.h=new ej;this.m=new Ob(new Db(this),d&6520832|262144|Cs);this.i=d&-6520833|3;this.g=a;this.j=b;this.l=c;!!this.j&&(this.i|=512);!this.g&&!!this.j&&(H((O(),O(),N),this),0==(this.m.g&Es)&&I((null,N)))}
function tr(a){var b,c,d;this.l=a;this.o=a.props['a'];O();b=++pr;this.j=new mc(b,null,new ur(this),false);this.h=(d=new nb((c=null,c)),d);this.g=new Ab(null,new yr(this),ct);!!this.o&&Fm(this.o,this,new vr(this));I((null,N))}
function uj(a,b){var c,d,e,f,g,h;g=b==null?0:(f=w(b),f|0);d=(c=a.g.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(lj(b,e.Lb())){if(d.length==1){d.length=0;xj(a.g,g)}else{d.splice(h,1)}--a.h;return e.Mb()}}return null}
function fq(){fq=uh;eq=new gq('NOT_READY',0);Zp=new gq('CONNECTED',1);cq=new gq('JOIN_REQUESTED',2);bq=new gq('JOIN_REJECTED',3);aq=new gq('JOINED',4);Yp=new gq('CLOSED',5);dq=new gq('LEFT',6);_p=new gq('FULL',7);$p=new gq('ERROR',8)}
function th(a,b,c){var d=qh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=qh[b]),wh(h));_.Zb=c;!b&&(_.$b=yh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.Yb=f)}
function ul(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;kl(b,vh(xl.prototype.Ub,xl,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Rs]=c[0],undefined):(d[Rs]=c,undefined));return rl(a,e,f,d)}
function _h(a){if(a.nb()){var b=a.i;b.ob()?(a.v='['+b.u):!b.nb()?(a.v='[L'+b.lb()+';'):(a.v='['+b.lb());a.h=b.kb()+'[]';a.s=b.mb()+'[]';return}var c=a.m;var d=a.j;d=d.split('/');a.v=ai('.',[c,ai('$',d)]);a.h=ai('.',[c,ai('.',d)]);a.s=d[d.length-1]}
function yb(b){var c,d,e,f,g;g=b.i&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new gj(b.h);e.g<e.i.g.length;){d=(e.h=e.g++,e.i.g[e.h]);if(d.h){f=d.h;c=f.g;try{X(c)}catch(a){a=jh(a);if(!jd(a,8))throw kh(a)}if(6==(b.i&7)){return true}}}}}tb(b);return false}
function pc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.X();return a&&a.V()}},suppressed:{get:function(){return c.W()}}})}catch(a){}}}
function oo(a){a.D=new $wnd.RTCPeerConnection(Ih({},[Lh({})]));a.F=false;a.G=false;a.D.onicecandidate=vh(Ip.prototype.hb,Ip,[a]);a.D.ontrack=vh(Jp.prototype.ib,Jp,[a]);a.D.onconnectionstatechange=vh(xp.prototype.eb,xp,[a]);a.D.onnegotiationneeded=vh(iq.prototype.eb,iq,[a]);_n(a,nn(a.B));_n(a,nn(a.K))}
function Bj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function ar(a){var b;this.s=new Yr(this);this.j=a;this.m=a.props['a'];this.o=a.props['b'];O();b=++Yq;this.i=new mc(b,new br(this),new cr(this),false);this.g=new ab(new ir,new dr(this),new er(this),35815424);this.h=new Ab(null,new jr(this),ct);Fm(this.m,this,new fr(this));this.u=new Vo(this.o,(fq(),eq),(Vp(),Up));Mo(this.u);Gm(this.m,this.o);I((null,N))}
function xb(a,b,c){var d,e,f,g;g=a.i&7;if(b!=g){a.i=a.i&-8|b;if(!a.g&&6==b){c&&(1==(a.i&7)||1==(3&a.m.g)||H((O(),O(),N),a))}else if(!!a.g&&4==g&&(6==b||5==b)){mb(a.g.l);c&&(1==(a.i&7)||1==(3&a.m.g)||H((O(),O(),N),a))}else if(3==b||3!=g&&2==b){if(a.g){d=a.g;wb((e=d.s,e));d.v=null}Zi(a.h,new Fb(a));a.h.g=$c(ge,As,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.g&&wb((f=a.g.o,f))}}
function mi(a){var b,c,d,e,f,g,h,i;b=new RegExp('\\|','g');h=$c(je,As,2,0,6,1);c=0;i=a;e=null;while(true){g=b.exec(i);if(g==null||i==''){h[c]=i;break}else{f=g.index;h[c]=i.substr(0,f);i=ni(i,f+g[0].length,i.length);b.lastIndex=0;if(e==i){h[c]=i.substr(0,1);i=i.substr(1)}e=i;++c}}if(a.length>0){d=h.length;while(d>0&&h[d-1]==''){--d}d<h.length&&(h.length=d)}return h}
function ko(a){var b,c;F((O(),O(),N),new ep(a),bt);sn(a.B,true);Z(a.g);Ro(a,(Vp(),Up));So(a,(fq(),eq));a.L=new $wnd.WebSocket((b=$wnd.goog.global.globalThis.location,c=s('https',b.protocol)?'wss':'ws',c+'://'+b.hostname+':'+3737+'/r/'+a.C));a.L.onopen=vh(Ep.prototype.eb,Ep,[a]);a.L.onmessage=vh(Fp.prototype.fb,Fp,[a]);a.L.onclose=vh(Gp.prototype.cb,Gp,[a]);a.L.onerror=vh(Hp.prototype.eb,Hp,[a])}
function An(a,b,c){var d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;this.I=a;this.J=b;O();d=++hn;this.H=new mc(d,null,new Bn(this),true);this.A=c;this.G=true;this.h=(m=new nb((f=null,f)),m);this.o=(n=new nb((g=null,g)),n);this.l=(o=new nb((h=null,h)),o);this.j=(p=new nb((i=null,i)),p);this.i=(q=new nb((j=null,j)),q);this.u=(r=new nb((k=null,k)),r);this.s=(l=new nb((e=null,e)),l);this.g=new ab(new Cn(this),null,null,Ws);this.m=new Ab(new Dn(this),null,404750336);I((null,N))}
function Vo(a,b,c){var d,e,f,g,h,i,j,k,l;this.I=new ej;this.H=new pj;this.B=new An(new wp,new Bp(this),false);this.K=new An(new Cp,new Dp(this),false);this.J=new ej;this.C=a;O();d=++to;this.A=new mc(d,new Wo(this),new Xo(this),true);this.v=b;this.u=c;this.s='';this.o=(i=new nb((f=null,f)),i);this.m=(j=new nb((g=null,g)),j);this.l=(k=new nb((e=null,e)),k);this.j=(l=new nb(null),l);this.i=(h=new nb(null),h);this.g=new ab(new Yo(this),null,null,Ws);this.h=new ab(new Zo(this),null,null,Ws)}
function um(){um=uh;$l=new vm(Ss,0);_l=new vm('checkbox',1);am=new vm('color',2);bm=new vm('date',3);cm=new vm('datetime',4);dm=new vm('email',5);em=new vm('file',6);fm=new vm('hidden',7);gm=new vm('image',8);hm=new vm('month',9);im=new vm('number',10);jm=new vm('password',11);km=new vm('radio',12);lm=new vm('range',13);mm=new vm('reset',14);nm=new vm('search',15);om=new vm('submit',16);pm=new vm('tel',17);qm=new vm('text',18);rm=new vm('time',19);sm=new vm('url',20);tm=new vm('week',21)}
function Xb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.l){return}j=(n=a.l.i&7,n>3?n:4);e=false;c=0;if(!!a.h&&1!=(a.l.i&7)){m=a.h.g.length;for(h=0;h<m;h++){k=$i(a.h,h);if(-1!=k.l&&-2!=k.l){k.l=-1;h!=c&&dj(a.h,c,k);++c;if(k.h){l=k.h;f=l.i&7;f==6&&(j=f)}}}}d=a.l.h;for(i=d.g.length-1;i>=0;i--){k=d.g[i];if(-1==k.l){k.l=0}else{hb(k,a.l);e=true}}2<(a.l.i&7)&&4!=j&&(a.l.i&7)<j&&xb(a.l,j,false);if(a.h){for(g=c-1;g>=0;g--){k=$i(a.h,g);if(-1==k.l){k.l=0;gb(k,a.l);e=true}}}if(a.h){for(g=a.h.g.length-1;g>=c;g--){aj(a.h,g)}e&&vb(a.l,a.h)}else{e&&vb(a.l,new ej)}if(db(a.l)&&!!a.l.g){b=a.l.g;k=b.l;!!k.h&&Cs!=(k.h.i&Ds)&&k.i.g.length<=0&&0==k.h.g.j&&_b(a,k)}}
function nr(a){var b,c,d,e;a.m=0;ym();b=(c=(lb(a.h),a.i),d=a.o,e=(kb(d.g),d.i),ul(ft,Hl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['home'])),vh(ls.prototype.Vb,ls,[a])),[ul('h1',null,['vChat']),ul('label',Tl(new $wnd.Object,'roomCode'),['Enter a room code.']),ul('input',Cl(Ll(Ql(Ml(Ol(Nl(Sl(zl(Pl(yl(Gl(new $wnd.Object,(um(),qm)),bd(Yc(je,1),As,2,6,['roomCodeInput'])),'Room code'),'roomCode'),null==c?'':c),vh(ns.prototype.Vb,ns,[a]))),10)))),null),ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['roomSelectButtons'])),[ul(Ss,Gl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[jt])),(Xl(),Wl)),['Join']),ul('a',Dl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[jt])),'#'+Bm()),['Join Random'])]),e.h==0?null:ql([ul(lt,null,['Recently used rooms:']),ql(Fk(Bk(new Gk(null,new ok(e,16)),new ms),new wl))])]));return b}
function Dj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Ns]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Bj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Ns]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function ho(a,b){var c,d,e,f,g,h,i;e=b.data;d=$wnd.goog.global.globalThis.console;h=$wnd.JSON.parse(e);g=h;if(pd(a.L)===pd(b.currentTarget)){Z(a.g);c=g[Is];if(s('create',c)){d.log('Connected to room as host');Ro(a,(Vp(),Tp));So(a,(fq(),aq))}else if(s('connect',c)){d.log('Connected to room as guest');Ro(a,(Vp(),Sp));So(a,(fq(),Zp))}else if(s('full',c)){d.log('Room full. Leaving room.');Ro(a,(Vp(),Up));$n(a,(fq(),_p))}else if(s(_s,c)){f=g['id'];i=g['message'];d.log("Guest '"+f+"' requested access to room with message '"+i+"'");Xi(a.I,new Am(f,i));jb(a.j)}else if(s('accept',c)){d.log('Host allowed guest to join room.');So(a,(fq(),aq));oo(a)}else if(s('reject',c)){d.log('Host rejected guest from room.');So(a,(fq(),bq))}else if(s('accepted',c)){f=g['id'];d.log("Host accepted guest '"+f+"' into room.");nj(a.H,f);jb(a.i)}else if(s('remove',c)){f=g['id'];if(oj(a.H,f)){d.log("Guest '"+f+at);jb(a.i)}else if(cj(a.I,new uq(f))){d.log("Client '"+f+at);jb(a.j)}}else if(s('offer',c)){a.F=true;a.D.setRemoteDescription(g[Xs]);a.D.createAnswer().then(vh(vq.prototype.bb,vq,[a])).then(vh(wq.prototype.bb,wq,[a])).catch(vh(xq.prototype.bb,xq,[a,d]))}else if(s('answer',c)){a.D.setRemoteDescription(g[Xs]);a.F=false;bo(a)}else s(Zs,c)?a.D.addIceCandidate(Jh(Kh({},g[$s]),g[Zs])):s(Ys,c)&&(a.G=true,bo(a))}}
function Wq(a){var b,c,d;a.l=0;ym();b=(c=a.u.B,d=X(a.u.g),ul(lt,Bl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['room-view'])),vh(Zr.prototype.U,Zr,[a])),[ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['video-section'])),[ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['video-list'])),Fk(Bk(X(a.u.h).yb(),new Vr),new wl)),ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['active-video'])),[ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['active-video-wrapper'])),[vs(ts(ss(a.u.B),'active-video-element'),true)]),ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['controls'])),[ul(Ss,Fl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[nt])),vh(bs.prototype.Wb,bs,[a])),[ul(ot,Il(Kl(Jl(new $wnd.Object,on(a.u.K)?'img/screen_share_on.svg':'img/screen_share_off.svg'),32),32),null)]),ul(Ss,Fl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[nt])),vh(cs.prototype.Wb,cs,[c])),[ul(ot,Il(Kl(Jl(new $wnd.Object,X(c.g)?pt:qt),32),32),null)]),ul(Ss,Fl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[nt])),vh(ds.prototype.Wb,ds,[c])),[ul(ot,Il(Kl(Jl(new $wnd.Object,(kb(c.u),c.G?'img/cam_on.svg':'img/cam_off.svg')),32),32),null)]),ul(Ss,Fl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[nt])),vh(es.prototype.Wb,es,[a])),[ul(ot,Il(Kl(Jl(new $wnd.Object,X(a.g)?'img/fullscreen_on.svg':'img/fullscreen_off.svg'),32),32),null)]),ul(Ss,Fl(yl(El(new $wnd.Object,(Pp(),Mp)!=d&&Op!=d),bd(Yc(je,1),As,2,6,[nt])),vh(fs.prototype.Wb,fs,[a])),[ul(ot,Il(Kl(Jl(new $wnd.Object,'img/hangup.svg'),32),32),null)])])])]),ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['message-area'])),[Tq(a)])]));return b}
function Tq(a){var b,c;c=To(a.u);if((fq(),eq)==c){return ql([ul(et,null,['Getting ready...']),ul('p',null,["You'll be able to join in just a moment."])])}else if($p==c){return ql([ul(et,null,['Service Offline']),ul('p',null,['The chat service is offline at the moment. Try again later.'])])}else if(Zp==c){return ql([ul(et,null,['Ready to join?']),ul('p',null,['Request access to join the room.']),ul(ft,Hl(new $wnd.Object,vh(Xr.prototype.Vb,Xr,[a])),[ul('label',Tl(new $wnd.Object,gt),[ht]),ul('input',Ql(Ml(Sl(Nl(Ll(zl(Pl(Gl(new $wnd.Object,(um(),qm)),it),gt)),vh(as.prototype.Vb,as,[a])),Po(a.u)),30)),null),ul(Ss,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[jt])),[kt])])])}else if(cq==c){return ql([ul(et,null,['Joining room']),ul('p',null,['Waiting for host to allow access to the room.'])])}else if(aq==c&&(Vp(),Tp)==Qo(a.u)&&zo(a.u).g.length!=0){b=zo(a.u).g[0];return ql([ul(et,null,['Guest requests access']),ul('p',null,['A guest has sent you a message to join the room:']),ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['request-message'])),[b.h]),ul(ft,Hl(new $wnd.Object,vh(Wr.prototype.Vb,Wr,[])),[ul(Ss,Fl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[jt])),vh($r.prototype.Wb,$r,[a,b])),['Accept']),ul(Ss,Fl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[jt])),vh(_r.prototype.Wb,_r,[a,b])),['Reject'])])])}else return aq==c&&(Vp(),Tp)==Qo(a.u)&&Ji(yo(a.u).g)==0?ql([ul(et,null,['Waiting for guests to join']),ul('p',null,['Waiting for someone to join this room']),ul('a',Dl(new $wnd.Object,'#'+a.u.C),[a.u.C])]):aq==c?ql([ul(et,null,['Joined room']),ul('p',null,['Joined room. Feel free to chat.'])]):bq==c?ql([ul(et,null,['Access denied']),ul('p',null,['The host denied access to the room. You can attempt to re-request access to join the room.']),ul(ft,Hl(new $wnd.Object,vh(Xr.prototype.Vb,Xr,[a])),[ul('label',Tl(new $wnd.Object,gt),[ht]),ul('input',Ql(Ml(Sl(Nl(Ll(zl(Pl(Gl(new $wnd.Object,(um(),qm)),it),gt)),vh(as.prototype.Vb,as,[a])),Po(a.u)),30)),null),ul(Ss,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[jt])),[kt])])]):Yp==c?ql([ul(et,null,['Room closed']),ul('p',null,[(Vp(),Tp)==Qo(a.u)?'You closed the room.':'The host closed the room.']),ul('a',Dl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[jt])),'#'),[mt])]):_p==c?ql([ul(et,null,['Room full']),ul('p',null,['The room is full and no other guests can connect at this time.']),ul('a',Dl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[jt])),'#'),[mt])]):dq==c?ql([ul(et,null,['Left the room']),ul('p',null,['You left the room.']),ul('a',Dl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,[jt])),'#'),[mt])]):null}
var ys='object',zs={6:1},As={4:1},Bs={11:1},Cs=1048576,Ds=1835008,Es=2097152,Fs='__noinit__',Gs={4:1,13:1,10:1,8:1},Hs='null',Is='command',Js={32:1,69:1},Ks={32:1,63:1},Ls={44:1},Ms={4:1,32:1,63:1},Ns='delete',Os=15525485,Ps=5.9604644775390625E-8,Qs=16777216,Rs='children',Ss='button',Ts='vchat.rooms',Us=142606336,Vs='hashchange',Ws=35651584,Xs='session',Ys='renegotiate',Zs='candidate',$s='mlineindex',_s='request_access',at="' left the room.",bt=75497472,ct=1411518464,dt='fullscreenchange',et='h2',ft='form',gt='requestAccessMessage',ht='Enter a message to send to the host to request access.',it="Hi, I'm John Doe.",jt='primary-button',kt='Request Access',lt='div',mt='Return to Home',nt='control-btn',ot='img',pt='img/mic_on.svg',qt='img/mic_off.svg';var _,qh,lh,ih=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;rh();th(1,null,{},t);_.M=function(a){return s(this,a)};_.N=function(){return this.Yb};_.O=st;_.P=function(){var a;return Th(v(this))+'@'+(a=w(this)>>>0,a.toString(16))};_.equals=function(a){return this.M(a)};_.hashCode=function(){return this.O()};_.toString=function(){return this.P()};var dd,ed,fd;th(71,1,{},Uh);_.jb=function(a){var b;b=new Uh;b.l=4;a>1?(b.i=Zh(this,a-1)):(b.i=this);return b};_.kb=function(){Sh(this);return this.h};_.lb=function(){return Th(this)};_.mb=function(){Sh(this);return this.s};_.nb=function(){return (this.l&4)!=0};_.ob=function(){return (this.l&1)!=0};_.P=function(){return ((this.l&2)!=0?'interface ':(this.l&1)!=0?'':'class ')+(Sh(this),this.v)};_.l=0;_.o=0;var Rh=1;var ge=Wh(1);var Yd=Wh(71);th(104,1,{},J);_.h=1;_.i=false;_.j=true;_.l=0;var vd=Wh(104);th(105,1,zs,K);_.Q=function(){Hb(this.g)};var sd=Wh(105);th(57,1,{},L);_.R=function(){return this.g.Q(),null};var td=Wh(57);th(106,1,{},M);var ud=Wh(106);var N;th(58,1,{58:1},U);_.h=0;_.i=false;_.j=0;var wd=Wh(58);th(259,1,Bs);_.P=function(){var a;return Th(this.Yb)+'@'+(a=w(this)>>>0,a.toString(16))};var zd=Wh(259);th(39,259,Bs,ab);_.S=function(){W(this)};_.T=rt;_.g=false;_.j=0;_.u=false;var yd=Wh(39);th(143,1,{},bb);_.R=function(){return Y(this.g)};var xd=Wh(143);th(12,259,{11:1,12:1},nb);_.S=function(){eb(this)};_.T=function(){return -2==this.l};_.g=4;_.j=false;_.l=0;var Bd=Wh(12);th(142,1,zs,ob);_.Q=function(){fb(this.g)};var Ad=Wh(142);th(24,259,{11:1,24:1},Ab,Bb);_.S=function(){pb(this)};_.T=function(){return 1==(this.i&7)};_.i=0;var Gd=Wh(24);th(137,1,{},Cb);_.Q=function(){V(this.g)};var Cd=Wh(137);th(138,1,zs,Db);_.Q=function(){rb(this.g)};var Dd=Wh(138);th(139,1,zs,Eb);_.Q=function(){ub(this.g)};var Ed=Wh(139);th(140,1,{},Fb);_.U=function(a){sb(this.g,a)};var Fd=Wh(140);th(117,1,{},Ib);_.g=0;_.h=0;_.i=0;var Hd=Wh(117);th(148,1,Bs,Kb);_.S=function(){Jb(this)};_.T=rt;_.g=false;var Id=Wh(148);th(82,259,{11:1,82:1},Ob);_.S=function(){Lb(this)};_.T=function(){return 2==(3&this.g)};_.g=0;var Kd=Wh(82);th(116,1,{},Tb);var Jd=Wh(116);th(149,1,{},dc);_.P=function(){var a;return Sh(Ld),Ld.v+'@'+(a=bl(this)>>>0,a.toString(16))};_.g=0;var Ub;var Ld=Wh(149);th(23,1,Bs,mc);_.S=function(){hc(this)};_.T=function(){return this.s<0};_.P=function(){var a;return Sh(Nd),Nd.v+'@'+(a=bl(this)>>>0,a.toString(16))};_.j=0;_.s=0;var Nd=Wh(23);th(136,1,zs,nc);_.Q=function(){kc(this.g)};var Md=Wh(136);th(8,1,{4:1,8:1});_.V=At;_.W=function(){return Fk(Bk(ij((this.s==null&&(this.s=$c(le,As,8,0,0,1)),this.s)),new wi),new Jk)};_.X=function(){return this.m};_.Y=function(){return this.o};_.Z=function(){qc(this,sc(new Error(rc(this,this.o))));Vc(this)};_.P=function(){return rc(this,this.Y())};_.l=Fs;_.u=true;var le=Wh(8);th(13,8,{4:1,13:1,8:1});var _d=Wh(13);th(10,13,Gs);var he=Wh(10);th(99,10,Gs);var ee=Wh(99);th(100,99,Gs);var Rd=Wh(100);th(48,100,{48:1,4:1,13:1,10:1,8:1},yc);_.Y=function(){xc(this);return this.i};_.$=function(){return pd(this.h)===pd(vc)?null:this.h};var vc;var Od=Wh(48);var Pd=Wh(0);th(243,1,{});var Qd=Wh(243);var Ac=0,Bc=0,Cc=-1;th(109,243,{},Qc);var Mc;var Sd=Wh(109);var Tc;th(253,1,{});var Ud=Wh(253);th(101,253,{},Xc);var Td=Wh(101);th(73,1,{96:1});_.P=rt;var Vd=Wh(73);th(103,10,Gs);var ce=Wh(103);th(141,103,Gs,Ph);var Wd=Wh(141);dd={4:1,97:1,22:1};var Xd=Wh(97);th(56,1,{4:1,56:1});var fe=Wh(56);ed={4:1,22:1,98:1,56:1};var Zd=Wh(98);th(16,1,{4:1,22:1,16:1});_.M=function(a){return this===a};_.O=st;_.P=function(){return this.g!=null?this.g:''+this.h};_.h=0;var $d=Wh(16);th(72,10,Gs,di);var ae=Wh(72);th(102,10,Gs,ei);var be=Wh(102);th(37,56,{4:1,22:1,37:1,56:1},fi);_.M=function(a){return jd(a,37)&&a.g==this.g};_.O=rt;_.P=function(){return ''+this.g};_.g=0;var de=Wh(37);var hi;th(356,1,{});fd={4:1,96:1,22:1,2:1};var je=Wh(2);th(55,73,{96:1},ui,vi);var ie=Wh(55);th(360,1,{});th(94,1,{},wi);_.rb=function(a){return a.l};var ke=Wh(94);th(47,10,Gs,xi,yi);var me=Wh(47);th(254,1,{32:1});_.pb=zt;_.xb=function(){return new ok(this,0)};_.yb=function(){return new Gk(null,this.xb())};_.sb=function(a){throw kh(new yi('Add not supported on this collection'))};_.tb=function(){var a;for(a=this.qb();a.Cb();){a.Db();a.Eb()}};_.ub=function(a){return zi(this,a,false)};_.vb=function(){return this.wb()==0};_.zb=function(){return this.Ab($c(ge,As,1,this.wb(),5,1))};_.Ab=function(a){var b,c,d,e;e=this.wb();a.length<e&&(a=$k(new Array(e),a));d=a;c=this.qb();for(b=0;b<e;++b){d[b]=c.Db()}a.length>e&&(a[e]=null);return a};_.P=function(){var a,b,c;c=new rk(', ','[',']');for(b=this.qb();b.Cb();){a=b.Db();pk(c,a===this?'(this Collection)':a==null?Hs:xh(a))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var ne=Wh(254);th(257,1,{240:1});_.M=function(a){var b,c,d;if(a===this){return true}if(!jd(a,49)){return false}d=a;if(this.g.h+this.h.h!=d.g.h+d.h.h){return false}for(c=new Pi((new Li(d)).g);c.h;){b=Ni(c);if(!Bi(this,b)){return false}}return true};_.O=function(){return jj(new Li(this))};_.P=function(){var a,b,c;c=new rk(', ','{','}');for(b=new Pi((new Li(this)).g);b.h;){a=Ni(b);pk(c,Ci(this,a.Lb())+'='+Ci(this,a.Mb()))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var ze=Wh(257);th(118,257,{240:1});var qe=Wh(118);th(256,254,Js);_.xb=function(){return new ok(this,1)};_.M=function(a){var b;if(a===this){return true}if(!jd(a,69)){return false}b=a;if(b.wb()!=this.wb()){return false}return Ai(this,b)};_.O=function(){return jj(this)};var Be=Wh(256);th(35,256,Js,Li);_.tb=vt;_.ub=function(a){return Ki(this,a)};_.qb=function(){return new Pi(this.g)};_.wb=wt;var pe=Wh(35);th(38,1,{},Pi);_.Bb=tt;_.Db=function(){return Ni(this)};_.Cb=xt;_.Eb=function(){Oi(this)};_.h=false;var oe=Wh(38);th(255,254,Ks);_.xb=function(){return new ok(this,16)};_.Fb=function(a,b){throw kh(new yi('Add not supported on this list'))};_.sb=function(a){this.Fb(this.wb(),a);return true};_.tb=function(){this.Jb(0,this.wb())};_.M=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,63)){return false}f=a;if(this.wb()!=f.wb()){return false}e=f.qb();for(c=this.qb();c.Cb();){b=c.Db();d=e.Db();if(!(pd(b)===pd(d)||b!=null&&u(b,d))){return false}}return true};_.O=function(){return kj(this)};_.qb=function(){return new Ri(this)};_.Hb=function(a){return new Si(this,a)};_.Ib=function(a){throw kh(new yi('Remove not supported on this list'))};_.Jb=function(a,b){var c,d;d=this.Hb(a);for(c=a;c<b;++c){d.Db();d.Eb()}};var te=Wh(255);th(74,1,{},Ri);_.Bb=tt;_.Cb=function(){return this.h<this.j.wb()};_.Db=function(){this.h<this.j.wb();return this.j.Gb(this.i=this.h++)};_.Eb=ut;_.h=0;_.i=-1;var re=Wh(74);th(108,74,{},Si);_.Eb=ut;_.Kb=function(a){this.g.Fb(this.h,a);++this.h;this.i=-1};var se=Wh(108);th(112,256,Js,Ti);_.tb=vt;_.ub=yt;_.qb=function(){var a;return a=new Pi((new Li(this.g)).g),new Ui(a)};_.wb=wt;var ve=Wh(112);th(75,1,{},Ui);_.Bb=tt;_.Cb=function(){return this.g.h};_.Db=function(){var a;a=Ni(this.g);return a.Lb()};_.Eb=function(){Oi(this.g)};var ue=Wh(75);th(110,1,Ls);_.M=function(a){var b;if(!jd(a,44)){return false}b=a;return lj(this.g,b.Lb())&&lj(this.h,b.Mb())};_.Lb=rt;_.Mb=xt;_.O=function(){return $j(this.g)^$j(this.h)};_.Nb=function(a){var b;b=this.h;this.h=a;return b};_.P=function(){return this.g+'='+this.h};var we=Wh(110);th(111,110,Ls,Vi);var xe=Wh(111);th(258,1,Ls);_.M=function(a){var b;if(!jd(a,44)){return false}b=a;return lj(this.h.value[0],b.Lb())&&lj(Lj(this),b.Mb())};_.O=function(){return $j(this.h.value[0])^$j(Lj(this))};_.P=function(){return this.h.value[0]+'='+Lj(this)};var ye=Wh(258);th(261,255,Ks);_.Fb=function(a,b){var c;c=this.Hb(a);c.Kb(b)};_.Gb=function(a){var b;b=this.Hb(a);return b.Db()};_.qb=function(){return Rj(this,0)};_.Ib=function(a){var b,c;b=this.Hb(a);c=b.Db();b.Eb();return c};var Ae=Wh(261);th(15,255,Ms,ej,fj);_.Fb=function(a,b){Xk(this.g,a,b)};_.sb=function(a){return Xi(this,a)};_.tb=function(){this.g=$c(ge,As,1,0,5,1)};_.ub=function(a){return _i(this,a,0)!=-1};_.pb=function(a){Zi(this,a)};_.Gb=function(a){return $i(this,a)};_.vb=function(){return this.g.length==0};_.qb=function(){return new gj(this)};_.Ib=function(a){return aj(this,a)};_.Jb=function(a,b){var c;c=b-a;Zk(this.g,a,c)};_.wb=function(){return this.g.length};_.zb=function(){return Vk(this.g,this.g.length)};_.Ab=function(a){var b,c;c=this.g.length;a.length<c&&(a=$k(new Array(c),a));for(b=0;b<c;++b){a[b]=this.g[b]}a.length>c&&(a[c]=null);return a};var De=Wh(15);th(29,1,{},gj);_.Bb=tt;_.Cb=function(){return this.g<this.i.g.length};_.Db=function(){return this.h=this.g++,this.i.g[this.h]};_.Eb=function(){aj(this.i,this.g=this.h);this.h=-1};_.g=0;_.h=-1;var Ce=Wh(29);th(49,118,{4:1,49:1,240:1},mj);var Ee=Wh(49);th(168,256,{4:1,32:1,69:1},pj);_.sb=function(a){return nj(this,a)};_.tb=vt;_.ub=yt;_.vb=function(){return Ji(this.g)==0};_.qb=function(){var a;return a=new Pi((new Li((new Ti(this.g)).g)).g),new Ui(a)};_.wb=wt;var Fe=Wh(168);th(76,1,{},vj);_.pb=zt;_.qb=function(){return new wj(this)};_.h=0;var He=Wh(76);th(77,1,{},wj);_.Bb=tt;_.Db=function(){return this.j=this.g[this.i++],this.j};_.Cb=function(){var a;if(this.i<this.g.length){return true}a=this.h.next();if(!a.done){this.g=a.value[1];this.i=0;return true}return false};_.Eb=function(){uj(this.l,this.j.Lb());this.i!=0&&--this.i};_.i=0;_.j=null;var Ge=Wh(77);var zj;th(78,1,{},Jj);_.pb=zt;_.qb=function(){return new Kj(this)};_.h=0;_.i=0;var Ke=Wh(78);th(79,1,{},Kj);_.Bb=tt;_.Db=function(){return this.i=this.g,this.g=this.h.next(),new Mj(this.j,this.i,this.j.i)};_.Cb=function(){return !this.g.done};_.Eb=function(){Ij(this.j,this.i.value[0])};var Ie=Wh(79);th(119,258,Ls,Mj);_.Lb=function(){return this.h.value[0]};_.Mb=function(){return Lj(this)};_.Nb=function(a){return Hj(this.g,this.h.value[0],a)};_.i=0;var Je=Wh(119);th(159,261,Ms,Vj);_.sb=function(a){Qj(this,a,this.i.h,this.i);return true};_.tb=function(){Uj(this)};_.Hb=function(a){return Rj(this,a)};_.wb=xt;_.h=0;var Ne=Wh(159);th(160,1,{},Xj);_.Bb=tt;_.Kb=function(a){Qj(this.j,a,this.h.h,this.h);++this.g;this.i=null};_.Cb=function(){return this.h!=this.j.i};_.Db=function(){return Wj(this)};_.Eb=function(){var a;a=this.i.g;Tj(this.j,this.i);this.h==this.i?(this.h=a):--this.g;this.i=null};_.g=0;_.i=null;var Le=Wh(160);th(60,1,{},Yj);var Me=Wh(60);th(202,1,{},fk);_.g=0;_.h=0;var _j,ak,bk=0;var Oe=Wh(202);th(121,1,{});_.Bb=Bt;_.Ob=function(){return this.j};_.Pb=At;_.j=0;_.l=0;var Se=Wh(121);th(80,121,{});var Pe=Wh(80);th(113,1,{});_.Bb=Bt;_.Ob=xt;_.Pb=function(){return this.j-this.i};_.h=0;_.i=0;_.j=0;var Re=Wh(113);th(114,113,{},mk);_.Bb=function(a){jk(this,a)};_.Qb=function(a){return kk(this,a)};var Qe=Wh(114);th(30,1,{},ok);_.Ob=rt;_.Pb=function(){nk(this);return this.i};_.Bb=function(a){nk(this);this.j.Bb(a)};_.Qb=function(a){nk(this);if(this.j.Cb()){a.U(this.j.Db());return true}return false};_.g=0;_.i=0;var Te=Wh(30);th(46,1,{},qk,rk);_.P=function(){return !this.g?this.i:this.l.length==0?this.g.g:this.g.g+(''+this.l)};var Ue=Wh(46);th(70,1,{},sk);_.rb=function(a){return a};var Ve=Wh(70);th(83,1,{},tk);var We=Wh(83);th(120,1,{});_.i=false;var ef=Wh(120);th(31,120,{},Gk);var xk;var df=Wh(31);th(95,1,{},Jk);_.Rb=function(a){return yk(),$c(ge,As,1,a,5,1)};var Xe=Wh(95);th(81,80,{},Lk);_.Qb=function(a){this.h=false;while(!this.h&&this.i.Qb(new Mk(this,a)));return this.h};_.h=false;var Ze=Wh(81);th(125,1,{},Mk);_.U=function(a){Kk(this.g,this.h,a)};var Ye=Wh(125);th(122,80,{},Ok);_.Qb=function(a){return this.h.Qb(new Pk(this,a))};var _e=Wh(122);th(124,1,{},Pk);_.U=function(a){Nk(this.g,this.h,a)};var $e=Wh(124);th(123,1,{},Rk);_.U=function(a){Qk(this,a)};var af=Wh(123);th(126,1,{},Sk);_.U=function(a){yk()};var bf=Wh(126);th(127,1,{},Uk);_.U=function(a){Tk(this,a)};var cf=Wh(127);th(358,1,{});th(355,1,{});var al=0;var cl,dl=0,el;th(1348,1,{});th(1381,1,{});th(84,1,{},wl);_.Rb=function(a){return new Array(a)};var ff=Wh(84);th(308,$wnd.Function,{},xl);_.Ub=function(a){vl(this.g,this.h,a)};th(40,16,{4:1,22:1,16:1,40:1},Yl);var Ul,Vl,Wl;var gf=Xh(40,Zl);th(9,16,{4:1,22:1,16:1,9:1},vm);var $l,_l,am,bm,cm,dm,em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm,qm,rm,sm,tm;var hf=Xh(9,wm);var xm;th(293,$wnd.Function,{},zm);_.bb=function(a){return Jb(xm),xm=null,null};th(87,1,{87:1},Am);var jf=Wh(87);th(59,1,{59:1});var kf=Wh(59);th(150,59,{11:1,59:1},Hm);_.S=Ct;_.T=Dt;_.P=function(){var a;return Sh(of),of.v+'@'+(a=bl(this)>>>0,a.toString(16))};var Em=0;var of=Wh(150);th(151,1,zs,Im);_.Q=function(){cb(this.g.j)};var lf=Wh(151);th(152,1,zs,Jm);_.Q=function(){eb(this.g.g)};var mf=Wh(152);th(153,1,zs,Km);_.Q=function(){Cm(this.g,this.h)};var nf=Wh(153);th(161,1,{});var _f=Wh(161);th(162,161,Bs,Pm);_.S=Ct;_.T=Dt;_.P=function(){var a;return Sh(uf),uf.v+'@'+(a=bl(this)>>>0,a.toString(16))};var Nm=0;var uf=Wh(162);th(163,1,zs,Qm);_.Q=function(){W(this.g.g)};var pf=Wh(163);th(165,1,{},Rm);_.Q=function(){Lm(this.g)};var qf=Wh(165);th(166,1,{},Sm);_.Q=function(){Mm(this.g)};var rf=Wh(166);th(164,1,{},Tm);_.R=function(){var a;return a=$wnd.goog.global.globalThis.location.hash,a.length==0?a:a.substr(1)};var sf=Wh(164);th(167,1,zs,Um);_.Q=Ht;var tf=Wh(167);th(61,1,{61:1});_.K=0;var ag=Wh(61);th(62,61,{11:1,61:1},An);_.S=function(){hc(this.H)};_.T=function(){return this.H.s<0};_.P=function(){var a;return Sh(Gf),Gf.v+'@'+(a=bl(this)>>>0,a.toString(16))};_.v=false;_.A=false;_.G=false;var hn=0;var Gf=Wh(62);th(223,1,zs,Bn);_.Q=function(){jn(this.g)};var vf=Wh(223);th(224,1,{},Cn);_.R=function(){return pn(this.g)};var wf=Wh(224);th(225,1,{},Dn);_.Q=function(){$m(this.g)};var xf=Wh(225);th(226,1,zs,En);_.Q=function(){kn(this.g,this.h)};var yf=Wh(226);th(88,1,zs,Fn);_.Q=function(){an(this.g,this.h)};_.h=false;var zf=Wh(88);th(227,1,zs,Gn);_.Q=function(){qn(this.g)};var Af=Wh(227);th(228,1,zs,Hn);_.Q=function(){en(this.g)};var Bf=Wh(228);th(229,1,zs,In);_.Q=function(){fn(this.g)};var Cf=Wh(229);th(230,1,zs,Jn);_.Q=function(){bn(this.g,this.h)};var Df=Wh(230);th(231,1,zs,Kn);_.Q=function(){cn(this.g)};var Ef=Wh(231);th(232,1,zs,Ln);_.Q=function(){dn(this.g,this.h)};var Ff=Wh(232);th(203,1,{});_.F=false;_.G=false;var sg=Wh(203);th(204,203,Bs,Vo);_.S=function(){hc(this.A)};_.T=function(){return this.A.s<0};_.P=function(){var a;return Sh(Zf),Zf.v+'@'+(a=bl(this)>>>0,a.toString(16))};var to=0;var Zf=Wh(204);th(205,1,zs,Wo);_.Q=function(){vo(this.g)};var Hf=Wh(205);th(206,1,zs,Xo);_.Q=function(){uo(this.g)};var If=Wh(206);th(207,1,{},Yo);_.R=function(){return Ao(this.g)};var Jf=Wh(207);th(208,1,{},Zo);_.R=function(){return Nn(this.g)};var Kf=Wh(208);th(209,1,zs,$o);_.Q=function(){wo(this.g,this.h)};var Lf=Wh(209);th(210,1,zs,_o);_.Q=function(){po(this.g)};var Mf=Wh(210);th(211,1,zs,ap);_.Q=function(){ko(this.g)};var Nf=Wh(211);th(212,1,zs,bp);_.Q=function(){eo(this.g,this.h)};var Of=Wh(212);th(213,1,zs,cp);_.Q=function(){jo(this.g,this.h)};var Pf=Wh(213);th(214,1,zs,dp);_.Q=function(){io(this.g,this.h)};var Qf=Wh(214);th(86,1,zs,ep);_.Q=function(){$n(this.g,(fq(),dq))};var Rf=Wh(86);th(215,1,zs,fp);_.Q=function(){fo(this.g,this.h)};var Sf=Wh(215);th(216,1,zs,gp);_.Q=function(){Bo(this.g,this.h)};var Tf=Wh(216);th(217,1,zs,hp);_.Q=function(){co(this.g,this.h)};var Uf=Wh(217);th(218,1,zs,ip);_.Q=function(){ho(this.g,this.h)};var Vf=Wh(218);th(219,1,zs,jp);_.Q=function(){mo(this.g)};var Wf=Wh(219);th(220,1,zs,kp);_.Q=function(){Co(this.g,this.h)};var Xf=Wh(220);th(221,1,zs,lp);_.Q=function(){Do(this.g,this.h)};var Yf=Wh(221);th(147,1,{},mp);_.handleEvent=function(a){Om(this.g)};var $f=Wh(147);th(337,$wnd.Function,{},np);_._=function(a,b,c){return Qh(),a.enabled?true:false};th(330,$wnd.Function,{},op);_._=Et;th(331,$wnd.Function,{},pp);_._=Et;th(332,$wnd.Function,{},qp);_.bb=function(a){return Wm(this.g,this.h,a)};_.h=0;th(333,$wnd.Function,{},rp);_.bb=function(a){return Xm(this.g,this.h,a)};_.h=0;th(334,$wnd.Function,{},sp);_._=function(a,b,c){return Ym(this.g,a)};th(336,$wnd.Function,{},tp);_.eb=function(a){Zm(this.g)};th(335,$wnd.Function,{},up);_._=function(a,b,c){return gn(a)};th(270,$wnd.Function,{},vp);_._=function(a,b,c){return s('live',a.readyState)&&a.stop(),null};th(187,1,{},wp);_.Tb=function(){return $wnd.goog.global.globalThis.navigator.mediaDevices.getUserMedia(Fh(Eh({}),Gh(Hh({},Bh(Ah(Ch({},160),640),1280)),Bh(Ah(Ch({},120),360),720))))};var bg=Wh(187);th(318,$wnd.Function,{},xp);_.eb=function(a){Go(this.g,a)};th(191,1,{},yp);_.U=Ft;var cg=Wh(191);th(329,$wnd.Function,{},zp);_.gb=function(a){Ko(this.g,a)};th(196,1,{},Ap);_.U=Ft;var dg=Wh(196);th(188,1,{},Bp);_.U=Gt;var eg=Wh(188);th(189,1,{},Cp);_.Tb=function(){return $wnd.goog.global.globalThis.navigator.mediaDevices.getDisplayMedia(Dh({}))};var fg=Wh(189);th(190,1,{},Dp);_.U=Gt;var gg=Wh(190);th(311,$wnd.Function,{},Ep);_.eb=function(a){Jo(this.g,a)};th(312,$wnd.Function,{},Fp);_.fb=function(a){Io(this.g,a)};th(313,$wnd.Function,{},Gp);_.cb=function(a){Fo(this.g,a)};th(314,$wnd.Function,{},Hp);_.eb=function(a){Ho(this.g,a)};th(316,$wnd.Function,{},Ip);_.hb=function(a){go(this.g,a)};th(317,$wnd.Function,{},Jp);_.ib=function(a){Lo(this.g,a)};th(25,16,{4:1,22:1,16:1,25:1},Qp);var Kp,Lp,Mp,Np,Op;var hg=Xh(25,Rp);th(41,16,{4:1,22:1,16:1,41:1},Wp);var Sp,Tp,Up;var ig=Xh(41,Xp);th(17,16,{4:1,22:1,16:1,17:1},gq);var Yp,Zp,$p,_p,aq,bq,cq,dq,eq;var jg=Xh(17,hq);th(319,$wnd.Function,{},iq);_.eb=function(a){ao(this.g)};th(320,$wnd.Function,{},jq);_._=function(a,b,c){return On(this.g,this.h,a)};th(309,$wnd.Function,{},kq);_._=function(a,b,c){return Pn(this.g,a)};th(328,$wnd.Function,{},lq);_.ab=function(a,b,c){return qo(this.g,a)};th(321,$wnd.Function,{},mq);_.bb=function(a){return Qn(this.g,a)};th(322,$wnd.Function,{},nq);_.bb=function(a){return Rn(this.g)};th(323,$wnd.Function,{},oq);_.bb=function(a){return Sn(this.g,a)};th(324,$wnd.Function,{},pq);_._=function(a,b,c){return Tn(this.g,a)};th(192,1,{},qq);_.Sb=function(a){return Un(this.g,a)};var kg=Wh(192);th(193,1,{},rq);_.U=function(a){};var lg=Wh(193);th(194,1,{},sq);_.Tb=function(){return $wnd.Promise.resolve(this.g)};var mg=Wh(194);th(195,1,{},tq);_.Sb=function(a){return Vn(this.g,a)};var ng=Wh(195);th(197,1,{},uq);_.Sb=function(a){return ro(this.g,a)};var og=Wh(197);th(325,$wnd.Function,{},vq);_.bb=function(a){return Wn(this.g,a)};th(326,$wnd.Function,{},wq);_.bb=function(a){return Xn(this.g)};th(327,$wnd.Function,{},xq);_.bb=function(a){return Yn(this.g,this.h,a)};th(198,1,zs,yq);_.Q=function(){Zn(this.g,this.h)};var pg=Wh(198);th(199,1,zs,zq);_.Q=function(){no(this.g,ml('reject_access','id',this.h.g))};var qg=Wh(199);th(200,1,{},Aq);_.Sb=function(a){return so(this.g,a)};var rg=Wh(200);th(129,1,{});var ug=Wh(129);th(93,1,{},Bq);var tg=Wh(93);th(130,129,{});_.j=0;var Tg=Wh(130);th(131,130,Bs,Hq);_.S=Ct;_.T=Dt;_.P=function(){var a;return Sh(zg),zg.v+'@'+(a=bl(this)>>>0,a.toString(16))};var Fq=0;var zg=Wh(131);th(132,1,zs,Iq);_.Q=function(){cb(this.g.l)};var vg=Wh(132);th(133,1,zs,Jq);_.Q=function(){pb(this.g.g)};var wg=Wh(133);th(135,1,{},Kq);_.R=function(){return Dq(this.g)};var xg=Wh(135);th(134,1,{},Lq);_.Q=function(){Eq(this.g)};var yg=Wh(134);th(146,1,{});var bh=Wh(146);th(176,146,{});_.l=0;var Vg=Wh(176);th(177,176,Bs,ar);_.S=function(){hc(this.i)};_.T=function(){return this.i.s<0};_.P=function(){var a;return Sh(Jg),Jg.v+'@'+(a=bl(this)>>>0,a.toString(16))};var Yq=0;var Jg=Wh(177);th(178,1,zs,br);_.Q=function(){cb(this.g.u)};var Ag=Wh(178);th(179,1,zs,cr);_.Q=function(){Zq(this.g)};var Bg=Wh(179);th(181,1,{},dr);_.Q=function(){Rq(this.g)};var Cg=Wh(181);th(182,1,{},er);_.Q=function(){Sq(this.g)};var Dg=Wh(182);th(184,1,zs,fr);_.Q=function(){hc(this.g.i)};var Eg=Wh(184);th(185,1,{},gr);_.R=function(){return Wq(this.g)};var Fg=Wh(185);th(186,1,zs,hr);_.Q=Ht;var Gg=Wh(186);th(180,1,{},ir);_.R=function(){return Qh(),$wnd.goog.global.globalThis.document.fullscreen?true:false};var Hg=Wh(180);th(183,1,{},jr);_.Q=function(){Xq(this.g)};var Ig=Wh(183);th(260,1,{});var fh=Wh(260);th(169,260,{});_.m=0;var Xg=Wh(169);th(170,169,Bs,tr);_.S=function(){hc(this.j)};_.T=function(){return this.j.s<0};_.P=function(){var a;return Sh(Pg),Pg.v+'@'+(a=bl(this)>>>0,a.toString(16))};var pr=0;var Pg=Wh(170);th(171,1,zs,ur);_.Q=function(){qr(this.g)};var Kg=Wh(171);th(173,1,zs,vr);_.Q=function(){hc(this.g.j)};var Lg=Wh(173);th(174,1,zs,wr);_.Q=function(){rr(this.g,this.h)};var Mg=Wh(174);th(175,1,{},xr);_.R=function(){return nr(this.g)};var Ng=Wh(175);th(172,1,{},yr);_.Q=function(){or(this.g)};var Og=Wh(172);th(201,1,{});var hh=Wh(201);th(233,201,{});var Zg=Wh(233);th(234,233,Bs,Dr);_.S=function(){hc(this.g)};_.T=function(){return this.g.s<0};_.P=function(){var a;return Sh(Rg),Rg.v+'@'+(a=bl(this)>>>0,a.toString(16))};var Cr=0;var Rg=Wh(234);th(235,1,zs,Er);_.Q=function(){hc(this.g.g)};var Qg=Wh(235);th(292,$wnd.Function,{},Fr);_.Xb=function(a){return new Ir(a)};var Gr;th(115,$wnd.React.Component,{},Ir);sh(qh[1],_);_.componentWillUnmount=function(){Cq(this.g)};_.render=function(){return Gq(this.g)};_.shouldComponentUpdate=function(a){return 1==this.g.j};var Sg=Wh(115);th(297,$wnd.Function,{},Jr);_.Xb=function(a){return new Mr(a)};var Kr;th(156,$wnd.React.Component,{},Mr);sh(qh[1],_);_.componentWillUnmount=function(){db(this.g)&&Vq(this.g)};_.render=function(){return db(this.g)?$q(this.g):null};_.shouldComponentUpdate=function(a){return db(this.g)&&1==this.g.l};var Ug=Wh(156);th(294,$wnd.Function,{},Nr);_.Xb=function(a){return new Qr(a)};var Or;th(154,$wnd.React.Component,{},Qr);sh(qh[1],_);_.componentWillUnmount=function(){db(this.g)&&mr(this.g)};_.render=function(){return db(this.g)?sr(this.g):null};_.shouldComponentUpdate=function(a){return db(this.g)&&1==this.g.m};var Wg=Wh(154);th(338,$wnd.Function,{},Rr);_.Xb=function(a){return new Ur(a)};var Sr;th(222,$wnd.React.Component,{},Ur);sh(qh[1],_);_.componentWillUnmount=function(){db(this.g)&&hc(this.g.g)};_.render=function(){return db(this.g)?Ar(this.g):null};_.shouldComponentUpdate=function(a){return db(this.g)&&Br(this.g,a)};var Yg=Wh(222);th(158,1,{},Vr);_.rb=function(a){var b;return ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['video-list-item'])),[ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['video-list-item-wrapper'])),[vs(ts(us(new ws,a),'video-list-item-element'),false)]),(b=(kb(a.o),a.D),null!=b&&b.getAudioTracks().length>0?ul(lt,yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['video-list-item-controls'])),[ul(Ss,Fl(yl(new $wnd.Object,bd(Yc(je,1),As,2,6,['video-list-item-control-btn'])),vh(gs.prototype.Wb,gs,[a])),[ul(ot,Il(Kl(Jl(new $wnd.Object,X(a.g)?pt:qt),16),16),null)])]):null)])};var $g=Wh(158);th(305,$wnd.Function,{},Wr);_.Vb=function(a){a.preventDefault()};th(268,$wnd.Function,{},Xr);_.Vb=function(a){Uq(this.g,a)};th(157,1,{},Yr);_.handleEvent=function(a){_q(this.g)};var _g=Wh(157);th(298,$wnd.Function,{},Zr);_.U=function(a){Mq(this.g,a)};th(306,$wnd.Function,{},$r);_.Wb=function(a){Nq(this.g,this.h,a)};th(307,$wnd.Function,{},_r);_.Wb=function(a){Oq(this.g,this.h,a)};th(269,$wnd.Function,{},as);_.Vb=function(a){Pq(this.g,a)};th(299,$wnd.Function,{},bs);_.Wb=function(a){Uo(this.g.u)};th(300,$wnd.Function,{},cs);_.Wb=It;th(301,$wnd.Function,{},ds);_.Wb=function(a){zn(this.g)};th(302,$wnd.Function,{},es);_.Wb=function(a){Qq(this.g)};th(303,$wnd.Function,{},fs);_.Wb=function(a){Eo(this.g.u)};th(304,$wnd.Function,{},gs);_.Wb=It;th(145,1,{},ks);var ah=Wh(145);th(295,$wnd.Function,{},ls);_.Vb=function(a){kr(this.g,a)};th(155,1,{},ms);_.rb=function(a){return ul('a',Dl(yl(Al(new $wnd.Object,a),bd(Yc(je,1),As,2,6,['recent-room'])),'#'+a),[a])};var dh=Wh(155);th(296,$wnd.Function,{},ns);_.Vb=function(a){var b;lr(this.g,oi((b=a.target,b).value))};th(144,1,{},qs);var eh=Wh(144);th(339,$wnd.Function,{},rs);_.U=function(a){zr(this.g,a)};th(85,1,{},ws);var gh=Wh(85);var rd=Yh('D');var xs=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=oh;mh(zh);ph('permProps',[[]]);if (vchat) vchat.onScriptLoad(gwtOnLoad);})();