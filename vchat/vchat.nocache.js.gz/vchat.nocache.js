function vchat(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='vchat',tb='__gwt_marker_vchat',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='4ACA23FD58913E8E5EF406BBB872F072',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};vchat.onScriptLoad=function(a){vchat=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
vchat();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '4ACA23FD58913E8E5EF406BBB872F072';function t(){}
function yh(){}
function uh(){}
function Kb(){}
function Qc(){}
function Xc(){}
function zi(){}
function zl(){}
function _j(){}
function vk(){}
function Mk(){}
function Uk(){}
function Vk(){}
function Cm(){}
function Um(){}
function op(){}
function pp(){}
function qp(){}
function vp(){}
function wp(){}
function xp(){}
function zp(){}
function Bp(){}
function Dp(){}
function sq(){}
function jr(){}
function Gr(){}
function Kr(){}
function Or(){}
function Sr(){}
function Wr(){}
function Xr(){}
function ns(){}
function Vc(a){Uc()}
function Th(){Th=uh}
function vt(){Ti(this)}
function hj(){Zi(this)}
function K(a){this.g=a}
function L(a){this.g=a}
function M(a){this.g=a}
function bb(a){this.g=a}
function ob(a){this.g=a}
function Cb(a){this.g=a}
function Db(a){this.g=a}
function Eb(a){this.g=a}
function Fb(a){this.g=a}
function nc(a){this.g=a}
function Rh(a){this.g=a}
function ii(a){this.g=a}
function Oi(a){this.g=a}
function Wi(a){this.g=a}
function Xi(a){this.g=a}
function Xk(a){this.g=a}
function wk(a){this.g=a}
function Lm(a){this.g=a}
function Mm(a){this.g=a}
function Rm(a){this.g=a}
function Sm(a){this.g=a}
function Tm(a){this.g=a}
function Vm(a){this.g=a}
function Cn(a){this.g=a}
function Dn(a){this.g=a}
function En(a){this.g=a}
function Hn(a){this.g=a}
function In(a){this.g=a}
function Jn(a){this.g=a}
function Ln(a){this.g=a}
function Xo(a){this.g=a}
function Yo(a){this.g=a}
function Zo(a){this.g=a}
function $o(a){this.g=a}
function ap(a){this.g=a}
function bp(a){this.g=a}
function fp(a){this.g=a}
function kp(a){this.g=a}
function np(a){this.g=a}
function tp(a){this.g=a}
function up(a){this.g=a}
function yp(a){this.g=a}
function Ap(a){this.g=a}
function Cp(a){this.g=a}
function Ep(a){this.g=a}
function Fp(a){this.g=a}
function Gp(a){this.g=a}
function Hp(a){this.g=a}
function Ip(a){this.g=a}
function Jp(a){this.g=a}
function Kp(a){this.g=a}
function jq(a){this.g=a}
function lq(a){this.g=a}
function mq(a){this.g=a}
function nq(a){this.g=a}
function oq(a){this.g=a}
function pq(a){this.g=a}
function qq(a){this.g=a}
function rq(a){this.g=a}
function tq(a){this.g=a}
function uq(a){this.g=a}
function vq(a){this.g=a}
function wq(a){this.g=a}
function xq(a){this.g=a}
function yq(a){this.g=a}
function Bq(a){this.g=a}
function Jq(a){this.g=a}
function Kq(a){this.g=a}
function Lq(a){this.g=a}
function Mq(a){this.g=a}
function cr(a){this.g=a}
function dr(a){this.g=a}
function er(a){this.g=a}
function fr(a){this.g=a}
function gr(a){this.g=a}
function hr(a){this.g=a}
function ir(a){this.g=a}
function kr(a){this.g=a}
function vr(a){this.g=a}
function wr(a){this.g=a}
function yr(a){this.g=a}
function zr(a){this.g=a}
function Fr(a){this.g=a}
function Yr(a){this.g=a}
function Zr(a){this.g=a}
function $r(a){this.g=a}
function bs(a){this.g=a}
function cs(a){this.g=a}
function ds(a){this.g=a}
function es(a){this.g=a}
function fs(a){this.g=a}
function gs(a){this.g=a}
function hs(a){this.g=a}
function ms(a){this.g=a}
function os(a){this.g=a}
function ss(a){this.g=a}
function Ui(a){this.j=a}
function jj(a){this.i=a}
function wt(){Li(this.g)}
function Dt(){hc(this.h)}
function yj(){this.g=Hj()}
function Mj(){this.g=Hj()}
function Tk(a,b){a.g=b}
function vb(a,b){a.h=b}
function sl(a,b){a.key=b}
function nl(a,b){ml(a,b)}
function At(a){mi(this,a)}
function ut(a){Qj(this,a)}
function Ct(a){jk(this,a)}
function Jt(a){yn(this.g)}
function It(){Z(this.g.g)}
function ic(a){!!a&&a.Q()}
function D(a){--a.l;I(a)}
function P(a,b){T(a);Q(a,b)}
function Wk(a,b){Lk(a.g,b)}
function H(a,b){Sb(a.m,b.m)}
function ib(a){ac((O(),a))}
function jb(a){bc((O(),a))}
function mb(a){cc((O(),a))}
function Ht(a){Nn(this.g,a)}
function st(){return this.g}
function yt(){return this.h}
function Bt(){return this.l}
function kh(a){return a.l}
function Dq(a){a.j=2;hc(a.h)}
function Wq(a){a.l=2;hc(a.i)}
function nr(a){a.m=2;hc(a.j)}
function $q(a){pb(a.h);W(a.g)}
function gi(){tc.call(this)}
function Ai(){tc.call(this)}
function tt(){return el(this)}
function Nq(a,b){return a.v=b}
function qc(a,b){a.l=b;pc(a,b)}
function gc(a,b,c){Ji(a.l,b,c)}
function Sh(a){uc.call(this,a)}
function Bi(a){uc.call(this,a)}
function yi(a){Rh.call(this,a)}
function xi(){Rh.call(this,'')}
function sj(){this.g=new pj}
function O(){O=uh;N=new J}
function wc(){wc=uh;vc=new t}
function Nc(){Nc=uh;Mc=new Qc}
function Bk(){Bk=uh;Ak=new Vk}
function Dj(){Dj=uh;Cj=Fj()}
function cb(a){jd(a,11)&&a.S()}
function Gt(a){jd(a,11)&&a.S()}
function wo(a){cb(a.B);cb(a.K)}
function rr(a){pb(a.g);eb(a.h)}
function Wh(a){Vh(a);return a.v}
function Hk(a){xk(a);return a.g}
function bj(a,b){return a.g[b]}
function Yc(a,b){return ai(a,b)}
function bl(a,b){return cd(a,b)}
function xt(){return Mi(this.g)}
function Et(){return this.h.s<0}
function tc(){oc(this);this.Z()}
function Dc(){Dc=uh;!!(Uc(),Tc)}
function nh(){lh==null&&(lh=[])}
function ok(a,b,c){b.U(a.g[c])}
function Im(a,b,c){gc(a.h,b,c)}
function nn(a,b,c){gc(a.H,b,c)}
function al(a,b,c){a.splice(b,c)}
function C(a,b,c){A(a,new M(c),b)}
function so(a,b){return s(b.g,a)}
function Y(a){rb(a.m);return $(a)}
function Wb(a){Xb(a);!a.j&&$b(a)}
function fb(a){O();bc(a);a.l=-2}
function Vj(a){return Wj(a,a.i.h)}
function Mi(a){return a.g.h+a.h.h}
function Hj(){Dj();return new Cj}
function Kk(a,b){a.sb(b);return a}
function Cl(a,b){a.id=b;return a}
function Fh(a,b){a.min=b;return a}
function Eh(a,b){a.max=b;return a}
function Ph(a,b){a.sdp=b;return a}
function Ml(a,b){a.src=b;return a}
function Dl(a,b){a.key=b;return a}
function El(a,b){a.ref=b;return a}
function on(a){kb(a.o);return a.D}
function pn(a){kb(a.i);return a.A}
function zo(a){kb(a.i);return a.H}
function Ao(a){kb(a.j);return a.I}
function Qo(a){kb(a.l);return a.s}
function Uo(a){kb(a.o);return a.v}
function Ro(a){lb(a.m);return a.u}
function Qh(a,b){a.type=b;return a}
function ao(a,b){null!=b&&Nn(a,b)}
function jk(a,b){while(a.Qb(b));}
function Qk(a,b,c){b.U(a.g.rb(c))}
function Jj(a,b){return a.g.get(b)}
function Rj(a,b){Tj(a,b,a.g,a.g.g)}
function Sj(a,b){Tj(a,b,a.i.h,a.i)}
function Sk(a,b){this.g=a;this.h=b}
function Pk(a,b){this.g=a;this.h=b}
function fi(a,b){this.g=a;this.h=b}
function Yi(a,b){this.g=a;this.h=b}
function Al(a,b){this.g=a;this.h=b}
function Dm(a,b){this.g=a;this.h=b}
function Nm(a,b){this.g=a;this.h=b}
function Fn(a,b){this.g=a;this.h=b}
function Gn(a,b){this.g=a;this.h=b}
function Kn(a,b){this.g=a;this.h=b}
function Mn(a,b){this.g=a;this.h=b}
function _o(a,b){this.g=a;this.h=b}
function cp(a,b){this.g=a;this.h=b}
function dp(a,b){this.g=a;this.h=b}
function ep(a,b){this.g=a;this.h=b}
function gp(a,b){this.g=a;this.h=b}
function hp(a,b){this.g=a;this.h=b}
function ip(a,b){this.g=a;this.h=b}
function jp(a,b){this.g=a;this.h=b}
function lp(a,b){this.g=a;this.h=b}
function mp(a,b){this.g=a;this.h=b}
function rp(a,b){this.g=a;this.h=b}
function sp(a,b){this.g=a;this.h=b}
function Ib(a){this.j=a;this.h=100}
function _l(a,b){fi.call(this,a,b)}
function ym(a,b){fi.call(this,a,b)}
function Rp(a,b){fi.call(this,a,b)}
function Xp(a,b){fi.call(this,a,b)}
function hq(a,b){fi.call(this,a,b)}
function kq(a,b){this.g=a;this.h=b}
function zq(a,b){this.g=a;this.h=b}
function Aq(a,b){this.g=a;this.h=b}
function xr(a,b){this.g=a;this.h=b}
function _r(a,b){this.g=a;this.h=b}
function as(a,b){this.g=a;this.h=b}
function Gl(a,b){a.href=b;return a}
function $k(a,b,c){a.splice(b,0,c)}
function to(a,b){return s(b.g,a.g)}
function ts(a){return vs(new xs,a)}
function is(a){return js(new ls,a)}
function ps(a){return qs(new rs,a)}
function zt(a){return Hi(this.g,a)}
function ti(a){return !a?Is:''+a.g}
function Kc(a){$wnd.clearTimeout(a)}
function Kh(a,b){a.width=b;return a}
function Ih(a,b){a.video=b;return a}
function Dh(a,b){a.ideal=b;return a}
function Vl(a,b){a.value=b;return a}
function vi(a,b){a.g+=''+b;return a}
function Hh(a){a.audio=true;return a}
function Jh(a,b){a.height=b;return a}
function s(a,b){return pd(a)===pd(b)}
function Gi(a){return !a?null:a.Mb()}
function pd(a){return a==null?null:a}
function bk(a){return a!=null?w(a):0}
function Yb(a){return !a.j?a:Yb(a.j)}
function rn(a){tn(a,(kb(a.i),!a.A))}
function rs(){this.g=wl((Qr(),Pr))}
function ls(){this.g=wl((Mr(),Lr))}
function xs(){this.g=wl((Ur(),Tr))}
function Cq(){this.g=wl((Ir(),Hr))}
function nb(a){this.i=new hj;this.h=a}
function Li(a){a.g=new yj;a.h=new Mj}
function Zi(a){a.g=$c(ge,Bs,1,0,5,1)}
function ub(a){O();tb(a);xb(a,2,true)}
function Lk(a,b){Bk();Tk(a,Kk(a.g,b))}
function Do(a,b){mo(a,b,new zq(a,b))}
function Eo(a,b){mo(a,b,new Aq(a,b))}
function F(a,b,c){B(a,new L(b),c,null)}
function G(a,b,c){return B(a,c,2048,b)}
function ml(a,b){for(var c in a){b(c)}}
function Il(a,b){a.onClick=b;return a}
function Ql(a,b){a.onChange=b;return a}
function Kl(a,b){a.onSubmit=b;return a}
function Hl(a,b){a.disabled=b;return a}
function Wl(a,b){a.htmlFor=b;return a}
function Nl(a,b){a.width=''+b;return a}
function Mh(a,b){a.candidate=b;return a}
function Gh(a){a.audio=false;return a}
function il(){il=uh;fl=new t;hl=new t}
function cl(a){if(!a){throw kh(new gi)}}
function tk(){uk.call(this,'|','','')}
function U(){this.g=$c(ge,Bs,1,100,5,1)}
function kb(a){var b;Zb((O(),b=Ub,b),a)}
function Tl(a){return a.required=true,a}
function el(a){return a.$H||(a.$H=++dl)}
function ni(a,b){return a.charCodeAt(b)}
function jd(a,b){return a!=null&&gd(a,b)}
function rj(a,b){return Ki(a.g,b)!=null}
function db(a){return !(jd(a,11)&&a.T())}
function Ol(a){return a.autoFocus=true,a}
function ld(a){return typeof a==='number'}
function od(a){return typeof a==='string'}
function Pl(a,b){a.maxLength=b;return a}
function Ll(a,b){a.height=''+b;return a}
function Lh(a,b){a.iceServers=b;return a}
function rl(a,b,c){a.props[b]=c;return a}
function js(a,b){rl(a.g,'a',b);return a}
function us(a,b){rl(a.g,'b',b);return a}
function ws(a,b){rl(a.g,'c',b);return a.g}
function Sl(a,b){a.placeholder=b;return a}
function Vh(a){if(a.v!=null){return}ci(a)}
function Ri(a){a.i.Eb();a.i=null;a.h=Pi(a)}
function Ti(a){a.j.Ib(a.i);a.h=a.i;a.i=-1}
function Lb(a){2==(3&a.g)||(a.g=-4&a.g|2)}
function Z(a){4==(a.m.i&7)&&xb(a.m,5,true)}
function Pm(a){F((O(),O(),N),new Vm(a),Ws)}
function yn(a){F((O(),O(),N),new In(a),Ws)}
function zn(a){F((O(),O(),N),new Hn(a),Ws)}
function An(a){F((O(),O(),N),new Jn(a),Ws)}
function No(a){F((O(),O(),N),new bp(a),Ws)}
function Fo(a){F((O(),O(),N),new fp(a),ct)}
function Po(a){F((O(),O(),N),new kp(a),ct)}
function Vo(a){F((O(),O(),N),new ap(a),Ws)}
function ar(a){F((O(),O(),N),new ir(a),Ws)}
function lc(a){O();Ub?a.Q():F((null,N),a,0)}
function uc(a){this.o=a;oc(this);this.Z()}
function pj(){this.g=new yj;this.h=new Mj}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function _k(a,b,c){Zk(c,0,a,b,c.length)}
function qi(a,b,c){return a.substr(b,c-b)}
function ro(a,b){return pd(b.track)===pd(a)}
function nd(a,b){return a&&b&&a instanceof b}
function kd(a){return typeof a==='boolean'}
function Ec(a,b,c){return a.apply(b,c);var d}
function Rb(a,b,c){c.g=-4&c.g|1;P(a.g[b],c)}
function Aj(a,b){var c;c=a[Ps];c.call(a,b)}
function ol(a,b){var c;c={};c[a]=b;return c}
function Nh(a,b){a.sdpMLineIndex=b;return a}
function Rl(a){a.pattern='^\\w+$';return a}
function oc(a){a.u&&a.l!==Gs&&a.Z();return a}
function Zh(a){var b;b=Yh(a);ei(a,b);return b}
function li(){li=uh;ki=$c(de,Bs,37,256,0,1)}
function ij(a){Zi(this);_k(this.g,0,a.zb())}
function Qj(a,b){while(a.Cb()){Wk(b,a.Db())}}
function mk(a,b){while(a.i<a.j){ok(a,b,a.i++)}}
function Hb(a){while(true){if(!Gb(a)){break}}}
function co(a){if(!a.F&&a.G){a.G=false;bo(a)}}
function Vq(a,b){b.preventDefault();Po(a.u)}
function $i(a,b){a.g[a.g.length]=b;return true}
function Pj(a,b,c){this.g=a;this.h=b;this.i=c}
function $j(a,b,c){this.j=a;this.h=c;this.g=b}
function Jk(a,b){Bk();zk.call(this,a);this.g=b}
function Sb(a,b){Rb(a,((b.g&229376)>>15)-1,b)}
function Jm(a,b){F((O(),O(),N),new Nm(a,b),Ws)}
function tn(a,b){F((O(),O(),N),new Gn(a,b),Ws)}
function Lo(a,b){F((O(),O(),N),new ep(a,b),Ws)}
function yo(a,b){F((O(),O(),N),new lp(a,b),ct)}
function Go(a,b){F((O(),O(),N),new ip(a,b),ct)}
function Ho(a,b){F((O(),O(),N),new cp(a,b),ct)}
function Io(a,b){F((O(),O(),N),new gp(a,b),ct)}
function Jo(a,b){F((O(),O(),N),new jp(a,b),ct)}
function Ko(a,b){F((O(),O(),N),new hp(a,b),ct)}
function Mo(a,b){F((O(),O(),N),new dp(a,b),ct)}
function Oo(a,b){F((O(),O(),N),new mp(a,b),ct)}
function sb(a,b){hb(b,a);b.i.g.length>0||(b.g=4)}
function Oq(a,b,c){c.preventDefault();yo(a.u,b)}
function Pq(a,b,c){c.preventDefault();Oo(a.u,b)}
function Pn(a,b,c){a.D.addTrack(c,b);return null}
function Ck(a,b){var c;return Gk(a,(c=new hj,c))}
function Uc(){Uc=uh;var a;!Wc();a=new Xc;Tc=a}
function Wm(a){wn(a,null);vn(a,null);un(a,null)}
function lj(a){return new Jk(null,kj(a,a.length))}
function ad(a){return Array.isArray(a)&&a.$b===yh}
function hd(a){return !Array.isArray(a)&&a.$b===yh}
function Hi(a,b){return od(b)?Ii(a,b):!!vj(a.g,b)}
function kj(a,b){return kk(b,a.length),new pk(a,b)}
function Ij(a,b){return !(a.g.get(b)===undefined)}
function mr(a,b){lc(new xr(a,b.length==0?null:b))}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function _h(a){var b;b=Yh(a);b.u=a;b.l=1;return b}
function Fq(a){if(0==a.j){a.j=1;a.i.forceUpdate()}}
function Yq(a){if(0==a.l){a.l=1;a.j.forceUpdate()}}
function pr(a){if(0==a.m){a.m=1;a.l.forceUpdate()}}
function qk(a){if(!a.j){a.j=a.h.qb();a.i=a.h.wb()}}
function Jb(a){if(!a.g){a.g=true;D((O(),O(),N))}}
function Nk(a,b,c){if(a.g.Sb(c)){a.h=true;b.U(c)}}
function gj(a,b,c){var d;d=a.g[b];a.g[b]=c;return d}
function qj(a,b){var c;c=Ji(a.g,b,a);return c==null}
function Zj(a){a.i=a.h;a.h=a.h.g;++a.g;return a.i.i}
function dj(a,b){var c;c=a.g[b];al(a.g,b,1);return c}
function Ah(a){var b;b=$wnd.console;b.log.apply(b,a)}
function Bh(a){$wnd.addEventListener(Ks,a,false)}
function Ch(a){$wnd.removeEventListener(Ks,a,false)}
function Yj(){this.g=new _j;this.i=new _j;Xj(this)}
function ll(){if(gl==256){fl=hl;hl=new t;gl=0}++gl}
function xk(a){if(!a.h){yk(a);a.i=true}else{xk(a.h)}}
function Hq(a){return G((O(),O(),N),a.g,new Lq(a))}
function _q(a){return G((O(),O(),N),a.h,new hr(a))}
function tr(a){return G((O(),O(),N),a.g,new yr(a))}
function S(a){return a.i?a.g.length-a.h+a.j:a.j-a.h}
function sn(a,b){var c;c=a.v;if(b!=c){a.v=b;jb(a.h)}}
function sr(a,b){var c;c=a.i;if(b!=c){a.i=b;jb(a.h)}}
function mn(a,b){var c;c=a.A;if(b!=c){a.A=b;jb(a.i)}}
function un(a,b){var c;c=a.B;if(b!=c){a.B=b;jb(a.j)}}
function vn(a,b){var c;c=a.C;if(b!=c){a.C=b;jb(a.l)}}
function xn(a,b){var c;c=a.G;if(b!=c){a.G=b;jb(a.u)}}
function xo(a,b){var c;c=a.s;if(b!=c){a.s=b;jb(a.l)}}
function Yk(a,b){var c;c=a.slice(0,b);return cd(c,a)}
function pl(a,b,c){var d;d={};d[Js]=a;d[b]=c;return d}
function Jl(a,b){a.type=b.g!=null?b.g:''+b.h;return a}
function ui(a,b){a.g+=String.fromCharCode(b);return a}
function Co(a,b){pd(a.L)===pd(b.currentTarget)&&Z(a.g)}
function oj(a,b){return pd(a)===pd(b)||a!=null&&u(a,b)}
function Ki(a,b){return b==null?xj(a.g,null):Lj(a.h,b)}
function Ii(a,b){return b==null?!!vj(a.g,null):Ij(a.h,b)}
function Dk(a,b){yk(a);return new Jk(a,new Ok(b,a.g))}
function Ek(a,b){yk(a);return new Jk(a,new Rk(b,a.g))}
function Sq(a){$wnd.document.addEventListener(et,a.s)}
function Tq(a){$wnd.document.removeEventListener(et,a.s)}
function lb(a){var b;O();!!Ub&&!!Ub.l&&Zb((b=Ub,b),a)}
function $h(a,b){var c;c=Yh(a);ei(a,c);c.l=b?8:0;return c}
function pk(a,b){this.i=0;this.j=b;this.h=17488;this.g=a}
function Vi(a,b){this.g=a;Ui.call(this,a);a.wb();this.h=b}
function dc(a,b){this.g=(O(),O(),N).h++;this.j=a;this.l=b}
function lk(a,b){this.l=a;this.j=(b&64)!=0?b|16384:b}
function rk(a,b){this.h=a;this.g=(b&4096)==0?b|64|16384:b}
function zk(a){if(!a){this.h=null;new hj}else{this.h=a}}
function Xj(a){a.g.g=a.i;a.i.h=a.g;a.g.h=a.i.g=null;a.h=0}
function Qi(a){var b;a.i=a.g;b=a.g.Db();a.h=Pi(a);return b}
function ec(a,b){Ub=new dc(Ub,b);a.j=false;Vb(Ub);return Ub}
function Ni(a,b){if(jd(b,44)){return Ei(a.g,b)}return false}
function bi(a){if(a.ob()){return null}var b=a.u;return qh[b]}
function Vb(a){if(a.l){2==(a.l.i&7)||xb(a.l,4,true);tb(a.l)}}
function qb(a){H((O(),O(),N),a);0==(a.m.g&Fs)&&I((null,N))}
function $m(a){!(!!a&&a.H.s<0)&&F((O(),O(),N),new Ln(a),Ws)}
function oo(a,b){null!=a.L&&a.L.send($wnd.JSON.stringify(b))}
function Fi(a,b){return b===a?'(this Map)':b==null?Is:xh(b)}
function rc(a,b){var c;c=Wh(a.Yb);return b==null?c:c+': '+b}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function yk(a){if(a.h){yk(a.h)}else if(a.i){throw kh(new hi)}}
function wh(a){function b(){}
;b.prototype=a||{};return new b}
function Oh(a){a.urls='stun:stun.l.google.com:19302';return a}
function Yp(){Wp();return bd(Yc(ig,1),Bs,41,0,[Vp,Up,Tp])}
function am(){$l();return bd(Yc(gf,1),Bs,40,0,[Xl,Yl,Zl])}
function Ir(){Ir=uh;var a;Hr=(a=vh(Gr.prototype.Xb,Gr,[]),a)}
function Mr(){Mr=uh;var a;Lr=(a=vh(Kr.prototype.Xb,Kr,[]),a)}
function Qr(){Qr=uh;var a;Pr=(a=vh(Or.prototype.Xb,Or,[]),a)}
function Ur(){Ur=uh;var a;Tr=(a=vh(Sr.prototype.Xb,Sr,[]),a)}
function Ar(a,b){var c;c=a.i;!(!!c&&c.H.s<0)&&lc(new Fn(c,b))}
function uj(a,b){var c;c=a.g.get(b);return c==null?new Array:c}
function ai(a,b){var c=a.g=a.g||[];return c[b]||(c[b]=a.jb(b))}
function mi(a,b){var c,d;for(d=a.qb();d.Cb();){c=d.Db();b.U(c)}}
function Qq(a,b){var c;lc(new _o(a.u,ri((c=b.target,c).value)))}
function vj(a,b){var c;return tj(b,uj(a,b==null?0:(c=w(b),c|0)))}
function sh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Ft(a,b,c){return Th(),(a.enabled=!a.enabled)?true:false}
function Sp(){Qp();return bd(Yc(hg,1),Bs,25,0,[Np,Pp,Mp,Lp,Op])}
function J(){this.m=new Tb;this.g=new Ib(this.m);new K(this.g)}
function zj(a){this.l=a;this.h=this.l.g.entries();this.g=new Array}
function Rk(a,b){lk.call(this,b.Pb(),b.Ob()&-6);this.g=a;this.h=b}
function So(a,b){var c;c=a.u;if(!(b==c||!!b&&b==c)){a.u=b;jb(a.m)}}
function To(a,b){var c;c=a.v;if(!(b==c||!!b&&b==c)){a.v=b;jb(a.o)}}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function Vn(a,b){var c;return c=(kb(b.o),b.D),null!=c&&s(c.id,a.id)}
function Fk(a,b){return !(yk(a),Hk(new Jk(a,new Ok(b,a.g)))).Qb(Ak)}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function On(a){var b;b=new hj;pn(a.K)&&$i(b,a.K);_i(b,a.J);return b}
function kc(a){ic(a.o);!!a.l&&jc(a);cb(a.g);cb(a.i);ic(a.h);ic(a.m)}
function vo(a){W(a.g);W(a.h);eb(a.o);eb(a.m);eb(a.l);eb(a.j);eb(a.i)}
function nk(a,b){if(a.i<a.j){ok(a,b,a.i++);return true}return false}
function Sn(a){oo(a,pl('offer',Ys,a.D.localDescription));return null}
function Zm(a,b){b.onended=vh(up.prototype.eb,up,[a]);return null}
function Ym(a,b,c){a.K==b&&F((O(),O(),N),new Mn(a,c),Ws);return null}
function eb(a){if(-2!=a.l){F((O(),O(),N),new ob(a),0);!!a.h&&pb(a.h)}}
function sc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function ql(a,b,c,d,e,f){var g;g={};g[a]=b;g[c]=d;g[e]=f;return g}
function Tj(a,b,c,d){var e;e=new _j;e.i=b;e.h=c;e.g=d;d.h=c.g=e;++a.h}
function gb(a,b){var c,d;$i(a.i,b);d=(c=b.i&7,c>3?c:4);a.g>d&&(a.g=d)}
function Ok(a,b){lk.call(this,b.Pb(),b.Ob()&-16449);this.g=a;this.i=b}
function Nj(a){this.j=a;this.h=this.j.g.entries();this.g=this.h.next()}
function uk(a,b,c){this.h=a;this.j=b;this.l=c;this.i=this.j+(''+this.l)}
function Jr(a){$wnd.React.Component.call(this,a);this.g=new Iq(this)}
function Nr(a){$wnd.React.Component.call(this,a);this.g=new br(this)}
function Rr(a){$wnd.React.Component.call(this,a);this.g=new ur(this)}
function Vr(a){$wnd.React.Component.call(this,a);this.g=new Er(this)}
function sk(a,b){!a.g?(a.g=new yi(a.j)):vi(a.g,a.h);vi(a.g,b);return a}
function Gk(a,b){var c;xk(a);c=new Uk;c.g=b;a.g.Bb(new Xk(c));return c.g}
function Ik(a,b){var c;c=Ck(a,new wk(new vk));return c.Ab(b.Rb(c.wb()))}
function Wn(a,b){var c;return c=(kb(b.o),b.D),!(null!=c&&!s(c.id,a.id))}
function Rn(a,b){return a.D.setLocalDescription(Qh(Ph({},b.sdp),b.type))}
function Xn(a,b){return a.D.setLocalDescription(Ph(Qh({},b.type),b.sdp))}
function iq(){gq();return bd(Yc(jg,1),Bs,17,0,[fq,$p,dq,cq,bq,Zp,eq,aq,_p])}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function yl(a,b,c){!s(c,'key')&&!s(c,'ref')&&(a[c]=b[c],undefined)}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&bd(Yc(a,f),b,c,e,g);return g}
function cd(a,b){Zc(b)!=10&&bd(v(b),b.Zb,b.__elementTypeId$,Zc(b),a);return a}
function Qb(a){var b,c;b=0;for(c=0;c<a.g.length;c++){b+=S(a.g[c])}return b}
function cj(a,b,c){for(;c<a.g.length;++c){if(oj(b,a.g[c])){return c}}return -1}
function Q(a,b){a.g[a.j]=b;++a.j;if(a.j>=a.g.length){a.j=0;a.i=true}}
function aj(a,b){var c,d,e,f;for(d=a.g,e=0,f=d.length;e<f;++e){c=d[e];b.U(c)}}
function Tb(){var a;this.g=$c(wd,Bs,58,5,0,1);for(a=0;a<5;a++){this.g[a]=new U}}
function Si(a){this.l=a;this.j=new Nj(this.l.h);this.g=this.j;this.h=Pi(this)}
function Nb(b){try{rb(b.h.g)}catch(a){a=jh(a);if(!jd(a,8))throw kh(a)}}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function mo(a,b,c){if(null!=a.L&&ej(a.I,b)){fj(a.I,new Bq(b));jb(a.j);c.Q()}}
function Ji(a,b,c){return od(b)?b==null?wj(a.g,null,c):Kj(a.h,b,c):wj(a.g,b,c)}
function qs(a,b){sl(a.g,ji(b.h.j)+(''+(Vh(fh),fh.v)));rl(a.g,'a',b);return a.g}
function ej(a,b){var c;c=cj(a,b,0);if(c==-1){return false}al(a.g,c,1);return true}
function Oj(a){if(a.g.i!=a.i){return Jj(a.g,a.h.value[0])}return a.h.value[1]}
function $(a){if(a.h){if(jd(a.h,10)){throw kh(a.h)}else{throw kh(a.h)}}return a.v}
function hn(a){if(s('live',a.readyState)){a.onended=null;a.stop()}return null}
function Tn(a,b){Ah(bd(Yc(ge,1),Bs,1,5,['Offer error: ',b]));a.F=false;return null}
function $l(){$l=uh;Xl=new _l(Us,0);Yl=new _l('reset',1);Zl=new _l('submit',2)}
function md(a){return a!=null&&(typeof a===zs||typeof a==='function')&&!(a.$b===yh)}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function W(a){if(!a.g){a.g=true;a.v=null;a.h=null;eb(a.l);2==(a.m.i&7)||pb(a.m)}}
function I(a){if(a.j&&a.l==0){if(!a.i){a.i=true;try{Hb(a.g)}finally{a.i=false}}}}
function no(a){if(null!=a.L){oo(a,pl(at,'message',(kb(a.l),a.s)));To(a,(gq(),dq))}}
function go(a,b){if(pd(a.L)===pd(b.currentTarget)){Z(a.g);To(a,(gq(),_p));a.L=null}}
function hc(a){if(a.s>=0){a.s=-2;B((O(),O(),N),new L(new nc(a)),67108864,null)}}
function wb(b){if(b){try{b.Q()}catch(a){a=jh(a);if(jd(a,8)){O()}else throw kh(a)}}}
function fc(){var a;try{Wb(Ub);O()}finally{a=Ub.j;!a&&((O(),O(),N).j=true);Ub=Ub.j}}
function Oc(a){var b,c;if(a.g){c=null;do{b=a.g;a.g=null;c=Sc(b,c)}while(a.g);a.g=c}}
function Pc(a){var b,c;if(a.h){c=null;do{b=a.h;a.h=null;c=Sc(b,c)}while(a.h);a.h=c}}
function Zb(a,b){var c;if(a.l){c=a.g;if(b.l!=c){b.l=c;!a.h&&(a.h=new hj);$i(a.h,b)}}}
function _b(a,b){var c;if(!a.i){c=Yb(a);!c.i&&(c.i=new hj);a.i=c.i}b.j=true;a.i.sb(b)}
function ei(a,b){var c;if(!a){return}b.u=a;var d=bi(b);if(!d){qh[a]=[b];return}d.Yb=b}
function Wj(a,b){var c;c=b.i;b.g.h=b.h;b.h.g=b.g;b.g=b.h=null;b.i=null;--a.h;return c}
function ln(a,b){var c;c=a.F;if(!(pd(b)===pd(c)||b!=null&&u(b,c))){a.F=b;jb(a.s)}}
function wn(a,b){var c;c=a.D;if(!(pd(b)===pd(c)||b!=null&&u(b,c))){a.D=b;jb(a.o)}}
function jo(a,b){var c;c=b.track;a.J=Ck(Dk(a.J.yb(),new uq(c)),new wk(new vk));Z(a.h)}
function kn(a){pb(a.m);W(a.g);eb(a.h);eb(a.o);eb(a.l);eb(a.j);eb(a.i);eb(a.u);eb(a.s)}
function $n(a,b){var c;c=b.g;oo(a,pl('approve_access','id',c));qj(a.H,c);jb(a.i);po(a)}
function vs(a,b){sl(a.g,(b?ji(b.H.j):null)+(''+(Vh(hh),hh.v)));rl(a.g,'a',b);return a}
function vh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ul(a,b,c,d){var e;e=vl($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function wl(a){var b;b=vl($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Yh(a){var b;b=new Xh;b.v='Class$'+(a?'S'+a:''+b.o);b.h=b.v;b.s=b.v;return b}
function Yn(a){oo(a,pl('answer',Ys,a.D.localDescription));a.F=false;co(a);return null}
function Zn(a,b){Ah(bd(Yc(ge,1),Bs,1,5,['Answer error: ',b]));a.F=false;co(a);return null}
function Fl(a){a.title='Room code should only contain letters or numbers.';return a}
function hi(){uc.call(this,"Stream already terminated, can't be modified or used")}
function mh(){nh();var a=lh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function tb(a){var b,c;for(c=new jj(a.h);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);b.g=4}}
function Di(a,b){var c,d;for(d=b.qb();d.Cb();){c=d.Db();if(!a.ub(c)){return false}}return true}
function mj(a){var b,c,d;d=0;for(c=a.qb();c.Cb();){b=c.Db();d=d+(b!=null?w(b):0);d=d|0}return d}
function Lj(a,b){var c;c=a.g.get(b);if(c===undefined){++a.i}else{Aj(a.g,b);--a.h}return c}
function nj(a){var b,c,d;d=1;for(c=a.qb();c.Cb();){b=c.Db();d=31*d+(b!=null?w(b):0);d=d|0}return d}
function jh(a){var b;if(jd(a,8)){return a}b=a&&a.__java$exception;if(!b){b=new yc(a);Vc(b)}return b}
function Pi(a){if(a.g.Cb()){return true}if(a.g!=a.j){return false}a.g=new zj(a.l.g);return a.g.Cb()}
function _i(a,b){var c,d;c=b.zb();d=c.length;if(d==0){return false}_k(a.g,a.g.length,c);return true}
function Rq(a){var b;b=$wnd.document;b.fullscreen?b.exitFullscreen():a.v.requestFullscreen()}
function zh(){var a;a=$wnd.document.getElementById('app');$wnd.ReactDOM.render((new Cq).g,a,null)}
function Wp(){Wp=uh;Vp=new Xp('UNKNOWN',0);Up=new Xp('HOST',1);Tp=new Xp('GUEST',2)}
function ph(a,b){typeof window===zs&&typeof window['$gwt']===zs&&(window['$gwt'][a]=b)}
function Ob(a,b){this.h=a;this.g=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function Ab(a,b,c){zb.call(this,null,a,b,c|(!a?262144:Ds)|(0==(c&6291456)?!a?Fs:4194304:0)|0|0|0)}
function cn(a,b){sn(a,false);wn(a,b);b.getTracks().forEach(vh(tp.prototype._,tp,[a]));a.J.U(b)}
function Nn(a,b){if(null!=a.D){b.getTracks().forEach(vh(kq.prototype._,kq,[a,b]));a.G=true;co(a)}}
function fn(a){var b;b=(kb(a.o),a.D);null!=b&&b.getAudioTracks().forEach(vh(pp.prototype._,pp,[]));Z(a.g)}
function Fm(a,b){Ci(a.i,b,true);3==a.i.h&&Vj(a.i);Rj(a.i,b);jb(a.g);$wnd.localStorage.setItem(Vs,si(a.i))}
function yc(a){wc();oc(this);this.l=a;pc(this,a);this.o=a==null?Is:xh(a);this.g='';this.h=a;this.g=''}
function mc(a,b,c,d){this.j=a;this.l=d?new pj:null;this.o=b;this.h=c;this.m=null;this.g=null;this.i=null}
function Xh(){this.o=Uh++;this.v=null;this.s=null;this.m=null;this.j=null;this.h=null;this.u=null;this.g=null}
function Kj(a,b,c){var d;d=a.g.get(b);a.g.set(b,c===undefined?null:c);d===undefined?++a.h:++a.i;return d}
function bd(a,b,c,d,e){e.Yb=a;e.Zb=b;e.$b=yh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function tj(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(oj(a,c.Lb())){return c}}return null}
function ji(a){var b,c;if(a>-129&&a<128){b=a+128;c=(li(),ki)[b];!c&&(c=ki[b]=new ii(a));return c}return new ii(a)}
function kk(a,b){if(0>a||a>b){throw kh(new Sh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Bm(){if(!Am){Am=(++(O(),O(),N).l,new Kb);$wnd.Promise.resolve(null).then(vh(Cm.prototype.bb,Cm,[]))}}
function Xm(a,b,c){a.K==b?F((O(),O(),N),new Kn(a,c),Ws):c.getTracks().forEach(vh(wp.prototype._,wp,[]));return null}
function pb(a){if(2<(a.i&7)){B((O(),O(),N),new L(new Eb(a)),67108864,null);!!a.g&&W(a.g);Lb(a.m);a.i=a.i&-8|1}}
function Mb(a){if(1==(3&a.g)){a.g=-4&a.g|0;0==(a.g&Ds)?Nb(a):rb(a.h.g);0!=(a.g&524288)&&(2==(3&a.g)||(a.g=-4&a.g|2))}}
function hb(a,b){var c,d;d=a.i;ej(d,b);!!a.h&&Ds!=(a.h.i&Es)&&a.i.g.length<=0&&0==a.h.g.j&&(a.j||_b((O(),c=Ub,c),a))}
function Eq(a){var b,c,d;a.j=0;Bm();c=(d=(b=X(a.l.j.g),b.length==0?null:b),null==d?ps(a.l):ks(is(a.l),d));return c}
function tl(a){var b;b=vl($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=ol(Ts,a);return b}
function $b(a){var b;if(a.i){while(!a.i.vb()){b=a.i.Ib(a.i.wb()-1);b.j=false;b.i.g.length>0||(b.h.i&7)>3&&xb(b.h,3,true)}}}
function gn(a){var b;xn(a,(kb(a.u),!a.G));b=(kb(a.o),a.D);null!=b&&b.getVideoTracks().forEach(vh(qp.prototype._,qp,[]))}
function qn(a){var b;return Th(),b=(kb(a.o),a.D),null!=b&&b.getAudioTracks().some(vh(op.prototype._,op,[]))?true:false}
function Bo(a){return null==a.L?(Qp(),Op):(Qp(),bd(Yc(hg,1),Bs,25,0,[Np,Pp,Mp,Lp,Op]))[a.L.readyState]}
function Br(a){return ul('video',null,a.j,ql('autoPlay',true,'className',a.h.props['b'],'muted',a.h.props['c']))}
function v(a){return od(a)?je:ld(a)?Zd:kd(a)?Xd:hd(a)?a.Yb:ad(a)?a.Yb:a.Yb||Array.isArray(a)&&Yc(Pd,1)||Pd}
function w(a){return od(a)?kl(a):ld(a)?qd(a):kd(a)?a?1231:1237:hd(a)?a.O():ad(a)?el(a):!!a&&!!a.hashCode?a.hashCode():el(a)}
function eo(a,b){var c;if(pd(a.L)===pd(b.currentTarget)){a.L=null;c=(kb(a.o),a.v);(gq(),eq)!=c&&Zp!=c&&_p!=c&&To(a,Zp);Z(a.g)}}
function _m(a){var b,c,d;c=(kb(a.o),a.D);d=(kb(a.s),a.F);if(null!=c&&null!=d){b=c;pd(b)!==pd(d.srcObject)&&(d.srcObject=b)}}
function kl(a){il();var b,c,d;c=':'+a;d=hl[c];if(d!=null){return qd(d)}d=fl[c];b=d==null?jl(a):qd(d);ll();hl[c]=b;return b}
function Cr(a,b){var c;c=a.h.props;if(!(c['b']===b['b'])){return true}if(!(c['c']===b['c'])){return true}return false}
function Ci(a,b,c){var d,e;for(e=a.qb();e.Cb();){d=e.Db();if(pd(b)===pd(d)||b!=null&&u(b,d)){c&&e.Eb();return true}}return false}
function Pb(a){var b,c,d;for(b=0;b<a.g.length;b++){d=a.g[b];if(0!=(d.i?d.g.length-d.h+d.j:d.j-d.h)){c=R(d);return c}}return null}
function Uj(a,b){var c,d;if(b>=a.h>>1){d=a.i;for(c=a.h;c>b;--c){d=d.h}}else{d=a.g.g;for(c=0;c<b;++c){d=d.g}}return new $j(a,b,d)}
function xh(a){var b;if(Array.isArray(a)&&a.$b===yh){return Wh(v(a))+'@'+(b=w(a)>>>0,b.toString(16))}return a.toString()}
function Km(){var a,b;Gm.call(this);O();a=++Hm;this.h=new mc(a,new Lm(this),new Mm(this),true);this.g=(b=new nb(null),b)}
function ik(){fk();var a,b,c;c=ek+++Date.now();a=qd($wnd.Math.floor(c*Rs))&16777215;b=qd(c-a*Ss);this.g=a^1502;this.h=b^Qs}
function zm(){xm();return bd(Yc(hf,1),Bs,9,0,[bm,cm,dm,em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm,qm,rm,sm,tm,um,vm,wm])}
function ks(a,b){var c;rl(a.g,'b',b);return c=a.g.props,sl(a.g,ti(c['a']?ji(c['a'].h.j):null)+'-'+c['b']+(Vh(bh),bh.v)),a.g}
function ko(a,b){var c;if(pd(a.D)===pd(b.currentTarget)){c=b.streams;a.J=new ij(a.J);c.forEach(vh(qq.prototype._,qq,[a]));Z(a.h)}}
function dn(a){var b;b=(kb(a.o),a.D);Wm(a);F((O(),O(),N),new Gn(a,false),Ws);null!=b&&b.getTracks().forEach(vh(vp.prototype._,vp,[]))}
function an(a){var b;++a.K;b=a.K;Wm(a);sn(a,true);a.I.Tb().then(vh(rp.prototype.bb,rp,[a,b])).catch(vh(sp.prototype.bb,sp,[a,b]))}
function Qn(a,b){var c;c=a.D.getSenders().find(vh(mq.prototype.ab,mq,[b]));if(null!=c){a.D.removeTrack(c);a.G=true;co(a)}return null}
function Bb(a,b){zb.call(this,a,new Cb(a),null,b|(Ds==(b&Es)?0:524288)|(0==(b&6291456)?Ds==(b&Es)?4194304:Fs:0)|0|268435456|0)}
function di(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function gk(a,b){var c,d;cl(b>0);if((b&-b)==b){return qd(b*hk(a)*4.6566128730773926E-10)}do{c=hk(a);d=c%b}while(c-d+(b-1)<0);return qd(d)}
function en(a,b){var c;sn(a,false);if(nd(b,$wnd.DOMException)){c=b;vn(a,c.name);un(a,c.message)}else{vn(a,Wh(v(b)));un(a,b==null?Is:xh(b))}}
function Qp(){Qp=uh;Np=new Rp('CONNECTING',0);Pp=new Rp('OPEN',1);Mp=new Rp('CLOSING',2);Lp=new Rp('CLOSED',3);Op=new Rp('NOT_REQUESTED',4)}
function Iq(a){var b;this.l=new Km;this.i=a;O();b=++Gq;this.h=new mc(b,new Jq(this),new Kq(this),false);this.g=new Ab(null,new Mq(this),dt)}
function Qm(){var a;this.i=new np(this);O();a=++Om;this.h=new mc(a,null,new Rm(this),true);this.g=new ab(new Um,new Sm(this),new Tm(this),Xs)}
function jc(a){var b,c,d;for(c=new jj(new ij(new Oi(a.l)));c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.Lb();jd(d,11)&&d.T()||b.Mb().Q()}}
function bc(a){var b,c,d;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new jj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;6!=d&&xb(b,6,true)}}}
function cc(a){var b,c,d;if(a.i.g.length>0&&4==a.g){a.g=5;for(c=new jj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;4==d&&xb(b,5,true)}}}
function ho(a,b){var c;if(pd(a.D)===pd(b.currentTarget)){c=b.candidate;null!=c&&null!=a.L&&oo(a,ql(Js,$s,_s,c.sdpMLineIndex,$s,c.candidate))}}
function u(a,b){return od(a)?s(a,b):ld(a)?pd(a)===pd(b):kd(a)?pd(a)===pd(b):hd(a)?a.M(b):ad(a)?s(a,b):!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function Em(){var a,b,c;b=new ik;c=new xi;for(a=0;a<10;a++){ui(c,ni('abcdefghijklmnopqrstuvwxyz1234567890',$wnd.Math.abs(gk(b,36))))}return c.g}
function lr(a,b){var c,d,e;b.preventDefault();c=(lb(a.h),a.i);null!=c&&(d=$wnd.location,e=c.length==0?c:'#'+c,s(d.hash,e)||(d.hash=e),undefined)}
function gd(a,b){if(od(a)){return !!fd[b]}else if(a.Zb){return !!a.Zb[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function bn(a,b){var c;mn(a,b);c=(kb(a.o),a.D);if(b){null==c&&an(a)}else{if(null!=c){c.getTracks().forEach(vh(wp.prototype._,wp,[]));wn(a,null)}}}
function Un(a,b){var c,d;if(Fk(a.J.yb(),new rq(b))){c=new sq;d=new Bn(new tq(b),c,true);an(d);a.J.sb(d);b.onremovetrack=vh(Ap.prototype.gb,Ap,[a])}return null}
function Bl(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function R(a){var b;if(0==(a.i?a.g.length-a.h+a.j:a.j-a.h)){return null}b=a.g[a.h];a.g[a.h]=null;++a.h;if(a.h>=a.g.length){a.h=0;a.i=false}return b}
function X(a){a.u?lb(a.l):kb(a.l);if(yb(a.m)){if(a.u&&(O(),!(!!Ub&&!!Ub.l))){return B((O(),O(),N),new bb(a),83888128,null)}else{rb(a.m)}}return $(a)}
function ri(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function A(b,c,d){var e,f;try{ec(b,d);try{f=(c.g.Q(),null)}finally{fc()}return f}catch(a){a=jh(a);if(jd(a,8)){e=a;throw kh(e)}else throw kh(a)}finally{I(b)}}
function ab(a,b,c,d){this.i=a;this.o=b;this.s=c;this.v=null;this.u=16384==(d&16384);this.m=new Bb(this,d&-16385);this.l=new nb(this.m);Ds==(d&Es)&&qb(this.m)}
function Gm(){var a,b,c,d,e;this.i=new Yj;this.j=new Qm;e=$wnd.localStorage.getItem(Vs);if(null!=e){for(b=pi(e),c=0,d=b.length;c<d;++c){a=b[c];Sj(this.i,a)}}}
function ac(a){var b,c;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new jj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);5==(b.i&7)?xb(b,6,true):4==(b.i&7)&&(a.g=4)}}}
function si(a){var b,c,d;d=new tk;for(c=Uj(a,0);c.h!=c.j.i;){b=Zj(c);!d.g?(d.g=new yi(d.j)):vi(d.g,d.h);vi(d.g,b)}return !d.g?d.i:d.l.length==0?d.g.g:d.g.g+(''+d.l)}
function qo(a){var b;b=on(a.K);null!=a.D&&null!=b&&pn(a.K)&&null!=a.D&&b.getTracks().forEach(vh(lq.prototype._,lq,[a]));zn(a.K);null!=a.D&&pn(a.K)&&null!=b&&Nn(a,b)}
function Gb(a){var b,c;if(0==a.i){b=Qb(a.j);if(0==b){a.g=0;return false}else if(a.g+1>a.h){a.g=0;return false}else{a.g=a.g+1;a.i=b}}--a.i;c=Pb(a.j);Mb(c);return true}
function oh(b,c,d,e){nh();var f=lh;$moduleName=c;$moduleBase=d;ih=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ys(g)()}catch(a){b(c,a)}}else{ys(g)()}}
function vl(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Er(a){var b;this.j=vh(ss.prototype.U,ss,[this]);this.h=a;this.i=a.props['a'];O();b=++Dr;this.g=new mc(b,null,null,false);nn(this.i,this,new Fr(this));I((null,N))}
function fk(){fk=uh;var a,b,c,d;ck=$c(rd,Bs,236,25,15,1);dk=$c(rd,Bs,236,33,15,1);d=1.52587890625E-5;for(b=32;b>=0;b--){dk[b]=d;d*=0.5}c=1;for(a=24;a>=0;a--){ck[a]=c;c*=0.5}}
function Fj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Gj()}}
function fo(a,b){var c;if(pd(a.D)===pd(b.currentTarget)){c=a.D.iceConnectionState;if(s('disconnected',c)||s('failed',c)||s('closed',c)){a.J.pb(new zp);a.J=new hj;Z(a.h)}else{bo(a)}}}
function fj(a,b){var c,d,e,f;e=null;f=0;for(d=0;d<a.g.length;++d){c=a.g[d];if(b.Sb(c)){if(e==null){e=Yk(a.g,d);f=d}}else e!=null&&(e[f++]=c)}if(e==null){return false}a.g=e;return true}
function B(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ub){g=c.R()}else{ec(b,e);try{g=c.R()}finally{fc()}}return g}catch(a){a=jh(a);if(jd(a,8)){f=a;throw kh(f)}else throw kh(a)}finally{I(b)}}
function _n(a,b){if(null!=a.L){a.I.g=$c(ge,Bs,1,0,5,1);a.L.close();a.L=null;To(a,b)}if(null!=a.D){a.J.pb(new Bp);a.J.tb();Li(a.H.g);a.D.close();a.D=null;a.F=false;a.G=false;jb(a.i);Z(a.h)}}
function rh(){qh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0]._b()&&(c=Rc(c,g)):g[0]._b()}catch(a){a=jh(a);if(jd(a,8)){d=a;Dc();Jc(jd(d,48)?d.$():d)}else throw kh(a)}}return c}
function xc(a){var b;if(a.i==null){b=pd(a.h)===pd(vc)?null:a.h;a.j=b==null?Is:md(b)?b==null?null:b.name:od(b)?'String':Wh(v(b));a.g=a.g+': '+(md(b)?b==null?null:b.message:b+'');a.i='('+a.j+') '+a.g}}
function V(b){var c,d,e;e=b.v;try{d=b.i.R();if(!(pd(e)===pd(d)||e!=null&&u(e,d))){b.v=d;b.h=null;ib(b.l)}}catch(a){a=jh(a);if(jd(a,13)){c=a;if(!b.h){b.v=null;b.h=c;ib(b.l)}throw kh(c)}else throw kh(a)}}
function hk(a){var b,c,d,e,f,g;e=a.g*Qs+a.h*1502;g=a.h*Qs+11;b=$wnd.Math.floor(g*Rs);e+=b;g-=b*Ss;e%=Ss;a.g=e;a.h=g;d=a.g*128;f=$wnd.Math.floor(a.h*dk[31]);c=d+f;c>=2147483648&&(c-=4294967296);return c}
function wj(a,b,c){var d,e,f,g,h;h=b==null?0:(g=w(b),g|0);e=(d=a.g.get(h),d==null?new Array:d);if(e.length==0){a.g.set(h,e)}else{f=tj(b,e);if(f){return f.Nb(c)}}e[e.length]=new Yi(b,c);++a.h;return null}
function jl(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ni(a,c++)}b=b|0;return b}
function Zk(a,b,c,d,e){var f,g,h,i,j;if(pd(a)===pd(c)){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function bo(a){var b;if(!a.F){b=(lb(a.m),a.u);if((Wp(),Up)==b){a.F=true;a.D.createOffer().then(vh(nq.prototype.bb,nq,[a])).then(vh(oq.prototype.bb,oq,[a])).catch(vh(pq.prototype.bb,pq,[a]))}else{oo(a,ol(Js,Zs))}}}
function rb(b){var c;if(1!=(b.i&7)){try{if(4!=(b.i&7)){if(0!=(b.i&512)){!!b.l&&(b.i&=-513);c=b.j;C((O(),O(),N),b,c)}else{b.l.Q()}}else 0!=(b.i&512)&&!!b.l&&(b.i&=-513)}catch(a){a=jh(a);if(jd(a,8)){O()}else throw kh(a)}}}
function Ei(a,b){var c,d,e;c=b.Lb();e=b.Mb();d=od(c)?c==null?Gi(vj(a.g,null)):Jj(a.h,c):Gi(vj(a.g,c));if(!(pd(e)===pd(d)||e!=null&&u(e,d))){return false}if(d==null&&!(od(c)?Ii(a,c):!!vj(a.g,c))){return false}return true}
function T(a){var b,c,d,e,f,g;b=a.i?a.g.length-a.h+a.j:a.j-a.h;if(b+1>a.g.length){g=(a.g.length-1)*2+1;c=$c(ge,Bs,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.h+d)%a.g.length;c[f]=a.g[e];a.g[e]=null;++f}a.g=c;a.h=0;a.j=f;a.i=false}}
function zb(a,b,c,d){this.h=new hj;this.m=new Ob(new Db(this),d&6520832|262144|Ds);this.i=d&-6520833|3;this.g=a;this.j=b;this.l=c;!!this.j&&(this.i|=512);!this.g&&!!this.j&&(H((O(),O(),N),this),0==(this.m.g&Fs)&&I((null,N)))}
function ur(a){var b,c,d;this.l=a;this.o=a.props['a'];O();b=++qr;this.j=new mc(b,null,new vr(this),false);this.h=(d=new nb((c=null,c)),d);this.g=new Ab(null,new zr(this),dt);!!this.o&&Im(this.o,this,new wr(this));I((null,N))}
function xj(a,b){var c,d,e,f,g,h;g=b==null?0:(f=w(b),f|0);d=(c=a.g.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(oj(b,e.Lb())){if(d.length==1){d.length=0;Aj(a.g,g)}else{d.splice(h,1)}--a.h;return e.Mb()}}return null}
function gq(){gq=uh;fq=new hq('NOT_READY',0);$p=new hq('CONNECTED',1);dq=new hq('JOIN_REQUESTED',2);cq=new hq('JOIN_REJECTED',3);bq=new hq('JOINED',4);Zp=new hq('CLOSED',5);eq=new hq('LEFT',6);aq=new hq('FULL',7);_p=new hq('ERROR',8)}
function th(a,b,c){var d=qh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=qh[b]),wh(h));_.Zb=c;!b&&(_.$b=yh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.Yb=f)}
function xl(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;nl(b,vh(Al.prototype.Ub,Al,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ts]=c[0],undefined):(d[Ts]=c,undefined));return ul(a,e,f,d)}
function ci(a){if(a.nb()){var b=a.i;b.ob()?(a.v='['+b.u):!b.nb()?(a.v='[L'+b.lb()+';'):(a.v='['+b.lb());a.h=b.kb()+'[]';a.s=b.mb()+'[]';return}var c=a.m;var d=a.j;d=d.split('/');a.v=di('.',[c,di('$',d)]);a.h=di('.',[c,di('.',d)]);a.s=d[d.length-1]}
function yb(b){var c,d,e,f,g;g=b.i&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new jj(b.h);e.g<e.i.g.length;){d=(e.h=e.g++,e.i.g[e.h]);if(d.h){f=d.h;c=f.g;try{X(c)}catch(a){a=jh(a);if(!jd(a,8))throw kh(a)}if(6==(b.i&7)){return true}}}}}tb(b);return false}
function pc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.X();return a&&a.V()}},suppressed:{get:function(){return c.W()}}})}catch(a){}}}
function po(a){a.D=new $wnd.RTCPeerConnection(Lh({},[Oh({})]));a.F=false;a.G=false;a.D.onicecandidate=vh(Jp.prototype.hb,Jp,[a]);a.D.ontrack=vh(Kp.prototype.ib,Kp,[a]);a.D.onconnectionstatechange=vh(yp.prototype.eb,yp,[a]);a.D.onnegotiationneeded=vh(jq.prototype.eb,jq,[a]);ao(a,on(a.B));ao(a,on(a.K))}
function Ej(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function br(a){var b;this.s=new Zr(this);this.j=a;this.m=a.props['a'];this.o=a.props['b'];O();b=++Zq;this.i=new mc(b,new cr(this),new dr(this),false);this.g=new ab(new jr,new er(this),new fr(this),35815424);this.h=new Ab(null,new kr(this),dt);Im(this.m,this,new gr(this));this.u=new Wo(this.o,(gq(),fq),(Wp(),Vp));No(this.u);Jm(this.m,this.o);I((null,N))}
function xb(a,b,c){var d,e,f,g;g=a.i&7;if(b!=g){a.i=a.i&-8|b;if(!a.g&&6==b){c&&(1==(a.i&7)||1==(3&a.m.g)||H((O(),O(),N),a))}else if(!!a.g&&4==g&&(6==b||5==b)){mb(a.g.l);c&&(1==(a.i&7)||1==(3&a.m.g)||H((O(),O(),N),a))}else if(3==b||3!=g&&2==b){if(a.g){d=a.g;wb((e=d.s,e));d.v=null}aj(a.h,new Fb(a));a.h.g=$c(ge,Bs,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.g&&wb((f=a.g.o,f))}}
function pi(a){var b,c,d,e,f,g,h,i;b=new RegExp('\\|','g');h=$c(je,Bs,2,0,6,1);c=0;i=a;e=null;while(true){g=b.exec(i);if(g==null||i==''){h[c]=i;break}else{f=g.index;h[c]=i.substr(0,f);i=qi(i,f+g[0].length,i.length);b.lastIndex=0;if(e==i){h[c]=i.substr(0,1);i=i.substr(1)}e=i;++c}}if(a.length>0){d=h.length;while(d>0&&h[d-1]==''){--d}d<h.length&&(h.length=d)}return h}
function lo(a){var b,c;F((O(),O(),N),new fp(a),ct);tn(a.B,true);Z(a.g);So(a,(Wp(),Vp));To(a,(gq(),fq));a.L=new $wnd.WebSocket((b=$wnd.location,c=s('https',b.protocol)?'wss':'ws',c+'://'+b.hostname+':'+3737+'/r/'+a.C));a.L.onopen=vh(Fp.prototype.eb,Fp,[a]);a.L.onmessage=vh(Gp.prototype.fb,Gp,[a]);a.L.onclose=vh(Hp.prototype.cb,Hp,[a]);a.L.onerror=vh(Ip.prototype.eb,Ip,[a])}
function Bn(a,b,c){var d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;this.I=a;this.J=b;O();d=++jn;this.H=new mc(d,null,new Cn(this),true);this.A=c;this.G=true;this.h=(m=new nb((f=null,f)),m);this.o=(n=new nb((g=null,g)),n);this.l=(o=new nb((h=null,h)),o);this.j=(p=new nb((i=null,i)),p);this.i=(q=new nb((j=null,j)),q);this.u=(r=new nb((k=null,k)),r);this.s=(l=new nb((e=null,e)),l);this.g=new ab(new Dn(this),null,null,Xs);this.m=new Ab(new En(this),null,404750336);I((null,N))}
function Wo(a,b,c){var d,e,f,g,h,i,j,k,l;this.I=new hj;this.H=new sj;this.B=new Bn(new xp,new Cp(this),false);this.K=new Bn(new Dp,new Ep(this),false);this.J=new hj;this.C=a;O();d=++uo;this.A=new mc(d,new Xo(this),new Yo(this),true);this.v=b;this.u=c;this.s='';this.o=(i=new nb((f=null,f)),i);this.m=(j=new nb((g=null,g)),j);this.l=(k=new nb((e=null,e)),k);this.j=(l=new nb(null),l);this.i=(h=new nb(null),h);this.g=new ab(new Zo(this),null,null,Xs);this.h=new ab(new $o(this),null,null,Xs)}
function xm(){xm=uh;bm=new ym(Us,0);cm=new ym('checkbox',1);dm=new ym('color',2);em=new ym('date',3);fm=new ym('datetime',4);gm=new ym('email',5);hm=new ym('file',6);im=new ym('hidden',7);jm=new ym('image',8);km=new ym('month',9);lm=new ym('number',10);mm=new ym('password',11);nm=new ym('radio',12);om=new ym('range',13);pm=new ym('reset',14);qm=new ym('search',15);rm=new ym('submit',16);sm=new ym('tel',17);tm=new ym('text',18);um=new ym('time',19);vm=new ym('url',20);wm=new ym('week',21)}
function Xb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.l){return}j=(n=a.l.i&7,n>3?n:4);e=false;c=0;if(!!a.h&&1!=(a.l.i&7)){m=a.h.g.length;for(h=0;h<m;h++){k=bj(a.h,h);if(-1!=k.l&&-2!=k.l){k.l=-1;h!=c&&gj(a.h,c,k);++c;if(k.h){l=k.h;f=l.i&7;f==6&&(j=f)}}}}d=a.l.h;for(i=d.g.length-1;i>=0;i--){k=d.g[i];if(-1==k.l){k.l=0}else{hb(k,a.l);e=true}}2<(a.l.i&7)&&4!=j&&(a.l.i&7)<j&&xb(a.l,j,false);if(a.h){for(g=c-1;g>=0;g--){k=bj(a.h,g);if(-1==k.l){k.l=0;gb(k,a.l);e=true}}}if(a.h){for(g=a.h.g.length-1;g>=c;g--){dj(a.h,g)}e&&vb(a.l,a.h)}else{e&&vb(a.l,new hj)}if(db(a.l)&&!!a.l.g){b=a.l.g;k=b.l;!!k.h&&Ds!=(k.h.i&Es)&&k.i.g.length<=0&&0==k.h.g.j&&_b(a,k)}}
function or(a){var b,c,d,e;a.m=0;Bm();b=(c=(lb(a.h),a.i),d=a.o,e=(kb(d.g),d.i),xl(gt,Kl(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['home'])),vh(ms.prototype.Vb,ms,[a])),[xl('h1',null,['vChat']),xl('label',Wl(new $wnd.Object,'roomCode'),['Enter a room code.']),xl('input',Fl(Ol(Tl(Pl(Rl(Ql(Vl(Cl(Sl(Bl(Jl(new $wnd.Object,(xm(),tm)),bd(Yc(je,1),Bs,2,6,['roomCodeInput'])),'Room code'),'roomCode'),null==c?'':c),vh(os.prototype.Vb,os,[a]))),10)))),null),xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['roomSelectButtons'])),[xl(Us,Jl(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[kt])),($l(),Zl)),['Join']),xl('a',Gl(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[kt])),'#'+Em()),['Join Random'])]),e.h==0?null:tl([xl(mt,null,['Recently used rooms:']),tl(Ik(Ek(new Jk(null,new rk(e,16)),new ns),new zl))])]));return b}
function Gj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Ps]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Ej()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Ps]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function io(a,b){var c,d,e,f,g,h;d=b.data;g=$wnd.JSON.parse(d);f=g;if(pd(a.L)===pd(b.currentTarget)){Z(a.g);c=f[Js];if(s('create',c)){Ah(bd(Yc(ge,1),Bs,1,5,['Connected to room as host']));So(a,(Wp(),Up));To(a,(gq(),bq))}else if(s('connect',c)){Ah(bd(Yc(ge,1),Bs,1,5,['Connected to room as guest']));So(a,(Wp(),Tp));To(a,(gq(),$p))}else if(s('full',c)){Ah(bd(Yc(ge,1),Bs,1,5,['Room full. Leaving room.']));So(a,(Wp(),Vp));_n(a,(gq(),aq))}else if(s(at,c)){e=f['id'];h=f['message'];Ah(bd(Yc(ge,1),Bs,1,5,["Guest '"+e+"' requested access to room with message '"+h+"'"]));$i(a.I,new Dm(e,h));jb(a.j)}else if(s('accept',c)){Ah(bd(Yc(ge,1),Bs,1,5,['Host allowed guest to join room.']));To(a,(gq(),bq));po(a)}else if(s('reject',c)){Ah(bd(Yc(ge,1),Bs,1,5,['Host rejected guest from room.']));To(a,(gq(),cq))}else if(s('accepted',c)){e=f['id'];Ah(bd(Yc(ge,1),Bs,1,5,["Host accepted guest '"+e+"' into room."]));qj(a.H,e);jb(a.i)}else if(s('remove',c)){e=f['id'];if(rj(a.H,e)){Ah(bd(Yc(ge,1),Bs,1,5,["Guest '"+e+bt]));jb(a.i)}else if(fj(a.I,new vq(e))){Ah(bd(Yc(ge,1),Bs,1,5,["Client '"+e+bt]));jb(a.j)}}else if(s('offer',c)){a.F=true;a.D.setRemoteDescription(f[Ys]);a.D.createAnswer().then(vh(wq.prototype.bb,wq,[a])).then(vh(xq.prototype.bb,xq,[a])).catch(vh(yq.prototype.bb,yq,[a]))}else if(s('answer',c)){a.D.setRemoteDescription(f[Ys]);a.F=false;co(a)}else s($s,c)?a.D.addIceCandidate(Mh(Nh({},f[_s]),f[$s])):s(Zs,c)&&(a.G=true,co(a))}}
function Xq(a){var b,c,d;a.l=0;Bm();b=(c=a.u.B,d=X(a.u.g),xl(mt,El(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['room-view'])),vh($r.prototype.U,$r,[a])),[xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['video-section'])),[xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['video-list'])),Ik(Ek(X(a.u.h).yb(),new Wr),new zl)),xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['active-video'])),[xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['active-video-wrapper'])),[ws(us(ts(a.u.B),'active-video-element'),true)]),xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['controls'])),[xl(Us,Il(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[ot])),vh(cs.prototype.Wb,cs,[a])),[xl(pt,Ll(Nl(Ml(new $wnd.Object,pn(a.u.K)?'img/screen_share_on.svg':'img/screen_share_off.svg'),32),32),null)]),xl(Us,Il(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[ot])),vh(ds.prototype.Wb,ds,[c])),[xl(pt,Ll(Nl(Ml(new $wnd.Object,X(c.g)?qt:rt),32),32),null)]),xl(Us,Il(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[ot])),vh(es.prototype.Wb,es,[c])),[xl(pt,Ll(Nl(Ml(new $wnd.Object,(kb(c.u),c.G?'img/cam_on.svg':'img/cam_off.svg')),32),32),null)]),xl(Us,Il(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[ot])),vh(fs.prototype.Wb,fs,[a])),[xl(pt,Ll(Nl(Ml(new $wnd.Object,X(a.g)?'img/fullscreen_on.svg':'img/fullscreen_off.svg'),32),32),null)]),xl(Us,Il(Bl(Hl(new $wnd.Object,(Qp(),Np)!=d&&Pp!=d),bd(Yc(je,1),Bs,2,6,[ot])),vh(gs.prototype.Wb,gs,[a])),[xl(pt,Ll(Nl(Ml(new $wnd.Object,'img/hangup.svg'),32),32),null)])])])]),xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['message-area'])),[Uq(a)])]));return b}
function Uq(a){var b,c;c=Uo(a.u);if((gq(),fq)==c){return tl([xl(ft,null,['Getting ready...']),xl('p',null,["You'll be able to join in just a moment."])])}else if(_p==c){return tl([xl(ft,null,['Service Offline']),xl('p',null,['The chat service is offline at the moment. Try again later.'])])}else if($p==c){return tl([xl(ft,null,['Ready to join?']),xl('p',null,['Request access to join the room.']),xl(gt,Kl(new $wnd.Object,vh(Yr.prototype.Vb,Yr,[a])),[xl('label',Wl(new $wnd.Object,ht),[it]),xl('input',Tl(Pl(Vl(Ql(Ol(Cl(Sl(Jl(new $wnd.Object,(xm(),tm)),jt),ht)),vh(bs.prototype.Vb,bs,[a])),Qo(a.u)),30)),null),xl(Us,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[kt])),[lt])])])}else if(dq==c){return tl([xl(ft,null,['Joining room']),xl('p',null,['Waiting for host to allow access to the room.'])])}else if(bq==c&&(Wp(),Up)==Ro(a.u)&&Ao(a.u).g.length!=0){b=Ao(a.u).g[0];return tl([xl(ft,null,['Guest requests access']),xl('p',null,['A guest has sent you a message to join the room:']),xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['request-message'])),[b.h]),xl(gt,Kl(new $wnd.Object,vh(Xr.prototype.Vb,Xr,[])),[xl(Us,Il(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[kt])),vh(_r.prototype.Wb,_r,[a,b])),['Accept']),xl(Us,Il(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[kt])),vh(as.prototype.Wb,as,[a,b])),['Reject'])])])}else return bq==c&&(Wp(),Up)==Ro(a.u)&&Mi(zo(a.u).g)==0?tl([xl(ft,null,['Waiting for guests to join']),xl('p',null,['Waiting for someone to join this room']),xl('a',Gl(new $wnd.Object,'#'+a.u.C),[a.u.C])]):bq==c?tl([xl(ft,null,['Joined room']),xl('p',null,['Joined room. Feel free to chat.'])]):cq==c?tl([xl(ft,null,['Access denied']),xl('p',null,['The host denied access to the room. You can attempt to re-request access to join the room.']),xl(gt,Kl(new $wnd.Object,vh(Yr.prototype.Vb,Yr,[a])),[xl('label',Wl(new $wnd.Object,ht),[it]),xl('input',Tl(Pl(Vl(Ql(Ol(Cl(Sl(Jl(new $wnd.Object,(xm(),tm)),jt),ht)),vh(bs.prototype.Vb,bs,[a])),Qo(a.u)),30)),null),xl(Us,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[kt])),[lt])])]):Zp==c?tl([xl(ft,null,['Room closed']),xl('p',null,[(Wp(),Up)==Ro(a.u)?'You closed the room.':'The host closed the room.']),xl('a',Gl(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[kt])),'#'),[nt])]):aq==c?tl([xl(ft,null,['Room full']),xl('p',null,['The room is full and no other guests can connect at this time.']),xl('a',Gl(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[kt])),'#'),[nt])]):eq==c?tl([xl(ft,null,['Left the room']),xl('p',null,['You left the room.']),xl('a',Gl(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,[kt])),'#'),[nt])]):null}
var zs='object',As={6:1},Bs={4:1},Cs={11:1},Ds=1048576,Es=1835008,Fs=2097152,Gs='__noinit__',Hs={4:1,13:1,10:1,8:1},Is='null',Js='command',Ks='hashchange',Ls={32:1,69:1},Ms={32:1,63:1},Ns={44:1},Os={4:1,32:1,63:1},Ps='delete',Qs=15525485,Rs=5.9604644775390625E-8,Ss=16777216,Ts='children',Us='button',Vs='vchat.rooms',Ws=142606336,Xs=35651584,Ys='session',Zs='renegotiate',$s='candidate',_s='mlineindex',at='request_access',bt="' left the room.",ct=75497472,dt=1411518464,et='fullscreenchange',ft='h2',gt='form',ht='requestAccessMessage',it='Enter a message to send to the host to request access.',jt="Hi, I'm John Doe.",kt='primary-button',lt='Request Access',mt='div',nt='Return to Home',ot='control-btn',pt='img',qt='img/mic_on.svg',rt='img/mic_off.svg';var _,qh,lh,ih=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;rh();th(1,null,{},t);_.M=function(a){return s(this,a)};_.N=function(){return this.Yb};_.O=tt;_.P=function(){var a;return Wh(v(this))+'@'+(a=w(this)>>>0,a.toString(16))};_.equals=function(a){return this.M(a)};_.hashCode=function(){return this.O()};_.toString=function(){return this.P()};var dd,ed,fd;th(71,1,{},Xh);_.jb=function(a){var b;b=new Xh;b.l=4;a>1?(b.i=ai(this,a-1)):(b.i=this);return b};_.kb=function(){Vh(this);return this.h};_.lb=function(){return Wh(this)};_.mb=function(){Vh(this);return this.s};_.nb=function(){return (this.l&4)!=0};_.ob=function(){return (this.l&1)!=0};_.P=function(){return ((this.l&2)!=0?'interface ':(this.l&1)!=0?'':'class ')+(Vh(this),this.v)};_.l=0;_.o=0;var Uh=1;var ge=Zh(1);var Yd=Zh(71);th(104,1,{},J);_.h=1;_.i=false;_.j=true;_.l=0;var vd=Zh(104);th(105,1,As,K);_.Q=function(){Hb(this.g)};var sd=Zh(105);th(57,1,{},L);_.R=function(){return this.g.Q(),null};var td=Zh(57);th(106,1,{},M);var ud=Zh(106);var N;th(58,1,{58:1},U);_.h=0;_.i=false;_.j=0;var wd=Zh(58);th(259,1,Cs);_.P=function(){var a;return Wh(this.Yb)+'@'+(a=w(this)>>>0,a.toString(16))};var zd=Zh(259);th(39,259,Cs,ab);_.S=function(){W(this)};_.T=st;_.g=false;_.j=0;_.u=false;var yd=Zh(39);th(143,1,{},bb);_.R=function(){return Y(this.g)};var xd=Zh(143);th(12,259,{11:1,12:1},nb);_.S=function(){eb(this)};_.T=function(){return -2==this.l};_.g=4;_.j=false;_.l=0;var Bd=Zh(12);th(142,1,As,ob);_.Q=function(){fb(this.g)};var Ad=Zh(142);th(24,259,{11:1,24:1},Ab,Bb);_.S=function(){pb(this)};_.T=function(){return 1==(this.i&7)};_.i=0;var Gd=Zh(24);th(137,1,{},Cb);_.Q=function(){V(this.g)};var Cd=Zh(137);th(138,1,As,Db);_.Q=function(){rb(this.g)};var Dd=Zh(138);th(139,1,As,Eb);_.Q=function(){ub(this.g)};var Ed=Zh(139);th(140,1,{},Fb);_.U=function(a){sb(this.g,a)};var Fd=Zh(140);th(117,1,{},Ib);_.g=0;_.h=0;_.i=0;var Hd=Zh(117);th(148,1,Cs,Kb);_.S=function(){Jb(this)};_.T=st;_.g=false;var Id=Zh(148);th(82,259,{11:1,82:1},Ob);_.S=function(){Lb(this)};_.T=function(){return 2==(3&this.g)};_.g=0;var Kd=Zh(82);th(116,1,{},Tb);var Jd=Zh(116);th(149,1,{},dc);_.P=function(){var a;return Vh(Ld),Ld.v+'@'+(a=el(this)>>>0,a.toString(16))};_.g=0;var Ub;var Ld=Zh(149);th(23,1,Cs,mc);_.S=function(){hc(this)};_.T=function(){return this.s<0};_.P=function(){var a;return Vh(Nd),Nd.v+'@'+(a=el(this)>>>0,a.toString(16))};_.j=0;_.s=0;var Nd=Zh(23);th(136,1,As,nc);_.Q=function(){kc(this.g)};var Md=Zh(136);th(8,1,{4:1,8:1});_.V=Bt;_.W=function(){return Ik(Ek(lj((this.s==null&&(this.s=$c(le,Bs,8,0,0,1)),this.s)),new zi),new Mk)};_.X=function(){return this.m};_.Y=function(){return this.o};_.Z=function(){qc(this,sc(new Error(rc(this,this.o))));Vc(this)};_.P=function(){return rc(this,this.Y())};_.l=Gs;_.u=true;var le=Zh(8);th(13,8,{4:1,13:1,8:1});var _d=Zh(13);th(10,13,Hs);var he=Zh(10);th(99,10,Hs);var ee=Zh(99);th(100,99,Hs);var Rd=Zh(100);th(48,100,{48:1,4:1,13:1,10:1,8:1},yc);_.Y=function(){xc(this);return this.i};_.$=function(){return pd(this.h)===pd(vc)?null:this.h};var vc;var Od=Zh(48);var Pd=Zh(0);th(243,1,{});var Qd=Zh(243);var Ac=0,Bc=0,Cc=-1;th(109,243,{},Qc);var Mc;var Sd=Zh(109);var Tc;th(253,1,{});var Ud=Zh(253);th(101,253,{},Xc);var Td=Zh(101);th(73,1,{96:1});_.P=st;var Vd=Zh(73);th(103,10,Hs);var ce=Zh(103);th(141,103,Hs,Sh);var Wd=Zh(141);dd={4:1,97:1,22:1};var Xd=Zh(97);th(56,1,{4:1,56:1});var fe=Zh(56);ed={4:1,22:1,98:1,56:1};var Zd=Zh(98);th(16,1,{4:1,22:1,16:1});_.M=function(a){return this===a};_.O=tt;_.P=function(){return this.g!=null?this.g:''+this.h};_.h=0;var $d=Zh(16);th(72,10,Hs,gi);var ae=Zh(72);th(102,10,Hs,hi);var be=Zh(102);th(37,56,{4:1,22:1,37:1,56:1},ii);_.M=function(a){return jd(a,37)&&a.g==this.g};_.O=st;_.P=function(){return ''+this.g};_.g=0;var de=Zh(37);var ki;th(356,1,{});fd={4:1,96:1,22:1,2:1};var je=Zh(2);th(55,73,{96:1},xi,yi);var ie=Zh(55);th(360,1,{});th(94,1,{},zi);_.rb=function(a){return a.l};var ke=Zh(94);th(47,10,Hs,Ai,Bi);var me=Zh(47);th(254,1,{32:1});_.pb=At;_.xb=function(){return new rk(this,0)};_.yb=function(){return new Jk(null,this.xb())};_.sb=function(a){throw kh(new Bi('Add not supported on this collection'))};_.tb=function(){var a;for(a=this.qb();a.Cb();){a.Db();a.Eb()}};_.ub=function(a){return Ci(this,a,false)};_.vb=function(){return this.wb()==0};_.zb=function(){return this.Ab($c(ge,Bs,1,this.wb(),5,1))};_.Ab=function(a){var b,c,d,e;e=this.wb();a.length<e&&(a=bl(new Array(e),a));d=a;c=this.qb();for(b=0;b<e;++b){d[b]=c.Db()}a.length>e&&(a[e]=null);return a};_.P=function(){var a,b,c;c=new uk(', ','[',']');for(b=this.qb();b.Cb();){a=b.Db();sk(c,a===this?'(this Collection)':a==null?Is:xh(a))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var ne=Zh(254);th(257,1,{240:1});_.M=function(a){var b,c,d;if(a===this){return true}if(!jd(a,49)){return false}d=a;if(this.g.h+this.h.h!=d.g.h+d.h.h){return false}for(c=new Si((new Oi(d)).g);c.h;){b=Qi(c);if(!Ei(this,b)){return false}}return true};_.O=function(){return mj(new Oi(this))};_.P=function(){var a,b,c;c=new uk(', ','{','}');for(b=new Si((new Oi(this)).g);b.h;){a=Qi(b);sk(c,Fi(this,a.Lb())+'='+Fi(this,a.Mb()))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var ze=Zh(257);th(118,257,{240:1});var qe=Zh(118);th(256,254,Ls);_.xb=function(){return new rk(this,1)};_.M=function(a){var b;if(a===this){return true}if(!jd(a,69)){return false}b=a;if(b.wb()!=this.wb()){return false}return Di(this,b)};_.O=function(){return mj(this)};var Be=Zh(256);th(35,256,Ls,Oi);_.tb=wt;_.ub=function(a){return Ni(this,a)};_.qb=function(){return new Si(this.g)};_.wb=xt;var pe=Zh(35);th(38,1,{},Si);_.Bb=ut;_.Db=function(){return Qi(this)};_.Cb=yt;_.Eb=function(){Ri(this)};_.h=false;var oe=Zh(38);th(255,254,Ms);_.xb=function(){return new rk(this,16)};_.Fb=function(a,b){throw kh(new Bi('Add not supported on this list'))};_.sb=function(a){this.Fb(this.wb(),a);return true};_.tb=function(){this.Jb(0,this.wb())};_.M=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,63)){return false}f=a;if(this.wb()!=f.wb()){return false}e=f.qb();for(c=this.qb();c.Cb();){b=c.Db();d=e.Db();if(!(pd(b)===pd(d)||b!=null&&u(b,d))){return false}}return true};_.O=function(){return nj(this)};_.qb=function(){return new Ui(this)};_.Hb=function(a){return new Vi(this,a)};_.Ib=function(a){throw kh(new Bi('Remove not supported on this list'))};_.Jb=function(a,b){var c,d;d=this.Hb(a);for(c=a;c<b;++c){d.Db();d.Eb()}};var te=Zh(255);th(74,1,{},Ui);_.Bb=ut;_.Cb=function(){return this.h<this.j.wb()};_.Db=function(){this.h<this.j.wb();return this.j.Gb(this.i=this.h++)};_.Eb=vt;_.h=0;_.i=-1;var re=Zh(74);th(108,74,{},Vi);_.Eb=vt;_.Kb=function(a){this.g.Fb(this.h,a);++this.h;this.i=-1};var se=Zh(108);th(112,256,Ls,Wi);_.tb=wt;_.ub=zt;_.qb=function(){var a;return a=new Si((new Oi(this.g)).g),new Xi(a)};_.wb=xt;var ve=Zh(112);th(75,1,{},Xi);_.Bb=ut;_.Cb=function(){return this.g.h};_.Db=function(){var a;a=Qi(this.g);return a.Lb()};_.Eb=function(){Ri(this.g)};var ue=Zh(75);th(110,1,Ns);_.M=function(a){var b;if(!jd(a,44)){return false}b=a;return oj(this.g,b.Lb())&&oj(this.h,b.Mb())};_.Lb=st;_.Mb=yt;_.O=function(){return bk(this.g)^bk(this.h)};_.Nb=function(a){var b;b=this.h;this.h=a;return b};_.P=function(){return this.g+'='+this.h};var we=Zh(110);th(111,110,Ns,Yi);var xe=Zh(111);th(258,1,Ns);_.M=function(a){var b;if(!jd(a,44)){return false}b=a;return oj(this.h.value[0],b.Lb())&&oj(Oj(this),b.Mb())};_.O=function(){return bk(this.h.value[0])^bk(Oj(this))};_.P=function(){return this.h.value[0]+'='+Oj(this)};var ye=Zh(258);th(261,255,Ms);_.Fb=function(a,b){var c;c=this.Hb(a);c.Kb(b)};_.Gb=function(a){var b;b=this.Hb(a);return b.Db()};_.qb=function(){return Uj(this,0)};_.Ib=function(a){var b,c;b=this.Hb(a);c=b.Db();b.Eb();return c};var Ae=Zh(261);th(15,255,Os,hj,ij);_.Fb=function(a,b){$k(this.g,a,b)};_.sb=function(a){return $i(this,a)};_.tb=function(){this.g=$c(ge,Bs,1,0,5,1)};_.ub=function(a){return cj(this,a,0)!=-1};_.pb=function(a){aj(this,a)};_.Gb=function(a){return bj(this,a)};_.vb=function(){return this.g.length==0};_.qb=function(){return new jj(this)};_.Ib=function(a){return dj(this,a)};_.Jb=function(a,b){var c;c=b-a;al(this.g,a,c)};_.wb=function(){return this.g.length};_.zb=function(){return Yk(this.g,this.g.length)};_.Ab=function(a){var b,c;c=this.g.length;a.length<c&&(a=bl(new Array(c),a));for(b=0;b<c;++b){a[b]=this.g[b]}a.length>c&&(a[c]=null);return a};var De=Zh(15);th(29,1,{},jj);_.Bb=ut;_.Cb=function(){return this.g<this.i.g.length};_.Db=function(){return this.h=this.g++,this.i.g[this.h]};_.Eb=function(){dj(this.i,this.g=this.h);this.h=-1};_.g=0;_.h=-1;var Ce=Zh(29);th(49,118,{4:1,49:1,240:1},pj);var Ee=Zh(49);th(168,256,{4:1,32:1,69:1},sj);_.sb=function(a){return qj(this,a)};_.tb=wt;_.ub=zt;_.vb=function(){return Mi(this.g)==0};_.qb=function(){var a;return a=new Si((new Oi((new Wi(this.g)).g)).g),new Xi(a)};_.wb=xt;var Fe=Zh(168);th(76,1,{},yj);_.pb=At;_.qb=function(){return new zj(this)};_.h=0;var He=Zh(76);th(77,1,{},zj);_.Bb=ut;_.Db=function(){return this.j=this.g[this.i++],this.j};_.Cb=function(){var a;if(this.i<this.g.length){return true}a=this.h.next();if(!a.done){this.g=a.value[1];this.i=0;return true}return false};_.Eb=function(){xj(this.l,this.j.Lb());this.i!=0&&--this.i};_.i=0;_.j=null;var Ge=Zh(77);var Cj;th(78,1,{},Mj);_.pb=At;_.qb=function(){return new Nj(this)};_.h=0;_.i=0;var Ke=Zh(78);th(79,1,{},Nj);_.Bb=ut;_.Db=function(){return this.i=this.g,this.g=this.h.next(),new Pj(this.j,this.i,this.j.i)};_.Cb=function(){return !this.g.done};_.Eb=function(){Lj(this.j,this.i.value[0])};var Ie=Zh(79);th(119,258,Ns,Pj);_.Lb=function(){return this.h.value[0]};_.Mb=function(){return Oj(this)};_.Nb=function(a){return Kj(this.g,this.h.value[0],a)};_.i=0;var Je=Zh(119);th(159,261,Os,Yj);_.sb=function(a){Tj(this,a,this.i.h,this.i);return true};_.tb=function(){Xj(this)};_.Hb=function(a){return Uj(this,a)};_.wb=yt;_.h=0;var Ne=Zh(159);th(160,1,{},$j);_.Bb=ut;_.Kb=function(a){Tj(this.j,a,this.h.h,this.h);++this.g;this.i=null};_.Cb=function(){return this.h!=this.j.i};_.Db=function(){return Zj(this)};_.Eb=function(){var a;a=this.i.g;Wj(this.j,this.i);this.h==this.i?(this.h=a):--this.g;this.i=null};_.g=0;_.i=null;var Le=Zh(160);th(60,1,{},_j);var Me=Zh(60);th(202,1,{},ik);_.g=0;_.h=0;var ck,dk,ek=0;var Oe=Zh(202);th(121,1,{});_.Bb=Ct;_.Ob=function(){return this.j};_.Pb=Bt;_.j=0;_.l=0;var Se=Zh(121);th(80,121,{});var Pe=Zh(80);th(113,1,{});_.Bb=Ct;_.Ob=yt;_.Pb=function(){return this.j-this.i};_.h=0;_.i=0;_.j=0;var Re=Zh(113);th(114,113,{},pk);_.Bb=function(a){mk(this,a)};_.Qb=function(a){return nk(this,a)};var Qe=Zh(114);th(30,1,{},rk);_.Ob=st;_.Pb=function(){qk(this);return this.i};_.Bb=function(a){qk(this);this.j.Bb(a)};_.Qb=function(a){qk(this);if(this.j.Cb()){a.U(this.j.Db());return true}return false};_.g=0;_.i=0;var Te=Zh(30);th(46,1,{},tk,uk);_.P=function(){return !this.g?this.i:this.l.length==0?this.g.g:this.g.g+(''+this.l)};var Ue=Zh(46);th(70,1,{},vk);_.rb=function(a){return a};var Ve=Zh(70);th(83,1,{},wk);var We=Zh(83);th(120,1,{});_.i=false;var ef=Zh(120);th(31,120,{},Jk);var Ak;var df=Zh(31);th(95,1,{},Mk);_.Rb=function(a){return Bk(),$c(ge,Bs,1,a,5,1)};var Xe=Zh(95);th(81,80,{},Ok);_.Qb=function(a){this.h=false;while(!this.h&&this.i.Qb(new Pk(this,a)));return this.h};_.h=false;var Ze=Zh(81);th(125,1,{},Pk);_.U=function(a){Nk(this.g,this.h,a)};var Ye=Zh(125);th(122,80,{},Rk);_.Qb=function(a){return this.h.Qb(new Sk(this,a))};var _e=Zh(122);th(124,1,{},Sk);_.U=function(a){Qk(this.g,this.h,a)};var $e=Zh(124);th(123,1,{},Uk);_.U=function(a){Tk(this,a)};var af=Zh(123);th(126,1,{},Vk);_.U=function(a){Bk()};var bf=Zh(126);th(127,1,{},Xk);_.U=function(a){Wk(this,a)};var cf=Zh(127);th(358,1,{});th(355,1,{});var dl=0;var fl,gl=0,hl;th(1341,1,{});th(1381,1,{});th(84,1,{},zl);_.Rb=function(a){return new Array(a)};var ff=Zh(84);th(308,$wnd.Function,{},Al);_.Ub=function(a){yl(this.g,this.h,a)};th(40,16,{4:1,22:1,16:1,40:1},_l);var Xl,Yl,Zl;var gf=$h(40,am);th(9,16,{4:1,22:1,16:1,9:1},ym);var bm,cm,dm,em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm,qm,rm,sm,tm,um,vm,wm;var hf=$h(9,zm);var Am;th(293,$wnd.Function,{},Cm);_.bb=function(a){return Jb(Am),Am=null,null};th(87,1,{87:1},Dm);var jf=Zh(87);th(59,1,{59:1});var kf=Zh(59);th(150,59,{11:1,59:1},Km);_.S=Dt;_.T=Et;_.P=function(){var a;return Vh(of),of.v+'@'+(a=el(this)>>>0,a.toString(16))};var Hm=0;var of=Zh(150);th(151,1,As,Lm);_.Q=function(){cb(this.g.j)};var lf=Zh(151);th(152,1,As,Mm);_.Q=function(){eb(this.g.g)};var mf=Zh(152);th(153,1,As,Nm);_.Q=function(){Fm(this.g,this.h)};var nf=Zh(153);th(161,1,{});var _f=Zh(161);th(162,161,Cs,Qm);_.S=Dt;_.T=Et;_.P=function(){var a;return Vh(uf),uf.v+'@'+(a=el(this)>>>0,a.toString(16))};var Om=0;var uf=Zh(162);th(163,1,As,Rm);_.Q=function(){W(this.g.g)};var pf=Zh(163);th(165,1,{},Sm);_.Q=function(){Bh(this.g.i)};var qf=Zh(165);th(166,1,{},Tm);_.Q=function(){Ch(this.g.i)};var rf=Zh(166);th(164,1,{},Um);_.R=function(){var a;return a=$wnd.location.hash,a.length==0?a:a.substr(1)};var sf=Zh(164);th(167,1,As,Vm);_.Q=It;var tf=Zh(167);th(61,1,{61:1});_.K=0;var ag=Zh(61);th(62,61,{11:1,61:1},Bn);_.S=function(){hc(this.H)};_.T=function(){return this.H.s<0};_.P=function(){var a;return Vh(Gf),Gf.v+'@'+(a=el(this)>>>0,a.toString(16))};_.v=false;_.A=false;_.G=false;var jn=0;var Gf=Zh(62);th(223,1,As,Cn);_.Q=function(){kn(this.g)};var vf=Zh(223);th(224,1,{},Dn);_.R=function(){return qn(this.g)};var wf=Zh(224);th(225,1,{},En);_.Q=function(){_m(this.g)};var xf=Zh(225);th(226,1,As,Fn);_.Q=function(){ln(this.g,this.h)};var yf=Zh(226);th(88,1,As,Gn);_.Q=function(){bn(this.g,this.h)};_.h=false;var zf=Zh(88);th(227,1,As,Hn);_.Q=function(){rn(this.g)};var Af=Zh(227);th(228,1,As,In);_.Q=function(){fn(this.g)};var Bf=Zh(228);th(229,1,As,Jn);_.Q=function(){gn(this.g)};var Cf=Zh(229);th(230,1,As,Kn);_.Q=function(){cn(this.g,this.h)};var Df=Zh(230);th(231,1,As,Ln);_.Q=function(){dn(this.g)};var Ef=Zh(231);th(232,1,As,Mn);_.Q=function(){en(this.g,this.h)};var Ff=Zh(232);th(203,1,{});_.F=false;_.G=false;var sg=Zh(203);th(204,203,Cs,Wo);_.S=function(){hc(this.A)};_.T=function(){return this.A.s<0};_.P=function(){var a;return Vh(Zf),Zf.v+'@'+(a=el(this)>>>0,a.toString(16))};var uo=0;var Zf=Zh(204);th(205,1,As,Xo);_.Q=function(){wo(this.g)};var Hf=Zh(205);th(206,1,As,Yo);_.Q=function(){vo(this.g)};var If=Zh(206);th(207,1,{},Zo);_.R=function(){return Bo(this.g)};var Jf=Zh(207);th(208,1,{},$o);_.R=function(){return On(this.g)};var Kf=Zh(208);th(209,1,As,_o);_.Q=function(){xo(this.g,this.h)};var Lf=Zh(209);th(210,1,As,ap);_.Q=function(){qo(this.g)};var Mf=Zh(210);th(211,1,As,bp);_.Q=function(){lo(this.g)};var Nf=Zh(211);th(212,1,As,cp);_.Q=function(){fo(this.g,this.h)};var Of=Zh(212);th(213,1,As,dp);_.Q=function(){ko(this.g,this.h)};var Pf=Zh(213);th(214,1,As,ep);_.Q=function(){jo(this.g,this.h)};var Qf=Zh(214);th(86,1,As,fp);_.Q=function(){_n(this.g,(gq(),eq))};var Rf=Zh(86);th(215,1,As,gp);_.Q=function(){go(this.g,this.h)};var Sf=Zh(215);th(216,1,As,hp);_.Q=function(){Co(this.g,this.h)};var Tf=Zh(216);th(217,1,As,ip);_.Q=function(){eo(this.g,this.h)};var Uf=Zh(217);th(218,1,As,jp);_.Q=function(){io(this.g,this.h)};var Vf=Zh(218);th(219,1,As,kp);_.Q=function(){no(this.g)};var Wf=Zh(219);th(220,1,As,lp);_.Q=function(){Do(this.g,this.h)};var Xf=Zh(220);th(221,1,As,mp);_.Q=function(){Eo(this.g,this.h)};var Yf=Zh(221);th(147,1,{},np);_.handleEvent=function(a){Pm(this.g)};var $f=Zh(147);th(337,$wnd.Function,{},op);_._=function(a,b,c){return Th(),a.enabled?true:false};th(330,$wnd.Function,{},pp);_._=Ft;th(331,$wnd.Function,{},qp);_._=Ft;th(332,$wnd.Function,{},rp);_.bb=function(a){return Xm(this.g,this.h,a)};_.h=0;th(333,$wnd.Function,{},sp);_.bb=function(a){return Ym(this.g,this.h,a)};_.h=0;th(334,$wnd.Function,{},tp);_._=function(a,b,c){return Zm(this.g,a)};th(336,$wnd.Function,{},up);_.eb=function(a){$m(this.g)};th(335,$wnd.Function,{},vp);_._=function(a,b,c){return hn(a)};th(270,$wnd.Function,{},wp);_._=function(a,b,c){return s('live',a.readyState)&&a.stop(),null};th(187,1,{},xp);_.Tb=function(){return $wnd.navigator.mediaDevices.getUserMedia(Ih(Hh({}),Jh(Kh({},Eh(Dh(Fh({},160),640),1280)),Eh(Dh(Fh({},120),360),720))))};var bg=Zh(187);th(318,$wnd.Function,{},yp);_.eb=function(a){Ho(this.g,a)};th(191,1,{},zp);_.U=Gt;var cg=Zh(191);th(329,$wnd.Function,{},Ap);_.gb=function(a){Lo(this.g,a)};th(196,1,{},Bp);_.U=Gt;var dg=Zh(196);th(188,1,{},Cp);_.U=Ht;var eg=Zh(188);th(189,1,{},Dp);_.Tb=function(){return $wnd.navigator.mediaDevices.getDisplayMedia(Gh({}))};var fg=Zh(189);th(190,1,{},Ep);_.U=Ht;var gg=Zh(190);th(311,$wnd.Function,{},Fp);_.eb=function(a){Ko(this.g,a)};th(312,$wnd.Function,{},Gp);_.fb=function(a){Jo(this.g,a)};th(313,$wnd.Function,{},Hp);_.cb=function(a){Go(this.g,a)};th(314,$wnd.Function,{},Ip);_.eb=function(a){Io(this.g,a)};th(316,$wnd.Function,{},Jp);_.hb=function(a){ho(this.g,a)};th(317,$wnd.Function,{},Kp);_.ib=function(a){Mo(this.g,a)};th(25,16,{4:1,22:1,16:1,25:1},Rp);var Lp,Mp,Np,Op,Pp;var hg=$h(25,Sp);th(41,16,{4:1,22:1,16:1,41:1},Xp);var Tp,Up,Vp;var ig=$h(41,Yp);th(17,16,{4:1,22:1,16:1,17:1},hq);var Zp,$p,_p,aq,bq,cq,dq,eq,fq;var jg=$h(17,iq);th(319,$wnd.Function,{},jq);_.eb=function(a){bo(this.g)};th(320,$wnd.Function,{},kq);_._=function(a,b,c){return Pn(this.g,this.h,a)};th(309,$wnd.Function,{},lq);_._=function(a,b,c){return Qn(this.g,a)};th(328,$wnd.Function,{},mq);_.ab=function(a,b,c){return ro(this.g,a)};th(321,$wnd.Function,{},nq);_.bb=function(a){return Rn(this.g,a)};th(322,$wnd.Function,{},oq);_.bb=function(a){return Sn(this.g)};th(323,$wnd.Function,{},pq);_.bb=function(a){return Tn(this.g,a)};th(324,$wnd.Function,{},qq);_._=function(a,b,c){return Un(this.g,a)};th(192,1,{},rq);_.Sb=function(a){return Vn(this.g,a)};var kg=Zh(192);th(193,1,{},sq);_.U=function(a){};var lg=Zh(193);th(194,1,{},tq);_.Tb=function(){return $wnd.Promise.resolve(this.g)};var mg=Zh(194);th(195,1,{},uq);_.Sb=function(a){return Wn(this.g,a)};var ng=Zh(195);th(197,1,{},vq);_.Sb=function(a){return so(this.g,a)};var og=Zh(197);th(325,$wnd.Function,{},wq);_.bb=function(a){return Xn(this.g,a)};th(326,$wnd.Function,{},xq);_.bb=function(a){return Yn(this.g)};th(327,$wnd.Function,{},yq);_.bb=function(a){return Zn(this.g,a)};th(198,1,As,zq);_.Q=function(){$n(this.g,this.h)};var pg=Zh(198);th(199,1,As,Aq);_.Q=function(){oo(this.g,pl('reject_access','id',this.h.g))};var qg=Zh(199);th(200,1,{},Bq);_.Sb=function(a){return to(this.g,a)};var rg=Zh(200);th(129,1,{});var ug=Zh(129);th(93,1,{},Cq);var tg=Zh(93);th(130,129,{});_.j=0;var Tg=Zh(130);th(131,130,Cs,Iq);_.S=Dt;_.T=Et;_.P=function(){var a;return Vh(zg),zg.v+'@'+(a=el(this)>>>0,a.toString(16))};var Gq=0;var zg=Zh(131);th(132,1,As,Jq);_.Q=function(){cb(this.g.l)};var vg=Zh(132);th(133,1,As,Kq);_.Q=function(){pb(this.g.g)};var wg=Zh(133);th(135,1,{},Lq);_.R=function(){return Eq(this.g)};var xg=Zh(135);th(134,1,{},Mq);_.Q=function(){Fq(this.g)};var yg=Zh(134);th(146,1,{});var bh=Zh(146);th(176,146,{});_.l=0;var Vg=Zh(176);th(177,176,Cs,br);_.S=function(){hc(this.i)};_.T=function(){return this.i.s<0};_.P=function(){var a;return Vh(Jg),Jg.v+'@'+(a=el(this)>>>0,a.toString(16))};var Zq=0;var Jg=Zh(177);th(178,1,As,cr);_.Q=function(){cb(this.g.u)};var Ag=Zh(178);th(179,1,As,dr);_.Q=function(){$q(this.g)};var Bg=Zh(179);th(181,1,{},er);_.Q=function(){Sq(this.g)};var Cg=Zh(181);th(182,1,{},fr);_.Q=function(){Tq(this.g)};var Dg=Zh(182);th(184,1,As,gr);_.Q=function(){hc(this.g.i)};var Eg=Zh(184);th(185,1,{},hr);_.R=function(){return Xq(this.g)};var Fg=Zh(185);th(186,1,As,ir);_.Q=It;var Gg=Zh(186);th(180,1,{},jr);_.R=function(){return Th(),$wnd.document.fullscreen?true:false};var Hg=Zh(180);th(183,1,{},kr);_.Q=function(){Yq(this.g)};var Ig=Zh(183);th(260,1,{});var fh=Zh(260);th(169,260,{});_.m=0;var Xg=Zh(169);th(170,169,Cs,ur);_.S=function(){hc(this.j)};_.T=function(){return this.j.s<0};_.P=function(){var a;return Vh(Pg),Pg.v+'@'+(a=el(this)>>>0,a.toString(16))};var qr=0;var Pg=Zh(170);th(171,1,As,vr);_.Q=function(){rr(this.g)};var Kg=Zh(171);th(173,1,As,wr);_.Q=function(){hc(this.g.j)};var Lg=Zh(173);th(174,1,As,xr);_.Q=function(){sr(this.g,this.h)};var Mg=Zh(174);th(175,1,{},yr);_.R=function(){return or(this.g)};var Ng=Zh(175);th(172,1,{},zr);_.Q=function(){pr(this.g)};var Og=Zh(172);th(201,1,{});var hh=Zh(201);th(233,201,{});var Zg=Zh(233);th(234,233,Cs,Er);_.S=function(){hc(this.g)};_.T=function(){return this.g.s<0};_.P=function(){var a;return Vh(Rg),Rg.v+'@'+(a=el(this)>>>0,a.toString(16))};var Dr=0;var Rg=Zh(234);th(235,1,As,Fr);_.Q=function(){hc(this.g.g)};var Qg=Zh(235);th(292,$wnd.Function,{},Gr);_.Xb=function(a){return new Jr(a)};var Hr;th(115,$wnd.React.Component,{},Jr);sh(qh[1],_);_.componentWillUnmount=function(){Dq(this.g)};_.render=function(){return Hq(this.g)};_.shouldComponentUpdate=function(a){return 1==this.g.j};var Sg=Zh(115);th(297,$wnd.Function,{},Kr);_.Xb=function(a){return new Nr(a)};var Lr;th(156,$wnd.React.Component,{},Nr);sh(qh[1],_);_.componentWillUnmount=function(){db(this.g)&&Wq(this.g)};_.render=function(){return db(this.g)?_q(this.g):null};_.shouldComponentUpdate=function(a){return db(this.g)&&1==this.g.l};var Ug=Zh(156);th(294,$wnd.Function,{},Or);_.Xb=function(a){return new Rr(a)};var Pr;th(154,$wnd.React.Component,{},Rr);sh(qh[1],_);_.componentWillUnmount=function(){db(this.g)&&nr(this.g)};_.render=function(){return db(this.g)?tr(this.g):null};_.shouldComponentUpdate=function(a){return db(this.g)&&1==this.g.m};var Wg=Zh(154);th(338,$wnd.Function,{},Sr);_.Xb=function(a){return new Vr(a)};var Tr;th(222,$wnd.React.Component,{},Vr);sh(qh[1],_);_.componentWillUnmount=function(){db(this.g)&&hc(this.g.g)};_.render=function(){return db(this.g)?Br(this.g):null};_.shouldComponentUpdate=function(a){return db(this.g)&&Cr(this.g,a)};var Yg=Zh(222);th(158,1,{},Wr);_.rb=function(a){var b;return xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['video-list-item'])),[xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['video-list-item-wrapper'])),[ws(us(vs(new xs,a),'video-list-item-element'),false)]),(b=(kb(a.o),a.D),null!=b&&b.getAudioTracks().length>0?xl(mt,Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['video-list-item-controls'])),[xl(Us,Il(Bl(new $wnd.Object,bd(Yc(je,1),Bs,2,6,['video-list-item-control-btn'])),vh(hs.prototype.Wb,hs,[a])),[xl(pt,Ll(Nl(Ml(new $wnd.Object,X(a.g)?qt:rt),16),16),null)])]):null)])};var $g=Zh(158);th(305,$wnd.Function,{},Xr);_.Vb=function(a){a.preventDefault()};th(268,$wnd.Function,{},Yr);_.Vb=function(a){Vq(this.g,a)};th(157,1,{},Zr);_.handleEvent=function(a){ar(this.g)};var _g=Zh(157);th(298,$wnd.Function,{},$r);_.U=function(a){Nq(this.g,a)};th(306,$wnd.Function,{},_r);_.Wb=function(a){Oq(this.g,this.h,a)};th(307,$wnd.Function,{},as);_.Wb=function(a){Pq(this.g,this.h,a)};th(269,$wnd.Function,{},bs);_.Vb=function(a){Qq(this.g,a)};th(299,$wnd.Function,{},cs);_.Wb=function(a){Vo(this.g.u)};th(300,$wnd.Function,{},ds);_.Wb=Jt;th(301,$wnd.Function,{},es);_.Wb=function(a){An(this.g)};th(302,$wnd.Function,{},fs);_.Wb=function(a){Rq(this.g)};th(303,$wnd.Function,{},gs);_.Wb=function(a){Fo(this.g.u)};th(304,$wnd.Function,{},hs);_.Wb=Jt;th(145,1,{},ls);var ah=Zh(145);th(295,$wnd.Function,{},ms);_.Vb=function(a){lr(this.g,a)};th(155,1,{},ns);_.rb=function(a){return xl('a',Gl(Bl(Dl(new $wnd.Object,a),bd(Yc(je,1),Bs,2,6,['recent-room'])),'#'+a),[a])};var dh=Zh(155);th(296,$wnd.Function,{},os);_.Vb=function(a){var b;mr(this.g,ri((b=a.target,b).value))};th(144,1,{},rs);var eh=Zh(144);th(339,$wnd.Function,{},ss);_.U=function(a){Ar(this.g,a)};th(85,1,{},xs);var gh=Zh(85);var rd=_h('D');var ys=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=oh;mh(zh);ph('permProps',[[]]);if (vchat) vchat.onScriptLoad(gwtOnLoad);})();