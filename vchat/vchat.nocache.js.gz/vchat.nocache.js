function vchat(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='vchat',tb='__gwt_marker_vchat',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='5616A51BAF8DABAA91901B59706DBCF8',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};vchat.onScriptLoad=function(a){vchat=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
vchat();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '5616A51BAF8DABAA91901B59706DBCF8';function r(){}
function rj(){}
function sj(){}
function tj(){}
function Wf(){}
function Sf(){}
function Gb(){}
function Mc(){}
function Tc(){}
function _h(){}
function el(){}
function fl(){}
function gl(){}
function ll(){}
function ml(){}
function ql(){}
function ul(){}
function Rc(a){Qc()}
function jg(){jg=Sf}
function dh(){Vg(this)}
function I(a){this.g=a}
function J(a){this.g=a}
function Z(a){this.g=a}
function lb(a){this.g=a}
function yb(a){this.g=a}
function zb(a){this.g=a}
function Ab(a){this.g=a}
function Bb(a){this.g=a}
function lc(a){this.g=a}
function zg(a){this.g=a}
function Qg(a){this.g=a}
function Zh(a){this.g=a}
function fh(a){this.i=a}
function fk(a){this.g=a}
function ek(a){this.g=a}
function ik(a){this.g=a}
function jk(a){this.g=a}
function kk(a){this.g=a}
function mk(a){this.g=a}
function vk(a){this.g=a}
function wk(a){this.g=a}
function xk(a){this.g=a}
function yk(a){this.g=a}
function Gk(a){this.g=a}
function Hk(a){this.g=a}
function Ik(a){this.g=a}
function Jk(a){this.g=a}
function Vk(a){this.g=a}
function Wk(a){this.g=a}
function Xk(a){this.g=a}
function Yk(a){this.g=a}
function ai(a){this.g=a}
function Cj(a){this.g=a}
function Dj(a){this.g=a}
function Ej(a){this.g=a}
function Fj(a){this.g=a}
function bl(a){this.g=a}
function cl(a){this.g=a}
function dl(a){this.g=a}
function hl(a){this.g=a}
function il(a){this.g=a}
function jl(a){this.g=a}
function kl(a){this.g=a}
function yl(a){this.g=a}
function zl(a){this.g=a}
function Al(a){this.g=a}
function Bl(a){this.g=a}
function Cl(a){this.g=a}
function Il(a){this.g=a}
function Jl(a){this.g=a}
function rh(){this.g=zh()}
function Dh(){this.g=zh()}
function em(){ec(this.h)}
function cm(a){Jh(this,a)}
function fb(a){Yb((L(),a))}
function gb(a){Zb((L(),a))}
function jb(a){$b((L(),a))}
function B(a){--a.l;G(a)}
function fc(a){!!a&&a.O()}
function ic(a,b){Ng(a.l,b)}
function Aj(a,b){ic(a.h,b)}
function qi(a,b){pi(a,b)}
function rb(a,b){a.h=b}
function $h(a,b){a.g=b}
function ti(a,b){a.key=b}
function F(a,b){Ob(a.m,b.m)}
function M(a,b){Q(a);N(a,b)}
function Mk(a){a.m=2;ec(a.j)}
function ok(a){a.j=2;ec(a.h)}
function If(a){return a.h}
function am(){return this.h}
function bm(){return this.i}
function $l(){return this.g}
function _l(){return hi(this)}
function ig(a){rc.call(this,a)}
function Hg(a){rc.call(this,a)}
function gm(){mb(this.g.g)}
function L(){L=Sf;K=new H}
function tc(){tc=Sf;sc=new r}
function Jc(){Jc=Sf;Ic=new Mc}
function vh(){vh=Sf;uh=xh()}
function oc(a,b){a.h=b;nc(a,b)}
function ei(a,b){a.splice(b,1)}
function dc(a,b,c){Mg(a.l,b,c)}
function yj(a,b,c){dc(a.h,b,c)}
function Oh(a,b,c){b.P(a.g[c])}
function Yg(a,b){return a.g[b]}
function Uc(a,b){return sg(a,b)}
function fm(){return this.h.s<0}
function zh(){vh();return new uh}
function mg(a){lg(a);return a.v}
function Qk(a){mb(a.g);bb(a.h)}
function _k(a){!!a.h&&Aj(a.h,a)}
function $(a){dd(a,12)&&a.M()}
function Sb(a){Tb(a);!a.j&&Wb(a)}
function V(a){nb(a.l);return X(a)}
function cg(a,b){a.max=b;return a}
function dg(a,b){a.min=b;return a}
function Wh(a,b){a.eb(b);return a}
function Gi(a,b){a.src=b;return a}
function Tk(a){hb(a.h);return a.i}
function Ng(a,b){return qh(a.g,b)}
function Xh(a,b){$h(a,Wh(a.g,b))}
function Jh(a,b){while(a.pb(b));}
function xg(a,b){this.g=a;this.h=b}
function Ug(a,b){this.g=a;this.h=b}
function Eb(a){this.j=a;this.h=100}
function im(a){return 1==this.g.j}
function dm(){return Ag(this.h.j)}
function Og(a){return a.g.h+a.h.h}
function Bh(a,b){return a.g.get(b)}
function Qi(a,b){xg.call(this,a,b)}
function nj(a,b){xg.call(this,a,b)}
function zi(a,b){this.g=a;this.h=b}
function gk(a,b){this.g=a;this.h=b}
function hk(a,b){this.g=a;this.h=b}
function lk(a,b){this.g=a;this.h=b}
function nk(a,b){this.g=a;this.h=b}
function Zk(a,b){this.g=a;this.h=b}
function uj(){this.g=wi((ol(),nl))}
function Hl(){this.g=wi((sl(),rl))}
function Kl(){this.g=wi((wl(),vl))}
function zc(){zc=Sf;!!(Qc(),Pc)}
function Hc(){wc!=0&&(wc=0);yc=-1}
function cb(a){L();Zb(a);a.l=-2}
function Sj(a){Uj(a,(hb(a.h),!a.v))}
function jm(a){jc(new gk(this.g,a))}
function Dl(a){return Fl(new Hl,a)}
function jd(a){return a==null?null:a}
function Ub(a){return !a.j?a:Ub(a.j)}
function q(a,b){return jd(a)===jd(b)}
function A(a,b,c){v(a,new J(c),b)}
function ci(a,b,c){a.splice(b,0,c)}
function Li(a,b){a.value=b;return a}
function fg(a,b){a.video=b;return a}
function bg(a,b){a.ideal=b;return a}
function hg(a,b){a.width=b;return a}
function gg(a,b){a.height=b;return a}
function eg(a){a.audio=true;return a}
function Hi(a){a.width='32';return a}
function Gc(a){$wnd.clearTimeout(a)}
function Ih(a){return a!=null?u(a):0}
function Lg(a){return !a?null:a.kb()}
function Mg(a,b,c){return ph(a.g,b,c)}
function D(a,b,c){return w(a,c,2048,b)}
function C(a,b,c){w(a,new I(b),c,null)}
function di(a,b){bi(b,0,a,0,b.length)}
function Ci(a,b){a.onClick=b;return a}
function Ei(a,b){a.onSubmit=b;return a}
function Ii(a,b){a.onChange=b;return a}
function Bi(a,b){a.disabled=b;return a}
function Fi(a){a.height='32';return a}
function kb(a){this.i=new dh;this.h=a}
function li(){li=Sf;ii=new r;ki=new r}
function Lf(){Jf==null&&(Jf=[])}
function Vg(a){a.g=Wc(Zd,Ml,1,0,5,1)}
function R(){this.g=Wc(Zd,Ml,1,100,5,1)}
function hb(a){var b;Vb((L(),b=Qb,b),a)}
function qb(a){L();pb(a);tb(a,2,true)}
function hi(a){return a.$H||(a.$H=++gi)}
function Gg(a){return !a?'null':''+a.g}
function dd(a,b){return a!=null&&bd(a,b)}
function Dg(a,b){return a.charCodeAt(b)}
function ab(a){return !(!!a&&1==(a.i&7))}
function fd(a){return typeof a==='number'}
function hd(a){return typeof a==='string'}
function cc(a){return dd(a,32)?a.Q():null}
function ed(a){return typeof a==='boolean'}
function pi(a,b){for(var c in a){b(c)}}
function El(a,b){si(a.g,'b',b);return a}
function Fl(a,b){si(a.g,'a',b);return a}
function si(a,b,c){a.props[b]=c;return a}
function lg(a){if(a.v!=null){return}ug(a)}
function zj(a){C((L(),L(),K),new Fj(a),Wl)}
function $j(a){C((L(),L(),K),new mk(a),Wl)}
function ak(a){C((L(),L(),K),new jk(a),Wl)}
function bk(a){C((L(),L(),K),new ik(a),Wl)}
function ck(a){C((L(),L(),K),new kk(a),Wl)}
function sk(a){$(a.o);$(a.l);$(a.s);$(a.m)}
function Hb(a){2==(3&a.g)||(a.g=-4&a.g|2)}
function W(a){4==(a.l.i&7)&&tb(a.l,5,true)}
function jc(a){L();Qb?a.O():C((null,K),a,0)}
function rc(a){this.j=a;mc(this);this.U()}
function Vh(a,b){Sh.call(this,a);this.g=b}
function lh(){this.g=new rh;this.h=new Dh}
function Qc(){Qc=Sf;var a;!Sc();a=new Tc;Pc=a}
function Cg(){Cg=Sf;Bg=Wc(Wd,Ml,27,256,0,1)}
function Nb(a,b,c){c.g=-4&c.g|1;M(a.g[b],c)}
function Ac(a,b,c){return a.apply(b,c);var d}
function gd(a,b){return a&&b&&a instanceof b}
function th(a,b){var c;c=a[Tl];c.call(a,b)}
function Zj(a,b){C((L(),L(),K),new lk(a,b),Wl)}
function Uj(a,b){C((L(),L(),K),new hk(a,b),Wl)}
function _j(a,b){C((L(),L(),K),new nk(a,b),Wl)}
function Ob(a,b){Nb(a,((b.g&229376)>>15)-1,b)}
function ob(a,b){eb(b,a);b.i.g.length>0||(b.g=4)}
function Wg(a,b){a.g[a.g.length]=b;return true}
function mc(a){a.m&&a.h!==Ql&&a.U();return a}
function Ji(a){a.placeholder='Room id';return a}
function pg(a){var b;b=og(a);wg(a,b);return b}
function rg(a){var b;b=og(a);b.u=a;b.l=1;return b}
function Gh(a,b,c){this.g=a;this.h=b;this.i=c}
function H(){this.m=new Pb;this.g=new Eb(this.m)}
function hh(a){return new Vh(null,gh(a,a.length))}
function Th(a){Rh(a);return new Vh(a,new Yh(a.g))}
function Db(a){while(true){if(!Cb(a)){break}}}
function Mh(a,b){while(a.i<a.j){Oh(a,b,a.i++)}}
function Ah(a,b){return !(a.g.get(b)===undefined)}
function gh(a,b){return Kh(b,a.length),new Ph(a,b)}
function Lk(a,b){jc(new Zk(a,b.length==0?null:b))}
function Nc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function $g(a,b){var c;c=a.g[b];ei(a.g,b);return c}
function Sg(a){var b;b=a.g.hb();a.h=Rg(a);return b}
function Fb(a){if(!a.g){a.g=true;B((L(),L(),K))}}
function qk(a){if(0==a.j){a.j=1;a.i.forceUpdate()}}
function Ok(a){if(0==a.m){a.m=1;a.l.forceUpdate()}}
function oi(){if(ji==256){ii=ki;ki=new r;ji=0}++ji}
function _f(a,b,c,d){a.addEventListener(b,c,d)}
function ag(a,b,c,d){a.removeEventListener(b,c,d)}
function ah(a,b,c){var d;d=a.g[b];a.g[b]=c;return d}
function Rj(a,b){var c;c=a.v;if(b!=c){a.v=b;gb(a.h)}}
function Tj(a,b){var c;c=a.u;if(b!=c){a.u=b;gb(a.g)}}
function Vj(a,b){var c;c=a.A;if(b!=c){a.A=b;gb(a.i)}}
function Wj(a,b){var c;c=a.B;if(b!=c){a.B=b;gb(a.j)}}
function Yj(a,b){var c;c=a.F;if(b!=c){a.F=b;gb(a.s)}}
function Rk(a,b){var c;c=a.i;if(b!=c){a.i=b;gb(a.h)}}
function Lh(a,b){this.i=a;this.h=(b&64)!=0?b|16384:b}
function Pg(a,b){if(b){return Kg(a.g,b)}return false}
function Di(a,b){a.type=b.g!=null?b.g:''+b.h;return a}
function P(a){return a.i?a.g.length-a.h+a.j:a.j-a.h}
function Yc(a){return Array.isArray(a)&&a.xb===Wf}
function cd(a){return !Array.isArray(a)&&a.xb===Wf}
function tk(a){return D((L(),L(),K),a.g,new yk(a))}
function Dk(a){return D((L(),L(),K),a.g,new Jk(a))}
function Sk(a){return D((L(),L(),K),a.g,new Wk(a))}
function kh(a,b){return jd(a)===jd(b)||a!=null&&s(a,b)}
function Qh(a){if(!a.h){Rh(a);a.i=true}else{Qh(a.h)}}
function Sh(a){if(!a){this.h=null;new dh}else{this.h=a}}
function Yh(a){Lh.call(this,a.nb(),a.mb()&-6);this.g=a}
function xb(a){vb.call(this,a,new yb(a),null,304611328)}
function ib(a){var b;L();!!Qb&&!!Qb.l&&Vb((b=Qb,b),a)}
function qg(a,b){var c;c=og(a);wg(a,c);c.l=b?8:0;return c}
function pc(a,b){var c;c=mg(a.vb);return b==null?c:c+': '+b}
function ac(a,b){Qb=new _b(Qb,b);a.j=false;Rb(Qb);return Qb}
function tg(a){if(a.cb()){return null}var b=a.u;return Of[b]}
function Uf(a){function b(){}
;b.prototype=a||{};return new b}
function ol(){ol=Sf;var a;nl=(a=Tf(ml.prototype.ub,ml,[]),a)}
function sl(){sl=Sf;var a;rl=(a=Tf(ql.prototype.ub,ql,[]),a)}
function wl(){wl=Sf;var a;vl=(a=Tf(ul.prototype.ub,ul,[]),a)}
function Ri(){Pi();return Zc(Uc(Ee,1),Ml,29,0,[Mi,Ni,Oi])}
function Fc(a){zc();$wnd.setTimeout(function(){throw a},0)}
function Rh(a){if(a.h){Rh(a.h)}else if(a.i){throw If(new yg)}}
function Rb(a){if(a.l){2==(a.l.i&7)||tb(a.l,4,true);pb(a.l)}}
function _b(a,b){this.g=(L(),L(),K).h++;this.j=a;this.l=b}
function Ph(a,b){this.i=0;this.j=b;this.h=17488;this.g=a}
function nh(a,b){var c;c=a.g.get(b);return c==null?new Array:c}
function sg(a,b){var c=a.g=a.g||[];return c[b]||(c[b]=a.Z(b))}
function Qf(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function oh(a,b){var c;return mh(b,nh(a,b==null?0:(c=u(b),c|0)))}
function eh(a){Vg(this);di(this.g,Jg(a,Wc(Zd,Ml,1,Og(a.g),5,1)))}
function wj(a){ag(($f(),$wnd.goog.global.window),Vl,a.i,false)}
function vj(a){_f(($f(),$wnd.goog.global.window),Vl,a.i,false)}
function Ek(a){Uj(a.i.props['b'],false);Uj(a.i.props['c'],false)}
function Nh(a,b){if(a.i<a.j){Oh(a,b,a.i++);return true}return false}
function hm(a,b,c){return jg(),(a.enabled=!a.enabled)?true:false}
function yi(a,b,c){!q(c,'key')&&!q(c,'ref')&&(a[c]=b[c],undefined)}
function Dc(a,b,c){var d;d=Bc();try{return Ac(a,b,c)}finally{Ec(d)}}
function Gj(a,b){b.onended=Tf(kl.prototype.Y,kl,[a]);return null}
function Kk(a,b){b.preventDefault();C((L(),L(),K),new Xk(a),Wl)}
function bb(a){if(-2!=a.l){C((L(),L(),K),new lb(a),0);!!a.h&&mb(a.h)}}
function hc(a){fc(a.o);!!a.l&&gc(a);$(a.g);$(a.i);fc(a.h);fc(a.m)}
function Ec(a){a&&Lc((Jc(),Ic));--wc;if(a){if(yc!=-1){Gc(yc);yc=-1}}}
function Jb(b){try{nb(b.h.g)}catch(a){a=Hf(a);if(!dd(a,6))throw If(a)}}
function sh(a){this.l=a;this.h=this.l.g.entries();this.g=new Array}
function Eh(a){this.j=a;this.h=this.j.g.entries();this.g=this.h.next()}
function pl(a){$wnd.React.Component.call(this,a);this.g=new uk(this)}
function tl(a){$wnd.React.Component.call(this,a);this.g=new Fk(this)}
function xl(a){$wnd.React.Component.call(this,a);this.g=new Uk(this)}
function vc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Cc(b){zc();return function(){return Dc(b,this,arguments);var a}}
function qc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Uh(a,b){var c;Qh(a);c=new _h;c.g=b;a.g.ob(new ai(c));return c.g}
function ri(a,b,c,d){var e;e={};e['autoPlay']=a;e[b]=c;e['id']=d;return e}
function Wc(a,b,c,d,e,f){var g;g=Xc(e,d);e!=10&&Zc(Uc(a,f),b,c,e,g);return g}
function Mb(a){var b,c;b=0;for(c=0;c<a.g.length;c++){b+=P(a.g[c])}return b}
function Zg(a,b,c){for(;c<a.g.length;++c){if(kh(b,a.g[c])){return c}}return -1}
function N(a,b){a.g[a.j]=b;++a.j;if(a.j>=a.g.length){a.j=0;a.i=true}}
function db(a,b){var c,d;Wg(a.i,b);d=(c=b.i&7,c>3?c:4);a.g>d&&(a.g=d)}
function Xg(a,b){var c,d,e,f;for(d=a.g,e=0,f=d.length;e<f;++e){c=d[e];b.P(c)}}
function Pb(){var a;this.g=Wc(pd,Ml,43,5,0,1);for(a=0;a<5;a++){this.g[a]=new R}}
function Tg(a){this.j=a;this.i=new Eh(this.j.h);this.g=this.i;this.h=Rg(this)}
function Pj(a){mb(a.l);bb(a.m);bb(a.j);bb(a.i);bb(a.h);bb(a.g);bb(a.s);bb(a.o)}
function T(a){if(!a.g){a.g=true;a.v=null;a.h=null;bb(a.j);2==(a.l.i&7)||mb(a.l)}}
function G(a){if(a.j&&a.l==0){if(!a.i){a.i=true;try{Db(a.g)}finally{a.i=false}}}}
function Fh(a){if(a.g.i!=a.i){return Bh(a.g,a.h.value[0])}return a.h.value[1]}
function X(a){if(a.h){if(dd(a.h,9)){throw If(a.h)}else{throw If(a.h)}}return a.v}
function sb(b){if(b){try{b.O()}catch(a){a=Hf(a);if(dd(a,6)){L()}else throw If(a)}}}
function ec(a){if(a.s>=0){a.s=-2;w((L(),L(),K),new I(new lc(a)),67108864,null)}}
function _g(a,b){var c;c=Zg(a,b,0);if(c==-1){return false}ei(a.g,c);return true}
function Qj(a,b){var c;c=a.D;if(!(jd(b)===jd(c)||b!=null&&s(b,c))){a.D=b;gb(a.o)}}
function Xj(a,b){var c;c=a.C;if(!(jd(b)===jd(c)||b!=null&&s(b,c))){a.C=b;gb(a.m)}}
function Kc(a){var b,c;if(a.g){c=null;do{b=a.g;a.g=null;c=Oc(b,c)}while(a.g);a.g=c}}
function Lc(a){var b,c;if(a.h){c=null;do{b=a.h;a.h=null;c=Oc(b,c)}while(a.h);a.h=c}}
function Vb(a,b){var c;if(a.l){c=a.g;if(b.l!=c){b.l=c;!a.h&&(a.h=new dh);Wg(a.h,b)}}}
function fi(a,b){return Vc(b)!=10&&Zc(t(b),b.wb,b.__elementTypeId$,Vc(b),a),a}
function Vc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function kd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function yg(){rc.call(this,"Stream already terminated, can't be modified or used")}
function $f(){$f=Sf;Yf=$wnd.goog.global.document;Zf=$wnd.goog.global.navigator}
function Pi(){Pi=Sf;Mi=new Qi(Ul,0);Ni=new Qi('reset',1);Oi=new Qi('submit',2)}
function og(a){var b;b=new ng;b.v='Class$'+(a?'S'+a:''+b.o);b.h=b.v;b.s=b.v;return b}
function Xb(a,b){var c;if(!a.i){c=Ub(a);!c.i&&(c.i=new dh);a.i=c.i}b.j=true;Wg(a.i,b)}
function wg(a,b){var c;if(!a){return}b.u=a;var d=tg(b);if(!d){Of[a]=[b];return}d.vb=b}
function Tf(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function ui(a,b,c,d){var e;e=vi($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function wi(a){var b;b=vi($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function ih(a){var b,c,d;d=0;for(c=new Tg(a.g);c.h;){b=Sg(c);d=d+(b?u(b):0);d=d|0}return d}
function Ig(a,b){var c,d;for(d=new Tg(b.g);d.h;){c=Sg(d);if(!Pg(a,c)){return false}}return true}
function pb(a){var b,c;for(c=new fh(a.h);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);b.g=4}}
function Hj(a){var b,c;b=(hb(a.m),a.C);c=(hb(a.o),a.D);null!=b&&null!=c&&(c.srcObject=b)}
function uc(a){tc();mc(this);this.h=a;nc(this,a);this.j=a==null?'null':Vf(a);this.g=a}
function Kf(){Lf();var a=Jf;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function bc(){var a;try{Sb(Qb);L()}finally{a=Qb.j;!a&&((L(),L(),K).j=true);Qb=Qb.j}}
function Xf(){$wnd.ReactDOM.render((new uj).g,($f(),Yf).getElementById('app'),null)}
function Kb(a,b){this.h=a;this.g=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:Ol)|(0==(c&6291456)?!a?2097152:4194304:0)|0|0|0)}
function Jj(a,b){Xj(a,b);Wj(a,null);Vj(a,null);b.getTracks().forEach(Tf(jl.prototype.W,jl,[a]))}
function Kh(a,b){if(0>a||a>b){throw If(new ig('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Rg(a){if(a.g.gb()){return true}if(a.g!=a.i){return false}a.g=new sh(a.j.g);return a.g.gb()}
function Hf(a){var b;if(dd(a,6)){return a}b=a&&a.__java$exception;if(!b){b=new uc(a);Rc(b)}return b}
function pk(a){var b,c;a.j=0;qj();c=(b=U(a.o.g),b.length==0?(new Kl).g:Gl(El(Dl(a.m),a.l),a.s));return c}
function Ch(a,b,c){var d;d=a.g.get(b);a.g.set(b,c===undefined?null:c);d===undefined?++a.h:++a.i;return d}
function Zc(a,b,c,d,e){e.vb=a;e.wb=b;e.xb=Wf;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function kc(a,b,c,d){this.j=a;this.l=d?new lh:null;this.o=b;this.h=c;this.m=null;this.g=null;this.i=null}
function ng(){this.o=kg++;this.v=null;this.s=null;this.m=null;this.j=null;this.h=null;this.u=null;this.g=null}
function Y(a,b){this.m=a;this.o=b;this.s=null;this.v=null;this.u=false;this.l=new xb(this);this.j=new kb(this.l)}
function Nf(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function mh(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(kh(a,c.jb())){return c}}return null}
function Ag(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Cg(),Bg)[b];!c&&(c=Bg[b]=new zg(a));return c}return new zg(a)}
function Vf(a){var b;if(Array.isArray(a)&&a.xb===Wf){return mg(t(a))+'@'+(b=u(a)>>>0,b.toString(16))}return a.toString()}
function Nj(a){var b;Yj(a,(hb(a.s),!a.F));b=(hb(a.m),a.C);null!=b&&b.getVideoTracks().forEach(Tf(gl.prototype.W,gl,[]))}
function Mj(a){var b;Tj(a,(hb(a.g),!a.u));b=(hb(a.m),a.C);null!=b&&b.getAudioTracks().forEach(Tf(fl.prototype.W,fl,[]))}
function qj(){if(!pj){pj=(++(L(),L(),K).l,new Gb);$wnd.Promise.resolve(null).then(Tf(rj.prototype.X,rj,[]))}}
function mb(a){if(2<(a.i&7)){w((L(),L(),K),new I(new Ab(a)),67108864,null);!!a.g&&T(a.g);Hb(a.m);a.i=a.i&-8|1}}
function Ib(a){if(1==(3&a.g)){a.g=-4&a.g|0;0==(a.g&Ol)?Jb(a):nb(a.h.g);0!=(a.g&524288)&&(2==(3&a.g)||(a.g=-4&a.g|2))}}
function eb(a,b){var c,d;d=a.i;_g(d,b);!!a.h&&Ol!=(a.h.i&1835008)&&a.i.g.length<=0&&0==a.h.g.i&&(a.j||Xb((L(),c=Qb,c),a))}
function Wb(a){var b;if(a.i){while(a.i.g.length!=0){b=$g(a.i,a.i.g.length-1);b.j=false;b.i.g.length>0||(b.h.i&7)>3&&tb(b.h,3,true)}}}
function Lb(a){var b,c,d;for(b=0;b<a.g.length;b++){d=a.g[b];if(0!=(d.i?d.g.length-d.h+d.j:d.j-d.h)){c=O(d);return c}}return null}
function jh(a){var b,c,d;d=1;for(c=new fh(a);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=31*d+(b!=null?u(b):0);d=d|0}return d}
function ni(a){li();var b,c,d;c=':'+a;d=ki[c];if(d!=null){return kd(d)}d=ii[c];b=d==null?mi(a):kd(d);oi();ki[c]=b;return b}
function bh(a,b){var c,d;d=a.g.length;b.length<d&&(b=fi(new Array(d),b));for(c=0;c<d;++c){b[c]=a.g[c]}b.length>d&&(b[d]=null);return b}
function vg(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function t(a){return hd(a)?_d:fd(a)?Rd:ed(a)?Pd:cd(a)?a.vb:Yc(a)?a.vb:a.vb||Array.isArray(a)&&Uc(Id,1)||Id}
function u(a){return hd(a)?ni(a):fd(a)?kd(a):ed(a)?a?1231:1237:cd(a)?a.K():Yc(a)?hi(a):!!a&&!!a.hashCode?a.hashCode():hi(a)}
function s(a,b){return hd(a)?q(a,b):fd(a)?jd(a)===jd(b):ed(a)?jd(a)===jd(b):cd(a)?a.I(b):Yc(a)?q(a,b):!!a&&!!a.equals?a.equals(b):jd(a)===jd(b)}
function oj(){mj();return Zc(Uc(Fe,1),Ml,7,0,[Si,Ti,Ui,Vi,Wi,Xi,Yi,Zi,$i,_i,aj,bj,cj,dj,ej,fj,gj,hj,ij,jj,kj,lj])}
function Fk(a){var b;this.i=a;L();b=++Ck;this.h=new kc(b,new Hk(this),new Gk(this),false);this.g=new wb(null,new Ik(this),Yl)}
function Bj(){var a;this.i=new dl(this);L();a=++xj;this.h=new kc(a,null,new Cj(this),true);this.g=new Y(new Dj(this),new Ej(this))}
function al(a){var b;this.h=a;L();b=++$k;this.g=new kc(b,new bl(this),null,true);!!this.h&&yj(this.h,this,new cl(this));G((null,K))}
function Bc(){var a;if(wc!=0){a=vc();if(a-xc>2000){xc=a;yc=$wnd.setTimeout(Hc,10)}}if(wc++==0){Kc((Jc(),Ic));return true}return false}
function Sc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function Gl(a,b){var c;si(a.g,'c',b);return c=a.g.props,ti(a.g,Gg(cc(c['a']))+'-'+Gg(cc(c['b']))+'-'+Gg(cc(c['c']))+(lg(Df),Df.v)),a.g}
function gc(a){var b,c,d;for(c=new fh(new eh(new Qg(a.l)));c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.jb();dd(d,12)&&d.N()||b.kb().O()}}
function Zb(a){var b,c,d;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new fh(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.i.g.length>0&&4==a.g){a.g=5;for(c=new fh(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;4==d&&tb(b,5,true)}}}
function Lj(a,b){var c;Xj(a,null);if(gd(b,$wnd.DOMException)){c=b;Wj(a,c.name);Vj(a,c.message)}else{Wj(a,mg(t(b)));Vj(a,b==null?'null':Vf(b))}}
function bd(a,b){if(hd(a)){return !!ad[b]}else if(a.wb){return !!a.wb[b]}else if(fd(a)){return !!_c[b]}else if(ed(a)){return !!$c[b]}return false}
function Ai(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function O(a){var b;if(0==(a.i?a.g.length-a.h+a.j:a.j-a.h)){return null}b=a.g[a.h];a.g[a.h]=null;++a.h;if(a.h>=a.g.length){a.h=0;a.i=false}return b}
function U(a){a.u?ib(a.j):hb(a.j);if(ub(a.l)){if(a.u&&(L(),!(!!Qb&&!!Qb.l))){return w((L(),L(),K),new Z(a),83888128,null)}else{nb(a.l)}}return X(a)}
function Fg(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Jg(a,b){var c,d,e,f;f=Og(a.g);b.length<f&&(b=fi(new Array(f),b));e=b;d=new Tg(a.g);for(c=0;c<f;++c){e[c]=Sg(d)}b.length>f&&(b[f]=null);return b}
function Uk(a){var b,c,d;this.l=a;L();b=++Pk;this.j=new kc(b,null,new Vk(this),false);this.h=(d=new kb((c=null,c)),d);this.g=new wb(null,new Yk(this),Yl)}
function Xc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function v(b,c,d){var e,f;try{ac(b,d);try{f=(c.g.O(),null)}finally{bc()}return f}catch(a){a=Hf(a);if(dd(a,6)){e=a;throw If(e)}else throw If(a)}finally{G(b)}}
function w(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.L()}else{ac(b,e);try{g=c.L()}finally{bc()}}return g}catch(a){a=Hf(a);if(dd(a,6)){f=a;throw If(f)}else throw If(a)}finally{G(b)}}
function Kj(a){var b;b=(hb(a.m),a.C);Xj(a,null);Wj(a,null);Vj(a,null);C((L(),L(),K),new hk(a,false),Wl);null!=b&&b.getTracks().forEach(Tf(ll.prototype.W,ll,[]))}
function Ij(a,b){var c;Rj(a,b);c=(hb(a.m),a.C);b?null==c&&a.H.qb().then(Tf(hl.prototype.X,hl,[a])).catch(Tf(il.prototype.X,il,[a])):null!=c&&c.getTracks().forEach(Tf(el.prototype.W,el,[]))}
function Yb(a){var b,c;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new fh(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);5==(b.i&7)?tb(b,6,true):4==(b.i&7)&&(a.g=4)}}}
function Cb(a){var b,c;if(0==a.i){b=Mb(a.j);if(0==b){a.g=0;return false}else if(a.g+1>a.h){a.g=0;return false}else{a.g=a.g+1;a.i=b}}--a.i;c=Lb(a.j);Ib(c);return true}
function Mf(b,c,d,e){Lf();var f=Jf;$moduleName=c;$moduleBase=d;Gf=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Ll(g)()}catch(a){b(c,a)}}else{Ll(g)()}}
function vi(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function xh(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return yh()}}
function Pf(){Of={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Oc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].yb()&&(c=Nc(c,g)):g[0].yb()}catch(a){a=Hf(a);if(dd(a,6)){d=a;zc();Fc(dd(d,34)?d.V():d)}else throw If(a)}}return c}
function ph(a,b,c){var d,e,f,g,h;h=(g=hi(b),g|0);e=(d=a.g.get(h),d==null?new Array:d);if(e.length==0){a.g.set(h,e)}else{f=mh(b,e);if(f){return f.lb(c)}}e[e.length]=new Ug(b,c);++a.h;return null}
function bi(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function uk(a){var b;this.o=new Bj;this.l=new dk(new sj);this.s=new dk(new tj);this.m=new al(this.o);this.i=a;L();b=++rk;this.h=new kc(b,new vk(this),new wk(this),false);this.g=new wb(null,new xk(this),Yl)}
function mi(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Dg(a,c++)}b=b|0;return b}
function nb(b){var c;if(1!=(b.i&7)){try{if(4!=(b.i&7)){if(0!=(b.i&512)){!!b.l&&(b.i&=-513);c=b.j;A((L(),L(),K),b,c)}else{b.l.O()}}else 0!=(b.i&512)&&!!b.l&&(b.i&=-513)}catch(a){a=Hf(a);if(dd(a,6)){L()}else throw If(a)}}}
function Q(a){var b,c,d,e,f,g;b=a.i?a.g.length-a.h+a.j:a.j-a.h;if(b+1>a.g.length){g=(a.g.length-1)*2+1;c=Wc(Zd,Ml,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.h+d)%a.g.length;c[f]=a.g[e];a.g[e]=null;++f}a.g=c;a.h=0;a.j=f;a.i=false}}
function qh(a,b){var c,d,e,f,g,h;g=!b?0:(f=hi(b),f|0);d=(c=a.g.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(kh(b,e.jb())){if(d.length==1){d.length=0;th(a.g,g)}else{d.splice(h,1)}--a.h;return e.kb()}}return null}
function vb(a,b,c,d){this.h=new dh;this.m=new Kb(new zb(this),d&6520832|262144|Ol);this.i=d&-6520833|3;this.g=a;this.j=b;this.l=c;!!this.j&&(this.i|=512);!this.g&&!!this.j&&(F((L(),L(),K),this),0==(this.m.g&2097152)&&G((null,K)))}
function Rf(a,b,c){var d=Of,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Of[b]),Uf(h));_.wb=c;!b&&(_.xb=Wf);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.vb=f)}
function ug(a){if(a.bb()){var b=a.i;b.cb()?(a.v='['+b.u):!b.bb()?(a.v='[L'+b._()+';'):(a.v='['+b._());a.h=b.$()+'[]';a.s=b.ab()+'[]';return}var c=a.m;var d=a.j;d=d.split('/');a.v=vg('.',[c,vg('$',d)]);a.h=vg('.',[c,vg('.',d)]);a.s=d[d.length-1]}
function Kg(a,b){var c,d,e;c=b.jb();e=b.kb();d=hd(c)?c==null?Lg(oh(a.g,null)):Bh(a.h,c):Lg(oh(a.g,c));if(!(jd(e)===jd(d)||e!=null&&s(e,d))){return false}if(d==null&&!(hd(c)?c==null?!!oh(a.g,null):Ah(a.h,c):!!oh(a.g,c))){return false}return true}
function S(b){var c,d,e,f;f=b.v;try{e=(d=($f(),$wnd.goog.global.window).location.hash,null==d?'':d.substr(1));if(!(f==e||f!=null&&q(f,e))){b.v=e;b.h=null;fb(b.j)}}catch(a){a=Hf(a);if(dd(a,10)){c=a;if(!b.h){b.v=null;b.h=c;fb(b.j)}throw If(c)}else throw If(a)}}
function xi(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;qi(b,Tf(zi.prototype.rb,zi,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return ui(a,e,f,d)}
function ub(b){var c,d,e,f,g;g=b.i&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new fh(b.h);e.g<e.i.g.length;){d=(e.h=e.g++,e.i.g[e.h]);if(d.h){f=d.h;c=f.g;try{U(c)}catch(a){a=Hf(a);if(!dd(a,6))throw If(a)}if(6==(b.i&7)){return true}}}}}pb(b);return false}
function nc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.T();return a&&a.R()}},suppressed:{get:function(){return c.S()}}})}catch(a){}}}
function wh(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function Nk(a){var b,c;a.m=0;qj();b=(c=(hb(a.h),a.i),xi('div',Ai(new $wnd.Object,Zc(Uc(_d,1),Ml,2,6,['enter-room-container'])),[xi('form',Ei(new $wnd.Object,Tf(Il.prototype.sb,Il,[a])),[xi('input',Ii(Li(Ji(Di(new $wnd.Object,(mj(),ij))),c),Tf(Jl.prototype.sb,Jl,[a])),null),xi(Ul,Bi(Di(new $wnd.Object,(Pi(),Oi)),null==c),['Enter'])])]));return b}
function tb(a,b,c){var d,e,f,g;g=a.i&7;if(b!=g){a.i=a.i&-8|b;if(!a.g&&6==b){c&&(1==(a.i&7)||1==(3&a.m.g)||F((L(),L(),K),a))}else if(!!a.g&&4==g&&(6==b||5==b)){jb(a.g.j);sb((e=a.g.s,e));c&&(1==(a.i&7)||1==(3&a.m.g)||F((L(),L(),K),a))}else if(3==b||3!=g&&2==b){if(a.g){d=a.g;sb((e=d.o,e));d.v=null}Xg(a.h,new Bb(a));a.h.g=Wc(Zd,Ml,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.g&&sb((f=a.g.m,f))}}
function dk(a){var b,c,d,e,f,g,h,i,j,k,l,m,n,o,p;this.H=a;L();b=++Oj;this.G=new kc(b,null,new ek(this),true);this.v=false;this.u=true;this.F=true;this.m=(k=new kb((d=null,d)),k);this.j=(l=new kb((e=null,e)),l);this.i=(m=new kb((f=null,f)),m);this.h=(n=new kb((g=null,g)),n);this.g=(o=new kb((h=null,h)),o);this.s=(p=new kb((i=null,i)),p);this.o=(j=new kb((c=null,c)),j);this.l=new wb(new fk(this),null,404750336);G((null,K))}
function mj(){mj=Sf;Si=new nj(Ul,0);Ti=new nj('checkbox',1);Ui=new nj('color',2);Vi=new nj('date',3);Wi=new nj('datetime',4);Xi=new nj('email',5);Yi=new nj('file',6);Zi=new nj('hidden',7);$i=new nj('image',8);_i=new nj('month',9);aj=new nj('number',10);bj=new nj('password',11);cj=new nj('radio',12);dj=new nj('range',13);ej=new nj('reset',14);fj=new nj('search',15);gj=new nj('submit',16);hj=new nj('tel',17);ij=new nj('text',18);jj=new nj('time',19);kj=new nj('url',20);lj=new nj('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.l){return}j=(n=a.l.i&7,n>3?n:4);e=false;c=0;if(!!a.h&&1!=(a.l.i&7)){m=a.h.g.length;for(h=0;h<m;h++){k=Yg(a.h,h);if(-1!=k.l&&-2!=k.l){k.l=-1;h!=c&&ah(a.h,c,k);++c;if(k.h){l=k.h;f=l.i&7;f==6&&(j=f)}}}}d=a.l.h;for(i=d.g.length-1;i>=0;i--){k=d.g[i];if(-1==k.l){k.l=0}else{eb(k,a.l);e=true}}2<(a.l.i&7)&&4!=j&&(a.l.i&7)<j&&tb(a.l,j,false);if(a.h){for(g=c-1;g>=0;g--){k=Yg(a.h,g);if(-1==k.l){k.l=0;db(k,a.l);e=true}}}if(a.h){for(g=a.h.g.length-1;g>=c;g--){$g(a.h,g)}e&&rb(a.l,a.h)}else{e&&rb(a.l,new dh)}if(ab(a.l)&&!!a.l.g){b=a.l.g;k=b.j;!!k.h&&Ol!=(k.h.i&1835008)&&k.i.g.length<=0&&0==k.h.g.i&&Xb(a,k)}}
function yh(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Tl]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!wh()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Tl]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function Ak(a){var b,c,d,e,f,g,h,i;a.j=0;qj();c=a.i.props['a'];if(!!c&&c.g.s<0){return null}b=a.i.props['b'];if(!!b&&b.G.s<0){return null}d=a.i.props['c'];if(!!d&&d.G.s<0){return null}e=(f=a.i.props['b'],g=a.i.props['c'],h=Tf(yl.prototype.P,yl,[f]),i=Tf(zl.prototype.P,zl,[g]),xi('div',Ai(new $wnd.Object,Zc(Uc(_d,1),Ml,2,6,['video-wrapper'])),[xi('div',Ai(new $wnd.Object,Zc(Uc(_d,1),Ml,2,6,['local-video-wrapper'])),[ui('video',null,h,ri(true,'muted',true,'localVideo')),(hb(g.h),g.v?ui('video',null,i,ri(true,'muted',true,'screenShareVideo')):null)]),ui('video',null,null,ri(true,'className','hide','remoteVideo')),xi('div',Ai(new $wnd.Object,Zc(Uc(_d,1),Ml,2,6,['controls'])),[xi(Ul,Ci(Ai(new $wnd.Object,Zc(Uc(_d,1),Ml,2,6,[Zl])),Tf(Al.prototype.tb,Al,[g])),[xi('img',Fi(Hi(Gi(new $wnd.Object,(hb(g.h),g.v?'img/screen_share_on.svg':'img/screen_share_off.svg')))),null)]),xi(Ul,Ci(Ai(new $wnd.Object,Zc(Uc(_d,1),Ml,2,6,[Zl])),Tf(Bl.prototype.tb,Bl,[f])),[xi('img',Fi(Hi(Gi(new $wnd.Object,(hb(f.g),f.u?'img/mic_on.svg':'img/mic_off.svg')))),null)]),xi(Ul,Ci(Ai(new $wnd.Object,Zc(Uc(_d,1),Ml,2,6,[Zl])),Tf(Cl.prototype.tb,Cl,[f])),[xi('img',Fi(Hi(Gi(new $wnd.Object,(hb(f.s),f.F?'img/cam_on.svg':'img/cam_off.svg')))),null)])]),null,xi('div',Ai(new $wnd.Object,Zc(Uc(_d,1),Ml,2,6,['status'])),[xi('p',null,['Waiting for someone...'])])]));return e}
var Ml={4:1},Nl={12:1},Ol=1048576,Pl={8:1},Ql='__noinit__',Rl={4:1,10:1,9:1,6:1},Sl={36:1},Tl='delete',Ul='button',Vl='hashchange',Wl=142606336,Xl={12:1,32:1},Yl=1411518464,Zl='control-btn';var _,Of,Jf,Gf=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Pf();Rf(1,null,{},r);_.I=function(a){return q(this,a)};_.J=function(){return this.vb};_.K=_l;_.equals=function(a){return this.I(a)};_.hashCode=function(){return this.K()};var $c,_c,ad;Rf(50,1,{},ng);_.Z=function(a){var b;b=new ng;b.l=4;a>1?(b.i=sg(this,a-1)):(b.i=this);return b};_.$=function(){lg(this);return this.h};_._=function(){return mg(this)};_.ab=function(){lg(this);return this.s};_.bb=function(){return (this.l&4)!=0};_.cb=function(){return (this.l&1)!=0};_.l=0;_.o=0;var kg=1;var Zd=pg(1);var Qd=pg(50);Rf(96,1,{},H);_.h=1;_.i=false;_.j=true;_.l=0;var od=pg(96);Rf(39,1,{},I);_.L=function(){return this.g.O(),null};var md=pg(39);Rf(97,1,{},J);var nd=pg(97);var K;Rf(43,1,{43:1},R);_.h=0;_.i=false;_.j=0;var pd=pg(43);Rf(173,1,Nl);var sd=pg(173);Rf(106,173,Nl,Y);_.M=function(){T(this)};_.N=$l;_.g=false;_.i=0;_.u=false;var rd=pg(106);Rf(107,1,{},Z);_.L=function(){return V(this.g)};var qd=pg(107);Rf(16,173,{12:1,16:1},kb);_.M=function(){bb(this)};_.N=function(){return -2==this.l};_.g=4;_.j=false;_.l=0;var ud=pg(16);Rf(105,1,Pl,lb);_.O=function(){cb(this.g)};var td=pg(105);Rf(18,173,{12:1,18:1},wb,xb);_.M=function(){mb(this)};_.N=function(){return 1==(this.i&7)};_.i=0;var zd=pg(18);Rf(99,1,{},yb);_.O=function(){S(this.g)};var vd=pg(99);Rf(100,1,Pl,zb);_.O=function(){nb(this.g)};var wd=pg(100);Rf(101,1,Pl,Ab);_.O=function(){qb(this.g)};var xd=pg(101);Rf(102,1,{},Bb);_.P=function(a){ob(this.g,a)};var yd=pg(102);Rf(136,1,{},Eb);_.g=0;_.h=0;_.i=0;var Ad=pg(136);Rf(111,1,Nl,Gb);_.M=function(){Fb(this)};_.N=$l;_.g=false;var Bd=pg(111);Rf(54,173,{12:1,54:1},Kb);_.M=function(){Hb(this)};_.N=function(){return 2==(3&this.g)};_.g=0;var Dd=pg(54);Rf(135,1,{},Pb);var Cd=pg(135);Rf(117,1,{},_b);_.g=0;var Qb;var Ed=pg(117);Rf(23,1,Nl,kc);_.M=function(){ec(this)};_.N=function(){return this.s<0};_.j=0;_.s=0;var Gd=pg(23);Rf(98,1,Pl,lc);_.O=function(){hc(this.g)};var Fd=pg(98);Rf(6,1,{4:1,6:1});_.R=am;_.S=function(){var a,b;return a=Uh(Th(hh((this.l==null&&(this.l=Wc(ae,Ml,6,0,0,1)),this.l))),(b=new dh,b)),bh(a,Wc(Zd,Ml,1,a.g.length,5,1))};_.T=bm;_.U=function(){oc(this,qc(new Error(pc(this,this.j))));Rc(this)};_.h=Ql;_.m=true;var ae=pg(6);Rf(10,6,{4:1,10:1,6:1});var Td=pg(10);Rf(9,10,Rl);var $d=pg(9);Rf(66,9,Rl);var Xd=pg(66);Rf(67,66,Rl);var Kd=pg(67);Rf(34,67,{34:1,4:1,10:1,9:1,6:1},uc);_.V=function(){return jd(this.g)===jd(sc)?null:this.g};var sc;var Hd=pg(34);var Id=pg(0);Rf(157,1,{});var Jd=pg(157);var wc=0,xc=0,yc=-1;Rf(73,157,{},Mc);var Ic;var Ld=pg(73);var Pc;Rf(168,1,{});var Nd=pg(168);Rf(68,168,{},Tc);var Md=pg(68);var Yf,Zf;Rf(70,9,Rl);var Vd=pg(70);Rf(103,70,Rl,ig);var Od=pg(103);$c={4:1,26:1};var Pd=pg(167);Rf(38,1,{4:1,38:1});var Yd=pg(38);_c={4:1,26:1,62:1,38:1};var Rd=pg(62);Rf(28,1,{4:1,26:1,28:1});_.I=function(a){return this===a};_.K=_l;_.h=0;var Sd=pg(28);Rf(69,9,Rl,yg);var Ud=pg(69);Rf(27,38,{4:1,26:1,27:1,38:1},zg);_.I=function(a){return dd(a,27)&&a.g==this.g};_.K=$l;_.g=0;var Wd=pg(27);var Bg;Rf(246,1,{});ad={4:1,61:1,26:1,2:1};var _d=pg(2);Rf(250,1,{});Rf(52,9,Rl,Hg);var be=pg(52);Rf(169,1,{44:1});_.eb=function(a){throw If(new Hg('Add not supported on this collection'))};var ce=pg(169);Rf(172,1,{154:1});_.I=function(a){var b,c,d;if(a===this){return true}if(!dd(a,40)){return false}d=a;if(this.g.h+this.h.h!=d.g.h+d.h.h){return false}for(c=new Tg((new Qg(d)).g);c.h;){b=Sg(c);if(!Kg(this,b)){return false}}return true};_.K=function(){return ih(new Qg(this))};var ke=pg(172);Rf(104,172,{154:1});var fe=pg(104);Rf(171,169,{44:1,180:1});_.I=function(a){var b;if(a===this){return true}if(!dd(a,24)){return false}b=a;if(Og(b.g)!=this.fb()){return false}return Ig(this,b)};_.K=function(){return ih(this)};var le=pg(171);Rf(24,171,{24:1,44:1,180:1},Qg);_.fb=function(){return Og(this.g)};var ee=pg(24);Rf(25,1,{},Tg);_.hb=function(){return Sg(this)};_.gb=am;_.h=false;var de=pg(25);Rf(170,169,{44:1,177:1});_.ib=function(a,b){throw If(new Hg('Add not supported on this list'))};_.eb=function(a){this.ib(this.fb(),a);return true};_.I=function(a){var b,c,d,e,f;if(a===this){return true}if(!dd(a,14)){return false}f=a;if(this.fb()!=f.g.length){return false}e=new fh(f);for(c=new fh(this);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=(e.h=e.g++,e.i.g[e.h]);if(!(jd(b)===jd(d)||b!=null&&s(b,d))){return false}}return true};_.K=function(){return jh(this)};var ge=pg(170);Rf(74,1,Sl);_.I=function(a){var b;if(!dd(a,36)){return false}b=a;return kh(this.g,b.jb())&&kh(this.h,b.kb())};_.jb=$l;_.kb=am;_.K=function(){return Ih(this.g)^Ih(this.h)};_.lb=function(a){var b;b=this.h;this.h=a;return b};var he=pg(74);Rf(75,74,Sl,Ug);var ie=pg(75);Rf(175,1,Sl);_.I=function(a){var b;if(!dd(a,36)){return false}b=a;return kh(this.h.value[0],b.jb())&&kh(Fh(this),b.kb())};_.K=function(){return Ih(this.h.value[0])^Ih(Fh(this))};var je=pg(175);Rf(14,170,{4:1,14:1,44:1,177:1},dh,eh);_.ib=function(a,b){ci(this.g,a,b)};_.eb=function(a){return Wg(this,a)};_.fb=function(){return this.g.length};var ne=pg(14);Rf(15,1,{},fh);_.gb=function(){return this.g<this.i.g.length};_.hb=function(){return this.h=this.g++,this.i.g[this.h]};_.g=0;_.h=-1;var me=pg(15);Rf(40,104,{4:1,40:1,154:1},lh);var oe=pg(40);Rf(115,1,{},rh);_.h=0;var qe=pg(115);Rf(116,1,{},sh);_.hb=function(){return this.j=this.g[this.i++],this.j};_.gb=function(){var a;if(this.i<this.g.length){return true}a=this.h.next();if(!a.done){this.g=a.value[1];this.i=0;return true}return false};_.i=0;_.j=null;var pe=pg(116);var uh;Rf(112,1,{},Dh);_.h=0;_.i=0;var te=pg(112);Rf(113,1,{},Eh);_.hb=function(){return this.i=this.g,this.g=this.h.next(),new Gh(this.j,this.i,this.j.i)};_.gb=function(){return !this.g.done};var re=pg(113);Rf(114,175,Sl,Gh);_.jb=function(){return this.h.value[0]};_.kb=function(){return Fh(this)};_.lb=function(a){return Ch(this.g,this.h.value[0],a)};_.i=0;var se=pg(114);Rf(82,1,{});_.ob=cm;_.mb=am;_.nb=bm;_.h=0;_.i=0;var xe=pg(82);Rf(83,82,{});var ue=pg(83);Rf(76,1,{});_.ob=cm;_.mb=am;_.nb=function(){return this.j-this.i};_.h=0;_.i=0;_.j=0;var we=pg(76);Rf(77,76,{},Ph);_.ob=function(a){Mh(this,a)};_.pb=function(a){return Nh(this,a)};var ve=pg(77);Rf(81,1,{});_.i=false;var De=pg(81);Rf(53,81,{},Vh);var Ce=pg(53);Rf(84,83,{},Yh);_.pb=function(a){return this.g.pb(new Zh(a))};var ze=pg(84);Rf(86,1,{},Zh);_.P=function(a){this.g.P(a.h)};var ye=pg(86);Rf(85,1,{},_h);_.P=function(a){$h(this,a)};var Ae=pg(85);Rf(87,1,{},ai);_.P=function(a){Xh(this.g,a)};var Be=pg(87);Rf(248,1,{});Rf(245,1,{});var gi=0;var ii,ji=0,ki;Rf(852,1,{});Rf(877,1,{});Rf(229,$wnd.Function,{},zi);_.rb=function(a){yi(this.g,this.h,a)};Rf(29,28,{4:1,26:1,28:1,29:1},Qi);var Mi,Ni,Oi;var Ee=qg(29,Ri);Rf(7,28,{4:1,26:1,28:1,7:1},nj);var Si,Ti,Ui,Vi,Wi,Xi,Yi,Zi,$i,_i,aj,bj,cj,dj,ej,fj,gj,hj,ij,jj,kj,lj;var Fe=qg(7,oj);var pj;Rf(205,$wnd.Function,{},rj);_.X=function(a){return Fb(pj),pj=null,null};Rf(89,1,{});var Je=pg(89);Rf(79,1,{},sj);_.qb=function(){var a;return (a=($f(),Zf),a).mediaDevices.getUserMedia(fg(eg({}),gg(hg({},cg(bg(dg({},160),640),1280)),cg(bg(dg({},120),360),720))))};var Ge=pg(79);Rf(80,1,{},tj);_.qb=function(){var a;return (a=($f(),Zf),a).mediaDevices.getDisplayMedia()};var He=pg(80);Rf(60,1,{},uj);var Ie=pg(60);Rf(118,1,{});var tf=pg(118);Rf(119,118,Xl,Bj);_.Q=dm;_.M=em;_.N=fm;var xj=0;var Oe=pg(119);Rf(120,1,Pl,Cj);_.O=function(){T(this.g.g)};var Ke=pg(120);Rf(121,1,{},Dj);_.O=function(){vj(this.g)};var Le=pg(121);Rf(122,1,{},Ej);_.O=function(){wj(this.g)};var Me=pg(122);Rf(123,1,Pl,Fj);_.O=function(){W(this.g.g)};var Ne=pg(123);Rf(41,1,{41:1});var uf=pg(41);Rf(55,41,{12:1,32:1,41:1},dk);_.Q=function(){return Ag(this.G.j)};_.M=function(){ec(this.G)};_.N=function(){return this.G.s<0};_.u=false;_.v=false;_.F=false;var Oj=0;var Ze=pg(55);Rf(124,1,Pl,ek);_.O=function(){Pj(this.g)};var Pe=pg(124);Rf(125,1,{},fk);_.O=function(){Hj(this.g)};var Qe=pg(125);Rf(56,1,Pl,gk);_.O=function(){Qj(this.g,this.h)};var Re=pg(56);Rf(57,1,Pl,hk);_.O=function(){Ij(this.g,this.h)};_.h=false;var Se=pg(57);Rf(126,1,Pl,ik);_.O=function(){Sj(this.g)};var Te=pg(126);Rf(127,1,Pl,jk);_.O=function(){Mj(this.g)};var Ue=pg(127);Rf(128,1,Pl,kk);_.O=function(){Nj(this.g)};var Ve=pg(128);Rf(129,1,Pl,lk);_.O=function(){Jj(this.g,this.h)};var We=pg(129);Rf(130,1,Pl,mk);_.O=function(){Kj(this.g)};var Xe=pg(130);Rf(131,1,Pl,nk);_.O=function(){Lj(this.g,this.h)};var Ye=pg(131);Rf(90,89,{});_.j=0;var wf=pg(90);Rf(91,90,Xl,uk);_.Q=dm;_.M=em;_.N=fm;var rk=0;var cf=pg(91);Rf(92,1,Pl,vk);_.O=function(){sk(this.g)};var $e=pg(92);Rf(93,1,Pl,wk);_.O=gm;var _e=pg(93);Rf(94,1,{},xk);_.O=function(){qk(this.g)};var af=pg(94);Rf(95,1,{},yk);_.L=function(){return pk(this.g)};var bf=pg(95);Rf(174,1,{});var Df=pg(174);Rf(146,174,{});_.j=0;var yf=pg(146);Rf(147,146,Xl,Fk);_.Q=dm;_.M=em;_.N=fm;var Ck=0;var hf=pg(147);Rf(149,1,Pl,Gk);_.O=gm;var df=pg(149);Rf(148,1,Pl,Hk);_.O=function(){Ek(this.g)};var ef=pg(148);Rf(150,1,{},Ik);_.O=function(){qk(this.g)};var ff=pg(150);Rf(151,1,{},Jk);_.L=function(){return Ak(this.g)};var gf=pg(151);Rf(176,1,{});var Ff=pg(176);Rf(139,176,{});_.m=0;var Af=pg(139);Rf(140,139,Xl,Uk);_.Q=function(){return Ag(this.j.j)};_.M=function(){ec(this.j)};_.N=function(){return this.j.s<0};var Pk=0;var of=pg(140);Rf(141,1,Pl,Vk);_.O=function(){Qk(this.g)};var jf=pg(141);Rf(144,1,{},Wk);_.L=function(){return Nk(this.g)};var kf=pg(144);Rf(145,1,Pl,Xk);_.O=function(){var a;a=Tk(this.g);null!=a&&(($f(),$wnd.goog.global.window).location.hash=a)};var lf=pg(145);Rf(142,1,{},Yk);_.O=function(){Ok(this.g)};var mf=pg(142);Rf(143,1,Pl,Zk);_.O=function(){Rk(this.g,this.h)};var nf=pg(143);Rf(42,1,{42:1});var Bf=pg(42);Rf(132,42,{12:1,32:1,42:1},al);_.Q=function(){return Ag(this.g.j)};_.M=function(){ec(this.g)};_.N=function(){return this.g.s<0};var $k=0;var rf=pg(132);Rf(133,1,Pl,bl);_.O=function(){_k(this.g)};var pf=pg(133);Rf(134,1,Pl,cl);_.O=function(){ec(this.g.g)};var qf=pg(134);Rf(108,1,{},dl);_.handleEvent=function(a){zj(this.g)};var sf=pg(108);Rf(199,$wnd.Function,{},el);_.W=function(a,b,c){return a.stop(),null};Rf(200,$wnd.Function,{},fl);_.W=hm;Rf(201,$wnd.Function,{},gl);_.W=hm;Rf(197,$wnd.Function,{},hl);_.X=function(a){return Zj(this.g,a),null};Rf(198,$wnd.Function,{},il);_.X=function(a){return _j(this.g,a),null};Rf(202,$wnd.Function,{},jl);_.W=function(a,b,c){return Gj(this.g,a)};Rf(204,$wnd.Function,{},kl);_.Y=function(a){return $j(this.g),null};Rf(203,$wnd.Function,{},ll);_.W=function(a,b,c){return q('live',a.readyState)&&a.stop(),null};Rf(196,$wnd.Function,{},ml);_.ub=function(a){return new pl(a)};var nl;Rf(78,$wnd.React.Component,{},pl);Qf(Of[1],_);_.componentWillUnmount=function(){ok(this.g)};_.render=function(){return tk(this.g)};_.shouldComponentUpdate=im;var vf=pg(78);Rf(211,$wnd.Function,{},ql);_.ub=function(a){return new tl(a)};var rl;Rf(138,$wnd.React.Component,{},tl);Qf(Of[1],_);_.componentDidMount=function(){Uj(this.g.i.props['b'],true)};_.componentWillUnmount=function(){ok(this.g)};_.render=function(){return Dk(this.g)};_.shouldComponentUpdate=im;var xf=pg(138);Rf(210,$wnd.Function,{},ul);_.ub=function(a){return new xl(a)};var vl;Rf(137,$wnd.React.Component,{},xl);Qf(Of[1],_);_.componentWillUnmount=function(){Mk(this.g)};_.render=function(){return Sk(this.g)};_.shouldComponentUpdate=function(a){return 1==this.g.m};var zf=pg(137);Rf(212,$wnd.Function,{},yl);_.P=jm;Rf(213,$wnd.Function,{},zl);_.P=jm;Rf(214,$wnd.Function,{},Al);_.tb=function(a){bk(this.g)};Rf(215,$wnd.Function,{},Bl);_.tb=function(a){ak(this.g)};Rf(216,$wnd.Function,{},Cl);_.tb=function(a){ck(this.g)};Rf(110,1,{},Hl);var Cf=pg(110);Rf(207,$wnd.Function,{},Il);_.sb=function(a){Kk(this.g,a)};Rf(209,$wnd.Function,{},Jl);_.sb=function(a){Lk(this.g,Fg(a.target.value))};Rf(109,1,{},Kl);var Ef=pg(109);var ld=rg('D');var Ll=(zc(),Cc);var gwtOnLoad=gwtOnLoad=Mf;Kf(Xf);Nf('permProps',[[]]);if (vchat) vchat.onScriptLoad(gwtOnLoad);})();