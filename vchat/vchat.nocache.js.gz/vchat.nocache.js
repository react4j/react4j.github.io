function vchat(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='vchat',tb='__gwt_marker_vchat',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='B2EB83A76DFD5C8EF7C83A5D4D9C2945',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};vchat.onScriptLoad=function(a){vchat=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
vchat();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'B2EB83A76DFD5C8EF7C83A5D4D9C2945';function w(){}
function wi(){}
function zh(){}
function vh(){}
function vm(){}
function Pm(){}
function Pk(){}
function qk(){}
function Hk(){}
function Qk(){}
function Nb(){}
function Tc(){}
function $c(){}
function Wj(){}
function tl(){}
function dp(){}
function ep(){}
function jp(){}
function kp(){}
function lp(){}
function np(){}
function qp(){}
function cq(){}
function fq(){}
function lq(){}
function Yq(){}
function tr(){}
function xr(){}
function Br(){}
function Fr(){}
function Jr(){}
function Or(){}
function $r(){}
function Yc(a){Xc()}
function Qh(){Qh=vh}
function yb(a,b){a.h=b}
function Ok(a,b){a.g=b}
function O(a){this.g=a}
function N(a){this.g=a}
function P(a){this.g=a}
function eb(a){this.g=a}
function rb(a){this.g=a}
function Fb(a){this.g=a}
function Gb(a){this.g=a}
function Hb(a){this.g=a}
function Ib(a){this.g=a}
function qc(a){this.g=a}
function Oh(a){this.g=a}
function fi(a){this.g=a}
function Ki(a){this.g=a}
function Si(a){this.g=a}
function Ti(a){this.g=a}
function Qi(a){this.j=a}
function fj(a){this.i=a}
function rk(a){this.g=a}
function Sk(a){this.g=a}
function Em(a){this.g=a}
function Fm(a){this.g=a}
function Mm(a){this.g=a}
function Nm(a){this.g=a}
function Om(a){this.g=a}
function Qm(a){this.g=a}
function wn(a){this.g=a}
function xn(a){this.g=a}
function An(a){this.g=a}
function Bn(a){this.g=a}
function Cn(a){this.g=a}
function En(a){this.g=a}
function Mo(a){this.g=a}
function No(a){this.g=a}
function Oo(a){this.g=a}
function Po(a){this.g=a}
function Ro(a){this.g=a}
function So(a){this.g=a}
function Wo(a){this.g=a}
function _o(a){this.g=a}
function cp(a){this.g=a}
function hp(a){this.g=a}
function ip(a){this.g=a}
function mp(a){this.g=a}
function op(a){this.g=a}
function pp(a){this.g=a}
function rp(a){this.g=a}
function sp(a){this.g=a}
function tp(a){this.g=a}
function up(a){this.g=a}
function vp(a){this.g=a}
function wp(a){this.g=a}
function xp(a){this.g=a}
function Yp(a){this.g=a}
function $p(a){this.g=a}
function _p(a){this.g=a}
function aq(a){this.g=a}
function bq(a){this.g=a}
function dq(a){this.g=a}
function eq(a){this.g=a}
function gq(a){this.g=a}
function hq(a){this.g=a}
function iq(a){this.g=a}
function jq(a){this.g=a}
function kq(a){this.g=a}
function oq(a){this.g=a}
function wq(a){this.g=a}
function xq(a){this.g=a}
function yq(a){this.g=a}
function zq(a){this.g=a}
function Rq(a){this.g=a}
function Sq(a){this.g=a}
function Tq(a){this.g=a}
function Uq(a){this.g=a}
function Vq(a){this.g=a}
function Wq(a){this.g=a}
function Xq(a){this.g=a}
function Zq(a){this.g=a}
function ir(a){this.g=a}
function jr(a){this.g=a}
function lr(a){this.g=a}
function mr(a){this.g=a}
function sr(a){this.g=a}
function Kr(a){this.g=a}
function Lr(a){this.g=a}
function Mr(a){this.g=a}
function Nr(a){this.g=a}
function Pr(a){this.g=a}
function Qr(a){this.g=a}
function Rr(a){this.g=a}
function Sr(a){this.g=a}
function Zr(a){this.g=a}
function _r(a){this.g=a}
function ds(a){this.g=a}
function dj(){Vi(this)}
function et(){Pi(this)}
function it(a){ji(this)}
function dt(a){Mj(this,a)}
function kt(a){ek(this,a)}
function lt(){kc(this.h)}
function uj(){this.g=Dj()}
function Ij(){this.g=Dj()}
function H(a){--a.l;L(a)}
function lc(a){!!a&&a.Q()}
function lh(a){return a.l}
function lb(a){dc((R(),a))}
function mb(a){ec((R(),a))}
function pb(a){fc((R(),a))}
function il(a,b){hl(a,b)}
function Rk(a,b){Gk(a.g,b)}
function K(a,b){Vb(a.m,b.m)}
function S(a,b){W(a);T(a,b)}
function ml(a,b){a.key=b}
function R(){R=vh;Q=new M}
function zc(){zc=vh;yc=new w}
function zj(){zj=vh;yj=Bj()}
function qt(){bb(this.g.g)}
function pt(a){Gn(this.g,a)}
function bt(){return this.g}
function gt(){return this.h}
function jt(){return this.l}
function Aq(a,b){return a.v=b}
function ct(){return _k(this)}
function di(){wc.call(this)}
function xi(){wc.call(this)}
function Jq(a){a.l=2;kc(a.i)}
function qq(a){a.j=2;kc(a.h)}
function ar(a){a.m=2;kc(a.j)}
function tc(a,b){a.l=b;sc(a,b)}
function jc(a,b,c){Gi(a.l,b,c)}
function Nq(a){sb(a.h);Z(a.g)}
function fb(a){md(a,11)&&a.S()}
function Ph(a){xc.call(this,a)}
function yi(a){xc.call(this,a)}
function vi(a){Oh.call(this,a)}
function ui(){Oh.call(this,'')}
function er(a){sb(a.g);hb(a.h)}
function mo(a){fb(a.B);fb(a.I)}
function Th(a){Sh(a);return a.v}
function Zi(a,b){return a.g[b]}
function jk(a,b,c){b.U(a.g[c])}
function Bm(a,b,c){jc(a.h,b,c)}
function fn(a,b,c){jc(a.I,b,c)}
function Xk(a,b){a.splice(b,1)}
function Yk(a,b){return fd(a,b)}
function _c(a,b){return Zh(a,b)}
function ft(){return Ii(this.g)}
function mt(){return this.h.s<0}
function wc(){rc(this);this.Z()}
function oj(){this.g=new lj}
function Qc(){Qc=vh;Pc=new Tc}
function wk(){wk=vh;vk=new Qk}
function Gc(){Gc=vh;!!(Xc(),Wc)}
function Oc(){Dc!=0&&(Dc=0);Fc=-1}
function ib(a){R();ec(a);a.l=-2}
function Ck(a){sk(a);return a.g}
function Ch(a,b){a.max=b;return a}
function Dh(a,b){a.min=b;return a}
function wl(a,b){a.id=b;return a}
function Mh(a,b){a.sdp=b;return a}
function Fk(a,b){a.sb(b);return a}
function xl(a,b){a.key=b;return a}
function yl(a,b){a.ref=b;return a}
function Fl(a,b){a.src=b;return a}
function gn(a){nb(a.o);return a.F}
function hn(a){nb(a.i);return a.B}
function po(a){nb(a.i);return a.F}
function qo(a){nb(a.j);return a.G}
function Fo(a){nb(a.l);return a.s}
function Go(a){ob(a.m);return a.u}
function Jo(a){nb(a.o);return a.v}
function Dj(){zj();return new yj}
function io(a,b){return v(b.g,a)}
function Rj(a){return Sj(a,a.i.h)}
function Ii(a){return a.g.h+a.h.h}
function qi(a){return !a?ss:''+a.g}
function Fj(a,b){return a.g.get(b)}
function Nj(a,b){Pj(a,b,a.g,a.g.g)}
function Oj(a,b){Pj(a,b,a.i.h,a.i)}
function Zb(a){$b(a);!a.j&&bc(a)}
function ek(a,b){while(a.Ob(b));}
function Lk(a,b,c){b.U(a.g.rb(c))}
function G(a,b,c){D(a,new P(c),b)}
function Vk(a,b,c){a.splice(b,0,c)}
function Ul(a,b){ci.call(this,a,b)}
function rm(a,b){ci.call(this,a,b)}
function wm(a,b){this.g=a;this.h=b}
function Gm(a,b){this.g=a;this.h=b}
function ci(a,b){this.g=a;this.h=b}
function Ui(a,b){this.g=a;this.h=b}
function Kk(a,b){this.g=a;this.h=b}
function Nk(a,b){this.g=a;this.h=b}
function ul(a,b){this.g=a;this.h=b}
function yn(a,b){this.g=a;this.h=b}
function zn(a,b){this.g=a;this.h=b}
function Dn(a,b){this.g=a;this.h=b}
function Fn(a,b){this.g=a;this.h=b}
function Qo(a,b){this.g=a;this.h=b}
function To(a,b){this.g=a;this.h=b}
function Uo(a,b){this.g=a;this.h=b}
function Vo(a,b){this.g=a;this.h=b}
function Xo(a,b){this.g=a;this.h=b}
function Yo(a,b){this.g=a;this.h=b}
function Zo(a,b){this.g=a;this.h=b}
function $o(a,b){this.g=a;this.h=b}
function ap(a,b){this.g=a;this.h=b}
function bp(a,b){this.g=a;this.h=b}
function fp(a,b){this.g=a;this.h=b}
function gp(a,b){this.g=a;this.h=b}
function Zp(a,b){this.g=a;this.h=b}
function mq(a,b){this.g=a;this.h=b}
function nq(a,b){this.g=a;this.h=b}
function kr(a,b){this.g=a;this.h=b}
function Tr(a,b){this.g=a;this.h=b}
function Ur(a,b){this.g=a;this.h=b}
function Lb(a){this.j=a;this.h=100}
function pq(){this.g=ql((vr(),ur))}
function Yr(){this.g=ql((zr(),yr))}
function cs(){this.g=ql((Dr(),Cr))}
function oh(){mh==null&&(mh=[])}
function hs(){this.g=ql((Hr(),Gr))}
function Ep(a,b){ci.call(this,a,b)}
function Kp(a,b){ci.call(this,a,b)}
function Wp(a,b){ci.call(this,a,b)}
function jo(a,b){return v(b.g,a.g)}
function ht(a){return Ei(this.g,a)}
function Vr(a){return Wr(new Yr,a)}
function as(a){return bs(new cs,a)}
function es(a){return gs(new hs,a)}
function ab(a){ub(a.m);return cb(a)}
function Nh(a,b){a.type=b;return a}
function Fh(a,b){a.video=b;return a}
function Bh(a,b){a.ideal=b;return a}
function Hh(a,b){a.width=b;return a}
function Gh(a,b){a.height=b;return a}
function Al(a,b){a.href=b;return a}
function Ol(a,b){a.value=b;return a}
function si(a,b){a.g+=''+b;return a}
function Gl(a){a.width='32';return a}
function Eh(a){a.audio=true;return a}
function sd(a){return a==null?null:a}
function Yj(a){return a!=null?C(a):0}
function Di(a){return !a?null:a.Kb()}
function _b(a){return !a.j?a:_b(a.j)}
function v(a,b){return sd(a)===sd(b)}
function Gk(a,b){wk();Ok(a,Fk(a.g,b))}
function to(a,b){bo(a,b,new mq(a,b))}
function uo(a,b){bo(a,b,new nq(a,b))}
function jn(a){mn(a,(nb(a.i),!a.B))}
function xb(a){R();wb(a);Ab(a,2,true)}
function Vi(a){a.g=bd(je,ls,1,0,5,1)}
function ok(){pk.call(this,'|','','')}
function Nc(a){$wnd.clearTimeout(a)}
function Pl(a,b){a.htmlFor=b;return a}
function Bl(a,b){a.onClick=b;return a}
function Jl(a,b){a.onChange=b;return a}
function Dl(a,b){a.onSubmit=b;return a}
function Jh(a,b){a.candidate=b;return a}
function El(a){a.height='32';return a}
function qb(a){this.i=new dj;this.h=a}
function dl(){dl=vh;al=new w;cl=new w}
function Zk(a){if(!a){throw lh(new di)}}
function hl(a,b){for(var c in a){b(c)}}
function ki(a,b){return a.charCodeAt(b)}
function J(a,b,c){return F(a,c,2048,b)}
function nj(a,b){return Hi(a.g,b)!=null}
function md(a,b){return a!=null&&kd(a,b)}
function _k(a){return a.$H||(a.$H=++$k)}
function Ml(a){return a.required=true,a}
function Hl(a){return a.autoFocus=true,a}
function od(a){return typeof a==='number'}
function rd(a){return typeof a==='string'}
function gb(a){return !(md(a,11)&&a.T())}
function Ob(a){2==(3&a.g)||(a.g=-4&a.g|2)}
function nb(a){var b;ac((R(),b=Xb,b),a)}
function I(a,b,c){F(a,new O(b),c,null)}
function Wk(a,b,c){Uk(c,0,a,b,c.length)}
function Wr(a,b){ll(a.g,'a',b);return a}
function Il(a,b){a.maxLength=b;return a}
function Ih(a,b){a.iceServers=b;return a}
function Ll(a,b){a.placeholder=b;return a}
function ll(a,b,c){a.props[b]=c;return a}
function fs(a,b){ll(a.g,'b',b);return a.g}
function Sh(a){if(a.v!=null){return}_h(a)}
function Ni(a){a.i.Db();a.i=null;a.h=Li(a)}
function Pi(a){a.j.Hb(a.i);a.h=a.i;a.i=-1}
function xc(a){this.o=a;rc(this);this.Z()}
function lj(){this.g=new uj;this.h=new Ij}
function X(){this.g=bd(je,ls,1,100,5,1)}
function Km(a){I((R(),R(),Q),new Qm(a),Es)}
function rn(a){I((R(),R(),Q),new En(a),Es)}
function sn(a){I((R(),R(),Q),new Bn(a),Es)}
function tn(a){I((R(),R(),Q),new An(a),Es)}
function un(a){I((R(),R(),Q),new Cn(a),Es)}
function Co(a){I((R(),R(),Q),new So(a),Es)}
function Ko(a){I((R(),R(),Q),new Ro(a),Es)}
function Eo(a){I((R(),R(),Q),new _o(a),Os)}
function Pq(a){I((R(),R(),Q),new Xq(a),Es)}
function oc(a){R();Xb?a.Q():I((null,Q),a,0)}
function wj(a,b){var c;c=a[xs];c.call(a,b)}
function jl(a,b){var c;c={};c[a]=b;return c}
function Kh(a,b){a.sdpMLineIndex=b;return a}
function Kl(a){a.pattern='^\\w+$';return a}
function rc(a){a.u&&a.l!==qs&&a.Z();return a}
function bb(a){4==(a.m.i&7)&&Ab(a.m,5,true)}
function Ub(a,b,c){c.g=-4&c.g|1;S(a.g[b],c)}
function ni(a,b,c){return a.substr(b,c-b)}
function Hc(a,b,c){return a.apply(b,c);var d}
function qd(a,b){return a&&b&&a instanceof b}
function ho(a,b){return sd(b.track)===sd(a)}
function nd(a){return typeof a==='boolean'}
function Iq(a,b){b.preventDefault();Eo(a.u)}
function Mj(a,b){while(a.Bb()){Rk(b,a.Cb())}}
function hk(a,b){while(a.i<a.j){jk(a,b,a.i++)}}
function Kb(a){while(true){if(!Jb(a)){break}}}
function ej(a){Vi(this);Wk(this.g,0,a.yb())}
function Lj(a,b,c){this.g=a;this.h=b;this.i=c}
function Vj(a,b,c){this.j=a;this.h=c;this.g=b}
function Ek(a,b){wk();uk.call(this,a);this.g=b}
function Wi(a,b){a.g[a.g.length]=b;return true}
function Wh(a){var b;b=Vh(a);bi(a,b);return b}
function ii(){ii=vh;hi=bd(ge,ls,37,256,0,1)}
function Xc(){Xc=vh;var a;!Zc();a=new $c;Wc=a}
function yo(a,b){I((R(),R(),Q),new $o(a,b),Os)}
function vo(a,b){I((R(),R(),Q),new Zo(a,b),Os)}
function wo(a,b){I((R(),R(),Q),new To(a,b),Os)}
function xo(a,b){I((R(),R(),Q),new Xo(a,b),Os)}
function zo(a,b){I((R(),R(),Q),new Yo(a,b),Os)}
function Bo(a,b){I((R(),R(),Q),new Uo(a,b),Os)}
function oo(a,b){I((R(),R(),Q),new ap(a,b),Os)}
function Do(a,b){I((R(),R(),Q),new bp(a,b),Os)}
function Ao(a,b){I((R(),R(),Q),new Vo(a,b),Es)}
function Cm(a,b){I((R(),R(),Q),new Gm(a,b),Es)}
function mn(a,b){I((R(),R(),Q),new zn(a,b),Es)}
function Vb(a,b){Ub(a,((b.g&229376)>>15)-1,b)}
function vb(a,b){kb(b,a);b.i.g.length>0||(b.g=4)}
function Dq(a,b,c){c.preventDefault();oo(a.u,b)}
function Eq(a,b,c){c.preventDefault();Do(a.u,b)}
function Ei(a,b){return rd(b)?Fi(a,b):!!rj(a.g,b)}
function Ej(a,b){return !(a.g.get(b)===undefined)}
function _q(a,b){oc(new kr(a,b.length==0?null:b))}
function Uc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function _i(a,b){var c;c=a.g[b];Xk(a.g,b);return c}
function Yh(a){var b;b=Vh(a);b.u=a;b.l=1;return b}
function xk(a,b){var c;return Bk(a,(c=new dj,c))}
function gj(a,b){return fk(b,a.length),new kk(a,b)}
function hj(a){return new Ek(null,gj(a,a.length))}
function uq(a){return J((R(),R(),Q),a.g,new yq(a))}
function dd(a){return Array.isArray(a)&&a.Yb===zh}
function ld(a){return !Array.isArray(a)&&a.Yb===zh}
function Oq(a){return J((R(),R(),Q),a.h,new Wq(a))}
function gr(a){return J((R(),R(),Q),a.g,new lr(a))}
function V(a){return a.i?a.g.length-a.h+a.j:a.j-a.h}
function lk(a){if(!a.j){a.j=a.h.qb();a.i=a.h.vb()}}
function sq(a){if(0==a.j){a.j=1;a.i.forceUpdate()}}
function Lq(a){if(0==a.l){a.l=1;a.j.forceUpdate()}}
function cr(a){if(0==a.m){a.m=1;a.l.forceUpdate()}}
function Mb(a){if(!a.g){a.g=true;H((R(),R(),Q))}}
function sk(a){if(!a.h){tk(a);a.i=true}else{sk(a.h)}}
function Ik(a,b,c){if(a.g.Qb(c)){a.h=true;b.U(c)}}
function Jn(a,b,c){a.D.addTrack(c,b);return null}
function mj(a,b){var c;c=Gi(a.g,b,a);return c==null}
function Tk(a,b){var c;c=a.slice(0,b);return fd(c,a)}
function cj(a,b,c){var d;d=a.g[b];a.g[b]=c;return d}
function en(a,b){var c;c=a.B;if(b!=c){a.B=b;mb(a.i)}}
function kn(a,b){var c;c=a.v;if(b!=c){a.v=b;mb(a.g)}}
function ln(a,b){var c;c=a.A;if(b!=c){a.A=b;mb(a.h)}}
function nn(a,b){var c;c=a.C;if(b!=c){a.C=b;mb(a.j)}}
function on(a,b){var c;c=a.D;if(b!=c){a.D=b;mb(a.l)}}
function qn(a,b){var c;c=a.H;if(b!=c){a.H=b;mb(a.u)}}
function no(a,b){var c;c=a.s;if(b!=c){a.s=b;mb(a.l)}}
function fr(a,b){var c;c=a.i;if(b!=c){a.i=b;mb(a.h)}}
function kl(a,b,c,d){var e;e={};e[a]=b;e[c]=d;return e}
function Cl(a,b){a.type=b.g!=null?b.g:''+b.h;return a}
function ri(a,b){a.g+=String.fromCharCode(b);return a}
function Uj(a){a.i=a.h;a.h=a.h.g;++a.g;return a.i.i}
function Rm(a){pn(a,null);on(a,null);nn(a,null)}
function Hi(a,b){return b==null?tj(a.g,null):Hj(a.h,b)}
function Fi(a,b){return b==null?!!rj(a.g,null):Ej(a.h,b)}
function kj(a,b){return sd(a)===sd(b)||a!=null&&A(a,b)}
function so(a,b){sd(a.J)===sd(b.currentTarget)&&bb(a.g)}
function yk(a,b){tk(a);return new Ek(a,new Jk(b,a.g))}
function zk(a,b){tk(a);return new Ek(a,new Mk(b,a.g))}
function Vl(){Tl();return ed(_c(kf,1),ls,39,0,[Ql,Rl,Sl])}
function Lp(){Jp();return ed(_c(jg,1),ls,40,0,[Ip,Hp,Gp])}
function ob(a){var b;R();!!Xb&&!!Xb.l&&ac((b=Xb,b),a)}
function tb(a){K((R(),R(),Q),a);0==(a.m.g&ps)&&L((null,Q))}
function gc(a,b){this.g=(R(),R(),Q).h++;this.j=a;this.l=b}
function kk(a,b){this.i=0;this.j=b;this.h=17488;this.g=a}
function Ri(a,b){this.g=a;Qi.call(this,a);a.vb();this.h=b}
function gk(a,b){this.l=a;this.j=(b&64)!=0?b|16384:b}
function mk(a,b){this.h=a;this.g=(b&4096)==0?b|64|16384:b}
function uk(a){if(!a){this.h=null;new dj}else{this.h=a}}
function gl(){if(bl==256){al=cl;cl=new w;bl=0}++bl}
function Xh(a,b){var c;c=Vh(a);bi(a,c);c.l=b?8:0;return c}
function Mi(a){var b;a.i=a.g;b=a.g.Cb();a.h=Li(a);return b}
function hc(a,b){Xb=new gc(Xb,b);a.j=false;Yb(Xb);return Xb}
function Ji(a,b){if(md(b,43)){return Bi(a.g,b)}return false}
function $h(a){if(a.ob()){return null}var b=a.u;return rh[b]}
function xh(a){function b(){}
;b.prototype=a||{};return new b}
function Lh(a){a.urls='stun:stun.l.google.com:19302';return a}
function tk(a){if(a.h){tk(a.h)}else if(a.i){throw lh(new ei)}}
function Yb(a){if(a.l){2==(a.l.i&7)||Ab(a.l,4,true);wb(a.l)}}
function eo(a,b){null!=a.J&&a.J.send($wnd.JSON.stringify(b))}
function Zh(a,b){var c=a.g=a.g||[];return c[b]||(c[b]=a.jb(b))}
function qj(a,b){var c;c=a.g.get(b);return c==null?new Array:c}
function uc(a,b){var c;c=Th(a.Wb);return b==null?c:c+': '+b}
function Ci(a,b){return b===a?'(this Map)':b==null?ss:yh(b)}
function nr(a,b){var c;c=a.i;!(!!c&&c.I.s<0)&&oc(new yn(c,b))}
function Bq(a,b){var c;oc(new Qo(a.u,oi((c=b.target,c).value)))}
function rj(a,b){var c;return pj(b,qj(a,b==null?0:(c=C(b),c|0)))}
function th(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Mc(a){Gc();$wnd.setTimeout(function(){throw a},0)}
function vr(){vr=vh;var a;ur=(a=wh(tr.prototype.Vb,tr,[]),a)}
function zr(){zr=vh;var a;yr=(a=wh(xr.prototype.Vb,xr,[]),a)}
function Dr(){Dr=vh;var a;Cr=(a=wh(Br.prototype.Vb,Br,[]),a)}
function Hr(){Hr=vh;var a;Gr=(a=wh(Fr.prototype.Vb,Fr,[]),a)}
function Um(a,b){b.onended=wh(ip.prototype.eb,ip,[a]);return null}
function ot(a,b,c){return v('live',a.readyState)&&a.stop(),null}
function nt(a,b,c){return Qh(),(a.enabled=!a.enabled)?true:false}
function Fp(){Dp();return ed(_c(ig,1),ls,23,0,[Ap,Cp,zp,yp,Bp])}
function M(){this.m=new Wb;this.g=new Lb(this.m);new N(this.g)}
function vj(a){this.l=a;this.h=this.l.g.entries();this.g=new Array}
function Mk(a,b){gk.call(this,b.Nb(),b.Mb()&-6);this.g=a;this.h=b}
function Ho(a,b){var c;c=a.u;if(!(b==c||!!b&&b==c)){a.u=b;mb(a.m)}}
function Io(a,b){var c;c=a.v;if(!(b==c||!!b&&b==c)){a.v=b;mb(a.o)}}
function On(a,b){var c;return c=(nb(b.o),b.F),null!=c&&v(c.id,a.id)}
function Kc(a,b,c){var d;d=Ic();try{return Hc(a,b,c)}finally{Lc(d)}}
function Tm(a,b,c){a.L==b&&I((R(),R(),Q),new Fn(a,c),Es);return null}
function ik(a,b){if(a.i<a.j){jk(a,b,a.i++);return true}return false}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Hn(a){var b;b=new dj;hn(a.I)&&Wi(b,a.I);Xi(b,a.H);return b}
function lo(a){Z(a.g);Z(a.h);hb(a.o);hb(a.m);hb(a.l);hb(a.j);hb(a.i)}
function nc(a){lc(a.o);!!a.l&&mc(a);fb(a.g);fb(a.i);lc(a.h);lc(a.m)}
function hb(a){if(-2!=a.l){I((R(),R(),Q),new rb(a),0);!!a.h&&sb(a.h)}}
function Ak(a,b){return !(tk(a),Ck(new Ek(a,new Jk(b,a.g)))).Ob(vk)}
function td(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Lc(a){a&&Sc((Qc(),Pc));--Dc;if(a){if(Fc!=-1){Nc(Fc);Fc=-1}}}
function Qb(b){try{ub(b.h.g)}catch(a){a=kh(a);if(!md(a,8))throw lh(a)}}
function ji(a){var b,c;for(c=a.qb();c.Bb();){b=c.Cb();md(b,11)&&b.S()}}
function jb(a,b){var c,d;Wi(a.i,b);d=(c=b.i&7,c>3?c:4);a.g>d&&(a.g=d)}
function Jk(a,b){gk.call(this,b.Nb(),b.Mb()&-16449);this.g=a;this.i=b}
function Jj(a){this.j=a;this.h=this.j.g.entries();this.g=this.h.next()}
function pk(a,b,c){this.h=a;this.j=b;this.l=c;this.i=this.j+(''+this.l)}
function wr(a){$wnd.React.Component.call(this,a);this.g=new vq(this)}
function Ar(a){$wnd.React.Component.call(this,a);this.g=new Qq(this)}
function Er(a){$wnd.React.Component.call(this,a);this.g=new hr(this)}
function Ir(a){$wnd.React.Component.call(this,a);this.g=new rr(this)}
function nk(a,b){!a.g?(a.g=new vi(a.j)):si(a.g,a.h);si(a.g,b);return a}
function Bk(a,b){var c;sk(a);c=new Pk;c.g=b;a.g.Ab(new Sk(c));return c.g}
function Dk(a,b){var c;c=xk(a,new rk(new qk));return c.zb(b.Pb(c.vb()))}
function Pn(a,b){var c;return c=(nb(b.o),b.F),!(null!=c&&!v(c.id,a.id))}
function Pj(a,b,c,d){var e;e=new Wj;e.i=b;e.h=c;e.g=d;d.h=c.g=e;++a.h}
function sl(a,b,c){!v(c,'key')&&!v(c,'ref')&&(a[c]=b[c],undefined)}
function Ln(a,b){return a.D.setLocalDescription(Nh(Mh({},b.sdp),b.type))}
function Qn(a,b){return a.D.setLocalDescription(Mh(Nh({},b.type),b.sdp))}
function Mn(a){eo(a,kl(Hs,'offer',Js,a.D.localDescription));return null}
function Rn(a){eo(a,kl(Hs,'answer',Js,a.D.localDescription));return null}
function Tb(a){var b,c;b=0;for(c=0;c<a.g.length;c++){b+=V(a.g[c])}return b}
function T(a,b){a.g[a.j]=b;++a.j;if(a.j>=a.g.length){a.j=0;a.i=true}}
function Hm(a){$wnd.goog.global.globalThis.addEventListener(Fs,a.i,false)}
function Im(a){$wnd.goog.global.globalThis.removeEventListener(Fs,a.i,false)}
function Fq(a){$wnd.goog.global.globalThis.document.addEventListener(Qs,a.s)}
function Oi(a){this.l=a;this.j=new Jj(this.l.h);this.g=this.j;this.h=Li(this)}
function Kj(a){if(a.g.i!=a.i){return Fj(a.g,a.h.value[0])}return a.h.value[1]}
function Cc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Jc(b){Gc();return function(){return Kc(b,this,arguments);var a}}
function Xp(){Vp();return ed(_c(kg,1),ls,17,0,[Up,Np,Sp,Rp,Qp,Mp,Tp,Pp,Op])}
function Gi(a,b,c){return rd(b)?b==null?sj(a.g,null,c):Gj(a.h,b,c):sj(a.g,b,c)}
function bo(a,b,c){if(null!=a.J&&aj(a.G,b)){bj(a.G,new oq(b));mb(a.j);c.Q()}}
function Gn(a,b){null!=a.D&&b.getTracks().forEach(wh(Zp.prototype._,Zp,[a,b]))}
function Gq(a){$wnd.goog.global.globalThis.document.removeEventListener(Qs,a.s)}
function L(a){if(a.j&&a.l==0){if(!a.i){a.i=true;try{Kb(a.g)}finally{a.i=false}}}}
function Z(a){if(!a.g){a.g=true;a.v=null;a.h=null;hb(a.l);2==(a.m.i&7)||sb(a.m)}}
function kc(a){if(a.s>=0){a.s=-2;F((R(),R(),Q),new O(new qc(a)),67108864,null)}}
function bd(a,b,c,d,e,f){var g;g=cd(e,d);e!=10&&ed(_c(a,f),b,c,e,g);return g}
function aj(a,b){var c;c=$i(a,b,0);if(c==-1){return false}Xk(a.g,c);return true}
function bs(a,b){ml(a.g,gi(b.h.j)+(''+(Sh(gh),gh.v)));ll(a.g,'a',b);return a.g}
function cb(a){if(a.h){if(md(a.h,10)){throw lh(a.h)}else{throw lh(a.h)}}return a.v}
function zb(b){if(b){try{b.Q()}catch(a){a=kh(a);if(md(a,8)){R()}else throw lh(a)}}}
function fd(a,b){ad(b)!=10&&ed(B(b),b.Xb,b.__elementTypeId$,ad(b),a);return a}
function $i(a,b,c){for(;c<a.g.length;++c){if(kj(b,a.g[c])){return c}}return -1}
function pr(a,b){var c;c=a.h.props;if(!(c['b']===b['b'])){return true}return false}
function dn(a,b){var c;c=a.G;if(!(sd(b)===sd(c)||b!=null&&A(b,c))){a.G=b;mb(a.s)}}
function pn(a,b){var c;c=a.F;if(!(sd(b)===sd(c)||b!=null&&A(b,c))){a.F=b;mb(a.o)}}
function Yi(a,b){var c,d,e,f;for(d=a.g,e=0,f=d.length;e<f;++e){c=d[e];b.U(c)}}
function Wb(){var a;this.g=bd(zd,ls,56,5,0,1);for(a=0;a<5;a++){this.g[a]=new X}}
function ic(){var a;try{Zb(Xb);R()}finally{a=Xb.j;!a&&((R(),R(),Q).j=true);Xb=Xb.j}}
function Rc(a){var b,c;if(a.g){c=null;do{b=a.g;a.g=null;c=Vc(b,c)}while(a.g);a.g=c}}
function Sc(a){var b,c;if(a.h){c=null;do{b=a.h;a.h=null;c=Vc(b,c)}while(a.h);a.h=c}}
function ac(a,b){var c;if(a.l){c=a.g;if(b.l!=c){b.l=c;!a.h&&(a.h=new dj);Wi(a.h,b)}}}
function Tn(a,b){if(null!=a.J){a.G.g=bd(je,ls,1,0,5,1);a.J.close();a.J=null;Io(a,b)}}
function cc(a,b){var c;if(!a.i){c=_b(a);!c.i&&(c.i=new dj);a.i=c.i}b.j=true;a.i.sb(b)}
function bi(a,b){var c;if(!a){return}b.u=a;var d=$h(b);if(!d){rh[a]=[b];return}d.Wb=b}
function Sj(a,b){var c;c=b.i;b.g.h=b.h;b.h.g=b.g;b.g=b.h=null;b.i=null;--a.h;return c}
function Vh(a){var b;b=new Uh;b.v='Class$'+(a?'S'+a:''+b.o);b.h=b.v;b.s=b.v;return b}
function gs(a,b){ml(a.g,(b?gi(b.I.j):null)+(''+(Sh(ih),ih.v)));ll(a.g,'a',b);return a}
function wh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function zl(a){a.title='Room code should only contain letters or numbers.';return a}
function Tl(){Tl=vh;Ql=new Ul(Cs,0);Rl=new Ul('reset',1);Sl=new Ul('submit',2)}
function Jp(){Jp=vh;Ip=new Kp('UNKNOWN',0);Hp=new Kp('HOST',1);Gp=new Kp('GUEST',2)}
function pd(a){return a!=null&&(typeof a===js||typeof a==='function')&&!(a.Yb===zh)}
function ad(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function co(a){if(null!=a.J){eo(a,kl(Hs,Ms,'message',(nb(a.l),a.s)));Io(a,(Vp(),Sp))}}
function Sn(a,b){var c;c=b.g;eo(a,kl(Hs,'approve_access','id',c));mj(a.F,c);mb(a.i);fo(a)}
function Hj(a,b){var c;c=a.g.get(b);if(c===undefined){++a.i}else{wj(a.g,b);--a.h}return c}
function ol(a,b,c,d){var e;e=pl($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function ql(a){var b;b=pl($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Ai(a,b){var c,d;for(d=b.qb();d.Bb();){c=d.Cb();if(!a.tb(c)){return false}}return true}
function wb(a){var b,c;for(c=new fj(a.h);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);b.g=4}}
function nh(){oh();var a=mh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function cn(a){sb(a.m);hb(a.h);hb(a.o);hb(a.l);hb(a.j);hb(a.i);hb(a.g);hb(a.u);hb(a.s)}
function Ym(a,b){ln(a,false);pn(a,b);b.getTracks().forEach(wh(hp.prototype._,hp,[a]));a.K.U(b)}
function Un(a,b){null!=b&&null!=a.D&&b.getTracks().forEach(wh(Zp.prototype._,Zp,[a,b]))}
function qh(a,b){typeof window===js&&typeof window['$gwt']===js&&(window['$gwt'][a]=b)}
function Rb(a,b){this.h=a;this.g=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function Db(a,b,c){Cb.call(this,null,a,b,c|(!a?262144:ns)|(0==(c&6291456)?!a?ps:4194304:0)|0|0|0)}
function ei(){xc.call(this,"Stream already terminated, can't be modified or used")}
function or(a){return ol('video',null,a.j,kl('autoPlay',true,'className',a.h.props['b']))}
function fk(a,b){if(0>a||a>b){throw lh(new Ph('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Li(a){if(a.g.Bb()){return true}if(a.g!=a.j){return false}a.g=new vj(a.l.g);return a.g.Bb()}
function Xi(a,b){var c,d;c=b.yb();d=c.length;if(d==0){return false}Wk(a.g,a.g.length,c);return true}
function ij(a){var b,c,d;d=0;for(c=a.qb();c.Bb();){b=c.Cb();d=d+(b!=null?C(b):0);d=d|0}return d}
function jj(a){var b,c,d;d=1;for(c=a.qb();c.Bb();){b=c.Cb();d=31*d+(b!=null?C(b):0);d=d|0}return d}
function kh(a){var b;if(md(a,8)){return a}b=a&&a.__java$exception;if(!b){b=new Bc(a);Yc(b)}return b}
function Gj(a,b,c){var d;d=a.g.get(b);a.g.set(b,c===undefined?null:c);d===undefined?++a.h:++a.i;return d}
function ed(a,b,c,d,e){e.Wb=a;e.Xb=b;e.Yb=zh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function pj(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(kj(a,c.Jb())){return c}}return null}
function gi(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ii(),hi)[b];!c&&(c=hi[b]=new fi(a));return c}return new fi(a)}
function Bc(a){zc();rc(this);this.l=a;sc(this,a);this.o=a==null?ss:yh(a);this.g='';this.h=a;this.g=''}
function pc(a,b,c,d){this.j=a;this.l=d?new lj:null;this.o=b;this.h=c;this.m=null;this.g=null;this.i=null}
function Uh(){this.o=Rh++;this.v=null;this.s=null;this.m=null;this.j=null;this.h=null;this.u=null;this.g=null}
function Tj(){this.g=new Wj;this.i=new Wj;this.g.g=this.i;this.i.h=this.g;this.g.h=this.i.g=null;this.h=0}
function um(){if(!tm){tm=(++(R(),R(),Q).l,new Nb);$wnd.Promise.resolve(null).then(wh(vm.prototype.bb,vm,[]))}}
function Sm(a,b,c){a.L==b?I((R(),R(),Q),new Dn(a,c),Es):c.getTracks().forEach(wh(kp.prototype._,kp,[]));return null}
function sb(a){if(2<(a.i&7)){F((R(),R(),Q),new O(new Hb(a)),67108864,null);!!a.g&&Z(a.g);Ob(a.m);a.i=a.i&-8|1}}
function Pb(a){if(1==(3&a.g)){a.g=-4&a.g|0;0==(a.g&ns)?Qb(a):ub(a.h.g);0!=(a.g&524288)&&(2==(3&a.g)||(a.g=-4&a.g|2))}}
function kb(a,b){var c,d;d=a.i;aj(d,b);!!a.h&&ns!=(a.h.i&os)&&a.i.g.length<=0&&0==a.h.g.j&&(a.j||cc((R(),c=Xb,c),a))}
function rq(a){var b,c,d;a.j=0;um();c=(d=(b=$(a.l.j.g),b.length==0?null:b),null==d?as(a.l):Xr(Vr(a.l),d));return c}
function nl(a){var b;b=pl($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=jl(Bs,a);return b}
function Cq(a){var b;b=$wnd.goog.global.globalThis.document;b.fullscreen?b.exitFullscreen():a.v.requestFullscreen()}
function Ah(){var a;a=$wnd.goog.global.globalThis.document.getElementById('app');$wnd.ReactDOM.render((new pq).g,a,null)}
function Kn(a,b){var c;c=a.D.getSenders().find(wh(_p.prototype.ab,_p,[b]));null!=c&&a.D.removeTrack(c);return null}
function fl(a){dl();var b,c,d;c=':'+a;d=cl[c];if(d!=null){return td(d)}d=al[c];b=d==null?el(a):td(d);gl();cl[c]=b;return b}
function yh(a){var b;if(Array.isArray(a)&&a.Yb===zh){return Th(B(a))+'@'+(b=C(a)>>>0,b.toString(16))}return a.toString()}
function _m(a){var b;kn(a,(nb(a.g),!a.v));b=(nb(a.o),a.F);null!=b&&b.getAudioTracks().forEach(wh(dp.prototype._,dp,[]))}
function an(a){var b;qn(a,(nb(a.u),!a.H));b=(nb(a.o),a.F);null!=b&&b.getVideoTracks().forEach(wh(ep.prototype._,ep,[]))}
function Vm(a){var b,c,d;c=(nb(a.o),a.F);d=(nb(a.s),a.G);if(null!=c&&null!=d){b=c;sd(b)!==sd(d.srcObject)&&(d.srcObject=b)}}
function Vn(a,b){var c;if(sd(a.J)===sd(b.currentTarget)){a.J=null;c=(nb(a.o),a.v);(Vp(),Tp)!=c&&Mp!=c&&Op!=c&&Io(a,Mp);bb(a.g)}}
function bc(a){var b;if(a.i){while(!a.i.ub()){b=a.i.Hb(a.i.vb()-1);b.j=false;b.i.g.length>0||(b.h.i&7)>3&&Ab(b.h,3,true)}}}
function B(a){return rd(a)?me:od(a)?ae:nd(a)?$d:ld(a)?a.Wb:dd(a)?a.Wb:a.Wb||Array.isArray(a)&&_c(Sd,1)||Sd}
function C(a){return rd(a)?fl(a):od(a)?td(a):nd(a)?a?1231:1237:ld(a)?a.O():dd(a)?_k(a):!!a&&!!a.hashCode?a.hashCode():_k(a)}
function ro(a){return null==a.J?(Dp(),Bp):(Dp(),ed(_c(ig,1),ls,23,0,[Ap,Cp,zp,yp,Bp]))[a.J.readyState]}
function sm(){qm();return ed(_c(lf,1),ls,9,0,[Wl,Xl,Yl,Zl,$l,_l,am,bm,cm,dm,em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm])}
function Dm(){var a,b;zm.call(this);R();a=++Am;this.h=new pc(a,new Em(this),new Fm(this),true);this.g=(b=new qb(null),b)}
function dk(){ak();var a,b,c;c=_j+++Date.now();a=td($wnd.Math.floor(c*zs))&16777215;b=td(c-a*As);this.g=a^1502;this.h=b^ys}
function Xr(a,b){var c;ll(a.g,'b',b);return c=a.g.props,ml(a.g,qi(c['a']?gi(c['a'].h.j):null)+'-'+c['b']+(Sh(dh),dh.v)),a.g}
function Qj(a,b){var c,d;if(b>=a.h>>1){d=a.i;for(c=a.h;c>b;--c){d=d.h}}else{d=a.g.g;for(c=0;c<b;++c){d=d.g}}return new Vj(a,b,d)}
function Sb(a){var b,c,d;for(b=0;b<a.g.length;b++){d=a.g[b];if(0!=(d.i?d.g.length-d.h+d.j:d.j-d.h)){c=U(d);return c}}return null}
function zi(a,b,c){var d,e;for(e=a.qb();e.Bb();){d=e.Cb();if(sd(b)===sd(d)||b!=null&&A(b,d)){c&&e.Db();return true}}return false}
function Ic(){var a;if(Dc!=0){a=Cc();if(a-Ec>2000){Ec=a;Fc=$wnd.setTimeout(Oc,10)}}if(Dc++==0){Rc((Qc(),Pc));return true}return false}
function Eb(a,b){Cb.call(this,a,new Fb(a),null,b|(ns==(b&os)?0:524288)|(0==(b&6291456)?ns==(b&os)?4194304:ps:0)|0|268435456|0)}
function ym(a,b){zi(a.i,b,true);3==a.i.h&&Rj(a.i);Nj(a.i,b);mb(a.g);$wnd.goog.global.globalThis.localStorage.setItem(Ds,pi(a.i))}
function Wm(a){var b;++a.L;b=a.L;Rm(a);ln(a,true);a.J.Rb().then(wh(fp.prototype.bb,fp,[a,b])).catch(wh(gp.prototype.bb,gp,[a,b]))}
function Zm(a){var b;b=(nb(a.o),a.F);Rm(a);I((R(),R(),Q),new zn(a,false),Es);null!=b&&b.getTracks().forEach(wh(jp.prototype._,jp,[]))}
function ai(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function bk(a,b){var c,d;Zk(b>0);if((b&-b)==b){return td(b*ck(a)*4.6566128730773926E-10)}do{c=ck(a);d=c%b}while(c-d+(b-1)<0);return td(d)}
function Zc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function $m(a,b){var c;ln(a,false);if(qd(b,$wnd.DOMException)){c=b;on(a,c.name);nn(a,c.message)}else{on(a,Th(B(b)));nn(a,b==null?ss:yh(b))}}
function Dp(){Dp=vh;Ap=new Ep('CONNECTING',0);Cp=new Ep('OPEN',1);zp=new Ep('CLOSING',2);yp=new Ep('CLOSED',3);Bp=new Ep('NOT_REQUESTED',4)}
function vq(a){var b;this.l=new Dm;this.i=a;R();b=++tq;this.h=new pc(b,new wq(this),new xq(this),false);this.g=new Db(null,new zq(this),Ps)}
function Lm(){var a;this.i=new cp(this);R();a=++Jm;this.h=new pc(a,null,new Mm(this),true);this.g=new db(new Pm,new Nm(this),new Om(this),Gs)}
function mc(a){var b,c,d;for(c=new fj(new ej(new Ki(a.l)));c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.Jb();md(d,11)&&d.T()||b.Kb().Q()}}
function ec(a){var b,c,d;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new fj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;6!=d&&Ab(b,6,true)}}}
function fc(a){var b,c,d;if(a.i.g.length>0&&4==a.g){a.g=5;for(c=new fj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;4==d&&Ab(b,5,true)}}}
function A(a,b){return rd(a)?v(a,b):od(a)?sd(a)===sd(b):nd(a)?sd(a)===sd(b):ld(a)?a.M(b):dd(a)?v(a,b):!!a&&!!a.equals?a.equals(b):sd(a)===sd(b)}
function xm(){var a,b,c;b=new dk;c=new ui;for(a=0;a<10;a++){ri(c,ki('abcdefghijklmnopqrstuvwxyz1234567890',$wnd.Math.abs(bk(b,36))))}return c.g}
function kd(a,b){if(rd(a)){return !!jd[b]}else if(a.Xb){return !!a.Xb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function Xm(a,b){var c;en(a,b);c=(nb(a.o),a.F);if(b){null==c&&Wm(a)}else{if(null!=c){c.getTracks().forEach(wh(kp.prototype._,kp,[]));pn(a,null)}}}
function Xn(a,b){$wnd.goog.global.globalThis.console.log('Websocket.error',b);if(sd(a.J)===sd(b.currentTarget)){bb(a.g);Io(a,(Vp(),Op));a.J=null}}
function $n(a,b){var c;c=b.track;$wnd.goog.global.globalThis.console.log('onRemoveTrack '+c.id);a.H=xk(yk(a.H.xb(),new hq(c)),new rk(new qk));bb(a.h)}
function vl(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function U(a){var b;if(0==(a.i?a.g.length-a.h+a.j:a.j-a.h)){return null}b=a.g[a.h];a.g[a.h]=null;++a.h;if(a.h>=a.g.length){a.h=0;a.i=false}return b}
function $(a){a.u?ob(a.l):nb(a.l);if(Bb(a.m)){if(a.u&&(R(),!(!!Xb&&!!Xb.l))){return F((R(),R(),Q),new eb(a),83888128,null)}else{ub(a.m)}}return cb(a)}
function oi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function cd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function D(b,c,d){var e,f;try{hc(b,d);try{f=(c.g.Q(),null)}finally{ic()}return f}catch(a){a=kh(a);if(md(a,8)){e=a;throw lh(e)}else throw lh(a)}finally{L(b)}}
function db(a,b,c,d){this.i=a;this.o=b;this.s=c;this.v=null;this.u=16384==(d&16384);this.m=new Eb(this,d&-16385);this.l=new qb(this.m);ns==(d&os)&&tb(this.m)}
function Yn(a,b){var c,d;if(sd(a.D)===sd(b.currentTarget)){c=b.candidate;null!=c&&null!=a.J&&eo(a,(d={},d[Hs]=Ks,d[Ls]=c.sdpMLineIndex,d[Ks]=c.candidate,d))}}
function Wn(a,b){var c;if(sd(a.D)===sd(b.currentTarget)){c=a.D.iceConnectionState;if(v('disconnected',c)||v('failed',c)||v('closed',c)){a.H.pb(new np);a.H=new dj;bb(a.h)}}}
function dc(a){var b,c;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new fj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);5==(b.i&7)?Ab(b,6,true):4==(b.i&7)&&(a.g=4)}}}
function Nn(a,b){var c,d;if(Ak(a.H.xb(),new eq(b))){c=new fq;d=new vn(new gq(b),c,true,true);Wm(d);a.H.sb(d);b.onremovetrack=wh(op.prototype.fb,op,[a])}return null}
function pi(a){var b,c,d;d=new ok;for(c=Qj(a,0);c.h!=c.j.i;){b=Uj(c);!d.g?(d.g=new vi(d.j)):si(d.g,d.h);si(d.g,b)}return !d.g?d.i:d.l.length==0?d.g.g:d.g.g+(''+d.l)}
function Jb(a){var b,c;if(0==a.i){b=Tb(a.j);if(0==b){a.g=0;return false}else if(a.g+1>a.h){a.g=0;return false}else{a.g=a.g+1;a.i=b}}--a.i;c=Sb(a.j);Pb(c);return true}
function ph(b,c,d,e){oh();var f=mh;$moduleName=c;$moduleBase=d;jh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{is(g)()}catch(a){b(c,a)}}else{is(g)()}}
function $q(a,b){var c,d,e;b.preventDefault();c=(ob(a.h),a.i);null!=c&&(d=$wnd.goog.global.globalThis.location,e=c.length==0?c:'#'+c,v(d.hash,e)||(d.hash=e),undefined)}
function pl(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function rr(a){var b;this.j=wh(ds.prototype.U,ds,[this]);this.h=a;this.i=a.props['a'];R();b=++qr;this.g=new pc(b,null,null,false);fn(this.i,this,new sr(this));L((null,Q))}
function ak(){ak=vh;var a,b,c,d;Zj=bd(ud,ls,236,25,15,1);$j=bd(ud,ls,236,33,15,1);d=1.52587890625E-5;for(b=32;b>=0;b--){$j[b]=d;d*=0.5}c=1;for(a=24;a>=0;a--){Zj[a]=c;c*=0.5}}
function Bj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Cj()}}
function zm(){var a,b,c,d,e;this.i=new Tj;this.j=new Lm;e=$wnd.goog.global.globalThis.localStorage.getItem(Ds);if(null!=e){for(b=mi(e),c=0,d=b.length;c<d;++c){a=b[c];Oj(this.i,a)}}}
function In(a){var b;b=(ob(a.m),a.u);(Jp(),Hp)==b?a.D.createOffer().then(wh(aq.prototype.bb,aq,[a])).then(wh(bq.prototype.bb,bq,[a])).catch(wh(cq.prototype.bb,cq,[])):eo(a,jl(Hs,Is))}
function bj(a,b){var c,d,e,f;e=null;f=0;for(d=0;d<a.g.length;++d){c=a.g[d];if(b.Qb(c)){if(e==null){e=Tk(a.g,d);f=d}}else e!=null&&(e[f++]=c)}if(e==null){return false}a.g=e;return true}
function _n(a,b){var c;if(sd(a.D)===sd(b.currentTarget)){$wnd.goog.global.globalThis.console.log('onTrack',b);c=b.streams;a.H=new ej(a.H);c.forEach(wh(dq.prototype._,dq,[a]));bb(a.h)}}
function F(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Xb){g=c.R()}else{hc(b,e);try{g=c.R()}finally{ic()}}return g}catch(a){a=kh(a);if(md(a,8)){f=a;throw lh(f)}else throw lh(a)}finally{L(b)}}
function sh(){rh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Vc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Zb()&&(c=Uc(c,g)):g[0].Zb()}catch(a){a=kh(a);if(md(a,8)){d=a;Gc();Mc(md(d,47)?d.$():d)}else throw lh(a)}}return c}
function Ac(a){var b;if(a.i==null){b=sd(a.h)===sd(yc)?null:a.h;a.j=b==null?ss:pd(b)?b==null?null:b.name:rd(b)?'String':Th(B(b));a.g=a.g+': '+(pd(b)?b==null?null:b.message:b+'');a.i='('+a.j+') '+a.g}}
function Y(b){var c,d,e;e=b.v;try{d=b.i.R();if(!(sd(e)===sd(d)||e!=null&&A(e,d))){b.v=d;b.h=null;lb(b.l)}}catch(a){a=kh(a);if(md(a,13)){c=a;if(!b.h){b.v=null;b.h=c;lb(b.l)}throw lh(c)}else throw lh(a)}}
function ck(a){var b,c,d,e,f,g;e=a.g*ys+a.h*1502;g=a.h*ys+11;b=$wnd.Math.floor(g*zs);e+=b;g-=b*As;e%=As;a.g=e;a.h=g;d=a.g*128;f=$wnd.Math.floor(a.h*$j[31]);c=d+f;c>=2147483648&&(c-=4294967296);return c}
function sj(a,b,c){var d,e,f,g,h;h=b==null?0:(g=C(b),g|0);e=(d=a.g.get(h),d==null?new Array:d);if(e.length==0){a.g.set(h,e)}else{f=pj(b,e);if(f){return f.Lb(c)}}e[e.length]=new Ui(b,c);++a.h;return null}
function el(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ki(a,c++)}b=b|0;return b}
function Uk(a,b,c,d,e){var f,g,h,i,j;if(sd(a)===sd(c)){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function go(a){var b;b=gn(a.I);null!=a.D&&null!=b&&hn(a.I)&&null!=a.D&&b.getTracks().forEach(wh($p.prototype._,$p,[a]));tn(a.I);null!=a.D&&hn(a.I)&&null!=b&&null!=a.D&&b.getTracks().forEach(wh(Zp.prototype._,Zp,[a,b]))}
function ub(b){var c;if(1!=(b.i&7)){try{if(4!=(b.i&7)){if(0!=(b.i&512)){!!b.l&&(b.i&=-513);c=b.j;G((R(),R(),Q),b,c)}else{b.l.Q()}}else 0!=(b.i&512)&&!!b.l&&(b.i&=-513)}catch(a){a=kh(a);if(md(a,8)){R()}else throw lh(a)}}}
function Bi(a,b){var c,d,e;c=b.Jb();e=b.Kb();d=rd(c)?c==null?Di(rj(a.g,null)):Fj(a.h,c):Di(rj(a.g,c));if(!(sd(e)===sd(d)||e!=null&&A(e,d))){return false}if(d==null&&!(rd(c)?Fi(a,c):!!rj(a.g,c))){return false}return true}
function W(a){var b,c,d,e,f,g;b=a.i?a.g.length-a.h+a.j:a.j-a.h;if(b+1>a.g.length){g=(a.g.length-1)*2+1;c=bd(je,ls,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.h+d)%a.g.length;c[f]=a.g[e];a.g[e]=null;++f}a.g=c;a.h=0;a.j=f;a.i=false}}
function Cb(a,b,c,d){this.h=new dj;this.m=new Rb(new Gb(this),d&6520832|262144|ns);this.i=d&-6520833|3;this.g=a;this.j=b;this.l=c;!!this.j&&(this.i|=512);!this.g&&!!this.j&&(K((R(),R(),Q),this),0==(this.m.g&ps)&&L((null,Q)))}
function hr(a){var b,c,d;this.l=a;this.o=a.props['a'];R();b=++dr;this.j=new pc(b,null,new ir(this),false);this.h=(d=new qb((c=null,c)),d);this.g=new Db(null,new mr(this),Ps);!!this.o&&Bm(this.o,this,new jr(this));L((null,Q))}
function tj(a,b){var c,d,e,f,g,h;g=b==null?0:(f=C(b),f|0);d=(c=a.g.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(kj(b,e.Jb())){if(d.length==1){d.length=0;wj(a.g,g)}else{d.splice(h,1)}--a.h;return e.Kb()}}return null}
function Vp(){Vp=vh;Up=new Wp('NOT_READY',0);Np=new Wp('CONNECTED',1);Sp=new Wp('JOIN_REQUESTED',2);Rp=new Wp('JOIN_REJECTED',3);Qp=new Wp('JOINED',4);Mp=new Wp('CLOSED',5);Tp=new Wp('LEFT',6);Pp=new Wp('FULL',7);Op=new Wp('ERROR',8)}
function uh(a,b,c){var d=rh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=rh[b]),xh(h));_.Xb=c;!b&&(_.Yb=zh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.Wb=f)}
function rl(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;il(b,wh(ul.prototype.Sb,ul,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Bs]=c[0],undefined):(d[Bs]=c,undefined));return ol(a,e,f,d)}
function _h(a){if(a.nb()){var b=a.i;b.ob()?(a.v='['+b.u):!b.nb()?(a.v='[L'+b.lb()+';'):(a.v='['+b.lb());a.h=b.kb()+'[]';a.s=b.mb()+'[]';return}var c=a.m;var d=a.j;d=d.split('/');a.v=ai('.',[c,ai('$',d)]);a.h=ai('.',[c,ai('.',d)]);a.s=d[d.length-1]}
function fo(a){a.D=new $wnd.RTCPeerConnection(Ih({},[Lh({})]));a.D.onicecandidate=wh(wp.prototype.hb,wp,[a]);a.D.ontrack=wh(xp.prototype.ib,xp,[a]);a.D.onconnectionstatechange=wh(mp.prototype.eb,mp,[a]);a.D.onnegotiationneeded=wh(Yp.prototype.eb,Yp,[a]);Un(a,gn(a.B));Un(a,gn(a.I))}
function Bb(b){var c,d,e,f,g;g=b.i&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new fj(b.h);e.g<e.i.g.length;){d=(e.h=e.g++,e.i.g[e.h]);if(d.h){f=d.h;c=f.g;try{$(c)}catch(a){a=kh(a);if(!md(a,8))throw lh(a)}if(6==(b.i&7)){return true}}}}}wb(b);return false}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.X();return a&&a.V()}},suppressed:{get:function(){return c.W()}}})}catch(a){}}}
function Aj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function Qq(a){var b;this.s=new Lr(this);this.j=a;this.m=a.props['a'];this.o=a.props['b'];R();b=++Mq;this.i=new pc(b,new Rq(this),new Sq(this),false);this.g=new db(new Yq,new Tq(this),new Uq(this),35815424);this.h=new Db(null,new Zq(this),Ps);Bm(this.m,this,new Vq(this));this.u=new Lo(this.o,(Vp(),Up),(Jp(),Ip));Co(this.u);Cm(this.m,this.o);L((null,Q))}
function Ab(a,b,c){var d,e,f,g;g=a.i&7;if(b!=g){a.i=a.i&-8|b;if(!a.g&&6==b){c&&(1==(a.i&7)||1==(3&a.m.g)||K((R(),R(),Q),a))}else if(!!a.g&&4==g&&(6==b||5==b)){pb(a.g.l);c&&(1==(a.i&7)||1==(3&a.m.g)||K((R(),R(),Q),a))}else if(3==b||3!=g&&2==b){if(a.g){d=a.g;zb((e=d.s,e));d.v=null}Yi(a.h,new Ib(a));a.h.g=bd(je,ls,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.g&&zb((f=a.g.o,f))}}
function mi(a){var b,c,d,e,f,g,h,i;b=new RegExp('\\|','g');h=bd(me,ls,2,0,6,1);c=0;i=a;e=null;while(true){g=b.exec(i);if(g==null||i==''){h[c]=i;break}else{f=g.index;h[c]=i.substr(0,f);i=ni(i,f+g[0].length,i.length);b.lastIndex=0;if(e==i){h[c]=i.substr(0,1);i=i.substr(1)}e=i;++c}}if(a.length>0){d=h.length;while(d>0&&h[d-1]==''){--d}d<h.length&&(h.length=d)}return h}
function ao(a){var b,c;I((R(),R(),Q),new Wo(a),Os);mn(a.B,true);bb(a.g);Ho(a,(Jp(),Ip));Io(a,(Vp(),Up));a.J=new $wnd.WebSocket((b=$wnd.goog.global.globalThis.location,c=v('https',b.protocol)?'wss':'ws',c+'://'+b.hostname+':'+3737+'/r/'+a.C));a.J.onopen=wh(sp.prototype.eb,sp,[a]);a.J.onmessage=wh(tp.prototype.gb,tp,[a]);a.J.onclose=wh(up.prototype.cb,up,[a]);a.J.onerror=wh(vp.prototype.eb,vp,[a])}
function vn(a,b,c,d){var e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;this.J=a;this.K=b;R();e=++bn;this.I=new pc(e,null,new wn(this),true);this.B=c;this.v=d;this.H=true;this.h=(o=new qb((g=null,g)),o);this.o=(p=new qb((h=null,h)),p);this.l=(q=new qb((i=null,i)),q);this.j=(r=new qb((j=null,j)),r);this.i=(s=new qb((k=null,k)),s);this.g=(t=new qb((l=null,l)),t);this.u=(u=new qb((m=null,m)),u);this.s=(n=new qb((f=null,f)),n);this.m=new Db(new xn(this),null,404750336);L((null,Q))}
function qm(){qm=vh;Wl=new rm(Cs,0);Xl=new rm('checkbox',1);Yl=new rm('color',2);Zl=new rm('date',3);$l=new rm('datetime',4);_l=new rm('email',5);am=new rm('file',6);bm=new rm('hidden',7);cm=new rm('image',8);dm=new rm('month',9);em=new rm('number',10);fm=new rm('password',11);gm=new rm('radio',12);hm=new rm('range',13);im=new rm('reset',14);jm=new rm('search',15);km=new rm('submit',16);lm=new rm('tel',17);mm=new rm('text',18);nm=new rm('time',19);om=new rm('url',20);pm=new rm('week',21)}
function Lo(a,b,c){var d,e,f,g,h,i,j,k,l;this.G=new dj;this.F=new oj;this.B=new vn(new lp,new pp(this),false,true);this.I=new vn(new qp,new rp(this),false,false);this.H=new dj;this.C=a;R();d=++ko;this.A=new pc(d,new Mo(this),new No(this),true);this.v=b;this.u=c;this.s='';this.o=(i=new qb((f=null,f)),i);this.m=(j=new qb((g=null,g)),j);this.l=(k=new qb((e=null,e)),k);this.j=(l=new qb(null),l);this.i=(h=new qb(null),h);this.g=new db(new Oo(this),null,null,Gs);this.h=new db(new Po(this),null,null,Gs)}
function $b(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.l){return}j=(n=a.l.i&7,n>3?n:4);e=false;c=0;if(!!a.h&&1!=(a.l.i&7)){m=a.h.g.length;for(h=0;h<m;h++){k=Zi(a.h,h);if(-1!=k.l&&-2!=k.l){k.l=-1;h!=c&&cj(a.h,c,k);++c;if(k.h){l=k.h;f=l.i&7;f==6&&(j=f)}}}}d=a.l.h;for(i=d.g.length-1;i>=0;i--){k=d.g[i];if(-1==k.l){k.l=0}else{kb(k,a.l);e=true}}2<(a.l.i&7)&&4!=j&&(a.l.i&7)<j&&Ab(a.l,j,false);if(a.h){for(g=c-1;g>=0;g--){k=Zi(a.h,g);if(-1==k.l){k.l=0;jb(k,a.l);e=true}}}if(a.h){for(g=a.h.g.length-1;g>=c;g--){_i(a.h,g)}e&&yb(a.l,a.h)}else{e&&yb(a.l,new dj)}if(gb(a.l)&&!!a.l.g){b=a.l.g;k=b.l;!!k.h&&ns!=(k.h.i&os)&&k.i.g.length<=0&&0==k.h.g.j&&cc(a,k)}}
function br(a){var b,c,d,e;a.m=0;um();b=(c=(ob(a.h),a.i),d=a.o,e=(nb(d.g),d.i),rl(Ss,Dl(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,['home'])),wh(Zr.prototype.Tb,Zr,[a])),[rl('h1',null,['vChat']),rl(Ts,Pl(new $wnd.Object,'roomCode'),['Enter a room code.']),rl(Ws,zl(Hl(Ml(Il(Kl(Jl(Ol(wl(Ll(vl(Cl(new $wnd.Object,(qm(),mm)),ed(_c(me,1),ls,2,6,['roomCodeInput'])),'Room code'),'roomCode'),null==c?'':c),wh(_r.prototype.Tb,_r,[a]))),10)))),null),rl($s,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,['roomSelectButtons'])),[rl(Cs,Cl(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[Ys])),(Tl(),Sl)),['Join']),rl('a',Al(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[Ys])),'#'+xm()),['Join Random'])]),e.h==0?null:nl([rl($s,null,['Recently used rooms:']),nl(Dk(zk(new Ek(null,new mk(e,16)),new $r),new tl))])]));return b}
function Cj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[xs]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Aj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[xs]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function Kq(a){var b,c;a.l=0;um();c=(b=a.u.B,rl($s,yl(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,['room-view'])),wh(Mr.prototype.U,Mr,[a])),[rl($s,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,['video-section'])),[rl($s,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,['video-list'])),Dk(zk($(a.u.h).xb(),new Or),new tl)),rl($s,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,['active-video'])),[rl($s,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,['active-video-wrapper'])),[fs(es(a.u.B),'active-video-element')]),rl($s,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,['controls'])),[rl(Cs,Bl(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[at])),wh(Pr.prototype.Ub,Pr,[a])),[rl('img',El(Gl(Fl(new $wnd.Object,hn(a.u.I)?'img/screen_share_on.svg':'img/screen_share_off.svg'))),null)]),rl(Cs,Bl(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[at])),wh(Qr.prototype.Ub,Qr,[b])),[rl('img',El(Gl(Fl(new $wnd.Object,(nb(b.g),b.v?'img/mic_on.svg':'img/mic_off.svg')))),null)]),rl(Cs,Bl(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[at])),wh(Rr.prototype.Ub,Rr,[b])),[rl('img',El(Gl(Fl(new $wnd.Object,(nb(b.u),b.H?'img/cam_on.svg':'img/cam_off.svg')))),null)]),rl(Cs,Bl(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[at])),wh(Sr.prototype.Ub,Sr,[a])),[rl('img',El(Gl(Fl(new $wnd.Object,$(a.g)?'img/fullscreen_on.svg':'img/fullscreen_off.svg'))),null)])])])]),rl($s,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,['message-area'])),[Hq(a)])]));return c}
function Zn(a,b){var c,d,e,f,g,h,i,j;e=b.data;d=$wnd.goog.global.globalThis.console;h=$wnd.JSON.parse(e);g=h;if(sd(a.J)===sd(b.currentTarget)){bb(a.g);c=g[Hs];if(v('create',c)){d.log('Connected to room as host');Ho(a,(Jp(),Hp));Io(a,(Vp(),Qp))}else if(v('connect',c)){d.log('Connected to room as guest');Ho(a,(Jp(),Gp));Io(a,(Vp(),Np))}else if(v('full',c)){d.log('Room full. Leaving room.');Ho(a,(Jp(),Ip));Tn(a,(Vp(),Pp))}else if(v(Ms,c)){f=g['id'];i=g['message'];d.log("Guest '"+f+"' requested access to room with message '"+i+"'");Wi(a.G,new wm(f,i));mb(a.j)}else if(v('accept',c)){d.log('Host allowed guest to join room.');Io(a,(Vp(),Qp));fo(a)}else if(v('reject',c)){d.log('Host rejected guest from room.');Io(a,(Vp(),Rp))}else if(v('accepted',c)){f=g['id'];d.log("Host accepted guest '"+f+"' into room.");mj(a.F,f);mb(a.i)}else if(v('remove',c)){f=g['id'];if(nj(a.F,f)){d.log("Guest '"+f+Ns);mb(a.i)}else if(bj(a.G,new iq(f))){d.log("Client '"+f+Ns);mb(a.j)}}else if(v('offer',c)){a.D.setRemoteDescription(g[Js]);a.D.createAnswer().then(wh(jq.prototype.bb,jq,[a])).then(wh(kq.prototype.bb,kq,[a])).catch(wh(lq.prototype.bb,lq,[]))}else v('answer',c)?a.D.setRemoteDescription(g[Js]):v(Ks,c)?a.D.addIceCandidate(Jh(Kh({},g[Ls]),g[Ks])):v(Is,c)&&(j=(ob(a.m),a.u),(Jp(),Hp)==j?a.D.createOffer().then(wh(aq.prototype.bb,aq,[a])).then(wh(bq.prototype.bb,bq,[a])).catch(wh(cq.prototype.bb,cq,[])):eo(a,jl(Hs,Is)))}}
function Hq(a){var b,c;c=Jo(a.u);if((Vp(),Up)==c){return nl([rl(Rs,null,['Getting ready...']),rl('p',null,["You'll be able to join in just a moment."])])}else if(Op==c){return nl([rl(Rs,null,['Service Offline']),rl('p',null,['The chat service is offline at the moment. Try again later.'])])}else if(Np==c){return nl([rl(Rs,null,['Ready to join?']),rl('p',null,['Request access to join the room.']),rl(Ss,Dl(new $wnd.Object,wh(Kr.prototype.Tb,Kr,[a])),[rl(Ts,Pl(new $wnd.Object,Us),[Vs]),rl(Ws,Ml(Il(Ol(Jl(Hl(wl(Ll(Cl(new $wnd.Object,(qm(),mm)),Xs),Us)),wh(Nr.prototype.Tb,Nr,[a])),Fo(a.u)),30)),null),rl(Cs,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[Ys])),[Zs])])])}else if(Sp==c){return nl([rl(Rs,null,['Joining room']),rl('p',null,['Waiting for host to allow access to the room.'])])}else if(Qp==c&&(Jp(),Hp)==Go(a.u)&&qo(a.u).g.length!=0){b=qo(a.u).g[0];return nl([rl(Rs,null,['Guest requests access']),rl('p',null,['A guest has sent you a message to join the room:']),rl($s,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,['request-message'])),[b.h]),rl(Ss,Dl(new $wnd.Object,wh(Jr.prototype.Tb,Jr,[])),[rl(Cs,Bl(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[Ys])),wh(Tr.prototype.Ub,Tr,[a,b])),['Accept']),rl(Cs,Bl(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[Ys])),wh(Ur.prototype.Ub,Ur,[a,b])),['Reject'])])])}else return Qp==c&&(Jp(),Hp)==Go(a.u)&&Ii(po(a.u).g)==0?nl([rl(Rs,null,['Waiting for guests to join']),rl('p',null,['Waiting for someone to join this room']),rl('a',Al(new $wnd.Object,'#'+a.u.C),[a.u.C])]):Qp==c?nl([rl(Rs,null,['Joined room']),rl('p',null,['Joined room. Feel free to chat.'])]):Rp==c?nl([rl(Rs,null,['Access denied']),rl('p',null,['The host denied access to the room. You can attempt to re-request access to join the room.']),rl(Ss,Dl(new $wnd.Object,wh(Kr.prototype.Tb,Kr,[a])),[rl(Ts,Pl(new $wnd.Object,Us),[Vs]),rl(Ws,Ml(Il(Ol(Jl(Hl(wl(Ll(Cl(new $wnd.Object,(qm(),mm)),Xs),Us)),wh(Nr.prototype.Tb,Nr,[a])),Fo(a.u)),30)),null),rl(Cs,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[Ys])),[Zs])])]):Mp==c?nl([rl(Rs,null,['Room closed']),rl('p',null,[(Jp(),Hp)==Go(a.u)?'You closed the room.':'The host closed the room.']),rl('a',Al(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[Ys])),'#'),[_s])]):Pp==c?nl([rl(Rs,null,['Room full']),rl('p',null,['The room is full and no other guests can connect at this time.']),rl('a',Al(vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[Ys])),'#'),[_s])]):Tp==c?nl([rl(Rs,null,['Left the room']),rl('p',null,['You left the room. Request access to re-join the room.']),rl(Ss,Dl(new $wnd.Object,wh(Kr.prototype.Tb,Kr,[a])),[rl(Ts,Pl(new $wnd.Object,Us),[Vs]),rl(Ws,Ml(Il(Ol(Jl(Hl(wl(Ll(Cl(new $wnd.Object,(qm(),mm)),Xs),Us)),wh(Nr.prototype.Tb,Nr,[a])),Fo(a.u)),30)),null),rl(Cs,vl(new $wnd.Object,ed(_c(me,1),ls,2,6,[Ys])),[Zs])])]):null}
var js='object',ks={6:1},ls={4:1},ms={11:1},ns=1048576,os=1835008,ps=2097152,qs='__noinit__',rs={4:1,13:1,10:1,8:1},ss='null',ts={31:1,67:1},us={31:1,61:1},vs={43:1},ws={4:1,31:1,61:1},xs='delete',ys=15525485,zs=5.9604644775390625E-8,As=16777216,Bs='children',Cs='button',Ds='vchat.rooms',Es=142606336,Fs='hashchange',Gs=35651584,Hs='command',Is='renegotiate',Js='session',Ks='candidate',Ls='mlineindex',Ms='request_access',Ns="' left the room.",Os=75497472,Ps=1411518464,Qs='fullscreenchange',Rs='h2',Ss='form',Ts='label',Us='requestAccessMessage',Vs='Enter a message to send to the host to request access.',Ws='input',Xs="Hi, I'm John Doe.",Ys='primary-button',Zs='Request Access',$s='div',_s='Return to Home',at='control-btn';var _,rh,mh,jh=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;sh();uh(1,null,{},w);_.M=function(a){return v(this,a)};_.N=function(){return this.Wb};_.O=ct;_.P=function(){var a;return Th(B(this))+'@'+(a=C(this)>>>0,a.toString(16))};_.equals=function(a){return this.M(a)};_.hashCode=function(){return this.O()};_.toString=function(){return this.P()};var gd,hd,jd;uh(71,1,{},Uh);_.jb=function(a){var b;b=new Uh;b.l=4;a>1?(b.i=Zh(this,a-1)):(b.i=this);return b};_.kb=function(){Sh(this);return this.h};_.lb=function(){return Th(this)};_.mb=function(){Sh(this);return this.s};_.nb=function(){return (this.l&4)!=0};_.ob=function(){return (this.l&1)!=0};_.P=function(){return ((this.l&2)!=0?'interface ':(this.l&1)!=0?'':'class ')+(Sh(this),this.v)};_.l=0;_.o=0;var Rh=1;var je=Wh(1);var _d=Wh(71);uh(103,1,{},M);_.h=1;_.i=false;_.j=true;_.l=0;var yd=Wh(103);uh(104,1,ks,N);_.Q=function(){Kb(this.g)};var vd=Wh(104);uh(55,1,{},O);_.R=function(){return this.g.Q(),null};var wd=Wh(55);uh(105,1,{},P);var xd=Wh(105);var Q;uh(56,1,{56:1},X);_.h=0;_.i=false;_.j=0;var zd=Wh(56);uh(259,1,ms);_.P=function(){var a;return Th(this.Wb)+'@'+(a=C(this)>>>0,a.toString(16))};var Cd=Wh(259);uh(49,259,ms,db);_.S=function(){Z(this)};_.T=bt;_.g=false;_.j=0;_.u=false;var Bd=Wh(49);uh(144,1,{},eb);_.R=function(){return ab(this.g)};var Ad=Wh(144);uh(12,259,{11:1,12:1},qb);_.S=function(){hb(this)};_.T=function(){return -2==this.l};_.g=4;_.j=false;_.l=0;var Ed=Wh(12);uh(143,1,ks,rb);_.Q=function(){ib(this.g)};var Dd=Wh(143);uh(22,259,{11:1,22:1},Db,Eb);_.S=function(){sb(this)};_.T=function(){return 1==(this.i&7)};_.i=0;var Jd=Wh(22);uh(138,1,{},Fb);_.Q=function(){Y(this.g)};var Fd=Wh(138);uh(139,1,ks,Gb);_.Q=function(){ub(this.g)};var Gd=Wh(139);uh(140,1,ks,Hb);_.Q=function(){xb(this.g)};var Hd=Wh(140);uh(141,1,{},Ib);_.U=function(a){vb(this.g,a)};var Id=Wh(141);uh(116,1,{},Lb);_.g=0;_.h=0;_.i=0;var Kd=Wh(116);uh(149,1,ms,Nb);_.S=function(){Mb(this)};_.T=bt;_.g=false;var Ld=Wh(149);uh(80,259,{11:1,80:1},Rb);_.S=function(){Ob(this)};_.T=function(){return 2==(3&this.g)};_.g=0;var Nd=Wh(80);uh(115,1,{},Wb);var Md=Wh(115);uh(150,1,{},gc);_.P=function(){var a;return Sh(Od),Od.v+'@'+(a=_k(this)>>>0,a.toString(16))};_.g=0;var Xb;var Od=Wh(150);uh(21,1,ms,pc);_.S=function(){kc(this)};_.T=function(){return this.s<0};_.P=function(){var a;return Sh(Qd),Qd.v+'@'+(a=_k(this)>>>0,a.toString(16))};_.j=0;_.s=0;var Qd=Wh(21);uh(137,1,ks,qc);_.Q=function(){nc(this.g)};var Pd=Wh(137);uh(8,1,{4:1,8:1});_.V=jt;_.W=function(){return Dk(zk(hj((this.s==null&&(this.s=bd(oe,ls,8,0,0,1)),this.s)),new wi),new Hk)};_.X=function(){return this.m};_.Y=function(){return this.o};_.Z=function(){tc(this,vc(new Error(uc(this,this.o))));Yc(this)};_.P=function(){return uc(this,this.Y())};_.l=qs;_.u=true;var oe=Wh(8);uh(13,8,{4:1,13:1,8:1});var ce=Wh(13);uh(10,13,rs);var ke=Wh(10);uh(98,10,rs);var he=Wh(98);uh(99,98,rs);var Ud=Wh(99);uh(47,99,{47:1,4:1,13:1,10:1,8:1},Bc);_.Y=function(){Ac(this);return this.i};_.$=function(){return sd(this.h)===sd(yc)?null:this.h};var yc;var Rd=Wh(47);var Sd=Wh(0);uh(243,1,{});var Td=Wh(243);var Dc=0,Ec=0,Fc=-1;uh(108,243,{},Tc);var Pc;var Vd=Wh(108);var Wc;uh(253,1,{});var Xd=Wh(253);uh(100,253,{},$c);var Wd=Wh(100);uh(73,1,{95:1});_.P=bt;var Yd=Wh(73);uh(102,10,rs);var fe=Wh(102);uh(142,102,rs,Ph);var Zd=Wh(142);gd={4:1,96:1,20:1};var $d=Wh(96);uh(54,1,{4:1,54:1});var ie=Wh(54);hd={4:1,20:1,97:1,54:1};var ae=Wh(97);uh(16,1,{4:1,20:1,16:1});_.M=function(a){return this===a};_.O=ct;_.P=function(){return this.g!=null?this.g:''+this.h};_.h=0;var be=Wh(16);uh(72,10,rs,di);var de=Wh(72);uh(101,10,rs,ei);var ee=Wh(101);uh(37,54,{4:1,20:1,37:1,54:1},fi);_.M=function(a){return md(a,37)&&a.g==this.g};_.O=bt;_.P=function(){return ''+this.g};_.g=0;var ge=Wh(37);var hi;uh(350,1,{});jd={4:1,95:1,20:1,2:1};var me=Wh(2);uh(53,73,{95:1},ui,vi);var le=Wh(53);uh(354,1,{});uh(93,1,{},wi);_.rb=function(a){return a.l};var ne=Wh(93);uh(46,10,rs,xi,yi);var pe=Wh(46);uh(254,1,{31:1});_.pb=it;_.wb=function(){return new mk(this,0)};_.xb=function(){return new Ek(null,this.wb())};_.sb=function(a){throw lh(new yi('Add not supported on this collection'))};_.tb=function(a){return zi(this,a,false)};_.ub=function(){return this.vb()==0};_.yb=function(){return this.zb(bd(je,ls,1,this.vb(),5,1))};_.zb=function(a){var b,c,d,e;e=this.vb();a.length<e&&(a=Yk(new Array(e),a));d=a;c=this.qb();for(b=0;b<e;++b){d[b]=c.Cb()}a.length>e&&(a[e]=null);return a};_.P=function(){var a,b,c;c=new pk(', ','[',']');for(b=this.qb();b.Bb();){a=b.Cb();nk(c,a===this?'(this Collection)':a==null?ss:yh(a))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var qe=Wh(254);uh(257,1,{239:1});_.M=function(a){var b,c,d;if(a===this){return true}if(!md(a,48)){return false}d=a;if(this.g.h+this.h.h!=d.g.h+d.h.h){return false}for(c=new Oi((new Ki(d)).g);c.h;){b=Mi(c);if(!Bi(this,b)){return false}}return true};_.O=function(){return ij(new Ki(this))};_.P=function(){var a,b,c;c=new pk(', ','{','}');for(b=new Oi((new Ki(this)).g);b.h;){a=Mi(b);nk(c,Ci(this,a.Jb())+'='+Ci(this,a.Kb()))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var Ce=Wh(257);uh(117,257,{239:1});var te=Wh(117);uh(256,254,ts);_.wb=function(){return new mk(this,1)};_.M=function(a){var b;if(a===this){return true}if(!md(a,67)){return false}b=a;if(b.vb()!=this.vb()){return false}return Ai(this,b)};_.O=function(){return ij(this)};var Ee=Wh(256);uh(35,256,ts,Ki);_.tb=function(a){return Ji(this,a)};_.qb=function(){return new Oi(this.g)};_.vb=ft;var se=Wh(35);uh(38,1,{},Oi);_.Ab=dt;_.Cb=function(){return Mi(this)};_.Bb=gt;_.Db=function(){Ni(this)};_.h=false;var re=Wh(38);uh(255,254,us);_.wb=function(){return new mk(this,16)};_.Eb=function(a,b){throw lh(new yi('Add not supported on this list'))};_.sb=function(a){this.Eb(this.vb(),a);return true};_.M=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,61)){return false}f=a;if(this.vb()!=f.vb()){return false}e=f.qb();for(c=this.qb();c.Bb();){b=c.Cb();d=e.Cb();if(!(sd(b)===sd(d)||b!=null&&A(b,d))){return false}}return true};_.O=function(){return jj(this)};_.qb=function(){return new Qi(this)};_.Gb=function(a){return new Ri(this,a)};_.Hb=function(a){throw lh(new yi('Remove not supported on this list'))};var we=Wh(255);uh(74,1,{},Qi);_.Ab=dt;_.Bb=function(){return this.h<this.j.vb()};_.Cb=function(){this.h<this.j.vb();return this.j.Fb(this.i=this.h++)};_.Db=et;_.h=0;_.i=-1;var ue=Wh(74);uh(107,74,{},Ri);_.Db=et;_.Ib=function(a){this.g.Eb(this.h,a);++this.h;this.i=-1};var ve=Wh(107);uh(111,256,ts,Si);_.tb=ht;_.qb=function(){var a;return a=new Oi((new Ki(this.g)).g),new Ti(a)};_.vb=ft;var ye=Wh(111);uh(75,1,{},Ti);_.Ab=dt;_.Bb=function(){return this.g.h};_.Cb=function(){var a;a=Mi(this.g);return a.Jb()};_.Db=function(){Ni(this.g)};var xe=Wh(75);uh(109,1,vs);_.M=function(a){var b;if(!md(a,43)){return false}b=a;return kj(this.g,b.Jb())&&kj(this.h,b.Kb())};_.Jb=bt;_.Kb=gt;_.O=function(){return Yj(this.g)^Yj(this.h)};_.Lb=function(a){var b;b=this.h;this.h=a;return b};_.P=function(){return this.g+'='+this.h};var ze=Wh(109);uh(110,109,vs,Ui);var Ae=Wh(110);uh(258,1,vs);_.M=function(a){var b;if(!md(a,43)){return false}b=a;return kj(this.h.value[0],b.Jb())&&kj(Kj(this),b.Kb())};_.O=function(){return Yj(this.h.value[0])^Yj(Kj(this))};_.P=function(){return this.h.value[0]+'='+Kj(this)};var Be=Wh(258);uh(261,255,us);_.Eb=function(a,b){var c;c=this.Gb(a);c.Ib(b)};_.Fb=function(a){var b;b=this.Gb(a);return b.Cb()};_.qb=function(){return Qj(this,0)};_.Hb=function(a){var b,c;b=this.Gb(a);c=b.Cb();b.Db();return c};var De=Wh(261);uh(15,255,ws,dj,ej);_.Eb=function(a,b){Vk(this.g,a,b)};_.sb=function(a){return Wi(this,a)};_.tb=function(a){return $i(this,a,0)!=-1};_.pb=function(a){Yi(this,a)};_.Fb=function(a){return Zi(this,a)};_.ub=function(){return this.g.length==0};_.qb=function(){return new fj(this)};_.Hb=function(a){return _i(this,a)};_.vb=function(){return this.g.length};_.yb=function(){return Tk(this.g,this.g.length)};_.zb=function(a){var b,c;c=this.g.length;a.length<c&&(a=Yk(new Array(c),a));for(b=0;b<c;++b){a[b]=this.g[b]}a.length>c&&(a[c]=null);return a};var Ge=Wh(15);uh(28,1,{},fj);_.Ab=dt;_.Bb=function(){return this.g<this.i.g.length};_.Cb=function(){return this.h=this.g++,this.i.g[this.h]};_.Db=function(){_i(this.i,this.g=this.h);this.h=-1};_.g=0;_.h=-1;var Fe=Wh(28);uh(48,117,{4:1,48:1,239:1},lj);var He=Wh(48);uh(169,256,{4:1,31:1,67:1},oj);_.sb=function(a){return mj(this,a)};_.tb=ht;_.ub=function(){return Ii(this.g)==0};_.qb=function(){var a;return a=new Oi((new Ki((new Si(this.g)).g)).g),new Ti(a)};_.vb=ft;var Ie=Wh(169);uh(118,1,{},uj);_.pb=it;_.qb=function(){return new vj(this)};_.h=0;var Ke=Wh(118);uh(76,1,{},vj);_.Ab=dt;_.Cb=function(){return this.j=this.g[this.i++],this.j};_.Bb=function(){var a;if(this.i<this.g.length){return true}a=this.h.next();if(!a.done){this.g=a.value[1];this.i=0;return true}return false};_.Db=function(){tj(this.l,this.j.Jb());this.i!=0&&--this.i};_.i=0;_.j=null;var Je=Wh(76);var yj;uh(119,1,{},Ij);_.pb=it;_.qb=function(){return new Jj(this)};_.h=0;_.i=0;var Ne=Wh(119);uh(77,1,{},Jj);_.Ab=dt;_.Cb=function(){return this.i=this.g,this.g=this.h.next(),new Lj(this.j,this.i,this.j.i)};_.Bb=function(){return !this.g.done};_.Db=function(){Hj(this.j,this.i.value[0])};var Le=Wh(77);uh(120,258,vs,Lj);_.Jb=function(){return this.h.value[0]};_.Kb=function(){return Kj(this)};_.Lb=function(a){return Gj(this.g,this.h.value[0],a)};_.i=0;var Me=Wh(120);uh(160,261,ws,Tj);_.sb=function(a){Pj(this,a,this.i.h,this.i);return true};_.Gb=function(a){return Qj(this,a)};_.vb=gt;_.h=0;var Qe=Wh(160);uh(161,1,{},Vj);_.Ab=dt;_.Ib=function(a){Pj(this.j,a,this.h.h,this.h);++this.g;this.i=null};_.Bb=function(){return this.h!=this.j.i};_.Cb=function(){return Uj(this)};_.Db=function(){var a;a=this.i.g;Sj(this.j,this.i);this.h==this.i?(this.h=a):--this.g;this.i=null};_.g=0;_.i=null;var Oe=Wh(161);uh(58,1,{},Wj);var Pe=Wh(58);uh(202,1,{},dk);_.g=0;_.h=0;var Zj,$j,_j=0;var Re=Wh(202);uh(122,1,{});_.Ab=kt;_.Mb=function(){return this.j};_.Nb=jt;_.j=0;_.l=0;var Ve=Wh(122);uh(78,122,{});var Se=Wh(78);uh(112,1,{});_.Ab=kt;_.Mb=gt;_.Nb=function(){return this.j-this.i};_.h=0;_.i=0;_.j=0;var Ue=Wh(112);uh(113,112,{},kk);_.Ab=function(a){hk(this,a)};_.Ob=function(a){return ik(this,a)};var Te=Wh(113);uh(29,1,{},mk);_.Mb=bt;_.Nb=function(){lk(this);return this.i};_.Ab=function(a){lk(this);this.j.Ab(a)};_.Ob=function(a){lk(this);if(this.j.Bb()){a.U(this.j.Cb());return true}return false};_.g=0;_.i=0;var We=Wh(29);uh(45,1,{},ok,pk);_.P=function(){return !this.g?this.i:this.l.length==0?this.g.g:this.g.g+(''+this.l)};var Xe=Wh(45);uh(70,1,{},qk);_.rb=function(a){return a};var Ye=Wh(70);uh(81,1,{},rk);var Ze=Wh(81);uh(121,1,{});_.i=false;var hf=Wh(121);uh(30,121,{},Ek);var vk;var gf=Wh(30);uh(94,1,{},Hk);_.Pb=function(a){return wk(),bd(je,ls,1,a,5,1)};var $e=Wh(94);uh(79,78,{},Jk);_.Ob=function(a){this.h=false;while(!this.h&&this.i.Ob(new Kk(this,a)));return this.h};_.h=false;var af=Wh(79);uh(126,1,{},Kk);_.U=function(a){Ik(this.g,this.h,a)};var _e=Wh(126);uh(123,78,{},Mk);_.Ob=function(a){return this.h.Ob(new Nk(this,a))};var cf=Wh(123);uh(125,1,{},Nk);_.U=function(a){Lk(this.g,this.h,a)};var bf=Wh(125);uh(124,1,{},Pk);_.U=function(a){Ok(this,a)};var df=Wh(124);uh(127,1,{},Qk);_.U=function(a){wk()};var ef=Wh(127);uh(128,1,{},Sk);_.U=function(a){Rk(this,a)};var ff=Wh(128);uh(352,1,{});uh(349,1,{});var $k=0;var al,bl=0,cl;uh(1325,1,{});uh(1358,1,{});uh(82,1,{},tl);_.Pb=function(a){return new Array(a)};var jf=Wh(82);uh(307,$wnd.Function,{},ul);_.Sb=function(a){sl(this.g,this.h,a)};uh(39,16,{4:1,20:1,16:1,39:1},Ul);var Ql,Rl,Sl;var kf=Xh(39,Vl);uh(9,16,{4:1,20:1,16:1,9:1},rm);var Wl,Xl,Yl,Zl,$l,_l,am,bm,cm,dm,em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm;var lf=Xh(9,sm);var tm;uh(294,$wnd.Function,{},vm);_.bb=function(a){return Mb(tm),tm=null,null};uh(84,1,{84:1},wm);var mf=Wh(84);uh(57,1,{57:1});var nf=Wh(57);uh(151,57,{11:1,57:1},Dm);_.S=lt;_.T=mt;_.P=function(){var a;return Sh(rf),rf.v+'@'+(a=_k(this)>>>0,a.toString(16))};var Am=0;var rf=Wh(151);uh(152,1,ks,Em);_.Q=function(){fb(this.g.j)};var of=Wh(152);uh(153,1,ks,Fm);_.Q=function(){hb(this.g.g)};var pf=Wh(153);uh(154,1,ks,Gm);_.Q=function(){ym(this.g,this.h)};var qf=Wh(154);uh(162,1,{});var bg=Wh(162);uh(163,162,ms,Lm);_.S=lt;_.T=mt;_.P=function(){var a;return Sh(xf),xf.v+'@'+(a=_k(this)>>>0,a.toString(16))};var Jm=0;var xf=Wh(163);uh(164,1,ks,Mm);_.Q=function(){Z(this.g.g)};var sf=Wh(164);uh(166,1,{},Nm);_.Q=function(){Hm(this.g)};var tf=Wh(166);uh(167,1,{},Om);_.Q=function(){Im(this.g)};var uf=Wh(167);uh(165,1,{},Pm);_.R=function(){var a;return a=$wnd.goog.global.globalThis.location.hash,a.length==0?a:a.substr(1)};var vf=Wh(165);uh(168,1,ks,Qm);_.Q=qt;var wf=Wh(168);uh(59,1,{59:1});_.L=0;var cg=Wh(59);uh(60,59,{11:1,59:1},vn);_.S=function(){kc(this.I)};_.T=function(){return this.I.s<0};_.P=function(){var a;return Sh(If),If.v+'@'+(a=_k(this)>>>0,a.toString(16))};_.v=false;_.A=false;_.B=false;_.H=false;var bn=0;var If=Wh(60);uh(224,1,ks,wn);_.Q=function(){cn(this.g)};var yf=Wh(224);uh(225,1,{},xn);_.Q=function(){Vm(this.g)};var zf=Wh(225);uh(226,1,ks,yn);_.Q=function(){dn(this.g,this.h)};var Af=Wh(226);uh(85,1,ks,zn);_.Q=function(){Xm(this.g,this.h)};_.h=false;var Bf=Wh(85);uh(227,1,ks,An);_.Q=function(){jn(this.g)};var Cf=Wh(227);uh(228,1,ks,Bn);_.Q=function(){_m(this.g)};var Df=Wh(228);uh(229,1,ks,Cn);_.Q=function(){an(this.g)};var Ef=Wh(229);uh(230,1,ks,Dn);_.Q=function(){Ym(this.g,this.h)};var Ff=Wh(230);uh(231,1,ks,En);_.Q=function(){Zm(this.g)};var Gf=Wh(231);uh(232,1,ks,Fn);_.Q=function(){$m(this.g,this.h)};var Hf=Wh(232);uh(203,1,{});var tg=Wh(203);uh(204,203,ms,Lo);_.S=function(){kc(this.A)};_.T=function(){return this.A.s<0};_.P=function(){var a;return Sh(_f),_f.v+'@'+(a=_k(this)>>>0,a.toString(16))};var ko=0;var _f=Wh(204);uh(205,1,ks,Mo);_.Q=function(){mo(this.g)};var Jf=Wh(205);uh(206,1,ks,No);_.Q=function(){lo(this.g)};var Kf=Wh(206);uh(207,1,{},Oo);_.R=function(){return ro(this.g)};var Lf=Wh(207);uh(208,1,{},Po);_.R=function(){return Hn(this.g)};var Mf=Wh(208);uh(209,1,ks,Qo);_.Q=function(){no(this.g,this.h)};var Nf=Wh(209);uh(210,1,ks,Ro);_.Q=function(){go(this.g)};var Of=Wh(210);uh(211,1,ks,So);_.Q=function(){ao(this.g)};var Pf=Wh(211);uh(212,1,ks,To);_.Q=function(){Wn(this.g,this.h)};var Qf=Wh(212);uh(213,1,ks,Uo);_.Q=function(){_n(this.g,this.h)};var Rf=Wh(213);uh(214,1,ks,Vo);_.Q=function(){$n(this.g,this.h)};var Sf=Wh(214);uh(215,1,ks,Wo);_.Q=function(){Tn(this.g,(Vp(),Tp))};var Tf=Wh(215);uh(216,1,ks,Xo);_.Q=function(){Xn(this.g,this.h)};var Uf=Wh(216);uh(217,1,ks,Yo);_.Q=function(){so(this.g,this.h)};var Vf=Wh(217);uh(218,1,ks,Zo);_.Q=function(){Vn(this.g,this.h)};var Wf=Wh(218);uh(219,1,ks,$o);_.Q=function(){Zn(this.g,this.h)};var Xf=Wh(219);uh(220,1,ks,_o);_.Q=function(){co(this.g)};var Yf=Wh(220);uh(221,1,ks,ap);_.Q=function(){to(this.g,this.h)};var Zf=Wh(221);uh(222,1,ks,bp);_.Q=function(){uo(this.g,this.h)};var $f=Wh(222);uh(148,1,{},cp);_.handleEvent=function(a){Km(this.g)};var ag=Wh(148);uh(325,$wnd.Function,{},dp);_._=nt;uh(326,$wnd.Function,{},ep);_._=nt;uh(327,$wnd.Function,{},fp);_.bb=function(a){return Sm(this.g,this.h,a)};_.h=0;uh(328,$wnd.Function,{},gp);_.bb=function(a){return Tm(this.g,this.h,a)};_.h=0;uh(329,$wnd.Function,{},hp);_._=function(a,b,c){return Um(this.g,a)};uh(331,$wnd.Function,{},ip);_.eb=function(a){rn(this.g)};uh(330,$wnd.Function,{},jp);_._=ot;uh(271,$wnd.Function,{},kp);_._=ot;uh(188,1,{},lp);_.Rb=function(){return $wnd.goog.global.globalThis.navigator.mediaDevices.getUserMedia(Fh(Eh({}),Gh(Hh({},Ch(Bh(Dh({},160),640),1280)),Ch(Bh(Dh({},120),360),720))))};var dg=Wh(188);uh(317,$wnd.Function,{},mp);_.eb=function(a){wo(this.g,a)};uh(192,1,{},np);_.U=function(a){md(a,11)&&a.S()};var eg=Wh(192);uh(324,$wnd.Function,{},op);_.fb=function(a){Ao(this.g,a)};uh(189,1,{},pp);_.U=pt;var fg=Wh(189);uh(190,1,{},qp);_.Rb=function(){return $wnd.goog.global.globalThis.navigator.mediaDevices.getDisplayMedia()};var gg=Wh(190);uh(191,1,{},rp);_.U=pt;var hg=Wh(191);uh(310,$wnd.Function,{},sp);_.eb=function(a){zo(this.g,a)};uh(311,$wnd.Function,{},tp);_.gb=function(a){yo(this.g,a)};uh(312,$wnd.Function,{},up);_.cb=function(a){vo(this.g,a)};uh(313,$wnd.Function,{},vp);_.eb=function(a){xo(this.g,a)};uh(315,$wnd.Function,{},wp);_.hb=function(a){Yn(this.g,a)};uh(316,$wnd.Function,{},xp);_.ib=function(a){Bo(this.g,a)};uh(23,16,{4:1,20:1,16:1,23:1},Ep);var yp,zp,Ap,Bp,Cp;var ig=Xh(23,Fp);uh(40,16,{4:1,20:1,16:1,40:1},Kp);var Gp,Hp,Ip;var jg=Xh(40,Lp);uh(17,16,{4:1,20:1,16:1,17:1},Wp);var Mp,Np,Op,Pp,Qp,Rp,Sp,Tp,Up;var kg=Xh(17,Xp);uh(318,$wnd.Function,{},Yp);_.eb=function(a){In(this.g)};uh(242,$wnd.Function,{},Zp);_._=function(a,b,c){return Jn(this.g,this.h,a)};uh(308,$wnd.Function,{},$p);_._=function(a,b,c){return Kn(this.g,a)};uh(323,$wnd.Function,{},_p);_.ab=function(a,b,c){return ho(this.g,a)};uh(268,$wnd.Function,{},aq);_.bb=function(a){return Ln(this.g,a)};uh(269,$wnd.Function,{},bq);_.bb=function(a){return Mn(this.g)};uh(270,$wnd.Function,{},cq);_.bb=function(a){return $wnd.goog.global.globalThis.console.log('Offer error: ',a),null};uh(319,$wnd.Function,{},dq);_._=function(a,b,c){return Nn(this.g,a)};uh(193,1,{},eq);_.Qb=function(a){return On(this.g,a)};var lg=Wh(193);uh(194,1,{},fq);_.U=function(a){};var mg=Wh(194);uh(195,1,{},gq);_.Rb=function(){return $wnd.Promise.resolve(this.g)};var ng=Wh(195);uh(196,1,{},hq);_.Qb=function(a){return Pn(this.g,a)};var og=Wh(196);uh(197,1,{},iq);_.Qb=function(a){return io(this.g,a)};var pg=Wh(197);uh(320,$wnd.Function,{},jq);_.bb=function(a){return Qn(this.g,a)};uh(321,$wnd.Function,{},kq);_.bb=function(a){return Rn(this.g)};uh(322,$wnd.Function,{},lq);_.bb=function(a){return $wnd.goog.global.globalThis.console.log('Answer error: ',a),null};uh(198,1,ks,mq);_.Q=function(){Sn(this.g,this.h)};var qg=Wh(198);uh(199,1,ks,nq);_.Q=function(){eo(this.g,kl(Hs,'reject_access','id',this.h.g))};var rg=Wh(199);uh(200,1,{},oq);_.Qb=function(a){return jo(this.g,a)};var sg=Wh(200);uh(130,1,{});var vg=Wh(130);uh(92,1,{},pq);var ug=Wh(92);uh(131,130,{});_.j=0;var Ug=Wh(131);uh(132,131,ms,vq);_.S=lt;_.T=mt;_.P=function(){var a;return Sh(Ag),Ag.v+'@'+(a=_k(this)>>>0,a.toString(16))};var tq=0;var Ag=Wh(132);uh(133,1,ks,wq);_.Q=function(){fb(this.g.l)};var wg=Wh(133);uh(134,1,ks,xq);_.Q=function(){sb(this.g.g)};var xg=Wh(134);uh(136,1,{},yq);_.R=function(){return rq(this.g)};var yg=Wh(136);uh(135,1,{},zq);_.Q=function(){sq(this.g)};var zg=Wh(135);uh(147,1,{});var dh=Wh(147);uh(177,147,{});_.l=0;var Wg=Wh(177);uh(178,177,ms,Qq);_.S=function(){kc(this.i)};_.T=function(){return this.i.s<0};_.P=function(){var a;return Sh(Kg),Kg.v+'@'+(a=_k(this)>>>0,a.toString(16))};var Mq=0;var Kg=Wh(178);uh(179,1,ks,Rq);_.Q=function(){fb(this.g.u)};var Bg=Wh(179);uh(180,1,ks,Sq);_.Q=function(){Nq(this.g)};var Cg=Wh(180);uh(182,1,{},Tq);_.Q=function(){Fq(this.g)};var Dg=Wh(182);uh(183,1,{},Uq);_.Q=function(){Gq(this.g)};var Eg=Wh(183);uh(185,1,ks,Vq);_.Q=function(){kc(this.g.i)};var Fg=Wh(185);uh(186,1,{},Wq);_.R=function(){return Kq(this.g)};var Gg=Wh(186);uh(187,1,ks,Xq);_.Q=qt;var Hg=Wh(187);uh(181,1,{},Yq);_.R=function(){return Qh(),$wnd.goog.global.globalThis.document.fullscreen?true:false};var Ig=Wh(181);uh(184,1,{},Zq);_.Q=function(){Lq(this.g)};var Jg=Wh(184);uh(260,1,{});var gh=Wh(260);uh(170,260,{});_.m=0;var Yg=Wh(170);uh(171,170,ms,hr);_.S=function(){kc(this.j)};_.T=function(){return this.j.s<0};_.P=function(){var a;return Sh(Qg),Qg.v+'@'+(a=_k(this)>>>0,a.toString(16))};var dr=0;var Qg=Wh(171);uh(172,1,ks,ir);_.Q=function(){er(this.g)};var Lg=Wh(172);uh(174,1,ks,jr);_.Q=function(){kc(this.g.j)};var Mg=Wh(174);uh(175,1,ks,kr);_.Q=function(){fr(this.g,this.h)};var Ng=Wh(175);uh(176,1,{},lr);_.R=function(){return br(this.g)};var Og=Wh(176);uh(173,1,{},mr);_.Q=function(){cr(this.g)};var Pg=Wh(173);uh(201,1,{});var ih=Wh(201);uh(233,201,{});var $g=Wh(233);uh(234,233,ms,rr);_.S=function(){kc(this.g)};_.T=function(){return this.g.s<0};_.P=function(){var a;return Sh(Sg),Sg.v+'@'+(a=_k(this)>>>0,a.toString(16))};var qr=0;var Sg=Wh(234);uh(235,1,ks,sr);_.Q=function(){kc(this.g.g)};var Rg=Wh(235);uh(293,$wnd.Function,{},tr);_.Vb=function(a){return new wr(a)};var ur;uh(114,$wnd.React.Component,{},wr);th(rh[1],_);_.componentWillUnmount=function(){qq(this.g)};_.render=function(){return uq(this.g)};_.shouldComponentUpdate=function(a){return 1==this.g.j};var Tg=Wh(114);uh(303,$wnd.Function,{},xr);_.Vb=function(a){return new Ar(a)};var yr;uh(157,$wnd.React.Component,{},Ar);th(rh[1],_);_.componentWillUnmount=function(){gb(this.g)&&Jq(this.g)};_.render=function(){return gb(this.g)?Oq(this.g):null};_.shouldComponentUpdate=function(a){return gb(this.g)&&1==this.g.l};var Vg=Wh(157);uh(295,$wnd.Function,{},Br);_.Vb=function(a){return new Er(a)};var Cr;uh(155,$wnd.React.Component,{},Er);th(rh[1],_);_.componentWillUnmount=function(){gb(this.g)&&ar(this.g)};_.render=function(){return gb(this.g)?gr(this.g):null};_.shouldComponentUpdate=function(a){return gb(this.g)&&1==this.g.m};var Xg=Wh(155);uh(332,$wnd.Function,{},Fr);_.Vb=function(a){return new Ir(a)};var Gr;uh(223,$wnd.React.Component,{},Ir);th(rh[1],_);_.componentWillUnmount=function(){gb(this.g)&&kc(this.g.g)};_.render=function(){return gb(this.g)?or(this.g):null};_.shouldComponentUpdate=function(a){return gb(this.g)&&pr(this.g,a)};var Zg=Wh(223);uh(304,$wnd.Function,{},Jr);_.Tb=function(a){a.preventDefault()};uh(240,$wnd.Function,{},Kr);_.Tb=function(a){Iq(this.g,a)};uh(158,1,{},Lr);_.handleEvent=function(a){Pq(this.g)};var _g=Wh(158);uh(298,$wnd.Function,{},Mr);_.U=function(a){Aq(this.g,a)};uh(241,$wnd.Function,{},Nr);_.Tb=function(a){Bq(this.g,a)};uh(159,1,{},Or);_.rb=function(a){return fs(gs(new hs,a),'video-list-item')};var ah=Wh(159);uh(299,$wnd.Function,{},Pr);_.Ub=function(a){Ko(this.g.u)};uh(300,$wnd.Function,{},Qr);_.Ub=function(a){sn(this.g)};uh(301,$wnd.Function,{},Rr);_.Ub=function(a){un(this.g)};uh(302,$wnd.Function,{},Sr);_.Ub=function(a){Cq(this.g)};uh(305,$wnd.Function,{},Tr);_.Ub=function(a){Dq(this.g,this.h,a)};uh(306,$wnd.Function,{},Ur);_.Ub=function(a){Eq(this.g,this.h,a)};uh(146,1,{},Yr);var bh=Wh(146);uh(296,$wnd.Function,{},Zr);_.Tb=function(a){$q(this.g,a)};uh(156,1,{},$r);_.rb=function(a){return rl('a',Al(vl(xl(new $wnd.Object,a),ed(_c(me,1),ls,2,6,['recent-room'])),'#'+a),[a])};var eh=Wh(156);uh(297,$wnd.Function,{},_r);_.Tb=function(a){var b;_q(this.g,oi((b=a.target,b).value))};uh(145,1,{},cs);var fh=Wh(145);uh(333,$wnd.Function,{},ds);_.U=function(a){nr(this.g,a)};uh(83,1,{},hs);var hh=Wh(83);var ud=Yh('D');var is=(Gc(),Jc);var gwtOnLoad=gwtOnLoad=ph;nh(Ah);qh('permProps',[[]]);if (vchat) vchat.onScriptLoad(gwtOnLoad);})();