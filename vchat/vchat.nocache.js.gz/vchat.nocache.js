function vchat(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='vchat',tb='__gwt_marker_vchat',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='0F7CE1EF9EAAA63BC58589431A3966B5',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};vchat.onScriptLoad=function(a){vchat=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
vchat();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '0F7CE1EF9EAAA63BC58589431A3966B5';function t(){}
function Sh(){}
function Oh(){}
function _b(){}
function fd(){}
function nd(){}
function Ci(){}
function Cl(){}
function ck(){}
function yk(){}
function Pk(){}
function Xk(){}
function Yk(){}
function Fm(){}
function Xm(){}
function rp(){}
function sp(){}
function tp(){}
function yp(){}
function zp(){}
function Ap(){}
function Cp(){}
function Ep(){}
function Gp(){}
function vq(){}
function mr(){}
function Jr(){}
function Nr(){}
function Rr(){}
function Vr(){}
function Zr(){}
function $r(){}
function qs(){}
function ld(a){kd()}
function Wh(){Wh=Oh}
function yt(){Wi(this)}
function kj(){aj(this)}
function ab(a){this.g=a}
function bb(a){this.g=a}
function cb(a){this.g=a}
function sb(a){this.g=a}
function Fb(a){this.g=a}
function Tb(a){this.g=a}
function Ub(a){this.g=a}
function Vb(a){this.g=a}
function Wb(a){this.g=a}
function Ec(a){this.g=a}
function Uh(a){this.g=a}
function li(a){this.g=a}
function Ri(a){this.g=a}
function Zi(a){this.g=a}
function $i(a){this.g=a}
function $k(a){this.g=a}
function zk(a){this.g=a}
function Om(a){this.g=a}
function Pm(a){this.g=a}
function Um(a){this.g=a}
function Vm(a){this.g=a}
function Wm(a){this.g=a}
function Ym(a){this.g=a}
function Fn(a){this.g=a}
function Gn(a){this.g=a}
function Hn(a){this.g=a}
function Kn(a){this.g=a}
function Ln(a){this.g=a}
function Mn(a){this.g=a}
function On(a){this.g=a}
function $o(a){this.g=a}
function _o(a){this.g=a}
function ap(a){this.g=a}
function bp(a){this.g=a}
function dp(a){this.g=a}
function ep(a){this.g=a}
function ip(a){this.g=a}
function np(a){this.g=a}
function qp(a){this.g=a}
function wp(a){this.g=a}
function xp(a){this.g=a}
function Bp(a){this.g=a}
function Dp(a){this.g=a}
function Fp(a){this.g=a}
function Hp(a){this.g=a}
function Ip(a){this.g=a}
function Jp(a){this.g=a}
function Kp(a){this.g=a}
function Lp(a){this.g=a}
function Mp(a){this.g=a}
function Np(a){this.g=a}
function mq(a){this.g=a}
function oq(a){this.g=a}
function pq(a){this.g=a}
function qq(a){this.g=a}
function rq(a){this.g=a}
function sq(a){this.g=a}
function tq(a){this.g=a}
function uq(a){this.g=a}
function wq(a){this.g=a}
function xq(a){this.g=a}
function yq(a){this.g=a}
function zq(a){this.g=a}
function Aq(a){this.g=a}
function Bq(a){this.g=a}
function Eq(a){this.g=a}
function Mq(a){this.g=a}
function Nq(a){this.g=a}
function Oq(a){this.g=a}
function Pq(a){this.g=a}
function fr(a){this.g=a}
function gr(a){this.g=a}
function hr(a){this.g=a}
function ir(a){this.g=a}
function jr(a){this.g=a}
function kr(a){this.g=a}
function lr(a){this.g=a}
function nr(a){this.g=a}
function yr(a){this.g=a}
function zr(a){this.g=a}
function Br(a){this.g=a}
function Cr(a){this.g=a}
function Ir(a){this.g=a}
function _r(a){this.g=a}
function as(a){this.g=a}
function bs(a){this.g=a}
function es(a){this.g=a}
function fs(a){this.g=a}
function gs(a){this.g=a}
function hs(a){this.g=a}
function is(a){this.g=a}
function js(a){this.g=a}
function ks(a){this.g=a}
function ps(a){this.g=a}
function rs(a){this.g=a}
function vs(a){this.g=a}
function Xi(a){this.j=a}
function mj(a){this.i=a}
function Bj(){this.g=Kj()}
function Pj(){this.g=Kj()}
function zt(){Oi(this.g)}
function Gt(){yc(this.h)}
function xt(a){Tj(this,a)}
function Dt(a){pi(this,a)}
function Ft(a){mk(this,a)}
function Mt(a){Bn(this.g)}
function Lt(){pb(this.g.g)}
function Wk(a,b){a.g=b}
function Mb(a,b){a.h=b}
function vl(a,b){a.key=b}
function ql(a,b){pl(a,b)}
function Zk(a,b){Ok(a.g,b)}
function Y(a,b){hc(a.m,b.m)}
function V(a){--a.l;Z(a)}
function zc(a){!!a&&a.$()}
function Eh(a){return a.l}
function Et(){return this.l}
function vt(){return this.g}
function Bt(){return this.h}
function ji(){Kc.call(this)}
function Di(){Kc.call(this)}
function Db(a){tc((eb(),a))}
function zb(a){rc((eb(),a))}
function Ab(a){sc((eb(),a))}
function Kt(a){Qn(this.g,a)}
function vj(){this.g=new sj}
function eb(){eb=Oh;db=new $}
function Nc(){Nc=Oh;Mc=new t}
function cd(){cd=Oh;bd=new fd}
function Ek(){Ek=Oh;Dk=new Yk}
function Gj(){Gj=Oh;Fj=Ij()}
function Gq(a){a.j=2;yc(a.h)}
function Zq(a){a.l=2;yc(a.i)}
function qr(a){a.m=2;yc(a.j)}
function Hc(a,b){a.l=b;Gc(a,b)}
function fb(a,b){jb(a);gb(a,b)}
function xc(a,b,c){Mi(a.l,b,c)}
function Lm(a,b,c){xc(a.h,b,c)}
function qn(a,b,c){xc(a.H,b,c)}
function Qq(a,b){return a.v=b}
function ej(a,b){return a.g[b]}
function wt(){return hl(this)}
function Vh(a){Lc.call(this,a)}
function Ei(a){Lc.call(this,a)}
function Bi(a){Uh.call(this,a)}
function Ai(){Uh.call(this,'')}
function Hh(){Fh==null&&(Fh=[])}
function tb(a){Ad(a,10)&&a.ab()}
function zo(a){tb(a.B);tb(a.K)}
function br(a){Gb(a.h);mb(a.g)}
function ur(a){Gb(a.g);vb(a.h)}
function Jt(a){Ad(a,10)&&a.ab()}
function Kk(a){Ak(a);return a.g}
function Zh(a){Yh(a);return a.v}
function F(a,b){a.max=b;return a}
function G(a,b){a.min=b;return a}
function Q(a,b){a.sdp=b;return a}
function od(a,b){return di(a,b)}
function el(a,b){return ud(a,b)}
function At(){return Pi(this.g)}
function Ht(){return this.h.s<0}
function vo(a,b){return s(b.g,a)}
function dl(a,b,c){a.splice(b,c)}
function rk(a,b,c){b.cb(a.g[c])}
function mk(a,b){while(a.Sb(b));}
function Fl(a,b){a.id=b;return a}
function R(a,b){a.type=b;return a}
function Gl(a,b){a.key=b;return a}
function Hl(a,b){a.ref=b;return a}
function Pl(a,b){a.src=b;return a}
function Nk(a,b){a.ub(b);return a}
function rn(a){Bb(a.o);return a.D}
function sn(a){Bb(a.i);return a.A}
function Co(a){Bb(a.i);return a.H}
function Do(a){Bb(a.j);return a.I}
function To(a){Bb(a.l);return a.s}
function Uo(a){Cb(a.m);return a.u}
function Xo(a){Bb(a.o);return a.v}
function Kj(){Gj();return new Fj}
function wb(a){eb();sc(a);a.l=-2}
function Yj(a){return Zj(a,a.i.h)}
function Pi(a){return a.g.h+a.h.h}
function lc(a){mc(a);!a.j&&pc(a)}
function Uc(){Uc=Oh;!!(kd(),jd)}
function Kc(){Fc(this);this.ib()}
function Zb(a){this.j=a;this.h=100}
function ii(a,b){this.g=a;this.h=b}
function _i(a,b){this.g=a;this.h=b}
function D(a,b){a.ideal=b;return a}
function J(a,b){a.video=b;return a}
function L(a,b){a.width=b;return a}
function Sk(a,b){this.g=a;this.h=b}
function Vk(a,b){this.g=a;this.h=b}
function Dl(a,b){this.g=a;this.h=b}
function Jl(a,b){a.href=b;return a}
function eo(a,b){null!=b&&Qn(a,b)}
function cm(a,b){ii.call(this,a,b)}
function Bm(a,b){ii.call(this,a,b)}
function Gm(a,b){this.g=a;this.h=b}
function Qm(a,b){this.g=a;this.h=b}
function In(a,b){this.g=a;this.h=b}
function Jn(a,b){this.g=a;this.h=b}
function Nn(a,b){this.g=a;this.h=b}
function Pn(a,b){this.g=a;this.h=b}
function cp(a,b){this.g=a;this.h=b}
function fp(a,b){this.g=a;this.h=b}
function gp(a,b){this.g=a;this.h=b}
function hp(a,b){this.g=a;this.h=b}
function jp(a,b){this.g=a;this.h=b}
function kp(a,b){this.g=a;this.h=b}
function lp(a,b){this.g=a;this.h=b}
function mp(a,b){this.g=a;this.h=b}
function op(a,b){this.g=a;this.h=b}
function pp(a,b){this.g=a;this.h=b}
function up(a,b){this.g=a;this.h=b}
function vp(a,b){this.g=a;this.h=b}
function Up(a,b){ii.call(this,a,b)}
function $p(a,b){ii.call(this,a,b)}
function kq(a,b){ii.call(this,a,b)}
function nq(a,b){this.g=a;this.h=b}
function Cq(a,b){this.g=a;this.h=b}
function Dq(a,b){this.g=a;this.h=b}
function Vj(a,b){Wj(a,b,a.i.h,a.i)}
function Uj(a,b){Wj(a,b,a.g,a.g.g)}
function Mj(a,b){return a.g.get(b)}
function wo(a,b){return s(b.g,a.g)}
function wi(a){return !a?Ms:''+a.g}
function ls(a){return ms(new os,a)}
function ss(a){return ts(new us,a)}
function U(a,b,c){S(a,new cb(c),b)}
function Tk(a,b,c){b.cb(a.g.tb(c))}
function bl(a,b,c){a.splice(b,0,c)}
function Ar(a,b){this.g=a;this.h=b}
function cs(a,b){this.g=a;this.h=b}
function ds(a,b){this.g=a;this.h=b}
function os(){this.g=zl((Pr(),Or))}
function us(){this.g=zl((Tr(),Sr))}
function As(){this.g=zl((Xr(),Wr))}
function Fq(){this.g=zl((Lr(),Kr))}
function ob(a){Ib(a.m);return qb(a)}
function Yl(a,b){a.value=b;return a}
function K(a,b){a.height=b;return a}
function yi(a,b){a.g+=''+b;return a}
function I(a){a.audio=true;return a}
function H(a){a.audio=false;return a}
function _c(a){$wnd.clearTimeout(a)}
function un(a){wn(a,(Bb(a.i),!a.A))}
function Ct(a){return Ki(this.g,a)}
function ws(a){return ys(new As,a)}
function ek(a){return a!=null?w(a):0}
function Gd(a){return a==null?null:a}
function Ji(a){return !a?null:a.Ob()}
function nc(a){return !a.j?a:nc(a.j)}
function s(a,b){return Gd(a)===Gd(b)}
function Ok(a,b){Ek();Wk(a,Nk(a.g,b))}
function Go(a,b){po(a,b,new Cq(a,b))}
function Ho(a,b){po(a,b,new Dq(a,b))}
function Ll(a,b){a.onClick=b;return a}
function Zl(a,b){a.htmlFor=b;return a}
function N(a,b){a.candidate=b;return a}
function It(a){a.enabled=!a.enabled}
function Kl(a,b){a.disabled=b;return a}
function Nl(a,b){a.onSubmit=b;return a}
function Ql(a,b){a.width=''+b;return a}
function Tl(a,b){a.onChange=b;return a}
function M(a,b){a.iceServers=b;return a}
function Eb(a){this.i=new kj;this.h=a}
function Oi(a){a.g=new Bj;a.h=new Pj}
function ll(){ll=Oh;il=new t;kl=new t}
function ad(){Rc!=0&&(Rc=0);Tc=-1}
function aj(a){a.g=qd(ze,Fs,1,0,5,1)}
function wk(){xk.call(this,'|','','')}
function Lb(a){eb();Kb(a);Ob(a,2,true)}
function X(a,b,c){return T(a,c,2048,b)}
function qi(a,b){return a.charCodeAt(b)}
function uj(a,b){return Ni(a.g,b)!=null}
function hl(a){return a.$H||(a.$H=++gl)}
function Wl(a){return a.required=true,a}
function Ad(a,b){return a!=null&&yd(a,b)}
function pl(a,b){for(var c in a){b(c)}}
function fl(a){if(!a){throw Eh(new ji)}}
function cl(a,b,c){al(c,0,a,b,c.length)}
function W(a,b,c){T(a,new bb(b),c,null)}
function xs(a,b){ul(a.g,'b',b);return a}
function ms(a,b){ul(a.g,'a',b);return a}
function Ol(a,b){a.height=''+b;return a}
function Sl(a,b){a.maxLength=b;return a}
function ul(a,b,c){a.props[b]=c;return a}
function ti(a,b,c){return a.substr(b,c-b)}
function Rl(a){return a.autoFocus=true,a}
function Cd(a){return typeof a==='number'}
function Fd(a){return typeof a==='string'}
function Bd(a){return typeof a==='boolean'}
function ub(a){return !(Ad(a,10)&&a.bb())}
function Bb(a){var b;oc((eb(),b=jc,b),a)}
function kb(){this.g=qd(ze,Fs,1,100,5,1)}
function sj(){this.g=new Bj;this.h=new Pj}
function Lc(a){this.o=a;Fc(this);this.ib()}
function Ui(a){a.i.Gb();a.i=null;a.h=Si(a)}
function Wi(a){a.j.Kb(a.i);a.h=a.i;a.i=-1}
function ac(a){2==(3&a.g)||(a.g=-4&a.g|2)}
function pb(a){4==(a.m.i&7)&&Ob(a.m,5,true)}
function Yh(a){if(a.v!=null){return}fi(a)}
function zs(a,b){ul(a.g,'c',b);return a.g}
function Vl(a,b){a.placeholder=b;return a}
function O(a,b){a.sdpMLineIndex=b;return a}
function rl(a,b){var c;c={};c[a]=b;return c}
function Dj(a,b){var c;c=a[Ss];c.call(a,b)}
function Sn(a,b,c){return a.D.addTrack(c,b)}
function Vc(a,b,c){return a.apply(b,c);var d}
function Ed(a,b){return a&&b&&a instanceof b}
function uo(a,b){return Gd(b.track)===Gd(a)}
function Yq(a,b){b.preventDefault();So(a.u)}
function Tj(a,b){while(a.Eb()){Zk(b,a.Fb())}}
function Yb(a){while(true){if(!Xb(a)){break}}}
function lj(a){aj(this);cl(this.g,0,a.Bb())}
function Sj(a,b,c){this.g=a;this.h=b;this.i=c}
function bk(a,b,c){this.j=a;this.h=c;this.g=b}
function gc(a,b,c){c.g=-4&c.g|1;fb(a.g[b],c)}
function hc(a,b){gc(a,((b.g&229376)>>15)-1,b)}
function Cc(a){eb();jc?a.$():W((null,db),a,0)}
function Cn(a){W((eb(),eb(),db),new Kn(a),Zs)}
function Bn(a){W((eb(),eb(),db),new Ln(a),Zs)}
function Dn(a){W((eb(),eb(),db),new Mn(a),Zs)}
function Sm(a){W((eb(),eb(),db),new Ym(a),Zs)}
function Qo(a){W((eb(),eb(),db),new ep(a),Zs)}
function Yo(a){W((eb(),eb(),db),new dp(a),Zs)}
function Io(a){W((eb(),eb(),db),new ip(a),ft)}
function So(a){W((eb(),eb(),db),new np(a),ft)}
function dr(a){W((eb(),eb(),db),new lr(a),Zs)}
function ai(a){var b;b=_h(a);hi(a,b);return b}
function Fc(a){a.u&&a.l!==Ks&&a.ib();return a}
function Ul(a){a.pattern='^\\w+$';return a}
function bj(a,b){a.g[a.g.length]=b;return true}
function Jb(a,b){yb(b,a);b.i.g.length>0||(b.g=4)}
function Mk(a,b){Ek();Ck.call(this,a);this.g=b}
function pk(a,b){while(a.i<a.j){rk(a,b,a.i++)}}
function go(a){if(!a.F&&a.G){a.G=false;fo(a)}}
function Zm(a){zn(a,null);yn(a,null);xn(a,null)}
function oj(a){return new Mk(null,nj(a,a.length))}
function sd(a){return Array.isArray(a)&&a._b===Sh}
function Ki(a,b){return Fd(b)?Li(a,b):!!yj(a.g,b)}
function Lj(a,b){return !(a.g.get(b)===undefined)}
function Fk(a,b){var c;return Jk(a,(c=new kj,c))}
function Mm(a,b){W((eb(),eb(),db),new Qm(a,b),Zs)}
function wn(a,b){W((eb(),eb(),db),new Jn(a,b),Zs)}
function Bo(a,b){W((eb(),eb(),db),new op(a,b),ft)}
function Jo(a,b){W((eb(),eb(),db),new lp(a,b),ft)}
function Ko(a,b){W((eb(),eb(),db),new fp(a,b),ft)}
function Lo(a,b){W((eb(),eb(),db),new jp(a,b),ft)}
function Mo(a,b){W((eb(),eb(),db),new mp(a,b),ft)}
function No(a,b){W((eb(),eb(),db),new kp(a,b),ft)}
function Po(a,b){W((eb(),eb(),db),new gp(a,b),ft)}
function Ro(a,b){W((eb(),eb(),db),new pp(a,b),ft)}
function Oo(a,b){W((eb(),eb(),db),new hp(a,b),Zs)}
function pr(a,b){Cc(new Ar(a,b.length==0?null:b))}
function gd(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ci(a){var b;b=_h(a);b.u=a;b.l=1;return b}
function kd(){kd=Oh;var a;!md();a=new nd;jd=a}
function oi(){oi=Oh;ni=qd(we,Fs,36,256,0,1)}
function B(a){$wnd.addEventListener(Ds,a,false)}
function C(a){$wnd.removeEventListener(Ds,a,false)}
function Rq(a,b,c){c.preventDefault();Bo(a.u,b)}
function Sq(a,b,c){c.preventDefault();Ro(a.u,b)}
function nj(a,b){return nk(b,a.length),new sk(a,b)}
function zd(a){return !Array.isArray(a)&&a._b===Sh}
function tk(a){if(!a.j){a.j=a.h.sb();a.i=a.h.yb()}}
function Iq(a){if(0==a.j){a.j=1;a.i.forceUpdate()}}
function _q(a){if(0==a.l){a.l=1;a.j.forceUpdate()}}
function sr(a){if(0==a.m){a.m=1;a.l.forceUpdate()}}
function $b(a){if(!a.g){a.g=true;V((eb(),eb(),db))}}
function Qk(a,b,c){if(a.g.U(c)){a.h=true;b.cb(c)}}
function Ak(a){if(!a.h){Bk(a);a.i=true}else{Ak(a.h)}}
function ak(a){a.i=a.h;a.h=a.h.g;++a.g;return a.i.i}
function tj(a,b){var c;c=Mi(a.g,b,a);return c==null}
function gj(a,b){var c;c=a.g[b];dl(a.g,b,1);return c}
function jj(a,b,c){var d;d=a.g[b];a.g[b]=c;return d}
function _k(a,b){var c;c=a.slice(0,b);return ud(c,a)}
function pn(a,b){var c;c=a.A;if(b!=c){a.A=b;Ab(a.i)}}
function vn(a,b){var c;c=a.v;if(b!=c){a.v=b;Ab(a.h)}}
function vr(a,b){var c;c=a.i;if(b!=c){a.i=b;Ab(a.h)}}
function xn(a,b){var c;c=a.B;if(b!=c){a.B=b;Ab(a.j)}}
function yn(a,b){var c;c=a.C;if(b!=c){a.C=b;Ab(a.l)}}
function An(a,b){var c;c=a.G;if(b!=c){a.G=b;Ab(a.u)}}
function Ao(a,b){var c;c=a.s;if(b!=c){a.s=b;Ab(a.l)}}
function sl(a,b,c){var d;d={};d[Ns]=a;d[b]=c;return d}
function Ml(a,b){a.type=b.g!=null?b.g:''+b.h;return a}
function xi(a,b){a.g+=String.fromCharCode(b);return a}
function ok(a,b){this.l=a;this.j=(b&64)!=0?b|16384:b}
function _j(){this.g=new ck;this.i=new ck;$j(this)}
function ol(){if(jl==256){il=kl;kl=new t;jl=0}++jl}
function Gk(a,b){Bk(a);return new Mk(a,new Rk(b,a.g))}
function Hk(a,b){Bk(a);return new Mk(a,new Uk(b,a.g))}
function Ni(a,b){return b==null?Aj(a.g,null):Oj(a.h,b)}
function rj(a,b){return Gd(a)===Gd(b)||a!=null&&u(a,b)}
function Li(a,b){return b==null?!!yj(a.g,null):Lj(a.h,b)}
function ib(a){return a.i?a.g.length-a.h+a.j:a.j-a.h}
function cr(a){return X((eb(),eb(),db),a.h,new kr(a))}
function wr(a){return X((eb(),eb(),db),a.g,new Br(a))}
function Kq(a){return X((eb(),eb(),db),a.g,new Oq(a))}
function Vq(a){$wnd.document.addEventListener(ht,a.s)}
function Wq(a){$wnd.document.removeEventListener(ht,a.s)}
function A(a){var b;b=$wnd.console;b.log.apply(b,a)}
function Cb(a){var b;eb();!!jc&&!!jc.l&&oc((b=jc,b),a)}
function bi(a,b){var c;c=_h(a);hi(a,c);c.l=b?8:0;return c}
function Ti(a){var b;a.i=a.g;b=a.g.Fb();a.h=Si(a);return b}
function $j(a){a.g.g=a.i;a.i.h=a.g;a.g.h=a.i.g=null;a.h=0}
function Yi(a,b){this.g=a;Xi.call(this,a);a.yb();this.h=b}
function sk(a,b){this.i=0;this.j=b;this.h=17488;this.g=a}
function uk(a,b){this.h=a;this.g=(b&4096)==0?b|64|16384:b}
function Ck(a){if(!a){this.h=null;new kj}else{this.h=a}}
function ei(a){if(a.qb()){return null}var b=a.u;return Kh[b]}
function Qi(a,b){if(Ad(b,43)){return Hi(a.g,b)}return false}
function Fo(a,b){Gd(a.L)===Gd(b.currentTarget)&&pb(a.g)}
function kc(a){if(a.l){2==(a.l.i&7)||Ob(a.l,4,true);Kb(a.l)}}
function uc(a,b){this.g=(eb(),eb(),db).h++;this.j=a;this.l=b}
function vc(a,b){jc=new uc(jc,b);a.j=false;kc(jc);return jc}
function Ic(a,b){var c;c=Zh(a.Zb);return b==null?c:c+': '+b}
function Ii(a,b){return b===a?'(this Map)':b==null?Ms:Rh(b)}
function an(a,b){return b.onended=Ph(xp.prototype.R,xp,[a])}
function Lr(){Lr=Oh;var a;Kr=(a=Ph(Jr.prototype.Yb,Jr,[]),a)}
function Pr(){Pr=Oh;var a;Or=(a=Ph(Nr.prototype.Yb,Nr,[]),a)}
function Tr(){Tr=Oh;var a;Sr=(a=Ph(Rr.prototype.Yb,Rr,[]),a)}
function Xr(){Xr=Oh;var a;Wr=(a=Ph(Vr.prototype.Yb,Vr,[]),a)}
function _p(){Zp();return td(od(Bg,1),Fs,40,0,[Yp,Xp,Wp])}
function dm(){bm();return td(od(Af,1),Fs,39,0,[$l,_l,am])}
function $c(a){Uc();$wnd.setTimeout(function(){throw a},0)}
function Bk(a){if(a.h){Bk(a.h)}else if(a.i){throw Eh(new ki)}}
function Hb(a){Y((eb(),eb(),db),a);0==(a.m.g&Js)&&Z((null,db))}
function Dr(a,b){var c;c=a.i;!(!!c&&c.H.s<0)&&Cc(new In(c,b))}
function xj(a,b){var c;c=a.g.get(b);return c==null?new Array:c}
function di(a,b){var c=a.g=a.g||[];return c[b]||(c[b]=a.lb(b))}
function pi(a,b){var c,d;for(d=a.sb();d.Eb();){c=d.Fb();b.cb(c)}}
function yj(a,b){var c;return wj(b,xj(a,b==null?0:(c=w(b),c|0)))}
function Tq(a,b){var c;Cc(new cp(a.u,ui((c=b.target,c).value)))}
function ro(a,b){null!=a.L&&a.L.send($wnd.JSON.stringify(b))}
function bn(a){!(!!a&&a.H.s<0)&&W((eb(),eb(),db),new On(a),Zs)}
function $(){this.m=new ic;this.g=new Zb(this.m);new ab(this.g)}
function Cj(a){this.l=a;this.h=this.l.g.entries();this.g=new Array}
function Uk(a,b){ok.call(this,b.Rb(),b.Qb()&-6);this.g=a;this.h=b}
function Vo(a,b){var c;c=a.u;if(!(b==c||!!b&&b==c)){a.u=b;Ab(a.m)}}
function Wo(a,b){var c;c=a.v;if(!(b==c||!!b&&b==c)){a.v=b;Ab(a.o)}}
function Yc(a,b,c){var d;d=Wc();try{return Vc(a,b,c)}finally{Zc(d)}}
function Mh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Qh(a){function b(){}
;b.prototype=a||{};return new b}
function Jc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function P(a){a.urls='stun:stun.l.google.com:19302';return a}
function Rn(a){var b;b=new kj;sn(a.K)&&bj(b,a.K);cj(b,a.J);return b}
function Bc(a){zc(a.o);!!a.l&&Ac(a);tb(a.g);tb(a.i);zc(a.h);zc(a.m)}
function qk(a,b){if(a.i<a.j){rk(a,b,a.i++);return true}return false}
function Vn(a){ro(a,sl('offer',_s,a.D.localDescription));return null}
function tl(a,b,c,d,e,f){var g;g={};g[a]=b;g[c]=d;g[e]=f;return g}
function Bl(a,b,c){!s(c,'key')&&!s(c,'ref')&&(a[c]=b[c],undefined)}
function Yn(a,b){var c;return c=(Bb(b.o),b.D),null!=c&&s(c.id,a.id)}
function Vp(){Tp();return td(od(Ag,1),Fs,24,0,[Qp,Sp,Pp,Op,Rp])}
function Ik(a,b){return !(Bk(a),Kk(new Mk(a,new Rk(b,a.g)))).Sb(Dk)}
function Hd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Zc(a){a&&ed((cd(),bd));--Rc;if(a){if(Tc!=-1){_c(Tc);Tc=-1}}}
function cc(b){try{Ib(b.h.g)}catch(a){a=Dh(a);if(!Ad(a,7))throw Eh(a)}}
function ln(a){if(s('live',a.readyState)){a.onended=null;a.stop()}}
function gb(a,b){a.g[a.j]=b;++a.j;if(a.j>=a.g.length){a.j=0;a.i=true}}
function vk(a,b){!a.g?(a.g=new Bi(a.j)):yi(a.g,a.h);yi(a.g,b);return a}
function Rk(a,b){ok.call(this,b.Rb(),b.Qb()&-16449);this.g=a;this.i=b}
function Qj(a){this.j=a;this.h=this.j.g.entries();this.g=this.h.next()}
function xk(a,b,c){this.h=a;this.j=b;this.l=c;this.i=this.j+(''+this.l)}
function Mr(a){$wnd.React.Component.call(this,a);this.g=new Lq(this)}
function Qr(a){$wnd.React.Component.call(this,a);this.g=new er(this)}
function Ur(a){$wnd.React.Component.call(this,a);this.g=new xr(this)}
function Yr(a){$wnd.React.Component.call(this,a);this.g=new Hr(this)}
function Un(a,b){return a.D.setLocalDescription(R(Q({},b.sdp),b.type))}
function $n(a,b){return a.D.setLocalDescription(Q(R({},b.type),b.sdp))}
function Zn(a,b){var c;return c=(Bb(b.o),b.D),!(null!=c&&!s(c.id,a.id))}
function Lk(a,b){var c;c=Fk(a,new zk(new yk));return c.Cb(b.Tb(c.yb()))}
function Jk(a,b){var c;Ak(a);c=new Xk;c.g=b;a.g.Db(new $k(c));return c.g}
function Wj(a,b,c,d){var e;e=new ck;e.i=b;e.h=c;e.g=d;d.h=c.g=e;++a.h}
function qd(a,b,c,d,e,f){var g;g=rd(e,d);e!=10&&td(od(a,f),b,c,e,g);return g}
function _m(a,b,c){a.K==b&&W((eb(),eb(),db),new Pn(a,c),Zs);return null}
function vb(a){if(-2!=a.l){W((eb(),eb(),db),new Fb(a),0);!!a.h&&Gb(a.h)}}
function yo(a){mb(a.g);mb(a.h);vb(a.o);vb(a.m);vb(a.l);vb(a.j);vb(a.i)}
function po(a,b,c){if(null!=a.L&&hj(a.I,b)){ij(a.I,new Eq(b));Ab(a.j);c.$()}}
function xb(a,b){var c,d;bj(a.i,b);d=(c=b.i&7,c>3?c:4);a.g>d&&(a.g=d)}
function dj(a,b){var c,d,e,f;for(d=a.g,e=0,f=d.length;e<f;++e){c=d[e];b.cb(c)}}
function fc(a){var b,c;b=0;for(c=0;c<a.g.length;c++){b+=ib(a.g[c])}return b}
function fj(a,b,c){for(;c<a.g.length;++c){if(rj(b,a.g[c])){return c}}return -1}
function Rj(a){if(a.g.i!=a.i){return Mj(a.g,a.h.value[0])}return a.h.value[1]}
function Qc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Xc(b){Uc();return function(){return Yc(b,this,arguments);var a}}
function lq(){jq();return td(od(Cg,1),Fs,16,0,[iq,bq,gq,fq,eq,aq,hq,dq,cq])}
function Mi(a,b,c){return Fd(b)?b==null?zj(a.g,null,c):Nj(a.h,b,c):zj(a.g,b,c)}
function ts(a,b){vl(a.g,mi(b.h.j)+(''+(Yh(yh),yh.v)));ul(a.g,'a',b);return a.g}
function hj(a,b){var c;c=fj(a,b,0);if(c==-1){return false}dl(a.g,c,1);return true}
function ud(a,b){pd(b)!=10&&td(v(b),b.$b,b.__elementTypeId$,pd(b),a);return a}
function Wn(a,b){A(td(od(ze,1),Fs,1,5,['Offer error: ',b]));a.F=false;return null}
function qb(a){if(a.h){if(Ad(a.h,9)){throw Eh(a.h)}else{throw Eh(a.h)}}return a.v}
function mb(a){if(!a.g){a.g=true;a.v=null;a.h=null;vb(a.l);2==(a.m.i&7)||Gb(a.m)}}
function Z(a){if(a.j&&a.l==0){if(!a.i){a.i=true;try{Yb(a.g)}finally{a.i=false}}}}
function qo(a){if(null!=a.L){ro(a,sl(dt,'message',(Bb(a.l),a.s)));Wo(a,(jq(),gq))}}
function Nb(b){if(b){try{b.$()}catch(a){a=Dh(a);if(Ad(a,7)){eb()}else throw Eh(a)}}}
function on(a,b){var c;c=a.F;if(!(Gd(b)===Gd(c)||b!=null&&u(b,c))){a.F=b;Ab(a.s)}}
function zn(a,b){var c;c=a.D;if(!(Gd(b)===Gd(c)||b!=null&&u(b,c))){a.D=b;Ab(a.o)}}
function dd(a){var b,c;if(a.g){c=null;do{b=a.g;a.g=null;c=hd(b,c)}while(a.g);a.g=c}}
function ed(a){var b,c;if(a.h){c=null;do{b=a.h;a.h=null;c=hd(b,c)}while(a.h);a.h=c}}
function Vi(a){this.l=a;this.j=new Qj(this.l.h);this.g=this.j;this.h=Si(this)}
function ic(){var a;this.g=qd(Pd,Fs,57,5,0,1);for(a=0;a<5;a++){this.g[a]=new kb}}
function bm(){bm=Oh;$l=new cm(Xs,0);_l=new cm('reset',1);am=new cm('submit',2)}
function Zp(){Zp=Oh;Yp=new $p('UNKNOWN',0);Xp=new $p('HOST',1);Wp=new $p('GUEST',2)}
function _h(a){var b;b=new $h;b.v='Class$'+(a?'S'+a:''+b.o);b.h=b.v;b.s=b.v;return b}
function qc(a,b){var c;if(!a.i){c=nc(a);!c.i&&(c.i=new kj);a.i=c.i}b.j=true;a.i.ub(b)}
function oc(a,b){var c;if(a.l){c=a.g;if(b.l!=c){b.l=c;!a.h&&(a.h=new kj);bj(a.h,b)}}}
function hi(a,b){var c;if(!a){return}b.u=a;var d=ei(b);if(!d){Kh[a]=[b];return}d.Zb=b}
function Zj(a,b){var c;c=b.i;b.g.h=b.h;b.h.g=b.g;b.g=b.h=null;b.i=null;--a.h;return c}
function ys(a,b){vl(a.g,(b?mi(b.H.j):null)+(''+(Yh(Ah),Ah.v)));ul(a.g,'a',b);return a}
function Ph(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Il(a){a.title='Room code should only contain letters or numbers.';return a}
function _n(a){ro(a,sl('answer',_s,a.D.localDescription));a.F=false;go(a);return null}
function ki(){Lc.call(this,"Stream already terminated, can't be modified or used")}
function Gh(){Hh();var a=Fh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function nn(a){Gb(a.m);mb(a.g);vb(a.h);vb(a.o);vb(a.l);vb(a.j);vb(a.i);vb(a.u);vb(a.s)}
function bo(a,b){var c;c=b.g;ro(a,sl('approve_access','id',c));tj(a.H,c);Ab(a.i);so(a)}
function mo(a,b){var c;c=b.track;a.J=Fk(Gk(a.J.Ab(),new xq(c)),new zk(new yk));pb(a.h)}
function yc(a){if(a.s>=0){a.s=-2;T((eb(),eb(),db),new bb(new Ec(a)),67108864,null)}}
function jo(a,b){if(Gd(a.L)===Gd(b.currentTarget)){pb(a.g);Wo(a,(jq(),cq));a.L=null}}
function ao(a,b){A(td(od(ze,1),Fs,1,5,['Answer error: ',b]));a.F=false;go(a);return null}
function xl(a,b,c,d){var e;e=yl($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function zl(a){var b;b=yl($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Uq(a){var b;b=$wnd.document;b.fullscreen?b.exitFullscreen():a.v.requestFullscreen()}
function pd(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Dd(a){return a!=null&&(typeof a===Cs||typeof a==='function')&&!(a._b===Sh)}
function Jh(a,b){typeof window===Cs&&typeof window['$gwt']===Cs&&(window['$gwt'][a]=b)}
function dc(a,b){this.h=a;this.g=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function Rb(a,b,c){Qb.call(this,null,a,b,c|(!a?262144:Hs)|(0==(c&6291456)?!a?Js:4194304:0)|0|0|0)}
function Kb(a){var b,c;for(c=new mj(a.h);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);b.g=4}}
function Gi(a,b){var c,d;for(d=b.sb();d.Eb();){c=d.Fb();if(!a.wb(c)){return false}}return true}
function pj(a){var b,c,d;d=0;for(c=a.sb();c.Eb();){b=c.Fb();d=d+(b!=null?w(b):0);d=d|0}return d}
function qj(a){var b,c,d;d=1;for(c=a.sb();c.Eb();){b=c.Fb();d=31*d+(b!=null?w(b):0);d=d|0}return d}
function Oj(a,b){var c;c=a.g.get(b);if(c===undefined){++a.i}else{Dj(a.g,b);--a.h}return c}
function cj(a,b){var c,d;c=b.Bb();d=c.length;if(d==0){return false}cl(a.g,a.g.length,c);return true}
function Si(a){if(a.g.Eb()){return true}if(a.g!=a.j){return false}a.g=new Cj(a.l.g);return a.g.Eb()}
function Dh(a){var b;if(Ad(a,7)){return a}b=a&&a.__java$exception;if(!b){b=new Pc(a);ld(b)}return b}
function wc(){var a;try{lc(jc);eb()}finally{a=jc.j;!a&&((eb(),eb(),db).j=true);jc=jc.j}}
function Qn(a,b){if(null!=a.D){b.getTracks().forEach(Ph(nq.prototype.T,nq,[a,b]));a.G=true;go(a)}}
function fn(a,b){vn(a,false);zn(a,b);b.getTracks().forEach(Ph(wp.prototype.T,wp,[a]));a.J.cb(b)}
function nk(a,b){if(0>a||a>b){throw Eh(new Vh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Th(){var a;a=$wnd.document.getElementById('app');$wnd.ReactDOM.render((new Fq).g,a,null)}
function Nj(a,b,c){var d;d=a.g.get(b);a.g.set(b,c===undefined?null:c);d===undefined?++a.h:++a.i;return d}
function td(a,b,c,d,e){e.Zb=a;e.$b=b;e._b=Sh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function wj(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(rj(a,c.Nb())){return c}}return null}
function mi(a){var b,c;if(a>-129&&a<128){b=a+128;c=(oi(),ni)[b];!c&&(c=ni[b]=new li(a));return c}return new li(a)}
function jn(a){var b;b=(Bb(a.o),a.D);null!=b&&b.getAudioTracks().forEach(Ph(sp.prototype.T,sp,[]));pb(a.g)}
function Em(){if(!Dm){Dm=(++(eb(),eb(),db).l,new _b);$wnd.Promise.resolve(null).then(Ph(Fm.prototype.kb,Fm,[]))}}
function Gb(a){if(2<(a.i&7)){T((eb(),eb(),db),new bb(new Vb(a)),67108864,null);!!a.g&&mb(a.g);ac(a.m);a.i=a.i&-8|1}}
function Pc(a){Nc();Fc(this);this.l=a;Gc(this,a);this.o=a==null?Ms:Rh(a);this.g='';this.h=a;this.g=''}
function Dc(a,b,c,d){this.j=a;this.l=d?new sj:null;this.o=b;this.h=c;this.m=null;this.g=null;this.i=null}
function $h(){this.o=Xh++;this.v=null;this.s=null;this.m=null;this.j=null;this.h=null;this.u=null;this.g=null}
function wl(a){var b;b=yl($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=rl(Ws,a);return b}
function Hq(a){var b,c,d;a.j=0;Em();c=(d=(b=nb(a.l.j.g),b.length==0?null:b),null==d?ss(a.l):ns(ls(a.l),d));return c}
function yb(a,b){var c,d;d=a.i;hj(d,b);!!a.h&&Hs!=(a.h.i&Is)&&a.i.g.length<=0&&0==a.h.g.j&&(a.j||qc((eb(),c=jc,c),a))}
function Im(a,b){Fi(a.i,b,true);3==a.i.h&&Yj(a.i);Uj(a.i,b);Ab(a.g);$wnd.localStorage.setItem(Ys,vi(a.i))}
function bc(a){if(1==(3&a.g)){a.g=-4&a.g|0;0==(a.g&Hs)?cc(a):Ib(a.h.g);0!=(a.g&524288)&&(2==(3&a.g)||(a.g=-4&a.g|2))}}
function v(a){return Fd(a)?Ce:Cd(a)?qe:Bd(a)?oe:zd(a)?a.Zb:sd(a)?a.Zb:a.Zb||Array.isArray(a)&&od(ge,1)||ge}
function Eo(a){return null==a.L?(Tp(),Rp):(Tp(),td(od(Ag,1),Fs,24,0,[Qp,Sp,Pp,Op,Rp]))[a.L.readyState]}
function Er(a){return xl('video',null,a.j,tl('autoPlay',true,'className',a.h.props['b'],'muted',a.h.props['c']))}
function Cm(){Am();return td(od(Bf,1),Fs,8,0,[em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm,qm,rm,sm,tm,um,vm,wm,xm,ym,zm])}
function tn(a){var b;return Wh(),b=(Bb(a.o),a.D),null!=b&&b.getAudioTracks().some(Ph(rp.prototype.U,rp,[]))?true:false}
function kn(a){var b;An(a,(Bb(a.u),!a.G));b=(Bb(a.o),a.D);null!=b&&b.getVideoTracks().forEach(Ph(tp.prototype.T,tp,[]))}
function $m(a,b,c){a.K==b?W((eb(),eb(),db),new Nn(a,c),Zs):c.getTracks().forEach(Ph(zp.prototype.T,zp,[]));return null}
function Fr(a,b){var c;c=a.h.props;if(!(c['b']===b['b'])){return true}if(!(c['c']===b['c'])){return true}return false}
function Rh(a){var b;if(Array.isArray(a)&&a._b===Sh){return Zh(v(a))+'@'+(b=w(a)>>>0,b.toString(16))}return a.toString()}
function nl(a){ll();var b,c,d;c=':'+a;d=kl[c];if(d!=null){return Hd(d)}d=il[c];b=d==null?ml(a):Hd(d);ol();kl[c]=b;return b}
function cn(a){var b,c,d;c=(Bb(a.o),a.D);d=(Bb(a.s),a.F);if(null!=c&&null!=d){b=c;Gd(b)!==Gd(d.srcObject)&&(d.srcObject=b)}}
function Tn(a,b){var c;c=a.D.getSenders().find(Ph(pq.prototype.U,pq,[b]));if(null!=c){a.D.removeTrack(c);a.G=true;go(a)}}
function dn(a){var b;++a.K;b=a.K;Zm(a);vn(a,true);a.I.Ub().then(Ph(up.prototype.W,up,[a,b])).catch(Ph(vp.prototype.X,vp,[a,b]))}
function pc(a){var b;if(a.i){while(!a.i.xb()){b=a.i.Kb(a.i.yb()-1);b.j=false;b.i.g.length>0||(b.h.i&7)>3&&Ob(b.h,3,true)}}}
function ec(a){var b,c,d;for(b=0;b<a.g.length;b++){d=a.g[b];if(0!=(d.i?d.g.length-d.h+d.j:d.j-d.h)){c=hb(d);return c}}return null}
function Fi(a,b,c){var d,e;for(e=a.sb();e.Eb();){d=e.Fb();if(Gd(b)===Gd(d)||b!=null&&u(b,d)){c&&e.Gb();return true}}return false}
function Wc(){var a;if(Rc!=0){a=Qc();if(a-Sc>2000){Sc=a;Tc=$wnd.setTimeout(ad,10)}}if(Rc++==0){dd((cd(),bd));return true}return false}
function Xj(a,b){var c,d;if(b>=a.h>>1){d=a.i;for(c=a.h;c>b;--c){d=d.h}}else{d=a.g.g;for(c=0;c<b;++c){d=d.g}}return new bk(a,b,d)}
function no(a,b){var c;if(Gd(a.D)===Gd(b.currentTarget)){c=b.streams;a.J=new lj(a.J);c.forEach(Ph(tq.prototype.T,tq,[a]));pb(a.h)}}
function ho(a,b){var c;if(Gd(a.L)===Gd(b.currentTarget)){a.L=null;c=(Bb(a.o),a.v);(jq(),hq)!=c&&aq!=c&&cq!=c&&Wo(a,aq);pb(a.g)}}
function ns(a,b){var c;ul(a.g,'b',b);return c=a.g.props,vl(a.g,wi(c['a']?mi(c['a'].h.j):null)+'-'+c['b']+(Yh(vh),vh.v)),a.g}
function Nm(){var a,b;Jm.call(this);eb();a=++Km;this.h=new Dc(a,new Om(this),new Pm(this),true);this.g=(b=new Eb(null),b)}
function Lq(a){var b;this.l=new Nm;this.i=a;eb();b=++Jq;this.h=new Dc(b,new Mq(this),new Nq(this),false);this.g=new Rb(null,new Pq(this),gt)}
function lk(){ik();var a,b,c;c=hk+++Date.now();a=Hd($wnd.Math.floor(c*Us))&16777215;b=Hd(c-a*Vs);this.g=a^1502;this.h=b^Ts}
function w(a){return Fd(a)?nl(a):Cd(a)?Hd(a):Bd(a)?a?1231:1237:zd(a)?a.O():sd(a)?hl(a):!!a&&!!a.hashCode?a.hashCode():hl(a)}
function Sb(a,b){Qb.call(this,a,new Tb(a),null,b|(Hs==(b&Is)?0:524288)|(0==(b&6291456)?Hs==(b&Is)?4194304:Js:0)|0|268435456|0)}
function gi(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function md(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function gn(a){var b;b=(Bb(a.o),a.D);Zm(a);W((eb(),eb(),db),new Jn(a,false),Zs);null!=b&&b.getTracks().forEach(Ph(yp.prototype.T,yp,[]))}
function jk(a,b){var c,d;fl(b>0);if((b&-b)==b){return Hd(b*kk(a)*4.6566128730773926E-10)}do{c=kk(a);d=c%b}while(c-d+(b-1)<0);return Hd(d)}
function hn(a,b){var c;vn(a,false);if(Ed(b,$wnd.DOMException)){c=b;yn(a,c.name);xn(a,c.message)}else{yn(a,Zh(v(b)));xn(a,b==null?Ms:Rh(b))}}
function Tp(){Tp=Oh;Qp=new Up('CONNECTING',0);Sp=new Up('OPEN',1);Pp=new Up('CLOSING',2);Op=new Up('CLOSED',3);Rp=new Up('NOT_REQUESTED',4)}
function Ac(a){var b,c,d;for(c=new mj(new lj(new Ri(a.l)));c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.Nb();Ad(d,10)&&d.bb()||b.Ob().$()}}
function ko(a,b){var c;if(Gd(a.D)===Gd(b.currentTarget)){c=b.candidate;null!=c&&null!=a.L&&ro(a,tl(Ns,bt,ct,c.sdpMLineIndex,bt,c.candidate))}}
function Tm(){var a;this.i=new qp(this);eb();a=++Rm;this.h=new Dc(a,null,new Um(this),true);this.g=new rb(new Xm,new Vm(this),new Wm(this),$s)}
function u(a,b){return Fd(a)?s(a,b):Cd(a)?Gd(a)===Gd(b):Bd(a)?Gd(a)===Gd(b):zd(a)?a.M(b):sd(a)?s(a,b):!!a&&!!a.equals?a.equals(b):Gd(a)===Gd(b)}
function Hm(){var a,b,c;b=new lk;c=new Ai;for(a=0;a<10;a++){xi(c,qi('abcdefghijklmnopqrstuvwxyz1234567890',$wnd.Math.abs(jk(b,36))))}return c.g}
function or(a,b){var c,d,e;b.preventDefault();c=(Cb(a.h),a.i);null!=c&&(d=$wnd.location,e=c.length==0?c:'#'+c,s(d.hash,e)||(d.hash=e),undefined)}
function yd(a,b){if(Fd(a)){return !!xd[b]}else if(a.$b){return !!a.$b[b]}else if(Cd(a)){return !!wd[b]}else if(Bd(a)){return !!vd[b]}return false}
function en(a,b){var c;pn(a,b);c=(Bb(a.o),a.D);if(b){null==c&&dn(a)}else{if(null!=c){c.getTracks().forEach(Ph(zp.prototype.T,zp,[]));zn(a,null)}}}
function Xn(a,b){var c,d;if(Ik(a.J.Ab(),new uq(b))){c=new vq;d=new En(new wq(b),c,true);dn(d);a.J.ub(d);b.onremovetrack=Ph(Dp.prototype.V,Dp,[a])}}
function El(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function hb(a){var b;if(0==(a.i?a.g.length-a.h+a.j:a.j-a.h)){return null}b=a.g[a.h];a.g[a.h]=null;++a.h;if(a.h>=a.g.length){a.h=0;a.i=false}return b}
function sc(a){var b,c,d;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new mj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;6!=d&&Ob(b,6,true)}}}
function tc(a){var b,c,d;if(a.i.g.length>0&&4==a.g){a.g=5;for(c=new mj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;4==d&&Ob(b,5,true)}}}
function rc(a){var b,c;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new mj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);5==(b.i&7)?Ob(b,6,true):4==(b.i&7)&&(a.g=4)}}}
function ui(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function nb(a){a.u?Cb(a.l):Bb(a.l);if(Pb(a.m)){if(a.u&&(eb(),!(!!jc&&!!jc.l))){return T((eb(),eb(),db),new sb(a),83888128,null)}else{Ib(a.m)}}return qb(a)}
function rd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function S(b,c,d){var e,f;try{vc(b,d);try{f=(c.g.$(),null)}finally{wc()}return f}catch(a){a=Dh(a);if(Ad(a,7)){e=a;throw Eh(e)}else throw Eh(a)}finally{Z(b)}}
function rb(a,b,c,d){this.i=a;this.o=b;this.s=c;this.v=null;this.u=16384==(d&16384);this.m=new Sb(this,d&-16385);this.l=new Eb(this.m);Hs==(d&Is)&&Hb(this.m)}
function Jm(){var a,b,c,d,e;this.i=new _j;this.j=new Tm;e=$wnd.localStorage.getItem(Ys);if(null!=e){for(b=si(e),c=0,d=b.length;c<d;++c){a=b[c];Vj(this.i,a)}}}
function vi(a){var b,c,d;d=new wk;for(c=Xj(a,0);c.h!=c.j.i;){b=ak(c);!d.g?(d.g=new Bi(d.j)):yi(d.g,d.h);yi(d.g,b)}return !d.g?d.i:d.l.length==0?d.g.g:d.g.g+(''+d.l)}
function to(a){var b;b=rn(a.K);null!=a.D&&null!=b&&sn(a.K)&&null!=a.D&&b.getTracks().forEach(Ph(oq.prototype.T,oq,[a]));Cn(a.K);null!=a.D&&sn(a.K)&&null!=b&&Qn(a,b)}
function Xb(a){var b,c;if(0==a.i){b=fc(a.j);if(0==b){a.g=0;return false}else if(a.g+1>a.h){a.g=0;return false}else{a.g=a.g+1;a.i=b}}--a.i;c=ec(a.j);bc(c);return true}
function Ih(b,c,d,e){Hh();var f=Fh;$moduleName=c;$moduleBase=d;Ch=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Bs(g)()}catch(a){b(c,a)}}else{Bs(g)()}}
function yl(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function ik(){ik=Oh;var a,b,c,d;fk=qd(Id,Fs,234,25,15,1);gk=qd(Id,Fs,234,33,15,1);d=1.52587890625E-5;for(b=32;b>=0;b--){gk[b]=d;d*=0.5}c=1;for(a=24;a>=0;a--){fk[a]=c;c*=0.5}}
function Hr(a){var b;this.j=Ph(vs.prototype.cb,vs,[this]);this.h=a;this.i=a.props['a'];eb();b=++Gr;this.g=new Dc(b,null,null,false);qn(this.i,this,new Ir(this));Z((null,db))}
function Ij(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Jj()}}
function ij(a,b){var c,d,e,f;e=null;f=0;for(d=0;d<a.g.length;++d){c=a.g[d];if(b.U(c)){if(e==null){e=_k(a.g,d);f=d}}else e!=null&&(e[f++]=c)}if(e==null){return false}a.g=e;return true}
function io(a,b){var c;if(Gd(a.D)===Gd(b.currentTarget)){c=a.D.iceConnectionState;if(s('disconnected',c)||s('failed',c)||s('closed',c)){a.J.rb(new Cp);a.J=new kj;pb(a.h)}else{fo(a)}}}
function T(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!jc){g=c._()}else{vc(b,e);try{g=c._()}finally{wc()}}return g}catch(a){a=Dh(a);if(Ad(a,7)){f=a;throw Eh(f)}else throw Eh(a)}finally{Z(b)}}
function co(a,b){if(null!=a.L){a.I.g=qd(ze,Fs,1,0,5,1);a.L.close();a.L=null;Wo(a,b)}if(null!=a.D){a.J.rb(new Ep);a.J.vb();Oi(a.H.g);a.D.close();a.D=null;a.F=false;a.G=false;Ab(a.i);pb(a.h)}}
function Lh(){Kh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function hd(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].ac()&&(c=gd(c,g)):g[0].ac()}catch(a){a=Dh(a);if(Ad(a,7)){d=a;Uc();$c(Ad(d,47)?d.jb():d)}else throw Eh(a)}}return c}
function Oc(a){var b;if(a.i==null){b=Gd(a.h)===Gd(Mc)?null:a.h;a.j=b==null?Ms:Dd(b)?b==null?null:b.name:Fd(b)?'String':Zh(v(b));a.g=a.g+': '+(Dd(b)?b==null?null:b.message:b+'');a.i='('+a.j+') '+a.g}}
function kk(a){var b,c,d,e,f,g;e=a.g*Ts+a.h*1502;g=a.h*Ts+11;b=$wnd.Math.floor(g*Us);e+=b;g-=b*Vs;e%=Vs;a.g=e;a.h=g;d=a.g*128;f=$wnd.Math.floor(a.h*gk[31]);c=d+f;c>=2147483648&&(c-=4294967296);return c}
function lb(b){var c,d,e;e=b.v;try{d=b.i._();if(!(Gd(e)===Gd(d)||e!=null&&u(e,d))){b.v=d;b.h=null;zb(b.l)}}catch(a){a=Dh(a);if(Ad(a,12)){c=a;if(!b.h){b.v=null;b.h=c;zb(b.l)}throw Eh(c)}else throw Eh(a)}}
function zj(a,b,c){var d,e,f,g,h;h=b==null?0:(g=w(b),g|0);e=(d=a.g.get(h),d==null?new Array:d);if(e.length==0){a.g.set(h,e)}else{f=wj(b,e);if(f){return f.Pb(c)}}e[e.length]=new _i(b,c);++a.h;return null}
function ml(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+qi(a,c++)}b=b|0;return b}
function al(a,b,c,d,e){var f,g,h,i,j;if(Gd(a)===Gd(c)){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function fo(a){var b;if(!a.F){b=(Cb(a.m),a.u);if((Zp(),Xp)==b){a.F=true;a.D.createOffer().then(Ph(qq.prototype.W,qq,[a])).then(Ph(rq.prototype.W,rq,[a])).catch(Ph(sq.prototype.X,sq,[a]))}else{ro(a,rl(Ns,at))}}}
function Hi(a,b){var c,d,e;c=b.Nb();e=b.Ob();d=Fd(c)?c==null?Ji(yj(a.g,null)):Mj(a.h,c):Ji(yj(a.g,c));if(!(Gd(e)===Gd(d)||e!=null&&u(e,d))){return false}if(d==null&&!(Fd(c)?Li(a,c):!!yj(a.g,c))){return false}return true}
function jb(a){var b,c,d,e,f,g;b=a.i?a.g.length-a.h+a.j:a.j-a.h;if(b+1>a.g.length){g=(a.g.length-1)*2+1;c=qd(ze,Fs,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.h+d)%a.g.length;c[f]=a.g[e];a.g[e]=null;++f}a.g=c;a.h=0;a.j=f;a.i=false}}
function Ib(b){var c;if(1!=(b.i&7)){try{if(4!=(b.i&7)){if(0!=(b.i&512)){!!b.l&&(b.i&=-513);c=b.j;U((eb(),eb(),db),b,c)}else{b.l.$()}}else 0!=(b.i&512)&&!!b.l&&(b.i&=-513)}catch(a){a=Dh(a);if(Ad(a,7)){eb()}else throw Eh(a)}}}
function xr(a){var b,c,d;this.l=a;this.o=a.props['a'];eb();b=++tr;this.j=new Dc(b,null,new yr(this),false);this.h=(d=new Eb((c=null,c)),d);this.g=new Rb(null,new Cr(this),gt);!!this.o&&Lm(this.o,this,new zr(this));Z((null,db))}
function Qb(a,b,c,d){this.h=new kj;this.m=new dc(new Ub(this),d&6520832|262144|Hs);this.i=d&-6520833|3;this.g=a;this.j=b;this.l=c;!!this.j&&(this.i|=512);!this.g&&!!this.j&&(Y((eb(),eb(),db),this),0==(this.m.g&Js)&&Z((null,db)))}
function Aj(a,b){var c,d,e,f,g,h;g=b==null?0:(f=w(b),f|0);d=(c=a.g.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(rj(b,e.Nb())){if(d.length==1){d.length=0;Dj(a.g,g)}else{d.splice(h,1)}--a.h;return e.Ob()}}return null}
function jq(){jq=Oh;iq=new kq('NOT_READY',0);bq=new kq('CONNECTED',1);gq=new kq('JOIN_REQUESTED',2);fq=new kq('JOIN_REJECTED',3);eq=new kq('JOINED',4);aq=new kq('CLOSED',5);hq=new kq('LEFT',6);dq=new kq('FULL',7);cq=new kq('ERROR',8)}
function Nh(a,b,c){var d=Kh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Kh[b]),Qh(h));_.$b=c;!b&&(_._b=Sh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.Zb=f)}
function Al(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ql(b,Ph(Dl.prototype.Vb,Dl,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ws]=c[0],undefined):(d[Ws]=c,undefined));return xl(a,e,f,d)}
function fi(a){if(a.pb()){var b=a.i;b.qb()?(a.v='['+b.u):!b.pb()?(a.v='[L'+b.nb()+';'):(a.v='['+b.nb());a.h=b.mb()+'[]';a.s=b.ob()+'[]';return}var c=a.m;var d=a.j;d=d.split('/');a.v=gi('.',[c,gi('$',d)]);a.h=gi('.',[c,gi('.',d)]);a.s=d[d.length-1]}
function Pb(b){var c,d,e,f,g;g=b.i&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new mj(b.h);e.g<e.i.g.length;){d=(e.h=e.g++,e.i.g[e.h]);if(d.h){f=d.h;c=f.g;try{nb(c)}catch(a){a=Dh(a);if(!Ad(a,7))throw Eh(a)}if(6==(b.i&7)){return true}}}}}Kb(b);return false}
function so(a){a.D=new $wnd.RTCPeerConnection(M({},[P({})]));a.F=false;a.G=false;a.D.onicecandidate=Ph(Mp.prototype.Y,Mp,[a]);a.D.ontrack=Ph(Np.prototype.Z,Np,[a]);a.D.onconnectionstatechange=Ph(Bp.prototype.R,Bp,[a]);a.D.onnegotiationneeded=Ph(mq.prototype.R,mq,[a]);eo(a,rn(a.B));eo(a,rn(a.K))}
function Gc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.gb();return a&&a.eb()}},suppressed:{get:function(){return c.fb()}}})}catch(a){}}}
function Hj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function er(a){var b;this.s=new as(this);this.j=a;this.m=a.props['a'];this.o=a.props['b'];eb();b=++ar;this.i=new Dc(b,new fr(this),new gr(this),false);this.g=new rb(new mr,new hr(this),new ir(this),35815424);this.h=new Rb(null,new nr(this),gt);Lm(this.m,this,new jr(this));this.u=new Zo(this.o,(jq(),iq),(Zp(),Yp));Qo(this.u);Mm(this.m,this.o);Z((null,db))}
function si(a){var b,c,d,e,f,g,h,i;b=new RegExp('\\|','g');h=qd(Ce,Fs,2,0,6,1);c=0;i=a;e=null;while(true){g=b.exec(i);if(g==null||i==''){h[c]=i;break}else{f=g.index;h[c]=i.substr(0,f);i=ti(i,f+g[0].length,i.length);b.lastIndex=0;if(e==i){h[c]=i.substr(0,1);i=i.substr(1)}e=i;++c}}if(a.length>0){d=h.length;while(d>0&&h[d-1]==''){--d}d<h.length&&(h.length=d)}return h}
function Ob(a,b,c){var d,e,f,g;g=a.i&7;if(b!=g){a.i=a.i&-8|b;if(!a.g&&6==b){c&&(1==(a.i&7)||1==(3&a.m.g)||Y((eb(),eb(),db),a))}else if(!!a.g&&4==g&&(6==b||5==b)){Db(a.g.l);c&&(1==(a.i&7)||1==(3&a.m.g)||Y((eb(),eb(),db),a))}else if(3==b||3!=g&&2==b){if(a.g){d=a.g;Nb((e=d.s,e));d.v=null}dj(a.h,new Wb(a));a.h.g=qd(ze,Fs,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.g&&Nb((f=a.g.o,f))}}
function oo(a){var b,c;W((eb(),eb(),db),new ip(a),ft);wn(a.B,true);pb(a.g);Vo(a,(Zp(),Yp));Wo(a,(jq(),iq));a.L=new $wnd.WebSocket((b=$wnd.location,c=s('https',b.protocol)?'wss':'ws',c+'://'+b.hostname+':'+3737+'/r/'+a.C));a.L.onopen=Ph(Ip.prototype.R,Ip,[a]);a.L.onmessage=Ph(Jp.prototype.S,Jp,[a]);a.L.onclose=Ph(Kp.prototype.Q,Kp,[a]);a.L.onerror=Ph(Lp.prototype.R,Lp,[a])}
function En(a,b,c){var d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;this.I=a;this.J=b;eb();d=++mn;this.H=new Dc(d,null,new Fn(this),true);this.A=c;this.G=true;this.h=(m=new Eb((f=null,f)),m);this.o=(n=new Eb((g=null,g)),n);this.l=(o=new Eb((h=null,h)),o);this.j=(p=new Eb((i=null,i)),p);this.i=(q=new Eb((j=null,j)),q);this.u=(r=new Eb((k=null,k)),r);this.s=(l=new Eb((e=null,e)),l);this.g=new rb(new Gn(this),null,null,$s);this.m=new Rb(new Hn(this),null,404750336);Z((null,db))}
function Zo(a,b,c){var d,e,f,g,h,i,j,k,l;this.I=new kj;this.H=new vj;this.B=new En(new Ap,new Fp(this),false);this.K=new En(new Gp,new Hp(this),false);this.J=new kj;this.C=a;eb();d=++xo;this.A=new Dc(d,new $o(this),new _o(this),true);this.v=b;this.u=c;this.s='';this.o=(i=new Eb((f=null,f)),i);this.m=(j=new Eb((g=null,g)),j);this.l=(k=new Eb((e=null,e)),k);this.j=(l=new Eb(null),l);this.i=(h=new Eb(null),h);this.g=new rb(new ap(this),null,null,$s);this.h=new rb(new bp(this),null,null,$s)}
function Am(){Am=Oh;em=new Bm(Xs,0);fm=new Bm('checkbox',1);gm=new Bm('color',2);hm=new Bm('date',3);im=new Bm('datetime',4);jm=new Bm('email',5);km=new Bm('file',6);lm=new Bm('hidden',7);mm=new Bm('image',8);nm=new Bm('month',9);om=new Bm('number',10);pm=new Bm('password',11);qm=new Bm('radio',12);rm=new Bm('range',13);sm=new Bm('reset',14);tm=new Bm('search',15);um=new Bm('submit',16);vm=new Bm('tel',17);wm=new Bm('text',18);xm=new Bm('time',19);ym=new Bm('url',20);zm=new Bm('week',21)}
function mc(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.l){return}j=(n=a.l.i&7,n>3?n:4);e=false;c=0;if(!!a.h&&1!=(a.l.i&7)){m=a.h.g.length;for(h=0;h<m;h++){k=ej(a.h,h);if(-1!=k.l&&-2!=k.l){k.l=-1;h!=c&&jj(a.h,c,k);++c;if(k.h){l=k.h;f=l.i&7;f==6&&(j=f)}}}}d=a.l.h;for(i=d.g.length-1;i>=0;i--){k=d.g[i];if(-1==k.l){k.l=0}else{yb(k,a.l);e=true}}2<(a.l.i&7)&&4!=j&&(a.l.i&7)<j&&Ob(a.l,j,false);if(a.h){for(g=c-1;g>=0;g--){k=ej(a.h,g);if(-1==k.l){k.l=0;xb(k,a.l);e=true}}}if(a.h){for(g=a.h.g.length-1;g>=c;g--){gj(a.h,g)}e&&Mb(a.l,a.h)}else{e&&Mb(a.l,new kj)}if(ub(a.l)&&!!a.l.g){b=a.l.g;k=b.l;!!k.h&&Hs!=(k.h.i&Is)&&k.i.g.length<=0&&0==k.h.g.j&&qc(a,k)}}
function rr(a){var b,c,d,e;a.m=0;Em();b=(c=(Cb(a.h),a.i),d=a.o,e=(Bb(d.g),d.i),Al(jt,Nl(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['home'])),Ph(ps.prototype.Wb,ps,[a])),[Al('h1',null,['vChat']),Al('label',Zl(new $wnd.Object,'roomCode'),['Enter a room code.']),Al('input',Il(Rl(Wl(Sl(Ul(Tl(Yl(Fl(Vl(El(Ml(new $wnd.Object,(Am(),wm)),td(od(Ce,1),Fs,2,6,['roomCodeInput'])),'Room code'),'roomCode'),null==c?'':c),Ph(rs.prototype.Wb,rs,[a]))),10)))),null),Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['roomSelectButtons'])),[Al(Xs,Ml(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[nt])),(bm(),am)),['Join']),Al('a',Jl(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[nt])),'#'+Hm()),['Join Random'])]),e.h==0?null:wl([Al(pt,null,['Recently used rooms:']),wl(Lk(Hk(new Mk(null,new uk(e,16)),new qs),new Cl))])]));return b}
function Jj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Ss]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Hj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Ss]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function lo(a,b){var c,d,e,f,g,h;d=b.data;g=$wnd.JSON.parse(d);f=g;if(Gd(a.L)===Gd(b.currentTarget)){pb(a.g);c=f[Ns];if(s('create',c)){A(td(od(ze,1),Fs,1,5,['Connected to room as host']));Vo(a,(Zp(),Xp));Wo(a,(jq(),eq))}else if(s('connect',c)){A(td(od(ze,1),Fs,1,5,['Connected to room as guest']));Vo(a,(Zp(),Wp));Wo(a,(jq(),bq))}else if(s('full',c)){A(td(od(ze,1),Fs,1,5,['Room full. Leaving room.']));Vo(a,(Zp(),Yp));co(a,(jq(),dq))}else if(s(dt,c)){e=f['id'];h=f['message'];A(td(od(ze,1),Fs,1,5,["Guest '"+e+"' requested access to room with message '"+h+"'"]));bj(a.I,new Gm(e,h));Ab(a.j)}else if(s('accept',c)){A(td(od(ze,1),Fs,1,5,['Host allowed guest to join room.']));Wo(a,(jq(),eq));so(a)}else if(s('reject',c)){A(td(od(ze,1),Fs,1,5,['Host rejected guest from room.']));Wo(a,(jq(),fq))}else if(s('accepted',c)){e=f['id'];A(td(od(ze,1),Fs,1,5,["Host accepted guest '"+e+"' into room."]));tj(a.H,e);Ab(a.i)}else if(s('remove',c)){e=f['id'];if(uj(a.H,e)){A(td(od(ze,1),Fs,1,5,["Guest '"+e+et]));Ab(a.i)}else if(ij(a.I,new yq(e))){A(td(od(ze,1),Fs,1,5,["Client '"+e+et]));Ab(a.j)}}else if(s('offer',c)){a.F=true;a.D.setRemoteDescription(f[_s]);a.D.createAnswer().then(Ph(zq.prototype.W,zq,[a])).then(Ph(Aq.prototype.W,Aq,[a])).catch(Ph(Bq.prototype.X,Bq,[a]))}else if(s('answer',c)){a.D.setRemoteDescription(f[_s]);a.F=false;go(a)}else s(bt,c)?a.D.addIceCandidate(N(O({},f[ct]),f[bt])):s(at,c)&&(a.G=true,go(a))}}
function $q(a){var b,c,d;a.l=0;Em();b=(c=a.u.B,d=nb(a.u.g),Al(pt,Hl(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['room-view'])),Ph(bs.prototype.cb,bs,[a])),[Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['video-section'])),[Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['video-list'])),Lk(Hk(nb(a.u.h).Ab(),new Zr),new Cl)),Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['active-video'])),[Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['active-video-wrapper'])),[zs(xs(ws(a.u.B),'active-video-element'),true)]),Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['controls'])),[Al(Xs,Ll(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[rt])),Ph(fs.prototype.Xb,fs,[a])),[Al(st,Ol(Ql(Pl(new $wnd.Object,sn(a.u.K)?'img/screen_share_on.svg':'img/screen_share_off.svg'),32),32),null)]),Al(Xs,Ll(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[rt])),Ph(gs.prototype.Xb,gs,[c])),[Al(st,Ol(Ql(Pl(new $wnd.Object,nb(c.g)?tt:ut),32),32),null)]),Al(Xs,Ll(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[rt])),Ph(hs.prototype.Xb,hs,[c])),[Al(st,Ol(Ql(Pl(new $wnd.Object,(Bb(c.u),c.G?'img/cam_on.svg':'img/cam_off.svg')),32),32),null)]),Al(Xs,Ll(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[rt])),Ph(is.prototype.Xb,is,[a])),[Al(st,Ol(Ql(Pl(new $wnd.Object,nb(a.g)?'img/fullscreen_on.svg':'img/fullscreen_off.svg'),32),32),null)]),Al(Xs,Ll(El(Kl(new $wnd.Object,(Tp(),Qp)!=d&&Sp!=d),td(od(Ce,1),Fs,2,6,[rt])),Ph(js.prototype.Xb,js,[a])),[Al(st,Ol(Ql(Pl(new $wnd.Object,'img/hangup.svg'),32),32),null)])])])]),Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['message-area'])),[Xq(a)])]));return b}
function Xq(a){var b,c;c=Xo(a.u);if((jq(),iq)==c){return wl([Al(it,null,['Getting ready...']),Al('p',null,["You'll be able to join in just a moment."])])}else if(cq==c){return wl([Al(it,null,['Service Offline']),Al('p',null,['The chat service is offline at the moment. Try again later.'])])}else if(bq==c){return wl([Al(it,null,['Ready to join?']),Al('p',null,['Request access to join the room.']),Al(jt,Nl(new $wnd.Object,Ph(_r.prototype.Wb,_r,[a])),[Al('label',Zl(new $wnd.Object,kt),[lt]),Al('input',Wl(Sl(Yl(Tl(Rl(Fl(Vl(Ml(new $wnd.Object,(Am(),wm)),mt),kt)),Ph(es.prototype.Wb,es,[a])),To(a.u)),30)),null),Al(Xs,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[nt])),[ot])])])}else if(gq==c){return wl([Al(it,null,['Joining room']),Al('p',null,['Waiting for host to allow access to the room.'])])}else if(eq==c&&(Zp(),Xp)==Uo(a.u)&&Do(a.u).g.length!=0){b=Do(a.u).g[0];return wl([Al(it,null,['Guest requests access']),Al('p',null,['A guest has sent you a message to join the room:']),Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['request-message'])),[b.h]),Al(jt,Nl(new $wnd.Object,Ph($r.prototype.Wb,$r,[])),[Al(Xs,Ll(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[nt])),Ph(cs.prototype.Xb,cs,[a,b])),['Accept']),Al(Xs,Ll(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[nt])),Ph(ds.prototype.Xb,ds,[a,b])),['Reject'])])])}else return eq==c&&(Zp(),Xp)==Uo(a.u)&&Pi(Co(a.u).g)==0?wl([Al(it,null,['Waiting for guests to join']),Al('p',null,['Waiting for someone to join this room']),Al('a',Jl(new $wnd.Object,'#'+a.u.C),[a.u.C])]):eq==c?wl([Al(it,null,['Joined room']),Al('p',null,['Joined room. Feel free to chat.'])]):fq==c?wl([Al(it,null,['Access denied']),Al('p',null,['The host denied access to the room. You can attempt to re-request access to join the room.']),Al(jt,Nl(new $wnd.Object,Ph(_r.prototype.Wb,_r,[a])),[Al('label',Zl(new $wnd.Object,kt),[lt]),Al('input',Wl(Sl(Yl(Tl(Rl(Fl(Vl(Ml(new $wnd.Object,(Am(),wm)),mt),kt)),Ph(es.prototype.Wb,es,[a])),To(a.u)),30)),null),Al(Xs,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[nt])),[ot])])]):aq==c?wl([Al(it,null,['Room closed']),Al('p',null,[(Zp(),Xp)==Uo(a.u)?'You closed the room.':'The host closed the room.']),Al('a',Jl(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[nt])),'#'),[qt])]):dq==c?wl([Al(it,null,['Room full']),Al('p',null,['The room is full and no other guests can connect at this time.']),Al('a',Jl(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[nt])),'#'),[qt])]):hq==c?wl([Al(it,null,['Left the room']),Al('p',null,['You left the room.']),Al('a',Jl(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,[nt])),'#'),[qt])]):null}
var Cs='object',Ds='hashchange',Es={5:1},Fs={3:1},Gs={10:1},Hs=1048576,Is=1835008,Js=2097152,Ks='__noinit__',Ls={3:1,12:1,9:1,7:1},Ms='null',Ns='command',Os={31:1,68:1},Ps={31:1,62:1},Qs={43:1},Rs={3:1,31:1,62:1},Ss='delete',Ts=15525485,Us=5.9604644775390625E-8,Vs=16777216,Ws='children',Xs='button',Ys='vchat.rooms',Zs=142606336,$s=35651584,_s='session',at='renegotiate',bt='candidate',ct='mlineindex',dt='request_access',et="' left the room.",ft=75497472,gt=1411518464,ht='fullscreenchange',it='h2',jt='form',kt='requestAccessMessage',lt='Enter a message to send to the host to request access.',mt="Hi, I'm John Doe.",nt='primary-button',ot='Request Access',pt='div',qt='Return to Home',rt='control-btn',st='img',tt='img/mic_on.svg',ut='img/mic_off.svg';var _,Kh,Fh,Ch=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Lh();Nh(1,null,{},t);_.M=function(a){return s(this,a)};_.N=function(){return this.Zb};_.O=wt;_.P=function(){var a;return Zh(v(this))+'@'+(a=w(this)>>>0,a.toString(16))};_.equals=function(a){return this.M(a)};_.hashCode=function(){return this.O()};_.toString=function(){return this.P()};var vd,wd,xd;Nh(70,1,{},$h);_.lb=function(a){var b;b=new $h;b.l=4;a>1?(b.i=di(this,a-1)):(b.i=this);return b};_.mb=function(){Yh(this);return this.h};_.nb=function(){return Zh(this)};_.ob=function(){Yh(this);return this.s};_.pb=function(){return (this.l&4)!=0};_.qb=function(){return (this.l&1)!=0};_.P=function(){return ((this.l&2)!=0?'interface ':(this.l&1)!=0?'':'class ')+(Yh(this),this.v)};_.l=0;_.o=0;var Xh=1;var ze=ai(1);var pe=ai(70);Nh(102,1,{},$);_.h=1;_.i=false;_.j=true;_.l=0;var Od=ai(102);Nh(103,1,Es,ab);_.$=function(){Yb(this.g)};var Ld=ai(103);Nh(56,1,{},bb);_._=function(){return this.g.$(),null};var Md=ai(56);Nh(104,1,{},cb);var Nd=ai(104);var db;Nh(57,1,{57:1},kb);_.h=0;_.i=false;_.j=0;var Pd=ai(57);Nh(258,1,Gs);_.P=function(){var a;return Zh(this.Zb)+'@'+(a=w(this)>>>0,a.toString(16))};var Sd=ai(258);Nh(38,258,Gs,rb);_.ab=function(){mb(this)};_.bb=vt;_.g=false;_.j=0;_.u=false;var Rd=ai(38);Nh(141,1,{},sb);_._=function(){return ob(this.g)};var Qd=ai(141);Nh(11,258,{10:1,11:1},Eb);_.ab=function(){vb(this)};_.bb=function(){return -2==this.l};_.g=4;_.j=false;_.l=0;var Ud=ai(11);Nh(140,1,Es,Fb);_.$=function(){wb(this.g)};var Td=ai(140);Nh(23,258,{10:1,23:1},Rb,Sb);_.ab=function(){Gb(this)};_.bb=function(){return 1==(this.i&7)};_.i=0;var Zd=ai(23);Nh(135,1,{},Tb);_.$=function(){lb(this.g)};var Vd=ai(135);Nh(136,1,Es,Ub);_.$=function(){Ib(this.g)};var Wd=ai(136);Nh(137,1,Es,Vb);_.$=function(){Lb(this.g)};var Xd=ai(137);Nh(138,1,{},Wb);_.cb=function(a){Jb(this.g,a)};var Yd=ai(138);Nh(115,1,{},Zb);_.g=0;_.h=0;_.i=0;var $d=ai(115);Nh(146,1,Gs,_b);_.ab=function(){$b(this)};_.bb=vt;_.g=false;var _d=ai(146);Nh(81,258,{10:1,81:1},dc);_.ab=function(){ac(this)};_.bb=function(){return 2==(3&this.g)};_.g=0;var be=ai(81);Nh(114,1,{},ic);var ae=ai(114);Nh(147,1,{},uc);_.P=function(){var a;return Yh(ce),ce.v+'@'+(a=hl(this)>>>0,a.toString(16))};_.g=0;var jc;var ce=ai(147);Nh(22,1,Gs,Dc);_.ab=function(){yc(this)};_.bb=function(){return this.s<0};_.P=function(){var a;return Yh(ee),ee.v+'@'+(a=hl(this)>>>0,a.toString(16))};_.j=0;_.s=0;var ee=ai(22);Nh(134,1,Es,Ec);_.$=function(){Bc(this.g)};var de=ai(134);Nh(7,1,{3:1,7:1});_.eb=Et;_.fb=function(){return Lk(Hk(oj((this.s==null&&(this.s=qd(Ee,Fs,7,0,0,1)),this.s)),new Ci),new Pk)};_.gb=function(){return this.m};_.hb=function(){return this.o};_.ib=function(){Hc(this,Jc(new Error(Ic(this,this.o))));ld(this)};_.P=function(){return Ic(this,this.hb())};_.l=Ks;_.u=true;var Ee=ai(7);Nh(12,7,{3:1,12:1,7:1});var se=ai(12);Nh(9,12,Ls);var Ae=ai(9);Nh(97,9,Ls);var xe=ai(97);Nh(98,97,Ls);var ie=ai(98);Nh(47,98,{47:1,3:1,12:1,9:1,7:1},Pc);_.hb=function(){Oc(this);return this.i};_.jb=function(){return Gd(this.h)===Gd(Mc)?null:this.h};var Mc;var fe=ai(47);var ge=ai(0);Nh(241,1,{});var he=ai(241);var Rc=0,Sc=0,Tc=-1;Nh(107,241,{},fd);var bd;var je=ai(107);var jd;Nh(252,1,{});var le=ai(252);Nh(99,252,{},nd);var ke=ai(99);Nh(72,1,{95:1});_.P=vt;var me=ai(72);Nh(101,9,Ls);var ve=ai(101);Nh(139,101,Ls,Vh);var ne=ai(139);vd={3:1,96:1,21:1};var oe=ai(96);Nh(55,1,{3:1,55:1});var ye=ai(55);wd={3:1,21:1,55:1};var qe=ai(251);Nh(15,1,{3:1,21:1,15:1});_.M=function(a){return this===a};_.O=wt;_.P=function(){return this.g!=null?this.g:''+this.h};_.h=0;var re=ai(15);Nh(71,9,Ls,ji);var te=ai(71);Nh(100,9,Ls,ki);var ue=ai(100);Nh(36,55,{3:1,21:1,36:1,55:1},li);_.M=function(a){return Ad(a,36)&&a.g==this.g};_.O=vt;_.P=function(){return ''+this.g};_.g=0;var we=ai(36);var ni;Nh(355,1,{});xd={3:1,95:1,21:1,2:1};var Ce=ai(2);Nh(54,72,{95:1},Ai,Bi);var Be=ai(54);Nh(359,1,{});Nh(93,1,{},Ci);_.tb=function(a){return a.l};var De=ai(93);Nh(46,9,Ls,Di,Ei);var Fe=ai(46);Nh(253,1,{31:1});_.rb=Dt;_.zb=function(){return new uk(this,0)};_.Ab=function(){return new Mk(null,this.zb())};_.ub=function(a){throw Eh(new Ei('Add not supported on this collection'))};_.vb=function(){var a;for(a=this.sb();a.Eb();){a.Fb();a.Gb()}};_.wb=function(a){return Fi(this,a,false)};_.xb=function(){return this.yb()==0};_.Bb=function(){return this.Cb(qd(ze,Fs,1,this.yb(),5,1))};_.Cb=function(a){var b,c,d,e;e=this.yb();a.length<e&&(a=el(new Array(e),a));d=a;c=this.sb();for(b=0;b<e;++b){d[b]=c.Fb()}a.length>e&&(a[e]=null);return a};_.P=function(){var a,b,c;c=new xk(', ','[',']');for(b=this.sb();b.Eb();){a=b.Fb();vk(c,a===this?'(this Collection)':a==null?Ms:Rh(a))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var Ge=ai(253);Nh(256,1,{238:1});_.M=function(a){var b,c,d;if(a===this){return true}if(!Ad(a,48)){return false}d=a;if(this.g.h+this.h.h!=d.g.h+d.h.h){return false}for(c=new Vi((new Ri(d)).g);c.h;){b=Ti(c);if(!Hi(this,b)){return false}}return true};_.O=function(){return pj(new Ri(this))};_.P=function(){var a,b,c;c=new xk(', ','{','}');for(b=new Vi((new Ri(this)).g);b.h;){a=Ti(b);vk(c,Ii(this,a.Nb())+'='+Ii(this,a.Ob()))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var Se=ai(256);Nh(116,256,{238:1});var Je=ai(116);Nh(255,253,Os);_.zb=function(){return new uk(this,1)};_.M=function(a){var b;if(a===this){return true}if(!Ad(a,68)){return false}b=a;if(b.yb()!=this.yb()){return false}return Gi(this,b)};_.O=function(){return pj(this)};var Ue=ai(255);Nh(34,255,Os,Ri);_.vb=zt;_.wb=function(a){return Qi(this,a)};_.sb=function(){return new Vi(this.g)};_.yb=At;var Ie=ai(34);Nh(37,1,{},Vi);_.Db=xt;_.Fb=function(){return Ti(this)};_.Eb=Bt;_.Gb=function(){Ui(this)};_.h=false;var He=ai(37);Nh(254,253,Ps);_.zb=function(){return new uk(this,16)};_.Hb=function(a,b){throw Eh(new Ei('Add not supported on this list'))};_.ub=function(a){this.Hb(this.yb(),a);return true};_.vb=function(){this.Lb(0,this.yb())};_.M=function(a){var b,c,d,e,f;if(a===this){return true}if(!Ad(a,62)){return false}f=a;if(this.yb()!=f.yb()){return false}e=f.sb();for(c=this.sb();c.Eb();){b=c.Fb();d=e.Fb();if(!(Gd(b)===Gd(d)||b!=null&&u(b,d))){return false}}return true};_.O=function(){return qj(this)};_.sb=function(){return new Xi(this)};_.Jb=function(a){return new Yi(this,a)};_.Kb=function(a){throw Eh(new Ei('Remove not supported on this list'))};_.Lb=function(a,b){var c,d;d=this.Jb(a);for(c=a;c<b;++c){d.Fb();d.Gb()}};var Me=ai(254);Nh(73,1,{},Xi);_.Db=xt;_.Eb=function(){return this.h<this.j.yb()};_.Fb=function(){this.h<this.j.yb();return this.j.Ib(this.i=this.h++)};_.Gb=yt;_.h=0;_.i=-1;var Ke=ai(73);Nh(106,73,{},Yi);_.Gb=yt;_.Mb=function(a){this.g.Hb(this.h,a);++this.h;this.i=-1};var Le=ai(106);Nh(110,255,Os,Zi);_.vb=zt;_.wb=Ct;_.sb=function(){var a;return a=new Vi((new Ri(this.g)).g),new $i(a)};_.yb=At;var Oe=ai(110);Nh(74,1,{},$i);_.Db=xt;_.Eb=function(){return this.g.h};_.Fb=function(){var a;a=Ti(this.g);return a.Nb()};_.Gb=function(){Ui(this.g)};var Ne=ai(74);Nh(108,1,Qs);_.M=function(a){var b;if(!Ad(a,43)){return false}b=a;return rj(this.g,b.Nb())&&rj(this.h,b.Ob())};_.Nb=vt;_.Ob=Bt;_.O=function(){return ek(this.g)^ek(this.h)};_.Pb=function(a){var b;b=this.h;this.h=a;return b};_.P=function(){return this.g+'='+this.h};var Pe=ai(108);Nh(109,108,Qs,_i);var Qe=ai(109);Nh(257,1,Qs);_.M=function(a){var b;if(!Ad(a,43)){return false}b=a;return rj(this.h.value[0],b.Nb())&&rj(Rj(this),b.Ob())};_.O=function(){return ek(this.h.value[0])^ek(Rj(this))};_.P=function(){return this.h.value[0]+'='+Rj(this)};var Re=ai(257);Nh(260,254,Ps);_.Hb=function(a,b){var c;c=this.Jb(a);c.Mb(b)};_.Ib=function(a){var b;b=this.Jb(a);return b.Fb()};_.sb=function(){return Xj(this,0)};_.Kb=function(a){var b,c;b=this.Jb(a);c=b.Fb();b.Gb();return c};var Te=ai(260);Nh(14,254,Rs,kj,lj);_.Hb=function(a,b){bl(this.g,a,b)};_.ub=function(a){return bj(this,a)};_.vb=function(){this.g=qd(ze,Fs,1,0,5,1)};_.wb=function(a){return fj(this,a,0)!=-1};_.rb=function(a){dj(this,a)};_.Ib=function(a){return ej(this,a)};_.xb=function(){return this.g.length==0};_.sb=function(){return new mj(this)};_.Kb=function(a){return gj(this,a)};_.Lb=function(a,b){var c;c=b-a;dl(this.g,a,c)};_.yb=function(){return this.g.length};_.Bb=function(){return _k(this.g,this.g.length)};_.Cb=function(a){var b,c;c=this.g.length;a.length<c&&(a=el(new Array(c),a));for(b=0;b<c;++b){a[b]=this.g[b]}a.length>c&&(a[c]=null);return a};var We=ai(14);Nh(27,1,{},mj);_.Db=xt;_.Eb=function(){return this.g<this.i.g.length};_.Fb=function(){return this.h=this.g++,this.i.g[this.h]};_.Gb=function(){gj(this.i,this.g=this.h);this.h=-1};_.g=0;_.h=-1;var Ve=ai(27);Nh(48,116,{3:1,48:1,238:1},sj);var Xe=ai(48);Nh(166,255,{3:1,31:1,68:1},vj);_.ub=function(a){return tj(this,a)};_.vb=zt;_.wb=Ct;_.xb=function(){return Pi(this.g)==0};_.sb=function(){var a;return a=new Vi((new Ri((new Zi(this.g)).g)).g),new $i(a)};_.yb=At;var Ye=ai(166);Nh(75,1,{},Bj);_.rb=Dt;_.sb=function(){return new Cj(this)};_.h=0;var $e=ai(75);Nh(76,1,{},Cj);_.Db=xt;_.Fb=function(){return this.j=this.g[this.i++],this.j};_.Eb=function(){var a;if(this.i<this.g.length){return true}a=this.h.next();if(!a.done){this.g=a.value[1];this.i=0;return true}return false};_.Gb=function(){Aj(this.l,this.j.Nb());this.i!=0&&--this.i};_.i=0;_.j=null;var Ze=ai(76);var Fj;Nh(77,1,{},Pj);_.rb=Dt;_.sb=function(){return new Qj(this)};_.h=0;_.i=0;var bf=ai(77);Nh(78,1,{},Qj);_.Db=xt;_.Fb=function(){return this.i=this.g,this.g=this.h.next(),new Sj(this.j,this.i,this.j.i)};_.Eb=function(){return !this.g.done};_.Gb=function(){Oj(this.j,this.i.value[0])};var _e=ai(78);Nh(117,257,Qs,Sj);_.Nb=function(){return this.h.value[0]};_.Ob=function(){return Rj(this)};_.Pb=function(a){return Nj(this.g,this.h.value[0],a)};_.i=0;var af=ai(117);Nh(157,260,Rs,_j);_.ub=function(a){Wj(this,a,this.i.h,this.i);return true};_.vb=function(){$j(this)};_.Jb=function(a){return Xj(this,a)};_.yb=Bt;_.h=0;var ef=ai(157);Nh(158,1,{},bk);_.Db=xt;_.Mb=function(a){Wj(this.j,a,this.h.h,this.h);++this.g;this.i=null};_.Eb=function(){return this.h!=this.j.i};_.Fb=function(){return ak(this)};_.Gb=function(){var a;a=this.i.g;Zj(this.j,this.i);this.h==this.i?(this.h=a):--this.g;this.i=null};_.g=0;_.i=null;var cf=ai(158);Nh(59,1,{},ck);var df=ai(59);Nh(200,1,{},lk);_.g=0;_.h=0;var fk,gk,hk=0;var ff=ai(200);Nh(119,1,{});_.Db=Ft;_.Qb=function(){return this.j};_.Rb=Et;_.j=0;_.l=0;var kf=ai(119);Nh(79,119,{});var gf=ai(79);Nh(111,1,{});_.Db=Ft;_.Qb=Bt;_.Rb=function(){return this.j-this.i};_.h=0;_.i=0;_.j=0;var jf=ai(111);Nh(112,111,{},sk);_.Db=function(a){pk(this,a)};_.Sb=function(a){return qk(this,a)};var hf=ai(112);Nh(28,1,{},uk);_.Qb=vt;_.Rb=function(){tk(this);return this.i};_.Db=function(a){tk(this);this.j.Db(a)};_.Sb=function(a){tk(this);if(this.j.Eb()){a.cb(this.j.Fb());return true}return false};_.g=0;_.i=0;var lf=ai(28);Nh(45,1,{},wk,xk);_.P=function(){return !this.g?this.i:this.l.length==0?this.g.g:this.g.g+(''+this.l)};var mf=ai(45);Nh(69,1,{},yk);_.tb=function(a){return a};var nf=ai(69);Nh(82,1,{},zk);var of=ai(82);Nh(118,1,{});_.i=false;var yf=ai(118);Nh(29,118,{},Mk);var Dk;var xf=ai(29);Nh(94,1,{},Pk);_.Tb=function(a){return Ek(),qd(ze,Fs,1,a,5,1)};var pf=ai(94);Nh(80,79,{},Rk);_.Sb=function(a){this.h=false;while(!this.h&&this.i.Sb(new Sk(this,a)));return this.h};_.h=false;var rf=ai(80);Nh(123,1,{},Sk);_.cb=function(a){Qk(this.g,this.h,a)};var qf=ai(123);Nh(120,79,{},Uk);_.Sb=function(a){return this.h.Sb(new Vk(this,a))};var tf=ai(120);Nh(122,1,{},Vk);_.cb=function(a){Tk(this.g,this.h,a)};var sf=ai(122);Nh(121,1,{},Xk);_.cb=function(a){Wk(this,a)};var uf=ai(121);Nh(124,1,{},Yk);_.cb=function(a){Ek()};var vf=ai(124);Nh(125,1,{},$k);_.cb=function(a){Zk(this,a)};var wf=ai(125);Nh(357,1,{});Nh(354,1,{});var gl=0;var il,jl=0,kl;Nh(1357,1,{});Nh(1389,1,{});Nh(83,1,{},Cl);_.Tb=function(a){return new Array(a)};var zf=ai(83);Nh(307,$wnd.Function,{},Dl);_.Vb=function(a){Bl(this.g,this.h,a)};Nh(39,15,{3:1,21:1,15:1,39:1},cm);var $l,_l,am;var Af=bi(39,dm);Nh(8,15,{3:1,21:1,15:1,8:1},Bm);var em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm,qm,rm,sm,tm,um,vm,wm,xm,ym,zm;var Bf=bi(8,Cm);var Dm;Nh(292,$wnd.Function,{},Fm);_.kb=function(a){return $b(Dm),Dm=null,null};Nh(86,1,{86:1},Gm);var Cf=ai(86);Nh(58,1,{58:1});var Df=ai(58);Nh(148,58,{10:1,58:1},Nm);_.ab=Gt;_.bb=Ht;_.P=function(){var a;return Yh(Hf),Hf.v+'@'+(a=hl(this)>>>0,a.toString(16))};var Km=0;var Hf=ai(148);Nh(149,1,Es,Om);_.$=function(){tb(this.g.j)};var Ef=ai(149);Nh(150,1,Es,Pm);_.$=function(){vb(this.g.g)};var Ff=ai(150);Nh(151,1,Es,Qm);_.$=function(){Im(this.g,this.h)};var Gf=ai(151);Nh(159,1,{});var sg=ai(159);Nh(160,159,Gs,Tm);_.ab=Gt;_.bb=Ht;_.P=function(){var a;return Yh(Nf),Nf.v+'@'+(a=hl(this)>>>0,a.toString(16))};var Rm=0;var Nf=ai(160);Nh(161,1,Es,Um);_.$=function(){mb(this.g.g)};var If=ai(161);Nh(163,1,{},Vm);_.$=function(){B(this.g.i)};var Jf=ai(163);Nh(164,1,{},Wm);_.$=function(){C(this.g.i)};var Kf=ai(164);Nh(162,1,{},Xm);_._=function(){var a;return a=$wnd.location.hash,a.length==0?a:a.substr(1)};var Lf=ai(162);Nh(165,1,Es,Ym);_.$=Lt;var Mf=ai(165);Nh(60,1,{60:1});_.K=0;var tg=ai(60);Nh(61,60,{10:1,60:1},En);_.ab=function(){yc(this.H)};_.bb=function(){return this.H.s<0};_.P=function(){var a;return Yh(Zf),Zf.v+'@'+(a=hl(this)>>>0,a.toString(16))};_.v=false;_.A=false;_.G=false;var mn=0;var Zf=ai(61);Nh(221,1,Es,Fn);_.$=function(){nn(this.g)};var Of=ai(221);Nh(222,1,{},Gn);_._=function(){return tn(this.g)};var Pf=ai(222);Nh(223,1,{},Hn);_.$=function(){cn(this.g)};var Qf=ai(223);Nh(224,1,Es,In);_.$=function(){on(this.g,this.h)};var Rf=ai(224);Nh(87,1,Es,Jn);_.$=function(){en(this.g,this.h)};_.h=false;var Sf=ai(87);Nh(225,1,Es,Kn);_.$=function(){un(this.g)};var Tf=ai(225);Nh(226,1,Es,Ln);_.$=function(){jn(this.g)};var Uf=ai(226);Nh(227,1,Es,Mn);_.$=function(){kn(this.g)};var Vf=ai(227);Nh(228,1,Es,Nn);_.$=function(){fn(this.g,this.h)};var Wf=ai(228);Nh(229,1,Es,On);_.$=function(){gn(this.g)};var Xf=ai(229);Nh(230,1,Es,Pn);_.$=function(){hn(this.g,this.h)};var Yf=ai(230);Nh(201,1,{});_.F=false;_.G=false;var Lg=ai(201);Nh(202,201,Gs,Zo);_.ab=function(){yc(this.A)};_.bb=function(){return this.A.s<0};_.P=function(){var a;return Yh(qg),qg.v+'@'+(a=hl(this)>>>0,a.toString(16))};var xo=0;var qg=ai(202);Nh(203,1,Es,$o);_.$=function(){zo(this.g)};var $f=ai(203);Nh(204,1,Es,_o);_.$=function(){yo(this.g)};var _f=ai(204);Nh(205,1,{},ap);_._=function(){return Eo(this.g)};var ag=ai(205);Nh(206,1,{},bp);_._=function(){return Rn(this.g)};var bg=ai(206);Nh(207,1,Es,cp);_.$=function(){Ao(this.g,this.h)};var cg=ai(207);Nh(208,1,Es,dp);_.$=function(){to(this.g)};var dg=ai(208);Nh(209,1,Es,ep);_.$=function(){oo(this.g)};var eg=ai(209);Nh(210,1,Es,fp);_.$=function(){io(this.g,this.h)};var fg=ai(210);Nh(211,1,Es,gp);_.$=function(){no(this.g,this.h)};var gg=ai(211);Nh(212,1,Es,hp);_.$=function(){mo(this.g,this.h)};var hg=ai(212);Nh(85,1,Es,ip);_.$=function(){co(this.g,(jq(),hq))};var ig=ai(85);Nh(213,1,Es,jp);_.$=function(){jo(this.g,this.h)};var jg=ai(213);Nh(214,1,Es,kp);_.$=function(){Fo(this.g,this.h)};var kg=ai(214);Nh(215,1,Es,lp);_.$=function(){ho(this.g,this.h)};var lg=ai(215);Nh(216,1,Es,mp);_.$=function(){lo(this.g,this.h)};var mg=ai(216);Nh(217,1,Es,np);_.$=function(){qo(this.g)};var ng=ai(217);Nh(218,1,Es,op);_.$=function(){Go(this.g,this.h)};var og=ai(218);Nh(219,1,Es,pp);_.$=function(){Ho(this.g,this.h)};var pg=ai(219);Nh(145,1,{},qp);_.handleEvent=function(a){Sm(this.g)};var rg=ai(145);Nh(336,$wnd.Function,{},rp);_.U=function(a){return a.enabled};Nh(329,$wnd.Function,{},sp);_.T=It;Nh(330,$wnd.Function,{},tp);_.T=It;Nh(331,$wnd.Function,{},up);_.W=function(a){return $m(this.g,this.h,a)};_.h=0;Nh(332,$wnd.Function,{},vp);_.X=function(a){return _m(this.g,this.h,a)};_.h=0;Nh(333,$wnd.Function,{},wp);_.T=function(a){an(this.g,a)};Nh(335,$wnd.Function,{},xp);_.R=function(a){bn(this.g)};Nh(334,$wnd.Function,{},yp);_.T=function(a){ln(a)};Nh(269,$wnd.Function,{},zp);_.T=function(a){s('live',a.readyState)&&a.stop()};Nh(185,1,{},Ap);_.Ub=function(){return $wnd.navigator.mediaDevices.getUserMedia(J(I({}),K(L({},F(D(G({},160),640),1280)),F(D(G({},120),360),720))))};var ug=ai(185);Nh(317,$wnd.Function,{},Bp);_.R=function(a){Ko(this.g,a)};Nh(189,1,{},Cp);_.cb=Jt;var vg=ai(189);Nh(328,$wnd.Function,{},Dp);_.V=function(a){Oo(this.g,a)};Nh(194,1,{},Ep);_.cb=Jt;var wg=ai(194);Nh(186,1,{},Fp);_.cb=Kt;var xg=ai(186);Nh(187,1,{},Gp);_.Ub=function(){return $wnd.navigator.mediaDevices.getDisplayMedia(H({}))};var yg=ai(187);Nh(188,1,{},Hp);_.cb=Kt;var zg=ai(188);Nh(310,$wnd.Function,{},Ip);_.R=function(a){No(this.g,a)};Nh(311,$wnd.Function,{},Jp);_.S=function(a){Mo(this.g,a)};Nh(312,$wnd.Function,{},Kp);_.Q=function(a){Jo(this.g,a)};Nh(313,$wnd.Function,{},Lp);_.R=function(a){Lo(this.g,a)};Nh(315,$wnd.Function,{},Mp);_.Y=function(a){ko(this.g,a)};Nh(316,$wnd.Function,{},Np);_.Z=function(a){Po(this.g,a)};Nh(24,15,{3:1,21:1,15:1,24:1},Up);var Op,Pp,Qp,Rp,Sp;var Ag=bi(24,Vp);Nh(40,15,{3:1,21:1,15:1,40:1},$p);var Wp,Xp,Yp;var Bg=bi(40,_p);Nh(16,15,{3:1,21:1,15:1,16:1},kq);var aq,bq,cq,dq,eq,fq,gq,hq,iq;var Cg=bi(16,lq);Nh(318,$wnd.Function,{},mq);_.R=function(a){fo(this.g)};Nh(319,$wnd.Function,{},nq);_.T=function(a){Sn(this.g,this.h,a)};Nh(308,$wnd.Function,{},oq);_.T=function(a){Tn(this.g,a)};Nh(327,$wnd.Function,{},pq);_.U=function(a){return uo(this.g,a)};Nh(320,$wnd.Function,{},qq);_.W=function(a){return Un(this.g,a)};Nh(321,$wnd.Function,{},rq);_.W=function(a){return Vn(this.g)};Nh(322,$wnd.Function,{},sq);_.X=function(a){return Wn(this.g,a)};Nh(323,$wnd.Function,{},tq);_.T=function(a){Xn(this.g,a)};Nh(190,1,{},uq);_.U=function(a){return Yn(this.g,a)};var Dg=ai(190);Nh(191,1,{},vq);_.cb=function(a){};var Eg=ai(191);Nh(192,1,{},wq);_.Ub=function(){return $wnd.Promise.resolve(this.g)};var Fg=ai(192);Nh(193,1,{},xq);_.U=function(a){return Zn(this.g,a)};var Gg=ai(193);Nh(195,1,{},yq);_.U=function(a){return vo(this.g,a)};var Hg=ai(195);Nh(324,$wnd.Function,{},zq);_.W=function(a){return $n(this.g,a)};Nh(325,$wnd.Function,{},Aq);_.W=function(a){return _n(this.g)};Nh(326,$wnd.Function,{},Bq);_.X=function(a){return ao(this.g,a)};Nh(196,1,Es,Cq);_.$=function(){bo(this.g,this.h)};var Ig=ai(196);Nh(197,1,Es,Dq);_.$=function(){ro(this.g,sl('reject_access','id',this.h.g))};var Jg=ai(197);Nh(198,1,{},Eq);_.U=function(a){return wo(this.g,a)};var Kg=ai(198);Nh(127,1,{});var Ng=ai(127);Nh(92,1,{},Fq);var Mg=ai(92);Nh(128,127,{});_.j=0;var lh=ai(128);Nh(129,128,Gs,Lq);_.ab=Gt;_.bb=Ht;_.P=function(){var a;return Yh(Sg),Sg.v+'@'+(a=hl(this)>>>0,a.toString(16))};var Jq=0;var Sg=ai(129);Nh(130,1,Es,Mq);_.$=function(){tb(this.g.l)};var Og=ai(130);Nh(131,1,Es,Nq);_.$=function(){Gb(this.g.g)};var Pg=ai(131);Nh(133,1,{},Oq);_._=function(){return Hq(this.g)};var Qg=ai(133);Nh(132,1,{},Pq);_.$=function(){Iq(this.g)};var Rg=ai(132);Nh(144,1,{});var vh=ai(144);Nh(174,144,{});_.l=0;var nh=ai(174);Nh(175,174,Gs,er);_.ab=function(){yc(this.i)};_.bb=function(){return this.i.s<0};_.P=function(){var a;return Yh(ah),ah.v+'@'+(a=hl(this)>>>0,a.toString(16))};var ar=0;var ah=ai(175);Nh(176,1,Es,fr);_.$=function(){tb(this.g.u)};var Tg=ai(176);Nh(177,1,Es,gr);_.$=function(){br(this.g)};var Ug=ai(177);Nh(179,1,{},hr);_.$=function(){Vq(this.g)};var Vg=ai(179);Nh(180,1,{},ir);_.$=function(){Wq(this.g)};var Wg=ai(180);Nh(182,1,Es,jr);_.$=function(){yc(this.g.i)};var Xg=ai(182);Nh(183,1,{},kr);_._=function(){return $q(this.g)};var Yg=ai(183);Nh(184,1,Es,lr);_.$=Lt;var Zg=ai(184);Nh(178,1,{},mr);_._=function(){return Wh(),$wnd.document.fullscreen?true:false};var $g=ai(178);Nh(181,1,{},nr);_.$=function(){_q(this.g)};var _g=ai(181);Nh(259,1,{});var yh=ai(259);Nh(167,259,{});_.m=0;var ph=ai(167);Nh(168,167,Gs,xr);_.ab=function(){yc(this.j)};_.bb=function(){return this.j.s<0};_.P=function(){var a;return Yh(hh),hh.v+'@'+(a=hl(this)>>>0,a.toString(16))};var tr=0;var hh=ai(168);Nh(169,1,Es,yr);_.$=function(){ur(this.g)};var bh=ai(169);Nh(171,1,Es,zr);_.$=function(){yc(this.g.j)};var dh=ai(171);Nh(172,1,Es,Ar);_.$=function(){vr(this.g,this.h)};var eh=ai(172);Nh(173,1,{},Br);_._=function(){return rr(this.g)};var fh=ai(173);Nh(170,1,{},Cr);_.$=function(){sr(this.g)};var gh=ai(170);Nh(199,1,{});var Ah=ai(199);Nh(231,199,{});var rh=ai(231);Nh(232,231,Gs,Hr);_.ab=function(){yc(this.g)};_.bb=function(){return this.g.s<0};_.P=function(){var a;return Yh(jh),jh.v+'@'+(a=hl(this)>>>0,a.toString(16))};var Gr=0;var jh=ai(232);Nh(233,1,Es,Ir);_.$=function(){yc(this.g.g)};var ih=ai(233);Nh(291,$wnd.Function,{},Jr);_.Yb=function(a){return new Mr(a)};var Kr;Nh(113,$wnd.React.Component,{},Mr);Mh(Kh[1],_);_.componentWillUnmount=function(){Gq(this.g)};_.render=function(){return Kq(this.g)};_.shouldComponentUpdate=function(a){return 1==this.g.j};var kh=ai(113);Nh(296,$wnd.Function,{},Nr);_.Yb=function(a){return new Qr(a)};var Or;Nh(154,$wnd.React.Component,{},Qr);Mh(Kh[1],_);_.componentWillUnmount=function(){ub(this.g)&&Zq(this.g)};_.render=function(){return ub(this.g)?cr(this.g):null};_.shouldComponentUpdate=function(a){return ub(this.g)&&1==this.g.l};var mh=ai(154);Nh(293,$wnd.Function,{},Rr);_.Yb=function(a){return new Ur(a)};var Sr;Nh(152,$wnd.React.Component,{},Ur);Mh(Kh[1],_);_.componentWillUnmount=function(){ub(this.g)&&qr(this.g)};_.render=function(){return ub(this.g)?wr(this.g):null};_.shouldComponentUpdate=function(a){return ub(this.g)&&1==this.g.m};var oh=ai(152);Nh(337,$wnd.Function,{},Vr);_.Yb=function(a){return new Yr(a)};var Wr;Nh(220,$wnd.React.Component,{},Yr);Mh(Kh[1],_);_.componentWillUnmount=function(){ub(this.g)&&yc(this.g.g)};_.render=function(){return ub(this.g)?Er(this.g):null};_.shouldComponentUpdate=function(a){return ub(this.g)&&Fr(this.g,a)};var qh=ai(220);Nh(156,1,{},Zr);_.tb=function(a){var b;return Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['video-list-item'])),[Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['video-list-item-wrapper'])),[zs(xs(ys(new As,a),'video-list-item-element'),false)]),(b=(Bb(a.o),a.D),null!=b&&b.getAudioTracks().length>0?Al(pt,El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['video-list-item-controls'])),[Al(Xs,Ll(El(new $wnd.Object,td(od(Ce,1),Fs,2,6,['video-list-item-control-btn'])),Ph(ks.prototype.Xb,ks,[a])),[Al(st,Ol(Ql(Pl(new $wnd.Object,nb(a.g)?tt:ut),16),16),null)])]):null)])};var sh=ai(156);Nh(304,$wnd.Function,{},$r);_.Wb=function(a){a.preventDefault()};Nh(267,$wnd.Function,{},_r);_.Wb=function(a){Yq(this.g,a)};Nh(155,1,{},as);_.handleEvent=function(a){dr(this.g)};var th=ai(155);Nh(297,$wnd.Function,{},bs);_.cb=function(a){Qq(this.g,a)};Nh(305,$wnd.Function,{},cs);_.Xb=function(a){Rq(this.g,this.h,a)};Nh(306,$wnd.Function,{},ds);_.Xb=function(a){Sq(this.g,this.h,a)};Nh(268,$wnd.Function,{},es);_.Wb=function(a){Tq(this.g,a)};Nh(298,$wnd.Function,{},fs);_.Xb=function(a){Yo(this.g.u)};Nh(299,$wnd.Function,{},gs);_.Xb=Mt;Nh(300,$wnd.Function,{},hs);_.Xb=function(a){Dn(this.g)};Nh(301,$wnd.Function,{},is);_.Xb=function(a){Uq(this.g)};Nh(302,$wnd.Function,{},js);_.Xb=function(a){Io(this.g.u)};Nh(303,$wnd.Function,{},ks);_.Xb=Mt;Nh(143,1,{},os);var uh=ai(143);Nh(294,$wnd.Function,{},ps);_.Wb=function(a){or(this.g,a)};Nh(153,1,{},qs);_.tb=function(a){return Al('a',Jl(El(Gl(new $wnd.Object,a),td(od(Ce,1),Fs,2,6,['recent-room'])),'#'+a),[a])};var wh=ai(153);Nh(295,$wnd.Function,{},rs);_.Wb=function(a){var b;pr(this.g,ui((b=a.target,b).value))};Nh(142,1,{},us);var xh=ai(142);Nh(338,$wnd.Function,{},vs);_.cb=function(a){Dr(this.g,a)};Nh(84,1,{},As);var zh=ai(84);var Kd=ci('I');var Id=ci('D');var Jd=ci('F');var Bh=ci('S');var Bs=(Uc(),Xc);var gwtOnLoad=gwtOnLoad=Ih;Gh(Th);Jh('permProps',[[]]);if (vchat) vchat.onScriptLoad(gwtOnLoad);})();