function vchat(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='vchat',tb='__gwt_marker_vchat',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='60B1B3D8E56DA4AA5E023D53B1718A21',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};vchat.onScriptLoad=function(a){vchat=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
vchat();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '60B1B3D8E56DA4AA5E023D53B1718A21';function w(){}
function wh(){}
function Ah(){}
function Nb(){}
function Tc(){}
function $c(){}
function xi(){}
function Zj(){}
function tk(){}
function Kk(){}
function Sk(){}
function Tk(){}
function Tm(){}
function zm(){}
function wl(){}
function jp(){}
function kp(){}
function pp(){}
function qp(){}
function rp(){}
function tp(){}
function vp(){}
function xp(){}
function jq(){}
function mq(){}
function dr(){}
function Ar(){}
function Er(){}
function Ir(){}
function Mr(){}
function Qr(){}
function Wr(){}
function gs(){}
function Yc(a){Xc()}
function Rh(){Rh=wh}
function kt(){Ri(this)}
function fj(){Xi(this)}
function N(a){this.g=a}
function O(a){this.g=a}
function P(a){this.g=a}
function Ph(a){this.g=a}
function eb(a){this.g=a}
function rb(a){this.g=a}
function Fb(a){this.g=a}
function Gb(a){this.g=a}
function Hb(a){this.g=a}
function Ib(a){this.g=a}
function qc(a){this.g=a}
function gi(a){this.g=a}
function Mi(a){this.g=a}
function Ui(a){this.g=a}
function Vi(a){this.g=a}
function Vk(a){this.g=a}
function uk(a){this.g=a}
function Im(a){this.g=a}
function Jm(a){this.g=a}
function Qm(a){this.g=a}
function Rm(a){this.g=a}
function Sm(a){this.g=a}
function Um(a){this.g=a}
function Bn(a){this.g=a}
function Cn(a){this.g=a}
function Fn(a){this.g=a}
function Gn(a){this.g=a}
function Hn(a){this.g=a}
function Jn(a){this.g=a}
function So(a){this.g=a}
function To(a){this.g=a}
function Uo(a){this.g=a}
function Vo(a){this.g=a}
function Xo(a){this.g=a}
function Yo(a){this.g=a}
function ap(a){this.g=a}
function fp(a){this.g=a}
function ip(a){this.g=a}
function np(a){this.g=a}
function op(a){this.g=a}
function sp(a){this.g=a}
function up(a){this.g=a}
function wp(a){this.g=a}
function yp(a){this.g=a}
function zp(a){this.g=a}
function Ap(a){this.g=a}
function Bp(a){this.g=a}
function Cp(a){this.g=a}
function Dp(a){this.g=a}
function Ep(a){this.g=a}
function dq(a){this.g=a}
function fq(a){this.g=a}
function gq(a){this.g=a}
function hq(a){this.g=a}
function iq(a){this.g=a}
function kq(a){this.g=a}
function lq(a){this.g=a}
function nq(a){this.g=a}
function oq(a){this.g=a}
function pq(a){this.g=a}
function qq(a){this.g=a}
function rq(a){this.g=a}
function sq(a){this.g=a}
function vq(a){this.g=a}
function Dq(a){this.g=a}
function Eq(a){this.g=a}
function Fq(a){this.g=a}
function Gq(a){this.g=a}
function Yq(a){this.g=a}
function Zq(a){this.g=a}
function $q(a){this.g=a}
function _q(a){this.g=a}
function ar(a){this.g=a}
function br(a){this.g=a}
function cr(a){this.g=a}
function er(a){this.g=a}
function pr(a){this.g=a}
function qr(a){this.g=a}
function sr(a){this.g=a}
function tr(a){this.g=a}
function zr(a){this.g=a}
function Rr(a){this.g=a}
function Sr(a){this.g=a}
function Tr(a){this.g=a}
function Vr(a){this.g=a}
function Xr(a){this.g=a}
function Yr(a){this.g=a}
function Zr(a){this.g=a}
function $r(a){this.g=a}
function _r(a){this.g=a}
function fs(a){this.g=a}
function hs(a){this.g=a}
function ls(a){this.g=a}
function Si(a){this.j=a}
function hj(a){this.i=a}
function lt(){Ji(this.g)}
function st(){kc(this.h)}
function wj(){this.g=Fj()}
function Kj(){this.g=Fj()}
function Rk(a,b){a.g=b}
function yb(a,b){a.h=b}
function pl(a,b){a.key=b}
function ll(a,b){kl(a,b)}
function pt(a){ki(this,a)}
function jt(a){Oj(this,a)}
function rt(a){hk(this,a)}
function xt(){bb(this.g.g)}
function Uk(a,b){Jk(a.g,b)}
function K(a,b){Vb(a.m,b.m)}
function S(a,b){W(a);T(a,b)}
function H(a){--a.l;L(a)}
function lc(a){!!a&&a.Q()}
function lb(a){dc((R(),a))}
function mb(a){ec((R(),a))}
function pb(a){fc((R(),a))}
function wt(a){Ln(this.g,a)}
function ht(){return this.g}
function nt(){return this.h}
function qt(){return this.l}
function mh(a){return a.l}
function xq(a){a.j=2;kc(a.h)}
function Qq(a){a.l=2;kc(a.i)}
function hr(a){a.m=2;kc(a.j)}
function Uq(a){sb(a.h);Z(a.g)}
function ei(){wc.call(this)}
function yi(){wc.call(this)}
function it(){return cl(this)}
function Hq(a,b){return a.v=b}
function tc(a,b){a.l=b;sc(a,b)}
function jc(a,b,c){Hi(a.l,b,c)}
function Qh(a){xc.call(this,a)}
function zi(a){xc.call(this,a)}
function wi(a){Ph.call(this,a)}
function vi(){Ph.call(this,'')}
function qj(){this.g=new nj}
function R(){R=wh;Q=new M}
function zc(){zc=wh;yc=new w}
function Qc(){Qc=wh;Pc=new Tc}
function zk(){zk=wh;yk=new Tk}
function Bj(){Bj=wh;Aj=Dj()}
function fb(a){md(a,11)&&a.S()}
function vt(a){md(a,11)&&a.S()}
function ro(a){fb(a.B);fb(a.I)}
function lr(a){sb(a.g);hb(a.h)}
function Uh(a){Th(a);return a.v}
function Fk(a){vk(a);return a.g}
function _i(a,b){return a.g[b]}
function _c(a,b){return $h(a,b)}
function _k(a,b){return fd(a,b)}
function mt(){return Ki(this.g)}
function tt(){return this.h.s<0}
function wc(){rc(this);this.Z()}
function Gc(){Gc=wh;!!(Xc(),Wc)}
function ph(){nh==null&&(nh=[])}
function mk(a,b,c){b.U(a.g[c])}
function mn(a,b,c){jc(a.I,b,c)}
function Fm(a,b,c){jc(a.h,b,c)}
function $k(a,b,c){a.splice(b,c)}
function G(a,b,c){D(a,new P(c),b)}
function no(a,b){return v(b.g,a)}
function Ki(a){return a.g.h+a.h.h}
function Tj(a){return Uj(a,a.i.h)}
function ib(a){R();ec(a);a.l=-2}
function Zb(a){$b(a);!a.j&&bc(a)}
function hk(a,b){while(a.Qb(b));}
function Ok(a,b,c){b.U(a.g.rb(c))}
function Ik(a,b){a.sb(b);return a}
function zl(a,b){a.id=b;return a}
function Eh(a,b){a.min=b;return a}
function Dh(a,b){a.max=b;return a}
function Nh(a,b){a.sdp=b;return a}
function Jl(a,b){a.src=b;return a}
function Al(a,b){a.key=b;return a}
function Bl(a,b){a.ref=b;return a}
function nn(a){nb(a.o);return a.F}
function on(a){nb(a.i);return a.B}
function uo(a){nb(a.i);return a.F}
function vo(a){nb(a.j);return a.G}
function Lo(a){nb(a.l);return a.s}
function Po(a){nb(a.o);return a.v}
function Mo(a){ob(a.m);return a.u}
function Fj(){Bj();return new Aj}
function Hj(a,b){return a.g.get(b)}
function Pj(a,b){Rj(a,b,a.g,a.g.g)}
function Qj(a,b){Rj(a,b,a.i.h,a.i)}
function Qk(a,b){this.g=a;this.h=b}
function Nk(a,b){this.g=a;this.h=b}
function di(a,b){this.g=a;this.h=b}
function Wi(a,b){this.g=a;this.h=b}
function xl(a,b){this.g=a;this.h=b}
function Am(a,b){this.g=a;this.h=b}
function Km(a,b){this.g=a;this.h=b}
function Dn(a,b){this.g=a;this.h=b}
function En(a,b){this.g=a;this.h=b}
function In(a,b){this.g=a;this.h=b}
function Kn(a,b){this.g=a;this.h=b}
function Wo(a,b){this.g=a;this.h=b}
function Zo(a,b){this.g=a;this.h=b}
function $o(a,b){this.g=a;this.h=b}
function _o(a,b){this.g=a;this.h=b}
function bp(a,b){this.g=a;this.h=b}
function cp(a,b){this.g=a;this.h=b}
function dp(a,b){this.g=a;this.h=b}
function ep(a,b){this.g=a;this.h=b}
function gp(a,b){this.g=a;this.h=b}
function hp(a,b){this.g=a;this.h=b}
function lp(a,b){this.g=a;this.h=b}
function mp(a,b){this.g=a;this.h=b}
function Lb(a){this.j=a;this.h=100}
function Lp(a,b){di.call(this,a,b)}
function Rp(a,b){di.call(this,a,b)}
function Yl(a,b){di.call(this,a,b)}
function vm(a,b){di.call(this,a,b)}
function bq(a,b){di.call(this,a,b)}
function eq(a,b){this.g=a;this.h=b}
function tq(a,b){this.g=a;this.h=b}
function uq(a,b){this.g=a;this.h=b}
function rr(a,b){this.g=a;this.h=b}
function Ur(a,b){this.g=a;this.h=b}
function as(a,b){this.g=a;this.h=b}
function Oh(a,b){a.type=b;return a}
function Dl(a,b){a.href=b;return a}
function Yk(a,b,c){a.splice(b,0,c)}
function oo(a,b){return v(b.g,a.g)}
function ot(a){return Fi(this.g,a)}
function bs(a){return cs(new es,a)}
function is(a){return js(new ks,a)}
function ms(a){return os(new ps,a)}
function ri(a){return !a?As:''+a.g}
function ab(a){ub(a.m);return cb(a)}
function Ch(a,b){a.ideal=b;return a}
function Gh(a,b){a.video=b;return a}
function Ih(a,b){a.width=b;return a}
function Sl(a,b){a.value=b;return a}
function ti(a,b){a.g+=''+b;return a}
function wq(){this.g=tl((Cr(),Br))}
function es(){this.g=tl((Gr(),Fr))}
function ks(){this.g=tl((Kr(),Jr))}
function ps(){this.g=tl((Or(),Nr))}
function pn(a){sn(a,(nb(a.i),!a.B))}
function _b(a){return !a.j?a:_b(a.j)}
function Ei(a){return !a?null:a.Mb()}
function sd(a){return a==null?null:a}
function _j(a){return a!=null?C(a):0}
function v(a,b){return sd(a)===sd(b)}
function yo(a,b){ho(a,b,new tq(a,b))}
function zo(a,b){ho(a,b,new uq(a,b))}
function Hh(a,b){a.height=b;return a}
function Fh(a){a.audio=true;return a}
function Kl(a){a.width='32';return a}
function Fl(a,b){a.onClick=b;return a}
function Il(a){a.height='32';return a}
function Tl(a,b){a.htmlFor=b;return a}
function Nc(a){$wnd.clearTimeout(a)}
function Xi(a){a.g=bd(je,ts,1,0,5,1)}
function Ji(a){a.g=new wj;a.h=new Kj}
function qb(a){this.i=new fj;this.h=a}
function gl(){gl=wh;dl=new w;fl=new w}
function Oc(){Dc!=0&&(Dc=0);Fc=-1}
function rk(){sk.call(this,'|','','')}
function Jk(a,b){zk();Rk(a,Ik(a.g,b))}
function xb(a){R();wb(a);Ab(a,2,true)}
function nb(a){var b;ac((R(),b=Xb,b),a)}
function I(a,b,c){F(a,new O(b),c,null)}
function J(a,b,c){return F(a,c,2048,b)}
function li(a,b){return a.charCodeAt(b)}
function pj(a,b){return Ii(a.g,b)!=null}
function cl(a){return a.$H||(a.$H=++bl)}
function Ql(a){return a.required=true,a}
function Nl(a,b){a.onChange=b;return a}
function Hl(a,b){a.onSubmit=b;return a}
function El(a,b){a.disabled=b;return a}
function Kh(a,b){a.candidate=b;return a}
function Ml(a,b){a.maxLength=b;return a}
function Jh(a,b){a.iceServers=b;return a}
function ol(a,b,c){a.props[b]=c;return a}
function cs(a,b){ol(a.g,'a',b);return a}
function Th(a){if(a.v!=null){return}ai(a)}
function al(a){if(!a){throw mh(new ei)}}
function kl(a,b){for(var c in a){b(c)}}
function md(a,b){return a!=null&&kd(a,b)}
function oi(a,b,c){return a.substr(b,c-b)}
function Ll(a){return a.autoFocus=true,a}
function od(a){return typeof a==='number'}
function rd(a){return typeof a==='string'}
function nd(a){return typeof a==='boolean'}
function gb(a){return !(md(a,11)&&a.T())}
function Ob(a){2==(3&a.g)||(a.g=-4&a.g|2)}
function Ri(a){a.j.Ib(a.i);a.h=a.i;a.i=-1}
function Pi(a){a.i.Eb();a.i=null;a.h=Ni(a)}
function xc(a){this.o=a;rc(this);this.Z()}
function nj(){this.g=new wj;this.h=new Kj}
function X(){this.g=bd(je,ts,1,100,5,1)}
function Zk(a,b,c){Xk(c,0,a,b,c.length)}
function ns(a,b){ol(a.g,'b',b);return a.g}
function Pl(a,b){a.placeholder=b;return a}
function Ol(a){a.pattern='^\\w+$';return a}
function Om(a){I((R(),R(),Q),new Um(a),Ms)}
function xn(a){I((R(),R(),Q),new Gn(a),Ms)}
function yn(a){I((R(),R(),Q),new Fn(a),Ms)}
function zn(a){I((R(),R(),Q),new Hn(a),Ms)}
function Io(a){I((R(),R(),Q),new Yo(a),Ms)}
function Qo(a){I((R(),R(),Q),new Xo(a),Ms)}
function Ao(a){I((R(),R(),Q),new ap(a),Ws)}
function Ko(a){I((R(),R(),Q),new fp(a),Ws)}
function Wq(a){I((R(),R(),Q),new cr(a),Ms)}
function oc(a){R();Xb?a.Q():I((null,Q),a,0)}
function yj(a,b){var c;c=a[Fs];c.call(a,b)}
function ml(a,b){var c;c={};c[a]=b;return c}
function Lh(a,b){a.sdpMLineIndex=b;return a}
function rc(a){a.u&&a.l!==ys&&a.Z();return a}
function Xh(a){var b;b=Wh(a);ci(a,b);return b}
function bb(a){4==(a.m.i&7)&&Ab(a.m,5,true)}
function Ub(a,b,c){c.g=-4&c.g|1;S(a.g[b],c)}
function Hc(a,b,c){return a.apply(b,c);var d}
function qd(a,b){return a&&b&&a instanceof b}
function mo(a,b){return sd(b.track)===sd(a)}
function Pq(a,b){b.preventDefault();Ko(a.u)}
function Oj(a,b){while(a.Cb()){Uk(b,a.Db())}}
function kk(a,b){while(a.i<a.j){mk(a,b,a.i++)}}
function Kb(a){while(true){if(!Jb(a)){break}}}
function gj(a){Xi(this);Zk(this.g,0,a.zb())}
function Nj(a,b,c){this.g=a;this.h=b;this.i=c}
function Yj(a,b,c){this.j=a;this.h=c;this.g=b}
function Hk(a,b){zk();xk.call(this,a);this.g=b}
function Yi(a,b){a.g[a.g.length]=b;return true}
function Vb(a,b){Ub(a,((b.g&229376)>>15)-1,b)}
function Gm(a,b){I((R(),R(),Q),new Km(a,b),Ms)}
function Go(a,b){I((R(),R(),Q),new _o(a,b),Ms)}
function Co(a,b){I((R(),R(),Q),new Zo(a,b),Ws)}
function Ho(a,b){I((R(),R(),Q),new $o(a,b),Ws)}
function to(a,b){I((R(),R(),Q),new gp(a,b),Ws)}
function Bo(a,b){I((R(),R(),Q),new dp(a,b),Ws)}
function Do(a,b){I((R(),R(),Q),new bp(a,b),Ws)}
function Eo(a,b){I((R(),R(),Q),new ep(a,b),Ws)}
function Fo(a,b){I((R(),R(),Q),new cp(a,b),Ws)}
function Jo(a,b){I((R(),R(),Q),new hp(a,b),Ws)}
function sn(a,b){I((R(),R(),Q),new En(a,b),Ms)}
function Vm(a){vn(a,null);un(a,null);tn(a,null)}
function Lq(a,b,c){c.preventDefault();to(a.u,b)}
function Iq(a,b,c){c.preventDefault();Jo(a.u,b)}
function Fi(a,b){return rd(b)?Gi(a,b):!!tj(a.g,b)}
function Gj(a,b){return !(a.g.get(b)===undefined)}
function Ak(a,b){var c;return Ek(a,(c=new fj,c))}
function Xc(){Xc=wh;var a;!Zc();a=new $c;Wc=a}
function ji(){ji=wh;ii=bd(ge,ts,37,256,0,1)}
function Mb(a){if(!a.g){a.g=true;H((R(),R(),Q))}}
function Lk(a,b,c){if(a.g.Sb(c)){a.h=true;b.U(c)}}
function vb(a,b){kb(b,a);b.i.g.length>0||(b.g=4)}
function gr(a,b){oc(new rr(a,b.length==0?null:b))}
function ij(a,b){return ik(b,a.length),new nk(a,b)}
function jj(a){return new Hk(null,ij(a,a.length))}
function Bq(a){return J((R(),R(),Q),a.g,new Fq(a))}
function dd(a){return Array.isArray(a)&&a.$b===Ah}
function ld(a){return !Array.isArray(a)&&a.$b===Ah}
function Vq(a){return J((R(),R(),Q),a.h,new br(a))}
function nr(a){return J((R(),R(),Q),a.g,new sr(a))}
function V(a){return a.i?a.g.length-a.h+a.j:a.j-a.h}
function ok(a){if(!a.j){a.j=a.h.qb();a.i=a.h.wb()}}
function zq(a){if(0==a.j){a.j=1;a.i.forceUpdate()}}
function Sq(a){if(0==a.l){a.l=1;a.j.forceUpdate()}}
function jr(a){if(0==a.m){a.m=1;a.l.forceUpdate()}}
function jl(){if(el==256){dl=fl;fl=new w;el=0}++el}
function Wj(){this.g=new Zj;this.i=new Zj;Vj(this)}
function jk(a,b){this.l=a;this.j=(b&64)!=0?b|16384:b}
function Wk(a,b){var c;c=a.slice(0,b);return fd(c,a)}
function oj(a,b){var c;c=Hi(a.g,b,a);return c==null}
function bj(a,b){var c;c=a.g[b];$k(a.g,b,1);return c}
function ej(a,b,c){var d;d=a.g[b];a.g[b]=c;return d}
function Zh(a){var b;b=Wh(a);b.u=a;b.l=1;return b}
function Uc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Xj(a){a.i=a.h;a.h=a.h.g;++a.g;return a.i.i}
function On(a,b,c){a.D.addTrack(c,b);return null}
function un(a,b){var c;c=a.D;if(b!=c){a.D=b;mb(a.l)}}
function ln(a,b){var c;c=a.B;if(b!=c){a.B=b;mb(a.i)}}
function qn(a,b){var c;c=a.v;if(b!=c){a.v=b;mb(a.g)}}
function rn(a,b){var c;c=a.A;if(b!=c){a.A=b;mb(a.h)}}
function tn(a,b){var c;c=a.C;if(b!=c){a.C=b;mb(a.j)}}
function wn(a,b){var c;c=a.H;if(b!=c){a.H=b;mb(a.u)}}
function so(a,b){var c;c=a.s;if(b!=c){a.s=b;mb(a.l)}}
function mr(a,b){var c;c=a.i;if(b!=c){a.i=b;mb(a.h)}}
function nl(a,b,c,d){var e;e={};e[a]=b;e[c]=d;return e}
function Gl(a,b){a.type=b.g!=null?b.g:''+b.h;return a}
function si(a,b){a.g+=String.fromCharCode(b);return a}
function xo(a,b){sd(a.J)===sd(b.currentTarget)&&bb(a.g)}
function mj(a,b){return sd(a)===sd(b)||a!=null&&A(a,b)}
function Ii(a,b){return b==null?vj(a.g,null):Jj(a.h,b)}
function Gi(a,b){return b==null?!!tj(a.g,null):Gj(a.h,b)}
function Bk(a,b){wk(a);return new Hk(a,new Mk(b,a.g))}
function Ck(a,b){wk(a);return new Hk(a,new Pk(b,a.g))}
function vk(a){if(!a.h){wk(a);a.i=true}else{vk(a.h)}}
function xk(a){if(!a){this.h=null;new fj}else{this.h=a}}
function nk(a,b){this.i=0;this.j=b;this.h=17488;this.g=a}
function Ti(a,b){this.g=a;Si.call(this,a);a.wb();this.h=b}
function gc(a,b){this.g=(R(),R(),Q).h++;this.j=a;this.l=b}
function pk(a,b){this.h=a;this.g=(b&4096)==0?b|64|16384:b}
function Yh(a,b){var c;c=Wh(a);ci(a,c);c.l=b?8:0;return c}
function Oi(a){var b;a.i=a.g;b=a.g.Db();a.h=Ni(a);return b}
function Vj(a){a.g.g=a.i;a.i.h=a.g;a.g.h=a.i.g=null;a.h=0}
function tb(a){K((R(),R(),Q),a);0==(a.m.g&xs)&&L((null,Q))}
function ob(a){var b;R();!!Xb&&!!Xb.l&&ac((b=Xb,b),a)}
function uc(a,b){var c;c=Uh(a.Yb);return b==null?c:c+': '+b}
function Di(a,b){return b===a?'(this Map)':b==null?As:zh(b)}
function Zl(){Xl();return ed(_c(kf,1),ts,39,0,[Ul,Vl,Wl])}
function Sp(){Qp();return ed(_c(kg,1),ts,40,0,[Pp,Op,Np])}
function Mc(a){Gc();$wnd.setTimeout(function(){throw a},0)}
function Zm(a){!(!!a&&a.I.s<0)&&I((R(),R(),Q),new Jn(a),Ms)}
function Yb(a){if(a.l){2==(a.l.i&7)||Ab(a.l,4,true);wb(a.l)}}
function Li(a,b){if(md(b,43)){return Ci(a.g,b)}return false}
function _h(a){if(a.ob()){return null}var b=a.u;return sh[b]}
function yh(a){function b(){}
;b.prototype=a||{};return new b}
function hc(a,b){Xb=new gc(Xb,b);a.j=false;Yb(Xb);return Xb}
function Mh(a){a.urls='stun:stun.l.google.com:19302';return a}
function jo(a,b){null!=a.J&&a.J.send($wnd.JSON.stringify(b))}
function $h(a,b){var c=a.g=a.g||[];return c[b]||(c[b]=a.jb(b))}
function sj(a,b){var c;c=a.g.get(b);return c==null?new Array:c}
function ur(a,b){var c;c=a.i;!(!!c&&c.I.s<0)&&oc(new Dn(c,b))}
function ki(a,b){var c,d;for(d=a.qb();d.Cb();){c=d.Db();b.U(c)}}
function Jq(a,b){var c;oc(new Wo(a.u,pi((c=b.target,c).value)))}
function tj(a,b){var c;return rj(b,sj(a,b==null?0:(c=C(b),c|0)))}
function uh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ut(a,b,c){return Rh(),(a.enabled=!a.enabled)?true:false}
function Mp(){Kp();return ed(_c(jg,1),ts,23,0,[Hp,Jp,Gp,Fp,Ip])}
function Kr(){Kr=wh;var a;Jr=(a=xh(Ir.prototype.Xb,Ir,[]),a)}
function Cr(){Cr=wh;var a;Br=(a=xh(Ar.prototype.Xb,Ar,[]),a)}
function Gr(){Gr=wh;var a;Fr=(a=xh(Er.prototype.Xb,Er,[]),a)}
function Or(){Or=wh;var a;Nr=(a=xh(Mr.prototype.Xb,Mr,[]),a)}
function Ym(a,b){b.onended=xh(op.prototype.eb,op,[a]);return null}
function vc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function wk(a){if(a.h){wk(a.h)}else if(a.i){throw mh(new fi)}}
function lk(a,b){if(a.i<a.j){mk(a,b,a.i++);return true}return false}
function nc(a){lc(a.o);!!a.l&&mc(a);fb(a.g);fb(a.i);lc(a.h);lc(a.m)}
function No(a,b){var c;c=a.u;if(!(b==c||!!b&&b==c)){a.u=b;mb(a.m)}}
function Oo(a,b){var c;c=a.v;if(!(b==c||!!b&&b==c)){a.v=b;mb(a.o)}}
function Tn(a,b){var c;return c=(nb(b.o),b.F),null!=c&&v(c.id,a.id)}
function Kc(a,b,c){var d;d=Ic();try{return Hc(a,b,c)}finally{Lc(d)}}
function Xm(a,b,c){a.L==b&&I((R(),R(),Q),new Kn(a,c),Ms);return null}
function vl(a,b,c){!v(c,'key')&&!v(c,'ref')&&(a[c]=b[c],undefined)}
function Pk(a,b){jk.call(this,b.Pb(),b.Ob()&-6);this.g=a;this.h=b}
function xj(a){this.l=a;this.h=this.l.g.entries();this.g=new Array}
function M(){this.m=new Wb;this.g=new Lb(this.m);new N(this.g)}
function Dr(a){$wnd.React.Component.call(this,a);this.g=new Cq(this)}
function Hr(a){$wnd.React.Component.call(this,a);this.g=new Xq(this)}
function Lr(a){$wnd.React.Component.call(this,a);this.g=new or(this)}
function Pr(a){$wnd.React.Component.call(this,a);this.g=new yr(this)}
function Mk(a,b){jk.call(this,b.Pb(),b.Ob()&-16449);this.g=a;this.i=b}
function jb(a,b){var c,d;Yi(a.i,b);d=(c=b.i&7,c>3?c:4);a.g>d&&(a.g=d)}
function Dk(a,b){return !(wk(a),Fk(new Hk(a,new Mk(b,a.g)))).Qb(yk)}
function td(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function qo(a){Z(a.g);Z(a.h);hb(a.o);hb(a.m);hb(a.l);hb(a.j);hb(a.i)}
function qk(a,b){!a.g?(a.g=new wi(a.j)):ti(a.g,a.h);ti(a.g,b);return a}
function Mn(a){var b;b=new fj;on(a.I)&&Yi(b,a.I);Zi(b,a.H);return b}
function Rj(a,b,c,d){var e;e=new Zj;e.i=b;e.h=c;e.g=d;d.h=c.g=e;++a.h}
function sk(a,b,c){this.h=a;this.j=b;this.l=c;this.i=this.j+(''+this.l)}
function Lj(a){this.j=a;this.h=this.j.g.entries();this.g=this.h.next()}
function T(a,b){a.g[a.j]=b;++a.j;if(a.j>=a.g.length){a.j=0;a.i=true}}
function Ek(a,b){var c;vk(a);c=new Sk;c.g=b;a.g.Bb(new Vk(c));return c.g}
function Gk(a,b){var c;c=Ak(a,new uk(new tk));return c.Ab(b.Rb(c.wb()))}
function Un(a,b){var c;return c=(nb(b.o),b.F),!(null!=c&&!v(c.id,a.id))}
function Qn(a,b){return a.D.setLocalDescription(Oh(Nh({},b.sdp),b.type))}
function Vn(a,b){return a.D.setLocalDescription(Nh(Oh({},b.type),b.sdp))}
function Rn(a){jo(a,nl(Ps,'offer',Rs,a.D.localDescription));return null}
function Wn(a){jo(a,nl(Ps,'answer',Rs,a.D.localDescription));return null}
function Tb(a){var b,c;b=0;for(c=0;c<a.g.length;c++){b+=V(a.g[c])}return b}
function bd(a,b,c,d,e,f){var g;g=cd(e,d);e!=10&&ed(_c(a,f),b,c,e,g);return g}
function ho(a,b,c){if(null!=a.J&&cj(a.G,b)){dj(a.G,new vq(b));mb(a.j);c.Q()}}
function hb(a){if(-2!=a.l){I((R(),R(),Q),new rb(a),0);!!a.h&&sb(a.h)}}
function Qb(b){try{ub(b.h.g)}catch(a){a=lh(a);if(!md(a,8))throw mh(a)}}
function Lc(a){a&&Sc((Qc(),Pc));--Dc;if(a){if(Fc!=-1){Nc(Fc);Fc=-1}}}
function Jc(b){Gc();return function(){return Kc(b,this,arguments);var a}}
function Cc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Mj(a){if(a.g.i!=a.i){return Hj(a.g,a.h.value[0])}return a.h.value[1]}
function aj(a,b,c){for(;c<a.g.length;++c){if(mj(b,a.g[c])){return c}}return -1}
function gn(a){if(v('live',a.readyState)){a.onended=null;a.stop()}return null}
function fd(a,b){ad(b)!=10&&ed(B(b),b.Zb,b.__elementTypeId$,ad(b),a);return a}
function js(a,b){pl(a.g,hi(b.h.j)+(''+(Th(hh),hh.v)));ol(a.g,'a',b);return a.g}
function Hi(a,b,c){return rd(b)?b==null?uj(a.g,null,c):Ij(a.h,b,c):uj(a.g,b,c)}
function cq(){aq();return ed(_c(lg,1),ts,17,0,[_p,Up,Zp,Yp,Xp,Tp,$p,Wp,Vp])}
function Wb(){var a;this.g=bd(zd,ts,57,5,0,1);for(a=0;a<5;a++){this.g[a]=new X}}
function $i(a,b){var c,d,e,f;for(d=a.g,e=0,f=d.length;e<f;++e){c=d[e];b.U(c)}}
function Ln(a,b){null!=a.D&&b.getTracks().forEach(xh(eq.prototype._,eq,[a,b]))}
function Lm(a){$wnd.goog.global.globalThis.addEventListener(Ns,a.i,false)}
function Mm(a){$wnd.goog.global.globalThis.removeEventListener(Ns,a.i,false)}
function Nq(a){$wnd.goog.global.globalThis.document.removeEventListener(Ys,a.s)}
function Mq(a){$wnd.goog.global.globalThis.document.addEventListener(Ys,a.s)}
function Qi(a){this.l=a;this.j=new Lj(this.l.h);this.g=this.j;this.h=Ni(this)}
function Xl(){Xl=wh;Ul=new Yl(Ks,0);Vl=new Yl('reset',1);Wl=new Yl('submit',2)}
function kc(a){if(a.s>=0){a.s=-2;F((R(),R(),Q),new O(new qc(a)),67108864,null)}}
function Z(a){if(!a.g){a.g=true;a.v=null;a.h=null;hb(a.l);2==(a.m.i&7)||sb(a.m)}}
function L(a){if(a.j&&a.l==0){if(!a.i){a.i=true;try{Kb(a.g)}finally{a.i=false}}}}
function cb(a){if(a.h){if(md(a.h,10)){throw mh(a.h)}else{throw mh(a.h)}}return a.v}
function zb(b){if(b){try{b.Q()}catch(a){a=lh(a);if(md(a,8)){R()}else throw mh(a)}}}
function ic(){var a;try{Zb(Xb);R()}finally{a=Xb.j;!a&&((R(),R(),Q).j=true);Xb=Xb.j}}
function Rc(a){var b,c;if(a.g){c=null;do{b=a.g;a.g=null;c=Vc(b,c)}while(a.g);a.g=c}}
function Sc(a){var b,c;if(a.h){c=null;do{b=a.h;a.h=null;c=Vc(b,c)}while(a.h);a.h=c}}
function kn(a,b){var c;c=a.G;if(!(sd(b)===sd(c)||b!=null&&A(b,c))){a.G=b;mb(a.s)}}
function vn(a,b){var c;c=a.F;if(!(sd(b)===sd(c)||b!=null&&A(b,c))){a.F=b;mb(a.o)}}
function wr(a,b){var c;c=a.h.props;if(!(c['b']===b['b'])){return true}return false}
function cj(a,b){var c;c=aj(a,b,0);if(c==-1){return false}$k(a.g,c,1);return true}
function ac(a,b){var c;if(a.l){c=a.g;if(b.l!=c){b.l=c;!a.h&&(a.h=new fj);Yi(a.h,b)}}}
function cc(a,b){var c;if(!a.i){c=_b(a);!c.i&&(c.i=new fj);a.i=c.i}b.j=true;a.i.sb(b)}
function ci(a,b){var c;if(!a){return}b.u=a;var d=_h(b);if(!d){sh[a]=[b];return}d.Yb=b}
function Uj(a,b){var c;c=b.i;b.g.h=b.h;b.h.g=b.g;b.g=b.h=null;b.i=null;--a.h;return c}
function Wh(a){var b;b=new Vh;b.v='Class$'+(a?'S'+a:''+b.o);b.h=b.v;b.s=b.v;return b}
function os(a,b){pl(a.g,(b?hi(b.I.j):null)+(''+(Th(jh),jh.v)));ol(a.g,'a',b);return a}
function xh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Cl(a){a.title='Room code should only contain letters or numbers.';return a}
function fi(){xc.call(this,"Stream already terminated, can't be modified or used")}
function oh(){ph();var a=nh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function io(a){if(null!=a.J){jo(a,nl(Ps,Us,'message',(nb(a.l),a.s)));Oo(a,(aq(),Zp))}}
function ao(a,b){if(sd(a.J)===sd(b.currentTarget)){bb(a.g);Oo(a,(aq(),Vp));a.J=null}}
function jn(a){sb(a.m);hb(a.h);hb(a.o);hb(a.l);hb(a.j);hb(a.i);hb(a.g);hb(a.u);hb(a.s)}
function eo(a,b){var c;c=b.track;a.H=Ak(Bk(a.H.yb(),new oq(c)),new uk(new tk));bb(a.h)}
function Xn(a,b){var c;c=b.g;jo(a,nl(Ps,'approve_access','id',c));oj(a.F,c);mb(a.i);ko(a)}
function Jj(a,b){var c;c=a.g.get(b);if(c===undefined){++a.i}else{yj(a.g,b);--a.h}return c}
function rl(a,b,c,d){var e;e=sl($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function tl(a){var b;b=sl($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function ad(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function pd(a){return a!=null&&(typeof a===rs||typeof a==='function')&&!(a.$b===Ah)}
function rh(a,b){typeof window===rs&&typeof window['$gwt']===rs&&(window['$gwt'][a]=b)}
function Zn(a,b){null!=b&&null!=a.D&&b.getTracks().forEach(xh(eq.prototype._,eq,[a,b]))}
function bn(a,b){rn(a,false);vn(a,b);b.getTracks().forEach(xh(np.prototype._,np,[a]));a.K.U(b)}
function wb(a){var b,c;for(c=new hj(a.h);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);b.g=4}}
function Bi(a,b){var c,d;for(d=b.qb();d.Cb();){c=d.Db();if(!a.ub(c)){return false}}return true}
function kj(a){var b,c,d;d=0;for(c=a.qb();c.Cb();){b=c.Db();d=d+(b!=null?C(b):0);d=d|0}return d}
function lj(a){var b,c,d;d=1;for(c=a.qb();c.Cb();){b=c.Db();d=31*d+(b!=null?C(b):0);d=d|0}return d}
function lh(a){var b;if(md(a,8)){return a}b=a&&a.__java$exception;if(!b){b=new Bc(a);Yc(b)}return b}
function Ni(a){if(a.g.Cb()){return true}if(a.g!=a.j){return false}a.g=new xj(a.l.g);return a.g.Cb()}
function Zi(a,b){var c,d;c=b.zb();d=c.length;if(d==0){return false}Zk(a.g,a.g.length,c);return true}
function Ij(a,b,c){var d;d=a.g.get(b);a.g.set(b,c===undefined?null:c);d===undefined?++a.h:++a.i;return d}
function ed(a,b,c,d,e){e.Yb=a;e.Zb=b;e.$b=Ah;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function rj(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(mj(a,c.Lb())){return c}}return null}
function pc(a,b,c,d){this.j=a;this.l=d?new nj:null;this.o=b;this.h=c;this.m=null;this.g=null;this.i=null}
function Vh(){this.o=Sh++;this.v=null;this.s=null;this.m=null;this.j=null;this.h=null;this.u=null;this.g=null}
function Bc(a){zc();rc(this);this.l=a;sc(this,a);this.o=a==null?As:zh(a);this.g='';this.h=a;this.g=''}
function Rb(a,b){this.h=a;this.g=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function Db(a,b,c){Cb.call(this,null,a,b,c|(!a?262144:vs)|(0==(c&6291456)?!a?xs:4194304:0)|0|0|0)}
function vr(a){return rl('video',null,a.j,nl('autoPlay',true,'className',a.h.props['b']))}
function Qp(){Qp=wh;Pp=new Rp('UNKNOWN',0);Op=new Rp('HOST',1);Np=new Rp('GUEST',2)}
function ik(a,b){if(0>a||a>b){throw mh(new Qh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function ym(){if(!xm){xm=(++(R(),R(),Q).l,new Nb);$wnd.Promise.resolve(null).then(xh(zm.prototype.bb,zm,[]))}}
function Wm(a,b,c){a.L==b?I((R(),R(),Q),new In(a,c),Ms):c.getTracks().forEach(xh(qp.prototype._,qp,[]));return null}
function sb(a){if(2<(a.i&7)){F((R(),R(),Q),new O(new Hb(a)),67108864,null);!!a.g&&Z(a.g);Ob(a.m);a.i=a.i&-8|1}}
function Pb(a){if(1==(3&a.g)){a.g=-4&a.g|0;0==(a.g&vs)?Qb(a):ub(a.h.g);0!=(a.g&524288)&&(2==(3&a.g)||(a.g=-4&a.g|2))}}
function kb(a,b){var c,d;d=a.i;cj(d,b);!!a.h&&vs!=(a.h.i&ws)&&a.i.g.length<=0&&0==a.h.g.j&&(a.j||cc((R(),c=Xb,c),a))}
function yq(a){var b,c,d;a.j=0;ym();c=(d=(b=$(a.l.j.g),b.length==0?null:b),null==d?is(a.l):ds(bs(a.l),d));return c}
function ql(a){var b;b=sl($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=ml(Js,a);return b}
function Kq(a){var b;b=$wnd.goog.global.globalThis.document;b.fullscreen?b.exitFullscreen():a.v.requestFullscreen()}
function Bh(){var a;a=$wnd.goog.global.globalThis.document.getElementById('app');$wnd.ReactDOM.render((new wq).g,a,null)}
function Pn(a,b){var c;c=a.D.getSenders().find(xh(gq.prototype.ab,gq,[b]));null!=c&&a.D.removeTrack(c);return null}
function hi(a){var b,c;if(a>-129&&a<128){b=a+128;c=(ji(),ii)[b];!c&&(c=ii[b]=new gi(a));return c}return new gi(a)}
function zh(a){var b;if(Array.isArray(a)&&a.$b===Ah){return Uh(B(a))+'@'+(b=C(a)>>>0,b.toString(16))}return a.toString()}
function il(a){gl();var b,c,d;c=':'+a;d=fl[c];if(d!=null){return td(d)}d=dl[c];b=d==null?hl(a):td(d);jl();fl[c]=b;return b}
function $m(a){var b,c,d;c=(nb(a.o),a.F);d=(nb(a.s),a.G);if(null!=c&&null!=d){b=c;sd(b)!==sd(d.srcObject)&&(d.srcObject=b)}}
function en(a){var b;qn(a,(nb(a.g),!a.v));b=(nb(a.o),a.F);null!=b&&b.getAudioTracks().forEach(xh(jp.prototype._,jp,[]))}
function fn(a){var b;wn(a,(nb(a.u),!a.H));b=(nb(a.o),a.F);null!=b&&b.getVideoTracks().forEach(xh(kp.prototype._,kp,[]))}
function bc(a){var b;if(a.i){while(!a.i.vb()){b=a.i.Ib(a.i.wb()-1);b.j=false;b.i.g.length>0||(b.h.i&7)>3&&Ab(b.h,3,true)}}}
function B(a){return rd(a)?me:od(a)?ae:nd(a)?$d:ld(a)?a.Yb:dd(a)?a.Yb:a.Yb||Array.isArray(a)&&_c(Sd,1)||Sd}
function C(a){return rd(a)?il(a):od(a)?td(a):nd(a)?a?1231:1237:ld(a)?a.O():dd(a)?cl(a):!!a&&!!a.hashCode?a.hashCode():cl(a)}
function wo(a){return null==a.J?(Kp(),Ip):(Kp(),ed(_c(jg,1),ts,23,0,[Hp,Jp,Gp,Fp,Ip]))[a.J.readyState]}
function wm(){um();return ed(_c(lf,1),ts,9,0,[$l,_l,am,bm,cm,dm,em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm,qm,rm,sm,tm])}
function Hm(){var a,b;Dm.call(this);R();a=++Em;this.h=new pc(a,new Im(this),new Jm(this),true);this.g=(b=new qb(null),b)}
function gk(){dk();var a,b,c;c=ck+++Date.now();a=td($wnd.Math.floor(c*Hs))&16777215;b=td(c-a*Is);this.g=a^1502;this.h=b^Gs}
function ds(a,b){var c;ol(a.g,'b',b);return c=a.g.props,pl(a.g,ri(c['a']?hi(c['a'].h.j):null)+'-'+c['b']+(Th(eh),eh.v)),a.g}
function $n(a,b){var c;if(sd(a.J)===sd(b.currentTarget)){a.J=null;c=(nb(a.o),a.v);(aq(),$p)!=c&&Tp!=c&&Vp!=c&&Oo(a,Tp);bb(a.g)}}
function fo(a,b){var c;if(sd(a.D)===sd(b.currentTarget)){c=b.streams;a.H=new gj(a.H);c.forEach(xh(kq.prototype._,kq,[a]));bb(a.h)}}
function cn(a){var b;b=(nb(a.o),a.F);Vm(a);I((R(),R(),Q),new En(a,false),Ms);null!=b&&b.getTracks().forEach(xh(pp.prototype._,pp,[]))}
function _m(a){var b;++a.L;b=a.L;Vm(a);rn(a,true);a.J.Tb().then(xh(lp.prototype.bb,lp,[a,b])).catch(xh(mp.prototype.bb,mp,[a,b]))}
function Cm(a,b){Ai(a.i,b,true);3==a.i.h&&Tj(a.i);Pj(a.i,b);mb(a.g);$wnd.goog.global.globalThis.localStorage.setItem(Ls,qi(a.i))}
function Sj(a,b){var c,d;if(b>=a.h>>1){d=a.i;for(c=a.h;c>b;--c){d=d.h}}else{d=a.g.g;for(c=0;c<b;++c){d=d.g}}return new Yj(a,b,d)}
function Sb(a){var b,c,d;for(b=0;b<a.g.length;b++){d=a.g[b];if(0!=(d.i?d.g.length-d.h+d.j:d.j-d.h)){c=U(d);return c}}return null}
function Ai(a,b,c){var d,e;for(e=a.qb();e.Cb();){d=e.Db();if(sd(b)===sd(d)||b!=null&&A(b,d)){c&&e.Eb();return true}}return false}
function Ic(){var a;if(Dc!=0){a=Cc();if(a-Ec>2000){Ec=a;Fc=$wnd.setTimeout(Oc,10)}}if(Dc++==0){Rc((Qc(),Pc));return true}return false}
function Eb(a,b){Cb.call(this,a,new Fb(a),null,b|(vs==(b&ws)?0:524288)|(0==(b&6291456)?vs==(b&ws)?4194304:xs:0)|0|268435456|0)}
function bi(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Zc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function ek(a,b){var c,d;al(b>0);if((b&-b)==b){return td(b*fk(a)*4.6566128730773926E-10)}do{c=fk(a);d=c%b}while(c-d+(b-1)<0);return td(d)}
function dn(a,b){var c;rn(a,false);if(qd(b,$wnd.DOMException)){c=b;un(a,c.name);tn(a,c.message)}else{un(a,Uh(B(b)));tn(a,b==null?As:zh(b))}}
function Kp(){Kp=wh;Hp=new Lp('CONNECTING',0);Jp=new Lp('OPEN',1);Gp=new Lp('CLOSING',2);Fp=new Lp('CLOSED',3);Ip=new Lp('NOT_REQUESTED',4)}
function Cq(a){var b;this.l=new Hm;this.i=a;R();b=++Aq;this.h=new pc(b,new Dq(this),new Eq(this),false);this.g=new Db(null,new Gq(this),Xs)}
function Pm(){var a;this.i=new ip(this);R();a=++Nm;this.h=new pc(a,null,new Qm(this),true);this.g=new db(new Tm,new Rm(this),new Sm(this),Os)}
function mc(a){var b,c,d;for(c=new hj(new gj(new Mi(a.l)));c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.Lb();md(d,11)&&d.T()||b.Mb().Q()}}
function ec(a){var b,c,d;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new hj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;6!=d&&Ab(b,6,true)}}}
function fc(a){var b,c,d;if(a.i.g.length>0&&4==a.g){a.g=5;for(c=new hj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;4==d&&Ab(b,5,true)}}}
function A(a,b){return rd(a)?v(a,b):od(a)?sd(a)===sd(b):nd(a)?sd(a)===sd(b):ld(a)?a.M(b):dd(a)?v(a,b):!!a&&!!a.equals?a.equals(b):sd(a)===sd(b)}
function Bm(){var a,b,c;b=new gk;c=new vi;for(a=0;a<10;a++){si(c,li('abcdefghijklmnopqrstuvwxyz1234567890',$wnd.Math.abs(ek(b,36))))}return c.g}
function kd(a,b){if(rd(a)){return !!jd[b]}else if(a.Zb){return !!a.Zb[b]}else if(od(a)){return !!hd[b]}else if(nd(a)){return !!gd[b]}return false}
function an(a,b){var c;ln(a,b);c=(nb(a.o),a.F);if(b){null==c&&_m(a)}else{if(null!=c){c.getTracks().forEach(xh(qp.prototype._,qp,[]));vn(a,null)}}}
function yl(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function U(a){var b;if(0==(a.i?a.g.length-a.h+a.j:a.j-a.h)){return null}b=a.g[a.h];a.g[a.h]=null;++a.h;if(a.h>=a.g.length){a.h=0;a.i=false}return b}
function $(a){a.u?ob(a.l):nb(a.l);if(Bb(a.m)){if(a.u&&(R(),!(!!Xb&&!!Xb.l))){return F((R(),R(),Q),new eb(a),83888128,null)}else{ub(a.m)}}return cb(a)}
function pi(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function cd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function D(b,c,d){var e,f;try{hc(b,d);try{f=(c.g.Q(),null)}finally{ic()}return f}catch(a){a=lh(a);if(md(a,8)){e=a;throw mh(e)}else throw mh(a)}finally{L(b)}}
function db(a,b,c,d){this.i=a;this.o=b;this.s=c;this.v=null;this.u=16384==(d&16384);this.m=new Eb(this,d&-16385);this.l=new qb(this.m);vs==(d&ws)&&tb(this.m)}
function bo(a,b){var c,d;if(sd(a.D)===sd(b.currentTarget)){c=b.candidate;null!=c&&null!=a.J&&jo(a,(d={},d[Ps]=Ss,d[Ts]=c.sdpMLineIndex,d[Ss]=c.candidate,d))}}
function _n(a,b){var c;if(sd(a.D)===sd(b.currentTarget)){c=a.D.iceConnectionState;if(v('disconnected',c)||v('failed',c)||v('closed',c)){a.H.pb(new tp);a.H=new fj;bb(a.h)}}}
function dc(a){var b,c;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new hj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);5==(b.i&7)?Ab(b,6,true):4==(b.i&7)&&(a.g=4)}}}
function Sn(a,b){var c,d;if(Dk(a.H.yb(),new lq(b))){c=new mq;d=new An(new nq(b),c,true,true);_m(d);a.H.sb(d);b.onremovetrack=xh(up.prototype.fb,up,[a])}return null}
function qi(a){var b,c,d;d=new rk;for(c=Sj(a,0);c.h!=c.j.i;){b=Xj(c);!d.g?(d.g=new wi(d.j)):ti(d.g,d.h);ti(d.g,b)}return !d.g?d.i:d.l.length==0?d.g.g:d.g.g+(''+d.l)}
function Jb(a){var b,c;if(0==a.i){b=Tb(a.j);if(0==b){a.g=0;return false}else if(a.g+1>a.h){a.g=0;return false}else{a.g=a.g+1;a.i=b}}--a.i;c=Sb(a.j);Pb(c);return true}
function qh(b,c,d,e){ph();var f=nh;$moduleName=c;$moduleBase=d;kh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{qs(g)()}catch(a){b(c,a)}}else{qs(g)()}}
function fr(a,b){var c,d,e;b.preventDefault();c=(ob(a.h),a.i);null!=c&&(d=$wnd.goog.global.globalThis.location,e=c.length==0?c:'#'+c,v(d.hash,e)||(d.hash=e),undefined)}
function sl(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Yn(a,b){if(null!=a.J){a.G.g=bd(je,ts,1,0,5,1);a.J.close();a.J=null;Oo(a,b)}if(null!=a.D){a.H.pb(new vp);a.H.tb();Ji(a.F.g);a.D.close();a.D=null;mb(a.i);bb(a.h)}}
function yr(a){var b;this.j=xh(ls.prototype.U,ls,[this]);this.h=a;this.i=a.props['a'];R();b=++xr;this.g=new pc(b,null,null,false);mn(this.i,this,new zr(this));L((null,Q))}
function dk(){dk=wh;var a,b,c,d;ak=bd(ud,ts,235,25,15,1);bk=bd(ud,ts,235,33,15,1);d=1.52587890625E-5;for(b=32;b>=0;b--){bk[b]=d;d*=0.5}c=1;for(a=24;a>=0;a--){ak[a]=c;c*=0.5}}
function Dj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Ej()}}
function Dm(){var a,b,c,d,e;this.i=new Wj;this.j=new Pm;e=$wnd.goog.global.globalThis.localStorage.getItem(Ls);if(null!=e){for(b=ni(e),c=0,d=b.length;c<d;++c){a=b[c];Qj(this.i,a)}}}
function Nn(a){var b;b=(ob(a.m),a.u);(Qp(),Op)==b?a.D.createOffer().then(xh(hq.prototype.bb,hq,[a])).then(xh(iq.prototype.bb,iq,[a])).catch(xh(jq.prototype.bb,jq,[])):jo(a,ml(Ps,Qs))}
function dj(a,b){var c,d,e,f;e=null;f=0;for(d=0;d<a.g.length;++d){c=a.g[d];if(b.Sb(c)){if(e==null){e=Wk(a.g,d);f=d}}else e!=null&&(e[f++]=c)}if(e==null){return false}a.g=e;return true}
function F(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Xb){g=c.R()}else{hc(b,e);try{g=c.R()}finally{ic()}}return g}catch(a){a=lh(a);if(md(a,8)){f=a;throw mh(f)}else throw mh(a)}finally{L(b)}}
function th(){sh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Vc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0]._b()&&(c=Uc(c,g)):g[0]._b()}catch(a){a=lh(a);if(md(a,8)){d=a;Gc();Mc(md(d,47)?d.$():d)}else throw mh(a)}}return c}
function Ac(a){var b;if(a.i==null){b=sd(a.h)===sd(yc)?null:a.h;a.j=b==null?As:pd(b)?b==null?null:b.name:rd(b)?'String':Uh(B(b));a.g=a.g+': '+(pd(b)?b==null?null:b.message:b+'');a.i='('+a.j+') '+a.g}}
function Y(b){var c,d,e;e=b.v;try{d=b.i.R();if(!(sd(e)===sd(d)||e!=null&&A(e,d))){b.v=d;b.h=null;lb(b.l)}}catch(a){a=lh(a);if(md(a,13)){c=a;if(!b.h){b.v=null;b.h=c;lb(b.l)}throw mh(c)}else throw mh(a)}}
function fk(a){var b,c,d,e,f,g;e=a.g*Gs+a.h*1502;g=a.h*Gs+11;b=$wnd.Math.floor(g*Hs);e+=b;g-=b*Is;e%=Is;a.g=e;a.h=g;d=a.g*128;f=$wnd.Math.floor(a.h*bk[31]);c=d+f;c>=2147483648&&(c-=4294967296);return c}
function uj(a,b,c){var d,e,f,g,h;h=b==null?0:(g=C(b),g|0);e=(d=a.g.get(h),d==null?new Array:d);if(e.length==0){a.g.set(h,e)}else{f=rj(b,e);if(f){return f.Nb(c)}}e[e.length]=new Wi(b,c);++a.h;return null}
function hl(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+li(a,c++)}b=b|0;return b}
function Xk(a,b,c,d,e){var f,g,h,i,j;if(sd(a)===sd(c)){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function lo(a){var b;b=nn(a.I);null!=a.D&&null!=b&&on(a.I)&&null!=a.D&&b.getTracks().forEach(xh(fq.prototype._,fq,[a]));yn(a.I);null!=a.D&&on(a.I)&&null!=b&&null!=a.D&&b.getTracks().forEach(xh(eq.prototype._,eq,[a,b]))}
function ub(b){var c;if(1!=(b.i&7)){try{if(4!=(b.i&7)){if(0!=(b.i&512)){!!b.l&&(b.i&=-513);c=b.j;G((R(),R(),Q),b,c)}else{b.l.Q()}}else 0!=(b.i&512)&&!!b.l&&(b.i&=-513)}catch(a){a=lh(a);if(md(a,8)){R()}else throw mh(a)}}}
function Ci(a,b){var c,d,e;c=b.Lb();e=b.Mb();d=rd(c)?c==null?Ei(tj(a.g,null)):Hj(a.h,c):Ei(tj(a.g,c));if(!(sd(e)===sd(d)||e!=null&&A(e,d))){return false}if(d==null&&!(rd(c)?Gi(a,c):!!tj(a.g,c))){return false}return true}
function W(a){var b,c,d,e,f,g;b=a.i?a.g.length-a.h+a.j:a.j-a.h;if(b+1>a.g.length){g=(a.g.length-1)*2+1;c=bd(je,ts,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.h+d)%a.g.length;c[f]=a.g[e];a.g[e]=null;++f}a.g=c;a.h=0;a.j=f;a.i=false}}
function Cb(a,b,c,d){this.h=new fj;this.m=new Rb(new Gb(this),d&6520832|262144|vs);this.i=d&-6520833|3;this.g=a;this.j=b;this.l=c;!!this.j&&(this.i|=512);!this.g&&!!this.j&&(K((R(),R(),Q),this),0==(this.m.g&xs)&&L((null,Q)))}
function or(a){var b,c,d;this.l=a;this.o=a.props['a'];R();b=++kr;this.j=new pc(b,null,new pr(this),false);this.h=(d=new qb((c=null,c)),d);this.g=new Db(null,new tr(this),Xs);!!this.o&&Fm(this.o,this,new qr(this));L((null,Q))}
function vj(a,b){var c,d,e,f,g,h;g=b==null?0:(f=C(b),f|0);d=(c=a.g.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(mj(b,e.Lb())){if(d.length==1){d.length=0;yj(a.g,g)}else{d.splice(h,1)}--a.h;return e.Mb()}}return null}
function aq(){aq=wh;_p=new bq('NOT_READY',0);Up=new bq('CONNECTED',1);Zp=new bq('JOIN_REQUESTED',2);Yp=new bq('JOIN_REJECTED',3);Xp=new bq('JOINED',4);Tp=new bq('CLOSED',5);$p=new bq('LEFT',6);Wp=new bq('FULL',7);Vp=new bq('ERROR',8)}
function vh(a,b,c){var d=sh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=sh[b]),yh(h));_.Zb=c;!b&&(_.$b=Ah);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.Yb=f)}
function ul(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ll(b,xh(xl.prototype.Ub,xl,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Js]=c[0],undefined):(d[Js]=c,undefined));return rl(a,e,f,d)}
function ai(a){if(a.nb()){var b=a.i;b.ob()?(a.v='['+b.u):!b.nb()?(a.v='[L'+b.lb()+';'):(a.v='['+b.lb());a.h=b.kb()+'[]';a.s=b.mb()+'[]';return}var c=a.m;var d=a.j;d=d.split('/');a.v=bi('.',[c,bi('$',d)]);a.h=bi('.',[c,bi('.',d)]);a.s=d[d.length-1]}
function ko(a){a.D=new $wnd.RTCPeerConnection(Jh({},[Mh({})]));a.D.onicecandidate=xh(Dp.prototype.hb,Dp,[a]);a.D.ontrack=xh(Ep.prototype.ib,Ep,[a]);a.D.onconnectionstatechange=xh(sp.prototype.eb,sp,[a]);a.D.onnegotiationneeded=xh(dq.prototype.eb,dq,[a]);Zn(a,nn(a.B));Zn(a,nn(a.I))}
function Bb(b){var c,d,e,f,g;g=b.i&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new hj(b.h);e.g<e.i.g.length;){d=(e.h=e.g++,e.i.g[e.h]);if(d.h){f=d.h;c=f.g;try{$(c)}catch(a){a=lh(a);if(!md(a,8))throw mh(a)}if(6==(b.i&7)){return true}}}}}wb(b);return false}
function sc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.X();return a&&a.V()}},suppressed:{get:function(){return c.W()}}})}catch(a){}}}
function Cj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function Xq(a){var b;this.s=new Sr(this);this.j=a;this.m=a.props['a'];this.o=a.props['b'];R();b=++Tq;this.i=new pc(b,new Yq(this),new Zq(this),false);this.g=new db(new dr,new $q(this),new _q(this),35815424);this.h=new Db(null,new er(this),Xs);Fm(this.m,this,new ar(this));this.u=new Ro(this.o,(aq(),_p),(Qp(),Pp));Io(this.u);Gm(this.m,this.o);L((null,Q))}
function Ab(a,b,c){var d,e,f,g;g=a.i&7;if(b!=g){a.i=a.i&-8|b;if(!a.g&&6==b){c&&(1==(a.i&7)||1==(3&a.m.g)||K((R(),R(),Q),a))}else if(!!a.g&&4==g&&(6==b||5==b)){pb(a.g.l);c&&(1==(a.i&7)||1==(3&a.m.g)||K((R(),R(),Q),a))}else if(3==b||3!=g&&2==b){if(a.g){d=a.g;zb((e=d.s,e));d.v=null}$i(a.h,new Ib(a));a.h.g=bd(je,ts,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.g&&zb((f=a.g.o,f))}}
function ni(a){var b,c,d,e,f,g,h,i;b=new RegExp('\\|','g');h=bd(me,ts,2,0,6,1);c=0;i=a;e=null;while(true){g=b.exec(i);if(g==null||i==''){h[c]=i;break}else{f=g.index;h[c]=i.substr(0,f);i=oi(i,f+g[0].length,i.length);b.lastIndex=0;if(e==i){h[c]=i.substr(0,1);i=i.substr(1)}e=i;++c}}if(a.length>0){d=h.length;while(d>0&&h[d-1]==''){--d}d<h.length&&(h.length=d)}return h}
function go(a){var b,c;I((R(),R(),Q),new ap(a),Ws);sn(a.B,true);bb(a.g);No(a,(Qp(),Pp));Oo(a,(aq(),_p));a.J=new $wnd.WebSocket((b=$wnd.goog.global.globalThis.location,c=v('https',b.protocol)?'wss':'ws',c+'://'+b.hostname+':'+3737+'/r/'+a.C));a.J.onopen=xh(zp.prototype.eb,zp,[a]);a.J.onmessage=xh(Ap.prototype.gb,Ap,[a]);a.J.onclose=xh(Bp.prototype.cb,Bp,[a]);a.J.onerror=xh(Cp.prototype.eb,Cp,[a])}
function An(a,b,c,d){var e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;this.J=a;this.K=b;R();e=++hn;this.I=new pc(e,null,new Bn(this),true);this.B=c;this.v=d;this.H=true;this.h=(o=new qb((g=null,g)),o);this.o=(p=new qb((h=null,h)),p);this.l=(q=new qb((i=null,i)),q);this.j=(r=new qb((j=null,j)),r);this.i=(s=new qb((k=null,k)),s);this.g=(t=new qb((l=null,l)),t);this.u=(u=new qb((m=null,m)),u);this.s=(n=new qb((f=null,f)),n);this.m=new Db(new Cn(this),null,404750336);L((null,Q))}
function um(){um=wh;$l=new vm(Ks,0);_l=new vm('checkbox',1);am=new vm('color',2);bm=new vm('date',3);cm=new vm('datetime',4);dm=new vm('email',5);em=new vm('file',6);fm=new vm('hidden',7);gm=new vm('image',8);hm=new vm('month',9);im=new vm('number',10);jm=new vm('password',11);km=new vm('radio',12);lm=new vm('range',13);mm=new vm('reset',14);nm=new vm('search',15);om=new vm('submit',16);pm=new vm('tel',17);qm=new vm('text',18);rm=new vm('time',19);sm=new vm('url',20);tm=new vm('week',21)}
function Ro(a,b,c){var d,e,f,g,h,i,j,k,l;this.G=new fj;this.F=new qj;this.B=new An(new rp,new wp(this),false,true);this.I=new An(new xp,new yp(this),false,false);this.H=new fj;this.C=a;R();d=++po;this.A=new pc(d,new So(this),new To(this),true);this.v=b;this.u=c;this.s='';this.o=(i=new qb((f=null,f)),i);this.m=(j=new qb((g=null,g)),j);this.l=(k=new qb((e=null,e)),k);this.j=(l=new qb(null),l);this.i=(h=new qb(null),h);this.g=new db(new Uo(this),null,null,Os);this.h=new db(new Vo(this),null,null,Os)}
function $b(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.l){return}j=(n=a.l.i&7,n>3?n:4);e=false;c=0;if(!!a.h&&1!=(a.l.i&7)){m=a.h.g.length;for(h=0;h<m;h++){k=_i(a.h,h);if(-1!=k.l&&-2!=k.l){k.l=-1;h!=c&&ej(a.h,c,k);++c;if(k.h){l=k.h;f=l.i&7;f==6&&(j=f)}}}}d=a.l.h;for(i=d.g.length-1;i>=0;i--){k=d.g[i];if(-1==k.l){k.l=0}else{kb(k,a.l);e=true}}2<(a.l.i&7)&&4!=j&&(a.l.i&7)<j&&Ab(a.l,j,false);if(a.h){for(g=c-1;g>=0;g--){k=_i(a.h,g);if(-1==k.l){k.l=0;jb(k,a.l);e=true}}}if(a.h){for(g=a.h.g.length-1;g>=c;g--){bj(a.h,g)}e&&yb(a.l,a.h)}else{e&&yb(a.l,new fj)}if(gb(a.l)&&!!a.l.g){b=a.l.g;k=b.l;!!k.h&&vs!=(k.h.i&ws)&&k.i.g.length<=0&&0==k.h.g.j&&cc(a,k)}}
function ir(a){var b,c,d,e;a.m=0;ym();b=(c=(ob(a.h),a.i),d=a.o,e=(nb(d.g),d.i),ul($s,Hl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,['home'])),xh(fs.prototype.Vb,fs,[a])),[ul('h1',null,['vChat']),ul('label',Tl(new $wnd.Object,'roomCode'),['Enter a room code.']),ul('input',Cl(Ll(Ql(Ml(Ol(Nl(Sl(zl(Pl(yl(Gl(new $wnd.Object,(um(),qm)),ed(_c(me,1),ts,2,6,['roomCodeInput'])),'Room code'),'roomCode'),null==c?'':c),xh(hs.prototype.Vb,hs,[a]))),10)))),null),ul(et,yl(new $wnd.Object,ed(_c(me,1),ts,2,6,['roomSelectButtons'])),[ul(Ks,Gl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[ct])),(Xl(),Wl)),['Join']),ul('a',Dl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[ct])),'#'+Bm()),['Join Random'])]),e.h==0?null:ql([ul(et,null,['Recently used rooms:']),ql(Gk(Ck(new Hk(null,new pk(e,16)),new gs),new wl))])]));return b}
function Ej(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Fs]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Cj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Fs]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function co(a,b){var c,d,e,f,g,h,i,j;e=b.data;d=$wnd.goog.global.globalThis.console;h=$wnd.JSON.parse(e);g=h;if(sd(a.J)===sd(b.currentTarget)){bb(a.g);c=g[Ps];if(v('create',c)){d.log('Connected to room as host');No(a,(Qp(),Op));Oo(a,(aq(),Xp))}else if(v('connect',c)){d.log('Connected to room as guest');No(a,(Qp(),Np));Oo(a,(aq(),Up))}else if(v('full',c)){d.log('Room full. Leaving room.');No(a,(Qp(),Pp));Yn(a,(aq(),Wp))}else if(v(Us,c)){f=g['id'];i=g['message'];d.log("Guest '"+f+"' requested access to room with message '"+i+"'");Yi(a.G,new Am(f,i));mb(a.j)}else if(v('accept',c)){d.log('Host allowed guest to join room.');Oo(a,(aq(),Xp));ko(a)}else if(v('reject',c)){d.log('Host rejected guest from room.');Oo(a,(aq(),Yp))}else if(v('accepted',c)){f=g['id'];d.log("Host accepted guest '"+f+"' into room.");oj(a.F,f);mb(a.i)}else if(v('remove',c)){f=g['id'];if(pj(a.F,f)){d.log("Guest '"+f+Vs);mb(a.i)}else if(dj(a.G,new pq(f))){d.log("Client '"+f+Vs);mb(a.j)}}else if(v('offer',c)){a.D.setRemoteDescription(g[Rs]);a.D.createAnswer().then(xh(qq.prototype.bb,qq,[a])).then(xh(rq.prototype.bb,rq,[a])).catch(xh(sq.prototype.bb,sq,[d]))}else v('answer',c)?a.D.setRemoteDescription(g[Rs]):v(Ss,c)?a.D.addIceCandidate(Kh(Lh({},g[Ts]),g[Ss])):v(Qs,c)&&(j=(ob(a.m),a.u),(Qp(),Op)==j?a.D.createOffer().then(xh(hq.prototype.bb,hq,[a])).then(xh(iq.prototype.bb,iq,[a])).catch(xh(jq.prototype.bb,jq,[])):jo(a,ml(Ps,Qs)))}}
function Rq(a){var b,c,d;a.l=0;ym();b=(c=a.u.B,d=$(a.u.g),ul(et,Bl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,['room-view'])),xh(Tr.prototype.U,Tr,[a])),[ul(et,yl(new $wnd.Object,ed(_c(me,1),ts,2,6,['video-section'])),[ul(et,yl(new $wnd.Object,ed(_c(me,1),ts,2,6,['video-list'])),Gk(Ck($(a.u.h).yb(),new Wr),new wl)),ul(et,yl(new $wnd.Object,ed(_c(me,1),ts,2,6,['active-video'])),[ul(et,yl(new $wnd.Object,ed(_c(me,1),ts,2,6,['active-video-wrapper'])),[ns(ms(a.u.B),'active-video-element')]),ul(et,yl(new $wnd.Object,ed(_c(me,1),ts,2,6,['controls'])),[ul(Ks,Fl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[gt])),xh(Xr.prototype.Wb,Xr,[a])),[ul('img',Il(Kl(Jl(new $wnd.Object,on(a.u.I)?'img/screen_share_on.svg':'img/screen_share_off.svg'))),null)]),ul(Ks,Fl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[gt])),xh(Yr.prototype.Wb,Yr,[c])),[ul('img',Il(Kl(Jl(new $wnd.Object,(nb(c.g),c.v?'img/mic_on.svg':'img/mic_off.svg')))),null)]),ul(Ks,Fl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[gt])),xh(Zr.prototype.Wb,Zr,[c])),[ul('img',Il(Kl(Jl(new $wnd.Object,(nb(c.u),c.H?'img/cam_on.svg':'img/cam_off.svg')))),null)]),ul(Ks,Fl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[gt])),xh($r.prototype.Wb,$r,[a])),[ul('img',Il(Kl(Jl(new $wnd.Object,$(a.g)?'img/fullscreen_on.svg':'img/fullscreen_off.svg'))),null)]),ul(Ks,Fl(yl(El(new $wnd.Object,(Kp(),Hp)!=d&&Jp!=d),ed(_c(me,1),ts,2,6,[gt])),xh(_r.prototype.Wb,_r,[a])),[ul('img',Il(Kl(Jl(new $wnd.Object,'img/hangup.svg'))),null)])])])]),ul(et,yl(new $wnd.Object,ed(_c(me,1),ts,2,6,['message-area'])),[Oq(a)])]));return b}
function Oq(a){var b,c;c=Po(a.u);if((aq(),_p)==c){return ql([ul(Zs,null,['Getting ready...']),ul('p',null,["You'll be able to join in just a moment."])])}else if(Vp==c){return ql([ul(Zs,null,['Service Offline']),ul('p',null,['The chat service is offline at the moment. Try again later.'])])}else if(Up==c){return ql([ul(Zs,null,['Ready to join?']),ul('p',null,['Request access to join the room.']),ul($s,Hl(new $wnd.Object,xh(Rr.prototype.Vb,Rr,[a])),[ul('label',Tl(new $wnd.Object,_s),[at]),ul('input',Ql(Ml(Sl(Nl(Ll(zl(Pl(Gl(new $wnd.Object,(um(),qm)),bt),_s)),xh(Vr.prototype.Vb,Vr,[a])),Lo(a.u)),30)),null),ul(Ks,yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[ct])),[dt])])])}else if(Zp==c){return ql([ul(Zs,null,['Joining room']),ul('p',null,['Waiting for host to allow access to the room.'])])}else if(Xp==c&&(Qp(),Op)==Mo(a.u)&&vo(a.u).g.length!=0){b=vo(a.u).g[0];return ql([ul(Zs,null,['Guest requests access']),ul('p',null,['A guest has sent you a message to join the room:']),ul(et,yl(new $wnd.Object,ed(_c(me,1),ts,2,6,['request-message'])),[b.h]),ul($s,Hl(new $wnd.Object,xh(Qr.prototype.Vb,Qr,[])),[ul(Ks,Fl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[ct])),xh(as.prototype.Wb,as,[a,b])),['Accept']),ul(Ks,Fl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[ct])),xh(Ur.prototype.Wb,Ur,[a,b])),['Reject'])])])}else return Xp==c&&(Qp(),Op)==Mo(a.u)&&Ki(uo(a.u).g)==0?ql([ul(Zs,null,['Waiting for guests to join']),ul('p',null,['Waiting for someone to join this room']),ul('a',Dl(new $wnd.Object,'#'+a.u.C),[a.u.C])]):Xp==c?ql([ul(Zs,null,['Joined room']),ul('p',null,['Joined room. Feel free to chat.'])]):Yp==c?ql([ul(Zs,null,['Access denied']),ul('p',null,['The host denied access to the room. You can attempt to re-request access to join the room.']),ul($s,Hl(new $wnd.Object,xh(Rr.prototype.Vb,Rr,[a])),[ul('label',Tl(new $wnd.Object,_s),[at]),ul('input',Ql(Ml(Sl(Nl(Ll(zl(Pl(Gl(new $wnd.Object,(um(),qm)),bt),_s)),xh(Vr.prototype.Vb,Vr,[a])),Lo(a.u)),30)),null),ul(Ks,yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[ct])),[dt])])]):Tp==c?ql([ul(Zs,null,['Room closed']),ul('p',null,[(Qp(),Op)==Mo(a.u)?'You closed the room.':'The host closed the room.']),ul('a',Dl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[ct])),'#'),[ft])]):Wp==c?ql([ul(Zs,null,['Room full']),ul('p',null,['The room is full and no other guests can connect at this time.']),ul('a',Dl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[ct])),'#'),[ft])]):$p==c?ql([ul(Zs,null,['Left the room']),ul('p',null,['You left the room.']),ul('a',Dl(yl(new $wnd.Object,ed(_c(me,1),ts,2,6,[ct])),'#'),[ft])]):null}
var rs='object',ss={6:1},ts={4:1},us={11:1},vs=1048576,ws=1835008,xs=2097152,ys='__noinit__',zs={4:1,13:1,10:1,8:1},As='null',Bs={31:1,68:1},Cs={31:1,62:1},Ds={43:1},Es={4:1,31:1,62:1},Fs='delete',Gs=15525485,Hs=5.9604644775390625E-8,Is=16777216,Js='children',Ks='button',Ls='vchat.rooms',Ms=142606336,Ns='hashchange',Os=35651584,Ps='command',Qs='renegotiate',Rs='session',Ss='candidate',Ts='mlineindex',Us='request_access',Vs="' left the room.",Ws=75497472,Xs=1411518464,Ys='fullscreenchange',Zs='h2',$s='form',_s='requestAccessMessage',at='Enter a message to send to the host to request access.',bt="Hi, I'm John Doe.",ct='primary-button',dt='Request Access',et='div',ft='Return to Home',gt='control-btn';var _,sh,nh,kh=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;th();vh(1,null,{},w);_.M=function(a){return v(this,a)};_.N=function(){return this.Yb};_.O=it;_.P=function(){var a;return Uh(B(this))+'@'+(a=C(this)>>>0,a.toString(16))};_.equals=function(a){return this.M(a)};_.hashCode=function(){return this.O()};_.toString=function(){return this.P()};var gd,hd,jd;vh(71,1,{},Vh);_.jb=function(a){var b;b=new Vh;b.l=4;a>1?(b.i=$h(this,a-1)):(b.i=this);return b};_.kb=function(){Th(this);return this.h};_.lb=function(){return Uh(this)};_.mb=function(){Th(this);return this.s};_.nb=function(){return (this.l&4)!=0};_.ob=function(){return (this.l&1)!=0};_.P=function(){return ((this.l&2)!=0?'interface ':(this.l&1)!=0?'':'class ')+(Th(this),this.v)};_.l=0;_.o=0;var Sh=1;var je=Xh(1);var _d=Xh(71);vh(104,1,{},M);_.h=1;_.i=false;_.j=true;_.l=0;var yd=Xh(104);vh(105,1,ss,N);_.Q=function(){Kb(this.g)};var vd=Xh(105);vh(56,1,{},O);_.R=function(){return this.g.Q(),null};var wd=Xh(56);vh(106,1,{},P);var xd=Xh(106);var Q;vh(57,1,{57:1},X);_.h=0;_.i=false;_.j=0;var zd=Xh(57);vh(258,1,us);_.P=function(){var a;return Uh(this.Yb)+'@'+(a=C(this)>>>0,a.toString(16))};var Cd=Xh(258);vh(49,258,us,db);_.S=function(){Z(this)};_.T=ht;_.g=false;_.j=0;_.u=false;var Bd=Xh(49);vh(143,1,{},eb);_.R=function(){return ab(this.g)};var Ad=Xh(143);vh(12,258,{11:1,12:1},qb);_.S=function(){hb(this)};_.T=function(){return -2==this.l};_.g=4;_.j=false;_.l=0;var Ed=Xh(12);vh(142,1,ss,rb);_.Q=function(){ib(this.g)};var Dd=Xh(142);vh(22,258,{11:1,22:1},Db,Eb);_.S=function(){sb(this)};_.T=function(){return 1==(this.i&7)};_.i=0;var Jd=Xh(22);vh(137,1,{},Fb);_.Q=function(){Y(this.g)};var Fd=Xh(137);vh(138,1,ss,Gb);_.Q=function(){ub(this.g)};var Gd=Xh(138);vh(139,1,ss,Hb);_.Q=function(){xb(this.g)};var Hd=Xh(139);vh(140,1,{},Ib);_.U=function(a){vb(this.g,a)};var Id=Xh(140);vh(117,1,{},Lb);_.g=0;_.h=0;_.i=0;var Kd=Xh(117);vh(148,1,us,Nb);_.S=function(){Mb(this)};_.T=ht;_.g=false;var Ld=Xh(148);vh(82,258,{11:1,82:1},Rb);_.S=function(){Ob(this)};_.T=function(){return 2==(3&this.g)};_.g=0;var Nd=Xh(82);vh(116,1,{},Wb);var Md=Xh(116);vh(149,1,{},gc);_.P=function(){var a;return Th(Od),Od.v+'@'+(a=cl(this)>>>0,a.toString(16))};_.g=0;var Xb;var Od=Xh(149);vh(21,1,us,pc);_.S=function(){kc(this)};_.T=function(){return this.s<0};_.P=function(){var a;return Th(Qd),Qd.v+'@'+(a=cl(this)>>>0,a.toString(16))};_.j=0;_.s=0;var Qd=Xh(21);vh(136,1,ss,qc);_.Q=function(){nc(this.g)};var Pd=Xh(136);vh(8,1,{4:1,8:1});_.V=qt;_.W=function(){return Gk(Ck(jj((this.s==null&&(this.s=bd(oe,ts,8,0,0,1)),this.s)),new xi),new Kk)};_.X=function(){return this.m};_.Y=function(){return this.o};_.Z=function(){tc(this,vc(new Error(uc(this,this.o))));Yc(this)};_.P=function(){return uc(this,this.Y())};_.l=ys;_.u=true;var oe=Xh(8);vh(13,8,{4:1,13:1,8:1});var ce=Xh(13);vh(10,13,zs);var ke=Xh(10);vh(99,10,zs);var he=Xh(99);vh(100,99,zs);var Ud=Xh(100);vh(47,100,{47:1,4:1,13:1,10:1,8:1},Bc);_.Y=function(){Ac(this);return this.i};_.$=function(){return sd(this.h)===sd(yc)?null:this.h};var yc;var Rd=Xh(47);var Sd=Xh(0);vh(242,1,{});var Td=Xh(242);var Dc=0,Ec=0,Fc=-1;vh(109,242,{},Tc);var Pc;var Vd=Xh(109);var Wc;vh(252,1,{});var Xd=Xh(252);vh(101,252,{},$c);var Wd=Xh(101);vh(73,1,{96:1});_.P=ht;var Yd=Xh(73);vh(103,10,zs);var fe=Xh(103);vh(141,103,zs,Qh);var Zd=Xh(141);gd={4:1,97:1,20:1};var $d=Xh(97);vh(55,1,{4:1,55:1});var ie=Xh(55);hd={4:1,20:1,98:1,55:1};var ae=Xh(98);vh(16,1,{4:1,20:1,16:1});_.M=function(a){return this===a};_.O=it;_.P=function(){return this.g!=null?this.g:''+this.h};_.h=0;var be=Xh(16);vh(72,10,zs,ei);var de=Xh(72);vh(102,10,zs,fi);var ee=Xh(102);vh(37,55,{4:1,20:1,37:1,55:1},gi);_.M=function(a){return md(a,37)&&a.g==this.g};_.O=ht;_.P=function(){return ''+this.g};_.g=0;var ge=Xh(37);var ii;vh(352,1,{});jd={4:1,96:1,20:1,2:1};var me=Xh(2);vh(54,73,{96:1},vi,wi);var le=Xh(54);vh(356,1,{});vh(94,1,{},xi);_.rb=function(a){return a.l};var ne=Xh(94);vh(46,10,zs,yi,zi);var pe=Xh(46);vh(253,1,{31:1});_.pb=pt;_.xb=function(){return new pk(this,0)};_.yb=function(){return new Hk(null,this.xb())};_.sb=function(a){throw mh(new zi('Add not supported on this collection'))};_.tb=function(){var a;for(a=this.qb();a.Cb();){a.Db();a.Eb()}};_.ub=function(a){return Ai(this,a,false)};_.vb=function(){return this.wb()==0};_.zb=function(){return this.Ab(bd(je,ts,1,this.wb(),5,1))};_.Ab=function(a){var b,c,d,e;e=this.wb();a.length<e&&(a=_k(new Array(e),a));d=a;c=this.qb();for(b=0;b<e;++b){d[b]=c.Db()}a.length>e&&(a[e]=null);return a};_.P=function(){var a,b,c;c=new sk(', ','[',']');for(b=this.qb();b.Cb();){a=b.Db();qk(c,a===this?'(this Collection)':a==null?As:zh(a))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var qe=Xh(253);vh(256,1,{238:1});_.M=function(a){var b,c,d;if(a===this){return true}if(!md(a,48)){return false}d=a;if(this.g.h+this.h.h!=d.g.h+d.h.h){return false}for(c=new Qi((new Mi(d)).g);c.h;){b=Oi(c);if(!Ci(this,b)){return false}}return true};_.O=function(){return kj(new Mi(this))};_.P=function(){var a,b,c;c=new sk(', ','{','}');for(b=new Qi((new Mi(this)).g);b.h;){a=Oi(b);qk(c,Di(this,a.Lb())+'='+Di(this,a.Mb()))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var Ce=Xh(256);vh(118,256,{238:1});var te=Xh(118);vh(255,253,Bs);_.xb=function(){return new pk(this,1)};_.M=function(a){var b;if(a===this){return true}if(!md(a,68)){return false}b=a;if(b.wb()!=this.wb()){return false}return Bi(this,b)};_.O=function(){return kj(this)};var Ee=Xh(255);vh(35,255,Bs,Mi);_.tb=lt;_.ub=function(a){return Li(this,a)};_.qb=function(){return new Qi(this.g)};_.wb=mt;var se=Xh(35);vh(38,1,{},Qi);_.Bb=jt;_.Db=function(){return Oi(this)};_.Cb=nt;_.Eb=function(){Pi(this)};_.h=false;var re=Xh(38);vh(254,253,Cs);_.xb=function(){return new pk(this,16)};_.Fb=function(a,b){throw mh(new zi('Add not supported on this list'))};_.sb=function(a){this.Fb(this.wb(),a);return true};_.tb=function(){this.Jb(0,this.wb())};_.M=function(a){var b,c,d,e,f;if(a===this){return true}if(!md(a,62)){return false}f=a;if(this.wb()!=f.wb()){return false}e=f.qb();for(c=this.qb();c.Cb();){b=c.Db();d=e.Db();if(!(sd(b)===sd(d)||b!=null&&A(b,d))){return false}}return true};_.O=function(){return lj(this)};_.qb=function(){return new Si(this)};_.Hb=function(a){return new Ti(this,a)};_.Ib=function(a){throw mh(new zi('Remove not supported on this list'))};_.Jb=function(a,b){var c,d;d=this.Hb(a);for(c=a;c<b;++c){d.Db();d.Eb()}};var we=Xh(254);vh(74,1,{},Si);_.Bb=jt;_.Cb=function(){return this.h<this.j.wb()};_.Db=function(){this.h<this.j.wb();return this.j.Gb(this.i=this.h++)};_.Eb=kt;_.h=0;_.i=-1;var ue=Xh(74);vh(108,74,{},Ti);_.Eb=kt;_.Kb=function(a){this.g.Fb(this.h,a);++this.h;this.i=-1};var ve=Xh(108);vh(112,255,Bs,Ui);_.tb=lt;_.ub=ot;_.qb=function(){var a;return a=new Qi((new Mi(this.g)).g),new Vi(a)};_.wb=mt;var ye=Xh(112);vh(75,1,{},Vi);_.Bb=jt;_.Cb=function(){return this.g.h};_.Db=function(){var a;a=Oi(this.g);return a.Lb()};_.Eb=function(){Pi(this.g)};var xe=Xh(75);vh(110,1,Ds);_.M=function(a){var b;if(!md(a,43)){return false}b=a;return mj(this.g,b.Lb())&&mj(this.h,b.Mb())};_.Lb=ht;_.Mb=nt;_.O=function(){return _j(this.g)^_j(this.h)};_.Nb=function(a){var b;b=this.h;this.h=a;return b};_.P=function(){return this.g+'='+this.h};var ze=Xh(110);vh(111,110,Ds,Wi);var Ae=Xh(111);vh(257,1,Ds);_.M=function(a){var b;if(!md(a,43)){return false}b=a;return mj(this.h.value[0],b.Lb())&&mj(Mj(this),b.Mb())};_.O=function(){return _j(this.h.value[0])^_j(Mj(this))};_.P=function(){return this.h.value[0]+'='+Mj(this)};var Be=Xh(257);vh(260,254,Cs);_.Fb=function(a,b){var c;c=this.Hb(a);c.Kb(b)};_.Gb=function(a){var b;b=this.Hb(a);return b.Db()};_.qb=function(){return Sj(this,0)};_.Ib=function(a){var b,c;b=this.Hb(a);c=b.Db();b.Eb();return c};var De=Xh(260);vh(15,254,Es,fj,gj);_.Fb=function(a,b){Yk(this.g,a,b)};_.sb=function(a){return Yi(this,a)};_.tb=function(){this.g=bd(je,ts,1,0,5,1)};_.ub=function(a){return aj(this,a,0)!=-1};_.pb=function(a){$i(this,a)};_.Gb=function(a){return _i(this,a)};_.vb=function(){return this.g.length==0};_.qb=function(){return new hj(this)};_.Ib=function(a){return bj(this,a)};_.Jb=function(a,b){var c;c=b-a;$k(this.g,a,c)};_.wb=function(){return this.g.length};_.zb=function(){return Wk(this.g,this.g.length)};_.Ab=function(a){var b,c;c=this.g.length;a.length<c&&(a=_k(new Array(c),a));for(b=0;b<c;++b){a[b]=this.g[b]}a.length>c&&(a[c]=null);return a};var Ge=Xh(15);vh(28,1,{},hj);_.Bb=jt;_.Cb=function(){return this.g<this.i.g.length};_.Db=function(){return this.h=this.g++,this.i.g[this.h]};_.Eb=function(){bj(this.i,this.g=this.h);this.h=-1};_.g=0;_.h=-1;var Fe=Xh(28);vh(48,118,{4:1,48:1,238:1},nj);var He=Xh(48);vh(168,255,{4:1,31:1,68:1},qj);_.sb=function(a){return oj(this,a)};_.tb=lt;_.ub=ot;_.vb=function(){return Ki(this.g)==0};_.qb=function(){var a;return a=new Qi((new Mi((new Ui(this.g)).g)).g),new Vi(a)};_.wb=mt;var Ie=Xh(168);vh(76,1,{},wj);_.pb=pt;_.qb=function(){return new xj(this)};_.h=0;var Ke=Xh(76);vh(77,1,{},xj);_.Bb=jt;_.Db=function(){return this.j=this.g[this.i++],this.j};_.Cb=function(){var a;if(this.i<this.g.length){return true}a=this.h.next();if(!a.done){this.g=a.value[1];this.i=0;return true}return false};_.Eb=function(){vj(this.l,this.j.Lb());this.i!=0&&--this.i};_.i=0;_.j=null;var Je=Xh(77);var Aj;vh(78,1,{},Kj);_.pb=pt;_.qb=function(){return new Lj(this)};_.h=0;_.i=0;var Ne=Xh(78);vh(79,1,{},Lj);_.Bb=jt;_.Db=function(){return this.i=this.g,this.g=this.h.next(),new Nj(this.j,this.i,this.j.i)};_.Cb=function(){return !this.g.done};_.Eb=function(){Jj(this.j,this.i.value[0])};var Le=Xh(79);vh(119,257,Ds,Nj);_.Lb=function(){return this.h.value[0]};_.Mb=function(){return Mj(this)};_.Nb=function(a){return Ij(this.g,this.h.value[0],a)};_.i=0;var Me=Xh(119);vh(159,260,Es,Wj);_.sb=function(a){Rj(this,a,this.i.h,this.i);return true};_.tb=function(){Vj(this)};_.Hb=function(a){return Sj(this,a)};_.wb=nt;_.h=0;var Qe=Xh(159);vh(160,1,{},Yj);_.Bb=jt;_.Kb=function(a){Rj(this.j,a,this.h.h,this.h);++this.g;this.i=null};_.Cb=function(){return this.h!=this.j.i};_.Db=function(){return Xj(this)};_.Eb=function(){var a;a=this.i.g;Uj(this.j,this.i);this.h==this.i?(this.h=a):--this.g;this.i=null};_.g=0;_.i=null;var Oe=Xh(160);vh(59,1,{},Zj);var Pe=Xh(59);vh(202,1,{},gk);_.g=0;_.h=0;var ak,bk,ck=0;var Re=Xh(202);vh(121,1,{});_.Bb=rt;_.Ob=function(){return this.j};_.Pb=qt;_.j=0;_.l=0;var Ve=Xh(121);vh(80,121,{});var Se=Xh(80);vh(113,1,{});_.Bb=rt;_.Ob=nt;_.Pb=function(){return this.j-this.i};_.h=0;_.i=0;_.j=0;var Ue=Xh(113);vh(114,113,{},nk);_.Bb=function(a){kk(this,a)};_.Qb=function(a){return lk(this,a)};var Te=Xh(114);vh(29,1,{},pk);_.Ob=ht;_.Pb=function(){ok(this);return this.i};_.Bb=function(a){ok(this);this.j.Bb(a)};_.Qb=function(a){ok(this);if(this.j.Cb()){a.U(this.j.Db());return true}return false};_.g=0;_.i=0;var We=Xh(29);vh(45,1,{},rk,sk);_.P=function(){return !this.g?this.i:this.l.length==0?this.g.g:this.g.g+(''+this.l)};var Xe=Xh(45);vh(70,1,{},tk);_.rb=function(a){return a};var Ye=Xh(70);vh(83,1,{},uk);var Ze=Xh(83);vh(120,1,{});_.i=false;var hf=Xh(120);vh(30,120,{},Hk);var yk;var gf=Xh(30);vh(95,1,{},Kk);_.Rb=function(a){return zk(),bd(je,ts,1,a,5,1)};var $e=Xh(95);vh(81,80,{},Mk);_.Qb=function(a){this.h=false;while(!this.h&&this.i.Qb(new Nk(this,a)));return this.h};_.h=false;var af=Xh(81);vh(125,1,{},Nk);_.U=function(a){Lk(this.g,this.h,a)};var _e=Xh(125);vh(122,80,{},Pk);_.Qb=function(a){return this.h.Qb(new Qk(this,a))};var cf=Xh(122);vh(124,1,{},Qk);_.U=function(a){Ok(this.g,this.h,a)};var bf=Xh(124);vh(123,1,{},Sk);_.U=function(a){Rk(this,a)};var df=Xh(123);vh(126,1,{},Tk);_.U=function(a){zk()};var ef=Xh(126);vh(127,1,{},Vk);_.U=function(a){Uk(this,a)};var ff=Xh(127);vh(354,1,{});vh(351,1,{});var bl=0;var dl,el=0,fl;vh(1327,1,{});vh(1360,1,{});vh(84,1,{},wl);_.Rb=function(a){return new Array(a)};var jf=Xh(84);vh(309,$wnd.Function,{},xl);_.Ub=function(a){vl(this.g,this.h,a)};vh(39,16,{4:1,20:1,16:1,39:1},Yl);var Ul,Vl,Wl;var kf=Yh(39,Zl);vh(9,16,{4:1,20:1,16:1,9:1},vm);var $l,_l,am,bm,cm,dm,em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm,qm,rm,sm,tm;var lf=Yh(9,wm);var xm;vh(295,$wnd.Function,{},zm);_.bb=function(a){return Mb(xm),xm=null,null};vh(87,1,{87:1},Am);var mf=Xh(87);vh(58,1,{58:1});var nf=Xh(58);vh(150,58,{11:1,58:1},Hm);_.S=st;_.T=tt;_.P=function(){var a;return Th(rf),rf.v+'@'+(a=cl(this)>>>0,a.toString(16))};var Em=0;var rf=Xh(150);vh(151,1,ss,Im);_.Q=function(){fb(this.g.j)};var of=Xh(151);vh(152,1,ss,Jm);_.Q=function(){hb(this.g.g)};var pf=Xh(152);vh(153,1,ss,Km);_.Q=function(){Cm(this.g,this.h)};var qf=Xh(153);vh(161,1,{});var bg=Xh(161);vh(162,161,us,Pm);_.S=st;_.T=tt;_.P=function(){var a;return Th(xf),xf.v+'@'+(a=cl(this)>>>0,a.toString(16))};var Nm=0;var xf=Xh(162);vh(163,1,ss,Qm);_.Q=function(){Z(this.g.g)};var sf=Xh(163);vh(165,1,{},Rm);_.Q=function(){Lm(this.g)};var tf=Xh(165);vh(166,1,{},Sm);_.Q=function(){Mm(this.g)};var uf=Xh(166);vh(164,1,{},Tm);_.R=function(){var a;return a=$wnd.goog.global.globalThis.location.hash,a.length==0?a:a.substr(1)};var vf=Xh(164);vh(167,1,ss,Um);_.Q=xt;var wf=Xh(167);vh(60,1,{60:1});_.L=0;var cg=Xh(60);vh(61,60,{11:1,60:1},An);_.S=function(){kc(this.I)};_.T=function(){return this.I.s<0};_.P=function(){var a;return Th(If),If.v+'@'+(a=cl(this)>>>0,a.toString(16))};_.v=false;_.A=false;_.B=false;_.H=false;var hn=0;var If=Xh(61);vh(223,1,ss,Bn);_.Q=function(){jn(this.g)};var yf=Xh(223);vh(224,1,{},Cn);_.Q=function(){$m(this.g)};var zf=Xh(224);vh(225,1,ss,Dn);_.Q=function(){kn(this.g,this.h)};var Af=Xh(225);vh(88,1,ss,En);_.Q=function(){an(this.g,this.h)};_.h=false;var Bf=Xh(88);vh(226,1,ss,Fn);_.Q=function(){pn(this.g)};var Cf=Xh(226);vh(227,1,ss,Gn);_.Q=function(){en(this.g)};var Df=Xh(227);vh(228,1,ss,Hn);_.Q=function(){fn(this.g)};var Ef=Xh(228);vh(229,1,ss,In);_.Q=function(){bn(this.g,this.h)};var Ff=Xh(229);vh(230,1,ss,Jn);_.Q=function(){cn(this.g)};var Gf=Xh(230);vh(231,1,ss,Kn);_.Q=function(){dn(this.g,this.h)};var Hf=Xh(231);vh(203,1,{});var ug=Xh(203);vh(204,203,us,Ro);_.S=function(){kc(this.A)};_.T=function(){return this.A.s<0};_.P=function(){var a;return Th(_f),_f.v+'@'+(a=cl(this)>>>0,a.toString(16))};var po=0;var _f=Xh(204);vh(205,1,ss,So);_.Q=function(){ro(this.g)};var Jf=Xh(205);vh(206,1,ss,To);_.Q=function(){qo(this.g)};var Kf=Xh(206);vh(207,1,{},Uo);_.R=function(){return wo(this.g)};var Lf=Xh(207);vh(208,1,{},Vo);_.R=function(){return Mn(this.g)};var Mf=Xh(208);vh(209,1,ss,Wo);_.Q=function(){so(this.g,this.h)};var Nf=Xh(209);vh(210,1,ss,Xo);_.Q=function(){lo(this.g)};var Of=Xh(210);vh(211,1,ss,Yo);_.Q=function(){go(this.g)};var Pf=Xh(211);vh(212,1,ss,Zo);_.Q=function(){_n(this.g,this.h)};var Qf=Xh(212);vh(213,1,ss,$o);_.Q=function(){fo(this.g,this.h)};var Rf=Xh(213);vh(214,1,ss,_o);_.Q=function(){eo(this.g,this.h)};var Sf=Xh(214);vh(86,1,ss,ap);_.Q=function(){Yn(this.g,(aq(),$p))};var Tf=Xh(86);vh(215,1,ss,bp);_.Q=function(){ao(this.g,this.h)};var Uf=Xh(215);vh(216,1,ss,cp);_.Q=function(){xo(this.g,this.h)};var Vf=Xh(216);vh(217,1,ss,dp);_.Q=function(){$n(this.g,this.h)};var Wf=Xh(217);vh(218,1,ss,ep);_.Q=function(){co(this.g,this.h)};var Xf=Xh(218);vh(219,1,ss,fp);_.Q=function(){io(this.g)};var Yf=Xh(219);vh(220,1,ss,gp);_.Q=function(){yo(this.g,this.h)};var Zf=Xh(220);vh(221,1,ss,hp);_.Q=function(){zo(this.g,this.h)};var $f=Xh(221);vh(147,1,{},ip);_.handleEvent=function(a){Om(this.g)};var ag=Xh(147);vh(327,$wnd.Function,{},jp);_._=ut;vh(328,$wnd.Function,{},kp);_._=ut;vh(329,$wnd.Function,{},lp);_.bb=function(a){return Wm(this.g,this.h,a)};_.h=0;vh(330,$wnd.Function,{},mp);_.bb=function(a){return Xm(this.g,this.h,a)};_.h=0;vh(331,$wnd.Function,{},np);_._=function(a,b,c){return Ym(this.g,a)};vh(333,$wnd.Function,{},op);_.eb=function(a){Zm(this.g)};vh(332,$wnd.Function,{},pp);_._=function(a,b,c){return gn(a)};vh(272,$wnd.Function,{},qp);_._=function(a,b,c){return v('live',a.readyState)&&a.stop(),null};vh(187,1,{},rp);_.Tb=function(){return $wnd.goog.global.globalThis.navigator.mediaDevices.getUserMedia(Gh(Fh({}),Hh(Ih({},Dh(Ch(Eh({},160),640),1280)),Dh(Ch(Eh({},120),360),720))))};var dg=Xh(187);vh(319,$wnd.Function,{},sp);_.eb=function(a){Co(this.g,a)};vh(191,1,{},tp);_.U=vt;var eg=Xh(191);vh(326,$wnd.Function,{},up);_.fb=function(a){Go(this.g,a)};vh(196,1,{},vp);_.U=vt;var fg=Xh(196);vh(188,1,{},wp);_.U=wt;var gg=Xh(188);vh(189,1,{},xp);_.Tb=function(){return $wnd.goog.global.globalThis.navigator.mediaDevices.getDisplayMedia()};var hg=Xh(189);vh(190,1,{},yp);_.U=wt;var ig=Xh(190);vh(312,$wnd.Function,{},zp);_.eb=function(a){Fo(this.g,a)};vh(313,$wnd.Function,{},Ap);_.gb=function(a){Eo(this.g,a)};vh(314,$wnd.Function,{},Bp);_.cb=function(a){Bo(this.g,a)};vh(315,$wnd.Function,{},Cp);_.eb=function(a){Do(this.g,a)};vh(317,$wnd.Function,{},Dp);_.hb=function(a){bo(this.g,a)};vh(318,$wnd.Function,{},Ep);_.ib=function(a){Ho(this.g,a)};vh(23,16,{4:1,20:1,16:1,23:1},Lp);var Fp,Gp,Hp,Ip,Jp;var jg=Yh(23,Mp);vh(40,16,{4:1,20:1,16:1,40:1},Rp);var Np,Op,Pp;var kg=Yh(40,Sp);vh(17,16,{4:1,20:1,16:1,17:1},bq);var Tp,Up,Vp,Wp,Xp,Yp,Zp,$p,_p;var lg=Yh(17,cq);vh(320,$wnd.Function,{},dq);_.eb=function(a){Nn(this.g)};vh(241,$wnd.Function,{},eq);_._=function(a,b,c){return On(this.g,this.h,a)};vh(310,$wnd.Function,{},fq);_._=function(a,b,c){return Pn(this.g,a)};vh(325,$wnd.Function,{},gq);_.ab=function(a,b,c){return mo(this.g,a)};vh(269,$wnd.Function,{},hq);_.bb=function(a){return Qn(this.g,a)};vh(270,$wnd.Function,{},iq);_.bb=function(a){return Rn(this.g)};vh(271,$wnd.Function,{},jq);_.bb=function(a){return $wnd.goog.global.globalThis.console.log('Offer error: ',a),null};vh(321,$wnd.Function,{},kq);_._=function(a,b,c){return Sn(this.g,a)};vh(192,1,{},lq);_.Sb=function(a){return Tn(this.g,a)};var mg=Xh(192);vh(193,1,{},mq);_.U=function(a){};var ng=Xh(193);vh(194,1,{},nq);_.Tb=function(){return $wnd.Promise.resolve(this.g)};var og=Xh(194);vh(195,1,{},oq);_.Sb=function(a){return Un(this.g,a)};var pg=Xh(195);vh(197,1,{},pq);_.Sb=function(a){return no(this.g,a)};var qg=Xh(197);vh(322,$wnd.Function,{},qq);_.bb=function(a){return Vn(this.g,a)};vh(323,$wnd.Function,{},rq);_.bb=function(a){return Wn(this.g)};vh(324,$wnd.Function,{},sq);_.bb=function(a){return this.g.log('Answer error: ',a),null};vh(198,1,ss,tq);_.Q=function(){Xn(this.g,this.h)};var rg=Xh(198);vh(199,1,ss,uq);_.Q=function(){jo(this.g,nl(Ps,'reject_access','id',this.h.g))};var sg=Xh(199);vh(200,1,{},vq);_.Sb=function(a){return oo(this.g,a)};var tg=Xh(200);vh(129,1,{});var wg=Xh(129);vh(93,1,{},wq);var vg=Xh(93);vh(130,129,{});_.j=0;var Vg=Xh(130);vh(131,130,us,Cq);_.S=st;_.T=tt;_.P=function(){var a;return Th(Bg),Bg.v+'@'+(a=cl(this)>>>0,a.toString(16))};var Aq=0;var Bg=Xh(131);vh(132,1,ss,Dq);_.Q=function(){fb(this.g.l)};var xg=Xh(132);vh(133,1,ss,Eq);_.Q=function(){sb(this.g.g)};var yg=Xh(133);vh(135,1,{},Fq);_.R=function(){return yq(this.g)};var zg=Xh(135);vh(134,1,{},Gq);_.Q=function(){zq(this.g)};var Ag=Xh(134);vh(146,1,{});var eh=Xh(146);vh(176,146,{});_.l=0;var Xg=Xh(176);vh(177,176,us,Xq);_.S=function(){kc(this.i)};_.T=function(){return this.i.s<0};_.P=function(){var a;return Th(Lg),Lg.v+'@'+(a=cl(this)>>>0,a.toString(16))};var Tq=0;var Lg=Xh(177);vh(178,1,ss,Yq);_.Q=function(){fb(this.g.u)};var Cg=Xh(178);vh(179,1,ss,Zq);_.Q=function(){Uq(this.g)};var Dg=Xh(179);vh(181,1,{},$q);_.Q=function(){Mq(this.g)};var Eg=Xh(181);vh(182,1,{},_q);_.Q=function(){Nq(this.g)};var Fg=Xh(182);vh(184,1,ss,ar);_.Q=function(){kc(this.g.i)};var Gg=Xh(184);vh(185,1,{},br);_.R=function(){return Rq(this.g)};var Hg=Xh(185);vh(186,1,ss,cr);_.Q=xt;var Ig=Xh(186);vh(180,1,{},dr);_.R=function(){return Rh(),$wnd.goog.global.globalThis.document.fullscreen?true:false};var Jg=Xh(180);vh(183,1,{},er);_.Q=function(){Sq(this.g)};var Kg=Xh(183);vh(259,1,{});var hh=Xh(259);vh(169,259,{});_.m=0;var Zg=Xh(169);vh(170,169,us,or);_.S=function(){kc(this.j)};_.T=function(){return this.j.s<0};_.P=function(){var a;return Th(Rg),Rg.v+'@'+(a=cl(this)>>>0,a.toString(16))};var kr=0;var Rg=Xh(170);vh(171,1,ss,pr);_.Q=function(){lr(this.g)};var Mg=Xh(171);vh(173,1,ss,qr);_.Q=function(){kc(this.g.j)};var Ng=Xh(173);vh(174,1,ss,rr);_.Q=function(){mr(this.g,this.h)};var Og=Xh(174);vh(175,1,{},sr);_.R=function(){return ir(this.g)};var Pg=Xh(175);vh(172,1,{},tr);_.Q=function(){jr(this.g)};var Qg=Xh(172);vh(201,1,{});var jh=Xh(201);vh(232,201,{});var _g=Xh(232);vh(233,232,us,yr);_.S=function(){kc(this.g)};_.T=function(){return this.g.s<0};_.P=function(){var a;return Th(Tg),Tg.v+'@'+(a=cl(this)>>>0,a.toString(16))};var xr=0;var Tg=Xh(233);vh(234,1,ss,zr);_.Q=function(){kc(this.g.g)};var Sg=Xh(234);vh(294,$wnd.Function,{},Ar);_.Xb=function(a){return new Dr(a)};var Br;vh(115,$wnd.React.Component,{},Dr);uh(sh[1],_);_.componentWillUnmount=function(){xq(this.g)};_.render=function(){return Bq(this.g)};_.shouldComponentUpdate=function(a){return 1==this.g.j};var Ug=Xh(115);vh(299,$wnd.Function,{},Er);_.Xb=function(a){return new Hr(a)};var Fr;vh(156,$wnd.React.Component,{},Hr);uh(sh[1],_);_.componentWillUnmount=function(){gb(this.g)&&Qq(this.g)};_.render=function(){return gb(this.g)?Vq(this.g):null};_.shouldComponentUpdate=function(a){return gb(this.g)&&1==this.g.l};var Wg=Xh(156);vh(296,$wnd.Function,{},Ir);_.Xb=function(a){return new Lr(a)};var Jr;vh(154,$wnd.React.Component,{},Lr);uh(sh[1],_);_.componentWillUnmount=function(){gb(this.g)&&hr(this.g)};_.render=function(){return gb(this.g)?nr(this.g):null};_.shouldComponentUpdate=function(a){return gb(this.g)&&1==this.g.m};var Yg=Xh(154);vh(334,$wnd.Function,{},Mr);_.Xb=function(a){return new Pr(a)};var Nr;vh(222,$wnd.React.Component,{},Pr);uh(sh[1],_);_.componentWillUnmount=function(){gb(this.g)&&kc(this.g.g)};_.render=function(){return gb(this.g)?vr(this.g):null};_.shouldComponentUpdate=function(a){return gb(this.g)&&wr(this.g,a)};var $g=Xh(222);vh(306,$wnd.Function,{},Qr);_.Vb=function(a){a.preventDefault()};vh(267,$wnd.Function,{},Rr);_.Vb=function(a){Pq(this.g,a)};vh(157,1,{},Sr);_.handleEvent=function(a){Wq(this.g)};var ah=Xh(157);vh(300,$wnd.Function,{},Tr);_.U=function(a){Hq(this.g,a)};vh(308,$wnd.Function,{},Ur);_.Wb=function(a){Iq(this.g,this.h,a)};vh(268,$wnd.Function,{},Vr);_.Vb=function(a){Jq(this.g,a)};vh(158,1,{},Wr);_.rb=function(a){return ns(os(new ps,a),'video-list-item')};var bh=Xh(158);vh(301,$wnd.Function,{},Xr);_.Wb=function(a){Qo(this.g.u)};vh(302,$wnd.Function,{},Yr);_.Wb=function(a){xn(this.g)};vh(303,$wnd.Function,{},Zr);_.Wb=function(a){zn(this.g)};vh(304,$wnd.Function,{},$r);_.Wb=function(a){Kq(this.g)};vh(305,$wnd.Function,{},_r);_.Wb=function(a){Ao(this.g.u)};vh(307,$wnd.Function,{},as);_.Wb=function(a){Lq(this.g,this.h,a)};vh(145,1,{},es);var dh=Xh(145);vh(297,$wnd.Function,{},fs);_.Vb=function(a){fr(this.g,a)};vh(155,1,{},gs);_.rb=function(a){return ul('a',Dl(yl(Al(new $wnd.Object,a),ed(_c(me,1),ts,2,6,['recent-room'])),'#'+a),[a])};var fh=Xh(155);vh(298,$wnd.Function,{},hs);_.Vb=function(a){var b;gr(this.g,pi((b=a.target,b).value))};vh(144,1,{},ks);var gh=Xh(144);vh(335,$wnd.Function,{},ls);_.U=function(a){ur(this.g,a)};vh(85,1,{},ps);var ih=Xh(85);var ud=Zh('D');var qs=(Gc(),Jc);var gwtOnLoad=gwtOnLoad=qh;oh(Bh);rh('permProps',[[]]);if (vchat) vchat.onScriptLoad(gwtOnLoad);})();