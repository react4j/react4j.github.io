function vchat(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='vchat',tb='__gwt_marker_vchat',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='8DC8E377610070692E0237A9C280A905',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};vchat.onScriptLoad=function(a){vchat=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
vchat();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '8DC8E377610070692E0237A9C280A905';function v(){}
function kh(){}
function gh(){}
function gi(){}
function Lb(){}
function Sc(){}
function Zc(){}
function Hj(){}
function bk(){}
function nk(){}
function sk(){}
function Wk(){}
function Ul(){}
function om(){}
function op(){}
function ip(){}
function jp(){}
function kp(){}
function sp(){}
function wp(){}
function Ap(){}
function Gp(){}
function Ip(){}
function rq(){}
function uq(){}
function yq(){}
function Cq(){}
function Eq(){}
function Nq(){}
function Xc(a){Wc()}
function Bh(){Bh=gh}
function M(a){this.g=a}
function N(a){this.g=a}
function O(a){this.g=a}
function db(a){this.g=a}
function qb(a){this.g=a}
function Db(a){this.g=a}
function Eb(a){this.g=a}
function Fb(a){this.g=a}
function Gb(a){this.g=a}
function pc(a){this.g=a}
function zh(a){this.g=a}
function Sh(a){this.g=a}
function vi(a){this.g=a}
function Di(a){this.g=a}
function Ei(a){this.g=a}
function Bi(a){this.j=a}
function Si(a){this.i=a}
function ck(a){this.g=a}
function uk(a){this.g=a}
function dm(a){this.g=a}
function lm(a){this.g=a}
function mm(a){this.g=a}
function nm(a){this.g=a}
function pm(a){this.g=a}
function Nm(a){this.g=a}
function Om(a){this.g=a}
function Sm(a){this.g=a}
function _m(a){this.g=a}
function an(a){this.g=a}
function bn(a){this.g=a}
function cn(a){this.g=a}
function pn(a){this.g=a}
function qn(a){this.g=a}
function rn(a){this.g=a}
function sn(a){this.g=a}
function tn(a){this.g=a}
function En(a){this.g=a}
function Fn(a){this.g=a}
function Gn(a){this.g=a}
function In(a){this.g=a}
function Jn(a){this.g=a}
function Pn(a){this.g=a}
function Po(a){this.g=a}
function Oo(a){this.g=a}
function Qo(a){this.g=a}
function Ro(a){this.g=a}
function To(a){this.g=a}
function Uo(a){this.g=a}
function Xo(a){this.g=a}
function ap(a){this.g=a}
function dp(a){this.g=a}
function gp(a){this.g=a}
function hp(a){this.g=a}
function Bp(a){this.g=a}
function Cp(a){this.g=a}
function Dp(a){this.g=a}
function Ep(a){this.g=a}
function Fp(a){this.g=a}
function Hp(a){this.g=a}
function Jp(a){this.g=a}
function Kp(a){this.g=a}
function Lp(a){this.g=a}
function Mp(a){this.g=a}
function Np(a){this.g=a}
function Op(a){this.g=a}
function Pp(a){this.g=a}
function pq(a){this.g=a}
function qq(a){this.g=a}
function sq(a){this.g=a}
function tq(a){this.g=a}
function vq(a){this.g=a}
function wq(a){this.g=a}
function xq(a){this.g=a}
function Bq(a){this.g=a}
function Dq(a){this.g=a}
function Hq(a){this.g=a}
function Mq(a){this.g=a}
function Oq(a){this.g=a}
function Tq(a){this.g=a}
function rk(a,b){a.g=b}
function wb(a,b){a.h=b}
function Pk(a,b){a.key=b}
function Mk(a,b){Lk(a,b)}
function Qi(){Gi(this)}
function Pr(){Ai(this)}
function Vr(){jc(this.h)}
function Or(a){xj(this,a)}
function Tr(a){Rj(this,a)}
function kb(a){bc((Q(),a))}
function lb(a){cc((Q(),a))}
function ob(a){dc((Q(),a))}
function G(a){--a.l;K(a)}
function kc(a){!!a&&a.P()}
function Xg(a){return a.l}
function Xr(){rb(this.g.g)}
function Yr(){jc(this.g.j)}
function fj(){this.g=oj()}
function tj(){this.g=oj()}
function _i(){this.g=new Yi}
function Q(){Q=gh;P=new L}
function kj(){kj=gh;jj=mj()}
function Qh(){vc.call(this)}
function hi(){vc.call(this)}
function Mr(){return this.g}
function Rr(){return this.h}
function $r(a){co(this.g,a)}
function _r(a){bo(this.g,a)}
function as(a){Qn(this.g,a)}
function tk(a,b){mk(a.g,b)}
function J(a,b){Tb(a.m,b.m)}
function ic(a,b,c){ri(a.l,b,c)}
function R(a,b){V(a);S(a,b)}
function sc(a,b){a.l=b;rc(a,b)}
function Um(a){a.j=2;jc(a.h)}
function wn(a){a.m=2;jc(a.j)}
function eb(a){ld(a,12)&&a.R()}
function Ah(a){wc.call(this,a)}
function ii(a){wc.call(this,a)}
function fi(a){zh.call(this,a)}
function ei(){zh.call(this,'')}
function Nr(){return Dk(this)}
function Ki(a,b){return a.g[b]}
function Wj(a,b,c){b.T(a.g[c])}
function _l(a,b,c){ic(a.h,b,c)}
function Dm(a,b,c){ic(a.G,b,c)}
function zk(a,b){a.splice(b,1)}
function Ym(a){eb(a.m);eb(a.l)}
function qo(a){eb(a.B);eb(a.J)}
function An(a){rb(a.g);gb(a.h)}
function Ak(a,b){return ed(a,b)}
function $c(a,b){return Kh(a,b)}
function Qr(){return ti(this.g)}
function Wr(){return this.h.s<0}
function vc(){qc(this);this.Z()}
function yc(){yc=gh;xc=new v}
function Pc(){Pc=gh;Oc=new Sc}
function Fc(){Fc=gh;!!(Wc(),Vc)}
function $g(){Yg==null&&(Yg=[])}
function Xb(a){Yb(a);!a.j&&_b(a)}
function Eh(a){Dh(a);return a.v}
function nh(a,b){a.max=b;return a}
function oh(a,b){a.min=b;return a}
function Zk(a,b){a.id=b;return a}
function xh(a,b){a.sdp=b;return a}
function lk(a,b){a.qb(b);return a}
function oj(){kj();return new jj}
function mo(a,b){return u(b.g,a)}
function mk(a,b){rk(a,lk(a.g,b))}
function Rj(a,b){while(a.Lb(b));}
function ok(a,b,c){b.T(a.g.pb(c))}
function F(a,b,c){C(a,new O(c),b)}
function $k(a,b){a.key=b;return a}
function am(a){mb(a.g);return a.i}
function Em(a){mb(a.o);return a.D}
function Fm(a){mb(a.i);return a.A}
function to(a){mb(a.i);return a.G}
function uo(a){mb(a.j);return a.H}
function Io(a){mb(a.l);return a.s}
function Jo(a){mb(a.m);return a.u}
function Mo(a){mb(a.o);return a.v}
function $(a){sb(a.m);return bb(a)}
function yh(a,b){a.type=b;return a}
function Ph(a,b){this.g=a;this.h=b}
function Fi(a,b){this.g=a;this.h=b}
function Jb(a){this.j=a;this.h=100}
function qk(a,b){this.g=a;this.h=b}
function qj(a,b){return a.g.get(b)}
function ti(a){return a.g.h+a.h.h}
function Cj(a){return Dj(a,a.i.h)}
function Ur(){return Th(this.h.j)}
function ai(a){return !a?er:''+a.g}
function hb(a){Q();cc(a);a.l=-2}
function Nc(){Cc!=0&&(Cc=0);Ec=-1}
function Wl(){this.g=Tk((mp(),lp))}
function Vl(a,b){this.g=a;this.h=b}
function Xk(a,b){this.g=a;this.h=b}
function em(a,b){this.g=a;this.h=b}
function Pm(a,b){this.g=a;this.h=b}
function Qm(a,b){this.g=a;this.h=b}
function Rm(a,b){this.g=a;this.h=b}
function Tm(a,b){this.g=a;this.h=b}
function Hn(a,b){this.g=a;this.h=b}
function So(a,b){this.g=a;this.h=b}
function Vo(a,b){this.g=a;this.h=b}
function Wo(a,b){this.g=a;this.h=b}
function Yo(a,b){this.g=a;this.h=b}
function Zo(a,b){this.g=a;this.h=b}
function $o(a,b){this.g=a;this.h=b}
function _o(a,b){this.g=a;this.h=b}
function bp(a,b){this.g=a;this.h=b}
function cp(a,b){this.g=a;this.h=b}
function ep(a,b){this.g=a;this.h=b}
function fp(a,b){this.g=a;this.h=b}
function Wp(a,b){Ph.call(this,a,b)}
function rl(a,b){Ph.call(this,a,b)}
function Ql(a,b){Ph.call(this,a,b)}
function aq(a,b){Ph.call(this,a,b)}
function mq(a,b){Ph.call(this,a,b)}
function oq(a,b){this.g=a;this.h=b}
function zq(a,b){this.g=a;this.h=b}
function Aq(a,b){this.g=a;this.h=b}
function Fq(a,b){this.g=a;this.h=b}
function Gq(a,b){this.g=a;this.h=b}
function zj(a,b){Aj(a,b,a.i.h,a.i)}
function yj(a,b){Aj(a,b,a.g,a.g.g)}
function no(a,b){return u(b.g,a.g)}
function Sr(a){return pi(this.g,a)}
function Iq(a){return Jq(new Lq,a)}
function Pq(a){return Jq(new Sq,a)}
function Uq(a){return Wq(new Xq,a)}
function xk(a,b,c){a.splice(b,0,c)}
function ll(a,b){a.value=b;return a}
function al(a,b){a.href=b;return a}
function mh(a,b){a.ideal=b;return a}
function qh(a,b){a.video=b;return a}
function sh(a,b){a.width=b;return a}
function rh(a,b){a.height=b;return a}
function ci(a,b){a.g+=''+b;return a}
function ph(a){a.audio=true;return a}
function rd(a){return a==null?null:a}
function Jj(a){return a!=null?B(a):0}
function oi(a){return !a?null:a.Hb()}
function Zb(a){return !a.j?a:Zb(a.j)}
function u(a,b){return rd(a)===rd(b)}
function xo(a,b){jo(a,b,new zq(a,b))}
function yo(a,b){jo(a,b,new Aq(a,b))}
function Lq(){this.g=Tk((qp(),pp))}
function Sq(){this.g=Tk((up(),tp))}
function Xq(){this.g=Tk((yp(),xp))}
function pb(a){this.i=new Qi;this.h=a}
function Mc(a){$wnd.clearTimeout(a)}
function Gi(a){a.g=ad(ie,_q,1,0,5,1)}
function vb(a){Q();ub(a);yb(a,2,true)}
function H(a,b,c){D(a,new N(b),c,null)}
function I(a,b,c){return D(a,c,2048,b)}
function Lk(a,b){for(var c in a){b(c)}}
function Wh(a,b){return a.charCodeAt(b)}
function $i(a,b){return si(a.g,b)!=null}
function uh(a,b){a.candidate=b;return a}
function gl(a,b){a.onChange=b;return a}
function bl(a,b){a.onClick=b;return a}
function ml(a,b){a.htmlFor=b;return a}
function dl(a,b){a.onSubmit=b;return a}
function fl(a,b){a.maxLength=b;return a}
function Jq(a,b){Ok(a.g,'a',b);return a}
function yk(a,b,c){wk(c,0,a,b,c.length)}
function ld(a,b){return a!=null&&jd(a,b)}
function Dk(a){return a.$H||(a.$H=++Ck)}
function jl(a){return a.required=true,a}
function el(a){return a.autoFocus=true,a}
function nd(a){return typeof a==='number'}
function qd(a){return typeof a==='string'}
function fb(a){return !(ld(a,12)&&a.S())}
function hc(a){return ld(a,30)?a.U():null}
function mb(a){var b;$b((Q(),b=Vb,b),a)}
function _j(){ak.call(this,'|','','')}
function wc(a){this.o=a;qc(this);this.Z()}
function W(){this.g=ad(ie,_q,1,100,5,1)}
function Yi(){this.g=new fj;this.h=new tj}
function Hk(){Hk=gh;Ek=new v;Gk=new v}
function Bk(a){if(!a){throw Xg(new Qh)}}
function Dh(a){if(a.v!=null){return}Mh(a)}
function Vq(a,b){Ok(a.g,'b',b);return a.g}
function th(a,b){a.iceServers=b;return a}
function il(a,b){a.placeholder=b;return a}
function Ok(a,b,c){a.props[b]=c;return a}
function hl(a){a.pattern='^\\w+$';return a}
function yi(a){a.i.Ab();a.i=null;a.h=wi(a)}
function Ai(a){a.j.Eb(a.i);a.h=a.i;a.i=-1}
function Mb(a){2==(3&a.g)||(a.g=-4&a.g|2)}
function ab(a){4==(a.m.i&7)&&yb(a.m,5,true)}
function Ho(a){H((Q(),Q(),P),new ap(a),Hr)}
function Fo(a){H((Q(),Q(),P),new To(a),qr)}
function jm(a){H((Q(),Q(),P),new pm(a),qr)}
function Lm(a){H((Q(),Q(),P),new Sm(a),qr)}
function nc(a){Q();Vb?a.P():H((null,P),a,0)}
function hj(a,b){var c;c=a[jr];c.call(a,b)}
function hn(a,b){b.preventDefault();Ho(a.o)}
function kk(a,b){fk.call(this,a);this.g=b}
function Zh(a,b,c){return a.substr(b,c-b)}
function Gc(a,b,c){return a.apply(b,c);var d}
function pd(a,b){return a&&b&&a instanceof b}
function md(a){return typeof a==='boolean'}
function Ib(a){while(true){if(!Hb(a)){break}}}
function xj(a,b){while(a.yb()){tk(b,a.zb())}}
function wj(a,b,c){this.g=a;this.h=b;this.i=c}
function Gj(a,b,c){this.j=a;this.h=c;this.g=b}
function Sb(a,b,c){c.g=-4&c.g|1;R(a.g[b],c)}
function Tb(a,b){Sb(a,((b.g&229376)>>15)-1,b)}
function bm(a,b){H((Q(),Q(),P),new em(a,b),qr)}
function so(a,b){H((Q(),Q(),P),new bp(a,b),Hr)}
function zo(a,b){H((Q(),Q(),P),new $o(a,b),Hr)}
function Ao(a,b){H((Q(),Q(),P),new Vo(a,b),Hr)}
function Bo(a,b){H((Q(),Q(),P),new Yo(a,b),Hr)}
function Co(a,b){H((Q(),Q(),P),new _o(a,b),Hr)}
function Do(a,b){H((Q(),Q(),P),new Zo(a,b),Hr)}
function Eo(a,b){H((Q(),Q(),P),new Wo(a,b),Hr)}
function Go(a,b){H((Q(),Q(),P),new cp(a,b),Hr)}
function Hm(a){H((Q(),Q(),P),new Qm(a,true),qr)}
function qm(a){Km(a,null);Jm(a,null);Im(a,null)}
function qc(a){a.u&&a.l!==cr&&a.Z();return a}
function vh(a,b){a.sdpMLineIndex=b;return a}
function Hi(a,b){a.g[a.g.length]=b;return true}
function Tn(a,b,c){a.D.addTrack(c,b);return null}
function Hh(a){var b;b=Gh(a);Oh(a,b);return b}
function Jh(a){var b;b=Gh(a);b.u=a;b.l=1;return b}
function gk(a,b){var c;return ik(a,(c=new Qi,c))}
function Wc(){Wc=gh;var a;!Yc();a=new Zc;Vc=a}
function Vh(){Vh=gh;Uh=ad(fe,_q,35,256,0,1)}
function Uj(a,b){while(a.i<a.j){Wj(a,b,a.i++)}}
function dn(a,b,c){c.preventDefault();so(a.o,b)}
function en(a,b,c){c.preventDefault();Go(a.o,b)}
function pi(a,b){return qd(b)?qi(a,b):!!cj(a.g,b)}
function Ti(a,b){return Sj(b,a.length),new Xj(a,b)}
function pj(a,b){return !(a.g.get(b)===undefined)}
function vn(a,b){nc(new Hn(a,b.length==0?null:b))}
function tb(a,b){jb(b,a);b.i.g.length>0||(b.g=4)}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Mi(a,b){var c;c=a.g[b];zk(a.g,b);return c}
function Kb(a){if(!a.g){a.g=true;G((Q(),Q(),P))}}
function Yj(a){if(!a.j){a.j=a.h.ob();a.i=a.h.tb()}}
function Wm(a){if(0==a.j){a.j=1;a.i.forceUpdate()}}
function yn(a){if(0==a.m){a.m=1;a.l.forceUpdate()}}
function Kk(){if(Fk==256){Ek=Gk;Gk=new v;Fk=0}++Fk}
function cd(a){return Array.isArray(a)&&a.Vb===kh}
function kd(a){return !Array.isArray(a)&&a.Vb===kh}
function Ui(a){return new kk(null,Ti(a,a.length))}
function Zm(a){return I((Q(),Q(),P),a.g,new bn(a))}
function nn(a){return I((Q(),Q(),P),a.g,new sn(a))}
function Cn(a){return I((Q(),Q(),P),a.g,new In(a))}
function U(a){return a.i?a.g.length-a.h+a.j:a.j-a.h}
function Fj(a){a.i=a.h;a.h=a.h.g;++a.g;return a.i.i}
function Zi(a,b){var c;c=ri(a.g,b,a);return c==null}
function vk(a,b){var c;c=a.slice(0,b);return ed(c,a)}
function ro(a,b){var c;c=a.s;if(b!=c){a.s=b;lb(a.l)}}
function Jm(a,b){var c;c=a.C;if(b!=c){a.C=b;lb(a.l)}}
function Cm(a,b){var c;c=a.A;if(b!=c){a.A=b;lb(a.i)}}
function Gm(a,b){var c;c=a.v;if(b!=c){a.v=b;lb(a.h)}}
function Im(a,b){var c;c=a.B;if(b!=c){a.B=b;lb(a.j)}}
function Bn(a,b){var c;c=a.i;if(b!=c){a.i=b;lb(a.h)}}
function Pi(a,b,c){var d;d=a.g[b];a.g[b]=c;return d}
function Nk(a,b,c,d){var e;e={};e[a]=b;e[c]=d;return e}
function bi(a,b){a.g+=String.fromCharCode(b);return a}
function cl(a,b){a.type=b.g!=null?b.g:''+b.h;return a}
function si(a,b){return b==null?ej(a.g,null):sj(a.h,b)}
function qi(a,b){return b==null?!!cj(a.g,null):pj(a.h,b)}
function Xi(a,b){return rd(a)===rd(b)||a!=null&&w(a,b)}
function Tj(a,b){this.j=a;this.i=(b&64)!=0?b|16384:b}
function Zj(a,b){this.h=a;this.g=(b&4096)==0?b|64|16384:b}
function Xj(a,b){this.i=0;this.j=b;this.h=17488;this.g=a}
function Ci(a,b){this.g=a;Bi.call(this,a);a.tb();this.h=b}
function ec(a,b){this.g=(Q(),Q(),P).h++;this.j=a;this.l=b}
function fk(a){if(!a){this.h=null;new Qi}else{this.h=a}}
function dk(a){if(!a.h){ek(a);a.i=true}else{dk(a.h)}}
function hk(a,b){ek(a);return new kk(a,new pk(b,a.g))}
function Cb(a){Ab.call(this,a,new Db(a),null,304611328)}
function nb(a){var b;Q();!!Vb&&!!Vb.l&&$b((b=Vb,b),a)}
function Ih(a,b){var c;c=Gh(a);Oh(a,c);c.l=b?8:0;return c}
function xi(a){var b;a.i=a.g;b=a.g.zb();a.h=wi(a);return b}
function fc(a,b){Vb=new ec(Vb,b);a.j=false;Wb(Vb);return Vb}
function ui(a,b){if(ld(b,42)){return mi(a.g,b)}return false}
function Lh(a){if(a.nb()){return null}var b=a.u;return bh[b]}
function Wb(a){if(a.l){2==(a.l.i&7)||yb(a.l,4,true);ub(a.l)}}
function Lc(a){Fc();$wnd.setTimeout(function(){throw a},0)}
function sl(){ql();return dd($c(ff,1),_q,38,0,[nl,ol,pl])}
function bq(){_p();return dd($c(Eg,1),_q,39,0,[$p,Zp,Yp])}
function ni(a,b){return b===a?'(this Map)':b==null?er:jh(b)}
function tc(a,b){var c;c=Eh(a.Tb);return b==null?c:c+': '+b}
function Kh(a,b){var c=a.g=a.g||[];return c[b]||(c[b]=a.ib(b))}
function bj(a,b){var c;c=a.g.get(b);return c==null?new Array:c}
function Kn(a,b){var c;c=a.i;!(!!c&&c.G.s<0)&&nc(new Pm(c,b))}
function fn(a,b){var c;nc(new So(a.o,$h((c=b.target,c).value)))}
function eh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ih(a){function b(){}
;b.prototype=a||{};return new b}
function wh(a){a.urls='stun:stun.l.google.com:19302';return a}
function ek(a){if(a.h){ek(a.h)}else if(a.i){throw Xg(new Rh)}}
function L(){this.m=new Ub;this.g=new Jb(this.m);new M(this.g)}
function pk(a,b){Tj.call(this,b.Kb(),b.Jb()&-6);this.g=a;this.h=b}
function cj(a,b){var c;return aj(b,bj(a,b==null?0:(c=B(b),c|0)))}
function Xp(){Vp();return dd($c(Dg,1),_q,23,0,[Sp,Up,Rp,Qp,Tp])}
function mp(){mp=gh;var a;lp=(a=hh(kp.prototype.Sb,kp,[]),a)}
function qp(){qp=gh;var a;pp=(a=hh(op.prototype.Sb,op,[]),a)}
function up(){up=gh;var a;tp=(a=hh(sp.prototype.Sb,sp,[]),a)}
function yp(){yp=gh;var a;xp=(a=hh(wp.prototype.Sb,wp,[]),a)}
function tm(a,b){b.onended=hh(hp.prototype.cb,hp,[a]);return null}
function Vj(a,b){if(a.i<a.j){Wj(a,b,a.i++);return true}return false}
function mc(a){kc(a.o);!!a.l&&lc(a);eb(a.g);eb(a.i);kc(a.h);kc(a.m)}
function Ko(a,b){var c;c=a.u;if(!(b==c||!!b&&b==c)){a.u=b;lb(a.m)}}
function Lo(a,b){var c;c=a.v;if(!(b==c||!!b&&b==c)){a.v=b;lb(a.o)}}
function S(a,b){a.g[a.j]=b;++a.j;if(a.j>=a.g.length){a.j=0;a.i=true}}
function gj(a){this.l=a;this.h=this.l.g.entries();this.g=new Array}
function Ri(a){Gi(this);yk(this.g,0,li(a,ad(ie,_q,1,ti(a.g),5,1)))}
function po(a){Y(a.g);Y(a.h);gb(a.o);gb(a.m);gb(a.l);gb(a.j);gb(a.i)}
function Sn(a){var b;b=new Qi;Fm(a.J)&&Hi(b,a.J);Ii(b,a.I);return b}
function uc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function sm(a,b,c){a.J==b&&H((Q(),Q(),P),new Tm(a,c),qr);return null}
function Zr(a,b,c){return u('live',a.readyState)&&a.stop(),null}
function Vk(a,b,c){!u(c,'key')&&!u(c,'ref')&&(a[c]=b[c],undefined)}
function Jc(a,b,c){var d;d=Hc();try{return Gc(a,b,c)}finally{Kc(d)}}
function ib(a,b){var c,d;Hi(a.i,b);d=(c=b.i&7,c>3?c:4);a.g>d&&(a.g=d)}
function Aj(a,b,c,d){var e;e=new Hj;e.i=b;e.h=c;e.g=d;d.h=c.g=e;++a.h}
function uj(a){this.j=a;this.h=this.j.g.entries();this.g=this.h.next()}
function np(a){$wnd.React.Component.call(this,a);this.g=new $m(this)}
function rp(a){$wnd.React.Component.call(this,a);this.g=new on(this)}
function vp(a){$wnd.React.Component.call(this,a);this.g=new Dn(this)}
function zp(a){$wnd.React.Component.call(this,a);this.g=new On(this)}
function ak(a,b,c){this.h=a;this.j=b;this.l=c;this.i=this.j+(''+this.l)}
function Qn(a,b){b.getTracks().forEach(hh(oq.prototype._,oq,[a,b]))}
function jk(a,b){var c;c=gk(a,new ck(new bk));return c.wb(b.Mb(c.tb()))}
function ik(a,b){var c;dk(a);c=new sk;c.g=b;a.g.xb(new uk(c));return c.g}
function $j(a,b){!a.g?(a.g=new fi(a.j)):ci(a.g,a.h);ci(a.g,b);return a}
function Vn(a){lo(a,Nk(Fr,'offer',Gr,a.D.localDescription));return null}
function Yn(a){lo(a,Nk(Fr,'answer',Gr,a.D.localDescription));return null}
function Xn(a,b){return a.D.setLocalDescription(xh(yh({},b.type),b.sdp))}
function Un(a,b){return a.D.setLocalDescription(yh(xh({},b.sdp),b.type))}
function sd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Kc(a){a&&Rc((Pc(),Oc));--Cc;if(a){if(Ec!=-1){Mc(Ec);Ec=-1}}}
function Ob(b){try{sb(b.h.g)}catch(a){a=Wg(a);if(!ld(a,8))throw Xg(a)}}
function gb(a){if(-2!=a.l){H((Q(),Q(),P),new qb(a),0);!!a.h&&rb(a.h)}}
function jo(a,b,c){if(null!=a.K&&Ni(a.H,b)){Oi(a.H,new Bq(b));lb(a.j);c.P()}}
function ed(a,b){_c(b)!=10&&dd(A(b),b.Ub,b.__elementTypeId$,_c(b),a);return a}
function ad(a,b,c,d,e,f){var g;g=bd(e,d);e!=10&&dd($c(a,f),b,c,e,g);return g}
function Rb(a){var b,c;b=0;for(c=0;c<a.g.length;c++){b+=U(a.g[c])}return b}
function Li(a,b,c){for(;c<a.g.length;++c){if(Xi(b,a.g[c])){return c}}return -1}
function vj(a){if(a.g.i!=a.i){return qj(a.g,a.h.value[0])}return a.h.value[1]}
function Bc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ic(b){Fc();return function(){return Jc(b,this,arguments);var a}}
function nq(){lq();return dd($c(Fg,1),_q,17,0,[kq,dq,iq,hq,gq,cq,jq,fq,eq])}
function ri(a,b,c){return qd(b)?b==null?dj(a.g,null,c):rj(a.h,b,c):dj(a.g,b,c)}
function Ji(a,b){var c,d,e,f;for(d=a.g,e=0,f=d.length;e<f;++e){c=d[e];b.T(c)}}
function Ub(){var a;this.g=ad(yd,_q,56,5,0,1);for(a=0;a<5;a++){this.g[a]=new W}}
function zi(a){this.l=a;this.j=new uj(this.l.h);this.g=this.j;this.h=wi(this)}
function fm(a){$wnd.goog.global.globalThis.addEventListener(rr,a.i,false)}
function gm(a){$wnd.goog.global.globalThis.removeEventListener(rr,a.i,false)}
function K(a){if(a.j&&a.l==0){if(!a.i){a.i=true;try{Ib(a.g)}finally{a.i=false}}}}
function Y(a){if(!a.g){a.g=true;a.v=null;a.h=null;gb(a.l);2==(a.m.i&7)||rb(a.m)}}
function bb(a){if(a.h){if(ld(a.h,10)){throw Xg(a.h)}else{throw Xg(a.h)}}return a.v}
function xb(b){if(b){try{b.P()}catch(a){a=Wg(a);if(ld(a,8)){Q()}else throw Xg(a)}}}
function gc(){var a;try{Xb(Vb);Q()}finally{a=Vb.j;!a&&((Q(),Q(),P).j=true);Vb=Vb.j}}
function Qc(a){var b,c;if(a.g){c=null;do{b=a.g;a.g=null;c=Uc(b,c)}while(a.g);a.g=c}}
function Rc(a){var b,c;if(a.h){c=null;do{b=a.h;a.h=null;c=Uc(b,c)}while(a.h);a.h=c}}
function Bm(a,b){var c;c=a.F;if(!(rd(b)===rd(c)||b!=null&&w(b,c))){a.F=b;lb(a.s)}}
function Km(a,b){var c;c=a.D;if(!(rd(b)===rd(c)||b!=null&&w(b,c))){a.D=b;lb(a.o)}}
function Mn(a,b){var c;c=a.h.props;if(!(c['b']===b['b'])){return true}return false}
function Ni(a,b){var c;c=Li(a,b,0);if(c==-1){return false}zk(a.g,c);return true}
function Wn(a,b){var c;c=new Mm(new tq(b),new uq,true);Hi(a.I,c);Km(c,b);return null}
function Gh(a){var b;b=new Fh;b.v='Class$'+(a?'S'+a:''+b.o);b.h=b.v;b.s=b.v;return b}
function _k(a){a.title='Room code should only contain letters or numbers.';return a}
function ql(){ql=gh;nl=new rl(or,0);ol=new rl('reset',1);pl=new rl('submit',2)}
function _p(){_p=gh;$p=new aq('UNKNOWN',0);Zp=new aq('HOST',1);Yp=new aq('GUEST',2)}
function jc(a){if(a.s>=0){a.s=-2;D((Q(),Q(),P),new N(new pc(a)),67108864,null)}}
function $n(a,b){if(null!=a.K){a.H.g=ad(ie,_q,1,0,5,1);a.K.close();a.K=null;Lo(a,b)}}
function ko(a){if(null!=a.K){lo(a,Nk(Fr,Kr,'message',(mb(a.l),a.s)));Lo(a,(lq(),iq))}}
function $b(a,b){var c;if(a.l){c=a.g;if(b.l!=c){b.l=c;!a.h&&(a.h=new Qi);Hi(a.h,b)}}}
function ac(a,b){var c;if(!a.i){c=Zb(a);!c.i&&(c.i=new Qi);a.i=c.i}b.j=true;a.i.qb(b)}
function Oh(a,b){var c;if(!a){return}b.u=a;var d=Lh(b);if(!d){bh[a]=[b];return}d.Tb=b}
function hh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Dj(a,b){var c;c=b.i;b.g.h=b.h;b.h.g=b.g;b.g=b.h=null;b.i=null;--a.h;return c}
function sj(a,b){var c;c=a.g.get(b);if(c===undefined){++a.i}else{hj(a.g,b);--a.h}return c}
function Wq(a,b){Pk(a.g,(b?Th(b.G.j):null)+(''+(Dh(Ug),Ug.v)));Ok(a.g,'a',b);return a}
function Am(a){rb(a.m);gb(a.h);gb(a.o);gb(a.l);gb(a.j);gb(a.i);gb(a.g);gb(a.u);gb(a.s)}
function ub(a){var b,c;for(c=new Si(a.h);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);b.g=4}}
function Zg(){$g();var a=Yg;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function Rh(){wc.call(this,"Stream already terminated, can't be modified or used")}
function _c(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function od(a){return a!=null&&(typeof a===Zq||typeof a==='function')&&!(a.Vb===kh)}
function ah(a,b){typeof window===Zq&&typeof window['$gwt']===Zq&&(window['$gwt'][a]=b)}
function Pb(a,b){this.h=a;this.g=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function Sj(a,b){if(0>a||a>b){throw Xg(new Ah('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Ln(a){return Rk('video',null,a.j,Nk('autoPlay',true,'className',a.h.props['b']))}
function Tk(a){var b;b=Sk($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Rk(a,b,c,d){var e;e=Sk($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function dd(a,b,c,d,e){e.Tb=a;e.Ub=b;e.Vb=kh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function ki(a,b){var c,d;for(d=b.ob();d.yb();){c=d.zb();if(!a.rb(c)){return false}}return true}
function Vi(a){var b,c,d;d=0;for(c=a.ob();c.yb();){b=c.zb();d=d+(b!=null?B(b):0);d=d|0}return d}
function Wi(a){var b,c,d;d=1;for(c=a.ob();c.yb();){b=c.zb();d=31*d+(b!=null?B(b):0);d=d|0}return d}
function Vm(a){var b,c;a.j=0;Tl();b=(c=Z(a.m.g),c.length==0?Qq(Pq(a.m),a.l):Kq(Iq(a.l),c));return b}
function Wg(a){var b;if(ld(a,8)){return a}b=a&&a.__java$exception;if(!b){b=new Ac(a);Xc(b)}return b}
function wi(a){if(a.g.yb()){return true}if(a.g!=a.j){return false}a.g=new gj(a.l.g);return a.g.yb()}
function wm(a,b){Gm(a,false);Km(a,b);b.getTracks().forEach(hh(gp.prototype._,gp,[a]));a.I.T(b)}
function vo(a){return null==a.K?(Vp(),Tp):(Vp(),dd($c(Dg,1),_q,23,0,[Sp,Up,Rp,Qp,Tp]))[a.K.readyState]}
function A(a){return qd(a)?le:nd(a)?_d:md(a)?Zd:kd(a)?a.Tb:cd(a)?a.Tb:a.Tb||Array.isArray(a)&&$c(Rd,1)||Rd}
function Ac(a){yc();qc(this);this.l=a;rc(this,a);this.o=a==null?er:jh(a);this.g='';this.h=a;this.g=''}
function oc(a,b,c,d){this.j=a;this.l=d?new Yi:null;this.o=b;this.h=c;this.m=null;this.g=null;this.i=null}
function Fh(){this.o=Ch++;this.v=null;this.s=null;this.m=null;this.j=null;this.h=null;this.u=null;this.g=null}
function Ej(){this.g=new Hj;this.i=new Hj;this.g.g=this.i;this.i.h=this.g;this.g.h=this.i.g=null;this.h=0}
function cb(a,b,c){this.i=a;this.o=b;this.s=c;this.v=null;this.u=false;this.m=new Cb(this);this.l=new pb(this.m)}
function cm(){var a,b;Zl.call(this);Q();a=++$l;this.h=new oc(a,null,new dm(this),true);this.g=(b=new pb(null),b)}
function Th(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Vh(),Uh)[b];!c&&(c=Uh[b]=new Sh(a));return c}return new Sh(a)}
function aj(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(Xi(a,c.Gb())){return c}}return null}
function Ii(a,b){var c,d;c=vk(b.g,b.g.length);d=c.length;if(d==0){return false}yk(a.g,a.g.length,c);return true}
function rj(a,b,c){var d;d=a.g.get(b);a.g.set(b,c===undefined?null:c);d===undefined?++a.h:++a.i;return d}
function Kq(a,b){var c;Ok(a.g,'b',b);return c=a.g.props,Pk(a.g,ai(hc(c['a']))+'-'+c['b']+(Dh(Pg),Pg.v)),a.g}
function Qq(a,b){var c;Ok(a.g,'b',b);return c=a.g.props,Pk(a.g,ai(hc(c['a']))+'-'+ai(hc(c['b']))+(Dh(Sg),Sg.v)),a.g}
function Zn(a,b){var c;c=b.g;lo(a,Nk(Fr,'approve_access','id',c));Zi(a.G,c);lb(a.i);H((Q(),Q(),P),new Uo(a),Hr)}
function wo(a,b){$wnd.goog.global.globalThis.console.log('Websocket.open',b);rd(a.K)===rd(b.currentTarget)&&ab(a.g)}
function lh(){var a;a=$wnd.goog.global.globalThis.document.getElementById('app');$wnd.ReactDOM.render((new Wl).g,a,null)}
function jh(a){var b;if(Array.isArray(a)&&a.Vb===kh){return Eh(A(a))+'@'+(b=B(a)>>>0,b.toString(16))}return a.toString()}
function rb(a){if(2<(a.i&7)){D((Q(),Q(),P),new N(new Fb(a)),67108864,null);!!a.g&&Y(a.g);Mb(a.m);a.i=a.i&-8|1}}
function Tl(){if(!Sl){Sl=(++(Q(),Q(),P).l,new Lb);$wnd.Promise.resolve(null).then(hh(Ul.prototype.ab,Ul,[]))}}
function rm(a,b,c){a.J==b?H((Q(),Q(),P),new Rm(a,c),qr):c.getTracks().forEach(hh(jp.prototype._,jp,[]));return null}
function Bb(a,b,c){Ab.call(this,null,a,b,c|(!a?262144:br)|(0==(c&6291456)?!a?2097152:4194304:0)|0|0|0)}
function Nb(a){if(1==(3&a.g)){a.g=-4&a.g|0;0==(a.g&br)?Ob(a):sb(a.h.g);0!=(a.g&524288)&&(2==(3&a.g)||(a.g=-4&a.g|2))}}
function jb(a,b){var c,d;d=a.i;Ni(d,b);!!a.h&&br!=(a.h.i&1835008)&&a.i.g.length<=0&&0==a.h.g.j&&(a.j||ac((Q(),c=Vb,c),a))}
function _b(a){var b;if(a.i){while(!a.i.sb()){b=a.i.Eb(a.i.tb()-1);b.j=false;b.i.g.length>0||(b.h.i&7)>3&&yb(b.h,3,true)}}}
function Qk(a){var b,c;b=Sk($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=(c={},c[nr]=a,c);return b}
function Jk(a){Hk();var b,c,d;c=':'+a;d=Gk[c];if(d!=null){return sd(d)}d=Ek[c];b=d==null?Ik(a):sd(d);Kk();Gk[c]=b;return b}
function Qj(){Nj();var a,b,c;c=Mj+++Date.now();a=sd($wnd.Math.floor(c*lr))&16777215;b=sd(c-a*mr);this.g=a^1502;this.h=b^kr}
function um(a){var b,c,d;c=(mb(a.o),a.D);d=(mb(a.s),a.F);if(null!=c&&null!=d){b=c;rd(b)!==rd(d.srcObject)&&(d.srcObject=b)}}
function Qb(a){var b,c,d;for(b=0;b<a.g.length;b++){d=a.g[b];if(0!=(d.i?d.g.length-d.h+d.j:d.j-d.h)){c=T(d);return c}}return null}
function ji(a,b,c){var d,e;for(e=a.ob();e.yb();){d=e.zb();if(rd(b)===rd(d)||b!=null&&w(b,d)){c&&e.Ab();return true}}return false}
function Hc(){var a;if(Cc!=0){a=Bc();if(a-Dc>2000){Dc=a;Ec=$wnd.setTimeout(Nc,10)}}if(Cc++==0){Qc((Pc(),Oc));return true}return false}
function Bj(a,b){var c,d;if(b>=a.h>>1){d=a.i;for(c=a.h;c>b;--c){d=d.h}}else{d=a.g.g;for(c=0;c<b;++c){d=d.g}}return new Gj(a,b,d)}
function Yl(a,b){ji(a.i,b,true);3==a.i.h&&Cj(a.i);yj(a.i,b);lb(a.g);$wnd.goog.global.globalThis.localStorage.setItem(pr,_h(a.i))}
function bo(a,b){var c;if(rd(b.currentTarget)===rd(a.F)){c=$wnd.goog.global.globalThis.console;c.log('The Data Channel is Closed')}}
function Rl(){Pl();return dd($c(gf,1),_q,9,0,[tl,ul,vl,wl,xl,yl,zl,Al,Bl,Cl,Dl,El,Fl,Gl,Hl,Il,Jl,Kl,Ll,Ml,Nl,Ol])}
function B(a){return qd(a)?Jk(a):nd(a)?sd(a):md(a)?a?1231:1237:kd(a)?a.N():cd(a)?Dk(a):!!a&&!!a.hashCode?a.hashCode():Dk(a)}
function w(a,b){return qd(a)?u(a,b):nd(a)?rd(a)===rd(b):md(a)?rd(a)===rd(b):kd(a)?a.L(b):cd(a)?u(a,b):!!a&&!!a.equals?a.equals(b):rd(a)===rd(b)}
function Nh(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Yc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function xm(a){var b;b=(mb(a.o),a.D);qm(a);H((Q(),Q(),P),new Qm(a,false),qr);null!=b&&b.getTracks().forEach(hh(ip.prototype._,ip,[]))}
function Oj(a,b){var c,d;Bk(b>0);if((b&-b)==b){return sd(b*Pj(a)*4.6566128730773926E-10)}do{c=Pj(a);d=c%b}while(c-d+(b-1)<0);return sd(d)}
function km(){var a;this.i=new dp(this);Q();a=++hm;this.h=new oc(a,null,new lm(this),true);this.g=new cb(new om,new mm(this),new nm(this))}
function ym(a,b){var c;Gm(a,false);if(pd(b,$wnd.DOMException)){c=b;Jm(a,c.name);Im(a,c.message)}else{Jm(a,Eh(A(b)));Im(a,b==null?er:jh(b))}}
function Vp(){Vp=gh;Sp=new Wp('CONNECTING',0);Up=new Wp('OPEN',1);Rp=new Wp('CLOSING',2);Qp=new Wp('CLOSED',3);Tp=new Wp('NOT_REQUESTED',4)}
function lc(a){var b,c,d;for(c=new Si(new Ri(new vi(a.l)));c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.Gb();ld(d,12)&&d.S()||b.Hb().P()}}
function cc(a){var b,c,d;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new Si(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;6!=d&&yb(b,6,true)}}}
function dc(a){var b,c,d;if(a.i.g.length>0&&4==a.g){a.g=5;for(c=new Si(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;4==d&&yb(b,5,true)}}}
function Xl(){var a,b,c;b=new Qj;c=new ei;for(a=0;a<10;a++){bi(c,Wh('abcdefghijklmnopqrstuvwxyz1234567890',$wnd.Math.abs(Oj(b,36))))}return c.g}
function jd(a,b){if(qd(a)){return !!hd[b]}else if(a.Ub){return !!a.Ub[b]}else if(nd(a)){return !!gd[b]}else if(md(a)){return !!fd[b]}return false}
function eo(a,b){$wnd.goog.global.globalThis.console.log('Websocket.error',b);if(rd(a.K)===rd(b.currentTarget)){ab(a.g);Lo(a,(lq(),eq));a.K=null}}
function Yk(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function T(a){var b;if(0==(a.i?a.g.length-a.h+a.j:a.j-a.h)){return null}b=a.g[a.h];a.g[a.h]=null;++a.h;if(a.h>=a.g.length){a.h=0;a.i=false}return b}
function li(a,b){var c,d,e,f;f=a.tb();b.length<f&&(b=Ak(new Array(f),b));e=b;d=a.ob();for(c=0;c<f;++c){e[c]=d.zb()}b.length>f&&(b[f]=null);return b}
function Z(a){a.u?nb(a.l):mb(a.l);if(zb(a.m)){if(a.u&&(Q(),!(!!Vb&&!!Vb.l))){return D((Q(),Q(),P),new db(a),83888128,null)}else{sb(a.m)}}return bb(a)}
function $h(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function $m(a){var b;this.m=new km;this.l=new cm;this.i=a;Q();b=++Xm;this.h=new oc(b,new _m(this),new an(this),false);this.g=new Bb(null,new cn(this),sr)}
function bd(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function C(b,c,d){var e,f;try{fc(b,d);try{f=(c.g.P(),null)}finally{gc()}return f}catch(a){a=Wg(a);if(ld(a,8)){e=a;throw Xg(e)}else throw Xg(a)}finally{K(b)}}
function co(a,b){var c,d,e;if(rd(b.currentTarget)===rd(a.F)){c=$wnd.goog.global.globalThis.console;d=b.data;e=$wnd.JSON.parse(d);c.log('onDataChannelMessage',e)}}
function lo(a,b){var c;if(null!=a.K){c=$wnd.goog.global.globalThis.console;c.log('Sending message',$wnd.JSON.parse($wnd.JSON.stringify(b)));a.K.send($wnd.JSON.stringify(b))}}
function bc(a){var b,c;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new Si(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);5==(b.i&7)?yb(b,6,true):4==(b.i&7)&&(a.g=4)}}}
function _h(a){var b,c,d;d=new _j;for(c=Bj(a,0);c.h!=c.j.i;){b=Fj(c);!d.g?(d.g=new fi(d.j)):ci(d.g,d.h);ci(d.g,b)}return !d.g?d.i:d.l.length==0?d.g.g:d.g.g+(''+d.l)}
function Hb(a){var b,c;if(0==a.i){b=Rb(a.j);if(0==b){a.g=0;return false}else if(a.g+1>a.h){a.g=0;return false}else{a.g=a.g+1;a.i=b}}--a.i;c=Qb(a.j);Nb(c);return true}
function _g(b,c,d,e){$g();var f=Yg;$moduleName=c;$moduleBase=d;Vg=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Yq(g)()}catch(a){b(c,a)}}else{Yq(g)()}}
function Zl(){var a,b,c,d,e;this.i=new Ej;e=$wnd.goog.global.globalThis.localStorage.getItem(pr);if(null!=e){for(b=Yh(e),c=0,d=b.length;c<d;++c){a=b[c];zj(this.i,a)}}}
function un(a,b){var c,d,e;b.preventDefault();c=(nb(a.h),a.i);null!=c&&(d=$wnd.goog.global.globalThis.location,e=c.length==0?c:'#'+c,u(d.hash,e)||(d.hash=e),undefined)}
function Sk(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function On(a){var b;this.j=hh(Tq.prototype.T,Tq,[this]);this.h=a;this.i=a.props['a'];Q();b=++Nn;this.g=new oc(b,null,null,false);Dm(this.i,this,new Pn(this));K((null,P))}
function Nj(){Nj=gh;var a,b,c,d;Kj=ad(td,_q,220,25,15,1);Lj=ad(td,_q,220,33,15,1);d=1.52587890625E-5;for(b=32;b>=0;b--){Lj[b]=d;d*=0.5}c=1;for(a=24;a>=0;a--){Kj[a]=c;c*=0.5}}
function mj(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return nj()}}
function Oi(a,b){var c,d,e,f;e=null;f=0;for(d=0;d<a.g.length;++d){c=a.g[d];if(b.Nb(c)){if(e==null){e=vk(a.g,d);f=d}}else e!=null&&(e[f++]=c)}if(e==null){return false}a.g=e;return true}
function D(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Vb){g=c.Q()}else{fc(b,e);try{g=c.Q()}finally{gc()}}return g}catch(a){a=Wg(a);if(ld(a,8)){f=a;throw Xg(f)}else throw Xg(a)}finally{K(b)}}
function _n(a,b){var c;$wnd.goog.global.globalThis.console.log('Websocket.close',b);if(rd(a.K)===rd(b.currentTarget)){a.K=null;c=(mb(a.o),a.v);(lq(),jq)!=c&&cq!=c&&eq!=c&&Lo(a,cq);ab(a.g)}}
function dh(){bh={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Uc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Wb()&&(c=Tc(c,g)):g[0].Wb()}catch(a){a=Wg(a);if(ld(a,8)){d=a;Fc();Lc(ld(d,46)?d.$():d)}else throw Xg(a)}}return c}
function ho(a,b){var c;if(rd(a.D)===rd(b.currentTarget)){$wnd.goog.global.globalThis.console.log('onTrack',b);c=b.streams;Ji(a.I,new Gp);a.I=new Qi;c.forEach(hh(sq.prototype._,sq,[a]));ab(a.h)}}
function ao(a,b){var c;if(rd(a.D)===rd(b.currentTarget)){c=$wnd.goog.global.globalThis.console;c.log('onDataChannel',b);a.F=b.channel;a.F.onmessage=hh(Ep.prototype.eb,Ep,[a]);a.F.onclose=hh(Fp.prototype.cb,Fp,[a])}}
function zc(a){var b;if(a.i==null){b=rd(a.h)===rd(xc)?null:a.h;a.j=b==null?er:od(b)?b==null?null:b.name:qd(b)?'String':Eh(A(b));a.g=a.g+': '+(od(b)?b==null?null:b.message:b+'');a.i='('+a.j+') '+a.g}}
function X(b){var c,d,e;e=b.v;try{d=b.i.Q();if(!(rd(e)===rd(d)||e!=null&&w(e,d))){b.v=d;b.h=null;kb(b.l)}}catch(a){a=Wg(a);if(ld(a,13)){c=a;if(!b.h){b.v=null;b.h=c;kb(b.l)}throw Xg(c)}else throw Xg(a)}}
function Pj(a){var b,c,d,e,f,g;e=a.g*kr+a.h*1502;g=a.h*kr+11;b=$wnd.Math.floor(g*lr);e+=b;g-=b*mr;e%=mr;a.g=e;a.h=g;d=a.g*128;f=$wnd.Math.floor(a.h*Lj[31]);c=d+f;c>=2147483648&&(c-=4294967296);return c}
function dj(a,b,c){var d,e,f,g,h;h=b==null?0:(g=B(b),g|0);e=(d=a.g.get(h),d==null?new Array:d);if(e.length==0){a.g.set(h,e)}else{f=aj(b,e);if(f){return f.Ib(c)}}e[e.length]=new Fi(b,c);++a.h;return null}
function Ik(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+Wh(a,c++)}b=b|0;return b}
function wk(a,b,c,d,e){var f,g,h,i,j;if(rd(a)===rd(c)){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function fo(a,b){var c,d;if(rd(a.D)===rd(b.currentTarget)){$wnd.goog.global.globalThis.console.log('onIceCandidate',b);c=b.candidate;null!=c&&null!=a.K&&lo(a,(d={},d[Fr]=Ir,d[Jr]=c.sdpMLineIndex,d[Ir]=c.candidate,d))}}
function sb(b){var c;if(1!=(b.i&7)){try{if(4!=(b.i&7)){if(0!=(b.i&512)){!!b.l&&(b.i&=-513);c=b.j;F((Q(),Q(),P),b,c)}else{b.l.P()}}else 0!=(b.i&512)&&!!b.l&&(b.i&=-513)}catch(a){a=Wg(a);if(ld(a,8)){Q()}else throw Xg(a)}}}
function mi(a,b){var c,d,e;c=b.Gb();e=b.Hb();d=qd(c)?c==null?oi(cj(a.g,null)):qj(a.h,c):oi(cj(a.g,c));if(!(rd(e)===rd(d)||e!=null&&w(e,d))){return false}if(d==null&&!(qd(c)?qi(a,c):!!cj(a.g,c))){return false}return true}
function V(a){var b,c,d,e,f,g;b=a.i?a.g.length-a.h+a.j:a.j-a.h;if(b+1>a.g.length){g=(a.g.length-1)*2+1;c=ad(ie,_q,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.h+d)%a.g.length;c[f]=a.g[e];a.g[e]=null;++f}a.g=c;a.h=0;a.j=f;a.i=false}}
function Ab(a,b,c,d){this.h=new Qi;this.m=new Pb(new Eb(this),d&6520832|262144|br);this.i=d&-6520833|3;this.g=a;this.j=b;this.l=c;!!this.j&&(this.i|=512);!this.g&&!!this.j&&(J((Q(),Q(),P),this),0==(this.m.g&2097152)&&K((null,P)))}
function ej(a,b){var c,d,e,f,g,h;g=b==null?0:(f=B(b),f|0);d=(c=a.g.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(Xi(b,e.Gb())){if(d.length==1){d.length=0;hj(a.g,g)}else{d.splice(h,1)}--a.h;return e.Hb()}}return null}
function lq(){lq=gh;kq=new mq('NOT_READY',0);dq=new mq('CONNECTED',1);iq=new mq('JOIN_REQUESTED',2);hq=new mq('JOIN_REJECTED',3);gq=new mq('JOINED',4);cq=new mq('CLOSED',5);jq=new mq('LEFT',6);fq=new mq('FULL',7);eq=new mq('ERROR',8)}
function fh(a,b,c){var d=bh,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=bh[b]),ih(h));_.Ub=c;!b&&(_.Vb=kh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.Tb=f)}
function Uk(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;Mk(b,hh(Xk.prototype.Pb,Xk,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[nr]=c[0],undefined):(d[nr]=c,undefined));return Rk(a,e,f,d)}
function Mh(a){if(a.mb()){var b=a.i;b.nb()?(a.v='['+b.u):!b.mb()?(a.v='[L'+b.kb()+';'):(a.v='['+b.kb());a.h=b.jb()+'[]';a.s=b.lb()+'[]';return}var c=a.m;var d=a.j;d=d.split('/');a.v=Nh('.',[c,Nh('$',d)]);a.h=Nh('.',[c,Nh('.',d)]);a.s=d[d.length-1]}
function vm(a,b){var c,d;Cm(a,b);c=(mb(a.o),a.D);if(b){null==c&&(++a.J,d=a.J,qm(a),Gm(a,true),a.H.Ob().then(hh(ep.prototype.ab,ep,[a,d])).catch(hh(fp.prototype.ab,fp,[a,d])),undefined)}else{if(null!=c){c.getTracks().forEach(hh(jp.prototype._,jp,[]));Km(a,null)}}}
function on(a){var b;this.i=a;this.l=a.props['a'];this.m=a.props['b'];Q();b=++mn;this.h=new oc(b,new pn(this),new qn(this),false);this.g=new Bb(null,new tn(this),sr);_l(this.l,this,new rn(this));this.o=new No(this.m,(lq(),kq),(_p(),$p));Fo(this.o);bm(this.l,this.m);K((null,P))}
function zb(b){var c,d,e,f,g;g=b.i&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Si(b.h);e.g<e.i.g.length;){d=(e.h=e.g++,e.i.g[e.h]);if(d.h){f=d.h;c=f.g;try{Z(c)}catch(a){a=Wg(a);if(!ld(a,8))throw Xg(a)}if(6==(b.i&7)){return true}}}}}ub(b);return false}
function Dn(a){var b,c,d;this.l=a;this.s=a.props['a'];this.o=a.props['b'];Q();b=++zn;this.j=new oc(b,null,new En(this),false);this.h=(d=new pb((c=null,c)),d);this.g=new Bb(null,new Jn(this),sr);!!this.s&&_l(this.s,this,new Fn(this));!!this.o&&_l(this.o,this,new Gn(this));K((null,P))}
function rc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.X();return a&&a.V()}},suppressed:{get:function(){return c.W()}}})}catch(a){}}}
function lj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function Rn(a){var b;b=$wnd.goog.global.globalThis.console;b.log('Attempting to send rtc session description');a.F=a.D.createDataChannel('chat');a.F.onmessage=hh(Cp.prototype.eb,Cp,[a]);a.F.onclose=hh(Dp.prototype.cb,Dp,[a]);a.D.createOffer().then(hh(pq.prototype.ab,pq,[a])).then(hh(qq.prototype.ab,qq,[a])).catch(hh(rq.prototype.ab,rq,[]))}
function yb(a,b,c){var d,e,f,g;g=a.i&7;if(b!=g){a.i=a.i&-8|b;if(!a.g&&6==b){c&&(1==(a.i&7)||1==(3&a.m.g)||J((Q(),Q(),P),a))}else if(!!a.g&&4==g&&(6==b||5==b)){ob(a.g.l);c&&(1==(a.i&7)||1==(3&a.m.g)||J((Q(),Q(),P),a))}else if(3==b||3!=g&&2==b){if(a.g){d=a.g;xb((e=d.s,e));d.v=null}Ji(a.h,new Gb(a));a.h.g=ad(ie,_q,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.g&&xb((f=a.g.o,f))}}
function Yh(a){var b,c,d,e,f,g,h,i;b=new RegExp('\\|','g');h=ad(le,_q,2,0,6,1);c=0;i=a;e=null;while(true){g=b.exec(i);if(g==null||i==''){h[c]=i;break}else{f=g.index;h[c]=i.substr(0,f);i=Zh(i,f+g[0].length,i.length);b.lastIndex=0;if(e==i){h[c]=i.substr(0,1);i=i.substr(1)}e=i;++c}}if(a.length>0){d=h.length;while(d>0&&h[d-1]==''){--d}d<h.length&&(h.length=d)}return h}
function Mm(a,b,c){var d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;this.H=a;this.I=b;Q();d=++zm;this.G=new oc(d,null,new Nm(this),true);this.A=c;this.h=(n=new pb((f=null,f)),n);this.o=(o=new pb((g=null,g)),o);this.l=(p=new pb((h=null,h)),p);this.j=(q=new pb((i=null,i)),q);this.i=(r=new pb((j=null,j)),r);this.g=(s=new pb((k=null,k)),s);this.u=(t=new pb((l=null,l)),t);this.s=(m=new pb((e=null,e)),m);this.m=new Bb(new Om(this),null,404750336);K((null,P))}
function kn(a){var b;a.j=0;Tl();b=Uk(Dr,Yk(new $wnd.Object,dd($c(le,1),_q,2,6,['room-view'])),[Uk(Dr,Yk(new $wnd.Object,dd($c(le,1),_q,2,6,['video-section'])),[Uk(Dr,Yk(new $wnd.Object,dd($c(le,1),_q,2,6,['video-list'])),jk(hk(Z(a.o.h).vb(),new Eq),new Wk)),Uk(Dr,Yk(new $wnd.Object,dd($c(le,1),_q,2,6,['active-video'])),[Vq(Uq(a.o.B),'active-video-element')])]),Uk(Dr,Yk(new $wnd.Object,dd($c(le,1),_q,2,6,['message-area'])),[gn(a)])]);return b}
function No(a,b,c){var d,e,f,g,h,i,j,k,l;this.H=new Qi;this.G=new _i;this.B=new Mm(new Ap,new Hp(this),false);this.J=new Mm(new Ip,new Jp(this),false);this.I=new Qi;this.C=a;Q();d=++oo;this.A=new oc(d,new Oo(this),new Po(this),true);this.v=b;this.u=c;this.s='';this.o=(i=new pb((f=null,f)),i);this.m=(j=new pb((g=null,g)),j);this.l=(k=new pb((e=null,e)),k);this.j=(l=new pb(null),l);this.i=(h=new pb(null),h);this.g=new cb(new Qo(this),null,null);this.h=new cb(new Ro(this),null,null)}
function Pl(){Pl=gh;tl=new Ql(or,0);ul=new Ql('checkbox',1);vl=new Ql('color',2);wl=new Ql('date',3);xl=new Ql('datetime',4);yl=new Ql('email',5);zl=new Ql('file',6);Al=new Ql('hidden',7);Bl=new Ql('image',8);Cl=new Ql('month',9);Dl=new Ql('number',10);El=new Ql('password',11);Fl=new Ql('radio',12);Gl=new Ql('range',13);Hl=new Ql('reset',14);Il=new Ql('search',15);Jl=new Ql('submit',16);Kl=new Ql('tel',17);Ll=new Ql('text',18);Ml=new Ql('time',19);Nl=new Ql('url',20);Ol=new Ql('week',21)}
function io(a){var b,c,d;H((Q(),Q(),P),new Xo(a),Hr);Hm(a.B);a.K=new $wnd.WebSocket((c=$wnd.goog.global.globalThis.location,d=u('https',c.protocol)?'wss':'ws',d+'://'+c.hostname+':'+3737+'/r/'+a.C));ab(a.g);Ko(a,(_p(),$p));Lo(a,(lq(),kq));a.K.onopen=hh(Kp.prototype.cb,Kp,[a]);a.K.onmessage=hh(Lp.prototype.eb,Lp,[a]);a.K.onclose=hh(Mp.prototype.bb,Mp,[a]);a.K.onerror=hh(Np.prototype.cb,Np,[a]);a.D=new $wnd.RTCPeerConnection(th({},[wh({})]));a.D.onicecandidate=hh(Op.prototype.gb,Op,[a]);a.D.ontrack=hh(Pp.prototype.hb,Pp,[a]);a.D.ondatachannel=hh(Bp.prototype.fb,Bp,[a]);b=Em(a.B);null!=b&&b.getTracks().forEach(hh(oq.prototype._,oq,[a,b]))}
function Yb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.l){return}j=(n=a.l.i&7,n>3?n:4);e=false;c=0;if(!!a.h&&1!=(a.l.i&7)){m=a.h.g.length;for(h=0;h<m;h++){k=Ki(a.h,h);if(-1!=k.l&&-2!=k.l){k.l=-1;h!=c&&Pi(a.h,c,k);++c;if(k.h){l=k.h;f=l.i&7;f==6&&(j=f)}}}}d=a.l.h;for(i=d.g.length-1;i>=0;i--){k=d.g[i];if(-1==k.l){k.l=0}else{jb(k,a.l);e=true}}2<(a.l.i&7)&&4!=j&&(a.l.i&7)<j&&yb(a.l,j,false);if(a.h){for(g=c-1;g>=0;g--){k=Ki(a.h,g);if(-1==k.l){k.l=0;ib(k,a.l);e=true}}}if(a.h){for(g=a.h.g.length-1;g>=c;g--){Mi(a.h,g)}e&&wb(a.l,a.h)}else{e&&wb(a.l,new Qi)}if(fb(a.l)&&!!a.l.g){b=a.l.g;k=b.l;!!k.h&&br!=(k.h.i&1835008)&&k.i.g.length<=0&&0==k.h.g.j&&ac(a,k)}}
function xn(a){var b,c;a.m=0;Tl();b=(c=(nb(a.h),a.i),Uk(vr,dl(Yk(new $wnd.Object,dd($c(le,1),_q,2,6,['home'])),hh(Mq.prototype.Qb,Mq,[a])),[Uk('h1',null,['vChat']),Uk(wr,ml(new $wnd.Object,'roomCode'),['Enter a room code.']),Uk(zr,_k(el(jl(fl(hl(gl(ll(Zk(il(Yk(cl(new $wnd.Object,(Pl(),Ll)),dd($c(le,1),_q,2,6,['roomCodeInput'])),'Room code'),'roomCode'),null==c?'':c),hh(Oq.prototype.Qb,Oq,[a]))),10)))),null),Uk(Dr,Yk(new $wnd.Object,dd($c(le,1),_q,2,6,['roomSelectButtons'])),[Uk(or,cl(Yk(new $wnd.Object,dd($c(le,1),_q,2,6,[Br])),(ql(),pl)),['Join']),Uk('a',al(Yk(new $wnd.Object,dd($c(le,1),_q,2,6,[Br])),'#'+Xl()),['Join Random'])]),am(a.o).h==0?null:Qk([Uk(Dr,null,['Recently used rooms:']),Qk(jk(hk(new kk(null,new Zj(am(a.o),16)),new Nq),new Wk))])]));return b}
function nj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[jr]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!lj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[jr]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function go(a,b){var c,d,e,f,g,h,i;e=b.data;d=$wnd.goog.global.globalThis.console;d.log('Websocket.message',e);h=$wnd.JSON.parse(e);g=h;if(rd(a.K)===rd(b.currentTarget)){ab(a.g);c=g[Fr];if(u('create',c)){d.log('Connected to room as host');Ko(a,(_p(),Zp));Lo(a,(lq(),gq))}else if(u('connect',c)){d.log('Connected to room as guest');Ko(a,(_p(),Yp));Lo(a,(lq(),dq))}else if(u('full',c)){d.log('Room full. Leaving room.');Ko(a,(_p(),$p));$n(a,(lq(),fq))}else if(u(Kr,c)){f=g['id'];i=g['message'];d.log("Guest '"+f+"' requested access to room with message '"+i+"'");Hi(a.H,new Vl(f,i));lb(a.j)}else if(u('accept',c)){d.log('Host allowed guest to join room.');Lo(a,(lq(),gq))}else if(u('reject',c)){d.log('Host rejected guest from room.');Lo(a,(lq(),hq))}else if(u('accepted',c)){f=g['id'];d.log("Host accepted guest '"+f+"' into room.");Zi(a.G,f);lb(a.i)}else if(u('remove',c)){f=g['id'];if($i(a.G,f)){d.log("Guest '"+f+Lr);lb(a.i)}else if(Oi(a.H,new vq(f))){d.log("Client '"+f+Lr);lb(a.j)}}else if(u('offer',c)){a.D.setRemoteDescription(g[Gr]);a.D.createAnswer().then(hh(wq.prototype.ab,wq,[a])).then(hh(xq.prototype.ab,xq,[a])).catch(hh(yq.prototype.ab,yq,[]))}else u('answer',c)?a.D.setRemoteDescription(g[Gr]):u(Ir,c)&&a.D.addIceCandidate(uh(vh({},g[Jr]),g[Ir]))}}
function gn(a){var b,c;c=Mo(a.o);if((lq(),kq)==c){return Qk([Uk(ur,null,['Getting ready...']),Uk('p',null,["You'll be able to join in just a moment."])])}else if(eq==c){return Qk([Uk(ur,null,['Service Offline']),Uk('p',null,['The chat service is offline at the moment. Try again later.'])])}else if(dq==c){return Qk([Uk(ur,null,['Ready to join?']),Uk('p',null,['Request access to join the room.']),Uk(vr,dl(new $wnd.Object,hh(Dq.prototype.Qb,Dq,[a])),[Uk(wr,ml(new $wnd.Object,xr),[yr]),Uk(zr,jl(fl(ll(gl(el(Zk(il(cl(new $wnd.Object,(Pl(),Ll)),Ar),xr)),hh(Hq.prototype.Qb,Hq,[a])),Io(a.o)),30)),null),Uk(or,Yk(new $wnd.Object,dd($c(le,1),_q,2,6,[Br])),[Cr])])])}else if(iq==c){return Qk([Uk(ur,null,['Joining room']),Uk('p',null,['Waiting for host to allow access to the room.'])])}else if(gq==c&&(_p(),Zp)==Jo(a.o)&&uo(a.o).g.length!=0){b=uo(a.o).g[0];return Qk([Uk(ur,null,['Guest requests access']),Uk('p',null,['A guest has sent you a message to join the room:']),Uk(Dr,Yk(new $wnd.Object,dd($c(le,1),_q,2,6,['request-message'])),[b.h]),Uk(vr,dl(new $wnd.Object,hh(Cq.prototype.Qb,Cq,[])),[Uk(or,bl(Yk(new $wnd.Object,dd($c(le,1),_q,2,6,[Br])),hh(Fq.prototype.Rb,Fq,[a,b])),['Accept']),Uk(or,bl(Yk(new $wnd.Object,dd($c(le,1),_q,2,6,[Br])),hh(Gq.prototype.Rb,Gq,[a,b])),['Reject'])])])}else return gq==c&&(_p(),Zp)==Jo(a.o)&&ti(to(a.o).g)==0?Qk([Uk(ur,null,['Waiting for guests to join']),Uk('p',null,['Waiting for someone to join this room']),Uk('a',al(new $wnd.Object,'#'+a.o.C),[a.o.C])]):gq==c?Qk([Uk(ur,null,['Joined room']),Uk('p',null,['Joined room. Feel free to chat.'])]):hq==c?Qk([Uk(ur,null,['Access denied']),Uk('p',null,['The host denied access to the room. You can attempt to re-request access to join the room.']),Uk(vr,dl(new $wnd.Object,hh(Dq.prototype.Qb,Dq,[a])),[Uk(wr,ml(new $wnd.Object,xr),[yr]),Uk(zr,jl(fl(ll(gl(el(Zk(il(cl(new $wnd.Object,(Pl(),Ll)),Ar),xr)),hh(Hq.prototype.Qb,Hq,[a])),Io(a.o)),30)),null),Uk(or,Yk(new $wnd.Object,dd($c(le,1),_q,2,6,[Br])),[Cr])])]):cq==c?Qk([Uk(ur,null,['Room closed']),Uk('p',null,[(_p(),Zp)==Jo(a.o)?'You closed the room.':'The host closed the room.']),Uk('a',al(Yk(new $wnd.Object,dd($c(le,1),_q,2,6,[Br])),'#'),[Er])]):fq==c?Qk([Uk(ur,null,['Room full']),Uk('p',null,['The room is full and no other guests can connect at this time.']),Uk('a',al(Yk(new $wnd.Object,dd($c(le,1),_q,2,6,[Br])),'#'),[Er])]):jq==c?Qk([Uk(ur,null,['Left the room']),Uk('p',null,['You left the room. Request access to re-join the room.']),Uk(vr,dl(new $wnd.Object,hh(Dq.prototype.Qb,Dq,[a])),[Uk(wr,ml(new $wnd.Object,xr),[yr]),Uk(zr,jl(fl(ll(gl(el(Zk(il(cl(new $wnd.Object,(Pl(),Ll)),Ar),xr)),hh(Hq.prototype.Qb,Hq,[a])),Io(a.o)),30)),null),Uk(or,Yk(new $wnd.Object,dd($c(le,1),_q,2,6,[Br])),[Cr])])]):null}
var Zq='object',$q={7:1},_q={4:1},ar={12:1},br=1048576,cr='__noinit__',dr={4:1,13:1,10:1,8:1},er='null',fr={29:1,69:1},gr={29:1,63:1},hr={42:1},ir={4:1,29:1,63:1},jr='delete',kr=15525485,lr=5.9604644775390625E-8,mr=16777216,nr='children',or='button',pr='vchat.rooms',qr=142606336,rr='hashchange',sr=1411518464,tr={12:1,30:1},ur='h2',vr='form',wr='label',xr='requestAccessMessage',yr='Enter a message to send to the host to request access.',zr='input',Ar="Hi, I'm John Doe.",Br='primary-button',Cr='Request Access',Dr='div',Er='Return to Home',Fr='command',Gr='session',Hr=75497472,Ir='candidate',Jr='mlineindex',Kr='request_access',Lr="' left the room.";var _,bh,Yg,Vg=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;dh();fh(1,null,{},v);_.L=function(a){return u(this,a)};_.M=function(){return this.Tb};_.N=Nr;_.O=function(){var a;return Eh(A(this))+'@'+(a=B(this)>>>0,a.toString(16))};_.equals=function(a){return this.L(a)};_.hashCode=function(){return this.N()};_.toString=function(){return this.O()};var fd,gd,hd;fh(72,1,{},Fh);_.ib=function(a){var b;b=new Fh;b.l=4;a>1?(b.i=Kh(this,a-1)):(b.i=this);return b};_.jb=function(){Dh(this);return this.h};_.kb=function(){return Eh(this)};_.lb=function(){Dh(this);return this.s};_.mb=function(){return (this.l&4)!=0};_.nb=function(){return (this.l&1)!=0};_.O=function(){return ((this.l&2)!=0?'interface ':(this.l&1)!=0?'':'class ')+(Dh(this),this.v)};_.l=0;_.o=0;var Ch=1;var ie=Hh(1);var $d=Hh(72);fh(100,1,{},L);_.h=1;_.i=false;_.j=true;_.l=0;var xd=Hh(100);fh(101,1,$q,M);_.P=function(){Ib(this.g)};var ud=Hh(101);fh(55,1,{},N);_.Q=function(){return this.g.P(),null};var vd=Hh(55);fh(102,1,{},O);var wd=Hh(102);var P;fh(56,1,{56:1},W);_.h=0;_.i=false;_.j=0;var yd=Hh(56);fh(243,1,ar);_.O=function(){var a;return Eh(this.Tb)+'@'+(a=B(this)>>>0,a.toString(16))};var Bd=Hh(243);fh(57,243,ar,cb);_.R=function(){Y(this)};_.S=Mr;_.g=false;_.j=0;_.u=false;var Ad=Hh(57);fh(140,1,{},db);_.Q=function(){return $(this.g)};var zd=Hh(140);fh(11,243,{12:1,11:1},pb);_.R=function(){gb(this)};_.S=function(){return -2==this.l};_.g=4;_.j=false;_.l=0;var Dd=Hh(11);fh(139,1,$q,qb);_.P=function(){hb(this.g)};var Cd=Hh(139);fh(22,243,{12:1,22:1},Bb,Cb);_.R=function(){rb(this)};_.S=function(){return 1==(this.i&7)};_.i=0;var Id=Hh(22);fh(134,1,{},Db);_.P=function(){X(this.g)};var Ed=Hh(134);fh(135,1,$q,Eb);_.P=function(){sb(this.g)};var Fd=Hh(135);fh(136,1,$q,Fb);_.P=function(){vb(this.g)};var Gd=Hh(136);fh(137,1,{},Gb);_.T=function(a){tb(this.g,a)};var Hd=Hh(137);fh(113,1,{},Jb);_.g=0;_.h=0;_.i=0;var Jd=Hh(113);fh(144,1,ar,Lb);_.R=function(){Kb(this)};_.S=Mr;_.g=false;var Kd=Hh(144);fh(79,243,{12:1,79:1},Pb);_.R=function(){Mb(this)};_.S=function(){return 2==(3&this.g)};_.g=0;var Md=Hh(79);fh(112,1,{},Ub);var Ld=Hh(112);fh(146,1,{},ec);_.O=function(){var a;return Dh(Nd),Nd.v+'@'+(a=Dk(this)>>>0,a.toString(16))};_.g=0;var Vb;var Nd=Hh(146);fh(21,1,ar,oc);_.R=function(){jc(this)};_.S=function(){return this.s<0};_.O=function(){var a;return Dh(Pd),Pd.v+'@'+(a=Dk(this)>>>0,a.toString(16))};_.j=0;_.s=0;var Pd=Hh(21);fh(133,1,$q,pc);_.P=function(){mc(this.g)};var Od=Hh(133);fh(8,1,{4:1,8:1});_.V=function(){return this.l};_.W=function(){return jk(hk(Ui((this.s==null&&(this.s=ad(ne,_q,8,0,0,1)),this.s)),new gi),new nk)};_.X=function(){return this.m};_.Y=function(){return this.o};_.Z=function(){sc(this,uc(new Error(tc(this,this.o))));Xc(this)};_.O=function(){return tc(this,this.Y())};_.l=cr;_.u=true;var ne=Hh(8);fh(13,8,{4:1,13:1,8:1});var be=Hh(13);fh(10,13,dr);var je=Hh(10);fh(95,10,dr);var ge=Hh(95);fh(96,95,dr);var Td=Hh(96);fh(46,96,{46:1,4:1,13:1,10:1,8:1},Ac);_.Y=function(){zc(this);return this.i};_.$=function(){return rd(this.h)===rd(xc)?null:this.h};var xc;var Qd=Hh(46);var Rd=Hh(0);fh(226,1,{});var Sd=Hh(226);var Cc=0,Dc=0,Ec=-1;fh(105,226,{},Sc);var Oc;var Ud=Hh(105);var Vc;fh(237,1,{});var Wd=Hh(237);fh(97,237,{},Zc);var Vd=Hh(97);fh(74,1,{93:1});_.O=Mr;var Xd=Hh(74);fh(99,10,dr);var ee=Hh(99);fh(138,99,dr,Ah);var Yd=Hh(138);fd={4:1,20:1};var Zd=Hh(236);fh(54,1,{4:1,54:1});var he=Hh(54);gd={4:1,20:1,94:1,54:1};var _d=Hh(94);fh(16,1,{4:1,20:1,16:1});_.L=function(a){return this===a};_.N=Nr;_.O=function(){return this.g!=null?this.g:''+this.h};_.h=0;var ae=Hh(16);fh(73,10,dr,Qh);var ce=Hh(73);fh(98,10,dr,Rh);var de=Hh(98);fh(35,54,{4:1,20:1,35:1,54:1},Sh);_.L=function(a){return ld(a,35)&&a.g==this.g};_.N=Mr;_.O=function(){return ''+this.g};_.g=0;var fe=Hh(35);var Uh;fh(329,1,{});hd={4:1,93:1,20:1,2:1};var le=Hh(2);fh(53,74,{93:1},ei,fi);var ke=Hh(53);fh(333,1,{});fh(90,1,{},gi);_.pb=function(a){return a.l};var me=Hh(90);fh(45,10,dr,hi,ii);var oe=Hh(45);fh(238,1,{29:1});_.ub=function(){return new Zj(this,0)};_.vb=function(){return new kk(null,this.ub())};_.qb=function(a){throw Xg(new ii('Add not supported on this collection'))};_.rb=function(a){return ji(this,a,false)};_.sb=function(){return this.tb()==0};_.wb=function(a){return li(this,a)};_.O=function(){var a,b,c;c=new ak(', ','[',']');for(b=this.ob();b.yb();){a=b.zb();$j(c,a===this?'(this Collection)':a==null?er:jh(a))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var pe=Hh(238);fh(241,1,{223:1});_.L=function(a){var b,c,d;if(a===this){return true}if(!ld(a,47)){return false}d=a;if(this.g.h+this.h.h!=d.g.h+d.h.h){return false}for(c=new zi((new vi(d)).g);c.h;){b=xi(c);if(!mi(this,b)){return false}}return true};_.N=function(){return Vi(new vi(this))};_.O=function(){var a,b,c;c=new ak(', ','{','}');for(b=new zi((new vi(this)).g);b.h;){a=xi(b);$j(c,ni(this,a.Gb())+'='+ni(this,a.Hb()))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var Be=Hh(241);fh(114,241,{223:1});var se=Hh(114);fh(240,238,fr);_.ub=function(){return new Zj(this,1)};_.L=function(a){var b;if(a===this){return true}if(!ld(a,69)){return false}b=a;if(b.tb()!=this.tb()){return false}return ki(this,b)};_.N=function(){return Vi(this)};var De=Hh(240);fh(32,240,fr,vi);_.rb=function(a){return ui(this,a)};_.ob=function(){return new zi(this.g)};_.tb=Qr;var re=Hh(32);fh(36,1,{},zi);_.xb=Or;_.zb=function(){return xi(this)};_.yb=Rr;_.Ab=function(){yi(this)};_.h=false;var qe=Hh(36);fh(239,238,gr);_.ub=function(){return new Zj(this,16)};_.Bb=function(a,b){throw Xg(new ii('Add not supported on this list'))};_.qb=function(a){this.Bb(this.tb(),a);return true};_.L=function(a){var b,c,d,e,f;if(a===this){return true}if(!ld(a,63)){return false}f=a;if(this.tb()!=f.tb()){return false}e=f.ob();for(c=this.ob();c.yb();){b=c.zb();d=e.zb();if(!(rd(b)===rd(d)||b!=null&&w(b,d))){return false}}return true};_.N=function(){return Wi(this)};_.ob=function(){return new Bi(this)};_.Db=function(a){return new Ci(this,a)};_.Eb=function(a){throw Xg(new ii('Remove not supported on this list'))};var ve=Hh(239);fh(75,1,{},Bi);_.xb=Or;_.yb=function(){return this.h<this.j.tb()};_.zb=function(){this.h<this.j.tb();return this.j.Cb(this.i=this.h++)};_.Ab=Pr;_.h=0;_.i=-1;var te=Hh(75);fh(104,75,{},Ci);_.Ab=Pr;_.Fb=function(a){this.g.Bb(this.h,a);++this.h;this.i=-1};var ue=Hh(104);fh(108,240,fr,Di);_.rb=Sr;_.ob=function(){var a;return a=new zi((new vi(this.g)).g),new Ei(a)};_.tb=Qr;var xe=Hh(108);fh(76,1,{},Ei);_.xb=Or;_.yb=function(){return this.g.h};_.zb=function(){var a;a=xi(this.g);return a.Gb()};_.Ab=function(){yi(this.g)};var we=Hh(76);fh(106,1,hr);_.L=function(a){var b;if(!ld(a,42)){return false}b=a;return Xi(this.g,b.Gb())&&Xi(this.h,b.Hb())};_.Gb=Mr;_.Hb=Rr;_.N=function(){return Jj(this.g)^Jj(this.h)};_.Ib=function(a){var b;b=this.h;this.h=a;return b};_.O=function(){return this.g+'='+this.h};var ye=Hh(106);fh(107,106,hr,Fi);var ze=Hh(107);fh(242,1,hr);_.L=function(a){var b;if(!ld(a,42)){return false}b=a;return Xi(this.h.value[0],b.Gb())&&Xi(vj(this),b.Hb())};_.N=function(){return Jj(this.h.value[0])^Jj(vj(this))};_.O=function(){return this.h.value[0]+'='+vj(this)};var Ae=Hh(242);fh(246,239,gr);_.Bb=function(a,b){var c;c=this.Db(a);c.Fb(b)};_.Cb=function(a){var b;b=this.Db(a);return b.zb()};_.ob=function(){return Bj(this,0)};_.Eb=function(a){var b,c;b=this.Db(a);c=b.zb();b.Ab();return c};var Ce=Hh(246);fh(15,239,ir,Qi,Ri);_.Bb=function(a,b){xk(this.g,a,b)};_.qb=function(a){return Hi(this,a)};_.rb=function(a){return Li(this,a,0)!=-1};_.Cb=function(a){return Ki(this,a)};_.sb=function(){return this.g.length==0};_.ob=function(){return new Si(this)};_.Eb=function(a){return Mi(this,a)};_.tb=function(){return this.g.length};_.wb=function(a){var b,c;c=this.g.length;a.length<c&&(a=Ak(new Array(c),a));for(b=0;b<c;++b){a[b]=this.g[b]}a.length>c&&(a[c]=null);return a};var Fe=Hh(15);fh(27,1,{},Si);_.xb=Or;_.yb=function(){return this.g<this.i.g.length};_.zb=function(){return this.h=this.g++,this.i.g[this.h]};_.Ab=function(){Mi(this.i,this.g=this.h);this.h=-1};_.g=0;_.h=-1;var Ee=Hh(27);fh(47,114,{4:1,47:1,223:1},Yi);var Ge=Hh(47);fh(162,240,{4:1,29:1,69:1},_i);_.qb=function(a){return Zi(this,a)};_.rb=Sr;_.sb=function(){return ti(this.g)==0};_.ob=function(){var a;return a=new zi((new vi((new Di(this.g)).g)).g),new Ei(a)};_.tb=Qr;var He=Hh(162);fh(115,1,{},fj);_.ob=function(){return new gj(this)};_.h=0;var Je=Hh(115);fh(77,1,{},gj);_.xb=Or;_.zb=function(){return this.j=this.g[this.i++],this.j};_.yb=function(){var a;if(this.i<this.g.length){return true}a=this.h.next();if(!a.done){this.g=a.value[1];this.i=0;return true}return false};_.Ab=function(){ej(this.l,this.j.Gb());this.i!=0&&--this.i};_.i=0;_.j=null;var Ie=Hh(77);var jj;fh(116,1,{},tj);_.ob=function(){return new uj(this)};_.h=0;_.i=0;var Me=Hh(116);fh(78,1,{},uj);_.xb=Or;_.zb=function(){return this.i=this.g,this.g=this.h.next(),new wj(this.j,this.i,this.j.i)};_.yb=function(){return !this.g.done};_.Ab=function(){sj(this.j,this.i.value[0])};var Ke=Hh(78);fh(117,242,hr,wj);_.Gb=function(){return this.h.value[0]};_.Hb=function(){return vj(this)};_.Ib=function(a){return rj(this.g,this.h.value[0],a)};_.i=0;var Le=Hh(117);fh(160,246,ir,Ej);_.qb=function(a){Aj(this,a,this.i.h,this.i);return true};_.Db=function(a){return Bj(this,a)};_.tb=Rr;_.h=0;var Pe=Hh(160);fh(161,1,{},Gj);_.xb=Or;_.Fb=function(a){Aj(this.j,a,this.h.h,this.h);++this.g;this.i=null};_.yb=function(){return this.h!=this.j.i};_.zb=function(){return Fj(this)};_.Ab=function(){var a;a=this.i.g;Dj(this.j,this.i);this.h==this.i?(this.h=a):--this.g;this.i=null};_.g=0;_.i=null;var Ne=Hh(161);fh(60,1,{},Hj);var Oe=Hh(60);fh(190,1,{},Qj);_.g=0;_.h=0;var Kj,Lj,Mj=0;var Qe=Hh(190);fh(119,1,{});_.xb=Tr;_.Jb=function(){return this.i};_.Kb=function(){return this.j};_.i=0;_.j=0;var Ue=Hh(119);fh(120,119,{});var Re=Hh(120);fh(109,1,{});_.xb=Tr;_.Jb=Rr;_.Kb=function(){return this.j-this.i};_.h=0;_.i=0;_.j=0;var Te=Hh(109);fh(110,109,{},Xj);_.xb=function(a){Uj(this,a)};_.Lb=function(a){return Vj(this,a)};var Se=Hh(110);fh(28,1,{},Zj);_.Jb=Mr;_.Kb=function(){Yj(this);return this.i};_.xb=function(a){Yj(this);this.j.xb(a)};_.Lb=function(a){Yj(this);if(this.j.yb()){a.T(this.j.zb());return true}return false};_.g=0;_.i=0;var Ve=Hh(28);fh(44,1,{},_j,ak);_.O=function(){return !this.g?this.i:this.l.length==0?this.g.g:this.g.g+(''+this.l)};var We=Hh(44);fh(92,1,{},bk);_.pb=function(a){return a};var Xe=Hh(92);fh(145,1,{},ck);var Ye=Hh(145);fh(118,1,{});_.i=false;var df=Hh(118);fh(37,118,{},kk);var cf=Hh(37);fh(91,1,{},nk);_.Mb=function(a){return ad(ie,_q,1,a,5,1)};var Ze=Hh(91);fh(121,120,{},pk);_.Lb=function(a){return this.h.Lb(new qk(this,a))};var _e=Hh(121);fh(123,1,{},qk);_.T=function(a){ok(this.g,this.h,a)};var $e=Hh(123);fh(122,1,{},sk);_.T=function(a){rk(this,a)};var af=Hh(122);fh(124,1,{},uk);_.T=function(a){tk(this,a)};var bf=Hh(124);fh(331,1,{});fh(328,1,{});var Ck=0;var Ek,Fk=0,Gk;fh(1304,1,{});fh(1337,1,{});fh(80,1,{},Wk);_.Mb=function(a){return new Array(a)};var ef=Hh(80);fh(285,$wnd.Function,{},Xk);_.Pb=function(a){Vk(this.g,this.h,a)};fh(38,16,{4:1,20:1,16:1,38:1},rl);var nl,ol,pl;var ff=Ih(38,sl);fh(9,16,{4:1,20:1,16:1,9:1},Ql);var tl,ul,vl,wl,xl,yl,zl,Al,Bl,Cl,Dl,El,Fl,Gl,Hl,Il,Jl,Kl,Ll,Ml,Nl,Ol;var gf=Ih(9,Rl);var Sl;fh(277,$wnd.Function,{},Ul);_.ab=function(a){return Kb(Sl),Sl=null,null};fh(82,1,{82:1},Vl);var hf=Hh(82);fh(126,1,{});var lf=Hh(126);fh(89,1,{},Wl);var jf=Hh(89);fh(59,1,{59:1});var kf=Hh(59);fh(153,59,{12:1,30:1,59:1},cm);_.U=Ur;_.R=Vr;_.S=Wr;_.O=function(){var a;return Dh(of),of.v+'@'+(a=Dk(this)>>>0,a.toString(16))};var $l=0;var of=Hh(153);fh(154,1,$q,dm);_.P=function(){gb(this.g.g)};var mf=Hh(154);fh(155,1,$q,em);_.P=function(){Yl(this.g,this.h)};var nf=Hh(155);fh(58,1,{58:1});var og=Hh(58);fh(147,58,{12:1,30:1,58:1},km);_.U=Ur;_.R=Vr;_.S=Wr;_.O=function(){var a;return Dh(uf),uf.v+'@'+(a=Dk(this)>>>0,a.toString(16))};var hm=0;var uf=Hh(147);fh(148,1,$q,lm);_.P=function(){Y(this.g.g)};var pf=Hh(148);fh(150,1,{},mm);_.P=function(){fm(this.g)};var qf=Hh(150);fh(151,1,{},nm);_.P=function(){gm(this.g)};var rf=Hh(151);fh(149,1,{},om);_.Q=function(){var a;return a=$wnd.goog.global.globalThis.location.hash,a.length==0?a:a.substr(1)};var sf=Hh(149);fh(152,1,$q,pm);_.P=function(){ab(this.g.g)};var tf=Hh(152);fh(61,1,{61:1});_.J=0;var pg=Hh(61);fh(62,61,{12:1,30:1,61:1},Mm);_.U=function(){return Th(this.G.j)};_.R=function(){jc(this.G)};_.S=function(){return this.G.s<0};_.O=function(){var a;return Dh(Cf),Cf.v+'@'+(a=Dk(this)>>>0,a.toString(16))};_.v=false;_.A=false;var zm=0;var Cf=Hh(62);fh(211,1,$q,Nm);_.P=function(){Am(this.g)};var vf=Hh(211);fh(212,1,{},Om);_.P=function(){um(this.g)};var wf=Hh(212);fh(213,1,$q,Pm);_.P=function(){Bm(this.g,this.h)};var xf=Hh(213);fh(83,1,$q,Qm);_.P=function(){vm(this.g,this.h)};_.h=false;var yf=Hh(83);fh(214,1,$q,Rm);_.P=function(){wm(this.g,this.h)};var zf=Hh(214);fh(215,1,$q,Sm);_.P=function(){xm(this.g)};var Af=Hh(215);fh(216,1,$q,Tm);_.P=function(){ym(this.g,this.h)};var Bf=Hh(216);fh(127,126,{});_.j=0;var rg=Hh(127);fh(128,127,tr,$m);_.U=Ur;_.R=Vr;_.S=Wr;_.O=function(){var a;return Dh(Hf),Hf.v+'@'+(a=Dk(this)>>>0,a.toString(16))};var Xm=0;var Hf=Hh(128);fh(129,1,$q,_m);_.P=function(){Ym(this.g)};var Df=Hh(129);fh(130,1,$q,an);_.P=Xr;var Ef=Hh(130);fh(132,1,{},bn);_.Q=function(){return Vm(this.g)};var Ff=Hh(132);fh(131,1,{},cn);_.P=function(){Wm(this.g)};var Gf=Hh(131);fh(245,1,{});var Pg=Hh(245);fh(171,245,{});_.j=0;var tg=Hh(171);fh(172,171,tr,on);_.U=Ur;_.R=Vr;_.S=Wr;_.O=function(){var a;return Dh(Nf),Nf.v+'@'+(a=Dk(this)>>>0,a.toString(16))};var mn=0;var Nf=Hh(172);fh(173,1,$q,pn);_.P=function(){eb(this.g.o)};var If=Hh(173);fh(174,1,$q,qn);_.P=Xr;var Jf=Hh(174);fh(176,1,$q,rn);_.P=function(){jc(this.g.h)};var Kf=Hh(176);fh(177,1,{},sn);_.Q=function(){return kn(this.g)};var Lf=Hh(177);fh(175,1,{},tn);_.P=function(){Wm(this.g)};var Mf=Hh(175);fh(244,1,{});var Sg=Hh(244);fh(163,244,{});_.m=0;var vg=Hh(163);fh(164,163,tr,Dn);_.U=function(){return Th(this.j.j)};_.R=function(){jc(this.j)};_.S=function(){return this.j.s<0};_.O=function(){var a;return Dh(Uf),Uf.v+'@'+(a=Dk(this)>>>0,a.toString(16))};var zn=0;var Uf=Hh(164);fh(165,1,$q,En);_.P=function(){An(this.g)};var Of=Hh(165);fh(167,1,$q,Fn);_.P=Yr;var Pf=Hh(167);fh(168,1,$q,Gn);_.P=Yr;var Qf=Hh(168);fh(169,1,$q,Hn);_.P=function(){Bn(this.g,this.h)};var Rf=Hh(169);fh(170,1,{},In);_.Q=function(){return xn(this.g)};var Sf=Hh(170);fh(166,1,{},Jn);_.P=function(){yn(this.g)};var Tf=Hh(166);fh(189,1,{});var Ug=Hh(189);fh(217,189,{});var xg=Hh(217);fh(218,217,tr,On);_.U=function(){return Th(this.g.j)};_.R=function(){jc(this.g)};_.S=function(){return this.g.s<0};_.O=function(){var a;return Dh(Wf),Wf.v+'@'+(a=Dk(this)>>>0,a.toString(16))};var Nn=0;var Wf=Hh(218);fh(219,1,$q,Pn);_.P=function(){jc(this.g.g)};var Vf=Hh(219);fh(191,1,{});var Mg=Hh(191);fh(192,191,tr,No);_.U=function(){return Th(this.A.j)};_.R=function(){jc(this.A)};_.S=function(){return this.A.s<0};_.O=function(){var a;return Dh(mg),mg.v+'@'+(a=Dk(this)>>>0,a.toString(16))};var oo=0;var mg=Hh(192);fh(193,1,$q,Oo);_.P=function(){qo(this.g)};var Xf=Hh(193);fh(194,1,$q,Po);_.P=function(){po(this.g)};var Yf=Hh(194);fh(195,1,{},Qo);_.Q=function(){return vo(this.g)};var Zf=Hh(195);fh(196,1,{},Ro);_.Q=function(){return Sn(this.g)};var $f=Hh(196);fh(197,1,$q,So);_.P=function(){ro(this.g,this.h)};var _f=Hh(197);fh(198,1,$q,To);_.P=function(){io(this.g)};var ag=Hh(198);fh(199,1,$q,Uo);_.P=function(){Rn(this.g)};var bg=Hh(199);fh(200,1,$q,Vo);_.P=function(){ao(this.g,this.h)};var cg=Hh(200);fh(201,1,$q,Wo);_.P=function(){ho(this.g,this.h)};var dg=Hh(201);fh(202,1,$q,Xo);_.P=function(){$n(this.g,(lq(),jq))};var eg=Hh(202);fh(203,1,$q,Yo);_.P=function(){eo(this.g,this.h)};var fg=Hh(203);fh(204,1,$q,Zo);_.P=function(){wo(this.g,this.h)};var gg=Hh(204);fh(205,1,$q,$o);_.P=function(){_n(this.g,this.h)};var hg=Hh(205);fh(206,1,$q,_o);_.P=function(){go(this.g,this.h)};var ig=Hh(206);fh(207,1,$q,ap);_.P=function(){ko(this.g)};var jg=Hh(207);fh(208,1,$q,bp);_.P=function(){xo(this.g,this.h)};var kg=Hh(208);fh(209,1,$q,cp);_.P=function(){yo(this.g,this.h)};var lg=Hh(209);fh(141,1,{},dp);_.handleEvent=function(a){jm(this.g)};var ng=Hh(141);fh(306,$wnd.Function,{},ep);_.ab=function(a){return rm(this.g,this.h,a)};_.h=0;fh(307,$wnd.Function,{},fp);_.ab=function(a){return sm(this.g,this.h,a)};_.h=0;fh(308,$wnd.Function,{},gp);_._=function(a,b,c){return tm(this.g,a)};fh(310,$wnd.Function,{},hp);_.cb=function(a){Lm(this.g)};fh(309,$wnd.Function,{},ip);_._=Zr;fh(254,$wnd.Function,{},jp);_._=Zr;fh(276,$wnd.Function,{},kp);_.Sb=function(a){return new np(a)};var lp;fh(111,$wnd.React.Component,{},np);eh(bh[1],_);_.componentWillUnmount=function(){Um(this.g)};_.render=function(){return Zm(this.g)};_.shouldComponentUpdate=function(a){return 1==this.g.j};var qg=Hh(111);fh(281,$wnd.Function,{},op);_.Sb=function(a){return new rp(a)};var pp;fh(158,$wnd.React.Component,{},rp);eh(bh[1],_);_.componentWillUnmount=function(){fb(this.g)&&Um(this.g)};_.render=function(){return fb(this.g)?nn(this.g):null};_.shouldComponentUpdate=function(a){return fb(this.g)&&1==this.g.j};var sg=Hh(158);fh(280,$wnd.Function,{},sp);_.Sb=function(a){return new vp(a)};var tp;fh(156,$wnd.React.Component,{},vp);eh(bh[1],_);_.componentWillUnmount=function(){fb(this.g)&&wn(this.g)};_.render=function(){return fb(this.g)?Cn(this.g):null};_.shouldComponentUpdate=function(a){return fb(this.g)&&1==this.g.m};var ug=Hh(156);fh(311,$wnd.Function,{},wp);_.Sb=function(a){return new zp(a)};var xp;fh(210,$wnd.React.Component,{},zp);eh(bh[1],_);_.componentWillUnmount=function(){fb(this.g)&&jc(this.g.g)};_.render=function(){return fb(this.g)?Ln(this.g):null};_.shouldComponentUpdate=function(a){return fb(this.g)&&Mn(this.g,a)};var wg=Hh(210);fh(178,1,{},Ap);_.Ob=function(){return $wnd.goog.global.globalThis.navigator.mediaDevices.getUserMedia(qh(ph({}),rh(sh({},nh(mh(oh({},160),640),1280)),nh(mh(oh({},120),360),720))))};var yg=Hh(178);fh(294,$wnd.Function,{},Bp);_.fb=function(a){Ao(this.g,a)};fh(295,$wnd.Function,{},Cp);_.eb=$r;fh(296,$wnd.Function,{},Dp);_.cb=_r;fh(300,$wnd.Function,{},Ep);_.eb=$r;fh(301,$wnd.Function,{},Fp);_.cb=_r;fh(182,1,{},Gp);_.T=function(a){ld(a,12)&&a.R()};var zg=Hh(182);fh(179,1,{},Hp);_.T=as;var Ag=Hh(179);fh(180,1,{},Ip);_.Ob=function(){return $wnd.goog.global.globalThis.navigator.mediaDevices.getDisplayMedia()};var Bg=Hh(180);fh(181,1,{},Jp);_.T=as;var Cg=Hh(181);fh(287,$wnd.Function,{},Kp);_.cb=function(a){Do(this.g,a)};fh(288,$wnd.Function,{},Lp);_.eb=function(a){Co(this.g,a)};fh(289,$wnd.Function,{},Mp);_.bb=function(a){zo(this.g,a)};fh(290,$wnd.Function,{},Np);_.cb=function(a){Bo(this.g,a)};fh(292,$wnd.Function,{},Op);_.gb=function(a){fo(this.g,a)};fh(293,$wnd.Function,{},Pp);_.hb=function(a){Eo(this.g,a)};fh(23,16,{4:1,20:1,16:1,23:1},Wp);var Qp,Rp,Sp,Tp,Up;var Dg=Ih(23,Xp);fh(39,16,{4:1,20:1,16:1,39:1},aq);var Yp,Zp,$p;var Eg=Ih(39,bq);fh(17,16,{4:1,20:1,16:1,17:1},mq);var cq,dq,eq,fq,gq,hq,iq,jq,kq;var Fg=Ih(17,nq);fh(253,$wnd.Function,{},oq);_._=function(a,b,c){return Tn(this.g,this.h,a)};fh(297,$wnd.Function,{},pq);_.ab=function(a){return Un(this.g,a)};fh(298,$wnd.Function,{},qq);_.ab=function(a){return Vn(this.g)};fh(299,$wnd.Function,{},rq);_.ab=function(a){return $wnd.goog.global.globalThis.console.log('Offer error: ',a),null};fh(302,$wnd.Function,{},sq);_._=function(a,b,c){return Wn(this.g,a)};fh(183,1,{},tq);_.Ob=function(){return $wnd.Promise.resolve(this.g)};var Gg=Hh(183);fh(184,1,{},uq);_.T=function(a){};var Hg=Hh(184);fh(185,1,{},vq);_.Nb=function(a){return mo(this.g,a)};var Ig=Hh(185);fh(303,$wnd.Function,{},wq);_.ab=function(a){return Xn(this.g,a)};fh(304,$wnd.Function,{},xq);_.ab=function(a){return Yn(this.g)};fh(305,$wnd.Function,{},yq);_.ab=function(a){return $wnd.goog.global.globalThis.console.log('Answer error: ',a),null};fh(186,1,$q,zq);_.P=function(){Zn(this.g,this.h)};var Jg=Hh(186);fh(187,1,$q,Aq);_.P=function(){lo(this.g,Nk(Fr,'reject_access','id',this.h.g))};var Kg=Hh(187);fh(188,1,{},Bq);_.Nb=function(a){return no(this.g,a)};var Lg=Hh(188);fh(282,$wnd.Function,{},Cq);_.Qb=function(a){a.preventDefault()};fh(224,$wnd.Function,{},Dq);_.Qb=function(a){hn(this.g,a)};fh(159,1,{},Eq);_.pb=function(a){return Vq(Wq(new Xq,a),'video-list-item')};var Ng=Hh(159);fh(283,$wnd.Function,{},Fq);_.Rb=function(a){dn(this.g,this.h,a)};fh(284,$wnd.Function,{},Gq);_.Rb=function(a){en(this.g,this.h,a)};fh(225,$wnd.Function,{},Hq);_.Qb=function(a){fn(this.g,a)};fh(143,1,{},Lq);var Og=Hh(143);fh(278,$wnd.Function,{},Mq);_.Qb=function(a){un(this.g,a)};fh(157,1,{},Nq);_.pb=function(a){return Uk('a',al(Yk($k(new $wnd.Object,a),dd($c(le,1),_q,2,6,['recent-room'])),'#'+a),[a])};var Qg=Hh(157);fh(279,$wnd.Function,{},Oq);_.Qb=function(a){var b;vn(this.g,$h((b=a.target,b).value))};fh(142,1,{},Sq);var Rg=Hh(142);fh(312,$wnd.Function,{},Tq);_.T=function(a){Kn(this.g,a)};fh(81,1,{},Xq);var Tg=Hh(81);var td=Jh('D');var Yq=(Fc(),Ic);var gwtOnLoad=gwtOnLoad=_g;Zg(lh);ah('permProps',[[]]);if (vchat) vchat.onScriptLoad(gwtOnLoad);})();