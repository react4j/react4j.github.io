function vchat(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='vchat',tb='__gwt_marker_vchat',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='4786C9A3BE149F49CE04EB945815C54C',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};vchat.onScriptLoad=function(a){vchat=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
vchat();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '4786C9A3BE149F49CE04EB945815C54C';function t(){}
function Bh(){}
function xh(){}
function Kb(){}
function Qc(){}
function Xc(){}
function Xk(){}
function ck(){}
function yk(){}
function Pk(){}
function Yk(){}
function Ci(){}
function Cl(){}
function Cp(){}
function rp(){}
function sp(){}
function tp(){}
function yp(){}
function zp(){}
function Ap(){}
function Ep(){}
function Gp(){}
function Fm(){}
function Xm(){}
function vq(){}
function mr(){}
function Jr(){}
function Nr(){}
function Rr(){}
function Vr(){}
function Zr(){}
function $r(){}
function qs(){}
function Vc(a){Uc()}
function Wh(){Wh=xh}
function yt(){Wi(this)}
function kj(){aj(this)}
function K(a){this.g=a}
function L(a){this.g=a}
function M(a){this.g=a}
function bb(a){this.g=a}
function ob(a){this.g=a}
function Cb(a){this.g=a}
function Db(a){this.g=a}
function Eb(a){this.g=a}
function Fb(a){this.g=a}
function nc(a){this.g=a}
function Uh(a){this.g=a}
function li(a){this.g=a}
function Ri(a){this.g=a}
function Zi(a){this.g=a}
function $i(a){this.g=a}
function $k(a){this.g=a}
function zk(a){this.g=a}
function Om(a){this.g=a}
function Pm(a){this.g=a}
function Um(a){this.g=a}
function Vm(a){this.g=a}
function Wm(a){this.g=a}
function Ym(a){this.g=a}
function Fn(a){this.g=a}
function Gn(a){this.g=a}
function Hn(a){this.g=a}
function Kn(a){this.g=a}
function Ln(a){this.g=a}
function Mn(a){this.g=a}
function On(a){this.g=a}
function $o(a){this.g=a}
function _o(a){this.g=a}
function ap(a){this.g=a}
function bp(a){this.g=a}
function dp(a){this.g=a}
function ep(a){this.g=a}
function ip(a){this.g=a}
function np(a){this.g=a}
function qp(a){this.g=a}
function wp(a){this.g=a}
function xp(a){this.g=a}
function Bp(a){this.g=a}
function Dp(a){this.g=a}
function Fp(a){this.g=a}
function Hp(a){this.g=a}
function Ip(a){this.g=a}
function Jp(a){this.g=a}
function Kp(a){this.g=a}
function Lp(a){this.g=a}
function Mp(a){this.g=a}
function Np(a){this.g=a}
function mq(a){this.g=a}
function oq(a){this.g=a}
function pq(a){this.g=a}
function qq(a){this.g=a}
function rq(a){this.g=a}
function sq(a){this.g=a}
function tq(a){this.g=a}
function uq(a){this.g=a}
function wq(a){this.g=a}
function xq(a){this.g=a}
function yq(a){this.g=a}
function zq(a){this.g=a}
function Aq(a){this.g=a}
function Bq(a){this.g=a}
function Eq(a){this.g=a}
function Mq(a){this.g=a}
function Nq(a){this.g=a}
function Oq(a){this.g=a}
function Pq(a){this.g=a}
function fr(a){this.g=a}
function gr(a){this.g=a}
function hr(a){this.g=a}
function ir(a){this.g=a}
function jr(a){this.g=a}
function kr(a){this.g=a}
function lr(a){this.g=a}
function nr(a){this.g=a}
function yr(a){this.g=a}
function zr(a){this.g=a}
function Br(a){this.g=a}
function Cr(a){this.g=a}
function Ir(a){this.g=a}
function _r(a){this.g=a}
function as(a){this.g=a}
function bs(a){this.g=a}
function es(a){this.g=a}
function fs(a){this.g=a}
function gs(a){this.g=a}
function hs(a){this.g=a}
function is(a){this.g=a}
function js(a){this.g=a}
function ks(a){this.g=a}
function ps(a){this.g=a}
function rs(a){this.g=a}
function vs(a){this.g=a}
function Xi(a){this.j=a}
function mj(a){this.i=a}
function zt(){Oi(this.g)}
function Gt(){hc(this.h)}
function Bj(){this.g=Kj()}
function Pj(){this.g=Kj()}
function Wk(a,b){a.g=b}
function vb(a,b){a.h=b}
function vl(a,b){a.key=b}
function ql(a,b){pl(a,b)}
function Dt(a){pi(this,a)}
function xt(a){Tj(this,a)}
function Ft(a){mk(this,a)}
function Mt(a){Bn(this.g)}
function Lt(){Z(this.g.g)}
function ic(a){!!a&&a.Q()}
function D(a){--a.l;I(a)}
function P(a,b){T(a);Q(a,b)}
function Zk(a,b){Ok(a.g,b)}
function H(a,b){Sb(a.m,b.m)}
function ib(a){ac((O(),a))}
function jb(a){bc((O(),a))}
function mb(a){cc((O(),a))}
function Kt(a){Qn(this.g,a)}
function vt(){return this.g}
function Bt(){return this.h}
function Et(){return this.l}
function nh(a){return a.l}
function Gq(a){a.j=2;hc(a.h)}
function Zq(a){a.l=2;hc(a.i)}
function qr(a){a.m=2;hc(a.j)}
function br(a){pb(a.h);W(a.g)}
function ji(){tc.call(this)}
function Di(){tc.call(this)}
function wt(){return hl(this)}
function Qq(a,b){return a.v=b}
function qc(a,b){a.l=b;pc(a,b)}
function gc(a,b,c){Mi(a.l,b,c)}
function Vh(a){uc.call(this,a)}
function Ei(a){uc.call(this,a)}
function Bi(a){Uh.call(this,a)}
function Ai(){Uh.call(this,'')}
function vj(){this.g=new sj}
function O(){O=xh;N=new J}
function wc(){wc=xh;vc=new t}
function Nc(){Nc=xh;Mc=new Qc}
function Ek(){Ek=xh;Dk=new Yk}
function Gj(){Gj=xh;Fj=Ij()}
function cb(a){jd(a,10)&&a.S()}
function Jt(a){jd(a,10)&&a.S()}
function zo(a){cb(a.B);cb(a.K)}
function ur(a){pb(a.g);eb(a.h)}
function Zh(a){Yh(a);return a.v}
function Kk(a){Ak(a);return a.g}
function ej(a,b){return a.g[b]}
function el(a,b){return cd(a,b)}
function Yc(a,b){return di(a,b)}
function At(){return Pi(this.g)}
function Ht(){return this.h.s<0}
function tc(){oc(this);this.Z()}
function Dc(){Dc=xh;!!(Uc(),Tc)}
function qh(){oh==null&&(oh=[])}
function rk(a,b,c){b.U(a.g[c])}
function Lm(a,b,c){gc(a.h,b,c)}
function qn(a,b,c){gc(a.H,b,c)}
function dl(a,b,c){a.splice(b,c)}
function C(a,b,c){A(a,new M(c),b)}
function vo(a,b){return s(b.g,a)}
function Y(a){rb(a.m);return $(a)}
function Wb(a){Xb(a);!a.j&&$b(a)}
function fb(a){O();bc(a);a.l=-2}
function Yj(a){return Zj(a,a.i.h)}
function Pi(a){return a.g.h+a.h.h}
function Kj(){Gj();return new Fj}
function Nk(a,b){a.ub(b);return a}
function Fl(a,b){a.id=b;return a}
function Ih(a,b){a.min=b;return a}
function Hh(a,b){a.max=b;return a}
function Sh(a,b){a.sdp=b;return a}
function Pl(a,b){a.src=b;return a}
function Gl(a,b){a.key=b;return a}
function Hl(a,b){a.ref=b;return a}
function rn(a){kb(a.o);return a.D}
function sn(a){kb(a.i);return a.A}
function Co(a){kb(a.i);return a.H}
function Do(a){kb(a.j);return a.I}
function To(a){kb(a.l);return a.s}
function Xo(a){kb(a.o);return a.v}
function Uo(a){lb(a.m);return a.u}
function Th(a,b){a.type=b;return a}
function eo(a,b){null!=b&&Qn(a,b)}
function mk(a,b){while(a.Sb(b));}
function Tk(a,b,c){b.U(a.g.tb(c))}
function Mj(a,b){return a.g.get(b)}
function Uj(a,b){Wj(a,b,a.g,a.g.g)}
function Vj(a,b){Wj(a,b,a.i.h,a.i)}
function Vk(a,b){this.g=a;this.h=b}
function Sk(a,b){this.g=a;this.h=b}
function ii(a,b){this.g=a;this.h=b}
function _i(a,b){this.g=a;this.h=b}
function Dl(a,b){this.g=a;this.h=b}
function Gm(a,b){this.g=a;this.h=b}
function Qm(a,b){this.g=a;this.h=b}
function In(a,b){this.g=a;this.h=b}
function Jn(a,b){this.g=a;this.h=b}
function Nn(a,b){this.g=a;this.h=b}
function Pn(a,b){this.g=a;this.h=b}
function cp(a,b){this.g=a;this.h=b}
function fp(a,b){this.g=a;this.h=b}
function gp(a,b){this.g=a;this.h=b}
function hp(a,b){this.g=a;this.h=b}
function jp(a,b){this.g=a;this.h=b}
function kp(a,b){this.g=a;this.h=b}
function lp(a,b){this.g=a;this.h=b}
function mp(a,b){this.g=a;this.h=b}
function op(a,b){this.g=a;this.h=b}
function pp(a,b){this.g=a;this.h=b}
function up(a,b){this.g=a;this.h=b}
function vp(a,b){this.g=a;this.h=b}
function Ib(a){this.j=a;this.h=100}
function cm(a,b){ii.call(this,a,b)}
function Bm(a,b){ii.call(this,a,b)}
function Up(a,b){ii.call(this,a,b)}
function $p(a,b){ii.call(this,a,b)}
function kq(a,b){ii.call(this,a,b)}
function nq(a,b){this.g=a;this.h=b}
function Cq(a,b){this.g=a;this.h=b}
function Dq(a,b){this.g=a;this.h=b}
function Ar(a,b){this.g=a;this.h=b}
function cs(a,b){this.g=a;this.h=b}
function ds(a,b){this.g=a;this.h=b}
function Jl(a,b){a.href=b;return a}
function bl(a,b,c){a.splice(b,0,c)}
function wo(a,b){return s(b.g,a.g)}
function ws(a){return ys(new As,a)}
function ls(a){return ms(new os,a)}
function ss(a){return ts(new us,a)}
function Ct(a){return Ki(this.g,a)}
function wi(a){return !a?Ls:''+a.g}
function Kc(a){$wnd.clearTimeout(a)}
function Gh(a,b){a.ideal=b;return a}
function Lh(a,b){a.video=b;return a}
function Nh(a,b){a.width=b;return a}
function Yl(a,b){a.value=b;return a}
function yi(a,b){a.g+=''+b;return a}
function Fq(){this.g=zl((Lr(),Kr))}
function os(){this.g=zl((Pr(),Or))}
function us(){this.g=zl((Tr(),Sr))}
function As(){this.g=zl((Xr(),Wr))}
function un(a){wn(a,(kb(a.i),!a.A))}
function It(a){a.enabled=!a.enabled}
function Oi(a){a.g=new Bj;a.h=new Pj}
function aj(a){a.g=$c(ie,Es,1,0,5,1)}
function Kh(a){a.audio=true;return a}
function Mh(a,b){a.height=b;return a}
function Go(a,b){po(a,b,new Cq(a,b))}
function Ho(a,b){po(a,b,new Dq(a,b))}
function s(a,b){return pd(a)===pd(b)}
function Ji(a){return !a?null:a.Ob()}
function pd(a){return a==null?null:a}
function ek(a){return a!=null?w(a):0}
function Yb(a){return !a.j?a:Yb(a.j)}
function ub(a){O();tb(a);xb(a,2,true)}
function Ok(a,b){Ek();Wk(a,Nk(a.g,b))}
function G(a,b,c){return B(a,c,2048,b)}
function F(a,b,c){B(a,new L(b),c,null)}
function Ll(a,b){a.onClick=b;return a}
function Zl(a,b){a.htmlFor=b;return a}
function Kl(a,b){a.disabled=b;return a}
function Nl(a,b){a.onSubmit=b;return a}
function Tl(a,b){a.onChange=b;return a}
function Ph(a,b){a.candidate=b;return a}
function Ql(a,b){a.width=''+b;return a}
function Jh(a){a.audio=false;return a}
function nb(a){this.i=new kj;this.h=a}
function ll(){ll=xh;il=new t;kl=new t}
function fl(a){if(!a){throw nh(new ji)}}
function pl(a,b){for(var c in a){b(c)}}
function qi(a,b){return a.charCodeAt(b)}
function uj(a,b){return Ni(a.g,b)!=null}
function hl(a){return a.$H||(a.$H=++gl)}
function Wl(a){return a.required=true,a}
function jd(a,b){return a!=null&&gd(a,b)}
function db(a){return !(jd(a,10)&&a.T())}
function kb(a){var b;Zb((O(),b=Ub,b),a)}
function wk(){xk.call(this,'|','','')}
function U(){this.g=$c(ie,Es,1,100,5,1)}
function Lc(){Ac!=0&&(Ac=0);Cc=-1}
function ms(a,b){ul(a.g,'a',b);return a}
function xs(a,b){ul(a.g,'b',b);return a}
function Ol(a,b){a.height=''+b;return a}
function Sl(a,b){a.maxLength=b;return a}
function Oh(a,b){a.iceServers=b;return a}
function ul(a,b,c){a.props[b]=c;return a}
function cl(a,b,c){al(c,0,a,b,c.length)}
function ti(a,b,c){return a.substr(b,c-b)}
function Rl(a){return a.autoFocus=true,a}
function ld(a){return typeof a==='number'}
function od(a){return typeof a==='string'}
function kd(a){return typeof a==='boolean'}
function Lb(a){2==(3&a.g)||(a.g=-4&a.g|2)}
function Wi(a){a.j.Kb(a.i);a.h=a.i;a.i=-1}
function Ui(a){a.i.Gb();a.i=null;a.h=Si(a)}
function Yh(a){if(a.v!=null){return}fi(a)}
function zs(a,b){ul(a.g,'c',b);return a.g}
function Vl(a,b){a.placeholder=b;return a}
function Ul(a){a.pattern='^\\w+$';return a}
function uc(a){this.o=a;oc(this);this.Z()}
function sj(){this.g=new Bj;this.h=new Pj}
function Z(a){4==(a.m.i&7)&&xb(a.m,5,true)}
function Sm(a){F((O(),O(),N),new Ym(a),Zs)}
function Bn(a){F((O(),O(),N),new Ln(a),Zs)}
function Cn(a){F((O(),O(),N),new Kn(a),Zs)}
function Dn(a){F((O(),O(),N),new Mn(a),Zs)}
function Qo(a){F((O(),O(),N),new ep(a),Zs)}
function Yo(a){F((O(),O(),N),new dp(a),Zs)}
function Io(a){F((O(),O(),N),new ip(a),ft)}
function So(a){F((O(),O(),N),new np(a),ft)}
function dr(a){F((O(),O(),N),new lr(a),Zs)}
function lc(a){O();Ub?a.Q():F((null,N),a,0)}
function lj(a){aj(this);cl(this.g,0,a.Bb())}
function Dj(a,b){var c;c=a[Ss];c.call(a,b)}
function rl(a,b){var c;c={};c[a]=b;return c}
function Qh(a,b){a.sdpMLineIndex=b;return a}
function oc(a){a.u&&a.l!==Js&&a.Z();return a}
function ai(a){var b;b=_h(a);hi(a,b);return b}
function Ec(a,b,c){return a.apply(b,c);var d}
function Sn(a,b,c){return a.D.addTrack(c,b)}
function uo(a,b){return pd(b.track)===pd(a)}
function nd(a,b){return a&&b&&a instanceof b}
function Yq(a,b){b.preventDefault();So(a.u)}
function Tj(a,b){while(a.Eb()){Zk(b,a.Fb())}}
function pk(a,b){while(a.i<a.j){rk(a,b,a.i++)}}
function Hb(a){while(true){if(!Gb(a)){break}}}
function go(a){if(!a.F&&a.G){a.G=false;fo(a)}}
function Rb(a,b,c){c.g=-4&c.g|1;P(a.g[b],c)}
function Sj(a,b,c){this.g=a;this.h=b;this.i=c}
function bk(a,b,c){this.j=a;this.h=c;this.g=b}
function Mk(a,b){Ek();Ck.call(this,a);this.g=b}
function bj(a,b){a.g[a.g.length]=b;return true}
function Sb(a,b){Rb(a,((b.g&229376)>>15)-1,b)}
function Mm(a,b){F((O(),O(),N),new Qm(a,b),Zs)}
function wn(a,b){F((O(),O(),N),new Jn(a,b),Zs)}
function Oo(a,b){F((O(),O(),N),new hp(a,b),Zs)}
function Bo(a,b){F((O(),O(),N),new op(a,b),ft)}
function Jo(a,b){F((O(),O(),N),new lp(a,b),ft)}
function Ko(a,b){F((O(),O(),N),new fp(a,b),ft)}
function Lo(a,b){F((O(),O(),N),new jp(a,b),ft)}
function Mo(a,b){F((O(),O(),N),new mp(a,b),ft)}
function No(a,b){F((O(),O(),N),new kp(a,b),ft)}
function Po(a,b){F((O(),O(),N),new gp(a,b),ft)}
function Ro(a,b){F((O(),O(),N),new pp(a,b),ft)}
function sb(a,b){hb(b,a);b.i.g.length>0||(b.g=4)}
function Rq(a,b,c){c.preventDefault();Bo(a.u,b)}
function Sq(a,b,c){c.preventDefault();Ro(a.u,b)}
function Ki(a,b){return od(b)?Li(a,b):!!yj(a.g,b)}
function Lj(a,b){return !(a.g.get(b)===undefined)}
function oj(a){return new Mk(null,nj(a,a.length))}
function ad(a){return Array.isArray(a)&&a._b===Bh}
function hd(a){return !Array.isArray(a)&&a._b===Bh}
function Eh(a){$wnd.addEventListener(Ns,a,false)}
function Zm(a){zn(a,null);yn(a,null);xn(a,null)}
function pr(a,b){lc(new Ar(a,b.length==0?null:b))}
function nj(a,b){return nk(b,a.length),new sk(a,b)}
function Fk(a,b){var c;return Jk(a,(c=new kj,c))}
function Uc(){Uc=xh;var a;!Wc();a=new Xc;Tc=a}
function oi(){oi=xh;ni=$c(fe,Es,35,256,0,1)}
function Jb(a){if(!a.g){a.g=true;D((O(),O(),N))}}
function tk(a){if(!a.j){a.j=a.h.sb();a.i=a.h.yb()}}
function Iq(a){if(0==a.j){a.j=1;a.i.forceUpdate()}}
function _q(a){if(0==a.l){a.l=1;a.j.forceUpdate()}}
function sr(a){if(0==a.m){a.m=1;a.l.forceUpdate()}}
function Qk(a,b,c){if(a.g.fb(c)){a.h=true;b.U(c)}}
function jj(a,b,c){var d;d=a.g[b];a.g[b]=c;return d}
function ci(a){var b;b=_h(a);b.u=a;b.l=1;return b}
function Rc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ak(a){a.i=a.h;a.h=a.h.g;++a.g;return a.i.i}
function tj(a,b){var c;c=Mi(a.g,b,a);return c==null}
function gj(a,b){var c;c=a.g[b];dl(a.g,b,1);return c}
function Dh(a){var b;b=$wnd.console;b.log.apply(b,a)}
function _k(a,b){var c;c=a.slice(0,b);return cd(c,a)}
function pn(a,b){var c;c=a.A;if(b!=c){a.A=b;jb(a.i)}}
function vn(a,b){var c;c=a.v;if(b!=c){a.v=b;jb(a.h)}}
function xn(a,b){var c;c=a.B;if(b!=c){a.B=b;jb(a.j)}}
function yn(a,b){var c;c=a.C;if(b!=c){a.C=b;jb(a.l)}}
function An(a,b){var c;c=a.G;if(b!=c){a.G=b;jb(a.u)}}
function Ao(a,b){var c;c=a.s;if(b!=c){a.s=b;jb(a.l)}}
function vr(a,b){var c;c=a.i;if(b!=c){a.i=b;jb(a.h)}}
function ok(a,b){this.l=a;this.j=(b&64)!=0?b|16384:b}
function _j(){this.g=new ck;this.i=new ck;$j(this)}
function ol(){if(jl==256){il=kl;kl=new t;jl=0}++jl}
function Ak(a){if(!a.h){Bk(a);a.i=true}else{Ak(a.h)}}
function cr(a){return G((O(),O(),N),a.h,new kr(a))}
function wr(a){return G((O(),O(),N),a.g,new Br(a))}
function Kq(a){return G((O(),O(),N),a.g,new Oq(a))}
function Ni(a,b){return b==null?Aj(a.g,null):Oj(a.h,b)}
function rj(a,b){return pd(a)===pd(b)||a!=null&&u(a,b)}
function Fo(a,b){pd(a.L)===pd(b.currentTarget)&&Z(a.g)}
function Gk(a,b){Bk(a);return new Mk(a,new Rk(b,a.g))}
function Hk(a,b){Bk(a);return new Mk(a,new Uk(b,a.g))}
function Li(a,b){return b==null?!!yj(a.g,null):Lj(a.h,b)}
function S(a){return a.i?a.g.length-a.h+a.j:a.j-a.h}
function Ml(a,b){a.type=b.g!=null?b.g:''+b.h;return a}
function xi(a,b){a.g+=String.fromCharCode(b);return a}
function sl(a,b,c){var d;d={};d[Ms]=a;d[b]=c;return d}
function bi(a,b){var c;c=_h(a);hi(a,c);c.l=b?8:0;return c}
function lb(a){var b;O();!!Ub&&!!Ub.l&&Zb((b=Ub,b),a)}
function Fh(a){$wnd.removeEventListener(Ns,a,false)}
function Wq(a){$wnd.document.removeEventListener(ht,a.s)}
function Vq(a){$wnd.document.addEventListener(ht,a.s)}
function Jc(a){Dc();$wnd.setTimeout(function(){throw a},0)}
function Ck(a){if(!a){this.h=null;new kj}else{this.h=a}}
function sk(a,b){this.i=0;this.j=b;this.h=17488;this.g=a}
function Yi(a,b){this.g=a;Xi.call(this,a);a.yb();this.h=b}
function dc(a,b){this.g=(O(),O(),N).h++;this.j=a;this.l=b}
function uk(a,b){this.h=a;this.g=(b&4096)==0?b|64|16384:b}
function Ii(a,b){return b===a?'(this Map)':b==null?Ls:Ah(b)}
function rc(a,b){var c;c=Zh(a.Zb);return b==null?c:c+': '+b}
function Ti(a){var b;a.i=a.g;b=a.g.Fb();a.h=Si(a);return b}
function $j(a){a.g.g=a.i;a.i.h=a.g;a.g.h=a.i.g=null;a.h=0}
function qb(a){H((O(),O(),N),a);0==(a.m.g&Is)&&I((null,N))}
function Vb(a){if(a.l){2==(a.l.i&7)||xb(a.l,4,true);tb(a.l)}}
function ei(a){if(a.qb()){return null}var b=a.u;return th[b]}
function Qi(a,b){if(jd(b,43)){return Hi(a.g,b)}return false}
function ec(a,b){Ub=new dc(Ub,b);a.j=false;Vb(Ub);return Ub}
function zh(a){function b(){}
;b.prototype=a||{};return new b}
function Rh(a){a.urls='stun:stun.l.google.com:19302';return a}
function _p(){Zp();return bd(Yc(kg,1),Es,39,0,[Yp,Xp,Wp])}
function dm(){bm();return bd(Yc(jf,1),Es,38,0,[$l,_l,am])}
function an(a,b){return b.onended=yh(xp.prototype.bb,xp,[a])}
function Lr(){Lr=xh;var a;Kr=(a=yh(Jr.prototype.Yb,Jr,[]),a)}
function Pr(){Pr=xh;var a;Or=(a=yh(Nr.prototype.Yb,Nr,[]),a)}
function Tr(){Tr=xh;var a;Sr=(a=yh(Rr.prototype.Yb,Rr,[]),a)}
function Xr(){Xr=xh;var a;Wr=(a=yh(Vr.prototype.Yb,Vr,[]),a)}
function Dr(a,b){var c;c=a.i;!(!!c&&c.H.s<0)&&lc(new In(c,b))}
function xj(a,b){var c;c=a.g.get(b);return c==null?new Array:c}
function di(a,b){var c=a.g=a.g||[];return c[b]||(c[b]=a.lb(b))}
function pi(a,b){var c,d;for(d=a.sb();d.Eb();){c=d.Fb();b.U(c)}}
function Tq(a,b){var c;lc(new cp(a.u,ui((c=b.target,c).value)))}
function yj(a,b){var c;return wj(b,xj(a,b==null?0:(c=w(b),c|0)))}
function vh(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ro(a,b){null!=a.L&&a.L.send($wnd.JSON.stringify(b))}
function bn(a){!(!!a&&a.H.s<0)&&F((O(),O(),N),new On(a),Zs)}
function Bk(a){if(a.h){Bk(a.h)}else if(a.i){throw nh(new ki)}}
function Cj(a){this.l=a;this.h=this.l.g.entries();this.g=new Array}
function J(){this.m=new Tb;this.g=new Ib(this.m);new K(this.g)}
function Uk(a,b){ok.call(this,b.Rb(),b.Qb()&-6);this.g=a;this.h=b}
function Vo(a,b){var c;c=a.u;if(!(b==c||!!b&&b==c)){a.u=b;jb(a.m)}}
function Wo(a,b){var c;c=a.v;if(!(b==c||!!b&&b==c)){a.v=b;jb(a.o)}}
function Hc(a,b,c){var d;d=Fc();try{return Ec(a,b,c)}finally{Ic(d)}}
function Yn(a,b){var c;return c=(kb(b.o),b.D),null!=c&&s(c.id,a.id)}
function Vp(){Tp();return bd(Yc(jg,1),Es,24,0,[Qp,Sp,Pp,Op,Rp])}
function Ik(a,b){return !(Bk(a),Kk(new Mk(a,new Rk(b,a.g)))).Sb(Dk)}
function qd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Ic(a){a&&Pc((Nc(),Mc));--Ac;if(a){if(Cc!=-1){Kc(Cc);Cc=-1}}}
function kc(a){ic(a.o);!!a.l&&jc(a);cb(a.g);cb(a.i);ic(a.h);ic(a.m)}
function yo(a){W(a.g);W(a.h);eb(a.o);eb(a.m);eb(a.l);eb(a.j);eb(a.i)}
function Rn(a){var b;b=new kj;sn(a.K)&&bj(b,a.K);cj(b,a.J);return b}
function sc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function qk(a,b){if(a.i<a.j){rk(a,b,a.i++);return true}return false}
function Vn(a){ro(a,sl('offer',_s,a.D.localDescription));return null}
function _m(a,b,c){a.K==b&&F((O(),O(),N),new Pn(a,c),Zs);return null}
function eb(a){if(-2!=a.l){F((O(),O(),N),new ob(a),0);!!a.h&&pb(a.h)}}
function ln(a){if(s('live',a.readyState)){a.onended=null;a.stop()}}
function Q(a,b){a.g[a.j]=b;++a.j;if(a.j>=a.g.length){a.j=0;a.i=true}}
function Rk(a,b){ok.call(this,b.Rb(),b.Qb()&-16449);this.g=a;this.i=b}
function Qj(a){this.j=a;this.h=this.j.g.entries();this.g=this.h.next()}
function Qr(a){$wnd.React.Component.call(this,a);this.g=new er(this)}
function Ur(a){$wnd.React.Component.call(this,a);this.g=new xr(this)}
function Yr(a){$wnd.React.Component.call(this,a);this.g=new Hr(this)}
function Mr(a){$wnd.React.Component.call(this,a);this.g=new Lq(this)}
function xk(a,b,c){this.h=a;this.j=b;this.l=c;this.i=this.j+(''+this.l)}
function Wj(a,b,c,d){var e;e=new ck;e.i=b;e.h=c;e.g=d;d.h=c.g=e;++a.h}
function tl(a,b,c,d,e,f){var g;g={};g[a]=b;g[c]=d;g[e]=f;return g}
function Bl(a,b,c){!s(c,'key')&&!s(c,'ref')&&(a[c]=b[c],undefined)}
function gb(a,b){var c,d;bj(a.i,b);d=(c=b.i&7,c>3?c:4);a.g>d&&(a.g=d)}
function Zn(a,b){var c;return c=(kb(b.o),b.D),!(null!=c&&!s(c.id,a.id))}
function Lk(a,b){var c;c=Fk(a,new zk(new yk));return c.Cb(b.Tb(c.yb()))}
function Jk(a,b){var c;Ak(a);c=new Xk;c.g=b;a.g.Db(new $k(c));return c.g}
function vk(a,b){!a.g?(a.g=new Bi(a.j)):yi(a.g,a.h);yi(a.g,b);return a}
function Qb(a){var b,c;b=0;for(c=0;c<a.g.length;c++){b+=S(a.g[c])}return b}
function $c(a,b,c,d,e,f){var g;g=_c(e,d);e!=10&&bd(Yc(a,f),b,c,e,g);return g}
function cd(a,b){Zc(b)!=10&&bd(v(b),b.$b,b.__elementTypeId$,Zc(b),a);return a}
function po(a,b,c){if(null!=a.L&&hj(a.I,b)){ij(a.I,new Eq(b));jb(a.j);c.Q()}}
function Mi(a,b,c){return od(b)?b==null?zj(a.g,null,c):Nj(a.h,b,c):zj(a.g,b,c)}
function Un(a,b){return a.D.setLocalDescription(Th(Sh({},b.sdp),b.type))}
function $n(a,b){return a.D.setLocalDescription(Sh(Th({},b.type),b.sdp))}
function Gc(b){Dc();return function(){return Hc(b,this,arguments);var a}}
function zc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Rj(a){if(a.g.i!=a.i){return Mj(a.g,a.h.value[0])}return a.h.value[1]}
function fj(a,b,c){for(;c<a.g.length;++c){if(rj(b,a.g[c])){return c}}return -1}
function ts(a,b){vl(a.g,mi(b.h.j)+(''+(Yh(hh),hh.v)));ul(a.g,'a',b);return a.g}
function Nb(b){try{rb(b.h.g)}catch(a){a=mh(a);if(!jd(a,7))throw nh(a)}}
function Tb(){var a;this.g=$c(yd,Es,57,5,0,1);for(a=0;a<5;a++){this.g[a]=new U}}
function dj(a,b){var c,d,e,f;for(d=a.g,e=0,f=d.length;e<f;++e){c=d[e];b.U(c)}}
function on(a,b){var c;c=a.F;if(!(pd(b)===pd(c)||b!=null&&u(b,c))){a.F=b;jb(a.s)}}
function zn(a,b){var c;c=a.D;if(!(pd(b)===pd(c)||b!=null&&u(b,c))){a.D=b;jb(a.o)}}
function hj(a,b){var c;c=fj(a,b,0);if(c==-1){return false}dl(a.g,c,1);return true}
function hc(a){if(a.s>=0){a.s=-2;B((O(),O(),N),new L(new nc(a)),67108864,null)}}
function W(a){if(!a.g){a.g=true;a.v=null;a.h=null;eb(a.l);2==(a.m.i&7)||pb(a.m)}}
function I(a){if(a.j&&a.l==0){if(!a.i){a.i=true;try{Hb(a.g)}finally{a.i=false}}}}
function $(a){if(a.h){if(jd(a.h,9)){throw nh(a.h)}else{throw nh(a.h)}}return a.v}
function wb(b){if(b){try{b.Q()}catch(a){a=mh(a);if(jd(a,7)){O()}else throw nh(a)}}}
function qo(a){if(null!=a.L){ro(a,sl(dt,'message',(kb(a.l),a.s)));Wo(a,(jq(),gq))}}
function lq(){jq();return bd(Yc(lg,1),Es,16,0,[iq,bq,gq,fq,eq,aq,hq,dq,cq])}
function Wn(a,b){Dh(bd(Yc(ie,1),Es,1,5,['Offer error: ',b]));a.F=false;return null}
function jo(a,b){if(pd(a.L)===pd(b.currentTarget)){Z(a.g);Wo(a,(jq(),cq));a.L=null}}
function Oc(a){var b,c;if(a.g){c=null;do{b=a.g;a.g=null;c=Sc(b,c)}while(a.g);a.g=c}}
function Pc(a){var b,c;if(a.h){c=null;do{b=a.h;a.h=null;c=Sc(b,c)}while(a.h);a.h=c}}
function Zb(a,b){var c;if(a.l){c=a.g;if(b.l!=c){b.l=c;!a.h&&(a.h=new kj);bj(a.h,b)}}}
function fc(){var a;try{Wb(Ub);O()}finally{a=Ub.j;!a&&((O(),O(),N).j=true);Ub=Ub.j}}
function _h(a){var b;b=new $h;b.v='Class$'+(a?'S'+a:''+b.o);b.h=b.v;b.s=b.v;return b}
function _b(a,b){var c;if(!a.i){c=Yb(a);!c.i&&(c.i=new kj);a.i=c.i}b.j=true;a.i.ub(b)}
function hi(a,b){var c;if(!a){return}b.u=a;var d=ei(b);if(!d){th[a]=[b];return}d.Zb=b}
function Zj(a,b){var c;c=b.i;b.g.h=b.h;b.h.g=b.g;b.g=b.h=null;b.i=null;--a.h;return c}
function Il(a){a.title='Room code should only contain letters or numbers.';return a}
function Vi(a){this.l=a;this.j=new Qj(this.l.h);this.g=this.j;this.h=Si(this)}
function bm(){bm=xh;$l=new cm(Xs,0);_l=new cm('reset',1);am=new cm('submit',2)}
function Zp(){Zp=xh;Yp=new $p('UNKNOWN',0);Xp=new $p('HOST',1);Wp=new $p('GUEST',2)}
function md(a){return a!=null&&(typeof a===Cs||typeof a==='function')&&!(a._b===Bh)}
function Zc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function nn(a){pb(a.m);W(a.g);eb(a.h);eb(a.o);eb(a.l);eb(a.j);eb(a.i);eb(a.u);eb(a.s)}
function bo(a,b){var c;c=b.g;ro(a,sl('approve_access','id',c));tj(a.H,c);jb(a.i);so(a)}
function mo(a,b){var c;c=b.track;a.J=Fk(Gk(a.J.Ab(),new xq(c)),new zk(new yk));Z(a.h)}
function Oj(a,b){var c;c=a.g.get(b);if(c===undefined){++a.i}else{Dj(a.g,b);--a.h}return c}
function ys(a,b){vl(a.g,(b?mi(b.H.j):null)+(''+(Yh(jh),jh.v)));ul(a.g,'a',b);return a}
function yh(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function xl(a,b,c,d){var e;e=yl($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function zl(a){var b;b=yl($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Uq(a){var b;b=$wnd.document;b.fullscreen?b.exitFullscreen():a.v.requestFullscreen()}
function _n(a){ro(a,sl('answer',_s,a.D.localDescription));a.F=false;go(a);return null}
function ao(a,b){Dh(bd(Yc(ie,1),Es,1,5,['Answer error: ',b]));a.F=false;go(a);return null}
function Gi(a,b){var c,d;for(d=b.sb();d.Eb();){c=d.Fb();if(!a.wb(c)){return false}}return true}
function pj(a){var b,c,d;d=0;for(c=a.sb();c.Eb();){b=c.Fb();d=d+(b!=null?w(b):0);d=d|0}return d}
function qj(a){var b,c,d;d=1;for(c=a.sb();c.Eb();){b=c.Fb();d=31*d+(b!=null?w(b):0);d=d|0}return d}
function tb(a){var b,c;for(c=new mj(a.h);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);b.g=4}}
function ph(){qh();var a=oh;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ki(){uc.call(this,"Stream already terminated, can't be modified or used")}
function Ob(a,b){this.h=a;this.g=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function Ab(a,b,c){zb.call(this,null,a,b,c|(!a?262144:Gs)|(0==(c&6291456)?!a?Is:4194304:0)|0|0|0)}
function fn(a,b){vn(a,false);zn(a,b);b.getTracks().forEach(yh(wp.prototype.eb,wp,[a]));a.J.U(b)}
function Qn(a,b){if(null!=a.D){b.getTracks().forEach(yh(nq.prototype.eb,nq,[a,b]));a.G=true;go(a)}}
function nk(a,b){if(0>a||a>b){throw nh(new Vh('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function sh(a,b){typeof window===Cs&&typeof window['$gwt']===Cs&&(window['$gwt'][a]=b)}
function Ch(){var a;a=$wnd.document.getElementById('app');$wnd.ReactDOM.render((new Fq).g,a,null)}
function mh(a){var b;if(jd(a,7)){return a}b=a&&a.__java$exception;if(!b){b=new yc(a);Vc(b)}return b}
function Si(a){if(a.g.Eb()){return true}if(a.g!=a.j){return false}a.g=new Cj(a.l.g);return a.g.Eb()}
function cj(a,b){var c,d;c=b.Bb();d=c.length;if(d==0){return false}cl(a.g,a.g.length,c);return true}
function wj(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(rj(a,c.Nb())){return c}}return null}
function bd(a,b,c,d,e){e.Zb=a;e.$b=b;e._b=Bh;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Nj(a,b,c){var d;d=a.g.get(b);a.g.set(b,c===undefined?null:c);d===undefined?++a.h:++a.i;return d}
function mc(a,b,c,d){this.j=a;this.l=d?new sj:null;this.o=b;this.h=c;this.m=null;this.g=null;this.i=null}
function $h(){this.o=Xh++;this.v=null;this.s=null;this.m=null;this.j=null;this.h=null;this.u=null;this.g=null}
function yc(a){wc();oc(this);this.l=a;pc(this,a);this.o=a==null?Ls:Ah(a);this.g='';this.h=a;this.g=''}
function Im(a,b){Fi(a.i,b,true);3==a.i.h&&Yj(a.i);Uj(a.i,b);jb(a.g);$wnd.localStorage.setItem(Ys,vi(a.i))}
function jn(a){var b;b=(kb(a.o),a.D);null!=b&&b.getAudioTracks().forEach(yh(sp.prototype.eb,sp,[]));Z(a.g)}
function Em(){if(!Dm){Dm=(++(O(),O(),N).l,new Kb);$wnd.Promise.resolve(null).then(yh(Fm.prototype._,Fm,[]))}}
function $m(a,b,c){a.K==b?F((O(),O(),N),new Nn(a,c),Zs):c.getTracks().forEach(yh(zp.prototype.eb,zp,[]));return null}
function pb(a){if(2<(a.i&7)){B((O(),O(),N),new L(new Eb(a)),67108864,null);!!a.g&&W(a.g);Lb(a.m);a.i=a.i&-8|1}}
function Mb(a){if(1==(3&a.g)){a.g=-4&a.g|0;0==(a.g&Gs)?Nb(a):rb(a.h.g);0!=(a.g&524288)&&(2==(3&a.g)||(a.g=-4&a.g|2))}}
function hb(a,b){var c,d;d=a.i;hj(d,b);!!a.h&&Gs!=(a.h.i&Hs)&&a.i.g.length<=0&&0==a.h.g.j&&(a.j||_b((O(),c=Ub,c),a))}
function Hq(a){var b,c,d;a.j=0;Em();c=(d=(b=X(a.l.j.g),b.length==0?null:b),null==d?ss(a.l):ns(ls(a.l),d));return c}
function wl(a){var b;b=yl($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=rl(Ws,a);return b}
function mi(a){var b,c;if(a>-129&&a<128){b=a+128;c=(oi(),ni)[b];!c&&(c=ni[b]=new li(a));return c}return new li(a)}
function Fr(a,b){var c;c=a.h.props;if(!(c['b']===b['b'])){return true}if(!(c['c']===b['c'])){return true}return false}
function Ah(a){var b;if(Array.isArray(a)&&a._b===Bh){return Zh(v(a))+'@'+(b=w(a)>>>0,b.toString(16))}return a.toString()}
function kn(a){var b;An(a,(kb(a.u),!a.G));b=(kb(a.o),a.D);null!=b&&b.getVideoTracks().forEach(yh(tp.prototype.eb,tp,[]))}
function tn(a){var b;return Wh(),b=(kb(a.o),a.D),null!=b&&b.getAudioTracks().some(yh(rp.prototype.fb,rp,[]))?true:false}
function Eo(a){return null==a.L?(Tp(),Rp):(Tp(),bd(Yc(jg,1),Es,24,0,[Qp,Sp,Pp,Op,Rp]))[a.L.readyState]}
function Er(a){return xl('video',null,a.j,tl('autoPlay',true,'className',a.h.props['b'],'muted',a.h.props['c']))}
function v(a){return od(a)?le:ld(a)?_d:kd(a)?Zd:hd(a)?a.Zb:ad(a)?a.Zb:a.Zb||Array.isArray(a)&&Yc(Rd,1)||Rd}
function w(a){return od(a)?nl(a):ld(a)?qd(a):kd(a)?a?1231:1237:hd(a)?a.O():ad(a)?hl(a):!!a&&!!a.hashCode?a.hashCode():hl(a)}
function ho(a,b){var c;if(pd(a.L)===pd(b.currentTarget)){a.L=null;c=(kb(a.o),a.v);(jq(),hq)!=c&&aq!=c&&cq!=c&&Wo(a,aq);Z(a.g)}}
function Tn(a,b){var c;c=a.D.getSenders().find(yh(pq.prototype.fb,pq,[b]));if(null!=c){a.D.removeTrack(c);a.G=true;go(a)}}
function ns(a,b){var c;ul(a.g,'b',b);return c=a.g.props,vl(a.g,wi(c['a']?mi(c['a'].h.j):null)+'-'+c['b']+(Yh(eh),eh.v)),a.g}
function $b(a){var b;if(a.i){while(!a.i.xb()){b=a.i.Kb(a.i.yb()-1);b.j=false;b.i.g.length>0||(b.h.i&7)>3&&xb(b.h,3,true)}}}
function cn(a){var b,c,d;c=(kb(a.o),a.D);d=(kb(a.s),a.F);if(null!=c&&null!=d){b=c;pd(b)!==pd(d.srcObject)&&(d.srcObject=b)}}
function nl(a){ll();var b,c,d;c=':'+a;d=kl[c];if(d!=null){return qd(d)}d=il[c];b=d==null?ml(a):qd(d);ol();kl[c]=b;return b}
function lk(){ik();var a,b,c;c=hk+++Date.now();a=qd($wnd.Math.floor(c*Us))&16777215;b=qd(c-a*Vs);this.g=a^1502;this.h=b^Ts}
function Nm(){var a,b;Jm.call(this);O();a=++Km;this.h=new mc(a,new Om(this),new Pm(this),true);this.g=(b=new nb(null),b)}
function Cm(){Am();return bd(Yc(kf,1),Es,8,0,[em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm,qm,rm,sm,tm,um,vm,wm,xm,ym,zm])}
function Bb(a,b){zb.call(this,a,new Cb(a),null,b|(Gs==(b&Hs)?0:524288)|(0==(b&6291456)?Gs==(b&Hs)?4194304:Is:0)|0|268435456|0)}
function Pb(a){var b,c,d;for(b=0;b<a.g.length;b++){d=a.g[b];if(0!=(d.i?d.g.length-d.h+d.j:d.j-d.h)){c=R(d);return c}}return null}
function Fi(a,b,c){var d,e;for(e=a.sb();e.Eb();){d=e.Fb();if(pd(b)===pd(d)||b!=null&&u(b,d)){c&&e.Gb();return true}}return false}
function Fc(){var a;if(Ac!=0){a=zc();if(a-Bc>2000){Bc=a;Cc=$wnd.setTimeout(Lc,10)}}if(Ac++==0){Oc((Nc(),Mc));return true}return false}
function Xj(a,b){var c,d;if(b>=a.h>>1){d=a.i;for(c=a.h;c>b;--c){d=d.h}}else{d=a.g.g;for(c=0;c<b;++c){d=d.g}}return new bk(a,b,d)}
function no(a,b){var c;if(pd(a.D)===pd(b.currentTarget)){c=b.streams;a.J=new lj(a.J);c.forEach(yh(tq.prototype.eb,tq,[a]));Z(a.h)}}
function gn(a){var b;b=(kb(a.o),a.D);Zm(a);F((O(),O(),N),new Jn(a,false),Zs);null!=b&&b.getTracks().forEach(yh(yp.prototype.eb,yp,[]))}
function dn(a){var b;++a.K;b=a.K;Zm(a);vn(a,true);a.I.Ub().then(yh(up.prototype.hb,up,[a,b])).catch(yh(vp.prototype.ib,vp,[a,b]))}
function gi(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Wc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function jk(a,b){var c,d;fl(b>0);if((b&-b)==b){return qd(b*kk(a)*4.6566128730773926E-10)}do{c=kk(a);d=c%b}while(c-d+(b-1)<0);return qd(d)}
function hn(a,b){var c;vn(a,false);if(nd(b,$wnd.DOMException)){c=b;yn(a,c.name);xn(a,c.message)}else{yn(a,Zh(v(b)));xn(a,b==null?Ls:Ah(b))}}
function Tp(){Tp=xh;Qp=new Up('CONNECTING',0);Sp=new Up('OPEN',1);Pp=new Up('CLOSING',2);Op=new Up('CLOSED',3);Rp=new Up('NOT_REQUESTED',4)}
function Lq(a){var b;this.l=new Nm;this.i=a;O();b=++Jq;this.h=new mc(b,new Mq(this),new Nq(this),false);this.g=new Ab(null,new Pq(this),gt)}
function Tm(){var a;this.i=new qp(this);O();a=++Rm;this.h=new mc(a,null,new Um(this),true);this.g=new ab(new Xm,new Vm(this),new Wm(this),$s)}
function jc(a){var b,c,d;for(c=new mj(new lj(new Ri(a.l)));c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.Nb();jd(d,10)&&d.T()||b.Ob().Q()}}
function ko(a,b){var c;if(pd(a.D)===pd(b.currentTarget)){c=b.candidate;null!=c&&null!=a.L&&ro(a,tl(Ms,bt,ct,c.sdpMLineIndex,bt,c.candidate))}}
function u(a,b){return od(a)?s(a,b):ld(a)?pd(a)===pd(b):kd(a)?pd(a)===pd(b):hd(a)?a.M(b):ad(a)?s(a,b):!!a&&!!a.equals?a.equals(b):pd(a)===pd(b)}
function Hm(){var a,b,c;b=new lk;c=new Ai;for(a=0;a<10;a++){xi(c,qi('abcdefghijklmnopqrstuvwxyz1234567890',$wnd.Math.abs(jk(b,36))))}return c.g}
function or(a,b){var c,d,e;b.preventDefault();c=(lb(a.h),a.i);null!=c&&(d=$wnd.location,e=c.length==0?c:'#'+c,s(d.hash,e)||(d.hash=e),undefined)}
function gd(a,b){if(od(a)){return !!fd[b]}else if(a.$b){return !!a.$b[b]}else if(ld(a)){return !!ed[b]}else if(kd(a)){return !!dd[b]}return false}
function El(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function en(a,b){var c;pn(a,b);c=(kb(a.o),a.D);if(b){null==c&&dn(a)}else{if(null!=c){c.getTracks().forEach(yh(zp.prototype.eb,zp,[]));zn(a,null)}}}
function Xn(a,b){var c,d;if(Ik(a.J.Ab(),new uq(b))){c=new vq;d=new En(new wq(b),c,true);dn(d);a.J.ub(d);b.onremovetrack=yh(Dp.prototype.gb,Dp,[a])}}
function R(a){var b;if(0==(a.i?a.g.length-a.h+a.j:a.j-a.h)){return null}b=a.g[a.h];a.g[a.h]=null;++a.h;if(a.h>=a.g.length){a.h=0;a.i=false}return b}
function X(a){a.u?lb(a.l):kb(a.l);if(yb(a.m)){if(a.u&&(O(),!(!!Ub&&!!Ub.l))){return B((O(),O(),N),new bb(a),83888128,null)}else{rb(a.m)}}return $(a)}
function bc(a){var b,c,d;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new mj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;6!=d&&xb(b,6,true)}}}
function cc(a){var b,c,d;if(a.i.g.length>0&&4==a.g){a.g=5;for(c=new mj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;4==d&&xb(b,5,true)}}}
function ac(a){var b,c;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new mj(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);5==(b.i&7)?xb(b,6,true):4==(b.i&7)&&(a.g=4)}}}
function ui(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function _c(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function A(b,c,d){var e,f;try{ec(b,d);try{f=(c.g.Q(),null)}finally{fc()}return f}catch(a){a=mh(a);if(jd(a,7)){e=a;throw nh(e)}else throw nh(a)}finally{I(b)}}
function ab(a,b,c,d){this.i=a;this.o=b;this.s=c;this.v=null;this.u=16384==(d&16384);this.m=new Bb(this,d&-16385);this.l=new nb(this.m);Gs==(d&Hs)&&qb(this.m)}
function Jm(){var a,b,c,d,e;this.i=new _j;this.j=new Tm;e=$wnd.localStorage.getItem(Ys);if(null!=e){for(b=si(e),c=0,d=b.length;c<d;++c){a=b[c];Vj(this.i,a)}}}
function vi(a){var b,c,d;d=new wk;for(c=Xj(a,0);c.h!=c.j.i;){b=ak(c);!d.g?(d.g=new Bi(d.j)):yi(d.g,d.h);yi(d.g,b)}return !d.g?d.i:d.l.length==0?d.g.g:d.g.g+(''+d.l)}
function Gb(a){var b,c;if(0==a.i){b=Qb(a.j);if(0==b){a.g=0;return false}else if(a.g+1>a.h){a.g=0;return false}else{a.g=a.g+1;a.i=b}}--a.i;c=Pb(a.j);Mb(c);return true}
function to(a){var b;b=rn(a.K);null!=a.D&&null!=b&&sn(a.K)&&null!=a.D&&b.getTracks().forEach(yh(oq.prototype.eb,oq,[a]));Cn(a.K);null!=a.D&&sn(a.K)&&null!=b&&Qn(a,b)}
function rh(b,c,d,e){qh();var f=oh;$moduleName=c;$moduleBase=d;lh=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Bs(g)()}catch(a){b(c,a)}}else{Bs(g)()}}
function yl(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Hr(a){var b;this.j=yh(vs.prototype.U,vs,[this]);this.h=a;this.i=a.props['a'];O();b=++Gr;this.g=new mc(b,null,null,false);qn(this.i,this,new Ir(this));I((null,N))}
function ik(){ik=xh;var a,b,c,d;fk=$c(rd,Es,234,25,15,1);gk=$c(rd,Es,234,33,15,1);d=1.52587890625E-5;for(b=32;b>=0;b--){gk[b]=d;d*=0.5}c=1;for(a=24;a>=0;a--){fk[a]=c;c*=0.5}}
function Ij(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Jj()}}
function io(a,b){var c;if(pd(a.D)===pd(b.currentTarget)){c=a.D.iceConnectionState;if(s('disconnected',c)||s('failed',c)||s('closed',c)){a.J.rb(new Cp);a.J=new kj;Z(a.h)}else{fo(a)}}}
function ij(a,b){var c,d,e,f;e=null;f=0;for(d=0;d<a.g.length;++d){c=a.g[d];if(b.fb(c)){if(e==null){e=_k(a.g,d);f=d}}else e!=null&&(e[f++]=c)}if(e==null){return false}a.g=e;return true}
function B(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Ub){g=c.R()}else{ec(b,e);try{g=c.R()}finally{fc()}}return g}catch(a){a=mh(a);if(jd(a,7)){f=a;throw nh(f)}else throw nh(a)}finally{I(b)}}
function co(a,b){if(null!=a.L){a.I.g=$c(ie,Es,1,0,5,1);a.L.close();a.L=null;Wo(a,b)}if(null!=a.D){a.J.rb(new Ep);a.J.vb();Oi(a.H.g);a.D.close();a.D=null;a.F=false;a.G=false;jb(a.i);Z(a.h)}}
function uh(){th={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Sc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].ac()&&(c=Rc(c,g)):g[0].ac()}catch(a){a=mh(a);if(jd(a,7)){d=a;Dc();Jc(jd(d,47)?d.$():d)}else throw nh(a)}}return c}
function xc(a){var b;if(a.i==null){b=pd(a.h)===pd(vc)?null:a.h;a.j=b==null?Ls:md(b)?b==null?null:b.name:od(b)?'String':Zh(v(b));a.g=a.g+': '+(md(b)?b==null?null:b.message:b+'');a.i='('+a.j+') '+a.g}}
function V(b){var c,d,e;e=b.v;try{d=b.i.R();if(!(pd(e)===pd(d)||e!=null&&u(e,d))){b.v=d;b.h=null;ib(b.l)}}catch(a){a=mh(a);if(jd(a,12)){c=a;if(!b.h){b.v=null;b.h=c;ib(b.l)}throw nh(c)}else throw nh(a)}}
function kk(a){var b,c,d,e,f,g;e=a.g*Ts+a.h*1502;g=a.h*Ts+11;b=$wnd.Math.floor(g*Us);e+=b;g-=b*Vs;e%=Vs;a.g=e;a.h=g;d=a.g*128;f=$wnd.Math.floor(a.h*gk[31]);c=d+f;c>=2147483648&&(c-=4294967296);return c}
function zj(a,b,c){var d,e,f,g,h;h=b==null?0:(g=w(b),g|0);e=(d=a.g.get(h),d==null?new Array:d);if(e.length==0){a.g.set(h,e)}else{f=wj(b,e);if(f){return f.Pb(c)}}e[e.length]=new _i(b,c);++a.h;return null}
function ml(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+qi(a,c++)}b=b|0;return b}
function al(a,b,c,d,e){var f,g,h,i,j;if(pd(a)===pd(c)){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function fo(a){var b;if(!a.F){b=(lb(a.m),a.u);if((Zp(),Xp)==b){a.F=true;a.D.createOffer().then(yh(qq.prototype.hb,qq,[a])).then(yh(rq.prototype.hb,rq,[a])).catch(yh(sq.prototype.ib,sq,[a]))}else{ro(a,rl(Ms,at))}}}
function rb(b){var c;if(1!=(b.i&7)){try{if(4!=(b.i&7)){if(0!=(b.i&512)){!!b.l&&(b.i&=-513);c=b.j;C((O(),O(),N),b,c)}else{b.l.Q()}}else 0!=(b.i&512)&&!!b.l&&(b.i&=-513)}catch(a){a=mh(a);if(jd(a,7)){O()}else throw nh(a)}}}
function Hi(a,b){var c,d,e;c=b.Nb();e=b.Ob();d=od(c)?c==null?Ji(yj(a.g,null)):Mj(a.h,c):Ji(yj(a.g,c));if(!(pd(e)===pd(d)||e!=null&&u(e,d))){return false}if(d==null&&!(od(c)?Li(a,c):!!yj(a.g,c))){return false}return true}
function T(a){var b,c,d,e,f,g;b=a.i?a.g.length-a.h+a.j:a.j-a.h;if(b+1>a.g.length){g=(a.g.length-1)*2+1;c=$c(ie,Es,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.h+d)%a.g.length;c[f]=a.g[e];a.g[e]=null;++f}a.g=c;a.h=0;a.j=f;a.i=false}}
function zb(a,b,c,d){this.h=new kj;this.m=new Ob(new Db(this),d&6520832|262144|Gs);this.i=d&-6520833|3;this.g=a;this.j=b;this.l=c;!!this.j&&(this.i|=512);!this.g&&!!this.j&&(H((O(),O(),N),this),0==(this.m.g&Is)&&I((null,N)))}
function xr(a){var b,c,d;this.l=a;this.o=a.props['a'];O();b=++tr;this.j=new mc(b,null,new yr(this),false);this.h=(d=new nb((c=null,c)),d);this.g=new Ab(null,new Cr(this),gt);!!this.o&&Lm(this.o,this,new zr(this));I((null,N))}
function Aj(a,b){var c,d,e,f,g,h;g=b==null?0:(f=w(b),f|0);d=(c=a.g.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(rj(b,e.Nb())){if(d.length==1){d.length=0;Dj(a.g,g)}else{d.splice(h,1)}--a.h;return e.Ob()}}return null}
function jq(){jq=xh;iq=new kq('NOT_READY',0);bq=new kq('CONNECTED',1);gq=new kq('JOIN_REQUESTED',2);fq=new kq('JOIN_REJECTED',3);eq=new kq('JOINED',4);aq=new kq('CLOSED',5);hq=new kq('LEFT',6);dq=new kq('FULL',7);cq=new kq('ERROR',8)}
function wh(a,b,c){var d=th,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=th[b]),zh(h));_.$b=c;!b&&(_._b=Bh);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.Zb=f)}
function Al(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ql(b,yh(Dl.prototype.Vb,Dl,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Ws]=c[0],undefined):(d[Ws]=c,undefined));return xl(a,e,f,d)}
function fi(a){if(a.pb()){var b=a.i;b.qb()?(a.v='['+b.u):!b.pb()?(a.v='[L'+b.nb()+';'):(a.v='['+b.nb());a.h=b.mb()+'[]';a.s=b.ob()+'[]';return}var c=a.m;var d=a.j;d=d.split('/');a.v=gi('.',[c,gi('$',d)]);a.h=gi('.',[c,gi('.',d)]);a.s=d[d.length-1]}
function yb(b){var c,d,e,f,g;g=b.i&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new mj(b.h);e.g<e.i.g.length;){d=(e.h=e.g++,e.i.g[e.h]);if(d.h){f=d.h;c=f.g;try{X(c)}catch(a){a=mh(a);if(!jd(a,7))throw nh(a)}if(6==(b.i&7)){return true}}}}}tb(b);return false}
function pc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.X();return a&&a.V()}},suppressed:{get:function(){return c.W()}}})}catch(a){}}}
function so(a){a.D=new $wnd.RTCPeerConnection(Oh({},[Rh({})]));a.F=false;a.G=false;a.D.onicecandidate=yh(Mp.prototype.jb,Mp,[a]);a.D.ontrack=yh(Np.prototype.kb,Np,[a]);a.D.onconnectionstatechange=yh(Bp.prototype.bb,Bp,[a]);a.D.onnegotiationneeded=yh(mq.prototype.bb,mq,[a]);eo(a,rn(a.B));eo(a,rn(a.K))}
function Hj(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function er(a){var b;this.s=new as(this);this.j=a;this.m=a.props['a'];this.o=a.props['b'];O();b=++ar;this.i=new mc(b,new fr(this),new gr(this),false);this.g=new ab(new mr,new hr(this),new ir(this),35815424);this.h=new Ab(null,new nr(this),gt);Lm(this.m,this,new jr(this));this.u=new Zo(this.o,(jq(),iq),(Zp(),Yp));Qo(this.u);Mm(this.m,this.o);I((null,N))}
function xb(a,b,c){var d,e,f,g;g=a.i&7;if(b!=g){a.i=a.i&-8|b;if(!a.g&&6==b){c&&(1==(a.i&7)||1==(3&a.m.g)||H((O(),O(),N),a))}else if(!!a.g&&4==g&&(6==b||5==b)){mb(a.g.l);c&&(1==(a.i&7)||1==(3&a.m.g)||H((O(),O(),N),a))}else if(3==b||3!=g&&2==b){if(a.g){d=a.g;wb((e=d.s,e));d.v=null}dj(a.h,new Fb(a));a.h.g=$c(ie,Es,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.g&&wb((f=a.g.o,f))}}
function si(a){var b,c,d,e,f,g,h,i;b=new RegExp('\\|','g');h=$c(le,Es,2,0,6,1);c=0;i=a;e=null;while(true){g=b.exec(i);if(g==null||i==''){h[c]=i;break}else{f=g.index;h[c]=i.substr(0,f);i=ti(i,f+g[0].length,i.length);b.lastIndex=0;if(e==i){h[c]=i.substr(0,1);i=i.substr(1)}e=i;++c}}if(a.length>0){d=h.length;while(d>0&&h[d-1]==''){--d}d<h.length&&(h.length=d)}return h}
function oo(a){var b,c;F((O(),O(),N),new ip(a),ft);wn(a.B,true);Z(a.g);Vo(a,(Zp(),Yp));Wo(a,(jq(),iq));a.L=new $wnd.WebSocket((b=$wnd.location,c=s('https',b.protocol)?'wss':'ws',c+'://'+b.hostname+':'+3737+'/r/'+a.C));a.L.onopen=yh(Ip.prototype.bb,Ip,[a]);a.L.onmessage=yh(Jp.prototype.cb,Jp,[a]);a.L.onclose=yh(Kp.prototype.ab,Kp,[a]);a.L.onerror=yh(Lp.prototype.bb,Lp,[a])}
function En(a,b,c){var d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;this.I=a;this.J=b;O();d=++mn;this.H=new mc(d,null,new Fn(this),true);this.A=c;this.G=true;this.h=(m=new nb((f=null,f)),m);this.o=(n=new nb((g=null,g)),n);this.l=(o=new nb((h=null,h)),o);this.j=(p=new nb((i=null,i)),p);this.i=(q=new nb((j=null,j)),q);this.u=(r=new nb((k=null,k)),r);this.s=(l=new nb((e=null,e)),l);this.g=new ab(new Gn(this),null,null,$s);this.m=new Ab(new Hn(this),null,404750336);I((null,N))}
function Zo(a,b,c){var d,e,f,g,h,i,j,k,l;this.I=new kj;this.H=new vj;this.B=new En(new Ap,new Fp(this),false);this.K=new En(new Gp,new Hp(this),false);this.J=new kj;this.C=a;O();d=++xo;this.A=new mc(d,new $o(this),new _o(this),true);this.v=b;this.u=c;this.s='';this.o=(i=new nb((f=null,f)),i);this.m=(j=new nb((g=null,g)),j);this.l=(k=new nb((e=null,e)),k);this.j=(l=new nb(null),l);this.i=(h=new nb(null),h);this.g=new ab(new ap(this),null,null,$s);this.h=new ab(new bp(this),null,null,$s)}
function Am(){Am=xh;em=new Bm(Xs,0);fm=new Bm('checkbox',1);gm=new Bm('color',2);hm=new Bm('date',3);im=new Bm('datetime',4);jm=new Bm('email',5);km=new Bm('file',6);lm=new Bm('hidden',7);mm=new Bm('image',8);nm=new Bm('month',9);om=new Bm('number',10);pm=new Bm('password',11);qm=new Bm('radio',12);rm=new Bm('range',13);sm=new Bm('reset',14);tm=new Bm('search',15);um=new Bm('submit',16);vm=new Bm('tel',17);wm=new Bm('text',18);xm=new Bm('time',19);ym=new Bm('url',20);zm=new Bm('week',21)}
function Xb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.l){return}j=(n=a.l.i&7,n>3?n:4);e=false;c=0;if(!!a.h&&1!=(a.l.i&7)){m=a.h.g.length;for(h=0;h<m;h++){k=ej(a.h,h);if(-1!=k.l&&-2!=k.l){k.l=-1;h!=c&&jj(a.h,c,k);++c;if(k.h){l=k.h;f=l.i&7;f==6&&(j=f)}}}}d=a.l.h;for(i=d.g.length-1;i>=0;i--){k=d.g[i];if(-1==k.l){k.l=0}else{hb(k,a.l);e=true}}2<(a.l.i&7)&&4!=j&&(a.l.i&7)<j&&xb(a.l,j,false);if(a.h){for(g=c-1;g>=0;g--){k=ej(a.h,g);if(-1==k.l){k.l=0;gb(k,a.l);e=true}}}if(a.h){for(g=a.h.g.length-1;g>=c;g--){gj(a.h,g)}e&&vb(a.l,a.h)}else{e&&vb(a.l,new kj)}if(db(a.l)&&!!a.l.g){b=a.l.g;k=b.l;!!k.h&&Gs!=(k.h.i&Hs)&&k.i.g.length<=0&&0==k.h.g.j&&_b(a,k)}}
function rr(a){var b,c,d,e;a.m=0;Em();b=(c=(lb(a.h),a.i),d=a.o,e=(kb(d.g),d.i),Al(jt,Nl(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['home'])),yh(ps.prototype.Wb,ps,[a])),[Al('h1',null,['vChat']),Al('label',Zl(new $wnd.Object,'roomCode'),['Enter a room code.']),Al('input',Il(Rl(Wl(Sl(Ul(Tl(Yl(Fl(Vl(El(Ml(new $wnd.Object,(Am(),wm)),bd(Yc(le,1),Es,2,6,['roomCodeInput'])),'Room code'),'roomCode'),null==c?'':c),yh(rs.prototype.Wb,rs,[a]))),10)))),null),Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['roomSelectButtons'])),[Al(Xs,Ml(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[nt])),(bm(),am)),['Join']),Al('a',Jl(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[nt])),'#'+Hm()),['Join Random'])]),e.h==0?null:wl([Al(pt,null,['Recently used rooms:']),wl(Lk(Hk(new Mk(null,new uk(e,16)),new qs),new Cl))])]));return b}
function Jj(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Ss]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Hj()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Ss]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function lo(a,b){var c,d,e,f,g,h;d=b.data;g=$wnd.JSON.parse(d);f=g;if(pd(a.L)===pd(b.currentTarget)){Z(a.g);c=f[Ms];if(s('create',c)){Dh(bd(Yc(ie,1),Es,1,5,['Connected to room as host']));Vo(a,(Zp(),Xp));Wo(a,(jq(),eq))}else if(s('connect',c)){Dh(bd(Yc(ie,1),Es,1,5,['Connected to room as guest']));Vo(a,(Zp(),Wp));Wo(a,(jq(),bq))}else if(s('full',c)){Dh(bd(Yc(ie,1),Es,1,5,['Room full. Leaving room.']));Vo(a,(Zp(),Yp));co(a,(jq(),dq))}else if(s(dt,c)){e=f['id'];h=f['message'];Dh(bd(Yc(ie,1),Es,1,5,["Guest '"+e+"' requested access to room with message '"+h+"'"]));bj(a.I,new Gm(e,h));jb(a.j)}else if(s('accept',c)){Dh(bd(Yc(ie,1),Es,1,5,['Host allowed guest to join room.']));Wo(a,(jq(),eq));so(a)}else if(s('reject',c)){Dh(bd(Yc(ie,1),Es,1,5,['Host rejected guest from room.']));Wo(a,(jq(),fq))}else if(s('accepted',c)){e=f['id'];Dh(bd(Yc(ie,1),Es,1,5,["Host accepted guest '"+e+"' into room."]));tj(a.H,e);jb(a.i)}else if(s('remove',c)){e=f['id'];if(uj(a.H,e)){Dh(bd(Yc(ie,1),Es,1,5,["Guest '"+e+et]));jb(a.i)}else if(ij(a.I,new yq(e))){Dh(bd(Yc(ie,1),Es,1,5,["Client '"+e+et]));jb(a.j)}}else if(s('offer',c)){a.F=true;a.D.setRemoteDescription(f[_s]);a.D.createAnswer().then(yh(zq.prototype.hb,zq,[a])).then(yh(Aq.prototype.hb,Aq,[a])).catch(yh(Bq.prototype.ib,Bq,[a]))}else if(s('answer',c)){a.D.setRemoteDescription(f[_s]);a.F=false;go(a)}else s(bt,c)?a.D.addIceCandidate(Ph(Qh({},f[ct]),f[bt])):s(at,c)&&(a.G=true,go(a))}}
function $q(a){var b,c,d;a.l=0;Em();b=(c=a.u.B,d=X(a.u.g),Al(pt,Hl(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['room-view'])),yh(bs.prototype.U,bs,[a])),[Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['video-section'])),[Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['video-list'])),Lk(Hk(X(a.u.h).Ab(),new Zr),new Cl)),Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['active-video'])),[Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['active-video-wrapper'])),[zs(xs(ws(a.u.B),'active-video-element'),true)]),Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['controls'])),[Al(Xs,Ll(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[rt])),yh(fs.prototype.Xb,fs,[a])),[Al(st,Ol(Ql(Pl(new $wnd.Object,sn(a.u.K)?'img/screen_share_on.svg':'img/screen_share_off.svg'),32),32),null)]),Al(Xs,Ll(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[rt])),yh(gs.prototype.Xb,gs,[c])),[Al(st,Ol(Ql(Pl(new $wnd.Object,X(c.g)?tt:ut),32),32),null)]),Al(Xs,Ll(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[rt])),yh(hs.prototype.Xb,hs,[c])),[Al(st,Ol(Ql(Pl(new $wnd.Object,(kb(c.u),c.G?'img/cam_on.svg':'img/cam_off.svg')),32),32),null)]),Al(Xs,Ll(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[rt])),yh(is.prototype.Xb,is,[a])),[Al(st,Ol(Ql(Pl(new $wnd.Object,X(a.g)?'img/fullscreen_on.svg':'img/fullscreen_off.svg'),32),32),null)]),Al(Xs,Ll(El(Kl(new $wnd.Object,(Tp(),Qp)!=d&&Sp!=d),bd(Yc(le,1),Es,2,6,[rt])),yh(js.prototype.Xb,js,[a])),[Al(st,Ol(Ql(Pl(new $wnd.Object,'img/hangup.svg'),32),32),null)])])])]),Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['message-area'])),[Xq(a)])]));return b}
function Xq(a){var b,c;c=Xo(a.u);if((jq(),iq)==c){return wl([Al(it,null,['Getting ready...']),Al('p',null,["You'll be able to join in just a moment."])])}else if(cq==c){return wl([Al(it,null,['Service Offline']),Al('p',null,['The chat service is offline at the moment. Try again later.'])])}else if(bq==c){return wl([Al(it,null,['Ready to join?']),Al('p',null,['Request access to join the room.']),Al(jt,Nl(new $wnd.Object,yh(_r.prototype.Wb,_r,[a])),[Al('label',Zl(new $wnd.Object,kt),[lt]),Al('input',Wl(Sl(Yl(Tl(Rl(Fl(Vl(Ml(new $wnd.Object,(Am(),wm)),mt),kt)),yh(es.prototype.Wb,es,[a])),To(a.u)),30)),null),Al(Xs,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[nt])),[ot])])])}else if(gq==c){return wl([Al(it,null,['Joining room']),Al('p',null,['Waiting for host to allow access to the room.'])])}else if(eq==c&&(Zp(),Xp)==Uo(a.u)&&Do(a.u).g.length!=0){b=Do(a.u).g[0];return wl([Al(it,null,['Guest requests access']),Al('p',null,['A guest has sent you a message to join the room:']),Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['request-message'])),[b.h]),Al(jt,Nl(new $wnd.Object,yh($r.prototype.Wb,$r,[])),[Al(Xs,Ll(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[nt])),yh(cs.prototype.Xb,cs,[a,b])),['Accept']),Al(Xs,Ll(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[nt])),yh(ds.prototype.Xb,ds,[a,b])),['Reject'])])])}else return eq==c&&(Zp(),Xp)==Uo(a.u)&&Pi(Co(a.u).g)==0?wl([Al(it,null,['Waiting for guests to join']),Al('p',null,['Waiting for someone to join this room']),Al('a',Jl(new $wnd.Object,'#'+a.u.C),[a.u.C])]):eq==c?wl([Al(it,null,['Joined room']),Al('p',null,['Joined room. Feel free to chat.'])]):fq==c?wl([Al(it,null,['Access denied']),Al('p',null,['The host denied access to the room. You can attempt to re-request access to join the room.']),Al(jt,Nl(new $wnd.Object,yh(_r.prototype.Wb,_r,[a])),[Al('label',Zl(new $wnd.Object,kt),[lt]),Al('input',Wl(Sl(Yl(Tl(Rl(Fl(Vl(Ml(new $wnd.Object,(Am(),wm)),mt),kt)),yh(es.prototype.Wb,es,[a])),To(a.u)),30)),null),Al(Xs,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[nt])),[ot])])]):aq==c?wl([Al(it,null,['Room closed']),Al('p',null,[(Zp(),Xp)==Uo(a.u)?'You closed the room.':'The host closed the room.']),Al('a',Jl(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[nt])),'#'),[qt])]):dq==c?wl([Al(it,null,['Room full']),Al('p',null,['The room is full and no other guests can connect at this time.']),Al('a',Jl(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[nt])),'#'),[qt])]):hq==c?wl([Al(it,null,['Left the room']),Al('p',null,['You left the room.']),Al('a',Jl(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,[nt])),'#'),[qt])]):null}
var Cs='object',Ds={5:1},Es={3:1},Fs={10:1},Gs=1048576,Hs=1835008,Is=2097152,Js='__noinit__',Ks={3:1,12:1,9:1,7:1},Ls='null',Ms='command',Ns='hashchange',Os={30:1,68:1},Ps={30:1,62:1},Qs={43:1},Rs={3:1,30:1,62:1},Ss='delete',Ts=15525485,Us=5.9604644775390625E-8,Vs=16777216,Ws='children',Xs='button',Ys='vchat.rooms',Zs=142606336,$s=35651584,_s='session',at='renegotiate',bt='candidate',ct='mlineindex',dt='request_access',et="' left the room.",ft=75497472,gt=1411518464,ht='fullscreenchange',it='h2',jt='form',kt='requestAccessMessage',lt='Enter a message to send to the host to request access.',mt="Hi, I'm John Doe.",nt='primary-button',ot='Request Access',pt='div',qt='Return to Home',rt='control-btn',st='img',tt='img/mic_on.svg',ut='img/mic_off.svg';var _,th,oh,lh=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;uh();wh(1,null,{},t);_.M=function(a){return s(this,a)};_.N=function(){return this.Zb};_.O=wt;_.P=function(){var a;return Zh(v(this))+'@'+(a=w(this)>>>0,a.toString(16))};_.equals=function(a){return this.M(a)};_.hashCode=function(){return this.O()};_.toString=function(){return this.P()};var dd,ed,fd;wh(70,1,{},$h);_.lb=function(a){var b;b=new $h;b.l=4;a>1?(b.i=di(this,a-1)):(b.i=this);return b};_.mb=function(){Yh(this);return this.h};_.nb=function(){return Zh(this)};_.ob=function(){Yh(this);return this.s};_.pb=function(){return (this.l&4)!=0};_.qb=function(){return (this.l&1)!=0};_.P=function(){return ((this.l&2)!=0?'interface ':(this.l&1)!=0?'':'class ')+(Yh(this),this.v)};_.l=0;_.o=0;var Xh=1;var ie=ai(1);var $d=ai(70);wh(102,1,{},J);_.h=1;_.i=false;_.j=true;_.l=0;var xd=ai(102);wh(103,1,Ds,K);_.Q=function(){Hb(this.g)};var ud=ai(103);wh(56,1,{},L);_.R=function(){return this.g.Q(),null};var vd=ai(56);wh(104,1,{},M);var wd=ai(104);var N;wh(57,1,{57:1},U);_.h=0;_.i=false;_.j=0;var yd=ai(57);wh(258,1,Fs);_.P=function(){var a;return Zh(this.Zb)+'@'+(a=w(this)>>>0,a.toString(16))};var Bd=ai(258);wh(37,258,Fs,ab);_.S=function(){W(this)};_.T=vt;_.g=false;_.j=0;_.u=false;var Ad=ai(37);wh(141,1,{},bb);_.R=function(){return Y(this.g)};var zd=ai(141);wh(11,258,{10:1,11:1},nb);_.S=function(){eb(this)};_.T=function(){return -2==this.l};_.g=4;_.j=false;_.l=0;var Dd=ai(11);wh(140,1,Ds,ob);_.Q=function(){fb(this.g)};var Cd=ai(140);wh(23,258,{10:1,23:1},Ab,Bb);_.S=function(){pb(this)};_.T=function(){return 1==(this.i&7)};_.i=0;var Id=ai(23);wh(135,1,{},Cb);_.Q=function(){V(this.g)};var Ed=ai(135);wh(136,1,Ds,Db);_.Q=function(){rb(this.g)};var Fd=ai(136);wh(137,1,Ds,Eb);_.Q=function(){ub(this.g)};var Gd=ai(137);wh(138,1,{},Fb);_.U=function(a){sb(this.g,a)};var Hd=ai(138);wh(115,1,{},Ib);_.g=0;_.h=0;_.i=0;var Jd=ai(115);wh(146,1,Fs,Kb);_.S=function(){Jb(this)};_.T=vt;_.g=false;var Kd=ai(146);wh(81,258,{10:1,81:1},Ob);_.S=function(){Lb(this)};_.T=function(){return 2==(3&this.g)};_.g=0;var Md=ai(81);wh(114,1,{},Tb);var Ld=ai(114);wh(147,1,{},dc);_.P=function(){var a;return Yh(Nd),Nd.v+'@'+(a=hl(this)>>>0,a.toString(16))};_.g=0;var Ub;var Nd=ai(147);wh(22,1,Fs,mc);_.S=function(){hc(this)};_.T=function(){return this.s<0};_.P=function(){var a;return Yh(Pd),Pd.v+'@'+(a=hl(this)>>>0,a.toString(16))};_.j=0;_.s=0;var Pd=ai(22);wh(134,1,Ds,nc);_.Q=function(){kc(this.g)};var Od=ai(134);wh(7,1,{3:1,7:1});_.V=Et;_.W=function(){return Lk(Hk(oj((this.s==null&&(this.s=$c(ne,Es,7,0,0,1)),this.s)),new Ci),new Pk)};_.X=function(){return this.m};_.Y=function(){return this.o};_.Z=function(){qc(this,sc(new Error(rc(this,this.o))));Vc(this)};_.P=function(){return rc(this,this.Y())};_.l=Js;_.u=true;var ne=ai(7);wh(12,7,{3:1,12:1,7:1});var be=ai(12);wh(9,12,Ks);var je=ai(9);wh(97,9,Ks);var ge=ai(97);wh(98,97,Ks);var Td=ai(98);wh(47,98,{47:1,3:1,12:1,9:1,7:1},yc);_.Y=function(){xc(this);return this.i};_.$=function(){return pd(this.h)===pd(vc)?null:this.h};var vc;var Qd=ai(47);var Rd=ai(0);wh(241,1,{});var Sd=ai(241);var Ac=0,Bc=0,Cc=-1;wh(107,241,{},Qc);var Mc;var Ud=ai(107);var Tc;wh(252,1,{});var Wd=ai(252);wh(99,252,{},Xc);var Vd=ai(99);wh(72,1,{95:1});_.P=vt;var Xd=ai(72);wh(101,9,Ks);var ee=ai(101);wh(139,101,Ks,Vh);var Yd=ai(139);dd={3:1,96:1,21:1};var Zd=ai(96);wh(55,1,{3:1,55:1});var he=ai(55);ed={3:1,21:1,55:1};var _d=ai(251);wh(15,1,{3:1,21:1,15:1});_.M=function(a){return this===a};_.O=wt;_.P=function(){return this.g!=null?this.g:''+this.h};_.h=0;var ae=ai(15);wh(71,9,Ks,ji);var ce=ai(71);wh(100,9,Ks,ki);var de=ai(100);wh(35,55,{3:1,21:1,35:1,55:1},li);_.M=function(a){return jd(a,35)&&a.g==this.g};_.O=vt;_.P=function(){return ''+this.g};_.g=0;var fe=ai(35);var ni;wh(355,1,{});fd={3:1,95:1,21:1,2:1};var le=ai(2);wh(54,72,{95:1},Ai,Bi);var ke=ai(54);wh(359,1,{});wh(93,1,{},Ci);_.tb=function(a){return a.l};var me=ai(93);wh(46,9,Ks,Di,Ei);var oe=ai(46);wh(253,1,{30:1});_.rb=Dt;_.zb=function(){return new uk(this,0)};_.Ab=function(){return new Mk(null,this.zb())};_.ub=function(a){throw nh(new Ei('Add not supported on this collection'))};_.vb=function(){var a;for(a=this.sb();a.Eb();){a.Fb();a.Gb()}};_.wb=function(a){return Fi(this,a,false)};_.xb=function(){return this.yb()==0};_.Bb=function(){return this.Cb($c(ie,Es,1,this.yb(),5,1))};_.Cb=function(a){var b,c,d,e;e=this.yb();a.length<e&&(a=el(new Array(e),a));d=a;c=this.sb();for(b=0;b<e;++b){d[b]=c.Fb()}a.length>e&&(a[e]=null);return a};_.P=function(){var a,b,c;c=new xk(', ','[',']');for(b=this.sb();b.Eb();){a=b.Fb();vk(c,a===this?'(this Collection)':a==null?Ls:Ah(a))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var pe=ai(253);wh(256,1,{238:1});_.M=function(a){var b,c,d;if(a===this){return true}if(!jd(a,48)){return false}d=a;if(this.g.h+this.h.h!=d.g.h+d.h.h){return false}for(c=new Vi((new Ri(d)).g);c.h;){b=Ti(c);if(!Hi(this,b)){return false}}return true};_.O=function(){return pj(new Ri(this))};_.P=function(){var a,b,c;c=new xk(', ','{','}');for(b=new Vi((new Ri(this)).g);b.h;){a=Ti(b);vk(c,Ii(this,a.Nb())+'='+Ii(this,a.Ob()))}return !c.g?c.i:c.l.length==0?c.g.g:c.g.g+(''+c.l)};var Be=ai(256);wh(116,256,{238:1});var se=ai(116);wh(255,253,Os);_.zb=function(){return new uk(this,1)};_.M=function(a){var b;if(a===this){return true}if(!jd(a,68)){return false}b=a;if(b.yb()!=this.yb()){return false}return Gi(this,b)};_.O=function(){return pj(this)};var De=ai(255);wh(33,255,Os,Ri);_.vb=zt;_.wb=function(a){return Qi(this,a)};_.sb=function(){return new Vi(this.g)};_.yb=At;var re=ai(33);wh(36,1,{},Vi);_.Db=xt;_.Fb=function(){return Ti(this)};_.Eb=Bt;_.Gb=function(){Ui(this)};_.h=false;var qe=ai(36);wh(254,253,Ps);_.zb=function(){return new uk(this,16)};_.Hb=function(a,b){throw nh(new Ei('Add not supported on this list'))};_.ub=function(a){this.Hb(this.yb(),a);return true};_.vb=function(){this.Lb(0,this.yb())};_.M=function(a){var b,c,d,e,f;if(a===this){return true}if(!jd(a,62)){return false}f=a;if(this.yb()!=f.yb()){return false}e=f.sb();for(c=this.sb();c.Eb();){b=c.Fb();d=e.Fb();if(!(pd(b)===pd(d)||b!=null&&u(b,d))){return false}}return true};_.O=function(){return qj(this)};_.sb=function(){return new Xi(this)};_.Jb=function(a){return new Yi(this,a)};_.Kb=function(a){throw nh(new Ei('Remove not supported on this list'))};_.Lb=function(a,b){var c,d;d=this.Jb(a);for(c=a;c<b;++c){d.Fb();d.Gb()}};var ve=ai(254);wh(73,1,{},Xi);_.Db=xt;_.Eb=function(){return this.h<this.j.yb()};_.Fb=function(){this.h<this.j.yb();return this.j.Ib(this.i=this.h++)};_.Gb=yt;_.h=0;_.i=-1;var te=ai(73);wh(106,73,{},Yi);_.Gb=yt;_.Mb=function(a){this.g.Hb(this.h,a);++this.h;this.i=-1};var ue=ai(106);wh(110,255,Os,Zi);_.vb=zt;_.wb=Ct;_.sb=function(){var a;return a=new Vi((new Ri(this.g)).g),new $i(a)};_.yb=At;var xe=ai(110);wh(74,1,{},$i);_.Db=xt;_.Eb=function(){return this.g.h};_.Fb=function(){var a;a=Ti(this.g);return a.Nb()};_.Gb=function(){Ui(this.g)};var we=ai(74);wh(108,1,Qs);_.M=function(a){var b;if(!jd(a,43)){return false}b=a;return rj(this.g,b.Nb())&&rj(this.h,b.Ob())};_.Nb=vt;_.Ob=Bt;_.O=function(){return ek(this.g)^ek(this.h)};_.Pb=function(a){var b;b=this.h;this.h=a;return b};_.P=function(){return this.g+'='+this.h};var ye=ai(108);wh(109,108,Qs,_i);var ze=ai(109);wh(257,1,Qs);_.M=function(a){var b;if(!jd(a,43)){return false}b=a;return rj(this.h.value[0],b.Nb())&&rj(Rj(this),b.Ob())};_.O=function(){return ek(this.h.value[0])^ek(Rj(this))};_.P=function(){return this.h.value[0]+'='+Rj(this)};var Ae=ai(257);wh(260,254,Ps);_.Hb=function(a,b){var c;c=this.Jb(a);c.Mb(b)};_.Ib=function(a){var b;b=this.Jb(a);return b.Fb()};_.sb=function(){return Xj(this,0)};_.Kb=function(a){var b,c;b=this.Jb(a);c=b.Fb();b.Gb();return c};var Ce=ai(260);wh(14,254,Rs,kj,lj);_.Hb=function(a,b){bl(this.g,a,b)};_.ub=function(a){return bj(this,a)};_.vb=function(){this.g=$c(ie,Es,1,0,5,1)};_.wb=function(a){return fj(this,a,0)!=-1};_.rb=function(a){dj(this,a)};_.Ib=function(a){return ej(this,a)};_.xb=function(){return this.g.length==0};_.sb=function(){return new mj(this)};_.Kb=function(a){return gj(this,a)};_.Lb=function(a,b){var c;c=b-a;dl(this.g,a,c)};_.yb=function(){return this.g.length};_.Bb=function(){return _k(this.g,this.g.length)};_.Cb=function(a){var b,c;c=this.g.length;a.length<c&&(a=el(new Array(c),a));for(b=0;b<c;++b){a[b]=this.g[b]}a.length>c&&(a[c]=null);return a};var Fe=ai(14);wh(27,1,{},mj);_.Db=xt;_.Eb=function(){return this.g<this.i.g.length};_.Fb=function(){return this.h=this.g++,this.i.g[this.h]};_.Gb=function(){gj(this.i,this.g=this.h);this.h=-1};_.g=0;_.h=-1;var Ee=ai(27);wh(48,116,{3:1,48:1,238:1},sj);var Ge=ai(48);wh(166,255,{3:1,30:1,68:1},vj);_.ub=function(a){return tj(this,a)};_.vb=zt;_.wb=Ct;_.xb=function(){return Pi(this.g)==0};_.sb=function(){var a;return a=new Vi((new Ri((new Zi(this.g)).g)).g),new $i(a)};_.yb=At;var He=ai(166);wh(75,1,{},Bj);_.rb=Dt;_.sb=function(){return new Cj(this)};_.h=0;var Je=ai(75);wh(76,1,{},Cj);_.Db=xt;_.Fb=function(){return this.j=this.g[this.i++],this.j};_.Eb=function(){var a;if(this.i<this.g.length){return true}a=this.h.next();if(!a.done){this.g=a.value[1];this.i=0;return true}return false};_.Gb=function(){Aj(this.l,this.j.Nb());this.i!=0&&--this.i};_.i=0;_.j=null;var Ie=ai(76);var Fj;wh(77,1,{},Pj);_.rb=Dt;_.sb=function(){return new Qj(this)};_.h=0;_.i=0;var Me=ai(77);wh(78,1,{},Qj);_.Db=xt;_.Fb=function(){return this.i=this.g,this.g=this.h.next(),new Sj(this.j,this.i,this.j.i)};_.Eb=function(){return !this.g.done};_.Gb=function(){Oj(this.j,this.i.value[0])};var Ke=ai(78);wh(117,257,Qs,Sj);_.Nb=function(){return this.h.value[0]};_.Ob=function(){return Rj(this)};_.Pb=function(a){return Nj(this.g,this.h.value[0],a)};_.i=0;var Le=ai(117);wh(157,260,Rs,_j);_.ub=function(a){Wj(this,a,this.i.h,this.i);return true};_.vb=function(){$j(this)};_.Jb=function(a){return Xj(this,a)};_.yb=Bt;_.h=0;var Pe=ai(157);wh(158,1,{},bk);_.Db=xt;_.Mb=function(a){Wj(this.j,a,this.h.h,this.h);++this.g;this.i=null};_.Eb=function(){return this.h!=this.j.i};_.Fb=function(){return ak(this)};_.Gb=function(){var a;a=this.i.g;Zj(this.j,this.i);this.h==this.i?(this.h=a):--this.g;this.i=null};_.g=0;_.i=null;var Ne=ai(158);wh(59,1,{},ck);var Oe=ai(59);wh(200,1,{},lk);_.g=0;_.h=0;var fk,gk,hk=0;var Qe=ai(200);wh(119,1,{});_.Db=Ft;_.Qb=function(){return this.j};_.Rb=Et;_.j=0;_.l=0;var Ue=ai(119);wh(79,119,{});var Re=ai(79);wh(111,1,{});_.Db=Ft;_.Qb=Bt;_.Rb=function(){return this.j-this.i};_.h=0;_.i=0;_.j=0;var Te=ai(111);wh(112,111,{},sk);_.Db=function(a){pk(this,a)};_.Sb=function(a){return qk(this,a)};var Se=ai(112);wh(28,1,{},uk);_.Qb=vt;_.Rb=function(){tk(this);return this.i};_.Db=function(a){tk(this);this.j.Db(a)};_.Sb=function(a){tk(this);if(this.j.Eb()){a.U(this.j.Fb());return true}return false};_.g=0;_.i=0;var Ve=ai(28);wh(45,1,{},wk,xk);_.P=function(){return !this.g?this.i:this.l.length==0?this.g.g:this.g.g+(''+this.l)};var We=ai(45);wh(69,1,{},yk);_.tb=function(a){return a};var Xe=ai(69);wh(82,1,{},zk);var Ye=ai(82);wh(118,1,{});_.i=false;var gf=ai(118);wh(29,118,{},Mk);var Dk;var ff=ai(29);wh(94,1,{},Pk);_.Tb=function(a){return Ek(),$c(ie,Es,1,a,5,1)};var Ze=ai(94);wh(80,79,{},Rk);_.Sb=function(a){this.h=false;while(!this.h&&this.i.Sb(new Sk(this,a)));return this.h};_.h=false;var _e=ai(80);wh(123,1,{},Sk);_.U=function(a){Qk(this.g,this.h,a)};var $e=ai(123);wh(120,79,{},Uk);_.Sb=function(a){return this.h.Sb(new Vk(this,a))};var bf=ai(120);wh(122,1,{},Vk);_.U=function(a){Tk(this.g,this.h,a)};var af=ai(122);wh(121,1,{},Xk);_.U=function(a){Wk(this,a)};var cf=ai(121);wh(124,1,{},Yk);_.U=function(a){Ek()};var df=ai(124);wh(125,1,{},$k);_.U=function(a){Zk(this,a)};var ef=ai(125);wh(357,1,{});wh(354,1,{});var gl=0;var il,jl=0,kl;wh(1354,1,{});wh(1386,1,{});wh(83,1,{},Cl);_.Tb=function(a){return new Array(a)};var hf=ai(83);wh(307,$wnd.Function,{},Dl);_.Vb=function(a){Bl(this.g,this.h,a)};wh(38,15,{3:1,21:1,15:1,38:1},cm);var $l,_l,am;var jf=bi(38,dm);wh(8,15,{3:1,21:1,15:1,8:1},Bm);var em,fm,gm,hm,im,jm,km,lm,mm,nm,om,pm,qm,rm,sm,tm,um,vm,wm,xm,ym,zm;var kf=bi(8,Cm);var Dm;wh(292,$wnd.Function,{},Fm);_._=function(a){return Jb(Dm),Dm=null,null};wh(86,1,{86:1},Gm);var lf=ai(86);wh(58,1,{58:1});var mf=ai(58);wh(148,58,{10:1,58:1},Nm);_.S=Gt;_.T=Ht;_.P=function(){var a;return Yh(qf),qf.v+'@'+(a=hl(this)>>>0,a.toString(16))};var Km=0;var qf=ai(148);wh(149,1,Ds,Om);_.Q=function(){cb(this.g.j)};var nf=ai(149);wh(150,1,Ds,Pm);_.Q=function(){eb(this.g.g)};var of=ai(150);wh(151,1,Ds,Qm);_.Q=function(){Im(this.g,this.h)};var pf=ai(151);wh(159,1,{});var bg=ai(159);wh(160,159,Fs,Tm);_.S=Gt;_.T=Ht;_.P=function(){var a;return Yh(wf),wf.v+'@'+(a=hl(this)>>>0,a.toString(16))};var Rm=0;var wf=ai(160);wh(161,1,Ds,Um);_.Q=function(){W(this.g.g)};var rf=ai(161);wh(163,1,{},Vm);_.Q=function(){Eh(this.g.i)};var sf=ai(163);wh(164,1,{},Wm);_.Q=function(){Fh(this.g.i)};var tf=ai(164);wh(162,1,{},Xm);_.R=function(){var a;return a=$wnd.location.hash,a.length==0?a:a.substr(1)};var uf=ai(162);wh(165,1,Ds,Ym);_.Q=Lt;var vf=ai(165);wh(60,1,{60:1});_.K=0;var cg=ai(60);wh(61,60,{10:1,60:1},En);_.S=function(){hc(this.H)};_.T=function(){return this.H.s<0};_.P=function(){var a;return Yh(If),If.v+'@'+(a=hl(this)>>>0,a.toString(16))};_.v=false;_.A=false;_.G=false;var mn=0;var If=ai(61);wh(221,1,Ds,Fn);_.Q=function(){nn(this.g)};var xf=ai(221);wh(222,1,{},Gn);_.R=function(){return tn(this.g)};var yf=ai(222);wh(223,1,{},Hn);_.Q=function(){cn(this.g)};var zf=ai(223);wh(224,1,Ds,In);_.Q=function(){on(this.g,this.h)};var Af=ai(224);wh(87,1,Ds,Jn);_.Q=function(){en(this.g,this.h)};_.h=false;var Bf=ai(87);wh(225,1,Ds,Kn);_.Q=function(){un(this.g)};var Cf=ai(225);wh(226,1,Ds,Ln);_.Q=function(){jn(this.g)};var Df=ai(226);wh(227,1,Ds,Mn);_.Q=function(){kn(this.g)};var Ef=ai(227);wh(228,1,Ds,Nn);_.Q=function(){fn(this.g,this.h)};var Ff=ai(228);wh(229,1,Ds,On);_.Q=function(){gn(this.g)};var Gf=ai(229);wh(230,1,Ds,Pn);_.Q=function(){hn(this.g,this.h)};var Hf=ai(230);wh(201,1,{});_.F=false;_.G=false;var ug=ai(201);wh(202,201,Fs,Zo);_.S=function(){hc(this.A)};_.T=function(){return this.A.s<0};_.P=function(){var a;return Yh(_f),_f.v+'@'+(a=hl(this)>>>0,a.toString(16))};var xo=0;var _f=ai(202);wh(203,1,Ds,$o);_.Q=function(){zo(this.g)};var Jf=ai(203);wh(204,1,Ds,_o);_.Q=function(){yo(this.g)};var Kf=ai(204);wh(205,1,{},ap);_.R=function(){return Eo(this.g)};var Lf=ai(205);wh(206,1,{},bp);_.R=function(){return Rn(this.g)};var Mf=ai(206);wh(207,1,Ds,cp);_.Q=function(){Ao(this.g,this.h)};var Nf=ai(207);wh(208,1,Ds,dp);_.Q=function(){to(this.g)};var Of=ai(208);wh(209,1,Ds,ep);_.Q=function(){oo(this.g)};var Pf=ai(209);wh(210,1,Ds,fp);_.Q=function(){io(this.g,this.h)};var Qf=ai(210);wh(211,1,Ds,gp);_.Q=function(){no(this.g,this.h)};var Rf=ai(211);wh(212,1,Ds,hp);_.Q=function(){mo(this.g,this.h)};var Sf=ai(212);wh(85,1,Ds,ip);_.Q=function(){co(this.g,(jq(),hq))};var Tf=ai(85);wh(213,1,Ds,jp);_.Q=function(){jo(this.g,this.h)};var Uf=ai(213);wh(214,1,Ds,kp);_.Q=function(){Fo(this.g,this.h)};var Vf=ai(214);wh(215,1,Ds,lp);_.Q=function(){ho(this.g,this.h)};var Wf=ai(215);wh(216,1,Ds,mp);_.Q=function(){lo(this.g,this.h)};var Xf=ai(216);wh(217,1,Ds,np);_.Q=function(){qo(this.g)};var Yf=ai(217);wh(218,1,Ds,op);_.Q=function(){Go(this.g,this.h)};var Zf=ai(218);wh(219,1,Ds,pp);_.Q=function(){Ho(this.g,this.h)};var $f=ai(219);wh(145,1,{},qp);_.handleEvent=function(a){Sm(this.g)};var ag=ai(145);wh(336,$wnd.Function,{},rp);_.fb=function(a){return a.enabled};wh(329,$wnd.Function,{},sp);_.eb=It;wh(330,$wnd.Function,{},tp);_.eb=It;wh(331,$wnd.Function,{},up);_.hb=function(a){return $m(this.g,this.h,a)};_.h=0;wh(332,$wnd.Function,{},vp);_.ib=function(a){return _m(this.g,this.h,a)};_.h=0;wh(333,$wnd.Function,{},wp);_.eb=function(a){an(this.g,a)};wh(335,$wnd.Function,{},xp);_.bb=function(a){bn(this.g)};wh(334,$wnd.Function,{},yp);_.eb=function(a){ln(a)};wh(269,$wnd.Function,{},zp);_.eb=function(a){s('live',a.readyState)&&a.stop()};wh(185,1,{},Ap);_.Ub=function(){return $wnd.navigator.mediaDevices.getUserMedia(Lh(Kh({}),Mh(Nh({},Hh(Gh(Ih({},160),640),1280)),Hh(Gh(Ih({},120),360),720))))};var dg=ai(185);wh(317,$wnd.Function,{},Bp);_.bb=function(a){Ko(this.g,a)};wh(189,1,{},Cp);_.U=Jt;var eg=ai(189);wh(328,$wnd.Function,{},Dp);_.gb=function(a){Oo(this.g,a)};wh(194,1,{},Ep);_.U=Jt;var fg=ai(194);wh(186,1,{},Fp);_.U=Kt;var gg=ai(186);wh(187,1,{},Gp);_.Ub=function(){return $wnd.navigator.mediaDevices.getDisplayMedia(Jh({}))};var hg=ai(187);wh(188,1,{},Hp);_.U=Kt;var ig=ai(188);wh(310,$wnd.Function,{},Ip);_.bb=function(a){No(this.g,a)};wh(311,$wnd.Function,{},Jp);_.cb=function(a){Mo(this.g,a)};wh(312,$wnd.Function,{},Kp);_.ab=function(a){Jo(this.g,a)};wh(313,$wnd.Function,{},Lp);_.bb=function(a){Lo(this.g,a)};wh(315,$wnd.Function,{},Mp);_.jb=function(a){ko(this.g,a)};wh(316,$wnd.Function,{},Np);_.kb=function(a){Po(this.g,a)};wh(24,15,{3:1,21:1,15:1,24:1},Up);var Op,Pp,Qp,Rp,Sp;var jg=bi(24,Vp);wh(39,15,{3:1,21:1,15:1,39:1},$p);var Wp,Xp,Yp;var kg=bi(39,_p);wh(16,15,{3:1,21:1,15:1,16:1},kq);var aq,bq,cq,dq,eq,fq,gq,hq,iq;var lg=bi(16,lq);wh(318,$wnd.Function,{},mq);_.bb=function(a){fo(this.g)};wh(319,$wnd.Function,{},nq);_.eb=function(a){Sn(this.g,this.h,a)};wh(308,$wnd.Function,{},oq);_.eb=function(a){Tn(this.g,a)};wh(327,$wnd.Function,{},pq);_.fb=function(a){return uo(this.g,a)};wh(320,$wnd.Function,{},qq);_.hb=function(a){return Un(this.g,a)};wh(321,$wnd.Function,{},rq);_.hb=function(a){return Vn(this.g)};wh(322,$wnd.Function,{},sq);_.ib=function(a){return Wn(this.g,a)};wh(323,$wnd.Function,{},tq);_.eb=function(a){Xn(this.g,a)};wh(190,1,{},uq);_.fb=function(a){return Yn(this.g,a)};var mg=ai(190);wh(191,1,{},vq);_.U=function(a){};var ng=ai(191);wh(192,1,{},wq);_.Ub=function(){return $wnd.Promise.resolve(this.g)};var og=ai(192);wh(193,1,{},xq);_.fb=function(a){return Zn(this.g,a)};var pg=ai(193);wh(195,1,{},yq);_.fb=function(a){return vo(this.g,a)};var qg=ai(195);wh(324,$wnd.Function,{},zq);_.hb=function(a){return $n(this.g,a)};wh(325,$wnd.Function,{},Aq);_.hb=function(a){return _n(this.g)};wh(326,$wnd.Function,{},Bq);_.ib=function(a){return ao(this.g,a)};wh(196,1,Ds,Cq);_.Q=function(){bo(this.g,this.h)};var rg=ai(196);wh(197,1,Ds,Dq);_.Q=function(){ro(this.g,sl('reject_access','id',this.h.g))};var sg=ai(197);wh(198,1,{},Eq);_.fb=function(a){return wo(this.g,a)};var tg=ai(198);wh(127,1,{});var wg=ai(127);wh(92,1,{},Fq);var vg=ai(92);wh(128,127,{});_.j=0;var Vg=ai(128);wh(129,128,Fs,Lq);_.S=Gt;_.T=Ht;_.P=function(){var a;return Yh(Bg),Bg.v+'@'+(a=hl(this)>>>0,a.toString(16))};var Jq=0;var Bg=ai(129);wh(130,1,Ds,Mq);_.Q=function(){cb(this.g.l)};var xg=ai(130);wh(131,1,Ds,Nq);_.Q=function(){pb(this.g.g)};var yg=ai(131);wh(133,1,{},Oq);_.R=function(){return Hq(this.g)};var zg=ai(133);wh(132,1,{},Pq);_.Q=function(){Iq(this.g)};var Ag=ai(132);wh(144,1,{});var eh=ai(144);wh(174,144,{});_.l=0;var Xg=ai(174);wh(175,174,Fs,er);_.S=function(){hc(this.i)};_.T=function(){return this.i.s<0};_.P=function(){var a;return Yh(Lg),Lg.v+'@'+(a=hl(this)>>>0,a.toString(16))};var ar=0;var Lg=ai(175);wh(176,1,Ds,fr);_.Q=function(){cb(this.g.u)};var Cg=ai(176);wh(177,1,Ds,gr);_.Q=function(){br(this.g)};var Dg=ai(177);wh(179,1,{},hr);_.Q=function(){Vq(this.g)};var Eg=ai(179);wh(180,1,{},ir);_.Q=function(){Wq(this.g)};var Fg=ai(180);wh(182,1,Ds,jr);_.Q=function(){hc(this.g.i)};var Gg=ai(182);wh(183,1,{},kr);_.R=function(){return $q(this.g)};var Hg=ai(183);wh(184,1,Ds,lr);_.Q=Lt;var Ig=ai(184);wh(178,1,{},mr);_.R=function(){return Wh(),$wnd.document.fullscreen?true:false};var Jg=ai(178);wh(181,1,{},nr);_.Q=function(){_q(this.g)};var Kg=ai(181);wh(259,1,{});var hh=ai(259);wh(167,259,{});_.m=0;var Zg=ai(167);wh(168,167,Fs,xr);_.S=function(){hc(this.j)};_.T=function(){return this.j.s<0};_.P=function(){var a;return Yh(Rg),Rg.v+'@'+(a=hl(this)>>>0,a.toString(16))};var tr=0;var Rg=ai(168);wh(169,1,Ds,yr);_.Q=function(){ur(this.g)};var Mg=ai(169);wh(171,1,Ds,zr);_.Q=function(){hc(this.g.j)};var Ng=ai(171);wh(172,1,Ds,Ar);_.Q=function(){vr(this.g,this.h)};var Og=ai(172);wh(173,1,{},Br);_.R=function(){return rr(this.g)};var Pg=ai(173);wh(170,1,{},Cr);_.Q=function(){sr(this.g)};var Qg=ai(170);wh(199,1,{});var jh=ai(199);wh(231,199,{});var _g=ai(231);wh(232,231,Fs,Hr);_.S=function(){hc(this.g)};_.T=function(){return this.g.s<0};_.P=function(){var a;return Yh(Tg),Tg.v+'@'+(a=hl(this)>>>0,a.toString(16))};var Gr=0;var Tg=ai(232);wh(233,1,Ds,Ir);_.Q=function(){hc(this.g.g)};var Sg=ai(233);wh(291,$wnd.Function,{},Jr);_.Yb=function(a){return new Mr(a)};var Kr;wh(113,$wnd.React.Component,{},Mr);vh(th[1],_);_.componentWillUnmount=function(){Gq(this.g)};_.render=function(){return Kq(this.g)};_.shouldComponentUpdate=function(a){return 1==this.g.j};var Ug=ai(113);wh(296,$wnd.Function,{},Nr);_.Yb=function(a){return new Qr(a)};var Or;wh(154,$wnd.React.Component,{},Qr);vh(th[1],_);_.componentWillUnmount=function(){db(this.g)&&Zq(this.g)};_.render=function(){return db(this.g)?cr(this.g):null};_.shouldComponentUpdate=function(a){return db(this.g)&&1==this.g.l};var Wg=ai(154);wh(293,$wnd.Function,{},Rr);_.Yb=function(a){return new Ur(a)};var Sr;wh(152,$wnd.React.Component,{},Ur);vh(th[1],_);_.componentWillUnmount=function(){db(this.g)&&qr(this.g)};_.render=function(){return db(this.g)?wr(this.g):null};_.shouldComponentUpdate=function(a){return db(this.g)&&1==this.g.m};var Yg=ai(152);wh(337,$wnd.Function,{},Vr);_.Yb=function(a){return new Yr(a)};var Wr;wh(220,$wnd.React.Component,{},Yr);vh(th[1],_);_.componentWillUnmount=function(){db(this.g)&&hc(this.g.g)};_.render=function(){return db(this.g)?Er(this.g):null};_.shouldComponentUpdate=function(a){return db(this.g)&&Fr(this.g,a)};var $g=ai(220);wh(156,1,{},Zr);_.tb=function(a){var b;return Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['video-list-item'])),[Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['video-list-item-wrapper'])),[zs(xs(ys(new As,a),'video-list-item-element'),false)]),(b=(kb(a.o),a.D),null!=b&&b.getAudioTracks().length>0?Al(pt,El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['video-list-item-controls'])),[Al(Xs,Ll(El(new $wnd.Object,bd(Yc(le,1),Es,2,6,['video-list-item-control-btn'])),yh(ks.prototype.Xb,ks,[a])),[Al(st,Ol(Ql(Pl(new $wnd.Object,X(a.g)?tt:ut),16),16),null)])]):null)])};var ah=ai(156);wh(304,$wnd.Function,{},$r);_.Wb=function(a){a.preventDefault()};wh(267,$wnd.Function,{},_r);_.Wb=function(a){Yq(this.g,a)};wh(155,1,{},as);_.handleEvent=function(a){dr(this.g)};var bh=ai(155);wh(297,$wnd.Function,{},bs);_.U=function(a){Qq(this.g,a)};wh(305,$wnd.Function,{},cs);_.Xb=function(a){Rq(this.g,this.h,a)};wh(306,$wnd.Function,{},ds);_.Xb=function(a){Sq(this.g,this.h,a)};wh(268,$wnd.Function,{},es);_.Wb=function(a){Tq(this.g,a)};wh(298,$wnd.Function,{},fs);_.Xb=function(a){Yo(this.g.u)};wh(299,$wnd.Function,{},gs);_.Xb=Mt;wh(300,$wnd.Function,{},hs);_.Xb=function(a){Dn(this.g)};wh(301,$wnd.Function,{},is);_.Xb=function(a){Uq(this.g)};wh(302,$wnd.Function,{},js);_.Xb=function(a){Io(this.g.u)};wh(303,$wnd.Function,{},ks);_.Xb=Mt;wh(143,1,{},os);var dh=ai(143);wh(294,$wnd.Function,{},ps);_.Wb=function(a){or(this.g,a)};wh(153,1,{},qs);_.tb=function(a){return Al('a',Jl(El(Gl(new $wnd.Object,a),bd(Yc(le,1),Es,2,6,['recent-room'])),'#'+a),[a])};var fh=ai(153);wh(295,$wnd.Function,{},rs);_.Wb=function(a){var b;pr(this.g,ui((b=a.target,b).value))};wh(142,1,{},us);var gh=ai(142);wh(338,$wnd.Function,{},vs);_.U=function(a){Dr(this.g,a)};wh(84,1,{},As);var ih=ai(84);var td=ci('I');var rd=ci('D');var sd=ci('F');var kh=ci('S');var Bs=(Dc(),Gc);var gwtOnLoad=gwtOnLoad=rh;ph(Ch);sh('permProps',[[]]);if (vchat) vchat.onScriptLoad(gwtOnLoad);})();