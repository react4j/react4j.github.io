function vchat(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='vchat',tb='__gwt_marker_vchat',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='4342FA8D1116C13E849333853CE7E58C',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};vchat.onScriptLoad=function(a){vchat=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
vchat();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '4342FA8D1116C13E849333853CE7E58C';function t(){}
function Wf(){}
function Sf(){}
function Ib(){}
function Oc(){}
function Vc(){}
function Wh(){}
function mj(){}
function nj(){}
function oj(){}
function Zk(){}
function $k(){}
function dl(){}
function el(){}
function fl(){}
function jl(){}
function nl(){}
function Tc(a){Sc()}
function eg(){eg=Sf}
function Zg(){Qg(this)}
function K(a){this.g=a}
function L(a){this.g=a}
function ab(a){this.g=a}
function nb(a){this.g=a}
function Ab(a){this.g=a}
function Bb(a){this.g=a}
function Cb(a){this.g=a}
function Db(a){this.g=a}
function nc(a){this.g=a}
function ug(a){this.g=a}
function Lg(a){this.g=a}
function _g(a){this.i=a}
function Uh(a){this.g=a}
function Xh(a){this.g=a}
function xj(a){this.g=a}
function yj(a){this.g=a}
function zj(a){this.g=a}
function Aj(a){this.g=a}
function ak(a){this.g=a}
function bk(a){this.g=a}
function ek(a){this.g=a}
function fk(a){this.g=a}
function hk(a){this.g=a}
function qk(a){this.g=a}
function rk(a){this.g=a}
function sk(a){this.g=a}
function tk(a){this.g=a}
function Ak(a){this.g=a}
function Bk(a){this.g=a}
function Ck(a){this.g=a}
function Ok(a){this.g=a}
function Pk(a){this.g=a}
function Qk(a){this.g=a}
function Rk(a){this.g=a}
function Wk(a){this.g=a}
function Xk(a){this.g=a}
function Yk(a){this.g=a}
function bl(a){this.g=a}
function cl(a){this.g=a}
function rl(a){this.g=a}
function sl(a){this.g=a}
function tl(a){this.g=a}
function yl(a){this.g=a}
function zl(a){this.g=a}
function mh(){this.g=uh()}
function yh(){this.g=uh()}
function Xl(){gc(this.h)}
function Vl(a){Eh(this,a)}
function hb(a){$b((N(),a))}
function ib(a){_b((N(),a))}
function lb(a){ac((N(),a))}
function D(a){--a.l;I(a)}
function hc(a){!!a&&a.R()}
function kc(a,b){Ig(a.l,b)}
function vj(a,b){kc(a.h,b)}
function li(a,b){ki(a,b)}
function tb(a,b){a.h=b}
function Vh(a,b){a.g=b}
function ni(a,b){a.key=b}
function H(a,b){Qb(a.m,b.m)}
function O(a,b){S(a);P(a,b)}
function jk(a){a.j=2;gc(a.h)}
function Fk(a){a.m=2;gc(a.j)}
function If(a){return a.h}
function Tl(){return this.h}
function Rl(){return this.g}
function Ul(){return this.i}
function Sl(){return ci(this)}
function dg(a){tc.call(this,a)}
function Cg(a){tc.call(this,a)}
function Zl(){ob(this.g.g)}
function N(){N=Sf;M=new J}
function vc(){vc=Sf;uc=new t}
function Lc(){Lc=Sf;Kc=new Oc}
function qh(){qh=Sf;ph=sh()}
function qc(a,b){a.h=b;pc(a,b)}
function _h(a,b){a.splice(b,1)}
function fc(a,b,c){Hg(a.l,b,c)}
function tj(a,b,c){fc(a.h,b,c)}
function Jh(a,b,c){b.S(a.g[c])}
function Tg(a,b){return a.g[b]}
function Wc(a,b){return ng(a,b)}
function uh(){qh();return new ph}
function hg(a){gg(a);return a.v}
function Jk(a){ob(a.g);db(a.h)}
function Uk(a){!!a.h&&vj(a.h,a)}
function Ub(a){Vb(a);!a.j&&Yb(a)}
function bb(a){fd(a,13)&&a.P()}
function eb(a){N();_b(a);a.l=-2}
function Eh(a,b){while(a.sb(b));}
function Sh(a,b){Vh(a,Rh(a.g,b))}
function Ig(a,b){return lh(a.g,b)}
function Jg(a){return a.g.h+a.h.h}
function Yl(){return this.h.s<0}
function Lf(){Jf==null&&(Jf=[])}
function Bc(){Bc=Sf;!!(Sc(),Rc)}
function Jc(){yc!=0&&(yc=0);Ac=-1}
function Wl(){return vg(this.h.j)}
function am(a){return 1==this.g.j}
function Gb(a){this.j=a;this.h=100}
function sg(a,b){this.g=a;this.h=b}
function Pg(a,b){this.g=a;this.h=b}
function Bi(a,b){a.src=b;return a}
function Zf(a,b){a.max=b;return a}
function $f(a,b){a.min=b;return a}
function Rh(a,b){a.hb(b);return a}
function Qj(a){jb(a.h);return a.A}
function Mk(a){jb(a.h);return a.i}
function X(a){pb(a.l);return Z(a)}
function wh(a,b){return a.g.get(b)}
function Li(a,b){sg.call(this,a,b)}
function ij(a,b){sg.call(this,a,b)}
function ik(a,b){this.g=a;this.h=b}
function ck(a,b){this.g=a;this.h=b}
function dk(a,b){this.g=a;this.h=b}
function gk(a,b){this.g=a;this.h=b}
function Sk(a,b){this.g=a;this.h=b}
function _k(a,b){this.g=a;this.h=b}
function ti(a,b){this.g=a;this.h=b}
function al(a,b){this.g=a;this.h=b}
function ag(a,b){a.video=b;return a}
function cg(a,b){a.width=b;return a}
function Yf(a,b){a.ideal=b;return a}
function Gi(a,b){a.value=b;return a}
function Zh(a,b,c){a.splice(b,0,c)}
function C(a,b,c){A(a,new L(c),b)}
function ul(a){return wl(new xl,a)}
function s(a,b){return ld(a)===ld(b)}
function Gg(a){return !a?null:a.nb()}
function ld(a){return a==null?null:a}
function Dh(a){return a!=null?w(a):0}
function Wb(a){return !a.j?a:Wb(a.j)}
function Ic(a){$wnd.clearTimeout(a)}
function Ci(a){a.width='32';return a}
function _f(a){a.audio=true;return a}
function bg(a,b){a.height=b;return a}
function wi(a,b){a.onClick=b;return a}
function Ai(a){a.height='32';return a}
function Al(){this.g=qi((pl(),ol))}
function xl(){this.g=qi((ll(),kl))}
function pj(){this.g=qi((hl(),gl))}
function mb(a){this.i=new Zg;this.h=a}
function gi(){gi=Sf;di=new t;fi=new t}
function vi(a,b){a.disabled=b;return a}
function zi(a,b){a.onSubmit=b;return a}
function Di(a,b){a.onChange=b;return a}
function $h(a,b){Yh(b,0,a,0,b.length)}
function F(a,b,c){B(a,new K(b),c,null)}
function G(a,b,c){return B(a,c,2048,b)}
function Hg(a,b,c){return kh(a.g,b,c)}
function yg(a,b){return a.charCodeAt(b)}
function fd(a,b){return a!=null&&dd(a,b)}
function Bg(a){return !a?'null':''+a.g}
function ci(a){return a.$H||(a.$H=++bi)}
function cb(a){return !(!!a&&1==(a.i&7))}
function hd(a){return typeof a==='number'}
function kd(a){return typeof a==='string'}
function ec(a){return fd(a,35)?a.T():null}
function sb(a){N();rb(a);vb(a,2,true)}
function Qg(a){a.g=Yc(_d,Cl,1,0,5,1)}
function T(){this.g=Yc(_d,Cl,1,100,5,1)}
function tc(a){this.j=a;oc(this);this.X()}
function Qh(a,b){Nh.call(this,a);this.g=b}
function wl(a,b){mi(a.g,'a',b);return a}
function mi(a,b,c){a.props[b]=c;return a}
function ki(a,b){for(var c in a){b(c)}}
function oh(a,b){var c;c=a[Jl];c.call(a,b)}
function jb(a){var b;Xb((N(),b=Sb,b),a)}
function uj(a){F((N(),N(),M),new Aj(a),Ml)}
function Yj(a){F((N(),N(),M),new hk(a),Ml)}
function Zj(a){F((N(),N(),M),new ek(a),Ml)}
function $j(a){F((N(),N(),M),new fk(a),Ml)}
function gg(a){if(a.v!=null){return}pg(a)}
function oc(a){a.m&&a.h!==Gl&&a.X();return a}
function kg(a){var b;b=jg(a);rg(a,b);return b}
function Jb(a){2==(3&a.g)||(a.g=-4&a.g|2)}
function Y(a){4==(a.l.i&7)&&vb(a.l,5,true)}
function lc(a){N();Sb?a.R():F((null,M),a,0)}
function xg(){xg=Sf;wg=Yc(Yd,Cl,30,256,0,1)}
function gh(){this.g=new mh;this.h=new yh}
function Bh(a,b,c){this.g=a;this.h=b;this.i=c}
function Pb(a,b,c){c.g=-4&c.g|1;O(a.g[b],c)}
function Cc(a,b,c){return a.apply(b,c);var d}
function jd(a,b){return a&&b&&a instanceof b}
function gd(a){return typeof a==='boolean'}
function Fb(a){while(true){if(!Eb(a)){break}}}
function Hh(a,b){while(a.i<a.j){Jh(a,b,a.i++)}}
function qb(a,b){gb(b,a);b.i.g.length>0||(b.g=4)}
function Qb(a,b){Pb(a,((b.g&229376)>>15)-1,b)}
function Rg(a,b){a.g[a.g.length]=b;return true}
function Ei(a){a.placeholder='Room id';return a}
function yi(a){a.transform='scaleX(-1)';return a}
function mg(a){var b;b=jg(a);b.u=a;b.l=1;return b}
function nk(a){bb(a.o);bb(a.l);bb(a.s);bb(a.m)}
function Bj(a){Wj(a,null);Vj(a,null);Uj(a,null)}
function Tj(a){F((N(),N(),M),new dk(a,true),Ml)}
function Oh(a){Mh(a);return new Qh(a,new Th(a.g))}
function bh(a){return new Qh(null,ah(a,a.length))}
function $c(a){return Array.isArray(a)&&a.Ab===Wf}
function ed(a){return !Array.isArray(a)&&a.Ab===Wf}
function vh(a,b){return !(a.g.get(b)===undefined)}
function ah(a,b){return Fh(b,a.length),new Kh(a,b)}
function ok(a){return G((N(),N(),M),a.g,new tk(a))}
function yk(a){return G((N(),N(),M),a.g,new Ck(a))}
function Sc(){Sc=Sf;var a;!Uc();a=new Vc;Rc=a}
function J(){this.m=new Rb;this.g=new Gb(this.m)}
function ji(){if(ei==256){di=fi;fi=new t;ei=0}++ei}
function lk(a){if(0==a.j){a.j=1;a.i.forceUpdate()}}
function Hk(a){if(0==a.m){a.m=1;a.l.forceUpdate()}}
function Hb(a){if(!a.g){a.g=true;D((N(),N(),M))}}
function Lh(a){if(!a.h){Mh(a);a.i=true}else{Lh(a.h)}}
function Lk(a){return G((N(),N(),M),a.g,new Pk(a))}
function R(a){return a.i?a.g.length-a.h+a.j:a.j-a.h}
function Ek(a,b){lc(new Sk(a,b.length==0?null:b))}
function Pc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Xg(a,b,c){var d;d=a.g[b];a.g[b]=c;return d}
function Vg(a,b){var c;c=a.g[b];_h(a.g,b);return c}
function Ng(a){var b;b=a.g.kb();a.h=Mg(a);return b}
function Pj(a,b){var c;c=a.B;if(b!=c){a.B=b;ib(a.i)}}
function Rj(a,b){var c;c=a.v;if(b!=c){a.v=b;ib(a.g)}}
function Sj(a,b){var c;c=a.A;if(b!=c){a.A=b;ib(a.h)}}
function Uj(a,b){var c;c=a.C;if(b!=c){a.C=b;ib(a.j)}}
function Vj(a,b){var c;c=a.D;if(b!=c){a.D=b;ib(a.l)}}
function Xj(a,b){var c;c=a.H;if(b!=c){a.H=b;ib(a.u)}}
function Kk(a,b){var c;c=a.i;if(b!=c){a.i=b;ib(a.h)}}
function lg(a,b){var c;c=jg(a);rg(a,c);c.l=b?8:0;return c}
function xi(a,b){a.type=b.g!=null?b.g:''+b.h;return a}
function Kg(a,b){if(b){return Fg(a.g,b)}return false}
function fh(a,b){return ld(a)===ld(b)||a!=null&&u(a,b)}
function Gh(a,b){this.i=a;this.h=(b&64)!=0?b|16384:b}
function Kh(a,b){this.i=0;this.j=b;this.h=17488;this.g=a}
function bc(a,b){this.g=(N(),N(),M).h++;this.j=a;this.l=b}
function Th(a){Gh.call(this,a.qb(),a.pb()&-6);this.g=a}
function zb(a){xb.call(this,a,new Ab(a),null,304611328)}
function Nh(a){if(!a){this.h=null;new Zg}else{this.h=a}}
function og(a){if(a.gb()){return null}var b=a.u;return Of[b]}
function cc(a,b){Sb=new bc(Sb,b);a.j=false;Tb(Sb);return Sb}
function Uf(a){function b(){}
;b.prototype=a||{};return new b}
function Mh(a){if(a.h){Mh(a.h)}else if(a.i){throw If(new tg)}}
function Tb(a){if(a.l){2==(a.l.i&7)||vb(a.l,4,true);rb(a.l)}}
function kb(a){var b;N();!!Sb&&!!Sb.l&&Xb((b=Sb,b),a)}
function hl(){hl=Sf;var a;gl=(a=Tf(fl.prototype.xb,fl,[]),a)}
function ll(){ll=Sf;var a;kl=(a=Tf(jl.prototype.xb,jl,[]),a)}
function pl(){pl=Sf;var a;ol=(a=Tf(nl.prototype.xb,nl,[]),a)}
function Mi(){Ki();return _c(Wc(Ge,1),Cl,32,0,[Hi,Ii,Ji])}
function jh(a,b){var c;return hh(b,ih(a,b==null?0:(c=w(b),c|0)))}
function rc(a,b){var c;c=hg(a.yb);return b==null?c:c+': '+b}
function ih(a,b){var c;c=a.g.get(b);return c==null?new Array:c}
function ng(a,b){var c=a.g=a.g||[];return c[b]||(c[b]=a.ab(b))}
function Qf(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function Hc(a){Bc();$wnd.setTimeout(function(){throw a},0)}
function nh(a){this.l=a;this.h=this.l.g.entries();this.g=new Array}
function $g(a){Qg(this);$h(this.g,Eg(a,Yc(_d,Cl,1,Jg(a.g),5,1)))}
function jc(a){hc(a.o);!!a.l&&ic(a);bb(a.g);bb(a.i);hc(a.h);hc(a.m)}
function Ih(a,b){if(a.i<a.j){Jh(a,b,a.i++);return true}return false}
function $l(a,b,c){return eg(),(a.enabled=!a.enabled)?true:false}
function _l(a,b,c){return s('live',a.readyState)&&a.stop(),null}
function Dj(a,b,c){a.K==b&&F((N(),N(),M),new ik(a,c),Ml);return null}
function Ej(a,b){b.onended=Tf(cl.prototype._,cl,[a]);return null}
function Dk(a,b){b.preventDefault();F((N(),N(),M),new Qk(a),Ml)}
function db(a){if(-2!=a.l){F((N(),N(),M),new nb(a),0);!!a.h&&ob(a.h)}}
function Fc(a,b,c){var d;d=Dc();try{return Cc(a,b,c)}finally{Gc(d)}}
function si(a,b,c){!s(c,'key')&&!s(c,'ref')&&(a[c]=b[c],undefined)}
function sc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function xc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function Ec(b){Bc();return function(){return Fc(b,this,arguments);var a}}
function zh(a){this.j=a;this.h=this.j.g.entries();this.g=this.h.next()}
function il(a){$wnd.React.Component.call(this,a);this.g=new pk(this)}
function ml(a){$wnd.React.Component.call(this,a);this.g=new zk(this)}
function ql(a){$wnd.React.Component.call(this,a);this.g=new Nk(this)}
function Og(a){this.j=a;this.i=new zh(this.j.h);this.g=this.i;this.h=Mg(this)}
function P(a,b){a.g[a.j]=b;++a.j;if(a.j>=a.g.length){a.j=0;a.i=true}}
function fb(a,b){var c,d;Rg(a.i,b);d=(c=b.i&7,c>3?c:4);a.g>d&&(a.g=d)}
function Ph(a,b){var c;Lh(a);c=new Wh;c.g=b;a.g.rb(new Xh(c));return c.g}
function Ob(a){var b,c;b=0;for(c=0;c<a.g.length;c++){b+=R(a.g[c])}return b}
function Ug(a,b,c){for(;c<a.g.length;++c){if(fh(b,a.g[c])){return c}}return -1}
function Ah(a){if(a.g.i!=a.i){return wh(a.g,a.h.value[0])}return a.h.value[1]}
function Wg(a,b){var c;c=Ug(a,b,0);if(c==-1){return false}_h(a.g,c);return true}
function Yc(a,b,c,d,e,f){var g;g=Zc(e,d);e!=10&&_c(Wc(a,f),b,c,e,g);return g}
function Gc(a){a&&Nc((Lc(),Kc));--yc;if(a){if(Ac!=-1){Ic(Ac);Ac=-1}}}
function Lb(b){try{pb(b.h.g)}catch(a){a=Hf(a);if(!fd(a,6))throw If(a)}}
function md(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function ai(a,b){return Xc(b)!=10&&_c(v(b),b.zb,b.__elementTypeId$,Xc(b),a),a}
function Xc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function V(a){if(!a.g){a.g=true;a.v=null;a.h=null;db(a.j);2==(a.l.i&7)||ob(a.l)}}
function I(a){if(a.j&&a.l==0){if(!a.i){a.i=true;try{Fb(a.g)}finally{a.i=false}}}}
function qj(a){$wnd.goog.global.globalThis.window.addEventListener(Ll,a.i,false)}
function Ki(){Ki=Sf;Hi=new Li(Kl,0);Ii=new Li('reset',1);Ji=new Li('submit',2)}
function Z(a){if(a.h){if(fd(a.h,10)){throw If(a.h)}else{throw If(a.h)}}return a.v}
function ub(b){if(b){try{b.R()}catch(a){a=Hf(a);if(fd(a,6)){N()}else throw If(a)}}}
function dc(){var a;try{Ub(Sb);N()}finally{a=Sb.j;!a&&((N(),N(),M).j=true);Sb=Sb.j}}
function Oj(a,b){var c;c=a.G;if(!(ld(b)===ld(c)||b!=null&&u(b,c))){a.G=b;ib(a.s)}}
function Wj(a,b){var c;c=a.F;if(!(ld(b)===ld(c)||b!=null&&u(b,c))){a.F=b;ib(a.o)}}
function Xb(a,b){var c;if(a.l){c=a.g;if(b.l!=c){b.l=c;!a.h&&(a.h=new Zg);Rg(a.h,b)}}}
function Mc(a){var b,c;if(a.g){c=null;do{b=a.g;a.g=null;c=Qc(b,c)}while(a.g);a.g=c}}
function Nc(a){var b,c;if(a.h){c=null;do{b=a.h;a.h=null;c=Qc(b,c)}while(a.h);a.h=c}}
function Zb(a,b){var c;if(!a.i){c=Wb(a);!c.i&&(c.i=new Zg);a.i=c.i}b.j=true;Rg(a.i,b)}
function rg(a,b){var c;if(!a){return}b.u=a;var d=og(b);if(!d){Of[a]=[b];return}d.yb=b}
function Tf(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function jg(a){var b;b=new ig;b.v='Class$'+(a?'S'+a:''+b.o);b.h=b.v;b.s=b.v;return b}
function Sg(a,b){var c,d,e,f;for(d=a.g,e=0,f=d.length;e<f;++e){c=d[e];b.S(c)}}
function Rb(){var a;this.g=Yc(rd,Cl,46,5,0,1);for(a=0;a<5;a++){this.g[a]=new T}}
function gc(a){if(a.s>=0){a.s=-2;B((N(),N(),M),new K(new nc(a)),67108864,null)}}
function Nj(a){ob(a.m);db(a.h);db(a.o);db(a.l);db(a.j);db(a.i);db(a.g);db(a.u);db(a.s)}
function wc(a){vc();oc(this);this.h=a;pc(this,a);this.j=a==null?'null':Vf(a);this.g=a}
function tg(){tc.call(this,"Stream already terminated, can't be modified or used")}
function Kf(){Lf();var a=Jf;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function rb(a){var b,c;for(c=new _g(a.h);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);b.g=4}}
function dh(a){var b,c,d;d=0;for(c=new Og(a.g);c.h;){b=Ng(c);d=d+(b?w(b):0);d=d|0}return d}
function Dg(a,b){var c,d;for(d=new Og(b.g);d.h;){c=Ng(d);if(!Kg(a,c)){return false}}return true}
function oi(a,b,c,d){var e;e=pi($wnd.React.Element,a);e.key=b;e.ref=c;e.props=d;return e}
function qi(a){var b;b=pi($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function kk(a){var b,c;a.j=0;lj();c=(b=W(a.o.g),b.length==0?(new Al).g:vl(ul(a.m),a.l));return c}
function Hf(a){var b;if(fd(a,6)){return a}b=a&&a.__java$exception;if(!b){b=new wc(a);Tc(b)}return b}
function Mg(a){if(a.g.jb()){return true}if(a.g!=a.i){return false}a.g=new nh(a.j.g);return a.g.jb()}
function Fh(a,b){if(0>a||a>b){throw If(new dg('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Hj(a,b){Sj(a,false);Wj(a,b);b.getTracks().forEach(Tf(bl.prototype.Z,bl,[a]))}
function lj(){if(!kj){kj=(++(N(),N(),M).l,new Ib);$wnd.Promise.resolve(null).then(Tf(mj.prototype.$,mj,[]))}}
function rj(a){$wnd.goog.global.globalThis.window.removeEventListener(Ll,a.i,false)}
function Nf(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function Mb(a,b){this.h=a;this.g=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function yb(a,b,c){xb.call(this,null,a,b,c|(!a?262144:El)|(0==(c&6291456)?!a?2097152:4194304:0)|0|0|0)}
function mc(a,b,c,d){this.j=a;this.l=d?new gh:null;this.o=b;this.h=c;this.m=null;this.g=null;this.i=null}
function ig(){this.o=fg++;this.v=null;this.s=null;this.m=null;this.j=null;this.h=null;this.u=null;this.g=null}
function $(a,b){this.m=a;this.o=b;this.s=null;this.v=null;this.u=false;this.l=new zb(this);this.j=new mb(this.l)}
function xh(a,b,c){var d;d=a.g.get(b);a.g.set(b,c===undefined?null:c);d===undefined?++a.h:++a.i;return d}
function _c(a,b,c,d,e){e.yb=a;e.zb=b;e.Ab=Wf;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function hh(a,b){var c,d,e,f;for(d=b,e=0,f=d.length;e<f;++e){c=d[e];if(fh(a,c.mb())){return c}}return null}
function vg(a){var b,c;if(a>-129&&a<128){b=a+128;c=(xg(),wg)[b];!c&&(c=wg[b]=new ug(a));return c}return new ug(a)}
function Vf(a){var b;if(Array.isArray(a)&&a.Ab===Wf){return hg(v(a))+'@'+(b=w(a)>>>0,b.toString(16))}return a.toString()}
function vl(a,b){var c;mi(a.g,'b',b);return c=a.g.props,ni(a.g,Bg(ec(c['a']))+'-'+Bg(ec(c['b']))+(gg(Df),Df.v)),a.g}
function gb(a,b){var c,d;d=a.i;Wg(d,b);!!a.h&&El!=(a.h.i&1835008)&&a.i.g.length<=0&&0==a.h.g.i&&(a.j||Zb((N(),c=Sb,c),a))}
function Kj(a){var b;Rj(a,(jb(a.g),!a.v));b=(jb(a.o),a.F);null!=b&&b.getAudioTracks().forEach(Tf(Zk.prototype.Z,Zk,[]))}
function Lj(a){var b;Xj(a,(jb(a.u),!a.H));b=(jb(a.o),a.F);null!=b&&b.getVideoTracks().forEach(Tf($k.prototype.Z,$k,[]))}
function Cj(a,b,c){a.K==b?F((N(),N(),M),new gk(a,c),Ml):c.getTracks().forEach(Tf(el.prototype.Z,el,[]));return null}
function ob(a){if(2<(a.i&7)){B((N(),N(),M),new K(new Cb(a)),67108864,null);!!a.g&&V(a.g);Jb(a.m);a.i=a.i&-8|1}}
function Kb(a){if(1==(3&a.g)){a.g=-4&a.g|0;0==(a.g&El)?Lb(a):pb(a.h.g);0!=(a.g&524288)&&(2==(3&a.g)||(a.g=-4&a.g|2))}}
function v(a){return kd(a)?be:hd(a)?Td:gd(a)?Rd:ed(a)?a.yb:$c(a)?a.yb:a.yb||Array.isArray(a)&&Wc(Kd,1)||Kd}
function w(a){return kd(a)?ii(a):hd(a)?md(a):gd(a)?a?1231:1237:ed(a)?a.N():$c(a)?ci(a):!!a&&!!a.hashCode?a.hashCode():ci(a)}
function jj(){hj();return _c(Wc(He,1),Cl,8,0,[Ni,Oi,Pi,Qi,Ri,Si,Ti,Ui,Vi,Wi,Xi,Yi,Zi,$i,_i,aj,bj,cj,dj,ej,fj,gj])}
function zk(a){var b;this.i=a;N();b=++xk;this.h=new mc(b,null,new Ak(this),false);this.g=new yb(null,new Bk(this),Ol)}
function wj(){var a;this.i=new Yk(this);N();a=++sj;this.h=new mc(a,null,new xj(this),true);this.g=new $(new yj(this),new zj(this))}
function Vk(a){var b;this.h=a;N();b=++Tk;this.g=new mc(b,new Wk(this),null,true);!!this.h&&tj(this.h,this,new Xk(this));I((null,M))}
function Ij(a){var b;b=(jb(a.o),a.F);Bj(a);F((N(),N(),M),new dk(a,false),Ml);null!=b&&b.getTracks().forEach(Tf(dl.prototype.Z,dl,[]))}
function Fj(a){var b,c,d;c=(jb(a.o),a.F);d=(jb(a.s),a.G);if(null!=c&&null!=d){b=c;ld(b)!==ld(d.srcObject)&&(d.srcObject=b)}}
function ii(a){gi();var b,c,d;c=':'+a;d=fi[c];if(d!=null){return md(d)}d=di[c];b=d==null?hi(a):md(d);ji();fi[c]=b;return b}
function eh(a){var b,c,d;d=1;for(c=new _g(a);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=31*d+(b!=null?w(b):0);d=d|0}return d}
function ic(a){var b,c,d;for(c=new _g(new $g(new Lg(a.l)));c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.mb();fd(d,13)&&d.Q()||b.nb().R()}}
function Nb(a){var b,c,d;for(b=0;b<a.g.length;b++){d=a.g[b];if(0!=(d.i?d.g.length-d.h+d.j:d.j-d.h)){c=Q(d);return c}}return null}
function Yb(a){var b;if(a.i){while(a.i.g.length!=0){b=Vg(a.i,a.i.g.length-1);b.j=false;b.i.g.length>0||(b.h.i&7)>3&&vb(b.h,3,true)}}}
function Yg(a,b){var c,d;d=a.g.length;b.length<d&&(b=ai(new Array(d),b));for(c=0;c<d;++c){b[c]=a.g[c]}b.length>d&&(b[d]=null);return b}
function qg(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Xf(){var a;a=$wnd.goog.global.globalThis.document.getElementById('app');$wnd.ReactDOM.render((new pj).g,a,null)}
function Dc(){var a;if(yc!=0){a=xc();if(a-zc>2000){zc=a;Ac=$wnd.setTimeout(Jc,10)}}if(yc++==0){Mc((Lc(),Kc));return true}return false}
function Uc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function u(a,b){return kd(a)?s(a,b):hd(a)?ld(a)===ld(b):gd(a)?ld(a)===ld(b):ed(a)?a.L(b):$c(a)?s(a,b):!!a&&!!a.equals?a.equals(b):ld(a)===ld(b)}
function Jj(a,b){var c;Sj(a,false);if(jd(b,$wnd.DOMException)){c=b;Vj(a,c.name);Uj(a,c.message)}else{Vj(a,hg(v(b)));Uj(a,b==null?'null':Vf(b))}}
function dd(a,b){if(kd(a)){return !!cd[b]}else if(a.zb){return !!a.zb[b]}else if(hd(a)){return !!bd[b]}else if(gd(a)){return !!ad[b]}return false}
function ui(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function Q(a){var b;if(0==(a.i?a.g.length-a.h+a.j:a.j-a.h)){return null}b=a.g[a.h];a.g[a.h]=null;++a.h;if(a.h>=a.g.length){a.h=0;a.i=false}return b}
function W(a){a.u?kb(a.j):jb(a.j);if(wb(a.l)){if(a.u&&(N(),!(!!Sb&&!!Sb.l))){return B((N(),N(),M),new ab(a),83888128,null)}else{pb(a.l)}}return Z(a)}
function _b(a){var b,c,d;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new _g(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;6!=d&&vb(b,6,true)}}}
function ac(a){var b,c,d;if(a.i.g.length>0&&4==a.g){a.g=5;for(c=new _g(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=b.i&7;4==d&&vb(b,5,true)}}}
function $b(a){var b,c;if(a.i.g.length>0&&6!=a.g){a.g=6;for(c=new _g(a.i);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);5==(b.i&7)?vb(b,6,true):4==(b.i&7)&&(a.g=4)}}}
function Ag(a){var b,c,d;c=a.length;d=0;while(d<c&&a.charCodeAt(d)<=32){++d}b=c;while(b>d&&a.charCodeAt(b-1)<=32){--b}return d>0||b<c?a.substr(d,b-d):a}
function Eg(a,b){var c,d,e,f;f=Jg(a.g);b.length<f&&(b=ai(new Array(f),b));e=b;d=new Og(a.g);for(c=0;c<f;++c){e[c]=Ng(d)}b.length>f&&(b[f]=null);return b}
function Nk(a){var b,c,d;this.l=a;N();b=++Ik;this.j=new mc(b,null,new Ok(this),false);this.h=(d=new mb((c=null,c)),d);this.g=new yb(null,new Rk(this),Ol)}
function Zc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function A(b,c,d){var e,f;try{cc(b,d);try{f=(c.g.R(),null)}finally{dc()}return f}catch(a){a=Hf(a);if(fd(a,6)){e=a;throw If(e)}else throw If(a)}finally{I(b)}}
function B(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Sb){g=c.O()}else{cc(b,e);try{g=c.O()}finally{dc()}}return g}catch(a){a=Hf(a);if(fd(a,6)){f=a;throw If(f)}else throw If(a)}finally{I(b)}}
function Eb(a){var b,c;if(0==a.i){b=Ob(a.j);if(0==b){a.g=0;return false}else if(a.g+1>a.h){a.g=0;return false}else{a.g=a.g+1;a.i=b}}--a.i;c=Nb(a.j);Kb(c);return true}
function Mf(b,c,d,e){Lf();var f=Jf;$moduleName=c;$moduleBase=d;Gf=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{Bl(g)()}catch(a){b(c,a)}}else{Bl(g)()}}
function pi(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function sh(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return th()}}
function Pf(){Of={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Qc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].Bb()&&(c=Pc(c,g)):g[0].Bb()}catch(a){a=Hf(a);if(fd(a,6)){d=a;Bc();Hc(fd(d,36)?d.Y():d)}else throw If(a)}}return c}
function kh(a,b,c){var d,e,f,g,h;h=(g=ci(b),g|0);e=(d=a.g.get(h),d==null?new Array:d);if(e.length==0){a.g.set(h,e)}else{f=hh(b,e);if(f){return f.ob(c)}}e[e.length]=new Pg(b,c);++a.h;return null}
function Yh(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function pk(a){var b;this.o=new wj;this.l=new _j(new nj);this.s=new _j(new oj);this.m=new Vk(this.o);this.i=a;N();b=++mk;this.h=new mc(b,new qk(this),new rk(this),false);this.g=new yb(null,new sk(this),Ol)}
function hi(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+yg(a,c++)}b=b|0;return b}
function pb(b){var c;if(1!=(b.i&7)){try{if(4!=(b.i&7)){if(0!=(b.i&512)){!!b.l&&(b.i&=-513);c=b.j;C((N(),N(),M),b,c)}else{b.l.R()}}else 0!=(b.i&512)&&!!b.l&&(b.i&=-513)}catch(a){a=Hf(a);if(fd(a,6)){N()}else throw If(a)}}}
function S(a){var b,c,d,e,f,g;b=a.i?a.g.length-a.h+a.j:a.j-a.h;if(b+1>a.g.length){g=(a.g.length-1)*2+1;c=Yc(_d,Cl,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.h+d)%a.g.length;c[f]=a.g[e];a.g[e]=null;++f}a.g=c;a.h=0;a.j=f;a.i=false}}
function lh(a,b){var c,d,e,f,g,h;g=!b?0:(f=ci(b),f|0);d=(c=a.g.get(g),c==null?new Array:c);for(h=0;h<d.length;h++){e=d[h];if(fh(b,e.mb())){if(d.length==1){d.length=0;oh(a.g,g)}else{d.splice(h,1)}--a.h;return e.nb()}}return null}
function xb(a,b,c,d){this.h=new Zg;this.m=new Mb(new Bb(this),d&6520832|262144|El);this.i=d&-6520833|3;this.g=a;this.j=b;this.l=c;!!this.j&&(this.i|=512);!this.g&&!!this.j&&(H((N(),N(),M),this),0==(this.m.g&2097152)&&I((null,M)))}
function Rf(a,b,c){var d=Of,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Of[b]),Uf(h));_.zb=c;!b&&(_.Ab=Wf);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.yb=f)}
function Fg(a,b){var c,d,e;c=b.mb();e=b.nb();d=kd(c)?c==null?Gg(jh(a.g,null)):wh(a.h,c):Gg(jh(a.g,c));if(!(ld(e)===ld(d)||e!=null&&u(e,d))){return false}if(d==null&&!(kd(c)?c==null?!!jh(a.g,null):vh(a.h,c):!!jh(a.g,c))){return false}return true}
function pg(a){if(a.fb()){var b=a.i;b.gb()?(a.v='['+b.u):!b.fb()?(a.v='[L'+b.cb()+';'):(a.v='['+b.cb());a.h=b.bb()+'[]';a.s=b.eb()+'[]';return}var c=a.m;var d=a.j;d=d.split('/');a.v=qg('.',[c,qg('$',d)]);a.h=qg('.',[c,qg('.',d)]);a.s=d[d.length-1]}
function Gj(a,b){var c,d;Pj(a,b);c=(jb(a.o),a.F);if(b){null==c&&(++a.K,d=a.K,Bj(a),Sj(a,true),a.J.tb().then(Tf(_k.prototype.$,_k,[a,d])).catch(Tf(al.prototype.$,al,[a,d])),undefined)}else{if(null!=c){c.getTracks().forEach(Tf(el.prototype.Z,el,[]));Wj(a,null)}}}
function ri(a,b,c){var d,e,f;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;li(b,Tf(ti.prototype.ub,ti,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d['children']=c[0],undefined):(d['children']=c,undefined));return oi(a,e,f,d)}
function U(b){var c,d,e,f;f=b.v;try{e=(d=$wnd.goog.global.globalThis.window.location.hash,d.length==0?d:d.substr(1));if(!(f==e||f!=null&&s(f,e))){b.v=e;b.h=null;hb(b.j)}}catch(a){a=Hf(a);if(fd(a,11)){c=a;if(!b.h){b.v=null;b.h=c;hb(b.j)}throw If(c)}else throw If(a)}}
function wb(b){var c,d,e,f,g;g=b.i&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new _g(b.h);e.g<e.i.g.length;){d=(e.h=e.g++,e.i.g[e.h]);if(d.h){f=d.h;c=f.g;try{W(c)}catch(a){a=Hf(a);if(!fd(a,6))throw If(a)}if(6==(b.i&7)){return true}}}}}rb(b);return false}
function pc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.W();return a&&a.U()}},suppressed:{get:function(){return c.V()}}})}catch(a){}}}
function rh(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function Gk(a){var b,c;a.m=0;lj();b=(c=(jb(a.h),a.i),ri(Pl,ui(new $wnd.Object,_c(Wc(be,1),Cl,2,6,['enter-room-container'])),[ri('form',zi(new $wnd.Object,Tf(yl.prototype.vb,yl,[a])),[ri('input',Di(Gi(Ei(xi(new $wnd.Object,(hj(),dj))),null==c?'':c),Tf(zl.prototype.vb,zl,[a])),null),ri(Kl,vi(xi(new $wnd.Object,(Ki(),Ji)),null==c),['Enter'])])]));return b}
function vb(a,b,c){var d,e,f,g;g=a.i&7;if(b!=g){a.i=a.i&-8|b;if(!a.g&&6==b){c&&(1==(a.i&7)||1==(3&a.m.g)||H((N(),N(),M),a))}else if(!!a.g&&4==g&&(6==b||5==b)){lb(a.g.j);ub((e=a.g.s,e));c&&(1==(a.i&7)||1==(3&a.m.g)||H((N(),N(),M),a))}else if(3==b||3!=g&&2==b){if(a.g){d=a.g;ub((e=d.o,e));d.v=null}Sg(a.h,new Db(a));a.h.g=Yc(_d,Cl,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.g&&ub((f=a.g.m,f))}}
function _j(a){var b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;this.J=a;N();b=++Mj;this.I=new mc(b,null,new ak(this),true);this.B=false;this.v=true;this.H=true;this.h=(l=new mb((d=null,d)),l);this.o=(m=new mb((e=null,e)),m);this.l=(n=new mb((f=null,f)),n);this.j=(o=new mb((g=null,g)),o);this.i=(p=new mb((h=null,h)),p);this.g=(q=new mb((i=null,i)),q);this.u=(r=new mb((j=null,j)),r);this.s=(k=new mb((c=null,c)),k);this.m=new yb(new bk(this),null,404750336);I((null,M))}
function hj(){hj=Sf;Ni=new ij(Kl,0);Oi=new ij('checkbox',1);Pi=new ij('color',2);Qi=new ij('date',3);Ri=new ij('datetime',4);Si=new ij('email',5);Ti=new ij('file',6);Ui=new ij('hidden',7);Vi=new ij('image',8);Wi=new ij('month',9);Xi=new ij('number',10);Yi=new ij('password',11);Zi=new ij('radio',12);$i=new ij('range',13);_i=new ij('reset',14);aj=new ij('search',15);bj=new ij('submit',16);cj=new ij('tel',17);dj=new ij('text',18);ej=new ij('time',19);fj=new ij('url',20);gj=new ij('week',21)}
function Vb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.l){return}j=(n=a.l.i&7,n>3?n:4);e=false;c=0;if(!!a.h&&1!=(a.l.i&7)){m=a.h.g.length;for(h=0;h<m;h++){k=Tg(a.h,h);if(-1!=k.l&&-2!=k.l){k.l=-1;h!=c&&Xg(a.h,c,k);++c;if(k.h){l=k.h;f=l.i&7;f==6&&(j=f)}}}}d=a.l.h;for(i=d.g.length-1;i>=0;i--){k=d.g[i];if(-1==k.l){k.l=0}else{gb(k,a.l);e=true}}2<(a.l.i&7)&&4!=j&&(a.l.i&7)<j&&vb(a.l,j,false);if(a.h){for(g=c-1;g>=0;g--){k=Tg(a.h,g);if(-1==k.l){k.l=0;fb(k,a.l);e=true}}}if(a.h){for(g=a.h.g.length-1;g>=c;g--){Vg(a.h,g)}e&&tb(a.l,a.h)}else{e&&tb(a.l,new Zg)}if(cb(a.l)&&!!a.l.g){b=a.l.g;k=b.j;!!k.h&&El!=(k.h.i&1835008)&&k.i.g.length<=0&&0==k.h.g.i&&Zb(a,k)}}
function th(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype[Jl]=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!rh()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype[Jl]=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function vk(a){var b,c,d,e,f,g;a.j=0;lj();c=a.i.props['a'];if(!!c&&c.g.s<0){return null}b=a.i.props['b'];if(!!b&&b.I.s<0){return null}d=(e=a.i.props['b'],f=Tf(rl.prototype.S,rl,[e]),ri(Pl,ui(new $wnd.Object,_c(Wc(be,1),Cl,2,6,['room-lobby'])),[ri(Pl,ui(new $wnd.Object,_c(Wc(be,1),Cl,2,6,['local-cam-video'])),[oi('video',null,f,(g={},g['autoPlay']=true,g['muted']=true,g['style']=yi(new $wnd.Object),g)),(jb(e.o),null!=e.F?ri(Pl,ui(new $wnd.Object,_c(Wc(be,1),Cl,2,6,['local-cam-video-controls'])),[ri(Kl,wi(ui(new $wnd.Object,_c(Wc(be,1),Cl,2,6,[Ql])),Tf(sl.prototype.wb,sl,[e])),[ri('img',Ai(Ci(Bi(new $wnd.Object,(jb(e.g),e.v?'img/mic_on.svg':'img/mic_off.svg')))),null)]),ri(Kl,wi(ui(new $wnd.Object,_c(Wc(be,1),Cl,2,6,[Ql])),Tf(tl.prototype.wb,tl,[e])),[ri('img',Ai(Ci(Bi(new $wnd.Object,(jb(e.u),e.H?'img/cam_on.svg':'img/cam_off.svg')))),null)])]):null)]),Qj(a.i.props['b'])?ri(Pl,null,[ri('h2',null,['Getting ready...']),ri('p',null,["You'll be able to join in just a moment."])]):ri(Pl,null,[ri('h2',null,['Ready to join?']),ri(Kl,null,['Join'])])]));return d}
var Cl={4:1},Dl={13:1},El=1048576,Fl={9:1},Gl='__noinit__',Hl={4:1,11:1,10:1,6:1},Il={40:1},Jl='delete',Kl='button',Ll='hashchange',Ml=142606336,Nl={13:1,35:1},Ol=1411518464,Pl='div',Ql='control-btn';var _,Of,Jf,Gf=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Pf();Rf(1,null,{},t);_.L=function(a){return s(this,a)};_.M=function(){return this.yb};_.N=Sl;_.equals=function(a){return this.L(a)};_.hashCode=function(){return this.N()};var ad,bd,cd;Rf(54,1,{},ig);_.ab=function(a){var b;b=new ig;b.l=4;a>1?(b.i=ng(this,a-1)):(b.i=this);return b};_.bb=function(){gg(this);return this.h};_.cb=function(){return hg(this)};_.eb=function(){gg(this);return this.s};_.fb=function(){return (this.l&4)!=0};_.gb=function(){return (this.l&1)!=0};_.l=0;_.o=0;var fg=1;var _d=kg(1);var Sd=kg(54);Rf(100,1,{},J);_.h=1;_.i=false;_.j=true;_.l=0;var qd=kg(100);Rf(42,1,{},K);_.O=function(){return this.g.R(),null};var od=kg(42);Rf(101,1,{},L);var pd=kg(101);var M;Rf(46,1,{46:1},T);_.h=0;_.i=false;_.j=0;var rd=kg(46);Rf(176,1,Dl);var ud=kg(176);Rf(110,176,Dl,$);_.P=function(){V(this)};_.Q=Rl;_.g=false;_.i=0;_.u=false;var td=kg(110);Rf(111,1,{},ab);_.O=function(){return X(this.g)};var sd=kg(111);Rf(15,176,{13:1,15:1},mb);_.P=function(){db(this)};_.Q=function(){return -2==this.l};_.g=4;_.j=false;_.l=0;var wd=kg(15);Rf(109,1,Fl,nb);_.R=function(){eb(this.g)};var vd=kg(109);Rf(19,176,{13:1,19:1},yb,zb);_.P=function(){ob(this)};_.Q=function(){return 1==(this.i&7)};_.i=0;var Bd=kg(19);Rf(103,1,{},Ab);_.R=function(){U(this.g)};var xd=kg(103);Rf(104,1,Fl,Bb);_.R=function(){pb(this.g)};var yd=kg(104);Rf(105,1,Fl,Cb);_.R=function(){sb(this.g)};var zd=kg(105);Rf(106,1,{},Db);_.S=function(a){qb(this.g,a)};var Ad=kg(106);Rf(140,1,{},Gb);_.g=0;_.h=0;_.i=0;var Cd=kg(140);Rf(115,1,Dl,Ib);_.P=function(){Hb(this)};_.Q=Rl;_.g=false;var Dd=kg(115);Rf(58,176,{13:1,58:1},Mb);_.P=function(){Jb(this)};_.Q=function(){return 2==(3&this.g)};_.g=0;var Fd=kg(58);Rf(139,1,{},Rb);var Ed=kg(139);Rf(121,1,{},bc);_.g=0;var Sb;var Gd=kg(121);Rf(24,1,Dl,mc);_.P=function(){gc(this)};_.Q=function(){return this.s<0};_.j=0;_.s=0;var Id=kg(24);Rf(102,1,Fl,nc);_.R=function(){jc(this.g)};var Hd=kg(102);Rf(6,1,{4:1,6:1});_.U=Tl;_.V=function(){var a,b;return a=Ph(Oh(bh((this.l==null&&(this.l=Yc(ce,Cl,6,0,0,1)),this.l))),(b=new Zg,b)),Yg(a,Yc(_d,Cl,1,a.g.length,5,1))};_.W=Ul;_.X=function(){qc(this,sc(new Error(rc(this,this.j))));Tc(this)};_.h=Gl;_.m=true;var ce=kg(6);Rf(11,6,{4:1,11:1,6:1});var Vd=kg(11);Rf(10,11,Hl);var ae=kg(10);Rf(70,10,Hl);var Zd=kg(70);Rf(71,70,Hl);var Md=kg(71);Rf(36,71,{36:1,4:1,11:1,10:1,6:1},wc);_.Y=function(){return ld(this.g)===ld(uc)?null:this.g};var uc;var Jd=kg(36);var Kd=kg(0);Rf(160,1,{});var Ld=kg(160);var yc=0,zc=0,Ac=-1;Rf(77,160,{},Oc);var Kc;var Nd=kg(77);var Rc;Rf(171,1,{});var Pd=kg(171);Rf(72,171,{},Vc);var Od=kg(72);Rf(74,10,Hl);var Xd=kg(74);Rf(107,74,Hl,dg);var Qd=kg(107);ad={4:1,29:1};var Rd=kg(170);Rf(41,1,{4:1,41:1});var $d=kg(41);bd={4:1,29:1,66:1,41:1};var Td=kg(66);Rf(31,1,{4:1,29:1,31:1});_.L=function(a){return this===a};_.N=Sl;_.h=0;var Ud=kg(31);Rf(73,10,Hl,tg);var Wd=kg(73);Rf(30,41,{4:1,29:1,30:1,41:1},ug);_.L=function(a){return fd(a,30)&&a.g==this.g};_.N=Rl;_.g=0;var Yd=kg(30);var wg;Rf(245,1,{});cd={4:1,65:1,29:1,2:1};var be=kg(2);Rf(249,1,{});Rf(56,10,Hl,Cg);var de=kg(56);Rf(172,1,{47:1});_.hb=function(a){throw If(new Cg('Add not supported on this collection'))};var ee=kg(172);Rf(175,1,{158:1});_.L=function(a){var b,c,d;if(a===this){return true}if(!fd(a,43)){return false}d=a;if(this.g.h+this.h.h!=d.g.h+d.h.h){return false}for(c=new Og((new Lg(d)).g);c.h;){b=Ng(c);if(!Fg(this,b)){return false}}return true};_.N=function(){return dh(new Lg(this))};var me=kg(175);Rf(108,175,{158:1});var he=kg(108);Rf(174,172,{47:1,186:1});_.L=function(a){var b;if(a===this){return true}if(!fd(a,25)){return false}b=a;if(Jg(b.g)!=this.ib()){return false}return Dg(this,b)};_.N=function(){return dh(this)};var ne=kg(174);Rf(25,174,{25:1,47:1,186:1},Lg);_.ib=function(){return Jg(this.g)};var ge=kg(25);Rf(26,1,{},Og);_.kb=function(){return Ng(this)};_.jb=Tl;_.h=false;var fe=kg(26);Rf(173,172,{47:1,181:1});_.lb=function(a,b){throw If(new Cg('Add not supported on this list'))};_.hb=function(a){this.lb(this.ib(),a);return true};_.L=function(a){var b,c,d,e,f;if(a===this){return true}if(!fd(a,14)){return false}f=a;if(this.ib()!=f.g.length){return false}e=new _g(f);for(c=new _g(this);c.g<c.i.g.length;){b=(c.h=c.g++,c.i.g[c.h]);d=(e.h=e.g++,e.i.g[e.h]);if(!(ld(b)===ld(d)||b!=null&&u(b,d))){return false}}return true};_.N=function(){return eh(this)};var ie=kg(173);Rf(78,1,Il);_.L=function(a){var b;if(!fd(a,40)){return false}b=a;return fh(this.g,b.mb())&&fh(this.h,b.nb())};_.mb=Rl;_.nb=Tl;_.N=function(){return Dh(this.g)^Dh(this.h)};_.ob=function(a){var b;b=this.h;this.h=a;return b};var je=kg(78);Rf(79,78,Il,Pg);var ke=kg(79);Rf(178,1,Il);_.L=function(a){var b;if(!fd(a,40)){return false}b=a;return fh(this.h.value[0],b.mb())&&fh(Ah(this),b.nb())};_.N=function(){return Dh(this.h.value[0])^Dh(Ah(this))};var le=kg(178);Rf(14,173,{4:1,14:1,47:1,181:1},Zg,$g);_.lb=function(a,b){Zh(this.g,a,b)};_.hb=function(a){return Rg(this,a)};_.ib=function(){return this.g.length};var pe=kg(14);Rf(16,1,{},_g);_.jb=function(){return this.g<this.i.g.length};_.kb=function(){return this.h=this.g++,this.i.g[this.h]};_.g=0;_.h=-1;var oe=kg(16);Rf(43,108,{4:1,43:1,158:1},gh);var qe=kg(43);Rf(119,1,{},mh);_.h=0;var se=kg(119);Rf(120,1,{},nh);_.kb=function(){return this.j=this.g[this.i++],this.j};_.jb=function(){var a;if(this.i<this.g.length){return true}a=this.h.next();if(!a.done){this.g=a.value[1];this.i=0;return true}return false};_.i=0;_.j=null;var re=kg(120);var ph;Rf(116,1,{},yh);_.h=0;_.i=0;var ve=kg(116);Rf(117,1,{},zh);_.kb=function(){return this.i=this.g,this.g=this.h.next(),new Bh(this.j,this.i,this.j.i)};_.jb=function(){return !this.g.done};var te=kg(117);Rf(118,178,Il,Bh);_.mb=function(){return this.h.value[0]};_.nb=function(){return Ah(this)};_.ob=function(a){return xh(this.g,this.h.value[0],a)};_.i=0;var ue=kg(118);Rf(86,1,{});_.rb=Vl;_.pb=Tl;_.qb=Ul;_.h=0;_.i=0;var ze=kg(86);Rf(87,86,{});var we=kg(87);Rf(80,1,{});_.rb=Vl;_.pb=Tl;_.qb=function(){return this.j-this.i};_.h=0;_.i=0;_.j=0;var ye=kg(80);Rf(81,80,{},Kh);_.rb=function(a){Hh(this,a)};_.sb=function(a){return Ih(this,a)};var xe=kg(81);Rf(85,1,{});_.i=false;var Fe=kg(85);Rf(57,85,{},Qh);var Ee=kg(57);Rf(88,87,{},Th);_.sb=function(a){return this.g.sb(new Uh(a))};var Be=kg(88);Rf(90,1,{},Uh);_.S=function(a){this.g.S(a.h)};var Ae=kg(90);Rf(89,1,{},Wh);_.S=function(a){Vh(this,a)};var Ce=kg(89);Rf(91,1,{},Xh);_.S=function(a){Sh(this.g,a)};var De=kg(91);Rf(247,1,{});Rf(244,1,{});var bi=0;var di,ei=0,fi;Rf(1209,1,{});Rf(1240,1,{});Rf(228,$wnd.Function,{},ti);_.ub=function(a){si(this.g,this.h,a)};Rf(32,31,{4:1,29:1,31:1,32:1},Li);var Hi,Ii,Ji;var Ge=lg(32,Mi);Rf(8,31,{4:1,29:1,31:1,8:1},ij);var Ni,Oi,Pi,Qi,Ri,Si,Ti,Ui,Vi,Wi,Xi,Yi,Zi,$i,_i,aj,bj,cj,dj,ej,fj,gj;var He=lg(8,jj);var kj;Rf(217,$wnd.Function,{},mj);_.$=function(a){return Hb(kj),kj=null,null};Rf(93,1,{});var Le=kg(93);Rf(83,1,{},nj);_.tb=function(){return $wnd.goog.global.globalThis.navigator.mediaDevices.getUserMedia(ag(_f({}),bg(cg({},Zf(Yf($f({},160),640),1280)),Zf(Yf($f({},120),360),720))))};var Ie=kg(83);Rf(84,1,{},oj);_.tb=function(){return $wnd.goog.global.globalThis.navigator.mediaDevices.getDisplayMedia()};var Je=kg(84);Rf(64,1,{},pj);var Ke=kg(64);Rf(122,1,{});var tf=kg(122);Rf(123,122,Nl,wj);_.T=Wl;_.P=Xl;_.Q=Yl;var sj=0;var Qe=kg(123);Rf(124,1,Fl,xj);_.R=function(){V(this.g.g)};var Me=kg(124);Rf(125,1,{},yj);_.R=function(){qj(this.g)};var Ne=kg(125);Rf(126,1,{},zj);_.R=function(){rj(this.g)};var Oe=kg(126);Rf(127,1,Fl,Aj);_.R=function(){Y(this.g.g)};var Pe=kg(127);Rf(44,1,{44:1});_.K=0;var uf=kg(44);Rf(59,44,{13:1,35:1,44:1},_j);_.T=function(){return vg(this.I.j)};_.P=function(){gc(this.I)};_.Q=function(){return this.I.s<0};_.v=false;_.A=false;_.B=false;_.H=false;var Mj=0;var $e=kg(59);Rf(128,1,Fl,ak);_.R=function(){Nj(this.g)};var Re=kg(128);Rf(129,1,{},bk);_.R=function(){Fj(this.g)};var Se=kg(129);Rf(130,1,Fl,ck);_.R=function(){Oj(this.g,this.h)};var Te=kg(130);Rf(60,1,Fl,dk);_.R=function(){Gj(this.g,this.h)};_.h=false;var Ue=kg(60);Rf(131,1,Fl,ek);_.R=function(){Kj(this.g)};var Ve=kg(131);Rf(132,1,Fl,fk);_.R=function(){Lj(this.g)};var We=kg(132);Rf(133,1,Fl,gk);_.R=function(){Hj(this.g,this.h)};var Xe=kg(133);Rf(134,1,Fl,hk);_.R=function(){Ij(this.g)};var Ye=kg(134);Rf(135,1,Fl,ik);_.R=function(){Jj(this.g,this.h)};var Ze=kg(135);Rf(94,93,{});_.j=0;var wf=kg(94);Rf(95,94,Nl,pk);_.T=Wl;_.P=Xl;_.Q=Yl;var mk=0;var df=kg(95);Rf(96,1,Fl,qk);_.R=function(){nk(this.g)};var _e=kg(96);Rf(97,1,Fl,rk);_.R=Zl;var af=kg(97);Rf(98,1,{},sk);_.R=function(){lk(this.g)};var bf=kg(98);Rf(99,1,{},tk);_.O=function(){return kk(this.g)};var cf=kg(99);Rf(177,1,{});var Df=kg(177);Rf(150,177,{});_.j=0;var yf=kg(150);Rf(151,150,Nl,zk);_.T=Wl;_.P=Xl;_.Q=Yl;var xk=0;var hf=kg(151);Rf(152,1,Fl,Ak);_.R=Zl;var ef=kg(152);Rf(153,1,{},Bk);_.R=function(){lk(this.g)};var ff=kg(153);Rf(154,1,{},Ck);_.O=function(){return vk(this.g)};var gf=kg(154);Rf(179,1,{});var Ff=kg(179);Rf(143,179,{});_.m=0;var Af=kg(143);Rf(144,143,Nl,Nk);_.T=function(){return vg(this.j.j)};_.P=function(){gc(this.j)};_.Q=function(){return this.j.s<0};var Ik=0;var of=kg(144);Rf(145,1,Fl,Ok);_.R=function(){Jk(this.g)};var jf=kg(145);Rf(148,1,{},Pk);_.O=function(){return Gk(this.g)};var kf=kg(148);Rf(149,1,Fl,Qk);_.R=function(){var a;a=Mk(this.g);null!=a&&($wnd.goog.global.globalThis.window.location.hash=a)};var lf=kg(149);Rf(146,1,{},Rk);_.R=function(){Hk(this.g)};var mf=kg(146);Rf(147,1,Fl,Sk);_.R=function(){Kk(this.g,this.h)};var nf=kg(147);Rf(45,1,{45:1});var Bf=kg(45);Rf(136,45,{13:1,35:1,45:1},Vk);_.T=function(){return vg(this.g.j)};_.P=function(){gc(this.g)};_.Q=function(){return this.g.s<0};var Tk=0;var rf=kg(136);Rf(137,1,Fl,Wk);_.R=function(){Uk(this.g)};var pf=kg(137);Rf(138,1,Fl,Xk);_.R=function(){gc(this.g.g)};var qf=kg(138);Rf(112,1,{},Yk);_.handleEvent=function(a){uj(this.g)};var sf=kg(112);Rf(210,$wnd.Function,{},Zk);_.Z=$l;Rf(211,$wnd.Function,{},$k);_.Z=$l;Rf(212,$wnd.Function,{},_k);_.$=function(a){return Cj(this.g,this.h,a)};_.h=0;Rf(213,$wnd.Function,{},al);_.$=function(a){return Dj(this.g,this.h,a)};_.h=0;Rf(214,$wnd.Function,{},bl);_.Z=function(a,b,c){return Ej(this.g,a)};Rf(216,$wnd.Function,{},cl);_._=function(a){Yj(this.g)};Rf(215,$wnd.Function,{},dl);_.Z=_l;Rf(187,$wnd.Function,{},el);_.Z=_l;Rf(209,$wnd.Function,{},fl);_.xb=function(a){return new il(a)};var gl;Rf(82,$wnd.React.Component,{},il);Qf(Of[1],_);_.componentWillUnmount=function(){jk(this.g)};_.render=function(){return ok(this.g)};_.shouldComponentUpdate=am;var vf=kg(82);Rf(223,$wnd.Function,{},jl);_.xb=function(a){return new ml(a)};var kl;Rf(142,$wnd.React.Component,{},ml);Qf(Of[1],_);_.componentDidMount=function(){Tj(this.g.i.props['b'])};_.componentWillUnmount=function(){jk(this.g)};_.render=function(){return yk(this.g)};_.shouldComponentUpdate=am;var xf=kg(142);Rf(222,$wnd.Function,{},nl);_.xb=function(a){return new ql(a)};var ol;Rf(141,$wnd.React.Component,{},ql);Qf(Of[1],_);_.componentWillUnmount=function(){Fk(this.g)};_.render=function(){return Lk(this.g)};_.shouldComponentUpdate=function(a){return 1==this.g.m};var zf=kg(141);Rf(224,$wnd.Function,{},rl);_.S=function(a){lc(new ck(this.g,a))};Rf(226,$wnd.Function,{},sl);_.wb=function(a){Zj(this.g)};Rf(227,$wnd.Function,{},tl);_.wb=function(a){$j(this.g)};Rf(114,1,{},xl);var Cf=kg(114);Rf(219,$wnd.Function,{},yl);_.vb=function(a){Dk(this.g,a)};Rf(221,$wnd.Function,{},zl);_.vb=function(a){var b;Ek(this.g,Ag((b=a.target,b).value))};Rf(113,1,{},Al);var Ef=kg(113);var nd=mg('D');var Bl=(Bc(),Ec);var gwtOnLoad=gwtOnLoad=Mf;Kf(Xf);Nf('permProps',[[]]);if (vchat) vchat.onScriptLoad(gwtOnLoad);})();