function webspeechdemo(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='webspeechdemo',tb='__gwt_marker_webspeechdemo',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='CDCE39DD88D23E4B373B9E1F6308F938',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};webspeechdemo.onScriptLoad=function(a){webspeechdemo=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
webspeechdemo();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'CDCE39DD88D23E4B373B9E1F6308F938';function p(){}
function Rf(){}
function Nf(){}
function Gb(){}
function Jc(){}
function Qc(){}
function Qh(){}
function Ch(){}
function Yh(){}
function rg(){}
function vi(){}
function Ij(){}
function Rj(){}
function Xj(){}
function Tk(){}
function Uk(){}
function Vk(){}
function gl(){}
function kl(){}
function Oc(a){Nc()}
function Wf(){Wf=Nf}
function rb(a,b){a.b=b}
function Xh(a,b){a.a=b}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function ic(a){this.a=a}
function Ag(a){this.a=a}
function Ug(a){this.a=a}
function Uj(a){this.a=a}
function Qj(a){this.a=a}
function Sj(a){this.a=a}
function Tj(a){this.a=a}
function Vj(a){this.a=a}
function Wj(a){this.a=a}
function Yj(a){this.a=a}
function Zj(a){this.a=a}
function $j(a){this.a=a}
function $h(a){this.a=a}
function Dh(a){this.a=a}
function _j(a){this.a=a}
function ak(a){this.a=a}
function bk(a){this.a=a}
function jk(a){this.a=a}
function kk(a){this.a=a}
function lk(a){this.a=a}
function mk(a){this.a=a}
function Qk(a){this.a=a}
function Rk(a){this.a=a}
function Sk(a){this.a=a}
function Wk(a){this.a=a}
function cl(a){this.a=a}
function el(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function Fg(a){this.b=a}
function Qg(a){this.c=a}
function Zg(){this.a=fh()}
function ih(){this.a=fh()}
function Og(){Gg(this)}
function Sl(a){mh(this,a)}
function Ul(a){th(this,a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function w(a){--a.e;D(a)}
function Z(a){!!a&&cc(a.s)}
function dc(a){!!a&&a.A()}
function pi(a,b){oi(a,b)}
function Zh(a,b){Ph(a.a,b)}
function C(a,b){Ob(a.f,b.f)}
function L(a,b){P(a);M(a,b)}
function Vl(a){Jk(this.a,a)}
function sh(a){qh();this.a=a}
function Df(a){return a.b}
function Kj(a,b){return a.f=b}
function Rl(){return this.b}
function Ql(){return gi(this)}
function Jg(a,b){return a.a[b]}
function lc(a,b){a.b=b;kc(a,b)}
function dk(a){a.d=2;cc(a.b)}
function ci(a,b){a.splice(b,1)}
function Vf(a){oc.call(this,a)}
function og(a){oc.call(this,a)}
function sg(a){oc.call(this,a)}
function yh(a,b,c){b.C(a.a[c])}
function bb(a){K();Zb(a);a.e=-2}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function Zf(a){Yf(a);return a.j}
function fh(){ah();return new _g}
function Oh(a,b){a.T(b);return a}
function Rc(a,b){return dg(a,b)}
function Ph(a,b){Xh(a,Oh(a.a,b))}
function th(a,b){while(a.gb(b));}
function Uh(a,b,c){b.C(a.a.S(c))}
function v(a,b,c){t(a,new I(c),b)}
function K(){K=Nf;J=new F}
function qc(){qc=Nf;pc=new p}
function Gc(){Gc=Nf;Fc=new Jc}
function ah(){ah=Nf;_g=dh()}
function wc(){wc=Nf;!!(Nc(),Mc)}
function Ec(){tc!=0&&(tc=0);vc=-1}
function Gf(){Ef==null&&(Ef=[])}
function ng(){jc(this);this.I()}
function U(a){nb(a.f);return W(a)}
function Ek(a){hb(a.f);return a.n}
function Ck(a){hb(a.c);return a.l}
function Dk(a){hb(a.d);return a.m}
function Fk(a){hb(a.i);return a.q}
function Gk(a){hb(a.k);return a.r}
function Nk(a){hb(a.g);return a.o}
function Ok(a){hb(a.h);return a.p}
function Pi(a,b){a.max=b;return a}
function Qi(a,b){a.min=b;return a}
function yi(a,b){a.id=b;return a}
function Ai(a,b){a.ref=b;return a}
function Li(a,b){a.top=b;return a}
function Ji(a,b){a.left=b;return a}
function Si(a,b){a.step=b;return a}
function ai(a,b,c){a.splice(b,0,c)}
function fj(a,b){kg.call(this,a,b)}
function Ej(a,b){kg.call(this,a,b)}
function kg(a,b){this.a=a;this.b=b}
function Th(a,b){this.a=a;this.b=b}
function Wh(a,b){this.a=a;this.b=b}
function wi(a,b){this.a=a;this.b=b}
function Xk(a,b){this.a=a;this.b=b}
function Yk(a,b){this.a=a;this.b=b}
function Zk(a,b){this.a=a;this.b=b}
function $k(a,b){this.a=a;this.b=b}
function _k(a,b){this.a=a;this.b=b}
function al(a,b){this.a=a;this.b=b}
function bl(a,b){this.a=a;this.b=b}
function dl(a,b){this.a=a;this.b=b}
function fl(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function ck(){this.a=si((il(),hl))}
function qh(){qh=Nf;ph=new sh(null)}
function Wc(a){return new Array(a)}
function xg(a){return !a?null:kh(a)}
function fd(a){return a==null?null:a}
function yg(a){return a.a.b+a.b.b}
function hh(a,b){return a.a.get(b)}
function o(a,b){return fd(a)===fd(b)}
function Ub(a){return !a.d?a:Ub(a.d)}
function oh(a){return a!=null?s(a):0}
function Tl(){return this.a.length}
function bi(a,b){_h(b,0,a,0,b.length)}
function Bi(a,b){a.style=b;return a}
function Ci(a,b){a.title=b;return a}
function Ni(a,b){a.width=b;return a}
function Ui(a,b){a.value=b;return a}
function Ii(a,b){a.height=b;return a}
function Vi(a,b){a.htmlFor=b;return a}
function Ei(a,b){a.onClick=b;return a}
function Hi(a,b){a.display=b;return a}
function Di(a,b){a.disabled=b;return a}
function Ri(a,b){a.onChange=b;return a}
function oi(a,b){for(var c in a){b(c)}}
function Dc(a){$wnd.clearTimeout(a)}
function pg(a,b){return a.charCodeAt(b)}
function B(a,b,c){return u(a,c,2048,b)}
function A(a,b,c){u(a,new H(b),c,null)}
function qb(a){K();pb(a);tb(a,2,true)}
function Gg(a){a.a=Tc(Zd,vl,1,0,5,1)}
function Q(){this.a=Tc(Zd,vl,1,100,5,1)}
function jb(a){this.c=new Og;this.b=a}
function ki(){ki=Nf;hi=new p;ji=new p}
function Mi(a,b){a.transition=b;return a}
function qk(a,b){return o(b.voiceURI,a)}
function bd(a,b){return a!=null&&_c(a,b)}
function rh(a){return a.a!=null?a.a:null}
function $(a){return !(!!a&&1==(a.c&7))}
function gi(a){return a.$H||(a.$H=++fi)}
function ed(a){return typeof a==='string'}
function dd(a){return typeof a==='number'}
function cd(a){return typeof a==='boolean'}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function Kk(a){A((K(),K(),J),new el(a),Pl)}
function Mk(a){A((K(),K(),J),new cl(a),Pl)}
function gc(a){K();Qb?a.A():A((null,J),a,0)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Pj(a,b){Lk(a.e,b.target.value)}
function mh(a,b){while(a._()){Zh(b,a.ab())}}
function Nh(a,b){Gh.call(this,a);this.a=b}
function oc(a){this.d=a;jc(this);this.I()}
function Xg(){this.a=new Zg;this.b=new ih}
function Yf(a){if(a.j!=null){return}fg(a)}
function jc(a){a.f&&a.b!==zl&&a.I();return a}
function Ki(a){a.position='fixed';return a}
function zi(a,b){a['aria-label']=b;return a}
function Hg(a,b){a.a[a.a.length]=b;return true}
function ag(a){var b;b=_f(a);hg(a,b);return b}
function xc(a,b,c){return a.apply(b,c);var d}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function lh(a,b,c){this.a=a;this.b=b;this.c=c}
function wh(a,b){while(a.c<a.d){yh(a,b,a.c++)}}
function Db(a){while(true){if(!Cb(a)){break}}}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function Ah(a){if(!a.d){a.d=a.b.R();a.c=a.b.W()}}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Lk(a,b){A((K(),K(),J),new fl(a,b),Pl)}
function Lj(a,b){gc(new bl(a.e,b.target.value))}
function gh(a,b){return !(a.a.get(b)===undefined)}
function Hh(a,b){var c;return Lh(a,(c=new Og,c))}
function Lg(a,b){var c;c=a.a[b];ci(a.a,b);return c}
function Cg(a){var b;b=a.a.ab();a.b=Bg(a);return b}
function cg(a){var b;b=_f(a);b.i=a;b.e=1;return b}
function Kc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Rg(a,b){return uh(b,a.length),new zh(a,b)}
function hk(a){return B((K(),K(),J),a.a,new lk(a))}
function Sg(a){return new Nh(null,Rg(a,a.length))}
function Vc(a){return Array.isArray(a)&&a.pb===Rf}
function ad(a){return !Array.isArray(a)&&a.pb===Rf}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Oj(a,b){gc(new _k(a.e,lg(b.target.value)))}
function Mj(a,b){gc(new Zk(a.e,lg(b.target.value)))}
function Nj(a,b){gc(new $k(a.e,lg(b.target.value)))}
function Rh(a,b,c){if(a.a.ib(c)){a.b=true;b.C(c)}}
function Eh(a){if(!a.b){Fh(a);a.c=true}else{Eh(a.b)}}
function fk(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function ni(){if(ii==256){hi=ji;ji=new p;ii=0}++ii}
function ei(a){if(a==null){throw Df(new ng)}return a}
function Gi(a){a.border='1px solid orange';return a}
function Ng(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function vk(a,b){var c;c=a.l;if(b!=c){a.l=b;fb(a.c)}}
function wk(a,b){var c;c=a.m;if(b!=c){a.m=b;fb(a.d)}}
function xk(a,b){var c;c=a.n;if(b!=c){a.n=b;fb(a.f)}}
function yk(a,b){var c;c=a.o;if(b!=c){a.o=b;fb(a.g)}}
function zk(a,b){var c;c=a.p;if(b!=c){a.p=b;fb(a.h)}}
function Bk(a,b){var c;c=a.r;if(b!=c){a.r=b;fb(a.k)}}
function Ih(a,b){Fh(a);return new Nh(a,new Sh(b,a.a))}
function Kh(a,b){Fh(a);return new Nh(a,new Vh(b,a.a))}
function Jk(a,b){A((K(),K(),J),new dl(a,b),75497472)}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function zh(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function vh(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Bh(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function Fi(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function bg(a,b){var c;c=_f(a);hg(a,c);c.e=b?8:0;return c}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&yl)&&D((null,J))}
function Hk(a){gc(new al(a,rh(Jh(Ih(T(a.j).Y(),new kl)))))}
function Nc(){Nc=Nf;var a;!Pc();a=new Qc;Mc=a}
function Uf(){Uf=Nf;Tf=$wnd.goog.global.document}
function nh(a,b){return fd(a)===fd(b)||a!=null&&q(a,b)}
function mc(a,b){var c;c=Zf(a.nb);return b==null?c:c+': '+b}
function dg(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.L(b))}
function zg(a,b){if(bd(b,32)){return wg(a.a,b)}return false}
function eg(a){if(a.Q()){return null}var b=a.i;return Jf[b]}
function Gh(a){if(!a){this.b=null;new Og}else{this.b=a}}
function Fh(a){if(a.b){Fh(a.b)}else if(a.c){throw Df(new mg)}}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function fc(a){dc(a.f);!!a.d&&ec(a);Z(a.a);Z(a.c);dc(a.b);dc(a.e)}
function Cc(a){wc();$wnd.setTimeout(function(){throw a},0)}
function gj(){ej();return Xc(Rc(Ne,1),vl,25,0,[bj,cj,dj])}
function Pg(a){Gg(this);bi(this.a,vg(a,Tc(Zd,vl,1,yg(a.a),5,1)))}
function $g(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function Ik(a,b){gc(new al(a,rh(Jh(Ih(T(a.j).Y(),new sl(b))))))}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function Pf(a){function b(){}
;b.prototype=a||{};return new b}
function nc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Lf(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ui(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Ac(a,b,c){var d;d=yc();try{return xc(a,b,c)}finally{Bc(d)}}
function cb(a,b){var c,d;Hg(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Mh(a,b){var c;c=Hh(a,new Dh(new Ch));return c.Z(b.hb(c.W()))}
function xh(a,b){if(a.c<a.d){yh(a,b,a.c++);return true}return false}
function Vh(a,b){vh.call(this,b.fb(),b.eb()&-6);this.a=a;this.b=b}
function Sh(a,b){vh.call(this,b.fb(),b.eb()&-16449);this.a=a;this.c=b}
function jh(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function jl(a){$wnd.React.Component.call(this,a);this.a=new ik(this)}
function il(){il=Nf;var a;hl=(a=Of(gl.prototype.mb,gl,[]),a)}
function Jb(b){try{nb(b.b.a)}catch(a){a=Cf(a);if(!bd(a,4))throw Df(a)}}
function ab(a){if(-2!=a.e){A((K(),K(),J),new kb(a),0);!!a.b&&lb(a.b)}}
function Bc(a){a&&Ic((Gc(),Fc));--tc;if(a){if(vc!=-1){Dc(vc);vc=-1}}}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Kg(a,b,c){for(;c<a.a.length;++c){if(nh(b,a.a[c])){return c}}return -1}
function Lh(a,b){var c;Eh(a);c=new Yh;c.a=b;a.a.$(new $h(c));return c.a}
function Tc(a,b,c,d,e,f){var g;g=Uc(e,d);e!=10&&Xc(Rc(a,f),b,c,e,g);return g}
function Ig(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.C(c)}}
function Pb(){var a;this.a=Tc(nd,vl,38,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function Dg(a){this.d=a;this.c=new jh(this.d.b);this.a=this.c;this.b=Bg(this)}
function kh(a){if(a.a.c!=a.c){return hh(a.a,a.b.value[0])}return a.b.value[1]}
function sc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function zc(b){wc();return function(){return Ac(b,this,arguments);var a}}
function gd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function di(a,b){return Sc(b)!=10&&Xc(r(b),b.ob,b.__elementTypeId$,Sc(b),a),a}
function Sc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function S(a){if(!a.a){a.a=true;a.j=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function W(a){if(a.b){if(bd(a.b,6)){throw Df(a.b)}else{throw Df(a.b)}}return a.j}
function sb(b){if(b){try{b.A()}catch(a){a=Cf(a);if(bd(a,4)){K()}else throw Df(a)}}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function Hc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Lc(b,c)}while(a.a);a.a=c}}
function Ic(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Lc(b,c)}while(a.b);a.b=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Og);Hg(a.b,b)}}}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Og);a.c=c.c}b.d=true;a.c.T(b)}
function hg(a,b){var c;if(!a){return}b.i=a;var d=eg(b);if(!d){Jf[a]=[b];return}d.nb=b}
function Mg(a,b){var c;c=Kg(a,b,0);if(c==-1){return false}ci(a.a,c);return true}
function Ak(a,b){var c;c=a.q;if(!(fd(b)===fd(c)||b!=null&&q(b,c))){a.q=b;fb(a.i)}}
function cc(a){if(a.g>=0){a.g=-2;u((K(),K(),J),new H(new ic(a)),67108864,null)}}
function Sf(){$wnd.ReactDOM.render((new ck).a,(Uf(),Tf).getElementById('app'),null)}
function ej(){ej=Nf;bj=new fj(Dl,0);cj=new fj('reset',1);dj=new fj('submit',2)}
function _f(a){var b;b=new $f;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function si(a){var b;b=ri($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Eg(a,b){var c,d;for(c=0,d=a.a.length;c<d;++c){if(nh(b,a.a[c])){return c}}return -1}
function pb(a){var b,c;for(c=new Qg(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function ug(a,b){var c,d;for(d=new Dg(b.a);d.b;){c=Cg(d);if(!zg(a,c)){return false}}return true}
function Wg(a){var b,c,d;d=1;for(c=a.R();c._();){b=c.ab();d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Of(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Ff(){Gf();var a=Ef;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function mg(){oc.call(this,"Stream already terminated, can't be modified or used")}
function rc(a){qc();jc(this);this.b=a;kc(this,a);this.d=a==null?'null':Qf(a);this.a=a}
function hc(a,b,c){this.d=c?new Xg:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function tk(a){(Uf(),$wnd.goog.global.window).speechSynthesis.addEventListener(Ol,a.t)}
function uk(a){(Uf(),$wnd.goog.global.window).speechSynthesis.removeEventListener(Ol,a.t)}
function uh(a,b){if(0>a||a>b){throw Df(new Vf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:wl)|(0==(c&6291456)?!a?yl:4194304:0)|0|0|0)}
function sk(a){lb(a.a);S(a.e);S(a.b);S(a.j);ab(a.h);ab(a.g);ab(a.c);ab(a.d);ab(a.k);ab(a.i);ab(a.f)}
function Bg(a){if(a.a._()){return true}if(a.a!=a.c){return false}a.a=new $g(a.d.a);return a.a._()}
function Jh(a){var b;Eh(a);b=new Yh;if(a.a.gb(b)){return qh(),new sh(ei(b.a))}return qh(),qh(),ph}
function Cf(a){var b;if(bd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new rc(a);Oc(b)}return b}
function Xc(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=Rf;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Yg(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function Vg(a){var b,c,d;d=0;for(c=new Dg(a.a);c.b;){b=Cg(c);d=d+(b?oh(b.b.value[0])^oh(kh(b)):0);d=d|0}return d}
function tg(a,b){var c,d;for(d=a.R();d._();){c=d.ab();if(fd(b)===fd(c)||b!=null&&q(b,c)){return true}}return false}
function nk(a){var b,c;c=T(a.j);b=(hb(a.i),a.q);(null==b||!c.U(b))&&gc(new al(a,rh(Jh(Ih(T(a.j).Y(),new kl)))))}
function db(a,b){var c,d;d=a.c;Mg(d,b);!!a.b&&wl!=(a.b.c&xl)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function ec(a){var b,c;for(c=new Qg(new Pg(new Ag(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);kh(b).A()}}
function Wb(a){var b;if(a.c){while(!a.c.V()){b=a.c.db(a.c.W()-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Hj(){if(!Gj){Gj=(++(K(),K(),J).e,new Gb);$wnd.Promise.resolve(null).then(Of(Ij.prototype.K,Ij,[]))}}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&wl)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function r(a){return ed(a)?_d:dd(a)?Pd:cd(a)?Nd:ad(a)?a.nb:Vc(a)?a.nb:a.nb||Array.isArray(a)&&Rc(Gd,1)||Gd}
function s(a){return ed(a)?mi(a):dd(a)?gd(a):cd(a)?a?1231:1237:ad(a)?a.w():Vc(a)?gi(a):!!a&&!!a.hashCode?a.hashCode():gi(a)}
function Qf(a){var b;if(Array.isArray(a)&&a.pb===Rf){return Zf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function mi(a){ki();var b,c,d;c=':'+a;d=ji[c];if(d!=null){return gd(d)}d=hi[c];b=d==null?li(a):gd(d);ni();ji[c]=b;return b}
function qi(a){var b,c;b=ri($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=(c={},c[Cl]=a,c);return b}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function yc(){var a;if(tc!=0){a=sc();if(a-uc>2000){uc=a;vc=$wnd.setTimeout(Ec,10)}}if(tc++==0){Hc((Gc(),Fc));return true}return false}
function lg(a){var b;b=jg(a);if(b>3.4028234663852886E38){return Infinity}else if(b<-3.4028234663852886E38){return -Infinity}return b}
function If(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function $f(){this.g=Xf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function ik(a){this.e=new Pk;this.c=a;K();++gk;this.b=new hc(new jk(this),new kk(this),false);this.a=new wb(null,new mk(this),1411518464)}
function Fj(){Dj();return Xc(Rc(Oe,1),vl,5,0,[hj,ij,jj,kj,lj,mj,nj,oj,pj,qj,rj,sj,tj,uj,vj,wj,xj,yj,zj,Aj,Bj,Cj])}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(wl==(b&xl)?0:524288)|(0==(b&6291456)?wl==(b&xl)?4194304:yl:0)|0|268435456|0)}
function gg(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Tg(a,b){var c,d;d=a.a.length;b.length<d&&(b=di(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function vg(a,b){var c,d,e,f;f=a.W();b.length<f&&(b=di(new Array(f),b));e=b;d=a.R();for(c=0;c<f;++c){e[c]=d.ab()}b.length>f&&(b[f]=null);return b}
function Pc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return ed(a)?o(a,b):dd(a)?a===b:cd(a)?fd(a)===fd(b):ad(a)?a.u(b):Vc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):fd(a)===fd(b)}
function _c(a,b){if(ed(a)){return !!$c[b]}else if(a.ob){return !!a.ob[b]}else if(dd(a)){return !!Zc[b]}else if(cd(a)){return !!Yc[b]}return false}
function xi(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function T(a){a.i?hb(a.e):gb(a.e);if(ub(a.f)){if(a.i&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Qg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Qg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Qg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Uc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.A(),null)}finally{bc()}return f}catch(a){a=Cf(a);if(bd(a,4)){e=a;throw Df(e)}else throw Df(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.B()}else{ac(b,e);try{g=c.B()}finally{bc()}}return g}catch(a){a=Cf(a);if(bd(a,4)){f=a;throw Df(f)}else throw Df(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.h=c;this.j=null;this.i=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);wl==(d&xl)&&mb(this.f)}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function Hf(b,c,d,e){Gf();var f=Ef;$moduleName=c;$moduleBase=d;Bf=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{tl(g)()}catch(a){b(c,a)}}else{tl(g)()}}
function ri(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function dh(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return eh()}}
function Kf(){Jf={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Lc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Kc(c,g)):g[0].qb()}catch(a){a=Cf(a);if(bd(a,4)){d=a;wc();Cc(bd(d,31)?d.J():d)}else throw Df(a)}}return c}
function R(b){var c,d,e;e=b.j;try{d=b.c.B();if(!(fd(e)===fd(d)||e!=null&&q(e,d))){b.j=d;b.b=null;eb(b.e)}}catch(a){a=Cf(a);if(bd(a,8)){c=a;if(!b.b){b.j=null;b.b=c;eb(b.e)}throw Df(c)}else throw Df(a)}}
function _h(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Jj(a){var b,c,d,e;c=Nk(a.e);if(0!=c&&null!=a.f){b=(Uf(),Tf);e=b.createRange();d=Ok(a.e);e.setStart(a.f.firstChild,d);e.setEnd(a.f.firstChild,d+c);return e.getBoundingClientRect()}else{return null}}
function jg(a){ig==null&&(ig=new RegExp('^\\s*[+-]?(NaN|Infinity|((\\d+\\.?\\d*)|(\\.\\d+))([eE][+-]?\\d+)?[dDfF]?)\\s*$'));if(!ig.test(a)){throw Df(new og('For input string: "'+a+'"'))}return parseFloat(a)}
function li(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+pg(a,c++)}b=b|0;return b}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Tc(Zd,vl,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{fk(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Cf(a);if(bd(a,4)){K()}else throw Df(a)}}}
function vb(a,b,c,d){this.b=new Og;this.f=new Kb(new zb(this),d&6520832|262144|wl);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&yl)&&D((null,J)))}
function Mf(a,b,c){var d=Jf,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Jf[b]),Pf(h));_.ob=c;!b&&(_.pb=Rf);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function fg(a){if(a.P()){var b=a.c;b.Q()?(a.j='['+b.i):!b.P()?(a.j='[L'+b.N()+';'):(a.j='['+b.N());a.b=b.M()+'[]';a.h=b.O()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=gg('.',[c,gg('$',d)]);a.b=gg('.',[c,gg('.',d)]);a.h=d[d.length-1]}
function wg(a,b){var c,d,e,f,g;e=b.b.value[0];g=kh(b);f=e==null?xg(Yg((d=a.a.a.get(0),d==null?new Array:d))):hh(a.b,e);if(!(fd(g)===fd(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!Yg((c=a.a.a.get(0),c==null?new Array:c)):gh(a.b,e))){return false}return true}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Qg(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Cf(a);if(!bd(a,4))throw Df(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function ok(a,b){var c;c=b.type;if(!o(Nl,c)){V(a.e);V(a.b)}if((o('error',c)||o('end',c))&&(Uf(),$wnd.goog.global.window).speechSynthesis.paused){(Uf(),$wnd.goog.global.window).speechSynthesis.cancel()}else if(o(Nl,c)&&o(b.name,'word')){gc(new Xk(a,b.charIndex));gc(new Yk(a,b.charLength))}}
function ti(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;pi(b,Of(wi.prototype.jb,wi,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Cl]=c[0],undefined):(d[Cl]=c,undefined));return g=ri($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function kc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.H();return a&&a.F()}},suppressed:{get:function(){return c.G()}}})}catch(a){}}}
function bh(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.h,e));d.j=null}Ig(a.b,new Bb(a));a.b.a=Tc(Zd,vl,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function Dj(){Dj=Nf;hj=new Ej(Dl,0);ij=new Ej('checkbox',1);jj=new Ej('color',2);kj=new Ej('date',3);lj=new Ej('datetime',4);mj=new Ej('email',5);nj=new Ej('file',6);oj=new Ej('hidden',7);pj=new Ej('image',8);qj=new Ej('month',9);rj=new Ej('number',10);sj=new Ej('password',11);tj=new Ej('radio',12);uj=new Ej('range',13);vj=new Ej('reset',14);wj=new Ej('search',15);xj=new Ej('submit',16);yj=new Ej('tel',17);zj=new Ej('text',18);Aj=new Ej('time',19);Bj=new Ej('url',20);Cj=new Ej('week',21)}
function pk(a){var b,c;gc(new Xk(a,0));gc(new Yk(a,0));c=new $wnd.SpeechSynthesisUtterance((hb(a.f),a.n));c.voice=(hb(a.i),a.q);c.volume=(hb(a.k),a.r);c.pitch=(hb(a.c),a.l);b=(hb(a.d),a.m);c.rate=$wnd.Math.pow($wnd.Math.abs(b)+1,b<0?-1:1);c.addEventListener('start',new ml(a));c.addEventListener('end',new nl(a));c.addEventListener('error',new ol(a));c.addEventListener(Nl,new pl(a));c.addEventListener('pause',new ql(a));c.addEventListener('resume',new rl(a));(Uf(),$wnd.goog.global.window).speechSynthesis.speak(c)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Jg(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Ng(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Jg(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Lg(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Og)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&wl!=(k.b.c&xl)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function Pk(){var a,b,c,d,e,f,g,h,i,j,k,l,m,n;this.t=new ll(this);K();++rk;this.s=new hc(null,new Qk(this),true);this.l=0.5;this.m=0;this.r=1;this.n='Call me Ishmael. Some years ago, never mind how long precisely, having little or no money in my purse, and nothing particular to interest me on shore, I thought I would sail about a little and see the watery part of the world.';this.h=(i=new jb((b=null,b)),i);this.g=(j=new jb((c=null,c)),j);this.c=(k=new jb((d=null,d)),k);this.d=(l=new jb((e=null,e)),l);this.k=(m=new jb((f=null,f)),m);this.i=(n=new jb((g=null,g)),n);this.f=(h=new jb((a=null,a)),h);this.e=new X(new Tk,null,null,35667968);this.b=new X(new Uk,null,null,35667968);this.j=new X(new Vk,new Rk(this),new Sk(this),35651584);this.a=new wb(new Wk(this),null,413138944);D((null,J))}
function eh(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!bh()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function ek(a){var b,c,d,e,f;a.d=0;Hj();b=(c=Fk(a.e),ti(El,xi(new $wnd.Object,Xc(Rc(_d,1),vl,2,6,[T(a.e.e)?'speaking':null])),[ti('h1',null,['Web Speech Synthesis Demo']),ti('form',null,[ti(El,yi(new $wnd.Object,'textarea'),[T(a.e.e)?qi([ti(El,yi(Ai(new $wnd.Object,Of(Sj.prototype.C,Sj,[a])),'textbeingspoken'),[Ek(a.e)]),ti(El,Bi(new $wnd.Object,(d=Jj(a),e=(Uf(),Tf).body,f=Nk(a.e),Ii(Ni(Ji(Li(Mi(Hi(Gi(Ki(new $wnd.Object)),0==f?'none':'block'),0==f?'all 0s ease 0s':'all 50ms ease'),null==d?'0':d.top-1+e.clientHeight-e.scrollHeight+8+'px'),null==d?'0':d.left-1+e.clientWidth-e.scrollWidth-8+'px'),null==d?'0':d.width+'px'),null==d?'0':d.height+'px'))),null)]):ti('textarea',Ri(Di(Ui(new $wnd.Object,Ek(a.e)),T(a.e.e)),Of(Tj.prototype.kb,Tj,[a])),null)]),ti(El,xi(new $wnd.Object,Xc(Rc(_d,1),vl,2,6,[Fl])),[ti(Gl,Vi(new $wnd.Object,'pitch'),['Pitch']),ti('input',Ri(Di(Si(Pi(Qi(Ui(Fi(yi(new $wnd.Object,'pitch'),(Dj(),uj)),''+Ck(a.e)),'0'),'1'),'0.05'),T(a.e.e)),Of(Yj.prototype.kb,Yj,[a])),null),ti(Dl,Ei(Di(Ci(zi(Fi(new $wnd.Object,(ej(),bj)),Hl),Hl),T(a.e.e)),Of(Zj.prototype.lb,Zj,[a])),[Il])]),ti(El,xi(new $wnd.Object,Xc(Rc(_d,1),vl,2,6,[Fl])),[ti(Gl,Vi(new $wnd.Object,'rate'),['Rate']),ti('input',Ri(Di(Si(Pi(Qi(Ui(Fi(yi(new $wnd.Object,'rate'),uj),''+Dk(a.e)),'-3'),'3'),'0.25'),T(a.e.e)),Of($j.prototype.kb,$j,[a])),null),ti(Dl,Ei(Di(Ci(zi(Fi(new $wnd.Object,bj),Jl),Jl),T(a.e.e)),Of(_j.prototype.lb,_j,[a])),[Il])]),ti(El,xi(new $wnd.Object,Xc(Rc(_d,1),vl,2,6,[Fl])),[ti(Gl,Vi(new $wnd.Object,'volume'),['Volume']),ti('input',Ri(Di(Si(Pi(Qi(Ui(Fi(yi(new $wnd.Object,'volume'),uj),''+Gk(a.e)),'0'),'1'),'0.05'),T(a.e.e)),Of(ak.prototype.kb,ak,[a])),null),ti(Dl,Ei(Di(Ci(zi(Fi(new $wnd.Object,bj),Kl),Kl),T(a.e.e)),Of(bk.prototype.lb,bk,[a])),[Il])]),ti(El,xi(new $wnd.Object,Xc(Rc(_d,1),vl,2,6,[Fl])),[ti(Gl,Vi(new $wnd.Object,'voice'),['Voice']),ti('select',Ui(Di(Ri(new $wnd.Object,Of(Qj.prototype.kb,Qj,[a])),T(a.e.e)),null==c?'':c.voiceURI),Mh(Kh(T(a.e.j).Y(),new Rj),new vi)),ti(Dl,Ei(Di(Ci(zi(Fi(new $wnd.Object,bj),Ll),Ll),T(a.e.e)),Of(Uj.prototype.lb,Uj,[a])),[Il])]),ti(El,xi(new $wnd.Object,Xc(Rc(_d,1),vl,2,6,['bottom'])),[ti(Dl,Ei(Di(Ci(zi(xi(Fi(new $wnd.Object,bj),Xc(Rc(_d,1),vl,2,6,['small'])),'Speak'),'Speak'),T(a.e.e)),Of(Vj.prototype.lb,Vj,[a])),['Speak']),ti(Dl,Ei(Di(Ci(zi(xi(Fi(new $wnd.Object,bj),Xc(Rc(_d,1),vl,2,6,['small'])),T(a.e.b)?Ml:'Pause'),T(a.e.b)?Ml:'Pause'),!T(a.e.e)),Of(Wj.prototype.lb,Wj,[a])),[T(a.e.b)?Ml:'Pause']),ti(Dl,Ei(Di(Ci(zi(xi(Fi(new $wnd.Object,bj),Xc(Rc(_d,1),vl,2,6,['small'])),'Stop'),'Stop'),!T(a.e.e)),Of(Xj.prototype.lb,Xj,[])),['Stop'])])])]));return b}
var ul={10:1},vl={3:1},wl=1048576,xl=1835008,yl=2097152,zl='__noinit__',Al={3:1,8:1,6:1,4:1},Bl={3:1,35:1,60:1},Cl='children',Dl='button',El='div',Fl='speecharg',Gl='label',Hl='Reset pitch',Il='\u21B6',Jl='Reset rate',Kl='Reset volume',Ll='Reset voice',Ml='Resume',Nl='boundary',Ol='voiceschanged',Pl=142606336;var _,Jf,Ef,Bf=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Kf();Mf(1,null,{},p);_.u=function(a){return o(this,a)};_.v=function(){return this.nb};_.w=Ql;_.equals=function(a){return this.u(a)};_.hashCode=function(){return this.w()};var Yc,Zc,$c;Mf(44,1,{},$f);_.L=function(a){var b;b=new $f;b.e=4;a>1?(b.c=dg(this,a-1)):(b.c=this);return b};_.M=function(){Yf(this);return this.b};_.N=function(){return Zf(this)};_.O=function(){Yf(this);return this.h};_.P=function(){return (this.e&4)!=0};_.Q=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Xf=1;var Zd=ag(1);var Od=ag(44);Mf(75,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var md=ag(75);Mf(76,1,ul,G);_.A=function(){Db(this.a)};var jd=ag(76);Mf(36,1,{},H);_.B=function(){return this.a.A(),null};var kd=ag(36);Mf(77,1,{},I);var ld=ag(77);var J;Mf(38,1,{38:1},Q);_.b=0;_.c=false;_.d=0;var nd=ag(38);Mf(163,1,{});var qd=ag(163);Mf(40,163,{},X);_.a=false;_.d=0;_.i=false;var pd=ag(40);Mf(114,1,{},Y);_.B=function(){return U(this.a)};var od=ag(114);Mf(13,163,{13:1},jb);_.a=4;_.d=false;_.e=0;var sd=ag(13);Mf(113,1,ul,kb);_.A=function(){bb(this.a)};var rd=ag(113);Mf(21,163,{21:1},wb,xb);_.c=0;var xd=ag(21);Mf(108,1,{},yb);_.A=function(){R(this.a)};var td=ag(108);Mf(109,1,ul,zb);_.A=function(){nb(this.a)};var ud=ag(109);Mf(110,1,ul,Ab);_.A=function(){qb(this.a)};var vd=ag(110);Mf(111,1,{},Bb);_.C=function(a){ob(this.a,a)};var wd=ag(111);Mf(88,1,{},Eb);_.a=0;_.b=0;_.c=0;var yd=ag(88);Mf(124,1,{},Gb);_.a=false;var zd=ag(124);Mf(52,163,{52:1},Kb);_.a=0;var Bd=ag(52);Mf(87,1,{},Pb);var Ad=ag(87);Mf(126,1,{},_b);_.a=0;var Qb;var Cd=ag(126);Mf(53,1,{},hc);_.g=0;var Ed=ag(53);Mf(107,1,ul,ic);_.A=function(){fc(this.a)};var Dd=ag(107);Mf(4,1,{3:1,4:1});_.D=function(a){return new Error(a)};_.F=Rl;_.G=function(){return Mh(Kh(Sg((this.e==null&&(this.e=Tc(be,vl,4,0,0,1)),this.e)),new rg),new Qh)};_.H=function(){return this.c};_.I=function(){lc(this,nc(this.D(mc(this,this.d))));Oc(this)};_.b=zl;_.f=true;var be=ag(4);Mf(8,4,{3:1,8:1,4:1});var Rd=ag(8);Mf(6,8,Al);var $d=ag(6);Mf(46,6,Al);var Vd=ag(46);Mf(71,46,Al);var Id=ag(71);Mf(31,71,{31:1,3:1,8:1,6:1,4:1},rc);_.J=function(){return fd(this.a)===fd(pc)?null:this.a};var pc;var Fd=ag(31);var Gd=ag(0);Mf(145,1,{});var Hd=ag(145);var tc=0,uc=0,vc=-1;Mf(82,145,{},Jc);var Fc;var Jd=ag(82);var Mc;Mf(157,1,{});var Ld=ag(157);Mf(72,157,{},Qc);var Kd=ag(72);var Tf;Mf(74,6,Al);var Ud=ag(74);Mf(112,74,Al,Vf);var Md=ag(112);Yc={3:1,67:1,30:1};var Nd=ag(67);Mf(155,1,vl);var ig;var Yd=ag(155);Zc={3:1,30:1};var Pd=ag(156);Mf(22,1,{3:1,30:1,22:1});_.u=function(a){return this===a};_.w=Ql;_.b=0;var Qd=ag(22);Mf(45,6,Al);var Sd=ag(45);Mf(73,6,Al,mg);var Td=ag(73);Mf(222,1,{});Mf(78,46,Al,ng);_.D=function(a){return new TypeError(a)};var Wd=ag(78);Mf(68,45,Al,og);var Xd=ag(68);$c={3:1,66:1,30:1,2:1};var _d=ag(2);Mf(226,1,{});Mf(63,1,{},rg);_.S=function(a){return a.b};var ae=ag(63);Mf(37,6,Al,sg);var ce=ag(37);Mf(158,1,{35:1});_.X=function(){return new Bh(this,0)};_.Y=function(){return new Nh(null,this.X())};_.T=function(a){throw Df(new sg('Add not supported on this collection'))};_.U=function(a){return tg(this,a)};_.V=function(){return this.W()==0};_.Z=function(a){return vg(this,a)};var de=ag(158);Mf(161,1,{142:1});_.u=function(a){var b,c,d;if(a===this){return true}if(!bd(a,39)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Dg((new Ag(d)).a);c.b;){b=Cg(c);if(!wg(this,b)){return false}}return true};_.w=function(){return Vg(new Ag(this))};var ke=ag(161);Mf(89,161,{142:1});var ge=ag(89);Mf(160,158,{35:1,167:1});_.X=function(){return new Bh(this,1)};_.u=function(a){var b;if(a===this){return true}if(!bd(a,20)){return false}b=a;if(yg(b.a)!=this.W()){return false}return ug(this,b)};_.w=function(){return Vg(this)};var le=ag(160);Mf(20,160,{20:1,35:1,167:1},Ag);_.U=function(a){return zg(this,a)};_.R=function(){return new Dg(this.a)};_.W=function(){return yg(this.a)};var fe=ag(20);Mf(23,1,{},Dg);_.$=Sl;_.ab=function(){return Cg(this)};_._=Rl;_.b=false;var ee=ag(23);Mf(159,158,{35:1,60:1});_.X=function(){return new Bh(this,16)};_.bb=function(a,b){throw Df(new sg('Add not supported on this list'))};_.T=function(a){this.bb(this.W(),a);return true};_.u=function(a){var b,c,d,e,f;if(a===this){return true}if(!bd(a,60)){return false}f=a;if(this.W()!=f.W()){return false}e=f.R();for(c=this.R();c._();){b=c.ab();d=e.ab();if(!(fd(b)===fd(d)||b!=null&&q(b,d))){return false}}return true};_.w=function(){return Wg(this)};_.R=function(){return new Fg(this)};_.db=function(a){throw Df(new sg('Remove not supported on this list'))};var ie=ag(159);Mf(81,1,{},Fg);_.$=Sl;_._=function(){return this.a<this.b.W()};_.ab=function(){return this.a<this.b.W(),this.b.cb(this.a++)};_.a=0;var he=ag(81);Mf(162,1,{168:1});_.u=function(a){var b;if(!bd(a,32)){return false}b=a;return nh(this.b.value[0],b.b.value[0])&&nh(kh(this),kh(b))};_.w=function(){return oh(this.b.value[0])^oh(kh(this))};var je=ag(162);Mf(12,159,Bl,Og,Pg);_.bb=function(a,b){ai(this.a,a,b)};_.T=function(a){return Hg(this,a)};_.U=function(a){return Kg(this,a,0)!=-1};_.cb=function(a){return Jg(this,a)};_.V=function(){return this.a.length==0};_.R=function(){return new Qg(this)};_.db=function(a){return Lg(this,a)};_.W=Tl;_.Z=function(a){var b,c;c=this.a.length;a.length<c&&(a=di(new Array(c),a));for(b=0;b<c;++b){a[b]=this.a[b]}a.length>c&&(a[c]=null);return a};var ne=ag(12);Mf(15,1,{},Qg);_.$=Sl;_._=function(){return this.a<this.c.a.length};_.ab=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var me=ag(15);Mf(80,159,Bl,Ug);_.U=function(a){return Eg(this,a)!=-1};_.cb=function(a){return this.a[a]};_.W=Tl;_.Z=function(a){return Tg(this,a)};var oe=ag(80);Mf(39,89,{3:1,39:1,142:1},Xg);var pe=ag(39);Mf(90,1,{},Zg);_.R=function(){return new $g(this)};_.b=0;var re=ag(90);Mf(48,1,{},$g);_.$=Sl;_.ab=function(){return this.d=this.a[this.c++],this.d};_._=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var qe=ag(48);var _g;Mf(91,1,{},ih);_.R=function(){return new jh(this)};_.b=0;_.c=0;var ue=ag(91);Mf(49,1,{},jh);_.$=Sl;_.ab=function(){return this.c=this.a,this.a=this.b.next(),new lh(this.d,this.c,this.d.c)};_._=function(){return !this.a.done};var se=ag(49);Mf(32,162,{32:1,168:1},lh);_.c=0;var te=ag(32);Mf(33,1,{33:1},sh);_.u=function(a){var b;if(a===this){return true}if(!bd(a,33)){return false}b=a;return nh(this.a,b.a)};_.w=function(){return oh(this.a)};var ph;var ve=ag(33);Mf(93,1,{});_.$=Ul;_.eb=function(){return this.d};_.fb=function(){return this.e};_.d=0;_.e=0;var ze=ag(93);Mf(50,93,{});var we=ag(50);Mf(83,1,{});_.$=Ul;_.eb=Rl;_.fb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var ye=ag(83);Mf(84,83,{},zh);_.$=function(a){wh(this,a)};_.gb=function(a){return xh(this,a)};var xe=ag(84);Mf(19,1,{},Bh);_.eb=function(){return this.a};_.fb=function(){Ah(this);return this.c};_.$=function(a){Ah(this);this.d.$(a)};_.gb=function(a){Ah(this);if(this.d._()){a.C(this.d.ab());return true}return false};_.a=0;_.c=0;var Ae=ag(19);Mf(65,1,{},Ch);_.S=function(a){return a};var Be=ag(65);Mf(125,1,{},Dh);var Ce=ag(125);Mf(92,1,{});_.c=false;var Le=ag(92);Mf(24,92,{},Nh);var Ke=ag(24);Mf(64,1,{},Qh);_.hb=function(a){return Tc(Zd,vl,1,a,5,1)};var De=ag(64);Mf(95,50,{},Sh);_.gb=function(a){this.b=false;while(!this.b&&this.c.gb(new Th(this,a)));return this.b};_.b=false;var Fe=ag(95);Mf(97,1,{},Th);_.C=function(a){Rh(this.a,this.b,a)};var Ee=ag(97);Mf(94,50,{},Vh);_.gb=function(a){return this.b.gb(new Wh(this,a))};var He=ag(94);Mf(96,1,{},Wh);_.C=function(a){Uh(this.a,this.b,a)};var Ge=ag(96);Mf(51,1,{},Yh);_.C=function(a){Xh(this,a)};var Ie=ag(51);Mf(98,1,{},$h);_.C=function(a){Zh(this,a)};var Je=ag(98);Mf(224,1,{});Mf(221,1,{});var fi=0;var hi,ii=0,ji;Mf(829,1,{});Mf(854,1,{});Mf(123,1,{},vi);_.hb=function(a){return new Array(a)};var Me=ag(123);Mf(205,$wnd.Function,{},wi);_.jb=function(a){ui(this.a,this.b,a)};Mf(25,22,{3:1,30:1,22:1,25:1},fj);var bj,cj,dj;var Ne=bg(25,gj);Mf(5,22,{3:1,30:1,22:1,5:1},Ej);var hj,ij,jj,kj,lj,mj,nj,oj,pj,qj,rj,sj,tj,uj,vj,wj,xj,yj,zj,Aj,Bj,Cj;var Oe=bg(5,Fj);var Gj;Mf(206,$wnd.Function,{},Ij);_.K=function(a){return Fb(Gj),Gj=null,null};Mf(100,1,{});var Re=ag(100);Mf(195,$wnd.Function,{},Qj);_.kb=function(a){Pj(this.a,a)};Mf(86,1,{},Rj);_.S=function(a){return ti('option',Ui(new $wnd.Object,a.voiceURI),[a.name+' ('+a.lang+')'])};var Pe=ag(86);Mf(185,$wnd.Function,{},Sj);_.C=function(a){Kj(this.a,a)};Mf(187,$wnd.Function,{},Tj);_.kb=function(a){Lj(this.a,a)};Mf(196,$wnd.Function,{},Uj);_.lb=function(a){Kk(this.a.e)};Mf(197,$wnd.Function,{},Vj);_.lb=function(a){pk(this.a.e)};Mf(198,$wnd.Function,{},Wj);_.lb=function(a){T(this.a.e.b)?(Uf(),$wnd.goog.global.window).speechSynthesis.resume():(Uf(),$wnd.goog.global.window).speechSynthesis.pause()};Mf(199,$wnd.Function,{},Xj);_.lb=function(a){(Uf(),$wnd.goog.global.window).speechSynthesis.cancel()};Mf(188,$wnd.Function,{},Yj);_.kb=function(a){Mj(this.a,a)};Mf(189,$wnd.Function,{},Zj);_.lb=function(a){gc(new Zk(this.a.e,0.5))};Mf(190,$wnd.Function,{},$j);_.kb=function(a){Nj(this.a,a)};Mf(191,$wnd.Function,{},_j);_.lb=function(a){gc(new $k(this.a.e,0))};Mf(192,$wnd.Function,{},ak);_.kb=function(a){Oj(this.a,a)};Mf(193,$wnd.Function,{},bk);_.lb=function(a){gc(new _k(this.a.e,1))};Mf(62,1,{},ck);var Qe=ag(62);Mf(101,100,{});_.d=0;var qf=ag(101);Mf(102,101,{},ik);var gk=0;var We=ag(102);Mf(103,1,ul,jk);_.A=function(){Z(this.a.e)};var Se=ag(103);Mf(104,1,ul,kk);_.A=function(){lb(this.a.a)};var Te=ag(104);Mf(106,1,{},lk);_.B=function(){return ek(this.a)};var Ue=ag(106);Mf(105,1,{},mk);_.A=function(){fk(this.a)};var Ve=ag(105);Mf(127,1,{});var Af=ag(127);Mf(128,127,{},Pk);_.l=0;_.m=0;_.o=0;_.p=0;_.r=0;var rk=0;var of=ag(128);Mf(129,1,ul,Qk);_.A=function(){sk(this.a)};var Xe=ag(129);Mf(133,1,{},Rk);_.A=function(){tk(this.a)};var Ye=ag(133);Mf(134,1,{},Sk);_.A=function(){uk(this.a)};var Ze=ag(134);Mf(130,1,{},Tk);_.B=function(){return Wf(),(Uf(),$wnd.goog.global.window).speechSynthesis.speaking?true:false};var $e=ag(130);Mf(131,1,{},Uk);_.B=function(){return Wf(),(Uf(),$wnd.goog.global.window).speechSynthesis.paused?true:false};var _e=ag(131);Mf(132,1,{},Vk);_.B=function(){var a;return a=(Uf(),$wnd.goog.global.window).speechSynthesis.getVoices(),new Ug(di(a,Wc(a.length)))};var af=ag(132);Mf(135,1,{},Wk);_.A=function(){nk(this.a)};var bf=ag(135);Mf(55,1,ul,Xk);_.A=function(){zk(this.a,this.b)};_.b=0;var cf=ag(55);Mf(56,1,ul,Yk);_.A=function(){yk(this.a,this.b)};_.b=0;var df=ag(56);Mf(57,1,ul,Zk);_.A=function(){vk(this.a,this.b)};_.b=0;var ef=ag(57);Mf(58,1,ul,$k);_.A=function(){wk(this.a,this.b)};_.b=0;var ff=ag(58);Mf(59,1,ul,_k);_.A=function(){Bk(this.a,this.b)};_.b=0;var gf=ag(59);Mf(41,1,ul,al);_.A=function(){Ak(this.a,this.b)};var hf=ag(41);Mf(136,1,ul,bl);_.A=function(){xk(this.a,this.b)};var jf=ag(136);Mf(137,1,ul,cl);_.A=function(){V(this.a)};var kf=ag(137);Mf(138,1,ul,dl);_.A=function(){ok(this.a,this.b)};var lf=ag(138);Mf(139,1,ul,el);_.A=function(){Hk(this.a)};var mf=ag(139);Mf(140,1,ul,fl);_.A=function(){Ik(this.a,this.b)};var nf=ag(140);Mf(200,$wnd.Function,{},gl);_.mb=function(a){return new jl(a)};var hl;Mf(85,$wnd.React.Component,{},jl);Lf(Jf[1],_);_.componentDidMount=function(){(Uf(),$wnd.goog.global.window).speechSynthesis.cancel()};_.componentWillUnmount=function(){dk(this.a)};_.render=function(){return hk(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var pf=ag(85);Mf(54,1,{},kl);_.ib=function(a){return a.default};var rf=ag(54);Mf(115,1,{},ll);_.handleEvent=function(a){Mk(this.a.j)};var sf=ag(115);Mf(116,1,{},ml);_.handleEvent=Vl;var tf=ag(116);Mf(117,1,{},nl);_.handleEvent=Vl;var uf=ag(117);Mf(118,1,{},ol);_.handleEvent=Vl;var vf=ag(118);Mf(119,1,{},pl);_.handleEvent=Vl;var wf=ag(119);Mf(120,1,{},ql);_.handleEvent=Vl;var xf=ag(120);Mf(121,1,{},rl);_.handleEvent=Vl;var yf=ag(121);Mf(122,1,{},sl);_.ib=function(a){return qk(this.a,a)};var zf=ag(122);var hd=cg('D');var tl=(wc(),zc);var gwtOnLoad=gwtOnLoad=Hf;Ff(Sf);If('permProps',[[]]);if (webspeechdemo) webspeechdemo.onScriptLoad(gwtOnLoad);})();