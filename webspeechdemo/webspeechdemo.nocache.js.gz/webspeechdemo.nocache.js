function webspeechdemo(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='webspeechdemo',tb='__gwt_marker_webspeechdemo',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='C65E6DEE6CE1BA7D2266435DD8A73A0B',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};webspeechdemo.onScriptLoad=function(a){webspeechdemo=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
webspeechdemo();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'C65E6DEE6CE1BA7D2266435DD8A73A0B';function p(){}
function Qf(){}
function Mf(){}
function Fb(){}
function Ic(){}
function Pc(){}
function Ph(){}
function Bh(){}
function Xh(){}
function qg(){}
function ui(){}
function Hj(){}
function Qj(){}
function Wj(){}
function Sk(){}
function Tk(){}
function Uk(){}
function Vk(){}
function gl(){}
function kl(){}
function Nc(a){Mc()}
function Vf(){Vf=Mf}
function qb(a,b){a.b=b}
function Wh(a,b){a.a=b}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function hc(a){this.a=a}
function zg(a){this.a=a}
function Tg(a){this.a=a}
function Tj(a){this.a=a}
function Pj(a){this.a=a}
function Rj(a){this.a=a}
function Sj(a){this.a=a}
function Uj(a){this.a=a}
function Vj(a){this.a=a}
function Xj(a){this.a=a}
function Yj(a){this.a=a}
function Zj(a){this.a=a}
function Zh(a){this.a=a}
function Ch(a){this.a=a}
function $j(a){this.a=a}
function _j(a){this.a=a}
function ak(a){this.a=a}
function ik(a){this.a=a}
function jk(a){this.a=a}
function kk(a){this.a=a}
function lk(a){this.a=a}
function Pk(a){this.a=a}
function Qk(a){this.a=a}
function Rk(a){this.a=a}
function Wk(a){this.a=a}
function cl(a){this.a=a}
function el(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function rl(a){this.a=a}
function sl(a){this.a=a}
function Eg(a){this.b=a}
function Pg(a){this.c=a}
function Yg(){this.a=eh()}
function hh(){this.a=eh()}
function Ng(){Fg(this)}
function Sl(a){lh(this,a)}
function Ul(a){sh(this,a)}
function db(a){Xb((J(),a))}
function eb(a){Yb((J(),a))}
function hb(a){Zb((J(),a))}
function w(a){--a.e;D(a)}
function Y(a){!!a&&bc(a.s)}
function cc(a){!!a&&a.B()}
function oi(a,b){ni(a,b)}
function Yh(a,b){Oh(a.a,b)}
function C(a,b){Nb(a.f,b.f)}
function K(a,b){O(a);L(a,b)}
function Vl(a){Ik(this.a,a)}
function rh(a){ph();this.a=a}
function Cf(a){return a.b}
function Jj(a,b){return a.f=b}
function Rl(){return this.b}
function Ql(){return fi(this)}
function Ig(a,b){return a.a[b]}
function kc(a,b){a.b=b;jc(a,b)}
function ck(a){a.d=2;bc(a.b)}
function bi(a,b){a.splice(b,1)}
function Uf(a){nc.call(this,a)}
function ng(a){nc.call(this,a)}
function rg(a){nc.call(this,a)}
function _g(){_g=Mf;$g=bh()}
function J(){J=Mf;I=new F}
function pc(){pc=Mf;oc=new p}
function Fc(){Fc=Mf;Ec=new Ic}
function vc(){vc=Mf;!!(Mc(),Lc)}
function Ff(){Df==null&&(Df=[])}
function xh(a,b,c){b.C(a.a[c])}
function Th(a,b,c){b.C(a.a.S(c))}
function sh(a,b){while(a.gb(b));}
function Oh(a,b){Wh(a,Nh(a.a,b))}
function Qc(a,b){return cg(a,b)}
function T(a){mb(a.f);return V(a)}
function Yf(a){Xf(a);return a.j}
function Nh(a,b){a.T(b);return a}
function xi(a,b){a.id=b;return a}
function zi(a,b){a.ref=b;return a}
function Ki(a,b){a.top=b;return a}
function Oi(a,b){a.max=b;return a}
function Pi(a,b){a.min=b;return a}
function Bk(a){gb(a.c);return a.l}
function Ck(a){gb(a.d);return a.m}
function Dk(a){gb(a.f);return a.n}
function Ek(a){gb(a.i);return a.q}
function Fk(a){gb(a.k);return a.r}
function Mk(a){gb(a.g);return a.o}
function Nk(a){gb(a.h);return a.p}
function eh(){_g();return new $g}
function Vc(a){return new Array(a)}
function xg(a){return a.a.b+a.b.b}
function gh(a,b){return a.a.get(b)}
function Sh(a,b){this.a=a;this.b=b}
function Vh(a,b){this.a=a;this.b=b}
function jg(a,b){this.a=a;this.b=b}
function vi(a,b){this.a=a;this.b=b}
function Db(a){this.d=a;this.b=100}
function mg(){ic(this);this.I()}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function ab(a){J();Yb(a);a.e=-2}
function Dc(){sc!=0&&(sc=0);uc=-1}
function bk(){this.a=ri((il(),hl))}
function Xk(a,b){this.a=a;this.b=b}
function Yk(a,b){this.a=a;this.b=b}
function Zk(a,b){this.a=a;this.b=b}
function $k(a,b){this.a=a;this.b=b}
function _k(a,b){this.a=a;this.b=b}
function al(a,b){this.a=a;this.b=b}
function bl(a,b){this.a=a;this.b=b}
function dl(a,b){this.a=a;this.b=b}
function fl(a,b){this.a=a;this.b=b}
function ej(a,b){jg.call(this,a,b)}
function Dj(a,b){jg.call(this,a,b)}
function _h(a,b,c){a.splice(b,0,c)}
function v(a,b,c){t(a,new H(c),b)}
function ph(){ph=Mf;oh=new rh(null)}
function Ii(a,b){a.left=b;return a}
function Ri(a,b){a.step=b;return a}
function Ai(a,b){a.style=b;return a}
function Bi(a,b){a.title=b;return a}
function Mi(a,b){a.width=b;return a}
function Ti(a,b){a.value=b;return a}
function Hi(a,b){a.height=b;return a}
function Cc(a){$wnd.clearTimeout(a)}
function wg(a){return !a?null:jh(a)}
function nh(a){return a!=null?s(a):0}
function ed(a){return a==null?null:a}
function Tl(){return this.a.length}
function Tb(a){return !a.d?a:Tb(a.d)}
function o(a,b){return ed(a)===ed(b)}
function B(a,b,c){return u(a,c,2048,b)}
function A(a,b,c){u(a,new G(b),c,null)}
function ai(a,b){$h(b,0,a,0,b.length)}
function Gi(a,b){a.display=b;return a}
function Ci(a,b){a.disabled=b;return a}
function Qi(a,b){a.onChange=b;return a}
function Di(a,b){a.onClick=b;return a}
function Ui(a,b){a.htmlFor=b;return a}
function ni(a,b){for(var c in a){b(c)}}
function og(a,b){return a.charCodeAt(b)}
function pk(a,b){return o(b.voiceURI,a)}
function ad(a,b){return a!=null&&$c(a,b)}
function qh(a){return a.a!=null?a.a:null}
function Z(a){return !(!!a&&1==(a.c&7))}
function fi(a){return a.$H||(a.$H=++ei)}
function cd(a){return typeof a==='number'}
function dd(a){return typeof a==='string'}
function Li(a,b){a.transition=b;return a}
function Xf(a){if(a.j!=null){return}eg(a)}
function ib(a){this.c=new Ng;this.b=a}
function Wg(){this.a=new Yg;this.b=new hh}
function ji(){ji=Mf;gi=new p;ii=new p}
function Fg(a){a.a=Sc(Xd,ul,1,0,5,1)}
function P(){this.a=Sc(Xd,ul,1,100,5,1)}
function nc(a){this.d=a;ic(this);this.I()}
function Mh(a,b){Fh.call(this,a);this.a=b}
function Oj(a,b){Kk(a.e,b.target.value)}
function pb(a){J();ob(a);sb(a,2,true)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function fc(a){J();Pb?a.B():A((null,I),a,0)}
function Jk(a){A((J(),J(),I),new el(a),Pl)}
function Lk(a){A((J(),J(),I),new cl(a),Pl)}
function lh(a,b){while(a._()){Yh(b,a.ab())}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function bd(a){return typeof a==='boolean'}
function wc(a,b,c){return a.apply(b,c);var d}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function kh(a,b,c){this.a=a;this.b=b;this.c=c}
function yi(a,b){a['aria-label']=b;return a}
function Gg(a,b){a.a[a.a.length]=b;return true}
function Ji(a){a.position='fixed';return a}
function ic(a){a.f&&a.b!==zl&&a.I();return a}
function _f(a){var b;b=$f(a);gg(a,b);return b}
function Mc(){Mc=Mf;var a;!Oc();a=new Pc;Lc=a}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function Kj(a,b){fc(new bl(a.e,b.target.value))}
function vh(a,b){while(a.c<a.d){xh(a,b,a.c++)}}
function zh(a){if(!a.d){a.d=a.b.R();a.c=a.b.W()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Qh(a,b,c){if(a.a.ib(c)){a.b=true;b.C(c)}}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function Kk(a,b){A((J(),J(),I),new fl(a,b),Pl)}
function Gh(a,b){var c;return Kh(a,(c=new Ng,c))}
function Kg(a,b){var c;c=a.a[b];bi(a.a,b);return c}
function Bg(a){var b;b=a.a.ab();a.b=Ag(a);return b}
function bg(a){var b;b=$f(a);b.i=a;b.e=1;return b}
function Jc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Qg(a,b){return th(b,a.length),new yh(a,b)}
function fh(a,b){return !(a.a.get(b)===undefined)}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Uc(a){return Array.isArray(a)&&a.pb===Qf}
function _c(a){return !Array.isArray(a)&&a.pb===Qf}
function Rg(a){return new Mh(null,Qg(a,a.length))}
function gk(a){return B((J(),J(),I),a.a,new lk(a))}
function Lj(a,b){fc(new Zk(a.e,kg(b.target.value)))}
function Mj(a,b){fc(new $k(a.e,kg(b.target.value)))}
function Nj(a,b){fc(new _k(a.e,kg(b.target.value)))}
function ek(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Dh(a){if(!a.b){Eh(a);a.c=true}else{Dh(a.b)}}
function uk(a,b){var c;c=a.l;if(b!=c){a.l=b;eb(a.c)}}
function vk(a,b){var c;c=a.m;if(b!=c){a.m=b;eb(a.d)}}
function wk(a,b){var c;c=a.n;if(b!=c){a.n=b;eb(a.f)}}
function xk(a,b){var c;c=a.o;if(b!=c){a.o=b;eb(a.g)}}
function yk(a,b){var c;c=a.p;if(b!=c){a.p=b;eb(a.h)}}
function Ak(a,b){var c;c=a.r;if(b!=c){a.r=b;eb(a.k)}}
function Mg(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Ei(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Fi(a){a.border='1px solid orange';return a}
function di(a){if(a==null){throw Cf(new mg)}return a}
function mi(){if(hi==256){gi=ii;ii=new p;hi=0}++hi}
function Fh(a){if(!a){this.b=null;new Ng}else{this.b=a}}
function yh(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function uh(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function Ah(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Ik(a,b){A((J(),J(),I),new dl(a,b),75497472)}
function Hh(a,b){Eh(a);return new Mh(a,new Rh(b,a.a))}
function Jh(a,b){Eh(a);return new Mh(a,new Uh(b,a.a))}
function mh(a,b){return ed(a)===ed(b)||a!=null&&q(a,b)}
function fj(){dj();return Wc(Qc(Le,1),ul,25,0,[aj,bj,cj])}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&yl)&&D((null,I))}
function Gk(a){fc(new al(a,qh(Ih(Hh(S(a.j).Y(),new kl)))))}
function Bc(a){vc();$wnd.setTimeout(function(){throw a},0)}
function Tf(){Tf=Mf;Sf=$wnd.goog.global.document}
function ag(a,b){var c;c=$f(a);gg(a,c);c.e=b?8:0;return c}
function lc(a,b){var c;c=Yf(a.nb);return b==null?c:c+': '+b}
function cg(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.L(b))}
function Kf(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function yg(a,b){if(ad(b,32)){return vg(a.a,b)}return false}
function dg(a){if(a.Q()){return null}var b=a.i;return If[b]}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function Eh(a){if(a.b){Eh(a.b)}else if(a.c){throw Cf(new lg)}}
function Hk(a,b){fc(new al(a,qh(Ih(Hh(S(a.j).Y(),new sl(b))))))}
function ec(a){cc(a.f);!!a.d&&dc(a);Y(a.a);Y(a.c);cc(a.b);cc(a.e)}
function Og(a){Fg(this);ai(this.a,ug(a,Sc(Xd,ul,1,xg(a.a),5,1)))}
function Zg(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Uh(a,b){uh.call(this,b.fb(),b.eb()&-6);this.a=a;this.b=b}
function wh(a,b){if(a.c<a.d){xh(a,b,a.c++);return true}return false}
function Of(a){function b(){}
;b.prototype=a||{};return new b}
function mc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function il(){il=Mf;var a;hl=(a=Nf(gl.prototype.mb,gl,[]),a)}
function zc(a,b,c){var d;d=xc();try{return wc(a,b,c)}finally{Ac(d)}}
function bb(a,b){var c,d;Gg(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Lh(a,b){var c;c=Gh(a,new Ch(new Bh));return c.Z(b.hb(c.W()))}
function Kh(a,b){var c;Dh(a);c=new Xh;c.a=b;a.a.$(new Zh(c));return c.a}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Rh(a,b){uh.call(this,b.fb(),b.eb()&-16449);this.a=a;this.c=b}
function ih(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function jl(a){$wnd.React.Component.call(this,a);this.a=new hk(this)}
function Cg(a){this.d=a;this.c=new ih(this.d.b);this.a=this.c;this.b=Ag(this)}
function $(a){if(-2!=a.e){A((J(),J(),I),new jb(a),0);!!a.b&&kb(a.b)}}
function Ib(b){try{mb(b.b.a)}catch(a){a=Bf(a);if(!ad(a,4))throw Cf(a)}}
function Ac(a){a&&Hc((Fc(),Ec));--sc;if(a){if(uc!=-1){Cc(uc);uc=-1}}}
function ti(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Jg(a,b,c){for(;c<a.a.length;++c){if(mh(b,a.a[c])){return c}}return -1}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Hg(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.C(c)}}
function Ob(){var a;this.a=Sc(ld,ul,41,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function rc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function yc(b){vc();return function(){return zc(b,this,arguments);var a}}
function Lg(a,b){var c;c=Jg(a,b,0);if(c==-1){return false}bi(a.a,c);return true}
function Sc(a,b,c,d,e,f){var g;g=Tc(e,d);e!=10&&Wc(Qc(a,f),b,c,e,g);return g}
function ci(a,b){return Rc(b)!=10&&Wc(r(b),b.ob,b.__elementTypeId$,Rc(b),a),a}
function Rc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function fd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function jh(a){if(a.a.c!=a.c){return gh(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function R(a){if(!a.a){a.a=true;a.k=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function V(a){if(a.b){if(ad(a.b,6)){throw Cf(a.b)}else{throw Cf(a.b)}}return a.k}
function rb(b){if(b){try{b.B()}catch(a){a=Bf(a);if(ad(a,4)){J()}else throw Cf(a)}}}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function Gc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Kc(b,c)}while(a.a);a.a=c}}
function Hc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Kc(b,c)}while(a.b);a.b=c}}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ng);Gg(a.b,b)}}}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new Ng);a.c=c.c}b.d=true;a.c.T(b)}
function zk(a,b){var c;c=a.q;if(!(ed(b)===ed(c)||b!=null&&q(b,c))){a.q=b;eb(a.i)}}
function gg(a,b){var c;if(!a){return}b.i=a;var d=dg(b);if(!d){If[a]=[b];return}d.nb=b}
function Nf(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function $f(a){var b;b=new Zf;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function ri(a){var b;b=qi($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function qc(a){pc();ic(this);this.b=a;jc(this,a);this.d=a==null?'null':Pf(a);this.a=a}
function lg(){nc.call(this,"Stream already terminated, can't be modified or used")}
function Ef(){Ff();var a=Df;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ob(a){var b,c;for(c=new Pg(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Dg(a,b){var c,d;for(c=0,d=a.a.length;c<d;++c){if(mh(b,a.a[c])){return c}}return -1}
function tg(a,b){var c,d;for(d=new Cg(b.a);d.b;){c=Bg(d);if(!yg(a,c)){return false}}return true}
function Vg(a){var b,c,d;d=1;for(c=a.R();c._();){b=c.ab();d=31*d+(b!=null?s(b):0);d=d|0}return d}
function bc(a){if(a.g>=0){a.g=-2;u((J(),J(),I),new G(new hc(a)),67108864,null)}}
function Rf(){$wnd.ReactDOM.render((new bk).a,(Tf(),Sf).getElementById('app'),null)}
function dj(){dj=Mf;aj=new ej(Dl,0);bj=new ej('reset',1);cj=new ej('submit',2)}
function th(a,b){if(0>a||a>b){throw Cf(new Uf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function tk(a){(Tf(),$wnd.goog.global.window).speechSynthesis.removeEventListener(Ol,a.t)}
function sk(a){(Tf(),$wnd.goog.global.window).speechSynthesis.addEventListener(Ol,a.t)}
function rk(a){kb(a.a);R(a.e);R(a.b);R(a.j);$(a.h);$(a.g);$(a.c);$(a.d);$(a.k);$(a.i);$(a.f)}
function Ag(a){if(a.a._()){return true}if(a.a!=a.c){return false}a.a=new Zg(a.d.a);return a.a._()}
function Ih(a){var b;Dh(a);b=new Xh;if(a.a.gb(b)){return ph(),new rh(di(b.a))}return ph(),ph(),oh}
function Bf(a){var b;if(ad(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new qc(a);Nc(b)}return b}
function Wc(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=Qf;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function gc(a,b,c){this.d=c?new Wg:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function Zf(){this.g=Wf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function Xg(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function Ug(a){var b,c,d;d=0;for(c=new Cg(a.a);c.b;){b=Bg(c);d=d+(b?nh(b.b.value[0])^nh(jh(b)):0);d=d|0}return d}
function sg(a,b){var c,d;for(d=a.R();d._();){c=d.ab();if(ed(b)===ed(c)||b!=null&&q(b,c)){return true}}return false}
function mk(a){var b,c;c=S(a.j);b=(gb(a.i),a.q);(null==b||!c.U(b))&&fc(new al(a,qh(Ih(Hh(S(a.j).Y(),new kl)))))}
function cb(a,b){var c,d;d=a.c;Lg(d,b);!!a.b&&vl!=(a.b.c&wl)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function dc(a){var b,c;for(c=new Pg(new Og(new zg(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);jh(b).B()}}
function Vb(a){var b;if(a.c){while(!a.c.V()){b=a.c.db(a.c.W()-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:vl)|(0==(c&6291456)?!a?yl:4194304:0)|0|0|0)}
function Hf(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function r(a){return dd(a)?Zd:cd(a)?Nd:bd(a)?Ld:_c(a)?a.nb:Uc(a)?a.nb:a.nb||Array.isArray(a)&&Qc(Ed,1)||Ed}
function s(a){return dd(a)?li(a):cd(a)?fd(a):bd(a)?a?1231:1237:_c(a)?a.w():Uc(a)?fi(a):!!a&&!!a.hashCode?a.hashCode():fi(a)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function Gj(){if(!Fj){Fj=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(Nf(Hj.prototype.K,Hj,[]))}}
function Ej(){Cj();return Wc(Qc(Me,1),ul,5,0,[gj,hj,ij,jj,kj,lj,mj,nj,oj,pj,qj,rj,sj,tj,uj,vj,wj,xj,yj,zj,Aj,Bj])}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&vl)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Pf(a){var b;if(Array.isArray(a)&&a.pb===Qf){return Yf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function kg(a){var b;b=ig(a);if(b>3.4028234663852886E38){return Infinity}else if(b<-3.4028234663852886E38){return -Infinity}return b}
function li(a){ji();var b,c,d;c=':'+a;d=ii[c];if(d!=null){return fd(d)}d=gi[c];b=d==null?ki(a):fd(d);mi();ii[c]=b;return b}
function pi(a){var b,c;b=qi($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=(c={},c[Cl]=a,c);return b}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function xc(){var a;if(sc!=0){a=rc();if(a-tc>2000){tc=a;uc=$wnd.setTimeout(Dc,10)}}if(sc++==0){Gc((Fc(),Ec));return true}return false}
function Oc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(vl==(b&wl)?0:524288)|(0==(b&6291456)?vl==(b&wl)?4194304:yl:0)|0|268435456|0)}
function fg(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Sg(a,b){var c,d;d=a.a.length;b.length<d&&(b=ci(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function ug(a,b){var c,d,e,f;f=a.W();b.length<f&&(b=ci(new Array(f),b));e=b;d=a.R();for(c=0;c<f;++c){e[c]=d.ab()}b.length>f&&(b[f]=null);return b}
function q(a,b){return dd(a)?o(a,b):cd(a)?a===b:bd(a)?ed(a)===ed(b):_c(a)?a.u(b):Uc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):ed(a)===ed(b)}
function hk(a){this.e=new Ok;this.c=a;J();++fk;this.b=new gc(new ik(this),new jk(this),false);this.a=new vb(null,new kk(this),1411518464)}
function $c(a,b){if(dd(a)){return !!Zc[b]}else if(a.ob){return !!a.ob[b]}else if(cd(a)){return !!Yc[b]}else if(bd(a)){return !!Xc[b]}return false}
function wi(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function S(a){a.j?gb(a.e):fb(a.e);if(tb(a.f)){if(a.j&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Pg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Pg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Pg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Tc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.B(),null)}finally{ac()}return f}catch(a){a=Bf(a);if(ad(a,4)){e=a;throw Cf(e)}else throw Cf(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.A()}else{_b(b,e);try{g=c.A()}finally{ac()}}return g}catch(a){a=Bf(a);if(ad(a,4)){f=a;throw Cf(f)}else throw Cf(a)}finally{D(b)}}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function Gf(b,c,d,e){Ff();var f=Df;$moduleName=c;$moduleBase=d;Af=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{tl(g)()}catch(a){b(c,a)}}else{tl(g)()}}
function W(a,b,c,d,e){this.c=a;this.g=b;this.h=c;this.i=d;this.k=null;this.j=16384==(e&16384);this.f=new wb(this,e&-16385);this.e=new ib(this.f);vl==(e&wl)&&lb(this.f)}
function qi(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function bh(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return dh()}}
function Jf(){If={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Kc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Jc(c,g)):g[0].qb()}catch(a){a=Bf(a);if(ad(a,4)){d=a;vc();Bc(ad(d,31)?d.J():d)}else throw Cf(a)}}return c}
function Q(b){var c,d,e;e=b.k;try{d=b.c.A();if(!(ed(e)===ed(d)||e!=null&&q(e,d))){b.k=d;b.b=null;db(b.e)}}catch(a){a=Bf(a);if(ad(a,8)){c=a;if(!b.b){b.k=null;b.b=c;db(b.e)}throw Cf(c)}else throw Cf(a)}}
function $h(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Ij(a){var b,c,d,e;c=Mk(a.e);if(0!=c&&null!=a.f){b=(Tf(),Sf);e=b.createRange();d=Nk(a.e);e.setStart(a.f.firstChild,d);e.setEnd(a.f.firstChild,d+c);return e.getBoundingClientRect()}else{return null}}
function ig(a){hg==null&&(hg=new RegExp('^\\s*[+-]?(NaN|Infinity|((\\d+\\.?\\d*)|(\\.\\d+))([eE][+-]?\\d+)?[dDfF]?)\\s*$'));if(!hg.test(a)){throw Cf(new ng('For input string: "'+a+'"'))}return parseFloat(a)}
function ki(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+og(a,c++)}b=b|0;return b}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Sc(Xd,ul,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{ek(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Bf(a);if(ad(a,4)){J()}else throw Cf(a)}}}
function ub(a,b,c,d){this.b=new Ng;this.f=new Jb(new yb(this),d&6520832|262144|vl);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&yl)&&D((null,I)))}
function Lf(a,b,c){var d=If,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=If[b]),Of(h));_.ob=c;!b&&(_.pb=Qf);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function eg(a){if(a.P()){var b=a.c;b.Q()?(a.j='['+b.i):!b.P()?(a.j='[L'+b.N()+';'):(a.j='['+b.N());a.b=b.M()+'[]';a.h=b.O()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=fg('.',[c,fg('$',d)]);a.b=fg('.',[c,fg('.',d)]);a.h=d[d.length-1]}
function vg(a,b){var c,d,e,f,g;e=b.b.value[0];g=jh(b);f=e==null?wg(Xg((d=a.a.a.get(0),d==null?new Array:d))):gh(a.b,e);if(!(ed(g)===ed(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!Xg((c=a.a.a.get(0),c==null?new Array:c)):fh(a.b,e))){return false}return true}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Pg(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Bf(a);if(!ad(a,4))throw Cf(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function nk(a,b){var c;c=b.type;if(!o(Nl,c)){U(a.e);U(a.b)}if((o('error',c)||o('end',c))&&(Tf(),$wnd.goog.global.window).speechSynthesis.paused){(Tf(),$wnd.goog.global.window).speechSynthesis.cancel()}else if(o(Nl,c)&&o(b.name,'word')){fc(new Xk(a,b.charIndex));fc(new Yk(a,b.charLength))}}
function si(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;oi(b,Nf(vi.prototype.jb,vi,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Cl]=c[0],undefined):(d[Cl]=c,undefined));return g=qi($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function jc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.H();return a&&a.F()}},suppressed:{get:function(){return c.G()}}})}catch(a){}}}
function ah(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);rb((e=a.a.i,e));c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.h,e));d.k=null}Hg(a.b,new Ab(a));a.b.a=Sc(Xd,ul,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Cj(){Cj=Mf;gj=new Dj(Dl,0);hj=new Dj('checkbox',1);ij=new Dj('color',2);jj=new Dj('date',3);kj=new Dj('datetime',4);lj=new Dj('email',5);mj=new Dj('file',6);nj=new Dj('hidden',7);oj=new Dj('image',8);pj=new Dj('month',9);qj=new Dj('number',10);rj=new Dj('password',11);sj=new Dj('radio',12);tj=new Dj('range',13);uj=new Dj('reset',14);vj=new Dj('search',15);wj=new Dj('submit',16);xj=new Dj('tel',17);yj=new Dj('text',18);zj=new Dj('time',19);Aj=new Dj('url',20);Bj=new Dj('week',21)}
function ok(a){var b,c;fc(new Xk(a,0));fc(new Yk(a,0));c=new $wnd.SpeechSynthesisUtterance((gb(a.f),a.n));c.voice=(gb(a.i),a.q);c.volume=(gb(a.k),a.r);c.pitch=(gb(a.c),a.l);b=(gb(a.d),a.m);c.rate=$wnd.Math.pow($wnd.Math.abs(b)+1,b<0?-1:1);c.addEventListener('start',new ml(a));c.addEventListener('end',new nl(a));c.addEventListener('error',new ol(a));c.addEventListener(Nl,new pl(a));c.addEventListener('pause',new ql(a));c.addEventListener('resume',new rl(a));(Tf(),$wnd.goog.global.window).speechSynthesis.speak(c)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Ig(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Mg(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Ig(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Kg(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Ng)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&vl!=(k.b.c&wl)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function Ok(){var a,b,c,d,e,f,g,h,i,j,k,l,m,n;this.t=new ll(this);J();++qk;this.s=new gc(null,new Pk(this),true);this.l=0.5;this.m=0;this.r=1;this.n='Call me Ishmael. Some years ago, never mind how long precisely, having little or no money in my purse, and nothing particular to interest me on shore, I thought I would sail about a little and see the watery part of the world.';this.h=(i=new ib((b=null,b)),i);this.g=(j=new ib((c=null,c)),j);this.c=(k=new ib((d=null,d)),k);this.d=(l=new ib((e=null,e)),l);this.k=(m=new ib((f=null,f)),m);this.i=(n=new ib((g=null,g)),n);this.f=(h=new ib((a=null,a)),h);this.e=new W(new Tk,null,null,null,35667968);this.b=new W(new Uk,null,null,null,35667968);this.j=new W(new Vk,new Qk(this),new Rk(this),new Sk,35651584);this.a=new vb(new Wk(this),null,413138944);D((null,I))}
function dh(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!ah()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function dk(a){var b,c,d,e,f;a.d=0;Gj();b=(c=Ek(a.e),si(El,wi(new $wnd.Object,Wc(Qc(Zd,1),ul,2,6,[S(a.e.e)?'speaking':null])),[si('h1',null,['Web Speech Synthesis Demo']),si('form',null,[si(El,xi(new $wnd.Object,'textarea'),[S(a.e.e)?pi([si(El,xi(zi(new $wnd.Object,Nf(Rj.prototype.C,Rj,[a])),'textbeingspoken'),[Dk(a.e)]),si(El,Ai(new $wnd.Object,(d=Ij(a),e=(Tf(),Sf).body,f=Mk(a.e),Hi(Mi(Ii(Ki(Li(Gi(Fi(Ji(new $wnd.Object)),0==f?'none':'block'),0==f?'all 0s ease 0s':'all 50ms ease'),null==d?'0':d.top-1+e.clientHeight-e.scrollHeight+8+'px'),null==d?'0':d.left-1+e.clientWidth-e.scrollWidth-8+'px'),null==d?'0':d.width+'px'),null==d?'0':d.height+'px'))),null)]):si('textarea',Qi(Ci(Ti(new $wnd.Object,Dk(a.e)),S(a.e.e)),Nf(Sj.prototype.kb,Sj,[a])),null)]),si(El,wi(new $wnd.Object,Wc(Qc(Zd,1),ul,2,6,[Fl])),[si(Gl,Ui(new $wnd.Object,'pitch'),['Pitch']),si('input',Qi(Ci(Ri(Oi(Pi(Ti(Ei(xi(new $wnd.Object,'pitch'),(Cj(),tj)),''+Bk(a.e)),'0'),'1'),'0.05'),S(a.e.e)),Nf(Xj.prototype.kb,Xj,[a])),null),si(Dl,Di(Ci(Bi(yi(Ei(new $wnd.Object,(dj(),aj)),Hl),Hl),S(a.e.e)),Nf(Yj.prototype.lb,Yj,[a])),[Il])]),si(El,wi(new $wnd.Object,Wc(Qc(Zd,1),ul,2,6,[Fl])),[si(Gl,Ui(new $wnd.Object,'rate'),['Rate']),si('input',Qi(Ci(Ri(Oi(Pi(Ti(Ei(xi(new $wnd.Object,'rate'),tj),''+Ck(a.e)),'-3'),'3'),'0.25'),S(a.e.e)),Nf(Zj.prototype.kb,Zj,[a])),null),si(Dl,Di(Ci(Bi(yi(Ei(new $wnd.Object,aj),Jl),Jl),S(a.e.e)),Nf($j.prototype.lb,$j,[a])),[Il])]),si(El,wi(new $wnd.Object,Wc(Qc(Zd,1),ul,2,6,[Fl])),[si(Gl,Ui(new $wnd.Object,'volume'),['Volume']),si('input',Qi(Ci(Ri(Oi(Pi(Ti(Ei(xi(new $wnd.Object,'volume'),tj),''+Fk(a.e)),'0'),'1'),'0.05'),S(a.e.e)),Nf(_j.prototype.kb,_j,[a])),null),si(Dl,Di(Ci(Bi(yi(Ei(new $wnd.Object,aj),Kl),Kl),S(a.e.e)),Nf(ak.prototype.lb,ak,[a])),[Il])]),si(El,wi(new $wnd.Object,Wc(Qc(Zd,1),ul,2,6,[Fl])),[si(Gl,Ui(new $wnd.Object,'voice'),['Voice']),si('select',Ti(Ci(Qi(new $wnd.Object,Nf(Pj.prototype.kb,Pj,[a])),S(a.e.e)),null==c?'':c.voiceURI),Lh(Jh(S(a.e.j).Y(),new Qj),new ui)),si(Dl,Di(Ci(Bi(yi(Ei(new $wnd.Object,aj),Ll),Ll),S(a.e.e)),Nf(Tj.prototype.lb,Tj,[a])),[Il])]),si(El,wi(new $wnd.Object,Wc(Qc(Zd,1),ul,2,6,['bottom'])),[si(Dl,Di(Ci(Bi(yi(wi(Ei(new $wnd.Object,aj),Wc(Qc(Zd,1),ul,2,6,['small'])),'Speak'),'Speak'),S(a.e.e)),Nf(Uj.prototype.lb,Uj,[a])),['Speak']),si(Dl,Di(Ci(Bi(yi(wi(Ei(new $wnd.Object,aj),Wc(Qc(Zd,1),ul,2,6,['small'])),S(a.e.b)?Ml:'Pause'),S(a.e.b)?Ml:'Pause'),!S(a.e.e)),Nf(Vj.prototype.lb,Vj,[a])),[S(a.e.b)?Ml:'Pause']),si(Dl,Di(Ci(Bi(yi(wi(Ei(new $wnd.Object,aj),Wc(Qc(Zd,1),ul,2,6,['small'])),'Stop'),'Stop'),!S(a.e.e)),Nf(Wj.prototype.lb,Wj,[])),['Stop'])])])]));return b}
var ul={3:1},vl=1048576,wl=1835008,xl={10:1},yl=2097152,zl='__noinit__',Al={3:1,8:1,6:1,4:1},Bl={3:1,35:1,60:1},Cl='children',Dl='button',El='div',Fl='speecharg',Gl='label',Hl='Reset pitch',Il='\u21B6',Jl='Reset rate',Kl='Reset volume',Ll='Reset voice',Ml='Resume',Nl='boundary',Ol='voiceschanged',Pl=142606336;var _,If,Df,Af=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Jf();Lf(1,null,{},p);_.u=function(a){return o(this,a)};_.v=function(){return this.nb};_.w=Ql;_.equals=function(a){return this.u(a)};_.hashCode=function(){return this.w()};var Xc,Yc,Zc;Lf(44,1,{},Zf);_.L=function(a){var b;b=new Zf;b.e=4;a>1?(b.c=cg(this,a-1)):(b.c=this);return b};_.M=function(){Xf(this);return this.b};_.N=function(){return Yf(this)};_.O=function(){Xf(this);return this.h};_.P=function(){return (this.e&4)!=0};_.Q=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Wf=1;var Xd=_f(1);var Md=_f(44);Lf(99,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var kd=_f(99);Lf(37,1,{},G);_.A=function(){return this.a.B(),null};var hd=_f(37);Lf(100,1,{},H);var jd=_f(100);var I;Lf(41,1,{41:1},P);_.b=0;_.c=false;_.d=0;var ld=_f(41);Lf(162,1,{});var od=_f(162);Lf(39,162,{},W);_.a=false;_.d=0;_.j=false;var nd=_f(39);Lf(109,1,{},X);_.A=function(){return T(this.a)};var md=_f(109);Lf(13,162,{13:1},ib);_.a=4;_.d=false;_.e=0;var qd=_f(13);Lf(108,1,xl,jb);_.B=function(){ab(this.a)};var pd=_f(108);Lf(20,162,{20:1},vb,wb);_.c=0;var vd=_f(20);Lf(102,1,{},xb);_.B=function(){Q(this.a)};var rd=_f(102);Lf(103,1,xl,yb);_.B=function(){mb(this.a)};var sd=_f(103);Lf(104,1,xl,zb);_.B=function(){pb(this.a)};var td=_f(104);Lf(105,1,{},Ab);_.C=function(a){nb(this.a,a)};var ud=_f(105);Lf(139,1,{},Db);_.a=0;_.b=0;_.c=0;var wd=_f(139);Lf(119,1,{},Fb);_.a=false;var xd=_f(119);Lf(54,162,{54:1},Jb);_.a=0;var zd=_f(54);Lf(138,1,{},Ob);var yd=_f(138);Lf(122,1,{},$b);_.a=0;var Pb;var Ad=_f(122);Lf(50,1,{},gc);_.g=0;var Cd=_f(50);Lf(101,1,xl,hc);_.B=function(){ec(this.a)};var Bd=_f(101);Lf(4,1,{3:1,4:1});_.D=function(a){return new Error(a)};_.F=Rl;_.G=function(){return Lh(Jh(Rg((this.e==null&&(this.e=Sc(_d,ul,4,0,0,1)),this.e)),new qg),new Ph)};_.H=function(){return this.c};_.I=function(){kc(this,mc(this.D(lc(this,this.d))));Nc(this)};_.b=zl;_.f=true;var _d=_f(4);Lf(8,4,{3:1,8:1,4:1});var Pd=_f(8);Lf(6,8,Al);var Yd=_f(6);Lf(46,6,Al);var Td=_f(46);Lf(71,46,Al);var Gd=_f(71);Lf(31,71,{31:1,3:1,8:1,6:1,4:1},qc);_.J=function(){return ed(this.a)===ed(oc)?null:this.a};var oc;var Dd=_f(31);var Ed=_f(0);Lf(145,1,{});var Fd=_f(145);var sc=0,tc=0,uc=-1;Lf(79,145,{},Ic);var Ec;var Hd=_f(79);var Lc;Lf(157,1,{});var Jd=_f(157);Lf(72,157,{},Pc);var Id=_f(72);var Sf;Lf(74,6,Al);var Sd=_f(74);Lf(106,74,Al,Uf);var Kd=_f(106);Xc={3:1,67:1,30:1};var Ld=_f(67);Lf(155,1,ul);var hg;var Wd=_f(155);Yc={3:1,30:1};var Nd=_f(156);Lf(22,1,{3:1,30:1,22:1});_.u=function(a){return this===a};_.w=Ql;_.b=0;var Od=_f(22);Lf(45,6,Al);var Qd=_f(45);Lf(73,6,Al,lg);var Rd=_f(73);Lf(222,1,{});Lf(75,46,Al,mg);_.D=function(a){return new TypeError(a)};var Ud=_f(75);Lf(68,45,Al,ng);var Vd=_f(68);Zc={3:1,66:1,30:1,2:1};var Zd=_f(2);Lf(226,1,{});Lf(63,1,{},qg);_.S=function(a){return a.b};var $d=_f(63);Lf(36,6,Al,rg);var ae=_f(36);Lf(158,1,{35:1});_.X=function(){return new Ah(this,0)};_.Y=function(){return new Mh(null,this.X())};_.T=function(a){throw Cf(new rg('Add not supported on this collection'))};_.U=function(a){return sg(this,a)};_.V=function(){return this.W()==0};_.Z=function(a){return ug(this,a)};var be=_f(158);Lf(161,1,{142:1});_.u=function(a){var b,c,d;if(a===this){return true}if(!ad(a,38)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Cg((new zg(d)).a);c.b;){b=Bg(c);if(!vg(this,b)){return false}}return true};_.w=function(){return Ug(new zg(this))};var ie=_f(161);Lf(107,161,{142:1});var ee=_f(107);Lf(160,158,{35:1,167:1});_.X=function(){return new Ah(this,1)};_.u=function(a){var b;if(a===this){return true}if(!ad(a,21)){return false}b=a;if(xg(b.a)!=this.W()){return false}return tg(this,b)};_.w=function(){return Ug(this)};var je=_f(160);Lf(21,160,{21:1,35:1,167:1},zg);_.U=function(a){return yg(this,a)};_.R=function(){return new Cg(this.a)};_.W=function(){return xg(this.a)};var de=_f(21);Lf(24,1,{},Cg);_.$=Sl;_.ab=function(){return Bg(this)};_._=Rl;_.b=false;var ce=_f(24);Lf(159,158,{35:1,60:1});_.X=function(){return new Ah(this,16)};_.bb=function(a,b){throw Cf(new rg('Add not supported on this list'))};_.T=function(a){this.bb(this.W(),a);return true};_.u=function(a){var b,c,d,e,f;if(a===this){return true}if(!ad(a,60)){return false}f=a;if(this.W()!=f.W()){return false}e=f.R();for(c=this.R();c._();){b=c.ab();d=e.ab();if(!(ed(b)===ed(d)||b!=null&&q(b,d))){return false}}return true};_.w=function(){return Vg(this)};_.R=function(){return new Eg(this)};_.db=function(a){throw Cf(new rg('Remove not supported on this list'))};var ge=_f(159);Lf(78,1,{},Eg);_.$=Sl;_._=function(){return this.a<this.b.W()};_.ab=function(){return this.a<this.b.W(),this.b.cb(this.a++)};_.a=0;var fe=_f(78);Lf(163,1,{168:1});_.u=function(a){var b;if(!ad(a,32)){return false}b=a;return mh(this.b.value[0],b.b.value[0])&&mh(jh(this),jh(b))};_.w=function(){return nh(this.b.value[0])^nh(jh(this))};var he=_f(163);Lf(12,159,Bl,Ng,Og);_.bb=function(a,b){_h(this.a,a,b)};_.T=function(a){return Gg(this,a)};_.U=function(a){return Jg(this,a,0)!=-1};_.cb=function(a){return Ig(this,a)};_.V=function(){return this.a.length==0};_.R=function(){return new Pg(this)};_.db=function(a){return Kg(this,a)};_.W=Tl;_.Z=function(a){var b,c;c=this.a.length;a.length<c&&(a=ci(new Array(c),a));for(b=0;b<c;++b){a[b]=this.a[b]}a.length>c&&(a[c]=null);return a};var le=_f(12);Lf(15,1,{},Pg);_.$=Sl;_._=function(){return this.a<this.c.a.length};_.ab=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ke=_f(15);Lf(77,159,Bl,Tg);_.U=function(a){return Dg(this,a)!=-1};_.cb=function(a){return this.a[a]};_.W=Tl;_.Z=function(a){return Sg(this,a)};var me=_f(77);Lf(38,107,{3:1,38:1,142:1},Wg);var ne=_f(38);Lf(121,1,{},Yg);_.R=function(){return new Zg(this)};_.b=0;var pe=_f(121);Lf(53,1,{},Zg);_.$=Sl;_.ab=function(){return this.d=this.a[this.c++],this.d};_._=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var oe=_f(53);var $g;Lf(120,1,{},hh);_.R=function(){return new ih(this)};_.b=0;_.c=0;var se=_f(120);Lf(52,1,{},ih);_.$=Sl;_.ab=function(){return this.c=this.a,this.a=this.b.next(),new kh(this.d,this.c,this.d.c)};_._=function(){return !this.a.done};var qe=_f(52);Lf(32,163,{32:1,168:1},kh);_.c=0;var re=_f(32);Lf(33,1,{33:1},rh);_.u=function(a){var b;if(a===this){return true}if(!ad(a,33)){return false}b=a;return mh(this.a,b.a)};_.w=function(){return nh(this.a)};var oh;var te=_f(33);Lf(85,1,{});_.$=Ul;_.eb=function(){return this.d};_.fb=function(){return this.e};_.d=0;_.e=0;var xe=_f(85);Lf(48,85,{});var ue=_f(48);Lf(80,1,{});_.$=Ul;_.eb=Rl;_.fb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var we=_f(80);Lf(81,80,{},yh);_.$=function(a){vh(this,a)};_.gb=function(a){return wh(this,a)};var ve=_f(81);Lf(19,1,{},Ah);_.eb=function(){return this.a};_.fb=function(){zh(this);return this.c};_.$=function(a){zh(this);this.d.$(a)};_.gb=function(a){zh(this);if(this.d._()){a.C(this.d.ab());return true}return false};_.a=0;_.c=0;var ye=_f(19);Lf(65,1,{},Bh);_.S=function(a){return a};var ze=_f(65);Lf(140,1,{},Ch);var Ae=_f(140);Lf(84,1,{});_.c=false;var Je=_f(84);Lf(23,84,{},Mh);var Ie=_f(23);Lf(64,1,{},Ph);_.hb=function(a){return Sc(Xd,ul,1,a,5,1)};var Be=_f(64);Lf(87,48,{},Rh);_.gb=function(a){this.b=false;while(!this.b&&this.c.gb(new Sh(this,a)));return this.b};_.b=false;var De=_f(87);Lf(89,1,{},Sh);_.C=function(a){Qh(this.a,this.b,a)};var Ce=_f(89);Lf(86,48,{},Uh);_.gb=function(a){return this.b.gb(new Vh(this,a))};var Fe=_f(86);Lf(88,1,{},Vh);_.C=function(a){Th(this.a,this.b,a)};var Ee=_f(88);Lf(49,1,{},Xh);_.C=function(a){Wh(this,a)};var Ge=_f(49);Lf(90,1,{},Zh);_.C=function(a){Yh(this,a)};var He=_f(90);Lf(224,1,{});Lf(221,1,{});var ei=0;var gi,hi=0,ii;Lf(827,1,{});Lf(852,1,{});Lf(118,1,{},ui);_.hb=function(a){return new Array(a)};var Ke=_f(118);Lf(205,$wnd.Function,{},vi);_.jb=function(a){ti(this.a,this.b,a)};Lf(25,22,{3:1,30:1,22:1,25:1},ej);var aj,bj,cj;var Le=ag(25,fj);Lf(5,22,{3:1,30:1,22:1,5:1},Dj);var gj,hj,ij,jj,kj,lj,mj,nj,oj,pj,qj,rj,sj,tj,uj,vj,wj,xj,yj,zj,Aj,Bj;var Me=ag(5,Ej);var Fj;Lf(206,$wnd.Function,{},Hj);_.K=function(a){return Eb(Fj),Fj=null,null};Lf(92,1,{});var Pe=_f(92);Lf(195,$wnd.Function,{},Pj);_.kb=function(a){Oj(this.a,a)};Lf(83,1,{},Qj);_.S=function(a){return si('option',Ti(new $wnd.Object,a.voiceURI),[a.name+' ('+a.lang+')'])};var Ne=_f(83);Lf(185,$wnd.Function,{},Rj);_.C=function(a){Jj(this.a,a)};Lf(187,$wnd.Function,{},Sj);_.kb=function(a){Kj(this.a,a)};Lf(196,$wnd.Function,{},Tj);_.lb=function(a){Jk(this.a.e)};Lf(197,$wnd.Function,{},Uj);_.lb=function(a){ok(this.a.e)};Lf(198,$wnd.Function,{},Vj);_.lb=function(a){S(this.a.e.b)?(Tf(),$wnd.goog.global.window).speechSynthesis.resume():(Tf(),$wnd.goog.global.window).speechSynthesis.pause()};Lf(199,$wnd.Function,{},Wj);_.lb=function(a){(Tf(),$wnd.goog.global.window).speechSynthesis.cancel()};Lf(188,$wnd.Function,{},Xj);_.kb=function(a){Lj(this.a,a)};Lf(189,$wnd.Function,{},Yj);_.lb=function(a){fc(new Zk(this.a.e,0.5))};Lf(190,$wnd.Function,{},Zj);_.kb=function(a){Mj(this.a,a)};Lf(191,$wnd.Function,{},$j);_.lb=function(a){fc(new $k(this.a.e,0))};Lf(192,$wnd.Function,{},_j);_.kb=function(a){Nj(this.a,a)};Lf(193,$wnd.Function,{},ak);_.lb=function(a){fc(new _k(this.a.e,1))};Lf(62,1,{},bk);var Oe=_f(62);Lf(93,92,{});_.d=0;var pf=_f(93);Lf(94,93,{},hk);var fk=0;var Ue=_f(94);Lf(95,1,xl,ik);_.B=function(){Y(this.a.e)};var Qe=_f(95);Lf(96,1,xl,jk);_.B=function(){kb(this.a.a)};var Re=_f(96);Lf(97,1,{},kk);_.B=function(){ek(this.a)};var Se=_f(97);Lf(98,1,{},lk);_.A=function(){return dk(this.a)};var Te=_f(98);Lf(123,1,{});var zf=_f(123);Lf(124,123,{},Ok);_.l=0;_.m=0;_.o=0;_.p=0;_.r=0;var qk=0;var nf=_f(124);Lf(125,1,xl,Pk);_.B=function(){rk(this.a)};var Ve=_f(125);Lf(129,1,{},Qk);_.B=function(){sk(this.a)};var We=_f(129);Lf(130,1,{},Rk);_.B=function(){tk(this.a)};var Xe=_f(130);Lf(131,1,{},Sk);_.B=function(){};var Ye=_f(131);Lf(126,1,{},Tk);_.A=function(){return Vf(),(Tf(),$wnd.goog.global.window).speechSynthesis.speaking?true:false};var Ze=_f(126);Lf(127,1,{},Uk);_.A=function(){return Vf(),(Tf(),$wnd.goog.global.window).speechSynthesis.paused?true:false};var $e=_f(127);Lf(128,1,{},Vk);_.A=function(){var a;return a=(Tf(),$wnd.goog.global.window).speechSynthesis.getVoices(),new Tg(ci(a,Vc(a.length)))};var _e=_f(128);Lf(132,1,{},Wk);_.B=function(){mk(this.a)};var af=_f(132);Lf(55,1,xl,Xk);_.B=function(){yk(this.a,this.b)};_.b=0;var bf=_f(55);Lf(56,1,xl,Yk);_.B=function(){xk(this.a,this.b)};_.b=0;var cf=_f(56);Lf(57,1,xl,Zk);_.B=function(){uk(this.a,this.b)};_.b=0;var df=_f(57);Lf(58,1,xl,$k);_.B=function(){vk(this.a,this.b)};_.b=0;var ef=_f(58);Lf(59,1,xl,_k);_.B=function(){Ak(this.a,this.b)};_.b=0;var ff=_f(59);Lf(40,1,xl,al);_.B=function(){zk(this.a,this.b)};var gf=_f(40);Lf(133,1,xl,bl);_.B=function(){wk(this.a,this.b)};var hf=_f(133);Lf(134,1,xl,cl);_.B=function(){U(this.a)};var jf=_f(134);Lf(135,1,xl,dl);_.B=function(){nk(this.a,this.b)};var kf=_f(135);Lf(136,1,xl,el);_.B=function(){Gk(this.a)};var lf=_f(136);Lf(137,1,xl,fl);_.B=function(){Hk(this.a,this.b)};var mf=_f(137);Lf(200,$wnd.Function,{},gl);_.mb=function(a){return new jl(a)};var hl;Lf(82,$wnd.React.Component,{},jl);Kf(If[1],_);_.componentDidMount=function(){(Tf(),$wnd.goog.global.window).speechSynthesis.cancel()};_.componentWillUnmount=function(){ck(this.a)};_.render=function(){return gk(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var of=_f(82);Lf(51,1,{},kl);_.ib=function(a){return a.default};var qf=_f(51);Lf(110,1,{},ll);_.handleEvent=function(a){Lk(this.a.j)};var rf=_f(110);Lf(111,1,{},ml);_.handleEvent=Vl;var sf=_f(111);Lf(112,1,{},nl);_.handleEvent=Vl;var tf=_f(112);Lf(113,1,{},ol);_.handleEvent=Vl;var uf=_f(113);Lf(114,1,{},pl);_.handleEvent=Vl;var vf=_f(114);Lf(115,1,{},ql);_.handleEvent=Vl;var wf=_f(115);Lf(116,1,{},rl);_.handleEvent=Vl;var xf=_f(116);Lf(117,1,{},sl);_.ib=function(a){return pk(this.a,a)};var yf=_f(117);var gd=bg('D');var tl=(vc(),yc);var gwtOnLoad=gwtOnLoad=Gf;Ef(Rf);Hf('permProps',[[]]);if (webspeechdemo) webspeechdemo.onScriptLoad(gwtOnLoad);})();