function webspeechdemo(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='webspeechdemo',tb='__gwt_marker_webspeechdemo',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='4A2F4C7FA30BCB4098479121DC85156B',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};webspeechdemo.onScriptLoad=function(a){webspeechdemo=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
webspeechdemo();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = '4A2F4C7FA30BCB4098479121DC85156B';function p(){}
function Kf(){}
function Gf(){}
function Gb(){}
function Jc(){}
function Qc(){}
function Qj(){}
function Bj(){}
function Kj(){}
function kg(){}
function vh(){}
function Jh(){}
function Rh(){}
function oi(){}
function Mk(){}
function Nk(){}
function Ok(){}
function _k(){}
function jl(){}
function Oc(a){Nc()}
function Pf(){Pf=Gf}
function rb(a,b){a.b=b}
function Qh(a,b){a.a=b}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function ic(a){this.a=a}
function tg(a){this.a=a}
function Ng(a){this.a=a}
function Nj(a){this.a=a}
function Jj(a){this.a=a}
function Lj(a){this.a=a}
function Mj(a){this.a=a}
function Oj(a){this.a=a}
function Pj(a){this.a=a}
function Rj(a){this.a=a}
function Sj(a){this.a=a}
function Tj(a){this.a=a}
function Th(a){this.a=a}
function wh(a){this.a=a}
function Uj(a){this.a=a}
function Vj(a){this.a=a}
function Wj(a){this.a=a}
function ck(a){this.a=a}
function dk(a){this.a=a}
function ek(a){this.a=a}
function fk(a){this.a=a}
function Jk(a){this.a=a}
function Kk(a){this.a=a}
function Lk(a){this.a=a}
function Pk(a){this.a=a}
function Xk(a){this.a=a}
function Zk(a){this.a=a}
function dl(a){this.a=a}
function el(a){this.a=a}
function fl(a){this.a=a}
function gl(a){this.a=a}
function hl(a){this.a=a}
function il(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function yg(a){this.b=a}
function Jg(a){this.c=a}
function Sg(){this.a=Zg()}
function ah(){this.a=Zg()}
function Hg(){zg(this)}
function Ll(a){fh(this,a)}
function Nl(a){mh(this,a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function w(a){--a.e;D(a)}
function Z(a){!!a&&cc(a.s)}
function dc(a){!!a&&a.A()}
function ii(a,b){hi(a,b)}
function Sh(a,b){Ih(a.a,b)}
function C(a,b){Ob(a.f,b.f)}
function L(a,b){P(a);M(a,b)}
function Ol(a){Ck(this.a,a)}
function lh(a){jh();this.a=a}
function wf(a){return a.b}
function Dj(a,b){return a.f=b}
function Kl(){return this.b}
function Jl(){return _h(this)}
function Cg(a,b){return a.a[b]}
function lc(a,b){a.b=b;kc(a,b)}
function Yj(a){a.d=2;cc(a.b)}
function Xh(a,b){a.splice(b,1)}
function rh(a,b,c){b.C(a.a[c])}
function Of(a){oc.call(this,a)}
function hg(a){oc.call(this,a)}
function lg(a){oc.call(this,a)}
function gg(){jc(this);this.I()}
function Vg(){Vg=Gf;Ug=Xg()}
function K(){K=Gf;J=new F}
function qc(){qc=Gf;pc=new p}
function Gc(){Gc=Gf;Fc=new Jc}
function wc(){wc=Gf;!!(Nc(),Mc)}
function zf(){xf==null&&(xf=[])}
function Sf(a){Rf(a);return a.j}
function Hh(a,b){a.W(b);return a}
function ri(a,b){a.id=b;return a}
function U(a){nb(a.f);return W(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function bb(a){K();Zb(a);a.e=-2}
function Zg(){Vg();return new Ug}
function Rc(a,b){return Yf(a,b)}
function Ih(a,b){Qh(a,Hh(a.a,b))}
function mh(a,b){while(a.jb(b));}
function Nh(a,b,c){b.C(a.a.V(c))}
function v(a,b,c){t(a,new I(c),b)}
function Ii(a,b){a.max=b;return a}
function Ji(a,b){a.min=b;return a}
function ti(a,b){a.ref=b;return a}
function Ei(a,b){a.top=b;return a}
function vk(a){hb(a.c);return a.l}
function wk(a){hb(a.d);return a.m}
function xk(a){hb(a.f);return a.n}
function yk(a){hb(a.i);return a.q}
function zk(a){hb(a.k);return a.r}
function Gk(a){hb(a.g);return a.o}
function Hk(a){hb(a.h);return a.p}
function Ci(a,b){a.left=b;return a}
function Li(a,b){a.step=b;return a}
function pi(a,b){this.a=a;this.b=b}
function dg(a,b){this.a=a;this.b=b}
function Mh(a,b){this.a=a;this.b=b}
function Ph(a,b){this.a=a;this.b=b}
function Qk(a,b){this.a=a;this.b=b}
function Rk(a,b){this.a=a;this.b=b}
function Sk(a,b){this.a=a;this.b=b}
function Tk(a,b){this.a=a;this.b=b}
function Uk(a,b){this.a=a;this.b=b}
function Vk(a,b){this.a=a;this.b=b}
function Wk(a,b){this.a=a;this.b=b}
function Yk(a,b){this.a=a;this.b=b}
function $k(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function Xj(){this.a=li((bl(),al))}
function xj(a,b){dg.call(this,a,b)}
function $i(a,b){dg.call(this,a,b)}
function Vh(a,b,c){a.splice(b,0,c)}
function ui(a,b){a.style=b;return a}
function vi(a,b){a.title=b;return a}
function Gi(a,b){a.width=b;return a}
function Ni(a,b){a.value=b;return a}
function _g(a,b){return a.a.get(b)}
function rg(a){return a.a.b+a.b.b}
function Ub(a){return !a.d?a:Ub(a.d)}
function qg(a){return !a?null:dh(a)}
function hh(a){return a!=null?s(a):0}
function ed(a){return a==null?null:a}
function Ml(){return this.a.length}
function o(a,b){return ed(a)===ed(b)}
function Dc(a){$wnd.clearTimeout(a)}
function zg(a){a.a=Tc(Yd,ol,1,0,5,1)}
function qb(a){K();pb(a);tb(a,2,true)}
function Wh(a,b){Uh(b,0,a,0,b.length)}
function Ai(a,b){a.display=b;return a}
function Bi(a,b){a.height=b;return a}
function Oi(a,b){a.htmlFor=b;return a}
function xi(a,b){a.onClick=b;return a}
function Ki(a,b){a.onChange=b;return a}
function wi(a,b){a.disabled=b;return a}
function hi(a,b){for(var c in a){b(c)}}
function ig(a,b){return a.charCodeAt(b)}
function B(a,b,c){return u(a,c,2048,b)}
function A(a,b,c){u(a,new H(b),c,null)}
function jh(){jh=Gf;ih=new lh(null)}
function di(){di=Gf;ai=new p;ci=new p}
function jb(a){this.c=new Hg;this.b=a}
function Ec(){tc!=0&&(tc=0);vc=-1}
function $(a){return !(!!a&&1==(a.c&7))}
function _h(a){return a.$H||(a.$H=++$h)}
function kh(a){return a.a!=null?a.a:null}
function ad(a,b){return a!=null&&$c(a,b)}
function jk(a,b){return o(b.voiceURI,a)}
function Ij(a,b){Ek(a.e,b.target.value)}
function Fi(a,b){a.transition=b;return a}
function Gh(a,b){zh.call(this,a);this.a=b}
function oc(a){this.d=a;jc(this);this.I()}
function Qg(){this.a=new Sg;this.b=new ah}
function Q(){this.a=Tc(Yd,ol,1,100,5,1)}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function Dk(a){A((K(),K(),J),new Zk(a),Il)}
function Fk(a){A((K(),K(),J),new Xk(a),Il)}
function Rf(a){if(a.j!=null){return}$f(a)}
function jc(a){a.f&&a.b!==sl&&a.I();return a}
function Di(a){a.position='fixed';return a}
function si(a,b){a['aria-label']=b;return a}
function Vf(a){var b;b=Uf(a);ag(a,b);return b}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function xc(a,b,c){return a.apply(b,c);var d}
function dd(a){return typeof a==='string'}
function cd(a){return typeof a==='number'}
function bd(a){return typeof a==='boolean'}
function Db(a){while(true){if(!Cb(a)){break}}}
function fh(a,b){while(a.cb()){Sh(b,a.db())}}
function ph(a,b){while(a.c<a.d){rh(a,b,a.c++)}}
function eh(a,b,c){this.a=a;this.b=b;this.c=c}
function Ag(a,b){a.a[a.a.length]=b;return true}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Ek(a,b){A((K(),K(),J),new $k(a,b),Il)}
function gc(a){K();Qb?a.A():A((null,J),a,0)}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function th(a){if(!a.d){a.d=a.b.U();a.c=a.b.Z()}}
function Kh(a,b,c){if(a.a.L(c)){a.b=true;b.C(c)}}
function Ej(a,b){gc(new Wk(a.e,b.target.value))}
function $g(a,b){return !(a.a.get(b)===undefined)}
function Lg(a){return new Gh(null,Kg(a,a.length))}
function Kg(a,b){return nh(b,a.length),new sh(a,b)}
function Ah(a,b){var c;return Eh(a,(c=new Hg,c))}
function Eg(a,b){var c;c=a.a[b];Xh(a.a,b);return c}
function vg(a){var b;b=a.a.db();a.b=ug(a);return b}
function Xf(a){var b;b=Uf(a);b.i=a;b.e=1;return b}
function Gg(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Kc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Vc(a){return Array.isArray(a)&&a.rb===Kf}
function _c(a){return !Array.isArray(a)&&a.rb===Kf}
function ak(a){return B((K(),K(),J),a.a,new ek(a))}
function Nc(){Nc=Gf;var a;!Pc();a=new Qc;Mc=a}
function Nf(){Nf=Gf;Mf=$wnd.goog.global.document}
function $j(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function xh(a){if(!a.b){yh(a);a.c=true}else{xh(a.b)}}
function gi(){if(bi==256){ai=ci;ci=new p;bi=0}++bi}
function Zh(a){if(a==null){throw wf(new gg)}return a}
function zi(a){a.border='1px solid orange';return a}
function Fj(a,b){gc(new Sk(a.e,eg(b.target.value)))}
function Gj(a,b){gc(new Tk(a.e,eg(b.target.value)))}
function Hj(a,b){gc(new Uk(a.e,eg(b.target.value)))}
function Ck(a,b){A((K(),K(),J),new Yk(a,b),75497472)}
function Bh(a,b){yh(a);return new Gh(a,new Lh(b,a.a))}
function Dh(a,b){yh(a);return new Gh(a,new Oh(b,a.a))}
function qk(a,b){var c;c=a.n;if(b!=c){a.n=b;fb(a.f)}}
function ok(a,b){var c;c=a.l;if(b!=c){a.l=b;fb(a.c)}}
function pk(a,b){var c;c=a.m;if(b!=c){a.m=b;fb(a.d)}}
function rk(a,b){var c;c=a.o;if(b!=c){a.o=b;fb(a.g)}}
function sk(a,b){var c;c=a.p;if(b!=c){a.p=b;fb(a.h)}}
function uk(a,b){var c;c=a.r;if(b!=c){a.r=b;fb(a.k)}}
function Wf(a,b){var c;c=Uf(a);ag(a,c);c.e=b?8:0;return c}
function yi(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function oh(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function uh(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function sh(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function zh(a){if(!a){this.b=null;new Hg}else{this.b=a}}
function Zf(a){if(a.T()){return null}var b=a.i;return Cf[b]}
function sg(a,b){if(ad(b,33)){return pg(a.a,b)}return false}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function If(a){function b(){}
;b.prototype=a||{};return new b}
function Cc(a){wc();$wnd.setTimeout(function(){throw a},0)}
function Ak(a){gc(new Vk(a,kh(Ch(Bh(T(a.j)._(),new jl)))))}
function mb(a){C((K(),K(),J),a);0==(a.f.a&rl)&&D((null,J))}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function gh(a,b){return ed(a)===ed(b)||a!=null&&q(a,b)}
function _i(){Zi();return Wc(Rc(Me,1),ol,26,0,[Wi,Xi,Yi])}
function Ig(a){zg(this);Wh(this.a,og(a,Tc(Yd,ol,1,rg(a.a),5,1)))}
function fc(a){dc(a.f);!!a.d&&ec(a);Z(a.a);Z(a.c);dc(a.b);dc(a.e)}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function yh(a){if(a.b){yh(a.b)}else if(a.c){throw wf(new fg)}}
function Bk(a,b){gc(new Vk(a,kh(Ch(Bh(T(a.j)._(),new ll(b))))))}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function Tg(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Oh(a,b){oh.call(this,b.ib(),b.hb()&-6);this.a=a;this.b=b}
function mc(a,b){var c;c=Sf(a.pb);return b==null?c:c+': '+b}
function Yf(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.O(b))}
function Ef(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function ni(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Ac(a,b,c){var d;d=yc();try{return xc(a,b,c)}finally{Bc(d)}}
function bl(){bl=Gf;var a;al=(a=Hf(_k.prototype.ob,_k,[]),a)}
function mk(a){$wnd[xl].speechSynthesis.addEventListener(Hl,a.t)}
function nk(a){$wnd[xl].speechSynthesis.removeEventListener(Hl,a.t)}
function cl(a){$wnd.React.Component.call(this,a);this.a=new bk(this)}
function bh(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Lh(a,b){oh.call(this,b.ib(),b.hb()&-16449);this.a=a;this.c=b}
function cb(a,b){var c,d;Ag(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Fh(a,b){var c;c=Ah(a,new wh(new vh));return c.ab(b.kb(c.Z()))}
function Eh(a,b){var c;xh(a);c=new Rh;c.a=b;a.a.bb(new Th(c));return c.a}
function qh(a,b){if(a.c<a.d){rh(a,b,a.c++);return true}return false}
function sc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function zc(b){wc();return function(){return Ac(b,this,arguments);var a}}
function nc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function ab(a){if(-2!=a.e){A((K(),K(),J),new kb(a),0);!!a.b&&lb(a.b)}}
function Jb(b){try{nb(b.b.a)}catch(a){a=vf(a);if(!ad(a,4))throw wf(a)}}
function Bc(a){a&&Ic((Gc(),Fc));--tc;if(a){if(vc!=-1){Dc(vc);vc=-1}}}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Dg(a,b,c){for(;c<a.a.length;++c){if(gh(b,a.a[c])){return c}}return -1}
function dh(a){if(a.a.c!=a.c){return _g(a.a,a.b.value[0])}return a.b.value[1]}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function S(a){if(!a.a){a.a=true;a.j=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function W(a){if(a.b){if(ad(a.b,7)){throw wf(a.b)}else{throw wf(a.b)}}return a.j}
function Fg(a,b){var c;c=Dg(a,b,0);if(c==-1){return false}Xh(a.a,c);return true}
function Tc(a,b,c,d,e,f){var g;g=Uc(e,d);e!=10&&Wc(Rc(a,f),b,c,e,g);return g}
function Bg(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.C(c)}}
function tk(a,b){var c;c=a.q;if(!(ed(b)===ed(c)||b!=null&&q(b,c))){a.q=b;fb(a.i)}}
function wg(a){this.d=a;this.c=new bh(this.d.b);this.a=this.c;this.b=ug(this)}
function Pb(){var a;this.a=Tc(md,ol,39,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function Hc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Lc(b,c)}while(a.a);a.a=c}}
function Ic(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Lc(b,c)}while(a.b);a.b=c}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function sb(b){if(b){try{b.A()}catch(a){a=vf(a);if(ad(a,4)){K()}else throw wf(a)}}}
function cc(a){if(a.g>=0){a.g=-2;u((K(),K(),J),new H(new ic(a)),67108864,null)}}
function fd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Yh(a,b){return Sc(b)!=10&&Wc(r(b),b.qb,b.__elementTypeId$,Sc(b),a),a}
function Sc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Lf(){$wnd.ReactDOM.render((new Xj).a,(Nf(),Mf).getElementById('app'),null)}
function Zi(){Zi=Gf;Wi=new $i(wl,0);Xi=new $i('reset',1);Yi=new $i('submit',2)}
function Uf(a){var b;b=new Tf;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function li(a){var b;b=ki($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function ag(a,b){var c;if(!a){return}b.i=a;var d=Zf(b);if(!d){Cf[a]=[b];return}d.pb=b}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Hg);Ag(a.b,b)}}}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Hg);a.c=c.c}b.d=true;a.c.W(b)}
function pb(a){var b,c;for(c=new Jg(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function ng(a,b){var c,d;for(d=new wg(b.a);d.b;){c=vg(d);if(!sg(a,c)){return false}}return true}
function xg(a,b){var c,d;for(c=0,d=a.a.length;c<d;++c){if(gh(b,a.a[c])){return c}}return -1}
function Pg(a){var b,c,d;d=1;for(c=a.U();c.cb();){b=c.db();d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Hf(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function vf(a){var b;if(ad(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new rc(a);Oc(b)}return b}
function ug(a){if(a.a.cb()){return true}if(a.a!=a.c){return false}a.a=new Tg(a.d.a);return a.a.cb()}
function Ch(a){var b;xh(a);b=new Rh;if(a.a.jb(b)){return jh(),new lh(Zh(b.a))}return jh(),jh(),ih}
function yf(){zf();var a=xf;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function fg(){oc.call(this,"Stream already terminated, can't be modified or used")}
function rc(a){qc();jc(this);this.b=a;kc(this,a);this.d=a==null?'null':Jf(a);this.a=a}
function hc(a,b,c){this.d=c?new Qg:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function Tf(){this.g=Qf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function Rg(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function Wc(a,b,c,d,e){e.pb=a;e.qb=b;e.rb=Kf;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function nh(a,b){if(0>a||a>b){throw wf(new Of('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:pl)|(0==(c&6291456)?!a?rl:4194304:0)|0|0|0)}
function lk(a){lb(a.a);S(a.e);S(a.b);S(a.j);ab(a.h);ab(a.g);ab(a.c);ab(a.d);ab(a.k);ab(a.i);ab(a.f)}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function Aj(){if(!zj){zj=(++(K(),K(),J).e,new Gb);$wnd.Promise.resolve(null).then(Hf(Bj.prototype.K,Bj,[]))}}
function yj(){wj();return Wc(Rc(Ne,1),ol,5,0,[aj,bj,cj,dj,ej,fj,gj,hj,ij,jj,kj,lj,mj,nj,oj,pj,qj,rj,sj,tj,uj,vj])}
function r(a){return dd(a)?$d:cd(a)?Od:bd(a)?Md:_c(a)?a.pb:Vc(a)?a.pb:a.pb||Array.isArray(a)&&Rc(Fd,1)||Fd}
function ec(a){var b,c;for(c=new Jg(new Ig(new tg(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);dh(b).A()}}
function db(a,b){var c,d;d=a.c;Fg(d,b);!!a.b&&pl!=(a.b.c&ql)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function gk(a){var b,c;c=T(a.j);b=(hb(a.i),a.q);(null==b||!c.X(b))&&gc(new Vk(a,kh(Ch(Bh(T(a.j)._(),new jl)))))}
function Og(a){var b,c,d;d=0;for(c=new wg(a.a);c.b;){b=vg(c);d=d+(b?hh(b.b.value[0])^hh(dh(b)):0);d=d|0}return d}
function mg(a,b){var c,d;for(d=a.U();d.cb();){c=d.db();if(ed(b)===ed(c)||b!=null&&q(b,c)){return true}}return false}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function ji(a){var b,c;b=ki($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=(c={},c[vl]=a,c);return b}
function fi(a){di();var b,c,d;c=':'+a;d=ci[c];if(d!=null){return fd(d)}d=ai[c];b=d==null?ei(a):fd(d);gi();ci[c]=b;return b}
function Jf(a){var b;if(Array.isArray(a)&&a.rb===Kf){return Sf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function Wb(a){var b;if(a.c){while(!a.c.Y()){b=a.c.gb(a.c.Z()-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&pl)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function s(a){return dd(a)?fi(a):cd(a)?fd(a):bd(a)?a?1231:1237:_c(a)?a.w():Vc(a)?_h(a):!!a&&!!a.hashCode?a.hashCode():_h(a)}
function q(a,b){return dd(a)?o(a,b):cd(a)?a===b:bd(a)?ed(a)===ed(b):_c(a)?a.u(b):Vc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):ed(a)===ed(b)}
function Bf(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(pl==(b&ql)?0:524288)|(0==(b&6291456)?pl==(b&ql)?4194304:rl:0)|0|268435456|0)}
function eg(a){var b;b=cg(a);if(b>3.4028234663852886E38){return Infinity}else if(b<-3.4028234663852886E38){return -Infinity}return b}
function yc(){var a;if(tc!=0){a=sc();if(a-uc>2000){uc=a;vc=$wnd.setTimeout(Ec,10)}}if(tc++==0){Hc((Gc(),Fc));return true}return false}
function $c(a,b){if(dd(a)){return !!Zc[b]}else if(a.qb){return !!a.qb[b]}else if(cd(a)){return !!Yc[b]}else if(bd(a)){return !!Xc[b]}return false}
function _f(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Mg(a,b){var c,d;d=a.a.length;b.length<d&&(b=Yh(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function og(a,b){var c,d,e,f;f=a.Z();b.length<f&&(b=Yh(new Array(f),b));e=b;d=a.U();for(c=0;c<f;++c){e[c]=d.db()}b.length>f&&(b[f]=null);return b}
function Pc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function bk(a){this.e=new Ik;this.c=a;K();++_j;this.b=new hc(new ck(this),new dk(this),false);this.a=new wb(null,new fk(this),1411518464)}
function X(a,b,c,d){this.c=a;this.g=b;this.h=c;this.j=null;this.i=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);pl==(d&ql)&&mb(this.f)}
function qi(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function T(a){a.i?hb(a.e):gb(a.e);if(ub(a.f)){if(a.i&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Jg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Jg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Jg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Uc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.A(),null)}finally{bc()}return f}catch(a){a=vf(a);if(ad(a,4)){e=a;throw wf(e)}else throw wf(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.B()}else{ac(b,e);try{g=c.B()}finally{bc()}}return g}catch(a){a=vf(a);if(ad(a,4)){f=a;throw wf(f)}else throw wf(a)}finally{D(b)}}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function Af(b,c,d,e){zf();var f=xf;$moduleName=c;$moduleBase=d;uf=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{ml(g)()}catch(a){b(c,a)}}else{ml(g)()}}
function ki(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Xg(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Yg()}}
function Df(){Cf={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Lc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].sb()&&(c=Kc(c,g)):g[0].sb()}catch(a){a=vf(a);if(ad(a,4)){d=a;wc();Cc(ad(d,32)?d.J():d)}else throw wf(a)}}return c}
function R(b){var c,d,e;e=b.j;try{d=b.c.B();if(!(ed(e)===ed(d)||e!=null&&q(e,d))){b.j=d;b.b=null;eb(b.e)}}catch(a){a=vf(a);if(ad(a,9)){c=a;if(!b.b){b.j=null;b.b=c;eb(b.e)}throw wf(c)}else throw wf(a)}}
function Uh(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Cj(a){var b,c,d,e;c=Gk(a.e);if(0!=c&&null!=a.f){b=(Nf(),Mf);e=b.createRange();d=Hk(a.e);e.setStart(a.f.firstChild,d);e.setEnd(a.f.firstChild,d+c);return e.getBoundingClientRect()}else{return null}}
function cg(a){bg==null&&(bg=new RegExp('^\\s*[+-]?(NaN|Infinity|((\\d+\\.?\\d*)|(\\.\\d+))([eE][+-]?\\d+)?[dDfF]?)\\s*$'));if(!bg.test(a)){throw wf(new hg('For input string: "'+a+'"'))}return parseFloat(a)}
function ei(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ig(a,c++)}b=b|0;return b}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Tc(Yd,ol,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{$j(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=vf(a);if(ad(a,4)){K()}else throw wf(a)}}}
function vb(a,b,c,d){this.b=new Hg;this.f=new Kb(new zb(this),d&6520832|262144|pl);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&rl)&&D((null,J)))}
function Ff(a,b,c){var d=Cf,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Cf[b]),If(h));_.qb=c;!b&&(_.rb=Kf);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.pb=f)}
function $f(a){if(a.S()){var b=a.c;b.T()?(a.j='['+b.i):!b.S()?(a.j='[L'+b.Q()+';'):(a.j='['+b.Q());a.b=b.P()+'[]';a.h=b.R()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=_f('.',[c,_f('$',d)]);a.b=_f('.',[c,_f('.',d)]);a.h=d[d.length-1]}
function hk(a,b){var c;c=b.type;if(!o('boundary',c)){V(a.e);V(a.b)}if((o('error',c)||o('end',c))&&$wnd[xl].speechSynthesis.paused){$wnd[xl].speechSynthesis.cancel()}else if(o('boundary',c)&&o(b.name,'word')){gc(new Qk(a,b.charIndex));gc(new Rk(a,b.charLength))}}
function pg(a,b){var c,d,e,f,g;e=b.b.value[0];g=dh(b);f=e==null?qg(Rg((d=a.a.a.get(0),d==null?new Array:d))):_g(a.b,e);if(!(ed(g)===ed(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!Rg((c=a.a.a.get(0),c==null?new Array:c)):$g(a.b,e))){return false}return true}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Jg(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=vf(a);if(!ad(a,4))throw wf(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function mi(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ii(b,Hf(pi.prototype.lb,pi,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[vl]=c[0],undefined):(d[vl]=c,undefined));return g=ki($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function kc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.H();return a&&a.F()}},suppressed:{get:function(){return c.G()}}})}catch(a){}}}
function Wg(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.h,e));d.j=null}Bg(a.b,new Bb(a));a.b.a=Tc(Yd,ol,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function ik(a){var b,c;gc(new Qk(a,0));gc(new Rk(a,0));c=new $wnd.SpeechSynthesisUtterance((hb(a.f),a.n));c.voice=(hb(a.i),a.q);c.volume=(hb(a.k),a.r);c.pitch=(hb(a.c),a.l);b=(hb(a.d),a.m);c.rate=$wnd.Math.pow($wnd.Math.abs(b)+1,b<0?-1:1);c.onstart=Hf(dl.prototype.N,dl,[a]);c.onend=Hf(el.prototype.N,el,[a]);c.onerror=Hf(fl.prototype.M,fl,[a]);c.onboundary=Hf(gl.prototype.N,gl,[a]);c.onpause=Hf(hl.prototype.N,hl,[a]);c.onresume=Hf(il.prototype.N,il,[a]);$wnd[xl].speechSynthesis.speak(c)}
function wj(){wj=Gf;aj=new xj(wl,0);bj=new xj('checkbox',1);cj=new xj('color',2);dj=new xj('date',3);ej=new xj('datetime',4);fj=new xj('email',5);gj=new xj('file',6);hj=new xj('hidden',7);ij=new xj('image',8);jj=new xj('month',9);kj=new xj('number',10);lj=new xj('password',11);mj=new xj('radio',12);nj=new xj('range',13);oj=new xj('reset',14);pj=new xj('search',15);qj=new xj('submit',16);rj=new xj('tel',17);sj=new xj('text',18);tj=new xj('time',19);uj=new xj('url',20);vj=new xj('week',21)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Cg(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Gg(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Cg(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Eg(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Hg)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&pl!=(k.b.c&ql)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function Ik(){var a,b,c,d,e,f,g,h,i,j,k,l,m,n;this.t=new kl(this);K();++kk;this.s=new hc(null,new Jk(this),true);this.l=0.5;this.m=0;this.r=1;this.n='Call me Ishmael. Some years ago, never mind how long precisely, having little or no money in my purse, and nothing particular to interest me on shore, I thought I would sail about a little and see the watery part of the world.';this.h=(i=new jb((b=null,b)),i);this.g=(j=new jb((c=null,c)),j);this.c=(k=new jb((d=null,d)),k);this.d=(l=new jb((e=null,e)),l);this.k=(m=new jb((f=null,f)),m);this.i=(n=new jb((g=null,g)),n);this.f=(h=new jb((a=null,a)),h);this.e=new X(new Mk,null,null,35667968);this.b=new X(new Nk,null,null,35667968);this.j=new X(new Ok,new Kk(this),new Lk(this),35651584);this.a=new wb(new Pk(this),null,413138944);D((null,J))}
function Yg(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Wg()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function Zj(a){var b,c,d,e,f;a.d=0;Aj();b=(c=yk(a.e),mi(yl,qi(new $wnd.Object,Wc(Rc($d,1),ol,2,6,[T(a.e.e)?'speaking':null])),[mi('h1',null,['Web Speech Synthesis Demo']),mi('form',null,[mi(yl,ri(new $wnd.Object,'textarea'),[T(a.e.e)?ji([mi(yl,ri(ti(new $wnd.Object,Hf(Lj.prototype.C,Lj,[a])),'textbeingspoken'),[xk(a.e)]),mi(yl,ui(new $wnd.Object,(d=Cj(a),e=(Nf(),Mf).body,f=Gk(a.e),Bi(Gi(Ci(Ei(Fi(Ai(zi(Di(new $wnd.Object)),0==f?'none':'block'),0==f?'all 0s ease 0s':'all 50ms ease'),null==d?'0':d.top-1+e.clientHeight-e.scrollHeight-8+'px'),null==d?'0':d.left-1+e.clientWidth-e.scrollWidth-8+'px'),null==d?'0':d.width+'px'),null==d?'0':d.height+'px'))),null)]):mi('textarea',Ki(wi(Ni(new $wnd.Object,xk(a.e)),T(a.e.e)),Hf(Mj.prototype.mb,Mj,[a])),null)]),mi(yl,qi(new $wnd.Object,Wc(Rc($d,1),ol,2,6,[zl])),[mi(Al,Oi(new $wnd.Object,'pitch'),['Pitch']),mi('input',Ki(wi(Li(Ii(Ji(Ni(yi(ri(new $wnd.Object,'pitch'),(wj(),nj)),''+vk(a.e)),'0'),'1'),'0.05'),T(a.e.e)),Hf(Rj.prototype.mb,Rj,[a])),null),mi(wl,xi(wi(vi(si(yi(new $wnd.Object,(Zi(),Wi)),Bl),Bl),T(a.e.e)),Hf(Sj.prototype.nb,Sj,[a])),[Cl])]),mi(yl,qi(new $wnd.Object,Wc(Rc($d,1),ol,2,6,[zl])),[mi(Al,Oi(new $wnd.Object,'rate'),['Rate']),mi('input',Ki(wi(Li(Ii(Ji(Ni(yi(ri(new $wnd.Object,'rate'),nj),''+wk(a.e)),'-3'),'3'),'0.25'),T(a.e.e)),Hf(Tj.prototype.mb,Tj,[a])),null),mi(wl,xi(wi(vi(si(yi(new $wnd.Object,Wi),Dl),Dl),T(a.e.e)),Hf(Uj.prototype.nb,Uj,[a])),[Cl])]),mi(yl,qi(new $wnd.Object,Wc(Rc($d,1),ol,2,6,[zl])),[mi(Al,Oi(new $wnd.Object,'volume'),['Volume']),mi('input',Ki(wi(Li(Ii(Ji(Ni(yi(ri(new $wnd.Object,'volume'),nj),''+zk(a.e)),'0'),'1'),'0.05'),T(a.e.e)),Hf(Vj.prototype.mb,Vj,[a])),null),mi(wl,xi(wi(vi(si(yi(new $wnd.Object,Wi),El),El),T(a.e.e)),Hf(Wj.prototype.nb,Wj,[a])),[Cl])]),mi(yl,qi(new $wnd.Object,Wc(Rc($d,1),ol,2,6,[zl])),[mi(Al,Oi(new $wnd.Object,'voice'),['Voice']),mi('select',Ni(wi(Ki(new $wnd.Object,Hf(Jj.prototype.mb,Jj,[a])),T(a.e.e)),null==c?'':c.voiceURI),Fh(Dh(T(a.e.j)._(),new Kj),new oi)),mi(wl,xi(wi(vi(si(yi(new $wnd.Object,Wi),Fl),Fl),T(a.e.e)),Hf(Nj.prototype.nb,Nj,[a])),[Cl])]),mi(yl,qi(new $wnd.Object,Wc(Rc($d,1),ol,2,6,['bottom'])),[mi(wl,xi(wi(vi(si(qi(yi(new $wnd.Object,Wi),Wc(Rc($d,1),ol,2,6,['small'])),'Speak'),'Speak'),T(a.e.e)),Hf(Oj.prototype.nb,Oj,[a])),['Speak']),mi(wl,xi(wi(vi(si(qi(yi(new $wnd.Object,Wi),Wc(Rc($d,1),ol,2,6,['small'])),T(a.e.b)?Gl:'Pause'),T(a.e.b)?Gl:'Pause'),!T(a.e.e)),Hf(Pj.prototype.nb,Pj,[a])),[T(a.e.b)?Gl:'Pause']),mi(wl,xi(wi(vi(si(qi(yi(new $wnd.Object,Wi),Wc(Rc($d,1),ol,2,6,['small'])),'Stop'),'Stop'),!T(a.e.e)),Hf(Qj.prototype.nb,Qj,[])),['Stop'])])])]));return b}
var nl={11:1},ol={3:1},pl=1048576,ql=1835008,rl=2097152,sl='__noinit__',tl={3:1,9:1,7:1,4:1},ul={3:1,36:1,61:1},vl='children',wl='button',xl='window',yl='div',zl='speecharg',Al='label',Bl='Reset pitch',Cl='\u21B6',Dl='Reset rate',El='Reset volume',Fl='Reset voice',Gl='Resume',Hl='voiceschanged',Il=142606336;var _,Cf,xf,uf=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Df();Ff(1,null,{},p);_.u=function(a){return o(this,a)};_.v=function(){return this.pb};_.w=Jl;_.equals=function(a){return this.u(a)};_.hashCode=function(){return this.w()};var Xc,Yc,Zc;Ff(45,1,{},Tf);_.O=function(a){var b;b=new Tf;b.e=4;a>1?(b.c=Yf(this,a-1)):(b.c=this);return b};_.P=function(){Rf(this);return this.b};_.Q=function(){return Sf(this)};_.R=function(){Rf(this);return this.h};_.S=function(){return (this.e&4)!=0};_.T=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Qf=1;var Yd=Vf(1);var Nd=Vf(45);Ff(76,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var ld=Vf(76);Ff(77,1,nl,G);_.A=function(){Db(this.a)};var hd=Vf(77);Ff(37,1,{},H);_.B=function(){return this.a.A(),null};var jd=Vf(37);Ff(78,1,{},I);var kd=Vf(78);var J;Ff(39,1,{39:1},Q);_.b=0;_.c=false;_.d=0;var md=Vf(39);Ff(157,1,{});var pd=Vf(157);Ff(41,157,{},X);_.a=false;_.d=0;_.i=false;var od=Vf(41);Ff(114,1,{},Y);_.B=function(){return U(this.a)};var nd=Vf(114);Ff(14,157,{14:1},jb);_.a=4;_.d=false;_.e=0;var rd=Vf(14);Ff(113,1,nl,kb);_.A=function(){bb(this.a)};var qd=Vf(113);Ff(22,157,{22:1},wb,xb);_.c=0;var wd=Vf(22);Ff(108,1,{},yb);_.A=function(){R(this.a)};var sd=Vf(108);Ff(109,1,nl,zb);_.A=function(){nb(this.a)};var td=Vf(109);Ff(110,1,nl,Ab);_.A=function(){qb(this.a)};var ud=Vf(110);Ff(111,1,{},Bb);_.C=function(a){ob(this.a,a)};var vd=Vf(111);Ff(88,1,{},Eb);_.a=0;_.b=0;_.c=0;var xd=Vf(88);Ff(118,1,{},Gb);_.a=false;var yd=Vf(118);Ff(53,157,{53:1},Kb);_.a=0;var Ad=Vf(53);Ff(87,1,{},Pb);var zd=Vf(87);Ff(120,1,{},_b);_.a=0;var Qb;var Bd=Vf(120);Ff(54,1,{},hc);_.g=0;var Dd=Vf(54);Ff(107,1,nl,ic);_.A=function(){fc(this.a)};var Cd=Vf(107);Ff(4,1,{3:1,4:1});_.D=function(a){return new Error(a)};_.F=Kl;_.G=function(){return Fh(Dh(Lg((this.e==null&&(this.e=Tc(ae,ol,4,0,0,1)),this.e)),new kg),new Jh)};_.H=function(){return this.c};_.I=function(){lc(this,nc(this.D(mc(this,this.d))));Oc(this)};_.b=sl;_.f=true;var ae=Vf(4);Ff(9,4,{3:1,9:1,4:1});var Qd=Vf(9);Ff(7,9,tl);var Zd=Vf(7);Ff(47,7,tl);var Ud=Vf(47);Ff(72,47,tl);var Hd=Vf(72);Ff(32,72,{32:1,3:1,9:1,7:1,4:1},rc);_.J=function(){return ed(this.a)===ed(pc)?null:this.a};var pc;var Ed=Vf(32);var Fd=Vf(0);Ff(139,1,{});var Gd=Vf(139);var tc=0,uc=0,vc=-1;Ff(82,139,{},Jc);var Fc;var Id=Vf(82);var Mc;Ff(151,1,{});var Kd=Vf(151);Ff(73,151,{},Qc);var Jd=Vf(73);var Mf;Ff(75,7,tl);var Td=Vf(75);Ff(112,75,tl,Of);var Ld=Vf(112);Xc={3:1,68:1,31:1};var Md=Vf(68);Ff(149,1,ol);var bg;var Xd=Vf(149);Yc={3:1,31:1};var Od=Vf(150);Ff(23,1,{3:1,31:1,23:1});_.u=function(a){return this===a};_.w=Jl;_.b=0;var Pd=Vf(23);Ff(46,7,tl);var Rd=Vf(46);Ff(74,7,tl,fg);var Sd=Vf(74);Ff(224,1,{});Ff(79,47,tl,gg);_.D=function(a){return new TypeError(a)};var Vd=Vf(79);Ff(69,46,tl,hg);var Wd=Vf(69);Zc={3:1,67:1,31:1,2:1};var $d=Vf(2);Ff(228,1,{});Ff(64,1,{},kg);_.V=function(a){return a.b};var _d=Vf(64);Ff(38,7,tl,lg);var be=Vf(38);Ff(152,1,{36:1});_.$=function(){return new uh(this,0)};_._=function(){return new Gh(null,this.$())};_.W=function(a){throw wf(new lg('Add not supported on this collection'))};_.X=function(a){return mg(this,a)};_.Y=function(){return this.Z()==0};_.ab=function(a){return og(this,a)};var ce=Vf(152);Ff(155,1,{136:1});_.u=function(a){var b,c,d;if(a===this){return true}if(!ad(a,40)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new wg((new tg(d)).a);c.b;){b=vg(c);if(!pg(this,b)){return false}}return true};_.w=function(){return Og(new tg(this))};var je=Vf(155);Ff(89,155,{136:1});var fe=Vf(89);Ff(154,152,{36:1,161:1});_.$=function(){return new uh(this,1)};_.u=function(a){var b;if(a===this){return true}if(!ad(a,21)){return false}b=a;if(rg(b.a)!=this.Z()){return false}return ng(this,b)};_.w=function(){return Og(this)};var ke=Vf(154);Ff(21,154,{21:1,36:1,161:1},tg);_.X=function(a){return sg(this,a)};_.U=function(){return new wg(this.a)};_.Z=function(){return rg(this.a)};var ee=Vf(21);Ff(24,1,{},wg);_.bb=Ll;_.db=function(){return vg(this)};_.cb=Kl;_.b=false;var de=Vf(24);Ff(153,152,{36:1,61:1});_.$=function(){return new uh(this,16)};_.eb=function(a,b){throw wf(new lg('Add not supported on this list'))};_.W=function(a){this.eb(this.Z(),a);return true};_.u=function(a){var b,c,d,e,f;if(a===this){return true}if(!ad(a,61)){return false}f=a;if(this.Z()!=f.Z()){return false}e=f.U();for(c=this.U();c.cb();){b=c.db();d=e.db();if(!(ed(b)===ed(d)||b!=null&&q(b,d))){return false}}return true};_.w=function(){return Pg(this)};_.U=function(){return new yg(this)};_.gb=function(a){throw wf(new lg('Remove not supported on this list'))};var he=Vf(153);Ff(81,1,{},yg);_.bb=Ll;_.cb=function(){return this.a<this.b.Z()};_.db=function(){return this.a<this.b.Z(),this.b.fb(this.a++)};_.a=0;var ge=Vf(81);Ff(156,1,{162:1});_.u=function(a){var b;if(!ad(a,33)){return false}b=a;return gh(this.b.value[0],b.b.value[0])&&gh(dh(this),dh(b))};_.w=function(){return hh(this.b.value[0])^hh(dh(this))};var ie=Vf(156);Ff(13,153,ul,Hg,Ig);_.eb=function(a,b){Vh(this.a,a,b)};_.W=function(a){return Ag(this,a)};_.X=function(a){return Dg(this,a,0)!=-1};_.fb=function(a){return Cg(this,a)};_.Y=function(){return this.a.length==0};_.U=function(){return new Jg(this)};_.gb=function(a){return Eg(this,a)};_.Z=Ml;_.ab=function(a){var b,c;c=this.a.length;a.length<c&&(a=Yh(new Array(c),a));for(b=0;b<c;++b){a[b]=this.a[b]}a.length>c&&(a[c]=null);return a};var me=Vf(13);Ff(16,1,{},Jg);_.bb=Ll;_.cb=function(){return this.a<this.c.a.length};_.db=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var le=Vf(16);Ff(6,153,ul,Ng);_.X=function(a){return xg(this,a)!=-1};_.fb=function(a){return this.a[a]};_.Z=Ml;_.ab=function(a){return Mg(this,a)};var ne=Vf(6);Ff(40,89,{3:1,40:1,136:1},Qg);var oe=Vf(40);Ff(90,1,{},Sg);_.U=function(){return new Tg(this)};_.b=0;var qe=Vf(90);Ff(49,1,{},Tg);_.bb=Ll;_.db=function(){return this.d=this.a[this.c++],this.d};_.cb=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var pe=Vf(49);var Ug;Ff(91,1,{},ah);_.U=function(){return new bh(this)};_.b=0;_.c=0;var te=Vf(91);Ff(50,1,{},bh);_.bb=Ll;_.db=function(){return this.c=this.a,this.a=this.b.next(),new eh(this.d,this.c,this.d.c)};_.cb=function(){return !this.a.done};var re=Vf(50);Ff(33,156,{33:1,162:1},eh);_.c=0;var se=Vf(33);Ff(34,1,{34:1},lh);_.u=function(a){var b;if(a===this){return true}if(!ad(a,34)){return false}b=a;return gh(this.a,b.a)};_.w=function(){return hh(this.a)};var ih;var ue=Vf(34);Ff(93,1,{});_.bb=Nl;_.hb=function(){return this.d};_.ib=function(){return this.e};_.d=0;_.e=0;var ye=Vf(93);Ff(51,93,{});var ve=Vf(51);Ff(83,1,{});_.bb=Nl;_.hb=Kl;_.ib=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var xe=Vf(83);Ff(84,83,{},sh);_.bb=function(a){ph(this,a)};_.jb=function(a){return qh(this,a)};var we=Vf(84);Ff(20,1,{},uh);_.hb=function(){return this.a};_.ib=function(){th(this);return this.c};_.bb=function(a){th(this);this.d.bb(a)};_.jb=function(a){th(this);if(this.d.cb()){a.C(this.d.db());return true}return false};_.a=0;_.c=0;var ze=Vf(20);Ff(66,1,{},vh);_.V=function(a){return a};var Ae=Vf(66);Ff(119,1,{},wh);var Be=Vf(119);Ff(92,1,{});_.c=false;var Ke=Vf(92);Ff(25,92,{},Gh);var Je=Vf(25);Ff(65,1,{},Jh);_.kb=function(a){return Tc(Yd,ol,1,a,5,1)};var Ce=Vf(65);Ff(95,51,{},Lh);_.jb=function(a){this.b=false;while(!this.b&&this.c.jb(new Mh(this,a)));return this.b};_.b=false;var Ee=Vf(95);Ff(97,1,{},Mh);_.C=function(a){Kh(this.a,this.b,a)};var De=Vf(97);Ff(94,51,{},Oh);_.jb=function(a){return this.b.jb(new Ph(this,a))};var Ge=Vf(94);Ff(96,1,{},Ph);_.C=function(a){Nh(this.a,this.b,a)};var Fe=Vf(96);Ff(52,1,{},Rh);_.C=function(a){Qh(this,a)};var He=Vf(52);Ff(98,1,{},Th);_.C=function(a){Sh(this,a)};var Ie=Vf(98);Ff(226,1,{});Ff(223,1,{});var $h=0;var ai,bi=0,ci;Ff(831,1,{});Ff(856,1,{});Ff(117,1,{},oi);_.kb=function(a){return new Array(a)};var Le=Vf(117);Ff(207,$wnd.Function,{},pi);_.lb=function(a){ni(this.a,this.b,a)};Ff(26,23,{3:1,31:1,23:1,26:1},$i);var Wi,Xi,Yi;var Me=Wf(26,_i);Ff(5,23,{3:1,31:1,23:1,5:1},xj);var aj,bj,cj,dj,ej,fj,gj,hj,ij,jj,kj,lj,mj,nj,oj,pj,qj,rj,sj,tj,uj,vj;var Ne=Wf(5,yj);var zj;Ff(208,$wnd.Function,{},Bj);_.K=function(a){return Fb(zj),zj=null,null};Ff(100,1,{});var Qe=Vf(100);Ff(189,$wnd.Function,{},Jj);_.mb=function(a){Ij(this.a,a)};Ff(86,1,{},Kj);_.V=function(a){return mi('option',Ni(new $wnd.Object,a.voiceURI),[a.name+' ('+a.lang+')'])};var Oe=Vf(86);Ff(179,$wnd.Function,{},Lj);_.C=function(a){Dj(this.a,a)};Ff(181,$wnd.Function,{},Mj);_.mb=function(a){Ej(this.a,a)};Ff(190,$wnd.Function,{},Nj);_.nb=function(a){Dk(this.a.e)};Ff(191,$wnd.Function,{},Oj);_.nb=function(a){ik(this.a.e)};Ff(192,$wnd.Function,{},Pj);_.nb=function(a){T(this.a.e.b)?$wnd[xl].speechSynthesis.resume():$wnd[xl].speechSynthesis.pause()};Ff(193,$wnd.Function,{},Qj);_.nb=function(a){$wnd[xl].speechSynthesis.cancel()};Ff(182,$wnd.Function,{},Rj);_.mb=function(a){Fj(this.a,a)};Ff(183,$wnd.Function,{},Sj);_.nb=function(a){gc(new Sk(this.a.e,0.5))};Ff(184,$wnd.Function,{},Tj);_.mb=function(a){Gj(this.a,a)};Ff(185,$wnd.Function,{},Uj);_.nb=function(a){gc(new Tk(this.a.e,0))};Ff(186,$wnd.Function,{},Vj);_.mb=function(a){Hj(this.a,a)};Ff(187,$wnd.Function,{},Wj);_.nb=function(a){gc(new Uk(this.a.e,1))};Ff(63,1,{},Xj);var Pe=Vf(63);Ff(101,100,{});_.d=0;var pf=Vf(101);Ff(102,101,{},bk);var _j=0;var Ve=Vf(102);Ff(103,1,nl,ck);_.A=function(){Z(this.a.e)};var Re=Vf(103);Ff(104,1,nl,dk);_.A=function(){lb(this.a.a)};var Se=Vf(104);Ff(106,1,{},ek);_.B=function(){return Zj(this.a)};var Te=Vf(106);Ff(105,1,{},fk);_.A=function(){$j(this.a)};var Ue=Vf(105);Ff(121,1,{});var tf=Vf(121);Ff(122,121,{},Ik);_.l=0;_.m=0;_.o=0;_.p=0;_.r=0;var kk=0;var nf=Vf(122);Ff(123,1,nl,Jk);_.A=function(){lk(this.a)};var We=Vf(123);Ff(127,1,{},Kk);_.A=function(){mk(this.a)};var Xe=Vf(127);Ff(128,1,{},Lk);_.A=function(){nk(this.a)};var Ye=Vf(128);Ff(124,1,{},Mk);_.B=function(){return Pf(),$wnd[xl].speechSynthesis.speaking?true:false};var Ze=Vf(124);Ff(125,1,{},Nk);_.B=function(){return Pf(),$wnd[xl].speechSynthesis.paused?true:false};var $e=Vf(125);Ff(126,1,{},Ok);_.B=function(){var a;return a=$wnd[xl].speechSynthesis.getVoices(),new Ng(a)};var _e=Vf(126);Ff(129,1,{},Pk);_.A=function(){gk(this.a)};var af=Vf(129);Ff(56,1,nl,Qk);_.A=function(){sk(this.a,this.b)};_.b=0;var bf=Vf(56);Ff(57,1,nl,Rk);_.A=function(){rk(this.a,this.b)};_.b=0;var cf=Vf(57);Ff(58,1,nl,Sk);_.A=function(){ok(this.a,this.b)};_.b=0;var df=Vf(58);Ff(59,1,nl,Tk);_.A=function(){pk(this.a,this.b)};_.b=0;var ef=Vf(59);Ff(60,1,nl,Uk);_.A=function(){uk(this.a,this.b)};_.b=0;var ff=Vf(60);Ff(42,1,nl,Vk);_.A=function(){tk(this.a,this.b)};var gf=Vf(42);Ff(130,1,nl,Wk);_.A=function(){qk(this.a,this.b)};var hf=Vf(130);Ff(131,1,nl,Xk);_.A=function(){V(this.a)};var jf=Vf(131);Ff(132,1,nl,Yk);_.A=function(){hk(this.a,this.b)};var kf=Vf(132);Ff(133,1,nl,Zk);_.A=function(){Ak(this.a)};var lf=Vf(133);Ff(134,1,nl,$k);_.A=function(){Bk(this.a,this.b)};var mf=Vf(134);Ff(194,$wnd.Function,{},_k);_.ob=function(a){return new cl(a)};var al;Ff(85,$wnd.React.Component,{},cl);Ef(Cf[1],_);_.componentDidMount=function(){$wnd[xl].speechSynthesis.cancel()};_.componentWillUnmount=function(){Yj(this.a)};_.render=function(){return ak(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var of=Vf(85);Ff(198,$wnd.Function,{},dl);_.N=Ol;Ff(199,$wnd.Function,{},el);_.N=Ol;Ff(200,$wnd.Function,{},fl);_.M=Ol;Ff(201,$wnd.Function,{},gl);_.N=Ol;Ff(202,$wnd.Function,{},hl);_.N=Ol;Ff(203,$wnd.Function,{},il);_.N=Ol;Ff(55,1,{},jl);_.L=function(a){return a.default};var qf=Vf(55);Ff(115,1,{},kl);_.handleEvent=function(a){Fk(this.a.j)};var rf=Vf(115);Ff(116,1,{},ll);_.L=function(a){return jk(this.a,a)};var sf=Vf(116);var gd=Xf('D');var ml=(wc(),zc);var gwtOnLoad=gwtOnLoad=Af;yf(Lf);Bf('permProps',[[]]);if (webspeechdemo) webspeechdemo.onScriptLoad(gwtOnLoad);})();