function webspeechdemo(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='webspeechdemo',tb='__gwt_marker_webspeechdemo',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='FA30F4DB9A0AF0879DA1304C0A58AFCF',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};webspeechdemo.onScriptLoad=function(a){webspeechdemo=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
webspeechdemo();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'FA30F4DB9A0AF0879DA1304C0A58AFCF';function p(){}
function pg(){}
function Pf(){}
function Lf(){}
function Fb(){}
function Ic(){}
function Pc(){}
function Pj(){}
function Gj(){}
function Vj(){}
function Ah(){}
function Oh(){}
function Wh(){}
function ti(){}
function Rk(){}
function Sk(){}
function Tk(){}
function el(){}
function il(){}
function Nc(a){Mc()}
function Uf(){Uf=Lf}
function qb(a,b){a.b=b}
function Vh(a,b){a.a=b}
function G(a){this.a=a}
function H(a){this.a=a}
function X(a){this.a=a}
function jb(a){this.a=a}
function xb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function hc(a){this.a=a}
function yg(a){this.a=a}
function Sg(a){this.a=a}
function Sj(a){this.a=a}
function Oj(a){this.a=a}
function Qj(a){this.a=a}
function Rj(a){this.a=a}
function Tj(a){this.a=a}
function Uj(a){this.a=a}
function Wj(a){this.a=a}
function Xj(a){this.a=a}
function Yj(a){this.a=a}
function Yh(a){this.a=a}
function Bh(a){this.a=a}
function Zj(a){this.a=a}
function $j(a){this.a=a}
function _j(a){this.a=a}
function hk(a){this.a=a}
function ik(a){this.a=a}
function jk(a){this.a=a}
function kk(a){this.a=a}
function Ok(a){this.a=a}
function Pk(a){this.a=a}
function Qk(a){this.a=a}
function Uk(a){this.a=a}
function al(a){this.a=a}
function cl(a){this.a=a}
function jl(a){this.a=a}
function kl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function nl(a){this.a=a}
function ol(a){this.a=a}
function pl(a){this.a=a}
function ql(a){this.a=a}
function Dg(a){this.b=a}
function Og(a){this.c=a}
function Xg(){this.a=dh()}
function gh(){this.a=dh()}
function Mg(){Eg(this)}
function Ql(a){kh(this,a)}
function Sl(a){rh(this,a)}
function db(a){Xb((J(),a))}
function eb(a){Yb((J(),a))}
function hb(a){Zb((J(),a))}
function w(a){--a.e;D(a)}
function Y(a){!!a&&bc(a.s)}
function cc(a){!!a&&a.B()}
function ni(a,b){mi(a,b)}
function Xh(a,b){Nh(a.a,b)}
function C(a,b){Nb(a.f,b.f)}
function K(a,b){O(a);L(a,b)}
function Tl(a){Hk(this.a,a)}
function qh(a){oh();this.a=a}
function Bf(a){return a.b}
function Ij(a,b){return a.f=b}
function Pl(){return this.b}
function Ol(){return ei(this)}
function Hg(a,b){return a.a[b]}
function kc(a,b){a.b=b;jc(a,b)}
function bk(a){a.d=2;bc(a.b)}
function $g(){$g=Lf;Zg=ah()}
function J(){J=Lf;I=new F}
function pc(){pc=Lf;oc=new p}
function Fc(){Fc=Lf;Ec=new Ic}
function vc(){vc=Lf;!!(Mc(),Lc)}
function Tf(a){nc.call(this,a)}
function mg(a){nc.call(this,a)}
function qg(a){nc.call(this,a)}
function lg(){ic(this);this.I()}
function Ef(){Cf==null&&(Cf=[])}
function wh(a,b,c){b.C(a.a[c])}
function Sh(a,b,c){b.C(a.a.S(c))}
function rh(a,b){while(a.gb(b));}
function Nh(a,b){Vh(a,Mh(a.a,b))}
function Qc(a,b){return bg(a,b)}
function ai(a,b){a.splice(b,1)}
function wi(a,b){a.id=b;return a}
function yi(a,b){a.ref=b;return a}
function Ji(a,b){a.top=b;return a}
function Ni(a,b){a.max=b;return a}
function Oi(a,b){a.min=b;return a}
function Mh(a,b){a.T(b);return a}
function Xf(a){Wf(a);return a.j}
function Ak(a){gb(a.c);return a.l}
function Bk(a){gb(a.d);return a.m}
function Ck(a){gb(a.f);return a.n}
function Dk(a){gb(a.i);return a.q}
function Ek(a){gb(a.k);return a.r}
function Lk(a){gb(a.g);return a.o}
function Mk(a){gb(a.h);return a.p}
function T(a){mb(a.f);return V(a)}
function Rb(a){Sb(a);!a.d&&Vb(a)}
function ab(a){J();Yb(a);a.e=-2}
function dh(){$g();return new Zg}
function Vc(a){return new Array(a)}
function wg(a){return a.a.b+a.b.b}
function fh(a,b){return a.a.get(b)}
function Rh(a,b){this.a=a;this.b=b}
function Uh(a,b){this.a=a;this.b=b}
function ig(a,b){this.a=a;this.b=b}
function ui(a,b){this.a=a;this.b=b}
function Vk(a,b){this.a=a;this.b=b}
function Wk(a,b){this.a=a;this.b=b}
function Xk(a,b){this.a=a;this.b=b}
function Yk(a,b){this.a=a;this.b=b}
function Zk(a,b){this.a=a;this.b=b}
function $k(a,b){this.a=a;this.b=b}
function _k(a,b){this.a=a;this.b=b}
function bl(a,b){this.a=a;this.b=b}
function dl(a,b){this.a=a;this.b=b}
function Db(a){this.d=a;this.b=100}
function ak(){this.a=qi((gl(),fl))}
function Dc(){sc!=0&&(sc=0);uc=-1}
function Cc(a){$wnd.clearTimeout(a)}
function vg(a){return !a?null:ih(a)}
function Rl(){return this.a.length}
function dj(a,b){ig.call(this,a,b)}
function Cj(a,b){ig.call(this,a,b)}
function $h(a,b,c){a.splice(b,0,c)}
function v(a,b,c){t(a,new H(c),b)}
function oh(){oh=Lf;nh=new qh(null)}
function ed(a){return a==null?null:a}
function mh(a){return a!=null?s(a):0}
function Tb(a){return !a.d?a:Tb(a.d)}
function o(a,b){return ed(a)===ed(b)}
function Ai(a,b){a.title=b;return a}
function zi(a,b){a.style=b;return a}
function Qi(a,b){a.step=b;return a}
function Hi(a,b){a.left=b;return a}
function Li(a,b){a.width=b;return a}
function Si(a,b){a.value=b;return a}
function Gi(a,b){a.height=b;return a}
function Ti(a,b){a.htmlFor=b;return a}
function Ci(a,b){a.onClick=b;return a}
function Fi(a,b){a.display=b;return a}
function Bi(a,b){a.disabled=b;return a}
function Pi(a,b){a.onChange=b;return a}
function _h(a,b){Zh(b,0,a,0,b.length)}
function A(a,b,c){u(a,new G(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function ng(a,b){return a.charCodeAt(b)}
function ei(a){return a.$H||(a.$H=++di)}
function Z(a){return !(!!a&&1==(a.c&7))}
function ad(a,b){return a!=null&&$c(a,b)}
function ph(a){return a.a!=null?a.a:null}
function ok(a,b){return o(b.voiceURI,a)}
function Nj(a,b){Jk(a.e,b.target.value)}
function pb(a){J();ob(a);sb(a,2,true)}
function Eg(a){a.a=Sc(Xd,sl,1,0,5,1)}
function P(){this.a=Sc(Xd,sl,1,100,5,1)}
function nc(a){this.d=a;ic(this);this.I()}
function ib(a){this.c=new Mg;this.b=a}
function Vg(){this.a=new Xg;this.b=new gh}
function ii(){ii=Lf;fi=new p;hi=new p}
function Ki(a,b){a.transition=b;return a}
function Ii(a){a.position='fixed';return a}
function Wf(a){if(a.j!=null){return}dg(a)}
function fb(a){var b;Ub((J(),b=Pb,b),a)}
function Ik(a){A((J(),J(),I),new cl(a),Nl)}
function Kk(a){A((J(),J(),I),new al(a),Nl)}
function fc(a){J();Pb?a.B():A((null,I),a,0)}
function Gb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function U(a){4==(a.f.c&7)&&sb(a.f,5,true)}
function ic(a){a.f&&a.b!==xl&&a.I();return a}
function xi(a,b){a['aria-label']=b;return a}
function $f(a){var b;b=Zf(a);fg(a,b);return b}
function dd(a){return typeof a==='string'}
function cd(a){return typeof a==='number'}
function bd(a){return typeof a==='boolean'}
function wc(a,b,c){return a.apply(b,c);var d}
function Mb(a,b,c){c.a=-4&c.a|1;K(a.a[b],c)}
function mi(a,b){for(var c in a){b(c)}}
function kh(a,b){while(a._()){Xh(b,a.ab())}}
function uh(a,b){while(a.c<a.d){wh(a,b,a.c++)}}
function Cb(a){while(true){if(!Bb(a)){break}}}
function Lh(a,b){Eh.call(this,a);this.a=b}
function jh(a,b,c){this.a=a;this.b=b;this.c=c}
function F(){this.f=new Ob;this.a=new Db(this.f)}
function Mc(){Mc=Lf;var a;!Oc();a=new Pc;Lc=a}
function Fh(a,b){var c;return Jh(a,(c=new Mg,c))}
function Jk(a,b){A((J(),J(),I),new dl(a,b),Nl)}
function Nb(a,b){Mb(a,((b.a&229376)>>15)-1,b)}
function nb(a,b){cb(b,a);b.c.a.length>0||(b.a=4)}
function Fg(a,b){a.a[a.a.length]=b;return true}
function ag(a){var b;b=Zf(a);b.i=a;b.e=1;return b}
function Jc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Ag(a){var b;b=a.a.ab();a.b=zg(a);return b}
function Jg(a,b){var c;c=a.a[b];ai(a.a,b);return c}
function Jj(a,b){fc(new _k(a.e,b.target.value))}
function eh(a,b){return !(a.a.get(b)===undefined)}
function Pg(a,b){return sh(b,a.length),new xh(a,b)}
function fk(a){return B((J(),J(),I),a.a,new jk(a))}
function Qg(a){return new Lh(null,Pg(a,a.length))}
function Uc(a){return Array.isArray(a)&&a.pb===Pf}
function _c(a){return !Array.isArray(a)&&a.pb===Pf}
function N(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function yh(a){if(!a.d){a.d=a.b.R();a.c=a.b.W()}}
function dk(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Eb(a){if(!a.a){a.a=true;w((J(),J(),I))}}
function Ch(a){if(!a.b){Dh(a);a.c=true}else{Ch(a.b)}}
function Ph(a,b,c){if(a.a.ib(c)){a.b=true;b.C(c)}}
function tk(a,b){var c;c=a.l;if(b!=c){a.l=b;eb(a.c)}}
function uk(a,b){var c;c=a.m;if(b!=c){a.m=b;eb(a.d)}}
function vk(a,b){var c;c=a.n;if(b!=c){a.n=b;eb(a.f)}}
function wk(a,b){var c;c=a.o;if(b!=c){a.o=b;eb(a.g)}}
function xk(a,b){var c;c=a.p;if(b!=c){a.p=b;eb(a.h)}}
function zk(a,b){var c;c=a.r;if(b!=c){a.r=b;eb(a.k)}}
function Lg(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Ei(a){a.border='1px solid orange';return a}
function ci(a){if(a==null){throw Bf(new lg)}return a}
function li(){if(gi==256){fi=hi;hi=new p;gi=0}++gi}
function Gh(a,b){Dh(a);return new Lh(a,new Qh(b,a.a))}
function Ih(a,b){Dh(a);return new Lh(a,new Th(b,a.a))}
function Hk(a,b){A((J(),J(),I),new bl(a,b),75497472)}
function Kj(a,b){fc(new Xk(a.e,jg(b.target.value)))}
function Lj(a,b){fc(new Yk(a.e,jg(b.target.value)))}
function Mj(a,b){fc(new Zk(a.e,jg(b.target.value)))}
function lh(a,b){return ed(a)===ed(b)||a!=null&&q(a,b)}
function th(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function zh(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function xh(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function $b(a,b){this.a=(J(),J(),I).b++;this.d=a;this.e=b}
function Eh(a){if(!a){this.b=null;new Mg}else{this.b=a}}
function cg(a){if(a.Q()){return null}var b=a.i;return Hf[b]}
function Di(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function _f(a,b){var c;c=Zf(a);fg(a,c);c.e=b?8:0;return c}
function lc(a,b){var c;c=Xf(a.nb);return b==null?c:c+': '+b}
function xg(a,b){if(ad(b,32)){return ug(a.a,b)}return false}
function _b(a,b){Pb=new $b(Pb,b);a.d=false;Qb(Pb);return Pb}
function Nf(a){function b(){}
;b.prototype=a||{};return new b}
function gl(){gl=Lf;var a;fl=(a=Mf(el.prototype.mb,el,[]),a)}
function gb(a){var b;J();!!Pb&&!!Pb.e&&Ub((b=Pb,b),a)}
function lb(a){C((J(),J(),I),a);0==(a.f.a&wl)&&D((null,I))}
function Fk(a){fc(new $k(a,ph(Hh(Gh(S(a.j).Y(),new il)))))}
function Gk(a,b){fc(new $k(a,ph(Hh(Gh(S(a.j).Y(),new ql(b))))))}
function Dh(a){if(a.b){Dh(a.b)}else if(a.c){throw Bf(new kg)}}
function Qb(a){if(a.e){2==(a.e.c&7)||sb(a.e,4,true);ob(a.e)}}
function ec(a){cc(a.f);!!a.d&&dc(a);Y(a.a);Y(a.c);cc(a.b);cc(a.e)}
function Bc(a){vc();$wnd.setTimeout(function(){throw a},0)}
function Sf(){Sf=Lf;Rf=$wnd.goog.global.document}
function ej(){cj();return Wc(Qc(Le,1),sl,25,0,[_i,aj,bj])}
function Ng(a){Eg(this);_h(this.a,tg(a,Sc(Xd,sl,1,wg(a.a),5,1)))}
function Yg(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Th(a,b){th.call(this,b.fb(),b.eb()&-6);this.a=a;this.b=b}
function vh(a,b){if(a.c<a.d){wh(a,b,a.c++);return true}return false}
function bg(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.L(b))}
function Jf(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function si(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function zc(a,b,c){var d;d=xc();try{return wc(a,b,c)}finally{Ac(d)}}
function bb(a,b){var c,d;Fg(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Kh(a,b){var c;c=Fh(a,new Bh(new Ah));return c.Z(b.hb(c.W()))}
function Jh(a,b){var c;Ch(a);c=new Wh;c.a=b;a.a.$(new Yh(c));return c.a}
function mc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function yc(b){vc();return function(){return zc(b,this,arguments);var a}}
function rc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function hl(a){$wnd.React.Component.call(this,a);this.a=new gk(this)}
function hh(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Bg(a){this.d=a;this.c=new hh(this.d.b);this.a=this.c;this.b=zg(this)}
function Qh(a,b){th.call(this,b.fb(),b.eb()&-16449);this.a=a;this.c=b}
function L(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Lb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=N(a.a[c])}return b}
function Ig(a,b,c){for(;c<a.a.length;++c){if(lh(b,a.a[c])){return c}}return -1}
function ih(a){if(a.a.c!=a.c){return fh(a.a,a.b.value[0])}return a.b.value[1]}
function $(a){if(-2!=a.e){A((J(),J(),I),new jb(a),0);!!a.b&&kb(a.b)}}
function bc(a){if(a.g>=0){a.g=-2;u((J(),J(),I),new G(new hc(a)),67108864,null)}}
function R(a){if(!a.a){a.a=true;a.j=null;a.b=null;$(a.e);2==(a.f.c&7)||kb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Cb(a.a)}finally{a.c=false}}}}
function V(a){if(a.b){if(ad(a.b,6)){throw Bf(a.b)}else{throw Bf(a.b)}}return a.j}
function Ib(b){try{mb(b.b.a)}catch(a){a=Af(a);if(!ad(a,4))throw Bf(a)}}
function Ac(a){a&&Hc((Fc(),Ec));--sc;if(a){if(uc!=-1){Cc(uc);uc=-1}}}
function fd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function bi(a,b){return Rc(b)!=10&&Wc(r(b),b.ob,b.__elementTypeId$,Rc(b),a),a}
function Rc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Gg(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.C(c)}}
function yk(a,b){var c;c=a.q;if(!(ed(b)===ed(c)||b!=null&&q(b,c))){a.q=b;eb(a.i)}}
function Hc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Kc(b,c)}while(a.b);a.b=c}}
function Gc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Kc(b,c)}while(a.a);a.a=c}}
function Ub(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Mg);Fg(a.b,b)}}}
function Wb(a,b){var c;if(!a.c){c=Tb(a);!c.c&&(c.c=new Mg);a.c=c.c}b.d=true;a.c.T(b)}
function Kg(a,b){var c;c=Ig(a,b,0);if(c==-1){return false}ai(a.a,c);return true}
function Sc(a,b,c,d,e,f){var g;g=Tc(e,d);e!=10&&Wc(Qc(a,f),b,c,e,g);return g}
function fg(a,b){var c;if(!a){return}b.i=a;var d=cg(b);if(!d){Hf[a]=[b];return}d.nb=b}
function Mf(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Zf(a){var b;b=new Yf;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function cj(){cj=Lf;_i=new dj(Bl,0);aj=new dj('reset',1);bj=new dj('submit',2)}
function Ob(){var a;this.a=Sc(ld,sl,41,5,0,1);for(a=0;a<5;a++){this.a[a]=new P}}
function ac(){var a;try{Rb(Pb);J()}finally{a=Pb.d;!a&&((J(),J(),I).d=true);Pb=Pb.d}}
function rb(b){if(b){try{b.B()}catch(a){a=Af(a);if(ad(a,4)){J()}else throw Bf(a)}}}
function qc(a){pc();ic(this);this.b=a;jc(this,a);this.d=a==null?'null':Of(a);this.a=a}
function kg(){nc.call(this,"Stream already terminated, can't be modified or used")}
function Qf(){$wnd.ReactDOM.render((new ak).a,(Sf(),Rf).getElementById('app'),null)}
function rk(a){(Sf(),$wnd.goog.global.window).speechSynthesis.addEventListener(Ml,a.t)}
function sk(a){(Sf(),$wnd.goog.global.window).speechSynthesis.removeEventListener(Ml,a.t)}
function Df(){Ef();var a=Cf;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ob(a){var b,c;for(c=new Og(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function sg(a,b){var c,d;for(d=new Bg(b.a);d.b;){c=Ag(d);if(!xg(a,c)){return false}}return true}
function Cg(a,b){var c,d;for(c=0,d=a.a.length;c<d;++c){if(lh(b,a.a[c])){return c}}return -1}
function Ug(a){var b,c,d;d=1;for(c=a.R();c._();){b=c.ab();d=31*d+(b!=null?s(b):0);d=d|0}return d}
function qi(a){var b;b=pi($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Af(a){var b;if(ad(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new qc(a);Nc(b)}return b}
function zg(a){if(a.a._()){return true}if(a.a!=a.c){return false}a.a=new Yg(a.d.a);return a.a._()}
function Hh(a){var b;Ch(a);b=new Wh;if(a.a.gb(b)){return oh(),new qh(ci(b.a))}return oh(),oh(),nh}
function qk(a){kb(a.a);R(a.e);R(a.b);R(a.j);$(a.h);$(a.g);$(a.c);$(a.d);$(a.k);$(a.i);$(a.f)}
function kb(a){if(2<(a.c&7)){u((J(),J(),I),new G(new zb(a)),67108864,null);!!a.a&&R(a.a);Gb(a.f);a.c=a.c&-8|1}}
function Fj(){if(!Ej){Ej=(++(J(),J(),I).e,new Fb);$wnd.Promise.resolve(null).then(Mf(Gj.prototype.K,Gj,[]))}}
function sh(a,b){if(0>a||a>b){throw Bf(new Tf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Jb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function vb(a,b,c){ub.call(this,null,a,b,c|(!a?262144:tl)|(0==(c&6291456)?!a?wl:4194304:0)|0|0|0)}
function gc(a,b,c){this.d=c?new Vg:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function Yf(){this.g=Vf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function Wg(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function Tg(a){var b,c,d;d=0;for(c=new Bg(a.a);c.b;){b=Ag(c);d=d+(b?mh(b.b.value[0])^mh(ih(b)):0);d=d|0}return d}
function rg(a,b){var c,d;for(d=a.R();d._();){c=d.ab();if(ed(b)===ed(c)||b!=null&&q(b,c)){return true}}return false}
function Wc(a,b,c,d,e){e.nb=a;e.ob=b;e.pb=Pf;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Gf(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function cb(a,b){var c,d;d=a.c;Kg(d,b);!!a.b&&tl!=(a.b.c&ul)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Wb((J(),c=Pb,c),a))}
function dc(a){var b,c;for(c=new Og(new Ng(new yg(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);ih(b).B()}}
function Vb(a){var b;if(a.c){while(!a.c.V()){b=a.c.db(a.c.W()-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&sb(b.b,3,true)}}}
function lk(a){var b,c;c=S(a.j);b=(gb(a.i),a.q);(null==b||!c.U(b))&&fc(new $k(a,ph(Hh(Gh(S(a.j).Y(),new il)))))}
function r(a){return dd(a)?Zd:cd(a)?Nd:bd(a)?Ld:_c(a)?a.nb:Uc(a)?a.nb:a.nb||Array.isArray(a)&&Qc(Ed,1)||Ed}
function s(a){return dd(a)?ki(a):cd(a)?fd(a):bd(a)?a?1231:1237:_c(a)?a.w():Uc(a)?ei(a):!!a&&!!a.hashCode?a.hashCode():ei(a)}
function Hb(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&tl)?Ib(a):mb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function Of(a){var b;if(Array.isArray(a)&&a.pb===Pf){return Xf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function ki(a){ii();var b,c,d;c=':'+a;d=hi[c];if(d!=null){return fd(d)}d=fi[c];b=d==null?ji(a):fd(d);li();hi[c]=b;return b}
function oi(a){var b,c;b=pi($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=(c={},c[Al]=a,c);return b}
function Kb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=M(d);return c}}return null}
function xc(){var a;if(sc!=0){a=rc();if(a-tc>2000){tc=a;uc=$wnd.setTimeout(Dc,10)}}if(sc++==0){Gc((Fc(),Ec));return true}return false}
function jg(a){var b;b=hg(a);if(b>3.4028234663852886E38){return Infinity}else if(b<-3.4028234663852886E38){return -Infinity}return b}
function Dj(){Bj();return Wc(Qc(Me,1),sl,5,0,[fj,gj,hj,ij,jj,kj,lj,mj,nj,oj,pj,qj,rj,sj,tj,uj,vj,wj,xj,yj,zj,Aj])}
function wb(a,b){ub.call(this,a,new xb(a),null,b|(tl==(b&ul)?0:524288)|(0==(b&6291456)?tl==(b&ul)?4194304:wl:0)|0|268435456|0)}
function eg(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Rg(a,b){var c,d;d=a.a.length;b.length<d&&(b=bi(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function tg(a,b){var c,d,e,f;f=a.W();b.length<f&&(b=bi(new Array(f),b));e=b;d=a.R();for(c=0;c<f;++c){e[c]=d.ab()}b.length>f&&(b[f]=null);return b}
function Oc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return dd(a)?o(a,b):cd(a)?a===b:bd(a)?ed(a)===ed(b):_c(a)?a.u(b):Uc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):ed(a)===ed(b)}
function gk(a){this.e=new Nk;this.c=a;J();++ek;this.b=new gc(new hk(this),new ik(this),false);this.a=new vb(null,new kk(this),1411518464)}
function W(a,b,c,d){this.c=a;this.g=b;this.h=c;this.j=null;this.i=16384==(d&16384);this.f=new wb(this,d&-16385);this.e=new ib(this.f);tl==(d&ul)&&lb(this.f)}
function $c(a,b){if(dd(a)){return !!Zc[b]}else if(a.ob){return !!a.ob[b]}else if(cd(a)){return !!Yc[b]}else if(bd(a)){return !!Xc[b]}return false}
function vi(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function M(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function S(a){a.i?gb(a.e):fb(a.e);if(tb(a.f)){if(a.i&&(J(),!(!!Pb&&!!Pb.e))){return u((J(),J(),I),new X(a),83888128,null)}else{mb(a.f)}}return V(a)}
function Yb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Og(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&sb(b,6,true)}}}
function Zb(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Og(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&sb(b,5,true)}}}
function Xb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Og(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?sb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Tc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{_b(b,d);try{f=(c.a.B(),null)}finally{ac()}return f}catch(a){a=Af(a);if(ad(a,4)){e=a;throw Bf(e)}else throw Bf(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Pb){g=c.A()}else{_b(b,e);try{g=c.A()}finally{ac()}}return g}catch(a){a=Af(a);if(ad(a,4)){f=a;throw Bf(f)}else throw Bf(a)}finally{D(b)}}
function Bb(a){var b,c;if(0==a.c){b=Lb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Kb(a.d);Hb(c);return true}
function Ff(b,c,d,e){Ef();var f=Cf;$moduleName=c;$moduleBase=d;zf=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{rl(g)()}catch(a){b(c,a)}}else{rl(g)()}}
function pi(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function ah(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return bh()}}
function If(){Hf={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Kc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].qb()&&(c=Jc(c,g)):g[0].qb()}catch(a){a=Af(a);if(ad(a,4)){d=a;vc();Bc(ad(d,31)?d.J():d)}else throw Bf(a)}}return c}
function Q(b){var c,d,e;e=b.j;try{d=b.c.A();if(!(ed(e)===ed(d)||e!=null&&q(e,d))){b.j=d;b.b=null;db(b.e)}}catch(a){a=Af(a);if(ad(a,8)){c=a;if(!b.b){b.j=null;b.b=c;db(b.e)}throw Bf(c)}else throw Bf(a)}}
function Zh(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Hj(a){var b,c,d,e;c=Lk(a.e);if(0!=c&&null!=a.f){b=(Sf(),Rf);e=b.createRange();d=Mk(a.e);e.setStart(a.f.firstChild,d);e.setEnd(a.f.firstChild,d+c);return e.getBoundingClientRect()}else{return null}}
function hg(a){gg==null&&(gg=new RegExp('^\\s*[+-]?(NaN|Infinity|((\\d+\\.?\\d*)|(\\.\\d+))([eE][+-]?\\d+)?[dDfF]?)\\s*$'));if(!gg.test(a)){throw Bf(new mg('For input string: "'+a+'"'))}return parseFloat(a)}
function ji(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+ng(a,c++)}b=b|0;return b}
function O(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Sc(Xd,sl,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function mb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((J(),J(),I),b,c)}else{dk(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Af(a);if(ad(a,4)){J()}else throw Bf(a)}}}
function ub(a,b,c,d){this.b=new Mg;this.f=new Jb(new yb(this),d&6520832|262144|tl);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((J(),J(),I),this),0==(this.f.a&wl)&&D((null,I)))}
function Kf(a,b,c){var d=Hf,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Hf[b]),Nf(h));_.ob=c;!b&&(_.pb=Pf);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.nb=f)}
function dg(a){if(a.P()){var b=a.c;b.Q()?(a.j='['+b.i):!b.P()?(a.j='[L'+b.N()+';'):(a.j='['+b.N());a.b=b.M()+'[]';a.h=b.O()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=eg('.',[c,eg('$',d)]);a.b=eg('.',[c,eg('.',d)]);a.h=d[d.length-1]}
function ug(a,b){var c,d,e,f,g;e=b.b.value[0];g=ih(b);f=e==null?vg(Wg((d=a.a.a.get(0),d==null?new Array:d))):fh(a.b,e);if(!(ed(g)===ed(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!Wg((c=a.a.a.get(0),c==null?new Array:c)):eh(a.b,e))){return false}return true}
function tb(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Og(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{S(c)}catch(a){a=Af(a);if(!ad(a,4))throw Bf(a)}if(6==(b.c&7)){return true}}}}}ob(b);return false}
function mk(a,b){var c;c=b.type;if(!o(Ll,c)){U(a.e);U(a.b)}if((o('error',c)||o('end',c))&&(Sf(),$wnd.goog.global.window).speechSynthesis.paused){(Sf(),$wnd.goog.global.window).speechSynthesis.cancel()}else if(o(Ll,c)&&o(b.name,'word')){fc(new Vk(a,b.charIndex));fc(new Wk(a,b.charLength))}}
function ri(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ni(b,Mf(ui.prototype.jb,ui,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[Al]=c[0],undefined):(d[Al]=c,undefined));return g=pi($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function jc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.H();return a&&a.F()}},suppressed:{get:function(){return c.G()}}})}catch(a){}}}
function _g(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function sb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(!!a.a&&4==g&&(6==b||5==b)){hb(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((J(),J(),I),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;rb((e=d.h,e));d.j=null}Gg(a.b,new Ab(a));a.b.a=Sc(Xd,sl,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&rb((f=a.a.g,f))}}
function Bj(){Bj=Lf;fj=new Cj(Bl,0);gj=new Cj('checkbox',1);hj=new Cj('color',2);ij=new Cj('date',3);jj=new Cj('datetime',4);kj=new Cj('email',5);lj=new Cj('file',6);mj=new Cj('hidden',7);nj=new Cj('image',8);oj=new Cj('month',9);pj=new Cj('number',10);qj=new Cj('password',11);rj=new Cj('radio',12);sj=new Cj('range',13);tj=new Cj('reset',14);uj=new Cj('search',15);vj=new Cj('submit',16);wj=new Cj('tel',17);xj=new Cj('text',18);yj=new Cj('time',19);zj=new Cj('url',20);Aj=new Cj('week',21)}
function nk(a){var b,c;fc(new Vk(a,0));fc(new Wk(a,0));c=new $wnd.SpeechSynthesisUtterance((gb(a.f),a.n));c.voice=(gb(a.i),a.q);c.volume=(gb(a.k),a.r);c.pitch=(gb(a.c),a.l);b=(gb(a.d),a.m);c.rate=$wnd.Math.pow($wnd.Math.abs(b)+1,b<0?-1:1);c.addEventListener('start',new kl(a));c.addEventListener('end',new ll(a));c.addEventListener('error',new ml(a));c.addEventListener(Ll,new nl(a));c.addEventListener('pause',new ol(a));c.addEventListener('resume',new pl(a));(Sf(),$wnd.goog.global.window).speechSynthesis.speak(c)}
function Sb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Hg(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Lg(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{cb(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&sb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Hg(a.b,g);if(-1==k.e){k.e=0;bb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Jg(a.b,g)}e&&qb(a.e,a.b)}else{e&&qb(a.e,new Mg)}if(Z(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&tl!=(k.b.c&ul)&&k.c.a.length<=0&&0==k.b.a.d&&Wb(a,k)}}
function Nk(){var a,b,c,d,e,f,g,h,i,j,k,l,m,n;this.t=new jl(this);J();++pk;this.s=new gc(null,new Ok(this),true);this.l=0.5;this.m=0;this.r=1;this.n='Call me Ishmael. Some years ago, never mind how long precisely, having little or no money in my purse, and nothing particular to interest me on shore, I thought I would sail about a little and see the watery part of the world.';this.h=(i=new ib((b=null,b)),i);this.g=(j=new ib((c=null,c)),j);this.c=(k=new ib((d=null,d)),k);this.d=(l=new ib((e=null,e)),l);this.k=(m=new ib((f=null,f)),m);this.i=(n=new ib((g=null,g)),n);this.f=(h=new ib((a=null,a)),h);this.e=new W(new Rk,null,null,35667968);this.b=new W(new Sk,null,null,35667968);this.j=new W(new Tk,new Pk(this),new Qk(this),35651584);this.a=new vb(new Uk(this),null,413138944);D((null,I))}
function bh(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!_g()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function ck(a){var b,c,d,e,f;a.d=0;Fj();b=(c=Dk(a.e),ri(Cl,vi(new $wnd.Object,Wc(Qc(Zd,1),sl,2,6,[S(a.e.e)?'speaking':null])),[ri('h1',null,['Web Speech Synthesis Demo']),ri('form',null,[ri(Cl,wi(new $wnd.Object,'textarea'),[S(a.e.e)?oi([ri(Cl,wi(yi(new $wnd.Object,Mf(Qj.prototype.C,Qj,[a])),'textbeingspoken'),[Ck(a.e)]),ri(Cl,zi(new $wnd.Object,(d=Hj(a),e=(Sf(),Rf).body,f=Lk(a.e),Gi(Li(Hi(Ji(Ki(Fi(Ei(Ii(new $wnd.Object)),0==f?'none':'block'),0==f?'all 0s ease 0s':'all 50ms ease'),null==d?'0':d.top-1+e.clientHeight-e.scrollHeight+8+'px'),null==d?'0':d.left-1+e.clientWidth-e.scrollWidth-8+'px'),null==d?'0':d.width+'px'),null==d?'0':d.height+'px'))),null)]):ri('textarea',Pi(Bi(Si(new $wnd.Object,Ck(a.e)),S(a.e.e)),Mf(Rj.prototype.kb,Rj,[a])),null)]),ri(Cl,vi(new $wnd.Object,Wc(Qc(Zd,1),sl,2,6,[Dl])),[ri(El,Ti(new $wnd.Object,'pitch'),['Pitch']),ri('input',Pi(Bi(Qi(Ni(Oi(Si(Di(wi(new $wnd.Object,'pitch'),(Bj(),sj)),''+Ak(a.e)),'0'),'1'),'0.05'),S(a.e.e)),Mf(Wj.prototype.kb,Wj,[a])),null),ri(Bl,Ci(Bi(Ai(xi(Di(new $wnd.Object,(cj(),_i)),Fl),Fl),S(a.e.e)),Mf(Xj.prototype.lb,Xj,[a])),[Gl])]),ri(Cl,vi(new $wnd.Object,Wc(Qc(Zd,1),sl,2,6,[Dl])),[ri(El,Ti(new $wnd.Object,'rate'),['Rate']),ri('input',Pi(Bi(Qi(Ni(Oi(Si(Di(wi(new $wnd.Object,'rate'),sj),''+Bk(a.e)),'-3'),'3'),'0.25'),S(a.e.e)),Mf(Yj.prototype.kb,Yj,[a])),null),ri(Bl,Ci(Bi(Ai(xi(Di(new $wnd.Object,_i),Hl),Hl),S(a.e.e)),Mf(Zj.prototype.lb,Zj,[a])),[Gl])]),ri(Cl,vi(new $wnd.Object,Wc(Qc(Zd,1),sl,2,6,[Dl])),[ri(El,Ti(new $wnd.Object,'volume'),['Volume']),ri('input',Pi(Bi(Qi(Ni(Oi(Si(Di(wi(new $wnd.Object,'volume'),sj),''+Ek(a.e)),'0'),'1'),'0.05'),S(a.e.e)),Mf($j.prototype.kb,$j,[a])),null),ri(Bl,Ci(Bi(Ai(xi(Di(new $wnd.Object,_i),Il),Il),S(a.e.e)),Mf(_j.prototype.lb,_j,[a])),[Gl])]),ri(Cl,vi(new $wnd.Object,Wc(Qc(Zd,1),sl,2,6,[Dl])),[ri(El,Ti(new $wnd.Object,'voice'),['Voice']),ri('select',Si(Bi(Pi(new $wnd.Object,Mf(Oj.prototype.kb,Oj,[a])),S(a.e.e)),null==c?'':c.voiceURI),Kh(Ih(S(a.e.j).Y(),new Pj),new ti)),ri(Bl,Ci(Bi(Ai(xi(Di(new $wnd.Object,_i),Jl),Jl),S(a.e.e)),Mf(Sj.prototype.lb,Sj,[a])),[Gl])]),ri(Cl,vi(new $wnd.Object,Wc(Qc(Zd,1),sl,2,6,['bottom'])),[ri(Bl,Ci(Bi(Ai(xi(vi(Di(new $wnd.Object,_i),Wc(Qc(Zd,1),sl,2,6,['small'])),'Speak'),'Speak'),S(a.e.e)),Mf(Tj.prototype.lb,Tj,[a])),['Speak']),ri(Bl,Ci(Bi(Ai(xi(vi(Di(new $wnd.Object,_i),Wc(Qc(Zd,1),sl,2,6,['small'])),S(a.e.b)?Kl:'Pause'),S(a.e.b)?Kl:'Pause'),!S(a.e.e)),Mf(Uj.prototype.lb,Uj,[a])),[S(a.e.b)?Kl:'Pause']),ri(Bl,Ci(Bi(Ai(xi(vi(Di(new $wnd.Object,_i),Wc(Qc(Zd,1),sl,2,6,['small'])),'Stop'),'Stop'),!S(a.e.e)),Mf(Vj.prototype.lb,Vj,[])),['Stop'])])])]));return b}
var sl={3:1},tl=1048576,ul=1835008,vl={10:1},wl=2097152,xl='__noinit__',yl={3:1,8:1,6:1,4:1},zl={3:1,35:1,60:1},Al='children',Bl='button',Cl='div',Dl='speecharg',El='label',Fl='Reset pitch',Gl='\u21B6',Hl='Reset rate',Il='Reset volume',Jl='Reset voice',Kl='Resume',Ll='boundary',Ml='voiceschanged',Nl=142606336;var _,Hf,Cf,zf=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;If();Kf(1,null,{},p);_.u=function(a){return o(this,a)};_.v=function(){return this.nb};_.w=Ol;_.equals=function(a){return this.u(a)};_.hashCode=function(){return this.w()};var Xc,Yc,Zc;Kf(44,1,{},Yf);_.L=function(a){var b;b=new Yf;b.e=4;a>1?(b.c=bg(this,a-1)):(b.c=this);return b};_.M=function(){Wf(this);return this.b};_.N=function(){return Xf(this)};_.O=function(){Wf(this);return this.h};_.P=function(){return (this.e&4)!=0};_.Q=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Vf=1;var Xd=$f(1);var Md=$f(44);Kf(99,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var kd=$f(99);Kf(37,1,{},G);_.A=function(){return this.a.B(),null};var hd=$f(37);Kf(100,1,{},H);var jd=$f(100);var I;Kf(41,1,{41:1},P);_.b=0;_.c=false;_.d=0;var ld=$f(41);Kf(161,1,{});var od=$f(161);Kf(39,161,{},W);_.a=false;_.d=0;_.i=false;var nd=$f(39);Kf(109,1,{},X);_.A=function(){return T(this.a)};var md=$f(109);Kf(13,161,{13:1},ib);_.a=4;_.d=false;_.e=0;var qd=$f(13);Kf(108,1,vl,jb);_.B=function(){ab(this.a)};var pd=$f(108);Kf(20,161,{20:1},vb,wb);_.c=0;var vd=$f(20);Kf(102,1,{},xb);_.B=function(){Q(this.a)};var rd=$f(102);Kf(103,1,vl,yb);_.B=function(){mb(this.a)};var sd=$f(103);Kf(104,1,vl,zb);_.B=function(){pb(this.a)};var td=$f(104);Kf(105,1,{},Ab);_.C=function(a){nb(this.a,a)};var ud=$f(105);Kf(138,1,{},Db);_.a=0;_.b=0;_.c=0;var wd=$f(138);Kf(119,1,{},Fb);_.a=false;var xd=$f(119);Kf(54,161,{54:1},Jb);_.a=0;var zd=$f(54);Kf(137,1,{},Ob);var yd=$f(137);Kf(122,1,{},$b);_.a=0;var Pb;var Ad=$f(122);Kf(50,1,{},gc);_.g=0;var Cd=$f(50);Kf(101,1,vl,hc);_.B=function(){ec(this.a)};var Bd=$f(101);Kf(4,1,{3:1,4:1});_.D=function(a){return new Error(a)};_.F=Pl;_.G=function(){return Kh(Ih(Qg((this.e==null&&(this.e=Sc(_d,sl,4,0,0,1)),this.e)),new pg),new Oh)};_.H=function(){return this.c};_.I=function(){kc(this,mc(this.D(lc(this,this.d))));Nc(this)};_.b=xl;_.f=true;var _d=$f(4);Kf(8,4,{3:1,8:1,4:1});var Pd=$f(8);Kf(6,8,yl);var Yd=$f(6);Kf(46,6,yl);var Td=$f(46);Kf(71,46,yl);var Gd=$f(71);Kf(31,71,{31:1,3:1,8:1,6:1,4:1},qc);_.J=function(){return ed(this.a)===ed(oc)?null:this.a};var oc;var Dd=$f(31);var Ed=$f(0);Kf(144,1,{});var Fd=$f(144);var sc=0,tc=0,uc=-1;Kf(79,144,{},Ic);var Ec;var Hd=$f(79);var Lc;Kf(156,1,{});var Jd=$f(156);Kf(72,156,{},Pc);var Id=$f(72);var Rf;Kf(74,6,yl);var Sd=$f(74);Kf(106,74,yl,Tf);var Kd=$f(106);Xc={3:1,67:1,30:1};var Ld=$f(67);Kf(154,1,sl);var gg;var Wd=$f(154);Yc={3:1,30:1};var Nd=$f(155);Kf(22,1,{3:1,30:1,22:1});_.u=function(a){return this===a};_.w=Ol;_.b=0;var Od=$f(22);Kf(45,6,yl);var Qd=$f(45);Kf(73,6,yl,kg);var Rd=$f(73);Kf(221,1,{});Kf(75,46,yl,lg);_.D=function(a){return new TypeError(a)};var Ud=$f(75);Kf(68,45,yl,mg);var Vd=$f(68);Zc={3:1,66:1,30:1,2:1};var Zd=$f(2);Kf(225,1,{});Kf(63,1,{},pg);_.S=function(a){return a.b};var $d=$f(63);Kf(36,6,yl,qg);var ae=$f(36);Kf(157,1,{35:1});_.X=function(){return new zh(this,0)};_.Y=function(){return new Lh(null,this.X())};_.T=function(a){throw Bf(new qg('Add not supported on this collection'))};_.U=function(a){return rg(this,a)};_.V=function(){return this.W()==0};_.Z=function(a){return tg(this,a)};var be=$f(157);Kf(160,1,{141:1});_.u=function(a){var b,c,d;if(a===this){return true}if(!ad(a,38)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new Bg((new yg(d)).a);c.b;){b=Ag(c);if(!ug(this,b)){return false}}return true};_.w=function(){return Tg(new yg(this))};var ie=$f(160);Kf(107,160,{141:1});var ee=$f(107);Kf(159,157,{35:1,166:1});_.X=function(){return new zh(this,1)};_.u=function(a){var b;if(a===this){return true}if(!ad(a,21)){return false}b=a;if(wg(b.a)!=this.W()){return false}return sg(this,b)};_.w=function(){return Tg(this)};var je=$f(159);Kf(21,159,{21:1,35:1,166:1},yg);_.U=function(a){return xg(this,a)};_.R=function(){return new Bg(this.a)};_.W=function(){return wg(this.a)};var de=$f(21);Kf(24,1,{},Bg);_.$=Ql;_.ab=function(){return Ag(this)};_._=Pl;_.b=false;var ce=$f(24);Kf(158,157,{35:1,60:1});_.X=function(){return new zh(this,16)};_.bb=function(a,b){throw Bf(new qg('Add not supported on this list'))};_.T=function(a){this.bb(this.W(),a);return true};_.u=function(a){var b,c,d,e,f;if(a===this){return true}if(!ad(a,60)){return false}f=a;if(this.W()!=f.W()){return false}e=f.R();for(c=this.R();c._();){b=c.ab();d=e.ab();if(!(ed(b)===ed(d)||b!=null&&q(b,d))){return false}}return true};_.w=function(){return Ug(this)};_.R=function(){return new Dg(this)};_.db=function(a){throw Bf(new qg('Remove not supported on this list'))};var ge=$f(158);Kf(78,1,{},Dg);_.$=Ql;_._=function(){return this.a<this.b.W()};_.ab=function(){return this.a<this.b.W(),this.b.cb(this.a++)};_.a=0;var fe=$f(78);Kf(162,1,{167:1});_.u=function(a){var b;if(!ad(a,32)){return false}b=a;return lh(this.b.value[0],b.b.value[0])&&lh(ih(this),ih(b))};_.w=function(){return mh(this.b.value[0])^mh(ih(this))};var he=$f(162);Kf(12,158,zl,Mg,Ng);_.bb=function(a,b){$h(this.a,a,b)};_.T=function(a){return Fg(this,a)};_.U=function(a){return Ig(this,a,0)!=-1};_.cb=function(a){return Hg(this,a)};_.V=function(){return this.a.length==0};_.R=function(){return new Og(this)};_.db=function(a){return Jg(this,a)};_.W=Rl;_.Z=function(a){var b,c;c=this.a.length;a.length<c&&(a=bi(new Array(c),a));for(b=0;b<c;++b){a[b]=this.a[b]}a.length>c&&(a[c]=null);return a};var le=$f(12);Kf(15,1,{},Og);_.$=Ql;_._=function(){return this.a<this.c.a.length};_.ab=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ke=$f(15);Kf(77,158,zl,Sg);_.U=function(a){return Cg(this,a)!=-1};_.cb=function(a){return this.a[a]};_.W=Rl;_.Z=function(a){return Rg(this,a)};var me=$f(77);Kf(38,107,{3:1,38:1,141:1},Vg);var ne=$f(38);Kf(121,1,{},Xg);_.R=function(){return new Yg(this)};_.b=0;var pe=$f(121);Kf(53,1,{},Yg);_.$=Ql;_.ab=function(){return this.d=this.a[this.c++],this.d};_._=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var oe=$f(53);var Zg;Kf(120,1,{},gh);_.R=function(){return new hh(this)};_.b=0;_.c=0;var se=$f(120);Kf(52,1,{},hh);_.$=Ql;_.ab=function(){return this.c=this.a,this.a=this.b.next(),new jh(this.d,this.c,this.d.c)};_._=function(){return !this.a.done};var qe=$f(52);Kf(32,162,{32:1,167:1},jh);_.c=0;var re=$f(32);Kf(33,1,{33:1},qh);_.u=function(a){var b;if(a===this){return true}if(!ad(a,33)){return false}b=a;return lh(this.a,b.a)};_.w=function(){return mh(this.a)};var nh;var te=$f(33);Kf(85,1,{});_.$=Sl;_.eb=function(){return this.d};_.fb=function(){return this.e};_.d=0;_.e=0;var xe=$f(85);Kf(48,85,{});var ue=$f(48);Kf(80,1,{});_.$=Sl;_.eb=Pl;_.fb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var we=$f(80);Kf(81,80,{},xh);_.$=function(a){uh(this,a)};_.gb=function(a){return vh(this,a)};var ve=$f(81);Kf(19,1,{},zh);_.eb=function(){return this.a};_.fb=function(){yh(this);return this.c};_.$=function(a){yh(this);this.d.$(a)};_.gb=function(a){yh(this);if(this.d._()){a.C(this.d.ab());return true}return false};_.a=0;_.c=0;var ye=$f(19);Kf(65,1,{},Ah);_.S=function(a){return a};var ze=$f(65);Kf(139,1,{},Bh);var Ae=$f(139);Kf(84,1,{});_.c=false;var Je=$f(84);Kf(23,84,{},Lh);var Ie=$f(23);Kf(64,1,{},Oh);_.hb=function(a){return Sc(Xd,sl,1,a,5,1)};var Be=$f(64);Kf(87,48,{},Qh);_.gb=function(a){this.b=false;while(!this.b&&this.c.gb(new Rh(this,a)));return this.b};_.b=false;var De=$f(87);Kf(89,1,{},Rh);_.C=function(a){Ph(this.a,this.b,a)};var Ce=$f(89);Kf(86,48,{},Th);_.gb=function(a){return this.b.gb(new Uh(this,a))};var Fe=$f(86);Kf(88,1,{},Uh);_.C=function(a){Sh(this.a,this.b,a)};var Ee=$f(88);Kf(49,1,{},Wh);_.C=function(a){Vh(this,a)};var Ge=$f(49);Kf(90,1,{},Yh);_.C=function(a){Xh(this,a)};var He=$f(90);Kf(223,1,{});Kf(220,1,{});var di=0;var fi,gi=0,hi;Kf(826,1,{});Kf(851,1,{});Kf(118,1,{},ti);_.hb=function(a){return new Array(a)};var Ke=$f(118);Kf(204,$wnd.Function,{},ui);_.jb=function(a){si(this.a,this.b,a)};Kf(25,22,{3:1,30:1,22:1,25:1},dj);var _i,aj,bj;var Le=_f(25,ej);Kf(5,22,{3:1,30:1,22:1,5:1},Cj);var fj,gj,hj,ij,jj,kj,lj,mj,nj,oj,pj,qj,rj,sj,tj,uj,vj,wj,xj,yj,zj,Aj;var Me=_f(5,Dj);var Ej;Kf(205,$wnd.Function,{},Gj);_.K=function(a){return Eb(Ej),Ej=null,null};Kf(92,1,{});var Pe=$f(92);Kf(194,$wnd.Function,{},Oj);_.kb=function(a){Nj(this.a,a)};Kf(83,1,{},Pj);_.S=function(a){return ri('option',Si(new $wnd.Object,a.voiceURI),[a.name+' ('+a.lang+')'])};var Ne=$f(83);Kf(184,$wnd.Function,{},Qj);_.C=function(a){Ij(this.a,a)};Kf(186,$wnd.Function,{},Rj);_.kb=function(a){Jj(this.a,a)};Kf(195,$wnd.Function,{},Sj);_.lb=function(a){Ik(this.a.e)};Kf(196,$wnd.Function,{},Tj);_.lb=function(a){nk(this.a.e)};Kf(197,$wnd.Function,{},Uj);_.lb=function(a){S(this.a.e.b)?(Sf(),$wnd.goog.global.window).speechSynthesis.resume():(Sf(),$wnd.goog.global.window).speechSynthesis.pause()};Kf(198,$wnd.Function,{},Vj);_.lb=function(a){(Sf(),$wnd.goog.global.window).speechSynthesis.cancel()};Kf(187,$wnd.Function,{},Wj);_.kb=function(a){Kj(this.a,a)};Kf(188,$wnd.Function,{},Xj);_.lb=function(a){fc(new Xk(this.a.e,0.5))};Kf(189,$wnd.Function,{},Yj);_.kb=function(a){Lj(this.a,a)};Kf(190,$wnd.Function,{},Zj);_.lb=function(a){fc(new Yk(this.a.e,0))};Kf(191,$wnd.Function,{},$j);_.kb=function(a){Mj(this.a,a)};Kf(192,$wnd.Function,{},_j);_.lb=function(a){fc(new Zk(this.a.e,1))};Kf(62,1,{},ak);var Oe=$f(62);Kf(93,92,{});_.d=0;var of=$f(93);Kf(94,93,{},gk);var ek=0;var Ue=$f(94);Kf(95,1,vl,hk);_.B=function(){Y(this.a.e)};var Qe=$f(95);Kf(96,1,vl,ik);_.B=function(){kb(this.a.a)};var Re=$f(96);Kf(98,1,{},jk);_.A=function(){return ck(this.a)};var Se=$f(98);Kf(97,1,{},kk);_.B=function(){dk(this.a)};var Te=$f(97);Kf(123,1,{});var yf=$f(123);Kf(124,123,{},Nk);_.l=0;_.m=0;_.o=0;_.p=0;_.r=0;var pk=0;var mf=$f(124);Kf(125,1,vl,Ok);_.B=function(){qk(this.a)};var Ve=$f(125);Kf(129,1,{},Pk);_.B=function(){rk(this.a)};var We=$f(129);Kf(130,1,{},Qk);_.B=function(){sk(this.a)};var Xe=$f(130);Kf(126,1,{},Rk);_.A=function(){return Uf(),(Sf(),$wnd.goog.global.window).speechSynthesis.speaking?true:false};var Ye=$f(126);Kf(127,1,{},Sk);_.A=function(){return Uf(),(Sf(),$wnd.goog.global.window).speechSynthesis.paused?true:false};var Ze=$f(127);Kf(128,1,{},Tk);_.A=function(){var a;return a=(Sf(),$wnd.goog.global.window).speechSynthesis.getVoices(),new Sg(bi(a,Vc(a.length)))};var $e=$f(128);Kf(131,1,{},Uk);_.B=function(){lk(this.a)};var _e=$f(131);Kf(55,1,vl,Vk);_.B=function(){xk(this.a,this.b)};_.b=0;var af=$f(55);Kf(56,1,vl,Wk);_.B=function(){wk(this.a,this.b)};_.b=0;var bf=$f(56);Kf(57,1,vl,Xk);_.B=function(){tk(this.a,this.b)};_.b=0;var cf=$f(57);Kf(58,1,vl,Yk);_.B=function(){uk(this.a,this.b)};_.b=0;var df=$f(58);Kf(59,1,vl,Zk);_.B=function(){zk(this.a,this.b)};_.b=0;var ef=$f(59);Kf(40,1,vl,$k);_.B=function(){yk(this.a,this.b)};var ff=$f(40);Kf(132,1,vl,_k);_.B=function(){vk(this.a,this.b)};var gf=$f(132);Kf(133,1,vl,al);_.B=function(){U(this.a)};var hf=$f(133);Kf(134,1,vl,bl);_.B=function(){mk(this.a,this.b)};var jf=$f(134);Kf(135,1,vl,cl);_.B=function(){Fk(this.a)};var kf=$f(135);Kf(136,1,vl,dl);_.B=function(){Gk(this.a,this.b)};var lf=$f(136);Kf(199,$wnd.Function,{},el);_.mb=function(a){return new hl(a)};var fl;Kf(82,$wnd.React.Component,{},hl);Jf(Hf[1],_);_.componentDidMount=function(){(Sf(),$wnd.goog.global.window).speechSynthesis.cancel()};_.componentWillUnmount=function(){bk(this.a)};_.render=function(){return fk(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var nf=$f(82);Kf(51,1,{},il);_.ib=function(a){return a.default};var pf=$f(51);Kf(110,1,{},jl);_.handleEvent=function(a){Kk(this.a.j)};var qf=$f(110);Kf(111,1,{},kl);_.handleEvent=Tl;var rf=$f(111);Kf(112,1,{},ll);_.handleEvent=Tl;var sf=$f(112);Kf(113,1,{},ml);_.handleEvent=Tl;var tf=$f(113);Kf(114,1,{},nl);_.handleEvent=Tl;var uf=$f(114);Kf(115,1,{},ol);_.handleEvent=Tl;var vf=$f(115);Kf(116,1,{},pl);_.handleEvent=Tl;var wf=$f(116);Kf(117,1,{},ql);_.ib=function(a){return ok(this.a,a)};var xf=$f(117);var gd=ag('D');var rl=(vc(),yc);var gwtOnLoad=gwtOnLoad=Ff;Df(Qf);Gf('permProps',[[]]);if (webspeechdemo) webspeechdemo.onScriptLoad(gwtOnLoad);})();