function webspeechdemo(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='webspeechdemo',tb='__gwt_marker_webspeechdemo',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='D29758E91ED9A275E0E387C3C1D7E66D',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};webspeechdemo.onScriptLoad=function(a){webspeechdemo=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
webspeechdemo();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'D29758E91ED9A275E0E387C3C1D7E66D';function p(){}
function Pf(){}
function Lf(){}
function Gb(){}
function Jc(){}
function Qc(){}
function ng(){}
function yh(){}
function Mh(){}
function Uh(){}
function ri(){}
function _i(){}
function ij(){}
function oj(){}
function kk(){}
function lk(){}
function mk(){}
function zk(){}
function Jk(){}
function Oc(a){Nc()}
function Uf(){Uf=Lf}
function rb(a,b){a.b=b}
function Th(a,b){a.a=b}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function ic(a){this.a=a}
function wg(a){this.a=a}
function Qg(a){this.a=a}
function Bg(a){this.b=a}
function Mg(a){this.c=a}
function zh(a){this.a=a}
function Wh(a){this.a=a}
function hj(a){this.a=a}
function jj(a){this.a=a}
function kj(a){this.a=a}
function lj(a){this.a=a}
function mj(a){this.a=a}
function nj(a){this.a=a}
function pj(a){this.a=a}
function qj(a){this.a=a}
function rj(a){this.a=a}
function sj(a){this.a=a}
function tj(a){this.a=a}
function uj(a){this.a=a}
function Cj(a){this.a=a}
function Dj(a){this.a=a}
function Ej(a){this.a=a}
function Fj(a){this.a=a}
function Fk(a){this.a=a}
function hk(a){this.a=a}
function ik(a){this.a=a}
function jk(a){this.a=a}
function nk(a){this.a=a}
function vk(a){this.a=a}
function xk(a){this.a=a}
function Dk(a){this.a=a}
function Ek(a){this.a=a}
function Gk(a){this.a=a}
function Hk(a){this.a=a}
function Ik(a){this.a=a}
function Kk(a){this.a=a}
function Lk(a){this.a=a}
function Zk(a){this.a=a}
function $k(a){this.a=a}
function al(a){this.a=a}
function cl(a){this.a=a}
function Vg(){this.a=ah()}
function eh(){this.a=ah()}
function Kg(){Cg(this)}
function El(a){ih(this,a)}
function Gl(a){ph(this,a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function w(a){--a.e;D(a)}
function dc(a){!!a&&a.D()}
function Z(a){!!a&&cc(a.s)}
function L(a,b){P(a);M(a,b)}
function li(a,b){ki(a,b)}
function Vh(a,b){Lh(a.a,b)}
function C(a,b){Ob(a.f,b.f)}
function bj(a,b){return a.f=b}
function Bf(a){return a.b}
function Dl(){return this.b}
function Hl(a){ak(this.a,a)}
function oh(a){mh();this.a=a}
function og(a){oc.call(this,a)}
function kg(a){oc.call(this,a)}
function Tf(a){oc.call(this,a)}
function wj(a){a.d=2;cc(a.b)}
function lc(a,b){a.b=b;kc(a,b)}
function Ok(a,b){Uk(a);M(a,b)}
function $h(a,b){a.splice(b,1)}
function uh(a,b,c){b.G(a.a[c])}
function Fg(a,b){return a.a[b]}
function Rc(a,b){return ag(a,b)}
function Xf(a){Wf(a);return a.j}
function ah(){Yg();return new Xg}
function K(){K=Lf;J=new F}
function qc(){qc=Lf;pc=new p}
function Gc(){Gc=Lf;Fc=new Jc}
function Yg(){Yg=Lf;Xg=$g()}
function wc(){wc=Lf;!!(Nc(),Mc)}
function Ef(){Cf==null&&(Cf=[])}
function jg(){jc(this);this.L()}
function U(a){nb(a.f);return W(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function bb(a){K();Zb(a);a.e=-2}
function Lh(a,b){Th(a,Kh(a.a,b))}
function ph(a,b){while(a.jb(b));}
function Qh(a,b,c){b.G(a.a.V(c))}
function v(a,b,c){t(a,new I(c),b)}
function Kh(a,b){a.W(b);return a}
function ui(a,b){a.id=b;return a}
function Mi(a,b){a.min=b;return a}
function Li(a,b){a.max=b;return a}
function wi(a,b){a.ref=b;return a}
function Hi(a,b){a.top=b;return a}
function Bi(a){a.type=ql;return a}
function Vj(a){hb(a.c);return a.l}
function Wj(a){hb(a.d);return a.m}
function Xj(a){hb(a.f);return a.n}
function Yj(a){hb(a.i);return a.q}
function Zj(a){hb(a.k);return a.r}
function ek(a){hb(a.g);return a.o}
function fk(a){hb(a.h);return a.p}
function Fi(a,b){a.left=b;return a}
function Oi(a,b){a.step=b;return a}
function si(a,b){this.a=a;this.b=b}
function Ph(a,b){this.a=a;this.b=b}
function Sh(a,b){this.a=a;this.b=b}
function ok(a,b){this.a=a;this.b=b}
function pk(a,b){this.a=a;this.b=b}
function qk(a,b){this.a=a;this.b=b}
function rk(a,b){this.a=a;this.b=b}
function sk(a,b){this.a=a;this.b=b}
function tk(a,b){this.a=a;this.b=b}
function uk(a,b){this.a=a;this.b=b}
function wk(a,b){this.a=a;this.b=b}
function yk(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function vj(){this.a=oi((Bk(),Ak))}
function Ec(){tc!=0&&(tc=0);vc=-1}
function ug(a){return a.a.b+a.b.b}
function dh(a,b){return a.a.get(b)}
function bl(a,b){return Nk(a.a,b)}
function o(a,b){return ed(a)===ed(b)}
function tg(a){return !a?null:gh(a)}
function Ub(a){return !a.d?a:Ub(a.d)}
function Fl(){return this.a.length}
function ed(a){return a==null?null:a}
function kh(a){return a!=null?s(a):0}
function Dc(a){$wnd.clearTimeout(a)}
function xi(a,b){a.style=b;return a}
function yi(a,b){a.title=b;return a}
function Ji(a,b){a.width=b;return a}
function Qi(a,b){a.value=b;return a}
function Ei(a,b){a.height=b;return a}
function Ai(a,b){a.onClick=b;return a}
function Ri(a,b){a.htmlFor=b;return a}
function Di(a,b){a.display=b;return a}
function Yh(a,b,c){a.splice(b,0,c)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function fl(a){return bl((el(),dl),a)}
function Cg(a){a.a=Tc(Xd,il,1,0,5,1)}
function Pk(a){a.b=0;a.d=0;a.c=false}
function Pi(a){a.type='range';return a}
function Ni(a,b){a.onChange=b;return a}
function zi(a,b){a.disabled=b;return a}
function Zh(a,b){Xh(b,0,a,0,b.length)}
function mh(){mh=Lf;lh=new oh(null)}
function el(){el=Lf;dl=new cl(new Yk)}
function gi(){gi=Lf;di=new p;fi=new p}
function Yk(){this.d=new Vk;this.b=100}
function jb(a){this.c=new Kg;this.b=a}
function qb(a){K();pb(a);tb(a,2,true)}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function $(a){return !(!!a&&1==(a.c&7))}
function ci(a){return a.$H||(a.$H=++bi)}
function lg(a,b){return a.charCodeAt(b)}
function ad(a,b){return a!=null&&$c(a,b)}
function nh(a){return a.a!=null?a.a:null}
function cd(a){return typeof a==='number'}
function dd(a){return typeof a==='string'}
function Jj(a,b){return o(b.voiceURI,a)}
function gj(a,b){ck(a.e,b.target.value)}
function ki(a,b){for(var c in a){b(c)}}
function Ii(a,b){a.transition=b;return a}
function Gi(a){a.position='fixed';return a}
function Wf(a){if(a.j!=null){return}cg(a)}
function oc(a){this.d=a;jc(this);this.L()}
function Jh(a,b){Ch.call(this,a);this.a=b}
function Tg(){this.a=new Vg;this.b=new eh}
function Q(){this.a=Tc(Xd,il,1,100,5,1)}
function Vk(){this.a=Tc(Xd,il,1,100,5,1)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function xc(a,b,c){return a.apply(b,c);var d}
function vi(a,b){a['aria-label']=b;return a}
function jc(a){a.f&&a.b!==ml&&a.L();return a}
function $f(a){var b;b=Zf(a);eg(a,b);return b}
function bd(a){return typeof a==='boolean'}
function bk(a){A((K(),K(),J),new xk(a),Cl)}
function dk(a){A((K(),K(),J),new vk(a),Cl)}
function ck(a,b){A((K(),K(),J),new yk(a,b),Cl)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function gc(a){K();Qb?a.D():A((null,J),a,0)}
function ih(a,b){while(a.cb()){Vh(b,a.db())}}
function sh(a,b){while(a.c<a.d){uh(a,b,a.c++)}}
function Db(a){while(true){if(!Cb(a)){break}}}
function Wk(a){while(true){if(!Xk(a)){break}}}
function _k(a){if(a.a){Fb(Zi);Zi=null;a.a=null}}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function wh(a){if(!a.d){a.d=a.b.U();a.c=a.b.Z()}}
function Nh(a,b,c){if(a.a.A(c)){a.b=true;b.G(c)}}
function hh(a,b,c){this.a=a;this.b=b;this.c=c}
function Dg(a,b){a.a[a.a.length]=b;return true}
function Kc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function cj(a,b){gc(new uk(a.e,b.target.value))}
function bh(a,b){return !(a.a.get(b)===undefined)}
function Ng(a,b){return qh(b,a.length),new vh(a,b)}
function Dh(a,b){var c;return Hh(a,(c=new Kg,c))}
function Hg(a,b){var c;c=a.a[b];$h(a.a,b);return c}
function yg(a){var b;b=a.a.db();a.b=xg(a);return b}
function _f(a){var b;b=Zf(a);b.i=a;b.e=1;return b}
function Jg(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function Ci(a){a.border='1px solid orange';return a}
function Vc(a){return Array.isArray(a)&&a.rb===Pf}
function _c(a){return !Array.isArray(a)&&a.rb===Pf}
function Og(a){return new Jh(null,Ng(a,a.length))}
function Aj(a){return B((K(),K(),J),a.a,new Ej(a))}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function yj(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Ah(a){if(!a.b){Bh(a);a.c=true}else{Ah(a.b)}}
function ji(){if(ei==256){di=fi;fi=new p;ei=0}++ei}
function ai(a){if(a==null){throw Bf(new jg)}return a}
function Nc(){Nc=Lf;var a;!Pc();a=new Qc;Mc=a}
function Sf(){Sf=Lf;Rf=$wnd.goog.global.document}
function dj(a,b){gc(new qk(a.e,hg(b.target.value)))}
function ej(a,b){gc(new rk(a.e,hg(b.target.value)))}
function fj(a,b){gc(new sk(a.e,hg(b.target.value)))}
function Oj(a,b){var c;c=a.l;if(b!=c){a.l=b;fb(a.c)}}
function Pj(a,b){var c;c=a.m;if(b!=c){a.m=b;fb(a.d)}}
function Qj(a,b){var c;c=a.n;if(b!=c){a.n=b;fb(a.f)}}
function Rj(a,b){var c;c=a.o;if(b!=c){a.o=b;fb(a.g)}}
function Sj(a,b){var c;c=a.p;if(b!=c){a.p=b;fb(a.h)}}
function Uj(a,b){var c;c=a.r;if(b!=c){a.r=b;fb(a.k)}}
function Eh(a,b){Bh(a);return new Jh(a,new Oh(b,a.a))}
function Gh(a,b){Bh(a);return new Jh(a,new Rh(b,a.a))}
function ak(a,b){A((K(),K(),J),new wk(a,b),75497472)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&ll)&&D((null,J))}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function jh(a,b){return ed(a)===ed(b)||a!=null&&q(a,b)}
function rh(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function xh(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function vh(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function Ch(a){if(!a){this.b=null;new Kg}else{this.b=a}}
function bg(a){if(a.T()){return null}var b=a.i;return Hf[b]}
function vg(a,b){if(ad(b,29)){return sg(a.a,b)}return false}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function Nf(a){function b(){}
;b.prototype=a||{};return new b}
function Bh(a){if(a.b){Bh(a.b)}else if(a.c){throw Bf(new ig)}}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function $i(){if(!Zi){Zi=(++(K(),K(),J).e,new Gb);fl(new _i)}}
function $j(a){gc(new tk(a,nh(Fh(Eh(T(a.j)._(),new Jk)))))}
function _j(a,b){gc(new tk(a,nh(Fh(Eh(T(a.j)._(),new Lk(b))))))}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function Mj(a){$wnd[rl].speechSynthesis.addEventListener(Bl,a.t)}
function Cc(a){wc();$wnd.setTimeout(function(){throw a},0)}
function fc(a){dc(a.f);!!a.d&&ec(a);Z(a.a);Z(a.c);dc(a.b);dc(a.e)}
function Lg(a){Cg(this);Zh(this.a,rg(a,Tc(Xd,il,1,ug(a.a),5,1)))}
function Wg(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function Rh(a,b){rh.call(this,b.ib(),b.hb()&-6);this.a=a;this.b=b}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function mc(a,b){var c;c=Xf(a.pb);return b==null?c:c+': '+b}
function ag(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.O(b))}
function Jf(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function qi(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Ac(a,b,c){var d;d=yc();try{return xc(a,b,c)}finally{Bc(d)}}
function cb(a,b){var c,d;Dg(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Oh(a,b){rh.call(this,b.ib(),b.hb()&-16449);this.a=a;this.c=b}
function fh(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function Ck(a){$wnd.React.Component.call(this,a);this.a=new Bj(this)}
function Nj(a){$wnd[rl].speechSynthesis.removeEventListener(Bl,a.t)}
function Bk(){Bk=Lf;var a;Ak=(a=Mf(zk.prototype.ob,zk,[]),a)}
function th(a,b){if(a.c<a.d){uh(a,b,a.c++);return true}return false}
function Ih(a,b){var c;c=Dh(a,new zh(new yh));return c.ab(b.kb(c.Z()))}
function Hh(a,b){var c;Ah(a);c=new Uh;c.a=b;a.a.bb(new Wh(c));return c.a}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Eg(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.G(c)}}
function Tc(a,b,c,d,e,f){var g;g=Uc(e,d);e!=10&&Wc(Rc(a,f),b,c,e,g);return g}
function nc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function zc(b){wc();return function(){return Ac(b,this,arguments);var a}}
function sc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function gh(a){if(a.a.c!=a.c){return dh(a.a,a.b.value[0])}return a.b.value[1]}
function ab(a){if(-2!=a.e){A((K(),K(),J),new kb(a),0);!!a.b&&lb(a.b)}}
function cc(a){if(a.g>=0){a.g=-2;u((K(),K(),J),new H(new ic(a)),67108864,null)}}
function S(a){if(!a.a){a.a=true;a.j=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function W(a){if(a.b){if(ad(a.b,7)){throw Bf(a.b)}else{throw Bf(a.b)}}return a.j}
function Jb(b){try{nb(b.b.a)}catch(a){a=Af(a);if(!ad(a,5))throw Bf(a)}}
function sb(b){if(b){try{b.D()}catch(a){a=Af(a);if(ad(a,5)){K()}else throw Bf(a)}}}
function Bc(a){a&&Ic((Gc(),Fc));--tc;if(a){if(vc!=-1){Dc(vc);vc=-1}}}
function fd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function _h(a,b){return Sc(b)!=10&&Wc(r(b),b.qb,b.__elementTypeId$,Sc(b),a),a}
function Sc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function Tj(a,b){var c;c=a.q;if(!(ed(b)===ed(c)||b!=null&&q(b,c))){a.q=b;fb(a.i)}}
function Ic(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Lc(b,c)}while(a.b);a.b=c}}
function Hc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Lc(b,c)}while(a.a);a.a=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Kg);Dg(a.b,b)}}}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Kg);a.c=c.c}b.d=true;a.c.W(b)}
function Ig(a,b){var c;c=Gg(a,b,0);if(c==-1){return false}$h(a.a,c);return true}
function Mk(b){var c;c=Rk(b.d);try{_k(c)}catch(a){a=Af(a);if(!ad(a,5))throw Bf(a)}}
function eg(a,b){var c;if(!a){return}b.i=a;var d=bg(b);if(!d){Hf[a]=[b];return}d.pb=b}
function Mf(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Gg(a,b,c){for(;c<a.a.length;++c){if(jh(b,a.a[c])){return c}}return -1}
function zg(a){this.d=a;this.c=new fh(this.d.b);this.a=this.c;this.b=xg(this)}
function rc(a){qc();jc(this);this.b=a;kc(this,a);this.d=a==null?'null':Of(a);this.a=a}
function Pb(){var a;this.a=Tc(md,il,35,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function Zf(a){var b;b=new Yf;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function oi(a){var b;b=ni($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function Ag(a,b){var c,d;for(c=0,d=a.a.length;c<d;++c){if(jh(b,a.a[c])){return c}}return -1}
function qg(a,b){var c,d;for(d=new zg(b.a);d.b;){c=yg(d);if(!vg(a,c)){return false}}return true}
function pb(a){var b,c;for(c=new Mg(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function Df(){Ef();var a=Cf;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function ig(){oc.call(this,"Stream already terminated, can't be modified or used")}
function Qf(){$wnd.ReactDOM.render((new vj).a,(Sf(),Rf).getElementById('app'),null)}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:jl)|(0==(c&6291456)?!a?ll:4194304:0)|0|0|0)}
function hc(a,b,c){this.d=c?new Tg:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function Yf(){this.g=Vf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function Sg(a){var b,c,d;d=1;for(c=a.U();c.cb();){b=c.db();d=31*d+(b!=null?s(b):0);d=d|0}return d}
function Ug(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function Fh(a){var b;Ah(a);b=new Uh;if(a.a.jb(b)){return mh(),new oh(ai(b.a))}return mh(),mh(),lh}
function xg(a){if(a.a.cb()){return true}if(a.a!=a.c){return false}a.a=new Wg(a.d.a);return a.a.cb()}
function Af(a){var b;if(ad(a,5)){return a}b=a&&a.__java$exception;if(!b){b=new rc(a);Oc(b)}return b}
function Lj(a){lb(a.a);S(a.e);S(a.b);S(a.j);ab(a.h);ab(a.g);ab(a.c);ab(a.d);ab(a.k);ab(a.i);ab(a.f)}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&jl)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function db(a,b){var c,d;d=a.c;Ig(d,b);!!a.b&&jl!=(a.b.c&kl)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function ec(a){var b,c;for(c=new Mg(new Lg(new wg(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);gh(b).D()}}
function Wb(a){var b;if(a.c){while(!a.c.Y()){b=a.c.gb(a.c.Z()-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Gj(a){var b,c;c=T(a.j);b=(hb(a.i),a.q);(null==b||!c.X(b))&&gc(new tk(a,nh(Fh(Eh(T(a.j)._(),new Jk)))))}
function Rg(a){var b,c,d;d=0;for(c=new zg(a.a);c.b;){b=yg(c);d=d+(b?kh(b.b.value[0])^kh(gh(b)):0);d=d|0}return d}
function pg(a,b){var c,d;for(d=a.U();d.cb();){c=d.db();if(ed(b)===ed(c)||b!=null&&q(b,c)){return true}}return false}
function Wc(a,b,c,d,e){e.pb=a;e.qb=b;e.rb=Pf;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function qh(a,b){if(0>a||a>b){throw Bf(new Tf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function Gf(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function r(a){return dd(a)?Zd:cd(a)?Od:bd(a)?Md:_c(a)?a.pb:Vc(a)?a.pb:a.pb||Array.isArray(a)&&Rc(Fd,1)||Fd}
function s(a){return dd(a)?ii(a):cd(a)?fd(a):bd(a)?a?1231:1237:_c(a)?a.w():Vc(a)?ci(a):!!a&&!!a.hashCode?a.hashCode():ci(a)}
function Of(a){var b;if(Array.isArray(a)&&a.rb===Pf){return Xf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function ii(a){gi();var b,c,d;c=':'+a;d=fi[c];if(d!=null){return fd(d)}d=di[c];b=d==null?hi(a):fd(d);ji();fi[c]=b;return b}
function mi(a){var b,c;b=ni($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=(c={},c[pl]=a,c);return b}
function Nk(a,b){var c,d;d=0==O(a.d);c=new al(b);Ok(a.d,c);d&&$wnd.Promise.resolve(null).then(Mf(Zk.prototype.N,Zk,[a]));return c}
function Pg(a,b){var c,d;d=a.a.length;b.length<d&&(b=_h(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function Uk(a){var b,c;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){c=$wnd.Math.max(a.a.length-1,1)*2+1;Sk(a,c,b)}}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function yc(){var a;if(tc!=0){a=sc();if(a-uc>2000){uc=a;vc=$wnd.setTimeout(Ec,10)}}if(tc++==0){Hc((Gc(),Fc));return true}return false}
function hg(a){var b;b=gg(a);if(b>3.4028234663852886E38){return Infinity}else if(b<-3.4028234663852886E38){return -Infinity}return b}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(jl==(b&kl)?0:524288)|(0==(b&6291456)?jl==(b&kl)?4194304:ll:0)|0|268435456|0)}
function dg(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Pc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return dd(a)?o(a,b):cd(a)?a===b:bd(a)?ed(a)===ed(b):_c(a)?a.u(b):Vc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):ed(a)===ed(b)}
function Bj(a){this.e=new gk;this.c=a;K();++zj;this.b=new hc(new Cj(this),new Dj(this),false);this.a=new wb(null,new Fj(this),1411518464)}
function $c(a,b){if(dd(a)){return !!Zc[b]}else if(a.qb){return !!a.qb[b]}else if(cd(a)){return !!Yc[b]}else if(bd(a)){return !!Xc[b]}return false}
function rg(a,b){var c,d,e,f;f=a.Z();b.length<f&&(b=_h(new Array(f),b));e=b;d=a.U();for(c=0;c<f;++c){e[c]=d.db()}b.length>f&&(b[f]=null);return b}
function ti(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function Rk(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}else{b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}}
function Xk(a){var b;if(0==a.c){b=O(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;Pk(a.d);return false}else{a.a=a.a+1;a.c=b}}--a.c;Mk(a);return true}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function T(a){a.i?hb(a.e):gb(a.e);if(ub(a.f)){if(a.i&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Mg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Mg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Mg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Sk(a,b,c){var d,e,f,g;d=Tc(Xd,il,1,b,5,1);g=0;for(e=0;e<c;e++){f=(a.b+e)%a.a.length;d[g]=a.a[f];a.a[f]=null;++g}a.a=d;a.b=0;a.d=g;a.c=false}
function Uc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.D(),null)}finally{bc()}return f}catch(a){a=Af(a);if(ad(a,5)){e=a;throw Bf(e)}else throw Bf(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.F()}else{ac(b,e);try{g=c.F()}finally{bc()}}return g}catch(a){a=Af(a);if(ad(a,5)){f=a;throw Bf(f)}else throw Bf(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.h=c;this.j=null;this.i=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);jl==(d&kl)&&mb(this.f)}
function Ff(b,c,d,e){Ef();var f=Cf;$moduleName=c;$moduleBase=d;zf=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{gl(g)()}catch(a){b(c,a)}}else{gl(g)()}}
function ni(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function $g(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return _g()}}
function If(){Hf={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Lc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].sb()&&(c=Kc(c,g)):g[0].sb()}catch(a){a=Af(a);if(ad(a,5)){d=a;wc();Cc(ad(d,28)?d.M():d)}else throw Bf(a)}}return c}
function R(b){var c,d,e;e=b.j;try{d=b.c.F();if(!(ed(e)===ed(d)||e!=null&&q(e,d))){b.j=d;b.b=null;eb(b.e)}}catch(a){a=Af(a);if(ad(a,8)){c=a;if(!b.b){b.j=null;b.b=c;eb(b.e)}throw Bf(c)}else throw Bf(a)}}
function Xh(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function aj(a){var b,c,d,e;c=ek(a.e);if(0!=c&&null!=a.f){b=(Sf(),Rf);e=b.createRange();d=fk(a.e);e.setStart(a.f.firstChild,d);e.setEnd(a.f.firstChild,d+c);return e.getBoundingClientRect()}else{return null}}
function gg(a){fg==null&&(fg=new RegExp('^\\s*[+-]?(NaN|Infinity|((\\d+\\.?\\d*)|(\\.\\d+))([eE][+-]?\\d+)?[dDfF]?)\\s*$'));if(!fg.test(a)){throw Bf(new kg('For input string: "'+a+'"'))}return parseFloat(a)}
function hi(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+lg(a,c++)}b=b|0;return b}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Tc(Xd,il,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{yj(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=Af(a);if(ad(a,5)){K()}else throw Bf(a)}}}
function vb(a,b,c,d){this.b=new Kg;this.f=new Kb(new zb(this),d&6520832|262144|jl);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&ll)&&D((null,J)))}
function Kf(a,b,c){var d=Hf,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Hf[b]),Nf(h));_.qb=c;!b&&(_.rb=Pf);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.pb=f)}
function cg(a){if(a.S()){var b=a.c;b.T()?(a.j='['+b.i):!b.S()?(a.j='[L'+b.Q()+';'):(a.j='['+b.Q());a.b=b.P()+'[]';a.h=b.R()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=dg('.',[c,dg('$',d)]);a.b=dg('.',[c,dg('.',d)]);a.h=d[d.length-1]}
function Hj(a,b){var c;c=b.type;if(!o('boundary',c)){V(a.e);V(a.b)}if((o('error',c)||o('end',c))&&$wnd[rl].speechSynthesis.paused){$wnd[rl].speechSynthesis.cancel()}else if(o('boundary',c)&&o(b.name,'word')){gc(new ok(a,b.charIndex));gc(new pk(a,b.charLength))}}
function sg(a,b){var c,d,e,f,g;e=b.b.value[0];g=gh(b);f=e==null?tg(Ug((d=a.a.a.get(0),d==null?new Array:d))):dh(a.b,e);if(!(ed(g)===ed(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!Ug((c=a.a.a.get(0),c==null?new Array:c)):bh(a.b,e))){return false}return true}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Mg(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=Af(a);if(!ad(a,5))throw Bf(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function pi(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;li(b,Mf(si.prototype.lb,si,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[pl]=c[0],undefined):(d[pl]=c,undefined));return g=ni($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function kc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.K();return a&&a.I()}},suppressed:{get:function(){return c.J()}}})}catch(a){}}}
function Zg(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.h,e));d.j=null}Eg(a.b,new Bb(a));a.b.a=Tc(Xd,il,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function Ij(a){var b,c;gc(new ok(a,0));gc(new pk(a,0));c=new $wnd.SpeechSynthesisUtterance((hb(a.f),a.n));c.voice=(hb(a.i),a.q);c.volume=(hb(a.k),a.r);c.pitch=(hb(a.c),a.l);b=(hb(a.d),a.m);c.rate=$wnd.Math.pow($wnd.Math.abs(b)+1,b<0?-1:1);c.onstart=Mf(Dk.prototype.C,Dk,[a]);c.onend=Mf(Ek.prototype.C,Ek,[a]);c.onerror=Mf(Fk.prototype.B,Fk,[a]);c.onboundary=Mf(Gk.prototype.C,Gk,[a]);c.onpause=Mf(Hk.prototype.C,Hk,[a]);c.onresume=Mf(Ik.prototype.C,Ik,[a]);$wnd[rl].speechSynthesis.speak(c)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Fg(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Jg(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Fg(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Hg(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Kg)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&jl!=(k.b.c&kl)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function gk(){var a,b,c,d,e,f,g,h,i,j,k,l,m,n;this.t=new Kk(this);K();++Kj;this.s=new hc(null,new hk(this),true);this.l=0.5;this.m=0;this.r=1;this.n='Call me Ishmael. Some years ago, never mind how long precisely, having little or no money in my purse, and nothing particular to interest me on shore, I thought I would sail about a little and see the watery part of the world.';this.h=(i=new jb((b=null,b)),i);this.g=(j=new jb((c=null,c)),j);this.c=(k=new jb((d=null,d)),k);this.d=(l=new jb((e=null,e)),l);this.k=(m=new jb((f=null,f)),m);this.i=(n=new jb((g=null,g)),n);this.f=(h=new jb((a=null,a)),h);this.e=new X(new kk,null,null,35667968);this.b=new X(new lk,null,null,35667968);this.j=new X(new mk,new ik(this),new jk(this),35651584);this.a=new wb(new nk(this),null,413138944);D((null,J))}
function _g(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Zg()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function xj(a){var b,c,d,e,f;a.d=0;$i();b=(c=Yj(a.e),pi(sl,ti(new $wnd.Object,Wc(Rc(Zd,1),il,2,6,[T(a.e.e)?'speaking':null])),[pi('h1',null,['Web Speech Synthesis Demo']),pi('form',null,[pi(sl,ui(new $wnd.Object,'textarea'),[T(a.e.e)?mi([pi(sl,ui(wi(new $wnd.Object,Mf(jj.prototype.G,jj,[a])),'textbeingspoken'),[Xj(a.e)]),pi(sl,xi(new $wnd.Object,(d=aj(a),e=(Sf(),Rf).body,f=ek(a.e),Ei(Ji(Fi(Hi(Ii(Di(Ci(Gi(new $wnd.Object)),0==f?'none':'block'),0==f?'all 0s ease 0s':'all 50ms ease'),null==d?'0':d.top-1+e.clientHeight-e.scrollHeight-8+'px'),null==d?'0':d.left-1+e.clientWidth-e.scrollWidth-8+'px'),null==d?'0':d.width+'px'),null==d?'0':d.height+'px'))),null)]):pi('textarea',Ni(zi(Qi(new $wnd.Object,Xj(a.e)),T(a.e.e)),Mf(kj.prototype.mb,kj,[a])),null)]),pi(sl,ti(new $wnd.Object,Wc(Rc(Zd,1),il,2,6,[tl])),[pi(ul,Ri(new $wnd.Object,'pitch'),['Pitch']),pi('input',Ni(zi(Oi(Li(Mi(Qi(Pi(ui(new $wnd.Object,'pitch')),''+Vj(a.e)),'0'),'1'),'0.05'),T(a.e.e)),Mf(pj.prototype.mb,pj,[a])),null),pi(ql,Ai(zi(yi(vi(Bi(new $wnd.Object),vl),vl),T(a.e.e)),Mf(qj.prototype.nb,qj,[a])),[wl])]),pi(sl,ti(new $wnd.Object,Wc(Rc(Zd,1),il,2,6,[tl])),[pi(ul,Ri(new $wnd.Object,'rate'),['Rate']),pi('input',Ni(zi(Oi(Li(Mi(Qi(Pi(ui(new $wnd.Object,'rate')),''+Wj(a.e)),'-3'),'3'),'0.25'),T(a.e.e)),Mf(rj.prototype.mb,rj,[a])),null),pi(ql,Ai(zi(yi(vi(Bi(new $wnd.Object),xl),xl),T(a.e.e)),Mf(sj.prototype.nb,sj,[a])),[wl])]),pi(sl,ti(new $wnd.Object,Wc(Rc(Zd,1),il,2,6,[tl])),[pi(ul,Ri(new $wnd.Object,'volume'),['Volume']),pi('input',Ni(zi(Oi(Li(Mi(Qi(Pi(ui(new $wnd.Object,'volume')),''+Zj(a.e)),'0'),'1'),'0.05'),T(a.e.e)),Mf(tj.prototype.mb,tj,[a])),null),pi(ql,Ai(zi(yi(vi(Bi(new $wnd.Object),yl),yl),T(a.e.e)),Mf(uj.prototype.nb,uj,[a])),[wl])]),pi(sl,ti(new $wnd.Object,Wc(Rc(Zd,1),il,2,6,[tl])),[pi(ul,Ri(new $wnd.Object,'voice'),['Voice']),pi('select',Qi(zi(Ni(new $wnd.Object,Mf(hj.prototype.mb,hj,[a])),T(a.e.e)),null==c?'':c.voiceURI),Ih(Gh(T(a.e.j)._(),new ij),new ri)),pi(ql,Ai(zi(yi(vi(Bi(new $wnd.Object),zl),zl),T(a.e.e)),Mf(lj.prototype.nb,lj,[a])),[wl])]),pi(sl,ti(new $wnd.Object,Wc(Rc(Zd,1),il,2,6,['bottom'])),[pi(ql,Ai(zi(yi(vi(ti(Bi(new $wnd.Object),Wc(Rc(Zd,1),il,2,6,['small'])),'Speak'),'Speak'),T(a.e.e)),Mf(mj.prototype.nb,mj,[a])),['Speak']),pi(ql,Ai(zi(yi(vi(ti(Bi(new $wnd.Object),Wc(Rc(Zd,1),il,2,6,['small'])),T(a.e.b)?Al:'Pause'),T(a.e.b)?Al:'Pause'),!T(a.e.e)),Mf(nj.prototype.nb,nj,[a])),[T(a.e.b)?Al:'Pause']),pi(ql,Ai(zi(yi(vi(ti(Bi(new $wnd.Object),Wc(Rc(Zd,1),il,2,6,['small'])),'Stop'),'Stop'),!T(a.e.e)),Mf(oj.prototype.nb,oj,[])),['Stop'])])])]));return b}
var hl={10:1},il={3:1},jl=1048576,kl=1835008,ll=2097152,ml='__noinit__',nl={3:1,8:1,7:1,5:1},ol={3:1,32:1,59:1},pl='children',ql='button',rl='window',sl='div',tl='speecharg',ul='label',vl='Reset pitch',wl='\u21B6',xl='Reset rate',yl='Reset volume',zl='Reset voice',Al='Resume',Bl='voiceschanged',Cl=142606336;var _,Hf,Cf,zf=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;If();Kf(1,null,{},p);_.u=function(a){return o(this,a)};_.v=function(){return this.pb};_.w=function(){return ci(this)};_.equals=function(a){return this.u(a)};_.hashCode=function(){return this.w()};Kf(41,1,{},Yf);_.O=function(a){var b;b=new Yf;b.e=4;a>1?(b.c=ag(this,a-1)):(b.c=this);return b};_.P=function(){Wf(this);return this.b};_.Q=function(){return Xf(this)};_.R=function(){Wf(this);return this.h};_.S=function(){return (this.e&4)!=0};_.T=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Vf=1;var Xd=$f(1);var Nd=$f(41);Kf(75,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var ld=$f(75);Kf(76,1,hl,G);_.D=function(){Db(this.a)};var hd=$f(76);Kf(33,1,{},H);_.F=function(){return this.a.D(),null};var jd=$f(33);Kf(77,1,{},I);var kd=$f(77);var J;Kf(35,1,{35:1},Q);_.b=0;_.c=false;_.d=0;var md=$f(35);Kf(162,1,{});var pd=$f(162);Kf(37,162,{},X);_.a=false;_.d=0;_.i=false;var od=$f(37);Kf(113,1,{},Y);_.F=function(){return U(this.a)};var nd=$f(113);Kf(13,162,{13:1},jb);_.a=4;_.d=false;_.e=0;var rd=$f(13);Kf(112,1,hl,kb);_.D=function(){bb(this.a)};var qd=$f(112);Kf(21,162,{21:1},wb,xb);_.c=0;var wd=$f(21);Kf(107,1,{},yb);_.D=function(){R(this.a)};var sd=$f(107);Kf(108,1,hl,zb);_.D=function(){nb(this.a)};var td=$f(108);Kf(109,1,hl,Ab);_.D=function(){qb(this.a)};var ud=$f(109);Kf(110,1,{},Bb);_.G=function(a){ob(this.a,a)};var vd=$f(110);Kf(87,1,{},Eb);_.a=0;_.b=0;_.c=0;var xd=$f(87);Kf(118,1,{},Gb);_.a=false;var yd=$f(118);Kf(49,162,{49:1},Kb);_.a=0;var Ad=$f(49);Kf(86,1,{},Pb);var zd=$f(86);Kf(120,1,{},_b);_.a=0;var Qb;var Bd=$f(120);Kf(50,1,{},hc);_.g=0;var Dd=$f(50);Kf(106,1,hl,ic);_.D=function(){fc(this.a)};var Cd=$f(106);Kf(5,1,{3:1,5:1});_.H=function(a){return new Error(a)};_.I=Dl;_.J=function(){return Ih(Gh(Og((this.e==null&&(this.e=Tc(_d,il,5,0,0,1)),this.e)),new ng),new Mh)};_.K=function(){return this.c};_.L=function(){lc(this,nc(this.H(mc(this,this.d))));Oc(this)};_.b=ml;_.f=true;var _d=$f(5);Kf(8,5,{3:1,8:1,5:1});var Pd=$f(8);Kf(7,8,nl);var Yd=$f(7);Kf(43,7,nl);var Td=$f(43);Kf(71,43,nl);var Hd=$f(71);Kf(28,71,{28:1,3:1,8:1,7:1,5:1},rc);_.M=function(){return ed(this.a)===ed(pc)?null:this.a};var pc;var Ed=$f(28);var Fd=$f(0);Kf(144,1,{});var Gd=$f(144);var tc=0,uc=0,vc=-1;Kf(81,144,{},Jc);var Fc;var Id=$f(81);var Mc;Kf(156,1,{});var Kd=$f(156);Kf(72,156,{},Qc);var Jd=$f(72);var Xc,Yc,Zc;var Rf;Kf(74,7,nl);var Sd=$f(74);Kf(111,74,nl,Tf);var Ld=$f(111);Xc={3:1,67:1,65:1};var Md=$f(67);Kf(154,1,il);var fg;var Wd=$f(154);Yc={3:1,65:1};var Od=$f(155);Kf(42,7,nl);var Qd=$f(42);Kf(73,7,nl,ig);var Rd=$f(73);Kf(230,1,{});Kf(78,43,nl,jg);_.H=function(a){return new TypeError(a)};var Ud=$f(78);Kf(68,42,nl,kg);var Vd=$f(68);Zc={3:1,66:1,65:1,2:1};var Zd=$f(2);Kf(234,1,{});Kf(62,1,{},ng);_.V=function(a){return a.b};var $d=$f(62);Kf(34,7,nl,og);var ae=$f(34);Kf(157,1,{32:1});_.$=function(){return new xh(this,0)};_._=function(){return new Jh(null,this.$())};_.W=function(a){throw Bf(new og('Add not supported on this collection'))};_.X=function(a){return pg(this,a)};_.Y=function(){return this.Z()==0};_.ab=function(a){return rg(this,a)};var be=$f(157);Kf(160,1,{141:1});_.u=function(a){var b,c,d;if(a===this){return true}if(!ad(a,36)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new zg((new wg(d)).a);c.b;){b=yg(c);if(!sg(this,b)){return false}}return true};_.w=function(){return Rg(new wg(this))};var ie=$f(160);Kf(88,160,{141:1});var ee=$f(88);Kf(159,157,{32:1,166:1});_.$=function(){return new xh(this,1)};_.u=function(a){var b;if(a===this){return true}if(!ad(a,20)){return false}b=a;if(ug(b.a)!=this.Z()){return false}return qg(this,b)};_.w=function(){return Rg(this)};var je=$f(159);Kf(20,159,{20:1,32:1,166:1},wg);_.X=function(a){return vg(this,a)};_.U=function(){return new zg(this.a)};_.Z=function(){return ug(this.a)};var de=$f(20);Kf(22,1,{},zg);_.bb=El;_.db=function(){return yg(this)};_.cb=Dl;_.b=false;var ce=$f(22);Kf(158,157,{32:1,59:1});_.$=function(){return new xh(this,16)};_.eb=function(a,b){throw Bf(new og('Add not supported on this list'))};_.W=function(a){this.eb(this.Z(),a);return true};_.u=function(a){var b,c,d,e,f;if(a===this){return true}if(!ad(a,59)){return false}f=a;if(this.Z()!=f.Z()){return false}e=f.U();for(c=this.U();c.cb();){b=c.db();d=e.db();if(!(ed(b)===ed(d)||b!=null&&q(b,d))){return false}}return true};_.w=function(){return Sg(this)};_.U=function(){return new Bg(this)};_.gb=function(a){throw Bf(new og('Remove not supported on this list'))};var ge=$f(158);Kf(80,1,{},Bg);_.bb=El;_.cb=function(){return this.a<this.b.Z()};_.db=function(){return this.a<this.b.Z(),this.b.fb(this.a++)};_.a=0;var fe=$f(80);Kf(161,1,{167:1});_.u=function(a){var b;if(!ad(a,29)){return false}b=a;return jh(this.b.value[0],b.b.value[0])&&jh(gh(this),gh(b))};_.w=function(){return kh(this.b.value[0])^kh(gh(this))};var he=$f(161);Kf(12,158,ol,Kg,Lg);_.eb=function(a,b){Yh(this.a,a,b)};_.W=function(a){return Dg(this,a)};_.X=function(a){return Gg(this,a,0)!=-1};_.fb=function(a){return Fg(this,a)};_.Y=function(){return this.a.length==0};_.U=function(){return new Mg(this)};_.gb=function(a){return Hg(this,a)};_.Z=Fl;_.ab=function(a){var b,c;c=this.a.length;a.length<c&&(a=_h(new Array(c),a));for(b=0;b<c;++b){a[b]=this.a[b]}a.length>c&&(a[c]=null);return a};var le=$f(12);Kf(15,1,{},Mg);_.bb=El;_.cb=function(){return this.a<this.c.a.length};_.db=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var ke=$f(15);Kf(6,158,ol,Qg);_.X=function(a){return Ag(this,a)!=-1};_.fb=function(a){return this.a[a]};_.Z=Fl;_.ab=function(a){return Pg(this,a)};var me=$f(6);Kf(36,88,{3:1,36:1,141:1},Tg);var ne=$f(36);Kf(89,1,{},Vg);_.U=function(){return new Wg(this)};_.b=0;var pe=$f(89);Kf(45,1,{},Wg);_.bb=El;_.db=function(){return this.d=this.a[this.c++],this.d};_.cb=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var oe=$f(45);var Xg;Kf(90,1,{},eh);_.U=function(){return new fh(this)};_.b=0;_.c=0;var se=$f(90);Kf(46,1,{},fh);_.bb=El;_.db=function(){return this.c=this.a,this.a=this.b.next(),new hh(this.d,this.c,this.d.c)};_.cb=function(){return !this.a.done};var qe=$f(46);Kf(29,161,{29:1,167:1},hh);_.c=0;var re=$f(29);Kf(30,1,{30:1},oh);_.u=function(a){var b;if(a===this){return true}if(!ad(a,30)){return false}b=a;return jh(this.a,b.a)};_.w=function(){return kh(this.a)};var lh;var te=$f(30);Kf(92,1,{});_.bb=Gl;_.hb=function(){return this.d};_.ib=function(){return this.e};_.d=0;_.e=0;var xe=$f(92);Kf(47,92,{});var ue=$f(47);Kf(82,1,{});_.bb=Gl;_.hb=Dl;_.ib=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var we=$f(82);Kf(83,82,{},vh);_.bb=function(a){sh(this,a)};_.jb=function(a){return th(this,a)};var ve=$f(83);Kf(19,1,{},xh);_.hb=function(){return this.a};_.ib=function(){wh(this);return this.c};_.bb=function(a){wh(this);this.d.bb(a)};_.jb=function(a){wh(this);if(this.d.cb()){a.G(this.d.db());return true}return false};_.a=0;_.c=0;var ye=$f(19);Kf(64,1,{},yh);_.V=function(a){return a};var ze=$f(64);Kf(119,1,{},zh);var Ae=$f(119);Kf(91,1,{});_.c=false;var Je=$f(91);Kf(23,91,{},Jh);var Ie=$f(23);Kf(63,1,{},Mh);_.kb=function(a){return Tc(Xd,il,1,a,5,1)};var Be=$f(63);Kf(94,47,{},Oh);_.jb=function(a){this.b=false;while(!this.b&&this.c.jb(new Ph(this,a)));return this.b};_.b=false;var De=$f(94);Kf(96,1,{},Ph);_.G=function(a){Nh(this.a,this.b,a)};var Ce=$f(96);Kf(93,47,{},Rh);_.jb=function(a){return this.b.jb(new Sh(this,a))};var Fe=$f(93);Kf(95,1,{},Sh);_.G=function(a){Qh(this.a,this.b,a)};var Ee=$f(95);Kf(48,1,{},Uh);_.G=function(a){Th(this,a)};var Ge=$f(48);Kf(97,1,{},Wh);_.G=function(a){Vh(this,a)};var He=$f(97);Kf(232,1,{});Kf(229,1,{});var bi=0;var di,ei=0,fi;Kf(837,1,{});Kf(862,1,{});Kf(116,1,{},ri);_.kb=function(a){return new Array(a)};var Ke=$f(116);Kf(213,$wnd.Function,{},si);_.lb=function(a){qi(this.a,this.b,a)};var Zi;Kf(117,1,{202:1},_i);var Le=$f(117);Kf(99,1,{});var Oe=$f(99);Kf(194,$wnd.Function,{},hj);_.mb=function(a){gj(this.a,a)};Kf(85,1,{},ij);_.V=function(a){return pi('option',Qi(new $wnd.Object,a.voiceURI),[a.name+' ('+a.lang+')'])};var Me=$f(85);Kf(184,$wnd.Function,{},jj);_.G=function(a){bj(this.a,a)};Kf(186,$wnd.Function,{},kj);_.mb=function(a){cj(this.a,a)};Kf(195,$wnd.Function,{},lj);_.nb=function(a){bk(this.a.e)};Kf(196,$wnd.Function,{},mj);_.nb=function(a){Ij(this.a.e)};Kf(197,$wnd.Function,{},nj);_.nb=function(a){T(this.a.e.b)?$wnd[rl].speechSynthesis.resume():$wnd[rl].speechSynthesis.pause()};Kf(198,$wnd.Function,{},oj);_.nb=function(a){$wnd[rl].speechSynthesis.cancel()};Kf(187,$wnd.Function,{},pj);_.mb=function(a){dj(this.a,a)};Kf(188,$wnd.Function,{},qj);_.nb=function(a){gc(new qk(this.a.e,0.5))};Kf(189,$wnd.Function,{},rj);_.mb=function(a){ej(this.a,a)};Kf(190,$wnd.Function,{},sj);_.nb=function(a){gc(new rk(this.a.e,0))};Kf(191,$wnd.Function,{},tj);_.mb=function(a){fj(this.a,a)};Kf(192,$wnd.Function,{},uj);_.nb=function(a){gc(new sk(this.a.e,1))};Kf(61,1,{},vj);var Ne=$f(61);Kf(100,99,{});_.d=0;var nf=$f(100);Kf(101,100,{},Bj);var zj=0;var Te=$f(101);Kf(102,1,hl,Cj);_.D=function(){Z(this.a.e)};var Pe=$f(102);Kf(103,1,hl,Dj);_.D=function(){lb(this.a.a)};var Qe=$f(103);Kf(105,1,{},Ej);_.F=function(){return xj(this.a)};var Re=$f(105);Kf(104,1,{},Fj);_.D=function(){yj(this.a)};var Se=$f(104);Kf(121,1,{});var rf=$f(121);Kf(122,121,{},gk);_.l=0;_.m=0;_.o=0;_.p=0;_.r=0;var Kj=0;var lf=$f(122);Kf(123,1,hl,hk);_.D=function(){Lj(this.a)};var Ue=$f(123);Kf(127,1,{},ik);_.D=function(){Mj(this.a)};var Ve=$f(127);Kf(128,1,{},jk);_.D=function(){Nj(this.a)};var We=$f(128);Kf(124,1,{},kk);_.F=function(){return Uf(),$wnd[rl].speechSynthesis.speaking?true:false};var Xe=$f(124);Kf(125,1,{},lk);_.F=function(){return Uf(),$wnd[rl].speechSynthesis.paused?true:false};var Ye=$f(125);Kf(126,1,{},mk);_.F=function(){var a;return a=$wnd[rl].speechSynthesis.getVoices(),new Qg(a)};var Ze=$f(126);Kf(129,1,{},nk);_.D=function(){Gj(this.a)};var $e=$f(129);Kf(52,1,hl,ok);_.D=function(){Sj(this.a,this.b)};_.b=0;var _e=$f(52);Kf(53,1,hl,pk);_.D=function(){Rj(this.a,this.b)};_.b=0;var af=$f(53);Kf(54,1,hl,qk);_.D=function(){Oj(this.a,this.b)};_.b=0;var bf=$f(54);Kf(55,1,hl,rk);_.D=function(){Pj(this.a,this.b)};_.b=0;var cf=$f(55);Kf(56,1,hl,sk);_.D=function(){Uj(this.a,this.b)};_.b=0;var df=$f(56);Kf(38,1,hl,tk);_.D=function(){Tj(this.a,this.b)};var ef=$f(38);Kf(130,1,hl,uk);_.D=function(){Qj(this.a,this.b)};var ff=$f(130);Kf(131,1,hl,vk);_.D=function(){V(this.a)};var gf=$f(131);Kf(132,1,hl,wk);_.D=function(){Hj(this.a,this.b)};var hf=$f(132);Kf(133,1,hl,xk);_.D=function(){$j(this.a)};var jf=$f(133);Kf(134,1,hl,yk);_.D=function(){_j(this.a,this.b)};var kf=$f(134);Kf(199,$wnd.Function,{},zk);_.ob=function(a){return new Ck(a)};var Ak;Kf(84,$wnd.React.Component,{},Ck);Jf(Hf[1],_);_.componentDidMount=function(){$wnd[rl].speechSynthesis.cancel()};_.componentWillUnmount=function(){wj(this.a)};_.render=function(){return Aj(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var mf=$f(84);Kf(204,$wnd.Function,{},Dk);_.C=Hl;Kf(205,$wnd.Function,{},Ek);_.C=Hl;Kf(206,$wnd.Function,{},Fk);_.B=Hl;Kf(207,$wnd.Function,{},Gk);_.C=Hl;Kf(208,$wnd.Function,{},Hk);_.C=Hl;Kf(209,$wnd.Function,{},Ik);_.C=Hl;Kf(51,1,{},Jk);_.A=function(a){return a.default};var of=$f(51);Kf(114,1,{},Kk);_.handleEvent=function(a){dk(this.a.j)};var pf=$f(114);Kf(115,1,{},Lk);_.A=function(a){return Jj(this.a,a)};var qf=$f(115);Kf(136,1,{});var sf=$f(136);Kf(139,1,{},Vk);_.b=0;_.c=false;_.d=0;var tf=$f(139);Kf(57,136,{});_.a=0;_.b=0;_.c=0;var wf=$f(57);Kf(138,57,{},Yk);var uf=$f(138);Kf(214,$wnd.Function,{},Zk);_.N=function(a){return Wk((new $k(this.a)).a),null};Kf(137,1,{},$k);var vf=$f(137);Kf(58,1,{58:1},al);var xf=$f(58);Kf(135,1,{},cl);var yf=$f(135);var dl;var gd=_f('D');var gl=(wc(),zc);var gwtOnLoad=gwtOnLoad=Ff;Df(Qf);Gf('permProps',[[]]);if (webspeechdemo) webspeechdemo.onScriptLoad(gwtOnLoad);})();