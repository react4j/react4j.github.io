function webspeechdemo(){var nb='',ob=0,pb='gwt.codesvr=',qb='gwt.hosted=',rb='gwt.hybrid',sb='webspeechdemo',tb='__gwt_marker_webspeechdemo',ub='<script id="',vb='"><\/script>',wb='SCRIPT',xb='#',yb='?',zb='/',Ab=1,Bb='base',Cb='img',Db='clear.cache.gif',Eb='meta',Fb='name',Gb='gwt:property',Hb='content',Ib='=',Jb='gwt:onPropertyErrorFn',Kb='Bad handler "',Lb='" for "gwt:onPropertyErrorFn"',Mb='gwt:onLoadErrorFn',Nb='" for "gwt:onLoadErrorFn"',Ob='Single-script hosted mode not yet implemented. See issue ',Pb='http://code.google.com/p/google-web-toolkit/issues/detail?id=2079',Qb='E737360D0822924435F67E7E34E6E8FB',Rb=':',Sb='DOMContentLoaded',Tb=50;var k=nb,l=ob,m=pb,n=qb,o=rb,p=sb,q=tb,r=ub,s=vb,t=wb,u=xb,v=yb,w=zb,A=Ab,B=Bb,C=Cb,D=Db,F=Eb,G=Fb,H=Gb,I=Hb,J=Ib,K=Jb,L=Kb,M=Lb,N=Mb,O=Nb,P=Ob,Q=Pb,R=Qb,S=Rb,T=Sb,U=Tb;var V=window,W=document,X,Y,Z=k,$={},_=[],ab=[],bb=[],cb=l,db,eb;if(!V.__gwt_stylesLoaded){V.__gwt_stylesLoaded={}}if(!V.__gwt_scriptsLoaded){V.__gwt_scriptsLoaded={}}function fb(){var b=false;try{var c=V.location.search;return (c.indexOf(m)!=-1||(c.indexOf(n)!=-1||V.external&&V.external.gwtOnLoad))&&c.indexOf(o)==-1}catch(a){}fb=function(){return b};return b}
function gb(){if(X&&Y){X(db,p,Z,cb)}}
function hb(){var e,f=q,g;W.write(r+f+s);g=W.getElementById(f);e=g&&g.previousSibling;while(e&&e.tagName!=t){e=e.previousSibling}function h(a){var b=a.lastIndexOf(u);if(b==-1){b=a.length}var c=a.indexOf(v);if(c==-1){c=a.length}var d=a.lastIndexOf(w,Math.min(c,b));return d>=l?a.substring(l,d+A):k}
;if(e&&e.src){Z=h(e.src)}if(Z==k){var i=W.getElementsByTagName(B);if(i.length>l){Z=i[i.length-A].href}else{Z=h(W.location.href)}}else if(Z.match(/^\w+:\/\//)){}else{var j=W.createElement(C);j.src=Z+D;Z=h(j.src)}if(g){g.parentNode.removeChild(g)}}
function ib(){var b=document.getElementsByTagName(F);for(var c=l,d=b.length;c<d;++c){var e=b[c],f=e.getAttribute(G),g;if(f){if(f==H){g=e.getAttribute(I);if(g){var h,i=g.indexOf(J);if(i>=l){f=g.substring(l,i);h=g.substring(i+A)}else{f=g;h=k}$[f]=h}}else if(f==K){g=e.getAttribute(I);if(g){try{eb=eval(g)}catch(a){alert(L+g+M)}}}else if(f==N){g=e.getAttribute(I);if(g){try{db=eval(g)}catch(a){alert(L+g+O)}}}}}}
__gwt_isKnownPropertyValue=function(a,b){return b in _[a]};__gwt_getMetaProperty=function(a){var b=$[a];return b==null?null:b};webspeechdemo.onScriptLoad=function(a){webspeechdemo=null;X=a;gb()};if(fb()){alert(P+Q);return}hb();ib();try{var jb;jb=R;var kb=jb.indexOf(S);if(kb!=-1){cb=Number(jb.substring(kb+A))}}catch(a){return}var lb;function mb(){if(!Y){Y=true;gb();if(W.removeEventListener){W.removeEventListener(T,mb,false)}if(lb){clearInterval(lb)}}}
if(W.addEventListener){W.addEventListener(T,function(){mb()},false)}var lb=setInterval(function(){if(/loaded|complete/.test(W.readyState)){mb()}},U)}
webspeechdemo();(function () {var $gwt_version = "2.9.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $stats = $wnd.__gwtStatsEvent ? function(a) {$wnd.__gwtStatsEvent(a)} : null;var $strongName = 'E737360D0822924435F67E7E34E6E8FB';function p(){}
function pi(){}
function Lf(){}
function Hf(){}
function Gb(){}
function Jc(){}
function Qc(){}
function lg(){}
function wh(){}
function Kh(){}
function Sh(){}
function Cj(){}
function Lj(){}
function Rj(){}
function Nk(){}
function Ok(){}
function Pk(){}
function al(){}
function kl(){}
function Oc(a){Nc()}
function Qf(){Qf=Hf}
function rb(a,b){a.b=b}
function Rh(a,b){a.a=b}
function G(a){this.a=a}
function H(a){this.a=a}
function I(a){this.a=a}
function Y(a){this.a=a}
function kb(a){this.a=a}
function yb(a){this.a=a}
function zb(a){this.a=a}
function Ab(a){this.a=a}
function Bb(a){this.a=a}
function ic(a){this.a=a}
function ug(a){this.a=a}
function Og(a){this.a=a}
function Oj(a){this.a=a}
function Kj(a){this.a=a}
function Mj(a){this.a=a}
function Nj(a){this.a=a}
function Pj(a){this.a=a}
function Qj(a){this.a=a}
function Sj(a){this.a=a}
function Tj(a){this.a=a}
function Uj(a){this.a=a}
function Uh(a){this.a=a}
function xh(a){this.a=a}
function Vj(a){this.a=a}
function Wj(a){this.a=a}
function Xj(a){this.a=a}
function dk(a){this.a=a}
function ek(a){this.a=a}
function fk(a){this.a=a}
function gk(a){this.a=a}
function Kk(a){this.a=a}
function Lk(a){this.a=a}
function Mk(a){this.a=a}
function Qk(a){this.a=a}
function Yk(a){this.a=a}
function $k(a){this.a=a}
function el(a){this.a=a}
function fl(a){this.a=a}
function gl(a){this.a=a}
function hl(a){this.a=a}
function il(a){this.a=a}
function jl(a){this.a=a}
function ll(a){this.a=a}
function ml(a){this.a=a}
function zg(a){this.b=a}
function Kg(a){this.c=a}
function Tg(){this.a=$g()}
function bh(){this.a=$g()}
function Ig(){Ag(this)}
function Ll(a){gh(this,a)}
function Nl(a){nh(this,a)}
function eb(a){Yb((K(),a))}
function fb(a){Zb((K(),a))}
function ib(a){$b((K(),a))}
function w(a){--a.e;D(a)}
function Z(a){!!a&&cc(a.s)}
function dc(a){!!a&&a.A()}
function ji(a,b){ii(a,b)}
function Th(a,b){Jh(a.a,b)}
function C(a,b){Ob(a.f,b.f)}
function L(a,b){P(a);M(a,b)}
function Ol(a){Dk(this.a,a)}
function mh(a){kh();this.a=a}
function xf(a){return a.b}
function Ej(a,b){return a.f=b}
function Kl(){return this.b}
function Jl(){return ai(this)}
function Dg(a,b){return a.a[b]}
function lc(a,b){a.b=b;kc(a,b)}
function Zj(a){a.d=2;cc(a.b)}
function Yh(a,b){a.splice(b,1)}
function sh(a,b,c){b.C(a.a[c])}
function Pf(a){oc.call(this,a)}
function ig(a){oc.call(this,a)}
function mg(a){oc.call(this,a)}
function hg(){jc(this);this.I()}
function Wg(){Wg=Hf;Vg=Yg()}
function K(){K=Hf;J=new F}
function qc(){qc=Hf;pc=new p}
function Gc(){Gc=Hf;Fc=new Jc}
function wc(){wc=Hf;!!(Nc(),Mc)}
function Af(){yf==null&&(yf=[])}
function Tf(a){Sf(a);return a.j}
function Ih(a,b){a.V(b);return a}
function si(a,b){a.id=b;return a}
function U(a){nb(a.f);return W(a)}
function Sb(a){Tb(a);!a.d&&Wb(a)}
function bb(a){K();Zb(a);a.e=-2}
function $g(){Wg();return new Vg}
function Rc(a,b){return Zf(a,b)}
function Jh(a,b){Rh(a,Ih(a.a,b))}
function nh(a,b){while(a.ib(b));}
function Oh(a,b,c){b.C(a.a.U(c))}
function v(a,b,c){t(a,new I(c),b)}
function Ji(a,b){a.max=b;return a}
function Ki(a,b){a.min=b;return a}
function ui(a,b){a.ref=b;return a}
function Fi(a,b){a.top=b;return a}
function wk(a){hb(a.c);return a.l}
function xk(a){hb(a.d);return a.m}
function yk(a){hb(a.f);return a.n}
function zk(a){hb(a.i);return a.q}
function Ak(a){hb(a.k);return a.r}
function Hk(a){hb(a.g);return a.o}
function Ik(a){hb(a.h);return a.p}
function ah(a,b){return a.a.get(b)}
function sg(a){return a.a.b+a.b.b}
function Wc(a){return new Array(a)}
function _i(a,b){eg.call(this,a,b)}
function yj(a,b){eg.call(this,a,b)}
function eg(a,b){this.a=a;this.b=b}
function Nh(a,b){this.a=a;this.b=b}
function Qh(a,b){this.a=a;this.b=b}
function qi(a,b){this.a=a;this.b=b}
function Rk(a,b){this.a=a;this.b=b}
function Sk(a,b){this.a=a;this.b=b}
function Tk(a,b){this.a=a;this.b=b}
function Uk(a,b){this.a=a;this.b=b}
function Vk(a,b){this.a=a;this.b=b}
function Wk(a,b){this.a=a;this.b=b}
function Xk(a,b){this.a=a;this.b=b}
function Zk(a,b){this.a=a;this.b=b}
function _k(a,b){this.a=a;this.b=b}
function Eb(a){this.d=a;this.b=100}
function Yj(){this.a=mi((cl(),bl))}
function Ec(){tc!=0&&(tc=0);vc=-1}
function Ml(){return this.a.length}
function rg(a){return !a?null:eh(a)}
function o(a,b){return fd(a)===fd(b)}
function fd(a){return a==null?null:a}
function Ub(a){return !a.d?a:Ub(a.d)}
function Dc(a){$wnd.clearTimeout(a)}
function Di(a,b){a.left=b;return a}
function Mi(a,b){a.step=b;return a}
function vi(a,b){a.style=b;return a}
function wi(a,b){a.title=b;return a}
function Hi(a,b){a.width=b;return a}
function Oi(a,b){a.value=b;return a}
function Ci(a,b){a.height=b;return a}
function yi(a,b){a.onClick=b;return a}
function Pi(a,b){a.htmlFor=b;return a}
function Bi(a,b){a.display=b;return a}
function Wh(a,b,c){a.splice(b,0,c)}
function A(a,b,c){u(a,new H(b),c,null)}
function B(a,b,c){return u(a,c,2048,b)}
function ih(a){return a!=null?s(a):0}
function ii(a,b){for(var c in a){b(c)}}
function xi(a,b){a.disabled=b;return a}
function Li(a,b){a.onChange=b;return a}
function Xh(a,b){Vh(b,0,a,0,b.length)}
function jg(a,b){return a.charCodeAt(b)}
function ai(a){return a.$H||(a.$H=++_h)}
function $(a){return !(!!a&&1==(a.c&7))}
function bd(a,b){return a!=null&&_c(a,b)}
function lh(a){return a.a!=null?a.a:null}
function kh(){kh=Hf;jh=new mh(null)}
function ei(){ei=Hf;bi=new p;di=new p}
function jb(a){this.c=new Ig;this.b=a}
function Ag(a){a.a=Tc(Zd,pl,1,0,5,1)}
function Q(){this.a=Tc(Zd,pl,1,100,5,1)}
function oc(a){this.d=a;jc(this);this.I()}
function Rg(){this.a=new Tg;this.b=new bh}
function Hh(a,b){Ah.call(this,a);this.a=b}
function Gi(a,b){a.transition=b;return a}
function kk(a,b){return o(b.voiceURI,a)}
function Jj(a,b){Fk(a.e,b.target.value)}
function qb(a){K();pb(a);tb(a,2,true)}
function V(a){4==(a.f.c&7)&&tb(a.f,5,true)}
function Hb(a){2==(3&a.a)||(a.a=-4&a.a|2)}
function gb(a){var b;Vb((K(),b=Qb,b),a)}
function gc(a){K();Qb?a.A():A((null,J),a,0)}
function Ek(a){A((K(),K(),J),new $k(a),Il)}
function Gk(a){A((K(),K(),J),new Yk(a),Il)}
function Sf(a){if(a.j!=null){return}_f(a)}
function jc(a){a.f&&a.b!==tl&&a.I();return a}
function Ei(a){a.position='fixed';return a}
function ti(a,b){a['aria-label']=b;return a}
function Wf(a){var b;b=Vf(a);bg(a,b);return b}
function dd(a){return typeof a==='number'}
function ed(a){return typeof a==='string'}
function cd(a){return typeof a==='boolean'}
function xc(a,b,c){return a.apply(b,c);var d}
function Nb(a,b,c){c.a=-4&c.a|1;L(a.a[b],c)}
function fh(a,b,c){this.a=a;this.b=b;this.c=c}
function gh(a,b){while(a.bb()){Th(b,a.cb())}}
function qh(a,b){while(a.c<a.d){sh(a,b,a.c++)}}
function Db(a){while(true){if(!Cb(a)){break}}}
function Fb(a){if(!a.a){a.a=true;w((K(),K(),J))}}
function uh(a){if(!a.d){a.d=a.b.T();a.c=a.b.Y()}}
function ob(a,b){db(b,a);b.c.a.length>0||(b.a=4)}
function Ob(a,b){Nb(a,((b.a&229376)>>15)-1,b)}
function Fk(a,b){A((K(),K(),J),new _k(a,b),Il)}
function Fj(a,b){gc(new Xk(a.e,b.target.value))}
function _g(a,b){return !(a.a.get(b)===undefined)}
function Bg(a,b){a.a[a.a.length]=b;return true}
function Kc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function Fg(a,b){var c;c=a.a[b];Yh(a.a,b);return c}
function wg(a){var b;b=a.a.cb();a.b=vg(a);return b}
function Yf(a){var b;b=Vf(a);b.i=a;b.e=1;return b}
function Bh(a,b){var c;return Fh(a,(c=new Ig,c))}
function Lg(a,b){return oh(b,a.length),new th(a,b)}
function bk(a){return B((K(),K(),J),a.a,new fk(a))}
function Mg(a){return new Hh(null,Lg(a,a.length))}
function Vc(a){return Array.isArray(a)&&a.rb===Lf}
function ad(a){return !Array.isArray(a)&&a.rb===Lf}
function O(a){return a.c?a.a.length-a.b+a.d:a.d-a.b}
function Of(){Of=Hf;Nf=$wnd.goog.global.document}
function Nc(){Nc=Hf;var a;!Pc();a=new Qc;Mc=a}
function hi(){if(ci==256){bi=di;di=new p;ci=0}++ci}
function $h(a){if(a==null){throw xf(new hg)}return a}
function Ai(a){a.border='1px solid orange';return a}
function Hg(a,b,c){var d;d=a.a[b];a.a[b]=c;return d}
function pk(a,b){var c;c=a.l;if(b!=c){a.l=b;fb(a.c)}}
function qk(a,b){var c;c=a.m;if(b!=c){a.m=b;fb(a.d)}}
function rk(a,b){var c;c=a.n;if(b!=c){a.n=b;fb(a.f)}}
function sk(a,b){var c;c=a.o;if(b!=c){a.o=b;fb(a.g)}}
function tk(a,b){var c;c=a.p;if(b!=c){a.p=b;fb(a.h)}}
function vk(a,b){var c;c=a.r;if(b!=c){a.r=b;fb(a.k)}}
function Lh(a,b,c){if(a.a.kb(c)){a.b=true;b.C(c)}}
function yh(a){if(!a.b){zh(a);a.c=true}else{yh(a.b)}}
function _j(a){if(0==a.d){a.d=1;a.c.forceUpdate()}}
function Gj(a,b){gc(new Tk(a.e,fg(b.target.value)))}
function Hj(a,b){gc(new Uk(a.e,fg(b.target.value)))}
function Ij(a,b){gc(new Vk(a.e,fg(b.target.value)))}
function hh(a,b){return fd(a)===fd(b)||a!=null&&q(a,b)}
function ph(a,b){this.e=a;this.d=(b&64)!=0?b|16384:b}
function vh(a,b){this.b=a;this.a=(b&4096)==0?b|64|16384:b}
function th(a,b){this.c=0;this.d=b;this.b=17488;this.a=a}
function _b(a,b){this.a=(K(),K(),J).b++;this.d=a;this.e=b}
function Dk(a,b){A((K(),K(),J),new Zk(a,b),75497472)}
function Ch(a,b){zh(a);return new Hh(a,new Mh(b,a.a))}
function Eh(a,b){zh(a);return new Hh(a,new Ph(b,a.a))}
function Ah(a){if(!a){this.b=null;new Ig}else{this.b=a}}
function $f(a){if(a.S()){return null}var b=a.i;return Df[b]}
function tg(a,b){if(bd(b,32)){return qg(a.a,b)}return false}
function zi(a,b){a.type=b.a!=null?b.a:''+b.b;return a}
function Xf(a,b){var c;c=Vf(a);bg(a,c);c.e=b?8:0;return c}
function mc(a,b){var c;c=Tf(a.pb);return b==null?c:c+': '+b}
function Zf(a,b){var c=a.a=a.a||[];return c[b]||(c[b]=a.N(b))}
function hb(a){var b;K();!!Qb&&!!Qb.e&&Vb((b=Qb,b),a)}
function mb(a){C((K(),K(),J),a);0==(a.f.a&sl)&&D((null,J))}
function Bk(a){gc(new Wk(a,lh(Dh(Ch(T(a.j).$(),new kl)))))}
function Ck(a,b){gc(new Wk(a,lh(Dh(Ch(T(a.j).$(),new ml(b))))))}
function ac(a,b){Qb=new _b(Qb,b);a.d=false;Rb(Qb);return Qb}
function Jf(a){function b(){}
;b.prototype=a||{};return new b}
function cl(){cl=Hf;var a;bl=(a=If(al.prototype.ob,al,[]),a)}
function aj(){$i();return Xc(Rc(Ne,1),pl,25,0,[Xi,Yi,Zi])}
function Cc(a){wc();$wnd.setTimeout(function(){throw a},0)}
function zh(a){if(a.b){zh(a.b)}else if(a.c){throw xf(new gg)}}
function Rb(a){if(a.e){2==(a.e.c&7)||tb(a.e,4,true);pb(a.e)}}
function fc(a){dc(a.f);!!a.d&&ec(a);Z(a.a);Z(a.c);dc(a.b);dc(a.e)}
function Jg(a){Ag(this);Xh(this.a,pg(a,Tc(Zd,pl,1,sg(a.a),5,1)))}
function Ug(a){this.e=a;this.b=this.e.a.entries();this.a=new Array}
function F(){this.f=new Pb;this.a=new Eb(this.f);new G(this.a)}
function dl(a){$wnd.React.Component.call(this,a);this.a=new ck(this)}
function Ph(a,b){ph.call(this,b.hb(),b.gb()&-6);this.a=a;this.b=b}
function cb(a,b){var c,d;Bg(a.c,b);d=(c=b.c&7,c>3?c:4);a.a>d&&(a.a=d)}
function Gh(a,b){var c;c=Bh(a,new xh(new wh));return c._(b.jb(c.Y()))}
function rh(a,b){if(a.c<a.d){sh(a,b,a.c++);return true}return false}
function nc(b){if(!('stack' in b)){try{throw b}catch(a){}}return b}
function Ff(a,b){for(var c in a){b[c]===undefined&&(b[c]=a[c])}}
function oi(a,b,c){!o(c,'key')&&!o(c,'ref')&&(a[c]=b[c],undefined)}
function Ac(a,b,c){var d;d=yc();try{return xc(a,b,c)}finally{Bc(d)}}
function zc(b){wc();return function(){return Ac(b,this,arguments);var a}}
function sc(){if(Date.now){return Date.now()}return (new Date).getTime()}
function gd(a){return Math.max(Math.min(a,2147483647),-2147483648)|0}
function Bc(a){a&&Ic((Gc(),Fc));--tc;if(a){if(vc!=-1){Dc(vc);vc=-1}}}
function Jb(b){try{nb(b.b.a)}catch(a){a=wf(a);if(!bd(a,4))throw xf(a)}}
function ab(a){if(-2!=a.e){A((K(),K(),J),new kb(a),0);!!a.b&&lb(a.b)}}
function eh(a){if(a.a.c!=a.c){return ah(a.a,a.b.value[0])}return a.b.value[1]}
function Fh(a,b){var c;yh(a);c=new Sh;c.a=b;a.a.ab(new Uh(c));return c.a}
function Mb(a){var b,c;b=0;for(c=0;c<a.a.length;c++){b+=O(a.a[c])}return b}
function Eg(a,b,c){for(;c<a.a.length;++c){if(hh(b,a.a[c])){return c}}return -1}
function M(a,b){a.a[a.d]=b;++a.d;if(a.d>=a.a.length){a.d=0;a.c=true}}
function Mh(a,b){ph.call(this,b.hb(),b.gb()&-16449);this.a=a;this.c=b}
function dh(a){this.d=a;this.b=this.d.a.entries();this.a=this.b.next()}
function xg(a){this.d=a;this.c=new dh(this.d.b);this.a=this.c;this.b=vg(this)}
function Pb(){var a;this.a=Tc(nd,pl,38,5,0,1);for(a=0;a<5;a++){this.a[a]=new Q}}
function Cg(a,b){var c,d,e,f;for(d=a.a,e=0,f=d.length;e<f;++e){c=d[e];b.C(c)}}
function uk(a,b){var c;c=a.q;if(!(fd(b)===fd(c)||b!=null&&q(b,c))){a.q=b;fb(a.i)}}
function Gg(a,b){var c;c=Eg(a,b,0);if(c==-1){return false}Yh(a.a,c);return true}
function Tc(a,b,c,d,e,f){var g;g=Uc(e,d);e!=10&&Xc(Rc(a,f),b,c,e,g);return g}
function Zh(a,b){return Sc(b)!=10&&Xc(r(b),b.qb,b.__elementTypeId$,Sc(b),a),a}
function Sc(a){return a.__elementTypeCategory$==null?10:a.__elementTypeCategory$}
function S(a){if(!a.a){a.a=true;a.j=null;a.b=null;ab(a.e);2==(a.f.c&7)||lb(a.f)}}
function D(a){if(a.d&&a.e==0){if(!a.c){a.c=true;try{Db(a.a)}finally{a.c=false}}}}
function W(a){if(a.b){if(bd(a.b,6)){throw xf(a.b)}else{throw xf(a.b)}}return a.j}
function sb(b){if(b){try{b.A()}catch(a){a=wf(a);if(bd(a,4)){K()}else throw xf(a)}}}
function bc(){var a;try{Sb(Qb);K()}finally{a=Qb.d;!a&&((K(),K(),J).d=true);Qb=Qb.d}}
function Hc(a){var b,c;if(a.a){c=null;do{b=a.a;a.a=null;c=Lc(b,c)}while(a.a);a.a=c}}
function Ic(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Lc(b,c)}while(a.b);a.b=c}}
function Vb(a,b){var c;if(a.e){c=a.a;if(b.e!=c){b.e=c;!a.b&&(a.b=new Ig);Bg(a.b,b)}}}
function Xb(a,b){var c;if(!a.c){c=Ub(a);!c.c&&(c.c=new Ig);a.c=c.c}b.d=true;a.c.V(b)}
function bg(a,b){var c;if(!a){return}b.i=a;var d=$f(b);if(!d){Df[a]=[b];return}d.pb=b}
function If(a,b,c){var d=function(){return a.apply(d,arguments)};b.apply(d,c);return d}
function Vf(a){var b;b=new Uf;b.j='Class$'+(a?'S'+a:''+b.g);b.b=b.j;b.h=b.j;return b}
function mi(a){var b;b=li($wnd.React.Element,a);b.props={};b.key=null;b.ref=null;return b}
function rc(a){qc();jc(this);this.b=a;kc(this,a);this.d=a==null?'null':Kf(a);this.a=a}
function gg(){oc.call(this,"Stream already terminated, can't be modified or used")}
function zf(){Af();var a=yf;for(var b=0;b<arguments.length;b++){a.push(arguments[b])}}
function pb(a){var b,c;for(c=new Kg(a.b);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);b.a=4}}
function og(a,b){var c,d;for(d=new xg(b.a);d.b;){c=wg(d);if(!tg(a,c)){return false}}return true}
function yg(a,b){var c,d;for(c=0,d=a.a.length;c<d;++c){if(hh(b,a.a[c])){return c}}return -1}
function Qg(a){var b,c,d;d=1;for(c=a.T();c.bb();){b=c.cb();d=31*d+(b!=null?s(b):0);d=d|0}return d}
function cc(a){if(a.g>=0){a.g=-2;u((K(),K(),J),new H(new ic(a)),67108864,null)}}
function Mf(){$wnd.ReactDOM.render((new Yj).a,(Of(),Nf).getElementById('app'),null)}
function $i(){$i=Hf;Xi=new _i(xl,0);Yi=new _i('reset',1);Zi=new _i('submit',2)}
function oh(a,b){if(0>a||a>b){throw xf(new Pf('fromIndex: 0, toIndex: '+a+', length: '+b))}}
function ok(a){(Of(),$wnd.goog.global.window).speechSynthesis.removeEventListener(Hl,a.t)}
function nk(a){(Of(),$wnd.goog.global.window).speechSynthesis.addEventListener(Hl,a.t)}
function hc(a,b,c){this.d=c?new Rg:null;this.f=a;this.b=b;this.e=null;this.a=null;this.c=null}
function Kb(a,b){this.b=a;this.a=b|0|(0==(b&6291456)?4194304:0)|(0!=(b&229376)?0:98304)}
function wb(a,b,c){vb.call(this,null,a,b,c|(!a?262144:ql)|(0==(c&6291456)?!a?sl:4194304:0)|0|0|0)}
function mk(a){lb(a.a);S(a.e);S(a.b);S(a.j);ab(a.h);ab(a.g);ab(a.c);ab(a.d);ab(a.k);ab(a.i);ab(a.f)}
function vg(a){if(a.a.bb()){return true}if(a.a!=a.c){return false}a.a=new Ug(a.d.a);return a.a.bb()}
function Dh(a){var b;yh(a);b=new Sh;if(a.a.ib(b)){return kh(),new mh($h(b.a))}return kh(),kh(),jh}
function wf(a){var b;if(bd(a,4)){return a}b=a&&a.__java$exception;if(!b){b=new rc(a);Oc(b)}return b}
function Pg(a){var b,c,d;d=0;for(c=new xg(a.a);c.b;){b=wg(c);d=d+(b?ih(b.b.value[0])^ih(eh(b)):0);d=d|0}return d}
function Sg(a){var b,c,d,e;for(c=a,d=0,e=c.length;d<e;++d){b=c[d];if(null==b.b.value[0]){return b}}return null}
function ng(a,b){var c,d;for(d=a.T();d.bb();){c=d.cb();if(fd(b)===fd(c)||b!=null&&q(b,c)){return true}}return false}
function Xc(a,b,c,d,e){e.pb=a;e.qb=b;e.rb=Lf;e.__elementTypeId$=c;e.__elementTypeCategory$=d;return e}
function Cf(a,b){typeof window==='object'&&typeof window['$gwt']==='object'&&(window['$gwt'][a]=b)}
function r(a){return ed(a)?_d:dd(a)?Pd:cd(a)?Nd:ad(a)?a.pb:Vc(a)?a.pb:a.pb||Array.isArray(a)&&Rc(Gd,1)||Gd}
function ec(a){var b,c;for(c=new Kg(new Jg(new ug(a.d)));c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);eh(b).A()}}
function db(a,b){var c,d;d=a.c;Gg(d,b);!!a.b&&ql!=(a.b.c&rl)&&a.c.a.length<=0&&0==a.b.a.d&&(a.d||Xb((K(),c=Qb,c),a))}
function hk(a){var b,c;c=T(a.j);b=(hb(a.i),a.q);(null==b||!c.W(b))&&gc(new Wk(a,lh(Dh(Ch(T(a.j).$(),new kl)))))}
function Wb(a){var b;if(a.c){while(!a.c.X()){b=a.c.fb(a.c.Y()-1);b.d=false;b.c.a.length>0||(b.b.c&7)>3&&tb(b.b,3,true)}}}
function Bj(){if(!Aj){Aj=(++(K(),K(),J).e,new Gb);$wnd.Promise.resolve(null).then(If(Cj.prototype.K,Cj,[]))}}
function lb(a){if(2<(a.c&7)){u((K(),K(),J),new H(new Ab(a)),67108864,null);!!a.a&&S(a.a);Hb(a.f);a.c=a.c&-8|1}}
function Ib(a){if(1==(3&a.a)){a.a=-4&a.a|0;0==(a.a&ql)?Jb(a):nb(a.b.a);0!=(a.a&524288)&&(2==(3&a.a)||(a.a=-4&a.a|2))}}
function s(a){return ed(a)?gi(a):dd(a)?gd(a):cd(a)?a?1231:1237:ad(a)?a.w():Vc(a)?ai(a):!!a&&!!a.hashCode?a.hashCode():ai(a)}
function Kf(a){var b;if(Array.isArray(a)&&a.rb===Lf){return Tf(r(a))+'@'+(b=s(a)>>>0,b.toString(16))}return a.toString()}
function gi(a){ei();var b,c,d;c=':'+a;d=di[c];if(d!=null){return gd(d)}d=bi[c];b=d==null?fi(a):gd(d);hi();di[c]=b;return b}
function ki(a){var b,c;b=li($wnd.React.Element,$wnd.React.Fragment);b.key=null;b.ref=null;b.props=(c={},c[wl]=a,c);return b}
function Uf(){this.g=Rf++;this.j=null;this.h=null;this.f=null;this.d=null;this.b=null;this.i=null;this.a=null}
function ck(a){this.e=new Jk;this.c=a;K();++ak;this.b=new hc(new dk(this),new ek(this),false);this.a=new wb(null,new gk(this),1411518464)}
function zj(){xj();return Xc(Rc(Oe,1),pl,5,0,[bj,cj,dj,ej,fj,gj,hj,ij,jj,kj,lj,mj,nj,oj,pj,qj,rj,sj,tj,uj,vj,wj])}
function xb(a,b){vb.call(this,a,new yb(a),null,b|(ql==(b&rl)?0:524288)|(0==(b&6291456)?ql==(b&rl)?4194304:sl:0)|0|268435456|0)}
function Lb(a){var b,c,d;for(b=0;b<a.a.length;b++){d=a.a[b];if(0!=(d.c?d.a.length-d.b+d.d:d.d-d.b)){c=N(d);return c}}return null}
function yc(){var a;if(tc!=0){a=sc();if(a-uc>2000){uc=a;vc=$wnd.setTimeout(Ec,10)}}if(tc++==0){Hc((Gc(),Fc));return true}return false}
function fg(a){var b;b=dg(a);if(b>3.4028234663852886E38){return Infinity}else if(b<-3.4028234663852886E38){return -Infinity}return b}
function ag(a,b){var c=0;while(!b[c]||b[c]==''){c++}var d=b[c++];for(;c<b.length;c++){if(!b[c]||b[c]==''){continue}d+=a+b[c]}return d}
function Ng(a,b){var c,d;d=a.a.length;b.length<d&&(b=Zh(new Array(d),b));for(c=0;c<d;++c){b[c]=a.a[c]}b.length>d&&(b[d]=null);return b}
function pg(a,b){var c,d,e,f;f=a.Y();b.length<f&&(b=Zh(new Array(f),b));e=b;d=a.T();for(c=0;c<f;++c){e[c]=d.cb()}b.length>f&&(b[f]=null);return b}
function Pc(){if(Error.stackTraceLimit>0){$wnd.Error.stackTraceLimit=Error.stackTraceLimit=64;return true}return 'stack' in new Error}
function q(a,b){return ed(a)?o(a,b):dd(a)?a===b:cd(a)?fd(a)===fd(b):ad(a)?a.u(b):Vc(a)?o(a,b):!!a&&!!a.equals?a.equals(b):fd(a)===fd(b)}
function _c(a,b){if(ed(a)){return !!$c[b]}else if(a.qb){return !!a.qb[b]}else if(dd(a)){return !!Zc[b]}else if(cd(a)){return !!Yc[b]}return false}
function ri(a,b){var c,d,e,f,g;c=null;for(e=b,f=0,g=e.length;f<g;++f){d=e[f];null!=d&&(null==c?(c=d):(c+=' '+d))}null!=c&&(a.className=c);return a}
function N(a){var b;if(0==(a.c?a.a.length-a.b+a.d:a.d-a.b)){return null}b=a.a[a.b];a.a[a.b]=null;++a.b;if(a.b>=a.a.length){a.b=0;a.c=false}return b}
function T(a){a.i?hb(a.e):gb(a.e);if(ub(a.f)){if(a.i&&(K(),!(!!Qb&&!!Qb.e))){return u((K(),K(),J),new Y(a),83888128,null)}else{nb(a.f)}}return W(a)}
function Zb(a){var b,c,d;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Kg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;6!=d&&tb(b,6,true)}}}
function $b(a){var b,c,d;if(a.c.a.length>0&&4==a.a){a.a=5;for(c=new Kg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);d=b.c&7;4==d&&tb(b,5,true)}}}
function Yb(a){var b,c;if(a.c.a.length>0&&6!=a.a){a.a=6;for(c=new Kg(a.c);c.a<c.c.a.length;){b=(c.b=c.a++,c.c.a[c.b]);5==(b.c&7)?tb(b,6,true):4==(b.c&7)&&(a.a=4)}}}
function Uc(a,b){var c=new Array(b);var d;switch(a){case 14:case 15:d=0;break;case 16:d=false;break;default:return c;}for(var e=0;e<b;++e){c[e]=d}return c}
function t(b,c,d){var e,f;try{ac(b,d);try{f=(c.a.A(),null)}finally{bc()}return f}catch(a){a=wf(a);if(bd(a,4)){e=a;throw xf(e)}else throw xf(a)}finally{D(b)}}
function u(b,c,d,e){var f,g;try{if(0==(d&2048)&&!!Qb){g=c.B()}else{ac(b,e);try{g=c.B()}finally{bc()}}return g}catch(a){a=wf(a);if(bd(a,4)){f=a;throw xf(f)}else throw xf(a)}finally{D(b)}}
function X(a,b,c,d){this.c=a;this.g=b;this.h=c;this.j=null;this.i=16384==(d&16384);this.f=new xb(this,d&-16385);this.e=new jb(this.f);ql==(d&rl)&&mb(this.f)}
function Cb(a){var b,c;if(0==a.c){b=Mb(a.d);if(0==b){a.a=0;return false}else if(a.a+1>a.b){a.a=0;return false}else{a.a=a.a+1;a.c=b}}--a.c;c=Lb(a.d);Ib(c);return true}
function Bf(b,c,d,e){Af();var f=yf;$moduleName=c;$moduleBase=d;vf=e;function g(){for(var a=0;a<f.length;a++){f[a]()}}
if(b){try{nl(g)()}catch(a){b(c,a)}}else{nl(g)()}}
function li(a,b){var c;c=new $wnd.Object;c.$$typeof=a;c.type=b;c._owner=$wnd.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.current;return c}
function Yg(){function b(){try{return (new Map).entries().next().done}catch(a){return false}}
if(typeof Map==='function'&&Map.prototype.entries&&b()){return Map}else{return Zg()}}
function Ef(){Df={};!Array.isArray&&(Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'});function b(){return (new Date).getTime()}
!Date.now&&(Date.now=b)}
function Lc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].sb()&&(c=Kc(c,g)):g[0].sb()}catch(a){a=wf(a);if(bd(a,4)){d=a;wc();Cc(bd(d,31)?d.J():d)}else throw xf(a)}}return c}
function R(b){var c,d,e;e=b.j;try{d=b.c.B();if(!(fd(e)===fd(d)||e!=null&&q(e,d))){b.j=d;b.b=null;eb(b.e)}}catch(a){a=wf(a);if(bd(a,8)){c=a;if(!b.b){b.j=null;b.b=c;eb(b.e)}throw xf(c)}else throw xf(a)}}
function Vh(a,b,c,d,e){var f,g,h,i,j;if(a===c){a=a.slice(b,b+e);b=0}h=c;for(g=b,i=b+e;g<i;){f=$wnd.Math.min(g+10000,i);e=f-g;j=a.slice(g,f);j.splice(0,0,d,0);Array.prototype.splice.apply(h,j);g=f;d+=e}}
function Dj(a){var b,c,d,e;c=Hk(a.e);if(0!=c&&null!=a.f){b=(Of(),Nf);e=b.createRange();d=Ik(a.e);e.setStart(a.f.firstChild,d);e.setEnd(a.f.firstChild,d+c);return e.getBoundingClientRect()}else{return null}}
function dg(a){cg==null&&(cg=new RegExp('^\\s*[+-]?(NaN|Infinity|((\\d+\\.?\\d*)|(\\.\\d+))([eE][+-]?\\d+)?[dDfF]?)\\s*$'));if(!cg.test(a)){throw xf(new ig('For input string: "'+a+'"'))}return parseFloat(a)}
function fi(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)));b=b|0;c+=4}while(c<d){b=b*31+jg(a,c++)}b=b|0;return b}
function P(a){var b,c,d,e,f,g;b=a.c?a.a.length-a.b+a.d:a.d-a.b;if(b+1>a.a.length){g=(a.a.length-1)*2+1;c=Tc(Zd,pl,1,g,5,1);f=0;for(d=0;d<b;d++){e=(a.b+d)%a.a.length;c[f]=a.a[e];a.a[e]=null;++f}a.a=c;a.b=0;a.d=f;a.c=false}}
function nb(b){var c;if(1!=(b.c&7)){try{if(4!=(b.c&7)){if(0!=(b.c&512)){!!b.e&&(b.c&=-513);c=b.d;v((K(),K(),J),b,c)}else{_j(b.e.a)}}else 0!=(b.c&512)&&!!b.e&&(b.c&=-513)}catch(a){a=wf(a);if(bd(a,4)){K()}else throw xf(a)}}}
function vb(a,b,c,d){this.b=new Ig;this.f=new Kb(new zb(this),d&6520832|262144|ql);this.c=d&-6520833|3;this.a=a;this.d=b;this.e=c;!!this.d&&(this.c|=512);!this.a&&!!this.d&&(C((K(),K(),J),this),0==(this.f.a&sl)&&D((null,J)))}
function Gf(a,b,c){var d=Df,h;var e=d[a];var f=e instanceof Array?e[0]:null;if(e&&!f){_=e}else{_=(h=b&&b.prototype,!h&&(h=Df[b]),Jf(h));_.qb=c;!b&&(_.rb=Lf);d[a]=_}for(var g=3;g<arguments.length;++g){arguments[g].prototype=_}f&&(_.pb=f)}
function _f(a){if(a.R()){var b=a.c;b.S()?(a.j='['+b.i):!b.R()?(a.j='[L'+b.P()+';'):(a.j='['+b.P());a.b=b.O()+'[]';a.h=b.Q()+'[]';return}var c=a.f;var d=a.d;d=d.split('/');a.j=ag('.',[c,ag('$',d)]);a.b=ag('.',[c,ag('.',d)]);a.h=d[d.length-1]}
function qg(a,b){var c,d,e,f,g;e=b.b.value[0];g=eh(b);f=e==null?rg(Sg((d=a.a.a.get(0),d==null?new Array:d))):ah(a.b,e);if(!(fd(g)===fd(f)||g!=null&&q(g,f))){return false}if(f==null&&!(e==null?!!Sg((c=a.a.a.get(0),c==null?new Array:c)):_g(a.b,e))){return false}return true}
function ub(b){var c,d,e,f,g;g=b.c&7;switch(g){case 4:return false;case 3:case 6:return true;case 5:{for(e=new Kg(b.b);e.a<e.c.a.length;){d=(e.b=e.a++,e.c.a[e.b]);if(d.b){f=d.b;c=f.a;try{T(c)}catch(a){a=wf(a);if(!bd(a,4))throw xf(a)}if(6==(b.c&7)){return true}}}}}pb(b);return false}
function ni(a,b,c){var d,e,f,g;d={};e=null;f=null;if(null!=b){e='key' in b?b['key']:null;f='ref' in b?b['ref']:null;ji(b,If(qi.prototype.lb,qi,[d,b]))}null!=c&&c.length>0&&(1==c.length?(d[wl]=c[0],undefined):(d[wl]=c,undefined));return g=li($wnd.React.Element,a),g.key=e,g.ref=f,g.props=d,g}
function kc(d,b){if(b instanceof Object){try{b.__java$exception=d;if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1&&$doc.documentMode<9){return}var c=d;Object.defineProperties(b,{cause:{get:function(){var a=c.H();return a&&a.F()}},suppressed:{get:function(){return c.G()}}})}catch(a){}}}
function ik(a,b){var c;c=b.type;if(!o('boundary',c)){V(a.e);V(a.b)}if((o('error',c)||o('end',c))&&(Of(),$wnd.goog.global.window).speechSynthesis.paused){(Of(),$wnd.goog.global.window).speechSynthesis.cancel()}else if(o('boundary',c)&&o(b.name,'word')){gc(new Rk(a,b.charIndex));gc(new Sk(a,b.charLength))}}
function Xg(){if(!Object.create||!Object.getOwnPropertyNames){return false}var a='__proto__';var b=Object.create(null);if(b[a]!==undefined){return false}var c=Object.getOwnPropertyNames(b);if(c.length!=0){return false}b[a]=42;if(b[a]!==42){return false}if(Object.getOwnPropertyNames(b).length==0){return false}return true}
function tb(a,b,c){var d,e,f,g;g=a.c&7;if(b!=g){a.c=a.c&-8|b;if(!a.a&&6==b){c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(!!a.a&&4==g&&(6==b||5==b)){ib(a.a.e);c&&(1==(a.c&7)||1==(3&a.f.a)||C((K(),K(),J),a))}else if(3==b||3!=g&&2==b){if(a.a){d=a.a;sb((e=d.h,e));d.j=null}Cg(a.b,new Bb(a));a.b.a=Tc(Zd,pl,1,0,5,1)}else 3==g&&(3&b)==0&&!!a.a&&sb((f=a.a.g,f))}}
function xj(){xj=Hf;bj=new yj(xl,0);cj=new yj('checkbox',1);dj=new yj('color',2);ej=new yj('date',3);fj=new yj('datetime',4);gj=new yj('email',5);hj=new yj('file',6);ij=new yj('hidden',7);jj=new yj('image',8);kj=new yj('month',9);lj=new yj('number',10);mj=new yj('password',11);nj=new yj('radio',12);oj=new yj('range',13);pj=new yj('reset',14);qj=new yj('search',15);rj=new yj('submit',16);sj=new yj('tel',17);tj=new yj('text',18);uj=new yj('time',19);vj=new yj('url',20);wj=new yj('week',21)}
function jk(a){var b,c;gc(new Rk(a,0));gc(new Sk(a,0));c=new $wnd.SpeechSynthesisUtterance((hb(a.f),a.n));c.voice=(hb(a.i),a.q);c.volume=(hb(a.k),a.r);c.pitch=(hb(a.c),a.l);b=(hb(a.d),a.m);c.rate=$wnd.Math.pow($wnd.Math.abs(b)+1,b<0?-1:1);c.onstart=If(el.prototype.M,el,[a]);c.onend=If(fl.prototype.M,fl,[a]);c.onerror=If(gl.prototype.L,gl,[a]);c.onboundary=If(hl.prototype.M,hl,[a]);c.onpause=If(il.prototype.M,il,[a]);c.onresume=If(jl.prototype.M,jl,[a]);(Of(),$wnd.goog.global.window).speechSynthesis.speak(c)}
function Tb(a){var b,c,d,e,f,g,h,i,j,k,l,m,n;if(!a.e){return}j=(n=a.e.c&7,n>3?n:4);e=false;c=0;if(!!a.b&&1!=(a.e.c&7)){m=a.b.a.length;for(h=0;h<m;h++){k=Dg(a.b,h);if(-1!=k.e&&-2!=k.e){k.e=-1;h!=c&&Hg(a.b,c,k);++c;if(k.b){l=k.b;f=l.c&7;f==6&&(j=f)}}}}d=a.e.b;for(i=d.a.length-1;i>=0;i--){k=d.a[i];if(-1==k.e){k.e=0}else{db(k,a.e);e=true}}2<(a.e.c&7)&&4!=j&&(a.e.c&7)<j&&tb(a.e,j,false);if(a.b){for(g=c-1;g>=0;g--){k=Dg(a.b,g);if(-1==k.e){k.e=0;cb(k,a.e);e=true}}}if(a.b){for(g=a.b.a.length-1;g>=c;g--){Fg(a.b,g)}e&&rb(a.e,a.b)}else{e&&rb(a.e,new Ig)}if($(a.e)&&!!a.e.a){b=a.e.a;k=b.e;!!k.b&&ql!=(k.b.c&rl)&&k.c.a.length<=0&&0==k.b.a.d&&Xb(a,k)}}
function Jk(){var a,b,c,d,e,f,g,h,i,j,k,l,m,n;this.t=new ll(this);K();++lk;this.s=new hc(null,new Kk(this),true);this.l=0.5;this.m=0;this.r=1;this.n='Call me Ishmael. Some years ago, never mind how long precisely, having little or no money in my purse, and nothing particular to interest me on shore, I thought I would sail about a little and see the watery part of the world.';this.h=(i=new jb((b=null,b)),i);this.g=(j=new jb((c=null,c)),j);this.c=(k=new jb((d=null,d)),k);this.d=(l=new jb((e=null,e)),l);this.k=(m=new jb((f=null,f)),m);this.i=(n=new jb((g=null,g)),n);this.f=(h=new jb((a=null,a)),h);this.e=new X(new Nk,null,null,35667968);this.b=new X(new Ok,null,null,35667968);this.j=new X(new Pk,new Lk(this),new Mk(this),35651584);this.a=new wb(new Qk(this),null,413138944);D((null,J))}
function Zg(){function e(){this.obj=this.createObject()}
;e.prototype.createObject=function(a){return Object.create(null)};e.prototype.get=function(a){return this.obj[a]};e.prototype.set=function(a,b){this.obj[a]=b};e.prototype['delete']=function(a){delete this.obj[a]};e.prototype.keys=function(){return Object.getOwnPropertyNames(this.obj)};e.prototype.entries=function(){var b=this.keys();var c=this;var d=0;return {next:function(){if(d>=b.length)return {done:true};var a=b[d++];return {value:[a,c.get(a)],done:false}}}};if(!Xg()){e.prototype.createObject=function(){return {}};e.prototype.get=function(a){return this.obj[':'+a]};e.prototype.set=function(a,b){this.obj[':'+a]=b};e.prototype['delete']=function(a){delete this.obj[':'+a]};e.prototype.keys=function(){var a=[];for(var b in this.obj){b.charCodeAt(0)==58&&a.push(b.substring(1))}return a}}return e}
function $j(a){var b,c,d,e,f;a.d=0;Bj();b=(c=zk(a.e),ni(yl,ri(new $wnd.Object,Xc(Rc(_d,1),pl,2,6,[T(a.e.e)?'speaking':null])),[ni('h1',null,['Web Speech Synthesis Demo']),ni('form',null,[ni(yl,si(new $wnd.Object,'textarea'),[T(a.e.e)?ki([ni(yl,si(ui(new $wnd.Object,If(Mj.prototype.C,Mj,[a])),'textbeingspoken'),[yk(a.e)]),ni(yl,vi(new $wnd.Object,(d=Dj(a),e=(Of(),Nf).body,f=Hk(a.e),Ci(Hi(Di(Fi(Gi(Bi(Ai(Ei(new $wnd.Object)),0==f?'none':'block'),0==f?'all 0s ease 0s':'all 50ms ease'),null==d?'0':d.top-1+e.clientHeight-e.scrollHeight+8+'px'),null==d?'0':d.left-1+e.clientWidth-e.scrollWidth-8+'px'),null==d?'0':d.width+'px'),null==d?'0':d.height+'px'))),null)]):ni('textarea',Li(xi(Oi(new $wnd.Object,yk(a.e)),T(a.e.e)),If(Nj.prototype.mb,Nj,[a])),null)]),ni(yl,ri(new $wnd.Object,Xc(Rc(_d,1),pl,2,6,[zl])),[ni(Al,Pi(new $wnd.Object,'pitch'),['Pitch']),ni('input',Li(xi(Mi(Ji(Ki(Oi(zi(si(new $wnd.Object,'pitch'),(xj(),oj)),''+wk(a.e)),'0'),'1'),'0.05'),T(a.e.e)),If(Sj.prototype.mb,Sj,[a])),null),ni(xl,yi(xi(wi(ti(zi(new $wnd.Object,($i(),Xi)),Bl),Bl),T(a.e.e)),If(Tj.prototype.nb,Tj,[a])),[Cl])]),ni(yl,ri(new $wnd.Object,Xc(Rc(_d,1),pl,2,6,[zl])),[ni(Al,Pi(new $wnd.Object,'rate'),['Rate']),ni('input',Li(xi(Mi(Ji(Ki(Oi(zi(si(new $wnd.Object,'rate'),oj),''+xk(a.e)),'-3'),'3'),'0.25'),T(a.e.e)),If(Uj.prototype.mb,Uj,[a])),null),ni(xl,yi(xi(wi(ti(zi(new $wnd.Object,Xi),Dl),Dl),T(a.e.e)),If(Vj.prototype.nb,Vj,[a])),[Cl])]),ni(yl,ri(new $wnd.Object,Xc(Rc(_d,1),pl,2,6,[zl])),[ni(Al,Pi(new $wnd.Object,'volume'),['Volume']),ni('input',Li(xi(Mi(Ji(Ki(Oi(zi(si(new $wnd.Object,'volume'),oj),''+Ak(a.e)),'0'),'1'),'0.05'),T(a.e.e)),If(Wj.prototype.mb,Wj,[a])),null),ni(xl,yi(xi(wi(ti(zi(new $wnd.Object,Xi),El),El),T(a.e.e)),If(Xj.prototype.nb,Xj,[a])),[Cl])]),ni(yl,ri(new $wnd.Object,Xc(Rc(_d,1),pl,2,6,[zl])),[ni(Al,Pi(new $wnd.Object,'voice'),['Voice']),ni('select',Oi(xi(Li(new $wnd.Object,If(Kj.prototype.mb,Kj,[a])),T(a.e.e)),null==c?'':c.voiceURI),Gh(Eh(T(a.e.j).$(),new Lj),new pi)),ni(xl,yi(xi(wi(ti(zi(new $wnd.Object,Xi),Fl),Fl),T(a.e.e)),If(Oj.prototype.nb,Oj,[a])),[Cl])]),ni(yl,ri(new $wnd.Object,Xc(Rc(_d,1),pl,2,6,['bottom'])),[ni(xl,yi(xi(wi(ti(ri(zi(new $wnd.Object,Xi),Xc(Rc(_d,1),pl,2,6,['small'])),'Speak'),'Speak'),T(a.e.e)),If(Pj.prototype.nb,Pj,[a])),['Speak']),ni(xl,yi(xi(wi(ti(ri(zi(new $wnd.Object,Xi),Xc(Rc(_d,1),pl,2,6,['small'])),T(a.e.b)?Gl:'Pause'),T(a.e.b)?Gl:'Pause'),!T(a.e.e)),If(Qj.prototype.nb,Qj,[a])),[T(a.e.b)?Gl:'Pause']),ni(xl,yi(xi(wi(ti(ri(zi(new $wnd.Object,Xi),Xc(Rc(_d,1),pl,2,6,['small'])),'Stop'),'Stop'),!T(a.e.e)),If(Rj.prototype.nb,Rj,[])),['Stop'])])])]));return b}
var ol={10:1},pl={3:1},ql=1048576,rl=1835008,sl=2097152,tl='__noinit__',ul={3:1,8:1,6:1,4:1},vl={3:1,35:1,60:1},wl='children',xl='button',yl='div',zl='speecharg',Al='label',Bl='Reset pitch',Cl='\u21B6',Dl='Reset rate',El='Reset volume',Fl='Reset voice',Gl='Resume',Hl='voiceschanged',Il=142606336;var _,Df,yf,vf=-1;$wnd.goog=$wnd.goog||{};$wnd.goog.global=$wnd.goog.global||$wnd;Ef();Gf(1,null,{},p);_.u=function(a){return o(this,a)};_.v=function(){return this.pb};_.w=Jl;_.equals=function(a){return this.u(a)};_.hashCode=function(){return this.w()};var Yc,Zc,$c;Gf(44,1,{},Uf);_.N=function(a){var b;b=new Uf;b.e=4;a>1?(b.c=Zf(this,a-1)):(b.c=this);return b};_.O=function(){Sf(this);return this.b};_.P=function(){return Tf(this)};_.Q=function(){Sf(this);return this.h};_.R=function(){return (this.e&4)!=0};_.S=function(){return (this.e&1)!=0};_.e=0;_.g=0;var Rf=1;var Zd=Wf(1);var Od=Wf(44);Gf(75,1,{},F);_.b=1;_.c=false;_.d=true;_.e=0;var md=Wf(75);Gf(76,1,ol,G);_.A=function(){Db(this.a)};var jd=Wf(76);Gf(36,1,{},H);_.B=function(){return this.a.A(),null};var kd=Wf(36);Gf(77,1,{},I);var ld=Wf(77);var J;Gf(38,1,{38:1},Q);_.b=0;_.c=false;_.d=0;var nd=Wf(38);Gf(157,1,{});var qd=Wf(157);Gf(40,157,{},X);_.a=false;_.d=0;_.i=false;var pd=Wf(40);Gf(114,1,{},Y);_.B=function(){return U(this.a)};var od=Wf(114);Gf(13,157,{13:1},jb);_.a=4;_.d=false;_.e=0;var sd=Wf(13);Gf(113,1,ol,kb);_.A=function(){bb(this.a)};var rd=Wf(113);Gf(21,157,{21:1},wb,xb);_.c=0;var xd=Wf(21);Gf(108,1,{},yb);_.A=function(){R(this.a)};var td=Wf(108);Gf(109,1,ol,zb);_.A=function(){nb(this.a)};var ud=Wf(109);Gf(110,1,ol,Ab);_.A=function(){qb(this.a)};var vd=Wf(110);Gf(111,1,{},Bb);_.C=function(a){ob(this.a,a)};var wd=Wf(111);Gf(88,1,{},Eb);_.a=0;_.b=0;_.c=0;var yd=Wf(88);Gf(118,1,{},Gb);_.a=false;var zd=Wf(118);Gf(52,157,{52:1},Kb);_.a=0;var Bd=Wf(52);Gf(87,1,{},Pb);var Ad=Wf(87);Gf(120,1,{},_b);_.a=0;var Qb;var Cd=Wf(120);Gf(53,1,{},hc);_.g=0;var Ed=Wf(53);Gf(107,1,ol,ic);_.A=function(){fc(this.a)};var Dd=Wf(107);Gf(4,1,{3:1,4:1});_.D=function(a){return new Error(a)};_.F=Kl;_.G=function(){return Gh(Eh(Mg((this.e==null&&(this.e=Tc(be,pl,4,0,0,1)),this.e)),new lg),new Kh)};_.H=function(){return this.c};_.I=function(){lc(this,nc(this.D(mc(this,this.d))));Oc(this)};_.b=tl;_.f=true;var be=Wf(4);Gf(8,4,{3:1,8:1,4:1});var Rd=Wf(8);Gf(6,8,ul);var $d=Wf(6);Gf(46,6,ul);var Vd=Wf(46);Gf(71,46,ul);var Id=Wf(71);Gf(31,71,{31:1,3:1,8:1,6:1,4:1},rc);_.J=function(){return fd(this.a)===fd(pc)?null:this.a};var pc;var Fd=Wf(31);var Gd=Wf(0);Gf(139,1,{});var Hd=Wf(139);var tc=0,uc=0,vc=-1;Gf(82,139,{},Jc);var Fc;var Jd=Wf(82);var Mc;Gf(151,1,{});var Ld=Wf(151);Gf(72,151,{},Qc);var Kd=Wf(72);var Nf;Gf(74,6,ul);var Ud=Wf(74);Gf(112,74,ul,Pf);var Md=Wf(112);Yc={3:1,67:1,30:1};var Nd=Wf(67);Gf(149,1,pl);var cg;var Yd=Wf(149);Zc={3:1,30:1};var Pd=Wf(150);Gf(22,1,{3:1,30:1,22:1});_.u=function(a){return this===a};_.w=Jl;_.b=0;var Qd=Wf(22);Gf(45,6,ul);var Sd=Wf(45);Gf(73,6,ul,gg);var Td=Wf(73);Gf(223,1,{});Gf(78,46,ul,hg);_.D=function(a){return new TypeError(a)};var Wd=Wf(78);Gf(68,45,ul,ig);var Xd=Wf(68);$c={3:1,66:1,30:1,2:1};var _d=Wf(2);Gf(227,1,{});Gf(63,1,{},lg);_.U=function(a){return a.b};var ae=Wf(63);Gf(37,6,ul,mg);var ce=Wf(37);Gf(152,1,{35:1});_.Z=function(){return new vh(this,0)};_.$=function(){return new Hh(null,this.Z())};_.V=function(a){throw xf(new mg('Add not supported on this collection'))};_.W=function(a){return ng(this,a)};_.X=function(){return this.Y()==0};_._=function(a){return pg(this,a)};var de=Wf(152);Gf(155,1,{136:1});_.u=function(a){var b,c,d;if(a===this){return true}if(!bd(a,39)){return false}d=a;if(this.a.b+this.b.b!=d.a.b+d.b.b){return false}for(c=new xg((new ug(d)).a);c.b;){b=wg(c);if(!qg(this,b)){return false}}return true};_.w=function(){return Pg(new ug(this))};var ke=Wf(155);Gf(89,155,{136:1});var ge=Wf(89);Gf(154,152,{35:1,161:1});_.Z=function(){return new vh(this,1)};_.u=function(a){var b;if(a===this){return true}if(!bd(a,20)){return false}b=a;if(sg(b.a)!=this.Y()){return false}return og(this,b)};_.w=function(){return Pg(this)};var le=Wf(154);Gf(20,154,{20:1,35:1,161:1},ug);_.W=function(a){return tg(this,a)};_.T=function(){return new xg(this.a)};_.Y=function(){return sg(this.a)};var fe=Wf(20);Gf(23,1,{},xg);_.ab=Ll;_.cb=function(){return wg(this)};_.bb=Kl;_.b=false;var ee=Wf(23);Gf(153,152,{35:1,60:1});_.Z=function(){return new vh(this,16)};_.db=function(a,b){throw xf(new mg('Add not supported on this list'))};_.V=function(a){this.db(this.Y(),a);return true};_.u=function(a){var b,c,d,e,f;if(a===this){return true}if(!bd(a,60)){return false}f=a;if(this.Y()!=f.Y()){return false}e=f.T();for(c=this.T();c.bb();){b=c.cb();d=e.cb();if(!(fd(b)===fd(d)||b!=null&&q(b,d))){return false}}return true};_.w=function(){return Qg(this)};_.T=function(){return new zg(this)};_.fb=function(a){throw xf(new mg('Remove not supported on this list'))};var ie=Wf(153);Gf(81,1,{},zg);_.ab=Ll;_.bb=function(){return this.a<this.b.Y()};_.cb=function(){return this.a<this.b.Y(),this.b.eb(this.a++)};_.a=0;var he=Wf(81);Gf(156,1,{162:1});_.u=function(a){var b;if(!bd(a,32)){return false}b=a;return hh(this.b.value[0],b.b.value[0])&&hh(eh(this),eh(b))};_.w=function(){return ih(this.b.value[0])^ih(eh(this))};var je=Wf(156);Gf(12,153,vl,Ig,Jg);_.db=function(a,b){Wh(this.a,a,b)};_.V=function(a){return Bg(this,a)};_.W=function(a){return Eg(this,a,0)!=-1};_.eb=function(a){return Dg(this,a)};_.X=function(){return this.a.length==0};_.T=function(){return new Kg(this)};_.fb=function(a){return Fg(this,a)};_.Y=Ml;_._=function(a){var b,c;c=this.a.length;a.length<c&&(a=Zh(new Array(c),a));for(b=0;b<c;++b){a[b]=this.a[b]}a.length>c&&(a[c]=null);return a};var ne=Wf(12);Gf(15,1,{},Kg);_.ab=Ll;_.bb=function(){return this.a<this.c.a.length};_.cb=function(){return this.b=this.a++,this.c.a[this.b]};_.a=0;_.b=-1;var me=Wf(15);Gf(80,153,vl,Og);_.W=function(a){return yg(this,a)!=-1};_.eb=function(a){return this.a[a]};_.Y=Ml;_._=function(a){return Ng(this,a)};var oe=Wf(80);Gf(39,89,{3:1,39:1,136:1},Rg);var pe=Wf(39);Gf(90,1,{},Tg);_.T=function(){return new Ug(this)};_.b=0;var re=Wf(90);Gf(48,1,{},Ug);_.ab=Ll;_.cb=function(){return this.d=this.a[this.c++],this.d};_.bb=function(){var a;if(this.c<this.a.length){return true}a=this.b.next();if(!a.done){this.a=a.value[1];this.c=0;return true}return false};_.c=0;_.d=null;var qe=Wf(48);var Vg;Gf(91,1,{},bh);_.T=function(){return new dh(this)};_.b=0;_.c=0;var ue=Wf(91);Gf(49,1,{},dh);_.ab=Ll;_.cb=function(){return this.c=this.a,this.a=this.b.next(),new fh(this.d,this.c,this.d.c)};_.bb=function(){return !this.a.done};var se=Wf(49);Gf(32,156,{32:1,162:1},fh);_.c=0;var te=Wf(32);Gf(33,1,{33:1},mh);_.u=function(a){var b;if(a===this){return true}if(!bd(a,33)){return false}b=a;return hh(this.a,b.a)};_.w=function(){return ih(this.a)};var jh;var ve=Wf(33);Gf(93,1,{});_.ab=Nl;_.gb=function(){return this.d};_.hb=function(){return this.e};_.d=0;_.e=0;var ze=Wf(93);Gf(50,93,{});var we=Wf(50);Gf(83,1,{});_.ab=Nl;_.gb=Kl;_.hb=function(){return this.d-this.c};_.b=0;_.c=0;_.d=0;var ye=Wf(83);Gf(84,83,{},th);_.ab=function(a){qh(this,a)};_.ib=function(a){return rh(this,a)};var xe=Wf(84);Gf(19,1,{},vh);_.gb=function(){return this.a};_.hb=function(){uh(this);return this.c};_.ab=function(a){uh(this);this.d.ab(a)};_.ib=function(a){uh(this);if(this.d.bb()){a.C(this.d.cb());return true}return false};_.a=0;_.c=0;var Ae=Wf(19);Gf(65,1,{},wh);_.U=function(a){return a};var Be=Wf(65);Gf(119,1,{},xh);var Ce=Wf(119);Gf(92,1,{});_.c=false;var Le=Wf(92);Gf(24,92,{},Hh);var Ke=Wf(24);Gf(64,1,{},Kh);_.jb=function(a){return Tc(Zd,pl,1,a,5,1)};var De=Wf(64);Gf(95,50,{},Mh);_.ib=function(a){this.b=false;while(!this.b&&this.c.ib(new Nh(this,a)));return this.b};_.b=false;var Fe=Wf(95);Gf(97,1,{},Nh);_.C=function(a){Lh(this.a,this.b,a)};var Ee=Wf(97);Gf(94,50,{},Ph);_.ib=function(a){return this.b.ib(new Qh(this,a))};var He=Wf(94);Gf(96,1,{},Qh);_.C=function(a){Oh(this.a,this.b,a)};var Ge=Wf(96);Gf(51,1,{},Sh);_.C=function(a){Rh(this,a)};var Ie=Wf(51);Gf(98,1,{},Uh);_.C=function(a){Th(this,a)};var Je=Wf(98);Gf(225,1,{});Gf(222,1,{});var _h=0;var bi,ci=0,di;Gf(830,1,{});Gf(855,1,{});Gf(117,1,{},pi);_.jb=function(a){return new Array(a)};var Me=Wf(117);Gf(206,$wnd.Function,{},qi);_.lb=function(a){oi(this.a,this.b,a)};Gf(25,22,{3:1,30:1,22:1,25:1},_i);var Xi,Yi,Zi;var Ne=Xf(25,aj);Gf(5,22,{3:1,30:1,22:1,5:1},yj);var bj,cj,dj,ej,fj,gj,hj,ij,jj,kj,lj,mj,nj,oj,pj,qj,rj,sj,tj,uj,vj,wj;var Oe=Xf(5,zj);var Aj;Gf(207,$wnd.Function,{},Cj);_.K=function(a){return Fb(Aj),Aj=null,null};Gf(100,1,{});var Re=Wf(100);Gf(189,$wnd.Function,{},Kj);_.mb=function(a){Jj(this.a,a)};Gf(86,1,{},Lj);_.U=function(a){return ni('option',Oi(new $wnd.Object,a.voiceURI),[a.name+' ('+a.lang+')'])};var Pe=Wf(86);Gf(179,$wnd.Function,{},Mj);_.C=function(a){Ej(this.a,a)};Gf(181,$wnd.Function,{},Nj);_.mb=function(a){Fj(this.a,a)};Gf(190,$wnd.Function,{},Oj);_.nb=function(a){Ek(this.a.e)};Gf(191,$wnd.Function,{},Pj);_.nb=function(a){jk(this.a.e)};Gf(192,$wnd.Function,{},Qj);_.nb=function(a){T(this.a.e.b)?(Of(),$wnd.goog.global.window).speechSynthesis.resume():(Of(),$wnd.goog.global.window).speechSynthesis.pause()};Gf(193,$wnd.Function,{},Rj);_.nb=function(a){(Of(),$wnd.goog.global.window).speechSynthesis.cancel()};Gf(182,$wnd.Function,{},Sj);_.mb=function(a){Gj(this.a,a)};Gf(183,$wnd.Function,{},Tj);_.nb=function(a){gc(new Tk(this.a.e,0.5))};Gf(184,$wnd.Function,{},Uj);_.mb=function(a){Hj(this.a,a)};Gf(185,$wnd.Function,{},Vj);_.nb=function(a){gc(new Uk(this.a.e,0))};Gf(186,$wnd.Function,{},Wj);_.mb=function(a){Ij(this.a,a)};Gf(187,$wnd.Function,{},Xj);_.nb=function(a){gc(new Vk(this.a.e,1))};Gf(62,1,{},Yj);var Qe=Wf(62);Gf(101,100,{});_.d=0;var qf=Wf(101);Gf(102,101,{},ck);var ak=0;var We=Wf(102);Gf(103,1,ol,dk);_.A=function(){Z(this.a.e)};var Se=Wf(103);Gf(104,1,ol,ek);_.A=function(){lb(this.a.a)};var Te=Wf(104);Gf(106,1,{},fk);_.B=function(){return $j(this.a)};var Ue=Wf(106);Gf(105,1,{},gk);_.A=function(){_j(this.a)};var Ve=Wf(105);Gf(121,1,{});var uf=Wf(121);Gf(122,121,{},Jk);_.l=0;_.m=0;_.o=0;_.p=0;_.r=0;var lk=0;var of=Wf(122);Gf(123,1,ol,Kk);_.A=function(){mk(this.a)};var Xe=Wf(123);Gf(127,1,{},Lk);_.A=function(){nk(this.a)};var Ye=Wf(127);Gf(128,1,{},Mk);_.A=function(){ok(this.a)};var Ze=Wf(128);Gf(124,1,{},Nk);_.B=function(){return Qf(),(Of(),$wnd.goog.global.window).speechSynthesis.speaking?true:false};var $e=Wf(124);Gf(125,1,{},Ok);_.B=function(){return Qf(),(Of(),$wnd.goog.global.window).speechSynthesis.paused?true:false};var _e=Wf(125);Gf(126,1,{},Pk);_.B=function(){var a;return a=(Of(),$wnd.goog.global.window).speechSynthesis.getVoices(),new Og(Zh(a,Wc(a.length)))};var af=Wf(126);Gf(129,1,{},Qk);_.A=function(){hk(this.a)};var bf=Wf(129);Gf(55,1,ol,Rk);_.A=function(){tk(this.a,this.b)};_.b=0;var cf=Wf(55);Gf(56,1,ol,Sk);_.A=function(){sk(this.a,this.b)};_.b=0;var df=Wf(56);Gf(57,1,ol,Tk);_.A=function(){pk(this.a,this.b)};_.b=0;var ef=Wf(57);Gf(58,1,ol,Uk);_.A=function(){qk(this.a,this.b)};_.b=0;var ff=Wf(58);Gf(59,1,ol,Vk);_.A=function(){vk(this.a,this.b)};_.b=0;var gf=Wf(59);Gf(41,1,ol,Wk);_.A=function(){uk(this.a,this.b)};var hf=Wf(41);Gf(130,1,ol,Xk);_.A=function(){rk(this.a,this.b)};var jf=Wf(130);Gf(131,1,ol,Yk);_.A=function(){V(this.a)};var kf=Wf(131);Gf(132,1,ol,Zk);_.A=function(){ik(this.a,this.b)};var lf=Wf(132);Gf(133,1,ol,$k);_.A=function(){Bk(this.a)};var mf=Wf(133);Gf(134,1,ol,_k);_.A=function(){Ck(this.a,this.b)};var nf=Wf(134);Gf(194,$wnd.Function,{},al);_.ob=function(a){return new dl(a)};var bl;Gf(85,$wnd.React.Component,{},dl);Ff(Df[1],_);_.componentDidMount=function(){(Of(),$wnd.goog.global.window).speechSynthesis.cancel()};_.componentWillUnmount=function(){Zj(this.a)};_.render=function(){return bk(this.a)};_.shouldComponentUpdate=function(a){return 1==this.a.d};var pf=Wf(85);Gf(198,$wnd.Function,{},el);_.M=Ol;Gf(199,$wnd.Function,{},fl);_.M=Ol;Gf(200,$wnd.Function,{},gl);_.L=Ol;Gf(201,$wnd.Function,{},hl);_.M=Ol;Gf(202,$wnd.Function,{},il);_.M=Ol;Gf(203,$wnd.Function,{},jl);_.M=Ol;Gf(54,1,{},kl);_.kb=function(a){return a.default};var rf=Wf(54);Gf(115,1,{},ll);_.handleEvent=function(a){Gk(this.a.j)};var sf=Wf(115);Gf(116,1,{},ml);_.kb=function(a){return kk(this.a,a)};var tf=Wf(116);var hd=Yf('D');var nl=(wc(),zc);var gwtOnLoad=gwtOnLoad=Bf;zf(Mf);Cf('permProps',[[]]);if (webspeechdemo) webspeechdemo.onScriptLoad(gwtOnLoad);})();